// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/
// Converted to Typst by tao2typ: "2026-11-25T17:29:12.917748+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "G.R.H. Polymath", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("G.R.H. Polymath")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/")[#text("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-25 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")]#link("https://sites.math.duke.edu/~as1813/")[#text("Anurag Sahay")]#emph[#text(", ")#link("https://williamsawin.com/")[#text("Will Sawin")]#text(", and ")#link("https://personal.math.ubc.ca/~lior/")[#text("Lior Silberman")]#text(" – T.]")]

#text("Last Friday Levent Alpöge announced a Lean certicate containing a proof of the Generalized Riemann hypothesis. Since then there has been a flurry of activity in validating the certificate, and toward extracting a human-understnable proof and simplifying the Lean certificate itself.")

#text("It seems that this naturally suggests a Polymath-style project with several interrelated goals. These will naturally split into many")#linebreak()#text("sub-projects since the proof appears to touch on a range of mathematical fields within and without number theory.")

#list(
[#text("Bringing together the different efforts around the world under one roof, so that we can share our progress instead of duplicating effort.")],
[#text("Obtaining a human-readable and understandable proof of RH and GRH.")],
[#text("Understanding and clarifying any related literature.")],
[#text("Exploring further the mathematical advances embedded in the computer proof, and looking toward more general versions of the argument.")]
)

#text("We hope that enough results be obtained to justify publishing one or more review or research articles (which, traditionally, would be published under a pseudonym), but it is premature to discuss any details at this early stage of the process.")

#text("If you wish to contribute, please join the public forum ")#link("https://rh-polymath.zulipchat.com/")[#text("https://rh-polymath.zulipchat.com")]#text(". This will be public, with all discussions preserved and viewable without logging in.")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bcf76f63440f7d79f4d6a36dd9618b4808d330395daf5d19dcbec4f77b09c78-49c4881b95c0d221d329660a593af13b6c9d9adf71763763ef5974b85918a77d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jmdpark")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700067")[#strong[#text("jmdpark")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("Interested in seeing visually how things are inter-connected.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700070")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("There are several such diagrams; most on the Lean project Zulip.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sophie")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700073")[#strong[#text("Sophie")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("This is actually exciting! I’ve been vacillating between leaving maths and just doing some maths to regain composure, and now I think maybe a new way of ‘mathing’ is just starting to emerge. Hm …")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c44df296f4245adf3d3caeb19f2749a1d210cafa2769aff6f0ec6bd2d21c4341-3c12c69ecb80d93a22eea9bf7410efc77094096e0a2354c6e071b51ead8d9bbe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex P")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700072")[#strong[#text("Alex P")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("I’ve been waiting for this announcement. I have seen far too many fragmented attempts to abbreviate, recreate, restate the results without any public attempts at digestion.")

#text("I know that mathematicians are learning along the way as they adapt to this new world, but the lack of coordination has been concerning.")

#text("Polymath style is likely the best way forward for these large AI Lean releases moving forward, at the very least until AI also gets good at summarizing its own results.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700077")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("I saw that the Harder-Narasimhan filtration was mentioned, which I find surprising. Is it obvious why this is relevant?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700079")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("Joined. Thank you, this is a great idea.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57e7cbcff57466bec8bd836ad19663c2c7e702ea735f30ce356991db8eba080a-38a827ea3eada8a287f13cfddb08b5a01bac83b84c10127d2ed5f3341dbe204a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hypatiaa")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700080")[#strong[#text("hypatiaa")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("I can get behind this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d45398e9d3bd8454f0461b0fedcc93ba533bc4d656c0dc52771f156071188fbc-482e715e67977c5e7eea200b82b98026c4fde33ce29800458f4a83bda4c40a10.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian Bagshaw")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700081")[#strong[#text("Christian Bagshaw")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("Interested to see how digestible it really is.")

#text("After the big dump in October, David Harvey released a note a few weeks later about the integer multiplication result, and he seemed to only just be grasping the details, despite being (perhaps) the leading expert in the area.")

#text("I am wondering at what point AI will just start doing things that are beyond our ability to comprehend…")
]
