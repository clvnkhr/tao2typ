// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/
// Converted to Typst by tao2typ: "2026-10-14T07:22:42.909793+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Szemerédi-Trotter theorem and the cell decomposition", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Szemerédi-Trotter theorem and the cell decomposition")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 June 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/")[#text("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The celebrated ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di%E2%80%93Trotter_theorem")[#text("Szemerédi-Trotter theorem")]#text(" gives a bound for the set of incidences ")#mi("{I(P,L) := \\{ (p,\\ell) \\in P \\times L: p \\in \\ell \\}}")#text(" between a finite set of points ")#mi("{P}")#text(" and a finite set of lines ")#mi("{L}")#text(" in the Euclidean plane ")#mi("{{\\bf R}^2}")#text(". Specifically, the bound is ")#metadata(none) <tao-625f410f6b59c48a3f33>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|I(P,L)\\right| \\ll \\left|P\\right|^{2/3} \\left|L\\right|^{2/3} + \\left|P\\right| + \\left|L\\right|", block: true)]]

#text("where we use the asymptotic notation ")#mi("{X \\ll Y}")#text(" or ")#mi("{X=O(Y)}")#text(" to denote the statement that ")#mi("{X \\leq CY}")#text(" for some absolute constant ")#mi("{C}")#text(". In particular, the number of incidences between ")#mi("{n}")#text(" points and ")#mi("{n}")#text(" lines is ")#mi("{O(n^{4/3})}")#text(". This bound is sharp; consider for instance the discrete box ")#mi("{P := \\{ (a,b) \\in {\\bf Z}^2: 1 \\leq a \\leq N; 1 \\leq b \\leq 2N^2 \\}}")#text(" with ")#mi("{L}")#text(" being the collection of lines ")#mi("{\\{ (x,mx+b): m, b \\in {\\bf Z}, 1 \\leq m \\leq N, 1 \\leq b \\leq N^2 \\}}")#text(". One easily verifies that ")#tao-math("{\\left|P\\right|=2N^3}", block: false)#text(", ")#tao-math("{\\left|L\\right| = N^3}", block: false)#text(", and ")#tao-math("{\\left|I(P,L)\\right| = N^4}", block: false)#text(", showing that ")#link(<tao-625f410f6b59c48a3f33>)[#text("(1)")]#text(" is essentially sharp in the case ")#tao-math("{\\left|P\\right| \\sim \\left|L\\right|}", block: false)#text("; one can concoct similar examples for other regimes of ")#tao-math("{\\left|P\\right|}", block: false)#text(" and ")#tao-math("{\\left|L\\right|}", block: false)#text(".")

#text("On the other hand, if one replaces the Euclidean plane ")#mi("{{\\bf R}^2}")#text(" by a finite field geometry ")#mi("{F^2}")#text(", where ")#mi("{F}")#text(" is a finite field, then the estimate ")#link(<tao-625f410f6b59c48a3f33>)[#text("(1)")]#text(" is false. For instance, if ")#mi("{P}")#text(" is the entire plane ")#mi("{F^2}")#text(", and ")#mi("{L}")#text(" is the set of all lines in ")#mi("{F^2}")#text(", then ")#tao-math("{\\left|P\\right|, \\left|L\\right|}", block: false)#text(" are both comparable to ")#tao-math("{\\left|F\\right|^2}", block: false)#text(", but ")#tao-math("{\\left|I(P,L)\\right|}", block: false)#text(" is comparable to ")#tao-math("{\\left|F\\right|^3}", block: false)#text(", thus violating ")#link(<tao-625f410f6b59c48a3f33>)[#text("(1)")]#text(" when ")#tao-math("{\\left|F\\right|}", block: false)#text(" is large. Thus any proof of the Szemerédi-Trotter theorem must use a special property of the Euclidean plane which is not enjoyed by finite field geometries. In particular, this strongly suggests that one cannot rely purely on algebra and combinatorics to prove ")#link(<tao-625f410f6b59c48a3f33>)[#text("(1)")]#text("; one must also use some Euclidean geometry or topology as well.")

#text("Nowadays, the slickest proof of the Szemerédi-Trotter theorem is via the crossing number inequality (as discussed in ")#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/")[#text("this previous post")]#text("), which ultimately relies on ")#link("http://en.wikipedia.org/wiki/Euler_characteristic")[#text("Euler’s famous formula")]#text(" ")#tao-math("{\\left|V\\right|-\\left|E\\right|+\\left|F\\right|=2}", block: false)#text("; thus in this argument it is ")#emph[#text("topology")]#text(" which is the feature of Euclidean space which one is exploiting, and which is not present in the finite field setting. Today, though, I would like to mention a different proof (closer in spirit to the ")#link("http://www.ams.org/mathscinet-getitem?mr=729791")[#text("original proof of Szemerédi-Trotter")]#text(", and also a ")#link("http://www.ams.org/mathscinet-getitem?mr=1032370")[#text("later argument of Clarkson et al.")]#text("), based on the method of ")#emph[#text("cell decomposition")]#text(", which has proven to be a very flexible method in combinatorial incidence geometry. Here, the distinctive feature of Euclidean geometry one is exploiting is ")#emph[#text("convexity")]#text(", which again has no finite field analogue.")

#text("Roughly speaking, the idea is this. Using nothing more than the axiom that two points determine at most one line, one can obtain the bound ")#metadata(none) <tao-5f2b1d6f5492140fa7b4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|I(P,L)\\right| \\ll \\left|P\\right| \\left|L\\right|^{1/2} + \\left|L\\right|,", block: true)]]

#text("which is inferior to ")#link(<tao-625f410f6b59c48a3f33>)[#text("(1)")]#text(". (On the other hand, this estimate works in both Euclidean and finite field geometries, and is sharp in the latter case, as shown by the example given earlier.) Dually, the axiom that two lines determine at most one point gives the bound ")#metadata(none) <tao-f602b2d060e733bbcec0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|I(P,L)\\right| \\ll \\left|L\\right| \\left|P\\right|^{1/2} + \\left|P\\right|", block: true)]]

#text("(or alternatively, one can use projective duality to interchange points and lines and deduce ")#link(<tao-f602b2d060e733bbcec0>)[#text("(3)")]#text(" from ")#link(<tao-5f2b1d6f5492140fa7b4>)[#text("(2)")]#text(").")

#text("An inspection of the proof of ")#link(<tao-5f2b1d6f5492140fa7b4>)[#text("(2)")]#text(" shows that it is only expected to be sharp when the ")#emph[#text("bushes")]#text(" ")#mi("{L_p := \\{ \\ell \\in L: \\ell \\ni p \\}}")#text(" associated to each point ")#mi("{p \\in P}")#text(" behave like “independent” subsets of ")#mi("{L}")#text(", so that there is no significant correlation between the bush ")#mi("{L_p}")#text(" of one point and the bush of another point ")#mi("{L_q}")#text(".")

#text("However, in Euclidean space, we have the phenomenon that the bush of a point ")#mi("{L_p}")#text(" is influenced by the region of space that ")#mi("{p}")#text(" lies in. Clearly, if ")#mi("{p}")#text(" lies in a set ")#mi("{\\Omega}")#text(" (e.g. a convex polygon), then the only lines ")#mi("{\\ell \\in L}")#text(" that can contribute to ")#mi("{L_p}")#text(" are those lines which pass through ")#mi("{\\Omega}")#text(". If ")#mi("{\\Omega}")#text(" is a small convex region of space, one expects only a fraction of the lines in ")#mi("{L}")#text(" to actually pass through ")#mi("{\\Omega}")#text(". As such, if ")#mi("{p}")#text(" and ")#mi("{q}")#text(" both lie in ")#mi("{\\Omega}")#text(", then ")#mi("{L_p}")#text(" and ")#mi("{L_q}")#text(" are compressed inside a smaller subset of ")#mi("{L}")#text(", namely the set of lines passing through ")#mi("{\\Omega}")#text(", and so should be more likely to intersect than if they were independent. This should lead to an improvement to ")#link(<tao-5f2b1d6f5492140fa7b4>)[#text("(2)")]#text(" (and indeed, as we shall see below, ultimately leads to ")#link(<tao-625f410f6b59c48a3f33>)[#text("(1)")]#text(").")

#text("More formally, the argument proceeds by applying the following lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Cell decomposition)")]#text(" ")#metadata(none) <tao-39d02b42938b2b75d027>#text(" Let ")#mi("{L}")#text(" be a finite collection of lines in ")#mi("{{\\bf R}^2}")#text(", let ")#mi("{P}")#text(" be a finite set of points, and let ")#mi("{r \\geq 1}")#text(". Then it is possible to find a set ")#mi("{R}")#text(" of ")#mi("{O(r)}")#text(" lines in ")#mi("{L}")#text(", plus some additional open line segments not containing any point in ")#mi("{P}")#text(", which subdivide ")#mi("{{\\bf R}^2}")#text(" into ")#mi("{O(r^2)}")#text(" convex regions (or ")#emph[#text("cells")]#text("), such that the interior of each such cell is incident to at most ")#tao-math("{O(\\left|L\\right|/r)}", block: false)#text(" lines.")
]

#text("The deduction of ")#link(<tao-625f410f6b59c48a3f33>)[#text("(1)")]#text(" from ")#link(<tao-5f2b1d6f5492140fa7b4>)[#text("(2)")]#text(", ")#link(<tao-f602b2d060e733bbcec0>)[#text("(3)")]#text(" and Lemma ")#link(<tao-39d02b42938b2b75d027>)[#text("1")]#text(" is very quick. Firstly we may assume we are in the range ")#metadata(none) <tao-2269c0be009b610cfdbb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|L\\right|^{1/2} \\ll \\left|P\\right| \\ll \\left|L\\right|^2", block: true)]]

#text("otherwise the bound ")#link(<tao-625f410f6b59c48a3f33>)[#text("(1)")]#text(" follows already from either ")#link(<tao-5f2b1d6f5492140fa7b4>)[#text("(2)")]#text(" or ")#link(<tao-f602b2d060e733bbcec0>)[#text("(3)")]#text(" and some high-school algebra.")

#text("Let ")#mi("{r \\geq 1}")#text(" be a parameter ")#link("http://www.tricki.org/article/Keep_parameters_unspecified_until_it_is_clear_how_to_optimize_them")[#text("to be optimised later")]#text(". We apply the cell decomposition to subdivide ")#mi("{{\\bf R}^2}")#text(" into ")#mi("{O(r^2)}")#text(" open convex regions, plus a family ")#mi("{R}")#text(" of ")#mi("{O(r)}")#text(" lines. Each of the ")#mi("{O(r^2)}")#text(" convex regions ")#mi("{\\Omega}")#text(" has only ")#tao-math("{O(\\left|L\\right|/r)}", block: false)#text(" lines through it, and so by ")#link(<tao-5f2b1d6f5492140fa7b4>)[#text("(2)")]#text(" contributes ")#tao-math("{O( \\left|P \\cap \\Omega\\right| \\left|L\\right|^{1/2}/r^{1/2} + \\left|L\\right| / r )}", block: false)#text(" incidences. Meanwhile, on each of the lines ")#mi("{\\ell}")#text(" in ")#mi("{R}")#text(" used to perform this decomposition, there are at most ")#tao-math("{\\left|L\\right|}", block: false)#text(" transverse incidences (because each line in ")#mi("{L}")#text(" distinct from ")#mi("{\\ell}")#text(" can intersect ")#mi("{\\ell}")#text(" at most once), plus all the incidences along ")#mi("{\\ell}")#text(" itself. Putting all this together, one obtains")

#align(center)[#tao-fit-display[#tao-math("\\left|I(P,L)\\right| \\leq \\left|I(P,L \\cap R)\\right| + O( \\left|P\\right| \\left|L\\right|^{1/2}/r^{1/2} + \\left|L\\right| r).", block: true)]]

#text("We optimise this by selecting ")#tao-math("{r \\sim \\left|P\\right|^{2/3} / \\left|L\\right|^{1/3}}", block: false)#text("; from ")#link(<tao-2269c0be009b610cfdbb>)[#text("(4)")]#text(" we can ensure that ")#tao-math("{r \\leq \\left|L\\right|/2}", block: false)#text(", so that ")#tao-math("{\\left|L \\cap R\\right| \\leq \\left|L\\right|/2}", block: false)#text(". One then obtains")

#align(center)[#tao-fit-display[#tao-math("\\left|I(P,L)\\right| \\leq \\left|I(P,L \\cap R)\\right| + O( \\left|P\\right|^{2/3} \\left|L\\right|^{2/3} ).", block: true)]]

#text("We can iterate away the ")#mi("{L \\cap R}")#text(" error (halving the number of lines each time) and sum the resulting geometric series to obtain ")#link(<tao-625f410f6b59c48a3f33>)[#text("(1)")]#text(".")

#text("It remains to prove ")#link(<tao-39d02b42938b2b75d027>)[#text("(1)")]#text(". If one subdivides ")#mi("{{\\bf R}^2}")#text(" using ")#mi("{r}")#text(" arbitrary lines, one creates at most ")#mi("{O(r^2)}")#text(" cells (because each new line intersects the existing lines at most once, and so can create at most ")#mi("{O(r)}")#text(" distinct cells), and for a similar reason, every line in ")#mi("{L}")#text(" visits at most ")#mi("{r}")#text(" of these regions, and so by double counting one expects ")#tao-math("{O(\\left|L\\right|/r)}", block: false)#text(" lines per cell “on the average”. The key difficulty is then to get ")#tao-math("{O(\\left|L\\right|/r)}", block: false)#text(" lines through ")#emph[#text("every")]#text(" cell, not just on the average. It turns out that a probabilistic argument will almost work, but with a logarithmic loss (thus having ")#tao-math("{O( \\left|L\\right| \\log \\left|L\\right| / r )}", block: false)#text(" lines per cell rather than ")#tao-math("{O(\\left|L\\right|/r)}", block: false)#text("); but with a little more work one can then iterate away this loss also. The arguments here are loosely based on those of ")#link("http://www.ams.org/mathscinet-getitem?mr=1032370")[#text("Clarkson et al.")]#text("; a related (deterministic) decomposition also appears in the ")#link("http://www.ams.org/mathscinet-getitem?mr=729791")[#text("original paper of Szemerédi and Trotter")]#text(". But I wish to focus here on the probabilistic approach.)")

#text("It is also worth noting that the original (somewhat complicated) argument of Szemerédi-Trotter has been adapted to establish the analogue of ")#link(<tao-625f410f6b59c48a3f33>)[#text("(1)")]#text(" in the complex plane ")#mi("{{\\bf C}^2}")#text(" ")#link("http://arxiv.org/abs/math/0305283")[#text("by Toth")]#text(", while the other known proofs of Szemerédi-Trotter, so far, have not been able to be extended to this setting (the Euler characteristic argument clearly breaks down, as does any proof based on using lines to divide planes into half-spaces). So all three proofs have their advantages and disadvantages.")

#metadata(none) <tao-dbf94ebfbeef47283e7e>

#heading(level: 1)[#strong[#text(" — 1. The trivial incidence estimate — ")]]

#text("We first give a quick proof of the trivial incidence bound ")#link(<tao-5f2b1d6f5492140fa7b4>)[#text("(2)")]#text(". We have")

#align(center)[#tao-fit-display[#tao-math("\\left|I(P,L)\\right| = \\sum_{\\ell \\in L} \\left|P \\cap \\ell\\right|", block: true)]]

#text("and thus by Cauchy-Schwarz")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\ell \\in L} \\left|P \\cap \\ell\\right|^2 \\geq \\frac{\\left|I(P,L)\\right|^2}{\\left|L\\right|}.", block: true)]]

#text("On the other hand, observe that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\ell \\in L} \\left|P \\cap \\ell\\right|^2 - \\left|P \\cap \\ell\\right| = | \\{ (p,q,\\ell) \\in P \\times P \\times L: p \\neq q; p,q \\in \\ell \\}.", block: true)]]

#text("Because two distinct points ")#mi("{p,q}")#text(" are incident to at most one line, the right-hand side is at most ")#tao-math("{\\left|P\\right|^2}", block: false)#text(", thus")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\ell \\in L} \\left|P \\cap \\ell\\right|^2 \\leq \\left|I(P,L)\\right| + \\left|P\\right|^2.", block: true)]]

#text("Comparing this with the Cauchy-Schwarz bound and using a little high-school algebra we obtain ")#link(<tao-5f2b1d6f5492140fa7b4>)[#text("(2)")]#text(". A dual argument (swapping the role of lines and points) give ")#link(<tao-f602b2d060e733bbcec0>)[#text("(3)")]#text(".")

#text("A more informal proof of ")#link(<tao-5f2b1d6f5492140fa7b4>)[#text("(2)")]#text(" can be given as follows. Suppose for contradiction that ")#tao-math("{\\left|I(P,L)\\right|}", block: false)#text(" was much larger than ")#tao-math("{\\left|P\\right| \\left|L\\right|^{1/2} + \\left|L\\right|}", block: false)#text(". Since ")#tao-math("{\\left|I(P,L)\\right| = \\sum_{p \\in P} \\left|L_p\\right|}", block: false)#text(", this implies that that the ")#tao-math("{\\left|L_p\\right|}", block: false)#text(" are much larger than ")#tao-math("{\\left|L\\right|^{1/2}}", block: false)#text(" on the average. By the ")#link("http://en.wikipedia.org/wiki/Birthday_paradox")[#text("birthday paradox")]#text(", one then expects two randomly chosen ")#mi("{L_p, L_q}")#text(" to intersect in at least two places ")#mi("{\\ell, \\ell^{\\prime}}")#text("; but this would mean that two lines intersect in two points, a contradiction. The use of Cauchy-Schwarz in the rigorous argument given above can thus be viewed as an assertion that the average intersection of ")#mi("{L_p}")#text(" and ")#mi("{L_q}")#text(" is at least as large as what random chance predicts.")

#text("As mentioned in the introduction, we now see (intuitively, at least) that if nearby ")#mi("{p, q}")#text(" are such that ")#mi("{L_p, L_q}")#text(" are drawn from a smaller pool of lines than ")#mi("{L}")#text(", then their intersection is likely to be higher, and so one should be able to improve upon ")#link(<tao-5f2b1d6f5492140fa7b4>)[#text("(2)")]#text(".")

#heading(level: 1)[#strong[#text(" — 2. The probabilistic bound — ")]]

#text("Now we start proving Lemma ")#link(<tao-39d02b42938b2b75d027>)[#text("1")]#text(". We can assume that ")#tao-math("{r < \\left|L\\right|}", block: false)#text(", since the claim is trivial otherwise (we just use all the lines in ")#mi("{L}")#text(" to subdivide the plane, and there are no lines left in ")#mi("{L}")#text(" to intersect any of the cells). Similarly we may assume that ")#mi("{r > 1}")#text(", and that ")#tao-math("{\\left|L\\right|}", block: false)#text(" is large. We can also perturb all the lines slightly and assume that the lines are in general position (no three are concurrent), as the general claim then follows from a limiting argument (note that this may send some of the cells to become empty). (Of course, the Szemerédi-Trotter theorem is quite easy under the assumption of general position, but this theorem is not our current objective right now.)")

#text("We use the ")#link("http://en.wikipedia.org/wiki/Probabilistic_method")[#text("probabilistic method")]#text(", i.e. we construct ")#mi("{R}")#text(" by some random recipe and aim to show that the conclusion of the lemma holds with positive probaility.")

#text("The most obvious approach would be to choose the ")#mi("{r}")#text(" lines ")#mi("{R}")#text(" at random from ")#mi("{L}")#text(", thus each line ")#mi("{\\ell \\in L}")#text(" has a probability of ")#tao-math("{r/\\left|L\\right|}", block: false)#text(" of lying in ")#mi("{R}")#text(". Actually, for technical reasons it is slightly better to use a Bernoulli process to select ")#mi("{R}")#text(", thus each line ")#mi("{\\ell \\in L}")#text(" lies in ")#mi("{R}")#text(" with an ")#emph[#text("independent")]#text(" probability of ")#tao-math("{r/\\left|L\\right|}", block: false)#text(". This can cause ")#mi("{R}")#text(" to occasionally have size much larger than ")#mi("{r}")#text(", but this probability can be easily controlled (e.g. using the ")#link("http://en.wikipedia.org/wiki/Chernoff_bound")[#text("Chernoff inequality")]#text("). So with high probability, ")#mi("{R}")#text(" consists of ")#mi("{O(r)}")#text(" lines, which therefore carve out ")#mi("{O(r^2)}")#text(" cells. The remaining task is to show that each cell is incident to at most ")#tao-math("{O(\\left|L\\right|/r)}", block: false)#text(" lines from ")#mi("{L}")#text(".")

#text("Observe that each cell is a (possibly unbounded) polygon, whose edges come from lines in ")#mi("{R}")#text(". Note that (except in the degenerate case when ")#mi("{R}")#text(" consists of at most one line, which we can ignore) any line ")#mi("{\\ell}")#text(" which meets a cell in ")#mi("{R}")#text(", must intersect at least one of the edges of ")#mi("{R}")#text(". If we pretend for the moment that all cells have a bounded number of edges, it would then suffice to show that each edge of each cell was incident to ")#tao-math("{O(\\left|L\\right|/r)}", block: false)#text(" lines.")

#text("Let’s see how this would go. Suppose that one line ")#mi("{\\ell \\in L}")#text(" was picked for the set ")#mi("{R}")#text(", and consider all the other lines in ")#mi("{L}")#text(" that intersect ")#mi("{\\ell}")#text("; there are ")#tao-math("{O(\\left|L\\right|)}", block: false)#text(" of these lines ")#mi("{\\ell^{\\prime}}")#text(", which (by the general position hypothesis) intersect ")#mi("{\\ell}")#text(" at distinct points ")#mi("{\\ell \\cap \\ell^{\\prime}}")#text(" on the line. If one of these lines ")#mi("{\\ell^{\\prime}}")#text(" intersecting ")#mi("{\\ell}")#text(" is also selected for ")#mi("{R}")#text(", then the corresponding point ")#mi("{\\ell \\cap \\ell^{\\prime}}")#text(" will become a vertex of one of the cells (indeed, it will be the vertex of four cells). Thus each of these points on ")#mi("{\\ell}")#text(" has an independent probability of ")#tao-math("{r/\\left|L\\right|}", block: false)#text(" of becoming a vertex for a cell.")

#text("Now consider ")#mi("{m}")#text(" consecutive such points on ")#mi("{\\ell}")#text(". The probability that they all fail to be chosen as cell vertices is ")#tao-math("{(1-r/\\left|L\\right|)^m}", block: false)#text("; if ")#tao-math("{m = k \\left|L\\right|/r}", block: false)#text(", then this probability is ")#mi("{O( \\exp( - k ) )}")#text(". Thus runs of much more than ")#tao-math("{\\left|L\\right|/r}", block: false)#text(" points without vertices are unlikely. In particular, setting ")#tao-math("{k = 100 \\log \\left|L\\right|}", block: false)#text(", we see that the probability that any given ")#tao-math("{100 |L| \\log \\left|L\\right|/r}", block: false)#text(" consecutive points on any given line ")#mi("{\\ell}")#text(" are skipped is ")#tao-math("{O( \\left|L\\right|^{-100} )}", block: false)#text(". By the union bound, we thus see that with probability ")#tao-math("{1-O(\\left|L\\right|^{-98})}", block: false)#text(", that ")#emph[#text("every")]#text(" line ")#mi("{\\ell}")#text(" has at most ")#tao-math("{O( \\left|L\\right| \\log \\left|L\\right|/r )}", block: false)#text(" points between any two adjacent vertices. Or in other words, the edge of every cell is incident to at most ")#tao-math("{O( \\left|L\\right| \\log \\left|L\\right| / r )}", block: false)#text(" lines from ")#mi("{L}")#text(". This yields Lemma ")#link(<tao-39d02b42938b2b75d027>)[#text("1")]#text(" except for two things: firstly, the logarthmic loss of ")#tao-math("{O( \\log \\left|L\\right| )}", block: false)#text(", and secondly, the assumption that each cell had only a bounded number of edges.")

#text("To fix the latter problem, we will have to add some line segments to ")#mi("{R}")#text(". First, we randomly rotate the plane so that none of the lines in ")#mi("{L}")#text(" are vertical. Then we do the following modified construction: we select ")#mi("{O(r)}")#text(" lines from ")#mi("{L}")#text(" as before, creating ")#mi("{O(r^2)}")#text(" cells, some of which may have a very large number of edges. But then for each cell, and each vertex in that cell, we draw a vertical line segment from that vertex (in either the up or down direction) to bisect the cell into two pieces. (If the vertex is on the far left or far right of the cell, we do nothing.) Note that almost surely this construction will avoid hitting any point in ")#mi("{P}")#text(". Doing this once for each vertex, we see that we have subdivided each of the old cells into a number of new cells, each of which have at most four sides (two vertical sides, and two non-vertical sides). So we have now achieved a bounded number of sides per cell. But what about the number of such cells? Well, each vertex of each cell is responsible for at most two subdivisions of one cell into two, and the number of such vertices is at most ")#mi("{O(r^2)}")#text(" (as they are formed by intersecting two lines from the original selection of ")#mi("{O(r)}")#text(" lines together), so the total number of cells is still ")#mi("{O(r^2)}")#text(".")

#text("Is it still true that each edge of each cell is incident to ")#tao-math("{O( \\left|L\\right| \\log \\left|L\\right| / r )}", block: false)#text(" lines in ")#mi("{L}")#text("? We have already proven this (with high probability) for all the old edges – the ones that were formed from lines in ")#mi("{L}")#text(". But there are now some new edges, caused by dropping a vertical line segment from the intersection of two lines in ")#mi("{L}")#text(". But it is not hard to see that one can use much the same argument as before to see that with high probability, each of these line segments is incident to at most ")#tao-math("{O( \\left|L\\right| \\log \\left|L\\right| / r)}", block: false)#text(" lines in ")#mi("{L}")#text(" as desired.")

#text("Finally, we have to get rid of the logarithm. An inspection of the above arguments (and a use of the first moment method) reveals the following refinement: for any ")#mi("{k \\geq 1}")#text(", there are expected to be at most ")#mi("{O( \\exp(-k) r^2 )}")#text(" cells which are incident to more than ")#tao-math("{C k \\left|L\\right| / r}", block: false)#text(" lines, where ")#mi("{C}")#text(" is an absolute constant. This is already enough to improve the ")#tao-math("{O( \\left|L\\right| \\log \\left|L\\right| / r )}", block: false)#text(" bound slightly to ")#tao-math("{O( \\left|L\\right| \\log r / r )}", block: false)#text(". But one can do even better by using Lemma ")#link(<tao-39d02b42938b2b75d027>)[#text("1")]#text(" as an induction hypothesis, i.e. assume that for any smaller set ")#mi("{L^{\\prime}}")#text(" of lines with ")#tao-math("{\\left|L^{\\prime}\\right| < \\left|L\\right|}", block: false)#text(", and any ")#mi("{r^{\\prime} \\geq 1}")#text(", one can partition ")#mi("{L^{\\prime}}")#text(" into at most ")#mi("{C_1 (r^{\\prime})^2}")#text(" cells using at most ")#mi("{C_0 r^{\\prime}}")#text(" lines such that each cell is incident to at most ")#tao-math("{C_2 \\left|L^{\\prime}\\right|/r^{\\prime}}", block: false)#text(" lines, where ")#mi("{C_1, C_2, C_3}")#text(" are absolute constants. (When using induction, asymptotic notation becomes quite dangerous to use, and it is much safer to start writing out the constants explicitly. To close the induction, one has to end up with the same constants ")#mi("{C_0,C_1,C_2}")#text(" as one started with.) For each ")#mi("{k}")#text(" between ")#mi("{C_2/C}")#text(" and ")#mi("{O(\\log r)}")#text(" which is a power of two, one can apply the induction hypothesis to all the cells which are incident to between ")#tao-math("{C k \\left|L\\right|/r}", block: false)#text(" and ")#tao-math("{2Ck \\left|L\\right|/r}", block: false)#text(" (with ")#mi("{L^{\\prime}}")#text(" set equal to the lines in ")#mi("{L}")#text(" incident to this cell, and ")#mi("{r^{\\prime}}")#text(" set comparable to ")#mi("{2Ck}")#text("), and sum up (using the fact that ")#mi("{\\sum_k k^2 \\exp(-k)}")#text(" converges, especially if ")#mi("{k}")#text(" is restricted to powers of two) to close the induction if the constants ")#mi("{C_0, C_1, C_2}")#text(" are chosen properly; we leave the details as an exercise.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (26)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-39420")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2009")])]

#text("Is there at this point any proof of Szemeredi-Trotter via something like the polynomal method? This “Algebraic Methods…” paper of Guth and Katz is at least one instance where the method gives you some new insight into problems about the combinatorics of incidences.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-39422")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2009")])]

#text("I certainly think so! For one thing, there is a link between Szemeredi-Trotter and sum-product theorems (this is discussed in my crossing number article), so having a new approach to Szemeredi-Trotter, such as a polynomial approach, may well lead to new sum-product theorems, which is certainly of interest. Also, the current proof of Szemeredi-Trotter in the complex plane is rather messy; a clean proof would be good. Finally, the F_p Szemeredi-Trotter paper in my paper with Bourgain and Katz is only an epsilon better than trivial, and only applies to situations in which the number of lines and points is the same; improving either of these would be desirable (I understand that removing the latter would be helpful for some of the SL_d(F_p) product estimates).")

#text("There is also the problem of getting a good inverse theorem, i.e. when is Szemeredi-Trotter close to sharp? It’s unlikely that the polynomial method would help with that specific question, but having some other proof of Szemeredi-Trotter could also be useful for this purpose.")

#text("Finally, developing the polynomial method for its own sake seems worthwhile – it looks like an approach with a lot of potential for other combinatorial incidence geometry problems.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-39426")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2009")])]

#text("You “certainly think so” meaning such a proof is already known, or that it would be good if it were? I’m wholeheartedly with you on the latter.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-39432")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2009")])]

#text("Ah, I misread your “Is there at this point any” as “Is there any point to have a” :-). No, I don’t know of such an argument, but I would love to hear of one.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9946c9121e0cb957d136b5263170c8a16bc3714a9752b67f86f1a8e55f6903c-d05b29fec6ff76805e2997f2a2e0fd4a3c2f601ae9c890328792ae8a4468c320.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jozsef")]], [#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-39435")[#strong[#text("jozsef")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2009")])]

#text("Dear Terry. I think that the cutting lemma proof – which you presented here – tells us more about the structure of point-line arrangements with almost maximal number of incidences. Let me give an example. In your calculations you count lines being incident to two points in a cell it crosses. If the number of incidences is close to the Szemeredi-Trotter bound then using a cell decomposition one can guarantee that a typical line is incident to at least 3 points in a cell. Then a typical cell which has ")#mi("N")#text(" points has about ")#mi("cH^2")#text(" many collinear triples. Then, by Ruzsa-Szemeredi, it contains many (")#mi("c^{\\prime}H^3")#text(") triangles. So, one can see that if an arrangement has many incidences then it contains many triangles.")#linebreak()#text(" It would be nice to see a simple geometric proof for this; show (without using Ruzsa-Szemeredi) that for every positive c there is threshold ")#mi("n_0")#text(" that if ")#mi("n\\geq n_0")#text(" and the number of incidences between a set of n points, P, and a set of n lines, L, is at least ")#mi("cn^{4/3}")#text(" then there is a triangle, (i.e. three lines from L that the three crossing points are in P.)")#linebreak()#text(" About Csaba Toth’s paper on the complex case; As far as I know the manuscript has been at COMBINATORICA for more than 8 years(!) without a final decision. I believe that Csaba’s result is correct, however it might be difficult to referee.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b3b201f0308437d9f237aa2421c789a8ff84f856f2240209b2ad74a1592accc-e239f0fb4837efa15a46cd87f105e0f109c8ac7df42ba28e6eea88c2d9098976.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of iosevich")]], [#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-39443")[#strong[#text("iosevich")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2009")])]

#text("Are there any recent results in the direction of improving Szemeredi-Trotter for points and circles of the same radius?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-39452")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2009")])]

#emph[#text("As far as I know the manuscript has been at COMBINATORICA for more than 8 years(!) without a final decision.")]

#text("Time for the Polyreferee Project?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98573df78f21738ee208f46fda080b63615a41ce5430e3c317e3486a824e3f31-80e52398808cb1c9751e2014daffca486d9666169325f07daef7e4b24e348b5b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of E. Mehmet Kıral")]], [#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-39605")[#strong[#text("E. Mehmet Kıral")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2009")])]

#text("Dear Professor Tao,")

#text("I fail to see how you could conclude that the proof of Szemeredi-Trotter theorem must essentially use some sort of topological or convexity argument from the finite field example you gave above.")

#text("The Szemeredi-Trotter theorem given above involves an asymptotic inequality on the number of points and lines. However in the finite plane these are bounded and by choosing the hidden constant sufficiently large, we may let the inequality be satisfied.")

#text("Or is there some reason to believe that a generalization of Szemeredi-Trotter theorem to finite fields must involve a constant that is independent of the field (or maybe only dependent on the characteristic)?")

#text("Perhaps by observing that this result does not hold in “infinite characteristic p” fields, or maybe in fields with a quite different topology such as the p-adics we may deduce that the convexity arguments were necessary. Maybe it does.")

#text("Best Regards,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-39609")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2009")])]

#text("Dear Mehmet,")

#text("Well, if a proof of Szemeredi-Trotter did not use anything special about the ambient field, such as topology or convexity, then it would apply uniformly for all fields, and the finite field examples show that this is not the case; one cannot make the implied constant C the same for every choice of finite field, though of course as you say one can trivially find a C for any fixed choice of finite field for which Szemeredi-Trotter holds.")

#text("Also, it is not difficult to pack a lot of finite field examples (with the same characteristic) into an infinite field example. Consider for instance the algebraic closure ")#mi("\\overline{F}")#text(" of a finite field. This contains arbitrary large finite subfields G, just take any finite extension of F. For each such subfield G, one can create a Szemeredi-Trotter counterexample in the plane ")#mi("G^2")#text(" and hence in the plane ")#mi("\\overline{F}^2")#text(" by the construction in the post; thus Szemeredi-Trotter fails (for any choice of constant) for the field ")#mi("\\overline{F}")#text(". Thus any proof of Szemeredi-Trotter must use some property of the real line which is not shared by ")#mi("\\overline{F}")#text(", which seems to rule out most of the purely algebraic approaches to the problem, and is consistent with the fact that all known proofs use either topological or convexity methods.")

#text("[Actually, there is a loophole here. There is known to be a link between Szemeredi-Trotter theorems and sum-product theorems. The latter can be established by algebraic (and combinatorial) means, the main ingredient being a hypothesis that the ambient field contains no finite subfields, a statement which does indeed distinguish the real line from examples such as ")#mi("\\overline{F}")#text("; this is done for instance in my book with Van Vu. It is also known that sum-product theorems can yield some non-trivial results of Szemeredi-Trotter type (see e.g. my paper with Bourgain and Katz) but there is no known way of using this technology to establish the full Szemeredi-Trotter theorem.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-39718")[#strong[#text("Points and lines « Konrad Swanepoel’s blog")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2009")]

#text("[…] June 2009 in Discrete Geometry Terry Tao has a great post about the Szemeredi-Trotter theorem on the maximum number of incidences between m points and n […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Guth-Katz bound on the Erdős distance problem « What’s new")]], [#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-48203")[#strong[#text("The Guth-Katz bound on the Erdős distance problem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2010")])]

#text("[…] number methods (as discussed in this previous blog post) or by cell decomposition (as discussed in this previous blog post). In both cases, the order structure of (and in particular, the fact that a line divides a plane […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Szemeredi-Trotter theorem via the polynomial ham sandwich theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-50313")[#strong[#text("The Szemeredi-Trotter theorem via the polynomial ham sandwich theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2011")])]

#text("[…] (as discussed in this previous post) or via a slightly different type of cell decomposition (as discussed here). The proof given below is not that different, in particular, from the latter proof, but I believe […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/119aae497a73e3767304a4e6f80580cb879a1a225b91ee54aa626d4c0ba04718-bc771c68e07e9b2d6d6b6e5895afdd4b3028492ae39bc6302152a26a702433a2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Taole Zhu")]], [#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-50913")[#strong[#text("Taole Zhu")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2011")])]

#text("Does the cell decomposition lemma have a multidimensional analogue?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-50919")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2011")])]

#text("Yes. See for instance")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/")[#text("The Guth-Katz bound on the Erdős distance problem")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1395258b13a9c4e9077a99f526e3525b74ae78a3b38c04eaaf3753d067c23192-f886f31090e27a866fa44ea3cdd4c26dbd922190c59bb409b4488b9951712392.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of iitdelhireport")]], [#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-127223")[#strong[#text("iitdelhireport")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2012")])]

#text("Dear Terry, I know I am almost three years late to notice, but why can we guarantee that the cardinality of R is O(r)? My problem is that in your proof we might add r^2 vertical segments when we “fix the latter problem”.")

#text("At other places (e.g. Matousek’s book) it is only claimed that the number of cells is O(r^2). I wonder if this stronger version also holds.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-127236")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2012")])]

#text("Well, the only reason we needed R have cardinality O(r) is so that we have only O(r^2) cells, and we keep that latter property when the vertical line segments are added, so the cardinality of the modified R is no longer relevant. (I guess it would be more precise to say that we are not modifying R, but rather modifying how the cells are constructed from R.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1395258b13a9c4e9077a99f526e3525b74ae78a3b38c04eaaf3753d067c23192-f886f31090e27a866fa44ea3cdd4c26dbd922190c59bb409b4488b9951712392.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of iitdelhireport")]], [#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-127254")[#strong[#text("iitdelhireport")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2012")])]

#text("Thank you for your fast reply. I agree with you completely but in this case Lemma 1 is quite misunderstandable as you stated it in the post. It suggests that the cells are derived by partitioning the plane by r lines, which is not the case.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-127257")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2012")])]

#text("Ah, a fair point; I’ve reworded the text accordingly.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-127575")[#strong[#text("Mistery solved! « iitdelhireport")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2012")]

#text("[…] ")#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#c")[#text("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#c")]#text("… Share this:TwitterFacebookLike this:LikeBe the first to like this post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-152091")[#strong[#text("Is the cutting lemma true with O(r) lines? | Q&A System")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2012")]

#text("[…] The cutting lemma (a.k.a. cell decomposition lemma) states that given $n$ lines within the plane you’ll be able to divide it into $O(r^2)$ regions (even triangles) for just about any $1le rle n$ so that the inside associated with a region is intersected by $O(n/r)$ lines. For additional see e.g. Matousek’s book Lectures on Discrete Geometry or this publish. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-225210")[#strong[#text("Is the cutting lemma true with O(r) lines? | Question and Answer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2013")]

#text("[…] The cutting lemma (a.k.a. cell decomposition lemma) states that given $n$ lines in the plane it is possible to divide it into $O(r^2)$ regions (even triangles) for any $1le rle n$ such that the interior of any region is intersected by $O(n/r)$ lines. For more see e.g. Matousek’s book Lectures on Discrete Geometry or this post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a01f264f48f5e05d5d685b9021d8eabe021cba75bb29f31f0c2c489198037bd-3a332be6c68a6a6e665ca9294ad450f10654091c15e3a2b8f42c50a2c9b259ff.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Incidence Bounds and Interlacing Eigenvalues | Anurag's Math Blog")]], [#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-472602")[#strong[#text("Incidence Bounds and Interlacing Eigenvalues | Anurag's Math Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2016")])]

#text("[…] some constant . This result can be proved in several ways (including polynomial method), all of which use some topological property of the real plane. The same result does not hold over […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/06b49e42049f123eab962f78f41a164ed3ce8d7bf135730a98573933b7671551-ab570b99141487b372d9e151b598015bdffd2fc139905cbe624d27d8068f3d33.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Natalie Behague")]], [#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-658441")[#strong[#text("Natalie Behague")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("Hello! I have a question about the induction step at the end. I believe you are saying that for each ‘bad’ cell with more than C|L|/r lines intersecting it, we add to the set R the lines R’ given by the induction hypothesis, where L’ is the set of lines intersecting this cell.")

#text("For k a power of 2 say a cell has ‘badness’ k if it has between k C|L|/r and 2k C|L|/r lines intersecting it. The number of cells with badness k is about r^2e^{-k}. So in total we add about sum(r^2 e^{-k} 2Ck) new lines, summing over k being all powers of 2. This is O(r^2) lines added. Isn’t this too many? Have I misunderstood the inductive step?")

#text("Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-658452")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("Hmm, you’re right, the inductive argument does not close as stated. One can omit this induction and just settle for a weaker lemma in which one allows, for each ")#mi("k")#text(", to have a small number ( ")#mi("O( \\exp(-k) r^2 )")#text(" or so) cells in which one has as many as ")#tao-math("O(k\\left|L\\right|/r)", block: false)#text(" lines per cell, and this is still good enough for most applications. (Looking back at the Clarkson et al. paper, I now see that they also only control incidences per cell on the average, although they do cite other results of Chazelle-Friedman and Matousek that get the uniformity by a more complicated argument.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-692861")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2026")])]

#text("Regarding the use of the birthday paradox in the paper, you “picked” k＝| L_p | lines from L as your set of birthdays, for each point p, is that correct?")

#text("I’ve always been curious about the birthday paradox, but I never understood its essence. Ultimately, what is the underlying cause of the birthday paradox?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/#comment-692865")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2026")])]

#text("Yes, this is correct.")

#text("I view the birthday paradox as a natural consequence of Metcalfe’s law. (See ")#link("https://claude.ai/share/89f0db89-319c-4c85-807c-a88d9a703fed")[#text("this AI-generated answer")]#text(" for further elaboration.)")
]
]
