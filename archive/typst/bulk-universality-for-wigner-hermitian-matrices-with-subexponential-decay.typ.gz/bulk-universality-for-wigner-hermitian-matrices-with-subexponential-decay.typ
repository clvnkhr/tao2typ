// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/06/26/bulk-universality-for-wigner-hermitian-matrices-with-subexponential-decay/
// Converted to Typst by tao2typ: "2026-10-14T07:23:03.558950+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Bulk universality for Wigner hermitian matrices with subexponential decay", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Bulk universality for Wigner hermitian matrices with subexponential decay")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 June 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/06/26/bulk-universality-for-wigner-hermitian-matrices-with-subexponential-decay/")[#text("https://terrytao.wordpress.com/2009/06/26/bulk-universality-for-wigner-hermitian-matrices-with-subexponential-decay/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("One further paper in this stream: ")#link("http://www.mathematik.uni-muenchen.de/~lerdos/")[#text("László Erdős")]#text(", José Ramírez, ")#link("http://www.dpmms.cam.ac.uk/~bds32/")[#text("Benjamin Schlein")]#text(", ")#link("http://www.dpmms.cam.ac.uk/~bds32/")[#text("Van Vu")]#text(", ")#link("http://as.nyu.edu/object/horngtzeryau.html")[#text("Horng-Tzer Yau")]#text(", and myself have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" the paper “")#link("http://arxiv.org/abs/0906.4400")[#text("Bulk universality for Wigner hermitian matrices with subexponential decay")]#text("“, submitted to ")#link("http://math.ucsd.edu/~mrl/")[#text("Mathematical Research Letters")]#text(". (Incidentally, this is my first six-author paper I have been involved in, not counting the ")#link("http://en.wordpress.com/tag/polymath1/")[#text("polymath")]#text(" projects of course, though I have had a number of five-author papers.)")

#text("This short paper (9 pages) combines the machinery from two recent papers on the universality conjecture for the eigenvalue spacings in the bulk for Wigner random matrices (see ")#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/")[#text("my earlier blog post")]#text(" for more discussion). On the one hand, the ")#link("http://arxiv.org/abs/0905.4176")[#text("paper of Erdős-Ramírez-Schlein-Yau")]#text(" established this conjecture under the additional hypothesis that the distribution of the individual entries obeyed some smoothness and exponential decay conditions. Meanwhile, the ")#link("http://arxiv.org/abs/0906.0510")[#text("paper of Van Vu and myself")]#text(" (which I discussed in ")#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/")[#text("my earlier blog post")]#text(") established the conjecture under a somewhat different set of hypotheses, namely that the distribution of the individual entries obeyed some moment conditions (in particular, the third moment had to vanish), a support condition (the entries had to have real part supported in at least three points), and an exponential decay condition.")

#text("After comparing our results, the six of us realised that our methods could in fact be combined rather easily to obtain a stronger result, establishing the universality conjecture assuming only a exponential decay (or more precisely, sub-exponential decay) bound ")#tao-math("{\\Bbb P}(\\left|x_{\\ell k}\\right| > t ) \\ll \\exp( - t^c )", block: false)#text(" on the coefficients; thus all regularity, moment, and support conditions have been eliminated. (There is one catch, namely that we can no longer control a single spacing ")#mi("\\lambda_{i+1}-\\lambda_i")#text(" for a single fixed i, but must now average over all ")#mi("1 \\leq i \\leq n")#text(" before recovering the universality. This is an annoying technical issue but it may be resolvable in the future with further refinements to the method.)")

#text("I can describe the main idea behind the unified approach here. One can arrange the Wigner matrices in a hierarchy, from most structured to least structured:")

#list(
[#text("The most structured (or special) ensemble is the ")#emph[#text("Gaussian Unitary Ensemble")]#text(" (GUE), in which the coefficients are gaussian. Here, one has very explicit and tractable formulae for the eigenvalue distributions, gap spacing, etc.")],
[#text("The next most structured ensemble of Wigner matrices are the ")#emph[#text("Gaussian-divisible")]#text(" or ")#emph[#text("Johansson matrices")]#text(", which are matrices H of the form ")#mi("H = e^{-t/2} \\hat H + (1-e^{-t})^{1/2} V")#text(", where ")#mi("\\hat H")#text(" is another Wigner matrix, V is a GUE matrix independent of ")#mi("\\hat H")#text(", and ")#mi("0 < t < 1")#text(" is a fixed parameter independent of n. Here, one still has quite explicit (though not quite as tractable) formulae for the joint eigenvalue distribution and related statistics. Note that the limiting case t=1 is GUE.")],
[#text("After this, one has the ")#emph[#link("http://en.wikipedia.org/wiki/Ornstein-Uhlenbeck_process")[#text("Ornstein-Uhlenbeck")]#text("-evolved")]#emph[#text(" matrices")]#text(", which are also of the form ")#mi("H = e^{-t/2} \\hat H + (1-e^{-t})^{1/2} V")#text(", but now ")#mi("t = n^{-1+\\delta}")#text(" decays at a power rate with n, rather than being comparable to 1. Explicit formulae still exist for these matrices, but extracting universality out of this is hard work (and occupies the bulk of the ")#link("http://arxiv.org/abs/0905.4176")[#text("paper of Erdős-Ramírez-Schlein-Yau")]#text(").")],
[#text("Finally, one has arbitrary Wigner matrices, which can be viewed as the t=0 limit of the above Ornstein-Uhlenbeck process.")]
)

#text("The arguments in the ")#link("http://arxiv.org/abs/0905.4176")[#text("paper of Erdős-Ramírez-Schlein-Yau")]#text(" can be summarised as follows (I assume subexponential decay throughout this discussion):")

#enum(start: 1, 
[#text("(Structured case) The universality conjecture is true for Ornstein-Uhlenbeck-evolved matrices with ")#mi("t = n^{-1+\\delta}")#text(" for any ")#mi("0 < \\delta \\leq 1")#text(". (The case ")#mi("1/4 < \\delta \\leq 1")#text(" was treated in an earlier paper of ")#link("http://arxiv.org/abs/0905.2089")[#text("Erdős-Ramírez-Schlein-Yau")]#text(", while the case where t is comparable to 1 was treated ")#link("http://www.ams.org/mathscinet-getitem?mr=1810949")[#text("by Johansson")]#text(".)")],
[#text("(Matching) Every Wigner matrix with suitable smoothness conditions can be “matched” with an Ornstein-Uhlenbeck-evolved matrix, in the sense that the eigenvalue statistics for the two matrices are asymptotically identical. (This is relatively easy due to the fact that ")#mi("\\delta")#text(" can be taken arbitrarily close to zero.)")],
[#text("Combining 1. and 2. one obtains universality for all Wigner matrices obeying suitable smoothness conditions.")]
)

#text("The arguments in the ")#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/")[#text("paper of Van and myself")]#text(" can be summarised as follows:")

#enum(start: 1, 
[#text("(Structured case) The universality conjecture is true for Johansson matrices, by the ")#link("http://www.ams.org/mathscinet-getitem?mr=1810949")[#text("paper of Johansson")]#text(".")],
[#text("(Matching) Every Wigner matrix with some moment and support conditions can be “matched” with a Johansson matrix, in the sense that the first four moments of the entries agree, and hence (by the Lindeberg strategy in our paper) have asymptotically identical statistics.")],
[#text("Combining 1. and 2. one obtains universality for all Wigner matrices obtaining suitable moment and support conditions.")]
)

#text("What we realised is by combining the hard part 1. of the ")#link("http://arxiv.org/abs/0905.4176")[#text("paper of Erdős-Ramírez-Schlein-Yau")]#text(" with the hard part 2. of the ")#link("https://terrytao.wordpress.com/2009/06/26/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/")[#text("paper of Van and myself")]#text(", we can remove all regularity, moment, and support conditions. Roughly speaking, the unified argument proceeds as follows:")

#enum(start: 1, 
[#text("(Structured case) By the arguments ")#link("http://arxiv.org/abs/0905.4176")[#text("of Erdős-Ramírez-Schlein-Yau")]#text(", the universality conjecture is true for Ornstein-Uhlenbeck-evolved matrices with ")#mi("t = n^{-1+\\delta}")#text(" for any ")#mi("0 < \\delta \\leq 1")#text(".")],
[#text("(Matching) Every Wigner matrix ")#mi("H")#text(" can be “matched” with an Ornstein-Uhlenbeck-evolved matrix ")#mi("e^{-t/2} H + (1-e^{-t})^{1/2} V")#text(" for ")#mi("t= n^{-1+0.01}")#text(" (say), in the sense that the first four moments of the entries almost agree, which is enough (by the arguments ")#link("https://terrytao.wordpress.com/2009/06/26/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/")[#text("of Van and myself")]#text(") to show that these two matrices have asymptotically identical statistics on the average.")],
[#text("Combining 1. and 2. one obtains universality for the averaged statistics for all Wigner matrices.")]
)

#text("The averaging should be removable, but this would require better convergence results to the semicircular law than are currently known (except with additional hypotheses, such as vanishing third moment). The subexponential decay should also be relaxed to a condition of finiteness for some fixed moment ")#tao-math("{\\Bbb E} \\left|x\\right|^C", block: false)#text(", but we did not pursue this direction in order to keep the paper short.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/26/bulk-universality-for-wigner-hermitian-matrices-with-subexponential-decay/#comment-39775")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2009")])]

#text("Typo in:")

#text("1.(Structured case) The universalityconjecture is true for Johansson")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Random matrices: Localization of the eigenvalues and the necessity of four moments « What’s new")]], [#link("https://terrytao.wordpress.com/2009/06/26/bulk-universality-for-wigner-hermitian-matrices-with-subexponential-decay/#comment-44951")[#strong[#text("Random matrices: Localization of the eigenvalues and the necessity of four moments « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2010")])]

#text("[…] limit theorem for the normalised eigenvalue spacing in the bulk for all Wigner matrices, a result of Erdos, Ramirez, Schlein, Vu, Yau, and myself. One tool for this is the four moment theorem of Van and myself, which roughly speaking shows that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Wigner-Dyson-Mehta bulk universality conjecture for Wigner matrices « What’s new")]], [#link("https://terrytao.wordpress.com/2009/06/26/bulk-universality-for-wigner-hermitian-matrices-with-subexponential-decay/#comment-49998")[#strong[#text("The Wigner-Dyson-Mehta bulk universality conjecture for Wigner matrices « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2011")])]

#text("[…] a joint paper of ErdHs, Ramirez, Schlein, Vu, Yau, and myself}, we established the Wigner-Dyson-Mehta conjecture for all […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The asymptotic distribution of a single eigenvalue gap of a Wigner matrix « What’s new")]], [#link("https://terrytao.wordpress.com/2009/06/26/bulk-universality-for-wigner-hermitian-matrices-with-subexponential-decay/#comment-132070")[#strong[#text("The asymptotic distribution of a single eigenvalue gap of a Wigner matrix « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2012")])]

#text("[…] Unfortunately, when one tries to make this argument rigorous, one finds that the asymptotic for (1) does not control a single gap , but rather an ensemble of gaps , where is drawn from an interval of some moderate size (e.g. ); see for instance this paper of Deift, Kriecherbauer, McLaughlin, Venakides, and Zhou for a more precise formalisation of this statement (which is phrased slightly differently, in which one samples all gaps inside a fixed window of spectrum, rather than inside a fixed range of eigenvalue indices ). (This result is stated for GUE, but can be extended to other Wigner ensembles by the Four Moment Theorem, at least if one assumes a moment matching condition; see this previous paper with Van Vu for details. The moment condition can in fact be removed, as was done in this subsequent paper with Erdos, Ramirez, Schlein, Vu, and Yau.) […]")
]
