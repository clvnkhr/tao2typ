// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/
// Converted to Typst by tao2typ: "2026-10-14T09:21:56.399361+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The spectral theorem and its converses for unbounded symmetric operators", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The spectral theorem and its converses for unbounded symmetric operators")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 December 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/")[#text("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("LLet ")#mi("{L: H \\rightarrow H}")#text(" be a self-adjoint operator on a finite-dimensional Hilbert space ")#mi("{H}")#text(". The behaviour of this operator can be completely described by the ")#link("http://en.wikipedia.org/wiki/Spectral_theorem")[#text("spectral theorem")]#text(" for finite-dimensional self-adjoint operators (i.e. Hermitian matrices, when viewed in coordinates), which provides a sequence ")#mi("{\\lambda_1,\\ldots,\\lambda_n \\in {\\bf R}}")#text(" of eigenvalues and an orthonormal basis ")#mi("{e_1,\\ldots,e_n}")#text(" of eigenfunctions such that ")#mi("{L e_i = \\lambda_i e_i}")#text(" for all ")#mi("{i=1,\\ldots,n}")#text(". In particular, given any function ")#mi("{m: \\sigma(L) \\rightarrow {\\bf C}}")#text(" on the spectrum ")#mi("{\\sigma(L) := \\{ \\lambda_1,\\ldots,\\lambda_n\\}}")#text(" of ")#mi("{L}")#text(", one can then define the linear operator ")#mi("{m(L): H \\rightarrow H}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("m(L) e_i := m(\\lambda_i) e_i,")]]

#text("which then gives a ")#link("http://en.wikipedia.org/wiki/Functional_calculus")[#text("functional calculus")]#text(", in the sense that the map ")#mi("{m \\mapsto m(L)}")#text(" is a ")#link("http://en.wikipedia.org/wiki/C*-algebra")[#mi("{C^*}")#text("-algebra")]#text(" isometric homomorphism from the algebra ")#mi("{BC(\\sigma(L) \\rightarrow {\\bf C})}")#text(" of bounded continuous functions from ")#mi("{\\sigma(L)}")#text(" to ")#mi("{{\\bf C}}")#text(", to the algebra ")#mi("{B(H \\rightarrow H)}")#text(" of bounded linear operators on ")#mi("{H}")#text(". Thus, for instance, one can define heat operators ")#mi("{e^{-tL}}")#text(" for ")#mi("{t>0}")#text(", Schrödinger operators ")#mi("{e^{itL}}")#text(" for ")#mi("{t \\in {\\bf R}}")#text(", resolvents ")#mi("{\\frac{1}{L-z}}")#text(" for ")#mi("{z \\not \\in \\sigma(L)}")#text(", and (if ")#mi("{L}")#text(" is positive) wave operators ")#mi("{e^{it\\sqrt{L}}}")#text(" for ")#mi("{t \\in {\\bf R}}")#text(". These will be bounded operators (and, in the case of the Schrödinger and wave operators, unitary operators, and in the case of the heat operators with ")#mi("{L}")#text(" positive, they will be contractions). Among other things, this functional calculus can then be used to solve differential equations such as the heat equation ")#metadata(none) <tao-5a2a0ed9aa3ab7d82b53>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("u_t + Lu = 0; \\quad u(0) = f")]]



#text(" the Schrödinger equation ")#metadata(none) <tao-701586026ce95fd464c8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("u_t + iLu = 0; \\quad u(0) = f")]]



#text(" the wave equation ")#metadata(none) <tao-4b125ec99a74470517f9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("u_{tt} + Lu = 0; \\quad u(0) = f; \\quad u_t(0) = g")]]



#text(" or the Helmholtz equation ")#metadata(none) <tao-ab14d3faa25e917efe6e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("(L-z) u = f.")]]





#text("The functional calculus can also be associated to a spectral measure. Indeed, for any vectors ")#mi("{f, g \\in H}")#text(", there is a complex measure ")#mi("{\\mu_{f,g}}")#text(" on ")#mi("{\\sigma(L)}")#text(" with the property that")

#align(center)[#tao-fit-display[#mitex("\\langle m(L) f, g \\rangle_H = \\int_{\\sigma(L)} m(x) d\\mu_{f,g}(x);")]]

#text("indeed, one can set ")#mi("{\\mu_{f,g}}")#text(" to be the discrete measure on ")#mi("{\\sigma(L)}")#text(" defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\mu_{f,g}(E) := \\sum_{i: \\lambda_i \\in E} \\langle f, e_i \\rangle_H \\langle e_i, g \\rangle_H.")]]

#text("One can also view this complex measure as a coefficient")

#align(center)[#tao-fit-display[#mitex("\\mu_{f,g} = \\langle \\mu f, g \\rangle_H")]]

#text("of a ")#link("http://en.wikipedia.org/wiki/Projection-valued_measure")[#text("projection-valued measure")]#text(" ")#mi("{\\mu}")#text(" on ")#mi("{\\sigma(L)}")#text(", defined by setting")

#align(center)[#tao-fit-display[#mitex("\\mu(E) f := \\sum_{i: \\lambda_i \\in E} \\langle f, e_i \\rangle_H e_i.")]]

#text("Finally, one can view ")#mi("{L}")#text(" as unitarily equivalent to a multiplication operator ")#mi("{M: f \\mapsto g f}")#text(" on ")#mi("{\\ell^2(\\{1,\\ldots,n\\})}")#text(", where ")#mi("{g}")#text(" is the real-valued function ")#mi("{g(i) := \\lambda_i}")#text(", and the intertwining map ")#mi("{U: \\ell^2(\\{1,\\ldots,n\\}) \\rightarrow H}")#text(" is given by")

#align(center)[#tao-fit-display[#mitex("U ( (c_i)_{i=1}^n ) := \\sum_{i=1}^n c_i e_i,")]]

#text("so that ")#mi("{L = U M U^{-1}}")#text(".")

#text("It is an important fact in analysis that many of these above assertions extend to operators on an infinite-dimensional Hilbert space ")#mi("{H}")#text(", so long as one one is careful about what “self-adjoint operator” means; these facts are collectively referred to as the ")#emph[#text("spectral theorem")]#text(". For instance, it turns out that most of the above claims have analogues for ")#emph[#text("bounded")]#text(" self-adjoint operators ")#mi("{L: H \\rightarrow H}")#text(". However, in the theory of partial differential equations, one often needs to apply the spectral theorem to ")#emph[#text("unbounded")]#text(", ")#link("http://en.wikipedia.org/wiki/Densely_defined_operator")[#text("densely defined")]#text(" linear operators ")#mi("{L: D \\rightarrow H}")#text(", which (initially, at least), are only defined on a dense subspace ")#mi("{D}")#text(" of the Hilbert space ")#mi("{H}")#text(". A very typical situation arises when ")#mi("{H = L^2(\\Omega)}")#text(" is the square-integrable functions on some domain or manifold ")#mi("{\\Omega}")#text(" (which may have a boundary or be otherwise “incomplete”), and ")#mi("{D = C^\\infty_c(\\Omega)}")#text(" are the smooth compactly supported functions on ")#mi("{\\Omega}")#text(", and ")#mi("{L}")#text(" is some linear differential operator. It is then of interest to obtain the spectral theorem for such operators, so that one build operators such as ")#mi("{e^{-tL}, e^{itL}, \\frac{1}{L-z}, e^{it\\sqrt{L}}}")#text(" or to solve equations such as ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(1)")]#text(", ")#link(<tao-701586026ce95fd464c8>)[#text("(2)")]#text(", ")#link(<tao-4b125ec99a74470517f9>)[#text("(3)")]#text(", ")#link(<tao-ab14d3faa25e917efe6e>)[#text("(4)")]#text(".")

#text("In order to do this, some necessary conditions on the densely defined operator ")#mi("{L: D \\rightarrow H}")#text(" must be imposed. The most obvious is that of ")#emph[#text("symmetry")]#text(", which asserts that ")#metadata(none) <tao-3781049acb7fd5d7de25>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\langle Lf, g \\rangle_H = \\langle f, Lg \\rangle_H")]]



#text(" for all ")#mi("{f, g \\in D}")#text(". In some applications, one also wants to impose ")#emph[#text("positive definiteness")]#text(", which asserts that ")#metadata(none) <tao-afa6e9ab3ac6574d50e6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\langle Lf, f \\rangle_H \\geq 0")]]



#text(" for all ")#mi("{f \\in D}")#text(". These hypotheses are sufficient in the case when ")#mi("{L}")#text(" is bounded, and in particular when ")#mi("{H}")#text(" is finite dimensional. However, as it turns out, for unbounded operators these conditions are not, by themselves, enough to obtain a good spectral theory. For instance, one consequence of the spectral theorem should be that the resolvents ")#mi("{(L-z)^{-1}}")#text(" are well-defined for any strictly complex ")#mi("{z}")#text(", which by duality implies that the image of ")#mi("{L-z}")#text(" should be dense in ")#mi("{H}")#text(". However, this can fail if one just assumes symmetry, or symmetry and positive definiteness. A well-known example occurs when ")#mi("{H}")#text(" is the Hilbert space ")#mi("{H := L^2((0,1))}")#text(", ")#mi("{D := C^\\infty_c((0,1))}")#text(" is the space of test functions, and ")#mi("{L}")#text(" is the one-dimensional Laplacian ")#mi("{L := -\\frac{d^2}{dx^2}}")#text(". Then ")#mi("{L}")#text(" is symmetric and positive, but the operator ")#mi("{L-k^2}")#text(" does not have dense image for any complex ")#mi("{k}")#text(", since")

#align(center)[#tao-fit-display[#mitex("\\langle (L-\\overline{k}^2) f, e^{\\overline{k}x} \\rangle_H = 0")]]

#text("for all test functions ")#mi("{f \\in C^\\infty_c((0,1))}")#text(", as can be seen from a routine integration by parts. As such, the resolvent map is not everywhere uniquely defined. There is also a lack of uniqueness for the wave, heat, and Schrödinger equations for this operator (note that there are no spatial boundary conditions specified in these equations).")

#text("Another example occurs when ")#mi("{H := L^2((0,+\\infty))}")#text(", ")#mi("{D := C^\\infty_c((0,+\\infty))}")#text(", ")#mi("{L}")#text(" is the momentum operator ")#mi("{L := i \\frac{d}{dx}}")#text(". Then the resolvent ")#mi("{(L-z)^{-1}}")#text(" can be uniquely defined for ")#mi("{z}")#text(" in the upper half-plane, but not in the lower half-plane, due to the obstruction")

#align(center)[#tao-fit-display[#mitex("\\langle (L-z) f, e^{i \\bar{z} x} \\rangle_H = 0")]]

#text("for all test functions ")#mi("{f}")#text(" (note that the function ")#mi("{e^{i\\bar{z} x}}")#text(" lies in ")#mi("{L^2((0,+\\infty))}")#text(" when ")#mi("{z}")#text(" is in the lower half-plane). For related reasons, the translation operators ")#mi("{e^{itL}}")#text(" have a problem with either uniqueness or existence (depending on whether ")#mi("{t}")#text(" is positive or negative), due to the unspecified boundary behaviour at the origin.")

#text("The key property that lets one avoid this bad behaviour is that of ")#link("http://en.wikipedia.org/wiki/Essentially_self-adjoint")[#text("essential self-adjointness")]#text(". Once ")#mi("{L}")#text(" is essentially self-adjoint, then spectral theorem becomes applicable again, leading to all the expected behaviour (e.g. existence and uniqueness for the various PDE given above).")

#text("Unfortunately, the concept of essential self-adjointness is defined rather abstractly, and is difficult to verify directly; unlike the symmetry condition ")#link(<tao-3781049acb7fd5d7de25>)[#text("(5)")]#text(" or the positive condition ")#link(<tao-afa6e9ab3ac6574d50e6>)[#text("(6)")]#text(", it is not a “local” condition that can be easily verified just by testing ")#mi("{L}")#text(" on various inputs, but is instead a more “global” condition. In practice, to verify this property, one needs to invoke one of a number of a partial converses to the spectral theorem, which roughly speaking asserts that if at least one of the expected consequences of the spectral theorem is true for some symmetric densely defined operator ")#mi("{L}")#text(", then ")#mi("{L}")#text(" is self-adjoint. Examples of “expected consequences” include:")

#list(
[#text("Existence of resolvents ")#mi("{(L-z)^{-1}}")#text(" (or equivalently, dense image for ")#mi("{L-z}")#text(");")],
[#text("Existence of a contractive heat propagator semigroup ")#mi("{e^{tL}}")#text(" (in the positive case);")],
[#text("Existence of a unitary Schrödinger propagator group ")#mi("{e^{itL}}")#text(";")],
[#text("Existence of a unitary wave propagator group ")#mi("{e^{it\\sqrt{L}}}")#text(" (in the positive case);")],
[#text("Existence of a “reasonable” functional calculus.")],
[#text("Unitary equivalence with a multiplication operator.")]
)

#text("Thus, to actually verify essential self-adjointness of a differential operator, one typically has to first solve a PDE (such as the wave, Schrödinger, heat, or Helmholtz equation) by some non-spectral method (e.g. by a contraction mapping argument, or a perturbation argument based on an operator already known to be essentially self-adjoint). Once one can solve one of the PDEs, then one can apply one of the known converse spectral theorems to obtain essential self-adjointness, and then by the forward spectral theorem one can then solve all the other PDEs as well. But there is no getting out of that first step, which requires some input (typically of an ODE, PDE, or geometric nature) that is external to what abstract spectral theory can provide. For instance, if one wants to establish essential self-adjointness of the Laplace-Beltrami operator ")#mi("{L = -\\Delta_g}")#text(" on a smooth Riemannian manifold ")#mi("{(M,g)}")#text(" (using ")#mi("{C^\\infty_c(M)}")#text(" as the domain space), it turns out (under reasonable regularity hypotheses) that essential self-adjointness is equivalent to ")#link("http://en.wikipedia.org/wiki/Geodesic_manifold")[#text("geodesic completeness")]#text(" of the manifold, which is a global ODE condition rather than a local one: one needs geodesics to continue indefinitely in order to be able to (unitarily) solve PDEs such as the wave equation, which in turn leads to essential self-adjointness. (Note that the domains ")#mi("{(0,1)}")#text(" and ")#mi("{(0,+\\infty)}")#text(" in the previous examples were not geodesically complete.) For this reason, essential self-adjointness of a differential operator is sometimes referred to as ")#emph[#text("quantum completeness")]#text(" (with the completeness of the associated Hamilton-Jacobi flow then being the analogous ")#emph[#text("classical completeness")]#text(").")

#text("In these notes, I wanted to record (mostly for my own benefit) the forward and converse spectral theorems, and to verify essential self-adjointness of the Laplace-Beltrami operator on geodesically complete manifolds. This is extremely standard analysis (covered, for instance, in the texts ")#link("http://www.ams.org/mathscinet-getitem?mr=493419")[#text("of Reed and Simon")]#text("), but I wanted to write it down myself to make sure that I really understood this foundational material properly.")

#metadata(none) <tao-617481a1012f97100924>

#heading(level: 1)[#strong[#text(" — 1. Self-adjointness and resolvents — ")]]

#text("To begin, we study what we can abstractly say about a densely defined symmetric linear operator ")#mi("{L: D \\rightarrow H}")#text(" on a Hilbert space ")#mi("{H}")#text(". To avoid some technical issues we shall assume that the Hilbert space is ")#link("http://en.wikipedia.org/wiki/Hilbert_space#Separable_spaces")[#text("separable")]#text(", which is the case typically encountered in applications (particularly in PDE). We will occasionally assume also that ")#mi("{L}")#text(" is positive, but will make this hypothesis explicit whenever we are doing so.")

#text("All convergence in Hilbert spaces will be in the strong (i.e. norm) topology unless otherwise stated. Similarly, all inner products and norms will be over ")#mi("{H}")#text(" unless otherwise stated.")

#text("For technical reasons, it is convenient to reduce to the case when ")#mi("{L}")#text(" is ")#link("http://en.wikipedia.org/wiki/Closed_operator")[#text("closed")]#text(", which means that the graph ")#mi("{\\{ (f, Lf): f \\in D \\}}")#text(" is a closed subspace of ")#mi("{H \\times H}")#text(". Equivalently, ")#mi("{L}")#text(" is closed if whenever ")#mi("{f_n \\in D}")#text(" is a sequence converging strongly to a limit ")#mi("{f \\in H}")#text(", and ")#mi("{Lf_n}")#text(" converges to a limit ")#mi("{g}")#text(" in ")#mi("{H}")#text(", then ")#mi("{f \\in D}")#text(" and ")#mi("{g = Lf}")#text(". For instance, thanks to the ")#link("http://en.wikipedia.org/wiki/Closed_graph_theorem")[#text("closed graph theorem")]#text(", an everywhere-defined linear operator is closed if and only if it is bounded.")

#text("Not every densely defined symmetric linear operator is closed (indeed, one could take a closed operator and restrict the domain of definition to a proper dense subspace). However, all such operators are ")#emph[#text("closable")]#text(", in that they have a closure:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Closure)")]#text(" Let ")#mi("{L: D \\rightarrow H}")#text(" be a densely defined symmetric linear operator. Then there exists a unique extension ")#mi("{\\overline{L}: \\overline{D} \\rightarrow H}")#text(" of ")#mi("{L}")#text(" as a closed, densely defined symmetric linear operator, such that the graph ")#mi("{\\{ (f, \\overline{L} f): f \\in \\overline{D} \\}}")#text(" of ")#mi("{\\overline{L}}")#text(" is the closure of the graph ")#mi("{\\{ (f, Lf): f \\in D \\}}")#text(" of ")#mi("{L}")#text(".")
]

#emph[#text("Proof:")]#text(" The key step is to show that the closure ")#mi("{\\overline{\\{ (f, Lf): f \\in D \\}}}")#text(" of the graph of ")#mi("{L}")#text(" remains a graph, i.e. it obeys the vertical line test. If this failed, then by linearity one could find a sequence ")#mi("{f_n \\in D}")#text(" converging to zero such that ")#mi("{Lf_n}")#text(" converged to a non-zero limit ")#mi("{g}")#text(". Since ")#mi("{D}")#text(" is dense, we can find ")#mi("{g^{\\prime} \\in D}")#text(" such that ")#mi("{\\langle g, g^{\\prime} \\rangle \\neq 0}")#text(". But then by symmetry")

#align(center)[#tao-fit-display[#mitex("\\langle f_n, Lg^{\\prime} \\rangle = \\langle Lf_n, g^{\\prime} \\rangle = \\langle g_n, g^{\\prime} \\rangle \\rightarrow \\langle g, g^{\\prime} \\rangle \\neq 0.")]]

#text("On the other hand, as ")#mi("{f_n \\rightarrow 0}")#text(", ")#mi("{\\langle f_n, Lg^{\\prime} \\rangle \\rightarrow 0}")#text(". Thus ")#mi("{\\overline{\\{ (f, Lf): f \\in D \\}}}")#text(" is the graph of some function ")#mi("{\\overline{L}: \\overline{D} \\rightarrow H}")#text(". It is easy to see that this is a densely defined symmetric linear operator extending ")#mi("{L}")#text(", and is the unique such operator. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Show that ")#mi("{\\overline{L}}")#text(" is positive if and only if ")#mi("{L}")#text(" is positive.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" We caution that ")#mi("{\\overline{D}}")#text(" is not the closure or completion of ")#mi("{D}")#text(" with respect to the usual norm ")#tao-math("{f \\mapsto \\left\\|f\\right\\|}", block: false)#text(" on ")#mi("{D}")#text(". (Indeed, as ")#mi("{D}")#text(" is a dense subspace of ")#mi("{H}")#text(", that completion of ")#mi("{D}")#text(" is simply ")#mi("{H}")#text(".) However, it is the completion of ")#mi("{D}")#text(" with respect to the modified norm ")#tao-math("{f \\mapsto \\left\\|f\\right\\| + \\left\\|Lf\\right\\|}", block: false)#text(".")
]

#text("In PDE applications, the closure ")#mi("{\\overline{L}}")#text(" tends to be defined on a Sobolev space of functions that behave well at the boundary, and is given by a distributional derivative. Here is a simple example of this:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" ")#metadata(none) <tao-25ba0c73462c6aaef3ca>#text(" Let ")#mi("{L}")#text(" be the Laplacian ")#mi("{L = -\\frac{d^2}{dx^2}}")#text(", defined on the dense subspace ")#mi("{D := C^\\infty_c((0,1))}")#text(" of ")#mi("{H := L^2((0,1))}")#text(". Show that the closure ")#mi("{\\overline{L}}")#text(" is defined on the Sobolev space ")#mi("{H^2_0((0,1))}")#text(", defined as the completion of ")#mi("{C^\\infty_c((0,1))}")#text(" under the Sobolev norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{H^2_0((0,1))} := \\left\\| f \\right\\|_{L^2((0,1))} + \\left\\| Lf \\right\\|_{L^2((0,1))},", block: true)]]

#text("and that the action of ")#mi("{\\overline{L}}")#text(" is given by the weak (distributional) derivative, ")#mi("{\\overline{L} = -\\frac{d^2}{dx^2}}")#text(".")
]

#text("Next, we define the ")#emph[#text("adjoint")]#text(" ")#mi("{L^*: D^* \\rightarrow H}")#text(" of ")#mi("{L: D \\rightarrow H}")#text(", which informally speaking is the maximally defined operator for which one has the relationship ")#metadata(none) <tao-803118bb3829b6e62873>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\langle Lf, g \\rangle = \\langle f, L^* g \\rangle")]]



#text(" for ")#mi("{f \\in D}")#text(" and ")#mi("{g \\in D^*}")#text(". More formally, define ")#mi("{D^*}")#text(" to be the set of all vectors ")#mi("{g \\in H}")#text(" for which the map ")#mi("{f \\mapsto \\langle Lf, g \\rangle}")#text(" is a bounded linear functional on ")#mi("{D}")#text(", which thus extends to the closure ")#mi("{H}")#text(" of ")#mi("{D}")#text(". For such ")#mi("{g \\in H}")#text(", we may apply the ")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem")[#text("Riesz representation theorem for Hilbert spaces")]#text(" and locate a unique vector ")#mi("{L^* g \\in H}")#text(" for which ")#link(<tao-803118bb3829b6e62873>)[#text("(7)")]#text(" holds. This is easily seen to define a linear operator ")#mi("{L^*: D^* \\rightarrow H}")#text(". Furthermore, the claim that ")#mi("{L}")#text(" is symmetric can be reformulated as the claim that ")#mi("{L^*}")#text(" extends ")#mi("{L}")#text(".")

#text("If ")#mi("{L}")#text(" is not symmetric, then ")#mi("{L^*}")#text(" does not extend ")#mi("{L}")#text(", and need not be densely defined at all. However, it is still closed:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Let ")#mi("{L: D \\rightarrow H}")#text(" be a densely defined linear operator, and let ")#mi("{L^*: D^* \\rightarrow H}")#text(" be its adjoint. Show that ")#mi("{\\{ (-L^* g, g): g \\in D^* \\}}")#text(" is the orthogonal complement in ")#mi("{H \\times H}")#text(" of (the closure of) ")#mi("{\\{ (f, Lf): f \\in D \\}}")#text(". Conclude that ")#mi("{L^*}")#text(" is always closed.")

#text("If ")#mi("{L}")#text(" is symmetric, show that ")#mi("{L^{**} = \\overline{L}}")#text(" and ")#mi("{L^* = (\\overline{L})^*}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Construct an example of a densely defined linear operator ")#mi("{L: D \\rightarrow H}")#text(" in a separable Hilbert space ")#mi("{H}")#text(" for which ")#mi("{L^*}")#text(" is only defined at ")#mi("{\\{0\\}}")#text(". (")#emph[#text("Hint:")]#text(" Build a dense linearly independent basis of ")#mi("{H}")#text(", let ")#mi("{D}")#text(" be the algebraic span of that basis, and design ")#mi("{L}")#text(" so that the graph of ")#mi("{L}")#text(" is dense in ")#mi("{H \\times H}")#text(".)")
]

#text("We caution that the adjoint ")#mi("{L^*: D^* \\rightarrow H}")#text(" of a symmetric densely defined operator ")#mi("{L: D \\rightarrow H}")#text(" need not be itself symmetric, despite extending the symmetric operator ")#mi("{L}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" We continue Example ")#link(<tao-25ba0c73462c6aaef3ca>)[#text("2")]#text(". Show that for any complex number ")#mi("{k}")#text(", the functions ")#mi("{x \\mapsto e^{kx}}")#text(" lie in ")#mi("{D^*}")#text(" with ")#mi("{L^* e^{kx} = -k^2 e^{kx}}")#text(". Deduce that ")#mi("{L^*}")#text(" is not symmetric, and not positive.")
]

#text("Intuitively, the problem here is that the domain of ")#mi("{L}")#text(" is too “small” (it stays too far away from the boundary), which makes the domain of ")#mi("{L^*}")#text(" too “large” (it contains too much stuff coming from the boundary), which ruins the integration by parts argument that gives symmetry.")

#text("Now we can define (essential) self-adjointness.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2")]#text(" Let ")#mi("{L: D \\rightarrow H }")#text(" be a densely defined linear operator.")

#list(
[#mi("{L}")#text(" is ")#emph[#text("self-adjoint")]#text(" if ")#mi("{L = L^*}")#text(". (Note that this implies in particular that ")#mi("{L}")#text(" is symmetric and closed.)")],
[#mi("{L}")#text(" is ")#emph[#text("essentially self-adjoint")]#text(" if it is symmetric, and its closure ")#mi("{\\overline{L}}")#text(" is self-adjoint.")]
)
]

#text("Note that this extends the usual definition of self-adjointness for bounded operators. Conversely, from the closed graph theorem we also observe the ")#link("http://en.wikipedia.org/wiki/Hellinger%E2%80%93Toeplitz_theorem")[#text("Hellinger-Toeplitz theorem")]#text(": an operator that is self-adjoint and everywhere defined, is necessarily bounded.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Let ")#mi("{L: D \\rightarrow H }")#text(" be a densely defined symmetric closed linear operator. Show that ")#mi("{L}")#text(" is self-adjoint if and only if ")#mi("{L^*}")#text(" is symmetric.")
]

#text("It is not immediately obvious what advantage self-adjointness gives. To see this, we consider the problem of inverting the operator ")#mi("{L-z: D \\rightarrow H}")#text(" for some complex number ")#mi("{z}")#text(", where ")#mi("{L: D \\rightarrow H}")#text(" is densely defined, symmetric, and closed. Observe that if ")#mi("{f \\in D}")#text(", then ")#mi("{\\langle Lf, f \\rangle = \\langle f, Lf \\rangle}")#text(" is necessarily real. In particular,")

#align(center)[#tao-fit-display[#tao-math("\\text{Im} \\langle (L-z)f, f \\rangle = - \\text{Im} z \\left\\|f\\right\\|^2", block: true)]]

#text("and hence by the Cauchy-Schwarz inequality ")#metadata(none) <tao-c46ec05870925e250269>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left\\|(L-z) f \\right\\| \\geq \\left|\\text{Im} z\\right| \\|f\\|.", block: true)]]



#text(" In particular, if ")#mi("{z}")#text(" is strictly complex (i.e. not real), then ")#mi("{L-z}")#text(" is injective. Furthermore, we see that if ")#mi("{f_n \\in D}")#text(" is such that ")#mi("{(L-z) f_n}")#text(" is convergent, then by ")#link(<tao-c46ec05870925e250269>)[#text("(8)")]#text(" ")#mi("{f_n}")#text(" is convergent also, and hence ")#mi("{Lf_n}")#text(" is convergent. As ")#mi("{L}")#text(" was assumed to be closed, we conclude that ")#mi("{f_n}")#text(" converges to a limit ")#mi("{f}")#text(" in ")#mi("{D}")#text(", and ")#mi("{(L-z)f_n}")#text(" converges to ")#mi("{(L-z) f}")#text(". As a consequence, we see that the space ")#mi("{\\text{Image}(L-z) := \\{ (L-z)f: f \\in D \\}}")#text(" is a closed subspace of ")#mi("{H}")#text(". From ")#link(<tao-c46ec05870925e250269>)[#text("(8)")]#text(" we then see that we can define an inverse ")#mi("{R(z): \\text{Image}(L-z) \\rightarrow D}")#text(" of ")#mi("{L-z}")#text(", which we call the ")#link("http://en.wikipedia.org/wiki/Resolvent_formalism")[#text("resolvent")]#text(" of ")#mi("{L}")#text(" with spectral parameter ")#mi("{z}")#text("; this is a bounded linear operator with norm ")#tao-math("{\\left\\|R(z)\\right\\|_{op} \\leq \\frac{1}{\\left|\\text{Im}(z)\\right|}}", block: false)#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" If ")#mi("{L}")#text(" is densely defined, symmetric, closed, and positive, and ")#mi("{z}")#text(" is a complex number with ")#mi("{\\text{Re}(z) < 0}")#text(", show ")#mi("{R(z)}")#text(" is well-defined on ")#mi("{\\text{Image}(L-z)}")#text(" with ")#tao-math("{\\left\\|R(z)\\right\\|_{op} \\leq \\frac{1}{\\left|\\text{Re}(z)\\right|}}", block: false)#text(".")
]

#text("Now we observe a connection between self-adjointness and the domain of the resolvent. We first need some basic properties of the resolvent:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" ")#metadata(none) <tao-8ccf2f9e9cc41e7ad5bf>#text(" Let ")#mi("{L: D \\rightarrow H}")#text(" be densely defined, symmetric, and closed.")

#list(
[#text("(i) (Resolvent identity) If ")#mi("{z, w}")#text(" are distinct strictly complex numbers with ")#mi("{R(z), R(w)}")#text(" everywhere defined, show that ")#mi("{(z-w) R(z) R(w) = R(z) - R(w)}")#text(". (")#emph[#text("Hint:")]#text(" compute ")#mi("{R(z) (H-w) R(w) - R(z) (H-z) R(w)}")#text(" two different ways.)")],
[#text("(ii) If ")#mi("{z}")#text(" is a strictly complex number with ")#mi("{R(z)}")#text(" and ")#mi("{R(z^*)}")#text(" everywhere defined, show that ")#mi("{R(z)^* = R(z^*)}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3")]#text(" Let ")#mi("{L: D \\rightarrow H}")#text(" be densely defined, symmetric, and closed, let ")#mi("{L^*: D^* \\rightarrow H}")#text(" be the adjoint, and let ")#mi("{z}")#text(" be strictly complex.")

#list(
[#text("(i) (Surjectivity is dual to injectivity) ")#mi("{R(z)}")#text(" is everywhere defined if and only if the operator ")#mi("{L^* - z^*: D^* \\rightarrow H}")#text(" has trivial kernel.")],
[#text("(ii) (Self-adjointness implies surjectivity) If ")#mi("{L}")#text(" is self-adjoint, then ")#mi("{R(z)}")#text(" is everywhere defined.")],
[#text("(iii) (Surjectivity implies self-adjointness) Conversely, if ")#mi("{R(z)}")#text(" and ")#mi("{R(z^*)}")#text(" are both everywhere defined, then ")#mi("{L}")#text(" is self-adjoint.")]
)
]

#text("In particular, we see that we have a criterion for self-adjointness: a densely defined symmetric closed operator is self-adjoint if and only if ")#mi("{R(i)}")#text(" and ")#mi("{R(-i)}")#text(" are both everywhere defined, or in other words if ")#mi("{L+i}")#text(" and ")#mi("{L-i}")#text(" are both surjective.")

#emph[#text("Proof:")]#text(" We first prove (i). If ")#mi("{R(z)}")#text(" is not everywhere defined, then the closed subspace ")#mi("{\\text{Image}(L-z) \\subset H}")#text(" is not all of ")#mi("{H}")#text(". Thus there must be a non-zero vector ")#mi("{v \\in H}")#text(" in the orthogonal complement of this subspace, thus ")#mi("{\\langle (L-z) f, g \\rangle = 0}")#text(" for all ")#mi("{f \\in D}")#text(". In particular,")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle L f, g \\rangle\\right| = \\left|z\\right| \\left|\\langle f, g \\rangle\\right| \\leq \\left|z\\right| \\left\\|f\\right\\| \\left\\|g\\right\\|", block: true)]]

#text("and hence, by definition of ")#mi("{D^*}")#text(", ")#mi("{g}")#text(" lies in ")#mi("{D^*}")#text(". Now from ")#link(<tao-803118bb3829b6e62873>)[#text("(7)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\langle f, (L^* - z^*)g \\rangle = \\langle (L-z) f, g \\rangle = 0")]]

#text("for all ")#mi("{f \\in D}")#text("; since ")#mi("{D}")#text(" is dense, we have ")#mi("{(L^* - z^*)g = 0}")#text(" as required. The converse implication follows by reversing these steps.")

#text("Now we prove (ii). Suppose that ")#mi("{R(z)}")#text(" was not everywhere defined. By (i) and self-adjointness, we conclude that ")#mi("{(L-z^*)f = 0}")#text(" for some non-zero ")#mi("{f \\in D}")#text(". But this contradicts ")#link(<tao-c46ec05870925e250269>)[#text("(8)")]#text(".")

#text("Now we prove (iii). Let ")#mi("{g \\in D^*}")#text("; our task is to show that ")#mi("{g \\in D}")#text(". From Exercise ")#link(<tao-8ccf2f9e9cc41e7ad5bf>)[#text("8")]#text("(ii) and ")#link(<tao-803118bb3829b6e62873>)[#text("(7)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\langle f, R(z^*) (L^*-z^*) g \\rangle = \\langle R(z) f, (L^*-z^*) g \\rangle = \\langle (L-z) R(z) f, g \\rangle = \\langle f, g \\rangle")]]

#text("for all ")#mi("{f \\in H}")#text(". We conclude that ")#mi("{g = R(z^*) (L^*-z^*) g}")#text(". Since ")#mi("{R(z^*)}")#text(" takes values in ")#mi("{D}")#text(", the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Let ")#mi("{L: D \\rightarrow H}")#text(" be densely defined, symmetric, and closed, and let ")#mi("{z}")#text(" be strictly complex.")

#list(
[#text("(i) If ")#mi("{R(z)}")#text(" is everywhere defined, show that ")#mi("{R(w)}")#text(" is everywhere defined whenever ")#tao-math("{\\left|w-z\\right| < \\text{Im}(z)}", block: false)#text(". (")#emph[#text("Hint:")]#text(" use ")#link("http://en.wikipedia.org/wiki/Neumann_series")[#text("Neumann series")]#text(".)")],
[#text("(ii) If ")#mi("{R(z)}")#text(" is everywhere defined, show that ")#mi("{R(w)}")#text(" is everywhere defined whenever ")#mi("{\\text{Im}(w)}")#text(" has the same sign as ")#mi("{\\text{Im}(z)}")#text(".")],
[#text("(iii) If ")#mi("{L}")#text(" is positive, and ")#mi("{w}")#text(" is not a non-negative real, show that ")#mi("{R(w)}")#text(" is everywhere defined if and only if ")#mi("{L}")#text(" is self-adjoint.")]
)
]

#text("As a particular corollary of the above exercise, we see that a densely defined, symmetric closed positive operator ")#mi("{L}")#text(" is self-adjoint if and only if ")#mi("{R(-1)}")#text(" is everywhere defined, or in other words if ")#mi("{1+L}")#text(" is surjective.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Let ")#mi("{(X,\\mu)}")#text(" be a measure space with a countably generated ")#mi("{\\sigma}")#text("-algebra (so that ")#mi("{L^2(X,\\mu)}")#text(" is separable), let ")#mi("{m: X \\rightarrow {\\bf R}}")#text(" be a measurable function, and let ")#mi("{D}")#text(" be the space of all ")#mi("{f \\in L^2(X,\\mu)}")#text(" such that ")#mi("{mf \\in L^2(X,\\mu)}")#text(". Show that the multiplier operator ")#mi("{L: D \\rightarrow L^2(X,\\mu)}")#text(" defined by ")#mi("{L f := mf}")#text(" is a densely defined self-adjoint operator.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Let ")#mi("{H := L^2((0,+\\infty))}")#text(", ")#mi("{D := C^\\infty_c((0,+\\infty))}")#text(", and ")#mi("{L}")#text(" is the momentum operator ")#mi("{L := i \\frac{d}{dx}}")#text(". Show that ")#mi("{L}")#text(" is densely defined and symmetric, and ")#mi("{R(-i)}")#text(" is everywhere defined, but ")#mi("{R(i)}")#text(" is only defined on the orthogonal complement of ")#mi("{e^{-x}}")#text(". (Here, we define the resolvent of a closable operator to be the resolvent of its closure.) In particular, ")#mi("{L}")#text(" is not self-adjoint.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" Let ")#mi("{L}")#text(" be densely defined and symmetric.")

#list(
[#text("(i) Show that ")#mi("{L}")#text(" is essentially self-adjoint if and only if ")#mi("{\\text{Image}(L+i)}")#text(" and ")#mi("{\\text{Image}(L-i)}")#text(" are dense in ")#mi("{H}")#text(".")],
[#text("(ii) If ")#mi("{L}")#text(" is positive, show that ")#mi("{L}")#text(" is essentially self-adjoint if and only if ")#mi("{\\text{Image}(1+L)}")#text(" is dense in ")#mi("{H}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Let ")#mi("{a_1, a_2, \\ldots}")#text(" and ")#mi("{b_1,b_2,\\ldots}")#text(" be sequences of real numbers, with the ")#mi("{b_n}")#text(" all non-zero. Define the ")#emph[#text("Jacobi operator")]#text(" ")#mi("{T: \\ell^2_c({\\bf N}) \\rightarrow \\ell^2({\\bf N})}")#text(" from the space ")#mi("{\\ell^2_c({\\bf N})}")#text(" of compactly supported sequences ")#mi("{(x_n)_{n=1}^\\infty}")#text(" to the space ")#mi("{\\ell^2({\\bf N})}")#text(" of square-summable sequences ")#mi("{(y_n)_{n=1}^\\infty}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("T (x_n)_{n=1}^\\infty = (b_{n-1} x_{n-1} + a_n x_n + b_n x_{n+1})_{n=1}^\\infty")]]

#text("with the convention that ")#mi("{b_{n-1} x_{n-1}}")#text(" vanishes for ")#mi("{n=1}")#text(".")

#list(
[#text("(i) Show that ")#mi("{T}")#text(" is densely defined and symmetric.")],
[#text("(ii) Show that ")#mi("{T}")#text(" is essentially self-adjoint if and only if the (unique) solution ")#mi("{\\phi_n}")#text(" to the recurrence")

#align(center)[#tao-fit-display[#mitex("b_{n-1} \\phi_{n-1} + (a_n-i) \\phi_n + b_n \\phi_{n+1} = 0")]]

#text("with ")#mi("{\\phi_1 = 1}")#text(" (and the convention ")#mi("{b_0\\phi_0=0}")#text("), is not square-summable.")]
)

#text("This exercise shows that the self-adjointness of an operator, even one as explicit as a Jacobi operator, can depend in a rather subtle and “global” fashion on the behaviour of the coefficients of that oeprator.")
]

#heading(level: 1)[#strong[#text(" — 2. Self-adjointness and spectral measure — ")]]

#text("We have seen that self-adjoint operators have everywhere-defined resolvents ")#mi("{R(z)}")#text(" for all strictly complex ")#mi("{z}")#text(". Now we use this fact to build spectral measures. We will need a useful tool from complex analysis, which places a one-to-one correspondence between finite non-negative measures on ")#mi("{{\\bf R}}")#text(" and certain analytic functions on the upper half-plane:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Herglotz representation theorem)")]#text(" Let ")#mi("{F: {\\bf H} \\rightarrow \\overline{{\\bf H}}}")#text(" be an analytic function from the upper half-plane ")#mi("{{\\bf H} := \\{ z \\in {\\bf C}: \\text{Im}(z) > 0 \\}}")#text(" to the closed upper half-plane ")#mi("{\\overline{{\\bf H}} := \\{ z \\in {\\bf C}: \\text{Im}(z) \\geq 0 \\}}")#text(", obeying a bound of the form ")#tao-math("{\\left|F(z)\\right| \\leq C / \\text{Im}(z)}", block: false)#text(" for all ")#mi("{z \\in {\\bf H}}")#text(" and some ")#mi("{C>0}")#text(". Then there exists a finite non-negative Radon measure ")#mi("{\\mu}")#text(" on ")#mi("{{\\bf R}}")#text(" such that ")#metadata(none) <tao-4af4e217c06a9b00b977>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("F(z) = \\int_{\\bf R} \\frac{1}{x-z}\\ d\\mu(x)")]]



#text(" for all ")#mi("{z \\in {\\bf H}}")#text(". Furthermore, one has ")#mi("{y F(iy) \\rightarrow \\mu({\\bf R})}")#text(" as ")#mi("{y \\rightarrow +\\infty}")#text(".")
]

#text("We set the proof of the above theorem as an exercise below. Note in the converse direction that if ")#mi("{\\mu}")#text(" is a finite non-negative Radon measure, then the function ")#mi("{F}")#text(" defined by ")#link(<tao-4af4e217c06a9b00b977>)[#text("(9)")]#text(" obeys all the hypotheses of the theorem. The Herglotz representation theorem, like the more well known ")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem")[#text("Riesz representation theorem for measures")]#text(", is a useful tool to construct non-negative Radon measures; later on we will also use ")#link("http://en.wikipedia.org/wiki/Bochner%27s_theorem")[#text("Bochner’s theorem")]#text(" for a similar purpose.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Let ")#mi("{F}")#text(" be as in the hypothesis of the Herglotz representation theorem. For each ")#mi("{\\epsilon > 0}")#text(", let ")#mi("{F_\\epsilon: {\\bf R} \\rightarrow \\overline{{\\bf H}}}")#text(" be the function ")#mi("{F_\\epsilon(x) := F(x+i\\epsilon)}")#text(".")

#list(
[#text("(i) Show that one has ")#mi("{F_{\\epsilon+t} = F_\\epsilon * P_t}")#text(" for all ")#mi("{\\epsilon, t > 0}")#text(", where ")#mi("{P_t(x) := \\frac{1}{\\pi} \\frac{t}{x^2+t^2}}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Poisson_kernel")[#text("Poisson kernel")]#text(" and ")#mi("{*}")#text(" is the usual ")#link("http://en.wikipedia.org/wiki/Convolution")[#text("convolution")]#text(" operation.")],
[#text("(ii) Show that the non-negative measures ")#mi("{\\text{Im} F_\\epsilon(x)\\ dx}")#text(" have a finite mass independent of ")#mi("{\\epsilon}")#text(", and converge in the ")#link("http://en.wikipedia.org/wiki/Vague_topology")[#text("vague topology")]#text(" as ")#mi("{\\epsilon \\rightarrow 0}")#text(" to a non-negative finite measure ")#mi("{\\mu}")#text(".")],
[#text("(iii) Prove the Herglotz representation theorem.")]
)
]

#text("Now we return to spectral theory. Let ")#mi("{L: D \\rightarrow H}")#text(" be a densely-defined self-adjoint operator, and let ")#mi("{f \\in H}")#text(". We consider the function")

#align(center)[#tao-fit-display[#mitex("F_{f,f}(z) := \\langle R(z) f, f \\rangle")]]

#text("on the upper half-plane. We can use this function and the Herglotz representation theorem to construct spectral measures ")#mi("{\\mu_{f,f}}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" Let ")#mi("{L}")#text(", ")#mi("{f}")#text(", and ")#mi("{F_{f,f}}")#text(" be as above.")

#list(
[#text("(i) Show that ")#mi("{F_{f,f}}")#text(" is analytic. (")#emph[#text("Hint:")]#text(" use Neumann series and ")#link("http://en.wikipedia.org/wiki/Morera's_theorem")[#text("Morera’s theorem")]#text(".)")],
[#text("(ii) Show that ")#tao-math("{\\left|F_{f,f}(z)\\right| \\leq \\left\\|f\\right\\|^2/\\text{Im}(z)}", block: false)#text(" for all ")#mi("{z}")#text(" in the upper half-plane.")],
[#text("(iii) Show that ")#mi("{\\text{Im} F_{f,f}(z) \\geq 0}")#text(" for all ")#mi("{z}")#text(" in the upper half-plane. (")#emph[#text("Hint:")]#text(" You will find Exercise ")#link(<tao-8ccf2f9e9cc41e7ad5bf>)[#text("8")]#text(" to be useful.)")],
[#text("(iv) Show that ")#tao-math("{iy F_{f,f}(iy) \\rightarrow \\left\\|f\\right\\|^2}", block: false)#text(" for all ")#mi("{f \\in H}")#text(". (")#emph[#text("Hint:")]#text(" first show this for ")#mi("{f \\in D}")#text(", writing ")#mi("{f = R(i) g}")#text(" for some ")#mi("{g \\in H}")#text(".)")],
[#text("(v) Show that there is a non-negative Radon measure ")#mi("{\\mu_{f,f}}")#text(" of total mass ")#tao-math("{\\left\\|f\\right\\|^2}", block: false)#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\langle R(z) f, f \\rangle = \\int_{\\bf R} \\frac{1}{x-z}\\ d\\mu_{f,f}(x)")]]

#text("for all ")#mi("{z}")#text(" in either the upper or lower half-plane.")],
[#text("(vi) If ")#mi("{L}")#text(" is positive, show that ")#mi("{\\mu_{f,f}}")#text(" is supported in the right half-line ")#mi("{[0,+\\infty)}")#text(".")]
)
]

#text("We can ")#link("http://en.wikipedia.org/wiki/Polarization_identity")[#text("depolarise")]#text(" these measures by defining")

#align(center)[#tao-fit-display[#mitex("\\mu_{f,g} := \\frac{1}{4}( \\mu_{f+g,f+g} - \\mu_{f-g,f-g} + i \\mu_{f+ig,f+ig} - i \\mu_{f-ig,f-ig} )")]]

#text("to obtain complex measures ")#mi("{\\mu_{f,g}}")#text(" for any ")#mi("{f,g \\in H}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\langle R(z) f, g \\rangle = \\int_{\\bf R} \\frac{1}{x-z}\\ d\\mu_{f,g}(x)")]]

#text("for all ")#mi("{z}")#text(" in either the upper or lower half-plane. From duality we see that this uniquely defines ")#mi("{\\mu_{f,g}}")#text(". In particular, ")#mi("{\\mu_{f,g}}")#text(" depends sesquilinearly on ")#mi("{f,g}")#text(", and ")#mi("{\\mu_{g,f} = \\overline{\\mu_{f,g}}}")#text(". Also, since each ")#mi("{\\mu_{f,f}}")#text(" has mass ")#tao-math("{\\left\\|f\\right\\|^2}", block: false)#text(", we see that the inner product ")#mi("{\\langle f, g\\rangle}")#text(" can be recovered from the spectral measure ")#mi("{\\mu_{f,g}}")#text(": ")#metadata(none) <tao-00d8d3f11739d2f35370>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\langle f, g \\rangle = \\int_{\\bf R} \\ d\\mu_{f,g}(x).")]]





#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" With the above notation and assumptions, establish the bound ")#tao-math("{\\left\\|\\mu_{f,g} \\right\\|_{TV} \\ll \\left\\|f\\right\\| \\left\\|g\\right\\|}", block: false)#text(" for all ")#mi("{f,g \\in H}")#text(". In particular, for any bounded Borel-measurable function ")#mi("{m: {\\bf R} \\rightarrow {\\bf C}}")#text(", there exists a unique bounded operator ")#mi("{m(L): H \\rightarrow H}")#text(" such that ")#metadata(none) <tao-d7fadf9f3c25ac26cec0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\langle m(L) f, g \\rangle = \\int_{\\bf R} m(x)\\ d\\mu_{f,g}(x).")]]




]

#text("Thus, for instance ")#mi("{m(L)}")#text(" is the identity when ")#mi("{m=1}")#text(", and ")#mi("{m(L) = R(z)}")#text(" when ")#mi("{m(x) = \\frac{1}{x-z}}")#text(".")

#text("We have just created a map ")#mi("{m \\mapsto m(L)}")#text(" from the bounded Borel-measurable functions ")#mi("{B({\\bf R} \\rightarrow {\\bf C})}")#text(" on ")#mi("{{\\bf R}}")#text(", to the bounded operators ")#mi("{B(H \\rightarrow H)}")#text(" on ")#mi("{H}")#text(". Now we verify some basic properties of this map.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17 (Bounded functional calculus)")]#text(" Let ")#mi("{L: D \\rightarrow H}")#text(" be a self-adjoint densely defined operator, and let ")#mi("{m \\mapsto m(L)}")#text(" be as above.")

#list(
[#text("(i) Show that the map ")#mi("{m \\mapsto m(L)}")#text(" is ")#link("http://en.wikipedia.org/wiki/*-algebra")[#mi("{*}")#text("-linear")]#text(". In particular, if ")#mi("{m}")#text(" is real-valued, then ")#mi("{m(L)}")#text(" is self-adjoint.")],
[#text("(ii) For any ")#mi("{f, g \\in H}")#text(" and any strictly complex ")#mi("{z}")#text(", show that ")#mi("{d\\mu_{R(z) f, g}(x) = \\frac{1}{x-z}\\ d\\mu_{f,g}(x)}")#text(". (")#emph[#text("Hint:")]#text(" use the resolvent identity.)")],
[#text("(iii) For any ")#mi("{f,g \\in H}")#text(" and any ")#mi("{m \\in B({\\bf R} \\rightarrow {\\bf C})}")#text(", show that ")#mi("{d\\mu_{m(L) f, g} = m\\ d\\mu_{f,g}}")#text(".")],
[#text("(iv) Show that the map ")#mi("{m \\mapsto m(L)}")#text(" is a ")#mi("{*}")#text("-homomorphism. In particular, ")#mi("{m(L)}")#text(" and ")#mi("{m^{\\prime}(L)}")#text(" commute for all ")#mi("{m,m^{\\prime}\\in B({\\bf R} \\rightarrow {\\bf C})}")#text(".")],
[#text("(v) Show that ")#tao-math("{\\left\\|m(L)\\right\\|_{op} \\ll \\sup_{x \\in {\\bf R}} \\left|m(x)\\right|}", block: false)#text(" for all ")#mi("{m \\in B({\\bf R} \\rightarrow {\\bf C})}")#text(". Improve the ")#mi("{\\ll}")#text(" to ")#mi("{\\leq}")#text(". (")#emph[#text("Hint:")]#text(" to get this improvement, use the ")#mi("{TT^*}")#text(" identity ")#tao-math("{\\left\\|T\\right\\|_{op} = \\left\\|TT^* \\right\\|_{op}^{1/2}}", block: false)#text(" and the ")#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/")[#text("tensor power trick")]#text(".)")],
[#text("(vi) For any Borel subset ")#mi("{E}")#text(" of ")#mi("{{\\bf R}}")#text(", show that ")#mi("{\\mu(E) := 1_E(L)}")#text(" is an orthogonal projection of ")#mi("{H}")#text(". Show that ")#mi("{\\mu}")#text(" is a countably additive ")#link("http://en.wikipedia.org/wiki/Projection-valued_measure")[#text("projection-valued measure")]#text(", thus ")#mi("{\\sum_{n=1}^\\infty \\mu(E_n) = \\mu(\\bigcup_{n=1}^\\infty E_n)}")#text(" for any sequence of disjoint Borel ")#mi("{E_n}")#text(", where the convergence is in the strong operator topology.")],
[#text("(vii) For any bounded Borel set ")#mi("{E}")#text(", show that the image of ")#mi("{\\mu(E)}")#text(" lies in ")#mi("{D}")#text(".")],
[#text("(viii) Show that for any ")#mi("{f \\in D}")#text(" and ")#mi("{g \\in H}")#text(", one has ")#mi("{d\\mu_{Lf,g}(x) = x\\ d\\mu_{f,g}(x)}")#text(".")],
[#text("(ix) Let ")#mi("{D_c}")#text(" be the union of the images of ")#mi("{\\mu([-N,N])}")#text(" for ")#mi("{N=1,2,\\ldots}")#text(". Show that ")#mi("{D_c}")#text(" is a dense subspace of ")#mi("{D}")#text(" (and hence of ")#mi("{H}")#text("), and that ")#mi("{L}")#text(" maps ")#mi("{D_c}")#text(" to ")#mi("{D_c}")#text(".")],
[#text("(x) Show that ")#mi("{D}")#text(" is the space of all functions ")#mi("{f \\in H}")#text(" such that ")#tao-math("{\\int_{\\bf R} \\left|x\\right|^2\\ d\\mu_{f,f}(x) < \\infty}", block: false)#text(". Conclude in particular that ")#mi("{m(L)}")#text(" maps ")#mi("{D}")#text(" to ")#mi("{D}")#text(" for all ")#mi("{m \\in B({\\bf R} \\rightarrow {\\bf C})}")#text(".")],
[#text("(xi) If ")#mi("{m, m^{\\prime} \\in B({\\bf R} \\rightarrow {\\bf C})}")#text(" is such that ")#mi("{m^{\\prime}(x) = x m(x)}")#text(" for all ")#mi("{x \\in {\\bf R}}")#text(", show that ")#mi("{m(L)}")#text(" takes values in ")#mi("{D}")#text(", that ")#mi("{m^{\\prime}(L) f= L m(L) f}")#text(" for all ")#mi("{f \\in H}")#text(", and ")#mi("{m^{\\prime}(L) f = m(L) L f}")#text(" for all ")#mi("{f \\in D}")#text(".")],
[#text("(xii) Let ")#mi("{\\sigma(L)}")#text(" be the space of all ")#mi("{z}")#text(" such that ")#mi("{L-z: D \\rightarrow H}")#text(" is not invertible. Show that ")#mi("{\\sigma(L)}")#text(" is a closed set which is the union of the supports of the ")#mi("{\\mu_{f,g}}")#text(" as ")#mi("{f,g}")#text(" range over ")#mi("{H}")#text(". In particular, ")#mi("{\\sigma(L) \\subset {\\bf R}}")#text(", and ")#mi("{\\sigma(L) \\subset [0,+\\infty)}")#text(" when ")#mi("{L}")#text(" is positive. Show that ")#mi("{\\mu(\\sigma(L)) = \\mu({\\bf R})}")#text(" is the identity map.")],
[#text("(xiii) Extend the bounded functional calculus from the bounded Borel measurable functions ")#mi("{B({\\bf R}\\rightarrow{\\bf C})}")#text(" on ")#mi("{{\\bf R}}")#text(" to the bounded measurable functions ")#mi("{B(\\sigma(L)\\rightarrow{\\bf C})}")#text(" on the spectrum ")#mi("{\\sigma(L)}")#text(" (i.e. show that the previous statements (i)-(xi) continue to hold after ")#mi("{{\\bf R}}")#text(" is replaced by ")#mi("{\\sigma(L)}")#text(" throughout).")]
)
]

#text("The above collection of facts (or various subcollections thereof) is often referred to as the ")#emph[#text("spectral theorem")]#text(". It is stated for self-adjoint operators, but one can of course generalise the spectral theorem to essentially self-adjoint operators by applying the spectral theorem to the closure. (One has to replace the domain ")#mi("{D}")#text(" of ")#mi("{L}")#text(" by the domain ")#mi("{\\overline{D}}")#text(" of the closure ")#mi("{\\overline{L}}")#text(", of course, when doing so.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18 (Spectral measure and eigenfunctions)")]#text(" Let the notation be as in the preceding exercise, and let ")#mi("{\\lambda \\in {\\bf R}}")#text(". Show that the space ")#mi("{\\{ f \\in D: Lf = \\lambda f \\}}")#text(" is the range of the projection ")#mi("{\\mu(\\{\\lambda\\})}")#text(". In particular, ")#mi("{L}")#text(" has an eigenfunction at ")#mi("{\\lambda}")#text(" if and only if ")#mi("{\\mu(\\{\\lambda\\})}")#text(" is non-trivial.")
]

#text("We have seen how the existence of resolvents gives us a bounded functional calculus (i.e. the conclusions in the above exercise). Conversely, if a symmetric densely defined closed operator ")#mi("{L}")#text(" has a bounded functional calculus, one can define the resolvents ")#mi("{R(z)}")#text(" simply as ")#mi("{m_z(L)}")#text(", where ")#mi("{m_z(x) := \\frac{1}{x-z}}")#text(". Thus we see that the existence of a bounded functional calculus is equivalent to the existence of resolvents, which by the previous discussion is equivalent to self-adjointness.")

#text("Using the bounded functional calculus, one can not only recover the resolvents ")#mi("{R(z)}")#text(", but can now also build Schrödinger propagators ")#mi("{e^{itL}}")#text(", and when ")#mi("{L}")#text(" is positive definite one can also build heat operators ")#mi("{e^{tL}}")#text(" for ")#mi("{t > 0}")#text(" and wave operators ")#mi("{e^{it\\sqrt{L}}}")#text(" for ")#mi("{t \\in {\\bf R}}")#text(" (and also define resolvents ")#mi("{R(-k^2)}")#text(" for negative choices ")#mi("{-k^2}")#text(" of the spectral parameter). We will study these operators more in the next section.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19 (Locally bounded functional calculus)")]#text(" Let ")#mi("{L: D \\rightarrow H}")#text(" be a densely defined self-adjoint operator, and let ")#mi("{B_{loc}(\\sigma(L) \\rightarrow {\\bf C})}")#text(" be the space of Borel-measurable functions from ")#mi("{\\sigma(L)}")#text(" to ")#mi("{{\\bf C}}")#text(" which are bounded on every bounded set.")

#list(
[#text("Show that for every ")#mi("{m \\in B_{loc}(\\sigma(L) \\rightarrow {\\bf C})}")#text(" there is a unique linear operator ")#mi("{m(L): D_c \\rightarrow D_c}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("d\\mu_{m(L)f,g}(x) = m(x)\\ d\\mu_{f,g}(x)")]]

#text("whenever ")#mi("{f,g \\in D_c}")#text(".")],
[#text("(i) Show that the map ")#mi("{m \\mapsto m(L)}")#text(" is a ")#mi("{*}")#text("-homomorphism.")],
[#text("(ii) Show that when ")#mi("{m}")#text(" is actually bounded (rather than merely locally bounded), then this definition of ")#mi("{m(L)}")#text(" agrees with that in the preceding exercise (after restricting from ")#mi("{H}")#text(" to ")#mi("{D_c}")#text(").")],
[#text("(iii) Show that ")#mi("{L = \\iota(L)}")#text(", where ")#mi("{\\iota}")#text(" is the identity map ")#mi("{\\iota(x) := x}")#text(".")],
[#text("(iv) State and prove a rigorous version of the formal assertion that")

#align(center)[#tao-fit-display[#mitex("L = \\int_{\\bf R} xd \\mu(x)")]]

#text("and more generally")

#align(center)[#tao-fit-display[#mitex("m(L) = \\int_{\\bf R} m(x) d \\mu(x).")]]]
)
]

#text("Now we use the spectral theorem to place self-adjoint operators in a normal form. Let us say that two operators ")#mi("{L: D \\rightarrow H}")#text(" and ")#mi("{L^{\\prime}: D^{\\prime} \\rightarrow H^{\\prime}}")#text(" are ")#emph[#text("unitarily equivalent")]#text(" if there is a unitary map ")#mi("{U: H \\rightarrow H^{\\prime}}")#text(" with ")#mi("{U(D)=D^{\\prime}}")#text(" and ")#mi("{L^{\\prime} = U^{-1} L U}")#text(". It is easy to see that all the constructions given above (such as the bounded functional calculus) are preserved by unitary equivalence.")

#text("If ")#mi("{L: D \\rightarrow H}")#text(" is a densely defined self-adjoint operator, define an ")#emph[#text("invariant subspace")]#text(" to be a subspace ")#mi("{V}")#text(" of ")#mi("{H}")#text(" such that ")#mi("{m(L) V \\subset V}")#text(" for all ")#mi("{m \\in B(\\sigma(L) \\rightarrow {\\bf C})}")#text(". We say that a vector ")#mi("{f \\in H}")#text(" is a ")#emph[#text("cyclic vector")]#text(" for ")#mi("{H}")#text(" if the set ")#mi("{\\{ m(L) f: m \\in B(\\sigma(L) \\rightarrow {\\bf C})\\}}")#text(" is dense in ")#mi("{H}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]

#list(
[#text("(i) Show that if ")#mi("{V}")#text(" is an invariant subspace of ")#mi("{H}")#text(", then so is ")#mi("{V^\\perp}")#text(", and furthermore the orthogonal projections to ")#mi("{V}")#text(" and ")#mi("{V^\\perp}")#text(" commute with ")#mi("{m(L)}")#text(" for every ")#mi("{m \\in B(\\sigma(L) \\rightarrow {\\bf C})}")#text(".")],
[#text("(ii) Show that if ")#mi("{V}")#text(" is a invariant subspace of ")#mi("{H}")#text(", then the restriction ")#mi("{L\\downharpoonright_V: D \\cap V \\rightarrow V}")#text(" of ")#mi("{L}")#text(" to ")#mi("{V}")#text(" is a densely defined self-adjoint operator on ")#mi("{V}")#text(" with ")#mi("{\\sigma(L\\downharpoonright_V) \\subset\\sigma(L)}")#text(". Furthermore, one has ")#mi("{m(L\\downharpoonright_V) = m(L)\\downharpoonright_V}")#text(" for all ")#mi("{m \\in B(\\sigma(L) \\rightarrow {\\bf C})}")#text(".")],
[#text("(iii) Show that ")#mi("{H}")#text(" decomposes as a direct sum ")#mi("{\\bigoplus_{\\alpha \\in A} H_\\alpha}")#text(", where the index set ")#mi("{A}")#text(" is at most countable, and each ")#mi("{H_\\alpha}")#text(" is a closed invariant subspace of ")#mi("{H}")#text(" (with the ")#mi("{H_\\alpha}")#text(" mutually orthogonal), such that each ")#mi("{H_\\alpha}")#text(" has a cyclic vector ")#mi("{f_\\alpha}")#text(". (")#emph[#text("Hint:")]#text(" use Zorn’s lemma and the separability of ")#mi("{H}")#text(".)")],
[#text("(iv) If ")#mi("{H}")#text(" has a cyclic vector ")#mi("{f_0}")#text(", show that ")#mi("{L}")#text(" is unitarily conjugate to a multiplication operator ")#mi("{f(x) \\mapsto x f(x)}")#text(" on ")#mi("{L^2({\\bf R},\\nu)}")#text(" for some non-negative Radon measure ")#mi("{\\nu}")#text(", defined on the domain ")#mi("{\\{ f \\in L^2({\\bf R},\\nu): xf \\in L^2({\\bf R},\\nu) \\}}")#text(".")],
[#text("(v) For general ")#mi("{H}")#text(", show that ")#mi("{L}")#text(" is unitarily conjugate to a multiplication operator ")#mi("{f(x) \\mapsto g(x) f(x)}")#text(" on ")#mi("{L^2(X,\\nu)}")#text(" for some measure space ")#mi("{(X,\\nu)}")#text(" with a countably generated ")#mi("{\\sigma}")#text("-algebra and some measurable ")#mi("{g: X \\rightarrow {\\bf R}}")#text(", defined on the domain ")#mi("{\\{ f \\in L^2(X,\\nu): gf \\in L^2(X,\\nu) \\}}")#text(".")]
)
]

#text("The above exercise gives a satisfactory concrete description of a self-adjoint operator (up to unitary equivalence) as a multiplication operator on some measure space ")#mi("{L^2(X,\\nu)}")#text(", although we caution that this equivalence is not canonical (there is some flexibility in the choice of the underlying measure space ")#mi("{(X,\\nu)}")#text(" and multiplier ")#mi("{g}")#text(", as well as the unitary conjugation map).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" Let ")#mi("{L: D \\rightarrow H}")#text(" be a self-adjoint densely defined operator.")

#list(
[#text("(i) Show that ")#mi("{L}")#text(" is positive if and only if ")#mi("{\\sigma(L) \\subset [0,+\\infty)}")#text(".")],
[#text("(ii) Show that ")#mi("{L}")#text(" is bounded if and only if ")#mi("{\\sigma(L)}")#text(" is bounded. Furthermore, in this case we have ")#tao-math("{\\left\\|L\\right\\|_{op} = \\sup_{x \\in \\sigma(L)} \\left|x\\right|}", block: false)#text(".")],
[#text("(iii) Show that ")#mi("{H}")#text(" is trivial if and only if ")#mi("{\\sigma(L)}")#text(" is empty.")]
)
]

#heading(level: 1)[#strong[#text(" — 3. Self-adjointness and flows — ")]]

#text("Now we relate self-adjointness to a variety of flows, beginning with the heat flow.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" ")#metadata(none) <tao-ee2556352ebb644bd791>#text(" Let ")#mi("{L: D \\rightarrow H}")#text(" be a self-adjoint positive densely defined operator, and for each ")#mi("{t \\geq 0}")#text(", let ")#mi("{S(t): H \\rightarrow H}")#text(" be the heat operator ")#mi("{S(t) := e^{-tL}}")#text(".")

#list(
[#text("(i) Show that for each ")#mi("{t \\geq 0}")#text(", ")#mi("{S(t)}")#text(" is a bounded self-adjoint operator of norm at most ")#mi("{1}")#text(", that the map ")#mi("{t \\mapsto S(t)}")#text(" is continuous in the strong operator topology, and such that ")#mi("{S(0)=1}")#text(" and ")#mi("{S(t)S(t^{\\prime}) = S(t+t^{\\prime})}")#text(" for all ")#mi("{t,t^{\\prime} \\geq 0}")#text(". (The latter two properties are asserting that ")#mi("{t \\mapsto S(t)}")#text(" is a ")#emph[#text("one-parameter semigroup")]#text(".)")],
[#text("(ii) Show that for any ")#mi("{f \\in D}")#text(", ")#mi("{\\frac{S(t) f - f}{t}}")#text(" converges to ")#mi("{-Lf}")#text(" as ")#mi("{t \\rightarrow 0^+}")#text(".")],
[#text("(iii) Conversely, if ")#mi("{f \\in H}")#text(" is not in ")#mi("{D}")#text(", show that ")#mi("{\\frac{S(t) f - f}{t}}")#text(" does not converge as ")#mi("{t \\rightarrow 0^+}")#text(".")]
)
]

#text("We remark that the above exercise can be viewed as a special case of the ")#link("http://en.wikipedia.org/wiki/Hille%E2%80%93Yosida_theorem")[#text("Hille-Yoshida theorem")]#text(".")

#text("We now establish a converse to the above statement:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5")]#text(" ")#metadata(none) <tao-6f7ae7bca3cfbba37598>#text(" Let ")#mi("{H}")#text(" be a separable Hilbert space, and suppose one has a family ")#mi("{t \\mapsto S(t)}")#text(" of bounded self-adjoint operators of norm at most ")#mi("{1}")#text(" for each ")#mi("{t \\geq 0}")#text(", which is continuous in the strong operator topology, and such that ")#mi("{S(0)=1}")#text(" and ")#mi("{S(t) S(t^{\\prime}) = S(t+t^{\\prime})}")#text(" for all ")#mi("{t,t^{\\prime} \\geq 0}")#text(". Then there exists a unique self-adjoint positive densely defined operator ")#mi("{L: D \\rightarrow H}")#text(" such that ")#mi("{S(t) = e^{-tL}}")#text(" for all ")#mi("{t \\geq 0}")#text(".")
]

#text("We leave the proof of this result to the exercise below. The basic idea is to somehow use the identity")

#align(center)[#tao-fit-display[#mitex("(x+1)^{-1} = \\int_0^\\infty e^{-tx} e^{-t}\\ dt")]]

#text("which suggests that")

#align(center)[#tao-fit-display[#mitex("(L+1)^{-1} = \\int_0^\\infty S(t) e^{-t}\\ dt")]]

#text("which should allow one to recover ")#mi("{L}")#text(" from the ")#mi("{S(t)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" Let the notation be as in the above theorem.")

#list(
[#text("(i) Establish the uniqueness claim. (")#emph[#text("Hint:")]#text(" use Exercise ")#link(<tao-ee2556352ebb644bd791>)[#text("22")]#text(".)")],
[#text("(ii) Let ")#mi("{R}")#text(" be the operator")

#align(center)[#tao-fit-display[#mitex("R := \\int_0^\\infty S(t) e^{-t}\\ dt.")]]

#text("Show that ")#mi("{R}")#text(" is well-defined, bounded, positive semidefinite, and self-adjoint, with operator norm at most one, and that ")#mi("{R}")#text(" commutes with all the ")#mi("{S(t)}")#text(".")],
[#text("(iii) Show that the spectrum of ")#mi("{R}")#text(" lies in ")#mi("{[0,1]}")#text(", but that ")#mi("{R}")#text(" has no eigenvalue at ")#mi("{0}")#text(".")],
[#text("(iv) Show that there exists a densely defined self-adjoint operator ")#mi("{R^{-1}: D \\rightarrow H}")#text(" such that ")#mi("{RR^{-1}}")#text(" is the identity on ")#mi("{D}")#text(" and ")#mi("{R^{-1} R}")#text(" is the identity on ")#mi("{H}")#text(".")],
[#text("(v) Show that ")#mi("{L := R^{-1}-1}")#text(" is densely defined self-adjoint and positive definite, and commutes with all the ")#mi("{S(t)}")#text(".")],
[#text("(vi) Show that for all ")#mi("{v \\in H}")#text(" and ")#mi("{t \\geq 0}")#text(", one has ")#mi("{\\frac{d}{dt} S(t) Rf = -L S(t) Rf}")#text(" and ")#mi("{\\frac{d}{dt} e^{-tL} Rf = - L e^{-tL} Rf}")#text(", where the derivatives are in the classical limiting Newton quotient sense (in the strong topology of ")#mi("{H}")#text(").")],
[#text("(vii) Conclude the proof of Theorem ")#link(<tao-6f7ae7bca3cfbba37598>)[#text("5")]#text(". (")#emph[#text("Hint:")]#text(" show that ")#tao-math("{\\frac{d}{dt} \\left\\|S(t)Rf - e^{-tL} Rf\\right\\|^2}", block: false)#text(" is non-positive.)")]
)
]

#text("The above exercise gives an important way to establish essential self-adjointness, namely by solving the heat equation ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(1)")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" Let ")#mi("{L: D \\rightarrow H}")#text(" be a densely defined symmetric positive definite operator. Suppose that for every ")#mi("{f \\in D}")#text(" there exists a continuously differentiable solution ")#mi("{u: [0,+\\infty) \\rightarrow D}")#text(" to ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(1)")]#text(". Show that ")#mi("{L}")#text(" is essentially self-adjoint. (")#emph[#text("Hint:")]#text(" by investigating ")#tao-math("{\\frac{d}{dt} \\left\\| u(t)\\right\\|^2}", block: false)#text(", establish the uniqueness of solutions to the heat equation, which allows one to define linear contractions ")#mi("{S(t)}")#text(". To establish self-adjointness of the ")#mi("{S(t)}")#text(", take an inner product of a solution to the heat equation against a time-reversed solution to the heat equation, and differentiate that inner product in time. Now apply the preceding exercises to obtain a self-adjoint extension ")#mi("{L^{\\prime}: D^{\\prime} \\rightarrow H}")#text(" of ")#mi("{L}")#text(". To show that ")#mi("{L^{\\prime}}")#text(" is the closure of ")#mi("{L}")#text(", it suffices to show that ")#mi("{D}")#text(" is dense in ")#mi("{D^{\\prime}}")#text(" with the inner product ")#mi("{\\langle f, g \\rangle + \\langle L^{\\prime} f, g \\rangle}")#text(". But if ")#mi("{D}")#text(" is not dense in ")#mi("{D^{\\prime}}")#text(", then it has a non-trivial orthogonal complement; apply ")#mi("{S(t)}")#text(" to this complement to show that ")#mi("{D}")#text(" also has a non-trivial orthogonal complement in ")#mi("{H}")#text(", a contradiction.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" When applying the above criterion for essential self-adjointness, one usually cannot use the space ")#mi("{C^\\infty_c}")#text(" of compactly supported smooth functions as the dense subspace, because this space is usually not preserved by the heat flow. However, in practice one can get around this by enlarging the class, for instance to the class of ")#link("http://en.wikipedia.org/wiki/Schwartz_space")[#text("Schwartz functions")]#text(".")
]

#text("Now we obtain analogous results for the Schrödinger propagators ")#mi("{e^{itL}}")#text(". We begin with the analogue of Exercise ")#link(<tao-ee2556352ebb644bd791>)[#text("22")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" ")#metadata(none) <tao-91f2b430663cddf88fc6>#text(" Let ")#mi("{L: D \\rightarrow H}")#text(" be a self-adjoint densely defined operator, and for each ")#mi("{t \\in {\\bf R}}")#text(", let ")#mi("{U(t): H \\rightarrow H}")#text(" be the Schrödinger operator ")#mi("{S(t) := e^{itL}}")#text(".")

#list(
[#text("(i) Show that for each ")#mi("{t \\in {\\bf R}}")#text(", ")#mi("{U(t)}")#text(" is a unitary operator, that the map ")#mi("{t \\mapsto U(t)}")#text(" is continuous in the strong operator topology, and such that ")#mi("{U(0)=1}")#text(" and ")#mi("{U(t)U(t^{\\prime}) = U(t+t^{\\prime})}")#text(" for all ")#mi("{t,t^{\\prime} \\geq 0}")#text(".")],
[#text("(ii) Show that for any ")#mi("{f \\in D}")#text(", ")#mi("{\\frac{U(t) f - f}{t}}")#text(" converges to ")#mi("{iLf}")#text(" as ")#mi("{t \\rightarrow 0}")#text(".")],
[#text("(iii) Conversely, if ")#mi("{f \\in H}")#text(" is not in ")#mi("{D}")#text(", show that ")#mi("{\\frac{U(t) f - f}{t}}")#text(" does not converge as ")#mi("{t \\rightarrow 0}")#text(".")]
)
]

#text("Now we can give the converse, known as ")#link("http://en.wikipedia.org/wiki/Stone's_theorem_on_one-parameter_unitary_groups")[#text("Stone’s theorem on one-parameter unitary groups")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Stone’s theorem)")]#text(" ")#metadata(none) <tao-0890f0771d1b29b7b654>#text(" Let ")#mi("{H}")#text(" be a separable Hilbert space, and suppose one has a family ")#mi("{t \\mapsto U(t)}")#text(" of unitary for each ")#mi("{t \\in {\\bf R}}")#text(", which is continuous in the strong operator topology, and such that ")#mi("{U(0)=1}")#text(" and ")#mi("{U(t) U(t^{\\prime}) = U(t+t^{\\prime})}")#text(" for all ")#mi("{t,t^{\\prime} \\in {\\bf R}}")#text(". Then there exists a unique self-adjoint densely defined operator ")#mi("{L: D \\rightarrow H}")#text(" such that ")#mi("{U(t) = e^{itL}}")#text(" for all ")#mi("{t \\in {\\bf R}}")#text(".")
]

#text("We outline a proof of this theorem in an exercise below, based on using the group ")#mi("{U(t)}")#text(" to build spectral measure.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" Let the notation be as in the above theorem.")

#list(
[#text("(i) Establish the uniqueness component of Stone’s theorem.")],
[#text("(ii) Show that for any ")#mi("{f \\in H}")#text(", there is a non-negative Radon measure ")#mi("{\\mu_{f,f}}")#text(" of total mass ")#tao-math("{\\left\\|f\\right\\|^2}", block: false)#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\langle U(t) f, f \\rangle = \\int_{\\bf R} e^{itx}\\ d\\mu_{f,f}(x)")]]

#text("for all ")#mi("{t \\in {\\bf R}}")#text(". (")#emph[#text("Hint:")]#text(" use ")#link("http://en.wikipedia.org/wiki/Bochner%27s_theorem")[#text("Bochner’s theorem")]#text(", a proof of which (at least on ")#mi("{{\\bf R}}")#text(", which is the case of interest here) can be found for instance in ")#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/")[#text("these notes")]#text(".)")],
[#text("(iii) Show that for any ")#mi("{f,g \\in H}")#text(", there is a unique complex measure ")#mi("{\\mu_{f,g}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\langle U(t) f, g \\rangle = \\int_{\\bf R} e^{itx}\\ d\\mu_{f,g}(x)")]]

#text("for all ")#mi("{t \\in {\\bf R}}")#text(". Show that ")#mi("{\\mu_{f,g}}")#text(" is sesquilinear in ")#mi("{f,g}")#text(" with ")#mi("{\\mu_{g,f} = \\overline{\\mu_{f,g}}}")#text(".")],
[#text("(iv) Show that for any ")#mi("{m \\in B({\\bf R} \\rightarrow {\\bf C})}")#text(", there is a unique bounded operator ")#mi("{m(L): H \\rightarrow H}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\langle m(L) f, g \\rangle = \\int_{\\bf R} m(x)\\ d\\mu_{f,g}(x)")]]

#text("for all ")#mi("{f,g \\in H}")#text(".")],
[#text("(v) Show that ")#mi("{d\\mu_{m(L)f,g}(x) = m(x)\\ d\\mu_{f,g}(x)}")#text(" for all ")#mi("{m \\in B({\\bf R} \\rightarrow {\\bf C})}")#text(" and ")#mi("{f,g \\in H}")#text(".")],
[#text("(vi) Show that the map ")#mi("{m \\mapsto m(L)}")#text(" is a *-homomorphism from ")#mi("{B({\\bf R} \\rightarrow {\\bf C})}")#text(" to ")#mi("{B(H \\rightarrow H)}")#text(".")],
[#text("(vii) Show that there is a projection-valued measure ")#mi("{\\mu}")#text(" with ")#mi("{\\mu({\\bf R}) = 1}")#text(", such that for every ")#mi("{f, g}")#text(", the complex measure ")#mi("{\\mu_{f,g} := \\langle \\mu f, g \\rangle}")#text(" is such that")

#align(center)[#tao-fit-display[#mitex("\\langle U(t) f, g \\rangle = \\int_{\\bf R} e^{itx}\\ d\\mu_{f,g}(x)")]]

#text("for all ")#mi("{t \\in {\\bf R}}")#text(".")],
[#text("(viii) Show that there exists a self-adjoint densely defined operator ")#mi("{L: D \\rightarrow H}")#text(" whose spectral measure is ")#mi("{\\mu}")#text(".")],
[#text("(ix) Conclude the proof of Stone’s theorem.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" ")#metadata(none) <tao-d6a98598212ed729f5b9>#text(" Let ")#mi("{L: D \\rightarrow H}")#text(" be a densely defined symmetric operator. Suppose that for every ")#mi("{f \\in D}")#text(" there exists a continuously differentiable solution ")#mi("{u: {\\bf R}\\rightarrow D}")#text(" to ")#link(<tao-701586026ce95fd464c8>)[#text("(2)")]#text(". Show that ")#mi("{L}")#text(" is essentially self-adjoint.")
]

#text("We can now see a clear link between essential self-adjointness and completeness, at least in the case of scalar first-order differential operators:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" ")#metadata(none) <tao-7f1b55b860590406f84f>#text(" Let ")#mi("{M}")#text(" be a smooth manifold with a smooth measure ")#mi("{\\mu}")#text(", and let ")#mi("{X}")#text(" be a smooth vector field on ")#mi("{M}")#text(" which is divergence-free with respect to the measure ")#mi("{\\mu}")#text(". Suppose that the vector field ")#mi("{X}")#text(" is ")#emph[#text("complete")]#text(" in the sense that for any ")#mi("{x_0 \\in M}")#text(", there exists a global smooth solution ")#mi("{x: {\\bf R} \\rightarrow M}")#text(" to the ODE ")#mi("{\\frac{d}{dt} x(t) = X(x(t))}")#text(" with initial data ")#mi("{x(0)=x_0}")#text(". Show that the first-order differential operator ")#mi("{i \\nabla_X: C_c(M) \\rightarrow L^2(M)}")#text(" is essentially self-adjoint.")

#text("Extend the above result to non-divergence-free vector fields, after replacing ")#mi("{\\nabla_X}")#text(" with ")#mi("{\\nabla_X + \\frac{1}{2} \\text{div}(X)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" The requirement of completeness is basically necessary; one can still have essential self-adjointness if there are a measure zero set of initial data ")#mi("{x_0}")#text(" for which the trajectories of ")#mi("{X}")#text(" are incomplete, but once a positive measure set of trajectories become incomplete, the propagators ")#mi("{\\exp( t \\nabla_X )}")#text(" do not make sense globally, and so self-adjointness should fail.")
]

#text("Finally, we turn to the relationship between self-adjointness and the wave equation, which is a more complicated variant of the relationship between self-adjointness and the Schrödinger equation. More precisely, we will show the following version of Exercise ")#link(<tao-d6a98598212ed729f5b9>)[#text("27")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7")]#text(" ")#metadata(none) <tao-07d3f64ecfc4a56b4e13>#text(" Let ")#mi("{L: D \\rightarrow H}")#text(" be a densely defined positive symmetric operator. Suppose for every ")#mi("{f, g \\in D}")#text(", there exists a twice continuously differentiable (in ")#mi("{D}")#text(") solution ")#mi("{u: {\\bf R} \\rightarrow D}")#text(" to ")#link(<tao-4b125ec99a74470517f9>)[#text("(3)")]#text(". Then ")#mi("{L}")#text(" is essentially self-adjoint.")
]

#text("(One could also obtain wave equation analogues of Exercise ")#link(<tao-91f2b430663cddf88fc6>)[#text("25")]#text(" or Theorem ")#link(<tao-0890f0771d1b29b7b654>)[#text("6")]#text(", but these are somewhat messy to state, and we will not do so here.)")

#text("We now prove this theorem. To simplify the exposition, we will assume that ")#mi("{L}")#text(" is strictly positive, in the sense that ")#mi("{\\langle Lf, f \\rangle > 0}")#text(" for all non-zero ")#mi("{f \\in D}")#text(", and leave the general case as an exercise.")

#text("We introduce a new inner product ")#mi("{\\langle, \\rangle_{\\dot H^1}}")#text(" on ")#mi("{D}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\langle f, g \\rangle_{\\dot H^1} := \\langle Lf, g \\rangle.")]]

#text("By hypothesis, this is a Hermitian inner product on ")#mi("{D}")#text(". We then define an inner product ")#mi("{\\langle, \\rangle_E}")#text(" on ")#mi("{D \\times D}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\langle (u_0,u_1), (v_0,v_1) \\rangle_E := \\langle u_0, v_0 \\rangle_{\\dot H^1} + \\langle u_1, v_1 \\rangle,")]]

#text("then this is a Hermitian inner product on ")#mi("{D \\times D}")#text(". We define the ")#emph[#text("energy space")]#text(" ")#mi("{{\\mathcal E}}")#text(" be the completion of ")#mi("{D \\times D}")#text(" with respect to this inner product; we can factor this as ")#mi("{{\\mathcal E} = \\dot H^1 \\times H}")#text(", where ")#mi("{\\dot H^1}")#text(" is the completion of ")#mi("{D}")#text(" using the ")#mi("{\\dot H^1}")#text(" inner product.")

#text("Suppose ")#mi("{u: {\\bf R} \\rightarrow D}")#text(" is a twice continuously differentiable solution to ")#link(<tao-4b125ec99a74470517f9>)[#text("(3)")]#text(" for some ")#mi("{f,g \\in D}")#text(". Then if we define the energy")

#align(center)[#tao-fit-display[#mitex("E(t) := \\frac{1}{2} \\langle (u, \\partial t u),(u, \\partial t u) \\rangle_E,")]]

#text("then one easily computes using ")#link(<tao-4b125ec99a74470517f9>)[#text("(3)")]#text(" that ")#mi("{\\partial_t E(t) = 0}")#text(", and so")

#align(center)[#tao-fit-display[#mitex("E(t) = E(0) = \\frac{1}{2} \\langle (f, g), (f,g) \\rangle_E.")]]

#text("In particular, if ")#mi("{f=g=0}")#text(", then ")#mi("{u=0}")#text(", and so twice continuously differentiable solutions to ")#link(<tao-4b125ec99a74470517f9>)[#text("(3)")]#text(" are unique. This allows us to define wave operators ")#mi("{W(t): D \\times D \\rightarrow D \\times D}")#text(" by defining ")#mi("{W(t)(f,g) := (u(t), \\partial_t u(t))}")#text(". This is clearly linear, and from the energy identity we see that ")#mi("{W}")#text(" is an isometry, and thus extends to an isometry on the energy space ")#mi("{{\\mathcal E}}")#text(". From uniqueness we also see that ")#mi("{t \\mapsto W(t)}")#text(" is a one-parameter group, i.e. a homomorphism that is continuous in the strong operator topology. In particular, the isometries ")#mi("{W(t)}")#text(" are invertible and are thus unitary. By Stone’s theorem, there thus exists a densely defined self-adjoint operator ")#mi("{A: \\tilde D \\rightarrow {\\mathcal E}}")#text(" on some dense subspace ")#mi("{\\tilde D}")#text(" of ")#mi("{{\\mathcal E}}")#text(" such that ")#mi("{W(t) = e^{itA}}")#text(" for all ")#mi("{t \\in {\\bf R}}")#text(".")

#text("If ")#mi("{(f,g) \\in D \\times D}")#text(", then from the twice differentiability of the solution ")#mi("{u}")#text(" to the wave equation, we see that")

#align(center)[#tao-fit-display[#mitex("\\lim_{t \\rightarrow 0} \\frac{W(t)(f,g) - (f,g)}{t} = (g, -L f).")]]

#text("From Exercise ")#link(<tao-701586026ce95fd464c8>)[#text("2")]#text(", we conclude that ")#mi("{D \\times D \\subset \\tilde D}")#text(" and ")#metadata(none) <tao-b063dd3619e542ef6afc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("A(f,g) = (-ig,iL f)")]]



#text(" for all ")#mi("{(f,g) \\in D \\times D}")#text(".")

#text("Now we need to pass from the self-adjointness of ")#mi("{A}")#text(" to the essential self-adjointness of ")#mi("{L}")#text(". Suppose for contradiction that ")#mi("{L}")#text(" was not essentially self-adjoint. Then ")#mi("{L+1}")#text(" does not have dense image, and so there exists a non-zero ")#mi("{h \\in H}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\langle (L+1) f, h \\rangle = 0")]]

#text("for all ")#mi("{f \\in D}")#text(".")

#text("It will be convenient to work with a “band-limited” portion of ")#mi("{D \\times D}")#text(", to get around the problem that ")#mi("{A}")#text(" and ")#mi("{L}")#text(" can leave this domain. Let ")#mi("{\\phi: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a compactly supported even smooth function of total mass one. For any ")#mi("{R>0}")#text(", define the ")#emph[#text("Littlewood-Paley projection")]

#align(center)[#tao-fit-display[#mitex("P_{\\leq R} := \\int_{\\bf R} R \\phi(R t) W(t)\\ dt = \\int_{\\bf R} R \\phi(Rt) e^{itA}\\ dt = \\hat \\phi( A/R ),")]]

#text("where ")#mi("{\\hat \\phi}")#text(" is the Schwartz function ")#mi("{\\hat \\phi(\\xi) := \\int_{\\bf R} \\phi(t) e^{it\\xi}\\ dt}")#text(". Then (by strong continuity of ")#mi("{W(t)}")#text(") these operators map ")#mi("{D\\times D}")#text(" to ")#mi("{D \\times D}")#text(", commutes with the entire functional calculus of ")#mi("{A}")#text(", and also maps ")#mi("{{\\mathcal E}}")#text(" to ")#mi("{\\tilde D}")#text(". Also, from functional calculus one sees that")

#align(center)[#tao-fit-display[#mitex("A P_{\\leq R} = i \\int_{\\bf R} R^2 \\phi^{\\prime}(Rt) W(t)\\ dt")]]

#text("and in particular ")#mi("{A P_{\\leq R}}")#text(" maps ")#mi("{D \\times D}")#text(" to ")#mi("{D \\times D}")#text(" as well.")

#text("Let ")#mi("{\\tau: {\\mathcal E} \\rightarrow {\\mathcal E}}")#text(" be the reflection operator ")#mi("{\\tau(f,g) := (f,-g)}")#text(". From time reversal of the wave equation, we have ")#mi("{W(t) \\tau = \\tau W(-t)}")#text(", and thus ")#mi("{\\tau}")#text(" commutes with ")#mi("{P_{\\leq R}}")#text(". In particular, we can write")

#align(center)[#tao-fit-display[#mitex("P_{\\leq R} (f,g) = (P_{\\leq R}^0 f, P_{\\leq R}^1 g)")]]

#text("for some operators ")#mi("{P_{\\leq R}^0: \\dot H^1 \\rightarrow \\dot H^1}")#text(" and ")#mi("{P_{\\leq R}^1: H \\rightarrow H}")#text(". Since ")#mi("{P_{\\leq R}}")#text(" preserves ")#mi("{D \\times D}")#text(", the operators ")#mi("{P_{\\leq R}^0, P_{\\leq R}^1}")#text(" preserve ")#mi("{D}")#text(".")

#text("For any ")#mi("{(f,g) \\in D \\times D}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("P_{\\leq R} A(f,g) = A P_{\\leq R}(f,g);")]]

#text("combining this with ")#link(<tao-b063dd3619e542ef6afc>)[#text("(12)")]#text(" we see that")

#align(center)[#tao-fit-display[#mitex("P_{\\leq R}^0 g = P_{\\leq R}^1 g")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("P_{\\leq R}^1 Lf = L P_{\\leq R}^0 f")]]

#text("for all ")#mi("{f, g \\in D}")#text(". Also, since ")#mi("{A P_{\\leq R}}")#text(" preserves ")#mi("{D \\times D}")#text(", we see that ")#mi("{L P_{\\leq R}^0 = P_{\\leq R}^1 L}")#text(" preserves ")#mi("{D}")#text(".")

#text("We can then expand ")#mi("{A^2 P_{\\leq R}(f,g)}")#text(" as")

#tao-aligned(keep: true)[


#tao-math("A P_{\\leq R} A (f,g)  & = A P_{\\leq R} (-ig, iLf )", block: true)



#tao-math(" & = A (-i P_{\\leq R}^1 g, i L P_{\\leq R}^0 f )", block: true)



#tao-math(" & = (L P_{\\leq R}^0 f, L P_{\\leq R}^1 g)", block: true)
]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("(A^2+1) P_{\\leq R}(f,g) = ((L+1) P_{\\leq R}^0 f, (L+1) P_{\\leq R}^1 g).")]]

#text("In particular")

#align(center)[#tao-fit-display[#mitex("\\langle (A^2+1) P_{\\leq R}(f,g), (0,h) \\rangle_{\\mathcal E} = 0")]]

#text("for all ")#mi("{(f,g) \\in D \\times D}")#text(". By duality (noting that ")#mi("{(A^2+1) P_{\\leq R}}")#text(" is a bounded real function of ")#mi("{A}")#text(") we conclude that")

#align(center)[#tao-fit-display[#mitex("(A^2+1) P_{\\leq R} (0,h) = 0")]]

#text("But by sending ")#mi("{R \\rightarrow \\infty}")#text(" and using the spectral theorem, this implies from monotone convergence that the spectral measure ")#mi("{\\mu_{(0,h),(0,h)}}")#text(" is zero, and thus ")#mi("{(0,h)}")#text(" vanishes in ")#mi("{{\\mathcal E}}")#text(", a contradiction. This establishes the essential self-adjointness of ")#mi("{L}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29")]#text(" Establish Theorem ")#link(<tao-07d3f64ecfc4a56b4e13>)[#text("7")]#text(" without the assumption that ")#mi("{L}")#text(" is strictly positive. (")#emph[#text("Hint:")]#text(" use the Cauchy-Schwarz inequality to show that strict positivity is equivalent to the absence of eigenfunctions with eigenvalue zero, and then quotient out such eigenfunctions.)")
]

#heading(level: 1)[#strong[#text(" — 4. Essential self-adjointness of the Laplace-Beltrami operator — ")]]

#text("We now discuss how one can use the above criteria to establish essential self-adjointness of a Laplace-Beltrami operator ")#mi("{-\\Delta_g}")#text(" on a smooth complete Riemannian manifold ")#mi("{(M,g)}")#text(", viewed as a densely defined symmetric positive operator on the dense subspace ")#mi("{C^\\infty_c(M)}")#text(" of ")#mi("{L^2(M)}")#text(". This result was first established ")#link("http://www.ams.org/mathscinet-getitem?mr=48138")[#text("by Gaffney")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=151927")[#text("by Roelcke")]#text(".")

#text("To do this, we have to solve a PDE – either the Helmholtz equation ")#link(<tao-ab14d3faa25e917efe6e>)[#text("(4)")]#text(" (for some ")#mi("{z}")#text(" not on the positive real axis), the heat equation ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(1)")]#text(", the Schrödinger equation ")#link(<tao-91f2b430663cddf88fc6>)[#text("(25)")]#text(", or the wave equation ")#link(<tao-4b125ec99a74470517f9>)[#text("(3)")]#text(".")

#text("The Schrödinger formalism is quite suggestive. From a semiclassical perspective, the Schrödinger equation associated to the Laplace-Beltrami operator ")#mi("{-\\Delta_g}")#text(" should be viewed as a quantum version of the classical flow associated to the corresponding Hamiltonian ")#mi("{g^{ij}(x) \\xi_i \\xi_j}")#text(", i.e. geodesic flow. From Exercise ")#link(<tao-7f1b55b860590406f84f>)[#text("28")]#text(" we know that the generator of Hamiltonian flows (normalised by ")#mi("{i}")#text(") are essentially self-adjoint when they are complete (note from ")#link("http://en.wikipedia.org/wiki/Liouville%27s_theorem_(Hamiltonian)")[#text("Liouville’s theorem")]#text(" that such generators are automatically divergence-free with respect to Liouville measure), which suggests that the Schrödinger operator ")#mi("{-\\Delta_g}")#text(" should be also. Unfortunately, this is not a rigorous argument, and is difficult to make it so due to the nature of the time-dependent Schrödinger equation, which has infinite speed of propagation, and no dissipative properties. In practice, we therefore establish esssential self-adjointness by solving one of the other equations.")

#text("To solve any of these equations, it is difficult to solve any of them by an exact formula (unless the manifold ")#mi("{M}")#text(" is extremely symmetric); but one can proceed by solving them ")#emph[#text("approximately")]#text(", and using perturbation theory to eliminate the error. This method works as long as the error created by the approximate solution is both sufficiently small and sufficiently smooth that perturbative techniques (such as Neumann series, or the inverse function theorem) become applicable. (This type of method, for instance, is used to deduce essential self-adjointness of various perturbations ")#mi("{-\\Delta+V}")#text(" of the Laplace-Beltrami operator from the essential self-adjointness of the original operator ")#mi("{-\\Delta}")#text(".)")

#text("For instance, suppose one is trying to solve the Helmholtz equation")

#align(center)[#tao-fit-display[#mitex("(-\\Delta_g + k^2) u = f")]]

#text("for some large real ")#mi("{k}")#text(", and some ")#mi("{f \\in L^2(M)}")#text(". For sake of concreteness let us take ")#mi("{M}")#text(" to be three-dimensional. If ")#mi("{M}")#text(" was a Euclidean space ")#mi("{{\\bf R}^3}")#text(", then we have an explicit formula")

#align(center)[#tao-fit-display[#tao-math("u(x) = \\frac{1}{4\\pi} \\int_{{\\bf R}^3} \\frac{e^{-k\\left|x-y\\right|}}{\\left|x-y\\right|} f(y)\\ dy", block: true)]]

#text("for the solution; note that the exponential decay of ")#tao-math("{e^{-k\\left|x-y\\right|}}", block: false)#text(" will keep ")#mi("{u}")#text(" in ")#mi("{L^2}")#text(" as well. Inspired by this, we can try to solve the Helmholtz equation in curved space by proposing as an approximate solution")

#align(center)[#tao-fit-display[#mitex("u(x) = \\frac{1}{4\\pi} \\int_{M} \\frac{e^{-k d(x,y)}}{d(x,y)} f(y)\\ dg(y).")]]

#text("This is a little problematic because ")#mi("{d(x,y)}")#text(" develops singularities after a certain point, but if one has a uniform lower bound on the injectivity radius (here we are implicitly using the hypothesis of completeness), and also uniform bounds on the curvature and its derivatives, one can truncate this approximate solution to the region where ")#mi("{d(x,y)}")#text(" is small, and obtain an approximate solution ")#mi("{u}")#text(" whose error")

#align(center)[#tao-fit-display[#mitex("e := (-\\Delta_g + k^2) u - f")]]

#text("can be made to be smaller in ")#mi("{L^2}")#text(" norm than that of ")#mi("{f}")#text(" if the spectral parameter ")#mi("{k}")#text(" is chosen large enough; we omit the details. From this, we can then solve the Helmholtz equation by Neumann series and thus establish essential self-adjointness. A similar method also works (under the same hypotheses on ")#mi("{M}")#text(") to construct approximate heat kernels, giving another way to establish essential self-adjointness of the Laplace-Beltrami operator.")

#text("What about when there is no uniform bound on the geometry? In that case, it is best to work with the wave equation formalism, because the finite speed of propagation property of that equation allows one to localise to compact portions of the manifold for which uniform bounds on the geometry are automatic. Indeed, to solve the wave equation in ")#mi("{C^\\infty_c(M)}")#text(" for some fixed period of time, one can use finite speed of propagation, combined with completeness of the manifold, to work in a compact subset of this manifold, which by suitable alteration of the metric beyond the support of the solution, one can view as a subset of a compact complete manifold. On such manifolds, we already know essential self-adjointness by the previous arguments, so we may solve the wave equation in that setting (one can also solve the wave equation using methods from microlocal analysis, if desired), and then take repeated advantage of finite speed of propagation (which can be proven rigorously by energy methods) to glue together these local solutions to obtain a global solution; we omit the details.")

#text("In all these cases, a somewhat nontrivial application of PDE theory is required. Unfortunately, this seems to be inevitable; at some point one must somehow use the hypothesis of completeness of the underlying manifold, and PDE methods are the only known way to connect that hypothesis to the dynamics of the Laplace-Beltrami operator.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (31)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b7e2a1bd0526391c20e26577dd944eca8d0cb6691746df2afe6fd2b2c94e086-20257719d9ae3d6d0e100d3ea8225b8877f47930a8ee8c92d310256210c9063e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guest")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-117311")[#strong[#text("Guest")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2011")])]

#text("No need to publish this, just a small correction on Exercise 23:")

#text("“To establish self-adjointness of the s(t) , take an inner product of a solution to the heat equation against a time-reversed solution OF the heat equation, and differentiate that inner product in time.”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c6953ab4425d109767a7eef3ecc7c8cf8d944a87ec5e2a502981e671d9cc1a-1d73f6869dd4b3f2691c3f1f37c65f3584e7eca39cd73c5b09d3068e6ab0d958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-117525")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2011")])]

#text("Question: In the definition of adjoint just before Ex 3, it’s not clear to me why ")#mi("D^*")#text(" contains non-zero vectors at all, let alone why the adjoint is also a densely defined operator. If $L$ is symmetric then obviously ")#mi("D \\subset D^*")#text(" — what happens in general?")

#text("Typos:")

#text("Pf of Lemma 1: last \\neq should be a \\to")#linebreak()#text(" Statement of Prop 3(i): R(z) is everywhere defined iff the kernel is ")#emph[#text("trivial")]#text(".")#linebreak()#text(" Pf of Prop 3(i): In the second inline equation, the subspace is contained in ")#mi("H")#text(", not equal to it. Later, the non-zero vector should be ")#mi("g\\in H")#text(".")#linebreak()#text(" Ex 9: Isn’t the adjoint of multiplication by ")#mi("m")#text(" be multiplication by the complex conjugate? [i.e. did you mean for the function to be real valued?]")#linebreak()#text(" Ex 17: missing closing parenthesis at the end.")

#emph[#text("[Corrected, thanks. In general, the adjoint could well be trivial; I added an exercise to this effect. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/727990b2671e480565e8288b1743eb18c255528dcb3b64b9c5518e686383e1b7-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Александр Шапошников")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-120008")[#strong[#text("Александр Шапошников")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2012")])]

#text("It seems to me there is a missprint in Exercise 11:")#linebreak()#text(" R(i) and R(-i) should be interchanged")

#emph[#text("[Corrected, thanks – T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/42d91570b03d6081ac34817db0e3ecb9727e75d4da5d3a2584c57469eb4a0825-7c9a50b6b35d76663dcb73de2a455494350b0c9a7f94b8c36d82dbb2d7a6cd0b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Александр Шапошников")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-120272")[#strong[#text("Александр Шапошников")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2012")])]

#text("There is another small missprint in Exercise 17")#linebreak()#text(" (item (x)): ")#mi("\\int\\limits_{\\mathbb{R}}|x|\\,d\\mu_{f, f} < \\infty")#text(" should be replaced with ")#mi("\\int\\limits_{\\mathbb{R}}x^2\\,d\\mu_{f, f} < \\infty")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-143650")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2012")])]

#text("I would like to suggest a minor improvement to Exercise 11. The operator given there is not closed, but the previous text defines the resolvent only in the closed case. This can be a little confusing to the beginner and I suggest that a little note might be added to make explicit that the resolvent of a closable operator is assumed to be the resolvent of the closure. Thank you.")

#emph[#text("[Suggestion implemented, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ed4366c4acfdc577f31106b0d2504d33afb14aea32f847ce714bfb993b9550d-99b4a49893d437a8a2d40bd6d1e11fb0465f0dfaac37539a0136bac7bd85b261.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of VMT")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-416573")[#strong[#text("VMT")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2014")])]

#text("Hi! I don’t understand the hint for ex 17.(v): using the fact that ")#tao-math("\\left\\|f\\right\\|^2=\\left\\|\\mu_{f,f}\\right\\|^2", block: false)#text(" and ex 17.(iii) we directly obtain ")#tao-math("\\left\\|m(L)f\\right\\|^2=\\int d\\mu_{m(L)f,m(L)f}=\\int \\left|m(x)\\right|^2 d\\mu_{f,f}(x)\\le\\left\\|m\\right\\|_\\infty \\left\\|f\\right\\|^2", block: false)#text(", which already implies ")#tao-math("\\left\\|m(L)\\right\\|_{op}\\le\\left\\|m\\right\\|_\\infty", block: false)#text(".")#linebreak()#text(" If this is correct, what did you have in mind when you wrote the hint?")#linebreak()#text(" (Sorry for posting a doubt about a 3 years-old entry..)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-416580")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2014")])]

#text("Oh, that’s a nice solution! My solution proceeded by bounding ")#mi("\\mu_{m(L) f, g}")#text(" instead, and the depolarisation identity can cost one a factor of 4 or so when one uses that route, if one isn’t being careful. (I’m also very fond of the tensor power trick, so I couldn’t resist an opportunity to sneak it in, even if as it turns out it can be done without in this case.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ed4366c4acfdc577f31106b0d2504d33afb14aea32f847ce714bfb993b9550d-99b4a49893d437a8a2d40bd6d1e11fb0465f0dfaac37539a0136bac7bd85b261.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of VMT")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-416584")[#strong[#text("VMT")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2014")])]

#text("Thank you; so you probably proceeded by bounding ")#tao-math("\\left\\|\\mu_{f,g}\\right\\|_{TV}", block: false)#text(" in terms of ")#tao-math("\\left\\|f\\right\\| \\left\\|g\\right\\|", block: false)#text(". Still, I don’t understand how one can use the depolarisation identity.. On the other hand, if you use Cauchy-Schwarz you get ")#tao-math("\\left\\|\\mu_{f,g}\\right\\|_{TV}\\le\\left\\|f\\right\\| \\left\\|g\\right\\|", block: false)#text(".")#linebreak()#text(" If the answer is complicated, never mind!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-416587")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2014")])]

#text("Depolarisation gives a bound of the form ")#tao-math("\\left\\|\\mu_{f,g}\\right\\|_{TV} \\ll \\left\\|f\\right\\|^2 + \\left\\|g\\right\\|^2", block: false)#text(" which one can then amplify to ")#tao-math("\\left\\|\\mu_{f,g}\\right\\|_{TV} \\ll \\left\\|f\\right\\| \\left\\|g\\right\\|", block: false)#text(" by using homogeneity, as in ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("this previous post")]#text(". But it is true that by using the abstract Cauchy-Schwarz inequality, one can pass directly to ")#tao-math("\\left\\|\\mu_{f,g}\\right\\|_{TV} \\leq \\left\\|f\\right\\| \\left\\|g\\right\\|", block: false)#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ed4366c4acfdc577f31106b0d2504d33afb14aea32f847ce714bfb993b9550d-99b4a49893d437a8a2d40bd6d1e11fb0465f0dfaac37539a0136bac7bd85b261.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of VMT")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-416591")[#strong[#text("VMT")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2014")])]

#text("Ah, now I see. Very instructive, thank you!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/995c17988d83779c67addfbf437597dbb23ae42af3176c1f36e7f0c2b1b20052-49b9b950314e79ea7c2a7eac534543ad34c7e40f25da89b72a264504526c695d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-501897")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2018")])]

#text("Hi, Sorry to comment on and old comment of a relatively old post. I am a bit stuck trying to show that ")#tao-math("\\left|\\left|\\mu_{f,g}\\right|\\right|_{TV}\\leq \\left|\\left|f\\right|\\right||g||", block: false)#text(" directly using Cauchy-Schwarz (CS). It is a consequence of CS that for any measurable subset ")#mi("A")#text(", ")#tao-math("\\left|\\mu_{f,g}(A)\\right|\\leq \\mu_{f,f}(A)^{1/2}\\mu_{g,g}(A)^{1/2}( \\leq \\left|\\left|f\\right|\\right|\\left|\\left|g\\right|\\right|)", block: false)#text(".")#linebreak()#text(" but then if ")#mi("\\{A_j\\}")#text(" is a finite partition of ")#mi("\\mathbb{R}")#text(" one has:")#linebreak()#text(" ")#tao-math("\\displaystyle \\sum_j \\left|\\mu_{f,g}(A_j)\\right| \\leq \\sum_j \\mu_{f,f}(A_j)^{1/2} \\mu_{g,g}(A_j)^{1/2} \\leq \\left|\\left|g\\right|\\right| \\sum_j \\sqrt{\\mu_{f,f}(A_j)}", block: false)#text(" and here I would want to use finite additivity to remove the sum and bound by ")#tao-math("\\left|\\left|f\\right|\\right|", block: false)#text(" but the square root seems to prevent me from doing so. What is the trick I’m missing ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-501899")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2018")])]

#text("Hmm, I see now that to get the sharp inequality one needs to already possess the functional calculus, since with that calculus one can write ")#tao-math("\\sum_j \\left|\\mu_{f,g}(A_j)\\right|", block: false)#text(" as ")#mi("\\langle m(L) f, g \\rangle")#text(" for some piecewise constant multiplier ")#mi("m")#text(" bounded in magnitude by 1. So to avoid circularity one may have to revert back to the depolarisation argument that loses an absolute constant (something like 4), since one does not need the sharp inequality at this stage of the construction.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/476b1e800f647486ed862160abe8ac2a1e37602f82fd246a1824b9f4b97b7154-edf26c1505ea55a09e1cde1da485b73dd821ea970c2e82bc5b3ca8ff1634fad8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ramesh")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-454142")[#strong[#text("Ramesh")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2015")])]

#text("Can you please give a reference for the spectral theorem (multiplication form) for unbounded normal operators")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A wave equation approach to automorphic forms in analytic number theory | What's new")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-458251")[#strong[#text("A wave equation approach to automorphic forms in analytic number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2015")])]

#text("[…] as discussed in this previous post, the spectral theory of an essentially self-adjoint operator such as is basically equivalent to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-480226")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2017")])]

#text("Would you say something about what would people do if the unbounded linear operator is not densely defined on a Hilbert space? Can it be reduced to the densely defined case?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-482096")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2017")])]

#text("Can’t you just take the closure of the domain of definition, where the Hermitian form will be the restriction, to obtain a new, smaller Hilbert space, and get a self-map via orthogonal projection?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-481829")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2017")])]

#text("If the operator is linear and densely defined, but the domain of definition is not a linear space, the ex. 1 seems to require even boundedness of L, even though I didn’t find a counter-example yet.")

#emph[#text("[In the definition of “densely defined”, the domain of definition is understood to be a linear subspace, not just a set (otherwise it does not makes sense to require $latex $L$ to be linear. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-482184")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2017")])]

#text("Let ")#mi("L")#text(" be densely defined on a set ")#mi("D(L) \\subset H")#text(", ")#mi("H")#text(" a complex Hilbert space, and let ")#mi("v, w \\in H")#text(" and ")#mi("\\lambda, \\mu \\in \\mathbb C")#text(". We call ")#mi("L")#text(" linear iff ")#mi("\\lambda v + \\mu w, v, w \\in D(L)")#text(" implies ")#mi("L(\\lambda v + \\mu w) = \\lambda L(v) + \\mu L(w)")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-481895")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2017")])]

#text("Dear Prof. Tao,")

#text("please add a bar to the L in the equation defining the Sobolev norm in ex. 2, and formulate: “The Sobolev space is defined as the domain of definition of the closed operator \\overline L with Sobolev norm…”; indeed, closure can only be taken in spaces where you already have a norm on the larger space, as far as I know (on the other hand, the completion can be performed without any larger space around the space which is to be completed).")

#emph[#text("[“closure” replaced with “completion” -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-483332")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2017")])]

#text("Dear Prof. Tao, in the proof of Prop. 3 (i) please replace ")#mi("v \\in H")#text(" by ")#mi("g \\in H")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dac55d9445234b39b1dfd5fd3a9726d0369d92cde90f1b2771d9eee83fd57443-56e78dc8275be4663a9602336684f89960c7f9337ab9c538440349a4a8ca24a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oskar")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-483726")[#strong[#text("Oskar")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2017")])]

#text("In exercise 16 and 17 what is being meant with $\\ll$?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Math student")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-484145")[#strong[#text("Math student")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2017")])]

#text("In ex. 14 i) I’m having difficulty finding the right harmonic function to which to apply Liouville’s theorem; of course, the function needs to be defined on a whole real vector space, so I thought that I’d insert the exponential function, but the derivatives don’t want to cancel, in particular since we have a complicated convolution expression in there, which doesn’t seem to be easily evaluated. At this point, after several hours of thought, I raise the white flag. To which harmonic function do I have to apply Liouville?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-484157")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2017")])]

#text("Oops, I meant to say the maximum principle instead of Liouville’s theorem; I’ve updated the hint accordingly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-484175")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2017")])]

#text("At least, I discovered Nelson’s proof of Liouville’s theorem: Pick any two points, apply the average formula to very large neighbourhoods of these points, and observe that the neighbourhoods are equal up to “small” sets which don’t really perturb the outcome by boundedness.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mizar")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-525260")[#strong[#text("Mizar")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2019")])]

#text("Speaking of Exercise 14 (i), actually I can’t see it directly using the maximum principle, but rather by (odd) reflection in the hyperplane ")#mi("\\{t=0\\}")#text(", which gives a bounded harmonic function on ")#mi("\\mathbb R^2")#text(", and concluding with Liouville.")

#emph[#text("[Fair enough; I’ve removed the hint. -T]")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ee31510df3f52ddca255a2c79ef510e7dc7a86dc8c85bea96dc61603bc82fb4-eff6a90e4f17430e38242055ed1521ae6d9404483ee9181743cb8a1cc2719830.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nicola.arcozzi")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-688020")[#strong[#text("nicola.arcozzi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2025")])]

#text("Dear Prof. Tao, thanks for this. I have based part of a Master level course in Functional Analysis on these notes (solving exercises is motivating). I had a problem with Ex. 26 (v): it is easy to get it for continuous $m$, but I coud not think of a way to extend it to the measurable functions, without resorting to the Lebesgue-Hausdorff theorem on Borel functions (which requires, I believe, some trasfinite induction). [The notes are on arxiv].")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-688031")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2025")])]

#text("The idea is to use (iv) to show that the two measures in (v) have the same Fourier transform. It helps to first establish the relation between ")#mi("\\mu_{f,g}")#text(" and ")#mi("\\mu_{f,U(-t)g}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ee31510df3f52ddca255a2c79ef510e7dc7a86dc8c85bea96dc61603bc82fb4-eff6a90e4f17430e38242055ed1521ae6d9404483ee9181743cb8a1cc2719830.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nicola.arcozzi")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-688034")[#strong[#text("nicola.arcozzi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2025")])]

#text("What I get is")#linebreak()#mi("\\int_{\\mathbb{R}}e^{it}m(x)d\\mu_{f,g}(x)=\\int_{\\mathbb{R}}m(x)d\\mu_{f,U_tg}(x)=\\langle f,m(L)U_tg\\rangle")#linebreak()#text("and")#linebreak()#mi("\\int_{\\mathbb{R}}e^{it}d\\mu_{f,m(L)g}(x)=\\langle f,U_t m(L)g\\rangle.")#linebreak()#text("Here I seem to need ")#mi("U_tm(L)=m(L)U_t")#text(". It holds for trigonometric polynomials ")#mi("m")#text(", for their uniform limits, and the relation passes to pointwise limits of uniformly bounded sequences of functions. Here is where I use the Lebesgue-Hausdorff lemma. I might have missed something.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-688035")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2025")])]

#text("One has ")#mi("\\langle U(t) m(L) f, g\\rangle = \\langle m(L) f, U(-t) g \\rangle = \\int_{\\bf R} m(x) d\\mu_{f,U(-t) g}(x)")#text(" and ")#mi("\\langle m(L) U(t) f, g \\rangle = \\int_{\\bf R} m(x) d\\mu_{U(t) f, g}(x)")#text(", so we reduce to ")#mi("\\mu_{f,U(-t)g} = \\mu_{U(t) f, g}")#text(". But this is clear after taking Fourier transforms of both sides.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ee31510df3f52ddca255a2c79ef510e7dc7a86dc8c85bea96dc61603bc82fb4-eff6a90e4f17430e38242055ed1521ae6d9404483ee9181743cb8a1cc2719830.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nicola.arcozzi")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-688036")[#strong[#text("nicola.arcozzi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2025")])]

#text("Thanks!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/#comment-688368")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2025")])]

#text("Thank you for this beautifully structured exposition on spectral decompositions of unbounded symmetric operators. I’ve been exploring whether physical systems—particularly gravitational fields and entropy shells—can be modeled as harmonic domains, where boundary tension (e.g., gravitational thinning zones) modifies the effective domain of operators like the Laplacian.")

#text("Your discussion about the necessity of operator self-adjointness under varying domains made me wonder: could the physical ‘membrane’ of spacetime be treated analogously as a spectral surface, where entropy and field tension dynamically alter the domain structure?")

#text("In particular, I’ve been studying localized gravitational constant variations as phase-sensitive shifts, which might correspond to operator eigenvalue drift in curved harmonic shells. I’d be curious whether such physical modulation has an analog in your work on unbounded operators.")

#text("With respect")
]
