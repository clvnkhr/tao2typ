// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/
// Converted to Typst by tao2typ: "2026-10-14T15:17:25.307468+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The least quadratic nonresidue, and the square root barrier", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The least quadratic nonresidue, and the square root barrier")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 August 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/")[#text("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A large portion of analytic number theory is concerned with the distribution of number-theoretic sets such as the primes, or ")#link("http://en.wikipedia.org/wiki/Quadratic_residue")[#text("quadratic residues")]#text(" in a certain modulus. At a local level (e.g. on a short interval ")#mi("{[x,x+y]}")#text("), the behaviour of these sets may be quite irregular. However, in many cases one can understand the ")#emph[#text("global")]#text(" behaviour of such sets on very large intervals, (e.g. ")#mi("{[1,x]}")#text("), with reasonable accuracy (particularly if one assumes powerful additional conjectures, such as the Riemann hypothesis and its generalisations). For instance, in the case of the primes, we have the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(", which asserts that the number of primes in a large interval ")#mi("{[1,x]}")#text(" is asymptotically equal to ")#mi("{x/\\log x}")#text("; in the case of quadratic residues modulo a prime ")#mi("{p}")#text(", it is clear that there are exactly ")#mi("{(p-1)/2}")#text(" such residues in ")#mi("{[1,p]}")#text(". With elementary arguments, one can also count statistics such as the number of pairs of consecutive quadratic residues; and with the aid of deeper tools such as the Weil sum estimates, one can count more complex patterns in these residues also (e.g. ")#mi("{k}")#text("-point correlations).")

#text("One is often interested in converting this sort of “global” information on long intervals into “local” information on short intervals. If one is interested in the behaviour on a ")#emph[#text("generic")]#text(" or ")#emph[#text("average")]#text(" short interval, then the question is still essentially a global one, basically because one can view a long interval as an average of a long sequence of short intervals. (This does not mean that the problem is automatically easy, because not every global statistic about, say, the primes is understood. For instance, we do not know how to rigorously establish the conjectured asymptotic for the number of ")#link("http://en.wikipedia.org/wiki/Twin_prime")[#text("twin primes")]#text(" ")#mi("{n,n+2}")#text(" in a long interval ")#mi("{[1,N]}")#text(", and so we do not fully understand the local distribution of the primes in a typical short interval ")#mi("{[n,n+2]}")#text(".)")

#text("However, suppose that instead of understanding the ")#emph[#text("average-case")]#text(" behaviour of short intervals, one wants to control the ")#emph[#text("worst-case")]#text(" behaviour of such intervals (i.e. to establish bounds that hold for ")#emph[#text("all")]#text(" short intervals, rather than ")#emph[#text("most")]#text(" short intervals). Then it becomes substantially harder to convert global information to local information. In many cases one encounters a “square root barrier”, in which global information at scale ")#mi("{x}")#text(" (e.g. statistics on ")#mi("{[1,x]}")#text(") cannot be used to say anything non-trivial about a fixed (and possibly worst-case) short interval at scales ")#mi("{x^{1/2}}")#text(" or below. (Here we ignore factors of ")#mi("{\\log x}")#text(" for simplicity.) The basic reason for this is that even randomly distributed sets in ")#mi("{[1,x]}")#text(" (which are basically the most uniform type of global distribution one could hope for) exhibit random fluctuations of size ")#mi("{x^{1/2}}")#text(" or so in their global statistics (as can be seen for instance from the ")#link("http://en.wikipedia.org/wiki/Central_limit_theorem")[#text("central limit theorem")]#text("). Because of this, one could take a random (or pseudorandom) subset of ")#mi("{[1,x]}")#text(" and delete all the elements in a short interval of length ")#mi("{o(x^{1/2})}")#text(", without anything suspicious showing up on the global statistics level; the edited set still has essentially the same global statistics as the original set. On the other hand, the worst-case behaviour of this set on a short interval has been drastically altered.")

#text("One stark example of this arises when trying to control the largest gap between consecutive prime numbers in a large interval ")#mi("{[x,2x]}")#text(". There are convincing heuristics that suggest that this largest gap is of size ")#mi("{O( \\log^2 x )}")#text(" (")#link("http://en.wikipedia.org/wiki/Cram%C3%A9r%27s_conjecture")[#text("Cramér’s conjecture")]#text("). But even assuming the Riemann hypothesis, the best upper bound on this gap is only of size ")#mi("{O( x^{1/2} \\log x )}")#text(", basically because of this square root barrier. This particular instance of the square root barrier is a significant obstruction to the current polymath project “")#link("http://michaelnielsen.org/polymath1/index.php?title=Finding_primes")[#text("Finding primes")]#text("“.")

#text("On the other hand, in some cases one can use additional tricks to get past the square root barrier. The key point is that many number-theoretic sequences have special structure that distinguish them from being exactly like random sets. For instance, quadratic residues have the basic but fundamental property that the product of two quadratic residues is again a quadratic residue. One way to use this sort of structure to ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("amplify")]#text(" bad behaviour in a single short interval into bad behaviour across many short intervals. Because of this amplification, one can sometimes get new worst-case bounds by tapping the average-case bounds.")

#text("In this post I would like to indicate a classical example of this type of amplification trick, namely Burgess’s bound on short character sums. To narrow the discussion, I would like to focus primarily on the following classical problem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 1")]#text(" What are the best bounds one can place on the first quadratic non-residue ")#mi("{n_p}")#text(" in the interval ")#mi("{[1,p-1]}")#text(" for a large prime ")#mi("{p}")#text("?")
]

#text("(The first quadratic residue is, of course, ")#mi("{1}")#text("; the more interesting problem is the first quadratic non-residue.)")

#text("Probabilistic heuristics (presuming that each non-square integer has a 50-50 chance of being a quadratic residue) suggests that ")#mi("{n_p}")#text(" should have size ")#mi("{O( \\log p )}")#text(", and indeed Vinogradov conjectured that ")#mi("{n_p = O_\\varepsilon(p^\\varepsilon)}")#text(" for any ")#mi("{\\varepsilon > 0}")#text(". Using the ")#link("http://en.wikipedia.org/wiki/Character_sum")[#text("Pólya-Vinogradov inequality")]#text(", one can get the bound ")#mi("{n_p = O( \\sqrt{p} \\log p )}")#text(" (and can improve it to ")#mi("{n_p = O(\\sqrt{p})}")#text(" using ")#link("http://www.tricki.org/article/Smoothing_sums")[#text("smoothed sums")]#text("); combining this with a sieve theory argument (exploiting the multiplicative nature of quadratic residues) one can boost this to ")#mi("{n_p = O( p^{\\frac{1}{2\\sqrt{e}}} \\log^2 p )}")#text(". Inserting Burgess’s amplification trick one can boost this to ")#mi("{n_p = O_\\varepsilon( p^{\\frac{1}{4\\sqrt{e}}+\\varepsilon} )}")#text(" for any ")#mi("{\\varepsilon > 0}")#text(". Apart from refinements to the ")#mi("{\\varepsilon}")#text(" factor, this bound has stood for five decades as the “world record” for this problem, which is a testament to the difficulty in breaching the square root barrier.")

#text("Note: in order not to obscure the presentation with technical details, I will be using asymptotic notation ")#mi("{O()}")#text(" in a somewhat informal manner.")

#metadata(none) <tao-736650f53a54375af222>

#heading(level: 1)[#strong[#text(" — 1. Character sums — ")]]

#text("To approach the problem, we begin by fixing the large prime ")#mi("{p}")#text(" and introducing the ")#link("http://en.wikipedia.org/wiki/Legendre_symbol")[#text("Legendre symbol")]#text(" ")#mi("{\\chi(n) = \\left(\\tfrac{n}{p}\\right)}")#text(", defined to equal ")#mi("{0}")#text(" when ")#mi("{n}")#text(" is divisible by ")#mi("{p}")#text(", ")#mi("{+1}")#text(" when ")#mi("{n}")#text(" is an invertible quadratic residue modulo ")#mi("{p}")#text(", and ")#mi("{-1}")#text(" when ")#mi("{n}")#text(" is an invertible quadratic non-residue modulo ")#mi("{p}")#text(". Thus, for instance, ")#mi("{\\chi(n) = +1}")#text(" for all ")#mi("{1 \\leq n < n_p}")#text(". One of the main reasons one wants to work with the function ")#mi("{\\chi}")#text(" is that it enjoys two easily verified properties:")

#list(
[#mi("{\\chi}")#text(" is periodic with period ")#mi("{p}")#text(".")],
[#text("One has the total multiplicativity property ")#mi("{\\chi(nm) = \\chi(n) \\chi(m)}")#text(" for all integers ")#mi("{n,m}")#text(".")]
)

#text("In the jargon of number theory, ")#mi("{\\chi}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Dirichlet_character")[#text("Dirichlet character")]#text(" with conductor ")#mi("{p}")#text(". Another important property of this character is of course the law of ")#link("http://en.wikipedia.org/wiki/Quadratic_reciprocity")[#text("quadratic reciprocity")]#text(", but this law is more important for the ")#emph[#text("average-case")]#text(" behaviour in ")#mi("{p}")#text(", whereas we are concerned here with the ")#emph[#text("worst-case")]#text(" behaviour in ")#mi("{p}")#text(", and so we will not actually use this law here.")

#text("An obvious way to control ")#mi("{n_p}")#text(" is via the character sum ")#metadata(none) <tao-93db5a7927bddc193e91>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{1 \\leq n \\leq x} \\chi(n).")]]

#text("From the triangle inequality, we see that this sum has magnitude at most ")#mi("{x}")#text(". If we can then obtain a non-trivial bound of the form ")#metadata(none) <tao-a871c47a7f48a12b38a9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{1 \\leq n \\leq x} \\chi(n) = o(x)")]]

#text("for some ")#mi("{x}")#text(", this forces the existence of a quadratic nonresidue less than or equal to ")#mi("{x}")#text(", thus ")#mi("{n_p \\leq x}")#text(". So one approach to the problem is to bound the character sum ")#link(<tao-93db5a7927bddc193e91>)[#text("(1)")]#text(".")

#text("As there are just as many residues as non-residues, the sum ")#link(<tao-93db5a7927bddc193e91>)[#text("(1)")]#text(" is periodic with period ")#mi("{p}")#text(" and we obtain a trivial bound of ")#mi("{p}")#text(" for the magnitude of the sum. One can achieve a non-trivial bound by Fourier analysis. One can expand")

#align(center)[#tao-fit-display[#mitex("\\chi(n) = \\sum_{a=0}^{p-1} \\hat \\chi(a) e^{2\\pi i a n / p }")]]

#text("where ")#mi("{\\hat \\chi(a)}")#text(" are the Fourier coefficients of ")#mi("{\\chi}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\hat \\chi(a) := \\frac{1}{p} \\sum_{n=0}^{p-1} \\chi(n) e^{-2\\pi i an/p}.")]]

#text("As there are just as many quadratic residues as non-residues, ")#mi("{\\hat \\chi(0)=0}")#text(", so we may drop the ")#mi("{a=0}")#text(" term. From summing the geometric series we see that ")#metadata(none) <tao-a3f5b99599699164ad53>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\sum_{1 \\leq n \\leq x} e^{2\\pi i an/p} = O( 1 / \\left\\| a/p \\right\\| ),", block: true)]]

#text("where ")#tao-math("{\\left\\|a/p\\right\\|}", block: false)#text(" is the distance from ")#mi("{a/p}")#text(" to the nearest integer (")#mi("{0}")#text(" or ")#mi("{1}")#text("); inserting these bounds into ")#link(<tao-93db5a7927bddc193e91>)[#text("(1)")]#text(" and summing what is essentially a harmonic series in ")#mi("{a}")#text(" we obtain")

#align(center)[#tao-fit-display[#tao-math("\\sum_{1 \\leq n \\leq x} \\chi(n) = O( p \\log p \\sup_{a \\neq 0} \\left|\\hat \\chi(a)\\right| ).", block: true)]]

#text("Now, how big is ")#mi("{\\hat \\chi(a)}")#text("? Taking absolute values, we get a bound of ")#mi("{1}")#text(", but this gives us something worse than the trivial bound. To do better, we use the Plancherel identity")

#align(center)[#tao-fit-display[#tao-math("\\sum_{a=0}^{p-1} \\left|\\hat \\chi(a)\\right|^2 = \\frac{1}{p} \\sum_{n=0}^{p-1} \\left|\\chi(n)\\right|^2", block: true)]]

#text("which tells us that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{a=0}^{p-1} \\left|\\hat \\chi(a)\\right|^2 = O(1).", block: true)]]

#text("This tells us that ")#mi("{\\hat \\chi}")#text(" is small ")#emph[#text("on the average")]#text(", but does not immediately tell us anything new about the ")#emph[#text("worst-case")]#text(" behaviour of ")#mi("{\\chi}")#text(", which is what we need here. But now we use the multiplicative structure of ")#mi("{\\chi}")#text(" to relate average-case and worst-case behaviour. Note that if ")#mi("{b}")#text(" is coprime to ")#mi("{p}")#text(", then ")#mi("{\\chi(bn)}")#text(" is a scalar multiple of ")#mi("{\\chi(n)}")#text(" by a quantity ")#mi("{\\chi(b)}")#text(" of magnitude ")#mi("{1}")#text("; taking Fourier transforms, this implies that ")#mi("{\\hat \\chi(a/b)}")#text(" and ")#mi("{\\hat \\chi(a)}")#text(" also differ by this factor. In particular, ")#tao-math("{\\left|\\hat \\chi(a/b)\\right|=\\left|\\hat \\chi(a)\\right|}", block: false)#text(". As ")#mi("{b}")#text(" was arbitrary, we thus see that ")#tao-math("{\\left|\\hat \\chi(a)\\right|}", block: false)#text(" is constant for all ")#mi("{a}")#text(" coprime to ")#mi("{p}")#text("; in other words, the worst case is the ")#emph[#text("same")]#text(" as the average case. Combining this with the Plancherel bound one obtains ")#tao-math("{\\left|\\hat \\chi(a)\\right| = O(1/\\sqrt{p})}", block: false)#text(", leading to the ")#emph[#text("Pólya-Vinogradov inequality")]

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq n \\leq x} \\chi(n) = O( \\sqrt{p} \\log p ).")]]

#text("(In fact, a more careful computation reveals the slightly sharper bound ")#tao-math("{\\left|\\sum_{1 \\leq n \\leq x} \\chi(n)\\right| \\leq \\sqrt{p} \\log p}", block: false)#text("; this is non-trivial for ")#mi("{x > \\sqrt{p} \\log p}")#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Up to logarithmic factors, this is consistent with what one would expect if ")#mi("{\\chi}")#text(" fluctuated like a random sign pattern (at least for ")#mi("{x}")#text(" comparable to ")#mi("{p}")#text("; for smaller values of ")#mi("{x}")#text(", one expects instead a bound of the form ")#mi("{O(\\sqrt{x})}")#text(", up to logarithmic factors). It is conjectured that the ")#mi("{\\log p}")#text(" factor can be replaced with a ")#mi("{O(\\log \\log p)}")#text(" factor, which would be consistent with the random fluctuation model and is best possible; this is known for GRH, but unconditionally the Pólya-Vinogradov inequality is still the best known. (See however ")#link("http://arxiv.org/abs/math/0503113")[#text("this paper of Granville and Soundararajan")]#text(" for an improvement for non-quadratic characters ")#mi("{\\chi}")#text(".)")
]

#text("A direct application of the Pólya-Vinogradov inequality gives the bound ")#mi("{n_p \\leq \\sqrt{p} \\log p}")#text(". One can get rid of the logarithmic factor (which comes from the harmonic series arising from ")#link(<tao-a3f5b99599699164ad53>)[#text("(3)")]#text(") by replacing the sharp cutoff ")#mi("{1_{1 \\leq n \\leq x}}")#text(" by a ")#link("http://www.tricki.org/article/Smoothing_sums")[#text("smoother sum")]#text(", which has a better behaved Fourier transform. But one can do better still by exploiting the multiplicativity of ")#mi("{\\chi}")#text(" again, by the following trick of Vinogradov. Observe that not only does one have ")#mi("{\\chi(n)=+1}")#text(" for all ")#mi("{n \\leq n_p}")#text(", but also ")#mi("{\\chi(n) = +1}")#text(" for any ")#mi("{n}")#text(" which is ")#mi("{n_p-1}")#text("-smooth, i.e. is the product of integers less than ")#mi("{n_p}")#text(". So even if ")#mi("{n_p}")#text(" is significantly less than ")#mi("{x}")#text(", one can show that the sum ")#link(<tao-93db5a7927bddc193e91>)[#text("(1)")]#text(" is large if the majority of integers less than ")#mi("{x}")#text(" are ")#mi("{n_p-1}")#text("-smooth.")

#text("Since every integer ")#mi("{n}")#text(" less than ")#mi("{x}")#text(" is either ")#mi("{n_p}")#text("-smooth (in which case ")#mi("{\\chi(n)=+1}")#text("), or divisible by a prime ")#mi("{q}")#text(" between ")#mi("{n_p}")#text(" and ")#mi("{x}")#text(" (in which case ")#mi("{\\chi(n)}")#text(" is at least ")#mi("{-1}")#text("), we obtain the lower bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq n \\leq x} \\chi(n) \\geq \\sum_{1 \\leq n \\leq x} 1 - \\sum_{n_p < q \\leq x} \\sum_{1 \\leq n \\leq x: q|n} 2.")]]

#text("Clearly, ")#mi("{\\sum_{1 \\leq n \\leq x} 1 = x+O(1)}")#text(" and ")#mi("{\\sum_{1 \\leq n \\leq x: q|n} 2 = 2\\frac{x}{q} + O(1)}")#text(". The total number of primes less than ")#mi("{x}")#text(" is ")#mi("{O(\\frac{x}{\\log x}) = o(x)}")#text(" by the prime number theorem, thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq n \\leq x} \\chi(n) \\geq x - \\sum_{n_p < q \\leq x} 2\\frac{x}{q} + o(x).")]]

#text("Using the classical asymptotic ")#mi("{\\sum_{q \\leq y} \\frac{1}{q} = \\log \\log y + C + o(1)}")#text(" for some absolute constant ")#mi("{C}")#text(" (which basically follows from the prime number theorem, but also has an elementary proof), we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq n \\leq x} \\chi(n) \\geq x [1 - 2 \\log \\frac{\\log x}{\\log n_p} + o(1)].")]]

#text("If ")#mi("{n_p \\geq x^{\\frac{1}{\\sqrt{e}}+\\varepsilon}}")#text(" for some fixed ")#mi("{\\varepsilon > 0}")#text(", then the expression in brackets is bounded away from zero for ")#mi("{x}")#text(" large; in particular, this is incompatible with ")#link(<tao-a871c47a7f48a12b38a9>)[#text("(2)")]#text(" for ")#mi("{x}")#text(" large enough. As a consequence, we see that if we have a bound of the form ")#link(<tao-a871c47a7f48a12b38a9>)[#text("(2)")]#text(", then we can conclude ")#mi("{n_p = O_\\varepsilon( x^{\\frac{1}{\\sqrt{e}} + \\varepsilon} )}")#text(" for all ")#mi("{\\varepsilon > 0}")#text("; in particular, from the Pólya-Vinogradov inequality one has")

#align(center)[#tao-fit-display[#mitex("n_p = O_\\varepsilon( p^{\\frac{1}{2\\sqrt{e}} + \\varepsilon} )")]]

#text("for all ")#mi("{\\varepsilon > 0}")#text(", or equivalently that ")#mi("{n_p \\leq p^{\\frac{1}{2\\sqrt{e}} + o(1)}}")#text(". (By being a bit more careful, one can refine this to ")#mi("{n_p = O( p^{\\frac{1}{2\\sqrt{e}}} \\log^{2/\\sqrt{e}} p )}")#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The estimates on the Gauss-type sums ")#mi("{ \\hat \\chi(a) := \\frac{1}{p} \\sum_{n=0}^{p-1} \\chi(n) e^{-2\\pi i an/p}}")#text(" are sharp; nevertheless, they fail to penetrate the square root barrier in the sense that no non-trivial estimates are provided below the scale ")#mi("{\\sqrt{p}}")#text(". One can also see this barrier using the ")#link("http://en.wikipedia.org/wiki/Poisson_summation_formula")[#text("Poisson summation formula")]#text(", which basically gives a formula that (very roughly) takes the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{n = O(x)} \\chi(n) \\sim \\frac{x}{\\sqrt{p}} \\sum_{n=O(p/x)} \\chi(n)")]]

#text("for any ")#mi("{1 < x < p}")#text(", and is basically the limit of what one can say about character sums using Fourier analysis alone. In particular, we see that the Pólya-Vinogradov bound is basically the Poisson dual of the trivial bound. The scale ")#mi("{x=\\sqrt{p}}")#text(" is the crossing point where Poisson summation does not achieve any non-trivial modification of the scale parameter.")
]

#heading(level: 1)[#strong[#text(" — 2. Average-case bounds — ")]]

#text("The Pólya-Vinogradov bound establishes a non-trivial estimate ")#link(<tao-93db5a7927bddc193e91>)[#text("(1)")]#text(" for ")#mi("{x}")#text(" significantly larger than ")#mi("{\\sqrt{p} \\log p}")#text(". We are interested in extending ")#link(<tao-93db5a7927bddc193e91>)[#text("(1)")]#text(" to shorter intervals.")

#text("Before we address this issue for a fixed interval ")#mi("{[1,x]}")#text(", we first study the ")#emph[#text("average-case")]#text(" bound on short character sums. Fix a short length ")#mi("{y}")#text(", and consider the shifted sum ")#metadata(none) <tao-ecd3fad7a4d35d7130c6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{a \\leq n \\leq a+y} \\chi(n),")]]

#text("where ")#mi("{a}")#text(" is a parameter. The analogue of ")#link(<tao-93db5a7927bddc193e91>)[#text("(1)")]#text(" for such intervals would be ")#metadata(none) <tao-411b0496da5eeced5314>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_{a \\leq n \\leq a+y} \\chi(n) = o(y).")]]

#text("For ")#mi("{y}")#text(" very small (e.g. ")#mi("{y=p^\\varepsilon}")#text(" for some small ")#mi("{\\epsilon > 0}")#text("), we do not know how to establish ")#link(<tao-411b0496da5eeced5314>)[#text("(5)")]#text(" for ")#emph[#text("all")]#text(" ")#mi("{a}")#text("; but we can at least establish ")#link(<tao-411b0496da5eeced5314>)[#text("(5)")]#text(" for ")#emph[#text("almost all")]#text(" ")#mi("{a}")#text(", with only about ")#mi("{O(\\sqrt{p})}")#text(" exceptions (here we see the square root barrier again!).")

#text("More precisely, we will establish the moment estimates ")#metadata(none) <tao-bcb9dae6ea88dbf28c26>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\frac{1}{p} \\sum_{a=0}^{p-1} \\left|\\sum_{a \\leq n \\leq a+y} \\chi(n)\\right|^k = O_k( y^{k/2} + y^k p^{-1/2} )", block: true)]]

#text("for any positive even integer ")#mi("{k=2,4,\\ldots}")#text(". If ")#mi("{y}")#text(" is not too tiny, say ")#mi("{y \\geq p^{\\varepsilon}}")#text(" for some ")#mi("{\\varepsilon > 0}")#text(", then by applying ")#link(<tao-bcb9dae6ea88dbf28c26>)[#text("(6)")]#text(" for a sufficiently large ")#mi("{k}")#text(" and using Chebyshev’s inequality (or Markov’s inequality), we see (for any given ")#mi("{\\delta > 0}")#text(") that one has the non-trivial bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{a \\leq n \\leq a+y} \\chi(n)\\right| \\leq \\delta y", block: true)]]

#text("for all but at most ")#mi("{O_{\\delta,\\epsilon}(\\sqrt{p})}")#text(" values of ")#mi("{a \\in [1,p]}")#text(".")

#text("To see why ")#link(<tao-bcb9dae6ea88dbf28c26>)[#text("(6)")]#text(" is true, let us just consider the easiest case ")#mi("{k=2}")#text(". Squaring both sides, we expand ")#link(<tao-bcb9dae6ea88dbf28c26>)[#text("(6)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{p} \\sum_{a=0}^{p-1} \\sum_{a \\leq n,m \\leq a+y} \\chi(n) \\chi(m) = O(y) + O(y^2 p^{-1/2} ).")]]

#text("We can write ")#mi("{\\chi(n) \\chi(m)}")#text(" as ")#mi("{\\chi(n m)}")#text(". Writing ")#mi("{m=n+h}")#text(", and using the periodicity of ")#mi("{\\chi}")#text(", we can rewrite the left-hand side as")

#align(center)[#tao-fit-display[#tao-math("\\sum_{h=-y}^y (y-\\left|h\\right|) [\\frac{1}{p} \\sum_{n \\in F_p} \\chi(n(n+h))]", block: true)]]

#text("where we have abused notation and identified the finite field ")#mi("{F_p}")#text(" with ")#mi("{\\{0,1,\\ldots,p-1\\}}")#text(".")

#text("For ")#mi("{h=0}")#text(", the inner average is ")#mi("{O(1)}")#text(". For ")#mi("{h}")#text(" non-zero, we claim the bound ")#metadata(none) <tao-6d587918cc9410a3f4ee>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\sum_{n \\in F_p} \\chi(n(n+h))= O( \\sqrt{p} )")]]

#text("which is consistent with (and is in fact slightly stronger than) what one would get if ")#mi("{\\chi}")#text(" was a random sign pattern; assuming this bound gives ")#link(<tao-bcb9dae6ea88dbf28c26>)[#text("(6)")]#text(" for ")#mi("{k=2}")#text(" as required.")

#text("The bound ")#link(<tao-6d587918cc9410a3f4ee>)[#text("(7)")]#text(" can be established by quite elementary means (as it comes down to counting points on the hyperbola ")#mi("{y^2=x(x+h)}")#text(", which can be done by transforming the hyperbola to be rectangular), but for larger values of ")#mi("{k}")#text(" we will need the more general estimate ")#metadata(none) <tao-15d0b5ec64c82678556e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\sum_{n \\in F_p} \\chi(P(n))= O_k( \\sqrt{p} )")]]

#text("whenever ")#mi("{P}")#text(" is a polynomial over ")#mi("{F}")#text(" of degree ")#mi("{k}")#text(" which is not a constant multiple of a perfect square; this can be easily seen to give ")#link(<tao-bcb9dae6ea88dbf28c26>)[#text("(6)")]#text(" for general ")#mi("{k}")#text(".")

#text("An equivalent form of ")#link(<tao-15d0b5ec64c82678556e>)[#text("(8)")]#text(" is that the ")#link("http://en.wikipedia.org/wiki/Hyperelliptic_curve")[#text("hyperelliptic curve")]#text(" ")#metadata(none) <tao-34f3c623bcf02d60fd02>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\{ (x,y) \\in F_p \\times F_p: y^2 = P(x) \\}")]]

#text("contains ")#mi("{p + O_k(\\sqrt{p})}")#text(" points. This fact follows from a general theorem of Weil establishing the Riemann hypothesis for curves over function fields, but can also be deduced by a more elementary ")#link("http://www.ams.org/mathscinet-getitem?mr=252400")[#text("argument of Stepanov")]#text(", using the polynomial method, which we now give here. (This arrangement of the argument is based on the exposition in the ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("book by Iwaniec and Kowalski")]#text(".)")

#text("By translating the ")#mi("{x}")#text(" variable we may assume that ")#mi("{P(0)}")#text(" is non-zero. The key lemma is the following. Assume ")#mi("{p}")#text(" large, and take ")#mi("{l}")#text(" to be an integer comparable to ")#mi("{\\sqrt{p}}")#text(" (other values of this parameter are possible, but this is the optimal choice). All polynomials ")#mi("{Q(x)}")#text(" are understood to be over the field ")#mi("{F_p}")#text(" (i.e. they lie in the polynomial ring ")#mi("{F_p[X]}")#text("), although indeterminate variables ")#mi("{x}")#text(" need not lie in this field.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" There exists a non-zero polynomial ")#mi("{Q(x)}")#text(" of one indeterminate variable ")#mi("{x}")#text(" over ")#mi("{F_p}")#text(" of degree at most ")#mi("{lp/2 + O_k(p)}")#text(" which vanishes to order at least ")#mi("{l}")#text(" at every point ")#mi("{x \\in F_p}")#text(" for which ")#mi("{P(x)}")#text(" is a quadratic residue.")
]

#text("Note from the factor theorem that ")#mi("{Q}")#text(" can vanish to order at least ")#mi("{l}")#text(" at at most ")#mi("{\\text{deg}(Q)/l \\leq p/2 + O_k(\\sqrt{p})}")#text(" points, and so we see that ")#mi("{P(x)}")#text(" is an invertible quadratic residue for at most ")#mi("{p/2 + O_k(\\sqrt{p})}")#text(" values of ")#mi("{F_p}")#text(". Multiplying ")#mi("{P}")#text(" by a quadratic non-residue and running the same argument, we also see that ")#mi("{P(x)}")#text(" is an invertible quadratic non-residue for at most ")#mi("{p/2 + O_k(\\sqrt{p})}")#text(" values of ")#mi("{F_p}")#text(", and ")#link(<tao-15d0b5ec64c82678556e>)[#text("(8)")]#text(" (or the asymptotic for the number of points in ")#link(<tao-34f3c623bcf02d60fd02>)[#text("(9)")]#text(") follows.")

#text("We now prove the lemma. The polynomial ")#mi("{Q}")#text(" will be chosen to be of the form")

#align(center)[#tao-fit-display[#mitex("Q(x) = P^l(x) ( R(x,x^p) + P^{\\frac{p-1}{2}}(x) S(x,x^p) )")]]

#text("where ")#mi("{R(x,z), S(x,z)}")#text(" are polynomials of degree at most ")#mi("{\\frac{p-k-1}{2}}")#text(" in ")#mi("{x}")#text(", and degree at most ")#mi("{\\frac{l}{2} + C}")#text(" in ")#mi("{z}")#text(", where ")#mi("{C}")#text(" is a large constant (depending on ")#mi("{k}")#text(") to be chosen later (these parameters have been optimised for the argument that follows). Since ")#mi("{P}")#text(" has degree at most ")#mi("{k}")#text(", such a ")#mi("{Q}")#text(" will have degree")

#align(center)[#tao-fit-display[#mitex("\\leq kl + \\frac{p-k-1}{2} + \\frac{p-1}{2} k + p (\\frac{l}{2}+C^{\\prime}) = \\frac{lp}{2} + O_k(p)")]]

#text("as required. We claim (for suitable choices of ")#mi("{C,C^{\\prime}}")#text(") that")

#list(
[#text("(a) The degrees are small enough that ")#mi("{Q(x)}")#text(" is a non-zero polynomial whenever ")#mi("{R(x,z), S(x,z)}")#text(" are non-zero polynomials; and")],
[#text("(b) The degrees are large enough that there exists a non-trivial choice of ")#mi("{R(x,z)}")#text(" and ")#mi("{S(x,z)}")#text(" that ")#mi("{Q(x)}")#text(" vanishes to order at least ")#mi("{l}")#text(" whenever ")#mi("{x \\in F_p}")#text(" is such that ")#mi("{P(x)}")#text(" is a quadratic residue.")]
)

#text("Claims (a) and (b) together establish the lemma.")

#text("We first verify (a). We can cancel off the initial ")#mi("{P^l}")#text(" factor, so that we need to show that ")#mi("{R(x,x^p) + P^{\\frac{p-1}{2}}(x) S(x,x^p)}")#text(" does not vanish when at least one of ")#mi("{R(x,z), Q(x,z)}")#text(" is not vanishing. We may assume that ")#mi("{R, Q}")#text(" are not both divisible by ")#mi("{z}")#text(", since we could cancel out a common factor of ")#mi("{x^p}")#text(" otherwise.")

#text("Suppose for contradiction that the polynomial ")#mi("{R(x,x^p) + P^{\\frac{p-1}{2}} S(x,x^p)}")#text(" vanished, which implies that ")#mi("{R(x,0) = - P^{\\frac{p-1}{2}}(x) S(x,0)}")#text(" modulo ")#mi("{x^p}")#text(". Squaring and multiplying by ")#mi("{P}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("R(x,0)^2 P(x) = P(x)^p S(x,0)^2 \\text{ mod } x^p.")]]

#text("But over ")#mi("{F_p}")#text(" and modulo ")#mi("{x^p}")#text(", ")#mi("{P(x)^p = P(0)}")#text(" by Fermat’s little theorem. Observe that ")#mi("{R(x,0)^2 P(x)}")#text(" and ")#mi("{P(0) S(x,0)^2}")#text(" both have degree at most ")#mi("{p-1}")#text(", and so we can remove the ")#mi("{x^p}")#text(" modulus and conclude that ")#mi("{R(x,0)^2 P(x) = P(0) S(x,0)^2}")#text(" over ")#mi("{F_p}")#text(". But this implies (by the fundamental theorem of arithmetic for ")#mi("{F_p[X]}")#text(") that ")#mi("{P}")#text(" is a constant multiple of a square, a contradiction. (Recall that ")#mi("{P(0)}")#text(" is non-zero, and that ")#mi("{R(x,0)}")#text(" and ")#mi("{S(x,0)}")#text(" are not both zero.)")

#text("Now we prove (b). Let ")#mi("{x \\in F_p}")#text(" be such that ")#mi("{P(x)}")#text(" is a quadratic residue, thus ")#mi("{P(x)^{\\frac{p-1}{2}} = +1}")#text(" by Fermat’s little theorem. To get vanishing to order ")#mi("{l}")#text(", we need ")#metadata(none) <tao-71de3c9e182d88696c82>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\frac{d^j}{dx^j} [ P^l(x) ( R(x,x^p) + P^{\\frac{p-1}{2}}(x) S(x,x^p) ) ] = 0")]]

#text("for all ")#mi("{0 \\leq j < l}")#text(". (Of course, we cannot define derivatives using limits and Newton quotients in this finite characteristic setting, but we can still define derivatives of polynomials formally, thus for instance ")#mi("{\\frac{d}{dx} x^n := n x^{n-1}}")#text(", and enjoy all the usual rules of calculus, such as the product rule and chain rule.)")

#text("Over ")#mi("{F_p}")#text(", the polynomial ")#mi("{x^p}")#text(" has derivative zero. If we then compute the derivative in ")#link(<tao-71de3c9e182d88696c82>)[#text("(10)")]#text(" using many applications of the product and chain rule, we see that the left-hand side of ")#link(<tao-71de3c9e182d88696c82>)[#text("(10)")]#text(" can be expressed in the form")

#align(center)[#tao-fit-display[#mitex("P^{l-j}(x) [ R_j(x,x^p) + P^{\\frac{p-1}{2}}(x) S_j(x,x^p) ) ]")]]

#text("where ")#mi("{R_j(x,z), S_j(x,z)}")#text(" are polynomials of degree at most ")#mi("{\\frac{p-k-1}{2} + O_k(j)}")#text(" in ")#mi("{x}")#text(" and at most ")#mi("{\\frac{l}{2}+C}")#text(" in ")#mi("{z}")#text(", whose coefficients depend in some linear fashion on the coefficients of ")#mi("{R}")#text(" and ")#mi("{S}")#text(". (The exact nature of this linear relationship will depend on ")#mi("{k, p, P}")#text(", but this will not concern us.) Since we only need to evaluate this expression when ")#mi("{P(x)^{\\frac{p-1}{2}} = +1}")#text(" and ")#mi("{x^p=x}")#text(" (by Fermat’s little theorem), we thus see that we can verify ")#link(<tao-71de3c9e182d88696c82>)[#text("(10)")]#text(" provided that the polynomial")

#align(center)[#tao-fit-display[#mitex("P^{l-j}(x) [ R_j(x,x) + S_j(x,x) ) ]")]]

#text("vanishes identically. This is a polynomial of degree at most")

#align(center)[#tao-fit-display[#mitex("O(l-j) + \\frac{p-k-1}{2} + O_k(j) + \\frac{l}{2}+C = \\frac{p}{2} + O_k(p^{1/2}) + C,")]]

#text("and there are ")#mi("{l+1}")#text(" possible values of ")#mi("{j}")#text(", so this leads to")

#align(center)[#tao-fit-display[#mitex("\\frac{lp}{2} + O_k(p) + O( C \\sqrt{p} )")]]

#text("linear constraints on the coefficients of ")#mi("{R}")#text(" and ")#mi("{S}")#text(" to satisfy. On the other hand, the total number of these coefficients is")

#align(center)[#tao-fit-display[#mitex("2 \\times (\\frac{p-k-1}{2} + O(1)) \\times (\\frac{l}{2}+C + O(1)) = \\frac{lp}{2} + Cp + O_k(p).")]]

#text("For ")#mi("{C}")#text(" large enough, there are more coefficients than constraints, and so one can find a non-trivial choice of coefficients obeying the constraints ")#link(<tao-71de3c9e182d88696c82>)[#text("(10)")]#text(", and (b) follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" If one optimises all the constants here, one gets an upper bound of basically ")#mi("{8k \\sqrt{p}}")#text(" for the deviation in the number of points in ")#link(<tao-34f3c623bcf02d60fd02>)[#text("(9)")]#text(". This is only a little worse than the sharp bound of ")#mi("{2g\\sqrt{p}}")#text(" given from Weil’s theorem, where ")#mi("{g = \\lfloor \\frac{k-1}{2}\\rfloor}")#text(" is the genus; however, it is possible to boost the former bound to the latter by using a version of the ")#link("http://www.tricki.org/article/The_tensor_power_trick")[#text("tensor power trick")]#text(" (generalising ")#mi("{F_p}")#text(" to ")#mi("{F_{p^m}}")#text(" and then letting ")#mi("{m \\rightarrow \\infty}")#text(") combined with the theory of ")#link("http://en.wikipedia.org/wiki/Artin_L-function")[#text("Artin L-functions")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Hyperelliptic_curve")[#text("Riemann-Roch theorem")]#text(". This is (very briefly!) sketched in the ")#link("http://www.tricki.org/article/The_tensor_power_trick")[#text("Tricki article on the tensor power trick")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" Once again, the global estimate ")#link(<tao-15d0b5ec64c82678556e>)[#text("(8)")]#text(" is very sharp, but cannot penetrate below the square root barrier, in that one is allowed to have about ")#mi("{O(\\sqrt{p})}")#text(" exceptional values of ")#mi("{a}")#text(" for which no cancellation exists. One expects that these exceptional values of ")#mi("{a}")#text(" in fact do not exist, but we do not know how to do this unless ")#mi("{y}")#text(" is larger than ")#mi("{x^{1/4}}")#text(" (so that the Burgess bounds apply).")
]

#heading(level: 1)[#strong[#text(" — 3. The Burgess bound — ")]]

#text("The average case bounds in the previous section give an alternate demonstration of a non-trivial estimate ")#link(<tao-93db5a7927bddc193e91>)[#text("(1)")]#text(" for ")#mi("{x > p^{1/2+\\varepsilon}}")#text(", which is just a bit weaker than what the Pólya-Vinogradov inequality gives. Indeed, if ")#link(<tao-93db5a7927bddc193e91>)[#text("(1)")]#text(" failed for such an ")#mi("{x}")#text(", thus")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\in [1,x]} \\chi(n)\\right| \\gg x,", block: true)]]

#text("then by taking a small ")#mi("{y}")#text(" (e.g. ")#mi("{y = p^{\\varepsilon/2}}")#text(") and covering ")#mi("{[1,x]}")#text(" by intervals of length ")#mi("{y}")#text(", we see (from a first moment method argument) that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{a \\leq n \\leq a+y} \\chi(n)\\right| \\gg y", block: true)]]

#text("for a positive fraction of the ")#mi("{a}")#text(" in ")#mi("{[1,x]}")#text(". But this contradicts the results of the previous section.")

#text("Burgess observed that by exploiting the multiplicativity of ")#mi("{\\chi}")#text(" one last time to amplify the above argument, one can extend the range for which ")#link(<tao-93db5a7927bddc193e91>)[#text("(1)")]#text(" can be proved from ")#mi("{x > p^{1/2 + \\varepsilon}}")#text(" to also cover the range ")#mi("{p^{1/4+\\varepsilon} < x < p^{1/2}}")#text(". The idea is not to cover ")#mi("{[1,x]}")#text(" by intervals of length ")#mi("{y}")#text(", but rather by ")#emph[#text("arithmetic progressions")]#text(" ")#mi("{\\{ a, a+r, \\ldots, a+yr\\}}")#text(" of length ")#mi("{y}")#text(", where ")#mi("{a = O(x)}")#text(" and ")#mi("{r = O(x/y)}")#text(". Another application of the first moment method then shows that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{0 \\leq j \\leq y} \\chi(a+jr)\\right| \\gg y", block: true)]]

#text("for a positive fraction of the ")#mi("{a}")#text(" in ")#mi("{[1,x]}")#text(" and ")#mi("{r}")#text(" in ")#mi("{[1,x/y]}")#text(" (i.e. ")#mi("{\\gg x^2/y}")#text(" such pairs ")#mi("{(a,r)}")#text(").")

#text("For technical reasons, it will be inconvenient if ")#mi("{a}")#text(" and ")#mi("{r}")#text(" have too large of a common factor, so we pause to remove this possibility. Observe that for any ")#mi("{d \\geq 1}")#text(", the number of pairs ")#mi("{(a,r)}")#text(" which have ")#mi("{d}")#text(" as a common factor is ")#mi("{O( \\frac{1}{d^2} x^2/y )}")#text(". As ")#mi("{\\sum_{d=1}^\\infty \\frac{1}{d^2}}")#text(" is convergent, we may thus remove those pairs which have too large of a common factor, and assume that all pairs ")#mi("{(a,r)}")#text(" have common factor ")#mi("{O(1)}")#text(" at most (so are “almost coprime”).")

#text("Now we exploit the multiplicativity of ")#mi("{\\chi}")#text(" to write ")#mi("{\\chi(a+jr)}")#text(" as ")#mi("{\\chi(r) \\chi(b+j)}")#text(", where ")#mi("{b}")#text(" is a residue which is equal to ")#mi("{a/r}")#text(" mod ")#mi("{q}")#text(". Dividing out by ")#mi("{\\chi(r)}")#text(", we conclude that ")#metadata(none) <tao-ca20fb682feb5e81bc1a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left|\\sum_{0 \\leq j \\leq y} \\chi(b+j)\\right| \\gg y", block: true)]]

#text("for ")#mi("{\\gg x^2/y}")#text(" pairs ")#mi("{(a,r)}")#text(".")

#text("Now for a key observation: the ")#mi("{\\gg x^2/y}")#text(" values of ")#mi("{b}")#text(" arising from the pairs ")#mi("{(a,r)}")#text(" are mostly disjoint. Indeed, suppose that two pairs ")#mi("{(a,r), (a^{\\prime},r^{\\prime})}")#text(" generated the same value of ")#mi("{b}")#text(", thus ")#mi("{a/r = a^{\\prime}/r^{\\prime} \\text{ mod } p}")#text(". This implies that ")#mi("{ar^{\\prime} = a^{\\prime}r \\text{ mod } p}")#text(". Since ")#mi("{x < p^{1/2}}")#text(", we see that ")#mi("{ar^{\\prime}, a^{\\prime}r}")#text(" do not exceed ")#mi("{p}")#text(", so we may remove the modulus and conclude that ")#mi("{ar^{\\prime}=a^{\\prime}r}")#text(". But since we are assuming that ")#mi("{a, r}")#text(" and ")#mi("{a^{\\prime},r^{\\prime}}")#text(" are almost coprime, we see that for each ")#mi("{(a,r)}")#text(" there are at most ")#mi("{O(1)}")#text(" values of ")#mi("{a^{\\prime},r^{\\prime}}")#text(" for which ")#mi("{ar^{\\prime}=a^{\\prime}r}")#text(". So the ")#mi("{b}")#text("‘s here only overlap with multiplicity ")#mi("{O(1)}")#text(", and we conclude that ")#link(<tao-ca20fb682feb5e81bc1a>)[#text("(11)")]#text(" holds for ")#mi("{\\gg x^2/y}")#text(" values of ")#mi("{b}")#text(". But comparing this with the previous section, we obtain a contradiction unless ")#mi("{x^2/y \\ll \\sqrt{p}}")#text(". Setting ")#mi("{y}")#text(" to be a sufficiently small power of ")#mi("{p}")#text(", we obtain Burgess’s result that ")#link(<tao-93db5a7927bddc193e91>)[#text("(1)")]#text(" holds for ")#mi("{x > p^{1/4+\\varepsilon}}")#text(" for any fixed ")#mi("{\\varepsilon > 0}")#text(".")

#text("Combining Burgess’s estimate with Vinogradov’s sieving trick we conclude the bound ")#mi("{n_p = O_\\varepsilon( p^{1/4\\sqrt{e} + \\varepsilon} )}")#text(" for all ")#mi("{\\varepsilon > 0}")#text(", which is the best bound known today on the least quadratic non-residue except for refinements of the ")#mi("{p^\\varepsilon}")#text(" error term.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" There are many generalisations of this result, for instance to more general characters (with possibly composite conductor), or to shifted sums ")#link(<tao-ecd3fad7a4d35d7130c6>)[#text("(4)")]#text(". However, the ")#mi("{p^{1/4}}")#text(" type exponent has not been improved except with the assistance of powerful conjectures such as the ")#link("http://en.wikipedia.org/wiki/Generalized_Riemann_hypothesis")[#text("generalised Riemann hypothesis")]#text(".")
]

#heading(level: 1)[#text("Comments (28)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b1af1467332c044b32fef284f74a15e5e0b92a5ab33bd6559de953169e35dba6-7016c2facdd4edbda653da370c7176b83d8130e5c4de046415caa5df1c3f6c84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Zelinsky")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-41072")[#strong[#text("Joshua Zelinsky")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2009")])]

#text("“…but also ${\\chi(n) = +1}$ for any $n$ which is $n_p$-smooth, i.e. is the product of integers less than or equal to $n_p$.” Shouldn’t that be $n_p -1$ smooth? ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6981bafa5401060b1fd62a1bc81b103edb76feede94a0ca698b45526eddfd311-693d48fd4da572b496ecc1cdc44c234374b12046c456d3490a00eeb591c4c9d6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of charav")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-41077")[#strong[#text("charav")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2009")])]

#text("Professor Tao,")#linebreak()#text(" how we define a number-theoretic set?")

#text("Thanks for your time,")#linebreak()#text(" Christian")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-41080")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2009")])]

#text("By “number-theoretic set”, I simply mean a set which is of interest to number-theorists.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-41079")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2009")])]

#text("Some look on amplification in various areas of science and in tcs can be found in these two posts of Dick Lipton ")#link("http://rjlipton.wordpress.com/2009/08/10/the-role-of-amplifiers-in-science/")[#text("http://rjlipton.wordpress.com/2009/08/10/the-role-of-amplifiers-in-science/")]#linebreak()#text(" ")#link("http://rjlipton.wordpress.com/2009/08/13/amplifying-on-the-pcr-amplifier/")[#text("http://rjlipton.wordpress.com/2009/08/13/amplifying-on-the-pcr-amplifier/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-41089")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2009")])]

#text("I think the bound in (3) should be ")#tao-math("\\sum_{1 \\leq n \\leq x} e^{2\\pi i an/p} = O(  \\left\\| a/p \\right\\| ^{-1})", block: false)#text(" rather than ")#tao-math("\\sum_{1 \\leq n \\leq x} e^{2\\pi i an/p} = O( p / \\left\\| a/p \\right\\| )", block: false)#text(". ")#emph[#text("[Corrected, thanks. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0be49b7ca249c62312c42f75ab6210d03e09a6efae802e2c2a47b6f06bf48ba3-063f4f9f88d571699777b3c76d9c806f79aac01c3ad0b5a93adcb633b4a982fa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Efthymios Sofos")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-41100")[#strong[#text("Efthymios Sofos")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2009")])]

#text("There exists an elementary argument which shows the inequality")#linebreak()#text(" ")#mi("n=n_p \\leq \\sqrt{p}+1")#text(". Defining an integer m by")#linebreak()#text(" ")#mi("(m-1)n \\leq p < m n")#text(", we deduce that ")#mi("mn-p")#text(" lies between 0 and n.")#linebreak()#text(" By the definition of n, m is not a quadratic residue, therefore ")#mi("m\\geq n")#linebreak()#text(" which yields the stated inequality.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of RK")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-41137")[#strong[#text("RK")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2009")])]

#text("In a different direction, one can look at this problem on average over the prime p, using the large sieve. Fix ")#mi("\\epsilon > 0")#text(". Linnik showed that the number of primes ")#mi("p \\sim P")#text(" with ")#mi("n_p > P^{\\epsilon}")#text(" is bounded.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boris")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-41326")[#strong[#text("Boris")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2009")])]

#text("That is a very nice explanation of Stepanov’s argument. The trick of getting the extra variables by using the Frobenius map x|->x^p is really cool. It is similar to Thue’s trick from the proof of his famous result on the Diophantine approximations to algebraic numbers, where instead of the exact equality x=x^p, that is used here, he used two very good approximations to the same algebraic number.")

#text("A request: can you please increase the size of the images you use for mathematical equations. Currently, a single letter is 7px by 7px, which is really hard on the eyes. Since the images are scalar, scaling these tiny letters up yields images that are even more straining on the eyes. Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31a3f814b4ce3f9613fc9bf695a79a6f792c2f0629bc7e14d11d5840d3f7d743-309dee0d642fa87941549982d0b477a0c57d3958a1e8a9a3153402f98d832952.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of other")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-41626")[#strong[#text("other")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2009")])]

#text("Bourgain has recently found many ways around the square root barrier; see:")#linebreak()#text(" 1. Bourgain-Glibichuk-Konyagin, Bourgain-Chang: character sums over multiplicative groups")#linebreak()#text(" 2. Bourgain: 2-source extractors")#linebreak()#text(" 3. Bourgain: affine extractors")

#text("These are all based on the sum-product theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seva")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-41631")[#strong[#text("Seva")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2009")])]

#text("Dear Terry,")

#text("Could you indicate the exact form of the identity you mention in Remark 2?")

#text("As a more rhetorical question, I wonder whether it is possible to improve")#linebreak()#text(" Burgess’ result showing that, for some smoothening function $\\psi$, we have")#linebreak()#text(" ")#mi("\\sum_{n=1}^{H} \\chi(a+n)\\psi(n/H)=o(H)")#text(" for ")#mi("H\\gg p^c")#text(" with some")#linebreak()#text(" constant ")#mi("c<1/4")#text(". Using Vinogradov's trick, one would automatically")#linebreak()#text(" improve then the exponent ")#mi("1/2\\sqrt {e}")#text(" in the least quadratic")#linebreak()#text(" non-residue estimate.")

#text("Several tiny corrections on this occasion. \"Consecutive pairs\" in the first")#linebreak()#text(" paragraph should be \"pairs of consecutive\"; to count such pairs one does not")#linebreak()#text(" need Weil or anything that deep, this goes by a very simple computation.")#linebreak()#text(" Similarly, one does not need Chebyshev's inequality (whatever it means in")#linebreak()#text(" this context) to derive conclusions from (6), this follows by \"plain Markov\".")#linebreak()#text(" For the proof of Lemma 2, part (a), an issue to address is the case where")#linebreak()#text(" ")#mi("R(x,0)=0")#text("; fortunately, there is an easy fix-up. For part (b), to get")#linebreak()#text(" vanishing of order ")#mi("l")#text(" it suffices for (10) to hold for all ")#mi("j")#linebreak()#text(" strictly less than ")#mi("l")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-41640")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2009")])]

#text("Thanks for the corrections!")

#text("Regarding Remark 2, the Fourier transform of ")#mi("\\chi")#text(" is (up to a constant phase) ")#mi("1/\\sqrt{p} \\chi")#text(", hence by Parseval ")#mi("\\sum_{n \\in Z/pZ} \\chi(n) \\psi(n)")#text(" is a constant phase times ")#mi("\\sqrt{p} \\sum_{n \\in Z/pZ} \\chi(n) \\hat \\psi(n)")#text(" (I may have dropped a conjugation sign here, but it is not particularly relevant). If one chooses ")#mi("\\psi(n)")#text(" to be a smooth function adapted to the interval ")#mi("n = O(x)")#text(", then its Fourier transform will be mostly adapted to the interval ")#mi("n = O(p/x)")#text(" by the uncertainty principle, which leads to the heuristic relationship indicated in the text.")

#text("In harmonic analysis, Chebyshev’s inequality is often used to refer to the L^p version of Markov’s inequality (rather than just the L^2 version, which is the probability theorist’s version). I’ve now referenced both here.")

#text("Smoothing the sum can’t hurt, but in this particular case I don’t think it helps either. The sum from 1 to H in the Burgess argument ultimately just gets summed in absolute value, so smoothing this sum doesn’t really make it much smaller (there is no cancellation from oscillation to exploit, e.g. from Fourier analysis, which is the place where smoothing really helps.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-42846")[#strong[#text("Math websites falling into disuse? « What Is Research?")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2009")]

#text("[…] Tricki also hasn’t been mentioned on Gowers’ blog since June 25, 2009 and on Terence Tao’s blog since August 2009. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-46321")[#strong[#text("Theorem 33: the size of Gauss sums « Theorem of the week")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2010")]

#text("[…] difficult to say precise things about the distribution of the quadratic residues (Tao has a nice post about some ideas about this), but this evaluation of the Gauss sum gives some information that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/beeed5597923941b57f8b6628c32b825df93f93c87f5d099c69c3d39a2aab865-1f23b8cd15b3653b08bf6d1ea41ea9dbcc1dd08aecad4e897d884cd84dc0fa64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sungjin Kim")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-50761")[#strong[#text("Sungjin Kim")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2011")])]

#text("Dear Professor Tao,")#linebreak()#text(" If chi is a Legendre symbol, (7) follows easily by replacing (n/p) by (n*/p). Even we get strong result, the sum (7) becomes -1. Also, the n_p << sqrt (p) bound can be obtained by much simpler way, it is in")#linebreak()#text(" ")#link("http://number.subwiki.org/wiki/Smallest_quadratic_nonresidue_is_less_than_square_root_plus_one")[#text("http://number.subwiki.org/wiki/Smallest_quadratic_nonresidue_is_less_than_square_root_plus_one")]

#text("Sincerely,")#linebreak()#text(" Sungjin Kim")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On the number of solutions to 4/p = 1/n_1 + 1/n_2 + 1/n_3 « What’s new")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-55199")[#strong[#text("On the number of solutions to 4/p = 1/n_1 + 1/n_2 + 1/n_3 « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2011")])]

#text("[…] in which one or two of the are divisible by , with the other denominators being coprime to . (Of course, one can still get representations of by starting with a representation of and dividing by , but such representations are is not of the above form.) This shows that any attempt to establish the Erdös-Straus conjecture by manually constructing as a function of must involve a technique which breaks down if is replaced by (for instance, this rules out any approach based on using polynomial combinations of and dividing into cases based on residue classes of in small moduli). Part of the problem here is that we do not have good bounds that prevent a prime from “spoofing” a perfect square to all small moduli (say, to all moduli less than a small power of ); this problem is closely related (via quadratic reciprocity) to Vinogradov’s conjecture on the least quadratic nonresidue, discussed in this previous blog post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f13b0c714b8acb215abb6e84496a4b308205f7052ac0979c60563c22fae5c1ea-270423507ee5d697f0c60c253373d4f6e076fa33ad54898dddb2fd2135628439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian M.")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-55253")[#strong[#text("Ian M.")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2011")])]

#text("In the line following equation (2), you write quadratic residue where I think you mean quadratic nonresidue. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d39fdaf10946ee6d8957584e879378c93338fd3352e8785cd13f50d48d9a9d8-6071fd7255dc2dc3cfe34b4717111edc63fc626958a8ddb601d254afd37d4023.gif", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack D'Aurizio")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-87076")[#strong[#text("Jack D'Aurizio")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2011")])]

#text("What is known about the short sum ")#mi("S=\\sum_{p\\in [q^{D/C},q^D]}\\frac{\\chi(p)}{p}")#text(" where ")#mi("q")#text(" is a big prime, ")#mi("\\chi")#text(" is the nonprincipal real character modulus ")#mi("q")#text(", ")#mi("D")#text(" is a real number a little bigger than ")#mi("\\frac{1}{4}")#text(" and ")#mi("C\\in(1,2)")#text("?")

#text("If ")#mi("S")#text(" was ")#mi("o(1)")#text(" (or even bounded by a small constant), there would be significant improvements in the Vinogradov’s amplification trick. However, ")#mi("S")#text(" is rather too short…")#linebreak()#text(" By naming ")#mi("J=[q^{D/C},q^D]\\cap\\mathcal{P}")#text(", one has")#linebreak()#text(" ")#tao-math("\\left|S\\right|^2 = \\sum_{p\\in J}\\frac{1}{p^2}+2\\sum_{n=q^{2D/C}}^{q^{2D}}\\frac{\\chi(n)}{n}\\,1_{\\omega(n)=2}\\,\\cdot\\,1_{J\\cdot J}", block: false)#linebreak()#text(" that is slighly larger and supported on almost primes: is it possible to apply some weaker version of the Selberg formulas")#linebreak()#text(" ")#mi("\\sum_{pq\\leq x}\\frac{\\log p\\,\\log q}{pq}=\\frac{1}{2}\\,\\log^2 x+O(\\log x),")#linebreak()#text(" ")#mi("\\sum_{p\\leq x,\\;\\left(\\frac{D}{q}\\right)=1}\\frac{\\log p}{p}=\\frac{1}{2}\\,\\log x + O(D)")#linebreak()#text(" in the unlucky case ")#mi("x\\ll q")#text("?")#linebreak()#text(" In alternative, it is possible to express every value of the character as a Gauss sum and use Weyl difference method to state:")#linebreak()#text(" ")#tao-math("\\left|S\\right|^2 = \\frac{1}{q}\\left(\\sum_{n=q^{D/C}}^{q^{D+1}}w^2(n)+2\\sum_{h=1}^{\\lfloor q^{D+1}-q^{D/C}\\rfloor}\\sum_{n=q^{D/C}}^{q^{D+1}-h}\\cos\\left(\\frac{h}{q}\\right)f(n)f(n+h)\\right),", block: false)#linebreak()#text(" where")#linebreak()#text(" ")#mi("f(n)=\\chi(n)\\sum_{p|n,\\,p\\in J\\,n/p\\leq q}\\frac{\\chi(p)}{p}")#text(".")#linebreak()#text(" Here ")#mi("\\chi(n)\\chi(n+h)")#text(" has mean zero on intervals of length ")#mi("q")#text(", and ")#tao-math("\\left|w(n)\\right|", block: false)#text(" is relatively small and supported on q-smooth numbers. However, reasonable bounds seem very hard to achieve also in this case, since there are a huge number of sums, and the least of them have too few terms to hope in some cancellation.")#linebreak()#text(" As a third way, one could try to deal with")#linebreak()#text(" ")#mi("e^S-1\\leq \\prod_{p\\in J}\\left(1-\\frac{\\chi(p)}{p}\\right)^{-1}=T,")#linebreak()#text(" that exhibits a strong connection with ")#mi("L(1,\\chi)")#text(". Again, by expressing character values as Gauss sums and by switching the order of summation,")#linebreak()#text(" one has")#linebreak()#text(" ")#mi("T = \\frac{1}{\\sqrt{q}}\\sum_{n} \\chi(n)\\, e(-n/q)\\, w(n),")#linebreak()#text(" where")#linebreak()#text(" ")#mi("w(n) = \\sum_{d|n,\\, p|d\\to p\\in J,\\,n/d\\leq q}\\frac{\\chi(d)}{d}")#linebreak()#text(" is a small (")#tao-math("\\left|w(n)\\right|\\leq \\frac{q}{n}\\,d(n)", block: false)#text("), almost-multiplicative weight-function, supported on q-smooth numbers and")#linebreak()#text(" ")#mi("\\sum \\chi(n) e(-n/q)")#linebreak()#text(" is a Gauss sum on intervals of length q. Is it possible to bound ")#mi("T")#text(" by Poisson summation, maybe using the results of Maier, De La Breteche and Tenenbaum on exponential sums over smooth numbers?")

#link("mailto:elianto84@gmail.com")[#text("elianto84@gmail.com")]#linebreak()#text(" University of Pisa")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1220728caad023546e7ef6f215f1d75434a22606ed5ee518d3c540d5e2423fe4-6071fd7255dc2dc3cfe34b4717111edc63fc626958a8ddb601d254afd37d4023.gif", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack D'Aurizio")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-87083")[#strong[#text("Jack D'Aurizio")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2011")])]

#text("The problem of bounding ")#mi("n_q")#text(", the least quadratic non-residue modulus, without assuming GRH, is indeed very challenging.")#linebreak()#text(" I’m asking myself, too, if there is a way to deeper exploit quadratic reciprocity.")

#text("By assuming the independence of the values taken by the Legendre symbol modulus q over primes, one would expect to have ")#mi("n_q")#text(" bounded by some (potentially huge) power of ")#mi("\\log q")#text(".")

#text("Moreover, if ")#mi("q\\equiv 1\\pmod{4}")#text(" and, for some prime ")#mi("p<q")#text(",")#linebreak()#text(" ")#mi("n_p|(q-p)")#text(", then the prime number ")#mi("n_p\\ll p^{\\frac{1}{4\\sqrt{e}}+\\varepsilon}")#text(" is a quadratic non-residue modulus q.")

#text("Is there a way to exploit the Lovasz Local Lemma in the last setting?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Lang-Weil bound « What’s new")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-166330")[#strong[#text("The Lang-Weil bound « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2012")])]

#text("[…] for plane curves. For hyper-elliptic curves, an elementary proof (due to Stepanov) is discussed in this previous post. For general plane curves, the first proof was by Weil (leading to his famous Weil conjectures); […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bounding short exponential sums on smooth moduli via Weyl differencing | What's new")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-235688")[#strong[#text("Bounding short exponential sums on smooth moduli via Weyl differencing | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("[…] any fixed integer , assuming that is square-free (for simplicity) and of polynomial size; see this previous post for a discussion of the Burgess argument. This is non-trivial for as small as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Elliott-Halberstam conjecture implies the Vinogradov least quadratic nonresidue conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-433751")[#strong[#text("The Elliott-Halberstam conjecture implies the Vinogradov least quadratic nonresidue conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2014")])]

#text("[…] any fixed . See this previous post for a proof of these […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-466045")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2016")])]

#text("I don’t really understand the second half of this:")

#text("“Note that if ")#mi("b")#text(" is coprime to ")#mi("p")#text(", then ")#mi("\\chi(bn)")#text(" is a scalar multiple of ")#mi("\\chi(n)")#text(" by a quantity ")#mi("\\chi(b)")#text(" of magnitude ")#mi("1")#text("; taking Fourier transforms, this implies that ")#mi("\\hat \\chi(a/b)")#text(" and ")#mi("\\hat \\chi(a)")#text(" also differ by this factor. “")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-466050")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2016")])]

#text("If ")#mi("a \\mapsto \\hat \\chi(a)")#text(" is the Fourier transform of ")#mi("n \\mapsto \\chi(n)")#text(", then ")#mi("a \\mapsto \\hat \\chi(a/b)")#text(" is the Fourier transform of ")#mi("n \\mapsto \\chi(bn)")#text(", as can be seen by a simple change of variables ")#mi("n^{\\prime} := bn")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d28195df14800315168ea974f4adf888eace7d3a34fc83513af492698793a2c-e2ad3cdfa379c5dcf139408dc5d555ac7c236dfa87abd3799a789b51ef5d74f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kodlu")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-472538")[#strong[#text("kodlu")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2016")])]

#text("Could you please give a reference to the generalisation of the Burgess bound to shifted sums as in (4)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-472548")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2016")])]

#text("See e.g. Theorem 12.6 of Iwaniec-Kowalski.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-497110")[#strong[#text("On the Cramér-Granville Conjecture and finding prime pairs whose difference is 666 BootMath")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2018")]

#text("[…] The least quadratic nonresidue, and the square root barrier […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32065b81c16f187944d8c30e760cd8d517709c8ac8b7fd61fc96b9e15e310ac3-26bbdb9819ad9c35bc05f817557b45172536330a2f6cd94c8a4ec0de03846620.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Breaking the Square root Barrier via the Burgess Bound | George Shakan")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-497967")[#strong[#text("Breaking the Square root Barrier via the Burgess Bound | George Shakan")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2018")])]

#text("[…] analytic number theory and such a result would have wide applications. For instance, it would solve the Vinogradov least square problem. It would also have implications to sub–convexity bounds of –fucntions, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/724a5f80344d8c833d5f96098156b6474d7241d0645221f832a2cf430c495e55-d0c51b33bad4c6bd68b860e2c692845dc25308fcf7971962b7e0162cc488bbfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hc")]], [#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/#comment-685574")[#strong[#text("hc")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2024")])]

#text("There’s a typo in the proof of Lemma 2, where")

#text("“Since we only need to evaluate this expression when")

#link("https://s0.wp.com/latex.php?latex=%7BP%28x%29%5E%7B%5Cfrac%7Bp-1%7D%7B2%7D%7D+%3D+%2B1%7D&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%7BP%28x%29%5E%7B%5Cfrac%7Bp-1%7D%7B2%7D%7D+%3D+%2B1%7D&bg=ffffff&fg=000000&s=0&c=20201002")]

#text("and")

#link("https://s0.wp.com/latex.php?latex=%7Bx%5Ep%3Dp%7D&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%7Bx%5Ep%3Dp%7D&bg=ffffff&fg=000000&s=0&c=20201002")]

#text("(by Fermat’s little theorem),”")

#text("should be")

#text("$x^p = x$ by Fermat’s little theorem.")
]
