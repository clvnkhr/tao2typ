// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/12/03/course-announcement-254a-random-matrices/
// Converted to Typst by tao2typ: "2026-10-14T08:50:30.658726+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Course announcement: 254A – random matrices", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Course announcement: 254A – random matrices")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 December 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/12/03/course-announcement-254a-random-matrices/")[#text("https://terrytao.wordpress.com/2009/12/03/course-announcement-254a-random-matrices/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Starting in the winter quarter (Monday Jan 4, to be precise), I will be giving a ")#link("http://www.math.ucla.edu/~tao/254a.1.10w/")[#text("graduate course on random matrices")]#text(", with lecture notes to be posted on this blog. The topics I have in mind are somewhat fluid, but my initial plan is to cover a large fraction of the following:")

#list(
[#text("Central limit theorem, random walks, concentration of measure")],
[#text("The semicircular and Marcenko-Pastur laws for bulk distribution")],
[#text("A little bit on the connections with free probability")],
[#text("The spectral distribution of GUE and gaussian random matrices; theory of determinantal processes")],
[#text("A little bit on the connections with orthogonal polynomials and Riemann-Hilbert problems")],
[#text("Singularity probability and the least singular value; connections with the Littlewood-Offord problem")],
[#text("The circular law")],
[#text("Universality for eigenvalue spacing; Erdos-Schlein-Yau delocalisation of eigenvectors and applications")]
)

#text("If time permits, I may also cover")

#list(
[#text("The Tracy-Widom law")],
[#text("Connections with Dyson Brownian motion and the Ornstein-Uhlenbeck process; the Erdos-Schlein-Yau approach to eigenvalue spacing universality")],
[#text("Conjectural connections with zeroes of the Riemann zeta function")]
)

#text("Depending on how the course progresses, I may also continue it into the spring quarter (or else have a spring graduate course on a different topic – one potential topic I have in mind is dynamics on nilmanifolds and applications to combinatorics).")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/12/03/course-announcement-254a-random-matrices/#comment-42691")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2009")])]

#text("Great! I am looking forward to learning it!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2009/12/03/course-announcement-254a-random-matrices/#comment-42694")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2009")])]

#text("It looks like quite an ambitious selection of topics, but I’m glad to see them all there. I’ve seen survey papers on random matrices that focus on just one or two of your bullet points, but are written so as to give the uninitiated the impression that just those topics comprise all of random matrix theory. It’s somehow a bigger area than people admit.")

#text("Any plans to discuss applications (in, say, statistics, physics, or signal processing) in any level of detail?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/12/03/course-announcement-254a-random-matrices/#comment-42700")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2009")])]

#text("I have in mind a “sampler” course in which I try to present one illustrative model instance of each aspect of the theory, but then move on instead of trying to develop any one aspect in depth. I do not know at this point exactly how much I will be able to cover, but I think I will have a better idea after a few weeks.")

#text("I will probably be spending zero time on applications, though, except possibly near the end where I may talk about the conjectural relationship with zeroes of the Riemann zeta function. My initial projection though is that I may have to drop this topic for lack of time.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student not at UCLA")]], [#link("https://terrytao.wordpress.com/2009/12/03/course-announcement-254a-random-matrices/#comment-42702")[#strong[#text("student not at UCLA")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2009")])]

#text("I wish each class will be video taped, and uploaded online. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62d49a9e1a39401387406962ec9adf6b22cbd459f92fca2979d60d9b6b42b473-cf095d78e21fe0e1a4c72f5fd22c91e1c4ab0ede62f225721919d94387a7a714.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jo")]], [#link("https://terrytao.wordpress.com/2009/12/03/course-announcement-254a-random-matrices/#comment-42708")[#strong[#text("jo")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2009")])]

#text("I agree, it would be great if videos of the lectures were made available online (I wish this happened with the ricci flow lectures already).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/12/03/course-announcement-254a-random-matrices/#comment-42717")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2009")])]

#text("I believe that it is possible to arrange for Instructional Technology Services at UCLA to record the lectures, if Prof. Tao were interested.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/187e666bb92442c9042a0f8f6863f074b8564135a6041ced1e5a425138b78b6d-9084659a0d54caf5e68faedc64a3e1bb23eba6b76ddab1acebc550cdbe84850b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chebyshev")]], [#link("https://terrytao.wordpress.com/2009/12/03/course-announcement-254a-random-matrices/#comment-42719")[#strong[#text("chebyshev")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2009")])]

#text("I would like to see video of the lectures too")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d2f9281a5820face44ca5c5760dc10b65b235a30a88c4468e405cccab22dfc-9d9b6ba916195ebba12a95614763ab09b9fae0c8f0787c620e322a5f44dc61c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tyler Neylon")]], [#link("https://terrytao.wordpress.com/2009/12/03/course-announcement-254a-random-matrices/#comment-42722")[#strong[#text("Tyler Neylon")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2009")])]

#text("+1 for any possible mode of remote learning, such as video lectures or an online version of the course notes")
]
