// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/05/20/outside-in/
// Converted to Typst by tao2typ: "2026-10-14T07:00:05.106393+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Outside in", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Outside in")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 May 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/05/20/outside-in/")[#text("https://terrytao.wordpress.com/2008/05/20/outside-in/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Given that this blog is currently being devoted to a rather intensive study of flows on manifolds, I thought that it might be apropos to highlight an amazing 22-minute video from 1994 on this general topic by the (unfortunately ")#link("http://www.geom.uiuc.edu/closed.html")[#text("now closed")]#text(") ")#link("http://www.geom.uiuc.edu/")[#text("Geometry Center")]#text(", entitled “")#link("http://www.geom.uiuc.edu/docs/outreach/oi/")[#text("Outside In")]#text("“, which depicts ")#link("http://en.wikipedia.org/wiki/Smale's_paradox")[#text("Smale’s paradox")]#text(" (which asserts that an 2-sphere in three-dimensional space can be smoothly inverted without ever ceasing to be an ")#link("http://en.wikipedia.org/wiki/Immersion_%28mathematics%29")[#text("immersion")]#text("), following a construction of ")#link("http://en.wikipedia.org/wiki/William_Thurston")[#text("Thurston")]#text(" (who was credited with the concept for the video). I first saw this video at the ")#link("http://elib.zib.de/ICM98/")[#text("1998 International Congress of Mathematicians")]#text(" in Berlin, where it won the first prize at the ")#link("http://page.mi.fu-berlin.de/polthier/Events/VideoMath/")[#text("VideoMath Festival")]#text(" held there. It did a remarkably effective job of explaining the paradox, its resolution in three dimensions, and the lack of a similar paradox in two dimensions, all in a clear and non-technical manner.")

#text("A (rather low resolution) copy of the first half of the video ")#link("http://hk.youtube.com/watch?v=BVVfs4zKrgk")[#text("can be found here")]#text(", and the second half ")#link("http://hk.youtube.com/watch?v=x7d13SgqUXg")[#text("can be found here")]#text(". Some higher resolution short movies of just the inversion process can be found at ")#link("http://www.geom.uiuc.edu/docs/outreach/oi/")[#text("this Geometry Center page")]#text(". Finally, the video (and an accompanying booklet with more details and background) can still be ")#link("http://www.akpeters.com/product.asp?ProdCode=0466")[#text("obtained today from A K Peters")]#text(", although I believe the video is only available in the increasingly archaic VHS format.")

#text("There are a few other similar such high-quality expository videos of advanced mathematics floating around the internet, but I do not know of any page devoted to collecting such videos. If any readers have their own favourites, you are welcome to post some links or pointers to them here.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/841a3b79dbf4c44e4671107c4007a57a768dd7d20d8a04797990cb283fe20457-e66a41292cfb1eba4c16ba341e34ec8460fec308ea9218be317207aac2881291.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nobody")]], [#link("https://terrytao.wordpress.com/2008/05/20/outside-in/#comment-29927")[#strong[#text("nobody")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2008")])]

#text("I recommend")

#link("http://www.maths.ox.ac.uk/~hitchin/monopoles.mpg")[#text("http://www.maths.ox.ac.uk/~hitchin/monopoles.mpg")]

#text("Monopoles in motion – a study of the dynamics of slowly moving monopoles, made by IBM based on work by Atiyah and Hitchin, available only in the increasingly archaic MPEG format.")

#text("Also, cool knot dynamics videos courtesy of Jos Leys as you mentioned previously when you described Etienne Ghys’ ICM talk, some of which are available at")#linebreak()#text(" ")#link("http://www.josleys.com/show_gallery.php?galid=303")[#text("http://www.josleys.com/show_gallery.php?galid=303")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd52282579fbb6eefd4b47db64e867da028a76c9598bddff0f61fe315ed65140-5fd45f0087b36439ace017d4a9c7e298241f7817c18b5197b96dec298b9130d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Burhan")]], [#link("https://terrytao.wordpress.com/2008/05/20/outside-in/#comment-29928")[#strong[#text("Burhan")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2008")])]

#text("This one has Part I and II together")

#link("http://video.google.com/videoplay?docid=-6626464599825291409&pr=goog-sl")[#text("http://video.google.com/videoplay?docid=-6626464599825291409&pr=goog-sl")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2008/05/20/outside-in/#comment-29933")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2008")])]

#text("The sphere eversion animation posted above by Burhan is the best I have seen; thank you for posting it.")

#text("It calls to mind Drew Berry’s awesome animations of DNA replication:")

#link("http://video.google.com/videoplay?docid=-2237546742655575670")[#text("http://video.google.com/videoplay?docid=-2237546742655575670")]#linebreak()#text(" ")#link("http://www.molecularmovies.com/showcase/index.html")[#text("http://www.molecularmovies.com/showcase/index.html")]

#text("There is more similarity between the sphere eversion animation and Berry’s DNA animations than one might think — the quantum state-space of DNA (especially the nuclear spin sector) turns out to have a Kahlerian/Grassmannian geometry that every bit as elegant as the sphere eversion geometry.")

#text("By the way, it is fun to do a Fermi estimate of the rate of DNA production by human male testes. Is the net length of DNA produced by one male in one second greater than, or less than, the orbital distance that the space shuttle travels in one second? The surprising answer — the net length of DNA produced is the greater of the two.")

#text("Evidently Mother Nature is very serious about this DNA business. It is nice that she has provided the quantum state-space of these molecules with a geometry that we can hope to understand.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2008/05/20/outside-in/#comment-29938")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2008")])]

#text("I’ve found that this one and their other famous video “Not Knot” (also available in ")#link("http://www.youtube.com/watch?v=AGLPbSMxSUM")[#text("two")]#text(" ")#link("http://www.youtube.com/watch?v=MKwAS5omW_w")[#text("parts")]#text(") are great for undergraduate math clubs.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/05/20/outside-in/#comment-29950")[#strong[#text("Stones Cry Out - If they keep silent… » Things Heard: edition 18v3")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2008")]

#text("[…] (specifically topology) is really cool. Do watch the youtube […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b27ae24e0fd6af531dc0e830339afe13eb4111b63397128ba112e2a33b7eee4c-0a33e11e4845317363cb11738f9a5ae8a2646c411b2880db41b7efa7fe1b7c4a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick")]], [#link("https://terrytao.wordpress.com/2008/05/20/outside-in/#comment-29952")[#strong[#text("Nick")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2008")])]

#text("I was a summer student at the Geometry Center while they were making both Not Knot and Outside In…nice to see that they are still being viewed by people!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2e69fe991008100445ec71dcce3acc2dd72f160b39f34a569b2669354396f85-1909c969e8c28926f573b796901e14bbf8458eb0ecb81c2ff446a678aa5879f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy D")]], [#link("https://terrytao.wordpress.com/2008/05/20/outside-in/#comment-29957")[#strong[#text("Andy D")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2008")])]

#text("I’m curious whether the question Smale answered is, from first principles, ‘semi-decidable’, in the sense that you could write a simple program that would be guaranteed to find such an immersion provided one exists.")

#text("The idea being to look for a discrete approximation to the immersion, at progressively finer spatial & temporal scales, and then ‘smoothing out’ promising candidates. Or alternatively, perhaps multivariate polynomials")#linebreak()#text(" P(x, y, z, t) with rational coefs induce a natural dense set within the immersions (describing the sphere point (x, y, z) as it moves over time), and we can check them one by one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2008/05/20/outside-in/#comment-29961")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2008")])]

#text("Regarding Andy D’s comment, it strikes me that a wonderful 21st century animation … and a very effective way of communicating Ricci flow methods to the broader public … would be an ")#emph[#text("animated")]#text(" version of Perelman’s proof.")

#text("A short version to communicate the main geometric ideas would be good … and IMHO a long version to communicate details of the proof would be even better! :)")

#text("Also, the numerical methods behind such an animation would be of very great interest from a computational geometry point of view.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da77a30e6146f577d460d3be9911eb14408d5883385e74aca3fdbf0c2e773fab-de75cd195b29f0c41f5f8d5723bbe6b4533f14f6eebac8c531034637f2244a29.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2008/05/20/outside-in/#comment-30015")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2008")])]

#text("Hi everyone, it’s my first time posting here.")#linebreak()#text(" In answer to Andy D’s curiosity (from the first line of his post) I must say that there is no clue in Smale’s article about how to construct such a sphere eversion.")#linebreak()#text(" Smale was actually studying a topological invariant to classify immersions of the k-sphere in the euclidean n-space, through the k-th homotopy group of the stiefel manifold of k-frames of R^n.")#linebreak()#text(" My assumption is that he stumbled upon the famous Smale Paradox by accident. I write so because in his article from ’58 (where he managed to classify only immersions of the two-sphere in R^n) he just mentions the sphere eversion (without calling it so) once, as if it were just a mere (yet curious) result of theorem A.")

#text("Cheers")#linebreak()#text(" John")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69efe336c9821201d3ff47fe9dd91c27bf823742bad79841adfde0bc6a6b7432-a4d5c9fae47380411a02040bc257c2db5b940a97abe4dbc7b0d68f1110ef3656.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2008/05/20/outside-in/#comment-30071")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2008")])]

#text("There is a search engine specifically devoted to science-y videos, called ScienceHack ( ")#link("http://sciencehack.com/")[#text("http://sciencehack.com/")]#text(" ).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04744c1ec556b963891f014d87e635420009d945cde8e0de90496523a9c9f249-faba070bded647fdb7b69b0b854f013008755e8866cfcdf59dd568d10fcd5222.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian Agol")]], [#link("https://terrytao.wordpress.com/2008/05/20/outside-in/#comment-30098")[#strong[#text("Ian Agol")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2008")])]

#text("Another beautiful video of the sphere eversion is here:")#linebreak()#text(" ")#link("http://new.math.uiuc.edu/optiverse/")[#text("http://new.math.uiuc.edu/optiverse/")]

#text("Based on an idea of Rob Kusner, John Sullivan et. al. start with Boy’s surface, which is an immersed projective plane which is a critical point for the Willmore energy. They then push off in either direction and follow the gradient of the Willmore energy until they reach the round 2-sphere. The total effect is to evert the sphere.")

#text("With respect to John Sidles’ comment, there is a program for visualizing Ricci flow on a rotationally symmetric 3-sphere.")#linebreak()#text(" See: ")#link("http://arxiv.org/abs/math/0406189")[#text("http://arxiv.org/abs/math/0406189")]#linebreak()#text(" ")#link("http://www.irp.oist.jp/mbu/sinclair/ricci_rot/ricci_rot.html")[#text("http://www.irp.oist.jp/mbu/sinclair/ricci_rot/ricci_rot.html")]

#text("What would be great is to have a method for simulating Ricci flow on any 3-manifold. This could have theoretical applications, in terms of finding the computational complexity of distinguishing 3-manifolds.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/647572c9faac9042457793fcb9e1a2f03f8ed8f60463b33a4bdb64afb38e3540-bd86de52e1b3b5399ae563373131313cc9651e8423062127bbf6bfdd7e8209f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Justin")]], [#link("https://terrytao.wordpress.com/2008/05/20/outside-in/#comment-30157")[#strong[#text("Justin")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2008")])]

#text("I recommend the beautiful video on Möbius maps at ")#link("http://www.youtube.com/watch?v=JX3VmDgiFnY")[#text("http://www.youtube.com/watch?v=JX3VmDgiFnY")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7cd2d5a7d299c98087092bcab80c112e4b91f74c43e20fea65183713162b7c0a-3c2e62756da956bf9c332e9ef7f7896e4f4085a3b5c910e72ec15cf11b2b8c67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jos Leys")]], [#link("https://terrytao.wordpress.com/2008/05/20/outside-in/#comment-30489")[#strong[#text("Jos Leys")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2008")])]

#text("A new film, just released, can be found at ")#link("http://www.dimensions-math.org")[#text("http://www.dimensions-math.org")]#text(" . “Dimensions” is two hours of math animation covering the 2-sphere, dimension 3 as seen by Flatlanders, dimension 4 and its polyhedra, complex numbers and the Hopf fibration. It concludes with a thorough, but visual proof that stereographic projection sends circles to circles.")#linebreak()#text(" The website is a companion to the film in that its provides additional information on the topics covered. The film can be downloaded there for free, or the DVD can be ordered. ( only 10 Euro!)")

#text("The film was produced by Jos Leys (graphics and animation), Etienne Ghys (ENS Lyon, scenario and math) and Aurélien Alvarez (ENS Lyon, technical realization)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/05/20/outside-in/#comment-30510")[#strong[#text("Dimensions « The Unapologetic Mathematician")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2008")]

#text("[…] In the discussion thread about the movie Outside In on Terry Tao’s blog, a commenter going by Jos Leys points out a new movie called Dimensions. It’s two hours of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ed1c5abb29f59d83c8f5f53b54522a4eea117907d00e48a629d99461307116f-11be1f83fd02289e8ef2239c2e659a9af9d827080164758b395eff85989c49ab.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Carter")]], [#link("https://terrytao.wordpress.com/2008/05/20/outside-in/#comment-30511")[#strong[#text("Scott Carter")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2008")])]

#text("I am going about the eversion in extremely low tech")#linebreak()#text(" methodology simulating, perhaps, Tony Phillips’s article in Scientific American. Each non-critical phase of the immersion is described by a sequence of immersed curves (movie), the fundamental tropes for the movie are: birth, death, saddle, type II Reidemeister move (projection), type III Reidemeister move, zigzag move, and the other Yetter move (camel back or psi move: (\\cap \\otimes |)\\circ(| \\otimes X) (| \\otimes \\cap) (X \\otimes |). Successive immersions differ by means of the C,Rieger, Saito movive moves that do not involve branch points.")

#text("The important steps in the process are: create a pair of loops of double points, create 4 triple points, pass them through a tetrahedron, eliminate a pair of triple points, introduce a lips pair of folds, and untwist one piece until the other two triple points cancel.")

#text("The illustrations are drawn with illustrator, and all of the internal structure at each stage is visible. Each transition between stages is also codified by simple tropes (precisely codimension 1 singularities), and from the illustrator files it would not be difficult to reconstruct 3-d models.")

#text("To complete the low tech version, the process is the subject of a book in the works (about 60% complete), and the topological types of all of the singularities of the process are classified. Soon, I will have a stop action animation available as well.")

#text("It is amusing that the sphere eversion is a calculation in a symmetric monoidal 2-category with duals, and that the sphere eversion (when capped off at both ends) represents a generator of the")#linebreak()#text(" 3rd stable stem. Early work of the 1980s indicates that codimension 1 immersions with an odd number of 0-dimensional multiple points in real space are quite rare and (beyond the low dimensions) are controlled by the arf invariant 1 problem.")

#text("The Thurston-Thurston eversion depends on the belt-trick, and every eversion that I have studied has an embedded belt-trick therein. This is not suprising: Smale’s proof depends on the computation of homotopy groups of Steifel manifolds and the corresponding exact sequences ultimately rest on pie one of ess oh three being zee (or zed) mod 2. Somehow, I think Bill Thurston intuited this to give his eversion.")

#text("Groovy pictures will be available soon, I promise!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/05/20/outside-in/#comment-31067")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2008")])]

#text("Dear Prosser 陶:")#linebreak()#text(" I found this two-hour film about dimensions in mathematics on the following webset:")

#link("http://www.dimensions-math.org/Dim_E.htm")[#text("http://www.dimensions-math.org/Dim_E.htm")]

#text("刘")
]
