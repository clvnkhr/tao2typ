// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/
// Converted to Typst by tao2typ: "2026-11-23T18:31:26.814218+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Even more posts, opinion pieces, interviews, and position statements", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Even more posts, opinion pieces, interviews, and position statements")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/")[#text("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-23 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#list(
[#link("https://www.ahmath.org/statements")[#text("AHM Statement on the Announced Proof of the Riemann Hypothesis")]],
[#link("https://www.mathematik.de/dmv-blog/5362-dmv-pr%C3%A4sidium-zur-bedeutung-der-ki-f%C3%BCr-die-mathematik")[#text("Positionen des Präsidiums der Deutschen Mathematiker-Vereinigung (DMV) zur Bedeutung Künstlicher Intelligenz für die Mathematik")]#text(" (Positions of the Presidium of the German Mathematical Society (DMV) on the importance of artificial intelligence for mathematics)")],
[#link("https://www.youtube.com/watch?v=2GsuvsEg28o")[#text("Oxford Mathematics in Conversation on AI – Ben Green and James Maynard with Jan Obloj")]],
[#text("Alexander Givental, “")#link("https://sumizdat.com/homepage/verity.pdf")[#text("The Queen of Sciences in the Age of Silicon")]#text("“")],
[#text("Logan Graves, “")#link("https://logangraves.com/priest-monk-mathematician")[#text("Priest, Monk, and Mathematician")]#text("“")],
[#text("Thore Husfeldt, “")#link("https://www.youtube.com/watch?v=CYMn0QZLzyY")[#text("The Collapse of the Proof Economy")]#text("“")],
[#text("Masoud Kamgarpour, “")#link("https://sites.google.com/site/masoudkomi/whymath")[#text("Why mathematics?")]#text("“")]
)

#text("As always, further links to relevant such pieces can be made as comments to this post.")

#heading(level: 1)[#text("Comments (25)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f448afe442202445794dd733035cd0d78e932fc3a442ffa5ee3adc2e28852d8f-d5c6c038d65ac0e7844d36c370d5acae9e00eee7c4b9cf0f5af7d62351e879e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Una")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699797")[#strong[#text("Una")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Here is a post at proofs and prompts, talking about:")

#text("“")#strong[#text("What if all existing conjectures were solved? How could we move forward?")]#text("“")

#link("https://proofsandprompts.com/2026/11/18/why-the-future-of-mathematics-belongs-to-human-judgment/")[#text("https://proofsandprompts.com/2026/11/18/why-the-future-of-mathematics-belongs-to-human-judgment/")]

#text("I think it’s quite relevant to the recent progress of AI in math, and it does address the role of mathematicians as judges of the importance of new math problems. I think it’s pretty convincing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699805")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("If all existing conjectures were solved, string theorists and loop quantum gravity theorists would get really excited that there are mathematically rigorous bases for their theories.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b7b510e17de4e6675cd023e4cf3f59a066c1c5cd89874954a0ea48433ef61ab-34b42d77aebafd9d9aaf29a4e026152bc224389b462ff75bcd1aa5e71011667e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Celeste")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699798")[#strong[#text("Celeste")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("What a snobbish, retrograde, and out of touch reaction by the AHM!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699807")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#link("https://www.youtube.com/watch?v=-pjm8epal6o")[#text("Elementary school in middle of 11 data centers, surely just fine for human health")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699800")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("It’s time to devalue proofs and verification in mathematics since LLMs and automated theorem provers like Lean are better at those stuff than humans, and start putting more value in understanding and explaining the material.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699843")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Explaining can also be done by more passes (queries) to the LLM. In fact, that is the first thing mathematicians are currently doing to understand the proof of GRH, asking LLMs to summarize the main points, and then keep asking about smaller portions, etc.")

#text("“Understanding” = “More thinking”, which LLM can also do.")

#text("So, that “new value system” also doesn’t work.")

#text("The key is **who does the understanding**. Thus, if you want a value system for the humans, the value system must determine the “who”. As far as I know, that can only be done, currently, by in person evaluation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699804")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("AI with maths is inevitable. I think human mathematicians should start using AI to advance human knowledge. It is time for a change.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699811")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("I agree that it is never good mathematics practice whether you are an accountant or a research mathematician to simply believe stuff just because a computer says it is true.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b8d4bd06352a932806c939e0053686ef0e43041218bb4c12200340d433419c1-23b76515b6a6304506403c170e70a7ecbf0e7c06ac2ef60e355ab8f11dfe6a26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Kopp")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699850")[#strong[#text("Michael Kopp")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Again, cannot follow the argument. All a Lean proof can do is check that the argument is formally correct. It does not judge whether the argument given is in any way intuitive. That said, it was a human guiding an AI or collaborating with an AI who got to that point, based on Stepanov’s argument. Should we not all celebrate this achievement and … start harvesting the proof for insights, new concepts, deeper connections,… ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6834486ec93f5aa647b0623ca77b51cba987ae2de83dfde2a7eb970b29503ba4-1d939f8be969bc61464220f4c435253209f86338d543c461baa874922466bfdf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Misesenforce")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699856")[#strong[#text("Misesenforce")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("You never flew in an airplane ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699874")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Yeah, it’s like these people should go back to the last century. If they don’t trust formal verification software because it’s software and software has bugs, then they shouldn’t trust airplanes, digital bank accounts, modern healthcare, etc.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c398fef0c0d10ccbe00ddef9c12082522be4af08c899bc236a4849ce3c62d976-d34c53afbfec6381a711447de19d5da74a28faa5fee635abe38b9670222e2f3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Simon")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699879")[#strong[#text("Simon")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Humans developed airplanes, digital bank accounts, and modern healthcare. AI is completely different. Even Alpöge himself does not fully understand the proof he concocted using Claude. Go read his announcement.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699859")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("So mathematicians are making a huge mistake when they believe in the four colour theorem, because that was proven by a computer saying it is true.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699889")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Mathematicians will understand the proof of the Riemann hypothesis long before they will understand the four color theorem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/385706eb4b20841b7b9fad56fcc3e9a3ca9f5f141869248024126da086d2dda8-c90ace576b3f40213e183d6737cde6f6fc2130abf5312f97937aa92f3357bcd1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kęstutis")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699924")[#strong[#text("Kęstutis")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Funny enough the SAIR model is a giant advocate of this seemingly by default, I’m not sure playing with this stuff is how I want do research but I think we need to talk about the bigger picture of open access to information and the giant cloud supercomputer infrastructure humanity is addicted too and put two and two together about the environmental tipping point. I am not advocating hysteria, I am advocating for geuine democratic dialog about maintaining pluralism freedom of thought and inquery, the same infrastructure Alpöge used is primarily for the US militaries kill chain and was developed for that purpose explicitly people like Geoffrey Hinton will express this too even though many will call it pointless fearmongering. I agree we should learn from historical hubris and temper any expectations of policy that ends arms races, humans will be humans, but the alarm is gravely sober and we do need to take action, continuing down the trajectory we are on is an active choice too.")

#link("https://www.youtube.com/watch?v=H7_d_sgui6o&t=4511s&pp=ygUXc2Nob2x6ZSB0c2ltZXJtYW4gcGFuZWw%3D")[#text("This panel featuring Scholze & Tsimerman’s hilariously contrasting attitudes is definitely worth a listen")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d033158fbdd208fcbe4dcd31f5b90396e6148f04ce8631b94e1c59d09e03c4f4-28e1af4ff2dfd60993c85d6f4ce463463db6c7e18b167d636ac68150a6a18170.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Keith")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699818")[#strong[#text("Keith")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Particle physics postgrad. here from years back (Birkbeck – David Bohm taught). Isn’t this just a natural development for any advanced technical species in the galaxy (and others of course). An inflection point, a rupture towards an incredible future in terms of applications. Maybe it can be used to get to the stars, some new physics?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c1cd903354450d0c8e6069406f2d99d2a58342de0b7c1015c6bf066acbfb0b5-657eb716c63b513efa244c369622c0386ad2695d24faf7fde046631946800dae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brianbeverly1")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699819")[#strong[#text("brianbeverly1")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("In the Chinese room thought experiment, the argument is that a person sitting at a computer can be given a sequence of Chinese characters, input them, and output a slip of Chinese characters without understanding the language.")

#text("Assuming the Lean proofs are true and cannot be hacked or exploited, then we can get a truth statement. We now know the RH is true, not just extremely likely to be true. Our understanding hasn’t changed because everyone assumed it to be true.")

#text("But neither humans nor the machine understands it. We have been reduced to humans in the Chinese room with a computer.")

#text("If another AI tries to prove the RH is true, will it generate the exact Lean code? How many permutations of true RH Lean proofs exist? Science is about reproduction; AI is about probability. What if one machine zigs and the other zags? What if one day we find two Lean proofs with contradictory statements, one saying the RH is true and the other saying it is false?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699825")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Respectfully, I would suggest partnering with the Vatican. The Catholic Church has been consistently advocating the views expressed in the “AHM Statement on the Announced Proof of the Riemann Hypothesis.”")

#text("Please consider the following:")

#text("-Pope Leo XIV is an American.")

#text("-In 1977 he earned a BS in Mathematics from Villanova University.")

#text("-One of the central pillars of his pontificate is Artificial Intelligence and how humanity needs to guard human dignity in the midst of the AI revolution.")

#text("-He leads a global religion with 1.4 billion members")

#text("-When Pope Leo speaks, a tremendous amount of people, media, and governments listen")

#text("Respectfully, I’m going to be blunt due to the urgency of this situation: You have no chance of changing the trajectory of trillion-dollar companies unless you have powerful allies who can help amplify your viewpoints. If you and AHM are serious in your convictions, you must find strong allies. I think Pope Leo XIV is a great choice.")

#text("Evidence for my claim:")

#text("“Rome Call for AI Ethics” (2020)")

#text("“Artificial Intelligence and Peace” (1 January 2024)")

#text("“Artificial Intelligence and the Wisdom of the Heart” (2024)")

#text("“Antiqua et Nova” (28 January 2025)")

#text("“Magnifica Humanitas” (15 May 2026)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/872dcf53c566679f40637ae22d604ccf4fa4bbebe3c0cc0ead06bcc5824afeae-6ac692fe85d9783ee0546b1def7555679c577950606586c569cbb1d62fd393a2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ph4ri0")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699834")[#strong[#text("ph4ri0")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("As an academic mathematician who always had an interest in philosophy, I see all the mathematicians now scrambling to explain the relevance of their field and essentially going in the same route as philosophy.")

#text("Why do a philosophy undergraduate degree or PhD? Go to every undergraduate departmental website on philosophy and it argues that a degree in philosophy is a degree in critical thinking. It tries to urge more people to do the degree “pleading” that it will be valuable in the real world.")

#text("Pure mathematics has always been safe from this level of scrutiny and criticism. The gymnastics mathematicians are now having to play is trending in the same region as the type of arguments humanities researchers have had to play to justify their existence and place in the world.")

#text("I mean, just look at the trend of posts linked in above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a743641ab34ac55f59c14dcc91674fdd0af753bb96421b7543eb27cb0f412967-19fa7ef6e72b227b5a7469988334d39232e85b29b4e1f751f1c5e5a1de08f1e0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Patrick")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699839")[#strong[#text("Patrick")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("The “Association for Human Mathematics” presents one of the most disappointing statements I’ve ever read. It’s so flabbergasting that at first I thought it was some kind of parody of parochial sentiment.")

#text("Part of the wonder of mathematics is its universality – its nonreliance on human subjectivity. The idea that if humanity perishes millions of years in the future when our sun goes supernova, 2+2 will still equal 4. If we discover evidence of an intergalactic alien civilization, Fermat’s Last Theorem will be true for them as well.")

#text("This reduction of math to something subjective and within human scope is a terrible betrayal.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699937")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("I think you are conflating the “human language of mathematics” with patterns in the universe. 2+2=4 is our way of recognizing a pattern in nature that is independent of humanity’s existence, but the symbolic language we have developed is “human” by definition since we invented it. There is no reason that an AI if left to itself would even prefer this symbolic notation to explain these universal patterns. The mathematical language is deeply subjective and human. Humans picked the symbols, notations, names, definitions and axioms in this language.")

#text("Surely you consider English, Spanish, French, Hindi and so on… as human languages. One could describe a tree in all these languages, but the existence of the tree is independent of languages. Language is something we have invented to make sense of the world around us. In the same way, mathematics is a language invented by humans to understand the patterns in nature.")

#text("Indeed if one day we discovered an intergalactic civilization, Fermat’s last theorem will be true for them. And a tree will still be a tree for them. But the language and words they use for each of things will be reflective of their civilization.")

#text("As you can tell, for me mathematics has always been a language to understand patterns in the universe. An AI can also contribute to helping advance mathematics. But in the end, I would prefer to make sense of the universe in a way that is human (because I am human) and not try to understand how a machine thinks of the universe (and the other fellow machines will prefer the machine’s way).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699858")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Do you think it’s more likely that the proof is correct or that there’s in error in the reasoning behind Lean or a contradiction in the axioms? I’d be more confident in the results if they were spending as much resources trying to disprove or prove untrue facts. Wouldn’t it be wild if the AI also found a proof of the opposite, and then everyone would have to puzzle out what’s wrong 🙃")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699867")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("I wonder if someone has ever read Haruki Murakami’s ")#emph[#text("Barn Burning")]#text(". Isn’t what AI has been doing in mathematics lately a kind of barn burning in its own way?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d762d15076e1158330d4e83c58790903eb3747539c04d8bd72e82459078ea6dd-52be7b7527f575c928d4594f6ac97e015130f57ed132ec2bfdd6c3eeafc2e86a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lole")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699918")[#strong[#text("Lole")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("If iterated theta lifting can serve as an arithmetic analogue of Stepanov’s 1969 method for proving the Riemann hypothesis over function fields, could a suitably developed, shift-coupled version of iterated theta lifting similarly serve as an arithmetic analogue of Sawin and Shusterman’s geometric methods for proving the twin prime conjecture over function fields, yielding sufficiently strong estimates for shifted Möbius and prime correlations to overcome the parity barrier and ultimately prove the twin prime conjecture over the integers?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699939")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("“")#link("https://blog.danromik.com/on-the-ahms-awkward-position-on-rh")[#text("On the Association of Human Mathematics’ awkward position on the Riemann Hypothesis being solved")]#text("” by Dan Romik")
]
