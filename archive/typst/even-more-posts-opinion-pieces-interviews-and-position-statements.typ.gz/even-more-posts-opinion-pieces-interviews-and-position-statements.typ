// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/
// Converted to Typst by tao2typ: "2026-11-27T16:51:42.037542+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Even more posts, opinion pieces, interviews, and position statements", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Even more posts, opinion pieces, interviews, and position statements")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/")[#text("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-27 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#list(
[#link("https://www.ahmath.org/statements")[#text("AHM Statement on the Announced Proof of the Riemann Hypothesis")]],
[#link("https://www.mathematik.de/dmv-blog/5362-dmv-pr%C3%A4sidium-zur-bedeutung-der-ki-f%C3%BCr-die-mathematik")[#text("Positionen des Präsidiums der Deutschen Mathematiker-Vereinigung (DMV) zur Bedeutung Künstlicher Intelligenz für die Mathematik")]#text(" (Positions of the Presidium of the German Mathematical Society (DMV) on the importance of artificial intelligence for mathematics)")],
[#link("https://www.youtube.com/watch?v=2GsuvsEg28o")[#text("Oxford Mathematics in Conversation on AI – Ben Green and James Maynard with Jan Obloj")]],
[#text("Alexander Givental, “")#link("https://sumizdat.com/homepage/verity.pdf")[#text("The Queen of Sciences in the Age of Silicon")]#text("“")],
[#text("Logan Graves, “")#link("https://logangraves.com/priest-monk-mathematician")[#text("Priest, Monk, and Mathematician")]#text("“")],
[#text("Thore Husfeldt, “")#link("https://www.youtube.com/watch?v=CYMn0QZLzyY")[#text("The Collapse of the Proof Economy")]#text("“")],
[#text("Masoud Kamgarpour, “")#link("https://sites.google.com/site/masoudkomi/whymath")[#text("Why mathematics?")]#text("“")]
)

#text("As always, further links to relevant such pieces can be made as comments to this post.")

#heading(level: 1)[#text("Comments (46)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f448afe442202445794dd733035cd0d78e932fc3a442ffa5ee3adc2e28852d8f-d5c6c038d65ac0e7844d36c370d5acae9e00eee7c4b9cf0f5af7d62351e879e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Una")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699797")[#strong[#text("Una")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Here is a post at proofs and prompts, talking about:")

#text("“")#strong[#text("What if all existing conjectures were solved? How could we move forward?")]#text("“")

#link("https://proofsandprompts.com/2026/11/18/why-the-future-of-mathematics-belongs-to-human-judgment/")[#text("https://proofsandprompts.com/2026/11/18/why-the-future-of-mathematics-belongs-to-human-judgment/")]

#text("I think it’s quite relevant to the recent progress of AI in math, and it does address the role of mathematicians as judges of the importance of new math problems. I think it’s pretty convincing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699805")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("If all existing conjectures were solved, string theorists and loop quantum gravity theorists would get really excited that there are mathematically rigorous bases for their theories.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e31250526a5b9f6f1463c1abf69b93591d80f40877c1d78e606d35cc858c94bc-d6fb1e585e2ad7f7710f938b6b53a3ff8e0410d89aa0ffcfee5c4b99fe5fad70.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699967")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("I don’t find it to be convincing at all. Because I think part of the reason why beauty appears in mathematics at all is because people tend to struggle towards finding new ways of expressing things out of necessity. The very practice of spending years on what looks like a mess initially is part of what makes mathematics interesting.")

#text("How will anyone be a good curator if they have never done this process themselves? And frankly, who will pay mathematicians to be curators? Museum curators are paid because the public enjoys seeing the ancient artefacts. The public won’t care much about seeing beautiful math proofs.")

#text("And now we’re reduced to spending gigawatts of energy on solving conjectures and sorting them out? What a reprehensible activity. And according to betterdatacenterproject (dot) com, “")#strong[#text("Anthropic’s currently contracted data centers in the U.S. will be overwhelmingly powered by fossil fuels in the near term")]#text("“. So now we’re going to output more CO2 into the atmosphere to solve all math problems so that we can curate them?")

#text("Have we lost our minds?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b7b510e17de4e6675cd023e4cf3f59a066c1c5cd89874954a0ea48433ef61ab-34b42d77aebafd9d9aaf29a4e026152bc224389b462ff75bcd1aa5e71011667e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Celeste")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699798")[#strong[#text("Celeste")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("What a snobbish, retrograde, and out of touch reaction by the AHM!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699807")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#link("https://www.youtube.com/watch?v=-pjm8epal6o")[#text("Elementary school in middle of 11 data centers, surely just fine for human health")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e31250526a5b9f6f1463c1abf69b93591d80f40877c1d78e606d35cc858c94bc-d6fb1e585e2ad7f7710f938b6b53a3ff8e0410d89aa0ffcfee5c4b99fe5fad70.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699965")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("I don’t really understand this. The truth is, to a lot of people, mathematics with AI is just not that attractive a field any more, regardless of why or how much more math can be discovered.")

#text("The problem is that to keep up, mathematicians will often be forced to use AI or interact with AI-generated math. That’s like taking a person who loves baking and putting them in a industrial factory, asking them to operate the machines for 8 hours a day.")

#text("Regardless of the reasons, this is the reality.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699800")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("It’s time to devalue proofs and verification in mathematics since LLMs and automated theorem provers like Lean are better at those stuff than humans, and start putting more value in understanding and explaining the material.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699843")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Explaining can also be done by more passes (queries) to the LLM. In fact, that is the first thing mathematicians are currently doing to understand the proof of GRH, asking LLMs to summarize the main points, and then keep asking about smaller portions, etc.")

#text("“Understanding” = “More thinking”, which LLM can also do.")

#text("So, that “new value system” also doesn’t work.")

#text("The key is **who does the understanding**. Thus, if you want a value system for the humans, the value system must determine the “who”. As far as I know, that can only be done, currently, by in person evaluation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699804")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("AI with maths is inevitable. I think human mathematicians should start using AI to advance human knowledge. It is time for a change.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699811")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("I agree that it is never good mathematics practice whether you are an accountant or a research mathematician to simply believe stuff just because a computer says it is true.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b8d4bd06352a932806c939e0053686ef0e43041218bb4c12200340d433419c1-23b76515b6a6304506403c170e70a7ecbf0e7c06ac2ef60e355ab8f11dfe6a26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Kopp")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699850")[#strong[#text("Michael Kopp")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Again, cannot follow the argument. All a Lean proof can do is check that the argument is formally correct. It does not judge whether the argument given is in any way intuitive. That said, it was a human guiding an AI or collaborating with an AI who got to that point, based on Stepanov’s argument. Should we not all celebrate this achievement and … start harvesting the proof for insights, new concepts, deeper connections,… ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6834486ec93f5aa647b0623ca77b51cba987ae2de83dfde2a7eb970b29503ba4-1d939f8be969bc61464220f4c435253209f86338d543c461baa874922466bfdf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Misesenforce")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699856")[#strong[#text("Misesenforce")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("You never flew in an airplane ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699874")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Yeah, it’s like these people should go back to the last century. If they don’t trust formal verification software because it’s software and software has bugs, then they shouldn’t trust airplanes, digital bank accounts, modern healthcare, etc.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c398fef0c0d10ccbe00ddef9c12082522be4af08c899bc236a4849ce3c62d976-d34c53afbfec6381a711447de19d5da74a28faa5fee635abe38b9670222e2f3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Simon")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699879")[#strong[#text("Simon")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Humans developed airplanes, digital bank accounts, and modern healthcare. AI is completely different. Even Alpöge himself does not fully understand the proof he concocted using Claude. Go read his announcement.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699859")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("So mathematicians are making a huge mistake when they believe in the four colour theorem, because that was proven by a computer saying it is true.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699889")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Mathematicians will understand the proof of the Riemann hypothesis long before they will understand the four color theorem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699942")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Nearly all mathematicians don’t even understand the full proof of the classification of finite simple groups, which was entirely human written. The Riemann hypothesis proof looks to be simpler than the classification of finite simple groups, yet mathematicians accept the classification of finite simple groups as true.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/385706eb4b20841b7b9fad56fcc3e9a3ca9f5f141869248024126da086d2dda8-c90ace576b3f40213e183d6737cde6f6fc2130abf5312f97937aa92f3357bcd1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kęstutis")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699924")[#strong[#text("Kęstutis")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Funny enough the SAIR model is a giant advocate of this seemingly by default, I’m not sure playing with this stuff is how I want do research but I think we need to talk about the bigger picture of open access to information and the giant cloud supercomputer infrastructure humanity is addicted too and put two and two together about the environmental tipping point. I am not advocating hysteria, I am advocating for geuine democratic dialog about maintaining pluralism freedom of thought and inquery, the same infrastructure Alpöge used is primarily for the US militaries kill chain and was developed for that purpose explicitly people like Geoffrey Hinton will express this too even though many will call it pointless fearmongering. I agree we should learn from historical hubris and temper any expectations of policy that ends arms races, humans will be humans, but the alarm is gravely sober and we do need to take action, continuing down the trajectory we are on is an active choice too.")

#link("https://www.youtube.com/watch?v=H7_d_sgui6o&t=4511s&pp=ygUXc2Nob2x6ZSB0c2ltZXJtYW4gcGFuZWw%3D")[#text("This panel featuring Scholze & Tsimerman’s hilariously contrasting attitudes is definitely worth a listen")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d033158fbdd208fcbe4dcd31f5b90396e6148f04ce8631b94e1c59d09e03c4f4-28e1af4ff2dfd60993c85d6f4ce463463db6c7e18b167d636ac68150a6a18170.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Keith")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699818")[#strong[#text("Keith")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Particle physics postgrad. here from years back (Birkbeck – David Bohm taught). Isn’t this just a natural development for any advanced technical species in the galaxy (and others of course). An inflection point, a rupture towards an incredible future in terms of applications. Maybe it can be used to get to the stars, some new physics?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c1cd903354450d0c8e6069406f2d99d2a58342de0b7c1015c6bf066acbfb0b5-657eb716c63b513efa244c369622c0386ad2695d24faf7fde046631946800dae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brianbeverly1")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699819")[#strong[#text("brianbeverly1")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("In the Chinese room thought experiment, the argument is that a person sitting at a computer can be given a sequence of Chinese characters, input them, and output a slip of Chinese characters without understanding the language.")

#text("Assuming the Lean proofs are true and cannot be hacked or exploited, then we can get a truth statement. We now know the RH is true, not just extremely likely to be true. Our understanding hasn’t changed because everyone assumed it to be true.")

#text("But neither humans nor the machine understands it. We have been reduced to humans in the Chinese room with a computer.")

#text("If another AI tries to prove the RH is true, will it generate the exact Lean code? How many permutations of true RH Lean proofs exist? Science is about reproduction; AI is about probability. What if one machine zigs and the other zags? What if one day we find two Lean proofs with contradictory statements, one saying the RH is true and the other saying it is false?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699825")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Respectfully, I would suggest partnering with the Vatican. The Catholic Church has been consistently advocating the views expressed in the “AHM Statement on the Announced Proof of the Riemann Hypothesis.”")

#text("Please consider the following:")

#text("-Pope Leo XIV is an American.")

#text("-In 1977 he earned a BS in Mathematics from Villanova University.")

#text("-One of the central pillars of his pontificate is Artificial Intelligence and how humanity needs to guard human dignity in the midst of the AI revolution.")

#text("-He leads a global religion with 1.4 billion members")

#text("-When Pope Leo speaks, a tremendous amount of people, media, and governments listen")

#text("Respectfully, I’m going to be blunt due to the urgency of this situation: You have no chance of changing the trajectory of trillion-dollar companies unless you have powerful allies who can help amplify your viewpoints. If you and AHM are serious in your convictions, you must find strong allies. I think Pope Leo XIV is a great choice.")

#text("Evidence for my claim:")

#text("“Rome Call for AI Ethics” (2020)")

#text("“Artificial Intelligence and Peace” (1 January 2024)")

#text("“Artificial Intelligence and the Wisdom of the Heart” (2024)")

#text("“Antiqua et Nova” (28 January 2025)")

#text("“Magnifica Humanitas” (15 May 2026)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/872dcf53c566679f40637ae22d604ccf4fa4bbebe3c0cc0ead06bcc5824afeae-6ac692fe85d9783ee0546b1def7555679c577950606586c569cbb1d62fd393a2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ph4ri0")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699834")[#strong[#text("ph4ri0")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("As an academic mathematician who always had an interest in philosophy, I see all the mathematicians now scrambling to explain the relevance of their field and essentially going in the same route as philosophy.")

#text("Why do a philosophy undergraduate degree or PhD? Go to every undergraduate departmental website on philosophy and it argues that a degree in philosophy is a degree in critical thinking. It tries to urge more people to do the degree “pleading” that it will be valuable in the real world.")

#text("Pure mathematics has always been safe from this level of scrutiny and criticism. The gymnastics mathematicians are now having to play is trending in the same region as the type of arguments humanities researchers have had to play to justify their existence and place in the world.")

#text("I mean, just look at the trend of posts linked in above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a743641ab34ac55f59c14dcc91674fdd0af753bb96421b7543eb27cb0f412967-19fa7ef6e72b227b5a7469988334d39232e85b29b4e1f751f1c5e5a1de08f1e0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Patrick")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699839")[#strong[#text("Patrick")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("The “Association for Human Mathematics” presents one of the most disappointing statements I’ve ever read. It’s so flabbergasting that at first I thought it was some kind of parody of parochial sentiment.")

#text("Part of the wonder of mathematics is its universality – its nonreliance on human subjectivity. The idea that if humanity perishes millions of years in the future when our sun goes supernova, 2+2 will still equal 4. If we discover evidence of an intergalactic alien civilization, Fermat’s Last Theorem will be true for them as well.")

#text("This reduction of math to something subjective and within human scope is a terrible betrayal.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699937")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("I think you are conflating the “human language of mathematics” with patterns in the universe. 2+2=4 is our way of recognizing a pattern in nature that is independent of humanity’s existence, but the symbolic language we have developed is “human” by definition since we invented it. There is no reason that an AI if left to itself would even prefer this symbolic notation to explain these universal patterns. The mathematical language is deeply subjective and human. Humans picked the symbols, notations, names, definitions and axioms in this language.")

#text("Surely you consider English, Spanish, French, Hindi and so on… as human languages. One could describe a tree in all these languages, but the existence of the tree is independent of languages. Language is something we have invented to make sense of the world around us. In the same way, mathematics is a language invented by humans to understand the patterns in nature.")

#text("Indeed if one day we discovered an intergalactic civilization, Fermat’s last theorem will be true for them. And a tree will still be a tree for them. But the language and words they use for each of things will be reflective of their civilization.")

#text("As you can tell, for me mathematics has always been a language to understand patterns in the universe. An AI can also contribute to helping advance mathematics. But in the end, I would prefer to make sense of the universe in a way that is human (because I am human) and not try to understand how a machine thinks of the universe (and the other fellow machines will prefer the machine’s way).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699858")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Do you think it’s more likely that the proof is correct or that there’s in error in the reasoning behind Lean or a contradiction in the axioms? I’d be more confident in the results if they were spending as much resources trying to disprove or prove untrue facts. Wouldn’t it be wild if the AI also found a proof of the opposite, and then everyone would have to puzzle out what’s wrong 🙃")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699867")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("I wonder if someone has ever read Haruki Murakami’s ")#emph[#text("Barn Burning")]#text(". Isn’t what AI has been doing in mathematics lately a kind of barn burning in its own way?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d762d15076e1158330d4e83c58790903eb3747539c04d8bd72e82459078ea6dd-52be7b7527f575c928d4594f6ac97e015130f57ed132ec2bfdd6c3eeafc2e86a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lole")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699918")[#strong[#text("Lole")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("If iterated theta lifting can serve as an arithmetic analogue of Stepanov’s 1969 method for proving the Riemann hypothesis over function fields, could a suitably developed, shift-coupled version of iterated theta lifting similarly serve as an arithmetic analogue of Sawin and Shusterman’s geometric methods for proving the twin prime conjecture over function fields, yielding sufficiently strong estimates for shifted Möbius and prime correlations to overcome the parity barrier and ultimately prove the twin prime conjecture over the integers?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699929")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Riemann hypothesis proof relying on Langlands techniques is the end of analytic number theory as a distinct subfield. Every analytic number theorist will have to learn about automorphic forms and Galois representations and arithmetic geometry in order to understand the proof of the Riemann hypothesis, and then afterwards they are no longer “analytic number theorists”, they are just number theorists, since they would be experts at far more of number theory than just analytic number theory.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699931")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Solving the generalized Riemann hypothesis is like solving only the Hodge conjecture for CM abelian varieties. The real most general unsolved problem hasn’t been solved yet, which is the grand Riemann hypothesis for all automorphic L-functions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699939")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("“")#link("https://blog.danromik.com/on-the-ahms-awkward-position-on-rh")[#text("On the Association of Human Mathematics’ awkward position on the Riemann Hypothesis being solved")]#text("” by Dan Romik")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699971")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("Slop website with vapid opinions powered by slop generator ")#link("https://mathbb.app/")[#text("https://mathbb.app/")]#text(" .")

#text("What a time to be alive!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699941")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Kirti Joshi’s proof of the abc conjecture has been proven to have a gap at Corollary 9.11.1.1: ")#link("https://github.com/Ember-Institute/KirtiJoshi-abc")[#text("https://github.com/Ember-Institute/KirtiJoshi-abc")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a5839e264a5f4826ac0cd72a9ea5470779621aaa673e30d899440d1e1d8390e1-bd4a22e02294b5b560bb1db583eb95d54e8b1d917433e78c71e521187d6d063c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ruzhall")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699949")[#strong[#text("ruzhall")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("“Vanity of vanities, saith the Preacher, vanity of vanities; all is vanity.”")

#text("The most common question I get when teaching is “When I will use this in real life/what is it good for?” I used to get annoyed at this question, because there isn’t a good answer, and the honest answer (to 99% of my pupils) is a variation of “Never, if you don’t want to use it.” But it is a good question. What is everything good for? In the end, what matters to most people is mouths being fed and continuing the cycle.")

#text("Mathematics is niche art and only relatively handful of “snobbs” enjoy it. It had a privileged position because basically – mathematicians are considered smart people and the consensus is that it is a good thing to funnel money to whatever smart people, academia, find interesting; there is a lot of public trust.")

#text("Math dood, wat nou?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699966")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("I am confused by the negative response of some of the mathematics community.")

#text("If the proof is without value due to its opacity, well then nobody is stopping the community from ignoring it.")

#text("If the proof has value but much work of understanding and exposition remains, well I don’t think anyone is disputing that, so why the negative response?")

#text("It is just clearly a time where norms of professional glory must be adjusted. But that’s entirely up to y’all! There was a conjecture: professional glory in mathematics should be bestowed based on who discovers sound proofs of importance. That conjecture held for a long time but it has been disproven by counterexample.")

#text("Humanity has more mathematical knowledge than it did before this proof was published. A good thing, no?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd95e80daf16ad5b92a71c6462480902a783fc95fb30a35ba175a669e22b63b0-7f481c20628a50745480041bcdc12df443d9ce89cff363c6b8429ee285743d75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gordon Royle")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-700017")[#strong[#text("Gordon Royle")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("Most mathematicians are not obsessed with advancing mathematics")#strong[#text(" at any cost")]#text(" but are ")#strong[#text("also")]#text(" concerned with things like ethical behaviour and sustainability of the mathematical community.")

#text("For example, if a senior professor hears a graduate student talk at a conference and immediately goes away and solves their problem quickly, thereby scooping the student, then almost everyone would say that the corresponding advance in mathematical knowledge has come at too great a cost in terms of collateral damage.")

#text("The AI companies have indeed advanced mathematical knowledge, but firstly on the back of the greatest theft of intellectual property ever perpetrated, secondly they have deliberately maximised the damage they are causing to the mathematical community for PR reasons.")

#text("If some biologist creates an unstoppable new virus, then they will certainly have advanced biological knowledge, but is it worth the cost?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699993")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("The Clay Mathematics Institute has now marked the Riemann Hypothesis as “active”")

#link("https://www.claymath.org/millennium-problems/")[#text("https://www.claymath.org/millennium-problems/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699997")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#link("https://galoisrepresentations.org/2026/11/23/initial-thoughts-on-rh/")[#text("Initial Thoughts on RH")]#text(" by Frank Calegari")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-700006")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("Levent Alpoge lied about there being 250,000 pages:")

#link("https://redlib.catsarch.com/r/mathematics/comments/1y3wxv6/levent_alp%C3%B6ge_says_250k_pages_was_a_joke_big/")[#text("https://redlib.catsarch.com/r/mathematics/comments/1y3wxv6/levent_alp%C3%B6ge_says_250k_pages_was_a_joke_big/")]

#text("There is no written proof at all, only Lean code.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-700045")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("It is surprising (to me) the extent with which the AI tools are fine working with just the lean code.")

#text("There are myriad efforts underway using AI tools to extract a human-readable version from the lean. It’s not clear that the “slop” papers serve much useful purpose for these very difficult proofs.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-700008")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("Jack Thorne has a talk on the RIemann hypothesis at the University of Cambridge on December 1st:")

#link("https://talks.cam.ac.uk/talk/index/274363/")[#text("https://talks.cam.ac.uk/talk/index/274363/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-700025")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("I’d like to share a thought on how we might make AI-generated proofs more useful to mathematicians. Looking at the AI-generated manuscripts on the Riemann hypothesis and Navier–Stokes, I wondered why they were so long and why their arguments seemed so hard to check or build on. As I thought about what made them different from conventional proofs, one possibility occurred to me. If the same calculation or argument is needed in several places but is never packaged as a tool, the proof has to repeat it each time, and the reader has to follow it each time. It would be like going back to an epsilon–delta argument every time you take a derivative, rather than using differentiation as a tool.")

#text("So I tried extracting mathematical tools and ideas from recurring arguments in AI-generated proofs, using them to rewrite the original proofs, and then trying those tools on other problems.")

#text("First, I shortened proofs of the same theorems. For the stability of Brenier maps, I replaced a differentiation argument with a tool that compares moments at two points in time, reducing the proof from 18 pages to 14. In the Riemann manuscript, I cut a net 639 lines of source while preserving the existing theorems. I also wrote a separate proof route that bypasses 1,957 lines of the original argument, provided a selector for the required prime pairs is available.")

#text("I took one of the tools I had used to shorten the Riemann manuscript and developed it further. That work led to proofs answering three questions that earlier papers had left open, concerning power sums, copula correlation, and copula identification.")

#text("I applied the same approach to other AI-generated proofs and developed the resulting tools and ideas for use in quantum mechanics, mathematical finance, and other areas. In quantum mechanics, I obtained necessary and sufficient conditions for the existence of infinite-rank extreme KD-positive states in the abelian-group setting. In mathematical finance, given the distributions of individual losses but no assumptions about how they depend on one another, I found the exact maximum probability that the aggregate loss reaches or exceeds a threshold, under certain conditions. I also improved an implementation of the Sinkhorn algorithm, which is used in real software. In one setting, the new implementation was 3.93 times as fast as the original.")

#text("The reduction is small relative to the full Riemann manuscript. Still, I think that repeatedly looking for reusable tools and using them to replace parts of an argument can make the original proof substantially shorter and leave behind ideas that others can build on.")

#text("If you’d like to see more examples or read the proofs, you can find them on my ")#link("https://ai-proof-research.noblemink64.chatgpt.site/")[#text("research overview page")]#text(". It explains how I look for reusable mathematical tools and ideas in AI-generated proofs and brings together the results and manuscripts by field. I used AI in the research and in drafting this comment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fa9f2f43245bc9a2a9ded5701a4331e7b2296cfc2bb6e9d92483932c05358ed-2b55725f39e52016c2ad16dff019c56919182e64e1ce88e9f53632b25473069f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carlo Gasbarri")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-700032")[#strong[#text("Carlo Gasbarri")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("I recently wrote a paper on the “Role of Mathematicians in Mathematics” which is related to the actual “proof” of GRH. Every comment is welcome.")

#link("https://arxiv.org/abs/2611.29087")[#text("https://arxiv.org/abs/2611.29087")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-700059")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("Alessandro Masullo’s paper is about the Hecke Riemann hypothesis rather than the Generalized Riemann hypothesis. And word seems to be that with the necessary corrections to his paper, Alessandro Masullo has only proven that the Hecke Riemann hypothesis is equivalent to the Generalized Riemann hypothesis.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-700063")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("People on Lean are actually saying Masullo’s proof is a circular argument using a statement equivalent to the extended Riemann hypothesis to prove the extended Riemann hypothesis:")

#link("https://leanprover.zulipchat.com/#narrow/channel/113488-general/topic/Formalising.20Masullo.27s.20proof.20of.20GRH/near/643411854")[#text("https://leanprover.zulipchat.com/#narrow/channel/113488-general/topic/Formalising.20Masullo.27s.20proof.20of.20GRH/near/643411854")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54378113158020677e02a325b66079a3b74168b9c983c41207ca0644d1480d0a-e81d1ad5209fd11d23d671bc368b061e5c0f25890a1f21dfbfe63f99c1ef77af.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ecstatic6d274314ad")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-700152")[#strong[#text("ecstatic6d274314ad")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2026")])]

#text("An article by Alessandro Della Corte on «Artificial Education»:")

#link("https://ilpensierostorico.com/ai-in-education-who-benefits-from-its-inevitable-adoption/")[#text("https://ilpensierostorico.com/ai-in-education-who-benefits-from-its-inevitable-adoption/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-700155")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2026")])]

#text("This looks good: ")#link("https://arxiv.org/abs/2611.31286")[#text("https://arxiv.org/abs/2611.31286")]

#text("By Richard DeMillo and Richard Lipton, two of the authors of the original DLP paper. The third, Alan Perlis, is no longer with us. Abstract:")#link("https://arxiv.org/search/cs?searchtype=author&query=Lipton,+R")[#text("https://arxiv.org/search/cs?searchtype=author&query=Lipton,+R")]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Nearly fifty years ago, DeMillo, Lipton, and Perlis argued that mathematical proofs are not static, isolated structures of formal logic, but the products of a vibrant, evolving social process of human critique, internalization, and shared intuition. In October 2026, OpenAI challenged this thesis by releasing a massive repository of 722 automated mathematical manuscripts, claiming full or partial solutions to 372 longstanding open problems. This paper examines the immediate crisis through the lens of the original DLP framework. We argue that the sudden, automated overproduction of dense, unreadable proofs represents an industrial pollution of the mathematical ecosystem. By examining the three fatal structural pillars of this automated approach (Specification, Regress, and Utility), we demonstrate that decoupling the act of mechanical solving from the human social process of understanding produces a sterile repository of dead logical artifacts.")#linebreak()#text("The resulting industrialization of unexamined manuscripts is self-fulfilling. Flooding the literature guarantees that the finite supply of human attention will lose the race to separate signal from noise. In this sense, posting a result is not the same act as submitting it to the community processes by which mathematics is vetted, digested, and incorporated into shared knowledge.")
]
]
