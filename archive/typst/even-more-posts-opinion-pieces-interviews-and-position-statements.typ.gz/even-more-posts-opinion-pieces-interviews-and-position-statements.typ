// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/
// Converted to Typst by tao2typ: "2026-11-22T14:46:36.587556+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Even more posts, opinion pieces, interviews, and position statements", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Even more posts, opinion pieces, interviews, and position statements")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/")[#text("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-22 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#list(
[#link("https://www.ahmath.org/statements")[#text("AHM Statement on the Announced Proof of the Riemann Hypothesis")]],
[#link("https://www.mathematik.de/dmv-blog/5362-dmv-pr%C3%A4sidium-zur-bedeutung-der-ki-f%C3%BCr-die-mathematik")[#text("Positionen des Präsidiums der Deutschen Mathematiker-Vereinigung (DMV) zur Bedeutung Künstlicher Intelligenz für die Mathematik")]#text(" (Positions of the Presidium of the German Mathematical Society (DMV) on the importance of artificial intelligence for mathematics)")],
[#link("https://www.youtube.com/watch?v=2GsuvsEg28o")[#text("Oxford Mathematics in Conversation on AI – Ben Green and James Maynard with Jan Obloj")]],
[#text("Alexander Givental, “")#link("https://sumizdat.com/homepage/verity.pdf")[#text("The Queen of Sciences in the Age of Silicon")]#text("“")],
[#text("Logan Graves, “")#link("https://logangraves.com/priest-monk-mathematician")[#text("Priest, Monk, and Mathematician")]#text("“")],
[#text("Thor Husfeldt, “")#link("https://www.youtube.com/watch?v=CYMn0QZLzyY")[#text("The Collapse of the Proof Economy")]#text("“")],
[#text("Masoud Kamgarpour, “")#link("https://sites.google.com/site/masoudkomi/whymath")[#text("Why mathematics?")]#text("“")]
)

#text("As always, further links to relevant such pieces can be made as comments to this post.")

#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f448afe442202445794dd733035cd0d78e932fc3a442ffa5ee3adc2e28852d8f-d5c6c038d65ac0e7844d36c370d5acae9e00eee7c4b9cf0f5af7d62351e879e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Una")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699797")[#strong[#text("Una")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Here is a post at proofs and prompts, talking about:")

#text("“")#strong[#text("What if all existing conjectures were solved? How could we move forward?")]#text("“")

#link("https://proofsandprompts.com/2026/11/18/why-the-future-of-mathematics-belongs-to-human-judgment/")[#text("https://proofsandprompts.com/2026/11/18/why-the-future-of-mathematics-belongs-to-human-judgment/")]

#text("I think it’s quite relevant to the recent progress of AI in math, and it does address the role of mathematicians as judges of the importance of new math problems. I think it’s pretty convincing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699805")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("If all existing conjectures were solved, string theorists and loop quantum gravity theorists would get really excited that there are mathematically rigorous bases for their theories.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b7b510e17de4e6675cd023e4cf3f59a066c1c5cd89874954a0ea48433ef61ab-34b42d77aebafd9d9aaf29a4e026152bc224389b462ff75bcd1aa5e71011667e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Celeste")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699798")[#strong[#text("Celeste")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("What a snobbish, retrograde, and out of touch reaction by the AHM!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699807")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#link("https://www.youtube.com/watch?v=-pjm8epal6o")[#text("Elementary school in middle of 11 data centers, surely just fine for human health")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699800")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("It’s time to devalue proofs and verification in mathematics since LLMs and automated theorem provers like Lean are better at those stuff than humans, and start putting more value in understanding and explaining the material.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2026/11/21/even-more-posts-opinion-pieces-interviews-and-position-statements/#comment-699811")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("I agree that it is never good mathematics practice whether you are an accountant or a research mathematician to simply believe stuff just because a computer says it is true.")
]
