// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/02/22/setting-things-up/
// Converted to Typst by tao2typ: "2026-10-14T16:34:50.212262+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Setting things up…", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Setting things up…")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 February 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/02/22/setting-things-up/")[#text("https://terrytao.wordpress.com/2007/02/22/setting-things-up/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("For over eight years (")#link("http://www.math.ucla.edu/%7Etao/whatsnew1999.html")[#text("1999")]#text(", ")#link("http://www.math.ucla.edu/%7Etao/whatsnew2000.html")[#text("2000")]#text(", ")#link("http://www.math.ucla.edu/%7Etao/whatsnew2001.html")[#text("2001")]#text(", ")#link("http://www.math.ucla.edu/%7Etao/whatsnew2002.html")[#text("2002")]#text(", ")#link("http://www.math.ucla.edu/%7Etao/whatsnew2003.html")[#text("2003")]#text(", ")#link("http://www.math.ucla.edu/%7Etao/whatsnew2004.html")[#text("2004")]#text(", ")#link("http://www.math.ucla.edu/%7Etao/whatsnew2005.html")[#text("2005")]#text(", ")#link("http://www.math.ucla.edu/%7Etao/whatsnew2006.html")[#text("2006")]#text(", ")#link("http://www.math.ucla.edu/%7Etao/whatsnew2007.html")[#text("2007")]#text(") I’ve manually set up a “")#link("http://www.math.ucla.edu/%7Etao/whatsnew.html")[#text("What’s new")]#text("” web page off of my ")#link("http://www.math.ucla.edu/%7Etao")[#text("home page")]#text(" to list various research updates and other sundry news items. As an experiment, I’ve decided to move this page to a blog, to try out the various content management tools and make it a little easier to get feedback on things.")

#text("It may well be that this page will eventually evolve into a true blog, with external links, commentary, opinion pieces, and so forth, though this probably would require more time and attention than I actually have available. For now, though, its primary (and rather pedestrian) purpose is the same as with the old incarnation of this page: to announce and describe any new research papers, expository papers, or related material that I have.")

#text("(")#text("Update, ")#text("Feb 25) Moved over to wordpress, due to ")#link("http://faq.wordpress.com/2007/02/18/can-i-put-math-or-equations-in-my-posts/")[#text("better LaTeX support")]#text(".")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7f5141e5675ab3ea9ead83cef65628a8bbaea414269f4d0a8e379c1bc8608a52-7023cd6d088b86f0c884545b9f75616ce04a33d1af94a2a0a6ac2eb83d080909.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terry Tao is now blogging « Perfectly Reasonable Deviations")]], [#link("https://terrytao.wordpress.com/2007/02/22/setting-things-up/#comment-30")[#strong[#text("Terry Tao is now blogging « Perfectly Reasonable Deviations")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2007")])]

#text("[…] reasons why Terry started blogging in wordpress is that wordpress now allows embedding (more info here). Welcome to the blogosphere […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Book version of the blog « What’s new")]], [#link("https://terrytao.wordpress.com/2007/02/22/setting-things-up/#comment-24937")[#strong[#text("Book version of the blog « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2008")])]

#text("[…] January, 2008 in admin, book Tags: announcement, meta It’s now been almost a year since I moved my “What’s new?” page from my home page to this blog. Since then, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/22/setting-things-up/#comment-44541")[#strong[#text("New Year’s To-Do List « Learning Computation")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2010")]

#text("[…] and convert this blog to WordPress. After all, if it’s good enough for Terry Tao’s What’s New, Scott Aaronson’s Shtetl-Optimized, Tyler DiPietro’s PowerUp, and Foxy’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d286623368c887eafaa10f691b2add0d1b8381eec78a3a5283ca677eef00ba7a-157da4c1306e68bd6d25c5d51e9d17af5f144e1991985e06baf6d8c1a2a685b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AD")]], [#link("https://terrytao.wordpress.com/2007/02/22/setting-things-up/#comment-49840")[#strong[#text("AD")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2011")])]

#text("It looks like the texts from the earlier years are gone.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/695029890cc4df1a5cc73e7ccd775bb725d1a61c61e9730330353b28a621a44f-f3e4e542d9ceb6d01844442cc2cb367972bec81ffe583ddcf63f1ba7985cee6a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jérémy")]], [#link("https://terrytao.wordpress.com/2007/02/22/setting-things-up/#comment-474499")[#strong[#text("Jérémy")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2016")])]

#text("No longer working :/")
]
