// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/
// Converted to Typst by tao2typ: "2026-10-14T15:18:39.274571+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Further analysis of the truncated GPY sieve", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Further analysis of the truncated GPY sieve")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 June 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/")[#text("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This post is a continuation of the ")#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps")[#text("previous post on sieve theory")]#text(", which is an ongoing part of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("Polymath8 project")]#text(". As the previous post was getting somewhat full, we are rolling the thread over to the current post. We also take the opportunity to correct some errors in the treatment of the truncated GPY sieve from ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("this previous post")]#text(".")

#text("As usual, we let ")#mi("{x}")#text(" be a large asymptotic parameter, and ")#mi("{w}")#text(" a sufficiently slowly growing function of ")#mi("{x}")#text(". Let ")#mi("{0 < \\varpi < 1/4}")#text(" and ")#mi("{0 < \\delta < 1/4+\\varpi}")#text(" be such that ")#mi("{MPZ[\\varpi,\\delta]}")#text(" holds (see ")#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/")[#text("this previous post")]#text(" for a definition of this assertion). We let ")#mi("{{\\mathcal H}}")#text(" be a fixed admissible ")#mi("{k_0}")#text("-tuple, let ")#mi("{I := [w,x^\\delta]}")#text(", let ")#mi("{{\\mathcal S}_I}")#text(" be the square-free numbers with prime divisors in ")#mi("{I}")#text(", and consider the truncated GPY sieve")

#align(center)[#tao-fit-display[#mitex("\\nu(n) := \\lambda(n)^2")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\lambda(n) := \\sum_{d \\in {\\mathcal S}_I: d|P(n)} \\mu(d) g(\\frac{\\log d}{\\log R})")]]

#text("where ")#mi("{R := x^{1/4+\\varpi}}")#text(", ")#mi("{P}")#text(" is the polynomial")

#align(center)[#tao-fit-display[#mitex("P(n) := \\prod_{h \\in {\\mathcal H}} (n+h),")]]

#text("and ")#mi("{g: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a fixed smooth function supported on ")#mi("{[-1,1]}")#text(". As discussed in ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("the previous post")]#text(", we are interested in obtaining an upper bound of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq 2x} \\nu(n) \\leq (\\alpha+o(1)) (\\frac{W}{\\phi(W)})^{k_0} \\frac{x}{W \\log^{k_0} R}")]]

#text("as well as a lower bound of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq 2x} \\nu(n) \\theta(n+h) \\geq (\\beta+o(1)) (\\frac{W}{\\phi(W)})^{k_0} \\frac{x}{W \\log^{k_0-1} R}")]]

#text("for all ")#mi("{h \\in {\\mathcal H}}")#text(" (where ")#mi("{\\theta(n) = \\log n}")#text(" when ")#mi("{n}")#text(" is prime and ")#mi("{\\theta(n)=0}")#text(" otherwise), since this will give the conjecture ")#mi("{DHL[k_0,2]}")#text(" (i.e. infinitely many prime gaps of size at most ")#mi("{k_0}")#text(") whenever ")#metadata(none) <tao-87cfd62083178f54058c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("1+4\\varpi > \\frac{4\\alpha}{k_0 \\beta}.")]]

#text("It turns out we in fact have precise asymptotics ")#metadata(none) <tao-f81ab872625c131d92e7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{x \\leq n \\leq 2x} \\nu(n) = (\\alpha+o(1)) (\\frac{W}{\\phi(W)})^{k_0} \\frac{x}{W \\log^{k_0} R}")]]

#text("and ")#metadata(none) <tao-f096890dbb1b514cf178>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_{x \\leq n \\leq 2x} \\nu(n) \\theta(n+h) = (\\beta+o(1)) (\\frac{W}{\\phi(W)})^{k_0} \\frac{x}{W \\log^{k_0} R}")]]

#text("although the exact formulae for ")#mi("{\\alpha,\\beta}")#text(" are a little complicated. (The fact that ")#mi("{\\alpha,\\beta}")#text(" could be computed exactly was already anticipated in ")#link("http://annals.math.princeton.edu/wp-content/uploads/YitangZhang.pdf")[#text("Zhang’s paper")]#text("; see the remark on page 24.) We proceed as in ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang")[#text("the previous post")]#text(". Indeed, from the arguments in that post, ")#link(<tao-f81ab872625c131d92e7>)[#text("(2)")]#text(" is equivalent to ")#metadata(none) <tao-d1372818d61d68676e19>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{d_1,d_2 \\in {\\mathcal S}_I} \\mu(d_1) g(\\frac{\\log d_1}{\\log R}) \\mu(d_2) g(\\frac{\\log d_2}{\\log R}) \\frac{k_0^{\\Omega([d_1,d_2])}}{[d_1,d_2]}")]]

#align(center)[#tao-fit-display[#mitex("= (\\alpha + o(1)) (\\frac{W}{\\phi(W)})^{k_0} \\log^{-k_0} R")]]

#text("and ")#link(<tao-f096890dbb1b514cf178>)[#text("(3)")]#text(" is similarly equivalent to ")#metadata(none) <tao-aea721c039a808c24a14>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_{d_1,d_2 \\in {\\mathcal S}_I} \\mu(d_1) g(\\frac{\\log d_1}{\\log R}) \\mu(d_2) g(\\frac{\\log d_2}{\\log R}) \\frac{(k_0-1)^{\\Omega([d_1,d_2])}}{[d_1,d_2]}")]]

#align(center)[#tao-fit-display[#mitex("= (\\beta + o(1)) (\\frac{W}{\\phi(W)})^{k_0-1} \\log^{-k_0+1} R.")]]

#text("Here ")#mi("{\\Omega(d)}")#text(" is the number of prime factors of ")#mi("{d}")#text(".")

#text("We will work for now with ")#link(<tao-d1372818d61d68676e19>)[#text("(4)")]#text(", as the treatment of ")#link(<tao-aea721c039a808c24a14>)[#text("(5)")]#text(" is almost identical.")

#text("We would now like to replace the truncated interval ")#mi("{I = [w,x^\\delta]}")#text(" with the untruncated interval ")#mi("{I \\cup J = [w,\\infty)}")#text(", where ")#mi("{J = (x^\\delta,\\infty)}")#text(". Unfortunately this replacement was not quite done correctly in the previous post, and this will now be corrected here. We first observe that if ")#mi("{F(d_1,d_2)}")#text(" is any finitely supported function, then by Möbius inversion we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2 \\in {\\mathcal S}_I} F(d_1,d_2) = \\sum_{d_1,d_2 \\in {\\mathcal S}_{I \\cup J}} F(d_1,d_2) \\sum_{a \\in {\\mathcal S}_J} \\mu(a) 1_{a|[d_1,d_2]}.")]]

#text("Note that ")#mi("{a|[d_1,d_2]}")#text(" if and only if we have a factorisation ")#mi("{d_1 = a_1 d^{\\prime}_1}")#text(", ")#mi("{d_2 = a_2 d^{\\prime}_2}")#text(" with ")#mi("{[a_1,a_2] = a}")#text(" and ")#mi("{d^{\\prime}_1 d^{\\prime}_2}")#text(" coprime to ")#mi("{a_1 a_2}")#text(", and that this factorisation is unique. From this, we see that we may rearrange the previous expression as")

#align(center)[#tao-fit-display[#mitex("\\sum_{a_1,a_2 \\in {\\mathcal S}_J} \\mu( [a_1,a_2] ) \\sum_{d^{\\prime}_1,d^{\\prime}_2 \\in {\\mathcal S}_{I \\cup J}: (d^{\\prime}_1 d^{\\prime}_2, a_1 a_2) = 1} F( a_1 d^{\\prime}_1, a_2 d^{\\prime}_2 ).")]]

#text("Applying this to ")#link(<tao-d1372818d61d68676e19>)[#text("(4)")]#text(", and relabeling ")#mi("{d^{\\prime}_1,d^{\\prime}_2}")#text(" as ")#mi("{d_1,d_2}")#text(", we conclude that the left-hand side of ")#link(<tao-d1372818d61d68676e19>)[#text("(4)")]#text(" is equal to")

#align(center)[#tao-fit-display[#mitex("\\sum_{a_1,a_2 \\in {\\mathcal S}_J} \\mu( [a_1,a_2] ) \\sum_{d_1,d_2 \\in {\\mathcal S}_{I \\cup J}: (d_1d_2,a_1a_2)=1}")]]

#align(center)[#tao-fit-display[#mitex("\\mu(a_1d_1) g(\\frac{\\log a_1d_1}{\\log R}) \\mu(a_2d_2) g(\\frac{\\log a_2d_2}{\\log R}) \\frac{k_0^{\\Omega([a_1 d_1,a_2 d_2])}}{[a_1 d_1,a_2 d_2]}")]]

#text("which may be rearranged as ")#metadata(none) <tao-15f3b852d2465ae56ff5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{a_1,a_2 \\in {\\mathcal S}_J} \\frac{\\mu( (a_1,a_2) ) k_0^{\\Omega([a_1,a_2])}}{[a_1,a_2]} \\sum_{d_1,d_2\\in {\\mathcal S}_{I \\cup J}: (d_1d_2,a_1a_2)=1}")]]

#align(center)[#tao-fit-display[#mitex("\\mu(d_1) g(\\frac{\\log a_1d_1}{\\log R}) \\mu(d_2) g(\\frac{\\log a_1 d_2}{\\log R}) \\frac{k_0^{\\Omega([d_1,d_2])}}{[d_1, d_2]}.")]]

#text("This is almost the same formula that we had in ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang")[#text("the previous post")]#text(", except that the Möbius function ")#mi("{\\mu((a_1,a_2))}")#text(" of the greatest common divisor ")#mi("{(a_1,a_2)}")#text(" of ")#mi("{a_1,a_2}")#text(" was missing, and also the coprimality condition ")#mi("{(d_1d_2,a_1a_2)=1}")#text(" was not handled properly in the previous post.")

#text("We may now eliminate the condition ")#mi("{(d_1d_2,a_1a_2)=1}")#text(" as follows. Suppose that there is a prime ")#mi("{p_* \\in J}")#text(" that divides both ")#mi("{d_1d_2}")#text(" and ")#mi("{a_1a_2}")#text(". The expression")

#align(center)[#tao-fit-display[#mitex("\\sum_{a_1,a_2 \\in {\\mathcal S}_J} \\frac{k_0^{\\Omega([a_1,a_2])}}{[a_1,a_2]} \\sum_{d_1,d_2 \\in {\\mathcal S}_{I \\cup J}: p_* | (d_1d_2,a_1a_2)}")]]

#align(center)[#tao-fit-display[#tao-math("\\left|g(\\frac{\\log a_1d_1}{\\log R})\\right| |g(\\frac{\\log a_1 d_2}{\\log R})| \\frac{k_0^{\\Omega([d_1,d_2])}}{[d_1, d_2]}", block: true)]]

#text("can then be bounded by")

#align(center)[#tao-fit-display[#mitex("\\ll \\sum_{a_1,a_2} \\sum_{d_1,d_2: p_* | (d_1d_2,a_1a_2)} \\frac{k_0^{\\Omega([a_1,a_2])}}{[a_1,a_2]} \\frac{k_0^{\\Omega([d_1,d_2])}}{[d_1, d_2]} (a_1 a_2 d_1 d_2)^{-1/\\log R}")]]

#text("which may be factorised as")

#align(center)[#tao-fit-display[#mitex("\\ll \\frac{1}{p_*^2} \\prod_p (1 + \\frac{O(1)}{p^{1+1/\\log R}})")]]

#text("which by Mertens’ theorem (or the simple pole of ")#mi("{\\zeta(s)}")#text(" at ")#mi("{s=1}")#text(") is")

#align(center)[#tao-fit-display[#mitex("\\ll \\frac{\\log^{O(1)} R}{p_*^2}.")]]

#text("Summing over all ")#mi("{p_* > x^\\varpi}")#text(" gives a negligible contribution to ")#link(<tao-15f3b852d2465ae56ff5>)[#text("(6)")]#text(" for the purposes of ")#link(<tao-d1372818d61d68676e19>)[#text("(4)")]#text(". Thus we may effectively replace ")#link(<tao-15f3b852d2465ae56ff5>)[#text("(6)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\sum_{a_1,a_2 \\in {\\mathcal S}_J} \\frac{\\mu( (a_1,a_2) ) k_0^{\\Omega([a_1,a_2])}}{[a_1,a_2]} \\sum_{d_1,d_2\\in {\\mathcal S}_{I \\cup J}}")]]

#align(center)[#tao-fit-display[#mitex("\\mu(d_1) g(\\frac{\\log a_1d_1}{\\log R}) \\mu(d_2) g(\\frac{\\log a_1 d_2}{\\log R}) \\frac{k_0^{\\Omega([d_1,d_2])}}{[d_1, d_2]}.")]]

#text("The inner summation can be treated using Proposition 10 of ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang")[#text("the previous post")]#text(". We can then reduce ")#link(<tao-d1372818d61d68676e19>)[#text("(4)")]#text(" to ")#metadata(none) <tao-c9b1366e59ac8faa5f95>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\sum_{a_1,a_2 \\in {\\mathcal S}_J} \\frac{\\mu( (a_1,a_2) ) k_0^{\\Omega([a_1,a_2])}}{[a_1,a_2]} G_{k_0}( \\frac{\\log a_1}{\\log R}, \\frac{\\log a_2}{\\log R} ) = \\alpha+o(1)")]]

#text("where ")#mi("{G_{k_0}}")#text(" is the function")

#align(center)[#tao-fit-display[#mitex("G_{k_0}(t_1,t_2) := \\int_0^1 g^{(k_0)}(t+t_1) g^{(k_0)}(t+t_2) \\frac{t^{k_0-1}}{(k_0-1)!}\\ dt.")]]

#text("Note that ")#mi("{G}")#text(" vanishes if ")#mi("{t_1 \\geq 1}")#text(" or ")#mi("{t_2 \\geq 1}")#text(". In practice, we will work with functions ")#mi("{g}")#text(" in which ")#mi("{g^{(k_0)}}")#text(" has a definite sign (in our normalisations, ")#mi("{g^{(k_0)}}")#text(" will be non-positive), making ")#mi("{G_{k_0}}")#text(" non-negative.")

#text("We rewrite the left-hand side of ")#link(<tao-c9b1366e59ac8faa5f95>)[#text("(7)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{a \\in {\\mathcal S}_J} \\frac{k_0^{\\Omega(a)}}{a} \\sum_{a_1,a_2: [a_1,a_2] = a} \\mu((a_1,a_2)) G_{k_0}( \\frac{\\log a_1}{\\log R}, \\frac{\\log a_2}{\\log R} ).")]]

#text("We may factor ")#mi("{a = p_1 \\ldots p_n}")#text(" for some ")#mi("{x^\\delta < p_1 < \\ldots < p_n}")#text(" with ")#mi("{p_1 \\ldots p_n \\leq R}")#text("; in particular, ")#mi("{n < \\frac{1 + 4\\varpi}{4\\delta}}")#text(". The previous expression now becomes")

#align(center)[#tao-fit-display[#mitex("\\sum_{0 \\leq n < \\frac{1+4\\varpi}{4\\delta}} k_0^n \\sum_{x^\\delta < p_1 < \\ldots < p_n} \\frac{1}{p_1 \\ldots p_n}")]]

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\{1,\\ldots,n\\} = S \\cup T} (-1)^{\\left|S \\cap T\\right|} G_{k_0}( \\sum_{i \\in S} \\frac{\\log p_i}{\\log R}, \\sum_{j \\in T} \\frac{\\log p_j}{\\log R} ).", block: true)]]

#text("Using Mertens’ theorem, we thus conclude an exact formula for ")#mi("{\\alpha}")#text(", and similarly for ")#mi("{\\beta}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Exact formula)")]#text(" We have")

#align(center)[#tao-fit-display[#mitex("\\alpha = \\sum_{0 \\leq n < \\frac{1+4\\varpi}{4\\delta}} k_0^n \\int_{\\frac{4\\delta}{1+4\\varpi} < t_1 < \\ldots < t_n} G_{k_0,n}(t_1,\\ldots,t_n) \\frac{dt_1 \\ldots dt_n}{t_1 \\ldots t_n}")]]

#text("where")

#align(center)[#tao-fit-display[#tao-math("G_{k_0,n}(t_1,\\ldots,t_n) := \\sum_{\\{1,\\ldots,n\\} = S \\cup T} (-1)^{\\left|S \\cap T\\right|} G_{k_0}( \\sum_{i \\in S} t_i, \\sum_{j \\in T} t_j ).", block: true)]]

#text("Similarly we have")

#align(center)[#tao-fit-display[#mitex("\\beta = \\sum_{0 \\leq n < \\frac{1+4\\varpi}{4\\delta}} (k_0-1)^n \\int_{\\frac{4\\delta}{1+4\\varpi} < t_1 < \\ldots < t_n} G_{k_0-1,n}(t_1,\\ldots,t_n) \\frac{dt_1 \\ldots dt_n}{t_1 \\ldots t_n}")]]

#text("where ")#mi("{G_{k_0-1}}")#text(" and ")#mi("{G_{k_0-1,n}}")#text(" are defined similarly to ")#mi("{G_{k_0}}")#text(" and ")#mi("{G_{k_0,n}}")#text(" by replacing all occurrences of ")#mi("{k_0}")#text(" with ")#mi("{k_0-1}")#text(".")
]

#text("These formulae are unwieldy. However if we make some monotonicity hypotheses, namely that ")#mi("{g^{(k_0-1)}}")#text(" is positive, ")#mi("{g^{(k_0)}}")#text(" is negative, and ")#mi("{g^{(k_0+1)}}")#text(" is positive on ")#mi("{[0,1)}")#text(", then we can get some good estimates on the ")#mi("{G_{k_0}, G_{k_0-1}}")#text(" (which are now non-negative functions) and hence on ")#mi("{\\alpha,\\beta}")#text(". Namely, if ")#mi("{g^{(k_0)}}")#text(" is negative but increasing then we have")

#align(center)[#tao-fit-display[#mitex("-g^{(k_0)}(t+t_1) \\leq -g^{(k_0)}(\\frac{t}{1-t_1})")]]

#text("for ")#mi("{0 \\leq t_1 < 1}")#text(" and ")#mi("{t \\in [0,1]}")#text(", which implies that")

#align(center)[#tao-fit-display[#mitex("G_{k_0}(t_1,t_1) \\leq (1-t_1)_+^{k_0} G_{k_0}(0,0)")]]

#text("for any ")#mi("{t_1 \\geq 0}")#text(". A similar argument in fact gives")

#align(center)[#tao-fit-display[#mitex("G_{k_0}(t_1+t_2,t_1+t_2) \\leq (1-t_1)_+^{k_0} G_{k_0}(t_2,t_2)")]]

#text("for any ")#mi("{t_1,t_2 \\geq 0}")#text(". Iterating this we conclude that")

#align(center)[#tao-fit-display[#mitex("G_{k_0}(\\sum_{i \\in S} t_i, \\sum_{i \\in S} t_i) \\leq (\\prod_{i \\in S} (1-t_i)_+^{k_0}) G_{k_0}(0,0)")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("G_{k_0}(\\sum_{i \\in T} t_i, \\sum_{i \\in T} t_i) \\leq (\\prod_{i \\in T} (1-t_i)_+^{k_0}) G_{k_0}(0,0).")]]

#text("From Cauchy-Schwarz we thus have")

#align(center)[#tao-fit-display[#mitex("G_{k_0}( \\sum_{i \\in S} t_i, \\sum_{i \\in T} t_i ) \\leq (\\prod_{i=1}^n (1 - t_i)_+^{k_0/2}) G_{k_0}(0,0).")]]

#text("Observe from the binomial formula that of the ")#mi("{3^n}")#text(" pairs ")#mi("{(S,T)}")#text(" with ")#mi("{S \\cup T = \\{1,\\ldots,n\\}}")#text(", ")#mi("{\\frac{3^n+1}{2}}")#text(" of them have ")#tao-math("{\\left|S \\cap T\\right|}", block: false)#text(" even, and ")#mi("{\\frac{3^n-1}{2}}")#text(" of them have ")#tao-math("{\\left|S \\cap T\\right|}", block: false)#text(" odd. We thus have ")#metadata(none) <tao-d1a5ac9a015fac2ef7b3>

#tao-aligned(keep: true)[


#tao-math("-\\frac{3^n-1}{2} (\\prod_{i=1}^n (1 - t_i)_+^{k_0/2}) G_{k_0}(0,0)  & \\leq G_{k_0,n}(t_1,\\ldots,t_n)", block: true, numbering: n => [#text("(8)")])



#tao-math(" & \\leq \\frac{3^n+1}{2} (\\prod_{i=1}^n (1 - t_i)_+^{k_0/2}) G_{k_0}(0,0).", block: true)
]

#text("We have thus established the upper bound ")#metadata(none) <tao-ca978112ca1bbdcafac2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\alpha \\leq G_{k_0}(0,0) (1 + \\kappa)")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\kappa := \\sum_{1 \\leq n < \\frac{1+4\\varpi}{4\\delta}} \\frac{3^n+1}{2} k_0^n \\int_{\\frac{4\\delta}{1+4\\varpi} < t_1 < \\ldots < t_n} (\\prod_{i=1}^n (1 - t_i)_+^{k_0/2}) \\frac{dt_1 \\ldots dt_n}{t_1 \\ldots t_n}.")]]

#text("By symmetry we may factorise")

#align(center)[#tao-fit-display[#mitex("\\kappa := \\sum_{1 \\leq n < \\frac{1+4\\varpi}{4\\delta}} \\frac{3^n+1}{2} \\frac{k_0^n}{n!} ( \\int_{\\frac{4\\delta}{1+4\\varpi} < t \\leq 1} (1-t)^{k_0/2}\\ \\frac{dt}{t})^n.")]]

#text("The expression ")#mi("{\\kappa}")#text(" is explicitly computable for any given ")#mi("{\\varpi,\\delta,k_0}")#text(". Following ")#link("http://arxiv.org/abs/1306.1497")[#text("the recent preprint of Pintz")]#text(", one can get a slightly looser, but cleaner, bound by using the upper bound")

#align(center)[#tao-fit-display[#mitex("1-t \\leq \\exp(-t)")]]

#text("and so")

#align(center)[#tao-fit-display[#mitex("\\kappa \\leq \\sum_{1 \\leq n < \\frac{1+4\\varpi}{4\\delta}} \\frac{3^n+1}{2} \\frac{k_0^n}{n!} (\\int_{4\\delta/(1+4\\varpi)}^\\infty \\exp( - \\frac{k_0}{2} t )\\ \\frac{dt}{t})^n.")]]

#text("Note that")

#tao-aligned(keep: true)[


#tao-math("\\int_{4\\delta/(1+4\\varpi)}^\\infty \\exp( - \\frac{k_0}{2} t )\\ \\frac{dt}{t}  & = \\int_1^\\infty \\exp( - \\frac{2k_0 \\delta}{1+4\\varpi} t)\\ \\frac{dt}{t}", block: true)



#tao-math(" & < \\int_1^\\infty \\exp( - \\frac{2k_0 \\delta}{1+4\\varpi} t)\\ dt", block: true)



#tao-math(" & = \\frac{1+4\\varpi}{2k_0\\delta} \\exp( - \\frac{2k_0 \\delta}{1+4\\varpi} )", block: true)
]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("\\kappa \\leq \\tilde \\kappa")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\tilde \\kappa := \\sum_{1 \\leq n < \\frac{1+4\\varpi}{4\\delta}} \\frac{1}{n!} \\frac{3^n+1}{2} (\\frac{1+4\\varpi}{2\\delta} \\exp( - \\frac{2k_0 \\delta}{1+4\\varpi} ))^n.")]]

#text("In practice we expect the ")#mi("{n=1}")#text(" term to dominate, thus we have the heuristic approximation")

#align(center)[#tao-fit-display[#mitex("\\kappa \\lessapprox \\frac{1+4\\varpi}{\\delta} \\exp( - \\frac{2k_0 \\delta}{1+4\\varpi} ).")]]

#text("Now we turn to the estimation of ")#mi("{\\beta}")#text(". We have an analogue of ")#link(<tao-d1a5ac9a015fac2ef7b3>)[#text("(8)")]#text(", namely")

#tao-aligned(keep: true)[


#tao-math("-\\frac{3^n-1}{2} (\\prod_{i=1}^n (1-t_i)^{(k_0-1)/2}) G_{k_0-1}(0,0)  & \\leq G_{k_0-1,n}(t_1,\\ldots,t_n)", block: true)



#tao-math(" & \\leq \\frac{3^n+1}{2} (\\prod_{i=1}^n (1-t_i)^{(k_0-1)/2}) G_{k_0-1}(0,0).", block: true)
]

#text("But we have an improvment in the lower bound in the ")#mi("{n=1}")#text(" case, because in this case we have")

#align(center)[#tao-fit-display[#mitex("G_{k_0-1,n}(t) = G_{k_0-1}(t,0) + G_{k_0-1}(0,t) - G_{k_0-1}(t,t).")]]

#text("From the positive decreasing nature of ")#mi("{g^{(k_0-1)}}")#text(" we see that ")#mi("{G_{k_0-1}(t,t) \\leq G_{k_0-1}(t,0)}")#text(" and so ")#mi("{G_{k_0-1,n}(t)}")#text(" is non-negative and can thus be ignored for the purposes of lower bounds. (There are similar improvements available for higher ")#mi("{n}")#text(" but this seems to only give negligible improvements and will not be pursued here.) Thus we obtain ")#metadata(none) <tao-3e23e8160039594a3389>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\beta \\geq G_{k_0-1}(0,0) (1-\\kappa^{\\prime})")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\kappa^{\\prime} := \\sum_{2 \\leq n < \\frac{1+4\\varpi}{4\\delta}} \\frac{3^n-1}{2} \\frac{(k_0-1)^n}{n!}")]]

#align(center)[#tao-fit-display[#mitex("(\\int_{4\\delta/(1+4\\varpi)}^1 (1-t)^{(k_0-1)/2}\\ \\frac{dt}{t})^n.")]]

#text("Estimating ")#mi("{\\kappa^{\\prime}}")#text(" similarly to ")#mi("{\\kappa}")#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("\\kappa^{\\prime} \\leq \\tilde \\kappa^{\\prime}")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\tilde \\kappa^{\\prime} := \\sum_{2 \\leq n < \\frac{1+4\\varpi}{4\\delta}} \\frac{1}{n!} \\frac{3^n-1}{2} (\\frac{1+4\\varpi}{2\\delta} \\exp( - \\frac{2(k_0-1) \\delta}{1+4\\varpi} ))^n.")]]

#text("By ")#link(<tao-ca978112ca1bbdcafac2>)[#text("(9)")]#text(", ")#link(<tao-3e23e8160039594a3389>)[#text("(10)")]#text(", we see that the condition ")#link(<tao-87cfd62083178f54058c>)[#text("(1)")]#text(" is implied by")

#align(center)[#tao-fit-display[#mitex("(1+4\\varpi) (1-\\kappa^{\\prime}) > \\frac{4G_{k_0}(0,0)}{k_0 G_{k_0-1}(0,0)} (1+\\kappa).")]]

#text("By Theorem 14 and Lemma 15 of ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang")[#text("this previous post")]#text(", we may take the ratio ")#mi("{\\frac{4G_{k_0}(0,0)}{k_0 G_{k_0-1}(0,0)}}")#text(" to be arbitrarily close to ")#mi("{\\frac{j_{k_0-2}^2}{k_0(k_0-1)}}")#text(". We conclude the following theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" Let ")#mi("{0 < \\varpi < 1/4}")#text(" and ")#mi("{0 < \\delta < 1/4 + \\varpi}")#text(" be such that ")#mi("{MPZ[\\varpi,\\delta]}")#text(" holds. Let ")#mi("{k_0 \\geq 2}")#text(" be an integer, define")

#align(center)[#tao-fit-display[#mitex("\\kappa := \\sum_{1 \\leq n < \\frac{1+4\\varpi}{4\\delta}} \\frac{3^n+1}{2} \\frac{k_0^n}{n!} (\\int_{4\\delta/(1+4\\varpi)}^1 (1-t)^{k_0/2}\\ \\frac{dt}{t})^n")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\kappa^{\\prime} := \\sum_{2 \\leq n < \\frac{1+4\\varpi}{4\\delta}} \\frac{3^n-1}{2} \\frac{(k_0-1)^n}{n!}")]]

#align(center)[#tao-fit-display[#mitex("(\\int_{4\\delta/(1+4\\varpi)}^1 (1-t)^{(k_0-1)/2}\\ \\frac{dt}{t})^n")]]

#text("and suppose that")

#align(center)[#tao-fit-display[#mitex("(1+4\\varpi) (1-\\kappa^{\\prime}) > \\frac{j_{k_0-2}^2}{k_0(k_0-1)} (1+\\kappa).")]]

#text("Then ")#mi("{DHL[k_0,2]}")#text(" holds.")
]

#text("As noted earlier, we heuristically have")

#align(center)[#tao-fit-display[#mitex("\\tilde \\kappa \\approx \\frac{1+4\\varpi}{\\delta} \\exp( - \\frac{2k_0 \\delta}{1+4\\varpi} )")]]

#text("and ")#mi("{\\tilde \\kappa^{\\prime}}")#text(" is negligible. This constraint is a bit better than the previous condition, in which ")#mi("{\\tilde \\kappa^{\\prime}}")#text(" was not present and ")#mi("{\\tilde \\kappa}")#text(" was replaced by a quantity roughly of the form ")#mi("{2 \\log(2) k_0 \\exp( - \\frac{2k_0 \\delta}{1+4\\varpi})}")#text(".")

#heading(level: 1)[#text("Comments (91)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234106")[#strong[#text("REMIDI UAS SEMESTER 2")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")]

#text("[…] Further analysis of the truncated GPY sieve This post is a continuation of the previous post on sieve theory, which is an ongoing part of the Polymath8 project. As the previous post was getting somewhat full, we are rolling the thread over to the current post. We also take the opportunity to correct some errors in the treatment of the truncat … Wed, 12 Jun 2013 00:54:00 CDT more info… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The prime tuples conjecture, sieve theory, and the work of Goldston-Pintz-Yildirim, Motohashi-Pintz, and Zhang | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234107")[#strong[#text("The prime tuples conjecture, sieve theory, and the work of Goldston-Pintz-Yildirim, Motohashi-Pintz, and Zhang | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("[…] The above argument is not quite correct; a corrected (and improved) version is given at this newer post.] The product is by e.g. Mertens’ theorem, while . So the contribution of this case is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234113")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("If it all holds up, using the exponential integral directly instead of the approximant (this saves about 5%), I get that ")#mi("(\\omega,\\delta)=(1/891,7/17028)")#text(" and ")#mi("k_0=22951")#text(" is best. I have ")#mi("\\tilde\\kappa\\approx 1.6147592\\cdot 10^{-5}")#text(" rather than ")#mi("\\tilde\\kappa\\approx 1.69674148\\cdot 10^{-5}")#text(" that comes from the approximant.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234117")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("The relative error in the exponential integral approximation is about ")#mi("(1+4\\omega)/2k_0\\delta\\approx 1/18.8")#text(" (5%). On the other hand, with ")#mi("(1-x)\\le e^{-x}")#text(" as following Pintz, I think the main effect is at ")#mi("x")#text(" as above, so only lose 0.15%.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234131")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("What is the value of ")#mi("\\tilde \\kappa^{\\prime}")#text("? Also, what do you get with the improved ")#mi("\\kappa")#text(" and analogous ")#mi("\\kappa^{\\prime}")#text(" that I suggested below? My preliminary calculation tells that we save about 2%.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234224")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("The ")#mi("\\tilde\\kappa^{\\prime}")#text(" would be about the square, or ")#mi("10^{-10}")#text(". There is really no reason to make any approximations in the ")#mi("n=1")#text(" case, which should dominate, for there the integrals are easy. But you’ve probably worked this all out by now.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234240")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("Yes, I have now understood this. Thank you!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234124")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("This is very nice and clean. We can improve on ")#mi("\\kappa")#text(" as follows. By a similar argument as in the post,")

#mi("G_{k_0}(t_1+t_2,t_1+t_2) \\leq (1-t_1)_+^{k_0} G_{k_0}(t_2,t_2)")#text(".")

#text("By Cauchy,")

#mi("G_{k_0}( \\sum_{i \\in S} t_i, \\sum_{i \\in T} t_i )\\leq G_{k_0}^{1/2}( \\sum_{i \\in S} t_i, \\sum_{i \\in S} t_i )G_{k_0}^{1/2}( \\sum_{i \\in T} t_i, \\sum_{i \\in T} t_i ).")

#text("Applying the first observation iteratively on both factors,")

#mi("G_{k_0}( \\sum_{i \\in S} t_i, \\sum_{i \\in T} t_i ) \\leq (\\prod_{i=1}^n(1 - t_i)_+^{k_0/2}) G_{k_0}(0,0).")

#text("Therefore in (8) and in the definition of ")#mi("\\kappa")#text(" we can lower ")#mi("(1 - \\frac{1}{2} \\sum_{i=1}^n t_i)_+^{k_0}")#text(" to ")#mi("\\prod_{i=1}^n(1 - t_i)_+^{k_0/2}")#text(", and for the new ")#mi("\\kappa")#text(" we infer")

#mi("\\kappa \\leq \\sum_{1 \\leq n < \\frac{1+4\\varpi}{4\\delta}} \\frac{3^n+1}{2} \\frac{k_0^n}{n!} (\\int_{4\\delta/(1+4\\varpi)}^1 (1 - t)^{k_0/2}\\ \\frac{dt}{t})^n")#text(".")

#text("From here we can proceed as in the post, using ")#mi("(1-t)_+<e^{-t}")#text(", but the integral should be straightforward numerically.")

#text("Some typos:")

#text("1. In (3) the factor ")#mi("\\theta(n+h)")#text(" is missing.")

#text("2. \"")#mi("d^{\\prime}_1,d^{\\prime}_2")#text(" coprime to ")#mi("[a_1,a_2]")#text("\" should be \"")#mi("d^{\\prime}_1,d^{\\prime}_2")#text(" coprime to ")#mi("a")#text("\".")

#text("3. \"which are now non-negative functions\" should be \"which are now functions of constant sign\".")

#text("4. Three displays above (8), ")#mi("(1-t_2)_+^{-k_0/2}")#text(" should be ")#mi("(1-t_2)_+^{k_0/2}")#text(".")

#emph[#text("[Corrections 1-4 implemented, thanks. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234125")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("Actually the upper bound I stated for the new ")#mi("\\kappa")#text(" is an identity. All in all, the above modification simplifies the proof and produces a better result.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234141")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("Can you please state explicitly the identity? (because there is a stable numerical expression for the last one dimensional integral – showing it to be a remainder term for Taylor series approximation of the log function, which gives a new improved upper bound for the integral in terms of a power of ")#mi("\\delta / (1/4 + \\varpi)")#text(" instead of the current exponential bound.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234145")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#mi("\\kappa = \\sum_{1 \\leq n < \\frac{1+4\\varpi}{4\\delta}} \\frac{3^n+1}{2} \\frac{k_0^n}{n!} (\\int_{4\\delta/(1+4\\varpi)}^1 (1 - t)^{k_0/2}\\ \\frac{dt}{t})^n")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234160")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("Thanks. Consider now the integral above, denoting ")#mi("t_0")#text(" for its lower bound and ")#mi("k")#text(" for the exponent ")#mi("k_0 / 2")#text(".")#linebreak()#text(" The new upper bound is most simply obtained by replacing in the integrand ")#mi("1/ t")#text(" by ")#mi("1/ t_0")#text(".")#linebreak()#text(" Note that for large ")#mi("t_0")#text(", the resulting new bound")#linebreak()#text(" ")#mi("(1 - t_0)^{k + 1} / [(k + 1) t_0)]")#text(" should be better then the exponential one since it captures better the integrand behavior for large values of t.")

#text("Note that by trying directly to evaluate the integral by expanding")#linebreak()#text(" ")#mi("(1 - t)^k")#text(" in the integral and then integrate termwise, may lead to serious numerical problems since the alternating large binomial coefficients may lead to a significant loss of precision.")#linebreak()#text(" Fortunately the above numerical instability can be avoided by using the substitution ")#mi("u = 1 - t")#text(" so the integrand becomes")#linebreak()#text(" ")#mi("1/(1-u) - \\sum_{j=0}^{k -1} u^j")#text(" , so by term-wise integration it follows that the integral is in fact the remainder term for the k-th degree Taylor series approximation of ")#mi("-\\log(1-u)")#text(" in powers of u at")#linebreak()#text(" ")#mi("u = 1 - t_0")#text(", which implies the same new bound above.")

#text("Practical remark: it is important to note that all the coefficients of the above Taylor series approximation of ")#mi("-\\log (1-u)")#text(" in powers of")#linebreak()#text(" ")#mi("u")#text(" are positive and slowly decreasing so its computation at")#linebreak()#text(" ")#mi("u= 1 - t_0")#text(" should be numerically stable!")

#text("Final remark: in your integral bound, ")#mi("k = k_0 /2")#text(" which is integer")#linebreak()#text(" only for EVEN ")#mi("k_0")#text(" (otherwise, it is expressed by incomplete Beta function which can’t be expressed by a finite sum of elementary functions as above, but the new bound still holds!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234167")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("@Eytan: At this point I leave the calculation to computers. SAGE does a good job in evaluating such integrals numerically. For example, for ")#mi("(\\varpi,\\delta,k_0)=(\\frac{1}{891},\\frac{7}{17028},22949)")#text(" I get")

#mi("I:=k_0\\int_{4\\delta/(1+4\\varpi)}^1 (1 - t)^{k_0/2}\\ \\frac{dt}{t}\\approx 7.95032915715\\times 10^{-6}")#text(",")

#text("and ")#mi("1+\\kappa")#text(" is essentially ")#mi("(e^{3I}+e^I)/2")#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234175")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("Thanks for this! One amusing thing is that the bound ")#mi("\\prod_{i=1}^n (1-t_i)_+^{k_0/2}")#text(" is in fact very slightly worse than ")#mi("(1-\\sum_{i=1}^n t_i/2)^{k_0}")#text(", but the product formulation ends up being so much cleaner that it is easier to see the opportunity to improve upon the bound involving the exponential function. The above estimates also reveal that the (upper bounds on the) terms in which ")#mi("S \\cap T \\neq \\emptyset")#text(" are smaller than the others by an additional factor of at least ")#mi("(1 - \\frac{4\\delta}{1+4\\varpi})^{k_0/2}")#text(", which in principle can improve the ")#mi("\\frac{3^n+1}{2}")#text(", ")#mi("\\frac{3^n-1}{2}")#text(" factors to be close to ")#mi("2^n, 0")#text(" respectively for ")#mi("n \\geq 2")#text(", although this only leads to negligible improvements at the cost of a messier formula.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234234")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("1. Amusing indeed! In fact the optimized version of")

#mi("G_{k_0}(t_1+t_2,t_1+t_2) \\leq (1-t_1)_+^{k_0} G_{k_0}(t_2,t_2)")

#text("reads")

#mi("G_{k_0}(t_1+t_2,t_1+t_2) \\leq (\\frac{1-t_1-t_2}{1-t_2})_+^{k_0} G_{k_0}(t_2,t_2)")

#text("which by induction recovers the original")

#mi("G_{k_0}(\\sum_{i=1}^n t_i,\\sum_{i=1}^n t_i) \\leq (1-\\sum_{i=1}^n t_i)_+^{k_0} G_{k_0}(0,0)")

#text("2. We beat the quarter million barrier for prime gaps!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234238")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("Can one improve the lower bound on ")#mi("\\beta")#text(" via not being so lossy on ")#mi("G_{k0-1,1}(t)")#text(", which now appears to go as ")#mi("A+B-C")#text(" and ")#mi("B\\ge C")#text(", so it’s nonnegative? (In fact, ")#mi("A=B")#text(" by symmetry.) Maybe an improvement would use convexity somehow, or simply use the explicit expressions for ")#mi("g")#text("?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234242")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("It could be that we could almost obtain ")#mi("G_{k_0-1}(t)\\gtrapprox 2(1-t)^{k0/2}G(0,0)-(1-t)^{k0}G(0,0)")#text(", if the upper bound of ")#mi("G(t,0)\\le (1-t)^{k0/2}")#text(" were nearly sharp.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234130")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("It seems that there is a typo in the summands in (3).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234132")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("I mentioned this above (see item #1 in “Some typos”).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234157")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("Using the small improvement I described above, SAGE tells me that ")#mi("(\\omega,\\delta)=(1/891,7/17028)")#text(" and ")#mi("k_0=22949")#text(" is best. For this choice, ")#mi("\\kappa\\approx 1.5900816\\times 10^{-5}")#text(" and ")#mi("\\kappa^{\\prime}\\approx 1.2662224\\times 10^{-10}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234208")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("A suggestion to further optimize ")#mi("\\varpi , \\delta")#text(":")#linebreak()#text(" It seems that always the minimization of ")#mi("k_0(\\varpi, \\delta)")#text(" is done")

#text("1. Subject to the (unnecessary) restriction that ")#mi("1 / \\varpi")#text(" is an integer, and")

#text("2. ")#mi("\\delta")#text(" is determined by ")#mi("\\varpi")#text(" to satisfy the admissibility inequality constraint as EQUALITY constraint (i.e. the maximal ")#mi("\\delta")#linebreak()#text(" possible under the constraint).")

#text("My suggestion to deal with these two problems is:")

#text("1′. To refine the optimization of ")#mi("1/ \\varpi")#text(" in its neighborhood by allowing it to be a multiple of 0.1 (or 0.01) in the interval (890, 892).")

#text("2′. Using the previously optimized (not necessarily integer!) value of")#linebreak()#text(" ")#mi("1/ \\varpi")#text(" FIXED, and optimizing the previous value of")#linebreak()#text(" ")#mi("1/ \\delta")#text(" as an integer satisfying the admissibility constraint (in order to get a GLOBAL search for ")#mi("\\delta")#text(" – not only near the admissibility boundary!) and then using a finer LOCAL optimization search for")#linebreak()#text(" ")#mi("1/ \\delta")#text(" as a multiple of 0.1 (or 0.01).")

#text("Since both steps (1′), (2′) can only reduce the value of ")#mi("k_0")#text(", by alternating between this steps, k_0 should converge to a local minimum (by making the local search in (1′), (2′) finer enough.)")#linebreak()#text(" One may find many variants to this “alternating search” optimization, in particular a coarse GLOBAL search may be added at the beginning of (1′) in each iteration, using the value of ")#mi("\\delta")#text(" from the previous iteration FIXED (in order to keep a GLOBAL optimization at each iteration.)")

#text("Remark: Note that the current values of ")#mi("\\varpi")#text(" and ")#mi("\\delta")#linebreak()#text(" have the same order of magnitude!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234243")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("1. The expressions for ")#mi("\\kappa")#text(" and ")#mi("\\kappa^{\\prime}")#text(" are decreasing in ")#mi("\\delta")#text(", hence for a given ")#mi("\\varpi")#text(" we do not lose anything by taking the ")#mi("\\delta")#text(" satisfying ")#mi("207\\varpi+43\\delta=\\frac{1}{4}")#text(".")

#text("2. I believe that ")#mi("k_0=22949")#text(" is optimal for the current version of Theorem 2. I don’t have a formal proof, but it is advantageous to see how the ratio of ")#mi("(1+4\\varpi) (1-\\kappa^{\\prime})")#text(" and ")#mi("\\frac{j_{k_0-2}^2}{k_0(k_0-1)} (1+\\kappa)")#text(" changes as we vary ")#mi("k_0")#text(" or ")#mi("\\varpi")#text(". For ")#mi("\\varpi=\\frac{1}{891}")#text(", the ratio is ")#mi("0.9999998754")#text(" when ")#mi("k_0=22948")#text(", it is ")#mi("1.0000000161")#text(" when ")#mi("k_0=22949")#text(", and it is ")#mi("1.0000001568")#text(" when ")#mi("k_0=22950")#text(". For ")#mi("k_0=22949")#text(", the ratio is ")#mi("0.9999996427")#text(" when ")#mi("\\varpi=\\frac{1}{890}")#text(", it is ")#mi("1.0000000161")#text(" when ")#mi("\\varpi=\\frac{1}{891}")#text(", and it is $0.9999990240$ when ")#mi("\\varpi=\\frac{1}{892}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234253")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("Thank you for the data!")#linebreak()#text(" It follows therefore that for each given ")#mi("\\varpi")#text(" the optimal")#linebreak()#text(" ")#mi("\\delta")#text(" is determined such that the admissibility constraint should becomes equality (i.e. the maximal permissible ")#mi("\\delta")#text("), which leaves ")#mi("\\varpi")#text(" as the ONLY free parameter to minimize ")#mi("k_0")#text(". Therefore (since ")#mi("1/ \\varpi")#text(" is NOT restricted to be an integer), I suggest to vary ")#mi("1/ \\varpi")#text(" with small steps (0.1 say) in the interval (890, 892) to see if one of these 19 values of ")#mi("\\varpi")#text(" leads")#linebreak()#text(" to a new record of ")#mi("k_0")#text(". (since it involves a small number of trials, I think it worth the effort!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234342")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("I’m trying to analyze your data about the ratio above as a function of")#linebreak()#text(" ")#mi("1/ \\varpi")#text(" and ")#mi("k_0")#text(" as free parameters (")#mi("\\delta")#text(" is not free because of its dependence on ")#mi("\\varpi")#text(" via the restriction equality.)")#linebreak()#text(" It is easy to see from your data the almost linear dependence of the ratio")#linebreak()#text(" on ")#mi("k_0")#text(" in ")#mi("[22948, 22950]")#text(" for ")#mi("1/ \\varpi = 891")#text(" (which was quite expected), but the dependence of this ratio on ")#mi("1/ \\varpi")#text(" in")#linebreak()#text(" ")#mi("1 /\\varpi")#text(" in ")#mi("[890, 892]")#text(" for ")#mi("k_0 = 22949")#text(" must be WRONG because")

#text("1. The ratio should be ")#mi("> 1")#text(" for the admissible pair")#linebreak()#text(" ")#mi("(1/ \\varpi , k_0) = (892, 22949)")#text(", while the ratio you gave was")#linebreak()#text(" ")#mi("0.9999990240")#text(".")

#text("2. For ")#mi("k_0 = 22949")#text(" the dependence of the above ratio on")#linebreak()#text(" ")#mi("1/ \\varpi")#text(" in ")#mi("[890, 892]")#text(" is NOT monotonic (as it should be.)")

#text("It seems that the problem is due to a WRONG computation of the above ratio for the pair ")#mi("(1 /\\varpi , k_0) = (892, 22949)")#text(". Can you check it please and let me know the correct ratio. Thanks")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234345")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("I am confident my calculations are correct, and v08ltu independently confirmed them. Terry Tao also checks everything here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234348")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("But how is it possible that the admissible pair (892, 22249) gave a ratio LESS than 1? (it contradict the admissibility criterion in theorem 2!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234351")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("There is no contradiction to Theorem 2. Let us fix ")#mi("k_0=22949")#text(". In the interval ")#mi("(\\frac{1}{892},\\frac{1}{890})")#text(" the expression ")#mi("\\frac{4\\delta}{1+4\\varpi}")#text(" (for the optimized ")#mi("\\delta")#text(") is decreasing, hence ")#mi("\\kappa")#text(" and ")#mi("\\kappa^{\\prime}")#text(" are increasing. So in Theorem 2 we are looking at the ratio of two increasing quantities: ")#mi("1+4\\varpi")#text(" and ")#mi("\\frac{j_{k_0-2}^2}{k_0(k_0-1)}\\cdot\\frac{1+\\kappa}{1-\\kappa^{\\prime}}")#text(". The fact that the ratio has a local maximum in ")#mi("(\\frac{1}{892},\\frac{1}{890})")#text(" simply reflects the fact that ")#mi("1+4\\varpi")#text(" grows faster than ")#mi("\\frac{1+\\kappa}{1-\\kappa^{\\prime}}")#text(" on the left end of this interval, but this tendency changes somewhere inside the interval.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234357")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("It seems VERY strange that the criterion in theorem 2 is sufficient to decide that for ")#mi("k_0 = 22949")#text(", the parameter ")#mi("\\varpi = 1/891")#text(" is admissible (since the above ratio is greater than 1), while for")#linebreak()#text(" ")#mi("\\varpi = 1/ 892")#text(" (which obviously should be admissible) it can’t do so (because of ratio less than 1).")#linebreak()#text(" It is still possible (since the criterion is only sufficient), but it still seems very strange!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234371")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("The phenomenon is not so strange if you think of the role and meaning of the parameter ")#mi("\\delta")#text(". Ideally it would be infinite, i.e. we would use all divisors for the sieve leading to Theorem 2. In that case we would not have to consider ")#mi("\\kappa")#text(" and ")#mi("\\kappa^{\\prime}")#text(" at all (they would be zero), and the crucial ratio would be proportional to ")#mi("1+4\\varpi")#text(", i.e. monotonic as you expect it to be. The reason that we do need a finite ")#mi("\\delta")#text(" is our lack of understanding of the equidistribution of primes to large moduli, including those with possibly large prime factors. Zhang’s discovery is that for sufficiently small ")#mi("\\varpi")#text(", we can allow sufficiently many (but not all) prime factors to participate in the moduli, and this is measured by ")#mi("\\delta")#text(". At this point we have two opposite forces: Theorem 2 wants a ")#mi("\\delta")#text(" as large as possible, but the necessary hypothesis ")#mi("MPZ[\\varpi,\\delta]")#text(" is only available for sufficiently small ")#mi("\\delta")#text(" depending on ")#mi("\\varpi")#text(". So the question is: which ")#mi("\\varpi")#text(" gives the best compromising value of ")#mi("\\delta")#text(", one that is sufficiently small for the hypothesis to hold provably, and one that is sufficiently large for a good value of ")#mi("k_0")#text(". As things stand now, the best value lies somewhere between ")#mi("\\frac{1}{892}")#text(" and ")#mi("\\frac{1}{890}")#text(". It is a complicated proof!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234244")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("I always use tenths of an integer in the reciprocal of ")#mi("\\omega")#text(", but the ")#mi("k_0")#text("-result has never needed such precision in reporting.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234254")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("It depends on the sensitivity of ")#mi("k_0")#text(" to small changes in")#linebreak()#text(" ")#mi("1/ \\varpi")#text(" as well as how the above ratio is close to 1 (i,e, very small changes may lead to a downward “jump” to ")#mi("k_0 -1")#text(" if the ratio is sufficiently close to 1.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234228")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("I agree with this bound.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e129a68dcf0bb46ecba772753b8f9af1ec273d49cbd7ace8069058648b03b58-7eb33440dcbae163fc1d170d08c9c52deb82d4eb4253cf0fbe7e8b13997f3aa7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig Helfgott")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234181")[#strong[#text("Craig Helfgott")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("I have one question, and it may be obvious, but it is confusing me: When you derive (6) from the preceding line, you are apparently factorizing ")#mi("k_0^{\\Omega([a_1 d_1, a_2 d_2])}")#text(" as ")#mi("k_0^{\\Omega([a_1, a_2])} k_0^{\\Omega([d_1, d_2])}")#text(". Why is this allowed?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e129a68dcf0bb46ecba772753b8f9af1ec273d49cbd7ace8069058648b03b58-7eb33440dcbae163fc1d170d08c9c52deb82d4eb4253cf0fbe7e8b13997f3aa7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig Helfgott")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234183")[#strong[#text("Craig Helfgott")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("Okay, went back to the previous post for the definition of ")#mi("\\Omega")#text(". Sorry, I thought you were using Big-Omega notation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of unknown mathematician")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234218")[#strong[#text("unknown mathematician")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("Dear Prof. Tao and other top mathematicians here,")#linebreak()#text(" Is the purpose of this to turn Zhang´s paper obsolete even before it appears in print? It seems that this is already the case.")

#text("I wonder if had the author of the paper being studied been one of the top people in the area (one of you) if it would have generated such a collective effort to improve the result. I have never seen anything like this before.")

#text("I am a big fan of many math blogs and this is one of my favorites, but I cannot help the feeling that there is something not very nice happening here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27a32c47a0bb624b554c02f628b2a94362fed73bea1cf1cbd01049ab1aabea20-d67d36ca3fba5f314749153a396e9ee97f9d249b83b4616dbf0e35cc35a642d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ghaith")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234226")[#strong[#text("Ghaith")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("Dear unknown mathematician, I don’t think this is the case. Zhang’s result is amazing (I certainly wasn’t expecting to see something like it that soon). I think the collective effort you observe is natural since this is the most exciting thing to happen in number theory in a while. As a result, some people (e.g. me!) have gotten far more interested in learning about the proof. I think that the progress that has been made since then is impressive, and impressively rapid.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234237")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("Not at all! First Zhang’s paper already appeared in “print” (the final version is on the journal webpage, the physical paper is not important). Second, nothing can make the work of Zhang or Goldston-Pintz-Yildirim obsolate, since the ground-breaking ideas are there. I think what is happening is this. A few months ago noone (except for Zhang perhaps) thought that we would see bounded gaps between primes. Zhang’s “70 million” is not an astronomical constant like ")#mi("10^{3000}")#text(" that was customary in similar advances such as ternary Goldbach, Waring for cubes, Catalan’s conjecture etc. So one simply wonders what Zhang’s method with some tweaks is capable of. I find this a nice way to pay respect to Zhang, respond to the basic curiosity “So how small are those gaps, really?”, have fun together as a PolyMath group, and understand the argument as well as possible. There is really no reason to hold back progress, time is our real enemy.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b569ab6e7e3d7906c75b26228bb124f88e299a60f22618bcb8846df553ea7ad-f4d6150803cd83679d270d45b0ebd17630784da51d524022a26e5ab5e18ca754.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Goldston")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234259")[#strong[#text("Dan Goldston")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("All this interest and activity generated by Zhang’s work is a tribute to the importance of his contribution. It is true that the paper will not appear in print for years, but it is accepted for publication and available for others to build on. I think that anyone working on this problem for years to come is going to study Zhang’s paper for his insight.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pete")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234311")[#strong[#text("Pete")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("Obviously I don’t know how Zhang feels about it, but for sure I would be extremely happy if a result of mine was getting this kind of attention. It says: this result is not just worth a paper in Annals, it is worth weeks or months of time of the world’s best mathematicians (and it will surely be judged worth prize(s) as well).")

#text("Eventually there will be a (probably) Polymath long paper which gives substantially better bounds than Zhang’s original. It will probably also be published in Annals. But it will surely be written to be very clear that the improvements are absolutely relying on Zhang’s fundamental breakthrough. And no-one will get prizes for it.")

#text("There are also different levels of achievement on this problem. Pre-Zhang, the best known result was only somewhat better than the trivial point that the minimum gap isn’t larger than the average gap (and this was already a big result). Probably it was expected that the next result would be some slowly-growing-function gap, and as several people already said, no-one expected to see bounded gaps any time soon. In that context, if you can prove any bounded gaps theorem, then you are happy: you don’t really care if the bound is in the thousands, millions, or some tower of exponents (and exponentials usually appear in these kinds of things the first time, in some sense Zhang got lucky that his approach doesn’t need any). Zhang himself fairly obviously did not care too much: he deliberately didn’t optimise his work in the interests of writing a more readable paper, whereas the polymath version will probably have a lot of strange numbers and optimisations done by computer, as well as the ‘genuine’ improvements by modifying the approach, which will make it a lot harder going.")

#text("The books will record the fact of bounded gaps in the primes as ‘Zhang’s Theorem’, and the polymath result will be a note as an ‘improved Zhang’s Theorem’ or such: it seems very likely that the approach will not get to any gap such as 16, or 6, let alone 2, which would merit a new name.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234313")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("Actually before Zhang it was known that around ")#mi("x")#text(" we can find prime gaps of size less than ")#mi("(\\log x)^{3/7+o(1)}")#text(", a result by Pintz improving on a similar result of Goldston-Pintz-Yildirim with exponent ")#mi("1/2")#text(" in place of ")#mi("3/7")#text(". I would not call this “somewhat better than the trivial point”, it was already a fantastic result.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pete")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234327")[#strong[#text("Pete")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("Sure, but when log is easy and the aim is 2, polylog doesn’t look like a big step. I think the point you (and I) are trying to make is that even polylog was already very hard.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234343")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("I always thought of ")#mi("(\\log x)^{1/2}")#text(" as being half-way between the trivial gaps and bounded gaps (although, admittedly, I did not expect to see bounded gaps in my life). In some sense Zhang justified this feeling of mine.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72ea9506a8fb064ca33e1274316b9c84a40688ea23862e524fb0e6f7c49e439d-de04381cb4b04ef82414d1c9f13abb48fa2449415656dd437c3d5867c9ce47c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234316")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("I think these are pretty good responses to unknown mathematician’s comment. If polymath wasn’t happening, the alternatives would be that Zhang’s 70000000 just sat there for everyone to admire, or else people would publish piecemeal improvements and there would be one enormous mess deciding priorities (for those who cared) and even correctness. Even now, with the bound on ")#mi("H")#text(" around 300000, there could yet be over 100000 papers on the subject of improving the gap if we were proceeding in this way. The polymath is the perfect solution to this problem in my view. It’s highly inclusive and no-one fusses over priorities and credit. In addition, as pointed out above, these great ideas – not just of Zhang, but also of GPY, BFFI, etc – are getting publicly celebrated and debated. I can’t really imagine why that would annoy any of them.")

#text("To echo Pete’s comment, Zhang pretty explicitly states that his exponents are not optimised. Most likely he knew a few of the improvements that have come to light already in the polymath discussion, but he deferred from mentioning them so as to write a more readable paper. Anyway, I don’t get any kind of sense that the contributors to this blog are rushing to show Zhang how he could have done better, if that was the aspect of this thought to be “not very nice” by unknown mathematician.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234341")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("Actually ")#mi("H")#text(" is now below 250000 :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of unknown mathematician")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234772")[#strong[#text("unknown mathematician")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("First I want to thank you for all the responses to my comment. I also want to apologize for my very poor choice of words in it. I do have the highest respect for the mathematicians here not only for their mathematical abilities but also for the very high ethical stand assumed. As was mentioned before I too, would feel honored if one of my papers would get this much attention from a mathematician like Terence Tao.")

#text("I did not say that Zhang would not be given the proper credit for his work. His name is already in History and every response to my comment made that clear.")

#text("The only thing I still suspect ( I cannot be sure for I am not a number theorist) is that after all the work done here, if there are still insights in the original paper that have not been “dissected” here.")

#text("This went too far and I do regret to have written the above comment but cannot undo it … yet.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234336")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("I think that Zhang gets huge credit through this approach to his work, because it is clear that the improvements are founded on his work and insight – as an interested non-specialist that’s what I read – and he will also see the cascade of ideas and improvements his work has started.")

#text("Another advantage, as yet unstated, is that the Polymath approach here also tests the limits of what is possible using Zhang’s insights and maps the various barriers to progress. So that helps to see where new insight is necessary to go further.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f835facf182d8803de58823bb1fbc18770ffad249b8062d866cd20ed5570fa2-bdc515c82c20975751c595cc97682143767a56e5d5800a69168dc4926c332e0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andre K.")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234359")[#strong[#text("Andre K.")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("Dear Unknown Mathematician,")#linebreak()#text(" My feeling reading this blog is exactly the opposite of yours. I see it as a tribute to Zhang. I would be very proud to see so many advances based on my own ideas. Also, for people like me, amateur mathematicians (did my undergrad in math but moved on to other jobs), a blog like this is a magnificent window on how ‘real mathematicians’ work. It is an opportunity to see the work build up with all the unfruitful paths that do not work out and the little by little progress that is made. Otherwise, we would only see the final product – the paper in a journal. I commend Terence Tao for exposing all of us to this wonderful adventure. Andre K.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234236")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("Some typos: In the display below the definition of ")#mi("\\kappa")#text(", ")#mi("\\exp(-k_0/2)")#text(" should be ")#mi("\\exp(-t)")#text(". In the definition of ")#mi("\\kappa^{\\prime}")#text(", ")#mi("\\exp(-\\frac{k_0}{2}t)")#text(" should be ")#mi("(1-t)^{k_0/2}")#text(", and integration should end at ")#mi("t=1")#text(". In Theorem 2, the values of ")#mi("\\kappa")#text(" and ")#mi("\\kappa^{\\prime}")#text(" should be updated similarly.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234248")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("Actually, in the definition of ")#mi("\\kappa^{\\prime}")#text(", the exponent ")#mi("k_0/2")#text(" should be ")#mi("(k_0-1)/2")#text(". Two occurrences.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234302")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("In the definition of ")#mi("\\kappa^{\\prime}")#text(", the denominator should be ")#mi("n!")#text(" instead of ")#mi("n")#text(". Two occurrences.")#linebreak()#text(" ")#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Non-Mathematician")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234423")[#strong[#text("Non-Mathematician")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("I am absolutely a non-mathematician and find this site fascinating, and feel good for Zhang every time I visit here. No I don’t read the math discussions, but only read the shrinking numbers (and why they got crossed out.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234461")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("I claim that ")#mi("G_{k_0,n}(t_1,\\ldots,t_n)")#text(" is nonnegative, hence ")#mi("\\kappa^{\\prime}=0")#text(" is admissible in Theorem 2. For the proof let us consider functions of the form")

#mi("(t_1,t_2)\\mapsto\\int_\\mathbb{R}g_1(t+t_1)g_2(t+t_2)\\ d\\nu(t)")

#text("where ")#mi("d\\nu(t)")#text(" is a fixed measure on ")#mi("\\mathbb{R}")#text(", and ")#mi("g_1,g_2:\\mathbb{R}\\to\\mathbb{R}")#text(" are decreasing nonnegative functions such that the integrand is integrable. Let us call a function ")#mi("G(t_1,t_2)")#text(" nice, if it is a sum of functions of the above form. We observe that if ")#mi("G(t_1,t_2)")#text(" is nice, then ")#mi("G(t_1+\\tau,t_2)")#text(" and ")#mi("G(t_1,t_2+\\tau)")#text(" are nice for for any ")#mi("\\tau\\in\\mathbb{R}")#text(". Moreover, ")#mi("G(t_1,t_2)-G(t_1+\\tau,t_2)")#text(" and ")#mi("G(t_1,t_2)-G(t_1,t_2+\\tau)")#text(" are nice for any ")#mi("\\tau\\geq 0")#text(". It follows that")

#mi("(\\Delta_\\tau G)(t_1,t_2):=G(t_1+\\tau,t_2)+G(t_1,t_2+\\tau)-G(t_1+\\tau,t_2+\\tau)")

#text("is nice for any ")#mi("\\tau\\geq 0")#text(". Now we see that, for any ")#mi("t_1,\\dots,t_n\\geq 0")#text(", the function ")#mi("\\Delta_{t_1}\\dots\\Delta_{t_n}G")#text(" is nice, hence its value at ")#mi("(0,0)")#text(" is nonnegative. However, we can check by induction on ")#mi("n")#text(" that this this value is nothing but")

#tao-math("\\sum_{\\{1,\\ldots,n\\} = S \\cup T} (-1)^{\\left|S \\cap T\\right|} G( \\sum_{i \\in S} t_i, \\sum_{i \\in T} t_i ).", block: false)

#text("Specializing to ")#mi("G=G_{k_0}")#text(" gives the claim.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234537")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("Actually, could you give more detail as to why ")#mi("G(t_1,t_2) - G(t_1+\\tau,t_2)")#text(" is nice? Taking Newton quotients this would seem to imply that ")#mi("-\\frac{\\partial}{\\partial t_1} G(t_1,t_2)")#text(" is also nice, which looks like a statement that would need control on higher derivatives of ")#mi("g_1")#text(".")

#text("In our specific case, we do know that the Bessel-type function ")#mi("g")#text(" has derivatives with a fixed (alternating) sign, but one has to be careful when truncating at the endpoint ")#mi("t=1")#text(" since one only has a limited amount of regularity at this endpoint.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234575")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("You are right, I announced the result too quickly. I think the new values of ")#mi("\\kappa")#text(" and ")#mi("\\kappa^{\\prime}")#text(" are still ok, we don’t need any regularity at ")#mi("t=1")#text(".")

#text("To fix the proof, let us call a function ")#mi("g:\\mathbb{R}\\to\\mathbb{R}")#text(" appropriate if it is supported on some ")#mi("[a,b]")#text(" such that ")#mi("g^{(j)}")#text(" has sign ")#mi("(-1)^j")#text(" in ")#mi("(a,b)")#text(". If ")#mi("g(t)")#text(" is appropriate, then so is ")#mi("g(t+\\tau)")#text(" for any ")#mi("\\tau\\in\\mathbb{R}")#text(", while ")#mi("g(t)-g(t+\\tau)")#text(" is a sum of two appropriate functions for any ")#mi("\\tau\\geq 0")#text(". Hence if we restrict to appropriate functions ")#mi("g_1,g_2:\\mathbb{R}\\to\\mathbb{R}")#text(" in the definition of nice functions, and we take ")#mi("d\\nu(t)=t^{k_0-1}dt")#text(" restricted to ")#mi("[0,1]")#text(", then the argument goes through to yield")

#mi("0\\leq(\\Delta_{t_1}\\dots\\Delta_{t_n}G)(0,0)\\leq 2^n(\\prod_{i=1}^n(1-t_i)_+^{k_0/2})G(0,0)")#text(".")

#text("We apply this for ")#mi("g_1(t)=g_2(t)=t^{(1-k_0)/2} J_{k_0-1}(j_{k_0-2}\\sqrt{t})")#text(" restricted to ")#mi("[0,1]")#text(" to see that the new ")#mi("\\kappa")#text(" is admissible. To obtain ")#mi("\\kappa^{\\prime}=0")#text(", we use instead ")#mi("d\\nu(t)=t^{k_0-2}dt")#text(" and ")#mi("g_1(t)=g_2(t)=t^{(2-k_0)/2} J_{k_0-2}(j_{k_0-2}\\sqrt{t})")#text(", all restricted to ")#mi("[0,1]")#text(".")

#text("So do you agree that Theorem 2 holds with the new values of ")#mi("\\kappa")#text(" and ")#mi("\\kappa^{\\prime}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234577")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("Actually ")#mi("G(0,0)")#text(" should be ")#tao-math("\\left\\|G\\right\\|(0,0)", block: false)#text(" here and also in my comment today at 4:56 am. Note that for ")#mi("g_1=g_2")#text(" these values")#linebreak()#text(" are equal.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234625")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("I’m not yet clear why ")#mi("g(t)-g(t+\\tau)")#text(" is the sum of two appropriate functions, particularly in the case when ")#mi("a < t < b < t+\\tau")#text(" when one has to cross a point of potential discontinuity of ")#mi("g")#text(". Could you elaborate?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234684")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("Sorry my setup was still incompatible with my intuition. I think I got it right now, see my longer post below, sent a few minutes ago.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234480")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("This is a continuation of my previous comment. Let us introduce the notation")

#tao-math("\\left\\|G\\right\\|(t_1,t_2):=(\\int_\\mathbb{R}g_1^2(t+t_1)\\ d\\nu(t))^{1/2}(\\int_\\mathbb{R}g_2^2(t+t_2)\\ d\\nu(t))^{1/2}", block: false)

#text("so that ")#tao-math("G(t_1,t_2)\\leq \\left\\|G\\right\\|(t_1,t_2)", block: false)#text(" by Cauchy, with equality when ")#mi("g_1=g_2")#text(" and ")#mi("t_1=t_2")#text(". Let us also fix ")#mi("d\\nu(t):=t^{k_0-1}dt")#text(". Then we can see, as in the main post, that replacing ")#mi("G(t_1,t_2)")#text(" by ")#mi("G(t_1+\\tau,t_2)")#text(" or ")#mi("G(t_1,t_2+\\tau)")#text(" for any ")#mi("\\tau\\in\\mathbb{R}")#text(" multiplies the function ")#tao-math("\\left\\|G\\right\\|", block: false)#text(" by at most ")#mi("(1-\\tau)_+^{k_0/2}")#text(", while replacing ")#mi("G(t_1,t_2)")#text(" by ")#mi("G(t_1,t_2)-G(t_1+\\tau,t_2)")#text(" or ")#mi("G(t_1,t_2)-G(t_1,t_2+\\tau)")#text(" for any ")#mi("\\tau\\geq 0")#text(" cannot increase ")#tao-math("\\left\\|G\\right\\|", block: false)#text(". It follows, by Minkowski’s inequality, that ")#tao-math("\\left\\|\\Delta_\\tau G\\right\\|\\leq 2(1-\\tau)_+^{k_0/2}\\left\\|G\\right\\|", block: false)#text(" for any ")#mi("\\tau\\geq 0")#text(", hence for any ")#mi("t_1,\\dots,t_n\\geq 0")#text(" we have")

#tao-math("\\left\\|\\Delta_{t_1}\\dots\\Delta_{t_n}G\\right\\|\\leq 2^n(\\prod_{i=1}^n(1-t_i)_+^{k_0/2})\\left\\|G\\right\\|", block: false)#text(".")

#text("In particular, using the point ")#mi("(0,0)")#text(" we infer")

#mi("(\\Delta_{t_1}\\dots\\Delta_{t_n}G)(0,0)\\leq 2^n(\\prod_{i=1}^n(1-t_i)_+^{k_0/2})G(0,0)")#text(".")

#text("Specializing to the nice function ")#mi("G=G_{k_0}")#text(" we obtain finally")

#mi("0\\leq G_{k_0,n}(t_1,\\ldots,t_n)\\leq 2^n(\\prod_{i=1}^n(1-t_i)_+^{k_0/2})G(0,0)")#text(".")

#text("This is an improved version of (8), and yields Theorem 2 with the smaller values ")#mi("\\kappa^{\\prime}:=0")#text(" and")

#mi("\\kappa := \\sum_{1 \\leq n < \\frac{1+4\\varpi}{4\\delta}} \\frac{1}{n!} (2k_0\\int_{4\\delta/(1+4\\varpi)}^1 (1-t)^{k_0/2}\\ \\frac{dt}{t})^n")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234486")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("In practice one can replace ")#mi("1+\\kappa")#text(" by the clean")

#mi("1+\\tilde\\kappa:=\\exp(2k_0\\int_{4\\delta/(1+4\\varpi)}^1 (1-t)^{k_0/2}\\ \\frac{dt}{t})")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234489")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("In fact, you reduced (in the sum) the factor ")#mi("(3^n + 1) / 2")#text(" to")#linebreak()#text(" ")#mi("2^n")#text(" but since (in general) ")#mi("n=1")#text(" dominates, the improvement in ")#mi("\\kappa")#text(" might be small. I think that the elimination of ")#mi("\\kappa^{\\prime}")#text(" could be more significant.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234490")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("The elimination of ")#mi("\\kappa^{\\prime}")#text(" is also insignificant, because it has no ")#mi("n=1")#text(" term. At the moment the improved values serve esthetic purposes, but for smaller values of ")#mi("k_0")#text(" they might be useful eventually.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234517")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("Very neat! I’m impressed that you got all this positivity just from the monotone nature of ")#mi("g^{(k_0)}")#text(" and ")#mi("g^{(k_0-1)}")#text("; I would have thought that further properties of higher derivatives would be needed, but apparently not.")

#text("As you say it probably doesn’t lead to any improvement on ")#mi("k_0")#text(" with our current values of ")#mi("\\varpi,\\delta")#text(" but may make a contribution in the future.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234487")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("In proposition 1, in both sums n should start with 1 (not 0)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234492")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("No they are ok. The ")#mi("n=0")#text(" terms are the leading terms ")#mi("G_{k_0}(0,0)")#text(" and ")#mi("G_{k_0-1}(0,0)")#text(", while the ")#mi("n\\geq 1")#text(" terms are compared to these, the respective ratios being bounded by ")#mi("\\kappa")#text(" and ")#mi("\\kappa^{\\prime}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234495")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("But ")#mi("n=0")#text(" means that there are no integration variables!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234497")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("Yes. It is an empty multiplicative integral, i.e. equal to 1 (just like an empty product). This is a convention that Terry uses. If you look at the second display before Proposition 1, you will see that the ")#mi("n=0")#text(" term corresponds to the ")#mi("a=1")#text(" term there (because this is the only number with no prime factor), and this term equals ")#mi("G_{k_0}(0,0)")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234500")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("I don’t understand why do you call this empty integral “multiplicative” and the logic behind its definition as 1 (irrespective of its integrand)")#linebreak()#text(" Anyway, for clarification I suggest to separate the ")#mi("n=0")#text(" summand from the sum (because I don’t think this convention to be a standard one.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234513")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("The logic is similar to the reason why powers ")#mi("x^n")#text(" for ")#mi("x \\neq 0")#text(", or more generally products ")#mi("\\prod_{i=1}^n x_i")#text(" for ")#mi("x_i \\neq 0")#text(", are by convention set equal to ")#mi("1")#text(" when ")#mi("n=0")#text(" (see the Wikipedia entry on “")#link("http://en.wikipedia.org/wiki/Empty_product")[#text("empty products")]#text("“), and can in fact be deduced from that standard convention as follows.")

#mi("{\\bf R}^n")#text(" is the standard real ")#mi("n")#text("-dimensional vector space. Thus ")#mi("{\\bf R}^0")#text(" is the standard zero-dimensional vector space, i.e. the point ")#mi("\\{0\\}")#text(". More formally, ")#mi("{\\bf R}^n")#text(" by definition is the set of ")#mi("n")#text("-tuples ")#mi("(x_1,\\ldots,x_n)")#text(", with the zero tuple ")#mi("(0,\\ldots,0)")#text(" identified with ")#mi("0")#text("; thus, ")#mi("{\\bf R}^0")#text(" is the set of ")#mi("0")#text("-tuples ")#mi("()")#text(", but there is only one such tuple (cf. the ")#mi("x^0=1")#text(" rule mentioned earlier), and we identify this tuple with ")#mi("0")#text(".")

#text("To normalise n-dimensional Riemann or Lebesgue integration, we define the measure of a box ")#mi("\\prod_{i=1}^n [a_i,b_i] = \\{ (x_1,\\ldots,x_n): x_i \\in [a_i,b_i] \\text{ for all }1 \\leq i \\leq n\\}")#text(" when ")#mi("b_i > a_i")#text(" for all ")#mi("i")#text(" to equal ")#mi("\\prod_{i=1}^n (b_i-a_i)")#text(". In the zero dimensional case ")#mi("n=0")#text(", the box is a singleton set consists only of the empty tuple ")#mi("()")#text(" (as can be seen by carefully checking the definition, noting that universal quantification over an empty set is vacuously true), and the product ")#mi("\\prod_{i=1}^n (b_i-a_i)")#text(" is one by the empty product convention. Thus we see that ")#mi("{\\bf R}^0")#text(" has Lebesgue measure one. (Another way of seeing this is recalling that ")#mi("n")#text("-dimensional Lebesgue measure in ")#mi("{\\bf R}^n")#text(" is the same thing as ")#mi("n")#text("-dimensional Hausdorff measure on ")#mi("{\\bf R}^n")#text(", and that 0-dimensional Hausdorff measure is counting measure.) In particular, if ")#mi("F: {\\bf R}^0 \\to {\\bf C}")#text(" is a function, the empty integral")

#mi("\\int_{{\\bf R}^0} F")

#text("is equal to the value ")#mi("F( 0 )")#text(" of ")#mi("F")#text(" at the origin ")#mi("0 = ()")#text(". Thus for instance")

#mi("\\int_{\\frac{4\\delta}{1+\\varpi} < t_1 < \\ldots < t_n} G_{k-1,n}(t_1,\\ldots,t_n) \\frac{dt_1 \\ldots dt_n}{t_1 \\ldots t_n}")

#text("when ")#mi("n=0")#text(" is equal to the evaluation of the integrand ")#mi("G_{k-1,n}(t_1,\\ldots,t_n) \\frac{1}{t_1 \\ldots t_n}")#text(" at the origin (note carefully that the region of integration is the singleton set ")#mi("\\{0\\} = \\{()\\}")#text(" rather than the empty set). The denominator looks scary, but recall that the empty product is 1, so that ")#mi("t_1 \\ldots t_n = 1")#text(" when ")#mi("n=0")#text(", and so the expression simplifies to ")#mi("G_{k-1,0}()")#text(", which is ")#mi("G_{k-1}(0,0)")#text(" if one works through the definitions.")

#text("In the special case when one is integrating a tensor product")

#mi("\\int_{{\\bf R}^n} F_1(x_1) \\ldots F_n(x_n)\\ dx_1 \\ldots dx_n")

#text("for well-behaved functions ")#mi("F_i")#text(" then it is particularly clear that the ")#mi("n=0")#text(" case of this integral should be ")#mi("1")#text(", since Fubini’s theorem factors this integral as")

#mi("\\prod_{i=1}^n \\int_{{\\bf R}} F_i(x_i)\\ dx_i")

#text("and by convention the empty product is 1 (informally, the zero-dimensional integral of a “multiplicative” integrand is automatically 1). Another relevant example comes from the identity")

#mi("\\int_{0 < x_1 < \\ldots < x_n < 1}\\ dx_1 \\ldots dx_n = \\frac{1}{n!}")

#text("which extends without difficulty to the ")#mi("n=0")#text(" case using the correct conventions for zero-dimensional integration and for ")#mi("0!")#text(".")

#text("Basically, all of n-dimensional integration theory extends without difficulty to the 0-dimensional case when one adopts the correct conventions, much as the theory of exponentiation ")#mi("(n,x) \\mapsto x^n")#text(" for non-zero x and natural number n extends without difficulty to the ")#mi("n=0")#text(" case when one adopts the correct conventions. Isolating the ")#mi("n=0")#text(" case can be done if desired, but is not necessary (much as one could write, for instance, the Taylor series ")#mi("\\exp(x) = \\sum_{n=0}^\\infty \\frac{x^n}{n!}")#text(" as ")#mi("\\exp(x) = 1 + \\sum_{n=1}^\\infty \\frac{x^n}{n!}")#text(" if one was for some reason uncomfortable with the standard conventions for ")#mi("x^0")#text(" and ")#mi("0!")#text("). In order to keep the presentation short and avoid needless duplication of effort in handling a seemingly degenerate case that does not actually need any special attention, I have generally elected keep the n=0 case combined with the positive n cases.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69328ca38020bfdb13e572a59ca53eaf4bd575cc30bf6a9da7fcbe218b11e62b-35ac0fb53b4d8dfdaafdeca5cc6d4320e35ac400b23bc0818982f7d91f3d6ea8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234498")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("Pintz’s paper on arxiv has already been corrected can someone update the wiki to reflect that?")

#emph[#text("[Done, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234542")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("I understand the extension of integration on 0-th euclidean space using its Housdorff measure (which makes sense as “natural”), but I am not sure about the extension of Fubini theorem for this case. Also, It is not clear to me whether this is the only “natural” (and even “the” standard) extension.")#linebreak()#text(" (For example, “the” sum of the natural numbers was “naturally” interpreted by Ramanujan as ")#mi("\\zeta (-1) = -1/12")#text(".)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234634")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("Minor remark: perhaps it is better in proposition 1 to replace the summation index i (running over T) by j.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234650")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("In the 4-th and 6-th lines before (10), the index n should be 1.")

#emph[#text("[As explicitly stated just before these lines, the text here is restricted to the case ")#mi("n=1")#text(" (except for the parenthetical comment, which is explicitly restricted to the higher ")#mi("n")#text(" cases.) -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234668")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("A combinatorial question: the numbers ")#mi("(3^n + 1)/2 , (3^n - 1)/2")#text(" of partitions above to S and T are REGARDING the order of S and T.")#linebreak()#text(" Is it necessary? (otherwise, the bounds may be improved.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234682")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("In the fifth line above theorem 2, “we see” may be inserted before “that”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234683")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("This is my third attempt to improve (8) to")

#mi("0\\leq G_{k_0,n}(t_1,\\ldots,t_n)\\leq 2^n(\\prod_{i=1}^n(1-t_i)_+^{k_0/2})G_{k_0}(0,0)")

#text("for ")#mi("g_{k_0}(t):=t^{(1-k_0)/2} J_{k_0-1}(j_{k_0-2}\\sqrt{t})")#text(". This implies my earlier claimed improved value for ")#mi("\\kappa")#text(", while ")#mi("\\kappa^{\\prime}:=0")#text(" follows similarly.")

#text("Let us restrict to functions ")#mi("g:[0,1]\\to\\mathbb{R}")#text(" supported on some initial segment ")#mi("[0,\\sigma]\\subset[0,1]")#text(" such that ")#mi("g^{(j)}")#text(" is bounded and of sign ")#mi("(-1)^j")#text(" on ")#mi("(0,\\sigma)")#text(". Such functions will be called ")#mi("\\sigma")#text("-appropriate. For ")#mi("0\\leq\\tau\\leq\\sigma")#text(" let us consider the functions")

#mi("(R_\\tau g)(t):=g(t+\\tau)")#text(" and ")#mi("(D_\\tau g)(t):=g(t)-g(t+\\tau)")

#text("initially defined on ")#mi("[0,\\sigma-\\tau]")#text(" and then extended to be zero on ")#mi("(\\sigma-\\tau,1]")#text(". We observe that ")#mi("R_\\tau g")#text(" and ")#mi("D_\\tau g")#text(" are ")#mi("(\\sigma-\\tau)")#text("-appropriate, and their sum equals ")#mi("g")#text(" on ")#mi("[0,\\sigma-\\tau]")#text(". As in the main post, for the inner product")

#mi("\\langle g_1,g_2 \\rangle :=\\int_0^1 g_1(t)g_2(t)\\ t^{k_0-1}dt")

#text("we have ")#tao-math("\\left\\|R_\\tau g\\right\\|\\leq (1-\\tau)_+^{k_0/2}\\left\\|g\\right\\|", block: false)#text(". Moreover, ")#mi("0\\leq D_\\tau g\\leq g")#text(" implies ")#tao-math("\\left\\|D_\\tau g\\right\\|\\leq \\left\\|g\\right\\|", block: false)#text(".")

#text("Let ")#mi("g_1,g_2:[0,1]\\to\\mathbb{R}")#text(" be ")#mi("\\sigma")#text("-appropriate. For any ")#mi("t_1,\\dots,t_n\\geq 0")#text(" with sum at most ")#mi("\\sigma")#text(", let us consider the bilinear form")

#tao-math("\\langle g_1,g_2\\rangle_{t_1,\\dots,t_n} := \\sum_{\\{1,\\ldots,n\\} = S \\cup T} (-1)^{\\left|S \\cap T\\right|} \\langle \\prod_{i \\in S} R_{t_i}g_1,\\prod_{i \\in T}R_{t_i}g_2 \\rangle.", block: false)

#text("Then we have")

#mi("\\langle g_1,g_2\\rangle_{t_1,\\dots,t_n}=\\langle R_{t_n}g_1,g_2 \\rangle_{t_1,\\dots,t_{n-1}}+\\langle g_1,R_{t_n}g_2 \\rangle_{t_1,\\dots,t_{n-1}} -\\langle R_{t_n}g_1,R_{t_n}g_2 \\rangle_{t_1,\\dots,t_{n-1}}")#text(".")

#text("Noting that ")#mi("g_1-R_{t_n}g_1")#text(" equals ")#mi("D_{t_n}g_1")#text(" on the support of ")#mi("R_{t_n}g_2")#text(", we infer")

#mi("\\langle g_1,g_2\\rangle_{t_1,\\dots,t_n}=\\langle R_{t_n}g_1,g_2 \\rangle_{t_1,\\dots,t_{n-1}}+\\langle D_{t_n}g_1,R_{t_n}g_2 \\rangle_{t_1,\\dots,t_{n-1}}")#text(".")

#text("The point is the we have two terms with signs ")#mi("+,+")#text(" instead of three terms with signs ")#mi("+,+,-")#text(". By induction and the above remarks, we readily establish")

#tao-math("0\\leq\\langle g_1,g_2\\rangle_{t_1,\\dots,t_n}\\leq 2^n(\\prod_{i=1}^n(1-t_i)_+^{k_0/2})\\left\\|g_1\\right\\|\\left\\|g_2\\right\\|", block: false)#text(".")

#text("Specializing to ")#mi("g_1=g_2=g_{k_0}")#text(" and ")#mi("\\sigma=1")#text(" yields")

#mi("0\\leq G_{k_0,n}(t_1,\\ldots,t_n)\\leq 2^n(\\prod_{i=1}^n(1-t_i)_+^{k_0/2})G_{k_0}(0,0)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234704")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("Dear Gergely,")

#text("I think that the assertion that ")#mi("g_1 - R_{t_n} g_1")#text(" equals ")#mi("D_{t_n} g_1")#text(" on the support of ")#mi("R_{t_n} g_2")#text(" is not quite enough to conclude that ")#mi("\\langle g_1, R_{t_n} g_2 \\rangle_{t_1,\\ldots,t_{n-1}} - \\langle R_{t_n} g_1, R_{t_n} g_2 \\rangle_{t_1,\\ldots,t_{n-1}}")#text(" is equal to ")#mi("\\langle D_{t_n} g_1, R_{t_n} g_2 \\rangle_{t_1,\\ldots,t_{n-1}}")#text(" except when ")#mi("n=1")#text(", because of the non-local nature of the ")#mi("\\langle,\\rangle_{t_1,\\ldots,t_n}")#text(" bilinear form.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234738")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("You are right, I overlooked again. I found a new approach, please have a look at my comment below. Thanks for your patience and checking everything carefully!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234737")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("Terry is right, I was wrong again. But here is my fourth attempt to prove the same!")

#text("I will use the notation from my previous comment. Let ")#mi("g_1,g_2:[0,1]\\to\\mathbb{R}")#text(" be ")#mi("\\sigma")#text("-appropriate functions, and let")#linebreak()#text(" ")#mi("t_1,\\dots,t_n\\geq 0")#text(" be arbitrary numbers with sum ")#mi("t:=\\sum_{i=1}^n t_i<\\sigma")#text(". I claim that the function")

#mi("\\tau\\mapsto\\langle R_\\tau g_1,g_2\\rangle_{t_1,\\dots,t_n}")#text(" is decreasing on ")#mi("(0,\\sigma-t)")#text(".")

#text("As a simple consequence, we shall have")

#mi("\\langle g_1,g_2\\rangle_{t_1,\\dots,t_n}\\geq 0")#text(" for ")#mi("\\sum_{i=1}^n t_i<\\sigma")#text(".")

#text("We prove the monotonicity claim by induction on ")#mi("n")#text(". For ")#mi("n=0")#text(" the statement follows from the fact that ")#mi("g_1")#text(" and ")#mi("g_2")#text(" are nonnegative and decreasing. Now assume the statement for ")#mi("n-1\\geq 0")#text(" in place of ")#mi("n")#text(". For ")#mi("0<\\tau_1<\\tau_2<\\sigma-t")#text(" we obtain, by definition,")

#mi("\\langle R_{\\tau_1} g_1,g_2\\rangle_{t_1,\\dots,t_n}-\\langle R_{\\tau_2} g_1,g_2\\rangle_{t_1,\\dots,t_n}=\\int_{\\tau_1}^{\\tau_2}\\langle g_1^{\\tau},g_2\\rangle_{t_1,\\dots,t_n}\\ d\\tau")#text(",")

#text("where ")#mi("g_1^{\\tau}:=-R_\\tau g_1^{\\prime}")#text(" is ")#mi("(\\sigma-\\tau)")#text("-appropriate. Hence it suffices to show that")

#mi("\\langle g_1^{\\tau},g_2\\rangle_{t_1,\\dots,t_n}\\geq 0")#text(" for ")#mi("\\tau\\in(\\tau_1,\\tau_2)")#text(".")

#text("Renaming ")#mi("g_1^{\\tau}")#text(" to ")#mi("g_1")#text(", and ")#mi("\\sigma-\\tau")#text(" to ")#mi("\\sigma")#text(", we have reduced the induction step to the already mentioned consequence")

#mi("\\langle g_1,g_2\\rangle_{t_1,\\dots,t_n}\\geq 0")#text(" for ")#mi("\\sum_{i=1}^n t_i<\\sigma")#text(".")

#text("To see the last inequality, we combine the identity")

#mi("\\langle g_1,g_2\\rangle_{t_1,\\dots,t_n}=\\langle R_{t_n}g_1,g_2 \\rangle_{t_1,\\dots,t_{n-1}}+ \\langle g_1,R_{t_n}g_2 \\rangle_{t_1,\\dots,t_{n-1}}-\\langle R_{t_n}g_1,R_{t_n}g_2 \\rangle_{t_1,\\dots,t_{n-1}}")

#text("with the induction hypothesis. We obtain")

#mi("\\langle g_1,g_2\\rangle_{t_1,\\dots,t_n}\\geq\\langle R_{t_n}g_1,g_2 \\rangle_{t_1,\\dots,t_{n-1}}\\geq 0")#text(",")

#text("and we are done. As a useful consequence, the identity now implies")

#mi("\\langle g_1,g_2\\rangle_{t_1,\\dots,t_n}\\leq \\langle R_{t_n}g_1,g_2 \\rangle_{t_1,\\dots,t_{n-1}}+\\langle g_1,R_{t_n}g_2 \\rangle_{t_1,\\dots,t_{n-1}}")#text(".")

#text("By induction again and the remarks in my previous comment, we can now readily establish")

#tao-math("0\\leq\\langle g_1,g_2\\rangle_{t_1,\\dots,t_n}\\leq 2^n(\\prod_{i=1}^n(1-t_i)_+^{k_0/2})\\left\\|g_1\\right\\|\\left\\|g_2\\right\\|", block: false)#text(".")

#text("Specializing to ")#mi("g_1=g_2=g_{k_0}")#text(" and ")#mi("\\sigma=1")#text(" yields")

#mi("0\\leq G_{k_0,n}(t_1,\\ldots,t_n)\\leq 2^n(\\prod_{i=1}^n(1-t_i)_+^{k_0/2})G_{k_0}(0,0)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234756")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("Actually I am still not happy with the argument. Here are some thoughts that resonate with Terry’s earlier warnings.")

#text("1. We need to allow ")#mi("g_1")#text(" (resp. ")#mi("g_2")#text(") to be ")#mi("\\sigma_1")#text("-appropriate (resp. ")#mi("\\sigma_2")#text("-appropriate) with possibly different ")#mi("\\sigma_1,\\sigma_2\\geq\\sigma")#text(". We have no regularity at ")#mi("\\sigma_1")#text(" and ")#mi("\\sigma_2")#text(", so we cannot really go beyond the range ")#mi("t<\\min(\\sigma_1,\\sigma_2)")#text(" by considering higher derivatives. This means that the final conclusion")

#tao-math("0\\leq\\langle g_1,g_2\\rangle_{t_1,\\dots,t_n}\\leq 2^n(\\prod_{i=1}^n(1-t_i)_+^{k_0/2})\\left\\|g_1\\right\\|\\left\\|g_2\\right\\|", block: false)

#text("is restricted to ")#mi("\\sum_{i=1}^n t_i<1")#text(". Perhaps some combinatorial ideas can establish the lower bound in general, e.g. by cleverly arranging the terms in ")#mi("\\langle g_1,g_2\\rangle_{t_1,\\dots,t_n}")#text(", and then the upper bound follows as well. In fact we would only need the lower bound for ")#mi("g_1=g_2")#text(".")

#text("2. For similar reasons we cannot really deduce ")#mi("\\langle g_1,g_2\\rangle_{t_1,\\dots,t_n}\\geq 0")#text(" for ")#mi("t<\\sigma")#text(" from the fact that ")#mi("\\tau\\mapsto\\langle R_\\tau g_1,g_2\\rangle_{t_1,\\dots,t_n}")#text(" is decreasing on ")#mi("(0,\\sigma-t)")#text(". This can be remedied, however, by adding nonnegativity to the monotonicity statement, and inducting on ")#mi("n")#text(" for the stronger statement.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234765")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("Perhaps one should focus on the n=2 case for now, as this would generate the lion’s share of the savings even if it does not lead to the most elegant results.")

#text("In any event, for the specific example of Bessel functions, we should be able to get some more improvement in kappa from direct calculation of the n=1 terms rather than by upper bounds, but this would require numerical integration of Bessel functions of high order (not too computationally infeasible, but it may require a little more than simply using the off-the-shelf integration command for Maple/SAGE/Mathematica/etc. if one is to be confident about the accuracy of the integral). Although one thing that is working in our favour is that ")#mi("k_0")#text(" is now dropping to levels (such as 6329) in which accurate numerical computations for the relevant integrals look quite feasible.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234844")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("You are right about ")#mi("n=2")#text(", let me post a new comment about this below.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234758")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("There is a simpler and better way than using the trick with the (somewhat crude) inequality ")#tao-math("\\left|g(t + \\tau)\\right|  \\le \\left|g(t / (1 - \\tau))\\right|", block: false)#text(" above, the idea is to find the MINIMAL function ")#mi("K(\\tau)")#text(" satisfying")

#tao-math("\\left|g(t + \\tau)\\right| \\le K(\\tau) \\left|g(t)\\right|", block: false)#text(" whenever ")#mi("t, \\tau , t + \\tau")#text(" are in")#linebreak()#text(" ")#mi("[0, 1]")#text(", but for a specific ")#mi("g")#text(" proportional to the Bessel solution!")#linebreak()#text(" As it turns out, the solution is implied by the following sub-multiplicativity property for g (proportional to the Bessel solution) normalized to g(0) = 1:")

#mi("g(t + \\tau) \\le g(\\tau) g(t)")#text(" , whenever ")#mi("t, \\tau, t + \\tau")#text(" are in")#linebreak()#text(" ")#mi("[0, 1]")

#text("Clearly, this property should give simpler and better bounds. (I’ll send the details in some hours.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234845")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("For ")#mi("n=1,2")#text(" it is straightforward to generalize the treatment of ")#mi("G_{k_0-1,1}(t)")#text(" in the post. Let ")#mi("g_1,g_2:[0,1]\\to\\mathbb{R}")#text(" be nonnegative, continuous, and decreasing. Then")

#mi("\\langle g_1,g_2\\rangle_{t} = \\langle R_{t}g_1,g_2 \\rangle + \\langle g_1,R_{t}g_2 \\rangle - \\langle R_{t}g_1,R_{t}g_2 \\rangle\\geq \\langle R_{t}g_1,g_2 \\rangle\\geq 0")#text(",")

#text("and")

#tao-math("\\langle g_1,g_2\\rangle_{t} \\leq \\langle R_{t}g_1,g_2 \\rangle + \\langle g_1,R_{t}g_2 \\rangle\\leq 2(1-t)_+^{k_0/2}\\left\\|g_1\\right\\|\\left\\|g_2\\right\\|.", block: false)

#text("This implies")

#mi("\\langle g_1,g_2\\rangle_{t_1,t_2}=\\langle R_{t_2}g_1,g_2 \\rangle_{t_1}+ \\langle g_1,R_{t_2}g_2 \\rangle_{t_1}-\\langle R_{t_2}g_1,R_{t_2}g_2 \\rangle_{t_1}")

#tao-math("\\leq 2(1-t_1)_+^{k_0/2}(\\left\\|R_{t_2}g_1\\right\\|\\left\\|g_2\\right\\|+\\left\\|g_1\\right\\|\\left\\|R_{t_2}g_2\\right\\|)", block: false)

#tao-math("\\leq 4(1-t_1)_+^{k_0/2}(1-t_2)_+^{k_0/2}\\left\\|g_1\\right\\|\\left\\|g_2\\right\\|", block: false)#text(".")

#text("In addition,")

#mi("\\langle g_1,g_2\\rangle_{t_1,t_2}=\\langle R_{t_1+t_2}g_1,R_{t_1+t_2}g_2\\rangle")

#mi("+\\langle R_{t_1+t_2}g_1,(1-R_{t_1})g_2\\rangle+\\langle (1-R_{t_1})g_1,R_{t_1+t_2}g_2\\rangle")

#mi("+\\langle (R_{t_1}-R_{t_1+t_2})g_1,R_{t_2}g_2\\rangle+\\langle R_{t_2}g_1,(R_{t_1}-R_{t_1+t_2})g_2\\rangle\\geq 0")#text(".")

#text("This shows that")

#mi("0\\leq G_{k_0,n}(t_1,\\ldots,t_n)\\leq 2^n(\\prod_{i=1}^n(1-t_i)_+^{k_0/2})G_{k_0}(0,0)")

#text("is valid for ")#mi("n=1,2")#text(", and the same is true with ")#mi("k_0-1")#text(" in place of ")#mi("k_0")#text(". As a result, in the expression for ")#mi("\\kappa^{\\prime}")#text(", the term ")#mi("n=2")#text(" can be omitted, while for ")#mi("\\kappa")#text(" the ")#mi("n=2")#text(" term can be multiplied by ")#mi("\\frac{2^{n+1}}{3^n+1}=\\frac{4}{5}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234930")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2013")])]

#text("In the third line above (8), it should be trinomial (instead of binomial)")

#emph[#text("[Depends on how you count it. I used the sum and difference of binomial formulae ")#mi("3^n = \\sum_{i=0}^n 2^{n-i} \\binom{n}{i}")#text(" and ")#mi("1 = \\sum_{i=0}^n (-1)^i 2^{n-i} \\binom{n}{i}")#text(" to arrive at these conclusions. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234937")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2013")])]

#text("Thanks! (I used the equivalent expansions ")#mi("(1+1+1)^n")#text(" and")#linebreak()#text(" ")#mi("(1-1+1)^n")#text(")")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-235028")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("I think I proved that for any nonnegative, continuous, and decreasing functions ")#mi("g_1,g_2:[0,1]\\to\\mathbb{R}")#text(", and for any ")#mi("0\\leq t_1,\\dots,t_n<1")#text(",")

#mi("\\langle g_1,g_2\\rangle_{t_1,\\dots,t_n}\\geq 0")#text(".")

#text("We use the convention that ")#mi("g_1,g_2")#text(" are extended to be zero on ")#mi("(1,\\infty)")#text(", and we borrow notation from our earlier attempt (")#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234683")[#text("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234683")]#text("). Combining nonnegativity with the recursion identity")

#mi("\\langle g_1,g_2\\rangle_{t_1,\\dots,t_n}=\\langle R_{t_n}g_1,g_2 \\rangle_{*}+\\langle g_1,R_{t_n}g_2 \\rangle_{*}-\\langle R_{t_n}g_1,R_{t_n}g_2 \\rangle_{*}")#text(",")

#text("where * abbreviates ")#mi("t_1,\\dots,t_{n-1}")#text(", we obtain by induction")

#tao-math("0\\leq\\langle g_1,g_2\\rangle_{t_1,\\dots,t_n}\\leq 2^n(\\prod_{i=1}^n(1-t_i)_+^{k_0/2})\\left\\|g_1\\right\\|\\left\\|g_2\\right\\|", block: false)#text(".")

#text("This yields Theorem 2 with ")#mi("\\kappa^{\\prime}:=0")#text(" and")

#mi("\\kappa := \\sum_{1 \\leq n < \\frac{1+4\\varpi}{4\\delta}} \\frac{1}{n!} (2k_0\\int_{4\\delta/(1+4\\varpi)}^1 (1-t)^{k_0/2}\\ \\frac{dt}{t})^n")#text(".")

#text("The main idea of the proof is that ")#mi("g_1,g_2")#text(" can be approximated arbitrarily well in sup-norm by decreasing step functions, which in turn are nonnegative linear combinations of the characteristic functions ")#mi("\\alpha_\\tau:=1_{[0,1-\\tau]}")#text(" extended by zero on ")#mi("(1-\\tau,\\infty)")#text(". Hence it suffices to verify")

#mi("\\langle \\alpha_s,\\alpha_t\\rangle_{t_1,\\dots,t_n}\\geq 0")#text(" for any ")#mi("0\\leq s\\leq t<1")#text(".")

#text("We work with the measure ")#mi("x^{k_0-1}dx")#text(" supported on ")#mi("[0,1]")#text(", hence we have the scaling property")

#mi("\\langle \\alpha_s,\\alpha_t\\rangle_{t_1,\\dots,t_n}=(1-s)^{k_0}\\langle \\alpha_0,\\alpha_{\\frac{t-s}{1-s}}\\rangle_{t_1,\\dots,t_n}")#text(".")

#text("That is, we can restrict to ")#mi("s=0")#text(" without loss of generality, and it suffices to show")

#mi("\\langle \\alpha_0,\\alpha_t\\rangle_{t_1,\\dots,t_n}\\geq 0")#text(" for any ")#mi("0\\leq t<1")#text(".")

#text("We shall prove more, namely that the left hand side decreases in ")#mi("t")#text(". This implies nonnegativity, as the left hand side approaches zero for ")#mi("t\\to 1-")#text(".")

#text("With the convention that ")#mi("\\alpha_\\tau=0")#text(" for ")#mi("\\tau\\geq 1")#text(", the recursion identity expresses the left hand side as")

#mi("\\langle \\alpha_{t_n},\\alpha_t \\rangle_{*}+\\langle \\alpha_0,\\alpha_{t+t_n} \\rangle_{*}-\\langle \\alpha_{t_n},\\alpha_{t+t_n} \\rangle_{*}")#text(".")

#text("By the scaling property, we can rewrite this as")

#mi("(1-t_n)^{k_0}\\langle\\alpha_0,\\alpha_{\\frac{t-t_n}{1-t_n}}\\rangle_{*}+\\langle\\alpha_0,\\alpha_{t+t_n}\\rangle_{*} -(1-t_n)^{k_0}\\langle\\alpha_0,\\alpha_{\\frac{t}{1-t_n}}\\rangle_{*}")#text(" for ")#mi("t_n\\leq t")#text(",")

#mi("(1-t)^{k_0}\\langle\\alpha_0,\\alpha_{\\frac{t_n-t}{1-t}}\\rangle_{*}+\\langle\\alpha_0,\\alpha_{t+t_n}\\rangle_{*} -(1-t_n)^{k_0}\\langle\\alpha_0,\\alpha_{\\frac{t}{1-t_n}}\\rangle_{*}")#text(" for ")#mi("t\\leq t_n")#text(".")

#text("Based on these scaled recursion formulae, we shall prove the following claim by induction on ")#mi("n")#text(": for any fixed ")#mi("t_1,\\dots,t_n")#text(", there is a finite set ")#mi("S\\subset[0,1]")#text(" such that on any interval ")#mi("I\\subset[0,1]\\setminus S")#text(" the function ")#mi("f(t):=\\langle\\alpha_0,\\alpha_t\\rangle_{t_1,\\dots,t_n}")#text(" is of the form ")#mi("a_I(1-t)^{k_0}+b_I")#text(" with nonnegative constants ")#mi("a_I,b_I\\geq 0")#text(". The claim implies that ")#mi("f(t)")#text(" decreases on ")#mi("[0,1]\\setminus S")#text(", hence in fact on ")#mi("[0,1]")#text(" by its continuity in ")#mi("t")#text(".")

#text("Now we show the claim by induction on ")#mi("n")#text(". For ")#mi("n=0")#text(" the statement follows from ")#mi("\\langle\\alpha_0,\\alpha_t\\rangle=\\frac{1}{k_0}(1-t)_+^{k_0}")#text(". Let us assume the statement for ")#mi("n-1\\geq 0")#text(" in place of ")#mi("n")#text(". Let us fix ")#mi("t_1,\\dots,t_n")#text(", and consider the exceptional set ")#mi("S")#text(" corresponding to ")#mi("t_1,\\dots,t_{n-1}")#text(". Let ")#mi("\\tilde S\\subset[0,1]")#text(" be the set of points ")#mi("t\\in[0,1]")#text(" such that any of the following expressions lies in ")#mi("S")#text(": ")#mi("\\frac{t-t_n}{1-t_n}")#text(", ")#mi("\\frac{t_n-t}{1-t}")#text(", ")#mi("t+t_n")#text(", ")#mi("\\frac{t}{1-t_n}")#text(". Add ")#mi("t_n")#text(" also to ")#mi("\\tilde S")#text(". Now let ")#mi("I\\subset[0,1]\\setminus \\tilde S")#text(" be any interval. By the scaled recursion formulae and the induction hypothesis, there are nonnegative constants ")#mi("a_I,b_I\\geq 0")#text(", such that ")#mi("f(t):=\\langle\\alpha_0,\\alpha_t\\rangle_{t_1,\\dots,t_n}")#text(" takes one of the following two forms on all of ")#mi("I")#text(":")

#mi("(1-t_n)^{k_0}(a_I(1-\\frac{t-t_n}{1-t_n})^{k_0}+b_I)+(a_I(1-t-t_n)^{k_0}+b_I)")

#mi("-(1-t_n)^{k_0}(a_I(1-\\frac{t}{1-t_n})^{k_0}+b_I)")#text(",")

#text("or")

#mi("(1-t)^{k_0}(a_I(1-\\frac{t_n-t}{1-t})^{k_0}+b_I)+(a_I(1-t-t_n)^{k_0}+b_I)")

#mi("-(1-t_n)^{k_0}(a_I(1-\\frac{t}{1-t_n})^{k_0}+b_I)")#text(".")

#text("The first expression simplifies to ")#mi("a_I(1-t)^{k_0}+b_I")#text(", while the second simplifies to")

#mi("b_I(1-t)^{k_0}+a_I(1-t_n)^{k_0}+(1-(1-t_n)^{k_0})b_I")#text(".")

#text("In both cases ")#mi("f(t)")#text(" is of the form ")#mi("\\tilde a_I(1-t)^{k_0}+\\tilde b_I")#text(" on ")#mi("I")#text(", where ")#mi("\\tilde a_I,\\tilde b_I\\geq 0")#text(" are nonnegative constants, hence we are done.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-235034")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("Actually this proof gives the stronger statement that I anticipated before:")

#mi("\\tau\\mapsto\\langle R_\\tau g_1,g_2\\rangle_{t_1,\\dots,t_n}")#text(" decreases on ")#mi("[0,1]")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-235039")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("Actually, I erred again, in the last step: I proceeded as if each of ")#mi("\\frac{t-t_n}{1-t_n}")#text(", ")#mi("\\frac{t_n-t}{1-t}")#text(", ")#mi("t+t_n")#text(", ")#mi("\\frac{t}{1-t_n}")#text(" mapped ")#mi("I")#text(" into the same interval lying in ")#mi("[0,1]\\setminus S")#text(". This is clearly false. Nevertheless, I believe the ideas in this approach are good ones. One needs to understand ")#mi("\\langle \\alpha_0,\\alpha_t\\rangle_{t_1,\\dots,t_n}")#text(" explicitly enough to conclude that it is nonnegative. I believe this is doable (although not really important for the project).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-235215")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("The statement I tried to prove here is false, see ")#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235214")[#text("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235214")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A truncated elementary Selberg sieve of Pintz | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-235107")[#strong[#text("A truncated elementary Selberg sieve of Pintz | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("[…] post is a continuation of the previous post on sieve theory, which is an ongoing part of the Polymath8 project. As the previous post was getting somewhat full, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-235115")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("Time to close this thread and move on to the next one:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/")[#text("A truncated elementary Selberg sieve of Pintz")]
]
]
