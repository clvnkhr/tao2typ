// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/
// Converted to Typst by tao2typ: "2026-10-14T15:16:34.756360+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "PCM article: Differential forms", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("PCM article: Differential forms")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 December 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/")[#text("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("I’m continuing my ")#link("https://terrytao.wordpress.com/category/paper/companion/")[#text("series of articles")]#text(" for the ")#link("http://gowers.wordpress.com/2007/09/06/hello-world/")[#text("Princeton Companion to Mathematics")]#text(" through the holiday season with my article on “")#link("http://www.math.ucla.edu/~tao/preprints/forms.pdf")[#text("Differential forms and integration")]#text("“. This is my attempt to explain the concept of a ")#link("http://en.wikipedia.org/wiki/Differential_form")[#text("differential form")]#text(" in differential geometry and several variable calculus; which I view as an extension of the concept of the ")#emph[#text("signed integral")]#text(" in single variable calculus. I briefly touch on the important concept of ")#link("http://en.wikipedia.org/wiki/De_Rham_cohomology")[#text("de Rham cohomology")]#text(", but mostly I stick to fundamentals.")

#text("I would also like to highlight ")#link("http://en.wikipedia.org/wiki/Doron_Zeilberger")[#text("Doron Zeilberger")]#text("‘s PCM article “")#link("http://www.math.rutgers.edu/~zeilberg/mamarim/mamarimhtml/enu.html")[#text("Enumerative and Algebraic combinatorics")]#text("“. This article describes the art of how to usefully count the number of objects of a given type exactly; this subject has a rather algebraic flavour to it, in contrast with asymptotic combinatorics, which is more concerned with computing the ")#link("http://en.wikipedia.org/wiki/Order_of_magnitude")[#text("order of magnitude")]#text(" of number of objects in a class. The two subjects complement each other; for instance, in my own work, I have found enumerative and other algebraic methods tend to be useful for controlling “main terms” in a given expression, while asymptotic and other analytic methods tend to be good at controlling “error terms”.")

#heading(level: 1)[#text("Comments (23)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c36abc819a6f677defa6ba3c408a97bffe2efa24e82fcfca5703ef73e9a87888-4e318a7da43897d74b01c84efb8d07bc264d85aa2fabd65ef866bc106874b4d5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frank Morgan")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-22058")[#strong[#text("Frank Morgan")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2007")])]

#text("DIFFERENTIAL FORMS. Geometric measure theory has a more direct and general definition of the integral of a differential form, which requires no parametrization and applies to any kD rectifiable subset of R^n. It uses kD Hausdorff measure (which can be defined in one line) and the fact that a kD rectifiable set has an (approximate) tangent plane at almost every point. Namely, apply the differential form to the tangent plane and integrate with respect to Hausdorff measure. This definition is also more clearly related to the unsigned definite integral.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fac38f934cad15875a729896f1c111c7e3fc13cdf63eaa028bf4d546e794975a-1637a5ba3dac5af648541cc6b1ee6a609f4855477b5ebb50f4284f9e4412784f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of finelli")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-22075")[#strong[#text("finelli")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2007")])]

#text("I think I spotted a typo in the paper ")#link("http://www.math.ucla.edu/~tao/preprints/forms.pdf")[#text("http://www.math.ucla.edu/~tao/preprints/forms.pdf")]

#text("If I am not mistaken, on page 5 it should read")#linebreak()#text(" $f(x+v) \\approx f(x) + df_x(v)$ and consequently the equation just below.")

#text("Thank you for your wonderful papers !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-22100")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2007")])]

#text("Dear finelli: Thanks for the correction!")

#text("Dear Frank: Thanks for the comment! It appears to me that one also needs to specify an orientation on each tangent plane in order to define the integral of a form properly (and in case the subset is a non-orientable manifold, this orientation will necessarily be discontinuous) but still, the point that the signed definite integral (i.e. integration of forms) can be represented in terms of the unsigned one (integration against a measure) is a valid one. Which notion of integral is “better” probably depends on what type of mathematics one is doing, though. For geometric measure theory, integration against a measure is much more important than integration on forms (as term “measure” in “geometric measure theory” already suggests); but for differential topology, for instance, the reverse would be true.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-22113")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2007")])]

#text("This was a very nice little article. I am a second year graduate student and I am planning to study Geometry and I find that differential forms, among my fellows students as well, are very difficult objects to understand well. Even after doing many textbook problems and computations, I often find myself discovering “simple” features that had eluded me in the past. I think the difficulty lies in the variety of ways in which they can be described; certainly being told they’re sections of the exterior algebra of the cotangent bundle is probably the least illuminating for most first year graduate students. I especially liked the intuitive description of them as “infinitesimal” multi-linear maps, which would fall under the category of “simple” feature I mentioned earlier. Nevertheless, thanks for this addition. I am always excited to hear intuitive surveys of topics that are all too often immediately treated with a “cold” formalism and are thus abstruse even to students that might pretend to understand them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/086fffb5e07bc6794374ab66b785bda9fffab5f3f33bdd6aa42a199d09d101a2-91fbf3eed2d2c362cffe07e05a089b5971e48081078cd2e95a3747e0ac183ef5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Kinyon")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-22134")[#strong[#text("Michael Kinyon")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2007")])]

#text("Terry:")#linebreak()#text(" There are various books out there (Edwards, Flanders, Bressoud, etc.) which use differential forms, but the whole idea finally clicked for me when I found the marvelous “Applied Differential Geometry” by the late William L. Burke. It’s certainly not the book one should look to for formalities, but it has the best pictures around. Please have a look at it if you haven’t already done so.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c36abc819a6f677defa6ba3c408a97bffe2efa24e82fcfca5703ef73e9a87888-4e318a7da43897d74b01c84efb8d07bc264d85aa2fabd65ef866bc106874b4d5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frank Morgan")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-22146")[#strong[#text("Frank Morgan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2007")])]

#text("GEOMETRIC MEASURE THEORY. Differential forms are actually fundamental to geometric measure theory, where the space of generalized kD surfaces (with unrestricted topology and singularities) called “currents” is defined as the dualspace of the space of smooth differential forms. In other words, a surface is defined by what you get when you integrate differential forms over it. The space of all currents is too big, so one restricts attention to the “rectifiable currents” associated with rectifiable sets.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of davidspeyer")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-22181")[#strong[#text("davidspeyer")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2007")])]

#text("This article would have been a big help to me when I was first trying, and failing, to understand differential forms. I’ll certainly consult it if I have to teach about them.")

#text("Is there any chance of a follow up article explaining the definition of the exterior derivative in equally well motivated terms? To me, this is still one of those things that I just have to accept without understanding.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Carney")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-22202")[#strong[#text("Dan Carney")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2007")])]

#text("Hi Prof. Tao,")

#text("When you define the derivative df of a function f:R^n -> R on the top of page 5, you do so by demanding that it gives the first order Taylor approximation mentioned in a comment above,")

#text("f(x+v) \\approx f(x) + df_x(v).")

#text("This is fine in R^n since the tangent space of any point is just a copy of the base manifold, but I don’t see the generalization to a generic manifold where this is no longer true. Since I too am still trying to make sense out of the exterior derivative, I was wondering how you would explain how the construction makes sense in general.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-22253")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2007")])]

#text("Dear Dan: well, the quick and dirty fix is simply to place an arbitrary smooth coordinate chart on the manifold near x, and verify by hand that the above definition is consistent across all changes of coordinate charts. Another approach is to go back to the abstract definition of the tangent space ")#mi("T_x M")#text(", which is the space of all curves ")#mi("\\gamma: [-1,1] \\to M")#text(" with ")#mi("\\gamma(0)=x")#text(", with two curves ")#mi("\\gamma, \\tilde \\gamma")#text(" which are tangent to each other in the sense that ")#tao-math("\\text{dist}(\\gamma(t), \\tilde \\gamma(t)) = o(\\left|t\\right|)", block: false)#text(" as ")#mi("t \\to 0")#text(" are considered equivalent. Such curves give a way to make sense of ")#mi("x+tv")#text(" for ")#mi("v \\in T_x M")#text(", up to errors of ")#tao-math("o(\\left|t\\right|)", block: false)#text(" which can be hidden inside the ")#mi("\\approx")#text(" notation that I didn’t bother defining.")

#text("More generally, at the infinitesimal level, all errors of o(|t|) can be ignored (until one starts differentiating twice or more, but we’re not doing that here), and so all smooth manifolds can be viewed as infinitesimally flat for the purposes of first derivatives. Curvature only shows up at the second derivative level.")

#text("Dear David: I’m afraid I only have some unsatisfactory “motivations” for the exterior derivative also. One way is to decide from the fundamental theorem of calculus that differentiation is the adjoint of the boundary operation ")#mi("\\partial")#text(", and then seek to compute what the adjoint of the boundary operator ")#mi("\\partial")#text(" in higher dimensions is (i.e. to derive Stokes’ theorem). Another motivation is to try to work out the correct notion of a derivation is on an exterior algebra; there is basically only one non-trivial notion which is compatible with the antisymmetry of the wedge product, and then d is going to be the only such derivation (up to scalars) from k forms to k+1 forms which is covariant (I think). A third way that appeals to my Fourier-analytic background is to write ")#mi("d\\omega = i\\xi \\wedge \\omega")#text(", where ")#mi("\\xi")#text(" is the 1-form that represents the “frequency” of ")#mi("\\omega")#text(". (This can be made rigorous using Fourier analysis or pseudodifferential calculus.) Viewed in this way, d is basically the only natural operation that combines the k-form ")#mi("\\omega")#text(" with the 1-form of frequency.")

#text("Dear Michael: Thanks for the reference. I myself learnt forms initially the old-fashioned way, from Spivak, but I really only understood it when I got frustrated at doing differential geometry computations in coordinates and decided that there had to be a better way.")

#text("Dear Frank: Thanks again for the comments. I was vaguely aware of currents as some sort of “weighted combination of surfaces” but didn’t realise that they were defined as the dual to smooth forms (much as distributions are the dual to test functions, I suppose.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-22273")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2007")])]

#text("Another way to define the operator ")#mi("d")#text(" which is somewhat abstract at first but very convenient comes from interpreting the tangent space at ")#mi("x")#text(" as the linear space of derivations on the space ")#mi("L=C^{\\infty}(X)")#text(" of smooth (say real-valued) functions on ")#mi("X")#text(" which are “based at ")#mi("x")#text("“: a tangent vector ")#mi("v")#text(" is then seen as an ")#mi("\\mathbf{R}")#text("-linear map ")#mi("v:L\\rightarrow \\mathbf{R}")#text(" such that")

#mi("v(fg)=v(f)g(x)+v(g)f(x)")

#text("for all functions ")#mi("f")#text(" and ")#mi("g")#text(". [In a chart centered at ")#mi("{}0")#text(", this amounts to interpreting, say, a unit tangent vector in the ")#mi("i")#text("-th coordinate direction as the operator of partial derivation in this direction, evaluated at the origin.]")

#text("Then ")#mi("df")#text(", which at ")#mi("x")#text(" must map a tangent vector ")#mi("v")#text(" to a number, is simply the map ")#mi("v\\mapsto v(f)")#text(", i.e., evaluating the “variable” derivation for the given function.")

#text("(This approach has the feature of working essentially unchanged in algebraic geometry.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-22274")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2007")])]

#text("P.S. I noticed the following typos:")

#text("page 2 line 1 delete “the”")#linebreak()#text(" page 7, line 19, a backslash is missing in one R^n")#linebreak()#text(" page 8, line -10, there seems to be missing “=0” at the end of the line.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-22330")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2007")])]

#text("Dear Emmanuel: Thanks for the corrections! I do find the abstract approach of viewing the tangent bundle as the space of derivations on some abstract algebra ")#mi("L")#text(", then defining forms etc. by purely algebraic means to be very pretty. Indeed, with this approach, one doesn’t even really need to know that there is an underlying space X consisting of points x involved at all. In differential geometry, this approach leads to various extremely clean proofs of geometric identities (e.g. Bianchi identities for curvature), without any messing around with infinitesimals or limits at all. Though I did find it tricky to connect this “point-less” perspective with geometric intuition, at times…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-670819")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2022")])]

#text("Is there any tradeoff with using the clean algebraic approach? Does one ")#emph[#text("have")]#text(" to use “infinitesimals” or “limits” at some point?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-670843")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2022")])]

#text("The literature on ")#link("https://en.wikipedia.org/wiki/Synthetic_differential_geometry")[#text("synthetic differential geometry")]#text(" has, I believe, largely replicated all the key features of traditional differential geometry in a purely algebraic format without limits, though they still use infinitesimals as a substitute for limits. The field of ")#link("https://en.wikipedia.org/wiki/Noncommutative_geometry")[#text("noncommutative geometry ")]#text(" also adopts a primarily algebraic approach. There are also other more classical ways to work with differential forms on manifolds, such as relying on ")#text("Cartan’s moving frames")#text(" formalism rather than on coordinate systems. So there are a lot of options and to some extent the formalism one selects is a matter of personal preference, its ease of calculation, its familiarity with the target audience, and whether it conveys the geometric intuition one wishes to exploit and communicate. I personally am most comfortable with the traditional formalism of tensor fields (manipulated for instance using Penrose abstract index notation), but in certain situations other formalisms may be more convenient to use.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-22604")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2007")])]

#text("Reading the article was very useful to me. Two typos to report:")

#text("page 2, end of the fifth (counting backwards) line before eq. (3): “be to” should probably be “to be”;")

#text("page 9, towards the end of the second paragraph: probably “")#mi("\\Phi(S) in Y")#text("“, not “")#mi("\\Phi(S) in X")#text("“.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-22766")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2008")])]

#text("Dear t8m8r: Thanks for the corrections to this article, and the phase space article also!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Orr")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-22803")[#strong[#text("Orr")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2008")])]

#text("Dear Prof. Tao,")#linebreak()#text(" This exposition is more or less the opposite of any exposition I ever saw in a course or textbook and it is therefore very illuminating, thanks!")

#text("Here are some (perhaps) typos that haven’t been mentioned above:")#linebreak()#text(" page 6, the first line of equations – should muliply by delta t.")#linebreak()#text(" page 9, line 7, perhaps it should be “… another n-form fdx_1 …”")#linebreak()#text(" page 9, line 6 into the second paragraph, perhaps you meant “…based at phi(x)”.")#linebreak()#text(" Also, in page 9, there is some confusion between capital phi and lowercase phi.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-22964")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2008")])]

#text("Thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-51094")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2011")])]

#text("What type of the line integrals with respect to arc length in differential geometry? It seems that there is no “sign” and it is not a “anti-derivative”. So is it the “unsigned definite integral”?")

#text("Generally speaking, can one say that all kinds of integration can be categorized into these three concepts? What about the integration in complex analysis? Are they kind of the same as those in the real world(say, can also be put into these three categories) though they have some special properties?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-203671")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2012")])]

#text("What “definition” do you use for integration of forms? In page 5 of the article, you points out a connection between integration of differential forms and the Lebesgue (or Riemann) integral. I saw several textbooks actually use this connection to “define” integration of differential forms. Is there an advantage of not defining it in terms of the Lebesgue (or Riemann) integral?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 255B, Notes 1: The Lagrangian formulation of the Euler equations | What's new")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-508851")[#strong[#text("255B, Notes 1: The Lagrangian formulation of the Euler equations | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2018")])]

#text("[…] we will pull back are that of differential forms, which we will define using coordinates. (See also my previous notes on this topic for more discussion on differential forms.) For any , a -form on will be defined as a family of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-642523")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2022")])]

#text("On page 7, it is said that")#linebreak()#text(" ")#emph[#linebreak()#text(" By convention, if ")#mi("k\\ne k^{\\prime}")#text(", the integral of a ")#mi("k")#text("-dimensional form on a ")#mi("k^{\\prime}")#text("-dimensional surface is understood to be zero.")#linebreak()#text(" ")]#linebreak()#text(" I may misread something in the article. Isn’t the line integral in the plane a 1-dimensional form on a 2-dimensional (trivial) surface that is not necessarily zero?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/#comment-642536")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2022")])]

#text("Line integrals are on one-dimensional curves, which may be contained in 2-dimensional surfaces, but the integral is not being performed on the entirety of the surface.")
]
]
