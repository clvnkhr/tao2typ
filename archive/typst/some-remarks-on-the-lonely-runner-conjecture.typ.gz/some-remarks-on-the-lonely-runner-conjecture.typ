// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T15:19:50.741640+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Some remarks on the lonely runner conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Some remarks on the lonely runner conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 January 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/")[#text("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper “")#link("https://arxiv.org/abs/1701.02048")[#text("Some remarks on the lonely runner conjecture")]#text("“, submitted to ")#link("http://cdm.ucalgary.ca/cdm/index.php/cdm")[#text("Contributions to discrete mathematics")]#text(". I had blogged about the ")#link("https://en.wikipedia.org/wiki/Lonely_runner_conjecture")[#text("lonely runner conjecture")]#text(" in ")#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/")[#text("this previous blog post")]#text(", and I returned to the problem recently to see if I could obtain anything further. The results obtained were more modest than I had hoped, but they did at least seem to indicate a potential strategy to make further progress on the problem, and also highlight some of the difficulties of the problem.")

#text("One can rephrase the lonely runner conjecture as the following covering problem. Given any integer “velocity” ")#mi("{v}")#text(" and radius ")#mi("{0 < \\delta < 1/2}")#text(", define the ")#emph[#text("Bohr set")]#text(" ")#mi("{B(v,\\delta)}")#text(" to be the subset of the unit circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(" given by the formula")

#align(center)[#tao-fit-display[#tao-math("B(v,\\delta) := \\{ t \\in {\\bf R}/{\\bf Z}: \\left\\|vt\\right\\| \\leq \\delta \\},", block: true)]]

#text("where ")#tao-math("{\\left\\|x\\right\\|}", block: false)#text(" denotes the distance of ")#mi("{x}")#text(" to the nearest integer. Thus, for ")#mi("{v}")#text(" positive, ")#mi("{B(v,\\delta)}")#text(" is simply the union of the ")#mi("{v}")#text(" intervals ")#mi("{[\\frac{a-\\delta}{v}, \\frac{a+\\delta}{v}]}")#text(" for ")#mi("{a=0,\\dots,v-1}")#text(", projected onto the unit circle ")#mi("{{\\bf R}/{\\bf Z}}")#text("; in the language of the usual formulation of the lonely runner conjecture, ")#mi("{B(v,\\delta)}")#text(" represents those times in which a runner moving at speed ")#mi("{v}")#text(" returns to within ")#mi("{\\delta}")#text(" of his or her starting position. For any non-zero integers ")#mi("{v_1,\\dots,v_n}")#text(", let ")#mi("{\\delta(v_1,\\dots,v_n)}")#text(" be the smallest radius ")#mi("{\\delta}")#text(" such that the ")#mi("{n}")#text(" Bohr sets ")#mi("{B(v_1,\\delta),\\dots,B(v_n,\\delta)}")#text(" cover the unit circle: ")#metadata(none) <tao-3fa405a8301ace34d11c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("{\\bf R}/{\\bf Z} = \\bigcup_{i=1}^n B(v_i,\\delta).")]]



#text(" Then define ")#mi("{\\delta_n}")#text(" to be the smallest value of ")#mi("{\\delta(v_1,\\dots,v_n)}")#text(", as ")#mi("{v_1,\\dots,v_n}")#text(" ranges over tuples of distinct non-zero integers. The ")#link("https://en.wikipedia.org/wiki/Dirichlet's_approximation_theorem")[#text("Dirichlet approximation theorem")]#text(" quickly gives that")

#align(center)[#tao-fit-display[#mitex("\\delta(1,\\dots,n) = \\frac{1}{n+1}")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("\\delta_n \\leq \\frac{1}{n+1}")]]

#text("for any ")#mi("{n \\geq 1}")#text(". The lonely runner conjecture is equivalent to the assertion that this bound is in fact optimal:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Lonely runner conjecture)")]#text(" For any ")#mi("{n \\geq 1}")#text(", one has ")#mi("{\\delta_n = \\frac{1}{n+1}}")#text(".")
]

#text("This conjecture is currently known for ")#mi("{n \\leq 6}")#text(" (see ")#link("http://www.ams.org/mathscinet-getitem?mr=2398840")[#text("this paper of Barajas and Serra")]#text("), but remains open for higher ")#mi("{n}")#text(".")

#text("It is natural to try to attack the problem by establishing lower bounds on the quantity ")#mi("{\\delta_n}")#text(". We have the following “trivial” bound, that gets within a factor of two of the conjecture:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Trivial bound)")]#text(" For any ")#mi("{n \\geq 1}")#text(", one has ")#mi("{\\delta_n \\geq \\frac{1}{2n}}")#text(".")
]

#emph[#text("Proof:")]#text(" It is not difficult to see that for any non-zero velocity ")#mi("{v}")#text(" and any ")#mi("{0 < \\delta < 1/2}")#text(", the Bohr set ")#mi("{B(v,\\delta)}")#text(" has Lebesgue measure ")#mi("{m(B(v,\\delta)) = 2\\delta}")#text(". In particular, by the union bound ")#metadata(none) <tao-ef3ff703d7565ab5215c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("m(\\bigcup_{i=1}^n B(v_i,\\delta)) \\leq \\sum_{i=1}^n m(B(v_i,\\delta))")]]



#text(" we see that the covering ")#link(<tao-3fa405a8301ace34d11c>)[#text("(1)")]#text(" is only possible if ")#mi("{1 \\leq 2 n \\delta}")#text(", giving the claim. ")#mi("\\Box")

#text("So, in some sense, all the difficulty is coming from the need to improve upon the trivial union bound ")#link(<tao-ef3ff703d7565ab5215c>)[#text("(2)")]#text(" by a factor of two.")

#text("Despite the crudeness of the union bound ")#link(<tao-ef3ff703d7565ab5215c>)[#text("(2)")]#text(", it has proven surprisingly hard to make substantial improvements on the trivial bound ")#mi("{\\delta_n \\geq \\frac{1}{2n}}")#text(". In 1994, ")#link("http://www.ams.org/mathscinet-getitem?mr=1337104")[#text("Chen")]#text(" obtained the slight improvement")

#align(center)[#tao-fit-display[#mitex("\\delta_n \\geq \\frac{1}{2n - 1 + \\frac{1}{2n-3}}")]]

#text("which was improved a little ")#link("http://www.ams.org/mathscinet-getitem?mr=1670560")[#text("by Chen and Cusick")]#text(" in 1999 to")

#align(center)[#tao-fit-display[#mitex("\\delta_n \\geq \\frac{1}{2n-3}")]]

#text("when ")#mi("{2n-3}")#text(" was prime. In a ")#link("http://www.ams.org/mathscinet-getitem?mr=3484755")[#text("recent paper of Perarnau and Serra")]#text(", the bound")

#align(center)[#tao-fit-display[#mitex("\\delta_n \\geq \\frac{1}{2n-2+o(1)}")]]

#text("was obtained for arbitrary ")#mi("{n}")#text(". These bounds only improve upon the trivial bound by a multiplicative factor of ")#mi("{1+O(1/n)}")#text(". Heuristically, one reason for this is as follows. The union bound ")#link(<tao-ef3ff703d7565ab5215c>)[#text("(2)")]#text(" would of course be sharp if the Bohr sets ")#mi("{B(v_i,\\delta)}")#text(" were all disjoint. Strictly speaking, such disjointness is not possible, because all the Bohr sets ")#mi("{B(v_i,\\delta)}")#text(" have to contain the origin as an interior point. However, it is possible to come up with a large number of Bohr sets ")#mi("{B(v_i,\\delta)}")#text(" which are ")#emph[#text("almost")]#text(" disjoint. For instance, suppose that we had velocities ")#mi("{v_1,\\dots,v_s}")#text(" that were all prime numbers between ")#mi("{n/4}")#text(" and ")#mi("{n/2}")#text(", and that ")#mi("{\\delta}")#text(" was equal to ")#mi("{\\delta_n}")#text(" (and in particular was between ")#mi("{1/2n}")#text(" and ")#mi("{1/(n+1)}")#text(". Then each set ")#mi("{B(v_i,\\delta)}")#text(" can be split into a “kernel” interval ")#mi("{[-\\frac{\\delta}{v_i}, \\frac{\\delta}{v_i}]}")#text(", together with the “petal” intervals ")#mi("{\\bigcup_{a=1}^{v_i-1} [\\frac{a-\\delta}{v_i}, \\frac{a+\\delta}{v_i}]}")#text(". Roughly speaking, as the prime ")#mi("{v_i}")#text(" varies, the kernel interval stays more or less fixed, but the petal intervals range over disjoint sets, and from this it is not difficult to show that")

#align(center)[#tao-fit-display[#mitex("m(\\bigcup_{i=1}^s B(v_i,\\delta)) = (1-O(\\frac{1}{n})) \\sum_{i=1}^s m(B(v_i,\\delta)),")]]

#text("so that the union bound is within a multiplicative factor of ")#mi("{1+O(\\frac{1}{n})}")#text(" of the truth in this case.")

#text("This does not imply that ")#mi("{\\delta_n}")#text(" is within a multiplicative factor of ")#mi("{1+O(1/n)}")#text(" of ")#mi("{\\frac{1}{2n}}")#text(", though, because there are not enough primes between ")#mi("{n/4}")#text(" and ")#mi("{n/2}")#text(" to assign to ")#mi("{n}")#text(" distinct velocities; indeed, by the prime number theorem, there are only about ")#mi("{\\frac{n}{4\\log n}}")#text(" such velocities that could be assigned to a prime. So, while the union bound could be close to tight for up to ")#mi("{\\asymp n/\\log n}")#text(" Bohr sets, the above counterexamples don’t exclude improvements to the union bound for larger collections of Bohr sets. Following this train of thought, I was able to obtain a logarithmic improvement to previous lower bounds:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(" For sufficiently large ")#mi("{n}")#text(", one has ")#mi("{\\delta_n \\geq \\frac{1}{2n} + \\frac{c \\log n}{n^2 (\\log\\log n)^2}}")#text(" for some absolute constant ")#mi("{c>0}")#text(".")
]

#text("The factors of ")#mi("{\\log\\log n}")#text(" in the denominator are for technical reasons and might perhaps be removable by a more careful argument. However it seems difficult to adapt the methods to improve the ")#mi("{\\log n}")#text(" in the numerator, basically because of the obstruction provided by the near-counterexample discussed above.")

#text("Roughly speaking, the idea of the proof of this theorem is as follows. If we have the covering ")#link(<tao-3fa405a8301ace34d11c>)[#text("(1)")]#text(" for ")#mi("{\\delta}")#text(" very close to ")#mi("{1/2n}")#text(", then the multiplicity function ")#mi("{\\sum_{i=1}^n 1_{B(v_i,\\delta)}}")#text(" will then be mostly equal to ")#mi("{1}")#text(", but occasionally be larger than ")#mi("{1}")#text(". On the other hand, one can compute that the ")#mi("{L^2}")#text(" norm of this multiplicity function is significantly larger than ")#mi("{1}")#text(" (in fact it is at least ")#mi("{(3/2-o(1))^{1/2}}")#text("). Because of this, the ")#mi("{L^3}")#text(" norm must be very large, which means that the triple intersections ")#mi("{B(v_i,\\delta) \\cap B(v_j,\\delta) \\cap B(v_k,\\delta)}")#text(" must be quite large for many triples ")#mi("{(i,j,k)}")#text(". Using some basic Fourier analysis and additive combinatorics, one can deduce from this that the velocities ")#mi("{v_1,\\dots,v_n}")#text(" must have a large structured component, in the sense that there exists an arithmetic progression of length ")#mi("{\\asymp n}")#text(" that contains ")#mi("{\\asymp n}")#text(" of these velocities. For simplicity let us take the arithmetic progression to be ")#mi("{\\{1,\\dots,n\\}}")#text(", thus ")#mi("{\\asymp n}")#text(" of the velocities ")#mi("{v_1,\\dots,v_n}")#text(" lie in ")#mi("{\\{1,\\dots,n\\}}")#text(". In particular, from the prime number theorem, most of these velocities will not be prime, and will in fact likely have a “medium-sized” prime factor (in the precise form of the argument, “medium-sized” is defined to be “between ")#mi("{\\log^{10} n}")#text(" and ")#mi("{n^{1/10}}")#text("“). Using these medium-sized prime factors, one can show that many of the ")#mi("{B(v_i,\\delta)}")#text(" will have quite a large overlap with many of the other ")#mi("{B(v_j,\\delta)}")#text(", and this can be used after some elementary arguments to obtain a more noticeable improvement on the union bound ")#link(<tao-ef3ff703d7565ab5215c>)[#text("(2)")]#text(" than was obtained previously.")

#text("A modification of the above argument also allows for the improved estimate ")#metadata(none) <tao-b38efe8153f5a54aca84>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\delta(v_1,\\dots,v_n) \\geq \\frac{1+c-o(1)}{2n}")]]



#text(" if one knows that ")#emph[#text("all")]#text(" of the velocities ")#mi("{v_1,\\dots,v_n}")#text(" are of size ")#mi("{O(n)}")#text(".")

#text("In my previous blog post, I showed that in order to prove the lonely runner conjecture, it suffices to do so under the additional assumption that all of the velocities ")#mi("{v_1,\\dots,v_n}")#text(" are of size ")#mi("{O(n^{O(n^2)})}")#text("; I reproduce this argument (slightly cleaned up for publication) in the current preprint. There is unfortunately a huge gap between ")#mi("{O(n)}")#text(" and ")#mi("{O(n^{O(n^2)})}")#text(", so the above bound ")#link(<tao-b38efe8153f5a54aca84>)[#text("(3)")]#text(" does not immediately give any new bounds for ")#mi("{\\delta_n}")#text(". However, one could perhaps try to start attacking the lonely runner conjecture by increasing the range ")#mi("{O(n)}")#text(" for which one has good results, and by decreasing the range ")#mi("{O(n^{O(n^2)})}")#text(" that one can reduce to. For instance, in the current preprint I give an elementary argument (using a certain amount of case-checking) that shows that the lonely runner bound ")#metadata(none) <tao-970b1897af0abab6127d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\delta(v_1,\\dots,v_n) \\geq \\frac{1}{n+1}")]]



#text(" holds if all the velocities ")#mi("{v_1,\\dots,v_n}")#text(" are assumed to lie between ")#mi("{1}")#text(" and ")#mi("{1.2 n}")#text(". This upper threshold of ")#mi("{1.2 n}")#text(" is only a tiny improvement over the trivial threshold of ")#mi("{n}")#text(", but it seems to be an interesting sub-problem of the lonely runner conjecture to increase this threshold further. One key target would be to get up to ")#mi("{2n}")#text(", as there are actually a number of ")#mi("{n}")#text("-tuples ")#mi("{(v_1,\\dots,v_n)}")#text(" in this range for which ")#link(<tao-970b1897af0abab6127d>)[#text("(4)")]#text(" holds with equality. The Dirichlet approximation theorem of course gives the tuple ")#mi("{(1,2,\\dots,n)}")#text(", but there is also the double ")#mi("{(2,4,\\dots,2n)}")#text(" of this tuple, and furthermore there is an additional construction of ")#link("http://www.ams.org/mathscinet-getitem?mr=2280354")[#text("Goddyn and Wong")]#text(" that gives some further examples such as ")#mi("{(1,2,3,4,5,7,12)}")#text(", or more generally one can start with the standard tuple ")#mi("{(1,\\dots,n)}")#text(" and accelerate one of the velocities ")#mi("{v}")#text(" to ")#mi("{2v}")#text("; this turns out to work as long as ")#mi("{v}")#text(" shares a common factor with every integer between ")#mi("{n-v+1}")#text(" and ")#mi("{2n-2v+1}")#text(". There are a few more examples of this type in the paper of Goddyn and Wong, but all of them can be placed in an arithmetic progression of length ")#mi("{O(n \\log n)}")#text(" at most, so if one were very optimistic, one could perhaps envision a strategy in which the upper bound of ")#mi("{O(n^{O(n^2)})}")#text(" mentioned earlier was reduced all the way to something like ")#mi("{O( n \\log n )}")#text(", and then a separate argument deployed to treat this remaining case, perhaps isolating the constructions of Goddyn and Wong (and possible variants thereof) as the only extreme cases.")

#heading(level: 1)[#text("Comments (32)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-476410")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2017")])]

#text("You’re probably well aware of this but the lonely runner conjecture is just one of a surprisingly large collection of questions arising from different areas of mathematics that can be formulated in the following manner: Let ")#mi("F: \\mathbb{R} / \\mathbb{Z} \\rightarrow \\mathbb{R}")#text(" be a mean-zero function. Obtain an estimate from below for the following quantity in terms of only the cardinality of $B$:")

#mi("\\max_{t}  \\sum_{n \\in B} F(t n). (*)")

#text("In the case of the lonely runner conjecture one has ")#mi("F(x)= 1_{[1/n, 1-1/n}(x) - (n- 2)/(n)")#text(" and one seeks an estimate for sets of size ")#mi("B=n-1")#text(". The trivial result from your post can be seen from applying mean value theorem to $(*)$ with ")#mi("F(x)= 1_{[1/2n, 1-1/2n}(x) - (n- 1)/n")#text(".")

#text("Perhaps the best-known problem of this form is Chowla’s cosine problem which asks for a lower estimate on (*) when ")#mi("F(x)=-cos(x)")#text(". Indeed, proving that (*) tends to infinity with B was a long-standing problem solved by Cohen as a corollary to his work on the the Littlewood problem. However the state of things here is still quite unsatisfactory. While the true lower bound is probably near $|B|^{1/2}$, no lower bound of polynomial strength is known.")

#text("If one considers ")#mi("F(x) = 1_{1/3, 2/3}(x) - 1/3")#text(", then the problem of showing that (*) tends to infinity with ")#mi("B")#text(" is open and would imply progress on the problem of finding large sum-free subsets within arbitrary sets of the integers. Indeed, in this case Bourgain expended a fair amount of effort “just” to show that (*) exceeded the constant ")#mi("1/3")#text(" for all large sets.")

#text("Years ago, I attempt to apply a variant of Bourgain’s approach to the lonely runner problem. If I recall correctly, this leads to estimates of the form (*) ")#mi("\\gg c/n^2")#text(" (or ")#mi("(1/2n + c/n^2)")#text(" in the lonely runner problem as stated here) for marginally non-trivial values of ")#mi("c")#text(". The idea is to slightly decrease the size of the interval defining ")#mi("F")#text(" and then do some painful case analysis using the non-constant terms in the Fourier series defining $F$ to obtain a small gain.")

#text("Bourgain also considered (*) with the function ")#mi("F(x) = 1_{1/4-1/8, 1/4+1/8} - 1/4")#text(". In this case, he was able to obtain a lower bound of the order ")#tao-math("\\log \\left|B\\right| / \\log \\log \\left|B\\right|", block: false)#text(", which has implications for solution free subsets of a linear equation in four variables. I recall hoping that one might be able to adapt this approach here to the LRC (although the relevant $F$’s for the LRC are symmetric which is the main obstruction to applying these arguments in the prior setting). Curiously, if one could succeed here then one might expect this to produce a result of similar strength to what you obtain here. On the other hand, your ideas might be circumventing the symmetry obstruction previously mentioned.")

#text("Another problem of this form occurs when one takes ")#tao-math("F(x) = \\log \\left|1-e(2 \\pi i x) \\right|", block: false)#text(". This is equivalent to a question of Erdos and Szekeres from 1950. While this looks very similar to the function arising from the sum-free subset problem from the Fourier analytic point of view, there is a simple but clever argument due to Erdos and Szekeres exploiting algebraic properties of this particular ")#mi("F")#text(", which appears to have no analog in other cases, which leads to a lower bound of the order ")#tao-math("\\log \\left|B\\right|", block: false)#text(". Improving even the constant here has been open for over a half a century. There us also some interest in the case of sets within short APs here, with a result somewhat analogous to your Proposition 1.7 being obtained in a recent paper of Bourgain and Chang.")

#text("Yet another problem, having implications to an old question of Bohr regarding the convergence of Dirichlet series, occurs by taking ")#mi("F(x) = sin(x)")#text(". This is slightly different since Parseval gives a lower bound of the order ")#tao-math("\\sqrt{\\left|B\\right|}", block: false)#text(" and one seeks further asymptotic improvements. Here Konyagin has improved this by a factor of ")#tao-math("( \\frac{ \\log \\left|B\\right|} {\\log \\log \\left|B\\right|} )^{1/2}", block: false)#text(". The truth is probably of the order ")#mi("n^{2/3}")#text(".")

#text("It might be worth considering if your ideas have any applications to these other problems.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-476426")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2017")])]

#text("That’s a nice perspective on this family of problems! Unfortunately it seems my methods don’t apply easily to the other problems. In all of the problems you mentioned, the “trivial” bound is basically what comes out of the pigeonhole principle (or integral variants thereof). Certainly the trivial bound for the lonely runner conjecture can also be established this way, but what sets this problem apart from the others you mentioned is that the trivial bound for lonely runner can ")#emph[#text("also")]#text(" be obtained from the union bound, whereas I don’t see any good way to do so for the other problems. All of the methods in my paper are focused on trying to wring a bit of improvement over the union bound, but it doesn’t look to me like they have much chance of being able to improve upon more general applications of the pigeonhole principle (in which the average number of pigeons per pigeonhole is not close to one, but is instead much larger, or if the number of pigeons is allowed to be non-integral).")

#text("It’s certainly good to publicise these other problems though. The one about sum-free sets, in particular, definitely feels like one should be able to improve upon Bourgain’s result, or at least reprove it with a simpler proof…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-476510")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2017")])]

#text("Is it possible to make the method more flexible by relaxing the uniform(!) upper bound constraint in (3) on all the velocities to a more general constraint given by a function ")#mi("F_n")#text(" dominating their distribution function and than optimize (over all permissible such functions ")#mi("F_n")#text(") the resulting lower bound for ")#mi("\\delta_n")#text(" (as a functional of ")#mi("F_n")#text(")?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-476597")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2017")])]

#text("Yes; actually for (3) to hold it would be enough for ")#mi("\\gg n")#text(" of the velocities to be ")#mi("O(n)")#text(". I’ll add a remark to this effect in the next revision of the ms.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17fcfe998cfd25f867b37e16359ce2ed5164ca08c7d8e1a568a5df391a287e67-01f47e652504ff278464bff210318e77fc35c65bd80dfe45ac2c2481de478ccd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-476521")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2017")])]

#text("Shouldn’t the second term on the RHS in Theorem 3 be ")#mi("\\frac{c\\log n}{n^2(\\log\\log n)^2}")#text(" instead of ")#mi("\\frac{c\\log n}{n(\\log\\log n)^2}")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MatjazG")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-476556")[#strong[#text("MatjazG")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2017")])]

#text("I believe it should be; at least it is written thus in the preprint abstract. In any case, as it’s written in the blog post right now the lower bound in Theorem 3 divided by upper bound of ")#mi("\\frac{1}{n+1}")#text(" would diverge to infinity as ")#mi("n \\rightarrow \\infty")#text(", so there is clearly something wrong!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-476603")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2017")])]

#text("Statements like Theorem 1.4 (from page 5-6 of the paper on arXiv, but not this blog post) make me uncomfortable. The more I think about them, the more vacuous they seem (the statement, not the proof), in the sense I describe in the next paragraph. I’m definitely cheating, in that the computation of ")#mi("C_0")#text(" will terminate only if LRC is false, but then again that’s the only case in which we care about the Theorem.")

#text("The LRC is either true or false, if true then clearly (i) and (ii) are both true. If the LRC is false, there’s a smallest n’ for which there is a counterexample. If ")#mi("n_0<n^{\\prime}")#text(", then again clearly (i) and (ii) are both true. If ")#mi("n_0 \\geq n^{\\prime}")#text(", then (i) is false and we can compute ")#mi("C_0")#text(" so as to make (ii) false in the following explicit manner: exhaustively examine every set of speeds with maximum 1, then 2, then 3, and so on, to find a counterexample. Take ")#mi("C_0")#text(" large enough to capture this counterexample and make (ii) false.")

#text("The content of the theorem, imho, is that you are able to compute ")#mi("C_0")#text(" without producing a counterexample, but the statement of the theorem doesn't draw attention to that. How much work would it be to actually compute a value?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-476711")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2017")])]

#text("Yes, you’re right that the theorem is trivial if the constant ")#mi("C_0")#text(" is allowed to be ineffective (not a priori bounded from above by any explicitly computable function). I did say in Theorem 1.4 that the constant ")#mi("C_0")#text(" is effectively computable; actually, now that I look again at the proof, I think I can improve ")#mi("n^{C_0 n^2}")#text(" to ")#mi("C_1 n^{7n^2}")#text(" for some explicitly computable but large ")#mi("C_1")#text(" (something like ")#mi("10^{10}")#text(", perhaps, if one makes everything explicit). I’ll emphasise this point more and put in the improved bound in the next revision of the ms.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e61d020eb5d4a79a2ddd4647f419a85128931336990d2b437925383058847a8-c52c25f4123c65058f107cdd6c8c1e1b55b76ad68cb644bd35a8f25afbfa0c9f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chr0538")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-476746")[#strong[#text("chr0538")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2017")])]

#text("Why Goldbach conjecture was not people crack, really no idea? I do not think so, or some, there must be trouble you help me look at my proof, do not ignore me, a person is not recorded by history.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-476758")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2017")])]

#text("chr0538: Please read ")#link("https://terrytao.wordpress.com/about/")[#text("https://terrytao.wordpress.com/about/")]#text(" and stop posting such comments to Terry’s blog. It is very impolite to do so.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e61d020eb5d4a79a2ddd4647f419a85128931336990d2b437925383058847a8-c52c25f4123c65058f107cdd6c8c1e1b55b76ad68cb644bd35a8f25afbfa0c9f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chr0538")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-476765")[#strong[#text("chr0538")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2017")])]

#text("OK")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e61d020eb5d4a79a2ddd4647f419a85128931336990d2b437925383058847a8-c52c25f4123c65058f107cdd6c8c1e1b55b76ad68cb644bd35a8f25afbfa0c9f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chr0538")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-476766")[#strong[#text("chr0538")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2017")])]

#text("Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e61d020eb5d4a79a2ddd4647f419a85128931336990d2b437925383058847a8-c52c25f4123c65058f107cdd6c8c1e1b55b76ad68cb644bd35a8f25afbfa0c9f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terry Cheng")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-478413")[#strong[#text("Terry Cheng")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2017")])]

#text("Thank you.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3170687540c66dc22acac3ff153a5f7b25b10303e42e1144b148a6cfe32bff3d-0c12835ec5ba8882b4301c470ff7175f999ad4539c3167aabdb48ab191ff6473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eulogio Garcia")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-476755")[#strong[#text("Eulogio Garcia")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2017")])]

#text("the conjecture of the solitary runner with the Dirichelet aproximation theorem is correct if ")#mi("\\delta(v_{1}, ......v_{k}) \\in Z")#text(" and the time is ")#mi("(t = \\frac{1}{k})")#text(".")

#text("aproximation theorem:")

#mi("a\\alpha - b = \\frac{1}{N}")#text(" ; 1 < a < n; ")#mi("\\forall(\\alpha) \\in R")#linebreak()#text(" and ")#mi("(a, b) \\in Z")#text(".")

#text("We know that: ")#mi("\\forall (\\frac{1}{N} = \\frac{n}{m})")#text("latex ; 1 < a < n < m ")#mi("\\neq  n+1")#text(".")

#text("ie:")

#mi("\\frac{an}{m} - b = \\frac{1}{N}")

#text("(1) ")#mi("\\frac{an- bm}{m} = \\frac{1}{N}")#text(" ; m = N = nk; a bk; n = 1")

#mi("n[a - bk] = 1")

#text("Thus there are infinitely many values ")#mi("(a - bk = 1)")#text(" to teplace thim in equation (1).")

#text("Generally.")

#mi("n[a - bk] = n")#text("; ")#mi("n\\geq 1")

#text("With these of dedutions and remembering the statement: any runner will be at least a distance ")#mi("\\frac{1}{N}")#text(" from another runner.")

#text("We have:")

#mi("\\frac{ an - bm}{m} = \\frac{a_{i}n_{i} - bm_{i}}{m_{i}} = ..........")#linebreak()#text(" ")#mi("\\frac{a_{k}n_{k} - bm_{k}}{m_{k}} = \\frac{1}{N}")

#mi("\\forall(a > a_{i} > .......> a_{k})")

#text("However observing equation (1) we see that it does not admit ")#mi("(N = p)")#text("; ie for such a group of runner the equality is not possible.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1edf56a05f92780dc627b102cdc640a054d66c27ce89380f32475badd8b04245-14837a19bf4f555fcff631ee105681e1f4886010a4a586631614868d2f39141d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jérôme Renault")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-477398")[#strong[#text("Jérôme Renault")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("Hello Prof. Tao,")#linebreak()#text(" I am not sure whether you are aware of, or have noticed, the 2004 paper giving a short proof for ")#mi("n=5")#text(": “View Obstruction: a shorter proof for 6 lonely runners”, Discrete Maths. (I am much more into game theory than into number theory and did not come back to the lonely runner since then, but I find this conjecture very interesting). It suggests the following elementary but systematic and general approach.")

#text("We assume the conjecture holds for ")#mi("n-1")#text(", are given positive integer speeds ")#mi("v_1")#text(",…,")#mi("v_n")#text(", and want to show the existence of ")#mi("t")#text(" such that : ")#tao-math("\\left\\|tv_i\\right\\|\\geq \\frac{1}{n+1}", block: false)#text(" for each ")#mi("i")#text(" =1,…,")#mi("n")#text(". W.l.o.g. we assume that ")#mi("v_1")#text(" is a multiple of ")#mi("n+1")#text(", and that ")#mi("{\\rm gcd}\\{v_1,")#text("…,")#mi("v_n\\}=1")#text(". (it is not difficult to see that one can also restrict attention to speeds such that for each ")#mi("l=2,")#text("…,")#mi("n+1")#text(" there is at least one, and at most ")#mi("n-2")#text(", speeds which are multiple of ")#mi("l")#text(").")

#text("The simple idea is the following: consider a time ")#mi("s")#text(" maximizing ")#tao-math("\\left\\|tv_1\\right\\|", block: false)#text(" among the times ")#mi("t")#text(" where the other runners ")#mi("2")#text(",…, ")#mi("n")#text(", are all in the safe region ")#mi("[1/(n+1),n/(n+1)]")#text(".")#linebreak()#text(" Claim: if the conjecture is false for these speeds, that is if ")#tao-math("\\left\\|s v_1\\right\\|", block: false)#text(" is strictly lower than ")#mi("1/(n+1)")#text(", then there exists ")#mi("\\lambda \\in \\{1,")#text("…,")#mi("n\\}")#text(" and ")#mi("\\alpha\\in \\{0,")#text("…,")#mi("n\\}")#text(" such that time")

#mi("\\lambda s + \\frac{\\alpha}{n+1}")

#text("(possibly + or – small ")#mi("\\varepsilon")#text(") contradicts the definition of ")#mi("s")#text(". This claim is fully correct and give elementary proofs for ")#mi("n=2,3,4")#text(", (to my knowledge, much simpler than the other existing ones, see the appendix in the above paper) and was mainly used to prove the case ")#mi("n=5")#text(" (where a different argument was used to tackle the case of 3 even speeds, but I believe it was just a short cut and the claim is likely to be also correct for ")#mi("n=5")#text("). I am not saying the claim will be surely correct for all ")#mi("n")#text(", but I believe the approach may be interesting and help simplifying the problem by restricting, to some extent, the study of the different speeds to the study of their congruence classes modulo ")#mi("n+1")#text(". (the approach could also be possibly improved by looking at times of the form")#linebreak()#text(" ")#mi("\\lambda s + \\frac{\\alpha}{l}")#text(", with ")#mi("l=2,")#text("…,")#mi("n+1")

#text("Do you have any ideas whether the claim could be be correct in general, and/or do you think there is any hope to prove the conjecture for larger ")#mi("n")#text(" using such an approach ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-477482")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("Hi Terry,")#linebreak()#text(" I’m looking at your ArXiv preprint and think there’s something missing in the statement of statement of Proposition 2.1. Presumably $Q$ is meant to be $P(w_1′,\\ldots,w_{r’}’;N_1′,\\ldots,N_{r’}’)$ (not $Q$ of those same parameters) and also $Q$ should be required to be $t$-proper?")

#emph[#text("[Thanks, this will be added to the next revision of the ms. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-477604")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2017")])]

#text("I’ve reached a point in the ArXiv ms where I’m not understanding something, and worse: there’s a fallacious way to derive the thing I’m not understanding. Between (3.13) and (3.14) you’re applying the pigeonhole principle to ")#mi("P_{ij}\\cap P_k")#text(" to deduce that there are two elements ")#mi("A\\log\\log n/A_1")#text(" apart. You showed in (3.13) that there are ")#mi("A_1n/(A\\log\\log n)")#text(" values of ")#mi("k")#text(" such that ")#mi("\\#(P_{ij}\\cap P_k\\gg n/A_1")#text(". I *can* see that there are two ")#mi("k")#text("‘s that are ")#mi("A\\log\\log n/A_1")#text(" apart, but I don’t see why you can say that for each ")#mi("k")#text(", there are two terms of ")#mi("P_{ij}\\cap P_k")#text(" that are that distance apart (in particular, this would imply a bound on ")#mi("v_k")#text("). Can you enlighten me?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-477710")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2017")])]

#text("Oops; many of the occurrences of ")#mi("\\frac{A \\log \\log n}{A_1}")#text(" here should be ")#mi("A_1")#text(" (because ")#mi("P_k")#text(" has length about ")#mi("n")#text(", and ")#mi("P_{ij} \\cup P_k")#text(" has density about ")#mi("1/A_1")#text(" in this progression). For the argument the important thing is that this quantity is ")#mi("o(\\log n)")#text(". Also the ")#mi("B")#text("‘s in the proof of Proposition 3 should be ")#mi("H")#text(". I’ll correct these typos in the next version of the ms.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-477728")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2017")])]

#text("Good to know – would it be possible to email me a copy of the next version of the ms when it’s ready?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8c877fb7da3f9fa119ddd9cfe6b57e727e9f07379e7aaccee4397c9c6f6ca993-eba407c100c5d616bb9e9414537f2fa4ea296ce49475a5f3f0159f7c17ac172e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Magger")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-477724")[#strong[#text("Magger")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2017")])]

#text("It seems that ${\\|x\\|_{{\\bf R/{\\bf Z}} \\geq \\frac{1} {n+1}}$ should be ${\\|x\\|_{{\\bf R/{\\bf Z}} \\leq \\frac{1} {n+1}}$ in Lemma 4.3?")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8c877fb7da3f9fa119ddd9cfe6b57e727e9f07379e7aaccee4397c9c6f6ca993-eba407c100c5d616bb9e9414537f2fa4ea296ce49475a5f3f0159f7c17ac172e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Magger")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-478173")[#strong[#text("Magger")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2017")])]

#text("Is it true that argument about the disjointness of petal sets also holds for pairwise coprime velocities?")

#emph[#text("[Yes – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e61d020eb5d4a79a2ddd4647f419a85128931336990d2b437925383058847a8-c52c25f4123c65058f107cdd6c8c1e1b55b76ad68cb644bd35a8f25afbfa0c9f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terry Cheng")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-487019")[#strong[#text("Terry Cheng")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2017")])]

#text("Dear MR.Tao,I am so sorry to do that.I will study harder and carefully .I will be modest and never be arrogant.I will do mathematics in the future , that is my dream.I hope you can understand me.")#linebreak()#text(" I am sorry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/30a090b32920fe63cc1eb7425e22de7a2d62033561531eacd38cf1e72c1ced31-8c38f2194bfc51a929d85e36f7a44d7aa048844aa9e061f59592fd5f5d1b609b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Siktar")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-513385")[#strong[#text("Joshua Siktar")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2019")])]

#text("In Theorem 3 here (or Theorem 1.2 using the paper’s numbering), the constant is not explicitly chosen to be optimal. I was wondering if part of the reason for this is that it is anticipated better bounds altogether will be found so quickly that a specific value of the constants would be moot. Or is the explicit value of the constant just not of general interest whatsoever?")

#text("From what I’ve read on the problem it’s clear there are numerous types of approaches on the problem, some very geometric in nature. Best of luck on all of this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f23374eed5b08832ef6e74c302c0fd4d7d005fd842d85bb27fb52f15abce767b-31d692a234d9796ea2dda707a4e2f496e0773a8eb49a49bbf04464d38c8e6ea1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of phil howlett")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-519191")[#strong[#text("phil howlett")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2019")])]

#text("Here is a matlab program that checks the bounds")

#text("clear all")

#text("%define the speed difference vector with at least two entries")#linebreak()#text(" %v = [1,2,3,4]")#linebreak()#text(" %v = [1,3,4,7]")#linebreak()#text(" %v = [1,2,3,4,5]")#linebreak()#text(" %v = [1,3,4,5,9]")#linebreak()#text(" %v = [1,2,3,4,5,6]")#linebreak()#text(" %v = [1,2,3,4,5,6,7]")#linebreak()#text(" %v = [1,2,3,4,5,7,12]")#linebreak()#text(" %v = [1,4,5,6,7,11,13]")#linebreak()#text(" %v = [1,2,3,4,5,6,7,8]")#linebreak()#text(" %v = [1,2,3,4,5,6,7,8,9]")#linebreak()#text(" %v = [1,2,3,4,5,6,7,8,9,10]")#linebreak()#text(" %v = [1,2,3,4,5,6,7,8,9,10,11]")#linebreak()#text(" %v = [1,2,3,4,5,6,7,8,9,10,11,12]")#linebreak()#text(" %v = [1,2,3,4,5,6,7,8,9,10,11,12,13]")#linebreak()#text(" %v = [1,2,3,4,5,6,7,8,9,10,11,13,24]")#linebreak()#text(" %v = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18]")#linebreak()#text(" %v = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,19,36]")#linebreak()#text(" %v = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,25,48]")#linebreak()#text(" %v = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,31,60]")#linebreak()#text(" %v = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,…")#linebreak()#text(" % 32,33,34,35,37,72]")

#text("% Goddyn and Wong example")#linebreak()#text(" v = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,…")#linebreak()#text(" 32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,…")#linebreak()#text(" 61,62,63,64,65,66,67,68,69,71,73,140,144]")

#text("%define the corresponding separation functions")#linebreak()#text(" x = 0:0.000001:1;")#linebreak()#text(" y=(@(x)min(v’*x – floor(v’*x),ones(size(v’*x)) – (v’*x – floor(v’*x))));")#linebreak()#text(" ymin = min(y(x));")#linebreak()#text(" ymax = max(ymin’)")

#text("%plot selected separation functions")#linebreak()#text(" figure(1)")#linebreak()#text(" axis([0 1 0 0.5])")

#text("hold on")

#text("plot([0 1],[1/2 1/2],’k’,’Linewidth’,0.5)")#linebreak()#text(" plot([1 1],[0 1/2],’k’,’Linewidth’,0.5)")

#text("plot(x,y(x),’c’,’Linewidth’,2)")#linebreak()#text(" plot(x,ymin,’k’,’Linewidth’,2)")

#text("plot([0,1],[ymax,ymax],’–k’,’Linewidth’,1)")

#text("hold off")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2143743597522d291a7f119b64a6405d5b9e745d90c702f1ce695f67a33eecc0-00f00821f227f55b11714d9d26826fcc7a8b4cc22ceaae6b5f894bfed678a0f1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Babak Farhang")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-519224")[#strong[#text("Babak Farhang")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2019")])]

#text("My naive approach (I don’t have a solution, thinking/writing out loud) would be to quantize the problem. Suppose our track is a ring with")

#text("v1 x v2 x v3 x ..")

#text("slots. (The v’s are still relative primes.) Consider a state machine S that moves peg1 by v1 slots, peg2 by v2 slots,.. at each transition. So let’s quantize t over the natural numbers and call each transition an increment by 1. Prove the mapping t -> S is cyclic. (I’m thinking you do this by proving any peg/runner ends up in the same position after a fixed multiple of steps, multiply these fixed multiples for each peg, and..)")

#text("If this approach works (o, I doubt I’m not being naive), then it can be proved that the pegs all meet at any arbitrary slot and hence that 1/k becomes 1/2 (?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2143743597522d291a7f119b64a6405d5b9e745d90c702f1ce695f67a33eecc0-00f00821f227f55b11714d9d26826fcc7a8b4cc22ceaae6b5f894bfed678a0f1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Babak Farhang")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-519227")[#strong[#text("Babak Farhang")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2019")])]

#text("1st correction: the ring must have v1 x v2 x v3 + 1 slots. (We want each peg/runner to eventually visit every slot.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2143743597522d291a7f119b64a6405d5b9e745d90c702f1ce695f67a33eecc0-00f00821f227f55b11714d9d26826fcc7a8b4cc22ceaae6b5f894bfed678a0f1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Babak Farhang")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-519358")[#strong[#text("Babak Farhang")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2019")])]

#text("Never mind that correction.. And for thinking out loud. Here’s my attempt using the discrete approach I mention above. ")#link("https://babaksjournal.blogspot.com/2019/08/proving-lonely-runner-problem-discretely.html")[#text("https://babaksjournal.blogspot.com/2019/08/proving-lonely-runner-problem-discretely.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2143743597522d291a7f119b64a6405d5b9e745d90c702f1ce695f67a33eecc0-00f00821f227f55b11714d9d26826fcc7a8b4cc22ceaae6b5f894bfed678a0f1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Babak Farhang")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-519577")[#strong[#text("Babak Farhang")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2019")])]

#text("An update: I have an argument (and an algorithm) for calculating the time when the runners are exactly at 1/2 from the origin if their speeds are all odd and relative primes. ")#link("http://babaksjournal.blogspot.com/2019/08/lonely-runner-redux_12.html")[#text("http://babaksjournal.blogspot.com/2019/08/lonely-runner-redux_12.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-522447")[#strong[#text("El problema del corredor solitario – Blog del Instituto de Matemáticas de la Universidad de Sevilla")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2019")]

#text("[…] Tao tiene una entrada en su blog sobre el problema. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-638750")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2021")])]

#text("I don’t see how the sets for v1=1, v2=10 can cover the unit circle, because there are gaps between the sets for v2=10. (In this case n=2, the Bohr sets are B(v1, 1/(n+1)), B(v2, 1/(n+1)). But the conjecture has been proven for n=2. So what is wrong here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-638778")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2021")])]

#text("This shows that ")#mi("\\delta(1,10)")#text(" exceeds ")#mi("\\frac{1}{n+1} = \\frac{1}{3}")#text(" (in fact I think it is equal to ")#mi("\\frac{5}{11}")#text("), but ")#mi("\\delta_2")#text(", being the infimum of all the ")#mi("\\delta(v_1,v_2)")#text(", is still equal to ")#mi("\\frac{1}{3}")#text(".")

#text("The lonely runner conjecture is equivalent to the assertion that for any ")#mi("v_1,\\dots,v_n")#text(" and ")#mi("\\varepsilon>0")#text(", the Bohr sets ")#mi("B(v_i,\\frac{1}{n+1}-\\varepsilon)")#text(" fail to cover the whole circle.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/01/10/some-remarks-on-the-lonely-runner-conjecture/#comment-688440")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2025")])]

#text("I’ve been thinking about this conjecture on and off for a while, specifically in terms of other mathematical concepts and domains that might help model it.")

#text("The initial simplifications (subtracting the distance of the slowest runner, thus making that runner stationary; integer-valued or at least rationally proportioned speeds) do yield some interesting parallels elsewhere.")

#text("One such parallel is a rational winding along the surface of a hyperdimensional torus. My initial thought was that this winding, though a parametrization in terms of time, could also be understood as an operation of “slicing” this torus into a new topological shape. The measure of the dimensions of this shape could then yield the relative “loneliness” of runners. An irrational winding of the torus, going by the logic of this sort of operation, would “slice” the space into an infinitesimally thin number line. But, for rational windings, which are thus closed (i.e. periodic in terms of time), a specific topological shape would be produced each time. Concepts in the theory of measure of such a space could have correlates for the conjecture.")

#text("Beyond that, there’s an interesting implication of the conjecture my musical intuition suggests to me – however unhelpful it would probably be for any sort of proof, specification of bounds, etc. The conjecture models a situation in music of rhythmic polyphony: musical voices repeating at periodically distinct sub-intervals of the rhythmic space spanning a complete repetition of all voices together (i.e., return of all runners periodically to the origin of the track at the same time, in non-trivial cases of the conjecture).")

#text("An example would be two distinct voices, one of which repeats every 10th, and the other, every 12th eighth note (so, time signatures 5/4 and 6/4). This is equivalent to the simplified version of the lonely runner conjecture in a specific instance with three runners, with the distance of the slowest runner subtracted. The derivation is possible by taking the least common multiple of the length of the intervals, 30, and treating each voice as a distinct subdivision of 30. So, the speeds of the runners would be w = 6 + c, 5 + c, c, for some c constant.")

#text("The conjecture, understood this way, gives an upper bound on the amount of time before a single voice within such a rhythmically polyphonic arrangement repeats, considered as a fraction of the length of the overall repetition. It does so in inverse proportion to the number of voices.")

#text("Hypothetically, one could imagine 30 distinct such rhythmically contrapuntal voices, all taking up different subdivisions of an extremely long musical measure. This means that no more than 1/30th of this measure will elapse before a voice has repeated. There could perhaps be some bridge, from here, to a model in the study of signal and periodicity, but regardless, it was interesting to think about.")
]
