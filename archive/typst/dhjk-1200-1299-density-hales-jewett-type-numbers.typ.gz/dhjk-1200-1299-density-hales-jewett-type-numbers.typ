// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/
// Converted to Typst by tao2typ: "2026-10-14T16:35:40.159279+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "DHJ(k): 1200-1299 (Density Hales-Jewett type numbers)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("DHJ(k): 1200-1299 (Density Hales-Jewett type numbers)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 March 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/")[#text("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("This is a continuation of the ")#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/")[#text("1100-1199 thread")]#text(" of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("polymath1")]#text(" project, which is now full. The focus has now mostly shifted to generalisations of the previous problems being studied to larger alphabet sizes k, so I am changing the title here from DHJ(3) to DHJ(k) to reflect this.")

#text("The discussion is evolving rapidly, but here are some of the topics currently being discussed:")

#list(
[#text("Understanding the density Hales-Jewett numbers ")#mi("c_{n,k}")#text(", defined as the size of the largest subset of ")#mi("[k]^n")#text(" that does not contain a combinatorial line. The progress on that problem is summarised ")#link("http://michaelnielsen.org/polymath1/index.php?title=Higher-dimensional_DHJ_numbers")[#text("here")]#text(".")],
[#link("http://michaelnielsen.org/polymath1/index.php?title=Higher-dimensional_Fujimura")[#text("Fujimura’s problem in higher dimensions")]#text(".")],
[#text("The ")#link("http://michaelnielsen.org/polymath1/index.php?title=Hyper-optimistic_conjecture")[#text("hyper-optimistic conjecture")]#text(" in higher dimensions. It looks like the conjecture in fact fails in higher dimensions, though perhaps it could be salvaged by reformulating it.")],
[#text("Reducing the need for computer assistance in")#link("http://michaelnielsen.org/polymath1/index.php?title=Moser%27s_cube_problem")[#text(" our result")]#text(" ")#mi("c^{\\prime}_5=124")#text(" on Moser’s problem.")],
[#text("New lower bounds for the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Hales-Jewett_theorem")[#text("coloring Hales-Jewett numbers")]#text(".")]
)

#text("Note that much of the most recent progress has not yet been ported to the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("wiki")]#text(". In order to help everyone else catch up, it may useful if authors of comments (particularly comments with lengthy computations, or with corrections to previous comments) put their work on the relevant page of the wiki (not necessarily in the most polished format), and perhaps only place a summary of it on the thread itself.")

#text("[Incidentally, for the more casual followers of this project, a non-technical introduction to this project can be found at ")#link("http://numberwarrior.wordpress.com/2009/03/25/a-gentle-introduction-to-the-polymath-project/")[#text("this post of Jason Dyer")]#text(".]")

#text("Comments here should start from 1200.")

#heading(level: 1)[#text("Comments (91)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-37950")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2009")])]

#text("1245. HJ k>3")

#text("I have had the programs running during the weekend and they have improved the bounds for two pairs of values.")

#mi("c_{4,6}\\geq 1051")#linebreak()#text(" ")#mi("c_{5,4}\\geq 708")

#text("I have updated my table page and the solutions are available there too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-37958")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2009")])]

#text("Metacomment.")

#text("The sequence primary to Granvik.1234 is A105659, which was sent in to the OEIS by Sascha Kurz.")

#link("http://www.wm.uni-bayreuth.de/index.php?id=206")[#text("Sascha Kurz’s research page")]#text(" has quite a few papers about integral point sets, although I haven’t found the sequence in question. I have emailed the author to hopefully get further info.")

#text("I have no idea why integral triangles would be linked to combinatorial lines in such a manner.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-37971")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2009")])]

#text("I withdrew my submission 24 hours earlier of A156989 in favor of Terry Tao’s submission, because I have 2130 sequences there already, and the world of mathematics would benefit from more directly from Dr. Tao. OEIS is a tremendously valuable collaborationware. I now consider it, among other things, a kind of alpha test of Polymath1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5536e2ed5c1fa87e54776ade5c0361da235581bd08d9265280e5bf61c2141ed-12b84bee07fb83b2ffe132e11959371bef82c8c3b1a80d1c8030af90cbdec6dc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. Eppstein")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-37973")[#strong[#text("D. Eppstein")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2009")])]

#text("1246. Fujimura disjoint triangle cover")

#text("Theorem: for all n congruent to 0 or 2 mod 6, the triangular lattice with n points per side can be partitioned into (upwards oriented) triples of points forming the vertices of equilateral triangles.")

#text("Proof: We show more strongly by induction that such a partition exists in which the outer three points in each corner of the lattice are each covered by triangles of the partition. As a base case, it’s trivial for n=2.")

#text("When n=0 or 6 mod 18, the result follows by partitioning the lattice into six upwards-oriented sublattices of size n/3 and three downwards-oriented sublattices of size n/3 – 1, per [1220]. The upwards sublattices can be partitioned by induction and the downwards sublattices are translates of each other in an equilateral triangle and together can be partitioned into congruent triangles with one vertex per downwards sublattice.")

#text("Similarly, when n = 2 or 8 mod 18, the result follows by partitioning the lattice into six upwards-oriented sublattices of size n/3 and three downwards-oriented sublattices of size n/3 + 1, per [1242].")

#text("When n = 14 mod 18, the result follows by covering the lattice by six upwards-oriented sublattices of size (n+4)/3 that overlap only on their corners, with six downwards-oriented sublatices of size (n+4)/3 – 5 in an equilateral triangle pattern, per [1222].")

#text("When n = 12 mod 18, the result follows by placing three upwards-oriented sublattices of size (n+6)/3 centered on each side of the lattice, overlapping in a size-2 sublattice in the center of the lattice, and placing three upwards-oriented sublattices of size (n+6)/3 – 4 in the corners of the lattice, leaving three downwards-oriented sublattices of size (n+6)/3 – 3 in an equilateral triangle pattern.")

#text("This covers all possible values mod 18, so the result is proven.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5536e2ed5c1fa87e54776ade5c0361da235581bd08d9265280e5bf61c2141ed-12b84bee07fb83b2ffe132e11959371bef82c8c3b1a80d1c8030af90cbdec6dc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. Eppstein")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-37975")[#strong[#text("D. Eppstein")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2009")])]

#text("Follow-up to previous comment: there’s a gap in the proof. The claimed decomposition for 12 mod 18 actually works for 14 mod 18. If you try it for 12 mod 18 the three side-centered sublattices will have too large an area of overlap.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38009")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2009")])]

#text("1248: Fujimura triangles")

#text("If you have a solution for n, you can get a solution for 2n+2.")#linebreak()#text(" First cover the 2n+2 grid with the smallest triangles.")#linebreak()#text(" That leaves an n grid of twice the size.")

#text("That together with the previous post gives a solution for 30 mod 36.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/695de786c9d393fce34bec65916413ba358609668cf188a2788feeefc47652db-3bc56624561ed7ca30bebf54d2185d31e3d2708ba55bd810ad2e339f3f8ca6c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mats Granvik")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38026")[#strong[#text("Mats Granvik")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2009")])]

#text("1249.")

#text("What I said here in 1234 and 1239 does not hold. The next term with this method would have been 1473 which is outside the bounds for $latex $.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/695de786c9d393fce34bec65916413ba358609668cf188a2788feeefc47652db-3bc56624561ed7ca30bebf54d2185d31e3d2708ba55bd810ad2e339f3f8ca6c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mats Granvik")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38027")[#strong[#text("Mats Granvik")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2009")])]

#text("1249.")#linebreak()#text(" Oops, I got the latex wrong I meant c7.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38032")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2009")])]

#text("1250. Density Moser theorems implies DH(k) for all k")

#text("If we take a point from n^k and map it to 2^k points in 2n^k as follows f(p) is the set of points such that the ith coordinate value is either the ith value of p or 2k-p. This will give 2^k possible points for each point p and thus preserve density.")

#text("If there is a geometric line in the 2k set it corresponds to a combinatorial line in the k set as pairs of the form 2k-i and i which are the two possible ith points of a geometric line are images of i and so from a geometric line we get a combinatorial line in the original. This is a generalization for a specific result involving 3 and 6 already known.")

#text("We can use this as follows if we have a proof that if a cube of side n has density epsilon and there is a dimension high enough that it has a geometric line and this is true for all n Call this DM(n), we can get DHJ(n) for all n. To see this suppose we do not have DHJ(k) for a specific k then we can use the above mapping which preserves density to get a Moser set with side 2k with epsilon for all dimensions n such that there is no geometric line and this contradicts DM(n) for the specific values epsilon and 2k. This could be used to possibly simplify proofs of DHJ(k) and its consequences.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38064")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2009")])]

#text("1251: Fujimura, size 12")

#text("Referring to 1244, here is a solution to size 12 with a small triangle in each corner:")#linebreak()#text(" a,")#linebreak()#text(" aa,")#linebreak()#text(" bhj,")#linebreak()#text(" bbjj,")#linebreak()#text(" chlhq,")#linebreak()#text(" cckorv,")#linebreak()#text(" dglnlvv,")#linebreak()#text(" eggoqotq,")#linebreak()#text(" eekprkurx,")#linebreak()#text(" dimdswuuxx,")#linebreak()#text(" fiinsstnytz,")#linebreak()#text(" ffmpmwpwyyzz.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38066")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2009")])]

#text("1252. Fujimura, disjoint triangles")

#text("Proof that an equilateral triangle of sides 6n, 6n+2 can be split into equilateral triangles.")

#text("Further, they can be covered so that the three corners contain length-2 triangles.")

#text("Further, if the side is more than 204, they can be covered so the three corners contain separate length-6 triangles.")

#text("Take David’s three rules from 1242.")#linebreak()#text(" (1) P(k,S) => P(3k,S u {k})")#linebreak()#text(" (2) P(k,S) and j in S => P(3k-2j,S u {k})")#linebreak()#text(" (3) P(k,S) => P(3k+2,S u {k}).")#linebreak()#text(" Add a fourth rule from 1248:")#linebreak()#text(" (4) P(k,S) => P(2k+2, 2 U (2S+2) )")

#text("Let Q(k) be the property P(k,{2,6}).")#linebreak()#text(" We can do induction if n >34.")#linebreak()#text(" Suppose Q(6n) and Q(6n+2) are true")#linebreak()#text(" then Q(6n) -> Q(18n-4),Q(18n-12),Q(18n),Q(18n+2)")#linebreak()#text(" and Q(6n+2) -> Q(18n+2),Q(18n-6),Q(18n+6),Q(18n+8)")#linebreak()#text(" -> Q(18n+m) for m=-6,-4,0,2,6,8")#linebreak()#text(" -> Q(6p) and Q(6p+2) are true for p=3n-1, 3n, 3n+1")

#text("All that remains now is to establish P(k,S) for k below 204, and Q(6k),Q(6k+2) for k between 35 and 104. My Matlab routine, based on the four rules, said it was true.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38067")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2009")])]

#text("1253. HJ")

#text("I decided try out a variation of the earlier constructions for large sets without combinatorial lines. Consider all sets of the following type: A point ")#mi("x")#text(" is in ")#mi("S_A")#text(" if the sum of the coordinates of ")#mi("x")#text(" belongs to ")#mi("A")#text(".")#linebreak()#text(" The construction considering the divisors of k is a special case of this kind of set.")

#text("It is easy to modify the integer programs to sets of this kind. The results are here")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/Data/HJ/")[#text("http://abel.math.umu.se/~klasm/Data/HJ/")]#linebreak()#text(" The numbers of optimal solutions are quite small.")

#text("The optimal set of this type for (5,4) actually improved the lower bound for ")#mi("c_{5,4}")#text(" from 708 to 712.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38077")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2009")])]

#text("1254. Colorings avoiding geometric lines")

#text("Let M(n,r) be defined as the least dimension of an n-cube such that any r-coloring of it has a monochromatic line.")#linebreak()#text(" We will show:")

#text("M(2k,r) is greater than or equal to HJ(k,r) and")#linebreak()#text(" M(2k+1,r) is greater than or equal to HJ(k,r).")

#text("If we have a r-coloring of k^n")#linebreak()#text(" which is combinatorial line free then")#linebreak()#text(" we give the color each point of 2k (a,b,c..")#linebreak()#text(" to each point (a or 2k-a, b or 2k-b and")#linebreak()#text(" get a geometric line free coloring as a geometric")#linebreak()#text(" line would force a combinatorial line in the orginal coloring")#linebreak()#text(" so M(2k,r) is greater than or equal to HJ(k,r).")

#text("Similarly")#linebreak()#text(" if we have a r-coloring of k^n")#linebreak()#text(" which is combinatorial line free then")#linebreak()#text(" we give the color each point of 2k (a,b,c..")#linebreak()#text(" to each point (a or 2k-a+1, b or 2k-b+1 and")#linebreak()#text(" get a geometric line free coloring as a geometric")#linebreak()#text(" line would force a combinatorial line in the orginal coloring")#linebreak()#text(" so M(2k+1,r) is greater than or equal to HJ(k,r).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38087")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2009")])]

#text("1255. Hyper-optimistic conjecture for Moser sets")

#text("If we look at the question of whether the weight of a set that is geometric line free is equal to")#linebreak()#text(" the greatest number of slices in a geometric line free set we get")#linebreak()#text(" the hyper-optimistic conjecture for Moser sets. For 2 the question is trivially true")#linebreak()#text(" since we are allowed only one point and there are single points that are slices.")

#text("For 3 and 4 since there are two slice sets that contain geometric lines the number")#linebreak()#text(" of slices in a geometric set is linear and quadratic respectively for a density of c/n")#linebreak()#text(" in the slice space and this will transfer over to a maximum density of all sets composed of slices of I think")#linebreak()#text(" 1/n^.5 and this in turn should I think give colorings of less than 1/n^.5 must have a monochromatic line.")#linebreak()#text(" Beyond 3 and 4 the colorings start getting better at 5. Can these numbers")#linebreak()#text(" be improved by some sort of nonslice division of points. Or for that matter is there a conterexample to the this conjecture for Moser sets.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38096")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2009")])]

#text("1255. Hyper-optimistic conjecture for Moser sets correction")

#text("In the above the lower bound for the density for moser sets n=3 and 4 deri ed from slices should be something like")#linebreak()#text(" 1/n^5 but with a factor of log n as well. That will also affect the colorings by a factor of log n as well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38148")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2009")])]

#text("1256. Regarding ")#mi("c_{4,5}")

#text("Following my 1189, I have found a saturated solution of ")#mi("c_{4,5}")#text(" in which all five points of the major diagonal are among the 125 deleted points. I think that makes it different from the other solutions. I have put it in the wiki. I can’t see how to generalize it yet.")

#text("Also, regarding the dissection of the Fujimura triangle into disjoint triangles, there are 118 solutions when n=8, and millions when n=12. So my proof that involved triangles with n>600 was probably overkill.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38149")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2009")])]

#text("1257.")

#text("The solution for ")#mi("c_{4,5}")#text(" that I put in the wiki was just a disguised version of the solution we already have: Replace the digits (0,1,2,3,4) by (3,4,0,2,1), then for all 125 points (x,y,z,w), x+y+z+2w is a multiple of 5.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38176")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2009")])]

#text("1258. Lower bound for density of combinatorial line free k cube of side n")

#text("From 1170 we get a formula for slice desity based on")#linebreak()#text(" lower bounds for sets without k term geometric progressions")#linebreak()#text(" and we get if k is greater than 2^n +1")#linebreak()#text(" C\\frac{\\sqrt[2n]{log N}}{2^{n2^{(n-1)/2}\\sqrt[2n]{log N}}}")

#text("Now if we restrict ourselves to several standard deviations from the mean")#linebreak()#text(" then all the slices will be roughly the same size")#linebreak()#text(" as the limit of (1+1/c(n^.5))^c(n^.5) is roughly e^-c")#linebreak()#text(" the density is roughly the same there will be a factor of 1/2^5 on the constant multiplying the exponent 2^c(log n)^.5")#linebreak()#text(" also in the original I think N had to be k*n+1 since the values for which the arithmetic series are excluded go from 0 to kn and here that range would be roughly c(n^.5)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38177")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2009")])]

#text("1258. Correction and further remarks")

#text("It should be side k and dimension N")#linebreak()#text(" n is used in the formula")#linebreak()#text(" the argument has already been used in the wiki to")#linebreak()#text(" get the asymptote for c_n based on a set of slices")#linebreak()#text(" close to even distribution by a multiple of square root")#linebreak()#text(" of n so here I am extending this argument for cases greater than three")#linebreak()#text(" using the most recent bound for k arithmetic progression free sets")#linebreak()#text(" from")

#link("http://arxiv.org/PS_cache/arxiv/pdf/0811/0811.3057v2.pdf")[#text("Click to access 0811.3057v2.pdf")]

#text("and we get if k is greater than 2^n +1")

#text("C\\frac{\\sqrt[2n]{log k(cN^.5)+1}}{2^{n2^{(n-1)/2}\\sqrt[2n]{log K(cN^5}+1}")

#text("where here capital N is dimension and n is an integer entirely separate")#linebreak()#text(" from N dependent of k")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38191")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2009")])]

#text("1259. 4D Moser")

#text("If a 4D Moser set has more than 40 points and 4 points with three")#linebreak()#text(" 2’s it must have the following statistics:")

#text("(6,16,15,4,0,0)")

#text("We have from post 1113 that only the following statistics are possible:")

#text("(6,16,15,4,0), (7,16,14,4,0), (7,17,13,4,0), and (7,18,12,4,0).")

#text("and from post 1241")

#text("If a Moser set has 4 points with 3 2’s and its size is 41")#linebreak()#text(" or more then it must not have any set of two points with three twos with")#linebreak()#text(" the same c statistic.")

#text("We look at the number of points with one two each one must appear in exactly one of the four possible middles cubes from the four possible coordinate slices, hence if the number of these points is greater than 16 then there must be one such middle cube with five of these points")#linebreak()#text(" then by 1241 we know that there must be three points with three twos in the cube as well as otherwise there would be two with the same c statistic so we check the pareto optimizers from the wiki and find there is only one satisfying 5 something 3 something and that is (5,4,3,0)")#linebreak()#text(" so the center has 12 points and distribution (5,4,3,0) and the cube with")#linebreak()#text(" the remaining point with three twos has thirteen points so the remaining cube must have 16 points and hence distribution (4,12,0,0) and the distribution of the other side cube since has thirteen points must be")#linebreak()#text(" (3,6,3,1) or (4,6,2,1) but this gives a total of 5 + 12+ 6 points with one two")#linebreak()#text(" which is two many for any of the possible sets of statistics so the only")#linebreak()#text(" distribution that is possible is the one with 16 points with one two")#linebreak()#text(" namely (6,16,15,4,0) and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38254")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2009")])]

#text("1260. 4D Moser")

#text("A 4D Moser set with 4 points with three threes has 40 points or less.")#linebreak()#text(" By the reasoning of the above post each slice of a Moser set must have 4 points or less with one 2in the center cube. Since from the above we must have 16 of these points and each point only appears in one coordinate slice the division must be exactly 4 4 4 4.")

#text("No extremal slice can be 16 if so it has distribution (4,12,0,0) by the Pareto optimizers and hence since by the above the distribution of points with one two must include exactly 4 in the center slice we have a total of 16 and hence none in the other extremal set which contains its center point then by looking at the Pareto optimizers we see that we have to remove 6 points from a thirteen point or four points from a 11 point set in order to realize this and this gives at most 8 points then we have 8 + 16 points for the two side slices and we need 17 points in the center slice which cannot be realized.")

#text("So we have the side slice without the center point must have 15 points or less. Next we show that the center slice must have 14 points or less. By the above it must have 4 points with one two but this gives a distribution")#linebreak()#text(" of (4 x y z) note the points with one two in this slice count as points with no 2 in the internal statistics of the cube. The center slice must have y = to three because we have already established that there are no two points with the same c-statistic so we must have statistics (4 x 3 0)")#linebreak()#text(" which looking at the Pareto optimizers must have 14 points or less.")#linebreak()#text(" (I will continue this in the next post .)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38255")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2009")])]

#text("1261. 4D Moser set")

#text("Continued from 1260:")

#text("Now we recall that now two points with three twos can have the same c-statistic then we can assume without loss of generality that all such points have the coordinate not equal to 2 equal to one. Then we look at the points")#linebreak()#text(" (1 1 3 2) (1 3 1 2) (3 1 1 2) Only one of these can be in the Moser set because otherwise a line will be formed with the points with three 2’s under the above assumption. Now that means that under one of the coordinate cuts must have a diagonal connecting two points with one two. empty and that means that it can have at most 5 points with one two since each of the other diagonals have at most one point. That implies that the there must be at most 12 points in this cube since the other points have at most 14 and 15 points we must have the distribution 12 14")#linebreak()#text(" 15 or we will have less than 41 points. Then the statistics of the")#linebreak()#text(" cube must be (3 5 3 1) or ( 4 5 2 1) and the other side cube")#linebreak()#text(" must have statistics ( 3 9 3 1) (4 9 2 1) or (4 11 0 0)")#linebreak()#text(" or (3 12 0 0) but since we have the statistics (6 15 16 4 0) we can only have the choice (3 5 3 1) and the choices (3 9 3 1) and (3 12 0 0)")#linebreak()#text(" or we would have more than 6 points with no 2’s and we can discard")#linebreak()#text(" the possiblity (3 12 0 0) because it would give more than 16 points with one 2. So we must have (3 5 3 1) and (3 9 3 1) and this gives center slice")#linebreak()#text(" (2 9 3 0) but this has less than four points with two twos and will force another slice to have more than 4 and so we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38256")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2009")])]

#text("1261. Correction")

#text("The first sentence should read recall that no two points with three twos can have the same c-statistic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38261")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2009")])]

#text("1262.")

#text("Kristal, this is great! Looks like we are on track to produce a human proof of the ")#mi("c^{\\prime}_5=124")#text(" theorem, though if I recall correctly we used Klas’s data in other places as well than the ")#mi("d \\leq 3")#text(" bound for 41+ Moser sets. Also, my reduction of the statistics used Michael’s data for the n=3 Moser sets, which was a brute force search over the ")#mi("2^{27}")#text(" possibilities if I recall correctly. But that is at least a computation that is easily reproduced, and can probably be proven by human methods also.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38268")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2009")])]

#text("p.s. if you could transcribe the argument to the wiki, that would be great also. At some point I’ll also describe the argument in 1113 in more detail, to help complete the proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38348")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2009")])]

#text("1263. 4D Moser set")

#text("I put all my posts and 1113 on the Moser wiki at the end of the section n=4.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38359")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2009")])]

#text("1264. Limited HOC")

#text("Do we need the complete HOC to get DHJ(3)? I haven’t had much time still but I’ve been fiddling with the disjoint triangle proofs and it seems like configurations can get quite different depending on the divisibility of the side length. I theorize it might be possible to find an extremely specific case (to generate a random and non-serious example, where (n+1) mod 128 = 41) where Fujimura is not only tractable but constructible, and the construction can then be used to resolve both ends of the equation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38368")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2009")])]

#text("1265. Limited HOC")

#text("As I understand it we do not need equality but bounding by a constant factor would be enough for the cases n=3 and higher.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38435")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2009")])]

#text("1266. 4D Moser set")

#text("Kristal, I was going through your proof of the 4D Moser set, and I don’t think you have eliminated the statistic (7,16,14,4,0). In 1259 you show that b=16, and in 1261 you use that a=6.")

#text("I have edited your proof a little in the Wiki; I hope you don’t mind.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38446")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2009")])]

#text("1267. 4D Moser set")

#text("It looks like I made a mistake hear and I need to")#linebreak()#text(" do case (7 16 14 4 0)")#linebreak()#text(" Here it is:")

#text("Recall we must have the distribution 12 14")#linebreak()#text(" 15 or we will have less than 41 points. Also recall that the statistics of the side cube with its center point must be (3 5 3 1) or ( 4 5 2 1) then the statistics of the other side cube")#linebreak()#text(" must be ( 3 9 3 0) (4 9 2 0) or (4 11 0 0)")#linebreak()#text(" or (3 12 0 0)")#linebreak()#text(" Since the statistics are")#linebreak()#text(" (7,16,14,4,0) we must have one of the following four pairs")#linebreak()#text(" (3 5 3 1) and (4 9 2 0)")#linebreak()#text(" (3 5 3 1) and (4 11 0 0)")#linebreak()#text(" ( 4 5 2 1) and (3 9 3 0)")#linebreak()#text(" ( 4 5 2 1) and (3 12 0 0)")

#text("(3 5 3 1) and (4 9 2 0)")#linebreak()#text(" forces the middle slice to have statistics (0 2 9 3)")#linebreak()#text(" which has less than 4 points with one two")#linebreak()#text(" hence forces another slice to have more than four which gives")#linebreak()#text(" a contradiction")

#text("(3 5 3 1) and (4 11 0 0)")#linebreak()#text(" forces the middle slice to have statistics (0 0 11 3)")#linebreak()#text(" which has less than 4 points with one two")#linebreak()#text(" hence forces another slice to have more which gives")#linebreak()#text(" a contradiction")

#text("( 4 5 2 1) and (3 9 3 0)")#linebreak()#text(" forces the middle slice to have statistics (0 2 9 3)")#linebreak()#text(" which has less than 4 points with one two")#linebreak()#text(" hence forces another slice to have more which gives")#linebreak()#text(" a contradiction")

#text("( 4 5 2 1) and (3 12 0 0)")#linebreak()#text(" has 17 points with one two which contradicts the")#linebreak()#text(" statistics of the entire set.")#linebreak()#text(" So none of the cases work and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38499")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2009")])]

#text("1268. 4D Moser Set")

#text("I have added 1267 to the wiki at")

#link("http://michaelnielsen.org/polymath1/index.php?title=Moser%27s_cube_problem")[#text("http://michaelnielsen.org/polymath1/index.php?title=Moser%27s_cube_problem")]

#text("at the end of the section n=4")

#text("Thank you to Michael Peake for finding the error and editing")#linebreak()#text(" the proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38767")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2009")])]

#text("Metacomment:")#linebreak()#text(" Given that we have not added much new material for the last month or so I have a metaquestion:")

#text("What are the current plans for writing something up based on the threads here? Will it be part of the paper already being written or a second one?")

#text("We have a number of results on both asymptotics and small (n,k). In the outline for the write up that has begun at the wiki, bounds are mentioned as a possible part of the Discussion section.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38772")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2009")])]

#text("Ah, yes, I should be getting back to this project at some point. I was kind of delaying things hoping for the paper writing project on the other side to advance a bit first, but that seems to be slow also.")

#text("Right now, it looks like the plan is to have two papers – one for the new proofs of DHJ(3), and the other for the small (n,k) results. My feeling is that we don’t need to put every single result we’ve established into the small(n,k) paper; there are some which definitely have a preliminary feel to them, and in any case there’s no reason why we can’t write a subsequent paper should there be further significant advances, and in the meantime we have the wiki.")

#text("The obvious things to put in, I think, are the c_6 and c’_5 computations, the numerics for higher n, the asymptotic counterexamples we have, and the results we have for the n,k DHJ numbers, including the breakdown of the HOC. It looks like we’re close to a human proof of c’_5; it would be nice to have both in there. That would already be a reasonably-sized paper with a number of non-trivial results, I think.")

#text("Once we get some consensus on what to put in, I can try to draft an outline of the paper similar to what one has for the other paper, and then we can discuss individual sections, standardise the notation (e.g. is [3] equal to {0,1,2} or {1,2,3}? Not a life-or-death issue, but one which needs to be settled at some point.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38787")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2009")])]

#text("I think the suggested material should make a good paper. This will be emphasising the original “growing n” direction of the problem.")

#text("I am away for about a week now but once I get back home I should have some time to devote to this project again.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38817")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2009")])]

#text("I also agree that the suggested material looks good for a paper. I would prefer {1,2,3} as I am used to seeing 2 as the center point. I will be looking at the problem of making the proof of c_5′ a human proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38839")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2009")])]

#text("I also vote for {1,2,3}.")

#text("I think Fujimura deserves a paper on its own but we don’t know enough about it yet to consider one. Separated from DHJ, allowing r < 0 should be considered, and I think it’d be productive to study all the various restrictions on r (only r = 1, 0 < r < 3, etc.)")

#text("I also now believe the HOC is false for even DHJ(3), and it’d be great if we could find a counterexample before the paper goes up, but that might be out of our computational reach.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38840")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2009")])]

#text("Second thought: would it be productive to make a “spin-off” thread for a Fujimura-only polymath? (I’d be happy to make one but my blog traffic is about 30 times less than here, so I doubt we’d get much of the same cross-interaction we’ve had.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38848")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2009")])]

#text("1269. Fujimura when r can only equal 1")

#text("r=1 is the case of considering only the triangles of sidelength 1.")

#text("Consider each row r of the triangular lattice. Let the terms of a particular row be i_0, i_1, …. , i_r.")#linebreak()#text(" When r mod 3 = 0, then the terms i_k where k mod 3 = 1 should be removed.")#linebreak()#text(" When r mod 3 = 1, then the terms i_k where k mod 3 = 0 should be removed.")#linebreak()#text(" When r mod 3 = 2, then the terms i_k where k mod 3 = 2 should be removed.")

#text("This leaves maximal sets of 0, 2, 4, 6, 10, 14, 18, 24, … which curiously enough matches with ")#link("http://www.research.att.com/~njas/sequences/A128422")[#text("A128422")]#text(" which is the projective plane crossing number of ")#mi("K_{4,n}")#text(".")

#text("There’s a closed form of ")#mi("f(n) = \\lfloor \\frac{n}{3} \\rfloor(2n-3(1+\\lfloor \\frac{n}{3} \\rfloor))")#text(" for A128422 which means the closed form for the sequence above is just ")#mi("f(n+3)")#text(" of the same.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38849")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2009")])]

#text("(Oops, unfortunate variable name clash in 1269. r row is different from other r. Sorry about that!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-38960")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2009")])]

#text("1270. It occurs to me that it could be beneficial to build line-free sets directly from Behrend-ish arguments, rather than from the Behrend bound on ")#mi("r_3(n)")#text(". Here’s what I have in mind, but I haven’t worked out the numbers.")

#text("Take ")#mi("u")#text(" in ")#mi("T^d = [-1/2,1/2)^d")#text(" uniformly, and take ")#mi("v")#text(" in ")#mi("(T^d)^n")#text(" uniformly. Let ")#mi("\\phi")#text(" be the map from $[3]^n={0,1,2}^n \\to T^d$ that takes ")#mi("x")#text(" to ")#mi("u + v \\cdot x \\mod 1")#text(". The useful thing is that this map takes any combinatorial line to an arithmetic progression in ")#mi("T^d")#text(".")

#text("If we restrict our attention to those ")#mi("x")#text(" that map into the box ")#mi("[-1/4,1/4)^d")#text(" then we avoid wrap around progressions in ")#mi("T^d")#text(", and so we can think of ")#mi("[-1/4,1/4)^d")#text(" as a subset of ")#mi("R^d")#text(". If we further restrict our attention to those ")#mi("x")#text(" that map into a thin annulus, then we are only left with progressions with very small difference.")

#text("Since ")#mi("u")#text(" was chosen uniformly, we can estimate the number of ")#mi("x \\in [3]^n")#text(" that map into the annulus and into the box: the proportion is just the volume of that shape. Letting ")#mi("d")#text(" be the 0-1 vector with 1’s where the wild-cards are, we get a difference in ")#mi("R^d")#text(" of ")#mi("d \\cdot v")#text(", which must be uniformly distributed mod 1 by the choice of ")#mi("v")#text(", and must be small because the annulus is thin. We can bound how many times that happens by the volume of a small ball, and throw out one point for each time.")

#text("This is basically just rehashing the Green-Wolf construction, but using a map from [3]^n instead of a map from [1,k] and then taking slices. I don’t know what this gives…and I’d prefer to have a construction that includes this and the slices one as special cases, and *then* optimize the parameters. I’ll work out what this gives next week (after the CANT conference here in New York), but if anybody sees a better map or family of maps to look at please post!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-2/#comment-50467")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2011")])]

#text("Guys, we forgot to do combinatorial planes ;)")

#text("There are $(latex 5^n-2*4^n+3^n)/2$ combinatorial planes.")

#text("Let ")#mi("S")#text(" be a set that intersects all 2-dimensional combinatorial planes of ")#mi("[3]^n")#text(". Let ")#mi("P(n)")#text(" be the size of the smallest such set. This is ")#mi("3^n")#text(" minus the sets we have been considering.")

#text("Just for the sake of writing this down, we have ")#mi("P(1)=0, P(2)=1")#text(". Then ")#mi("P(3) = 3")#text(" for example ")#mi("111,222,333")#text(".")

#mi("9 \\leq P(4) \\leq 11")#text(" as there are nine disjoint planes, and the following eleven points cut all planes:")

#mi("1111,2222,3333,1123,1231,1312,2132,2321,2213,3111,3222")

#mi("27 \\leq P(5) \\leq 39 as there are 27 disjoint planes, and the following 39 points cover all planes:")#text("latex 11123 11132 11233 11312 11331 12121 12211$")

#mi("12223 12232 12322 13131 13222 13313 21113")

#mi("21131 21222 21311 22112 22231 22323 23122")

#mi("23212 23221 23233 23332 31112 31211 31221")

#mi("31233 31323 32133 32222 32313 32331 33111")

#mi("33123 33213 33321 33332")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37617")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1201. Additions to Wiki")

#text("I have added some material to the wiki at:")

#link("http://michaelnielsen.org/polymath1/index.php?title=Coloring_Hales-Jewett_theorem")[#text("http://michaelnielsen.org/polymath1/index.php?title=Coloring_Hales-Jewett_theorem")]#text(" n sections 5 through 8. It includes material from the end of the 1100 thread through 1196")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37625")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1202. ")#mi("c_{4,k}")#text(" is saturated for all odd ")#mi("k \\ge 5")

#text("Delete all points xxxx, along with all points xxyz and xyzw whose coordinates add up to a multiple of k.")

#text("k is allowed to be a multiple of 3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37626")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1203. Oops")#linebreak()#text(" Sorry, I think my previous comment is wrong")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37627")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1202. Additions to Wiki")

#text("I have added more material to the wiki:")

#text("Here is a summary of results the proofs are on the site at:")#linebreak()#text(" ")#link("http://michaelnielsen.org/polymath1/index.php?title=Coloring_Hales-Jewett_theorem#Improved_bounds_on_HJ.28n.2Cr.29")[#text("http://michaelnielsen.org/polymath1/index.php?title=Coloring_Hales-Jewett_theorem#Improved_bounds_on_HJ.28n.2Cr.29")]#linebreak()#text(" in sections 5 through 12 each group below is from one section:")

#text("HJ(3,3) is greater than 13")#linebreak()#text(" HJ(3,4) is greater than 37")#linebreak()#text(" HJ(3,5) is greater than 84")#linebreak()#text(" This leads to improvements in the existing bounds for c_n in the spreadsheet for values 82-84 as the density must be greater than 1/r=1/5 for n less than or equal to 84.")#linebreak()#text(" HJ(3,6) is greater than 103")#linebreak()#text(" Again this leads to improvements in the existing bounds for c_n for 82 to 98 again as the density must be greater than 1/r=1/6 for n less than or equal to 103 and the table stops at 98.")

#text("H(4,2) is greater than 11")#linebreak()#text(" HJ(4,3) is greater than 97")#linebreak()#text(" HJ(4,4) is greater than 349")#linebreak()#text(" HJ(4,5) is greater than 751")#linebreak()#text(" HJ(4,6) is greater than 3259")

#text("HJ(5,2) is greater than 59")#linebreak()#text(" HJ(5,3) is greater than 302")#linebreak()#text(" HJ(5,4) is greater than 2609")#linebreak()#text(" HJ(5,5) is greater than 6011")#linebreak()#text(" HJ(5,6) is greater than 14173")

#text("HJ(6,2) is greater than 226")#linebreak()#text(" HJ(6,3) is greater than 1777")#linebreak()#text(" HJ(6,4) is greater than 18061")#linebreak()#text(" HJ(6,5) is greater than 49391")#linebreak()#text(" HJ(6,6) is greater than 120097")

#text("HJ(7,2) is greater than 617")#linebreak()#text(" HJ(7,3) is greater than 7309")#linebreak()#text(" HJ(7,4) is greater than 64661")

#text("HJ(8,2) is greater than 1069")#linebreak()#text(" HJ(8,3) is greater than 34057")

#text("HJ(9,2) is greater than 3389")

#text("HJ(n,r) is greater than ((n^r/ern(1+o(1)))/n-1) -2")#linebreak()#text(" HJ(3,r) is greater than ((3^r/er3(1+o(1)))/2) -2")#linebreak()#text(" c_n is is greater than 3^n/(logn-log (log n) -log 3e(1+(o)1))")#linebreak()#text(" The maximal number of points in a combinatorial line free cube of side m and dimension n is greater than m^n/(logn-log (log n) -log (me(1+o1)) .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37632")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1203. Fujimura k=4 n=7")

#text("This night my program finished the computation for Fujimur’as problem with k=4 n=7. The optimum size is 78, and there are only 48 solutions.")#linebreak()#text(" I have updated my table page and put the solutions there.")

#text("I do not plan to extend the k=4 case further unless further values are needed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37647")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2009")])]

#text("1204. Query on HJ(k,r)")

#text("Kristal,")

#text("I am having trouble with the limit for ")#mi("c_n")#text(".")#linebreak()#text(" The formula given for the van der Waerden number W(r,k) is ")#mi("\\frac{r^k}{erk}(1+o(1))")#text(", where r is the number of colours and k the size of the cube. k is also the length of the arithmetic progression. For DHJ(3), k=3, so $W(r,3) = \\frac{r^2}{3e}(1+o(1))$. Then we can set the dimension to be ")#mi("n = r^2/6e  + o(r^2)")#text(" and keep 1/r of the points. The total number of points kept is ")#mi("3^n/r")#text(", which is ")#mi("O(3^n/\\sqrt{n})")#text(" or ")#mi("3^{n-log(n)/2}")#text(". This is smaller than the old limit of ")#mi("3^{n-\\sqrt{log(n)}}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37670")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2009")])]

#text("1205. HOC")

#text("Is there some viable alternative to the HOC?")

#text("For k=2 to original HOC is true.")#linebreak()#text(" For k=3 it holds for the few values of n where we know the involved values.")

#text("For k=4 it fails for n=2, weight 7.5 and Fujimura has has 7 points, but the number of points in the weighted problem is the same as in the unweighted maximum")

#text("For k=4 and n=3 the weight is greater than the size of Fujimura solution, and the number of points is smaller than in the maximum unweighted set.")#linebreak()#text(" The same things holds for n=4")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37671")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2009")])]

#text("1206. HJ(k,r)")

#text("I made a mistake in this section of the wiki, I switched r and k")#linebreak()#text(" in the exponent I have repaired this I no longer can improve the")#linebreak()#text(" existing asymptotic to c_n so I have deleted that material.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37672")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2009")])]

#text("1207. HOC")

#text("If the in the HOC equality is replaced a bounding constant factor then I think you can still get DHJ(k) from the weakened HOC The corners theorem and the combinatorial line free state forces the number of slices to be small")#linebreak()#text(" the constant factor forces the set in equal slices measure to be small and then equivalence of measures makes the density of the points with ordinary weighting small and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5536e2ed5c1fa87e54776ade5c0361da235581bd08d9265280e5bf61c2141ed-12b84bee07fb83b2ffe132e11959371bef82c8c3b1a80d1c8030af90cbdec6dc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. Eppstein")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37674")[#strong[#text("D. Eppstein")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2009")])]

#text("I’m coming to this very late, and probably this is overly naive and already long since considered and discarded, but: a permutation can be thought of as a machine for turning slices into {0,1}-colorings of [n]: the coloring is formed by coloring a prefix of the permutation with 0 and a suffix with 1, and the slice tells you how long to make the prefix and suffix. This machine has the property that any two colorings picked out by the same permutation form a combinatorial line in [2]^n. And the equal-slices measure of a set of colorings is just the expected number of colorings picked out by a random permutation.")

#text("So I was wondering, in connection with the hyper-optimistic conjecture, whether one could define some sort of combinatorial machine for turning slices into {0,1,2}-colorings of [n], with the property that for any three slices forming an equilateral triangle, the three colorings picked out by the machine for those slices form a combinatorial line. If such machines existed, we could hope for a proof of the hyperoptimistic conjecture in which the equal-slices measure is the expected number of colorings picked out by a random machine.")

#text("Sadly, machines of this type do not seem to exist. At least, I tried placing {0,1,2}-colorings of a two-element set into a triangle of the six possible slices a two-element set, and the constraint that equilateral triangles form lines quickly led to inconsistencies.")

#text("With this avenue of attack on the hyper-optimistic conjecture blocked off, I’m wondering what other approaches might seem more promising. I looked on the wiki but all I saw were computer calculations; I can imagine a counterexample to the hyper-optimistic conjecture being found in this way but that seems unlikely to lead to a proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37680")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2009")])]

#text("1209. Coloring machine")

#text("David, welcome!")

#text("I vaguely considered what you are speaking of ")#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/#comment-37021")[#text("at this comment")]#text(". I haven’t had time to think about it further, though. There’s a definite feel of some sort of “automatic chain” going on based on disjoint triangles that could be used to formulate a sensible coloring.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37682")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2009")])]

#text("1210. Coloring machine")

#text("Hi David!")

#text("What you propose sounds similar to what Gowers proposed ")#link("http://gowers.wordpress.com/2009/02/06/dhj-the-triangle-removal-approach/#comment-1938")[#text("back in 331")]#text(" and then ")#link("http://gowers.wordpress.com/2009/02/06/dhj-the-triangle-removal-approach/#comment-1940")[#text("discounted in 332")]#text(" for more or less the same reason you did. However, this approach did lead to what I called “Cartesian semi-products”, which were basically upper triangular grids in the cube such that any triangle with ")#emph[#text("one edge on the diagonal")]#text(" formed a combinatorial line; see e.g. my ")#link("http://gowers.wordpress.com/2009/02/08/dhj-quasirandomness-and-obstructions-to-uniformity/#comment-2108")[#text("comment 451")]#text(". Some vestige of this idea eventually got incorporated into the crucial observation “if a set has no combinatorial lines, then it correlates with a local complexity 1 set” which was finally proven in ")#link("http://gowers.wordpress.com/2009/02/23/brief-review-of-polymath1/#comment-2431")[#text("Gowers’ comment 820")]#text(". And this is a cornerstone of one of our current proofs of DHJ. So, basically, your idea is what did lead (after about four weeks of work, and many twists and turns) to a full solution of the problem :-)")

#text("The breakdown of the hyper-optimistic conjecture in k=4 does strongly suggest that the k=3 HOC, if true, is going to be true for “fluky” reasons rather than because there is an elegant proof of the fact. The version of HOC with a constant loss may of course still be true, but cannot be proven or disproven numerically, and I’m not sure there is much more one can say about that version of the conjecture at this stage.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5536e2ed5c1fa87e54776ade5c0361da235581bd08d9265280e5bf61c2141ed-12b84bee07fb83b2ffe132e11959371bef82c8c3b1a80d1c8030af90cbdec6dc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. Eppstein")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37684")[#strong[#text("D. Eppstein")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2009")])]

#text("1211. Coloring machine")

#text("Ok, define a “coloring machine” to be a function M that maps slices in Δn to colorings in [3]^n, but now rather than requiring that all equilateral triangles are mapped by M to lines, we only hope that many of them are. Let a(M) be the cardinality of the largest subset of Δn that avoids all of the triangles mapped by M to lines (obviously this is greater than or equal to the largest triangle-free set).")

#text("Then the equal-slices measure of any line-free set must be at most a(M). The proof idea is pretty much the same as for Lubell’s proof of Sperner. The equal-slices measure is the expected number of elements of the line-free set that are picked out by a machine M’ formed by applying a random permutation to M, but any individual one of these machines can only pick out a(M) of these elements else the elements it picks out would include a line.")

#text("That is, even if this idea is hopeless for getting to the hyper-optimistic conjecture, maybe it can at least give a nontrivial upper bound on equal-slices measure, if only we could find an infinite family of M’s with small a’s. Of course, you do already have a nontrivial upper bound on equal-slices measure: it is o(|Δn|) because (")#link("http://michaelnielsen.org/polymath1/index.php?title=Equal-slices_measure")[#text("the Wiki says")]#text(") that statement is the same as DHJ(3).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37700")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2009")])]

#text("1212. HJ(3,r)")

#text("I have added the new bound:")

#text("HJ(3,r) is greater than r^{clnr}/2-1")

#text("to the wiki at")#linebreak()#text(" ")#link("http://michaelnielsen.org/polymath1/index.php?title=Coloring_Hales-Jewett_theorem#Improved_bounds_on_HJ.283.2Cr.29")[#text("http://michaelnielsen.org/polymath1/index.php?title=Coloring_Hales-Jewett_theorem#Improved_bounds_on_HJ.283.2Cr.29")]#linebreak()#text(" more is on it there.")

#text("As far as I know this is the first greater than polynomial bound for")#linebreak()#text(" HJ(3,r)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37707")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2009")])]

#text("1213. all sort of things")

#text("Let me repeat some little comments (from the 1000 thread) which are perhaps more appropriate on this thread. The first is that it can be fruitful to examine slightly finer slice structures (perhaps in order to eliminate the hyper optimistic conj already for k=3). For example: Let ")#mi("\\Gamma_{a,b,c; x,y,z}")#text(" be all 0-1-2 vectors with a 0’s b 1’s and c 2’s where x is the sum of indices of the 0 entries y the sum of indices of 1 entries and z the sum of entriez of z vectors. (Such slices are of interest for binary vectors; you can have further refinements by presecribing the sum of squares of 0-indices etc;) union of slices where the sets of vectors (b+2x,y+2z) avoides 3-term AP look like avoiding combinatorial lines. But I do not know if such examples are potentially useful.")

#text("The other comment related to David’s is that in the DHJ(2) case (it is still an interesting issue if DHJ(2) is a good analog for DHJ(3)) there are sets which are line-ample – with a lot of lines. Namely, the chains. Now for DHJ(3) I am not aware of sets which have a “lot of lines” (by a lot we really want more than for combinatorial subspaces).")

#text("A concrete problem is this: for Sperner a maximal chain is a subset on which the density of a line-free subsubset is at most 1/(n+1). (And of course, there is no subset which is better).")

#text("For ")#mi("{0,1,2}^n")#text(" what is the subset X so that the maximum density ")#mi("c_X")#text(" in X of a line avoiding subsubset Y is minimum. Are there such X for which ")#mi("c_X")#text(" is smaller or even substantially smaller than for ")#mi("X= \\{0,1,2\\}^n?")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9946c9121e0cb957d136b5263170c8a16bc3714a9752b67f86f1a8e55f6903c-d05b29fec6ff76805e2997f2a2e0fd4a3c2f601ae9c890328792ae8a4468c320.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jozsef")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37725")[#strong[#text("jozsef")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2009")])]

#text("1214. HJ(3,r)")

#text("re. 1212. Kristal, I think that this is a standard argument. If one can r-colour the integers from 0 to 2d avoiding monochromatic 3-term arithmetic progressions, then it implies HJ(3.r)>d; just colour every point of ")#mi("\\{0,1,2\\}^d")#text(" with the colour assigned to the sum of its coordinates. So, ")#mi("HJ(3,r)\\geq W(3,r)/2")#text(". You used a+2b+1, but it is the same.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9946c9121e0cb957d136b5263170c8a16bc3714a9752b67f86f1a8e55f6903c-d05b29fec6ff76805e2997f2a2e0fd4a3c2f601ae9c890328792ae8a4468c320.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jozsef")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37727")[#strong[#text("jozsef")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2009")])]

#text("1214. HJ(3,r) (contd.)")

#text("Maybe one can use a 1-1 map between ")#mi("[3]^n")#text(" and a subset of integers to get a new bound on HJ(3,r) or DHJ3. We can consider the coordinates of points in ")#mi("[3]^n")#text(" as exponents of the prime factorization of an integer. If we can find a large set of integers without a 3-term GEOMETRIC progression, that would give a line-free subset in ")#mi("[3]^n")#text(". It is different from Kristal’s construction and it might give a better bound (but I’m not sure).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37730")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2009")])]

#text("1215. Regarding ")#mi("c_{5,k}")

#text("Following from 1188 and 1189, any coordinate-line-free solution of the five-dimensional k-cube, with ")#mi("k^4")#text(" missing points, must have the following missing points of each type.")

#text("p(vwxyz) = 24a + (k-1)(k-2)(k-3)(k-4)")#linebreak()#text(" p(wwxyz) = -60a + 10(k-1)(k-2)(k-3)")#linebreak()#text(" p(xxyyz) = 30a + 15(k-1)(k-2)")#linebreak()#text(" p(xxxyz) = 20a + 10(k-1)(k-2)")#linebreak()#text(" p(xxxyy) = -10a + 10(k-1)")#linebreak()#text(" p(xxxxy) = -5a + 5(k-1)")#linebreak()#text(" p(xxxxx) = a+1")#linebreak()#text(" (a=0..k-1)")

#text("Again, the number of missing points on the main diagonal (xxxxx) can be anything from 1 to k, but then the number of each other type is fixed. I don’t know why the formulae are so neat; the theory of Young tableaux and Schur polynomials must have something to do with it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/743ec659e95a03c26d192883fa7bbe7647704868ea113c827a627daa82ded8e0-dbc98e08ce176ef4ec67b629e09f1f3d2786817a4f2ebdb07194ca7cd341d047.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37741")[#strong[#text("Gil")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2009")])]

#text("1216. re 1214 part B")#linebreak()#text(" Dear Jozsef, This looks very interesting! but are there any bounds known on the density of sets avoiding 3-terms geometric progression? (also when you say it is different than Krystal’s example which example do you refer to?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37742")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2009")])]

#text("1217. Coloring machines")

#text("I tried playing around a bit with David’s suggestion to find maps ")#mi("\\phi: \\Delta_r \\to [3]^n")#text(" from a triangle ")#mi("\\Delta_r := \\{ (a,b,c) \\in {\\Bbb Z}_+^3: a+b+c=r\\}")#text(" into ")#mi("[3]^n")#text(" which map as many equilateral triangles into ")#mi("[3]^n")#text(" as possible.")

#text("Currently, we are using embeddings such as ")#mi("\\phi( a,b,c ) = 0^a 1^b 2^c")#text(" (taking r=n, say); this maps (a+r,b,c), (a,b+r,c), (a,b,c+r) to a line as long as b=0 (thus the equilateral triangle has to have one side on the boundary of ")#mi("\\Delta_r")#text(").")

#text("Another thing to do is to take ")#mi("r = 2^n-1")#text(", and map ")#mi("\\phi(a,b,c) = w")#text(" whenever a (resp. b, c) is the n-bit binary string which has 1s at the places where w is 0 (resp. 1, 2) and 0s elsewhere. This map is not defined on all of ")#mi("\\Delta_r")#text(", but only maps a sort of ")#link("http://en.wikipedia.org/wiki/Sierpinski_triangle")[#text("Sierpinski triangle")]#text(" in ")#mi("\\Delta_r")#text(" to ")#mi("[3]^n")#text(", in which exactly one of the i^th bits of a, b, c is one for each i. Any line in ")#mi("[3]^n")#text(" maps back to an equilateral triangle in ")#mi("\\Delta_r")#text(". But this basically is just reformulating DHJ(3) as a problem about avoiding a sort of Sierpinski gasket of equilateral triangles (a little reminiscent of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=IP-Szemer%C3%A9di_theorem")[#text("IP-Szemeredi theorem")]#text(" or ")#link("http://michaelnielsen.org/polymath1/index.php?title=Tidy_problem_page#Strong_Roth_theorem")[#text("strong Roth theorem")]#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5536e2ed5c1fa87e54776ade5c0361da235581bd08d9265280e5bf61c2141ed-12b84bee07fb83b2ffe132e11959371bef82c8c3b1a80d1c8030af90cbdec6dc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. Eppstein")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37744")[#strong[#text("D. Eppstein")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2009")])]

#text("1218. Ternary error correction")

#text("While thinking more about what kinds of bounds the coloring machine idea might be able to prove, I ran into a different question that may be heading a bit too far off-topic, but I thought I’d mention it here anyway.")

#text("A ternary error-correcting code is just a subset of [3]^n such that no two colorings differ only in a single position. The maximum size of an error correcting code is just [3]^{n-1}, or equivalently the maximum density is 1/3 — just take all colorings whose sum is 0 mod 3. But what is the maximum equal-slices density?")

#text("A lower bound of 1/3 on maximum equal-slices density is trivial: take the three sets of colorings whose sum is i mod 3 for i=0,1,2, and choose whichever of them has largest density. But this is not in general optimal. A better lower bound for some n is to take a maximum independent set in Δ_n and use all colorings within those slices. For n=2 this gives equal-slices density 1/2, and for n=4 it gives 2/5, but for n=3 it doesn’t do any better than the trivial 1/3 lower bound.")

#text("An upper bound on the maximum equal-slices density is the value of a fractional relaxation of the maximum independent set: assign real numbers to Δ_n such that no two adjacent numbers add to more than one, and take the average of these numbers. I think the optimal solution is the assignment of 1/2 to each slice, so the maximum equal-slices density should be at most 1/2. For n=2 this matches the lower bound but for higher n it is different.")

#text("My suspicion is that the lower bound is tight and the upper bound isn’t. Is this known? Any hope of a proof?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9946c9121e0cb957d136b5263170c8a16bc3714a9752b67f86f1a8e55f6903c-d05b29fec6ff76805e2997f2a2e0fd4a3c2f601ae9c890328792ae8a4468c320.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jozsef")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37747")[#strong[#text("jozsef")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2009")])]

#text("129. Re 126. Geometric progressions")

#text("Dear Gil, I was thinking about how to get a lower bound on HJ(3,r) which is different from Kristal’s in post 1212. I don’t know good lower bounds on monochromatic-3-term-geometric-progression (3GP) avoiding colourings, but I will think about it. In fact, we don’t need to avoid all geometric progressions, just the ones where ")#mi("a")#text(" and ")#mi("d")#text(" are relative primes where the 3GP is written as ")#mi("a, ad, ad^2")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37748")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2009")])]

#text("1219. Fujimura and divisibility")

#text("I was working on k=3 Fujimura a little, and while I haven’t had much luck, I wanted to note the divisibility of n seems to be a major factor in the layout of any potential disjoint triangles.")

#text("For example, when n mod 2 = 1, one can lay out triangles of side length 1 all the way to the edges of the lattice (for example when n = 3, the triangles 030-120-021, 210-300-201, 012-102-003) whereas when n mod 2 = 0 there is an “extra row”. This means the increase in disjoint triangles to a n mod 2 = 1 case is larger than to a n mod 2 = 0 case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5536e2ed5c1fa87e54776ade5c0361da235581bd08d9265280e5bf61c2141ed-12b84bee07fb83b2ffe132e11959371bef82c8c3b1a80d1c8030af90cbdec6dc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. Eppstein")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37750")[#strong[#text("D. Eppstein")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2009")])]

#text("Minor bugfix: that should be “error detection” and “error-detecting code” not “error correction” etc — correction requires greater Hamming distance than two.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37751")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2009")])]

#text("1220. Fujimura disjoint triangle cover")

#text("The triangular lattice of Fujimura’s problem can be covered by disjoint triangles as long as n=2*3^(i-1)-1 (where i >= 1).")

#text("Esentially, 6 copies of the previous cover are arranged to make the new cover, and the points not included can then be covered. It’s somewhat Sierpinski-ish.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5536e2ed5c1fa87e54776ade5c0361da235581bd08d9265280e5bf61c2141ed-12b84bee07fb83b2ffe132e11959371bef82c8c3b1a80d1c8030af90cbdec6dc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. Eppstein")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37754")[#strong[#text("D. Eppstein")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2009")])]

#text("1221. Fujimura disjoint triangle cover.")

#text("Jason: see ")#link("http://www.ics.uci.edu/~eppstein/0xDE/x3c.cc")[#text("my C++ code for finding covers by disjoint triangles")]#text(". Obvious necessary conditions for a cover to exist are that the triangular lattice have a number of points divisible by three, and that the bottom edge of the triangle have evenly many points. That is, the number of points on the bottom edge must be 0 or 2 (mod 6). My code finds solutions for all small n satisfying those conditions, with numbers of points on the bottom edge equal to 2, 6, 8, 12, 14, and after that I got tired of waiting for an answer. Your construction allows any solution to be tripled, so 18 and 24 are also solvable; the next unknown case is 20.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5536e2ed5c1fa87e54776ade5c0361da235581bd08d9265280e5bf61c2141ed-12b84bee07fb83b2ffe132e11959371bef82c8c3b1a80d1c8030af90cbdec6dc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. Eppstein")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37755")[#strong[#text("D. Eppstein")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2009")])]

#text("1222. Fujimura disjoint triangle cover.")

#text("If you have a solution with a triangle with n points on the bottom edge, and in addition your solution has the property that it uses the three side-length-1 triangles from the three corners, then Jason’s idea of arranging 6 copies and then covering the remaining points can be used in such a way that the 6 copies overlap only on these side-length-1 triangles. The resulting cover has 3n-4 points on the bottom edge (and again uses three side-length-1 corner triangles).")

#text("The solutions for 6 and 8 do have this property of using the three small corner triangles, and lead to solutions for 14 and 20. As I said, 18 and 24 are solvable using Jason’s version of the tripling construction. The same idea with order-6 overlapping corner regions allows the side-length-14 solution to turned into a solution with side length 3*14 – 2*6 = 30. So the next unknown case is 26.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37779")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2009")])]

#text("1223. Alternate slice notation")

#text("Kalai.1213 discusses an alternate slice notation ")#mi("\\Gamma_{a,b,c;x,y,z}")#text(". To begin with, Gil, are you really meaning this?")

#text("x is the sum of indices of the 1 entries")#linebreak()#text(" y is the sum of indices of the 2 entries")#linebreak()#text(" z is the sum of indices of the 3 entries")

#text("So for example the string 321 would have x = 2, y = 1, and z = 0. Equal slice notation would have a = 1, b = 1, and c = 1.")

#text("Given that, I’m not sure how useful it is combining the equal-slice and index-slice together; on ")#mi("c_3")#text(" for example it gives one point for each slice, which isn’t terribly useful. It seems better to form a separate slice type notation, say, ")#mi("\\Psi_{x,y,z}")#text(", and then if at any point we need equal-slice and index-slice together we can use intersection etc. as needed.")

#text("With ")#mi("c_3")#text(" then each ")#mi("\\Psi_{x,y,z}")#text(" is a combinatorial line. For example ")#mi("\\Psi_{2,1,0}")#text(" is the line 121-221-321 intersecting the equal slices ")#mi("\\Gamma_{2,1,0}")#text(", ")#mi("\\Gamma_{1,2,0}")#text(", and ")#mi("\\Gamma_{1,1,1}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37782")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2009")])]

#text("1224. Alternate slice notation")

#text("The ")#mi("\\Psi_{x,y,z}")#text(" I just mentioned gives combinatorial lines with a single wildcard in the first position; it is therefore useful to be able to number indices arbitrarily, so for example ")#mi("\\Psi^{[2,0,1]}_{x,y,z}")#text(" would give a single wildcard in the second position.")

#text("Note also ")#mi("\\Psi^{[1,1,1]}_{x,y,z}")#text(" is then simply equal slices, so it’s probably best to keep with our original notation of Gamma, so the original index-slice notation would be ")#mi("\\Gamma^{[0,1,2]}_{x,y,z}")

#text("(Or whatever alternate way other than my bracket-thing people want to do this.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37783")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2009")])]

#text("1225.")#linebreak()#text(" Dear Jason, I suppose this is what I meant; It is ok to think separately on slices of various types. (I did not understand your notation ")#mi("\\Gamma_{x,y,x}^{a,b,c}")#text(".)")

#text("I did not understand what is ")#mi("\\Psi_{x,y,z}")#text(" in 1223.")#linebreak()#text(" if the sum of indices of the locations for ‘1’ is ‘2’ why do you get there 121 and 221?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37784")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2009")])]

#text("1226. Alternate slice notation")

#text("Maybe I’m misunderstanding, but:")

#text("121 (in equal slices it would be a = 2, b = 1, c = 0)")#linebreak()#text(" 1s: 0 + 2 = 2 = x")#linebreak()#text(" 2s: 1 = 1 = y")#linebreak()#text(" 3s: 0 = z")

#text("221 (in equal slices a = 1, b = 2, c = 0)")#linebreak()#text(" 1s: 2 = 2 = x")#linebreak()#text(" 2s: 0 + 1 = 1 = y")#linebreak()#text(" 3s: 0 = z")

#text("321 (in equal slices a = 1, b = 1, c = 1)")#linebreak()#text(" 1s: 2 = 2 = x")#linebreak()#text(" 2s: 1 = 1 = y")#linebreak()#text(" 3s: 0 = z")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37786")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2009")])]

#text("Ok, i suppose I started with 1 (not with 0) it makes no difference if you insist your sets will be from the same slice with the two definitions together. But starting with ‘1’ will not allow even the coarse slices to have lines.")

#text("Now the individual slices in the index sum definitions are smaller.")#linebreak()#text(" (Actually a single slice in the ususal sense is at most ")#mi("3^n/n")#text(" and not ")#mi("3^n/\\sqrt {n}")#text(" as the wiki suggests, right?)")#linebreak()#text(" Each slice in the new sense have ")#mi("3^n/n^3")#text(" (when you just take the sum of indices) and if you insist on a slice both in terms of the sums of indices and in terms of number of coordinates of each type (and then you can start with 0) you get slices of at most ")#mi("3^n/n^4")#text(".")

#text("Now we want to gather many such slices to avoid a combinatorial line. So it looks that if the indices of the slices are (a,b,c,x,y,z,) we should not include 6-tuples avoiding 3 term a. p. simultaniusly in both b+2c and x+2y")

#text("The tragedy is that it seems that unions of such slices will give you examples in the same ball park as the examples we already have. but I am not sure about it. Also if it is in the same ball park asymptotically it can lead to better examples than the hyper optimistic ones. We may be able to explore the situation for union of slices in the different sense and in the refined sense for small but not terribly small n’s.")

#text("the question is related to the maximum sizes of subsets of a rectangle {1,2,…,a} times {1,2,…,b} not having a 3-term A.P. I suppose the asnwer is in the same ball park as for {1,2,…,ab} but I am not sure about it and I suppose experts would know.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37793")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2009")])]

#text("1128. Alternate slice notation")

#text("Just to clarify on my notation, ")#mi("\\Gamma^{0,1,2}")#text(" would mean the index starts at 0, and ")#mi("\\Gamma^{1,2,3}")#text(" would mean the index starts at 1.")

#text("So to compare:")

#text("221 with ")#mi("\\Gamma^{0,1,2}")#text(":")

#text("1s: 2 = x")#linebreak()#text(" 2s: 0 + 1 = 1 = y")#linebreak()#text(" 3s: 0 = z")

#text("221 with ")#mi("\\Gamma^{1,2,3}")#text(":")

#text("1s: 3 = x")#linebreak()#text(" 2s: 1 + 2 = 3 = y")#linebreak()#text(" 3s: 0 = x")

#text("Equal slices is ")#mi("\\Gamma^{1,1,1}")#text(", giving equal weight to each position in the string.")

#text("I think it worthwhile to compare the different possible slices using this notation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37794")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2009")])]

#text("1228. Maximal single slice")

#text("I think that the maximal single slice is one with all coordinates equal if the dimension is divisible by three, or one of three slices of the same size")#linebreak()#text(" using stirling’s approximation")#linebreak()#text(" ")#link("http://mathworld.wolfram.com/StirlingsApproximation.html")[#text("http://mathworld.wolfram.com/StirlingsApproximation.html")]#text(" gives roughly")#linebreak()#text(" 3^n/n. Apparently the division is by a power approximately one factor of square root of n greater each time we increase k by one and look for the maximum center slice of a cube of dimension n and side k.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37808")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2009")])]

#text("1229. HOC k=3")

#text("I have now used a different integer programming solver, the cplex solver, in order to determine the value of ")#mi("c_{6,3}^{\\mu}")#text(".")#linebreak()#text(" The program found a solutions quite quickly and after a bit over twelve hours the program had reduced the upper bound to the same value.")

#text("The result is ")#mi("c_{n,3}^{\\mu}=15")#text(".")

#text("With this program I can currently not get complete sets of solutions but the solution the program did find is here")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/solutions-n=6-k=3-HOC-6")[#text("http://abel.math.umu.se/~klasm/solutions-n=6-k=3-HOC-6")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37818")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2009")])]

#text("1230. Alternate slice notation")

#text("Quick note: when strings get larger the above notation is obviously impractical and not very general, so it’s probably best to have ")#mi("Gamma^1")#text(" mean Gil’s indexing starting at 1 and ")#mi("Gamma^0")#text(" be my own starting at 0.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37823")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2009")])]

#text("1231. Alternate slice notation visual comparison")

#text("Just for fun, here’s [3]^2 with four different slice types:")

#link("http://numberwarrior.files.wordpress.com/2009/04/sampleslice.gif")[#image("../assets/9ed900c378e4cf2aff497167ae9d96cd765b5efd5058195e0862ca6509a3ccf5-07c1a6bb693049d50c943983cd6776624c7b10a0da4ca7919dd884266c40ff3d.gif", width: 90%)]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37842")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2009")])]

#text("1232.")

#text("I wanted to mentioned before it slips my mind that I expanded my GA to strings in [4]^n, [5]^n, [6]^n and [7]^n. I haven’t had the time to try very hard but I did make an improvement in the lowerbound of [6]^3 of 1031. Things keep coming up but I will try to remember to exhibit the solution. If I don’t and someone is curious about this, please make a post on my blog and remind me or something like that.")

#text("Cheers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37843")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2009")])]

#text("1233. GA lower bound 1031")

#text("Possibly could that be the Moser set 6^4 has a lower bound of 1031? 6^3 is 216.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/065138e1b1902805d7f744a8b774918e0ccbb72d8c610f9cb5f0d04cde9795e3-c304526fcf69ae299ab157ae31b1f0cc68fc0ab5c24aaa809399deb8b52fce69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mats Granvik")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37869")[#strong[#text("Mats Granvik")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2009")])]

#text("1234.")

#text("Dear Terence Tao,")

#text("It appears that except for the first term, sequence A156989 in the oeis")#linebreak()#text(" is given by the expression A105659(A101976) + A000027 – 2.")#linebreak()#text(" That is: 0, 2, 6, 18, 52, 150, 450")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37871")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2009")])]

#text("1235.")

#text("Thanks Kristal. Yes I meant [6]^4.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37872")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2009")])]

#text("1236. OEIS sequence")

#text("Mats, I get a sequence starting 0, 4, 17, 42, 123 . . .")

#text("1*1+1-2 = 0")#linebreak()#text(" 2*2+2-2 = 4")#linebreak()#text(" 4*4+3-2 = 17")#linebreak()#text(" 5*8+4-2 = 42")

#text("Am I reading your expression wrong?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37873")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2009")])]

#text("1237. Fujimura disjoint triangle cover")

#text("David, it might also be useful to have the same information about near-covers, that is, covering ")#tao-math("\\left|\\Delta_n\\right|-1", block: false)#text(" and ")#tao-math("\\left|\\Delta_n\\right|-2", block: false)#text(".")

#text("At the least constructive proofs of the covers seem to leave the door open for upper bound improvement, although I’m still noodling with that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37877")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2009")])]

#text("1238. Colorings avoiding geometric lines")

#text("Let M(n,r) be defined as the least dimension of an n-cube such that any r-coloring of it has a monochromatic line. We will show M(3,2) =3.")#linebreak()#text(" It is greater than 2 since we can color the square of side three as follows")

#text("221")#linebreak()#text(" 112")#linebreak()#text(" 212")

#text("To see that it is three must show that every two coloring of the three dimensional cube of side 3 must have a monochromatic geometric line. We start by noting that one of the colors must have the center point then we subtract the Pareto optimal statistics from the total number of points in each class then we get a set of possible statistics that are the only statistics except for those which we get by adding points which correspond to the original statistics with one central point with points removed.")

#text("We start with (8,12,6,1) and subtract (3,6,3,1), (4,4,3,1) and (4,6,2,1) getting (5,6,3,0), (4,8,3,0) and (4,6,4,0). Of these only (4,6,4,0) is an extremiser. Now it has two four points with two 2’s. So it must have a pair with the same c-statistic slice on the coordinate of this pair which is not equal to two and we get two side slices which are squares with the central spot occupied. Without loss of generality let the first coordinate be the one with two points with the same c-statistic.")

#text("No suppose that there is a second pair of points with two 2’s with the same c-statistic then in the center slice the center and the two points with two 2’s will be empty and hence form a line in the other color and this gives a contradiction so we must have the two remaining points having different c-statistics.")

#text("Now without loss of generality let the two remaining points with two twos that are in the center slice be (2,2,1) and (2,1,2).")#linebreak()#text(" Then look at the points (1,1,1), (3,1,3), and (3,3,1) only one can be in the set because of possible monochromatic lines formed by (2,2,1), (2,1,1) and (3,2,2). Similarly of the points (3,1,1), (1,1,3) and (1,3,1) can contain only one element in the set because of possible monochromatic lines formed by (2,2,1), (2,1,1) and (1,2,2).")

#text("Since we must have four points with no twos by the above we must have the points (1,3,3) and (3,3,3) in the set. This will exclude the point (2,3,3).")#linebreak()#text(" Since the point (2,3,3) is excluded and the center slice must contain 4 points the point (2,1,1) must be excluded or it will eliminate all possible remaining points due to possible lines.")

#text("Because of a possible line with (1,3,3) and (1,2,2) the point (1,1,1) must be excluded. Similarly because of a possible line with (3,3,3) and (3,2,2) the point (3,1,1) must be excluded.")

#text("But now with (1,1,1), (2,1,1) and (3,1,1) excluded by the above they must be in the other color where they form a monochromatic line and we are done and M(3,2) =3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/695de786c9d393fce34bec65916413ba358609668cf188a2788feeefc47652db-3bc56624561ed7ca30bebf54d2185d31e3d2708ba55bd810ad2e339f3f8ca6c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mats Granvik")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37893")[#strong[#text("Mats Granvik")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2009")])]

#text("1239. Re:1236.")

#text("Jason, the expression with the parentheses means that A101976 is used as an index to A105659. In other words lookup the A101976:th number in sequence A105659, then add A000027 and subtract two.")

#text("Doing it backwards as I originally did it, you can lookup 2 5 16 49 146 445 without separating commas in the search.")

#text("The position of those numbers are given by sequence A101976.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37905")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2009")])]

#text("1240. re: David’s 1218")#linebreak()#text(" There are some studies of the “diatance distribution” for error correcting codes, and for linear codes this is equivalent to asking about the densities in every slice. (In particular, about the equal slice measure.) In fact, the linear programming method is based on solving linear programs for the entire distance distribution. (I am not so sure if talking about slices is so natural in the non linear case.)")

#text("For example, the conjecture that for (say linear) error-correcting codes that correct a linear number of errors the Gilbert-Varshamov bound is asymptotically optimal, can be strenghtened to Gilbert Varshamov being asymptotically optimal for every slice (and the density in a slice with ")#mi("bn")#text(" ‘1’s will thus be ")#mi("2^{-H(a)n}")#text(" where ")#mi("an")#text(" is the minimal distance. (Nati linial and I studied such distance distributions in an old paper of ours.) Anyway, I think trying to relate questions discussed here with error-correcting codes would be very nice. But such a connection is, so far, far.")

#text("Also it is worth mentioning that for Sperner’s theorem there is a complete description (sharper than the LYM inequalities) of the possible “f-vectors” namely the number of sets of every possible size. (and this follows from the Kruskal-Katona’s theorem). But it would be ultra optimistic to hope for something like this in DHJ(3).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37922")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2009")])]

#text("1241. 4D Moser")

#text("If a Moser set has 4 points with 3 2’s and its size is 41")#linebreak()#text(" or more then it must not have any set of two points with three twos with")#linebreak()#text(" the same c statistic. We have already shown that if a Moser set has 4 points with 3 2’s and its size is 41")#linebreak()#text(" or more then it must not have two sets of two points with three twos with")#linebreak()#text(" the same c statistic. See post 1171 in ")#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/")[#text("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/")]

#text("We start by assuming we have such a pair and as noted above only one pair the we slice on that the coordinate of that pair say i getting two slide slices with 13 or less points that means that the center slice must have 15 point or more it cannot have sixteen as it has at least one point with three twos in the configuration which becomes a point with two 2’s in the central slice and prevents the only realization of sixteen points from occurring since it has no points with two 2’s. Further we see from the Pareto optimal statistics for Moser sets for n=3 at the Moser wiki we see its distribution must be (4,9,2) we slice the center cube along one of the coordinates j in which there is a point with three twos then one outside slice without loss of generality say j=1 with the point with three twos must have that point at its center and hence have a maximum of 5 points and at most two points with three twos. the center slice has no center point and one point with three twos(we know it is not in the other outside slice because we have only one set of two points with the same c statistic and they are outside the center cube. Because of this the center slice can have at most 4 and it can contain at most three points with two twos, so the remaining slice j =3 must have all four points with two twos.")

#text("Now the two side slices since they have thirteen points must have statistics (3,6,3,1) or (4,6,2,1) each. So each of the diagonals connecting points with one two in the slice overall must have at least one point and that means that if we cut each of the side cubes along the same coordinate we cut the center cube we get there are a total four points with one two in the two side slices and if they are divided 2, 2. We can pick two pairs one point in a pair in each slice such there is a correspondence between the pairs of the points in that the coordinates j are equal. If they are divided 1,3 again there is a correspondence between the one point and one of the three such that the coordinates except for j are equal.")

#text("Now in the case of division 2-2 or 1-3 in the above we get a contradiction as follows be we have the above correspondences plus another one in the cube j=1 since it has its center spot occupied combined they give there are one or two points with the same center coordinates except for i in the cube j equals three but the center square of j=3 contains all its points with two two’s which block all lines between points with identical coordinates except for j and i equal to three and we get a line so we must have a four zero split, and since that split must have four points in each side cube and the center slice contains of j=3 contains all of it line so must have at most four of these point and the cube j=1 contains its center point and contains at most four of these points, these points must lie on either the squares i=1,j=3 and i=3,j=1 or i=1,j=1 and i=3,j=3 but then they will form a diagonal cube with i=2,j=2 which contains one point with three twos and this forms a line with one of the pairs of these four points on the diagonal cube and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5536e2ed5c1fa87e54776ade5c0361da235581bd08d9265280e5bf61c2141ed-12b84bee07fb83b2ffe132e11959371bef82c8c3b1a80d1c8030af90cbdec6dc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. Eppstein")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37925")[#strong[#text("D. Eppstein")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2009")])]

#text("1242. Fujimura disjoint triangle cover")

#text("Ok, let P(k,S) denote the statement “the triangular lattice with k points per side admits a partition into disjoint equilateral triangles, such that, for each number k’ in set S, the three corner sublattices with k’ points per side are also partitioned into equilateral triangles”.")

#text("We’ve seen")#linebreak()#text(" (1) P(k,S) => P(3k,S u {k}) [Jason Dyer 1220] and")#linebreak()#text(" (2) P(k,S) and j in S => P(3k-2j,S u {k}) [me 1222].")

#text("But we also have")#linebreak()#text(" (3) P(k,S) => P(3k+2,S u {k}).")#linebreak()#text(" To see this, in a (3k+2)-lattice, place six copies of the P(k,S) partition, three in each corner and three centered on each side. There are two points left over on each side edge of the (3k+2)-lattice that form an equilateral triangle with a point near the middle of the lattice. The remaining points form three regions that are translates of each other in an equilateral pattern and can be covered with congruent equilateral triangles having one point per region. The cover for the 8-lattice is an example of this construction.")

#text("So we have")#linebreak()#text(" P(2,Ø) — obvious")#linebreak()#text(" P(6,{2}) — by (1) from P(2,Ø)")#linebreak()#text(" P(8,{2}) — by (3) from P(2,Ø)")#linebreak()#text(" P(14,{2,6}) — by (2) from P(6,{2})")#linebreak()#text(" P(20,{2,6}) — by (3) from P(6,{2})")#linebreak()#text(" P(20,{2,8}) — by (2) from P(8,{2})")#linebreak()#text(" P(24,{2,8}) — by (1) from P(8,{2})")#linebreak()#text(" P(26,{2,8}) — by (3) from P(8,{2})")#linebreak()#text(" P(30,{2,6,14}) — by (2) from P(14,{2,6})")#linebreak()#text(" 36: NO SOLUTION KNOWN")#linebreak()#text(" P(38,{2,6,14}) — by (2) from P(14,{2,6})")#linebreak()#text(" P(42,{2,6,14}) — by (1) from P(14,{2,6})")#linebreak()#text(" P(44,{2,6,14}) — by (3) from P(14,{2,6})")#linebreak()#text(" P(44,{2,8,20}) — by (2) from P(20,{2,8})")#linebreak()#text(" P(48,{2,6,20}) — by (2) from P(20,{2,6})")#linebreak()#text(" 50: NO SOLUTION KNOWN")#linebreak()#text(" 54: NO SOLUTION KNOWN")#linebreak()#text(" P(56,{2,6,20}) — by (2) from P(20,{2,6})")#linebreak()#text(" P(56,{2,8,20}) — by (2) from P(20,{2,8})")#linebreak()#text(" P(60,{2,6,20}) — by (1) from P(20,{2,6})")#linebreak()#text(" P(60,{2,8,20}) — by (1) from P(20,{2,8})")#linebreak()#text(" P(62,{2,6,20}) — by (3) from P(20,{2,6})")#linebreak()#text(" P(62,{2,8,20}) — by (3) from P(20,{2,8})")

#text("It’s starting to look likely that there’s a solution whenever the side length is 0 or 2 mod 6.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5536e2ed5c1fa87e54776ade5c0361da235581bd08d9265280e5bf61c2141ed-12b84bee07fb83b2ffe132e11959371bef82c8c3b1a80d1c8030af90cbdec6dc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. Eppstein")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37930")[#strong[#text("D. Eppstein")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2009")])]

#text("1243. Fujimura disjoint triangle cover")

#text("I forgot that my program had already found a solution for 12. Tripling that gives 36. So the first unknown sizes are 50 and 56.")

#text("Also, in the 3n+2 construction, there’s no need to treat the six leftover side points and the three center points as distinct from the three congruent regions. It’s simpler just to think of this as a partition of the (3n+2)-triangular lattice into six n-lattices and three upside-down (n+1)-lattices.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5536e2ed5c1fa87e54776ade5c0361da235581bd08d9265280e5bf61c2141ed-12b84bee07fb83b2ffe132e11959371bef82c8c3b1a80d1c8030af90cbdec6dc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. Eppstein")]], [#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/comment-page-1/#comment-37938")[#strong[#text("D. Eppstein")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2009")])]

#text("1244. Fujimura disjoint triangle cover")

#text("Ok, after noticing several more erroneous omissions in the list above, I wrote a program to run the various lattice-tripling patterns for me. Among the possible triangular lattice sizes (congruent to 0 or 2 mod 6) up to 1000, it only fails to find a solution for 32, 66, 96, 192, 288, 572, and 578.")

#text("If the size-12 solution can have size-1 equilateral triangles in all four of its corners (that is, in the previous notation, P(12,{2}) — I haven’t checked, but this should be within reach of hand search or the search algorithm I posted earlier), then the only size without a known solution up to 5000 would be 66. So it seems that these tripling rules are almost enough to solve all possible lattice sizes.")
]
