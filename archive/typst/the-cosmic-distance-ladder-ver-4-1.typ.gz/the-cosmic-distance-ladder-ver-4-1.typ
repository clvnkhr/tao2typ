// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/
// Converted to Typst by tao2typ: "2026-10-14T16:36:19.413729+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Cosmic Distance Ladder (version 4.1)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Cosmic Distance Ladder (version 4.1)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 October 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/")[#text("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("This week I once again gave some public lectures on the ")#link("http://en.wikipedia.org/wiki/Cosmic_distance_ladder")[#text("cosmic distance ladder")]#text(" in astronomy,")#link("http://events.stanford.edu/events/250/25019/")[#text(" once at Stanford")]#text(" and ")#link("http://newsroom.ucla.edu/portal/ucla/ucla-mathematician-terence-tao-172674.aspx")[#text("once at UCLA")]#text(". The slides I used were similar to the “")#link("https://terrytao.wordpress.com/wp-content/uploads/2009/09/cosmic-distance-ladder2.pdf")[#text("version 3.0")]#text("” slides I used for ")#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/")[#text("the same talk")]#text(" last year in Australia and elsewhere, but the images have been updated (and the permissions for copyrighted images secured), and some additional data has also been placed on them. I am placing these slides here on this blog, in ")#link("https://terrytao.wordpress.com/wp-content/uploads/2017/11/cosmic-distance-ladder1.pptx")[#text("Powerpoint format")]#text(" and also in ")#link("https://terrytao.wordpress.com/wp-content/uploads/2017/11/cosmic-distance-ladder2.pdf")[#text("PDF format")]#text(". (Video for the UCLA talk should also be available on the UCLA web site at some point; I’ll add a link when it becomes available.)")

#text("These slides have evolved over a period of almost five years, particularly with regards to the imagery, but this is likely to be close to the final version. Here are some of the older iterations of the slides:")

#list(
[#text("(")#link("http://www.math.ucla.edu/~tao/preprints/Slides/distance_ladder.pdf")[#text("Version 1.0, 2006")]#text(") A text-based version of the slides, together with ")#link("http://www.math.ucla.edu/~tao/preprints/Slides/distance_pics.pdf")[#text("accompanying figures")]#text(".")],
[#text("(")#link("https://terrytao.wordpress.com/wp-content/uploads/2007/05/cosmic-distance-ladder.ppt")[#text("Version 2.0, 2007")]#text(") First conversion to Powerpoint format.")],
[#text("(")#link("https://terrytao.wordpress.com/wp-content/uploads/2009/09/cosmic-distance-ladder2.pdf")[#text("Version 3.0, 2009")]#text(") Second conversion to Powerpoint format, with completely new imagery and a slightly different arrangement.")],
[#text("(")#link("https://terrytao.wordpress.com/wp-content/uploads/2010/09/cosmic-distance-ladder.pptx")[#text("Version 4.0, 2010")]#text(") Images updated from the previous version, with copyright permissions secured.")],
[#text("(")#link("https://terrytao.wordpress.com/wp-content/uploads/2010/10/cosmic-distance-ladder.pdf")[#text("Version 4.1, 2010")]#text(") The version used for the UCLA talk, with some additional data and calculations added.")],
[#text("(")#link("https://terrytao.wordpress.com/wp-content/uploads/2010/10/cosmic-distance-ladder2.pptx")[#text("Version 4.2, 2010")]#text(") A slightly edited version, incorporating some corrections and feedback.")],
[#text("(")#link("https://terrytao.wordpress.com/wp-content/uploads/2017/11/cosmic-distance-ladder2.pdf")[#text("Version 4.3, 2017")]#text(") Some further corrections.")]
)

#text("I have found that working on and polishing a single public lecture over a period of several years has been very rewarding and educational, especially given that I had very little public speaking experience at the beginning; there are several other mathematicians I know of who are also putting some effort into giving good talks that communicate mathematics and science to the general public, but I think there could potentially be many more such talks like this.")

#text("A note regarding copyright: I am happy to have the text or layout of these slides used as the basis for other presentations, so long as the source is acknowledged. However, some of the images in these slides are copyrighted by others, and permission by the copyright holders was granted only for the display of the slides in their current format. (The list of such images is given at the end of the slides.) So if you wish to adapt the slides for your own purposes, you may need to use slightly different imagery.")

#text("(")#emph[#text("Update")]#text(", October 11: Version 4.2 uploaded, and notice on copyright added.)")

#text("(")#emph[#text("Update")]#text(", October 20: Some photos from the UCLA talk are ")#link("http://www.ams.org/meetings/lectures/einstein-2010")[#text("available here")]#text(".)")

#text("(Update, October 25: Video from the talk is available on ")#link("http://www.youtube.com/watch?v=7ne0GArfeMs")[#text("Youtube")]#text(" and on ")#link("http://www.math.ucla.edu/itunes")[#text("Itunes")]#text(".)")

#heading(level: 1)[#text("Comments (46)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47517")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2010")])]

#text("Maybe there could be more like this, but this is such a wonderful topic, not to mention beautifully executed, that it may be hard to make them as good. I particularly like the very general message that it is possible to measure things that at first seem as though they cannot be measured.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47521")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2010")])]

#text("Well, from my experience at least, a few years polishing of a talk could improve it quite a bit. I could imagine, for instance, that your own public talk on the existence of infinity could be given a similar treatment (e.g. visiting some famous historical milestones in our understanding of infinity, such as Zeno’s paradox, Hilbert’s hotel, Lebesgue measure, etc.).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ea5e8351bc52b04b984facb313dfb2122bc3ce8edda88d8889e3525e72587c0-8906d1b3c4a21b122a16401ca8fa5747c4e5992900e673f0be4f8b586cfa768e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dylan Thurston")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47519")[#strong[#text("Dylan Thurston")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2010")])]

#text("Your distance to Proxima Centauri is off by a factor of 1000: It’s about 4 * 10^13 km. In general, very nice!")#linebreak()#text(" ")#emph[#text("[Oops. Will fix for Version 4.2, certainly. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee1fa0dc5739bc24e4d6b4ef13aa793365979ae308a2e8401bf8440bd337f878-13cc6a689aaade70f2832eba03554079c456fa07a09b2f8fd06fb5b618718cd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gerard")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47520")[#strong[#text("Gerard")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2010")])]

#text("This reminded me of the classic: how would you make a tool from zero? Because you need tools for making tools, and for makings this tools you need straight lines, and to make straight lines…")

#text("Anyway, i didnt knew Aristarchus did so many things! He was, literally, awesome!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47538")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2010")])]

#text("LOL … how do you make a tool from zero? Gerard, I used to wonder this myself, back when I was a kid. Here is a mathematically elegant and completely practical technique that is fun to teach/tell to kids.")

#text("You are marooned on a desert island with nothing but coconut trees, sand, and water. To make a perfect optical flat, proceed as follows. (1) Dry some fronds in the sun, weave twine, and make a fire-bow. (2) Start a fire and smelt three rough-glass blanks {A,B,C}. (3) Grind blank A against B, B against C, and C against A, using at each stage of grinding, the increasingly fine glass grit from the stage before. Be sure to rotate and translate each blank during polishing, maintaining a water-based slurry between the blanks.")

#text("After awhile, this process will yield three perfect optical flats … I’m sure folks on *this* weblog can explain why. By grinding two faces onto a blank, an intersecting straight edge is created … now we’ve got a start on the bed of a lathe … next we grind some ball-bearings … and before long our desert island has a thriving high-precision machine shop under the coconut trees.")

#text("This start-from-nothing precision grinding procedure has been used for centuries by telescope makers … and even today, variants of this grinding technique yield the most perfect surfaces achieved by any technology.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43f6fd83668935da0d0c70a669432cf5eb387b8faa5576153ca95d588e50eca3-ba65af4f8d940a2eb73d6e1943bd99ab517942572df95a5b8ab817a1dfc89aee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Woett")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47522")[#strong[#text("Woett")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2010")])]

#text("Our universe is pretty awesome")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20304ddd6344529534c15f56edac9e7e3ebc3709c5fdfa02b28ba34278a8e7f2-9ffa631e95c9aa10aac0af43fdbc1e3616e26e432d9490db31e7f1efe978b5c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of linfengliu.china@gmail.com")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47530")[#strong[#text("linfengliu.china@gmail.com")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2010")])]

#text("very well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of P.")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47532")[#strong[#text("P.")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2010")])]

#text("Tank you for sharing this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9974a55807e249543a7704e6537d62967784e736753cf3b41b8d3bb4d31f2619-9feb2cb96611fdd03f7b22b539cd003762241ff5901ff8fe2410b6c3d6e79b85.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hendrik")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47539")[#strong[#text("hendrik")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2010")])]

#text("I didn’t know the Greeks already went that far. Nice presentation. Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f99d917eb49e4ab306ccf74b3dcbf5daaed995f040f98ac84d2cdd2e3d550cd8-d393381f844b44f64673cac564a830f3b6555bfa931ac1619ea3a1368cc5bde2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of possiblywrong")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47550")[#strong[#text("possiblywrong")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2010")])]

#text("Thank you for sharing this! I empathize with the experience of presenting, tweaking, and re-presenting– and learning in the process. In my case I have tried, but mostly failed, to provide a good introduction to the mathematics of cryptography, geared toward exciting the interest of advanced secondary students looking for research projects.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea854970dfe14ed70ce18bfd7b6954b0cfb60d9675baa54ac8969c4b5c8a96b2-08c8195085c0b6446e492d6da2a3b9c82f045038176d58610957f8ad465f8516.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pete Royston")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47551")[#strong[#text("Pete Royston")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2010")])]

#text("Dr. Tao, I just wanted to tell you how much my family enjoyed your talk at UCLA. It is impressive that you can cover this topic in a way that entertains parents, a UCLA math undergrad, an eleven-year-old (who claims to have understood most of it) and a nine-year-old (who’s favorite part was the Star Wars lightspeed screen). We were hoping you would post the powerpoint somewhere, thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9befe51704e026c46c336ed449b80ce1fbafdf7d96d6526b93c0ba6f2c67c89e-fcb33cd491c622cd050a4a7b5b13684fa88c2dc134c977cdd100f932b45ac3a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zhang Xiao")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47556")[#strong[#text("Zhang Xiao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2010")])]

#text("Thanks for sharing and I enjoy the presentation very much! By the way, I would like to mention the Titius-Bode law which to me is a miracle yet still not well understood by the astronomists:")#linebreak()#text(" ")#link("http://en.wikipedia.org/wiki/Titius%E2%80%93Bode_law")[#text("http://en.wikipedia.org/wiki/Titius%E2%80%93Bode_law")]#text(".")#linebreak()#text(" I hope it may somehow interest you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b856fff2ac52bad5be7432c8353942458388b5d83f6870631e8ae20f6b93b8a2-e8d60b3b59e4f16e78420fd4c96559be2ed1b9af1cd3181f1c12d6f7f8ad2ad4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dmfdmf")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47558")[#strong[#text("dmfdmf")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2010")])]

#text("“By establishing the relationship of feet to miles, he can grasp and know any distance on earth; by establishing the relationship of miles to light-years, he can know the distances of galaxies.” Ayn Rand “Introduction to Objectivist Epistemology”")

#link("http://aynrandlexicon.com/lexicon/measurement.html")[#text("http://aynrandlexicon.com/lexicon/measurement.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47562")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2010")])]

#text("Shouldn’t the use of these images in education/presentation settings falls under the Fair Use doctrine?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47564")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2010")])]

#text("I am not an expert on these issues, but apparently in order for UCLA to be able to place video of the talk on their public web site, permissions from the copyright holders of any images used in the talk needed to be secured.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47565")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2010")])]

#text("Yeah, video is a form of publication and thus is not “protected” by Fair Use.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47563")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2010")])]

#text("A typo on page 41: a elliptical -> an elliptical")

#emph[#text("[Will correct for Ver 4.3, thanks. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e0a16f26b62732a6aa8faf4458bea5ba6f0ca4cf593cd2624f4000c6718a55e-ca76e4b919ce6d09730d8ffcbc327111177941f9afbd6a667f27661e71b5dfdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of laurent")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47566")[#strong[#text("laurent")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2010")])]

#text("For all its limitations it is fascinating to see the power of the human mind at answering questions which are well beyond man’s physical capacities. The scalability in time and space is very well illustrated. Your slides are doing a wonderful job, thank you very much! History of (great) ideas and mathematical ingenuity are almost as interesting as mathematics themselves. If I may risk an opinion, I would prefer to see science not taught separately from its history for three reasons: 1. ideas are better understood if presented in context. 2. it is less intimidating for the student to see that all the brilliant ideas he is taught are (often) the result of a long and collective effort 3. it gives a sense of belonging.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of So muss ein Vortrag sein ! « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47576")[#strong[#text("So muss ein Vortrag sein ! « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2010")])]

#text("[…] wissen will, was ein guter Vortrag, dem empfehle ich sich den Vortrag von T. Tao „The Cosmic Distance Ladder“ anzusehen. Es ist einfach genial, wie hier die Lösung einer Jahrtausendfrage erklärt […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d10259e569f7948fb426f219171f06e13dc570f262d4c1ae121b4b024a8b1608-030659b4e829203ccdf0062ebabb0491445396a52c856fea3b1d5e19b723499e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ObsessiveMathsFreak")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47577")[#strong[#text("ObsessiveMathsFreak")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2010")])]

#text("I recommend adding a logarithmic chart somewhere (at the end?) with objects at various length scales plotted, showing how things get, say , x times bigger as you go.")

#text("One pop culture way to do this would be to plot the increasing length scales of all the mechs in Gurren Lagann(I’m actually serious).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47801")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2010")])]

#text("These sorts of plots have been done by other people much better than I could. See for instance")

#link("http://primaxstudio.com/stuff/scale_of_universe/")[#text("http://primaxstudio.com/stuff/scale_of_universe/")]

#text("(or the classic “Powers of Ten” sequence, ")#link("http://www.youtube.com/watch?v=0fKBhvDjuy0")[#text("http://www.youtube.com/watch?v=0fKBhvDjuy0")]#text(" ).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2ef4771ca2ab7dad53fcce82a8ace27e37df6d0aff62762a48a1a9969d283c2-858d8eb2df6df36936af6aebe4bac87dca04ec63500731c9a1c71683b175d99a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Amar Pai")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47588")[#strong[#text("Amar Pai")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2010")])]

#text("Just wanted to say I really enjoyed going through your slides! Quite interesting & easy to follow.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of minh")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47629")[#strong[#text("minh")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2010")])]

#text("Very interesting!")#linebreak()#text(" A typo on Images Credits: astronomy.swim.edu.au/cosmos should read astronomy.swin.edu.au/cosmos")

#emph[#text("[Corrected for Ver 4.3 – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d13918ef9f22956fbcd9b9a912ddd47fa9514b783193c321c0fa1f369cff4c1-7154fd69c9ab960ebc666fa03dce79abfd0d7acd3640136a63ccf46879d3e4e9.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andreas Thom")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47751")[#strong[#text("Andreas Thom")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2010")])]

#text("Very nice! Just two minor remarks:")

#text("– there is some slight confusion in the notation: In the computations of the distance to the moon, “D” denotes its distance to the earth, later you use “d” for distance when you are computing the distance to the sun, which you now call “D”. The letter “R” is used for both the radius of the moon and the sun, which is a smaller problem.")

#text("– The name of Copernicus is either Nikolaus Kopernikus or Nicolaus Copernicus but not Nicholas. (Slide 92)")

#emph[#text("[Thanks! This will be corrected for version 4.3 – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c712efc01dda0d0dfde02589d6b51ecad9f919c902b12282c9fbe03366671f0c-cf1225443223e8ac3172f92cde3dbbae84492ce5b80b98fbb2f492ea0bbdbde1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MathStudent")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47800")[#strong[#text("MathStudent")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2010")])]

#text("Great slides, I’m waiting eagerly for the video.")#linebreak()#text(" Incidentally, I remember reading in Carl Sagan’s “Cosmos” that Eratosthenes actually hired a man to pace the distance between Alexandria and Syene. Obviously, given the accuracy of his answer, the man faithfully walked the 5000 stadia, so the money must’ve been good!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-47867")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2010")])]

#text("Video for this talk is now available at")

#text("and at")

#link("http://www.math.ucla.edu/itunes")[#text("http://www.math.ucla.edu/itunes")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/374e43a48903df50ab37e8912e33c6ae3afe746a9edd4b3678d79c8236923dbc-d166669a941b254aeaf36e6fd87be886b49b46d29cab5c412c34c2ffd005e88d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Refreshing Childhood Math « Joseph Chan")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-49199")[#strong[#text("Refreshing Childhood Math « Joseph Chan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2010")])]

#text("[…] He described the lecture in his blog: The Cosmic Distance Ladder (version 4.1) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qiaozi")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-49376")[#strong[#text("qiaozi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2011")])]

#text("[I left these questions to your 2009-09-93 post, and then realized this update, so I dare to copy them here. Thanks!]")

#text("Dear Terry,")

#text("I have two questions about your usage of lunar eclipses to compute the distance between the earth and the moon.")

#text("1. Your Slide 48 says that “The maximum length of a lunar eclipse is three hours”, but the local time information for the December 2010 lunar eclipse (see ")#link("http://en.wikipedia.org/wiki/December_2010_lunar_eclipse")[#text("http://en.wikipedia.org/wiki/December_2010_lunar_eclipse")]#text(") shows that the the average time between the start and the end of penumbral is about 5.5 hours, and that for umbral is about 3.5 hours. Is there a disagreement?")

#text("2. Your Slide 50 computes the distance D from v=2r/3 hour=2*pi*D/1 month, so")#linebreak()#text(" \\[")#linebreak()#text(" D=r*(1 month/3 hour)/pi=r*(28*24/3)/pi=71.3r.")#linebreak()#text(" \\]")#linebreak()#text(" To replace 3 hours by 3.5 hours seems better, yielding $61.1r$, but it seems not so close to your $60r$. Did I miss something?")

#text("Thanks for your attention, and for providing us with such a beautifully written presentation!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-49381")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2011")])]

#text("I simplified the discussion for the sake of exposition. To do things properly, one has to take into account three corrections. Firstly, when computing the length of an eclipse, one has to use the length of time in which the center of the moon is in (umbral) eclipse, rather than the length of time in which some portion of the moon is in eclipse. The former is at most 3 hours, while the latter is at most 4 hours. Secondly, one has to use the synodic lunar month (about 29 days) rather than the sidereal lunar month (a bit less than 28 days) to take into account the motion of the earth around the sun. Finally, one has to take into account the fact that the umbra is not quite two Earth radii wide, due to the non-zero angular width of the sun; in fact, at the distance of the moon, it is about 25% shorter. One can take into account all of these corrections and obtain more precise values for the distance to the moon, but the mathematics is a bit more complicated than what I actually wrote on the slide (though certainly in the same spirit).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-71097")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2011")])]

#text("I saw your comment on G+. Their problem is that they believe that it is part of Christian belief, the myth of flat earth also has effected them to think incorrectly that way. See")

#link("http://en.wikipedia.org/wiki/Flat_Earth_myth")[#text("http://en.wikipedia.org/wiki/Flat_Earth_myth")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-146338")[#strong[#text("How should mathematics be taught to non-mathematicians? « Gowers's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2012")]

#text("[…] That question could lead to a more general discussion of the cosmic distance ladder, which has been beautifully explained by Terence Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e14bb8676d2b2d6fa87bf3f4ec60a2440ba826a9cf50b715d4e25189f703647-803bca68d27ba90d11d7eeb73a55c1b62699e9a3aa3bc480fa49afb262061d02.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Shepherd")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-146756")[#strong[#text("John Shepherd")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2012")])]

#text("In slide 143 the product epsilon nought mu nought should be raised to the power minus 1/2, not 1/2, to get the speed of light. Brilliant slides!")

#emph[#text("[Thanks, this will be corrected in the next revision of the slides – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-155567")[#strong[#text("Assorted free entertainment #1 « Unabashed Naïveté")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2012")]

#text("[…] Here’s Terry Tao on how our meek little species came to measure astronomical distances and map the cosmos. (Or if his presentation is too slow for you, there’s also a PDF linked in this blog post.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-184840")[#strong[#text("» Cosmic Distance Ladder")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2012")]

#text("[…] Slides More […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e63ea5e1b8218e00224ea4064e491a057dff17e7c93e5d999780a667b1087078-3d3f907f8b982b39a3aa7591934ce51e829e6701c5d4eb8f1b99d0b8dd4c075c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel Lacruz")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-488509")[#strong[#text("Miguel Lacruz")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2017")])]

#text("Dear Terry,")

#text("In slide 50 of version 4.2. 2010 you are using the relation")

#text("v = 2r / 3 hours = 2 π D / 1 month")

#text("and from there you get D = 60r. Using π=3, I get D=80r instead. Could you please explain this?")

#text("Best regards,")#linebreak()#text(" Miguel")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-488577")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2017")])]

#text("The calculation given is a slight oversimplification, because the umbra is actually a bit narrower than 2 Earth radii due to the angular spread of the Sun. This can be corrected for, but requires a somewhat more complicated mathematical analysis. I’ll update the next version of the slides with a note on this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Climbing the cosmic distance ladder (book announcement) | What's new")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-594825")[#strong[#text("Climbing the cosmic distance ladder (book announcement) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2020")])]

#text("[…] emphasising the role of mathematics in building the ladder). I previously blogged about the lecture here; the most recent version of the slides can be found here. Recently, I have begun working with Tanya […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-594837")[#strong[#text("Climbing the cosmic distance ladder: Terence Tao book announcement – A2M1N")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2020")]

#text("[…] emphasising the role of mathematics in building the ladder). I previously blogged about the lecture here; the most recent version of the slides can be found here. Recently, I have begun working with Tanya […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-594849")[#strong[#text("Ice climbing the cosmic distance ladder: Terence Tao book announcement - JellyEnt")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2020")]

#text("[…] the operate of arithmetic in building the ladder). I previously blogged referring to the lecture right here; the most modern mannequin of the slides can be realized right here. This day, I genuinely safe […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-594856")[#strong[#text("Climbing the cosmic distance ladder: Terence Tao book announcement - Your Cheer")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2020")]

#text("[…] emphasising the role of mathematics in building the ladder). I previously blogged about the lecture here; the most recent version of the slides can be found here. Recently, I have begun working with Tanya […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-594978")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2020")])]

#text("Dear Prof. Tao, would you mind to share your reference for “Copernicus started with the records of the ancient Babylonians”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-595031")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("Ah, we should reword this to make this clearer. Copernicus may not have had direct access to Babylonian primary sources, but their data on planetary motions did get incorporated into the Greek texts (e.g., Ptolemy’s Almagest) that he was working with (or more precisely, the Arabic translations of those texts). I think there were also later Arabic tables of motions that included Babylonian data that Copernicus also had access to.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-595482")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2020")])]

#text("I see, thank you for the clarification. According to wikipedia at his time direct translations of Ptolemy from greek to latin were around already (e.g., by Regiomontanus), and he was probably also able and in a condition to read the greek version.")

#text("That sentence was very intriguing as it reminded me of some questions that have been raised about how much of the mathematics usually attributed to European authors should actually be attributed to some other much older eastern civilization. Not just that it might all have been independently rediscovered (as I might had erroneously understood while reading Weil’s account on number theory) but that it was actually brought to Europe and silently used (perhaps due to inquisition) without mention of the original sources. There is something written by George Gheverghese Joseph about this and I am sure by scholars which I do not know. For some extremist positions, C. J. Raju :)")

#text("I can testimony of at least one specific case that I came across (I guess not really widely known, long to explain, I can tell in private) which still leaves me wondering how much of the “lost ancient math” might actually have been intentionally re-established in Europe at that time and how much we might still not know.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-643419")[#strong[#text("Philosophy of science and the blockchain: A book review – Windows On Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2022")]

#text("[…] right graph is adapted from Terry Tao’s excellent cosmic distance ladder presentation; I was happy to hear Tao is planning to turn it into a popular science […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-643445")[#strong[#text("A book review – Windows On Theory |")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2022")]

#text("[…] right graph is adapted from Terry Tao’s excellent cosmic distance ladder presentation; I was happy to hear Tao is planning to turn it into a popular science […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/#comment-668313")[#strong[#text("AI will change the world, but won’t take it over by playing “3-dimensional chess”. – Windows On Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2022")]

#text("[…] Figure 3: Measures of human progress both in terms of GDP and the scale of objects we can measure. Taken from this blog post, with the first figure from Our World in Data, and data for second figure from Terence Tao’s cosmic ladder presentation. […]")
]
