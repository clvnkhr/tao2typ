// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/
// Converted to Typst by tao2typ: "2026-10-14T09:04:47.577838+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245A: Problem solving strategies", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245A: Problem solving strategies")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 October 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")[#text("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is going to be a somewhat experimental post. In class, I mentioned that when solving the type of homework problems encountered in a graduate real analysis course, there are really only about a dozen or so basic tricks and techniques that are used over and over again. But I had not thought to actually try to make these tricks explicit, so I am going to try to compile here a list of some of these techniques here. But this list is going to be far from exhaustive; perhaps if other recent students of real analysis would like to share their own methods, then I encourage you to do so in the comments (even – or especially – if the techniques are somewhat vague and general in nature).")

#text("(See also the ")#link("http://www.tricki.org/")[#text("Tricki")]#text(" for some general mathematical problem solving tips. Once this page matures somewhat, I might migrate it to the Tricki.)")

#text("Note: the tricks occur here in no particular order, reflecting the stream-of-consciousness way in which they were arrived at. Indeed, this list will be extended on occasion whenever I find another trick that can be added to this list.")

#metadata(none) <tao-ee9e28fc44d82ee4135c>

#strong[#text("1. Split up equalities into inequalities.")]

#text("If one has to show that two numerical quantities X and Y are equal, try proving that ")#mi("X \\leq Y")#text(" and ")#mi("Y \\leq X")#text(" separately. (Often one of these will be very easy, and the other one harder; but the easy direction may still provide some clue as to what needs to be done to establish the other direction.)")

#text("In a similar spirit, to show that two sets E and F are equal, try proving that ")#mi("E \\subset F")#text(" and ")#mi("F \\subset E")#text(".")

#strong[#text("2. Give yourself an epsilon of room.")]

#text("If one has to show that ")#mi("X \\leq Y")#text(", try proving that ")#mi("X \\leq Y+\\varepsilon")#text(" for any ")#mi("\\varepsilon > 0")#text(". (This trick combines well with Trick 1.)")

#text("In a similar spirit, if one needs to show that a quantity ")#mi("X")#text(" vanishes, try showing that ")#tao-math("\\left|X\\right| \\leq \\varepsilon", block: false)#text(" for every ")#mi("\\varepsilon > 0")#text(".")

#text("Or: if one wishes to show that two functions ")#mi("f, g")#text(" agree almost everywhere, try showing first that ")#tao-math("\\left|f(x)-g(x)\\right| \\leq \\varepsilon", block: false)#text(" holds for almost every x, or even just outside of a set of measure at most ")#mi("\\varepsilon")#text(", for any given ")#mi("\\varepsilon > 0")#text(".")

#text("Or: if one wants to show that a sequence ")#mi("x_n")#text(" of real numbers converges to zero, try showing that ")#tao-math("\\limsup_{n \\to \\infty} \\left|x_n\\right| \\leq \\varepsilon", block: false)#text(" for every ")#mi("\\varepsilon > 0")#text(".")

#text("Don’t be too focused on getting all your error terms adding up to exactly ")#mi("\\varepsilon")#text(" – usually, as long as the final error bound consists of terms that can all be made as small as one wishes by choosing parameters in a suitable way, that is enough. For instance, an error term such as ")#mi("10\\varepsilon")#text(" is certainly OK, or even more complicated expressions such as ")#mi("10 \\varepsilon/\\delta + 4 \\delta")#text(" if one has the ability to choose ")#mi("\\delta")#text(" as small as one wishes, and then after ")#mi("\\delta")#text(" is chosen, one can then also set ")#mi("\\varepsilon")#text(" as small as one wishes (in a manner that can depend on ")#mi("\\delta")#text(").")

#text("One caveat: for finite ")#mi("x")#text(", and any ")#mi("\\varepsilon > 0")#text(", it is true that ")#mi("x+\\varepsilon > x")#text(" and ")#mi("x-\\varepsilon < x")#text(", but this statement is not true when ")#mi("x")#text(" is equal to ")#mi("+\\infty")#text(" (or ")#mi("-\\infty")#text("). So remember to exercise some care with the epsilon of room trick when some quantities are infinite.")

#text("See also ")#link("http://www.tricki.org/article/Create_an_epsilon_of_room")[#text("the Tricki article on this topic")]#text(".")

#strong[#text("3. Decompose or approximate a rough or general object by a smoother or simpler one.")]

#text("If one has to prove something about an unbounded (or infinite measure) set, consider proving it for bounded (or finite measure) sets first if this looks easier.")

#text("Similarly:")

#enum(start: 1, 
[#text("if one has to prove something about a measurable set, try proving it for open, closed, compact, bounded, or elementary sets first.")],
[#text("if one has to prove something about a measurable function, try proving it for functions that are continuous, bounded, compactly supported, simple, absolutely integrable, etc.")],
[#text("if one has to prove something about an infinite sum or sequence, try proving it first for finite truncations of that sum or sequence (but try to get all the bounds independent of the number of terms in that truncation, so that you can still pass to the limit!).")],
[#text("if one has to prove something about a complex-valued function, try it for real-valued functions first.")],
[#text("If one has to prove something about a real-valued function, try it for unsigned functions first.")],
[#text("If one has to prove something about a simple function, try it for indicator functions first.")]
)

#text("In order to pass back to the general case from these special cases, one will have to somehow decompose the general object into a combination of special ones, or approximate general objects by special ones (or as a limit of a sequence of special objects). In the latter case, one may need an epsilon of room (trick 2), and some sort of limiting analysis may be needed to deal with the errors in the approximation (it is not always enough to just “pass to the limit”, as one has to justify that the desirable properties of the approximating object are preserved in the limit).")

#emph[#text("Note")]#text(": one should not do this blindly, as one might then be loading on a bunch of distracting but ultimately useless hypotheses that end up being a lot less help than one might hope. But they should be kept in mind as something to try if one starts having thoughts such as “Gee, it would be nice at this point if I could assume that ")#mi("f")#text(" is continuous / real-valued / simple / unsigned / etc. “.")

#text("In the more quantitative areas of analysis and PDE, one sees a common variant of the above technique, namely the method of ")#emph[#text("a priori")]#text(" estimates. Here, one needs to prove an estimate or inequality for all functions in a large, rough class (e.g. all rough solutions to a PDE). One can often then first prove this inequality in a much smaller (but still “dense”) class of “nice” functions, so that there is little difficulty justifying the various manipulations (e.g. exchanging integrals, sums, or limits, or integrating by parts) that one wishes to perform. Once one obtains these ")#emph[#text("a priori")]#text(" estimates, one can then often take some sort of limiting argument to recover the general case.")

#strong[#text("4. If one needs to flip an upper bound to a lower bound or vice versa, look for a way to take reflections or complements.")]

#text("Sometimes one needs a lower bound for some quantity, but only has techniques that give upper bounds. In some cases, though, one can “reflect” an upper bound into a lower bound (or vice versa) by replacing a set ")#mi("E")#text(" contained in some space ")#mi("X")#text(" with its complement ")#mi("X \\backslash E")#text(", or a function ")#mi("f")#text(" with its negation ")#mi("-f")#text(" (or perhaps subtracting ")#mi("f")#text(" from some dominating function ")#mi("F")#text(" to obtain ")#mi("F-f")#text("). This trick works best when the objects being reflected are contained in some sort of “bounded”, “finite measure”, or “absolutely integrable” container, so that one avoids having the dangerous situation of having to subtract infinite quantities from each other.")

#text("The triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\| \\geq \\left\\|g \\right\\| - \\left\\| f-g\\right\\|", block: true)]]

#text("can be used to flip an upper bound on ")#tao-math("\\left\\|f-g\\right\\|", block: false)#text(" to a lower bound on ")#tao-math("\\left\\|f\\right\\|", block: false)#text(", provided of course one has a lower bound on ")#tao-math("\\left\\|g\\right\\|", block: false)#text(". Similarly, the Cauchy-Schwarz inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle f,g \\rangle\\right| \\leq \\left\\|f\\right\\| \\left\\|g\\right\\|", block: true)]]

#text("can flip a upper bound on ")#tao-math("\\left\\|g\\right\\|", block: false)#text(" to a lower bound on ")#tao-math("\\left\\|f\\right\\|", block: false)#text(", provided that one has a lower bound on ")#tao-math("\\left|\\langle f, g \\rangle\\right|", block: false)#text(". Holder’s inequality can also be used in a similar fashion.")

#strong[#text("5. Uncountable unions can sometimes be replaced by countable or finite unions.")]

#text("Uncountable unions are not well-behaved in measure theory; for instance, an uncountable union of null sets need not be a null set (or even a measurable set). (On the other hand, the uncountable union of ")#emph[#text("open")]#text(" sets remains open; this can often be important to know.) However, in many cases one can replace an uncountable union by a countable one. For instance, if one needs to prove a statement for all ")#mi("\\varepsilon > 0")#text(", then there are an uncountable number of ")#mi("\\varepsilon")#text("‘s one needs to check, which may threaten measurability; but in many cases it is enough to only work with a countable sequence of ")#mi("\\varepsilon")#text("s, such as the numbers ")#mi("1/m")#text(" for ")#mi("m=1,2,3,\\ldots")#text(".")

#text("In a similar spirit, given a real parameter ")#mi("\\lambda")#text(", this parameter initially ranges over uncountably many values, but in some cases one can get away with only working with a countable set of such values, such as the rationals. In a similar spirit, rather than work with all boxes (of which there are uncountably many), one might work with the dyadic boxes (of which there are only countably many; also, they obey nicer nesting properties than general boxes and so are often desirable to work with in any event).")

#text("If you are working on a compact set, then one can often replace even uncountable unions with finite ones, so long as one is working with open sets. When this option is available, it is often worth spending an epsilon of measure (or whatever other resource is available to spend) to make one’s sets open, just so that one can take advantage of compactness.")

#strong[#text("6. If it is difficult to work globally, work locally instead.")]

#text("A domain such as Euclidean space ")#mi("{\\bf R}^d")#text(" has infinite measure, and this creates a number of technical difficulties when trying to do measure theory directly on such spaces. Sometimes it is best to work more locally, for instance working on a large ball ")#mi("B(0,R)")#text(" or even a small ball such as ")#mi("B(x,\\varepsilon)")#text(" first, and then figuring out how to patch things together later. Compactness (or the closely related property of total boundedness) is often useful for patching together small balls to cover a large ball. Patching together large balls into the whole space tends to work well when the properties one are trying to establish are local in nature (such as continuity, or pointwise convergence) or behave well with respect to countable unions. For instance, to prove that a sequence of functions ")#mi("f_n")#text(" converges pointwise almost everywhere to ")#mi("f")#text(" on ")#mi("{\\bf R}^d")#text(", it suffices to verify this pointwise almost everywhere convergence on the ball ")#mi("B(0,R)")#text(" for every ")#mi("R > 0")#text(" (which one can take to be an integer to get countability, see Trick 5).")

#strong[#text("7. Be willing to throw away an exceptional set.")]

#text("The “Lebesgue philosophy” to measure theory is that null sets are often “irrelevant”, and so one should be very willing to cut out a set of measure zero on which bad things are happening (e.g. a function is undefined or infinite, a sequence of functions is not converging, etc.). One should also be only slightly less willing to throw away sets of positive but small measure, e.g. sets of measure at most ")#mi("\\varepsilon")#text(". If such sets can be made arbitrarily small in measure, this is often almost as good as just throwing away a null set.")

#text("Many things in measure theory improve after throwing away a small set. The most notable examples of this are Egorov’s theorem (pointwise a.e. convergence becomes locally uniform convergence after throwing away a small set) and Lusin’s theorem (measurable functions become continuous after throwing away a small set). A related (and simpler) principle is that a measurable function ")#mi("f")#text(" that is finite almost everywhere can become locally bounded after throwing away a small set (this can be seen by applying downward monotone convergence to exceptional sets such as ")#tao-math("\\{ x \\in B(0,R): \\left|f(x)\\right| \\geq N \\}", block: false)#text(" as ")#mi("N \\to \\infty")#text("). From Markov’s inequality, one also sees that a function that is small in ")#mi("L^1")#text(" norm becomes small uniformly after throwing away a small set. (The same is true for functions that are small in other ")#mi("L^p")#text(" norms, or (by definition) for functions that are converging to zero in measure.)")

#text("A little later in this course, we will also start seeing a similar trick of throwing away most of a sequence and working with a subsequence instead. (This trick can also be interpreted as “throwing away a small set”, but to understand what “small” means in this context, one needs the language of ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilters")]#text(", which will not be discussed here.) See Trick 17 below.")

#strong[#text("8. Draw pictures and try to build counterexamples.")]

#text("Measure theory, particularly on Euclidean spaces, has a significant geometric aspect to it, and you should be exploiting your geometric intuition. Drawing pictures and graphs of all the objects being studied is a good way to start. These pictures need not be completely realistic; they should be just complicated enough to hint at the complexities of the problem, but not more. (For instance, usually one- or two-dimensional pictures suffice for understanding problems in ")#mi("{\\bf R}^d")#text("; drawing intricate 3D (or 4D, etc.) pictures does not often make things simpler. To indicate that a function is not continuous, one or two discontinuities or oscillations might suffice; make it too ornate and it becomes less clear what to do about that function.)")

#text("A common mistake is to try to draw a picture in which both the hypotheses and conclusion of the problem hold. This is actually not all that useful, as it often does not reveal the causal relationship between the former and the latter. One should try instead to draw a picture in which the hypotheses hold but for which the conclusion does not – in other words, a ")#emph[#text("counterexample")]#text(" to the problem. Of course, you should be expected to fail at this task, given that the statement of the problem is presumably true. However, the ")#emph[#text("way")]#text(" in which your picture fails to accomplish this task is often very instructive, and can reveal vital clues as to how the solution to the problem is supposed to proceed.")

#strong[#text("9. Try simpler cases first.")]

#text("This advice of course extends well beyond measure theory, but if one is completely stuck on a problem, try making the problem simpler (while still capturing at least one of the difficulties of the problem that you cannot currently resolve). For instance, if faced with a problem in ")#mi("{\\bf R}^d")#text(", try the one-dimensional case ")#mi("d=1")#text(" first. Faced with a problem about a general measurable function ")#mi("f")#text(", try a much simpler case first, such as an indicator function ")#mi("f = 1_E")#text(". Faced with a problem about a general measurable set, try an elementary set first. Faced with a problem about a sequence of functions, try a monotone sequence of functions first. And so forth. (Note that this trick overlaps quite a bit with Trick 3.)")

#text("The problem should not be made so simple that it becomes trivial, as this doesn’t really gain you any new insight about the original problem; instead, one should try to keep the “essential” difficulties of the problem while throwing away those aspects that you think are less important (but are still serving to add to the overall difficulty level).")

#text("On the other hand, if the simplified problem is unexpectedly easy, but one cannot extend the methods to the general case (or somehow leverage the simplified case to the general case, as in Trick 3), this is an indication that the true difficulty lies elsewhere. For instance, if a problem involving general functions could be solved easily for monotone functions, but one cannot then extend that argument to the general case, this suggests that the true enemy is oscillation, and perhaps one should try another simple case in which the function is allowed to be highly oscillatory (but perhaps simple in other ways, e.g. bounded with compact support).")

#strong[#text("10. Abstract away any information that you believe or suspect to be irrelevant.")]

#text("Sometimes one is faced with an embarrassment of riches when it comes to what choice of technique to use on a problem; there are so many different facts that one knows about the problem, and so many different pieces of theory that one could apply, that one doesn’t quite know where to begin.")

#text("When this happens, ")#emph[#text("abstraction")]#text(" can be a vital tool to clear away some of the conceptual clutter. Here, one wants to “forget” part of the setting that the problem is phrased in, and only keep the part that seems to be most relevant to the hypotheses and conclusions of the problem (and thus, presumably, to the solution as well).")

#text("For instance, if one is working in a problem that is set in Euclidean space ")#mi("{\\bf R}^d")#text(", but the hypotheses and conclusions only involve measure-theoretic concepts (e.g. measurability, integrability, measure, etc.) rather than topological structure, metric structure, etc., then it may be worthwhile to try abstracting the problem to the more general setting of an abstract measure space, thus forgetting that one was initially working in ")#mi("{\\bf R}^d")#text(". The point of doing this is that it cuts down on the number of possible ways to start attacking the problem. For instance, facts such as outer regularity (every measurable set can be approximated from above by an open set) do not hold in abstract measure spaces (which do not even have a meaningful notion of an open set), and so presumably will not play a role in the solution; similarly for any facts involving boxes. Instead, one should be trying to use general facts about measure, such as countable additivity, which are not specific to ")#mi("{\\bf R}^d")#text(".")

#text("[It is worth noting that sometimes this abstraction method does not always work; for instance, when viewed as a measure space, ")#mi("{\\bf R}^d")#text(" is not completely arbitrary, but does have one or two features that distinguish it from a generic measure space, most notably the fact that it is ")#link("http://en.wikipedia.org/wiki/%CE%A3-finite_measure")[#mi("\\sigma")#text("-finite")]#text(". So, even if the hypotheses and conclusion of a problem about ")#mi("{\\bf R}^d")#text(" is purely measure-theoretic in nature, one may still need to use some measure-theoretic facts specific to ")#mi("{\\bf R}^d")#text(". Here, it becomes useful to know a little bit about the classification of measure spaces to have some intuition as to how “generic” a measure space such as ")#mi("{\\bf R}^d")#text(" really is. This intuition is hard to convey at this level of the subject, but in general, measure spaces form a very “non-rigid” category, with very few invariants, and so it is largely true that one measure space usually behaves much the same as any other.]")

#text("Another example of abstraction: suppose that a problem involves a large number of sets (e.g. ")#mi("E_n")#text(" and ")#mi("F_n")#text(") and their measures, but that the conclusion of the problem only involves the measures ")#mi("m(E_n), m(F_n)")#text(" of the sets, rather than the sets themselves. Then one can try to abstract the sets out of the problem, by trying to write down every single relationship between the numerical quantities ")#mi("m(E_n), m(F_n)")#text(" that one can easily deduce from the given hypotheses (together with basic properties of measure, such as monotonicity or countable additivity). One can then rename these quantities (e.g. ")#mi("a_n := m(E_n)")#text(" and ")#mi("b_n := m(F_n)")#text(") to “forget” that these quantities arose from a measure-theoretic context, and then work with a purely numerical problem, in which one is starting with hypotheses on some sequences ")#mi("a_n, b_n")#text(" of numbers and trying to deduce a conclusion about such sequences. Such a problem is often easier to solve than the original problem due to the simpler context. Sometimes, this simplified problem will end up being false, but the counterexample will often be instructive, either in indicating the need to add an additional hypothesis connecting the ")#mi("a_n, b_n")#text(", or to indicate that one cannot work at this level of abstraction but must introduce some additional concrete ingredient.")

#text("A real-life example: a student once asked me how to justify the claim that")

#align(center)[#tao-fit-display[#tao-math("e^{\\pi i\\lambda^{-1}\\langle T^{-1}\\xi,\\xi\\rangle} =\\sum_{j=0}^N\\frac{(\\pi i\\lambda^{-1}\\langle T^{-1}\\xi,\\xi\\rangle)^j}{j!} +O(\\frac{\\left|\\xi\\right|^{2N+2}}{\\lambda^{N+1}})", block: true)]]

#text("uniformly for ")#mi("\\xi \\in {\\bf R}^d")#text(" and ")#mi("\\lambda > 0")#text(", where ")#mi("T: {\\bf R}^d \\to {\\bf R}^d")#text(" is a fixed linear operator and ")#mi("N")#text(" is a fixed natural number. This expression looks very complicated, but if one observes that the expression ")#mi("x := \\pi \\lambda^{-1}\\langle T^{-1}\\xi,\\xi\\rangle")#text(" is common to both sides, and that this expression is of magnitude ")#tao-math("O( \\left|\\xi\\right|^2 / \\lambda )", block: false)#text(", one sees that actually one can abstract this claim to the simpler claim")

#align(center)[#tao-fit-display[#mitex("e^{ix} = \\sum_{j=0}^N \\frac{(ix)^j}{j!} + O( x^{N+1} ).")]]

#text("At this point it is clear what to do: use Taylor’s theorem with remainder.")

#text("Note that this trick is in many ways the antithesis of Trick 9, because by passing to a special case, one often makes the problem more concrete, with more things that one is now able to start trying. However, the two tricks can work together. One particularly useful “advanced move” in mathematical problem solving is to first abstract the problem to a more general one, and ")#emph[#text("then")]#text(" consider a special case of that more abstract problem which is not directly related to the original one, but is somehow simpler than the original while still capturing some of the essence of the difficulty. Attacking this alternate problem can then lead to some indirect but important ways to make progress on the original problem.")

#strong[#text("11. Exploit Zeno’s paradox: a single epsilon can be cut up into countably many sub-epsilons.")]

#text("A particularly useful fact in measure theory is that one can cut up a single epsilon into countably many pieces, for instance by using the geometric series identity")

#align(center)[#tao-fit-display[#mitex("\\varepsilon = \\varepsilon/2 + \\varepsilon/4 + \\varepsilon/8 + \\ldots;")]]

#text("this observation arguably goes all the way back to ")#link("http://en.wikipedia.org/wiki/Zeno%27s_paradoxes")[#text("Zeno")]#text(". As such, even if one only has an epsilon of room budgeted for a problem, one can still use this budget to do a countably infinite number of things. This fact underlies many of the countable additivity and subadditivity properties in measure theory, and also makes the ability to approximate rough objects by smoother ones to be useful even when countably many rough objects need to be approximated.")

#text("In general, one should be alert to this sort of trick when one has to spend an epsilon or so on an infinite number of objects. If one was forced to spend the same epsilon on each object, one would soon end up with an unacceptable loss; but if one can get away with using a different epsilon each time, then Zeno’s trick comes in very handy.")

#text("Needless to say, this trick combines well with Trick 2.")

#strong[#text("12. If you expand your way to a double sum, a double integral, a sum of an integral, or an integral of a sum, try interchanging the two operations.")]

#text("Or, to put it another way: “The ")#link("http://en.wikipedia.org/wiki/Fubini's_theorem")[#text("Fubini-Tonelli theorem")]#text(" is your friend”. Provided that one is either in the unsigned or absolutely convergent worlds, this theorem allows you to interchange sums and integrals with each other. In many cases, a double sum or integral that is difficult to sum in one direction can become easier to sum (or at least to upper bound, which is often all that one needs in analysis). In fact, if in the course of expanding an expression, you encounter such a double sum or integral, you should reflexively try interchanging the operations to see if the resulting expression looks any simpler.")

#text("Note that in some cases the parameters in the summation may be constrained, and one may have to take a little care to sum it properly. For instance,")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{n=-\\infty}^\\infty \\sum_{m=n}^\\infty a_{m,n}")]]

#text("interchanges (assuming that the ")#mi("a_{n,m}")#text(" are either unsigned or absolutely convergent) to")

#align(center)[#tao-fit-display[#mitex("\\sum_{m=-\\infty}^\\infty \\sum_{n=-\\infty}^m a_{m,n}")]]

#text("(why? try plotting the set of pairs ")#mi("(m,n)")#text(" that appear in both). If one is having trouble interchanging constrained sums or integrals, one solution is to re-express the constraint using indicator functions. For instance, one can rewrite the constrained sum (1) as the unconstrained sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=-\\infty}^\\infty \\sum_{m=-\\infty}^\\infty 1_{m \\geq n} a_{m,n}")]]

#text("(extending the domain of ")#mi("a_{m,n}")#text(" if necessary), at which point interchanging the summations is easily accomplished.")

#text("The following point is obvious, but bears mentioning explicitly: while the interchanging sums/integrals trick can be very powerful, one should not apply it twice in a row to the same double sum or double operation, unless one is doing something genuinely non-trivial in between those two applications. So, after one exchanges a sum or integral, the next move should be something other than another exchange (unless one is dealing with a triple or higher sum or integral).")

#text("A related move (not so commonly used in measure theory, but occurring in other areas of analysis, particularly those involving the geometry of Euclidean spaces) is to merge two sums or integrals into a single sum or integral over the product space, in order to use some additional feature of the product space (e.g. rotation symmetry) that is not readily visible in the factor spaces. The classic example of this trick is the evaluation of the gaussian integral ")#mi("\\int_{-\\infty}^\\infty e^{-x^2}\\ dx")#text(" by squaring it, rewriting that square as the two-dimensional gaussian integral ")#mi("\\int_{{\\bf R}^2} e^{-x^2-y^2}\\ dx dy")#text(", and then switching to polar coordinates.")

#strong[#text("13. Pointwise control, uniform control, and integrated (average) control are all partially convertible to each other.")]

#text("There are three main ways to control functions (or sequences of functions, etc.) in analysis. Firstly, there is pointwise control, in which one can control the function at every point (or almost every point), but in a non-uniform way. Then there is uniform control, where one can control the function in the same way at most points (possibly throwing out a set of zero measure, or small measure). Finally, there is integrated control (or control “on the average”), in which one controls the integral of a function, rather than the pointwise values of that function.")

#text("It is important to realise that control of one type can often be partially converted to another type. Simple examples include the deduction of pointwise convergence from uniform convergence, or integrating a pointwise bound ")#mi("f(x) \\leq g(x)")#text(" to obtain an integrated bound ")#mi("\\int f \\leq \\int g")#text(". Of course, these conversions are not reversible and thus lose some information; not every pointwise convergent sequence is uniformly convergent, and an integral bound does not imply a pointwise bound. However, one can partially reverse such implications if one is willing to throw away an exceptional set (Trick 7). For instance, Egorov’s theorem lets one convert pointwise convergence to (local) uniform convergence after throwing away an exceptional set, and Markov’s inequality lets one convert integral bounds to pointwise bounds, again after throwing away an exceptional set.")

#strong[#text("14. If the conclusion and hypotheses look particularly close to each other, just expand out all the definitions and follow your nose.")]

#text("This trick is particularly useful when building the most basic foundations of a theory. Here, one may not need to experiment too much with generalisations, abstractions, or special cases, or try to marshall a lot of possibly relevant facts about the objects being studied: sometimes, all one has to do is go back to first principles, write out all the definitions with their epsilons and deltas, and start plugging away at the problem.")

#text("Knowing when to just follow one’s nose, and when to instead look for a more high-level approach to a problem, can require some judgement or experience. A direct approach tends to work best when the conclusion and hypothesis already look quite similar to each other (e.g. they both state that a certain set or family of sets is measurable, or they both state that a certain function or family of functions is continuous, etc.). But when the conclusion looks quite different from the hypotheses (e.g. the conclusion is some sort of integral identity, and the hypotheses involve measurability or convergence properties), then one may need to use more sophisticated tools than what one can easily get from using first principles.")

#strong[#text("15. Don’t worry too much about exactly what ")#mi("\\varepsilon")#text(" (or ")#mi("\\delta")#text(", or ")#mi("N")#text(", etc.) needs to be. It can usually be chosen or tweaked later if necessary.")]

#text("Often in the middle of an argument, you will want to use some fact that involves a parameter, such as ")#mi("\\varepsilon")#text(", that you are completely free to choose (subject of course to reasonable constraints, such as requiring ")#mi("\\varepsilon")#text(" to be positive). For instance, you may have a measurable set and decide to approximate it from above by an open set of at most ")#mi("\\varepsilon")#text(" more measure. But it may not be obvious exactly what value to give this parameter ")#mi("\\varepsilon")#text("; you have so many choices available that you don’t know which one to pick!")

#text("In many cases, one can postpone thinking about this problem by leaving ")#mi("\\varepsilon")#text(" undetermined for now, and continuing on with one’s argument, which will gradually start being decorated with ")#mi("\\varepsilon")#text("‘s all over the place. At some point, one will need ")#mi("\\varepsilon")#text(" to do something (and, in the particular case of ")#mi("\\varepsilon")#text(", “doing something” almost always means “being small enough”), e.g. one may need ")#mi("3n\\varepsilon")#text(" to be less than ")#mi("\\delta")#text(", where ")#mi("n, \\delta")#text(" are some other positive quantities in one’s problem that do not depend on ")#mi("\\varepsilon")#text(". At this point, one could now set ")#mi("\\varepsilon")#text(" to be whatever is needed to get past this step in the argument, e.g. one could set ")#mi("\\varepsilon")#text(" to equal ")#mi("\\delta/4n")#text(". But perhaps one still wishes to retain the freedom to set ")#mi("\\varepsilon")#text(" because it might come in handy later. In that case, one sets aside the requirement “")#mi("3n \\varepsilon < \\delta")#text("” and keeps going. Perhaps a bit later on, one might need ")#mi("\\varepsilon")#text(" to do something else; for instance, one might also need ")#mi("5\\varepsilon \\leq 2^{-n}")#text(". Once one has compiled the complete “wish list” of everything one wishes one’s parameters to do, then one can finally make the decision of what value to set those parameters equal to. For instance, if the above two inequalities are the only inequalities required of ")#mi("\\varepsilon")#text(", one can choose ")#mi("\\varepsilon")#text(" equal to ")#mi("\\min( \\delta/4n, 2^{-n}/5)")#text(". This may be a choice of ")#mi("\\varepsilon")#text(" which was not obvious at the start of the argument, but becomes so as the argument progresses.")

#text("There is however one big caveat when adopting this “choose parameters later” approach, which is that one needs to avoid a circular dependence of constants. For instance, it is perfectly fine to have two arbitrary parameters ")#mi("\\varepsilon")#text(" and ")#mi("\\delta")#text(" floating around unspecified for most of the argument, until at some point you realise that you need ")#mi("\\varepsilon")#text(" to be smaller than ")#mi("\\delta")#text(", and so one chooses ")#mi("\\varepsilon")#text(" accordingly (e.g. one sets it to equal ")#mi("\\delta/2")#text("). Or, perhaps instead one needs ")#mi("\\delta")#text(" to be smaller than ")#mi("\\varepsilon")#text(", and so sets ")#mi("\\delta")#text(" equal to ")#mi("\\varepsilon/2")#text(". One can execute either of these two choices separately, but of course one cannot perform them simultaneously; this sets up an inconsistent circular dependency in which ")#mi("\\varepsilon")#text(" needs to be defined after ")#mi("\\delta")#text(" is chosen, and ")#mi("\\delta")#text(" can only be chosen after ")#mi("\\varepsilon")#text(" is fixed. So, if one is going to delay choosing a parameter such as ")#mi("\\varepsilon")#text(" until later, it becomes important to mentally keep track of what objects in one’s argument depend on ")#mi("\\varepsilon")#text(", and which ones are independent of ")#mi("\\varepsilon")#text(". One can choose ")#mi("\\varepsilon")#text(" in terms of the latter quantities, but one usually cannot do so in terms of the former quantities (unless one takes the care to show that the interlinked constraints between the quantities are still consistent, and thus simultaneously satisfiable).")

#text("See also the Tricki article “")#link("http://www.tricki.org/article/Keep_parameters_unspecified_until_it_is_clear_how_to_optimize_them")[#text("Keep parameters unspecified until it is clear how to optimize them")]#text("“.")

#strong[#text("16. Once one has started to lose some constants (or some epsilons), don’t be hesitant to lose some more.")]

#text("Many techniques in analysis end up giving inequalities that are inefficient by a constant factor. For instance, any argument involving dyadic decomposition and powers of two tends to involve losses of factors of 2. When arguing using balls in Euclidean space, one sometimes loses factors involving the volume of the unit ball (although this factor often cancels itself out if one tracks it more carefully). And so forth. However, in many cases these constant factors end up being of little importance: an upper bound of ")#mi("2\\varepsilon")#text(" or ")#mi("100\\varepsilon")#text(" is often just as good as an upper bound of ")#mi("\\varepsilon")#text(" for the purposes of analysis (cf. Trick 15). So it is often best not to invest too much energy in carefully computing and optimising these constants; giving these constants a symbol such as ")#mi("C")#text(", and not worrying about their exact value, is often the simplest approach. (One can also use asymptotic notation, such as ")#mi("O()")#text(", which is very convenient to use once you know how it works.)")

#text("Now there are some cases in which one really does not want to lose any constants at all. For instance, if one is using Trick 1 to prove that ")#mi("X=Y")#text(", it is not enough to show that ")#mi("X \\leq 2Y")#text(" and ")#mi("Y \\leq 2X")#text("; one really needs to show ")#mi("X \\leq Y")#text(" and ")#mi("Y \\leq X")#text(" without losing any constants. (But proving ")#mi("X \\leq (1+\\varepsilon)Y")#text(" and ")#mi("Y \\leq (1+\\varepsilon)X")#text(" for every ")#mi("\\varepsilon > 0")#text(" is OK, by Trick 2.) But once one has already performed one step that loses a constant, there is little further to be lost by losing more; there can be a big difference between ")#mi("X \\leq Y")#text(" and ")#mi("X \\leq 2Y")#text(", but there is little difference in practice between ")#mi("X \\leq 2Y")#text(" and ")#mi("X \\leq 100Y")#text(", at least for the purposes of mathematical analysis. At that stage, one should put oneself in the mental mode of thought where “constants don’t matter”, which can lead to some simplifications. For instance, if one has to estimate a sum ")#mi("X+Y")#text(" of two positive quantities, one can start using such estimates as")

#align(center)[#tao-fit-display[#mitex("\\max(X,Y) \\leq X+Y \\leq 2 \\max(X,Y),")]]

#text("which says that, up to a factor of ")#mi("2")#text(", ")#mi("X+Y")#text(" is the same thing as ")#mi("\\max(X,Y)")#text(". In some cases the latter is easier to work with (e.g. ")#mi("\\max(X,Y)^n")#text(" is equal to ")#mi("\\max(X^n,Y^n)")#text(", whereas the formula for ")#mi("(X+Y)^n")#text(" is messier).")

#text("A related principle: if one is in the common situation where one can afford to have some error terms, then often approximate formulae can be more useful than exact formulae. For instance, a Taylor expansion with remainder such as ")#mi("f(x_0+h) = f(x_0) + f^{\\prime}(x_0) h + \\frac{1}{2} f^{\\prime\\prime}(x_0) h^2 + O(h^3)")#text(" can often be more useful than the full Taylor series ")#mi("f(x_0+h) = \\sum_{n=0}^\\infty \\frac{1}{n!} f^{(n)}(x_0) h^n")#text(". As a general rule of thumb, once one has a formula that is accurate up to the order of magnitude of error one is willing to tolerate, it is usually not very productive to try to refine the formula much further to improve the accuracy.")

#text("In a similar spirit, if one wants to optimise some expression (such as ")#mi("\\varepsilon \\lambda e^\\lambda + 1/\\lambda")#text(") in a parameter such as ")#mi("\\lambda > 0")#text(" (where in this example ")#mi("\\varepsilon > 0")#text(" is a small quantity), and one is willing to lose a constant factor, then it is often not necessary to perform the undergraduate calculus steps of differentiating in the parameter and setting the derivative equal to zero; one can instead just test a few values of the parameter ")#mi("\\lambda")#text(" and see what produces a near-optimal result. For instance, setting any ")#mi("\\lambda")#text(" larger than ")#mi("\\log \\frac{1}{\\varepsilon}")#text(" will give a terrible first term, but setting ")#mi("\\lambda = \\log \\frac{1}{\\varepsilon}")#text(" gives a first term that is only of size ")#mi("\\log \\frac{1}{\\varepsilon}")#text(", and a second term that is the smaller size ")#mi("1/\\log \\frac{1}{\\varepsilon}")#text(". To balance this one can instead set ")#mi("\\lambda = \\log \\frac{1}{\\varepsilon} - 2 \\log\\log \\frac{1}{\\varepsilon}")#text(", and now one sees that both terms are of size ")#mi("O( 1/\\log \\frac{1}{\\varepsilon} )")#text(". One can also easily show that it is not possible for both terms to simultaneously be significantly smaller than ")#mi("O( 1/\\log \\frac{1}{\\varepsilon} )")#text(". so the optimal bound here is indeed ")#mi("O( 1/\\log \\frac{1}{\\varepsilon} )")#text(". (Now try to arrive at the same conclusion using undergraduate calculus.)")

#strong[#text("17. One can often pass to a subsequence to improve the convergence properties.")]

#text("In real analysis, one often ends up possessing a sequence of objects, such as a sequence of functions ")#mi("f_n")#text(", which may converge in some rather slow or weak fashion to a limit ")#mi("f")#text(". Often, one can improve the convergence of this sequence by passing to a subsequence. For instance:")

#enum(start: 1, 
[#text("In a metric space, if a sequence ")#mi("x_n")#text(" converges to a limit ")#mi("x")#text(", then one can find a subsequence ")#mi("x_{n_j}")#text(" which converges quickly to the same limit ")#mi("x")#text(", for instance one can ensure that ")#mi("d(x_{n_j},x) \\leq 2^{-j}")#text(" (or one can replace ")#mi("2^{-j}")#text(" with any other positive expression depending on ")#mi("j")#text("). In particular, one can make ")#mi("\\sum_{j=1}^\\infty d(x_{n_j},x)")#text(" and ")#mi("\\sum_{j=1}^\\infty d(x_{n_j},x_{n_{j+1}})")#text(" absolutely convergent, which is sometimes useful.")],
[#text("A sequence of functions that converges in ")#mi("L^1")#text(" norm or in measure can be refined to a subsequence that converges pointwise almost everywhere as well.")],
[#text("A sequence in a (sequentially) compact space may not converge at all, but some subsequence of it will always converge.")],
[#text("The pigeonhole principle: A sequence which takes only finitely many values has a subsequence that is constant. More generally, a sequence which lives in the union of finitely many sets has a subsequence that lives in just one of these sets.")]
)

#text("Often, the subsequence is good enough for one’s applications, and there are also a number of ways to get back from a subsequence to the original sequence:")

#enum(start: 1, 
[#text("In a metric space, if you know that ")#mi("x_n")#text(" is a Cauchy sequence, and some subsequence of ")#mi("x_n")#text(" already converges to ")#mi("x")#text(", then this drags the entire sequence with it, i.e. ")#mi("x_n")#text(" converges to ")#mi("x")#text(" also.")],
[#text("The Urysohn subsequence principle: in a topological space, if every subsequence of a sequence ")#mi("x_n")#text(" itself has a subsequence that converges to a limit ")#mi("x")#text(", then the entire sequence converges to ")#mi("x")#text(".")]
)

#strong[#text("18. A real limit can be viewed as a meeting of the limit superior and limit inferior.")]

#text("A sequence ")#mi("x_n")#text(" of real numbers does not necessarily have a limit ")#mi("\\lim_{n \\to \\infty} x_n")#text(", but the limit superior ")#mi("\\limsup_{n \\to \\infty} x_n := \\inf_N \\sup_{n>N} x_n")#text(" and the limit inferior ")#mi("\\liminf_{n \\to \\infty} x_n = \\sup_N \\inf_{n>N} x_n")#text(" always exist (though they may be infinite), and can be easily defined in terms of infima and suprema. Because of this, it is often convenient to work with the lim sup and lim inf instead of a limit. For instance, to show that a limit ")#mi("\\lim_{n \\to \\infty} x_n")#text(" exists, it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\limsup_{n \\to \\infty} x_n \\leq \\liminf_{n \\to \\infty} x_n + \\varepsilon")]]

#text("for all ")#mi("\\varepsilon > 0")#text(". In a similar spirit, to show that a sequence ")#mi("x_n")#text(" of real numbers converges to zero, it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{n \\to \\infty} \\left|x_n\\right| \\leq \\varepsilon", block: true)]]

#text("for all ")#mi("\\varepsilon > 0")#text(". It can be more convenient to work with lim sups and lim infs instead of limits because one does not need to worry about the issue of whether the limit exists or not, and many tools (notably Fatou’s lemma and its relatives) still work in this setting. One should however be cautious that lim sups and lim infs tend to have only one half of the linearity properties that limits do; for instance, lim sups are subadditive but not necessarily additive, while lim infs are superadditive but not necessarily additive.")

#strong[#text("19. Be aware of and exploit the symmetries of the problem, for instance to normalise a key mathematical object, or to locate instructive limiting cases.")]

#text("In many problems in analysis enjoy some sort of symmetry (such as translation symmetry or homogeneity) in which the truth of the statement to be proven is clearly unchanged (or nearly unchanged) if one applies this symmetry to the parameters of the problem. For instance, if one wishes to establish an estimate of the form")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Tf \\right\\|_Y \\leq C \\left\\|f\\right\\|_X", block: true)]]

#text("for all ")#mi("f \\in X")#text(", then one can notice that this estimate enjoys a homogeneity symmetry, in that one can multiply ")#mi("f")#text(" by an arbitrary non-zero constant ")#mi("c")#text(" without changing the truth value of the above estimate, since the inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T(cf) \\right\\|_Y \\leq C \\left\\|cf\\right\\|_X", block: true)]]

#text("is clearly equivalent to the original inequality.")

#text("Being aware of such symmetries can have many advantages. Most obviously, one can ")#emph[#text("spend")]#text(" such symmetries to achieve a convenient normalisation; for instance, in the above problem, one can spend the homogeneity symmetry to obtain the normalisation ")#tao-math("\\left\\|f\\right\\|_X = 1", block: false)#text(" (in some rare cases, ")#tao-math("\\left\\|Tf\\right\\|_Y = 1", block: false)#text(" would be a more convenient normalisation). Once one enforces such a normalisation, though, the symmetry is “spent” and cannot be simultaneously used to achieve a different normalisation that is incompatible with the previous one (for instance one cannot simultaneously normalise ")#tao-math("\\left\\|f\\right\\|_X=1", block: false)#text(" and ")#tao-math("\\left\\|Tf\\right\\|_Y=1", block: false)#text("). It is thus desirable to collect as many symmetries of the problem as one can, so that one can normalise as much as possible (but one has to check that spending one symmetry to achieve a normalisation does not destroy the other symmetries one is planning to spend). For instance, to prove Holder’s inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|fg\\right\\|_{L^r(X,\\mu)} \\leq \\left\\|f\\right\\|_{L^p(X,\\mu)} \\left\\|g\\right\\|_{L^q(X,\\mu)}", block: true)]]

#text("one can use the homogeneity in ")#mi("f")#text(" and ")#mi("g")#text(" separately to simultaneously achieve the normalisations ")#tao-math("\\left\\|f\\right\\|_{L^p(X,\\mu)}=\\left\\|g\\right\\|_{L^q(X,\\mu)}=1", block: false)#text("; but one can also use the symmetry ")#tao-math("f \\mapsto \\left|f\\right|, g \\mapsto \\left|g\\right|", block: false)#text(" to make ")#mi("f,g")#text(" non-negative, and also the symmetry ")#tao-math("f \\mapsto \\left|f\\right|^c, g \\mapsto \\left|g\\right|^c, p \\mapsto p/c, q \\mapsto q/c, r \\mapsto r/c", block: false)#text(" to normalise one of the exponent, say ")#mi("r")#text(", to be equal to 1. Finally there is a symmetry ")#mi("f \\mapsto w^{-1/p} f")#text(", ")#mi("g \\mapsto w^{-1/q} g")#text(", ")#mi("d\\mu \\mapsto w\\ d\\mu")#text(" arising from reweighting the measure, which can be used (for instance) to achieve a normalisation ")#mi("f=g")#text(", which can be convenient for some proofs of this inequality (see ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("this previous blog post")]#text(" for more discussion).")

#text("A more advanced move is to ")#emph[#text("arbitrage")]#text(" an imbalance in symmetry in a statement to strengthen it, or to locate interesting asymptotic special cases; I discuss these sorts of tricks ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("in this post")]#text(". This is particularly powerful with respect to the symmetry of taking tensor products, where it is known as the “tensor power trick”. As another example, if one wishes to prove a nonlinear inequality of the form")

#align(center)[#tao-fit-display[#mitex("F(f+g) \\leq F(f)")]]

#text("for some given ")#mi("f")#text(" and all ")#mi("g")#text(" in some vector space, one can exploit the imbalance of symmetry with respect to dilations ")#mi("g \\mapsto \\varepsilon g")#text(" to rewrite this as")

#align(center)[#tao-fit-display[#mitex("F(f+\\varepsilon g) \\leq F(f)")]]

#text("and then by sending ")#mi("\\varepsilon \\to 0")#text(" one obtains some useful linearisations of the problem which can then be studied first (e.g., if ")#mi("F")#text(" is differentiable, one has the sub-problem of checking that ")#mi("F^{\\prime}(f)=0")#text(", and if ")#mi("F")#text(" is twice differentiable, there is also the sub-problem of checking that ")#mi("F^{\\prime\\prime}(f)")#text(" is negative semidefinite).")

#text("Symmetries can also be used to detect errors (particularly with regards to exponents), much as dimensional analysis is used in physics; see also this related ")#link("http://www.tricki.org/article/Use_basic_examples_to_calibrate_exponents")[#text("Tricki article")]#text(".")

#text("Because symmetries are so useful, it is often worth abstracting or generalising the problem to make these symmetries more evident; thus this trick combines well with Trick 10.")

#strong[#text("20. To show that a “completed” mathematical object exists, one can first build an “incomplete” mathematical object, find a way to make it more complete, and appeal to Zorn’s lemma to conclude.")]

#text("This trick is so standard in analysis that one sometimes sees lemmas in the literature whose entire proof is basically “Apply Zorn’s lemma in the obvious fashion.” The ")#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/")[#text("Hahn-Banach theorem")]#text(" is a well known example of this, but there are many others (e.g. the proof of existence of non-principal ultrafilters, discussed in ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("this previous post")]#text("). See ")#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/")[#text("my blog post on Zorn’s lemma")]#text(" for more discussion. One subtlety when applying this lemma is that one has to check that the class of incomplete objects one is applying Zorn’s lemma to is actually a set rather than a proper class; see ")#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/")[#text("this previous blog post")]#text(" for more discussion.")

#text("Zorn’s lemma of course relies on the axiom of choice, and the objects produced by this lemma are generally considered to be “nonconstructive”, but this should not deter one from using it; in practical applications (not involving pathological or hugely infinite objects), one can often rework an argument using Zorn’s lemma into a lengthier but more constructive one that does not require the axiom of choice.")

#strong[#text("21. To demonstrate that all objects in a certain class obey a certain property, first show that this property is closed under various basic operations of the class, and then establish the property for “generating” elements of the class.")]

#text("This is a variant of Trick 3. It can be illustrated by some basic examples:")

#enum(start: 1, 
[#text("(Induction) To show that a property ")#mi("P(n)")#text(" holds for all natural numbers ")#mi("n")#text(", first show that it is preserved under incrementation (if ")#mi("P(n)")#text(" holds, then ")#mi("P(n+1)")#text(" holds), then check the base case ")#mi("P(0)")#text(" arising from the generator ")#mi("n=0")#text(".")],
[#text("(Backwards induction) To show that a property ")#mi("P(n)")#text(" holds for all numbers ")#mi("1 \\leq n \\leq N")#text(", first show that it is preserved under decrementation (if ")#mi("P(n)")#text(" holds for ")#mi("1 < n \\leq N")#text(", then ")#mi("P(n-1)")#text(" holds), then check the base case ")#mi("P(N)")#text(" arising from the generator ")#mi("n=N")#text(".")],
[#text("(Strong induction) To show that a property ")#mi("P(n)")#text(" holds for all natural numbers ")#mi("n")#text(", show that it is preserved under least strict upper bounds (if ")#mi("P(n)")#text(" holds for all ")#mi("n<n_0")#text(", then ")#mi("P(n_0)")#text(" holds). In this case an empty set of generators suffices, so one can omit the base case step. (This also works more generally if the natural numbers are replaced by a well-ordered set.)")],
[#text("(Transfinite induction) To show that a property ")#mi("P(\\alpha)")#text(" holds for all ")#mi("\\alpha")#text(" in a well-ordered set, show that it is preserved under least upper bounds and incrementation, and verify the base case.")],
[#text("(Continuous induction) To show that a property ")#mi("P(x)")#text(" holds for all ")#mi("x")#text(" in a metric space, show that the property is preserved under limits (if ")#mi("x_n \\to x")#text(" and ")#mi("P(x_n)")#text(" holds, then ")#mi("P(x)")#text(" holds), is open (if ")#mi("P(x)")#text(" holds, then ")#mi("P(y)")#text(" holds for all ")#mi("y")#text(" sufficiently close to ")#mi("x")#text("), and verify a base case ")#mi("P(x_0)")#text(" for at least one point ")#mi("x_0 \\in X")#text(". (Continuous induction also works in more general topological spaces than metric spaces, though if the space is not first countable one may need to work with limits of nets instead of limits of sequences.)")],
[#text("(Dense subclass argument) To show that a property ")#mi("P(x)")#text(" holds for all ")#mi("x")#text(" in a topological space ")#mi("X")#text(", show that it is preserved under limits, then check it for a dense subclass. (This argument is also known as the “density argument” or “limiting argument”.) Again, for spaces that are not first countable, one has to work with limits of nets rather than limits of sequences.")],
[#text("(Linear algebra generation) To show that a property ")#mi("P(v)")#text(" holds for all vectors ")#mi("v")#text(" in a vector space ")#mi("V")#text(", show that the property is preserved under linear combinations (thus if ")#mi("P(v), P(w)")#text(" hold, then ")#mi("P(v+w)")#text(" holds, as well as ")#mi("P(cv)")#text(" for any scalar ")#mi("v")#text("), and also verify ")#mi("P(v)")#text(" for an algebraic basis (or ")#link("https://en.wikipedia.org/wiki/Basis_(linear_algebra)")[#text("Hamel basis")]#text(") of ")#mi("V")#text(". This sort of argument can also be adapted to other bases of ")#mi("V")#text(" than Hamel bases, but then one often needs to also verify that the property ")#mi("P")#text(" is preserved under limits.")],
[#text("(Sigma algebra generation) To show that a property ")#mi("P(E)")#text(" holds for all ")#mi("E")#text(" in a ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal B}")#text(", show that the property is preserved under countable unions, countable intersections, and complements, and then verify ")#mi("P")#text(" for the empty set and for a generating set of the ")#mi("\\sigma")#text("-algebra (for instance, if ")#mi("{\\mathcal B}")#text(" is a Borel ")#mi("\\sigma")#text("-algebra, one can take open sets, closed sets, or compact sets as the generating sets; in some cases one can also take balls, cubes, or rectangles); see Remark 4 of ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/")[#text("Notes 3")]#text(". One can relax the set of properties required, for instance countable intersections is redundant by de Morgan’s laws if one already has countable unions and complements, and by ")#link("https://en.wikipedia.org/wiki/Monotone_class_theorem")[#text("the monotone class lemma")]#text(" one only has to verify monotone countable intersections and unions (and drop complements) if the generating set is already a Boolean algebra. (In probability theory, the ")#link("https://en.wikipedia.org/wiki/Dynkin_system")[#mi("\\pi-\\lambda")#text(" theorem of Dynkin")]#text(" plays a similar role to the monotone class lemma.)")],
[#text("(Convex generation) To show that a property ")#mi("P(v)")#text(" holds for all ")#mi("v")#text(" in a finite-dimensional compact convex set ")#mi("K")#text(", show that it holds for convex linear combinations, then test it on all extreme points. The same argument also works for infinite dimensions if one allows for convex integrals rather than convex combinations, thanks to ")#link("https://en.wikipedia.org/wiki/Choquet_theory")[#text("Choquet’s theorem")]#text("; alternatively, by the ")#link("https://en.wikipedia.org/wiki/Choquet_theory")[#text("Krein-Milman theorem")]#text(", one can keep working with finite convex combinations as long the property is closed under limits.")],
[#text("(Stone-Weierstrass generation) To show that a property ")#mi("P(f)")#text(" holds for all continuous functions ")#mi("f")#text(" on a compact space ")#mi("X")#text(", show that the property is closed under algebraic operations (linear operations, pointwise multiplication, and also complex conjugation, if one is working with complex-valued functions), and also is true for a class of functions that is large enough to separate points in the space, so that the ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("Stone-Weierstrass theorem")]#text(" may be applied.")],
[#text("(Symmetry reduction) To show that a property ")#mi("P(x)")#text(" holds for all ")#mi("x")#text(" in a space ")#mi("X")#text(", which has a group ")#mi("G")#text(" acting on it, it suffices to show that the property ")#mi("P")#text(" is invariant under the group action (if ")#mi("P(x)")#text(" is true, then ")#mi("P(gx)")#text(" is true for any ")#mi("g \\in G")#text(", and then verify ")#mi("P")#text(" for one representative from each orbit of ")#mi("G")#text(". (This reduction overlaps significantly with Trick 19.)")]
)

#text("One caveat with applying these sorts of reductions: it is necessary that the predicate ")#mi("P()")#text(" be precisely defined to avoid ")#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/")[#text("vagueness paradoxes")]#text(". In particular, the predicate ")#mi("P()")#text(" should not involve asymptotic notation such as ")#mi("O()")#text(" or ")#mi("o()")#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (55)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b38832afbcc862fd0bb5be1b8b7393242c7e29467eb2a1b37304c068219caac-09e62b78107dcc84f9eb792d558b4706461c94c43a66b54e92df9d193513155b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tksm")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-47772")[#strong[#text("tksm")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2010")])]

#text("Another trick: see whether it is possible to extend a given function to a larger domain in order to access more tools. For example, a continuous function defined on an open interval may extend continuously to the closed interval, a smooth real function may extend to a complex analytic function.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d54d0c1552e59adb873e0aab9717b27e64529c2da8e2168a40cc2c5b8cb17aa-d6376878e1df40b9e30afb9e185a37be1022eac9157e337ffd86d92fc463ba37.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TK")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-47774")[#strong[#text("TK")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2010")])]

#text("I am new in research field. This is one of the most useful and appropriate article that i have read till date. Thanking you for posting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee1fa0dc5739bc24e4d6b4ef13aa793365979ae308a2e8401bf8440bd337f878-13cc6a689aaade70f2832eba03554079c456fa07a09b2f8fd06fb5b618718cd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gerard")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-47775")[#strong[#text("Gerard")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2010")])]

#text("Although “How to solve it” is a good reading about the philosophy and general procedures of problem’ solving, it’s conforting to see the common tricks made explicit. Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ec4fe8892e3e4624b279bfb3b81bdb57efd14820cd181c6b7e6055af65de2ec6-7252a550d886634e564dc7d09cdef84eedcd1e2e15f34bfe470a3c289ce9783b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Colin McQuillan")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-47776")[#strong[#text("Colin McQuillan")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2010")])]

#text("To show inequalities between norms, scaling to 1 helps with the algebra. For example in exercise 11 of")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/")[#text("245C, Notes 1: Interpolation of L^p spaces")]
]

#linebreak()#text(" to show that the bounds C and C’ are equivalent up to a multiplicative constant, scale C to 1 and bound C’, and vice versa.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lei")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-47777")[#strong[#text("Lei")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2010")])]

#text("I think the Remark 4 in notes 3 is also a very useful trick.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1cafcc314165c5a834383e1d42c9a9b53fdcf616d922233552170103b7e14bf3-7cf89bcbe232842e6fbdf54a84ab456cb4a161e814e82114b5e9c02c71692294.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thanks!")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-47779")[#strong[#text("Thanks!")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2010")])]

#text("I’m not in your class (unfortunately) but your post helped me a lot in my class!…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f361a04950475a41037ec565251c0e2c3286072d70467ca68caf07545c2a4334-83f82a5769ac964a883555046c8486b4350c09066749cf7b896745022888e9bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cy")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-47782")[#strong[#text("cy")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2010")])]

#text("Dear Prof Tao,")

#text("This is a great post to help students (like me) who are struggling with graduate analysis.")

#text("Do you have any advice to tackle problems of the type: Prove or disprove the following statements … So instead of attacking these problems directly, we have to think twice whether we are heading in the right direction. And usually it’s hard to think of suitable counterexamples during exams!")

#text("Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-47789")[#strong[#text("Top Posts — WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2010")]

#text("[…] 245A: Problem solving strategies This is going to be a somewhat experimental post. In class, I mentioned that when solving the type of homework problems […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6a6d7bfaab15d364e5b49865f28111b03bffa68435b4bdfcda74c51b42070a12-acae0d9c2b0ceb8fc191ea449781973da58d9d8338a5b301c554d0aca602f46e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-47803")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2010")])]

#text("Here are some more basic points that I remember being useful, related to yours:")

#text("Suppose you have some quantity ")#mi("F")#text(" which you are trying to bound by ")#mi("\\epsilon")#text(", as in strategy ")#mi("2")#text(". Suppose ")#mi("F")#text(" depends on several parameters: maybe there is a grid spacing ")#mi("a")#text(" which is going to zero and a length of some sequence ")#mi("n")#text(" which is going to infinity. The hard way to do this is to start out your proof: “Let ")#mi("a \\leq \\epsilon^2/100")#text(" and ")#mi("n \\geq 100^{1/\\epsilon}")#text(" …” The easy way is to start out with “Let ")#mi("a \\leq  \\delta")#text(" and ")#mi("n \\geq N")#text(".” Run the whole proof and get a bound for ")#mi("F")#text(" in terms of ")#mi("\\delta")#text(" and ")#mi("N")#text("; maybe something like ")#mi("\\delta^{1/2} + 1/\\log N")#text(". Only once you have those bounds, do you go back and figure out how small to take ")#mi("\\delta")#text(" and how large to take ")#mi("N")#text(" in terms of ")#mi("\\epsilon")#text(".")

#text("Regarding Terry’s advice: “A common mistake is to try to draw a picture in which both the hypotheses and conclusion of the problem hold.” I would say that this holds in every field of math. The attempt to build a counter-example is much more informative than the attempt to find an example. I like to take my statement and strip out all implications using the equivalence of “p implies q” and “not(p) or q”. So what I am trying to prove is simply “A or B or C or D”. Then a counterexample is “not(A) and not(B) and not(C) and not(D)”, and I can search for a counterexample without being biased as to which parts of the result to focus on.")

#text("Regarding 12: In analysis, you’ll learn lots of subtle results about when sums and integrals can be exchanged. The one that I have found most useful is “If your sum/integral is absolutely convergent, anything goes.” I am willing to sacrifice a lot in an analysis problem in order to work with an absolutely convergent summand/integrand, so that I can apply Terry’s advice 12 without worrying.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc9472e1d3156985323227bf90aed5111e2fec205d078b957077a71621e2d1e1-66b359ebb9e6fb23aca701266624e3f3bf1bea479e4375195819c692d4bfce7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of V.L.")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-47819")[#strong[#text("V.L.")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2010")])]

#text("A trick for proving things about Borel sets: if one wants to prove that the Borel sets have a certain property, one can prove that the collection of all sets that have that property is a sigma algebra that contains the open sets (or closed sets or intervals). Since the Borel sets are the smallest such sigma algebra, they must be contained in this collection. This avoids having to make arguments that use the way in which the Borel sets are generated.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b5e8b767c54854c71db2fcfcc5346fb8cbd066ba4e99aee473f1ef4419a3510-6dc981e01a3082a27ac0d4950e1e8cad3dd0ef0be5259ea79f9df5fb886dff7f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-47856")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2010")])]

#text("All these fall under the general philosophy ( I think I first saw it in Polya’s How to Solve it):")#linebreak()#text(" If you cannot solve a problem, find an easier one that you still cannot solve.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e8229618f8d5758a56027403331ee36b034edf0c03c9832ba4263167e3c2e59-f9b2278d80386c4ace80e5ebbf75df07cf05c03da8919722fe959b2cb062df4d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of edenh")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-47863")[#strong[#text("edenh")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2010")])]

#text("“Or: if one wishes to show that two functions f, g agree almost everywhere, try showing first that |f(x)-g(x)| \\leq \\varepsilon holds for almost every x.”")

#text("Is it obvious that this second condition implies the first?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-47868")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2010")])]

#text("By the Archimedean principle, the set ")#mi("\\{ x: f(x) \\neq g(x) \\}")#text(" is the union of the sets ")#tao-math("\\{ x: \\left|f(x)-g(x)\\right| > 1/n \\}", block: false)#text(" for all ")#mi("n=1,2,\\ldots")#text(". Thus, if all the latter sets have measure zero, the former set does also.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-47866")[#strong[#text("Linkage « An Ergodic Walk")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2010")]

#text("[…] October 26, 2010 Linkage Posted by Anand Sarwate under Uncategorized | Tags: mathematics, news, politics | Leave a Comment Terry Tao gives general tips on solving analysis problems. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/facbf5ac02324683fd960640ee2b89f4d7be25f85729cdc740ca5342700df8e4-4d5c663e4600ef79af845532158b1531aee63784c0a0f8307f08292d761d3b37.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AH")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-47995")[#strong[#text("AH")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2010")])]

#text("Thanks for this very helpful post!")

#text("The first display of item 18 contains a slight typo: the subscript on the liminf should be {n \\to \\infty}, not {n \\to infty}.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d51de496d939dce5862b7783f5167316bed951f68489ae467158d8d5edc2d74c-3d53c1546211099f925de3513d418a97f82f86daa632d2dd74e25457a63b74b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of -IamLittle-")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-48141")[#strong[#text("-IamLittle-")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2010")])]

#text("Dr Tao, is it good to learn some tricks to solve mathematic problems?")#linebreak()#text(" I am not used to learning tricks, I always solve problems without seeing any examples, tricks, etc. I know it wastes my time, so I would like to ask for your suggestion")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-48160")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2010")])]

#text("In the first paragraph fir trick 2 shouldn’t it be for ‘some’ ")#mi("\\epsilon")#text(" instead of for ‘any’ ")#mi("\\epsilon")#text("? ")#emph[#text("[No – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-48164")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2010")])]

#text("Could you please explain? (Sorry to bother with such a basic question but I am not a mathematician) As I see it if some quantity ")#mi("X \\leq Y")#text(" then ")#mi("\\exists \\epsilon  X \\leq Y + \\epsilon")#text(".")#linebreak()#text(" Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-48165")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2010")])]

#text("The issue is the reverse implication. ")#mi("\\exists \\epsilon > 0: X \\leq Y+\\epsilon")#text(" does not imply ")#mi("X \\leq Y")#text(", but ")#mi("\\forall \\epsilon > 0: X \\leq Y+\\epsilon")#text(" does.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-520609")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2019")])]

#text("I’m no mathematician but why is there a ‘0’ in ")#mi("[X")#text("/leq$ Y+/epsilon]$ I didn’t understand it .")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b71017f3ba0f543c5044556f27512e72972ffa9e69a8bf9184eadd8f7695b8bf-bea05fabd012afb0eff4e8714fccbbf0a0ed5d4690e1d374727fd01c1f9ac003.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MikeR")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-520691")[#strong[#text("MikeR")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2019")])]

#text("Quantifiers [there exists] and [for all] have very different meanings.")#linebreak()#text(" “There exists a pitch that I will hit for a home run” is different from “for all pitches I will hit a home run.”")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-48840")[#strong[#text("Universality and Characteristic Polynomials « Graduated Understanding")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2010")]

#text("[…] you feel are irrelevant to the current problem. Terry tao discusses a similar trick in analysis (trick 10) in his “problem solving strategies,” […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b65250bb5838c66ca74ae006e465d2c97993d53ae65a1872331c95224125dbc-f63b062d12effd708db263692f4c9be00d3d9dc57248c9b85c47ece75e841b1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of science and math")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-49343")[#strong[#text("science and math")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2011")])]

#text("Nice tips.")#linebreak()#text(" Thanks for sharing the tips with us.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-49388")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2011")])]

#text("When you call “Give yourself an epsilon of room” a standard trick, do you mean it is the ONLY way to handle such kind of problems? I was wondering whether it is right to say that most of the problems in analysis is about dealing with “epsilon”. (maybe according to Halmos’s experiences?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-52157")[#strong[#text("Some outside help… | Analysis Quals")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2011")]

#text("[…] Posted on May 1, 2011 by eekelly2388 Jeremy just sent me this link to Terry Tao’s blog about common problem solving strategies for analysis. I can especially relate to number 9, try simpler cases first. Also, number 15 is a great trick; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9a11c0014d2c35e5c8a89348bf93fd28af3d5469aa71e985c4e302e83e5a111-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Parth Kohli")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-211280")[#strong[#text("Parth Kohli")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2012")])]

#text("Prof. Terrence, please let me point out a mistake.")

#text("“In a similar spirit, to show that two sets E and F are equal, try proving that and $E \\subset B$ and $B \\subset E$.”")

#text("I believe that it’d be the following instead:")

#text("“In a similar spirit, to show that two sets E and F are equal, try proving that $E \\subseteq B$ and $B \\subseteq E$.")

#text("Regards.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dfc8618c80181dd8283bbb7715dcc86242d27331509305d79a1325eeeee3376f-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Parth Kohli")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-211281")[#strong[#text("Parth Kohli")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2012")])]

#text("Sorry, I do not know how to render MathJax here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b21893d260b389bf2c97acb1fb0707153f81dfe54c52cf09f26a21142ca60a38-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Clark Zinzow")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-218141")[#strong[#text("Clark Zinzow")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2013")])]

#text("Although I am not fluent in MathJax, I do not think that your correction is correct. His use of the normal subset is correct, since it is stating that E is a proper subset of F or E is equal to F, and vice versa, allowing for the potential of equality. Whereas your notation (assuming that “\\subseteq” is referring to the subset symbol with a horizontal line underneath it) refers to a proper subset exclusively, therefore not allowing for the potential of equality since E being a proper subset of F implies that there exists some element in F such that the same element is not in E, and vice versa.")

#text("Please let me know if I misunderstood! I know that some mathematicians occasionally use the proper subset symbol to mean “a subset of or equal to”, much to the chagrin of those raised by baby and/or adolescent Rudin (the text, not the man).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f2dc7f9e8f81556fb228b72d47410c515d892c5dc5c36f2c6918654592b6b52-7fd0e2a4848626a48dcf528bc401a8711b43901f65580490d9f159b37ba106e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spencer")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-370738")[#strong[#text("Spencer")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2014")])]

#text("In my experience the symbol for a proper subset is $\\subset$. See for instance: ")#link("http://mathworld.wolfram.com/Subset.html")[#text("http://mathworld.wolfram.com/Subset.html")]#text(" .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60d1f04bf6a2dc65035138164e59855890ef007daa8e570af472f1e6101a5cc2-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Clark Zinzow")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-456311")[#strong[#text("Clark Zinzow")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2015")])]

#text("Oh man I forgot about this post. My professor used what is widely considered incorrect notation, with subset being $\\subset$ and proper subset being $\\subseteq$, which is quite a terrible convention to use. I didn’t realize that this was incorrect until I took a topology class the next semester. Thanks for correcting me, I wouldn’t want to plant that incorrect seed into anyone else’s brain!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-359141")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2014")])]

#text("Would it be much more useful that if this list contains concrete examples (proofs/problems) that illustrate each strategy?")

#emph[#text("[The book version of this post at ")#link("https://terrytao.wordpress.com/books/an-introduction-to-measure-theory/")[#text("https://terrytao.wordpress.com/books/an-introduction-to-measure-theory/")]#text(" contains links to such examples in other sections of the book. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-451585")[#strong[#text("Career Advice by Prof Terence Tao, Mozart of Mathematics | MScMathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2015")]

#text("[…] See also Eric Schechter’s “Common errors in undergraduate mathematics“. I also have a post on problem solving strategies in real analysis. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-457167")[#strong[#text("译：解决数学问题 by 陶哲轩 | 万里风云")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2015")]

#text("[…] 请读Eric Schechter’s的《本科数学学习的常见错误》。除此，我也发表过一篇关于实分析解题策略的博客。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-470745")[#strong[#text("Solving mathematical problems | nguyen Huynh Huy's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2016")]

#text("[…] See also Eric Schechter’s “Common errors in undergraduate mathematics“. I also have a post on problem solving strategies in real analysis. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-509836")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#text("Here is a simple example for exploiting symmetries to make proofs go simpler: when a weak inequality ")#mi("m\\{Af > \\lambda \\} \\le \\frac{c}{\\lambda} \\int f")#text(" is to be proved for a homogeneous operator ")#mi("A")#text(", one can assume that ")#mi("\\lambda = 1")#text(". All books I have seen don’t make this observation and carry the ")#mi("\\lambda")#text(" around throughout the proof. The same happens when discussing the Calderón-Zygmund decomposition. For example, keeping ")#mi("\\lambda")#text(" around, the estimates ")#tao-math("m\\{Af > \\lambda \\}\\le \\frac{1}{\\lambda^2} \\int (Af)^2\\le \\frac{c}{\\lambda^2} \\int f^2 \\le \\frac{c}{\\lambda} \\int \\left|f\\right|", block: false)#text(", valid for ")#tao-math("\\left|f\\right|\\le \\lambda", block: false)#text(", looks lucky, while with ")#mi("\\lambda=1")#text(" it looks like business as usual, since “of course” ")#tao-math("\\int f^2 \\le \\int \\left|f\\right|", block: false)#text(" for ")#tao-math("\\left|f\\right|\\le 1", block: false)#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-509866")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#text("This is a great example! I used to agree with you on immediately spending the homogeneity symmetry to normalise ")#mi("\\lambda=1")#text(", but my thoughts on this are mixed now. Certainly it does simplify the calculations as you say. But once one spends the symmetry to buy the normalisation, one can’t spend it again to achieve any other normalisation (for instance, one might wish to normalise instead ")#tao-math("\\int \\left|f\\right| = 1", block: false)#text("), unless one undoes the normalisation to return to a homogeneous statement. If the normalisation is not immediately needed to achieve a simplification, it may actually be better to save the symmetry in reserve, though perhaps noting near the beginning of the argument that the reader could, if he or she wished, spend the symmetry right away to buy a normalisation.")

#text("A related point (which Jim Colliander shared with me some years ago) is that sometimes seemingly disposable parameters such as ")#mi("\\lambda")#text(" can be useful markers of information. For instance consider the Navier-Stokes equations ")#mi("\\partial_t u + (u \\cdot \\nabla) u = \\nu \\Delta u - \\nabla p; \\quad \\nabla \\cdot u = 0")#text(", where ")#mi("\\nu > 0")#text(" is a constant viscosity. It is a common practice to spend a homogeneity symmetry to normalise ")#mi("\\nu=1")#text(", which certainly does clean up many calculations a little bit. But if one instead retains ")#mi("\\nu")#text(" when doing, say, an energy estimate, one can see quite visibly what terms in the estimate are “viscosity terms” and which ones have nothing to do with viscosity, merely by the presence of ")#mi("\\nu")#text(" factors. Also, the presence of positive or negative powers of ")#mi("\\nu")#text(" in a term conveys a lot of information about what happens to that term in the inviscid limit ")#mi("\\nu \\to 0")#text(". (One can think of these factors as being analogous to the dimensional units of physics such as length, mass, and time; . Indeed, much as dimensional analysis can be used to detect an incorrect physical calculation, retaining parameters such as ")#mi("\\lambda")#text(" and ")#mi("\\nu")#text(" can also help guard against error, since if an equation or inequality suddenly stops being “lucky” in that the exponents of these parameters are no longer canceling out as expected, this immediately signals that a mistake has been made near this point.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-511151")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2019")])]

#emph[#text("… but if one observes that the expression")#linebreak()#text(" ")#mi("x := \\pi i\\lambda^{-1}\\langle T^{-1}\\xi,\\xi\\rangle")#text(" is common to both sides")#linebreak()#text(" ")]

#text("Since ")#mi("e^{ix}")#text(" is used later, I think there is a redundant ")#mi("i")#text(" in the definition above.")

#emph[#text("[Corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-511381")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2019")])]

#text("I’ve recently extended this list of problem solving strategies by adding two or three more tricks, some of which were based on previous suggestions in the comments.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f31626be2c68a252f3ba238a6f2ff016e7456e629702d5c6b6ac3b865931458b-4faed017e5d93571c12af2483c04b4be54595aab7ed82998f4db36dde10484ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Wright")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-520335")[#strong[#text("James Wright")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2019")])]

#text("Reblogged this on ")#link("https://numberery.wordpress.com/2019/08/26/245a-problem-solving-strategies/")[#text(">Numberery_")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-633490")[#strong[#text("Resumen de lecturas compartidas durante agosto de 2020 | Vestigium")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2021")]

#text("[…] Problem solving strategies. ~ Terence Tao (2010). #Math […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-640961")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2022")])]

#text("Most of the above strategies are for simplifying the mathematical structure of the problem by reducing its complexity (wrt some standard complexity measures)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dd8d1d90343ef0d9a57e051b72b88d2de782cd809dac95bb2dbf1614a2a56642-91cf450563022cceb09332b8020a4b26ff66f7804c9d6f16073e8b9358a278d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor Porton")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-641024")[#strong[#text("Victor Porton")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2022")])]

#text("Won’t it be counted as spam if I share my real real analysis problem? This problem is specifically interesting, because it is 1. open-ended; 2. but I tried to formalize it; 3. uses mix of both non-standard and standard analysis (limit on a filter); 4. because of being a mix, calls to reformulate itself better. Solving this problem will help me to become rich and famous and so have money and media links to spread scientific research.")

#text("From ")#link("https://math.stackexchange.com/q/4394253/4876")[#text("https://math.stackexchange.com/q/4394253/4876")]

#text("There are ")#mi("N")#text(" nodes, each has response time ")#mi("t_i")#text(" (here and further I use ")#mi("i")#text(" as an index).")

#text("I want probabilistically choose a node with low response time; if there are several nodes with low response time, alternate between them.")

#text("The first idea that came to my mind was to make probability of chosing ")#mi("i")#text("-th node proportional to ")#mi("1/t_i^2")#text(". But it is not a solution, because if there are many nodes with high response times, then may overweight few good (with low response times) nodes, so that with a big probability there will be selected a bad node.")

#text("Formally (using both non-standard analysis and limit on a filter):")

#text("I define ")#mi("p_i")#text(" as a decreasing in each argument positive-valued continuous function of positive numbers ")#mi("t_i")#text(" as follows: There are ")#mi("N")#text(" numbers ")#mi("t_i")#text(". I denote ")#mi("p_i")#text(" the (the sought for) (standard) probability of the node (that is ")#mi("p_i")#text(" is a function of ")#mi("t_i")#text(" and ")#mi("\\sum p_i=1")#text(").")

#text("Let extend the above function ")#mi("p_i")#text(" of ")#mi("t_i")#text(" by making ")#mi("t_i")#text(" to be non-standard (positive) reals in such a way that ")#mi("M")#text(" of them a “good” (infinitely smaller than the rest) and not infinitely bigger than each other.")

#text("Let ")#mi("N\\to +\\infty")#text(" by adding more “not good” nodes. Find a function of ")#mi("p_i")#text(" from ")#mi("t_i")#text(" such that we can warrant that even when ")#mi("N\\to +\\infty")#text(" (with the restriction that we don’t change existing nodes and add only bad nodes) we have ")#mi("\\sum_{i\\in M} p_i \\approx 1")#text(" and each ")#mi("p_i\\not\\approx 0")#text(".")

#text("Help to find such a function of ")#mi("p_i")#text(" from ")#mi("t_i")#text(".")

#text("Also, I used both non-standard analysis and limit. Isn’t it a poor way to formulate things? How to formulate the problem better (concisely and clearly)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-660045")[#strong[#text("Solving Problems - My Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2022")]

#text("[…] Problem solving strategies in a graduate real analysis course (2010) (HN) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bounding sums or integrals of non-negative quantities | What's new")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-681883")[#strong[#text("Bounding sums or integrals of non-negative quantities | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2023")])]

#text("[…] in the spirit of this previous post on analysis problem solving strategies, I am going to try here to collect some general principles and techniques that I have found useful […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-681981")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2023")])]

#text("Thanks for this blog")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-689142")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2025")])]

#text("Prof. Tao,")

#text("In Trick 10 you said “is clear what to do: use Taylor’s theorem with remainder”. Forgive my ignorance, Taylor’s theorem comes up repeatedly in analysis, but I never know when to use it. Coud you please tell me when to use it in practice?")

#text("Also, what do you mean by “rough” and “smooth” objects in Trick 3? In my mind, “smoothness” means you can take the derivatives infinitly many times.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-689144")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2025")])]

#text("Basically, if you would prefer to work with an explicit polynomial or linear function in place of a more general nonlinear function, and one also knows that the input variable is close to a particular location, then Taylor approximation around that location may be a viable tool. For instance, if one is working with an expression of the form ")#mi("e^x")#text(", and one also knows that ")#mi("x")#text(" is small (near ")#mi("0")#text("), then one of the Taylor approximations ")#mi("e^x = O(1)")#text(", ")#tao-math("e^x = 1 + O(\\left|x\\right|)", block: false)#text(", ")#tao-math("e^x = 1 + x + O(\\left|x\\right|^2)", block: false)#text(", ")#tao-math("e^x = 1 + x + x^2/2 + O(\\left|x\\right|^3)", block: false)#text(", etc. may be useful. The choice of which approximation to use often requires some trial and error, as well as some awareness of what the “error budget” in one’s argument is: if for instance, you think you can tolerate losses of ")#tao-math("O(\\left|x\\right|^2)", block: false)#text(" in the argument, but not losses of ")#tao-math("O(\\left|x\\right|)", block: false)#text(", then the second Taylor expansion ")#tao-math("e^x = 1 + x + O(\\left|x\\right|^2)", block: false)#text(" would be indicated for use here.")

#text("Terms such as “rough” and “smooth” are deliberately left vague to make the trick as broadly applicable as possible. In some cases, “smooth” here can indeed mean infinite differentiability, but on other context other notions of “regularity”, such as continuity, differentiability, absolute continuity, analyticity, polynomiality, piecewise smoothness, etc., could be used. Often the first step is to identify what property of a given function would actually be *useful* for one’s application. For instance, if you think you may need integration by parts, then perhaps continuous differentiability could be a useful property to acquire, since many rigorous integration by parts lemmas require a hypothesis such as this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fef06046c3e3f2eb0c11c98a8c4a11ed84b25ccbc023d13f15062e426e1fdf3a-366938429a206590b60f422cbbb17608d068f86905fb2652141d3f9024626ae7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of elias lam")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-689173")[#strong[#text("elias lam")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2025")])]

#text("Thank you for your reply! But there’s other stuffs bothering me: for the remainders part, what’s the difference between distinct remainders? Specifically, when encountering words like “using Taylor’s Theorem with remainder” (like your hints of exercises in this measure theory book), there’s various forms like the integral form, the Lagrange form, the Peano form, and so forth, so generally speaking—— what are the strategies of specifying when to use the appropriate form?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-689183")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2025")])]

#text("This is generally not too important (see Strategy 15 and Strategy 16). It is usually the order of the approximation error – e.g., whether it is linear ")#mi("O(\\varepsilon)")#text(", quadratic ")#mi("O(\\varepsilon^2)")#text(", etc. – which is the most significant; the precise choice of Taylor approximation to use may have some impact on the implied constant in the ")#mi("O()")#text(" notation, but for many applications it is not necessary to know the value of this constant.")

#text("It can be common with beginners to experience an “")#link("https://en.wikipedia.org/wiki/Analysis_paralysis")[#text("analysis paralysis")]#text("” when faced with a problem for which multiple options are available for solving the problem, with the result being that ")#emph[#text("none")]#text(" of the possible options are attempted. This is obviously an inferior problem solving strategy. Rather than agonize over which option is the “right” one, one should simply select the best initial guess one has, work with that, and see what happens. Most likely – especially for beginners – there will be some flaw in this choice that will make the attempted solution fail at some stage; nevertheless, such failures are ")#emph[#text("extremely")]#text(" helpful in moving the problem solving process forwards, as they often reveal important clues as to how to refine the initial attempt into a better partial solution, and eventually to a complete solution of the problem. See also ")#link("https://terrytao.wordpress.com/career-advice/on-the-importance-of-partial-progress/")[#text("https://terrytao.wordpress.com/career-advice/on-the-importance-of-partial-progress/")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fef06046c3e3f2eb0c11c98a8c4a11ed84b25ccbc023d13f15062e426e1fdf3a-366938429a206590b60f422cbbb17608d068f86905fb2652141d3f9024626ae7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of elias lam")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-689184")[#strong[#text("elias lam")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2025")])]

#text("Prof. Tao,")#linebreak()#text(" Thank you for patience! It is true that I am experiencing the state “analysis paralysis”. I worry too much on things that don’t reallly matter. Now I know what to do, get my hands dirty, even though this would lead to partial failure which is actually more important than “analysis paralysis”.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb8ee9d503e8392f2d77cfa96588986c2db619a92d07c2b64590f2ee8362a8fc-b9d213494ef42a25a8ee2716435fd4d650b3b7887f12cc3d387678d0c9ac3239.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sinai Coons")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-689209")[#strong[#text("Sinai Coons")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2025")])]

#text("Guess what I’ll be printing later today :)")#linebreak()#text("Thank you!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-689462")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2025")])]

#text("Dr Tao,")

#text("In exercise 16, “afactor” means “a factor”, right?")

#emph[#text("[Corrected, thanks – T.]")]

#text("I am a undergrad learing linear algebra and abstract algebra, I notice that strategy 1, 9, 14, etc can be useful in algebra as well. I would like to ask: In the similar spirits, could you provide some additional problem solving strategies for linear algebra (or abstract algebra)?")

#text("Thanks in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-689485")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2025")])]

#text("Dr Tao,")

#text("I think trick 11 is the same as ε/2^n trick right? But I don’t know when should ones use this trick when doing exercises.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-689504")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2025")])]

#text("As stated in the text: ” one should be alert to this sort of trick when one has to spend an epsilon or so on an infinite number of objects”.")

#text("More generally, though, asking “when should I use this trick” is not really the right question. Problem solving is not about blindly memorizing tricks, or trying to apply them as mechanically as possible; one should internalize *why* the trick works in some cases, and not in others, which will end up giving a much deeper and more robust understanding of how the trick fits in with the rest of the subject than if one tries to memorize them without achieving such understanding. See also ")#link("https://terrytao.wordpress.com/career-advice/learn-the-limitations-of-your-tools/")[#text("https://terrytao.wordpress.com/career-advice/learn-the-limitations-of-your-tools/")]#text(" and ")#link("https://terrytao.wordpress.com/career-advice/learn-the-power-of-other-mathematicians-tools/")[#text("https://terrytao.wordpress.com/career-advice/learn-the-power-of-other-mathematicians-tools/")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/#comment-693195")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2026")])]

#text("Dr. Tao:")

#text("Are many “decomposition” techniques, such as splitting a function f into the difference of its positive part f₊ := max(f, 0) and negative part f₋ := max(-f, 0), or the Lebesgue decomposition, Jordan decomposition, and Hahn decomposition, all practical examples of the application of Strategy 3?")

#emph[#text("[Yes – T.]")]
]
