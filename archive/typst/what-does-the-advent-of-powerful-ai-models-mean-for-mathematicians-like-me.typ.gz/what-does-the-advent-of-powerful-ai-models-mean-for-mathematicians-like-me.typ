// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/03/what-does-the-advent-of-powerful-ai-models-mean-for-mathematicians-like-me/
// Converted to Typst by tao2typ: "2026-10-14T16:39:36.292921+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "What does the advent of powerful AI models mean for mathematicians like me?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("What does the advent of powerful AI models mean for mathematicians like me?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/03/what-does-the-advent-of-powerful-ai-models-mean-for-mathematicians-like-me/")[#text("https://terrytao.wordpress.com/2026/10/03/what-does-the-advent-of-powerful-ai-models-mean-for-mathematicians-like-me/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://tildesites.bowdoin.edu/~jtaback/")[#text("Jennifer Taback")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("Recently I have read a stream of articles questioning the future of mathematics: what constitutes a proof, what we value, how we retain the human enterprise of creating knowledge. Many of these articles are written by mathematicians making significant progress on the conjectures that shape their fields, whose work is now imperiled by the capabilities of frontier AI models. I am not one of those mathematicians. There are many mathematical problems that I have revisited over two decades, but none will grab headlines. Nevertheless, I care deeply about their resolution, as do others in my field. What does the advent of powerful AI models mean for mathematicians like me? I have yet to succeed in prompting a solution to one of my long-term problems, though AI models have helped fix an incorrect lemma and suggested a helpful reorganization of a paper. They have pointed me in directions in which I had not thought to look, and spurred me to learn new mathematics. Combining AI with the skills I have honed over the years is making me a stronger mathematician.")

#metadata(none) <tao-5142f7b7dc1279d948fa>

#text("Journals prohibit AI models as co-authors, but these models have proven to be effective partners for me. I teach at Bowdoin College, a selective liberal arts college in Brunswick, Maine. While I have many wonderful collaborators, none are local. At my college, I have no one down the hall with whom to discuss research questions; mathematics departments at small colleges rarely have two colleagues in the same specialty. AI fills this gap for me. I respond to its (not always correct) answers to my questions, and ask for clarification as I would from a human collaborator. AI makes me ask myself more probing questions, challenging me to dig deeper into my accumulated knowledge and connect it to the broad synthesis the model can often provide. And sometimes AI is just wrong or confusing, as a human might be, and I move on.")

#text("Mathematics is a human endeavor, and machine-generated output requires substantial human intervention in order to contribute to our knowledge base. Having co-organized two conferences on ")#link("https://sites.google.com/view/communicating-math/")[#text("“Communicating Mathematics,”")]#text(" I know that every idea that advances mathematics, whether human- or AI-inspired, requires clear exposition, a skill most of us could improve. AI is helping me here as well; it is making my mathematical writing better by catching small inconsistencies in papers I believed I had diligently proofread, and helping me sharpen my arguments. Our profession should embrace responsible use of these tools in the service of stronger communication.")

#text("AI has arrived in my classroom too, at an institution that demands pedagogical excellence and innovation alongside active research. I expect my classroom to change more in the next two years than it has in the previous twenty, in unknown and unexpected ways. I am angry at AI for forcing evaluation into the classroom under timed conditions. I do not perform my best under those circumstances and neither do my students; we have narrowed assessment to what we can proctor. Without graduate student assistance, thoughtful oral examinations, for example, are impractical at the scale of my teaching. Faculty at small colleges, even well-endowed ones, rarely have the graduate students and teaching assistants that make such solutions feasible.")

#text("Conversations addressing pedagogical changes resulting from widespread access to AI models are proliferating, but they are often convened at R1 institutions. These conversations must be broadened to include faculty from the entire spectrum of colleges and universities, especially those with higher teaching loads and more limited support. I am optimistic that by working across institutions we can strengthen undergraduate mathematics education. Students will influence this work as well; some of my undergraduates have been remarkably creative in their use of AI tools to further their understanding. One student in my cryptography class, for example, built an animation of a WWII-era encryption device that let viewers watch the mechanics and the mathematics unfold together. I have no overarching answers yet. But I want my students to trade their fear of being replaced by machines for the excitement of building what comes next.")

#text("I write this with the security of a tenured professor. In a small department where mentoring is a personal responsibility, I hear the visceral worries of my junior colleagues who are unsure of their path to tenure and beyond. Their position is genuinely different from mine, and their promotion equally weighs research and teaching. They are building a record under rules that do not yet exist.")

#text("Working toward new standards for the discipline is not an abstract matter. We have to decide what counts as proof, and what we value for publication and tenure. I would like us to disclose the tools we use for research without fear of judgment, while taking personal responsibility for ensuring that our work is rigorously verified, understood, and explained before we disseminate it. We should not abandon lines of inquiry for fear that AI will get there first; second proofs of theorems, whether by humans or by AI, often provide valuable insight into a problem. I do not want to surrender my questions, nor would I want my junior colleagues to cede theirs.")

#text("If we do things differently, adopt novel technologies, and investigate new frontiers of the discipline, we will still be producing mathematics. I love what I do, and I feel I am doing it better than ever. I will keep learning and seeking understanding while making the best use of the resources available to me. I do not know what mathematics will look like a decade from now. I know it will be created by people who have learned to ask insightful questions, and I know we are the ones who will teach them to do that, both in liberal arts classrooms and at research universities. Mathematicians will continue the hard work of discovery and understanding using stronger, and perhaps stranger, tools, pursuing problems yet to be posed.")

#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/03/what-does-the-advent-of-powerful-ai-models-mean-for-mathematicians-like-me/#comment-696738")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2026")])]

#text("I would not agree that an AI plagiarizing an Enigma or Lorentz machine simulator counts as creative. There are hundreds of those on the internet and the model was trained on them all.")

#text("I am deeply worried about a future in which this is encouraged at academia.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/03/what-does-the-advent-of-powerful-ai-models-mean-for-mathematicians-like-me/#comment-696754")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2026")])]

#text("I think a lot of tenured faculty has abandoned early career people by full embracing LLMs and not really caring if it hurts avenues which most of the early career people were trained from.")

#text("I am deeply disappointed in this article as well.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86bb9188ac23a1491b4919779559de8696b2c29c88138a83a495228b924d5ef3-14a7fcec09343d3faa3628b2cca92bebeca76faba6db33d9618c43813391cf28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dependableshark302f4dc264")]], [#link("https://terrytao.wordpress.com/2026/10/03/what-does-the-advent-of-powerful-ai-models-mean-for-mathematicians-like-me/#comment-696765")[#strong[#text("dependableshark302f4dc264")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2026")])]

#text("What do you think they should do to help?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/03/what-does-the-advent-of-powerful-ai-models-mean-for-mathematicians-like-me/#comment-696796")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2026")])]

#text("Reject AI, forbid AI usage among students. Organize a boykott of AI companies. Organize a month of no smart phone usage.")

#text("Especially the last measure will be understood very well in Silicon Valley.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/03/what-does-the-advent-of-powerful-ai-models-mean-for-mathematicians-like-me/#comment-696741")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2026")])]

#text("“Combining AI with the skills I have honed over the years is making me a stronger mathematician.“")

#text("Combining a crane with the skills I have honed over the years is making me a stronger deadlifter 💪")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/03/what-does-the-advent-of-powerful-ai-models-mean-for-mathematicians-like-me/#comment-696749")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2026")])]

#text("I guess one key difference here is that a mathematician is also duty bound to society, where someone is paying them to do math. On the other hand you are deadlifting purely for yourself most of the time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cfb52009fbb600752d2e6bbc58a89a3d6b7e9b3efb811c34ceb740c7bfb0334d-4f4d4879ad1f1c32620ac1763bc74225a06f39fb89de6e7bfd7174a9e03022a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ashot1955")]], [#link("https://terrytao.wordpress.com/2026/10/03/what-does-the-advent-of-powerful-ai-models-mean-for-mathematicians-like-me/#comment-696752")[#strong[#text("ashot1955")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2026")])]

#text("I hope you at least realize that your anonymity makes your opinion more than just unserious.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0407444868fc42987e0e767c3fa8c7571cd73af435533bcece7a36bd594b0514-2ae27efe97fcf1ece7ea67e36afa94eee62825664716dc4ee7cf030a881d77c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shannon7774")]], [#link("https://terrytao.wordpress.com/2026/10/03/what-does-the-advent-of-powerful-ai-models-mean-for-mathematicians-like-me/#comment-696774")[#strong[#text("shannon7774")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2026")])]

#text("David Gilmour said this in 1971: “I don’t think equipment could take over. We do rely on it a lot. I mean, we couldn’t do what we do as we do it without it. We could still do a good, entertaining, musical show, I suppose, without it. But all those things are down to how you control them and whether you’re controlling them, not the other way around.”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1644c7ada1fe9126712ff045feaa8f551fb55d85d7023f53c7d53b48d0c268d6-8bcc80eff677b687935f6f20ed89884887470a9adbe385af8acab1d6a2aee536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Satya")]], [#link("https://terrytao.wordpress.com/2026/10/03/what-does-the-advent-of-powerful-ai-models-mean-for-mathematicians-like-me/#comment-696743")[#strong[#text("Satya")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2026")])]

#text("AI in mathematics is here to stay and coexist. It is a new way to obtain information. There is no way to going back. This is how it is, irrespective of its consequences to the math profession.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/03/what-does-the-advent-of-powerful-ai-models-mean-for-mathematicians-like-me/#comment-696753")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2026")])]

#text("Why not push for the release of the math results the AI companies are holding on to? Holding on to the cures for cancers because some academic biologist wants to be the one to discover them, for example, would be insane.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/03/what-does-the-advent-of-powerful-ai-models-mean-for-mathematicians-like-me/#comment-696767")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2026")])]

#text("The purpose of proving new theorems and the purpose of finding new cures for diseases are fundamentally different. This analogy does not hold.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/03/what-does-the-advent-of-powerful-ai-models-mean-for-mathematicians-like-me/#comment-696800")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2026")])]

#text("Yet mathematicians are fond of reminding us that mathematics is the foundation of all science.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/03/what-does-the-advent-of-powerful-ai-models-mean-for-mathematicians-like-me/#comment-696755")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2026")])]

#text("This is a cool-headed analysis, although it won’t be popular in certain circles.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/03/what-does-the-advent-of-powerful-ai-models-mean-for-mathematicians-like-me/#comment-696759")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2026")])]

#text("I really do not understand why these models are thought powerful?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/03/what-does-the-advent-of-powerful-ai-models-mean-for-mathematicians-like-me/#comment-696761")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2026")])]

#text("Manually verifying math papers may soon not be feasible anymore. This means you have to create a standard for how many different types of AI verifications are necessary to accept a proof as valid.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1644c7ada1fe9126712ff045feaa8f551fb55d85d7023f53c7d53b48d0c268d6-8bcc80eff677b687935f6f20ed89884887470a9adbe385af8acab1d6a2aee536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Satya")]], [#link("https://terrytao.wordpress.com/2026/10/03/what-does-the-advent-of-powerful-ai-models-mean-for-mathematicians-like-me/#comment-696775")[#strong[#text("Satya")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2026")])]

#text("Even “manual reading” of math papers may become officially useless. AI will write papers and there will be AI-readership. Ha Ha!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0407444868fc42987e0e767c3fa8c7571cd73af435533bcece7a36bd594b0514-2ae27efe97fcf1ece7ea67e36afa94eee62825664716dc4ee7cf030a881d77c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shannon7774")]], [#link("https://terrytao.wordpress.com/2026/10/03/what-does-the-advent-of-powerful-ai-models-mean-for-mathematicians-like-me/#comment-696772")[#strong[#text("shannon7774")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2026")])]

#text("I am experimenting with allowing AI usage in my Inquiry Based Learning class. I prefer for the students to discover the proofs for themselves in conversations with each other or with me. But even if they get the answers from AI, they still have to answer all of the questions that come from the audience when they present their proofs. I think there are definite problems with this approach! But it is something to consider as we all perform the experiment of trying to navigate teaching in the era of AI.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ffe8360291eb70c6217ab0288815a09f44b5b42fc30f01d721d8383dbc22289a-41f2894e3fe01738144ab00a618e89fd1ca95a4d53292839c184eb1a49d934ff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kryptonitedevotedlyb5c9a7365e")]], [#link("https://terrytao.wordpress.com/2026/10/03/what-does-the-advent-of-powerful-ai-models-mean-for-mathematicians-like-me/#comment-696798")[#strong[#text("kryptonitedevotedlyb5c9a7365e")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2026")])]

#text("“We have to decide what counts as proof”")

#text("easy: actually formal *mechanically-checkable* proofs, as opposed to “social” informal natural language “proofs”")
]
