// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/
// Converted to Typst by tao2typ: "2026-10-14T15:20:07.401870+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "QED version 2.0: an interactive text in first-order logic", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("QED version 2.0: an interactive text in first-order logic")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 August 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/")[#text("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("As readers who have followed ")#link("https://terrytao.wordpress.com/2018/07/28/gamifying-propositional-logic-qed-an-interactive-textbook/")[#text("my previous post")]#text(" will know, I have been spending the last few weeks extending my previous ")#link("http://www.math.ucla.edu/~tao/QED/QED.html")[#text("interactive text on propositional logic")]#text(" (entitied “QED”) to also cover first-order logic. The text has now reached what ")#link("https://teorth.github.io/QED/")[#text("seems to be a stable form")]#text(", with a complete set of deductive rules for first-order logic with equality, and no major bugs as far as I can tell (apart from one weird visual bug I can’t eradicate, in that some graphics elements can occasionally temporarily disappear when one clicks on an item). So it will likely not change much going forward.")

#text("I feel though that there could be more that could be done with this sort of framework (e.g., improved GUI, modification to other logics, developing the ability to write one’s own texts and libraries, exploring mathematical theories such as Peano arithmetic, etc.). But writing this text (particularly the first-order logic sections) has brought me close to the limit of my programming ability, as the number of bugs introduced with each new feature implemented has begun to grow at an alarming rate. I would like to repackage the code so that it can be re-used by more adept programmers for further possible applications, though I have never done something like this before and would appreciate advice on how to do so. The code is ")#link("http://www.math.ucla.edu/~tao/QED/QED.html")[#text("already available")]#text(" under a Creative Commons licence, but I am not sure how readable and modifiable it will be to others currently. [")#emph[#text("Update")]#text(": it is ")#link("https://github.com/teorth/QED")[#text("now on GitHub")]#text(".]")

#text("[One thing I noticed is that I would probably have to make more of a decoupling between the GUI elements, the underlying logical elements, and the interactive text. For instance, at some point I made the decision (convenient at the time) to use some GUI elements to store some of the state variables of the text, e.g. the exercise buttons are currently storing the status of what exercises are unlocked or not. This is presumably not an example of good programming practice, though it would be relatively easy to fix. More seriously, due to my inability to come up with a good general-purpose matching algorithm (or even specification of such an algorithm) for the the laws of first-order logic, many of the laws have to be hard-coded into the matching routine, so one cannot currently remove them from the text. It may well be that the best thing to do in fact is to rework the entire codebase from scratch using more professional software design methods.]")

#text("[")#emph[#text("Update")]#text(", Aug 23: links moved to GitHub version.]")

#heading(level: 1)[#text("Comments (64)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b0209dbec40eee906a80df7c285c71a86039d8ae41876bb8b901711e2f5bbbd-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Francisco Javier Thayer")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504078")[#strong[#text("Francisco Javier Thayer")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2018")])]

#text("There are already a siizeable number of “Theorem provers” (or “proof checkers). Among these are HOL the Mizar system and Coq (which formalized a proof of the Thomson Feit Theorem). The field has been chugging along for about 40 years with many more systems, too many to be included here (including one which I was heavily involved in not mentioned.) The holy grail of the field is to come up w/ a system that can actually FIND proofs, and some do make considerable headway in that direction, such as HOL.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504133")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2018")])]

#text("This is a game that guides you to discover theorems, developing the subject from scratch as you go. It’s not just a proof checker.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ffe261bb04bb570c8e7e2fe38b420460ba6b804f6223f9f49b5b358fdcbc5cb-15d52da9ab4fdc1e4479bda86060f1f3961e61eb933d97a1387fb070b0a01f76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nisarg Kothari")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504096")[#strong[#text("Nisarg Kothari")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2018")])]

#text("I suggest you post the code to github.com, which is the de facto standard for open source code sharing and collaboration.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa110cd843baa2000ae418ed3de2ae68b28bc66ef4075ccbcac1820a765bc52e-85a2258f3dc17fc3c3f5478e04ec551c8963350f4e5cfb87059b48fab2cfb0f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cjerdonek")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504097")[#strong[#text("cjerdonek")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2018")])]

#text("Congrats on your efforts! As a software developer, the first thing I’d suggest is choosing an open source license rather than a CC license, as open source licenses are specifically designed for (and more appropriate for) code. You can’t really go wrong with something simple like MIT or BSD-3-Clause, unless you want a copyleft license like GPLv3. You can find a list with instructions here: ")#link("https://opensource.org/licenses/category")[#text("https://opensource.org/licenses/category")]

#text("And yes, I’d echo Nisarg’s comment to put your code on GitHub as the next step after that if you’d like to solicit help from other software engineers. That by itself will make it much easier for others to view, download, and offer you specific suggestions, etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa110cd843baa2000ae418ed3de2ae68b28bc66ef4075ccbcac1820a765bc52e-85a2258f3dc17fc3c3f5478e04ec551c8963350f4e5cfb87059b48fab2cfb0f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cjerdonek")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504098")[#strong[#text("cjerdonek")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2018")])]

#text("PS – you also want to be sure to include a copyright notice along with any license (as the instructions for adding a license should tell you). While it might seem pedantic, it’s good to do from the beginning so that subsequent sharing and collaboration can be on clear footing.")

#text("GitHub has good documentation for creating your first repository (including things like adding a README, which serves as the “title page” for your project, as well as adding a license file, etc):")#linebreak()#text(" ")#link("https://help.github.com/articles/creating-a-repository-on-github/")[#text("https://help.github.com/articles/creating-a-repository-on-github/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72789d03a67fbeab81ef3d17c0c0745c84a6e801efb0957f79431ed2aad8ce39-a74f271550fdfa5bed81dd507db77663cbf69c670e907b5517af6ae425b0fafd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dr anil pedgaonkar")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504100")[#strong[#text("dr anil pedgaonkar")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2018")])]

#text("congrats a great work! dr anil pedgaonkar")#linebreak()#text(" i would not accept zf system.")#linebreak()#text(" but would accept empty sewt and sets constructed from it using ZF axioms except the ac and the last axiom in book by marseden.")#linebreak()#text(" we define a swt is only the one which is constructed as above . so no abstract sets.. i would be happy if great terrance tao replies to my comment. mail ")#link("mailto:anilped@hotmail.com")[#text("anilped@hotmail.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504108")[#strong[#text("First order logic – The nth Root")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2018")]

#text("[…] As readers who have followed my previous post will know, I have been spending the last few weeks extending my previous interactive text on propositional logic (entitied “QED”) to also cover first-order logic. The text has now reached what seems to be a stable form, with a complete set of deductive rules for first-order logic with equality, and no major bugs as far as I can tell (apart from one weird visual bug I can’t eradicate, in that some graphics elements can occasionally temporarily disappear when one clicks on an item). So it will likely not change much going forward. … (Terence Tao) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e849ab7247da7cb2e6927388b372cce1205326393e1fb1eb551583320d072ab-d8680fa32203d1295288b1a51e8d651e5481ceb45bdb37688eff7078e5700806.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LSAT")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504119")[#strong[#text("LSAT")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2018")])]

#text("This is a great little app, but I would suggest some sort of help function or way to bypass questions if needed. No matter what I do, I cannot make 6.1(b) work. I think it’s more of a quirk with the app than my logic, but in either case I’m doing something that just won’t work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504132")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2018")])]

#text("By “not work”, do you mean that you were expecting the text to perform in a certain way and it wasn’t (i.e. a potential bug in the code), or that you weren’t able to work out the solution? In the latter case, the discussion provided below Exercise 6.1(b) indicates the general strategy one needs to solve this sort of problem (in which the desired conclusion is of the form “X IMPLIES Y”.")

#text("Also, solving Exercise 6.1(b) is not required in order to unlock later exercises (only the first exercise of a section needs to be solved in order to unlock the rest of the section, as well as the first exercise of the next section).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e849ab7247da7cb2e6927388b372cce1205326393e1fb1eb551583320d072ab-d8680fa32203d1295288b1a51e8d651e5481ceb45bdb37688eff7078e5700806.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LSAT")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504137")[#strong[#text("LSAT")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2018")])]

#text("Hello Dr. Tao, what I mean is that I find the instructions unclear. I can create the formula for A AND (A OR B), but everything I try after doesn’t seem to work. I note a comment above about Macs, which I use. I haven’t tried a browser other than Chrome, but I think it’s not the browser. I must simply not be using the app correctly.")

#text("I’d like to see the actual procedure (click this, drag that) for the problem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504139")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2018")])]

#text("If you have reached as far as 6.1(b), the law of implication introduction should be unlocked, so that when one clicks on the formula A AND (A OR B), the ability to deduce A AND (A OR B) (assuming A AND (A OR B)) should be available.")

#text("Sometimes with version updates, laws that were previously unlocked become locked again. This can usually be fixed by revisiting the exercise that unlocked the law (in this case, 4.1). The achievements window will tell you what laws are currently available. If all else fails one can reset the text.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/346a3e84faf02ec40592e9efb4c9c2718d5151590a4446fe7b9627a43d85eda7-7e6cdac14496a2ae8eeb38f96abd40e5e423b11861ef2b0251f1dc58053d5bb5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacob H.")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504127")[#strong[#text("Jacob H.")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2018")])]

#text("Hi Terry! You might consider adding event.metaKey to the event.ctrlKey-catching clickBox function in gui.js so that mac users can also multi-select items (change the line “if (event.ctrlKey)” to “if (event.ctrlKey || event.metaKey)”)")

#emph[#text("[Now implemented; thanks for the suggestion -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504143")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2018")])]

#text("This is really nice and useful. I would be happy to contribute.")

#text("Something I have done on a much smaller scale is embedded illustration such as ")#link("http://math.iisc.ac.in/~gadgil/MA261/notes/chapter-3.html#percolation")[#text("http://math.iisc.ac.in/~gadgil/MA261/notes/chapter-3.html#percolation")]#text("” in notes of Manjunath Krishnapur (converted from LaTeX), also in standalone form such as ")#link("http://math.iisc.ac.in/~gadgil/MA261/illustrations/birthdays.html")[#text("http://math.iisc.ac.in/~gadgil/MA261/illustrations/birthdays.html")]#text(" to be used in lectures.")

#text("I too would echo the suggestion to put the code on Github as suggested (or Gitlab, which has some advantages, including latex support)? It makes it easy not only to contribute, but to plan using issues etc.")

#text("The two quick changes I would suggest are delegating styling in part to something like Bootstrap (which also makes the page mobile friendly) and delegating updating to a framework such as Vue. I would be happy to contribute these.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd366d60058a5a463c592880db8bcad746981d9cf730e5e200b2aa3963f3eb6a-8cd11ef2cf4d09d96bc08e5ac907ccc87b4f84cbadc84a240767b5f7fbc22aff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Sánchez Terraf")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504154")[#strong[#text("Pedro Sánchez Terraf")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2018")])]

#text("Dear Terence,")

#text("Thank you very much for your development. I’ve tried the app up to")

#text("12.1(a) (“Reductio ad absurdum”) Given B AND (NOT B) [assuming A]: deduce NOT A.")

#text("There is a detail to that exercise. Any propositional theorem of the form “NOT A” (no matter the assumption set) is provable without Excluded Middle (this is Glivenko theorem, and it doesn’t go through for predicate logic: ")#link("http://p.sanchezterraf.com.ar/2015/10/22/how-about-a-little-absurdity/")[#text("http://p.sanchezterraf.com.ar/2015/10/22/how-about-a-little-absurdity/")]#text(").")

#text("This applies to the system of “natural deduction” of Gentzen and similar ones.")

#text("Best wishes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dac6b43ed9186c134a5d7e012a519381d4399687dad8e86831a04e233545b2fb-f5c75610f66c7b969028f26ade4447d4599f3adbc49d7ba133fe6f3c7555ccf8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rolfe Schmidt")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504155")[#strong[#text("Rolfe Schmidt")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2018")])]

#text("I agree that a lot can be done with this, and it would be great to turn it into something that was easy for others to augment and use. I agree with the earlier commenters that a great way to start this is to put the code in a public repository like GitHub. This would allow us to have focused technical discussions and contribute new code in a controlled way.")

#text("You are spot on about the need to decouple the presentation from the “game data” from the logic engine. There are many ways to do this, of course, and design decisions need to be based on the expected users. On the spot, I’d start by moving the GUI to a framework like ReactJS and move the interactive text and other “game data” into a JSON configuration file so that it is ajax ready.")

#text("Those might not be very interesting tasks, but they are things that some of us could hammer out quickly once it’s on github. In any case, I’d be happy to lend a hand here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/53698db10a2405225f2c1a8bdf36d17524a08d8808ff9725cfd6139515a48cbe-1ce1f5210dcc7be790abdd68ee877d8503761d34acfccd20c12c8ae67f95e4f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of daniel peters")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504158")[#strong[#text("daniel peters")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2018")])]

#text("adding to the voices to put the source of the site on github, many many people (myself included) would love to be able to use and contribute to a text like this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504163")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2018")])]

#text("OK, I think I managed to create a github repository for the code here: ")#link("https://github.com/teorth/QED")[#text("https://github.com/teorth/QED")]

#text("I assume now that people are free to clone it to work on it separately? I’m still not completely comfortable with the git-style version control paradigm.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa110cd843baa2000ae418ed3de2ae68b28bc66ef4075ccbcac1820a765bc52e-85a2258f3dc17fc3c3f5478e04ec551c8963350f4e5cfb87059b48fab2cfb0f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cjerdonek")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504164")[#strong[#text("cjerdonek")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2018")])]

#text("Good work! Yes, Git’s command usage is a bit unintuitive and takes some getting used to, though the core mental model of the commit history as a directed acyclic graph is somewhat elegant.")

#text("A couple more things to consider: 1) You may want to use the “issues” tracker as a way to coordinate and ask for help on things: ")#link("https://github.com/teorth/QED/issues")[#text("https://github.com/teorth/QED/issues")]#linebreak()#text(" 2) It will probably be good to have an automated or semi-automated way of publishing to the web the latest version of what’s in the repository. One option for doing this would be to use “GitHub Pages” (the “Project Page” variant):")#linebreak()#text(" ")#link("https://help.github.com/articles/configuring-a-publishing-source-for-github-pages/")[#text("https://help.github.com/articles/configuring-a-publishing-source-for-github-pages/")]#linebreak()#text(" This will wind up publishing the site to the following URL (if published from your version):")#linebreak()#text(" ")#link("https://teorth.github.io/QED")[#text("https://teorth.github.io/QED")]

#text("I expect that people will either suggest changes to you that you can accept through GitHub’s UI, or else someone might take the lead on developing improvements in their own fork. It partly depends on whether you want to be the one to manage the main version. (You will also have the option of granting one or more trusted individuals “write” access to your own version of the repository, so that your version can remain the main one, with others able to work on it without your involvement.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504167")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2018")])]

#text("The rest of us will fork (make our copies), clone these and generate pull requests. I just generated one to move files to base.")

#text("The automatically generated page for my version (with no changes so far) is at ")#link("https://siddhartha-gadgil.github.io/QED/QED.html")[#text("https://siddhartha-gadgil.github.io/QED/QED.html")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa110cd843baa2000ae418ed3de2ae68b28bc66ef4075ccbcac1820a765bc52e-85a2258f3dc17fc3c3f5478e04ec551c8963350f4e5cfb87059b48fab2cfb0f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cjerdonek")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504168")[#strong[#text("cjerdonek")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2018")])]

#text("> But writing this text (particularly the first-order logic sections) has brought me close to the limit of my programming ability, as the number of bugs introduced with each new feature implemented has begun to grow at an alarming rate.")

#text("By the way, the main way a software engineer handles this situation is by writing tests. Ideally, much of the code should be structured as testable functions, and a single test would consist of (1) the input to one of these functions, and (2) the expected output. Tests can be set up so they are all run by invoking a command and even e.g. after pushing to GitHub. In that way you can be sure you’re not breaking previous code when adding new code, etc. It takes a bit of work to set that up, but that’s what you should be aiming for to have a more maintainable code base.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af464198bf73915cb729713a4c32ba96719cf086c431619d34cfcc15fe4515f0-eb70768b5e03dc08981de03e2ebef74c29e1f1c921a61b00938f9558eaf67feb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nicolaspatrois")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504177")[#strong[#text("nicolaspatrois")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2018")])]

#text("Hi,")

#text("I suspect a bug in exercise 6.1(a), it seems that I can’t use the Deduction theorem and I don’t know why.")#linebreak()#text(" Should I prove again 5.1 or 5.2?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504179")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2018")])]

#text("Hmm, I can’t replicate this issue. Is the deduction theorem unlocked in the achievements window? If you drag A (assuming A) into the root environment, does it say that no available deductions can be formed?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af464198bf73915cb729713a4c32ba96719cf086c431619d34cfcc15fe4515f0-eb70768b5e03dc08981de03e2ebef74c29e1f1c921a61b00938f9558eaf67feb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nicolaspatrois")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504180")[#strong[#text("nicolaspatrois")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2018")])]

#text("The Deduction theorem is unlocked.")#linebreak()#text(" I see this:")

#text("Available deductions")#linebreak()#text(" From formula “A”, [root environment]:")

#text("IMPLICATION INTRODUCTION: A [assuming A]")#linebreak()#text(" EXERCISE 4.1: A AND A [assuming A]")

#text("But when I click on the first, I can’t use the Deduction theorem when A is in the root environment even if I built the formula A IMPLIES.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504182")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2018")])]

#text("To use the deduction theorem, you have to start with a statement that is in an assumption environment, and drag it out of that environment. Dragging a formula from the Formulas window won’t trigger the deduction theorem.")

#text("To solve this particular exercise, first use the implication introduction law to derive A assuming A, then you can drag A from the “assuming A” environment out to the root environment to trigger the deduction theorem.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af464198bf73915cb729713a4c32ba96719cf086c431619d34cfcc15fe4515f0-eb70768b5e03dc08981de03e2ebef74c29e1f1c921a61b00938f9558eaf67feb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nicolaspatrois")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504183")[#strong[#text("nicolaspatrois")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2018")])]

#text("OK, thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cba969e611696ec887fc66e9a8d7885f8b819a6c7670dd65e438d34ac4c91dc8-c3e54537a6ef0bdda705c82665a4c41d4c983d9b84bb7acdd9e1758543432dcc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yahya Abdal-Aziz")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504184")[#strong[#text("Yahya Abdal-Aziz")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2018")])]

#text("Terry, in ex. 3.1(a), where you introduce formulae, the text reads in part “The formula A is known to be true, …”. However, what we know to be true is the statement A. Is there perhaps a missing rule of deduction that allows us to assert that if statement A is true, then formula “A” is true?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504185")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2018")])]

#text("I’ve now reworded the text to hopefully make things more clear. The sentence A is available as a formula (and hence can be placed in the Formulas window as a formula, but is also known to be true in this exercise, and so can also be placed in the Root Environment as a statement.")

#text("Basically, the root environment is the location in the text for holding all the sentences that one is sure is true, while the formulas window is an additional location that can be used to hold sentences that may or may not be true. So certainly every statement in the root environment can also become a formula. (Indeed, the text allows you to drag sentences from an environment to the formulas window, which is sometimes a faster way of making formulas than using the formula formation rules.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cba969e611696ec887fc66e9a8d7885f8b819a6c7670dd65e438d34ac4c91dc8-c3e54537a6ef0bdda705c82665a4c41d4c983d9b84bb7acdd9e1758543432dcc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yahya Abdal-Aziz")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504241")[#strong[#text("Yahya Abdal-Aziz")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2018")])]

#text("Thanks! That’s certainly clearer. BTW, minor typo on screen: “Root enviroment” should read “Root environment”.")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of P")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504197")[#strong[#text("P")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2018")])]

#text("Are you planning to add more exercises? The amount of exercises in the late half are kinda lacking compared to the rest. This should only involve adding things to the main html only, with almost no change to the logic code.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504229")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2018")])]

#text("Fair enough. I have added two more exercises to Section 23 (Russell’s paradox, and no largest natural number) and one more exercise to Section 22 (a Lewis Carroll logic puzzle) to the most current version of the text, now hosted on Github at ")#link("https://teorth.github.io/QED/QED.html")[#text("https://teorth.github.io/QED/QED.html")]#text(" . If more good exercises come to mind I will add them also (and people are now welcome to suggest their own exercises, or even contribute them directly to the git repository).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504301")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2018")])]

#text("Some more exercises added. Three of them are in group theory: the cancellation law ( XY = XZ implies Y=Z), the fact that the product of two invertible elements in a monoid is still invertible, and the fact that group inversion is an involution. A further (particularly challenging) exercise has been added: to prove that it is possible to raise an irrational positive real to an irrational positive real and obtain a rational. (This is a classic application of the law of the excluded middle; quite fun to work out, if one hasn’t seen it before.) Also added a couple of short helper exercises that shorten the proofs of some of the lengthier exercises.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504322")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2018")])]

#text("Dear Terence, thanks being awesome enough to dedicate your time for such projects, it’s truly generous of your part! :)")

#text("One trivial enhancement: Please add a warning when JS is disabled since the game requires it to work. It’s pretty easy to do with the HTML tag ")#link("https://www.w3schools.com/TAGs/tag_noscript.asp")[#text("https://www.w3schools.com/TAGs/tag_noscript.asp")]

#emph[#text("[Done – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa110cd843baa2000ae418ed3de2ae68b28bc66ef4075ccbcac1820a765bc52e-85a2258f3dc17fc3c3f5478e04ec551c8963350f4e5cfb87059b48fab2cfb0f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cjerdonek")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504340")[#strong[#text("cjerdonek")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2018")])]

#text("Question: can you point out generally where in the code this comment is a reference to? “More seriously, due to my inability to come up with a good general-purpose matching algorithm (or even specification of such an algorithm) for the the laws of first-order logic, many of the laws have to be hard-coded into the matching routine, so one cannot currently remove them from the text.”")#linebreak()#text(" Maybe I can think a bit about possible alternate approaches.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504344")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2018")])]

#text("The hardcoded laws are universalIntroduction, universalIntroduction2, universalSpecification, universalSpecification2, existentialInstantiation, existentialInstantiation2, and indiscernability. They’ve now been moved to logic.js, so the issue of requiring the main HTML (or js) files to contain these laws is no longer an issue. However there is a significant amount of code required to match these specific laws (lines 770-1092 of logic.js), compared against the general-purpose matching algorithm (lines 1195-1417).")

#text("There are two main issues. The first is that if one wishes to apply a law that involves an expression such as ")#mi("P(\\alpha)")#text(", then there can be multiple ways to match the expression one has to give multiple choices for ")#mi("P")#text(" and ")#mi("\\alpha")#text(". For instance, if one’s expression is ")#mi("Q(x,x)")#text(" and one wishes to match this with ")#mi("P(\\alpha)")#text(", then one could take ")#mi("P")#text(" to be the predicate ")#mi("P(y) = Q(y,y)")#text(" and ")#mi("\\alpha")#text(" to be ")#mi("x")#text(", or ")#mi("P")#text(" could be the predicate ")#mi("P(y) = Q(y,x)")#text(" and ")#mi("\\alpha = x")#text(", or ")#mi("P(y) = Q(x,y)")#text(" and ")#mi("\\alpha = x")#text(", or ")#mi("P(y) = Q(x,x)")#text(" and ")#mi("\\alpha")#text(" is an arbitrary term. The latter is particularly annoying since it means that there are actually an infinite number of matching possibilities, though of course there are only finitely many inequivalent ones. Among other things, it means that some laws (specifically, indiscernability and the existential introduction laws) give rise to multiple matches from a given set of inputs (in the final exercise, for instance, there is a point in the proof where existential introduction makes ")#mi("2^6 = 64")#text(" matches!). The general-purpose matching algorithm I have presumes that the matching is unique, and so cannot handle this sort of multiplicity; in the two laws where multiplicity does occur, I had to use ad hoc code to create the matches.")

#text("The second issue, which I view as the more serious one, is that some laws come with side conditions, e.g. a certain expression in the law is not allowed to use bound variables, or any free variables not currently available in the target environment. I haven’t thought of a good way to encode these side conditions in general, and they are another reason why the hard-coded laws need separate code to treat.")

#text("Incidentally neither of these issues show up in the propositional logic portion of the text (Sections 1-13). For that portion any law is treatable by the general-purpose matching algorithm.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28b3868b80ddac4925ef086ec21dfa6072e21c4b29229fe8b5c3cf3d35e3449b-bfdd190fab8f1a5bcbe14c22cda807b92bd161077c1788a4e461aa77ec67166d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine Deleforge")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504353")[#strong[#text("Antoine Deleforge")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2018")])]

#text("I noted some typos in the last exercises:")#linebreak()#text(" -24.1(a) : In the second bullet point, alpha=beta should be alpha=alpha")#linebreak()#text(" -24.4 : In the first bullet point, the letter alpha is wrongly displayed as “&alpha”.")#linebreak()#text(" -24.6 : In the second bullet point, X*1*X should be X*1 = X")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504358")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2018")])]

#text("(v.2.5.4) how does one use ex.8.2?")

#text("I have two statements of the form “A implies B”, “B implies C” where A,B,C are formulas, and want to extract “A implies C” but dragging one onto the other or selecting both doesn’t give list ex.8.2 as one of the options — I only get “conjunction introduction” and “exercise 1.1”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504359")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2018")])]

#text("Is the problem that 8.2 is phrased in terms of variables rather than in terms of formulas?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504365")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2018")])]

#text("I had to change the name of the law in Exercise 8.2 due to an HTML formatting error, with the result being that the law would have become locked again if it were previously unlocked. If one re-does Ex8.2 then the law should become available.")

#text("(I recently changed the code to index laws by a shorter, non-HTML name rather than the HTML name, so this issue should eventually no longer become an issue, but legacy players will still have their laws indexed by the HTML name.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504372")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2018")])]

#text("This looks awesome!")

#text("Dr. Terence, what work is needed for localization? It would be great to have this game translated to other languages and I’d be happy to help on that side but my question is about the technical side. (of course one can fork QED and translate everything, but having everything on the official QED page with a button to change the language would be awesome)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504376")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2018")])]

#text("Hmm, I’m not sure technically what the best way to do this is; I’ve opened an issue about this on the github repository at ")#link("https://github.com/teorth/QED/issues/9")[#text("https://github.com/teorth/QED/issues/9")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504615")[#strong[#text("Marc Young")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2018")]

#text("Hi Terence,")

#text("Thank you for the awesome site! I’m having a lot of fun with it, but I’m currently stuck on Existence (21.1) and I can’t, for the life of me, figure out what’s required. Any hints or suggestions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504616")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2018")])]

#text("You need to use the new Existence axiom to set up an environment where a variable x has been set. Figure out how to establish A inside this environment, then one can pull it back out to the root environment.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5a8135489b80527492bc4638b5a0e5405d336ba39904a67d002199795e24da00-aad14bb805a4a5ddd315de5f87d438d59029003689af493afcbb6c4357049368.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Epstein")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504662")[#strong[#text("Martin Epstein")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2018")])]

#text("This is fantastic. I hope there is a mobile version some day.")

#text("Typo in 18.1, last bullet point. “forn”")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11eed6da60c8c3306b786526064a8733f4f9d93b704ca3e0f3fb4adf50337aaf-60a0d2262bea3c0344fd29fb667c13ed056a99cc3408620fae5cf70e30ad4e21.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Epstein")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504826")[#strong[#text("Martin Epstein")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2018")])]

#text("18.5 should say “DISTRIBUTES OVER” and not “COMMUTES WITH” I think.")

#emph[#text("[Changed – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6903009ef14c5d03924f633bcb0cc51300a8f60d31193b3dee2e0447528690-b85c3528dd9fc627686ecb36265c26512c6f006c20dc3ec961820231450e21c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hugo")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504680")[#strong[#text("Hugo")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2018")])]

#text("Could someone give me a suggestion in Exercise 6.1? I can not complete it.")

#text("I thought as follows:")#linebreak()#text(" 1. Assume A;")#linebreak()#text(" 2. Deduce A implies A (Implication Introduction of 1) – But it does not work.")

#text("or")

#text("1. Assume A;")#linebreak()#text(" 2. Deduce A and A (Assuming A);")#linebreak()#text(" 3. Deduce A (Conjugation Elimination-Assuming A);")#linebreak()#text(" 4. Deduce A implies A (Implication Introduction of 1 and 3-Assuming A) – But it does not work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504688")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2018")])]

#text("(a) Is “DEDUCTION THEOREM” listed as unlocked in the Achievements section?")#linebreak()#text(" (b) to use the deduction theorem, you have to drag a statement inside an assumption environment outside of that environment. For instance, in your first approach, you would take the statement A inside the “Assume A” window and drag it to the root environment. If the deduction theorem is unlocked, A IMPLIES A should be listed as an available deduction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6903009ef14c5d03924f633bcb0cc51300a8f60d31193b3dee2e0447528690-b85c3528dd9fc627686ecb36265c26512c6f006c20dc3ec961820231450e21c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hugo")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-504696")[#strong[#text("Hugo")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2018")])]

#text("Thank you! It worked.")#linebreak()#text(" My congratulations for the design of this excellent didactic resource.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11eed6da60c8c3306b786526064a8733f4f9d93b704ca3e0f3fb4adf50337aaf-60a0d2262bea3c0344fd29fb667c13ed056a99cc3408620fae5cf70e30ad4e21.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Epstein")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-505064")[#strong[#text("Martin Epstein")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2018")])]

#text("I beat the game the other day. My favorite exercise was Russell’s paradox. I was very surprised that we could demonstrate it with basically no assumptions about what the set inclusion operator means.")

#text("Fun idea for a group theory exercise: Given the equality relation and a binary operation with the following; associativity, a left ID ‘1’, and left invertibility; show that 1 is also a right ID. I was able to prove this in the 24.4 environment in 39 lines.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11eed6da60c8c3306b786526064a8733f4f9d93b704ca3e0f3fb4adf50337aaf-60a0d2262bea3c0344fd29fb667c13ed056a99cc3408620fae5cf70e30ad4e21.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Epstein")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-505065")[#strong[#text("Martin Epstein")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2018")])]

#text("38 lines if we ignore the 4th given line which wasn’t relevant.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11eed6da60c8c3306b786526064a8733f4f9d93b704ca3e0f3fb4adf50337aaf-60a0d2262bea3c0344fd29fb667c13ed056a99cc3408620fae5cf70e30ad4e21.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of martinepstein")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-505313")[#strong[#text("martinepstein")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2018")])]

#text("I have it down to 30 lines (ignoring the 4th given line). I think the core of the proof is quite elegant, but you need to use associativity on a product of 4 terms which is cumbersome.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-505555")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2018")])]

#text("I’ve now implemented this exercise as Exercise 24.8. I was able to establish it in 32 lines (with a slightly different setup), but presumably this can be improved slightly.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-505223")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2018")])]

#text("Is it possible to extend this proof verification software to include also the method based on the univalent foundation of mathematics? see e.g.")#linebreak()#text(" ")#link("https://doi.org/10.1090/bull/1616")[#text("https://doi.org/10.1090/bull/1616")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-506493")[#strong[#text("William Grosso (@wgrosso)")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2018")]

#text("“I would like to repackage the code so that it can be re-used by more adept programmers for further possible applications, though I have never done something like this before and would appreciate advice on how to do so. ”")

#text("Is that the extent of your goals? Do you have specific applications in mind (“Stochastic Partial Differential Equations: The Game”)? How much would you want to be involved? What would be, in your opinion, a very good outcome here?")

#text("Open source projects that “succeed” usually have some sort of governance and community structure clearly articulated. Putting it on github and putting an MIT license is a start, but if you want to push it forward more you probably need a vision statement (what’s the goal? why should someone volunteer?) and some sort of idea of how you’d like it to proceed (do you want to be a benevolent dictator? ")#link("https://en.wikipedia.org/wiki/Benevolent_dictator_for_life")[#text("https://en.wikipedia.org/wiki/Benevolent_dictator_for_life")]#text("? One of 7 people who vote on major changes? Just a guy, playing with code? Etcetera).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af464198bf73915cb729713a4c32ba96719cf086c431619d34cfcc15fe4515f0-eb70768b5e03dc08981de03e2ebef74c29e1f1c921a61b00938f9558eaf67feb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nicolaspatrois")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-506573")[#strong[#text("nicolaspatrois")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2018")])]

#text("Hi,")#linebreak()#text(" In exercise 9.5(d), I´d like to use 9.1(a) (OR is commutative) but it´s not in the list of available deductions from formulas “A” and “C”.")#linebreak()#text(" I can deduce that AND is commutative but not OR.")#linebreak()#text(" Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af464198bf73915cb729713a4c32ba96719cf086c431619d34cfcc15fe4515f0-eb70768b5e03dc08981de03e2ebef74c29e1f1c921a61b00938f9558eaf67feb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nicolaspatrois")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-506575")[#strong[#text("nicolaspatrois")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2018")])]

#text("I reproved 9.1(a) but I still did not get the fact that OR is commutative.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-506612")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2018")])]

#text("To use the commutativity of OR, you have to click on a sentence of the form “A OR B”. (For instance, if you restart Exercise 9.1(a) and click on the A OR B sentence, the option to (circularly) apply the commutativity of or should be present. There should also be a “PROVED: OR IS COMMUTATIVE” line in your achievements window.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf6e0e079dd23a167f1eae253214d4344658d38cbe302fb5d66c8b2ee0a2611f-ef46ad4fe977c290693366345f481ad4b96576e55ea5ccd7e527bf67cf9f7d37.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SansCipher")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-508958")[#strong[#text("SansCipher")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2018")])]

#text("I don’t understand 22.1. What am I supposed to do there? I just don’t understand how it works")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-508998")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2018")])]

#text("Try dragging ")#mi("Q(\\alpha,\\alpha)")#text(" onto ")#mi("\\alpha")#text(" (or vice versa). This will not give you exactly the required conclusion, but it should give a hint as to what one needs to do to ")#mi("Q(\\alpha,\\alpha)")#text(" first before you can get that conclusion. (Also it is worth reading all of the notes for this question carefully.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9993c9a59c6e2fb95bb22dfc9cebd74ee599e5f13f206f32e9aef4ea5287c647-a6f86015d24a3914d412ee95c1bde013251c901247fc965a12244e01410242ed.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lkimelfeld")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-509639")[#strong[#text("lkimelfeld")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2018")])]

#text("Thank you.")#linebreak()#text(" Interesting QED game:-)")#linebreak()#text(" Also it is easy and interesting to code exercises from it for the Leanprover (")#link("https://leanprover.github.io/")[#text("https://leanprover.github.io/")]#text(" )")#linebreak()#text(" I’ve coded several just for fun:")#linebreak()#text(" ")#link("https://github.com/lkimelfeld/qedlean/blob/master/qed-lean.lean")[#text("https://github.com/lkimelfeld/qedlean/blob/master/qed-lean.lean")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0e5f2feae838babfce16da9d0b5aa553179933c8b9ff7b73f700470b548de0f-3857261ec1986ea2cee61ea35338a4ef462c3275b15e81322da848c6eb6241e1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Duncan Whyte")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-514869")[#strong[#text("Duncan Whyte")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2019")])]

#text("In 9.2(b), the shortest proof with 12 lines uses exercise 3.1(a). I can do 3.1(a) in two moves (B -> B or C -> A or (B or C)) but not in one line. This means that the best I can get is 14 lines.")#linebreak()#text(" Which variables/formulas should be dragged onto which to get 3.1(a)?")#linebreak()#text(" Thanks in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-514871")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2019")])]

#text("To select three objects, click on object 1, CTRL-click on object 2, and then CTRL-click on object 3. (I’ve now added some text to 3.1(a) to mention this; previously it was only mentioned in 9.4(c).)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/795030b921762f9cfb5debf8b78dd9b480da645a03d4e01c8070efaf9fb4f6ef-553587deceaa3d7f40fafcec2b001895ef40abd58d388db9d5a5f66694a4a34f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Contador De HistóriasParaAdultos")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-628947")[#strong[#text("Contador De HistóriasParaAdultos")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2021")])]

#text("Great work")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-682048")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2023")])]

#text("Hello , Where is the solutions ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f927bc9720c2936fb6a971b3851608b49ad68d06ae35053f634d6885b2e072d-f603ce6f9ef0ca76e8cb015e3fd593068761256ea880035ff7cdaeb15d55517d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/#comment-697507")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("In Exercise 2.2(b), it says that right associativity is provable in 7 lines. That is possible, but I’m confused as the game seems to include the “Q.E.D.” in the lines, meaning the actual proof is 6 lines. Am I missing something?")
]
