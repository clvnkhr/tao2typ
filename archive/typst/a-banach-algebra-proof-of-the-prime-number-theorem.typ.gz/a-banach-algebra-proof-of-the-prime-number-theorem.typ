// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/10/25/a-banach-algebra-proof-of-the-prime-number-theorem/
// Converted to Typst by tao2typ: "2026-10-14T10:21:02.549103+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A Banach algebra proof of the prime number theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A Banach algebra proof of the prime number theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 October 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/10/25/a-banach-algebra-proof-of-the-prime-number-theorem/")[#text("https://terrytao.wordpress.com/2014/10/25/a-banach-algebra-proof-of-the-prime-number-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(" can be expressed as the assertion ")#metadata(none) <tao-a160524700113ddd3205>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{n \\leq x} \\Lambda(n) = x + o(x)")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\Lambda(n) := \\sum_{d|n} \\mu(d) \\log \\frac{n}{d}")]]

#text("is the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(". It is a basic result in analytic number theory, but requires a bit of effort to prove. One “elementary” proof of this theorem proceeds through the ")#link("http://mathworld.wolfram.com/SelbergsFormula.html")[#text("Selberg symmetry formula")]#text(" ")#metadata(none) <tao-7c84ce75d92e62ebdbe7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{n \\leq x} \\Lambda_2(n) = 2 x \\log x + O(x)")]]

#text("where the second von Mangoldt function ")#mi("{\\Lambda_2}")#text(" is defined by the formula ")#metadata(none) <tao-81f59f6127dda321e9a9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\Lambda_2(n) := \\sum_{d|n} \\mu(d) \\log^2 \\frac{n}{d}")]]

#text("or equivalently ")#metadata(none) <tao-e00443c76cfe2be97aa8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\Lambda_2(n) = \\Lambda(n) \\log n + \\sum_{d|n} \\Lambda(d) \\Lambda(\\frac{n}{d}).")]]

#text("(We are avoiding the use of the ")#mi("{*}")#text(" symbol here to denote Dirichlet convolution, as we will need this symbol to denote ordinary convolution shortly.) For the convenience of the reader, we give a proof of the Selberg symmetry formula below the fold. Actually, for the purposes of proving the prime number theorem, the weaker estimate ")#metadata(none) <tao-8ad7086e50f5b031aad6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_{n \\leq x} \\Lambda_2(n) = 2 x \\log x + o(x \\log x)")]]

#text("suffices.")

#text("In this post I would like to record a somewhat “soft analysis” reformulation of the elementary proof of the prime number theorem in terms of Banach algebras, and specifically in Banach algebra structures on (completions of) the space ")#mi("{C_c({\\bf R})}")#text(" of compactly supported continuous functions ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" equipped with the convolution operation")

#align(center)[#tao-fit-display[#mitex("f*g(t) := \\int_{\\bf R} f(u) g(t-u)\\ du.")]]

#text("This soft argument does not easily give any quantitative decay rate in the prime number theorem, but by the same token it avoids many of the quantitative calculations in the traditional proofs of this theorem. Ultimately, the key “soft analysis” fact used is the ")#link("http://en.wikipedia.org/wiki/Spectral_radius")[#text("spectral radius formula")]#text(" ")#metadata(none) <tao-a26ea51cb6950777b229>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\lim_{n \\rightarrow \\infty} \\left\\|f^n\\right\\|^{1/n} = \\sup_{\\lambda \\in \\hat B} \\left|\\lambda(f)\\right|", block: true)]]

#text("for any element ")#mi("{f}")#text(" of a unital commutative Banach algebra ")#mi("{B}")#text(", where ")#mi("{\\hat B}")#text(" is the space of characters (i.e., continuous unital algebra homomorphisms from ")#mi("{B}")#text(" to ")#mi("{{\\bf C}}")#text(") of ")#mi("{B}")#text(". This formula is due to Gelfand and may be found in any text on Banach algebras; for sake of completeness we prove it below the fold.")

#text("The connection between prime numbers and Banach algebras is given by the following consequence of the Selberg symmetry formula.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Construction of a Banach algebra norm)")]#text(" ")#metadata(none) <tao-b2a96c3d3fc2b6accdb4>#text(" For any ")#mi("{G \\in C_c({\\bf R})}")#text(", let ")#tao-math("{\\left\\|G\\right\\|}", block: false)#text(" denote the quantity")

#align(center)[#tao-fit-display[#tao-math("\\left\\|G\\right\\| := \\limsup_{x \\rightarrow \\infty} \\left|\\sum_n \\frac{\\Lambda(n)}{n} G( \\log \\frac{x}{n} ) - \\int_{\\bf R} G(t)\\ dt\\right|.", block: true)]]

#text("Then ")#mi("{\\| \\|}")#text(" is a seminorm on ")#mi("{C_c({\\bf R})}")#text(" with the bound ")#metadata(none) <tao-4cd0e21a9a0795a14ec9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left\\|G\\right\\| \\leq \\left\\|G\\right\\|_{L^1({\\bf R})} := \\int_{\\bf R} |G(t)|\\ dt", block: true)]]

#text("for all ")#mi("{G \\in C_c({\\bf R})}")#text(". Furthermore, we have the Banach algebra bound ")#metadata(none) <tao-eeea394806ada3056899>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left\\| G * H \\right\\| \\leq \\left\\|G\\right\\| \\left\\|H\\right\\|", block: true)]]

#text("for all ")#mi("{G,H \\in C_c({\\bf R})}")#text(".")
]

#text("We prove this theorem below the fold. The prime number theorem then follows from Theorem ")#link(<tao-b2a96c3d3fc2b6accdb4>)[#text("1")]#text(" and the following two assertions. The first is an application of the spectral radius formula ")#link(<tao-a26ea51cb6950777b229>)[#text("(6)")]#text(" and some basic Fourier analysis (in particular, the observation that ")#mi("{C_c({\\bf R})}")#text(" contains a plentiful supply of local units):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Non-trivial Banach algebras with many local units have non-trivial spectrum)")]#text(" ")#metadata(none) <tao-dffe602cd1e0bfa9b4d8>#text(" Let ")#mi("{\\| \\|}")#text(" be a seminorm on ")#mi("{C_c({\\bf R})}")#text(" obeying ")#link(<tao-4cd0e21a9a0795a14ec9>)[#text("(7)")]#text(", ")#link(<tao-eeea394806ada3056899>)[#text("(8)")]#text(". Suppose that ")#mi("{\\| \\|}")#text(" is not identically zero. Then there exists ")#mi("{\\xi \\in {\\bf R}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{\\bf R} G(t) e^{-it\\xi}\\ dt\\right| \\leq \\left\\|G\\right\\|", block: true)]]

#text("for all ")#mi("{G \\in C_c}")#text(". In particular, by ")#link(<tao-4cd0e21a9a0795a14ec9>)[#text("(7)")]#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\|G\\right\\| = \\left\\| G \\right\\|_{L^1({\\bf R})}", block: true)]]

#text("whenever ")#mi("{G(t) e^{-it\\xi}}")#text(" is a non-negative function.")
]

#text("The second is a consequence of the Selberg symmetry formula and the fact that ")#mi("{\\Lambda}")#text(" is real (as well as ")#link("http://en.wikipedia.org/wiki/Mertens'_theorems")[#text("Mertens’ theorem")]#text(", in the ")#mi("{\\xi=0}")#text(" case), and is closely related to the non-vanishing of the Riemann zeta function ")#mi("{\\zeta}")#text(" on the line ")#mi("{\\{ 1+i\\xi: \\xi \\in {\\bf R}\\}}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Breaking the parity barrier)")]#text(" ")#metadata(none) <tao-d7cea7305a333d5c9ceb>#text(" Let ")#mi("{\\xi \\in {\\bf R}}")#text(". Then there exists ")#mi("{G \\in C_c({\\bf R})}")#text(" such that ")#mi("{G(t) e^{-it\\xi}}")#text(" is non-negative, and")

#align(center)[#tao-fit-display[#tao-math("\\left\\|G\\right\\| < \\left\\|G\\right\\|_{L^1({\\bf R})}.", block: true)]]
]

#text("Assuming Theorems ")#link(<tao-b2a96c3d3fc2b6accdb4>)[#text("1")]#text(", ")#link(<tao-dffe602cd1e0bfa9b4d8>)[#text("2")]#text(", ")#link(<tao-d7cea7305a333d5c9ceb>)[#text("3")]#text(", we may now quickly establish the prime number theorem as follows. Theorem ")#link(<tao-dffe602cd1e0bfa9b4d8>)[#text("2")]#text(" and Theorem ")#link(<tao-d7cea7305a333d5c9ceb>)[#text("3")]#text(" imply that the seminorm ")#mi("{\\| \\|}")#text(" constructed in Theorem ")#link(<tao-b2a96c3d3fc2b6accdb4>)[#text("1")]#text(" is trivial, and thus")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\Lambda(n)}{n} G( \\log \\frac{x}{n} ) = \\int_{\\bf R} G(t)\\ dt + o(1)")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(" for any Schwartz function ")#mi("{G}")#text(" (the decay rate in ")#mi("{o(1)}")#text(" may depend on ")#mi("{G}")#text("). Specialising to functions of the form ")#mi("{G(t) = e^{-t} \\eta( e^{-t} )}")#text(" for some smooth compactly supported ")#mi("{\\eta}")#text(" on ")#mi("{(0,+\\infty)}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\Lambda(n) \\eta(\\frac{n}{x}) = x \\int_{\\bf R} \\eta(u)\\ du + o(x)")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text("; by the smooth Urysohn lemma this implies that")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\varepsilon x \\leq n \\leq x} \\Lambda(n) = x - \\varepsilon x + o(x)")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(" for any fixed ")#mi("{\\varepsilon>0}")#text(", and the prime number theorem then follows by a telescoping series argument.")

#text("The same argument also yields the prime number theorem in arithmetic progressions, or equivalently that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) \\chi(n) = o(x)")]]

#text("for any fixed ")#link("http://en.wikipedia.org/wiki/Dirichlet%27s_theorem_on_arithmetic_progressions")[#text("Dirichlet character")]#text(" ")#mi("{\\chi}")#text("; the one difference is that the use of Mertens’ theorem is replaced by the basic fact that the quantity ")#mi("{L(1,\\chi) = \\sum_n \\frac{\\chi(n)}{n}}")#text(" is non-vanishing.")

#metadata(none) <tao-c81f3583186cb26ea066>

#heading(level: 1)[#strong[#text(" — 1. Proof of Selberg symmetry formula — ")]]

#text("We now prove ")#link(<tao-7c84ce75d92e62ebdbe7>)[#text("(2)")]#text(". From ")#link(<tao-81f59f6127dda321e9a9>)[#text("(3)")]#text(" we have ")#metadata(none) <tao-5e8c9902207afaeb7120>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\frac{1}{x} \\sum_{n \\leq x} \\Lambda_2(n) = \\sum_{d \\leq x} \\frac{\\mu(d)}{d} \\frac{1}{x/d} \\sum_{m \\leq x/d} \\log^2 m.")]]

#text("From the integral test we have the estimates")

#tao-aligned(keep: true)[


#tao-math("\\frac{1}{x} \\sum_{n \\leq x} \\log^2 n  & = \\log^2 x - 2\\log x + 2 + O( \\frac{\\log^2 (2 + x)}{x})", block: true)



#tao-math("\\sum_{n \\leq x} \\frac{1}{x/n} \\frac{1}{n}  & = 1 + O(\\frac{1}{x})", block: true)



#tao-math("\\sum_{n \\leq x} \\frac{1}{n}  & = \\log x + c_1 + O(\\frac{1}{x})", block: true)



#tao-math("\\sum_{n \\leq x} \\frac{\\log(x/n)}{n}  & = \\frac{1}{2} \\log^2 x + c_2 \\log x + c_3 + O( \\frac{\\log(2+x)}{x} )", block: true)
]

#text("for some absolute constants ")#mi("{c_1,c_2,c_3}")#text(" whose exact value is unimportant for us, and for any ")#mi("{x \\geq 1}")#text(". We conclude that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x} \\sum_{n \\leq x} \\log^2 n = \\sum_{n \\leq x} \\frac{2\\log(x/n)+ c_4 + c_5/(x/n)}{n} + O( \\frac{\\log^2 (2 + x)}{x})")]]

#text("for some further absolute constants ")#mi("{c_4,c_5}")#text(". Replacing ")#mi("{x}")#text(" by ")#mi("{x/d}")#text(" and inserting this into ")#link(<tao-5e8c9902207afaeb7120>)[#text("(9)")]#text(", one obtains")

#tao-aligned(keep: true)[


#tao-math("\\frac{1}{x} \\sum_{n \\leq x} \\Lambda_2(n)  & = \\sum_{d \\leq x} \\frac{\\mu(d)}{d} \\sum_{m \\leq x/d} \\frac{2 \\log(x/dm) + c_4 + c_5/(x/dm)}{m}", block: true)



#tao-math(" & + O( \\sum_{d \\leq x} \\frac{1}{d} \\frac{\\log^2( 2 + x/d )}{x/d} ).", block: true)
]

#text("The error term can be computed to be ")#mi("{O(1)}")#text(". The main term simplifies by Möbius inversion to ")#mi("{2 \\log x + c_4 + c_5/x}")#text(", and the claim follows.")

#heading(level: 1)[#strong[#text(" — 2. Constructing the Banach algebra — ")]]

#metadata(none) <tao-9306774f3fbb39aa066d>

#text("We now prove Theorem ")#link(<tao-b2a96c3d3fc2b6accdb4>)[#text("1")]#text(". It is convenient to transform the situation from the classical context of arithmetic functions on ")#mi("{{\\bf N}}")#text(" (such as ")#mi("{\\Lambda}")#text(" or ")#mi("{\\Lambda_2}")#text(") to the more Fourier-analytic context of Radon measures on the real line ")#mi("{{\\bf R}}")#text(". Define the discrete Radon measure")

#align(center)[#tao-fit-display[#mitex("\\mu := \\sum_{n=1}^\\infty \\frac{\\Lambda(n)}{n} \\delta_{\\log n}")]]

#text("and for any ")#mi("{h \\in {\\bf R}}")#text(", let ")#mi("{\\tau_h \\mu}")#text(" denote the left translate of the measure ")#mi("{\\mu}")#text(" by ")#mi("{h}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} G(t)\\ d\\tau_h \\mu(t) = \\int_{\\bf R} G(t+h)\\ d\\mu(t)")]]

#text("for any continuous compactly supported ")#mi("{G \\in C_c({\\bf R})}")#text(". We note in passing that the prime number theorem ")#link(<tao-a160524700113ddd3205>)[#text("(1)")]#text(" is equivalent to the assertion that the translates ")#mi("{\\tau_h \\mu}")#text(" converge in the ")#link("http://en.wikipedia.org/wiki/Vague_topology")[#text("vague topology")]#text(" to Lebesgue measure ")#mi("{m}")#text(" as ")#mi("{h \\rightarrow +\\infty}")#text(".")

#text("Let ")#mi("{\\nu}")#text(" denote the measure ")#metadata(none) <tao-7dfd8928a4a3162bbd66>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\nu := \\mu + \\frac{1}{t} \\mu * \\mu")]]

#text("where ")#mi("{\\mu * \\mu}")#text(" is the convolution of the Radon measures ")#mi("{\\mu}")#text(", and ")#mi("{t \\mu}")#text(" is the measure ")#mi("{\\mu}")#text(" multiplied by the identity function ")#mi("{t \\mapsto t}")#text(". From ")#link(<tao-e00443c76cfe2be97aa8>)[#text("(4)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\nu := \\sum_{n=1}^\\infty \\frac{\\Lambda_2(n)}{n \\log n} \\delta_{\\log n}.")]]

#text("We claim that the Selberg symmetry formula ")#link(<tao-8ad7086e50f5b031aad6>)[#text("(5)")]#text(" implies (in fact, it is equivalent to) the assertion that the translates ")#mi("{\\tau_h \\nu}")#text(" converge in the vague topology to ")#mi("{2m}")#text(". Indeed, ")#link(<tao-8ad7086e50f5b031aad6>)[#text("(5)")]#text(" implies for any fixed ")#mi("{0 < a < b}")#text(" that")

#align(center)[#tao-fit-display[#mitex("\\sum_{ax \\leq n \\leq bx} \\Lambda_2(n) = 2 (b-a) x \\log x + o(x \\log x)")]]

#text("or equivalently that")

#align(center)[#tao-fit-display[#mitex("\\sum_{ax \\leq n \\leq bx} \\frac{\\Lambda_2(n)}{n \\log n} \\frac{n}{x} (1 + \\frac{\\log \\frac{n}{x}}{\\log x}) = 2 (b-a) + o(1),")]]

#text("which we rewrite as")

#align(center)[#tao-fit-display[#mitex("\\int_{\\log a}^{\\log b} e^t (1 + \\frac{t}{\\log x}) \\ d\\tau_{\\log x} \\nu(t) = 2 \\int_{\\log a}^{\\log b} e^t\\ dt + o(1).")]]

#text("Since ")#mi("{\\frac{t}{\\log x} = o(1)}")#text(" for ")#mi("{\\log a \\leq t \\leq \\log b}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\log a}^{\\log b} e^t\\ d\\tau_{\\log x} \\nu(t) = 2 \\int_{\\log a}^{\\log b} e^t\\ dt + o(1),")]]

#text("which implies that ")#mi("{e^t \\tau_{\\log x} \\nu}")#text(" converges vaguely to ")#mi("{e^t m}")#text(", and the claim follows.")

#text("Now we begin the proof of Theorem ")#link(<tao-b2a96c3d3fc2b6accdb4>)[#text("1")]#text(". Observe that the quantity ")#tao-math("{\\left\\|G\\right\\|}", block: false)#text(" can be rewritten as ")#metadata(none) <tao-981f4e620f014826311b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left\\|G\\right\\| = \\limsup_{h \\rightarrow +\\infty} \\left|\\int_{\\bf R} G(t)\\ d\\tau_h \\mu(t) - \\int_{\\bf R} G(t)\\ dt\\right|.", block: true)]]

#text("Since ")#metadata(none) <tao-135fc7a09da25f03e44f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("0 \\leq \\tau_h \\mu \\leq \\tau_h \\nu")]]

#text("and ")#mi("{\\tau_h \\nu}")#text(" converges vaguely to ")#mi("{2m}")#text(", we see that the measures ")#mi("{\\tau_h \\mu}")#text(" are precompact in the vague topology, thanks to the ")#link("http://en.wikipedia.org/wiki/Helly%27s_selection_theorem")[#text("Helly selection principle")]#text(" or ")#link("http://en.wikipedia.org/wiki/Prokhorov%27s_theorem")[#text("Prokhorov theorem")]#text(". In particular, we have ")#metadata(none) <tao-0497db517ef058cb6d36>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left\\|G\\right\\| = \\left|\\int_{\\bf R} G(t)\\ d\\lambda - \\int_{\\bf R} G(t)\\ dt\\right|", block: true)]]

#text("for some limit point ")#mi("{\\lambda = \\lambda_G}")#text(" of the translates ")#mi("{\\tau_h\\mu}")#text(" in the vague topology. From ")#link(<tao-135fc7a09da25f03e44f>)[#text("(12)")]#text(" we have ")#metadata(none) <tao-4f996e14d7f39fdfd609>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("0 \\leq \\lambda \\leq 2m")]]

#text("and ")#link(<tao-4cd0e21a9a0795a14ec9>)[#text("(7)")]#text(" follows from ")#link(<tao-0497db517ef058cb6d36>)[#text("(13)")]#text(".")

#text("Finally, we prove ")#link(<tao-eeea394806ada3056899>)[#text("(8)")]#text(". By")#link(<tao-981f4e620f014826311b>)[#text("(11)")]#text(", it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{\\bf R} G*H(t) d\\tau_h\\mu(t) - \\int_{\\bf R} G*H(t)\\ dt\\right| \\leq \\left\\|G\\right\\| \\left\\|H\\right\\| + o(1)", block: true)]]

#text("for any ")#mi("{G,H \\in C_c({\\bf R})}")#text(", where the ")#mi("{o(1)}")#text(" decay errors are allowed to depend on ")#mi("{G,H}")#text(". Since ")#mi("{\\tau_h\\nu}")#text(" converges vaguely to ")#mi("{2m}")#text(", we already have from ")#link(<tao-7dfd8928a4a3162bbd66>)[#text("(10)")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} G*H(t)\\ d\\tau_h\\mu(t) + \\int_{\\bf R} G*H(t)\\ d\\tau_h(\\frac{1}{t} \\mu*\\mu)(t)")]]

#align(center)[#tao-fit-display[#mitex("= 2 \\int_{\\bf R} G*H(t) + o(1)")]]

#text("so it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{\\bf R} G*H(t)\\ d\\tau_h(\\frac{1}{t} \\mu*\\mu)(t) - \\int_{\\bf R} G*H(t)\\ dt\\right| \\leq \\left\\|G\\right\\| \\left\\|H\\right\\| + o(1)", block: true)]]

#text("Let ")#mi("{m_+}")#text(" be Lebesgue measure on the half-line ")#mi("{[0,+\\infty)}")#text(". Then ")#mi("{m_+ * m_+ = t m_+}")#text(", so ")#mi("{\\tau_h( \\frac{1}{t} (m_+ * m_+) )}")#text(" converges vaguely to ")#mi("{m}")#text(". The measure ")#mi("{\\frac{1}{t} (m_+ * \\mu)}")#text(" is equal to ")#mi("{m}")#text(" times the function ")#mi("{t \\mapsto \\frac{1}{t} \\sum_{n \\leq e^t} \\frac{\\Lambda(n)}{n}}")#text(", so by ")#link("http://en.wikipedia.org/wiki/Mertens%27_theorems")[#text("Mertens’ theorem")]#text(" this function also converges vaguely to ")#mi("{m}")#text(". We conclude that")

#align(center)[#tao-fit-display[#mitex("\\tau_h(\\frac{1}{t} \\mu*\\mu) - \\tau_h(\\frac{1}{t} (\\mu-m_+)*(\\mu-m_+))")]]

#text("converges vaguely to ")#mi("{m}")#text(", and so it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{\\bf R} G*H(t)\\ d\\tau_h(\\frac{1}{t} (\\mu-m_+)*(\\mu-m_+))(t)\\right| \\leq \\left\\|G\\right\\| \\left\\|H\\right\\| + o(1)", block: true)]]

#text("We rewrite this as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{\\bf R} \\frac{1}{t+h} G*H(t+h)\\ d((\\mu-m_+)*(\\mu-m_+))(t)\\right| \\leq \\left\\|G\\right\\| \\left\\|H\\right\\| + o(1).", block: true)]]

#text("On the support of ")#mi("{G*H(t+h)}")#text(", we have ")#mi("{\\frac{1}{t+h} = \\frac{1+o(1)}{h}}")#text(", so it suffices to show that ")#metadata(none) <tao-99ae3b48819b7b2763c6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left|\\frac{1}{h} \\int_{\\bf R} G*H(t+h)\\ d((\\mu-m_+)*(\\mu-m_+))(t)\\right|", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\leq \\left\\|G\\right\\| \\left\\|H\\right\\| + o(1).", block: true)]]

#text("(The error term in ")#mi("{\\frac{1+o(1)}{h}}")#text(" can be controlled by using ")#link(<tao-99ae3b48819b7b2763c6>)[#text("(15)")]#text(" with ")#mi("{G,H}")#text(" replaced by ")#tao-math("{\\left|G\\right|, \\left|H\\right|}", block: false)#text(", and modifying the preceding arguments to replace ")#mi("{(\\mu-m_+)*(\\mu-m_+)}")#text(" by ")#mi("{(\\mu+m_+)*(\\mu+m_+)}")#text(".)")

#text("From Fubini’s theorem we have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} G*H(t+h)\\ d((\\mu-m_+)*(\\mu-m_+))(t)")]]

#tao-aligned(keep: true)[


#tao-math(" & = \\int_{\\bf R} \\int_{\\bf R} G*H(t+s+h)\\ d(\\mu-m_+)(t) d(\\mu-m_+)(s)", block: true)



#tao-math(" & = \\int_{\\bf R} \\int_{\\bf R} \\int_{\\bf R} G(t+k) H(s+h-k)\\ d(\\mu-m_+)(t) d(\\mu-m_+)(s) dk", block: true)



#tao-math(" & = \\int_{\\bf R} (\\int_{\\bf R} G(t)\\ d\\tau_k (\\mu-m_+)(t)) (\\int_{\\bf R} H(s)\\ d\\tau_{h-k} (\\mu-m_+)(s))\\ dk", block: true)
]

#text("The ")#mi("{k}")#text(" integrand vanishes unless ")#mi("{-O(1) \\leq k \\leq h+O(1)}")#text(". By ")#link(<tao-981f4e620f014826311b>)[#text("(11)")]#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{k \\rightarrow +\\infty} \\left|\\int_{\\bf R} G(t)\\ d\\tau_k (\\mu-m_+)(t)\\right| = \\left\\|G\\right\\|", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{l \\rightarrow +\\infty} \\left|\\int_{\\bf R} H(t)\\ d\\tau_l (\\mu-m_+)(t)\\right| = \\left\\|H\\right\\|,", block: true)]]

#text("and the claim ")#link(<tao-99ae3b48819b7b2763c6>)[#text("(15)")]#text(" follows.")

#heading(level: 1)[#strong[#text(" — 3. Non-trivial algebras with many local units have non-trivial spectrum — ")]]

#text("We now prove Theorem ")#link(<tao-dffe602cd1e0bfa9b4d8>)[#text("2")]#text(". Let ")#mi("{B}")#text(" be the Banach algebra completion of ")#mi("{C_c({\\bf R})}")#text(" under the seminorm ")#mi("{\\| \\|}")#text(" (thus ")#mi("{B}")#text(" is the space of Cauchy sequences in ")#mi("{C_c({\\bf R})}")#text(", quotiented out by the sequences that go to zero in the seminorm ")#mi("{\\| \\|}")#text("). Since ")#mi("{\\| \\|}")#text(" is not identically zero, ")#mi("{B}")#text(" is a non-trivial commutative Banach algebra (but it is not necessarily unital).")

#text("It is convenient to adjoin a unit ")#mi("{1}")#text(" to ")#mi("{B}")#text(" to create a unital commutative Banach algebra ")#mi("{B^{\\prime} := {\\bf C} 1 + B}")#text(" with the extended norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\| t 1 + f \\right\\| := \\left|t\\right| + \\left|f\\right|", block: true)]]

#text("for ")#mi("{t \\in {\\bf C}}")#text(" and ")#mi("{f \\in B}")#text("; one easily verifies that ")#mi("{B^{\\prime}}")#text(" is a unital commutative Banach algebra.")

#text("Suppose that all elements of ")#mi("{B}")#text(" have zero spectral radius (as defined in ")#link(<tao-a26ea51cb6950777b229>)[#text("(6)")]#text("). Let ")#mi("{f}")#text(" be a Schwartz function with compactly supported Fourier transform. Then we can find another Schwartz function ")#mi("{g}")#text(" with compactly supported Fourier transform such that ")#mi("{f * g = f}")#text(" (by ensuring that ")#mi("{\\hat g=1}")#text(" on the support of ")#mi("{\\hat f}")#text("; thus ")#mi("{g}")#text(" is a “local unit” on the Fourier support of ")#mi("{f}")#text("). Thus ")#mi("{f * g^{*n} = f}")#text(" for all ")#mi("{n}")#text(". But ")#mi("{g}")#text(" has spectral radius zero, thus ")#mi("{f}")#text(" is zero in ")#mi("{B}")#text(". By density this implies that ")#mi("{B}")#text(" is trivial, a contradiction.")

#text("Thus there is an element of ")#mi("{B}")#text(" with positive spectral radius. Then by ")#link(<tao-a26ea51cb6950777b229>)[#text("(6)")]#text(", there is a character ")#mi("{\\lambda: B^{\\prime} \\rightarrow {\\bf C}}")#text(" that is does not vanish identically on ")#mi("{B}")#text(". Suppose that for each ")#mi("{\\xi \\in {\\bf R}}")#text(" there exists ")#mi("{f \\in C_c({\\bf R})}")#text(" in the kernel of ")#mi("{\\lambda}")#text(" whose Fourier coefficient ")#mi("{\\hat f(\\xi) := \\int_{\\bf R} f(t) e^{-it\\xi}\\ dt}")#text(" is non-vanishing. Since the kernel of ")#mi("{\\lambda}")#text(" is a space closed with respect to convolutions by ")#mi("{C_c({\\bf R})}")#text(" functions, some Fourier analysis and a smooth partition of unity then shows that the kernel of ")#mi("{\\lambda}")#text(" contains any Schwartz function with compactly supported Fourier transform, and thus by density ")#mi("{\\lambda}")#text(" is trivial, a contradiction. Thus there must exist ")#mi("{\\xi \\in {\\bf R}}")#text(" such that ")#mi("{\\text{ker}(\\lambda)}")#text(" contains all test functions with Fourier coefficient vanishing at ")#mi("{\\xi}")#text(". From this we conclude that ")#mi("{\\lambda}")#text(" on ")#mi("{B}")#text(" is a constant multiple of the Fourier coefficient map ")#mi("{f \\mapsto \\hat f(\\xi)}")#text("; being a non-trivial algebra homomorphism on ")#mi("{B}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("\\lambda(f) = \\hat f(\\xi)")]]

#text("for all ")#mi("{f \\in C_c({\\bf R})}")#text(". Since characters have norm at most ")#mi("{1}")#text(" (as can be seen for instance from ")#link(<tao-a26ea51cb6950777b229>)[#text("(6)")]#text("), we obtain the claim.")

#heading(level: 1)[#strong[#text(" — 4. Breaking the parity barrier — ")]]

#metadata(none) <tao-c1c50fe62721ac5b6c61>

#text("We now prove Theorem ")#link(<tao-d7cea7305a333d5c9ceb>)[#text("3")]#text(". We divide into two cases, depending on whether ")#mi("{\\xi=0}")#text(" or ")#mi("{\\xi \\neq 0}")#text(". If ")#mi("{\\xi=0}")#text(", we let ")#mi("{G = G_0: {\\bf R} \\rightarrow [0,1]}")#text(" be a continuous function that equals ")#mi("{1}")#text(" on ")#mi("{[-N,0]}")#text(" and is supported on ")#mi("{[-N-1,1]}")#text(" for some large ")#mi("{N}")#text(". From Mertens’ theorem we have")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\Lambda(n)}{n} G_0( \\log \\frac{x}{n} ) = N + O(1)")]]

#text("for ")#mi("{x}")#text(" sufficiently large depending on ")#mi("{N}")#text(", and thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\|G_0\\right\\| = O(1).", block: true)]]

#text("The claim then follows by taking ")#mi("{N}")#text(" sufficiently large.")

#text("Now suppose ")#mi("{\\xi \\neq 0}")#text(". In the language of Section ")#link(<tao-9306774f3fbb39aa066d>)[#text("2")]#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|G\\right\\| = \\left|\\int_{\\bf R} G(t)\\ d(\\lambda - m)(t)\\right|", block: true)]]

#text("for some limit point ")#mi("{\\lambda}")#text(" of the ")#mi("{\\tau_h \\mu}")#text(". We can write the right-hand side as")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\text{Re}( e^{i\\theta} G(t)\\ d(\\lambda-m)(t) )")]]

#text("for some phase ")#mi("{e^{i\\theta}}")#text(". From ")#link(<tao-4f996e14d7f39fdfd609>)[#text("(14)")]#text(", ")#mi("{\\lambda-m}")#text(" is a real measure between ")#mi("{-m}")#text(" and ")#mi("{m}")#text(", so by the triangle inequality we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|G\\right\\| \\leq \\int_{\\bf R} |\\text{Re}( e^{i\\theta} G(t) )|\\ dt.", block: true)]]

#text("Now we set ")#mi("{G(t) := G_0(t) e^{it\\xi}}")#text(", where ")#mi("{G_0}")#text(" is as before. Then")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} |\\text{Re}( e^{i\\theta} G(t) )|\\ dt = \\int_{\\bf R} |\\cos(t \\xi + \\theta)| G_0(t)\\ dt.")]]

#text("Since ")#tao-math("{t \\mapsto \\left|\\cos(t \\xi + \\theta)\\right|}", block: false)#text(" is periodic with period ")#tao-math("{2\\pi/\\left|\\xi\\right|}", block: false)#text(" and has mean value strictly less than ")#mi("{1}")#text(" (in fact, it has mean ")#mi("{\\frac{2}{\\pi}}")#text("), we thus have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} |\\text{Re}( e^{i\\theta} G(t) )|\\ dt = \\int_{\\bf R} |\\cos(t \\xi + \\theta)| G_0(t)\\ dt < \\int_{\\bf R} G_0(t)\\ dt")]]

#text("if ")#mi("{N}")#text(" is sufficiently large depending on ")#mi("{\\xi}")#text(". The claim follows.")

#heading(level: 1)[#strong[#text(" — 5. The prime number theorem in arithmetic progressions — ")]]

#text("Let ")#mi("{\\chi}")#text(" be a non-principal Dirichlet character of some period ")#mi("{q}")#text(". We allow all implied constants in the ")#mi("{O()}")#text(" notation to depend on ")#mi("{\\chi}")#text(". In this section we sketch the changes to the above arguments needed to establish")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\chi(n) \\Lambda(n) = o(x),")]]

#text("which gives the prime number in arithmetic progressions by the usual Fourier expansion into Dirichlet characters.")

#text("We have the twisted versions")

#align(center)[#tao-fit-display[#mitex("\\chi(n)\\Lambda_2(n) := \\sum_{d|n} \\chi(d)\\mu(d) \\chi(\\frac{n}{d}) \\log^2 \\frac{n}{d}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\chi(n)\\Lambda_2(n) = \\chi(n)\\Lambda(n) \\log n + \\sum_{d|n} \\chi(d)\\Lambda(d) \\chi(\\frac{n}{d})\\Lambda(\\frac{n}{d})")]]

#text("of ")#link(<tao-81f59f6127dda321e9a9>)[#text("(3)")]#text(", ")#link(<tao-e00443c76cfe2be97aa8>)[#text("(4)")]#text(". Since ")#mi("{\\chi}")#text(" has mean zero, a decomposition into intervals of length ")#mi("{q}")#text(" reveals that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x} \\sum_{n \\leq x} \\chi(n) \\log^2 n = O( \\frac{\\log^2 (2 + x)}{x})")]]

#text("from which we obtain the twisted Selberg symmetry formula")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\chi(n) \\Lambda_2(n) = O(x).")]]

#text("If we define the twisted measures")

#align(center)[#tao-fit-display[#mitex("\\mu_\\chi := \\sum_{n=1}^\\infty \\frac{\\chi(n) \\Lambda(n)}{n} \\delta_{\\log n}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\nu_\\chi := \\mu_\\chi + \\frac{1}{t} \\mu_\\chi * \\mu_\\chi")]]

#text("then")

#align(center)[#tao-fit-display[#mitex("\\nu_\\chi := \\sum_{n=1}^\\infty \\frac{\\chi(n) \\Lambda_2(n)}{n \\log n} \\delta_{\\log n}.")]]

#text("and hence ")#mi("{\\tau_h \\nu_\\chi}")#text(" converges weakly to zero as ")#mi("{h \\rightarrow +\\infty}")#text(". Introducing the twisted norms")

#align(center)[#tao-fit-display[#tao-math("\\left\\|G\\right\\|_\\chi := \\limsup_{x \\rightarrow \\infty} \\left|\\sum_n \\frac{\\chi(n) \\Lambda(n)}{n} G( \\log \\frac{x}{n} )\\right|", block: true)]]

#text("we may verify that ")#mi("{\\| \\|_\\chi}")#text(" obeys the conclusions of Theorem ")#link(<tao-b2a96c3d3fc2b6accdb4>)[#text("1")]#text(".")

#text("By repeating the previous arguments, it will suffice that the analogue of Theorem ")#link(<tao-d7cea7305a333d5c9ceb>)[#text("3")]#text(" for ")#mi("{\\| \\|_\\chi}")#text(" holds. When ")#mi("{\\xi = 0}")#text(", we can argue as in Section ")#link(<tao-c1c50fe62721ac5b6c61>)[#text("4")]#text(", where the role of Mertens’ theorem is replaced by Dirichlet’s theorem")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{\\chi(n) \\Lambda(n)}{n} = O(1)")]]

#text("which is ultimately a consequence of the non-vanishing of ")#mi("{L(1,\\chi)}")#text(".")

#text("For ")#mi("{\\xi \\neq 0}")#text(", the argument in Section ")#link(<tao-c1c50fe62721ac5b6c61>)[#text("4")]#text(" works with minimal changes if ")#mi("{\\chi}")#text(" is real-valued. If ")#mi("{\\chi}")#text(" is complex valued, it still takes only a finite number of values ")#mi("{S}")#text(" in the unit disk. Then the limit measures ")#mi("{\\lambda}")#text(" appearing in Section ")#link(<tao-c1c50fe62721ac5b6c61>)[#text("4")]#text(" are equal to Lebesgue measure ")#mi("{m}")#text(" times a density taking values in the convex hull ")#mi("{\\overline{S}}")#text(" of this finite set of values, which is a polygon in the unit disk. One can then modify the arguments in Section ")#link(<tao-c1c50fe62721ac5b6c61>)[#text("4")]#text(" to bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\|G\\right\\| \\leq \\int_{\\bf R} \\sup_{z \\in \\overline{S}} \\left|\\Re z e^{i\\theta} G(t)\\right|\\ dt", block: true)]]

#text("for some phase ")#mi("{e^{i\\theta}}")#text(". If we set ")#mi("{G(t) = e^{it\\xi} G_0(t)}")#text(" as before, we again observe that the function ")#tao-math("{t \\mapsto \\sup_{z \\in \\overline{S}} \\left|\\Re z e^{i\\theta} e^{it\\xi}\\right|}", block: false)#text(" is periodic and has mean strictly less than one, and so we can again establish the required bound ")#tao-math("{\\left\\|G\\right\\|_\\chi < \\left\\|G\\right\\|_{L^1({\\bf R})}}", block: false)#text(" if ")#mi("{N}")#text(" is large enough.")

#heading(level: 1)[#strong[#text(" — 6. Proof of Gelfand formula — ")]]

#text("We now prove ")#link(<tao-a26ea51cb6950777b229>)[#text("(6)")]#text(".")

#text("If ")#mi("{\\lambda}")#text(" is a character, then it has an operator norm:")

#align(center)[#tao-fit-display[#tao-math("\\left|\\lambda(f)\\right| \\leq \\left\\|\\lambda\\right\\|_{op} \\|f\\|.", block: true)]]

#text("But we may eliminate this norm by using the “tensor power trick”: replacing ")#mi("{f}")#text(" with ")#mi("{f^n}")#text(" and then taking ")#mi("{n^{th}}")#text(" roots we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\lambda(f)\\right| \\leq \\left\\|\\lambda\\right\\|_{op}^{1/n} \\left\\|f\\right\\|", block: true)]]

#text("and then on sending ")#mi("{n \\rightarrow \\infty}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\lambda(f)\\right| \\leq \\left\\|f\\right\\|.", block: true)]]

#text("Replacing ")#mi("{f}")#text(" by ")#mi("{f^n}")#text(" again, taking ")#mi("{n^{th}}")#text(" roots, and sending ")#mi("{n \\rightarrow \\infty}")#text(" we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\lambda(f)\\right| \\leq \\lim_{n \\rightarrow \\infty} \\left\\|f^n\\right\\|^{1/n}.", block: true)]]

#text("(The limit exists because ")#tao-math("{n \\mapsto \\left\\|f^n\\right\\|}", block: false)#text(" is submultiplicative.) This gives one direction of ")#link(<tao-a26ea51cb6950777b229>)[#text("(6)")]#text(". To give the other direction, suppose for sake of contradiction that we could find an ")#mi("{f \\in B}")#text(" such that ")#metadata(none) <tao-274db9ebdbcb2726ad02>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\lim_{n \\rightarrow \\infty} \\left\\|f^n\\right\\|^{1/n} > R > \\sup_{\\lambda \\in \\hat B} \\left|\\lambda(f)\\right|", block: true)]]

#text("for some real number ")#mi("{R>0}")#text(".")

#text("There are two cases, depending on whether we can find a complex number ")#mi("{z}")#text(" with ")#tao-math("{\\left|z\\right| \\geq R}", block: false)#text(" and ")#mi("{f-z}")#text(" non-invertible. First suppose that such a ")#mi("{z}")#text(" exists; then ")#mi("{f-z}")#text(" generates an ideal of ")#mi("{B}")#text(", which by Zorn’s lemma is contained in a maximal ideal ")#mi("{I}")#text(", whose quotient is then a field. By Neumann series, any element of ")#mi("{B}")#text(" sufficiently close to the identity is invertible and thus not in ")#mi("{I}")#text("; since ")#mi("{B/I}")#text(" is a field, we conclude that the complement of ")#mi("{I}")#text(" is open, and so ")#mi("{B/I}")#text(" is closed. This makes ")#mi("{B/I}")#text(" a Banach algebra as well as a field. If ")#mi("{f \\in B/I}")#text(" is not a multiple of the identity, then ")#mi("{f-z}")#text(" is invertible for every ")#mi("{z}")#text(" and so (by Neumann series) ")#mi("{(f-z)^{-1}}")#text(" is an analytic function from ")#mi("{{\\bf C}}")#text(" to ")#mi("{B/I}")#text(" which goes to zero at infinity, contradicting Liouville’s theorem. Thus ")#mi("{B/I}")#text(" is one-dimensional (this is the Banach-Mazur theorem) and thus isomorphic to ")#mi("{{\\bf C}}")#text("; this gives a continuous unital algebra homomorphism ")#mi("{\\lambda: B \\rightarrow {\\bf C}}")#text(" with ")#mi("{f-z}")#text(" in the kernel, thus ")#mi("{\\lambda(f)=z}")#text(", contradicting the second inequality in ")#link(<tao-274db9ebdbcb2726ad02>)[#text("(16)")]#text(".")

#text("Now suppose that ")#mi("{f-z}")#text(" is invertible for all ")#tao-math("{\\left|z\\right| \\geq R}", block: false)#text(". Then, as in the preceding argument, ")#mi("{z \\mapsto (f-z)^{-1}}")#text(" is an analytic function from ")#tao-math("{\\{ z: \\left|z\\right| \\geq R \\}}", block: false)#text(" to ")#mi("{B}")#text(" which decays to zero at infinity, so we have the Cauchy integral formula")

#align(center)[#tao-fit-display[#tao-math("f^n = -\\frac{1}{2\\pi} \\int_{\\left|z\\right|=R} z^n (f-z)^{-1}\\ dz", block: true)]]

#text("for any natural number ")#mi("{n}")#text(". From the triangle inequality we conclude in particular that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f^n \\right\\| \\ll_{R,f} R^n", block: true)]]

#text("which contradicts the first inequality in ")#link(<tao-274db9ebdbcb2726ad02>)[#text("(16)")]#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed7fe480a3961266e21303169a56485024d3761fdd7df6313fdb8a9c1d61f7a0-75a66dce3db0742badf7bb3b53131cb1c0febb8c669081d6c1961ecdd8c48a16.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of voloch")]], [#link("https://terrytao.wordpress.com/2014/10/25/a-banach-algebra-proof-of-the-prime-number-theorem/#comment-433312")[#strong[#text("voloch")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2014")])]

#text("What’s the role of $\\epsilon$ in theorem 3?")

#emph[#text("[Oops, that shouldn’t be there – deleted, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/327786970ea04341483a6a897eaf5c6416284f721aa106d3cd7503bb959c289a-dba86977e74fe0d41cad802544e943cdb6ab745b0facbaf24c6f4a5ef71be3bf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wubr2000")]], [#link("https://terrytao.wordpress.com/2014/10/25/a-banach-algebra-proof-of-the-prime-number-theorem/#comment-433316")[#strong[#text("wubr2000")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2014")])]

#text("Reblogged this on ")#link("http://wubrfell.com/2014/10/25/a-banach-algebra-proof-of-the-prime-number-theorem/")[#text("Importantish")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/065138e1b1902805d7f744a8b774918e0ccbb72d8c610f9cb5f0d04cde9795e3-c304526fcf69ae299ab157ae31b1f0cc68fc0ab5c24aaa809399deb8b52fce69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mats Granvik")]], [#link("https://terrytao.wordpress.com/2014/10/25/a-banach-algebra-proof-of-the-prime-number-theorem/#comment-433399")[#strong[#text("Mats Granvik")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2014")])]

#mi("a(n) = \\lim\\limits_{s \\rightarrow 1} \\zeta(s)\\sum\\limits_{d|n} \\mu(d)(e^{d})^{(s-1)}")

#mi("a(n)=1")

#mi("\\sum _{k=1}^n a(\\gcd (n,k)) \\log \\left(\\frac{n}{k}\\right) = \\lim_{s\\to 1} \\, \\zeta (s) \\sum _{k=1}^n \\frac{a(\\gcd (n,k))}{k^{s-1}}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dd792ce466ac8b4341f8a9162d68c16b08d9bd178f616ec98d0ff844a340d447-a8dd3134e6b8d7ab623dcabc4d8253d43da8f3dc0c51f6abafac24a8be615411.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt R.")]], [#link("https://terrytao.wordpress.com/2014/10/25/a-banach-algebra-proof-of-the-prime-number-theorem/#comment-433452")[#strong[#text("Matt R.")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2014")])]

#text("Reblogged this on ")#link("http://matthewhr.wordpress.com/2014/10/26/a-banach-algebra-proof-of-the-prime-number-theorem/")[#text("Math by Matt")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/686d6d93bb25b4a7e5ca0018c2229694ff9188a7b558dc64ef394a0d6e2f3053-8b71c75bc5bd875771103e0532aef19458318916c0cd01e7494372a36b3931ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/10/25/a-banach-algebra-proof-of-the-prime-number-theorem/#comment-433490")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2014")])]

#text("Seeing double. There is a second copy at the end.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cee7ff3d89f11b44c3fee3ebba656a25298f40ead1fb45f1417a75cc2588b66f-0e44f6dc250daa56655653384c059ea72241e93832a6b8225f83562222217fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yemon Choi")]], [#link("https://terrytao.wordpress.com/2014/10/25/a-banach-algebra-proof-of-the-prime-number-theorem/#comment-433811")[#strong[#text("Yemon Choi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2014")])]

#text("The title of Section 3 seems a little misleading, since it’s perfectly possible to have infinite-dimensional commutative Banach algebras in which every element has spectral radius zero, e.g. the quotient of the convolution algebra $L^1(R_+)$ by the ideal of functions supported on $[1,\\infty)$. (This quotient algebra even has a bounded approximate identity; of course it doesn’t have local units on a dense subalgebra, otherwise one could run the argument given in your post.)")

#text("Of course this is merely a quibble over terminology and doesn’t affect the actual mathematics in the post!")

#emph[#text("[Terminology changed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/126bcdb52aa8ea6bb8a73e8f73ec13ec279a7e2afa2abdf86a8b9b034128ca2f-e546fa76cece9b49c67e052398b334315edcda14392a56ff011bf1dc91bdfc12.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tony Huynh")]], [#link("https://terrytao.wordpress.com/2014/10/25/a-banach-algebra-proof-of-the-prime-number-theorem/#comment-435383")[#strong[#text("Tony Huynh")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2014")])]

#text("The link to the Selberg Symmetry Formula is the same as the link to the von Mangoldt function, which I suspect is unintended.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95f0b369fffc1e332832f72fd3b27c76421785e0dc6e3b0c1ab5ea594cc0a32b-db32347a753225a9a7fd4ede6b6dbcaea182d8f6b75dbe173e3e1c5328ae36c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of peter")]], [#link("https://terrytao.wordpress.com/2014/10/25/a-banach-algebra-proof-of-the-prime-number-theorem/#comment-435493")[#strong[#text("peter")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2014")])]

#text("i would love to understand this article but I am to dumb for that also my iq is only 2 digit but I want to have 3 digit iq. Can u help me ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/15a202e79590ee3813d6b62f518f4758cde57e780e538352911d43c388f33413-956dd1efb59b6d38fbb7a2ac91cac7cb8643e4f9ba93e38d77beee9d31c7f0c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zhenyuliao")]], [#link("https://terrytao.wordpress.com/2014/10/25/a-banach-algebra-proof-of-the-prime-number-theorem/#comment-443301")[#strong[#text("zhenyuliao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2014")])]

#text("Reblogged this on ")#link("http://zhenyuliao.wordpress.com/2014/11/30/a-banach-algebra-proof-of-the-prime-number-theorem/")[#text("zhenyuliao")]#text(" and commented:")#linebreak()#text(" Fun proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hiklicepleh")]], [#link("https://terrytao.wordpress.com/2014/10/25/a-banach-algebra-proof-of-the-prime-number-theorem/#comment-450189")[#strong[#text("hiklicepleh")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2015")])]

#text("You can say something about the non-trivial estimates ")#mi("\\displaystyle \\sum_{n \\leq \\frac{x}{2}} \\Lambda(\\frac{x}{n})")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 1: Elementary multiplicative number theory | What's new")]], [#link("https://terrytao.wordpress.com/2014/10/25/a-banach-algebra-proof-of-the-prime-number-theorem/#comment-472491")[#strong[#text("254A, Notes 1: Elementary multiplicative number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2016")])]

#text("[…] for various cutoff functions , such as smooth, compactly supported functions. See for instance this previous blog post for an instance of such an approach. Another related approach is the “pretentious” […]")
]
