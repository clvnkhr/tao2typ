// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/07/17/local-universality-of-zeroes-of-random-polynomials/
// Converted to Typst by tao2typ: "2026-10-14T16:37:10.208491+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Local universality of zeroes of random polynomials", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Local universality of zeroes of random polynomials")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 July 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/07/17/local-universality-of-zeroes-of-random-polynomials/")[#text("https://terrytao.wordpress.com/2013/07/17/local-universality-of-zeroes-of-random-polynomials/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://vanvu.commons.yale.edu/")[#text("Van Vu")]#text(" and I have just uploaded to the arXiv our joint paper “")#link("http://arxiv.org/abs/1307.4357")[#text("Local universality of zeroes of random polynomials")]#text("“. This paper is a sequel to ")#link("https://terrytao.wordpress.com/2012/06/11/random-matrices-universality-of-local-spectral-statistics-of-non-hermitian-matrices/")[#text("our previous work on local universality of eigenvalues of (non-Hermitian) random matrices ")#mi("{M_n}")#text(" with independent entries")]#text(". One can re-interpret these previous results as a universality result for a certain type of random polynomial ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(", namely the ")#link("http://en.wikipedia.org/wiki/Characteristic_polynomial")[#text("characteristic polynomial")]#text(" ")#mi("{f(z) = \\text{det}(M_n-z)}")#text(" of the random matrix ")#mi("{M_n}")#text(". In this paper, we consider the analogous problem for a different model of random polynomial, namely polynomials ")#mi("{f}")#text(" with independent random coefficients. More precisely, we consider random polynomials ")#mi("{f = f_n}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("f(z) = \\sum_{i=0}^n c_i \\xi_i z^n")]]

#text("where ")#mi("{c_0,\\ldots,c_n \\in {\\bf C}}")#text(" are deterministic complex coefficients, and ")#mi("{\\xi_0,\\ldots,\\xi_n \\equiv \\xi}")#text(" are independent identically distributed copies of a complex random variable ")#mi("{\\xi}")#text(", which we normalise to have mean zero and variance one. For simplicity we will ignore the technical issue that the leading coefficient ")#mi("{c_n \\xi_n}")#text(" is allowed to vanish; then ")#mi("{f}")#text(" has ")#mi("{n}")#text(" zeroes ")#mi("{\\zeta_1,\\ldots,\\zeta_n \\in {\\bf C}}")#text(" (counting multiplicity), which can be viewed as a random ")#link("http://en.wikipedia.org/wiki/Point_process")[#text("point process")]#text(" ")#mi("{\\Sigma = \\{\\zeta_1,\\ldots,\\zeta_n\\}}")#text(" in the complex plane. In analogy with other models (such as random matrix models), we expect the (suitably normalised) asymptotic statistics of this point process in the limit ")#mi("{n \\rightarrow \\infty}")#text(" to be ")#emph[#text("universal")]#text(", in the sense that it is largely independent of the precise distribution of the atom variable ")#mi("{\\xi}")#text(".")

#text("Our results are fairly general with regard to the choice of coefficients ")#mi("{c_i}")#text(", but we isolate three particular choice of coefficients that are particularly natural and well-studied in the literature:")

#list(
[#emph[#text("Flat polynomials")]#text(" (or ")#emph[#text("Weyl polynomials")]#text(") in which ")#mi("{c_i := \\frac{1}{\\sqrt{i!}}}")#text(".")],
[#emph[#text("Elliptic polynomials")]#text(" (or ")#emph[#text("binomial polynomials")]#text(") in which ")#mi("{c_i := \\sqrt{\\binom{n}{i}}}")#text(".")],
[#emph[#text("Kac polynomials")]#text(" in which ")#mi("{c_i := 1}")#text(".")]
)

#text("The flat and elliptic polynomials enjoy special symmetries in the model case when the atom distribution ")#mi("{\\xi}")#text(" is a complex Gaussian ")#mi("{N(0,1)_{\\bf C}}")#text(". Indeed, the zeroes ")#mi("{\\Sigma}")#text(" of elliptic polynomials with complex Gaussian coefficients have a distribution which is invariant with respect to isometries ")#mi("{T: {\\bf C} \\cup \\{\\infty\\} \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" of the Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" (thus ")#mi("{T\\Sigma}")#text(" has the same distribution as ")#mi("{\\Sigma}")#text("), while the zeroes of the limiting case ")#mi("{\\sum_{i=0}^\\infty \\frac{1}{\\sqrt{i!}} \\xi_i z^i}")#text(" of the flat polynomials with complex Gaussian coefficients are similarly invariant with respect to isometries ")#mi("{T: {\\bf C} \\rightarrow {\\bf C}}")#text(" of the complex plane ")#mi("{{\\bf C}}")#text(". (For a nice geometric proof of this facts, I recommend ")#link("http://www.ams.org/mathscinet-getitem?mr=2552864")[#text("the nice book of Hough, Krishnapur, Peres, and Virag")]#text(".)")

#text("The global (i.e. coarse-scale) distribution of zeroes of these polynomials is well understood, first in the case of gaussian distributions using the fundamental tool of the Kac-Rice formula, and then for more general choices of atom distribution in the recent work of ")#link("http://arxiv.org/abs/1205.5355")[#text("Kabluchko and Zaporozhets")]#text(". The zeroes of the flat polynomials are asymptotically distributed according to the ")#emph[#text("circular law")]#text(", normalised to be uniformly distributed on the disk ")#mi("{B(0,\\sqrt{n})}")#text(" of radius ")#mi("{\\sqrt{n}}")#text(" centred at the origin. To put it a bit informally, the zeroes are asymptotically distributed according to the measure ")#tao-math("{\\frac{1}{\\pi} 1_{\\left|z\\right| \\leq \\sqrt{n}} dz}", block: false)#text(", where ")#mi("{dz}")#text(" denotes Lebesgue measure on the complex plane. One can non-rigorously see the scale ")#mi("{\\sqrt{n}}")#text(" appear by observing that when ")#tao-math("{\\left|z\\right|}", block: false)#text(" is much larger than ")#mi("{\\sqrt{n}}")#text(", we expect the leading term ")#mi("{\\frac{1}{\\sqrt{n!}} \\xi_n z^n}")#text(" of the flat polynomial ")#mi("{\\sum_{i=0}^n \\frac{1}{\\sqrt{i!}} \\xi_i z^i}")#text(" to dominate, so that the polynomial should not have any zeroes in this region.")

#text("Similarly, the distribution of the elliptic polynomials is known to be asymptotically distributed according to a Cauchy-type distribution ")#tao-math("{\\frac{1}{\\pi} \\frac{1}{1+\\left|z\\right|^2/n} dz}", block: false)#text(". The Kac polynomials ")#mi("{\\sum_{i=0}^n \\xi_i z^i}")#text(" behave differently; the zeroes concentrate uniformly on the unit circle ")#tao-math("{\\left|z\\right|=1}", block: false)#text(" (which is reasonable, given that one would expect the top order term ")#mi("{\\xi_i z^i}")#text(" to dominate for ")#tao-math("{\\left|z\\right| > 1}", block: false)#text(" and the bottom order term ")#mi("{\\xi_0}")#text(" to dominate for ")#tao-math("{\\left|z\\right| < 1}", block: false)#text("). In particular, whereas the typical spacing between zeroes in the flat and elliptic cases would be expected to be comparable to ")#mi("{1}")#text(", the typical spacing between zeroes for a Kac polynomial would be expected instead to be comparable to ")#mi("{1/n}")#text(".")

#text("In our paper we studied the local distribution of zeroes at the scale of the typical spacing. In the case of polynomials with continuous complex atom disribution ")#mi("{\\xi}")#text(", the natural statistic to measure here is the ")#mi("{k}")#text("-point correlation function ")#mi("{\\rho^{(k)}(z_1,\\ldots,z_k)}")#text(", which for distinct complex numbers ")#mi("{z_1,\\ldots,z_k}")#text(" can be defined as the probability that there is a zero in each of the balls ")#mi("{B(z_1,\\varepsilon),\\ldots,B(z_k,\\varepsilon)}")#text(" for some infinitesimal ")#mi("{\\epsilon >0}")#text(", divided by the normalising factor ")#mi("{(\\pi \\epsilon^2)^k}")#text(". (One can also define a ")#mi("{k}")#text("-point correlation function in the case of a discrete distribution, but it will be a measure rather than a function in that case.) Our first main theorem is a general ")#emph[#text("replacement principle")]#text(" which asserts, very roughly speaking, that the asymptotic ")#mi("{k}")#text("-point correlation functions of two random polynomials ")#mi("{f, \\tilde f}")#text(" will agree if the log-magnitudes ")#tao-math("{\\log \\left|f(z)\\right|, \\log \\left|\\tilde f(z)\\right|}", block: false)#text(" have asymptotically the same distribution (actually we have to consider the joint distribution of ")#tao-math("{\\log \\left|f(z_1)\\right|, \\ldots \\log \\left|f(z_k)\\right|}", block: false)#text(" for several points ")#mi("{z_1,\\ldots,z_k}")#text(", but let us ignore this detail for now), and if the polynomials ")#mi("{f, \\tilde f}")#text(" obeys a “non-clustering property” which asserts, roughly speaking, that not too many of the zeroes of ")#mi("{f}")#text(" can typically concentrate in a small ball. This replacement principle was implicit in ")#link("https://terrytao.wordpress.com/2012/06/11/random-matrices-universality-of-local-spectral-statistics-of-non-hermitian-matrices/")[#text("our previous paper")]#text(" (and can be viewed as a local-scale version of the global-scale replacement principle in ")#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/")[#text("this earlier paper of ours")]#text("). Specialising the replacement principle to the elliptic or flat polynomials, and using the Lindeberg swapping argument, we obtain a ")#emph[#text("Two Moment Theorem")]#text(" that asserts, roughly speaking, that the asymptotic behaviour of the ")#mi("{k}")#text("-point correlation functions depends only on the first two moments of the real and imaginary components of ")#mi("{\\xi}")#text(", as long as one avoids some regions of space where universality is expected to break down. (In particular, because ")#mi("{f(0) = c_0 \\xi_0}")#text(" does not have a universal distribution, one does not expect universality to hold near the origin; there is a similar problem near infinity.) Closely related results, by a slightly different method, have also been obtained recently by ")#link("http://www.math.mun.ca/~merkli/PREPRINTS/SML.pdf")[#text("Ledoan, Merkli, and Starr")]#text(". A similar result holds for the Kac polynomials after rescaling to account for the narrower spacing between zeroes.")

#text("We also have analogous results in the case of polynomials with real coefficients (so that the coefficients ")#mi("{c_i}")#text(" and the atom distribution ")#mi("{\\xi}")#text(" are both real). In this case one expects to see a certain number of real zeroes, together with conjugate pairs of complex zeroes. Instead of the ")#mi("{k}")#text("-point correlation function ")#mi("{\\rho^{(k)}(z_1,\\ldots,z_k)}")#text(", the natural object of study is now the mixed ")#mi("{(k,l)}")#text("-point correlation function ")#mi("{\\rho^{(k,l)}(x_1,\\ldots,x_k,z_1,\\ldots,z_l)}")#text(" that (roughly speaking) controls how often one can find a real zero near the real numbers ")#mi("{x_1,\\ldots,x_k}")#text(", and a complex zero near the points ")#mi("{z_1,\\ldots,z_l}")#text(". It turns out that one can disentangle the real and strictly complex zeroes and obtain separate universality results for both zeroes, provided that at least one of the polynomials involved obeys a “weak repulsion estimate” that shows that the real zeroes do not cluster very close to each other (and that the complex zeroes do not cluster very close to their complex conjugates). Such an estimate is needed to avoid the situation of two nearby real zeroes “colliding” to create a (barely) complex zero and its complex conjugate, or the time reversal of such a collision. Fortunately, in the case of real gaussian polynomials one can use the Kac-Rice formula to establish such a weak repulsion estimate, allowing analogues of the above universality results for complex random polynomials in the real case. Among other things, this gives universality results for the number ")#mi("{N_{\\bf R}}")#text(" of real zeroes of a random flat or elliptic polynomial; it turns out this number is typically equal to ")#mi("{\\frac{2}{\\pi} \\sqrt{n} + O(n^{1/2-c})}")#text(" and ")#mi("{\\frac{n} + O(n^{1/2-c})}")#text(" respectively. (For Kac polynomials, the situation is somewhat different; it was already known that ")#mi("{N_{\\bf R} = \\frac{2}{\\pi} \\log n + o(\\log n)}")#text(" thanks to a long series of papers, starting with the foundational work of Kac and culminating in the work ")#link("http://www.ams.org/mathscinet-getitem?mr=286157")[#text("of Ibragimov")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=288824")[#text("and Maslova")]#text(".)")

#text("While our methods are based on our earlier work on eigenvalues of random matrices, the situation with random polynomials is actually somewhat easier to deal with. This is because the log-magnitude ")#tao-math("{\\log \\left|f(z)\\right|}", block: false)#text(" of a random polynomial with independent coefficients is significantly easier to control than the log-determinant ")#tao-math("{\\log \\left|\\text{det}(M-z)\\right|}", block: false)#text(" of a random matrix, as the former can be controlled by the central limit theorem, while the latter requires significantly more difficult arguments (in particular, bounds on the least singular value combined with Girko’s Hermitization trick). As such, one could view the current paper as an introduction to our more complicated previous paper, and with this in mind we have written the current paper to be self-contained (though this did make the paper somewhat lengthy, checking in at 68 pages).")
