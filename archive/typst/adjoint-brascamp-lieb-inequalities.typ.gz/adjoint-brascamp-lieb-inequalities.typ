// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/06/29/adjoint-brascamp-lieb-inequalities/
// Converted to Typst by tao2typ: "2026-10-14T11:10:35.464040+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Adjoint Brascamp-Lieb inequalities", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Adjoint Brascamp-Lieb inequalities")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 June 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/06/29/adjoint-brascamp-lieb-inequalities/")[#text("https://terrytao.wordpress.com/2023/06/29/adjoint-brascamp-lieb-inequalities/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://www.birmingham.ac.uk/staff/profiles/maths/bennett-jonathan.aspx")[#text("Jon Bennett")]#text(" and I have just uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/2306.16558")[#text("Adjoint Brascamp-Lieb inequalities")]#text("“. In this paper, we observe that the family of multilinear inequalities known as the ")#link("https://en.wikipedia.org/wiki/Brascamp%E2%80%93Lieb_inequality")[#text("Brascamp-Lieb inequalities")]#text(" (or Holder-Brascamp-Lieb inequalities) admit an adjoint formulation, and explore the theory of these adjoint inequalities and some of their consequences.")

#text("To motivate matters let us review the classical theory of adjoints for linear operators. If one has a bounded linear operator ")#mi("{T: L^p(X) \\rightarrow L^q(Y)}")#text(" for some measure spaces ")#mi("{X,Y}")#text(" and exponents ")#mi("{1 < p, q < \\infty}")#text(", then one can define an adjoint linear operator ")#mi("{T^*: L^{q^{\\prime}}(Y) \\rightarrow L^{p^{\\prime}}(X)}")#text(" involving the dual exponents ")#mi("{\\frac{1}{p}+\\frac{1}{p^{\\prime}} = \\frac{1}{q}+\\frac{1}{q^{\\prime}} = 1}")#text(", obeying (formally at least) the duality relation ")#metadata(none) <tao-c5419f8b099324d31350>#mi("\\displaystyle  \\langle Tf, g \\rangle = \\langle f, T^* g \\rangle \\ \\ \\ \\ \\ (1)")#text(" ")#text(" for suitable test functions ")#mi("{f, g}")#text(" on ")#mi("{X, Y}")#text(" respectively. Using the dual characterization")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^{p^{\\prime}}(X)} = \\sup_{g: \\left\\|g\\right\\|_{L^p(X)} \\leq 1} \\left|\\langle f, g \\rangle\\right|", block: true)]]

#text("of ")#mi("{L^{p^{\\prime}}(X)}")#text(" (and similarly for ")#mi("{L^{q^{\\prime}}(Y)}")#text("), one can show that ")#mi("{T^*}")#text(" has the same operator norm as ")#mi("{T}")#text(".")

#text("There is a slightly different way to proceed using Hölder’s inequality. For sake of exposition let us make the simplifying assumption that ")#mi("{T}")#text(" (and hence also ")#mi("{T^*}")#text(") maps non-negative functions to non-negative functions, and ignore issues of convergence or division by zero in the formal calculations below. Then for any reasonable function ")#mi("{g}")#text(" on ")#mi("{Y}")#text(", we have")

#tao-aligned(keep: true)[


#tao-math("\\left\\| T^* g \\right\\|_{L^{p^{\\prime}}(X)}^{p^{\\prime}}  & = \\langle (T^* g)^{p^{\\prime}-1}, T^* g \\rangle = \\langle T (T^* g)^{p^{\\prime}-1}, g \\rangle", block: true)



#tao-math(" & \\leq \\left\\|T\\right\\|_{op} \\left\\|(T^* g)^{p^{\\prime}-1}\\right\\|_{L^p(X)} \\left\\|g\\right\\|_{L^{p^{\\prime}}(Y)}", block: true)



#tao-math(" & = \\left\\|T\\right\\|_{op} \\left\\|T^* g \\right\\|_{L^{p^{\\prime}}(X)}^{p^{\\prime}-1} \\left\\|g\\right\\|_{L^{p^{\\prime}}(Y)};", block: true)
]

#text("by ")#link(<tao-c5419f8b099324d31350>)[#text("(1)")]#text(" and Hölder; dividing out by ")#tao-math("{\\left\\|T^* g \\right\\|_{L^{p^{\\prime}}(X)}^{p^{\\prime}-1}}", block: false)#text(" we obtain ")#tao-math("{\\left\\|T^*\\right\\|_{op} \\leq \\left\\|T\\right\\|_{op}}", block: false)#text(", and a similar argument also recovers the reverse inequality.")

#text("The first argument also extends to some extent to multilinear operators. For instance if one has a bounded bilinear operator ")#mi("{B: L^p(X) \\times L^q(Y) \\rightarrow L^r(Z)}")#text(" for ")#mi("{1 < p,q,r < \\infty}")#text(" then one can then define adjoint bilinear operators ")#mi("{B^{*1}: L^q(Y) \\times L^{r^{\\prime}}(Z) \\rightarrow L^{p^{\\prime}}(X)}")#text(" and ")#mi("{B^{*2}: L^p(X) \\times L^{r^{\\prime}}(Z) \\rightarrow L^{q^{\\prime}}(Y)}")#text(" obeying the relations")

#align(center)[#tao-fit-display[#mitex("\\langle B(f, g),h \\rangle = \\langle B^{*1}(g,h), f \\rangle = \\langle B^{*2}(f,h), g \\rangle")]]

#text("and with exactly the same operator norm as ")#mi("{B}")#text(". It is also possible, formally at least, to adapt the Hölder inequality argument to reach the same conclusion.")

#text("In this paper we observe that the Hölder inequality argument can be modified in the case of Brascamp-Lieb inequalities to obtain a different type of adjoint inequality. (Continuous) Brascamp-Lieb inequalities take the form")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} \\prod_{i=1}^k f_i^{c_i} \\circ B_i \\leq \\mathrm{BL}(\\mathbf{B},\\mathbf{c}) (\\prod_{i=1}^k \\int_{{\\bf R}^{d_i}} f_i)^{c_i}")]]

#text("for various exponents ")#mi("{c_1,\\dots,c_k}")#text(" and surjective linear maps ")#mi("{B_i: {\\bf R}^d \\rightarrow {\\bf R}^{d_i}}")#text(", where ")#mi("{f_i: {\\bf R}^{d_i} \\rightarrow {\\bf R}}")#text(" are arbitrary non-negative measurable functions and ")#mi("{\\mathrm{BL}(\\mathbf{B},\\mathbf{c})}")#text(" is the best constant for which this inequality holds for all such ")#mi("{f_i}")#text(". [There is also another inequality involving variances with respect to log-concave distributions that is also due to Brascamp and Lieb, but it is not related to the inequalities discussed here.] Well known examples of such inequalities include Hölder’s inequality and the sharp Young convolution inequality; another is the Loomis-Whitney inequality, the first non-trivial example of which is")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^3} f(y,z)^{1/2} g(x,z)^{1/2} h(x,y)^{1/2}")]]

#metadata(none) <tao-07ca1b132652ec4d9163>#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\leq (\\int_{{\\bf R}^2} f)^{1/2} (\\int_{{\\bf R}^2} g)^{1/2} (\\int_{{\\bf R}^2} h)^{1/2}")]]

#text("for all non-negative measurable ")#mi("{f,g,h: {\\bf R}^2 \\rightarrow {\\bf R}}")#text(". There are also discrete analogues of these inequalities, in which the Euclidean spaces ")#mi("{{\\bf R}^d, {\\bf R}^{d_i}}")#text(" are replaced by discrete abelian groups, and the surjective linear maps ")#mi("{B_i}")#text(" are replaced by discrete homomorphisms.")

#text("The operation ")#mi("{f \\mapsto f \\circ B_i}")#text(" of pulling back a function on ")#mi("{{\\bf R}^{d_i}}")#text(" by a linear map ")#mi("{B_i: {\\bf R}^d \\rightarrow {\\bf R}^{d_i}}")#text(" to create a function on ")#mi("{{\\bf R}^d}")#text(" has an adjoint ")#emph[#text("pushforward map")]#text(" ")#mi("{(B_i)_*}")#text(", which takes a function on ")#mi("{{\\bf R}^d}")#text(" and basically integrates it on the fibers of ")#mi("{B_i}")#text(" to obtain a “marginal distribution” on ")#mi("{{\\bf R}^{d_i}}")#text(" (possibly multiplied by a normalizing determinant factor). The adjoint Brascamp-Lieb inequalities that we obtain take the form")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^p({\\bf R}^d)} \\leq \\mathrm{ABL}( \\mathbf{B}, \\mathbf{c}, \\theta, p) \\prod_{i=1}^k \\left\\|(B_i)_* f \\right\\|_{L^{p_i}({\\bf R}^{d_i})}^{\\theta_i}", block: true)]]

#text("for non-negative ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" and various exponents ")#mi("{p, p_i, \\theta_i}")#text(", where ")#mi("{\\mathrm{ABL}( \\mathbf{B}, \\mathbf{c}, \\theta, p)}")#text(" is the optimal constant for which the above inequality holds for all such ")#mi("{f}")#text("; informally, such inequalities control the ")#mi("{L^p}")#text(" norm of a non-negative function in terms of its marginals. It turns out that every Brascamp-Lieb inequality generates a family of adjoint Brascamp-Lieb inequalities (with the exponent ")#mi("{p}")#text(" being ")#emph[#text("less")]#text(" than or equal to ")#mi("{1}")#text("). For instance, the adjoints of the Loomis-Whitney inequality ")#link(<tao-07ca1b132652ec4d9163>)[#text("(2)")]#text(" are the inequalities")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{L^p({\\bf R}^3)} \\leq \\left\\| (B_1)_* f \\right\\|_{L^{p_1}({\\bf R}^2)}^{\\theta_1} \\left\\| (B_2)_* f \\right\\|_{L^{p_2}({\\bf R}^2)}^{\\theta_2} \\left\\| (B_3)_* f \\right\\|_{L^{p_3}({\\bf R}^2)}^{\\theta_3}", block: true)]]

#text("for all non-negative measurable ")#mi("{f: {\\bf R}^3 \\rightarrow {\\bf R}}")#text(", all ")#mi("{\\theta_1, \\theta_2, \\theta_3>0}")#text(" summing to ")#mi("{1}")#text(", and all ")#mi("{0 < p \\leq 1}")#text(", where the ")#mi("{p_i}")#text(" exponents are defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} (1-\\frac{1}{p}) = \\theta_i (1-\\frac{1}{p_i})")]]

#text("and the ")#mi("{(B_i)_* f:{\\bf R}^2 \\rightarrow {\\bf R}}")#text(" are the marginals of ")#mi("{f}")#text(":")

#tao-aligned(keep: true)[


#tao-math("(B_1)_* f(y,z)  & := \\int_{\\bf R} f(x,y,z)\\ dx", block: true)



#tao-math("(B_2)_* f(x,z)  & := \\int_{\\bf R} f(x,y,z)\\ dy", block: true)



#tao-math("(B_3)_* f(x,y)  & := \\int_{\\bf R} f(x,y,z)\\ dz.", block: true)
]

#text("One can derive these adjoint Brascamp-Lieb inequalities from their forward counterparts by a version of the Hölder inequality argument mentioned previously, in conjunction with the observation that the pushforward maps ")#mi("{(B_i)_*}")#text(" are mass-preserving (i.e., they preserve the ")#mi("{L^1}")#text(" norm on non-negative functions). Conversely, it turns out that the adjoint Brascamp-Lieb inequalities are only available when the forward Brascamp-Lieb inequalities are. In the discrete case the forward and adjoint Brascamp-Lieb constants are essentially identical, but in the continuous case they can (and often do) differ by up to a constant. Furthermore, whereas in the forward case there is a ")#link("https://mathscinet.ams.org/mathscinet/article?mr=1069246")[#text("famous theorem of Lieb")]#text(" that asserts that the Brascamp-Lieb constants can be computed by optimizing over gaussian inputs, the same statement is only true up to constants in the adjoint case, and in fact in most cases the gaussians will fail to optimize the adjoint inequality. The situation appears to be complicated; roughly speaking, the adjoint inequalities only use a portion of the range of possible inputs of the forward Brascamp-Lieb inequality, and this portion often misses the gaussian inputs that would otherwise optimize the inequality.")

#text("We have located a modest number of applications of the adjoint Brascamp-Lieb inequality (but hope that there will be more in the future):")

#list(
[#text("The inequalities become equalities at ")#mi("{p=1}")#text("; taking a derivative at this value (in the spirit of the ")#link("https://en.wikipedia.org/wiki/Replica_trick")[#text("replica trick")]#text(" in physics) we recover the ")#link("https://mathscinet.ams.org/mathscinet/article?mr=2545242")[#text("entropic Brascamp-Lieb inequalities of Carlen and Cordero-Erausquin")]#text(". For instance, the derivative of the adjoint Loomis-Whitney inequalities at ")#mi("{p=1}")#text(" yields ")#link("https://en.wikipedia.org/wiki/Shearer%27s_inequality")[#text("Shearer’s inequality")]#text(".")],
[#text("The adjoint Loomis-Whitney inequalities, together with a few more applications of Hölder’s inequality, implies the log-concavity of the ")#link("https://en.wikipedia.org/wiki/Gowers_norm")[#text("Gowers uniformity norms")]#text(" on non-negative functions, which was previously observed ")#link("https://mathscinet.ams.org/mathscinet/article?mr=3262281")[#text("by Shkredov")]#text(" and ")#link("https://mathscinet.ams.org/mathscinet/article?mr=3685112")[#text("by Manners")]#text(".")],
[#text("Averaging the adjoint Loomis-Whitney inequalities over coordinate systems gives reverse ")#mi("{L^p}")#text(" inequalities for the ")#link("https://en.wikipedia.org/wiki/X-ray_transform")[#text("X-ray transform")]#text(" and other tomographic transforms that appear to be new in the literature. In particular, we obtain some monotonicity of the ")#mi("{L^{p_k}}")#text(" norms or entropies of the ")#mi("{k}")#text("-plane transform in ")#mi("{k}")#text(" (if the exponents ")#mi("{p_k}")#text(" are chosen in a dimensionally consistent fashion).")]
)

#text("We also record a number of variants of the adjoint Brascamp-Lieb inequalities, including discrete variants, and a reverse inequality involving ")#mi("{L^p}")#text(" norms with ")#mi("{p>1}")#text(" rather than ")#mi("{p<1}")#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37fd38d34a03039bb617ba181cf93ea989bae6b779c1ce12d58c92f69c07ef15-0211384ebdbc557380105c97392e2e26f7b9fc834921e4cab650c2f0e9d14000.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adj")]], [#link("https://terrytao.wordpress.com/2023/06/29/adjoint-brascamp-lieb-inequalities/#comment-679163")[#strong[#text("adj")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2023")])]

#text("amazing adjoints")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/29/adjoint-brascamp-lieb-inequalities/#comment-679167")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2023")])]

#text("Hi Terry. Love your blog. I want to ask though, why are you linking to mathscinet papers? That severely limits accessibility.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/06/29/adjoint-brascamp-lieb-inequalities/#comment-679202")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2023")])]

#text("This appears to be a recent change on mathscinet’s end. I would be open to suggestions for alternatives (in particular, a comparison with Zentralblatt or with doi).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/29/adjoint-brascamp-lieb-inequalities/#comment-679172")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2023")])]

#text("Is it true that whenever the adjoint and forward constants are the same (in some sense indicating “no loss of information”) than the adjoint inequalities are also optimized by gaussians?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/06/29/adjoint-brascamp-lieb-inequalities/#comment-679201")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2023")])]

#text("Actually, we found that in all non-degenerate cases that gaussians do *not* extremize the adjoint inequality; see Theorem 6.1. For instance, the adjoint Loomis-Whitney inequality is not optimized by gaussians, but instead by indicator functions of boxes (or more generally, Cartesian products ")#mi("E_1 \\times E_2 \\times E_3")#text("). This is despite the Loomis-Whitney inequality being optimized by gaussians (and with no loss in passing back and forth between the forward and adjoint inequalities). What seems to be going on here is that in order for gaussians to be good test functions for the forward inequality, the ")#mi("k")#text(" gaussians ")#mi("f_1,\\dots,f_k")#text(" have to be related to each other in a very specific way; but for the adjoint inequality there is only one input ")#mi("f")#text(" and the dual functions ")#mi("f_1,\\dots,f_k")#text(" associated to that input are unlikely to obey this specific relation even if ")#mi("f")#text(" is gaussian.")

#text("For the discrete analogues of these inequalities the situation is different; for both the forward and adjoint inequalities, indicator functions of subspaces serve as extremizers (Theorem 1.14).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a00d5244293c706eb81f8574ca9edee429b1bf2f7d1c3498615faa920a99d6ac-1be71940e14ee58e26960f36b5c21d09d18a410dfc6d1b76c4f1e416fd0f3fbf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of s")]], [#link("https://terrytao.wordpress.com/2023/06/29/adjoint-brascamp-lieb-inequalities/#comment-679235")[#strong[#text("s")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2023")])]

#text("Splundiferous")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c9d2eb616715a2a292eb82edda0bf8ab1160278f8a6d133666a5008f52ade62-57686ace458bea2c842086a688838af7dfbe5226f073093bcc21d274e289f42d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of XG")]], [#link("https://terrytao.wordpress.com/2023/06/29/adjoint-brascamp-lieb-inequalities/#comment-679327")[#strong[#text("XG")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2023")])]

#text("Great results! Small thing: in the early derivation right after “Then for any reasonable function”, I think that one should replace q by p’.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quadratini Loacker")]], [#link("https://terrytao.wordpress.com/2023/06/29/adjoint-brascamp-lieb-inequalities/#comment-679400")[#strong[#text("Quadratini Loacker")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2023")])]

#text("A small typo: Cordero-Erausquin instead of Cordero-Erasquin.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/245a27f3a461760e6311211106253be6e0293e534bff6f51f965d3bd3d0637e9-96e99a9fe9f43c8d6e868c6c3123ee36868b355ed796af022da8117a2d1fe1a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Courtade")]], [#link("https://terrytao.wordpress.com/2023/06/29/adjoint-brascamp-lieb-inequalities/#comment-679454")[#strong[#text("Tom Courtade")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2023")])]

#text("Unless I’m mistaken, a simple observation is that the adjoint BL inequality can be restated in terms of Rényi entropies, in a way that parallels the Cordero–Erausquin dual formulation of the BL inequalities. Namely, for a random vector ")#mi("X")#text(" with density ")#mi("f")#text(", the adjoint BL inequality is equivalently restated as")

#mi("h_p(X) \\leq \\sum_i c_i h_{p_i}(B_i X) + C")

#text("for a suitable constant ")#mi("C = C(B,c,\\theta,p)")#text(", where $h_p$ denotes the Rényi entropy of order ")#mi("p")#text(". As ")#mi("h_p")#text(" tends to Shannon entropy as ")#mi("p\\to 1")#text(", the connection to the Cordero–Erausquin entropic formulation of BL is fairly transparent.")

#text("This rewriting of the adjoint BL inequality also suggests what other “reverse” formulations of the adjoint BL inequality might look like (Question 10.8 in your paper), since we know their dual entropic formulations. For instance, just based on pattern matching, one might conjecture the analogue to Barthe’s inequality would look something like this: For ")#mi("X_i\\sim f_i")#text(" random vectors on ")#mi("\\mathbb{R}^{d_i}")#text(", do we have")

#mi("\\sum_i c_i h_{p_i}(X_i)  \\leq \\sup_{\\pi} h_p(\\sum_i c_i B_i^* X_i) + C")#text(",")

#text("where the sup is over all couplings of the ")#mi("X_i")#text("‘s? Taking ")#mi("p\\to 1")#text(" would recover Barthe’s inequality.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/06/29/adjoint-brascamp-lieb-inequalities/#comment-679543")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2023")])]

#text("Nice observation! We will add this to the next revision of the ms.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JojoPizza")]], [#link("https://terrytao.wordpress.com/2023/06/29/adjoint-brascamp-lieb-inequalities/#comment-679911")[#strong[#text("JojoPizza")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2023")])]

#text("Terence tao We need you in the field of Geometric complexity theory. Please contribute your time to advance this important field.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cd754b155202b1d1f5814c9d740f96da39a787c58e6e29663aee7bf26ee7b42-e831e481c3d4d6e6848e14f6a4a300dcf12aca8a11b97bcaecb9060a6fcf84d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Pritchard")]], [#link("https://terrytao.wordpress.com/2023/06/29/adjoint-brascamp-lieb-inequalities/#comment-680419")[#strong[#text("Paul Pritchard")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2023")])]

#text("Small typo: “various” should be “variants” in the last sentence.")#linebreak()#text(" ")#emph[#text("[Corrected, thanks – T.]")]
]
