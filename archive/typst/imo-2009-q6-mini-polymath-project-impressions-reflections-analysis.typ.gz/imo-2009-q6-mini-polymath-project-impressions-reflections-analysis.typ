// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/
// Converted to Typst by tao2typ: "2026-10-14T16:35:49.463627+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "IMO 2009 Q6 mini-polymath project: impressions, reflections, analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("IMO 2009 Q6 mini-polymath project: impressions, reflections, analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 July 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/")[#text("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The mini-polymath project to find solutions to Problem 6 of the 2009 IMO is ")#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/")[#text("still ongoing")]#text(", but I thought that, while the memories of the experience are still fresh, it would be a good time to open a parallel thread to collect the impressions that participants and observers had of how the project was conducted, how successful it was, and how it (or future projects) could be made to run more smoothly.")

#text("Just to get the ball rolling, here are some impressions I got as a (rather passive) moderator:")

#enum(start: 1, 
[#strong[#text("There is no shortage of potential interest in polymath projects.")]#text(" I was impressed by how the project could round up a dozen interested and qualified participants in a matter of hours; this is one particular strength of the polymath paradigm. Of course, it helped that this particular project was elementary, and was guaranteed to have an elementary (and relatively short) solution. Nevertheless, the availability of volunteers does bode well for future projects of this type.")],
[#strong[#text("A wiki needs to be set up as soon as possible.")]#text(" The ")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("wiki for polymath1")]#text(" was an enormously valuable resource, once it was set up. I had naively thought that the mini-polymath1 project would be short enough that a wiki was not necessary, but now I see that it would have come in handy for organising and storing the arguments, strategies, insights, and ideas that arose through the linear blog thread format, but which was difficult to summarise in that format. (I have belatedly set a wiki for this project up ")#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2009_q6")[#text("here")]#text(".) For the next polymath project (I have none planned yet, but can imagine that one would eventually arise), I will try to ensure a wiki is available early on.")],
[#strong[#text("There is an increasing temptation to work offline as the project develops.")]#text(" In the rules of the polymath projects to date, the idea is for participants to avoid working “offline” for too long, instead reporting all partial progress and thoughts on the blog and/or the wiki as it occurs. This ideal seems to be adhered to well in the first phases of the project, when the “easy” but essential observations are being made, and the various “low-hanging fruits” are harvested, but at some point it seems that one needs to do more non-trivial amounts of computation and thought, which is still much easier to do offline than online. It is possible that future technological advances (e.g. the concurrent editing capabilities of platforms such as ")#link("https://terrytao.wordpress.com/2009/05/29/google-wave/")[#text("Google Wave")]#text(") may change this, though; also a culture and etiquette of collaborative thinking might also evolve over time, much as how mathematical research has already adapted to happily absorb new modes of communication, such as email. In the meantime, though, I think one has accommodate both online and offline modes of thinking to make a polymath project as successful as possible, avoiding degeneration into a mass of low-quality observations on one hand, and a fracturing into isolated research efforts on the other.")],
[#strong[#text("Without leadership or organisation, the big picture can be obscured by chaos.")]#text(" As I was distracted by other tasks (for instance, flying from Bremen back to Los Angeles), and had already known of a solution to the problem, I adopted a laissez faire attitude to task of moderating the project. This worked to some extent, and there was certainly no shortage of ideas being tossed back and forth, arguments being checked and repaired, etc., but I think that with more active moderation, one could have had a bit more focus on longer-term strategy and vision than there was. Perhaps in future projects one could be more explicit in the rules about encouraging this sort of perspective (for instance, in encouraging periodic summaries of the situation either on the blog or on the wiki).")],
[#strong[#text("Polymath projects tend to generate multiple solutions to a problem, rather than a single solution.")]#text(" A single researcher will tend to focus on only one idea at a time, and is thus generally led to just a single solution (if that idea ends up being successful); but a polymath project is more capable of pursuing several independent lines of attack simultaneously, and so often when the breakthrough comes, one gets multiple solutions as a result. This makes it harder to do direct comparison of success between polymath projects and individual efforts; from the (limited) data points available, I tentatively hypothesise that polymath projects tend to be slower, but obtain broader and deeper results, than what a dedicated individual effort would accomplish.")],
[#strong[#text("Polymath progress is both very fast and very slow. ")]#text("I’ve noticed something paradoxical about these projects. On the one hand, progress can be very fast in the sense that ideas get tossed out there at a rapid rate; also, with all the proofreaders, errors in arguments get picked up much quicker than when only one mathematician is involved. On the other hand, it can take a while for an idea or insight obtained by one participant to be fully absorbed by the others, and sometimes the key observation can be drowned out by a large number of less important observations. The process seems somewhat analogous to that of evolution and natural selection in biology; consider for instance how the meme of “try using induction”, which was the ultimately successful approach, had to first fight among competing memes such as “try using contradiction”, “try counting arguments”, “try topological arguments on the cube”, etc., before gaining widespread acceptance. In contrast, an individual might through luck (or experience) hit upon the right approach (in this case, induction) very early on and end up with a solution far quicker than a polymath effort; conversely, he or she may select the wrong approach and end up wasting far more time than a polymath would.")],
[#strong[#text("The wordpress blog format is adequate, but far from ideal.")]#text(" Technical problems (most notably, the spam filter, the inability to preview or edit comments [except by myself], and the (temporary) lack of nesting and automatic comment numbering) made things more frustrating and clunky than they should be. Adding the wiki helps some of the problems, but definitely not all, especially since there is no integration between the blog and the wiki. But the LaTeX support included in the WordPress blog is valuable, even if it does act up sometimes. Hopefully future technologies will provide better platforms for this sort of thing. (As a temporary fix, one might set up some dedicated blog (or other forum) for polymath projects with customised code, rather than relying on hosts.)")]
)

#metadata(none) <tao-f057d9ad07a460347579>

#text("<swolpert@support.ucla.edu>")

#heading(level: 1)[#text("Comments (65)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-2/#comment-502534")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2018")])]

#text("I think the idea of mini polymath is really fantastic and think we can continue it more with other problems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40569")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("I think part of the problem with the filter is that there were a lot of people who weren’t aware it was there and lost posts that way.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mouse")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40574")[#strong[#text("Mouse")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("Do you still need automatic numbering if you have threading? A livejournal, or a livejournal community, might be an easy solution to some of the technical issues you brought up, though I don’t know if you can get automatic numbering. A possible issue is that lj is really set up to be used by people with lj accounts, though signing up is free etc., and anonymous commenting is available.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40579")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("1. In aggregate, a carefully written post will save the community a lot of time. I spent a lot of time trying to work through hastily written arguments. Of course, I imagine that there were others out there working through these same arguments. It is much more efficient for the author of a post to spend an extra 2 or 3 minutes proofreading, than it is for a dozen community members to spend 10 minutes working through an argument obscured by typos. Of course, the emphasis here is on the presentation of the idea, and not the idea itself. Certainly the rapid dissemination of all ideas is the spirit of polymath.")

#text("2. Proposed proofs should be quickly checked and either certified as correct or flawed. I would often find that a proposed proof was made and ignored (or, more precisely, not commented on). In these cases it was unclear if other community members had read and dismissed them, or if they just hadn’t been studied closely. Most likely, this results in multiple community members expending a lot of resources repeating the same verification process (this is not to say there isn’t value in reading a flawed proof). Additionally, a claim that a proposed proof is flawed should be accompanied by a clear explanation of the issue.")

#text("3. It would be useful to have a mechanism for identifying good ideas. Often I saw what I considered a good idea get buried in between a thread of unrelated posts. It would be helpful if there was a way of drawing attention to these. One idea would be to have a ranking system on the posts where users give quick feedback on the idea in a posts (similar to YouTube’s rating system). Of course, it would be delicate to implement this without hurting the feelings of participants. One can always just say “I think post 123 was a really good idea, we should try to develop this approach,” but it seems hard to do this without appearing pushy.")

#text("3. Leadership is needed. Part of the appeal of a polymath project is that it is a voluntary enterprise and trying to force too much structure would probably ruin the fun of it. However, I felt that often a promising developing thread of ideas would be quickly drowned out by an unrelated discussion. Here, it would have been helpful for someone to urge the community to continue exploring an idea, however it seems very difficult to do this without appearing pushy. As a logistical matter, it would probably also be useful to physically separate discussions of unrelated approaches (after they are well developed) to avoid the impression that an approach is dead just because no one has commented on it in the past 10 posts.")

#text("4. Of course, the most frustrating aspects were related to the medium (specifically the spam filter, inability to edit comments, etc) however these have already been addressed above.")

#text("Lastly, I would like to the opportunity to advocate another polymath project. As this project demonstrated, there is a lot of interested and capable participants for another polymath project. I think there was a lot of interest in the first project, however the barrier to entry was very high. Most of the contributors that “made it to the end” of DHJpolymath1 were distinguished mathematicians (of course there is a chicken and egg argument here) the majority of which had previously published density Ramsey results! This has been extensively discussed elsewhere, so I won’t belabor the point. I do think it would be possible to find a topic that (1) is both interesting and significant, (2) has a (relative) lower barrier of entry, and (3) has a reasonable chance of succeeding. Of course, I am making the case here, instead of starting the endeavor myself, as I imagine that it would be difficult to attract a critical amount of interest without the “star power” that you or Tim have.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21f981115eac23de64b0e57c9b310ac1a594a81242e2a7e7141f394cac10458f-62196923690a4a2e62fd0b0bbed8d60ae479c394bd19e7c6bea25a289fcbc9c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Moskovich")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40580")[#strong[#text("Daniel Moskovich")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("The main issue for me, and many other people I think, was simply that we missed it… it would help to know that there is a polymath problem coming up in x days, with x>2, even without knowing what the problem is, simply to know to be online when the problem comes out…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rweba")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40581")[#strong[#text("Rweba")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("Yes, I think some higher level organization would have been helpful (e.g. summarizing the current progress). Wiki should be helpful with this. Also automatic comment numbering would be good.")

#text("I second Daniel’s suggestion for say a week’s advance notice for the next one (perhaps starting on a Friday night to max participation? just an idea).")

#text("Although as far finding a problem that is (1) Significant (2) has low barriers to entry and (3) has a high chance of success, I don’t know how easy that is.")

#text("One idea is to try and pick a problem which is very “modular” i.e so different people can work in parallel on different parts and then try and “stitch” the results together. Of course this would require some coordination to break the problem up and coordinate the effort.")

#text("Looking forward to the next one!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40583")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("I have been thinking that a phpBB forum is probably the kind of technique one might want to use for Polymath projects?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 关于IMO Q6数学实验的总结 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40584")[#strong[#text("关于IMO Q6数学实验的总结 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("[…] 在总结的帖子中，Tao谈到这三天来他所看到的讨论的结果，总结为下面几点。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1d42168f0d29b83519498d6b15cefab628ea4102e81dfab59d17660cf095f12-e51bf28cb5cd6ba395b6e395f3dd9ac80cd20f708c7203de4e889ab0fa7d8a33.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Stacey")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40585")[#strong[#text("Andrew Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("Regarding forum software, then ")#link("http://bbpress.org/")[#text("bbpress")]#text(" is designed by the same team behind wordpress and has a level of integration with wordpress. It also has a LaTeX plugin which is based on the ones for wordpress so mathematics wouldn’t be a problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/914c459b8303f733c97b8f66e20143119e90f2997df4fece3560d18191db8f9d-9f9352973d40fb7977c9ca267e25b7e5047d2278800b2a73809480cc7c7b0609.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a.s.")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40587")[#strong[#text("a.s.")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text(". The first proof wasn’t, at least locally, a polymath idea (essentially, brumm gave the entire and original proof at once). On a global level, however, it can be viewed as emerged from a polymath approach — it was build upon a faulty argument spotted somewhere else. The second argument (Curioso et al) emerged locally in a polymath manner. So, IMHO, Polymath has passed his IMO test.")

#text(". This may sound trivial, but I think two separated polymaths are less efficient than one bigger project (cf. the story of the first proof). Tree-like development of the discussion needs many eyeballs. A sort of centralizing efforts in one place would be useful.")

#text(". A blog is a good place to start with, but some structure of discussion(s) and some leadership is badly needed. Starting from message #100, say, I had to devote more time to understand the present thinking, than to actually work on an idea. Well, maybe it’s just me. But, generally, with the abundance of information either you put much effort in simple reading or it turns into an individual research.")

#text(". A hypothetical platform for polymath project could take advantage of a tree structure. After an initial unstructured brainstorming and collecting “low hanging fruits” some basic threads could be constructed (one thread per idea). Further bifurcation should be allowed. Each “path” could be accompanied by an evolving abstract to give a quick access to the present thinking.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40590")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("I found the temptation to work off line to be very frustrating, starting around comment 120 or so. If this had been a problem that mattered to my research, I would have turned off the computer and headed out to a coffee shop for a few hours of quiet and thought. (Since this was actually a form of procrastination, it’s probably better that I didn’t!) For larger polymaths, the norms of etiquette should be sure to permit this sort of off line work, as long as we bring our ideas back to the forum.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40605")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("David,")

#text("Indulging in a bit of long-term and possibly wishful thinking, one might imagine a future in which everyone’s preferred working notebook environment could be integrated into the project. Each participant might have a personal working sandbox they could experiment in, with the option of promoting salient observations to the main discussion. I think it’d be necessary to be careful to avoid this turning into everyone working in private.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rweba")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40591")[#strong[#text("Rweba")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("I like a.s.’s idea of a separate thread for each approach. This should make the discussion much more coherent.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/914c459b8303f733c97b8f66e20143119e90f2997df4fece3560d18191db8f9d-9f9352973d40fb7977c9ca267e25b7e5047d2278800b2a73809480cc7c7b0609.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a.s.")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40595")[#strong[#text("a.s.")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("Thanks for kind words. Quite a novice here, I’ve just found that the polymath1 project has been using something along these lines for a while…")#linebreak()#text(" see e.g. ")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page#Threads_and_further_problems")[#text("http://michaelnielsen.org/polymath1/index.php?title=Main_Page#Threads_and_further_problems")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phil")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40597")[#strong[#text("Phil")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("I might not have the best perspective for the grand scheme of things, but it seems like Polymath can only work as it is supposed to if, basically, there are not very many Polymath projects alive at any given point in time (relative to the number of potentially interested participants). For example, you could imagine there being one to three each week released to, say, the entire mathematical community. — Which problem(s) would have to be determined by a centralized process which understands what Polymath is or is not good at and has general interest in this kind of thing. — But I would imagine these problems being a subject of conversation at tea, for example, provided there are few enough.")

#text("Overall it seems like there needs to be some kind of centralized entity (similar to a government) which deals with some aspects of polymath — if you let just about anyone start a polymath project, I don’t think you will end up with much polymath at all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40603")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("A few observations:")

#text("1. I was disappointed to find that I’d missed the project entirely, simply because I hadn’t checked my RSS reader for a week. When I did (last night) I found that not only had the project been started, in fact it seemed likely that a solution had already been found.")

#text("2. It may be worth changing the wiki so the main page is no longer so focused on the DHJ Project, but points to “Main pages” for multiple Polymath Projects, as well as information of general interest for Polymath Projects. I’d make the change myself, but I’m a bit reluctant to do so unilaterally. I’ll think about it a bit more, and may post a note on the Main talk page of the wiki.")

#text("3. Point 4 (on leadership) reminds me of an observation I’ve heard people make about open source software: it requires people with considerable skills as leaders to function well, and that these qualities are perhaps not quite the same as the traditional programmer stereotype. It’s intriguing to wonder whether the same pattern might eventually be seen in open source mathematics.")

#text("4. Regarding point 7 (on the collaborative software used) the issue tracking software used in open source software development does a great job of modularizing discussion around subproblems, effectively lowering the barrier to entry for later participants. See, e.g., ")#link("http://bugzilla.mozilla.org")[#text("http://bugzilla.mozilla.org")]#text(" It unfortunately lacks the strong narrative feel that the blog format seems to enable, but that’s often provided by a mailing list that runs concurrently.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40606")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("Let me clarify one point: I don’t think software like Bugzilla would necessarily be quite suitable for future Polymath Projects. The lack of decent LaTeX integration is a real problem. But issue tracking software is a pattern that has been tremendously useful in open source software, and it may be a good starting point for thinking about software for running Polymath Projects.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40608")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("Regarding incorporating off line work — when collaborating with others, I often send e-mails 1-3 times a day saying what I’ve tried so far, and what successes I’ve had. This is not only helpful for keeping my partners informed, but it creates a great record for myself. I see no reason why that approach (replacing e-mail with wiki editing or whatever) wouldn’t work for a polymath.")

#text("Michael Nielsen, above, suggests making my notebooks world readable instead. I don’t like that idea. I think I’d spend a lot of time trying to clean up my notes and improve my presentation when I needed to just get started.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2622b45187041ef83daa956a28337eddcfd1afa39db168c2216ed73d9c0172a1-c3b52b6d03226a653b9e2010337b44e6ed351e9d49b4ff4644e975b486639ca6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cartazio")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40609")[#strong[#text("cartazio")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("One idea to consider for future polymath projects is to create dedicated google groups, because then theres a natural means of keeping track of message threading with a tree like visualization, and its easier to keep track of whats new (because of the associated queue of emails that everyone would accrue)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40610")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("One compromise solution for a technological platform would be a dedicated WordPress-like group blog for polymath projects, in which one had multiple authors and editors (basically, anyone involved in the project could sign up as an author or editor), who could each independently set up and moderate threads (and also fish out comments from the spam filter, as needed; one could also hope that a dedicated blog attracts less spam than, say, my blog, which has a reasonable amount of both legitimate and spam traffic). With a customised installation, one could also implement things such as automatic comment numbering, comment preview, and comment editing (and possibly comment rating), and possibly also some ability to integrate with the wiki (not sure exactly how this would work, though). WordPress authors also have the ability to track comments in various threads quite easily from the wordpress dashboard; I suppose one could also use RSS or email updates as well. Perhaps the blog could also have some centralised page that stores all the most recent comments in all the threads in a project at once (possibly ranked by a ratings system), and the ability to reply easily to any one of them.")

#text("Implementing all this seems within the reach of current technology, though I do not know exactly how one would set something like this up.")

#text("@Michael: this project was set up on a whim (after a five-minute conversation with Tim Gowers, who told me about the grasshopper problem on Sunday). But certainly I take your point that there should be some preliminary “advertising” for a project before it is formally launched; I suppose that would also be a good period to solicit volunteer organisers and moderators.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40629")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("This sounds like what’s already been set up at the ")#link("http://www.noncommutative.org/")[#text("n-geometry cafe")]#text(". Is that something like what you were thinking of?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max Baroi")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40728")[#strong[#text("Max Baroi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2009")])]

#text("Dear Dr. Tao,")

#text("I’m interested as to what problems were caused by the lack of integration between the threads and the wiki. I have trouble seeing them in this mini-polymath project, since the solutions were small enough and the problem didn’t require a wide nor deep background that you didn’t really need to exploit the power of a wiki’s organizational structure.")

#text("Thanks for any response.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40734")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2009")])]

#text("The wiki, in early phase, could have been a place to put definitions and concepts and to record progress to date ie as a reference tool for the ongoing discussion- but it wasn’t up early enough to do this. For a simple (relatively) problem people seem to have thrown up a wide variety of apparently intuitive terminology and notation for essentially the same things. This obscures the commonality of many approaches. The wiki deals with essentially two proofs, but one of them comes in four flavours – interestingly different, but based on the same underlying ideas.")

#text("I think that there are three, maybe four, approaches which were suggested and explored – the two which succeeded were inductive in nature: there were also suggestions of a proof by contradiction in various ways (including some form of equivalence). There have also been some comments on using residue classes. A commentary would possibly have helped (though the thread developed so fast that it would have been commentary on basketball rather than cricket).")

#text("There have been suggestions that some of this kind of commentary material might belong on a parallel discussion thread – that’s fine – but the wiki can then be an index, telling participants where to go for information. I think on a longer, more complex project, the wiki could hold definitions which had become common currency, and results/lemmas etc which had been established [Polymath 1 has a thread devoted to the establishment of combinatorial numbers of various kinds. The table of established results belongs, to my mind, on the wiki, with cross-references].")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f58a6fe8e80900cd217f5495a3218d9acd85e5cd977db9fa87967870ef862781-e2c6836262ee65f748346f68b007381932b682cc851bc4e1d0fc0658dba16387.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ramanujantao")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40616")[#strong[#text("ramanujantao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("Dear Terry,")

#text("Why not just set up a “poly-math forum?” For example, set up a v-bulletin forum. And you can have topics that pertain to each project. E.g. like ")#link("http://www.mathhelpforum.com/math-help/")[#text("http://www.mathhelpforum.com/math-help/")]#text(". And we can appoint moderators.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/826a2728424b30ad8cc83000d2bfd8744edcd1bafba060e1c70b63281a0934f6-5e3de4a3d5bde314bee2c1b42ac7f851cee463773970099eaeb046cc61a7dd19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harrison")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40617")[#strong[#text("Harrison")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("One of the striking things that occurred in the DHJ project was using WordPress to track separate research threads in separate comment threads; this is probably one of the major reasons why moderation is useful. An alternative solution to that problem, without high-level moderation, would be a metadata or tagging system for comments, so that, for instance, if you were looking at the induction approach, you could tag your comment “induction;” if you had a comment that was relevant to multiple lines of work, you could give it multiple tags. Unfortunately, of course, WordPress doesn’t have that functionality, and neither (to my knowledge) does any major blogging or bulletin-board platform.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/373599b5c94464690b689f1bb1b063a92a622e8b246e4d8244f22cd741e2abe2-8f643e9e0747242d847da971d7d6a4c5557fd0795c19dcf0d348bac02bc2a6cc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40619")[#strong[#text("Henry")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("Having occasional summaries would indeed be quite useful. I don’t know that they necessarily have to be produced particularly by the organizers of the project, if that’s seen as a violation of the spirit of polymath; I could easily imagine a few different people writing up their own summaries and updating them semi-regularly. (This would have advantages and disadvantages; if too many people were writing poorly written updates, it wouldn’t be much help. But a few people with different perspectives writing good updates might be more useful than just one, and could mean that different people could cover different directions as ideas forked.)")

#text("I also noticed the importance of writing quality. In particular, when people start putting up very sketchy proofs, it became a hard decision whether to try to slog through them in case they were right, or to just ignore them. It’s probably just a matter of social norms (perhaps added by some ability to highlight posts), as people get comfortable with the idea of putting up short thoughts, but still taking the time to write them clearly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40623")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")]

#text("[…] IMO 2009 Q6 mini-polymath project: impressions, reflections, analysis The mini-polymath project to find solutions to Problem 6 of the 2009 IMO is still ongoing, but I thought that, while […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40625")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("Here’s my take. I’m extremely enthusiastic about the polymath idea and was annoyed with myself for not really getting involved in polymath1. This time around I was determined to jump in a little more, and to an extent I did.")

#text("But here’s the problem — it feels somewhat against the spirit of the project to say anything without having read the discussion so far. This is doable when you catch the project just a few hours after posting, as I did. But if you go away from it for half a day, there’s quite a lot to read, enough to be discouraging.")

#text("I guess it’s like this: a polymath project looks like the comment section of a blog post, but it’s not — it’s a collaboration. The comment section of a blog post is something you can check in on occasionally throughout the day, and skim. A collaboration is something to which you devote your day; if you have a research collaborator visiting, you talk to them more frequently than every few hours!")

#text("On the other hand, a polymath project which required some set of participants to commit in advance (if only in their own minds) to set aside a certain day or days to work on it starts to move away from the wiki-style “whoever shows up, lend a hand and build the building” frame of mind that makes polymath so appealing. So I’m not sure I have a good policy recommendation here.")

#text("Did other people have good luck participating in the polymath in the more casual way that didn’t work for me?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40626")[#strong[#text("Pseudo-Polymath » Blog Archive » Thursday Evening Highlights")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")]

#text("[…] With my blog’s name, I had to link this. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40631")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("Responding to JSE’s comment, I have to say that I quickly decided that it would be impossible for me to follow and participate in this impressively fast moving discussion. I thought about this problem on my brief bus ride home on the first day it appeared, and thought it interesting, but then the reality of real life quickly got in the way. My days are already too packed with obligations of various sorts, and I found it difficult to follow this swift flow of ideas on a casual and intermittent basis. The number of comments that appeared within a mere half day is jaw dropping. My largest block of free time is later in the evening, and I generally jealously guard that time for keeping momentum in my own work. Maybe the situation will be different when I retire.")

#text("Anyway, it was quite heartening to see all the enthusiastic participation here, and the interesting social mix of students and professional mathematicians working on a problem together. I’ll bet there’s a big hunger out there by students on summer break for stuff like this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/631b57c510b1e97558c98ce79b699fc120a2a323ae4958ed9424d13c6e5c405c-c26befb15dfbc1f1a6cb15cdddd237e171039be65c91ad3375b11e4835c4912b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40632")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("I have been observing the polymath projects and I think that one convention that it might be useful to adopt is that the author of each numbered comment ought to pick a previous numbered comment as the parent of the comment they are writing.")

#text("The purpose of this is to facilitate the construction of a tree of relationships between comments. A tree could easily be constructed from this information in software like Mathematica for instance.")

#text("This makes it easy for people to figure out the minimum number of posts necessary to understand the current comment. I think this would increase the efficiency with which people can follow arguments and get to a point where they can contribute.")

#text("In practice, to begin a comment 4 which follows from comment 2, I would recommend a notation such as:")

#text("4. 2->4,")

#text("The reason being that one could easily scroll through the comments and copy and paste “2->4,” directly into Mathematica creating a nice tree. During the next polymath I’d be glad to keep track of this for the group and we can see how it turns out. (Anybody with Mathematica can do this.)")

#text("To denote more than one parent comment we could write:")

#text("4. 2->4, 3->4,")

#text("I think we ought to keep this type of thing to minimum however as it might get confusing for long chains of comments. For something like 2->3->4, it’s already sort of implied that 2 is related to 4. We should reserve nodes with two parents to situations where arguments are not already linked in a chain.")

#text("I also propose calling the original post by the blog author as comment 0 and we can say comment 0 is the parent of all comments that represent a new line of thought.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40637")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("I normally find some time over the summer to have a go at the year’s IMO questions. I will never know whether I could have made this work on my own (I normally manage in the end).")

#text("There were various points at which I wanted to get my piece of paper out and work things out, but I managed to restrain myself to half a page of jottings.")

#text("What would have helped in moderation, and is still needed a bit of the Wiki, would be a consistent notation/consistent terminology for the concepts and ideas which emerge as potentially useful.")

#text("I think the threading on bulletin boards might work well for this kind of project.")

#text("Anyway I enjoyed this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/631b57c510b1e97558c98ce79b699fc120a2a323ae4958ed9424d13c6e5c405c-c26befb15dfbc1f1a6cb15cdddd237e171039be65c91ad3375b11e4835c4912b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40638")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("I created an image as an example of the concept. It’s based on a made-up example of comments in a polymath project. It can be found here:")

#link("http://twofoldgaze.files.wordpress.com/2009/07/exampleplot1.gif")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://twofoldgaze.files.wordpress.com/2009/07/exampleplot1.gif?w=490")[Original image]]]]

#text("A further elaboration would be to add labels so we know what each comment adds to what is previously known:")

#link("http://twofoldgaze.files.wordpress.com/2009/07/exampleplot2.gif")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://twofoldgaze.files.wordpress.com/2009/07/exampleplot2.gif?w=490")[Original image]]]]

#text("I think this is good because it gives a really easily read map of what’s going on with the project.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40639")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("As I said on my blog recently, I plan to start a new polymath project in the autumn, and have a shortlist of ten possible projects. At some point I’ll probably make this shortlist public, together with a few preliminary thoughts about each problem. I have some plans that may help with at least some of the worries that have been expressed in the comments here.")

#text("One is that I would like to announce the project quite a long time before actually starting it. This is for two reasons: it makes it less likely that people will find out about it only after there are 200 comments to read, and it gives people a chance to think about the problem in advance. The second of these reasons does not sound as though it is in the polymath spirit, but I see it not as a chance for people to do significant work on the problem, but rather for people to reach a certain starting line that will make it easier to keep up with the discussion.")

#text("A second is that in order to enforce a certain amount of organization, I thought I might have some kind of artificial slowing-down process. For instance, one could alternate between weeks where people make comments and try to hae mathematical ideas, and weeks that are entirely devoted to organizing and clarifying the ideas that have already been had, with much of the activity taking place on the Wiki (but also some on the blog — people could draw attention to interesting ideas that they do not understand and others could make some effort to explain them).")

#text("I’d be interested to know what anyone thinks about the second idea. I haven’t thought too hard about the details, but I think the basic idea of alternating the “exciting” part, where everybody throws out ideas extraordinarily rapidly, with a “reflective” part, where we try to make sure that everybody who wants to understand the important parts of the discussion has a chance to do so, could deal with a lot of the reasons that people have given for non-participation. It has the further advantage that people do not have to make quite such a heavy time-commitment over a short period of time.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e942430ff1257ac41f2cb8b03de7d52203ef174c36ddbff15f615d8ab4914902-8ddc25447f5bfeef892b40ed87c269f9cb4ec46df0a94ba282313a4ca3c594ec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pietro Poggi-Corradini")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40645")[#strong[#text("Pietro Poggi-Corradini")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")])]

#text("The trade-off when one is not supposed to walk off and work on his own for several hours is that a lot more erroneous posts get generated. So a moderator, or other observers, might waste precious time correcting other people’s work (I myself posted a wrong idea on the previous thread). In order to encourage postings in (semi)final form, the moderator could set up a rule where posting a wrong idea disables your ability to comment for say, 10 hours. This would be a more local process of balancing reflective vs. excited.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40654")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")])]

#text("Gowers,")

#text("As others have indicated, I think there is a hunger for another polymath project, and the summer seems to be a time when a lot of people have reduced obligations. Of course, I also understand that you are currently focusing on other projects. Let me suggest that the summer might be a good time to start some of the very preliminary issues. I see two streams of work that might be useful to start sooner rather than latter.")

#text("First, if it is decided that we want to use some modified technological platform that requires some amount of customization, it might be useful to try to find volunteers to implement this before the start of the project. Of course, part of this will need to be deciding what these customizations should be.")

#text("Secondly, it might be a good idea to post one (of the 10) proposals each week for the next 10 weeks (this would bring us into late September). This would force participants to spend some time fully considering each of the ten proposals, instead of just voting for their favorite problem off of a list. Of course, you’d probably want to have ground rules regarding to what extent the problem can be discussed in the comments to these posts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24aa6eda3d315cc448568f86e1a0f49dadc0c942f304ee9f7add66e0fbfae469-2a6726d03342086eed963b20cec2ba1edaed1fc6140a60e8871a820605f41eae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bburcham")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40660")[#strong[#text("bburcham")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")])]

#text("The second idea (slowing down by e.g. specifying focus on alternating weeks) makes me think Michael Nielsen’s comment at ")#link("https://terrytao.wordpress.com/#comment-40603")[#text("https://terrytao.wordpress.com/#comment-40603")]#text(" drawing a parallel with software development. If mathematics could move to more of a team development model, I see no reason why it wouldn’t use an iterative process, with each iteration having a particular (repeated) structure.")

#text("In software we often start a new iteration with a cleanup pass (of the previous iteration’s work product). Since a (software) iteration has defined deliverables, satisfying those (on a time schedule) almost always involves sacrificing some clarity or architectural quality.")

#text("Implicit in this (software) process is the idea that each iteration has objective, measurable goals and a deadline. Those measurable goals are an outcome of leadership (mentioned in the main post and by many commenters). Without leadership or some leadership process there can be no incremental goals.")

#text("This of course does not preclude parallel iteration. In fact, experience in the software world indicates pretty strongly that the number of folks who can work on a “subsystem” at once is limited. So I suspect that some amount of parallelism will be required for social reasons (to keep group size manageable).")

#text("To draw a finer bead, I see a parallel between Tim’s “exciting” and “reflective” phases and mainstream “iterative and incremental” (software) development which has “analysis”, “design”, “implementation”, “testing” and “rework” phases, with analysis and design perhaps mapping to “exciting” and the rest mapping to “reflective” (implementation, testing, rework).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/881129b35acf6b9a3253370c1ec853c923ad4973a05c0709e9f5e82ac2307faa-5f5e2be7d616d800aab509e0afa54c55c512397bf3203f4820d49af68e6ef5ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pablolessa")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40644")[#strong[#text("pablolessa")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")])]

#text("I think a lot of what’s great about polymath is the chaos and rhythm. So I’m not sure I like the idea of artificially slowing it down.")

#text("I’d like to propose a variant of the “comment linking” system proposed above by Kareem Carr. The idea is to ease the burden of keeping up with and navigating the discussion, while maintaining the above mentioned “narrative feel”.")

#text("How about if we make each comment include a set of “Backward” links pointing to two or three of the chronologically closest related comments that appeared before it in time.")

#text("If comment editing is allowed (and I think it should be, but restricted to fixing latex problems and typos), we could also include a set of “Forward” links.")

#text("These link sets would be maintained by the author of the comment. I think this wouldn’t be too much of a burden because the intention is to include only two or three links in each set.")

#text("A typical comment might look like this:")

#text("“325.")

#text("Backward: link1, link2, link3")

#text("main text….")

#text("Forward: link4, link5")#linebreak()#text(" “")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40646")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")])]

#text("Dear Prof Tao and Gowers,")

#text("If you start to discuss basic theorems and concepts in your blogs for example every week one theorem and its applications which appear on mathematical olympiads, it would be perfect for us, students who has passion for math.")

#text("the title could be ” theorem of the week.” if you choose a theorem (for instance mean value theorem) and then give a nice proof for it and explain the crucial parts, blog readers can also contribute by posting some nice questions and solutions.")

#text("in that case we may have chance to see how the leading mathematicians of our time approach questions, how their mind work…")

#text("this is really very valuable for us…")

#text("thank you very much for providing us with your treasure like blogs.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c525dbb80380d49b39d66b3899a94cab193179b50b9b7143ceec37b7536137a2-b99ed5240b84b9fc5ff2d46571833825fd48270c8b1a1b54acda76545b423e48.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bob")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40656")[#strong[#text("Bob")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")])]

#text("A forum or a bulletin board seems more like what you’d want to have, rather than a blog. Alternatively, you could try to set something up with software like dotproject or it’s competitors. I’ve found that’s a great way to collaborate on software projects, and I think you might find that it has a lot of the options you’re looking for.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40659")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")])]

#text("Thanks for all the feedback!")

#text("A couple things. Firstly, as Michael proposed, I reorganised the polymath wiki to link to all current and proposed polymath projects, rather than being focused primarily on polymath1. (It means that the domain name for the wiki is now slightly misleading, but I doubt this will be a serious problem.) It should now be a trivial matter to open up a new sub-page for any new polymath project.")

#text("I can see how the linear, one-thread format of current polymath projects tends to exclude casual observers from participating after the project gets up to full speed; the wiki helps slightly in this regard, but does not fully solve the problem. One possible proposal to ameliorate this difficulty is to have a “three-prong” platform for a polymath project. One prong would be the wiki, containing all the settled knowledge accumulated so far by the project. Another prong would be the “research” thread, containing all the latest ideas (though detailed computations should only be summarised here, with full details placed on the wiki instead). This prong would be primarily for the “full time” participants of the project. The third prong would be a “discussion” thread, which is for the “casual” participants. We would need volunteers to summarise the progress on the research thread at regular intervals and put those summaries on the casual thread, and to respond to questions from observers on those threads. General metacommentary on how best to organise the threads would also go on the discussion thread rather than the research thread. The hope is that the discussion thread will contain many fewer comments than the research thread, and the content of these comments will be more polished than the raw, cutting-edge comments in the research thread. (In a way, this is related to Tim’s proposal to separate the research and reflection phases of the projects, but I propose here to separate those phases in space, instead of in time as in Tim’s suggestion.) The full time participants would be primarily reading (and contributing to) the research thread (and wiki), but also would participate to some extent in the discussion thread, while the casual participants could focus on the discussion thread and only glance at the research thread from time to time.")

#text("Regarding software platforms, I think an improvised platform is still the best choice for now, given that we are still do not fully understand the optimal requirements needed for that platform (and also since improved platforms are in the pipeline). The features which would be particularly desirable would be")

#text("* LaTeX support")#linebreak()#text(" * group moderation")#linebreak()#text(" * comment editing and preview")#linebreak()#text(" * comment numbering and/or threading")#linebreak()#text(" * wiki-like features, i.e. group-editable, publicly-viewable documents with version control")#linebreak()#text(" * Some way to view all recent comments or developments in a project")#linebreak()#text(" * Easy registration process")#linebreak()#text(" * Easy commenting process (i.e. no technological knowledge required)")#linebreak()#text(" * permanent URLs for posts and comments (for link-back purposes)")

#text("Less mandatory, but still potentially useful, would be")

#text("* some way to tag comments (or to give subject headers to comments).")#linebreak()#text(" * some way to rate comments")#linebreak()#text(" * some way to tie comments to specific text in a document (e.g. a key step in a proof on a wiki page).")

#text("I tend to prefer the blog interfaces to the bulletin board or newsgroups interfaces, as I find them a little less cluttered and easier to navigate (I particularly dislike the “Prev 1 2 3 4 … 30 Next” model of navigation). But this could be to some extent due to my own familiarity with blogging. A tree of comments that one could expand and collapse, or jump to, as necessary would be ideal, but I am not sure if there are existing platforms out there that would easily support this sort of thing (while still retaining some sort of compatibility mode for older browsers).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/631b57c510b1e97558c98ce79b699fc120a2a323ae4958ed9424d13c6e5c405c-c26befb15dfbc1f1a6cb15cdddd237e171039be65c91ad3375b11e4835c4912b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40661")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")])]

#text("A wiki is a great way to keep all the information together. One thing it lacks however is an easy way of estimating just how much time investment would be necessary to get up to speed on at least one line of argument (so that one can contribute). In terms of time requirements, if the attitude for a potential participant is ‘I am willing to read as much as is necessary to contribute’ then reading the wiki and the comment thread works. However, if a participant is balancing time invested against other things, it might be useful to have some kind of estimate of how many ideas need to be sorted out before an original idea can be volunteered.")

#text("This is one of the reasons I think some kind of tree diagram can be useful because it says how many steps one has to take to get to a ‘leaf’, that is to get to the forefront of a particular argument. This is much, much less than the total number of comments but a casual reader is the least likely to know this.")

#text("Integrating my suggestion with Terry’s suggestion, I think my scheme would work well for organizing the research thread and I could periodically post updates of the comment diagram in the discussion thread.")

#text("So, I would be interested in volunteering to work on the discussion thread for the next project.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/631b57c510b1e97558c98ce79b699fc120a2a323ae4958ed9424d13c6e5c405c-c26befb15dfbc1f1a6cb15cdddd237e171039be65c91ad3375b11e4835c4912b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40662")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")])]

#text("pablolessa:")

#text("While the refinements you suggested would be helpful if they could be implemented without their disadvantages, I see a few disadvantages which would seem to me prohibitive. Your refinement requires comment authors to be continually vigilant of their post after having written it in order to provide the ‘forward links’ which would in theory concern comments written after a particular comment. If the comment author just has other things to do or is an author of dozens of comments, this would probably not get done. It would also require some editting of past comments which could damage the sense of chronology because it means past comments will continually be subject to change.")

#text("I think the way I have proposed asks a very minimal amount of work from the commenter. They are probably aware of what particular comment they are responding to or elaborating on and it’s something they could put at the top of their post with a few key strokes and forget about.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/881129b35acf6b9a3253370c1ec853c923ad4973a05c0709e9f5e82ac2307faa-5f5e2be7d616d800aab509e0afa54c55c512397bf3203f4820d49af68e6ef5ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pablolessa")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40663")[#strong[#text("pablolessa")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")])]

#text("Kareem Carr: Maybe you’re right and it would be too much overhead. Especially since there are many small comments. I probably got carried away :).")

#text("Whatever the conventions and platforms, I can’t wait for the next polymath project!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40664")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")])]

#text("I would like to comment on Kareem Carr’s idea of displaying tree diagrams. I think that such a capability is especially useful for large works with complex dependencies. I’ve been working for a long time on a LaTeX document that has grown to more than 160 pages and more than 200 lemmas, propositions and theorems, and I’ve discovered that management of the evolution of the document seems to increase in difficulty exponentially with size. Being able to display dependencies graphically would be handy in detecting accidental forward references created by moving things around, things that really should be moved, dead ends that perhaps should be removed, and smoothing of the flow of results in the text. I’ve laboriously mapped out dependencies by hand in certain sections by looking at all the \\ref statements to discover that the dependency tree was a bit of a rats nest, and based on that was able to move things around, combine results, etc., so that the section was easier to read. Of course, software that can automatically construct and display large dependency trees interactively would necessarily be complex and have to be able to do things like minimize cross-overs of arrows.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09dc583105c0582f50498ab92f82b263db613926e5efae8442ec85a796aa65ff-c7a58128ba4c9204ad6ba59afd6b07ca8c5cea1d97e1a0fcc954bcf4a631e5b0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A Student")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40666")[#strong[#text("A Student")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")])]

#text("When I first heard about the concept of these projects I was really excited and interested and wanted to be involved, but so far I have found them discouragingly prohibitive. Several of the factors have already been mentioned and discussed, but the worst offender by far was the blog format of discussions. Though some suggestions have been made to ameliorate these issues, it seems to me they more or less indicate the plethora of flaws in the system without truly addressing them.")

#text("The most prominent example in my mind at the moment is the concept of linking between related comments. This strategy is quite effective if you are interested in a particular idea. It is also essentially taking the long line of threads and folding it so related comments fall next to each other. But a thread of comments so linked is almost the same as taking a forum’s various postings and arranging them temporally. The only missing property is having multiple parents.")

#text("Personally I think these projects are well suited to a forum environment. Stickied topics could provide the problem description, references, idea summaries, while normal topics could encapsulate specific ideas. The notion and duties of moderators are quite natural in that setting. It may have fringe benefits that will improve the process. Private messaging comes to mind, allowing for example self policing without public shaming (as in etiquette, etc). Having seen mathematics at work in such a format (i.e. the math help bulletin board previously mentioned) it seems ideal to me, though I understand reticence seeing as this has been a perfectly good medium to others.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0b7c4aa131da825e9764009116e884e211c7ad7ac8e900e8db59f8a58433fd9-f65738458d08595e2fa6ae7c501d1de7723dbbae59671735eb6c701edecd8b54.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan O'Donnell")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40688")[#strong[#text("Ryan O'Donnell")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2009")])]

#text("When discussing the first project ")#link("http://gowers.wordpress.com/2009/03/10/polymath1-and-open-collaborative-mathematics/#comment-3002")[#text("Gil suggested")]#text(" that each comment post be delayed by a random amount of time (around 12 hours) before appearing. He said he was joking, but actually I think this could be a good idea. It might make things a bit more reflective and less frenetic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40689")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2009")])]

#text("Actually, the spam filter ended up serving as a ")#emph[#text("de facto")]#text(" implementation of this idea… :-) I can’t say that it really worked to improve the flow of the project, though.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40690")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2009")])]

#text("A modification of my week-on week-off idea might be this: if people start to feel that it is important to have a period of reflection and organization of where the project has achieved so far, then the “pure research” part is temporarily halted, but if enough wikification is taking place then that may not be necessary. In Terry’s terminology, the different activities are separated in space, but if the more expository part gets left behind, then it is given a bit of time to catch up. I think something like that could work. But even the limited experience so far suggests that this could be something that varies from project to project.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40703")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2009")])]

#text("Dear Tim,")

#text("I think this might happen naturally if we have the “discussion” thread for exactly this sort of exposition and meta-commentary; if the research thread moves too fast, then presumably we will get comments in the discussion thread from the interested casual participants asking for more explanation of what is going on, and hopefully some of the more active participants will volunteer to explain it all (and perhaps slow down their research activities a notch). We can explicitly encourage participants in the discussion thread to make constructive comments as to the pacing or structure of the project as needed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40708")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2009")])]

#text("Ah — that’s basically what I meant actually, but I’d forgotten about the idea of a discussion thread. So the idea is that we could have the two threads, and temporarily halting the research thread would be an emergency measure to be used only if many people start to complain that they are getting left behind. But the hope would be that every time an idea was put forward that was reasonably concrete and advanced the discussion, there would be a moral obligation on the participants to highlight the idea and present it as clearly as possible. (This does of course raise difficulties, such as the one already mentioned where a good idea can get swamped and have trouble making itself heard.)")

#text("On the subject of ratings, I think it could be quite useful for polymath, but I’d like to see a convention that only positive ratings were given, and that they were given not so much for comments that people liked, but for comments that were judged to be useful ones for people to read if they didn’t want to wade through the whole lot.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40700")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2009")])]

#text("I’ve discovered that WordPress has recently implemented a mechanism to rate posts and comments. I have mixed feelings as to whether this is actually a good thing, but I have decided to turn it on (for comments only) on a provisional basis to demonstrate the feature, given that it could potentially be of use to things such as the polymath projects. I may revisit this decision in a few weeks if such ratings turn out to be counterproductive or not otherwise beneficial. (Currently, I cannot localise the ratings to specific posts; I have to turn it on for the entire blog, or not at all.) Of course, if readers have their own opinions on whether ratings would be desirable, they are welcome to share their thoughts here. (One possibility is to create a dedicated blog for polymath-type projects, which would have the comment ratings, and then to turn ratings off in this current blog.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b80186b23ecd7183baf3997fea0be9728242b29992242075d680bd57d5ecaf5e-c01d0095c1e1fd68ce186085beae7f7aa8012003d8a49df53762ddeb97b4ffff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phi. Isett")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40705")[#strong[#text("Phi. Isett")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2009")])]

#text("In my opinion, it’s probably unfortunate for your blog as a whole to have the ratings in. If there were a polymath discussion blog and posting were public, I wouldn’t have needed to start my own blog in order to host my reply (below) to this post, so I like that idea. Thumbs up.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40701")[#strong[#text("The First Post « A Day in the Life of a Wild Positron")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2009")]

#text("[…] This is a blog which was started on a whim in order to host a very extensive reply to a blog entry of Terence Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40702")[#strong[#text("What Polymath Needs is Wasted Time « A Day in the Life of a Wild Positron")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2009")]

#text("[…] is important); many ideas and issues raised below were scattered within the first 43 comments on this entry of Prof. Tao’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b80186b23ecd7183baf3997fea0be9728242b29992242075d680bd57d5ecaf5e-c01d0095c1e1fd68ce186085beae7f7aa8012003d8a49df53762ddeb97b4ffff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phi. Isett")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40704")[#strong[#text("Phi. Isett")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2009")])]

#text("I have written an extensive reply to the above post and comments which outlines one organizational scheme through which polymath may operate successfully at even a very large scale. Rather than approaching the problem from the paradigm of open-source programming, inspiration is drawn from the successes of massively popular internet services (such as YouTube and Google Groups). The essay pertains to many of the ideas and concerns brought up above, and is therefore too long to contain here.")

#link("http://wildpositron.wordpress.com/2009/07/26/what-polymath-needs-is-wasted-time/")[#text("Here")]#text(" is a link to a (newly constructed) blog containing the reply.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b80186b23ecd7183baf3997fea0be9728242b29992242075d680bd57d5ecaf5e-c01d0095c1e1fd68ce186085beae7f7aa8012003d8a49df53762ddeb97b4ffff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phi. Isett")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40711")[#strong[#text("Phi. Isett")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2009")])]

#text("So far my comment above has received two negative ratings, which is obviously fine. At the same time, there has been no discussion of the various ideas in the essay and just what about them might merit the thumbs down, so I’m afraid that it might be poor advertising earning the unpopularity. I know it verges on bad etiquette, but I’ll try just once to defend my post for fear this might be the case.")

#text("First of all, I see how I could have given the wrong impression that I am suggesting to drop the open-source programming analogy as an approach to the problem. That would be silly — I think everyone sees how profitable the analogy can be, and I nothing to bring to that part of the discussion. I was hoping the ideas and approach in my essay could be married to the approaches taken so far to make an even more robust polymath.")

#text("Second, I apologize that I could not successfully compress the ideas to fit in a blog comment. I have included a miniature table of contents in the essay to help people locate exactly what I have to say about how to address the particular problems mentioned by other people in all the preceding comments.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40723")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2009")])]

#text("I’m not sure I can give a good justification, but I just wanted to register my visceral dislike for comment ratings.")

#text("But of course I appreciate the need for newcomers to a thread (or just people who have been doing something else for half a day and find themselves hundreds of posts behind!) to locate the “highlights” quickly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4ad6c18186ffa1aab4aadbb6437ddfdfd03ffdb28fa7b75fb5a4b74dadd060d-b17876bb6ed44b4eb4e6f409d6e9c2e04bf2fd6789fad7fda897a642de72445e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Selecting another polymath project « The polymath blog")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40731")[#strong[#text("Selecting another polymath project « The polymath blog")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2009")])]

#text("[…] lesson we got from the minipolymath feedback was that one would like a long period of lead time before a polymath project is formally launched, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8e3a4841587c22f6d2b2e405b4f372736eb4331b1fc2624a8da8d324f9d936f-e35edbfa24e3921824117f415a6626c3b394d19a44a38f326baeba9000949486.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ankara evden eve")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40735")[#strong[#text("Ankara evden eve")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2009")])]

#text("This is a good project .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4b56a8116db7182d5553c69bdedba88214646e5c839931226f61862f857f8c3-48aae16b6143b10fadbc010f6a8a0afb8cfd2348b3452d2cd42acf5778b00327.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ankara nakliyat")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40736")[#strong[#text("Ankara nakliyat")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2009")])]

#text("I like this project")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-40795")[#strong[#text("A mini-polymath project « Euclidean Ramsey Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2009")]

#text("[…] ")#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-")[#text("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-")]#text("… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-43230")[#strong[#text("Massively Collaborative Mathematics: lessons from polymath1 « Hypios – Thinking")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2010")]

#text("[…] leads not only to singling out the most promising approach but according to Fields Medalist Terence Tao, to actually generating more than one solution to the problem. (This, incidentally, is what we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/06849e100bf734f45a9dfcc89e627e06270752e577170400c3c3c79ac803d436-f05557b1f5289465627804446ee4710396b835bff4d71dbafcae2d3135a1b52b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bài toán số 6 trong IMO 2009 « Sharing")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-43692")[#strong[#text("Bài toán số 6 trong IMO 2009 « Sharing")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2010")])]

#text("[…] link 4 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Future mini-polymath project: 2010 IMO Q6? « What’s new")]], [#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/comment-page-1/#comment-45460")[#strong[#text("Future mini-polymath project: 2010 IMO Q6? « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2010")])]

#text("[…] the post-mortem discussion of this experiment, it became clear that the project could have benefited from some more planning and organisation, […]")
]
