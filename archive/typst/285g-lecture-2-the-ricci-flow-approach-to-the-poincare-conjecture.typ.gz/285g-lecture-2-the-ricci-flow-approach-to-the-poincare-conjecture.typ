// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T15:16:43.258718+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "285G, Lecture 2: The Ricci flow approach to the Poincaré conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("285G, Lecture 2: The Ricci flow approach to the Poincaré conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 April 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/")[#text("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("In order to motivate the lengthy and detailed analysis of Ricci flow that will occupy the rest of this course, I will spend this lecture giving a high-level overview of Perelman’s Ricci flow-based proof of the ")#link("http://en.wikipedia.org/wiki/Poincar%C3%A9_conjecture")[#text("Poincaré conjecture")]#text(", and in particular how that conjecture is reduced to verifying a number of (highly non-trivial) facts about Ricci flow.")

#text("At the risk of belaboring the obvious, here is the statement of that conjecture:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(". (Poincaré conjecture) Let M be a compact 3-manifold which is ")#link("http://en.wikipedia.org/wiki/Simply_connected_space")[#text("simply connected")]#text(" (i.e. it is connected, and every loop is contractible to a point). Then M is ")#link("http://en.wikipedia.org/wiki/Homeomorphism")[#text("homeomorphic")]#text(" to a 3-sphere ")#mi("S^3")#text(".")
]

#text("[Unless otherwise stated, all manifolds are assumed to be without boundary.]")

#text("I will take it for granted that this result is of interest, but you can read the ")#link("http://www.ams.org/notices/200310/fea-milnor.pdf")[#text("Notices article of Milnor")]#text(", the ")#link("http://www.ams.org/bull/2005-42-01/S0273-0979-04-01045-6/home.html")[#text("Bulletin article of Morgan")]#text(", or the ")#link("http://www.claymath.org/millennium/Poincare_Conjecture/poincare.pdf")[#text("Clay Mathematical Institute description of the problem")]#text(" (also by Milnor) for background and motivation for this conjecture. Perelman’s methods also extend to establish further generalisations of the Poincaré conjecture, most notably ")#link("http://en.wikipedia.org/wiki/Geometrization_conjecture")[#text("Thurston’s geometrisation conjecture")]#text(", but I will focus this course just on the Poincaré conjecture. (On the other hand, the geometrisation conjecture will be rather visibly lurking beneath the surface in the discussion of this lecture.)")

#heading(level: 1)[#metadata(none) <tao-ab0de8af88ea84d0f2a0>#text(" — Examples of compact 3-manifolds —")]

#text("Before we get to the Ricci flow approach to the Poincaré conjecture, we will need to discuss some examples of compact 3-manifolds. Here (as in the statement of the Poincaré conjecture) we will work in the ")#link("http://en.wikipedia.org/wiki/Topological_manifold")[#text("topological category")]#text(", so our manifolds are ")#emph[#text("a priori")]#text(" not endowed with a smooth structure or a Riemannian structure, and with two manifolds considered equivalent if they are homeomorphic. As mentioned in ")#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/")[#text("Lecture 0")]#text(", in three dimensions it is not difficult (once one has the triangulation theorem of Whitehead and Munkres) to move from the topological category back to the smooth or Riemannian category or vice versa, so one should not be too concerned about changes in category here.")

#text("The most basic example of a compact 3-manifold is the ")#emph[#text("sphere")]#text(" ")#mi("S^3")#text(", which is easiest to define extrinsically as the unit sphere in ")#mi("{\\Bbb R}^4")#text(", but can also be defined intrinsically as the ")#link("http://en.wikipedia.org/wiki/One-point_compactification")[#text("one-point compactification")]#text(" of ")#mi("{\\Bbb R}^3")#text(" (via the ")#link("http://en.wikipedia.org/wiki/Stereographic_projection")[#text("stereographic projection")]#text(", for instance). Using the latter description, it is easy to see that the sphere is simply connected (note that in two and higher dimensions one can always perturb a loop to avoid a specific point, such as the ")#link("http://en.wikipedia.org/wiki/Point_at_infinity")[#text("point at infinity")]#text(").")

#text("When we view ")#mi("S^3")#text(" as the unit sphere in ")#mi("{\\Bbb R}^4")#text(", it acquires a ")#link("http://en.wikipedia.org/wiki/Transitive_group_action")[#text("transitive")]#text(" ")#link("http://en.wikipedia.org/wiki/Group_action")[#text("action")]#text(" of the ")#link("http://en.wikipedia.org/wiki/Special_orthogonal_group")[#text("special orthogonal group")]#text(" SO(4), whose ")#link("http://en.wikipedia.org/wiki/Stabilizer_subgroup")[#text("stabiliser")]#text(" is equivalent to SO(3), thus we have a third important description of ")#mi("S^3")#text(", namely as the ")#link("http://en.wikipedia.org/wiki/Homogeneous_space")[#text("homogeneous space ")]#text("SO(4)/SO(3). Now suppose one has a finite subgroup ")#mi("\\Gamma")#text(" of SO(4) whose action on ")#mi("S^3")#text(" is ")#link("http://en.wikipedia.org/wiki/Group_action#Types_of_actions")[#text("free")]#text(". Then one can ")#link("http://en.wikipedia.org/wiki/Quotient_space")[#text("quotient ")]#mi("S^3")#text(" by ")#mi("\\Gamma")#text(" to create a new space")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\Gamma\\backslash S^3 \\equiv \\Gamma\\backslash SO(4) / SO(3) \\equiv \\{ \\Gamma x: x \\in S^3 \\},")]]

#text("which remains a manifold since the action is free. (If the action had some isolated fixed points, then the quotient space would merely be an ")#link("http://en.wikipedia.org/wiki/Orbifold")[#text("orbifold")]#text(".) Such manifolds are known as ")#link("http://en.wikipedia.org/wiki/Spherical_3-manifold")[#emph[#text("spherical 3-manifolds")]]#text(". If the action of ")#mi("\\Gamma")#text(" is not completely trivial, then this new manifold ")#mi("\\Gamma \\backslash S^3")#text(" is topologically inequivalent to the original sphere ")#mi("S^3")#text(". The easiest way to see this is to observe that ")#mi("\\Gamma \\backslash S^3")#text(" is not simply connected. Indeed, as the action is not trivial, we can find ")#mi("g \\in \\Gamma")#text(" and ")#mi("x \\in S^3")#text(" such that ")#mi("gx \\neq x")#text(". Then a path from x to gx in ")#mi("S^3")#text(" descends to a closed loop on ")#mi("\\Gamma \\backslash S^3")#text(" which cannot be contracted to a point (basically because the orbit ")#mi("\\Gamma x")#text(" of x in ")#mi("S^3")#text(" is discrete), and so ")#mi("\\Gamma \\backslash S^3")#text(" cannot be simply connected.")

#strong[#text("Remark 1.")]#text(" The above argument in fact shows that the ")#link("http://en.wikipedia.org/wiki/Fundamental_group")[#text("fundamental group")]#text(" ")#mi("\\pi_1(\\Gamma \\backslash S^3)")#text(" of ")#mi("\\Gamma \\backslash S^3")#text(" is just ")#mi("\\Gamma")#text("; this is ultimately because ")#mi("S^3")#text(" is the ")#link("http://en.wikipedia.org/wiki/Covering_space")[#text("universal covering space")]#text(" for ")#mi("\\Gamma \\backslash S^3")#text(". Conversely, Perelman’s arguments can be used to show that spherical 3-manifolds are the ")#emph[#text("only")]#text(" compact 3-manifolds with finite fundamental group (this conjecture, known as the ")#link("http://en.wikipedia.org/wiki/Elliptization_conjecture")[#emph[#text("elliptisation conjecture")]]#text(", is also a corollary of the ")#link("http://en.wikipedia.org/wiki/Geometrization_conjecture")[#text("geometrisation conjecture")]#text("). ")#mi("\\diamond")

#text("The most well-known example of a spherical 3-manifold (other than ")#mi("S^3")#text(" itself) is real ")#link("http://en.wikipedia.org/wiki/Projective_space")[#text("projective space")]#text(" ")#mi("\\Bbb{RP}^3")#text(", which is equivalent to the quotient ")#mi("\\Gamma \\backslash S^3")#text(" of ")#mi("S^3")#text(" by the two-element group ")#mi("\\{+1, -1\\} \\subset SO(4)")#text(". Other examples of spherical space forms include ")#link("http://en.wikipedia.org/wiki/Lens_space")[#text("lens spaces")]#text(" (in which ")#mi("\\Gamma")#text(" is a ")#link("http://en.wikipedia.org/wiki/Cyclic_group")[#text("cyclic group")]#text("), as well as a handful of other spaces in which ")#mi("\\Gamma")#text(" is essentially the symmetry group of a ")#link("http://en.wikipedia.org/wiki/Regular_polytope")[#text("regular polytope")]#text(" (the four-dimensional analogue of the classical ")#link("http://en.wikipedia.org/wiki/Platonic_solid")[#text("Platonic solids")]#text("). An interesting example of the latter is the ")#link("http://en.wikipedia.org/wiki/Poincar%C3%A9_homology_sphere")[#text("Poincaré homology sphere")]#text(", which has the same ")#link("http://en.wikipedia.org/wiki/Homology_group")[#text("homology groups")]#text(" as the sphere but is not homeomorphic to it.")

#text("The unit sphere ")#mi("S^3")#text(" (with the usual smooth structure) has a natural Riemannian metric g on it, which can be viewed either as the one induced from the Euclidean metric on the ambient space ")#mi("{\\Bbb R}^4")#text(" (by restricting the tangent spaces of the latter to the former), or the one induced from the ")#link("http://en.wikipedia.org/wiki/Lie_group")[#text("Lie group")]#text(" SO(4), which is in turn induced by the ")#link("http://en.wikipedia.org/wiki/Killing_form")[#text("Killing form")]#text(" on the ")#link("http://en.wikipedia.org/wiki/Lie_algebra")[#text("Lie algebra")]#text(" ")#mi("\\mathfrak{so}(4)")#text(" [")#emph[#text("Aside")]#text(": there may be a normalization issue with the latter interpretation]. This metric has constant ")#link("http://en.wikipedia.org/wiki/Sectional_curvature")[#text("sectional curvature")]#text(" +1, which means that")

#align(center)[#mi("g(\\text{Riem}(u,v) u, v) = +1")#text(" (1′)")]

#text("whenever ")#mi("x \\in S^3")#text(" and ")#mi("u, v \\in T_x M")#text(" are orthonormal vectors. (To put it another way, ")#mi("\\text{Riem}")#text(" is +1 times the identity section of ")#mi("\\text{Hom}( \\bigwedge^2 TM, \\bigwedge^2 TM )")#text(".)")

#text("The metric g is invariant under the action of the rotation group ")#mi("SO(4)")#text(", and so it also descends to provide a Riemannian metric on every spherical 3-manifold of constant curvature +1 (and thus also constant positive Ricci and scalar curvature). Such Riemannian manifolds are known as ")#emph[#text("spherical space forms")]#text(". Conversely, it is not difficult to show that any compact connected 3-manifold M of constant curvature +1 arises in this manner; this is basically because (1′) ensures that there is an infinitesimal action of the Lie algebra ")#mi("\\mathfrak{so}(4)")#text(" on the ")#link("http://en.wikipedia.org/wiki/Frame_bundle#Orthonormal_frame_bundle")[#text("orthonormal frame bundle")]#text(" of M, which then extends to an action of SO(4) which is ")#link("http://en.wikipedia.org/wiki/Transitive_action#Types_of_actions")[#text("transitive")]#text(" (thanks to the connectedness of M) and has ")#link("http://en.wikipedia.org/wiki/Group_action#Orbits_and_stabilizers")[#text("stabiliser")]#text(" equal to some finite extension of SO(3) (which is the structure group of the orthonormal frame bundle). Since ")#mi("S^3 \\equiv SO(4)/SO(3)")#text(", the claim follows.")

#strong[#text("Remark 2.")]#text(" The spherical space forms are one of the eight ")#link("http://en.wikipedia.org/wiki/Geometrization_conjecture#The_eight_Thurston_geometries")[#emph[#text("Thurston geometries")]]#text(" (or ")#emph[#text("model geometries")]#text(") that arise in the ")#link("http://en.wikipedia.org/wiki/Geometrization_conjecture")[#text("geometrisation conjecture")]#text(", namely the ")#emph[#text("spherical")]#text(" or ")#emph[#text("elliptic")]#text(" geometries. (These eight geometries are also closely related, though not identical to, the ")#link("http://en.wikipedia.org/wiki/Bianchi_classification")[#text("classification of ")]#text("Bianchi of three-dimensional Lie algebras into nine families.) ")#mi("\\diamond")

#text("Two more examples of 3-manifolds arise by considering ")#mi("S^2")#text("-bundles over ")#mi("S^1")#text(", or equivalently, ")#mi("S^2 \\times [0,1]")#text(" with the two spheres ")#mi("S^2 \\times \\{0\\}")#text(" and ")#mi("S^2 \\times \\{1\\}")#text(" identified. Some basic ")#link("http://en.wikipedia.org/wiki/Degree_%28continuous_map%29")[#text("degree theory")]#text(" (or even just ")#link("http://en.wikipedia.org/wiki/Winding_number")[#text("winding number")]#text(" theory) shows that up to continuous deformation, there are only two such identifications; the ")#link("http://en.wikipedia.org/wiki/Orientation_%28mathematics%29")[#text("orientation")]#text("-preserving one (which is equivalent to the identity map, or a rotation map) and the orientation-reversing one (which is equivalent to a reflection map). The first such identification leads to the ")#link("http://en.wikipedia.org/wiki/Orientability")[#text("orientable")]#text(" ")#mi("S^2")#text("-bundle ")#mi("S^2 \\times S^1")#text(", and the second identification leads to the non-orientable ")#mi("S^2")#text("-bundle (which is a 3-manifold analogue of the ")#link("http://en.wikipedia.org/wiki/Klein_bottle")[#text("Klein bottle")]#text("). Both of these manifolds can be viewed as quotients of the cylinder ")#mi("S^2 \\times {\\Bbb R}")#text(" by an action of ")#mi("{\\Bbb Z}")#text(". More precisely, ")#mi("S^2 \\times {\\Bbb R}")#text(" has an obvious transitive action of ")#mi("O(3) \\times {\\Bbb R}")#text(" on it given by the formula ")#mi("(U,s) (\\omega,t) := (U \\omega,s+t)")#text("; the stabiliser subgroup is ")#mi("O(2) \\times \\{0\\}")#text(", thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("S^2 \\times {\\Bbb R} \\equiv (O(3) \\times {\\Bbb R}) / (O(2) \\times \\{0\\}).")]]

#text("Every group element ")#mi("(U,s) \\in O(3) \\times {\\Bbb R}")#text(" with ")#mi("s \\neq 0")#text(" generates a discrete subgroup ")#mi("\\Gamma = \\{ (U^n, ns): n \\in {\\Bbb Z} \\}")#text(", and the quotient space")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\Gamma \\backslash S^2 \\times {\\Bbb R} \\equiv \\Gamma \\backslash (O(3) \\times {\\Bbb R}) / (O(2) \\times \\{0\\})")]]

#text("is homeomorphic to either the orientable or non-orientable ")#mi("S^2")#text("-bundle over ")#mi("S^1")#text(", depending whether ")#mi("\\det(U)")#text(" is equal to +1 (i.e. ")#mi("U \\in SO(3)")#text(" is rotation) or to -1 (i.e. ")#mi("U \\not \\in SO(3)")#text(" is a reflection).")

#text("Let M be one of the above ")#mi("S^2")#text("-bundles over ")#mi("S^1")#text(". The projection map from M to ")#mi("S^1")#text(" induces a homomorphism from the fundamental group ")#mi("\\pi_1(M)")#text(" to the fundamental group ")#mi("\\pi_1(S^1) \\equiv {\\Bbb Z}")#text(".")

#strong[#text("Exercise 1")]#text(". Show that this map is in fact bijective, thus ")#mi("\\pi_1(M) \\equiv {\\Bbb Z}")#text(". In particular these manifolds are not homeomorphic to the spherical 3-manifolds. ")#mi("\\diamond")

#text("There is an obvious Riemannian metric g to place on ")#mi("S^2 \\times {\\Bbb R}")#text(", being the direct sum of the standard metrics on ")#mi("S^2")#text(" and ")#mi("{\\Bbb R}")#text(" respectively; it can also be defined in terms of the Killing form on the Lie algebra ")#mi("\\mathfrak{so}(3) \\times {\\Bbb R}")#text(". As this metric is ")#mi("O(3) \\times {\\Bbb R}")#text("-invariant, it descends to both the oriented and non-oriented ")#mi("S^2")#text("-bundles over ")#mi("S^1")#text(". This metric is not of constant sectional curvature (the sectional curvature is positive on planes transverse to the axis of the cylinder, but vanish on planes parallel to that axis). But it has non-negative Riemann, sectional, Ricci curvature and positive scalar curvature.")#linebreak()#text(" ")#strong[]

#strong[#text("Remark 3.")]#text(" The geometries coming from ")#mi("S^2 \\times {\\Bbb R}")#text(" are another of the eight ")#link("http://en.wikipedia.org/wiki/Geometrization_conjecture#The_eight_Thurston_geometries")[#text("Thurston geometries")]#text(". These are the only two of the eight geometries that have some positive curvature in them; it is because of this that these two geometries can get extinguished in finite time by Ricci flow (remember, this flow compresses positively curved geometries and expands negatively curved ones). Very roughly speaking, it is these two geometries that show up in the finite time analysis of Ricci flow (in which the time variable t is bounded), whereas the other six geometries (being flat or negatively curved) only show up in the asymptotic analysis of Ricci flow (in the limit ")#mi("t \\to \\infty")#text("). ")#mi("\\diamond")

#text("One can form further 3-manifolds out of the ones already discussed by the procedure of taking ")#link("http://en.wikipedia.org/wiki/Connected_sum")[#text("connected sums")]#text(". Recall that the connected sum ")#mi("M \\# M^{\\prime}")#text(" of two connected 3-manifolds M, M’ is formed by choosing small 3-balls B, B’ in M and M’ respectively; if these balls are small enough, they are homeomorphic to the Euclidean ball ")#mi("B^3")#text(". Remove the interior of these two balls, leaving behind two boundaries ")#mi("\\partial B")#text(" and ")#mi("\\partial B^{\\prime}")#text(" which are homeomorphic to ")#mi("S^2")#text(", and then identify these two boundaries together to create a new connected 3-manifold.")

#strong[#text("Remark 4.")]#text(" It is not hard to see that the location of the small balls B, B’ is not relevant, since the connectedness of M and M’ easily allows one to “slide” these balls around. There is however a subtle technicality regarding the identification map between ")#mi("\\partial B")#text(" and ")#mi("\\partial B^{\\prime}")#text(". A bit of degree theory shows that up to homotopy, there are only two possible identifications, one of which reverses the orientation of the other; for instance, any homeomorphism of the unit sphere ")#mi("S^2")#text(" to itself can be continuously deformed (while remaining a homeomorphism) to either a rotation or a reflection. If one of the manifolds M, M’ is non-orientable then either choice of identification gives an equivalent connected sum up to homeomorphism, as one can slide one of the balls around the non-orientable manifold to return to the original location with the reversed orientation. Similarly, if both manifolds M, M’ are orientable and one of them has an orientation-reversing homeomorphism, then again the two connected sums are homeomorphic. But there are some orientable 3-manifolds which lack orientation-reversing homeomorphisms (e.g. some lens spaces are of this type), and so I believe that there are cases in which the connected sum operation of two orientable manifolds M, M’ is ambiguous. However, if one selects one of the two available orientations on M and M’ (thus upgrading these orient")#emph[#text("able")]#text(" manifolds to orient")#emph[#text("ed")]#text(" manifolds), then one can define an ")#emph[#text("oriented connected sum")]#text(" by asking that the oriented structures on M and M’ are compatible upon gluing, thus yielding an oriented connected manifold ")#mi("M \\# M^{\\prime}")#text(". This operation is then unambiguous up to homeomorphism. So, if we adopt the convention that all manifolds are equipped with an orientation if they are orientable, and are (of course) not equipped with an orientation if they are non-orientable, then we have a well-defined connected sum. [")#emph[#text("Aside")]#text(": this is a rather annoying and confusing technical issue. Is there a more elegant way to get around it? I suppose that for non-oriented manifolds, one could always pass to the ")#link("http://en.wikipedia.org/wiki/Orientability#Orientable_double_cover")[#text("oriented double cover")]#text(" first.] ")#mi("\\diamond")

#text("Once one addresses the technical issues raised in Remark 4, one can show that the connected sum operation is well-defined, commutative, and associative up to homeomorphism. There is also a strong relationship between the topology of a connected sum and that of its components:")

#strong[#text("Exercise 2.")]#text(" Let M, M’ be connected manifolds of the same dimension.")

#enum(start: 1, 
[#text("Show that ")#mi("M \\# M^{\\prime}")#text(" is compact if and only if ")#mi("M")#text(" and ")#mi("M^{\\prime}")#text(" are both compact.")],
[#text("Show that ")#mi("M \\# M^{\\prime}")#text(" is orientable if and only if ")#mi("M")#text(" and ")#mi("M^{\\prime}")#text(" are both orientable.")],
[#text("Show that ")#mi("M \\# M^{\\prime}")#text(" is simply connected if and only if ")#mi("M")#text(" and ")#mi("M^{\\prime}")#text(" are both simply connected.")]
)

#text("The sphere also plays a special role, as the identity for the connected sum operation:")

#strong[#text("Exercise 3.")]#text(" Let M be a connected manifold, and let S be a sphere of the same dimension. Show that ")#mi("M \\# S")#text(" (or ")#mi("S \\# M")#text(") is homeomorphic to M. ")#mi("\\diamond")

#text("This property uniquely defines the sphere topologically; if there was another connected manifold ")#mi("S^{\\prime}")#text(" of the same dimension as a sphere S which was also an identity for the connected sum, then a consideration of ")#mi("S \\# S^{\\prime}")#text(" shows that these two manifolds must be homeomorphic.")

#strong[#text("Exercise 4.")]#text(" Let M be a connected manifold. Suppose one connects M to itself by taking two small disjoint balls B and B’ inside M, removing the interiors of these balls, and identifying the boundaries ")#mi("\\partial B")#text(" and ")#mi("\\partial B^{\\prime}")#text(". Show that the resulting manifold is homeomorphic to the connected sum of M with an ")#mi("S^2")#text(" bundle over ")#mi("S^1")#text(". ")#mi("\\diamond")

#strong[#text("Remark 5. ")]#text("For this remark, let us restrict attention to compact connected oriented 3-manifolds; modulo homeomorphisms, this is a commutative associative ")#link("http://en.wikipedia.org/wiki/Monoid")[#text("monoid")]#text(" with respect to connected sum, with identity ")#mi("S^3")#text(". A manifold is said to ")#emph[#text("non-trivial")]#text(" if it is not the identity, and ")#emph[#text("prime")]#text(" if it is non-trivial but not representable as the sum of two non-trivial manifolds. It then turns out that there is a ")#link("http://en.wikipedia.org/wiki/Prime_3-manifold")[#text("prime decomposition theorem ")]#text("for such manifolds, analogous to the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_arithmetic")[#text("fundamental theorem of arithmetic")]#text(": every such manifold is expressible as the connected sum of finitely many prime manifolds, and that this decomposition is unique up to rearrangement. However, useful as this decomposition is, it turns out that one does not actually need the prime decomposition theorem to prove the Poincaré conjecture. (In fact, it is remarkable how little actual topology is needed to prove what is manifestly a topological conjecture; almost the entire proof of Perelman is conducted instead in the arena of differential geometry (and more specifically, Riemannian geometry) and partial differential equations.) ")#mi("\\diamond")

#text("Recall that of the spherical space forms and ")#mi("S^2")#text("-bundles over ")#mi("S^1")#text(" mentioned above, the sphere ")#mi("S^3")#text(" was the only one which was simply connected. From Exercises 2 and 3 we thus have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1.")]#text(" (Poincaré conjecture for positively curved Thurston geometries) Let M be a simply connected 3-manifold which is the connected sum of finitely many spherical space forms and ")#mi("S^2")#text("-bundles over ")#mi("S^1")#text(". Then M is homeomorphic to the sphere ")#mi("S^3")#text(".")
]

#strong[#text("Remark 6. ")]#text(" One can establish similar results for combinations of any of the eight Thurston geometries (where we now allow “combination” to not just include the connected sum operation which glues along spheres ")#mi("S^2")#text(", but also more complicated joining operations which glue along tori ")#mi("T^2")#text("). Because of this, it is not difficult to show that the ")#link("http://en.wikipedia.org/wiki/Geometrization_conjecture")[#text("geometrisation conjecture")]#text(" implies the Poincaré conjecture. But the former conjecture is a significantly stronger and richer conjecture than the latter; it classifies ")#emph[#text("all ")]#text("compact 3-manifolds, not just the simply connected ones. ")#mi("\\diamond")

#text("— Perelman’s theorems and the Poincaré conjecture —")

#text("We now have enough background to state the main results of Perelman; the rest of the course will be devoted to proving as much of these results as possible.")

#text("In 1981-1982, ")#link("http://www.ams.org/mathscinet-getitem?mr=664497")[#text("Hamilton realised")]#text(" that Ricci flow was an exceptionally promising tool for uniformising the geometry of a Riemmanian manifold, to the point where its topology became recognisable. The first evidence he established towards this phenomenon is the following ")#emph[#text("rounding theorem")]#text(": if a compact 3-manifold ")#mi("(M,g)")#text(" has everywhere positive Ricci curvature, then the Ricci flow ")#mi("(M(t),g(t))")#text(" with this initial data develops a singularity in finite time ")#mi("t_*")#text(". Furthermore, as one approaches this singularity, the Ricci curvature becomes increasingly uniform, and more precisely that ")#mi("\\frac{3}{\\overline{R}(t)} \\text{Ric}_{\\alpha \\beta}(t,x)")#text(" converges uniformly to the metric ")#mi("g_{\\alpha \\beta}(t,x)")#text(" as ")#mi("t \\to t_*")#text(", where ")#mi("\\overline{R}(t)")#text(" is the average scalar curvature on ")#mi("(M(t),g(t))")#text(". (One can also show that ")#mi("\\overline{R}(t) \\to +\\infty")#text(" as ")#mi("t \\to t_*")#text(".) Once the Ricci curvature is sufficiently uniform, one can apply tools from Riemannian geometry such as the ")#link("http://en.wikipedia.org/wiki/Sphere_theorem")[#text("sphere theorem")]#text(" to deduce that the original manifold M was in fact homeomorphic to a spherical space form (and in particular, if M is simply connected, is homeomorphic to a sphere ")#mi("S^3")#text(").")

#text("Unfortunately, for more general Riemannian 3-manifolds, Ricci flow was only able to partially uniformise the geometry before the appearance of the first singularity. (However, work ")#link("http://www.ams.org/mathscinet-getitem?mr=954419")[#text("of Hamilton")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1094458")[#text("of Chow")]#text(" did show that Ricci flow does accomplish this task for 2-manifolds. These methods can give a new proof of the ")#link("http://en.wikipedia.org/wiki/Uniformization_theorem")[#text("uniformisation theorem")]#text(": see this ")#link("http://arxiv.org/abs/math/0505163")[#text("paper of Chen, Lu, and Tian")]#text(" for further discussion.) In order to address is this issue, ")#link("http://www.ams.org/mathscinet-getitem?mr=1456308")[#text("Hamilton introduced")]#text(" (in the context of 4-manifolds) a notion of surgery on manifolds at each development of a singularity in order to continue the Ricci flow (but possibly with a topology change after each surgery). These and other results then led to Hamilton’s program to develop a systematic theory of Ricci flow with surgery that would be able to uniformise and then recognise the topology of various Riemannian manifolds, particularly 3-manifolds. However, prior to Perelman’s work, there was insufficient understanding of even the first singularity of Ricci flow to carry out this program, unless additional curvature assumptions were placed on the initial manifold.")

#text("The most important of Perelman’s results in this direction is the following global existence result for a certain modification of Ricci flow.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 ")]#text("(Global existence of Ricci flow with surgery) Let ")#mi("(M,g)")#text(" be a compact Riemannian 3-manifold, such that M does not contain any embedded copy of the ")#link("http://en.wikipedia.org/wiki/Real_projective_plane")[#text("real projective plane")]#text(" ")#mi("\\Bbb{RP}^2")#text(" with trivial normal bundle. Then there exists a ")#emph[#text("Ricci flow with surgery")]#text(" ")#mi("t \\mapsto (M(t),g(t))")#text(" which assigns a compact Riemannian manifold ")#mi("(M(t),g(t))")#text(" to each time ")#mi("t \\in [0,+\\infty)")#text(", as well as a closed set ")#mi("T \\subset (0,+\\infty)")#text(" of ")#emph[#text("surgery times")]#text(", with the following properties:")

#enum(start: 1, 
[#text("(Initial data) ")#mi("M(0) = M")#text(" and ")#mi("g(0) = g")#text(".")],
[#text("(Ricci flow) If I is any connected component of ")#mi("{}[0,+\\infty) \\backslash T")#text(" (and is therefore an interval), and ")#mi("t_I")#text(" is the left-endpoint of I, then ")#mi("t \\mapsto (M(t),g(t))")#text(" is a Ricci flow on ")#mi("\\{t_I\\} \\cup I")#text(", as defined in the ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("previous lecture")]#text(" (in particular, M(t) is constant on this interval).")],
[#text("(Topological compatibility) If ")#mi("t \\in T")#text(", and ")#mi("\\varepsilon > 0")#text(" is sufficiently small, then each connected component of ")#mi("M_{t-\\varepsilon}")#text(" is homeomorphic to the connected sum of finitely many connected components of ")#mi("M_t")#text(", together with a finite number of spherical space-forms, ")#mi("\\Bbb{RP}^3 \\# \\Bbb {RP}^3")#text(", and ")#mi("S^2")#text(" bundle over ")#mi("S^1")#text(". Furthermore, each connected component of ")#mi("M_t")#text(" is used in the connected sum decomposition of exactly one component of ")#mi("M_{t-\\varepsilon}")#text(".")],
[#text("(Geometric compatibility) For each ")#mi("t \\in T")#text(", the metric ")#mi("g(t)")#text(" on M(t) is related to a certain limit of the metrics ")#mi("g(t-\\varepsilon)")#text(" on ")#mi("M(t-\\varepsilon)")#text(" as ")#mi("\\varepsilon \\to 0")#text(" by a certain ")#emph[#text("surgery procedure")]#text(" which we will state precisely much later in this course.")]
)
]

#text("The key here is item 3, which depends crucially on the structural analysis of Ricci flow as it approaches a singularity. The precise definition of surgery in item 4 is highly technical (and differs in a number of ways from Hamilton’s version of the concept), but fortunately we do not need to know exactly what it is for topological applications such as the Poincaré conjecture, which only require item 3. (We do need to understand surgery in order to prove Theorems 3 and 4 below, though.)")

#text("The condition that M does not contain any embedded copy of ")#mi("\\Bbb{RP}^2")#text(" with trivial normal bundle is a technical one, but is not a significant obstacle for proving the Poincaré conjecture, thanks to the following topological lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" Let M be a simply connected 3-manifold. Then M does not contain any embedded copy of ")#mi("\\Bbb{RP}^2")#text(" with trivial normal bundle.")
]

#strong[#text("Proof.")]#text(" Suppose for contradiction that M contained an embedded copy ")#mi("\\Sigma")#text(" of ")#mi("\\Bbb{RP}^2")#text(" with trivial normal bundle. Then one can find a loop ")#mi("\\gamma")#text(" in ")#mi("\\Sigma")#text(" whose normal bundle in ")#mi("\\Sigma")#text(" is non-trivial (indeed, one can find a loop whose neighbourhood is a Möbius strip; this is easiest seen by viewing ")#mi("\\Bbb{RP}^2")#text(" topologically as the unit square with diametrically opposing points identified, and then taking ")#mi("\\gamma")#text(" to be a horizontal or vertical line through the centre of this square). Since ")#mi("\\Sigma")#text(" has trivial normal bundle in M, we conclude that ")#mi("\\gamma")#text(" has non-trivial normal bundle in M. But then ")#mi("\\gamma")#text(" cannot be contracted to a point, contradicting the hypothesis that M is simply connected. ")#mi("\\Box")

#strong[#text("Remark 7. ")]#text("The above argument in fact shows that no orientable manifold can contain an embedded ")#mi("\\Bbb{RP}^2")#text(" with trivial normal bundle; note that all simply connected manifolds are automatically orientable. The argument can also be modified to show that a simply connected manifold cannot contain any embedded copy of ")#mi("\\Bbb{RP}^2")#text(" at all (regardless of whether the normal bundle is trivial). ")#mi("\\diamond")

#text("To prove the Poincaré conjecture, we need to combine Theorem 2 with two other results about Ricci flow with surgery. The first is relatively easy:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3. ")]#text("(Discrete surgery times) Let ")#mi("t \\to (M(t),g(t))")#text(" be a Ricci flow with surgery with no embedded ")#mi("{\\Bbb RP}^2")#text(" with trivial normal bundle. Then the set T of surgery times is ")#link("http://en.wikipedia.org/wiki/Discrete_space")[#text("discrete")]#text(". In particular, any compact time interval only contains a finite number of surgeries.")
]

#text("This theorem is basically proven by obtaining a lower bound on how much volume is removed by each surgery, combined with an upper bound on how much the volume can grow during the Ricci flow stage of the process. We have isolated Theorem 3 from Theorem 2 to highlight the importance of the former, but in practice the two results are proven simultaneously (since the geometric and topological compatibility in Theorem 2 would become more difficult to formulate properly if the surgery times were allowed to accumulate).")

#text("The second result is more non-trivial, though it is still significantly easier to prove than Theorem 2.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4.")]#text(" (Finite time extinction) Let ")#mi("(M,g)")#text(" be a compact 3-manifold which is simply connected, and let ")#mi("t \\mapsto (M(t),g(t))")#text(" be an associated Ricci flow with surgery. Then M(t) is empty for all sufficiently large times t.")
]

#text("This result is analogous to finite time blowup results in nonlinear evolution equations. It is established by constructing a non-negative quantity W(t) depending on the geometry ")#mi("(M(t),g(t))")#text(" at time t, which decreases in such a manner that it must vanish in finite time, at which point one can show that the manifold becomes empty. (From topological compatibility it is clear that if the manifold is empty at time t, it is empty for all subsequent times.) There are two known candidates for this quantity, one due ")#link("http://arxiv.org/abs/math/0307245")[#text("to Perelman")]#text(" (based on a min-max functional over loops), and one due ")#link("http://www.ams.org/mathscinet-getitem?mr=2138137")[#text("to Colding and Minicozzi")]#text(" (based on minimal spheres). Both quantities are known to be strong enough to establish Theorem 4.")

#text("Once one has Theorems 2, 3, and 4 in hand, the proof of the Poincaré conjecture is easy:")

#strong[#text("Proof of Theorem 1")]#text(". Let M be a compact, simply connected 3-manifold. By an old result ")#link("http://www.ams.org/mathscinet-getitem?mr=48805")[#text("of Moise")]#text(", every 3-manifold can be ")#link("http://en.wikipedia.org/wiki/Triangulation_%28topology%29")[#text("triangulated")]#text(" and so can easily be endowed with a smooth structure. (In the converse direction, the results ")#link("http://www.ams.org/mathscinet-getitem?mr=121804")[#text("of Munkres")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=124917")[#text("of Whitehead")]#text(", show that this smooth structure is unique.) Using a standard ")#link("http://en.wikipedia.org/wiki/Partition_of_unity")[#text("partition of unity")]#text(" argument, one can then create a smooth Riemannian metric g on M.")

#text("Theorem 2 (and Lemma 1) gives us a Ricci flow with surgery ")#mi("t \\mapsto (M(t),g(t))")#text(" with surgery with initial data (M,g). By Theorem 4, there is some finite time ")#mi("t_*")#text(" after which the manifolds M(t) are empty. By Theorem 3, the number of surgeries up to that time are finite. By item 3. of Theorem 2 and working backwards from time ")#mi("t_*")#text(" to time 0, we conclude that ")#mi("M(0)=M")#text(" is the connected sum of finitely many spherical space forms, copies of ")#mi("\\Bbb{RP}^3 \\# \\Bbb{RP}^3")#text(", and ")#mi("S^2")#text(" bundles over ")#mi("S^1")#text(". Actually, since ")#mi("\\Bbb{RP}^3")#text(" is already a spherical space form, we can absorb the second case into the first. The claim now follows from Corollary 1. ")#mi("\\Box")

#strong[#text("Remark 8")]#text(". Perelman’s arguments in fact show a stronger version of Theorem 4: the finite time extinction occurs not only for simply connected manifolds, but more generally for any compact 3-manifold M whose fundamental group ")#mi("\\pi_1(M)")#text(" is a ")#link("http://en.wikipedia.org/wiki/Free_product")[#text("free product")]#text(" of finite groups and infinite cyclic groups. The above argument then shows that any such manifold is diffeomorphic to the connected sum of finitely many space forms and ")#mi("S^2")#text(" bundles over ")#mi("S^1")#text(" (i.e. it is made up of the positively curved Thurston geometries). Conversely, it can be shown that any such connected sum has a fundamental group of the above form. In particular this gives a topological necessary and sufficient condition for finite time extinction. One corollary of this is the ")#emph[#text("spherical space form conjecture")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Elliptization_conjecture")[#emph[#text("elliptisation conjecture")]]#text("): any compact 3-manifold with finite fundamental group is diffeomorphic to a spherical space form. See the ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("book of Morgan and Tian")]#text(" for details. ")#mi("\\diamond")

#strong[#text("Remark 9.")]#text(" Theorems 2 and 3 also form the basis of the proof of the geometrisation conjecture. However, an additional ingredient is also needed, namely an analysis of the behaviour of the solutions to Ricci flow with surgery in the asymptotic limit ")#mi("t \\to \\infty")#text(". Also, in order to avoid dealing with all of the other Thurston geometries , a substantial amount of existing theory concerning geometrisation is first used to topologically simplify the manifold before applying Ricci flow (for instance, one works only with prime manifolds). I have not studied these arguments particularly well, but the papers of ")#link("http://arxiv.org/abs/math.DG/0605667")[#text("Kleiner-Lott ")]#text("and ")#link("http://arxiv.org/abs/math/0612069")[#text("Cao-Zhu")]#text(" cover them in some detail. (There is also some technical issue regarding ")#link("http://en.wikipedia.org/wiki/Graph_manifold")[#text("graph manifolds")]#text(" that I do not really understand, but I understand that these issues have recently been resolved.) ")#mi("\\diamond")

#text("[")#emph[#text("Updated, Apr 2")]#text(": Reference to Moise’s triangulation theorem added.]")

#text("[")#emph[#text("Updated")]#text(", Apr 15: Issues relating to embedded ")#mi("\\Bbb{RP}^2")#text("‘s with trivial normal bundle addressed.]")

#text("[")#emph[#text("Updated")]#text(", Apr 17: incorrect exercise removed.]")

#heading(level: 1)[#text("Comments (17)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d3b8c64a747769488752da8238fad50f3c0f43ea5b38286f3e12259d2b63295-a6291db97fc41a7492325a9cb98759f45d97dea416d7fb910926547f82c96e60.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Kent")]], [#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/#comment-27862")[#strong[#text("Richard Kent")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2008")])]

#text("Hi,")

#text("Regarding the origin of smooth structures on 3-manifolds: E. Moise proved that topological 3-manifolds are triangulable in the 1950’s (see MR0048805), so you can indeed get a smooth structure that way.")

#text("Cheers,")#linebreak()#text(" Richard.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/#comment-27863")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2008")])]

#text("Dear Richard,")

#text("Thank you very much for the reference!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/#comment-27876")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2008")])]

#text("Dear Terence")

#text("I see that the phrase “is topologically equivalent to the original sphere” has been corrected to “is topologically ")#strong[#text("in")]#text("equivalent to the original sphere.” And the purpose of this remark is to assure you that we system engineers take a keen interest in the notes you work so hard to post!")

#text("Just to mention, the manifolds of greatest system engineering interest with regard to geometric flows are neither topological manifolds (which are too general) nor adaptive linear subspaces (which are pretty well understood., thanks in substantial measure to your own work), but rather algebraic manifolds.")

#text("We system engineers are very interested (from a practical point of view) to adaptively flow the geometry of our algebraic manifolds to better match the manifolds that nature provides, and we follow this weblog intently for ideas and tools that are relevant to this objective.")

#text("You remarked in an earlier post that “the field of PDE has proven to be the type of mathematics where progress generally starts in the concrete and then flows to the abstract.” In a similar vein, it turns out that progress in the field of quantum system engineering (QSE) flows in ")#emph[#text("both")]#text(" directions … perhaps that is why mathematical progress in QSE is somewhat turbulent. :)")

#text("In particular, IMHO this weblog is a very important source of abstract ideas and methods that turn out to have concrete applications in QSE. For which, you have our thanks and gratitude.")

#text("So we look forward with highly enjoyable anticipation to future lectures!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 4: Finite time extinction of the second homotopy group « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/#comment-28837")[#strong[#text("285G, Lecture 4: Finite time extinction of the second homotopy group « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2008")])]

#text("[…] Returning (perhaps anticlimactically) to the subject of the Poincaré conjecture, recall from Lecture 2 that one of the key pillars of the proof of that conjecture is the finite time extinction result […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 5: Finite time extinction of the third homotopy group, I. « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/#comment-29061")[#strong[#text("285G, Lecture 5: Finite time extinction of the third homotopy group, I. « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2008")])]

#text("[…] connected manifolds, this hypothesis is automatic; see Lemma 1 of (the newly updated version of) Lecture 2. (It is also automatic for orientable manifolds, and so one can always satisfy the hypothesis as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0968fd592b1875615ed25ee401bd2b9d09f4e922ff732d45028f6696215f22e3-630c111989e921aefac15e316f2377d43db0ec1f6f005490a99dc36ac863733d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/#comment-29118")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2008")])]

#text("Exercise 3 contradicts the fourth part of exercise 2. E.g. S^2 # (S^1 x S^1) (the connected sum of a 2-dimensional sphere and a 2-dimensional torus) has trivial pi_2, but pi_2(S^2) is not trivial.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/#comment-29119")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2008")])]

#text("Hmm, you’re right, the exercise doesn’t work as stated; I’ve removed it (and adjusted some stuff in Lecture 4 and 5 accordingly).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 6: Finite time extinction of the third homotopy group, II « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/#comment-29143")[#strong[#text("285G, Lecture 6: Finite time extinction of the third homotopy group, II « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2008")])]

#text("[…] 18 April, 2008 in 285G – poincare conjecture, math.AP, math.DG Tags: curvature, curve shortening flow, minimal disk, Perelman width, ramps, Ricci flow In this lecture we discuss Perelman’s original approach to finite time extinction of the third homotopy group (Theorem 1 from the previous lecture), which, as previously discussed, can be combined with the finite time extinction of the second homotopy group to imply finite time extinction of the entire Ricci flow with surgery for any compact simply connected Riemannian 3-manifold, i.e. Theorem 4 from Lecture 2. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 7: Rescaling of Ricci flows and kappa-noncollapsing « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/#comment-29205")[#strong[#text("285G, Lecture 7: Rescaling of Ricci flows and kappa-noncollapsing « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2008")])]

#text("[…] our discussion of the finite time extinction results for Ricci flow with surgery (Theorem 4 from Lecture 2), and turn instead to the main portion of Perelman’s argument, which is to establish the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Borcherds")]], [#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/#comment-29497")[#strong[#text("Richard Borcherds")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2008")])]

#text("The connected sum of two manifolds has yet another subtlety. In the smooth case it is no longer true that there are essentially only two ways to glue")#linebreak()#text(" two n-spheres; in general the group of components of the diffeomorphisms of a sphere can be quite a large finite group. For example, the Milnor spheres in 7 dimensions can be obtained by gluing together two 7-balls using a non-standard diffeomorphism of their boundaries. I think there is a indeed a canonical way to take the connected sum of")#linebreak()#text(" manifolds, but I have a vague recollection that showing it is well defined requires some quite hard theorems such as the annulus conjecture (or rather theorem).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/#comment-29603")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2008")])]

#text("Dear Richard,")

#text("That’s a good point (though I guess in three dimensions, at least, this issue does not come up since one has a unique smooth structure in this case).")

#text("I believe though that if one has smooth oriented structures on both manifolds, one can canonically define a connected sum in this category by arbitrarily choosing a smooth Riemannian metric on both manifolds, and identifying two very small balls in these metrics together using the exponential map (i.e. normal coordinates) for each (and some orientation-preserving orthogonal transformation between the tangent spaces of the centres of the balls), and then removing the interiors of these balls and smoothing things out a bit near the gluing boundary. The configuration space of all the choices one makes here is connected, and the operations are continuous, so I think that this operation is well defined up to smooth diffeomorphism, though I may have missed yet another subtlety here. (I can imagine that if one tries to identify two _large_ balls together, all bets are off.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/573d2542ab1f1dbc3aa25ef136ef711e6751ba35c1b4c15c36cc4b068a8c5dfd-811059f52c94f0492664ad3b7849f5bdce509d50393a8abe6b70a2eb60c38940.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy P.")]], [#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/#comment-29606")[#strong[#text("Andy P.")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2008")])]

#text("A good textbook reference for things like taking the connected sum of two smooth manifolds is Kosinski’s book on differential topology. A plus is that Dover just reissued it, so it now costs about $15 instead of $100+. It also contains a rather nice discussion of things like the h-cobordism theorem, the classification of exotic spheres, and other such things (though it starts with the definition of a manifold!).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 12: High curvature regions of Ricci flow and κ-solutions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/#comment-29821")[#strong[#text("285G, Lecture 12: High curvature regions of Ricci flow and κ-solutions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2008")])]

#text("[…] proof of the Poincaré conjecture: finite time extinction of Ricci flow with surgery (Theorem 4 of Lecture 2), and a -noncollapsing of Ricci flows with surgery (which, except for the surgery part, is Theorem […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 19: The structure of Ricci flow at the singular time, surgery, and the Poincaré conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/#comment-30244")[#strong[#text("285G, Lecture 19: The structure of Ricci flow at the singular time, surgery, and the Poincaré conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2008")])]

#text("[…] 6 June, 2008 in math.AT, math.DG by Terence Tao Tags: canonical neighbourhoods, horns, standard solution, surgery In the previous lecture, we studied high curvature regions of Ricci flows on some time interval , and concluded that (as long as a mild topological condition was obeyed) they all had canonical neighbourhoods. This is enough control to now study the limits of such flows as one approaches the singularity time T. It turns out that one can subdivide the manifold M into a continuing region C in which the geometry remains well behaved (for instance, the curvature does not blow up, and in fact converges smoothly to an (incomplete) limit), and a disappearing region D, whose topology is well controlled. (For instance, the interface between C and D will be a finite union of disjoint surfaces homeomorphic to .) This allows one (at the topological level, at least) to perform surgery on the interface , removing the disappearing region D and replacing them with a finite number of “caps” homeomorphic to the 3-ball . The relationship between the topology of the post-surgery manifold and pre-surgery manifold is as is described way back in Lecture 2. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21aa472f8f494bc91b3f99127ecfb240005ad8fd92924bde9342f28755854eba-7971f5b8170dffe3c80165b7c231573ce5686efec2b955b95c917ec0dd874252.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohammad")]], [#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/#comment-31145")[#strong[#text("Mohammad")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2008")])]

#text("There are two equations numbered as 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/#comment-453333")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2015")])]

#text("It is interesting to observe that the solution of the Bieberbach conjecture (by de Branges) is based on a similar “homotopic” approach in which the “flow” is described by Loewner’s differential equation (which fortunately satisfies certain key inequalities needed to prove the stronger Milin’s conjecture).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/#comment-694067")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2026")])]

#emph[#text("It then turns out that there is a prime decomposition theorem for such manifolds, analogous to the fundamental theorem of arithmetic.")]

#text("This analogy is very interesting. Since prime numbers are the atoms of natural numbers multiplication-they cannot be decomposed any further-are you trying to tell us that the prime decomposition theorem asserts that prime manifolds are also the “atoms” of connected sum?")
]
