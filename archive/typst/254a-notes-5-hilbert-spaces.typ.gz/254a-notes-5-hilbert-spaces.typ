// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/
// Converted to Typst by tao2typ: "2026-10-14T16:35:32.740920+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245B, notes 5: Hilbert spaces", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245B, notes 5: Hilbert spaces")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 January 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/")[#text("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the next few lectures, we will be studying four major classes of function spaces. In decreasing order of generality, these classes are the ")#link("http://en.wikipedia.org/wiki/Topological_vector_space")[#text("topological vector spaces")]#text(", the ")#link("http://en.wikipedia.org/wiki/Normed_vector_space")[#text("normed vector spaces")]#text(", the ")#link("http://en.wikipedia.org/wiki/Banach_space")[#text("Banach spaces")]#text(", and the ")#link("http://en.wikipedia.org/wiki/Hilbert_space")[#text("Hilbert spaces")]#text(". In order to motivate the discussion of the more general classes of spaces, we will first focus on the most special class – that of (real and complex) Hilbert spaces. These spaces can be viewed as generalisations of (real and complex) ")#link("http://en.wikipedia.org/wiki/Euclidean_space")[#text("Euclidean spaces")]#text(" such as ")#mi("{\\Bbb R}^n")#text(" and ")#mi("{\\Bbb C}^n")#text(" to infinite-dimensional settings, and indeed much of one’s Euclidean geometry intuition concerning lengths, angles, orthogonality, subspaces, etc. will transfer readily to arbitrary Hilbert spaces; in contrast, this intuition is not always accurate in the more general vector spaces mentioned above. In addition to Euclidean spaces, another fundamental example of Hilbert spaces comes from the Lebesgue spaces ")#mi("L^2(X,{\\mathcal X},\\mu)")#text(" of a measure space ")#mi("(X,{\\mathcal X},\\mu)")#text(". (There are of course many other Hilbert spaces of importance in complex analysis, harmonic analysis, and PDE, such as ")#link("http://en.wikipedia.org/wiki/Hardy_space")[#text("Hardy spaces")]#text(" ")#mi("{\\mathcal H}^2")#text(", ")#link("http://en.wikipedia.org/wiki/Sobolev_space")[#text("Sobolev spaces")]#text(" ")#mi("H^s = W^{s,2}")#text(", and the space ")#mi("HS")#text(" of ")#link("http://en.wikipedia.org/wiki/Hilbert%E2%80%93Schmidt_operator")[#text("Hilbert-Schmidt operators")]#text(", but we will not discuss those spaces much in this course. Complex Hilbert spaces also play a fundamental role in the ")#link("http://en.wikipedia.org/wiki/Mathematical_formulation_of_quantum_mechanics")[#text("foundations of quantum mechanics")]#text(", being the natural space to hold all the possible states of a quantum system (possibly after ")#link("http://en.wikipedia.org/wiki/Projective_space")[#text("projectivising")]#text(" the Hilbert space), but we will not discuss this subject here.)")

#text("Hilbert spaces are the natural abstract framework in which to study two important (and closely related) concepts: ")#link("http://en.wikipedia.org/wiki/Orthogonality")[#text("orthogonality")]#text(" and ")#link("http://en.wikipedia.org/wiki/Unitary_transformation")[#text("unitarity")]#text(", allowing us to generalise familiar concepts and facts from Euclidean geometry such as the ")#link("http://en.wikipedia.org/wiki/Unitary_transformation")[#text("Cartesian coordinate system")]#text(", ")#link("http://en.wikipedia.org/wiki/Rotation_(mathematics)")[#text("rotations")]#text(" and ")#link("http://en.wikipedia.org/wiki/Rotation_(mathematics)")[#text("reflections")]#text(", and the ")#link("http://en.wikipedia.org/wiki/Pythagorean_theorem")[#text("Pythagorean theorem")]#text(" to Hilbert spaces. (For instance, the ")#link("http://en.wikipedia.org/wiki/Fourier_transform")[#text("Fourier transform")]#text(" is a unitary transformation and can thus be viewed as a kind of generalised rotation.) Furthermore, the ")#link("http://en.wikipedia.org/wiki/Hodge_duality")[#text("Hodge duality")]#text(" on Euclidean spaces has a partial analogue for Hilbert spaces, namely the ")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem#The_Hilbert_space_representation_theorem")[#text("Riesz representation theorem for Hilbert spaces")]#text(", which makes the theory of ")#link("http://en.wikipedia.org/wiki/Dual_space")[#text("duality")]#text(" and ")#link("http://en.wikipedia.org/wiki/Adjoint_of_an_operator")[#text("adjoints")]#text(" for Hilbert spaces especially simple (when compared with the more subtle theory of duality for, say, Banach spaces). Much later (next quarter, in fact), we will see that this duality allows us to extend the ")#link("http://en.wikipedia.org/wiki/Spectral_theorem")[#text("spectral theorem")]#text(" for self-adjoint matrices to that of self-adjoint operators on a Hilbert space.")

#text("These notes are only the most basic introduction to the theory of Hilbert spaces. In particular, the theory of linear transformations between two Hilbert spaces, which is perhaps the most important aspect of the subject, is not covered much at all here (but I hope to discuss it further in future lectures.)")

#heading(level: 1)[#metadata(none) <tao-8e7340486f1543c3f2fe>#text("— Inner product spaces —")]

#text("The Euclidean norm")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|(x_1,\\ldots,x_n)\\right| := \\sqrt{x_1^2+\\ldots+x_n^2}", block: true)]]

#text("in real Euclidean space ")#mi("{\\Bbb R}^n")#text(" can be expressed in terms of the ")#link("http://en.wikipedia.org/wiki/Dot_product")[#text("dot product")]#text(" ")#mi("\\cdot: {\\Bbb R}^n \\times {\\Bbb R}^n \\to {\\Bbb R}")#text(", defined as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("(x_1,\\ldots,x_n) \\cdot (y_1,\\ldots,y_n) := x_1 y_1 + \\ldots + x_n y_n")]]

#text("by the well-known formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|x\\right| = (x \\cdot x)^{1/2}.", block: true)]]

#text("In particular, we have the positivity property")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("x\\cdot x \\geq 0")]]

#text("with equality if and only if ")#mi("x=0")#text(". One reason why it is more advantageous to work with the dot product than the norm is that while the norm function is only ")#link("http://en.wikipedia.org/wiki/Sublinear")[#text("sublinear")]#text(", the dot product is ")#link("http://en.wikipedia.org/wiki/Bilinear_map")[#text("bilinear")]#text(", thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("(cx + dy) \\cdot z = c (x \\cdot z) + d (y \\cdot z); z \\cdot (cx+dy) = c (z \\cdot x) + d (z \\cdot y)")]]

#text("for all vectors x,y and scalars c,d, and also symmetric,")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("x \\cdot y = y \\cdot x.")]]

#text("These properties make the inner product easier to manipulate algebraically than the norm.")

#text("The above discussion was for the real vector space ")#mi("{\\Bbb R}^n")#text(", but one can develop analogous statements for the complex vector space ")#mi("{\\Bbb C}^n")#text(", in which the norm")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left\\|(z_1,\\ldots,z_n)\\right\\| := \\sqrt{ \\left|z_1\\right|^2 + \\ldots + \\left|z_n\\right|^2 }", block: true)]]

#text("can be represented in terms of the complex inner product ")#mi("\\langle, \\rangle: {\\Bbb C}^n \\times {\\Bbb C}^n \\to {\\Bbb C}")#text(" defined by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("(z_1,\\ldots,z_n) \\cdot (w_1,\\ldots,w_n) := z_1 \\overline{w_1} + \\ldots + z_n \\overline{w_n}")]]

#text("by the analogue of (3), namely")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left\\| x \\right\\| = (\\langle x, x \\rangle)^{1/2}.", block: true)]]

#text("In particular, as before with (4), we have the positivity property")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\langle x, x \\rangle \\geq 0,")]]

#text("with equality if and only if x=0. The bilinearity property (5) is modified to the ")#link("http://en.wikipedia.org/wiki/Sesquilinear")[#text("sesquilinearity")]#text(" property")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\langle cx + dy, z\\rangle = c \\langle x, z\\rangle + d \\langle y, z\\rangle; \\langle z, cx+dy \\rangle = \\overline{c} \\langle z, x \\rangle + \\overline{d} \\langle z, y \\rangle")]]

#text("while the symmetry property (6) needs to be replaced with")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\langle x, y \\rangle = \\overline{\\langle y,x \\rangle}")]]

#text("in order to be compatible with sesquilinearity.")

#text("We can formalise all these properties axiomatically as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1.")]#text(" (Inner product space) A ")#emph[#text("complex inner product space")]#text(" ")#mi("(V, \\langle,\\rangle)")#text(" is a complex vector space V, together with an inner product ")#mi("\\langle,\\rangle: V \\times V \\to {\\Bbb C}")#text(" which is sesquilinear (i.e. (11) holds for all ")#mi("x,y \\in V")#text(" and ")#mi("c,d \\in {\\Bbb C}")#text(") and symmetric in the sesquilinear sense (i.e. (12) holds for all ")#mi("x,y \\in V")#text("), and obeys the positivity property (10) for all ")#mi("x \\in V")#text(", with equality if and only if x=0. We will usually abbreviate ")#mi("(V, \\langle,\\rangle)")#text(" as V.")

#text("A ")#emph[#text("real inner product space")]#text(" is defined similarly, but with all references to ")#mi("{\\Bbb C}")#text(" replaced by ")#mi("{\\Bbb R}")#text(" (and all references to complex conjugation dropped).")
]

#strong[#text("Example 1.")]#text(" ")#mi("{\\Bbb R}^n")#text(" with the standard dot product (2) is a real inner product space, and ")#mi("{\\Bbb C}^n")#text(" with the complex inner product (8) is a complex inner product space. ")#mi("\\diamond")

#strong[#text("Example 2.")]#text(" If ")#mi("(X,{\\mathcal X},\\mu)")#text(" is a measure space, then the complex ")#mi("L^2")#text(" space ")#mi("L^2(X,{\\mathcal X},\\mu) = L^2(X,{\\mathcal X},\\mu; {\\Bbb C})")#text(" with the complex inner product")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\langle f, g \\rangle := \\int_X f \\overline{g}\\ d\\mu")]]

#text("(which is well defined, by the Cauchy-Schwarz inequality) is easily verified to be a complex inner product space, and similarly for the real ")#mi("L^2")#text(" space (with the complex conjugate signs dropped, of course. Note that the finite dimensional examples ")#mi("{\\Bbb R}^n, {\\Bbb C}^n")#text(" can be viewed as the special case of the ")#mi("L^2")#text(" examples in which X is ")#mi("\\{1,\\ldots,n\\}")#text(" with the discrete ")#mi("\\sigma")#text("-algebra and counting measure. ")#mi("\\diamond")

#strong[#text("Example 3.")]#text(" Any subspace of a (real or complex) inner product space is again a (real or complex) inner product space, simply by restricting the inner product to the subspace. ")#mi("\\diamond")

#strong[#text("Example 4.")]#text(" Also, any real inner product space V can be ")#link("http://en.wikipedia.org/wiki/Complexification")[#text("complexified")]#text(" into the complex inner product space ")#mi("V_{\\Bbb C}")#text(", defined as the space of formal combinations ")#mi("x+iy")#text(" of vectors ")#mi("x, y \\in V")#text(" (with the obvious complex vector space structure), and with inner product")

#align(center)[#mi("\\displaystyle \\langle a+ib, c+id \\rangle := \\langle a, c \\rangle + i \\langle b, c \\rangle - i \\langle a, d \\rangle + \\langle b, d \\rangle")#text(". ")#mi("\\diamond")#text(" (14)")]

#strong[#text("Example 5.")]#text(" Fix a probability space ")#mi("(X, {\\mathcal X}, \\mu)")#text(". The space of square-integrable real-valued random variables of mean zero is an inner product space if one uses ")#link("http://en.wikipedia.org/wiki/Covariance")[#text("covariance")]#text(" as the inner product. (What goes wrong if one drops the mean zero assumption?) ")#mi("\\diamond")

#text("Given a (real or complex) inner product space V, we can define the norm ")#tao-math("\\left\\|x\\right\\|", block: false)#text(" of any vector space V by the formula (9), which is well defined thanks to the positivity property; in the case of the ")#mi("L^2")#text(" spaces, this norm of course corresponds to the usual ")#mi("L^2")#text(" norm. We have the following basic facts:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" Let V be a real or complex inner product space.")

#enum(start: 1, 
[#text("(Cauchy-Schwarz inequality) For any ")#mi("x, y \\in V")#text(", we have ")#tao-math("\\left|\\langle x, y \\rangle\\right| \\leq \\left\\|x\\right\\| \\left\\|y\\right\\|", block: false)#text(".")],
[#text("The function ")#tao-math("x \\mapsto \\left\\|x\\right\\|", block: false)#text(" is a norm on V. (Thus every inner product space is a normed vector space.)")]
)
]

#strong[#text("Proof.")]#text(" We shall just verify the complex case, as the real case is similar (and slightly easier). The positivity property tells us that the quadratic form ")#mi("\\langle ax+by, ax+by \\rangle")#text(" is non-negative for all complex numbers a, b. Using sesquilinearity and symmetry, we can expand this form as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left|a\\right|^2 \\left\\|x\\right\\|^2 + 2 \\text{Re}(a \\overline{b} \\langle x, y \\rangle) + \\left|b\\right|^2 \\left\\|y\\right\\|^2.", block: true)]]

#text("Optimising in a, b (see also my ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("blog post on the amplification trick")]#text(") we obtain the Cauchy-Schwarz inequality. To verify the norm property, the only non-trivial verification is that of the triangle inequality ")#tao-math("\\left\\|x+y\\right\\| \\leq \\left\\|x\\right\\| + \\left\\|y\\right\\|", block: false)#text(". But on expanding ")#tao-math("\\left\\|x+y\\right\\|^2 = \\langle x+y, x+y \\rangle", block: false)#text(" we see that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\left\\|x+y\\right\\|^2 = \\left\\|x\\right\\|^2 + 2 \\text{Re}( \\langle x, y \\rangle ) + \\left\\|y\\right\\|^2", block: true)]]

#text("and the claim then follows from the Cauchy-Schwarz inequality. ")#mi("\\Box")

#text("Observe from the Cauchy-Schwarz inequality that the inner product ")#mi("\\langle,\\rangle: H \\times H \\to {\\Bbb C}")#text(" is continuous.")

#strong[#text("Exercise 1.")]#text(" Let ")#mi("T: V \\to W")#text(" be a linear map from one (real or complex) inner product space to another. Show that T preserves the inner product structure (i.e. ")#mi("\\langle Tx, Ty \\rangle = \\langle x, y \\rangle")#text(" for all ")#mi("x,y \\in V")#text(") if and only if T is an isometry (i.e. ")#tao-math("\\left\\|Tx\\right\\| = \\left\\|x\\right\\|", block: false)#text(" for all ")#mi("x \\in V")#text("). [Hint: in the real case, express ")#mi("\\langle x, y \\rangle")#text(" in terms of ")#tao-math("\\left\\|x+y\\right\\|^2", block: false)#text(" and ")#tao-math("\\left\\|x-y\\right\\|^2", block: false)#text(". In the complex case, use ")#mi("x+y, x-y, x+iy, x-iy")#text(" instead of ")#mi("x+y, x-y")#text(".] ")#mi("\\diamond")

#text("Inspired by the above exercise, we say that two inner product spaces are ")#emph[#text("isomorphic")]#text(" if there exists an invertible isometry from one space to the other; such invertible isometries are known as ")#emph[#text("isomorphisms.")]

#strong[#text("Exercise 2.")]#text(" Let V be a real or complex inner product space. If ")#mi("x_1,\\ldots,x_n")#text(" are a finite collection of vectors in V, show that the ")#link("http://en.wikipedia.org/wiki/Gram_matrix")[#text("Gram matrix")]#text(" ")#mi("( \\langle x_i, x_j \\rangle )_{1 \\leq i,j \\leq n}")#text(" is Hermitian and positive semi-definite, and is positive definite if and only if the ")#mi("x_1,\\ldots,x_n")#text(" are linearly independent. Conversely, given a Hermitian positive semi-definite matrix ")#mi("(a_{ij})_{1 \\leq i, j \\leq n}")#text(" with real (resp. complex) entries, show that there exists a real (resp. complex) inner product space V and vectors ")#mi("x_1,\\ldots,x_n")#text(" such that ")#mi("\\langle x_i, x_j \\rangle = a_{ij}")#text(" for all ")#mi("1 \\leq i,j \\leq n")#text(". ")#mi("\\diamond")

#text("In analogy with the Euclidean case, we say that two vectors x, y in a (real or complex) vector space are ")#link("http://en.wikipedia.org/wiki/Orthogonality")[#emph[#text("orthogonal")]]#text(" if ")#mi("\\langle x, y \\rangle = 0")#text(". (With this convention, we see in particular that 0 is orthogonal to every vector, and is the only vector with this property.)")

#strong[#text("Exercise 3.")]#text(" (Pythagorean theorem) Let V be a real or complex inner product space. If ")#mi("x_1,\\ldots,x_n")#text(" are a finite set of pairwise orthogonal vectors, then ")#tao-math("\\left\\|x_1+\\ldots+x_n\\right\\|^2 = \\left\\|x_1\\right\\|^2 + \\ldots + \\left\\|x_n\\right\\|^2", block: false)#text(". In particular, we see that ")#tao-math("\\left\\|x_1+x_2\\right\\| \\geq \\left\\|x_1\\right\\|", block: false)#text(" whenever ")#mi("x_2")#text(" is orthogonal to ")#mi("x_1")#text(". ")#mi("\\diamond")

#text("A (possibly infinite) collection ")#mi("(e_\\alpha)_{\\alpha \\in A}")#text(" of vectors in a (real or complex) inner product space is said to be ")#link("http://en.wikipedia.org/wiki/Orthonormality")[#text("orthonormal")]#text(" if they are pairwise orthogonal and all of unit length.")

#strong[#text("Exercise 4. ")]#text(" Let ")#mi("(e_\\alpha)_{\\alpha \\in A}")#text(" be an orthonormal system of vectors in a real or complex inner product space. Show that this system is (algebraically) linearly independent (thus any non-trivial ")#emph[#text("finite")]#text(" linear combination of vectors in this system is non-zero). If x lies in the algebraic span of this system (i.e. it is a finite linear combination of vectors in the system), establish the inversion formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("x = \\sum_{\\alpha \\in A} \\langle x, e_\\alpha \\rangle e_\\alpha")]]

#text("(with only finitely many of the terms non-zero) and the (finite) Plancherel formula")

#align(center)[#tao-math("\\displaystyle \\left\\|x\\right\\|^2 = \\sum_{\\alpha \\in A} \\left|\\langle x, e_\\alpha \\rangle\\right|^2", block: false)#text(". ")#mi("\\diamond")#text(" (18)")]

#strong[#text("Exercise 5. ")]#text(" (")#link("http://en.wikipedia.org/wiki/Gram-Schmidt_theorem")[#text("Gram-Schmidt theorem")]#text(") Let ")#mi("e_1,\\ldots,e_n")#text(" be a finite orthonormal system in a real or complex inner product space, and let v be a vector not in the span of ")#mi("e_1,\\ldots,e_n")#text(". Show that there exists a vector ")#mi("e_{n+1}")#text(" with ")#mi("\\text{span}(e_1,\\ldots,e_n,e_{n+1}) = \\text{span}(e_1,\\ldots,e_n,v)")#text(" such that ")#mi("e_1,\\ldots,e_{n+1}")#text(" is an orthonormal system. Conclude that an n-dimensional real or complex inner product space is isomorphic to ")#mi("{\\Bbb R}^n")#text(" or ")#mi("{\\Bbb C}^n")#text(" respectively. Thus, any statement about inner product spaces which only involves a finite-dimensional subspace of that space can be verified just by checking it on Euclidean spaces. ")#mi("\\diamond")

#strong[#text("Exercise 6")]#text(" (Parallelogram law). For any inner product space V, establish the parallelogram law")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("\\left\\|x+y\\right\\|^2 + \\left\\|x-y\\right\\|^2 = 2 \\left\\|x\\right\\|^2 + 2 \\left\\|y\\right\\|^2.", block: true)]]

#text("Show that this inequality fails for ")#mi("L^p(X,{\\mathcal X},\\mu)")#text(" for ")#mi("p \\neq 2")#text(" as soon as X contains at least two disjoint sets of non-zero finite measure. On the other hand, establish the ")#link("http://en.wikipedia.org/wiki/Hanner%27s_inequalities")[#text("Hanner inequalities")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("\\left\\|f+g\\right\\|_p^p + \\left\\|f-g\\right\\|_p^p \\geq (\\left\\|f\\right\\|_p + \\left\\|g\\right\\|_p)^p + \\left|\\left\\|f\\right\\|_p - \\left\\|g\\right\\|_p\\right|^p", block: true)]]

#text("and")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("(\\left\\|f+g\\right\\|_p + \\left\\|f-g\\right\\|_p)^p + \\left|\\left\\|f+g\\right\\|_p - \\left\\|f-g\\right\\|_p\\right|^p \\leq 2^p (\\left\\|f\\right\\|_p^p + \\left\\|g\\right\\|_p^p)", block: true)]]

#text("for ")#mi("1 \\leq p \\leq 2")#text(", with the inequalities being reversed for ")#mi("2 \\leq p < \\infty")#text(". (Hint: (21) can be deduced from (20) by a simple substitution. For (20), reduce to the case when f,g are non-negative, and then exploit the inequality")

#tao-aligned(keep: true)[


#tao-math("\\left|x+y\\right|^p + \\left|x-y\\right|^p  & \\geq ((1+r)^{p-1} + (1-r)^{p-1}) x^p", block: true)



#tao-math(" & + ((1+r)^{p-1} - (1-r)^{p-1}) r^{1-p} y^p", block: true, numbering: n => [#text("(22)")])
]

#text("for all non-negative x,y, ")#mi("0 < r < 1")#text(", and ")#mi("1 \\leq p \\leq 2")#text(", with the inequality being reversed for ")#mi("2 \\leq p < \\infty")#text(", and with equality being attained when ")#mi("y < x")#text(" and ")#mi("r=y/x")#text(". ")#mi("\\diamond")

#heading(level: 1)[#text("— Hilbert spaces —")]

#text("Thus far, our discussion of inner product spaces has been largely algebraic in nature; this is because we have not been able to take limits inside these spaces and do some actual analysis. This can be rectified by adding an additional axiom.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2. ")]#text(" (Hilbert spaces) A (real or complex) Hilbert space is a (real or complex) inner product space which is ")#link("http://en.wikipedia.org/wiki/Complete_metric_space")[#text("complete")]#text(" (or equivalently, an inner product space which is also a ")#link("http://en.wikipedia.org/wiki/Banach_space")[#text("Banach space")]#text(").")
]

#strong[#text("Example 6.")]#text(" From Proposition 1 from ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("Notes 3")]#text(", (real or complex) ")#mi("L^2(X,{\\mathcal X},\\mu)")#text(" is a Hilbert space for any measure space ")#mi("(X,{\\mathcal X},\\mu)")#text(". In particular, ")#mi("{\\Bbb R}^n")#text(" and ")#mi("{\\Bbb C}^n")#text(" are Hilbert spaces. ")#mi("\\diamond")

#strong[#text("Exercise 7.")]#text(" Show that a subspace of a Hilbert space H will itself be a Hilbert space if and only if it is closed. (In particular, proper dense subspaces of Hilbert spaces are not Hilbert spaces.)")

#strong[#text("Example 7.")]#text(" By Example 6, the space ")#mi("l^2({\\Bbb Z})")#text(" of doubly infinite square-summable sequences is a Hilbert space. Inside this space, the space ")#mi("c_c({\\Bbb Z})")#text(" of sequences of finite support is a proper dense subspace (e.g. by Proposition 2 of ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("Notes 3")]#text(", though this can also be seen much more directly), and so cannot be a Hilbert space. ")#mi("\\diamond")

#strong[#text("Exercise 8.")]#text(" Let V be an inner product space. Show that there exists a Hilbert space ")#mi("\\overline{V}")#text(" which contains a dense subspace isomorphic to V; we refer to ")#mi("\\overline{V}")#text(" as a ")#link("http://en.wikipedia.org/wiki/Completion_(metric_space)#Completion")[#text("completion")]#text(" of V. Furthermore, this space is essentially unique in the sense that if ")#mi("\\overline{V}")#text(", ")#mi("\\overline{V}^{\\prime}")#text(" are two such completions, then there exists an isomorphism from ")#mi("\\overline{V}")#text(" to ")#mi("\\overline{V}^{\\prime}")#text(" which are the identity on V (if one identifies V with the dense subspaces of ")#mi("\\overline{V}")#text(" and ")#mi("\\overline{V^{\\prime}}")#text(". Because of this fact, inner product spaces are sometimes known as ")#link("http://en.wikipedia.org/wiki/Pre-Hilbert_space")[#text("pre-Hilbert spaces")]#text(", and can always be identified with dense subspaces of actual Hilbert spaces. ")#mi("\\diamond")

#strong[#text("Exercise 9.")]#text(" Let H, H’ be two Hilbert spaces. Define the ")#link("http://en.wikipedia.org/wiki/Direct_sum")[#text("direct sum")]#text(" ")#mi("H \\oplus H^{\\prime}")#text(" of the two spaces to be the vector space ")#mi("H \\times H^{\\prime}")#text(" with inner product ")#mi("\\langle (x,x^{\\prime}), (y,y^{\\prime}) \\rangle_{H \\oplus H^{\\prime}} := \\langle x, y \\rangle_H + \\langle x^{\\prime}, y^{\\prime} \\rangle_{H^{\\prime}}")#text(". Show that ")#mi("H \\oplus H^{\\prime}")#text(" is also a Hilbert space. ")#mi("\\diamond")

#strong[#text("Example 8. ")]#text(" If H is a complex Hilbert space, one can define the ")#emph[#text("complex conjugate")]#text(" ")#mi("\\overline{H}")#text(" of that space to be the set of formal conjugates ")#mi("\\{ \\overline{x}: x \\in H \\}")#text(" of vectors in H, with complex vector space structure ")#mi("\\overline{x} + \\overline{y} := \\overline{x+y}")#text(" and ")#mi("c \\overline{x} := \\overline{\\overline{c} x}")#text(", and inner product ")#mi("\\langle \\overline{x}, \\overline{y} \\rangle_{\\overline{H}} := \\langle y, x \\rangle_H")#text(". One easily checks that ")#mi("\\overline{H}")#text(" is again a complex Hilbert space. Note the map ")#mi("x \\mapsto \\overline{x}")#text(" is not a complex linear isometry; instead, it is a complex ")#link("http://en.wikipedia.org/wiki/Antilinear")[#text("antilinear")]#text(" isometry. ")#mi("\\diamond")

#text("A key application of the completeness axiom is to be able to define the “nearest point” from a vector to a closed convex body.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1.")]#text(" (Existence of minimisers) Let H be a Hilbert space, let K be a non-empty closed convex subset of H, and let x be a point in H. Then there exists a unique y in K that minimises the distance ")#tao-math("\\left\\|y-x\\right\\|", block: false)#text(" to x. Furthermore, for any other z in K, we have ")#mi("\\text{Re} \\langle z-y, y-x \\rangle \\geq 0")#text(".")
]

#strong[#text("Proof.")]#text(" Observe from the parallelogram law (19) the (geometrically obvious) fact that if y and y’ are distinct and equidistant from x, then their midpoint ")#mi("(y+y^{\\prime})/2")#text(" is strictly closer to x than either of y or y’. This ensures that the distance minimiser, if it exists, is unique. Also, if y is the distance minimiser and z is in K, then ")#mi("(1-\\theta) y + \\theta z")#text(" is at least as distant from x as y is for any ")#mi("0 < \\theta < 1")#text(", by convexity; squaring this and rearranging, we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#tao-math("2 \\text{Re} \\langle z-y, y-x \\rangle + \\theta \\left\\| z-y\\right\\|^2 \\geq 0.", block: true)]]

#text("Letting ")#mi("\\theta \\to 0")#text(" we obtain the final claim in the proposition.")

#text("It remains to show existence. Write ")#tao-math("D := \\inf_{y \\in K} \\left\\|x-y\\right\\|", block: false)#text(". It is clear that D is finite and non-negative. If the infimum is attained then we would be done. We cannot conclude immediately that this is the case, but we can certainly find a sequence ")#mi("y_n \\in K")#text(" such that ")#tao-math("\\left\\|x-y_n\\right\\| \\to D", block: false)#text(". On the other hand, the midpoints ")#mi("\\frac{y_n+y_m}{2}")#text(" lie in K by convexity and so ")#tao-math("\\left\\|x - \\frac{y_n+y_m}{2}\\right\\| \\geq D", block: false)#text(". Using the parallelogram law (19) we deduce that ")#tao-math("\\left\\|y_n - y_m\\right\\| \\to 0", block: false)#text(" as ")#mi("n, m \\to \\infty")#text(" and so ")#mi("y_n")#text(" is Cauchy; by completeness, it converges to a limit y, which lies in K since K is closed. From the triangle inequality we see that ")#tao-math("\\left\\|x-y_n\\right\\| \\to \\left\\|x-y\\right\\|", block: false)#text(", and thus ")#tao-math("\\left\\|x-y\\right\\| = D", block: false)#text(", and so y is a distance minimiser. ")#mi("\\Box")

#strong[#text("Exercise 10.")]#text(" Show by constructing counterexamples that the existence of the distance minimiser y can fail if either the closure or convexity hypothesis on K is dropped, or if H is merely an inner product space rather than a Hilbert space. (Hint: for the last case, let H be the inner product space ")#mi("C([0,1]) \\subset L^2([0,1])")#text(", and let K be the subspace of continuous functions supported on ")#mi("{}[0,1/2]")#text(".) On the other hand, show that existence (but not uniqueness) can be recovered if K is assumed to be ")#link("http://en.wikipedia.org/wiki/Compactness")[#text("compact")]#text(" rather than convex. ")#mi("\\diamond")

#strong[#text("Exercise 11.")]#text(" Using the Hanner inequalities (Exercise 6), show that Proposition 1 also holds for the ")#mi("L^p")#text(" spaces as long as ")#mi("1 < p < \\infty")#text(". (The specific feature of the ")#mi("L^p")#text(" spaces that is allowing this is known as ")#link("http://en.wikipedia.org/wiki/Uniformly_convex_space")[#text("uniform convexity")]#text(".) Give counterexamples to show that the propsition can fail for ")#mi("L^1")#text(" and for ")#mi("L^\\infty")#text(". ")#mi("\\diamond")

#text("This proposition has some importance in ")#link("http://en.wikipedia.org/wiki/Calculus_of_variations")[#text("calculus of variations")]#text(", but we will not pursue those applications here.")

#text("Since every subspace is necessarily convex, we have a corollary:")

#strong[#text("Exercise 12.")]#text(" (Orthogonal projections) Let V be a closed subspace of a Hilbert space H. Then for every ")#mi("x \\in H")#text(" there exists a unique decomposition ")#mi("x = x_V + x_{V^\\perp}")#text(", where ")#mi("x_V \\in V")#text(" and ")#mi("x_{V^\\perp}")#text(" is orthogonal to every element of V. Furthermore, ")#mi("x_V")#text(" is the closest element of V to x. ")#mi("\\diamond")

#text("Let ")#mi("\\pi_V: H \\to V")#text(" be the map ")#mi("\\pi_V: x \\mapsto x_V")#text(", where ")#mi("x_V")#text(" is given by the above exercise; we refer to ")#mi("\\pi_V")#text(" as the ")#emph[#text("orthogonal projection")]#text(" from H onto V. It is not hard to see that ")#mi("\\pi_V")#text(" is linear, and from the Pythagorean theorem we see that ")#mi("\\pi_V")#text(" is a contraction (thus ")#tao-math("\\left\\|\\pi_V x\\right\\| \\leq \\left\\|x\\right\\|", block: false)#text(" for all ")#mi("x \\in V")#text("). In particular, ")#mi("\\pi_V")#text(" is continuous.")

#strong[#text("Exercise 13.")]#text(" (Orthogonal complement) Given a subspace V of a Hilbert space H, define the ")#emph[#text("orthogonal complement")]#text(" ")#mi("V^\\perp")#text(" of V to be the set of all vectors in H that are orthogonal to every element of V. Establish the following claims:")

#enum(start: 1, 
[#mi("V^\\perp")#text(" is a closed subspace of H, and that ")#mi("(V^\\perp)^\\perp")#text(" is the closure of V.")],
[#mi("V^\\perp")#text(" is the trivial subspace {0} if and only if V is dense.")],
[#text("If V is closed, then H is isomorphic to the direct sum of V and ")#mi("V^\\perp")#text(".")],
[#text("If V, W are two closed subspaces of H, then ")#mi("(V + W)^\\perp = V^\\perp \\cap W^\\perp")#text(" and ")#mi("(V \\cap W)^\\perp = \\overline{V^\\perp + W^\\perp}")#text(". ")#mi("\\diamond")]
)

#text("Every vector ")#mi("v")#text(" in a Hilbert space gives rise to a continuous linear functional ")#mi("\\lambda_v: H \\to {\\Bbb C}")#text(", defined by the formula ")#mi("\\lambda_v(w) := \\langle w, v \\rangle")#text(" (the continuity follows from the Cauchy-Schwarz inequality). The ")#emph[#text("Riesz representation theorem for Hilbert spaces")]#text(" gives a converse:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" (")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem#The_Hilbert_space_representation_theorem")[#text("Riesz representation theorem for Hilbert spaces")]#text(") Let H be a complex Hilbert space, and let ")#mi("\\lambda: H \\to {\\Bbb C}")#text(" be a continuous linear functional on H. Then there exists a unique v in H such that ")#mi("\\lambda=\\lambda_v")#text(". A similar claim holds for real Hilbert spaces (replacing ")#mi("{\\Bbb C}")#text(" by ")#mi("{\\Bbb R}")#text(" throughout).")
]

#strong[#text("Proof.")]#text(" We just show the claim for complex Hilbert spaces, as the claim for real Hilbert spaces is very similar. First, we show uniqueness: if ")#mi("\\lambda_v = \\lambda_{v^{\\prime}}")#text(", then ")#mi("\\lambda_{v-v^{\\prime}}=0")#text(", and in particular ")#mi("\\langle v-v^{\\prime}, v-v^{\\prime} \\rangle=0")#text(", and so v=v’.")

#text("Now we show existence. We may assume that ")#mi("\\lambda")#text(" is not identically zero, since the claim is obvious otherwise. Observe that the kernel ")#mi("V := \\{ x \\in H: \\lambda(x) = 0 \\}")#text(" is then a proper subspace of H, which is closed since ")#mi("\\lambda")#text(" is continuous. By Exercise 13, the orthogonal complement ")#mi("V^\\perp")#text(" must contain at least one non-trivial vector w, which we can normalise to have unit magnitude. Since w doesn’t lie in V, ")#mi("\\lambda(w)")#text(" is non-zero. Now observe that for any x in H, ")#mi("x - \\frac{\\lambda(x)}{\\lambda(w)} w")#text(" lies in the kernel of ")#mi("\\lambda")#text(", i.e. it lies in V. Taking inner products with w, we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\langle x, w\\rangle - \\frac{\\lambda(x)}{\\lambda(w)} = 0")]]

#text("and thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\lambda(x) = \\langle x, \\overline{\\lambda(w)} w \\rangle")]]

#text("Thus we have ")#mi("\\lambda = \\lambda_{\\overline{\\lambda(w)} w}")#text(", and the claim follows. ")#mi("\\Box")

#strong[#text("Remark 1.")]#text(" This result gives an alternate proof of the p=2 case of Theorem 1 from ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("Notes 3")]#text(", and by modifying Remark 10 from ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("Notes 3")]#text(", can be used to give an alternate proof of the Lebesgue-Radon-Nikodym theorem (this proof is due to von Neumann). ")#mi("\\diamond")

#strong[#text("Remark 2.")]#text(" In the next set of notes, when we define the notion of a dual space, we can reinterpret the Riesz representation theorem as providing a canonical isomorphism ")#mi("H^* \\equiv \\overline{H}")#text(". ")#mi("\\diamond")

#strong[#text("Exercise 14.")]#text(" Using Exercise 11, give an alterate proof of the ")#mi("1 < p < \\infty")#text(" case of Theorem 1 from ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("Notes 3")]#text(". ")#mi("\\diamond")

#text("One important consequence of the Riesz representation theorem is the existence of adjoints:")

#strong[#text("Exercise 15.")]#text(" Let ")#mi("T: H \\to H^{\\prime}")#text(" be a continuous linear transformation. Show that that there exists a unique continuous linear transformation ")#mi("T^\\dagger: H^{\\prime} \\to H")#text(" with the property that ")#mi("\\langle Tx, y \\rangle = \\langle x, T^\\dagger y \\rangle")#text(" for all ")#mi("x \\in H")#text(" and ")#mi("y \\in H^{\\prime}")#text(". The transformation ")#mi("T^\\dagger")#text(" is called the (Hilbert space) ")#link("http://en.wikipedia.org/wiki/Adjoint_of_an_operator")[#text("adjoint")]#text(" of T; it is of course compatible with the notion of an ")#link("http://en.wikipedia.org/wiki/Conjugate_transpose")[#text("adjoint matrix")]#text(" from linear algebra. ")#mi("\\diamond")

#strong[#text("Exercise 16.")]#text(" Let ")#mi("T: H \\to H^{\\prime}")#text(" be a continuous linear transformation.")

#enum(start: 1, 
[#text("Show that ")#mi("(T^\\dagger)^\\dagger = T")#text(".")],
[#text("Show that T is an isometry if and only if ")#mi("T^\\dagger T = \\text{id}_H")#text(".")],
[#text("Show that T is an isomorphism if and only if ")#mi("T^\\dagger T = \\text{id}_H")#text(" and ")#mi("T{T^\\dagger}={\\text{id}}_{H^{\\prime}}")#text(".")],
[#text("If ")#mi("S: H^{\\prime} \\to H^{\\prime\\prime}")#text(" is another continuous linear transformation, show that ")#mi("(ST)^\\dagger = T^\\dagger S^\\dagger")#text(". ")#mi("\\diamond")]
)

#strong[#text("Remark 3. ")]#text(" An isomorphism of Hilbert spaces is also known as a ")#link("http://en.wikipedia.org/wiki/Unitary_transformation")[#text("unitary transformation")]#text(". (For real Hilbert spaces, the term")#link("http://en.wikipedia.org/wiki/Orthogonal_matrix")[#text(" orthogonal transformation")]#text(" is sometimes used instead.) Note that unitary and orthogonal ")#mi("n \\times n")#text(" matrices generate ")#link("http://en.wikipedia.org/wiki/Unitary_matrix")[#text("unitary")]#text(" and ")#link("http://en.wikipedia.org/wiki/Orthogonal_matrix")[#text("orthogonal")]#text(" transformations on ")#mi("{\\Bbb C}^n")#text(" and ")#mi("{\\Bbb R}^n")#text(" respectively. ")#mi("\\diamond")

#strong[#text("Exercise 17.")]#text(" Show that the projection map ")#mi("\\pi_V: H \\to V")#text(" from a Hilbert space to a closed subspace is the adjoint of the inclusion map ")#mi("\\iota_V: V \\to H")#text(". ")#mi("\\diamond")

#heading(level: 1)[#text("— Orthonormal bases —")]

#text("In the section on inner product spaces, we studied finite linear combinations of orthonormal systems. Now that we have completeness, we turn to infinite linear combinations.")

#text("We begin with countable linear combinations:")

#strong[#text("Exercise 18.")]#text(" Suppose that ")#mi("e_1, e_2, e_3, \\ldots")#text(" is a countable orthonormal system in a complex Hilbert space H, and ")#mi("c_1,c_2,\\ldots")#text(" is a sequence of complex numbers. (As usual, similar statements will hold here for real Hilbert spaces and real numbers.)")

#enum(start: 1, 
[#text("Show that the series ")#mi("\\sum_{n=1}^\\infty c_n e_n")#text(" is conditionally convergent in H if and only if ")#mi("c_n")#text(" is square-summable.")],
[#text("If ")#mi("c_n")#text(" is square-summable, show that ")#mi("\\sum_{n=1}^\\infty c_n e_n")#text(" is ")#link("http://en.wikipedia.org/wiki/Unconditionally_convergent")[#text("unconditionally convergent")]#text(" in H, i.e. every permutation of the ")#mi("c_n e_n")#text(" sums to the same value.")],
[#text("Show that the map ")#mi("(c_n)_{n=1}^\\infty \\mapsto \\sum_{n=1}^\\infty c_n e_n")#text(" is an isometry from the Hilbert space ")#mi("\\ell^2({\\Bbb N})")#text(" to H. The image V of this isometry is the smallest closed subspace of H that contains ")#mi("e_1,e_2,\\ldots")#text(", and which we shall therefore call the (Hilbert space) ")#emph[#text("span")]#text(" of ")#mi("e_1,e_2,\\ldots")#text(".")],
[#text("Take adjoints of 3. and conclude that for any ")#mi("x \\in H")#text(", we have ")#mi("\\pi_V(x) = \\sum_{n=1}^\\infty \\langle x, e_n \\rangle e_n")#text(" and ")#tao-math("\\left\\| \\pi_V(x) \\right\\| = (\\sum_{n=1}^\\infty \\left|\\langle x, e_n \\rangle\\right|^2)^{1/2}", block: false)#text(". Conclude in particular the ")#link("http://en.wikipedia.org/wiki/Bessel_inequality")[#text("Bessel inequality")]#text(" ")#tao-math("\\sum_{n=1}^\\infty \\left|\\langle x, e_n \\rangle\\right|^2 \\leq \\left\\|x\\right\\|^2", block: false)#text(".")]
)

#strong[#text("Remark 4.")]#text(" Note the contrast here between conditional and unconditional summability (which needs only square-summability of the coefficients ")#mi("c_n")#text(") and ")#link("http://en.wikipedia.org/wiki/Absolute_convergence")[#text("absolute summability")]#text(" (which requires the stronger condition that the ")#mi("c_n")#text(" are absolutely summable). In particular there exist non-absolutely summable series that are still unconditionally summable, in contrast to the situation for scalars, in which one has the ")#link("http://en.wikipedia.org/wiki/Riemann_rearrangement_theorem")[#text("Riemann rearrangement theorem")]#text(". ")#mi("\\diamond")

#text("Now we can handle arbitrary orthonormal systems ")#mi("(e_\\alpha)_{\\alpha \\in A}")#text(". If ")#mi("(c_\\alpha)_{\\alpha \\in A}")#text(" is square-summable, then at most countably many of the ")#mi("c_\\alpha")#text(" are non-zero (by Exercise 3 of ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("Notes 3")]#text("). Using parts 1,2 of Exercise 18, we can then form the sum ")#mi("\\sum_{\\alpha \\in A} c_\\alpha e_\\alpha")#text(" in an unambiguous manner. It is not hard to use Exercise 18 to then conclude that this gives an isometric embedding of ")#mi("\\ell^2(A)")#text(" into H. The image of this isometry is the smallest closed subspace of H that contains the orthonormal system, which we call the (Hilbert space) ")#emph[#text("span")]#text(" of that system. (It is the closure of the algebraic span of the system.)")

#strong[#text("Exercise 19.")]#text(" Let ")#mi("(e_\\alpha)_{\\alpha \\in A}")#text(" be an orthonormal system in H. Show that the following statements are equivalent:")

#enum(start: 1, 
[#text("The Hilbert space span of ")#mi("(e_\\alpha)_{\\alpha \\in A}")#text(" is all of H.")],
[#text("The algebraic span of ")#mi("(e_\\alpha)_{\\alpha \\in A}")#text(" (i.e. the finite linear combinations of the ")#mi("e_\\alpha")#text(") is dense in H.")],
[#text("One has the ")#link("http://en.wikipedia.org/wiki/Parseval_identity")[#text("Parseval identity")]#text(" ")#tao-math("\\left\\|x\\right\\|^2 = \\sum_{\\alpha \\in A} \\left|\\langle x, e_\\alpha \\rangle\\right|^2", block: false)#text(" for all ")#mi("x \\in H")#text(".")],
[#text("One has the inversion formula ")#mi("x = \\sum_{\\alpha \\in A} \\langle x, e_\\alpha \\rangle e_\\alpha")#text(" for all ")#mi("x \\in H")#text(" (in particular, the coefficients ")#mi("\\langle x, e_\\alpha \\rangle")#text(" are square summable).")],
[#text("The only vector that is orthogonal to all the ")#mi("e_\\alpha")#text(" is the zero vector.")],
[#text("There is an isomorphism from ")#mi("\\ell^2(A)")#text(" to H that maps ")#mi("\\delta_\\alpha")#text(" to ")#mi("e_\\alpha")#text(" for all ")#mi("\\alpha \\in A")#text(" (where ")#mi("\\delta_\\alpha")#text(" is the ")#link("http://en.wikipedia.org/wiki/Kronecker_delta")[#text("Kronecker delta")]#text(" at ")#mi("\\alpha")#text(").")]
)

#text("A system ")#mi("(e_\\alpha)_{\\alpha \\in A}")#text(" obeying any (and hence all) of the properties in Exercise 19 is known as an ")#link("http://en.wikipedia.org/wiki/Orthonormal_basis")[#text("orthonormal basis")]#text(" of the Hilbert space H. All Hilbert spaces have such a basis:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2. ")]#text("Every Hilbert space has at least one orthonormal basis.")
]

#strong[#text("Proof. ")]#text(" We use the standard ")#link("http://en.wikipedia.org/wiki/Zorn%27s_lemma")[#text("Zorn’s lemma")]#text(" argument. Every Hilbert space has at least one orthonormal system, namely the empty system. We order the orthonormal systems by inclusion, and observe that the union of any totally ordered set of orthonormal systems is again an orthonormal system. By Zorn’s lemma, there must exist a maximal orthonormal system ")#mi("(e_\\alpha)_{\\alpha \\in A}")#text(". There cannot be any unit vector orthogonal to all the elements of this system, since otherwise one could add that vector to the system and contradict orthogonality. Applying Exercise 19 in the contrapositive, we obtain an orthonormal basis as claimed. ")#mi("\\Box")

#strong[#text("Exercise 19.5.")]#text(" Show that every vector space V has at least one algebraic (or Hamel) basis, i.e. a set of basis vectors such that every vector in V can be expressed uniquely as a finite linear combination of basis vectors. ")#mi("\\diamond")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1. ")]#text(" Every Hilbert space is isomorphic to ")#mi("\\ell^2(A)")#text(" for some set A.")
]

#strong[#text("Exercise 20.")]#text(" Let A, B be sets. Show that ")#mi("\\ell^2(A)")#text(" and ")#mi("\\ell^2(B)")#text(" are isomorphic iff A and B have the same cardinality. (Hint: the case when A or B is finite is easy, so suppose A and B are both infinite. If ")#mi("\\ell^2(A)")#text(" and ")#mi("\\ell^2(B)")#text(" are isomorphic, show that B can be covered by a family of at most countable sets indexed by A, and vice versa. Then apply the ")#link("http://en.wikipedia.org/wiki/Cantor%E2%80%93Bernstein%E2%80%93Schroeder_theorem")[#text("Schroder-Bernstein theorem")]#text(". ")#mi("\\diamond")

#text("We can now classify Hilbert spaces up to isomorphism by a single ")#link("http://en.wikipedia.org/wiki/Cardinal_number")[#text("cardinal")]#text(", the ")#link("http://en.wikipedia.org/wiki/Dimension#Hilbert_spaces")[#text("dimension")]#text(" of that space:")

#strong[#text("Exercise 21.")]#text(" Show that all orthonormal bases of a given Hilbert space H have the same cardinality. This cardinality is called the (Hilbert space) ")#emph[#text("dimension")]#text(" of the Hilbert space. ")#mi("\\diamond")

#strong[#text("Exercise 22.")]#text(" Show that a Hilbert space is separable (i.e. has a countable dense subset) if and only if its dimension is at most countable. Conclude in particular that up to isomorphism, there is exactly one separable infinite-dimensional Hilbert space. ")#mi("\\diamond")

#strong[#text("Exercise 23.")]#text(" Let H, H’ be two complex Hilbert spaces. Show that there exists another Hilbert space ")#mi("H \\otimes H^{\\prime}")#text(", together with a map ")#mi("\\otimes: H \\times H^{\\prime} \\to H \\otimes H^{\\prime}")#text(" with the following properties:")

#enum(start: 1, 
[#text("The map ")#mi("\\otimes")#text(" is bilinear, thus ")#mi("(cx+dy) \\otimes x^{\\prime} = c (x \\otimes x^{\\prime}) + d (y \\otimes x^{\\prime})")#text(" and ")#mi("x \\otimes (cx^{\\prime}+dy^{\\prime}) = c (x \\otimes x^{\\prime}) + d(x \\otimes y^{\\prime})")#text(" for all ")#mi("x,y \\in H, x^{\\prime},y^{\\prime} \\in H^{\\prime}, c,d \\in {\\Bbb C}")#text(";")],
[#text("We have ")#mi("\\langle x \\otimes x^{\\prime}, y \\otimes y^{\\prime} \\rangle_{H \\otimes H^{\\prime}} = \\langle x, y \\rangle_H \\langle x^{\\prime}, y^{\\prime} \\rangle_{H^{\\prime}}")#text(" for all ")#mi("x,y \\in H, x^{\\prime},y^{\\prime} \\in H^{\\prime}")#text(".")],
[#text("The (algebraic) span of ")#mi("\\{ x \\otimes x^{\\prime}: x \\in H, x^{\\prime} \\in H^{\\prime} \\}")#text(" is dense in ")#mi("H \\otimes H^{\\prime}")#text(".")]
)

#text("Furthermore, show that ")#mi("H \\otimes H^{\\prime}")#text(" and ")#mi("\\otimes")#text(" are unique up to isomorphism in the sense that if ")#mi("H \\tilde \\otimes H^{\\prime}")#text(" and ")#mi("\\tilde \\otimes: H \\times H^{\\prime} \\to H \\tilde \\otimes H^{\\prime}")#text(" are another pair of objects obeying the above properties, then there exists an isomorphism ")#mi("\\Phi: H \\otimes H^{\\prime} \\to H \\tilde \\otimes H^{\\prime}")#text(" such that ")#mi("x \\tilde \\otimes x^{\\prime} = \\Phi( x \\otimes x^{\\prime} )")#text(" for all ")#mi("x \\in H, x^{\\prime} \\in H^{\\prime}")#text(". (Hint: to prove existence, create orthonormal bases for H and H’ and take formal tensor products of these bases.) The space ")#mi("H \\otimes H^{\\prime}")#text(" is called the (Hilbert space) ")#link("http://en.wikipedia.org/wiki/Tensor_product")[#text("tensor product")]#text(" of H and H’, and ")#mi("x \\otimes x^{\\prime}")#text(" is the ")#emph[#text("tensor product")]#text(" of x and x’. ")#mi("\\diamond")

#strong[#text("Exercise 24.")]#text(" Let ")#mi("(X, {\\mathcal X}, \\mu)")#text(" and ")#mi("(Y, {\\mathcal Y}, \\nu)")#text(" be measure spaces. Show that ")#mi("L^2( X \\times Y, {\\mathcal X} \\times {\\mathcal Y}, \\mu \\times \\nu )")#text(" is the tensor product of ")#mi("L^2(X, {\\mathcal X}, \\mu )")#text(" and ")#mi("L^2( Y, {\\mathcal Y}, \\mu )")#text(", if one defines the tensor product ")#mi("f \\otimes g")#text(" of ")#mi("f \\in L^2(X, {\\mathcal X}, \\mu)")#text(" and ")#mi("g \\in L^2(Y, {\\mathcal Y}, \\mu)")#text(" as ")#mi("f \\otimes g(x,y) := f(x) g(y)")#text(". ")#mi("\\diamond")

#text("We do not yet have enough theory in other areas to give the really useful applications of Hilbert space theory yet, but let us just illustrate a simple one, namely the development of ")#link("http://en.wikipedia.org/wiki/Fourier_series")[#text("Fourier series")]#text(" on the unit circle ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(". We can give this space the usual Lebesgue measure (identifying the unit circle with [0,1), if one wishes), giving rise to the complex Hilbert space ")#mi("L^2({\\Bbb R}/{\\Bbb Z})")#text(". On this space we can form the characters ")#mi("e_n(x) := e^{2\\pi i nx}")#text(" for all integer n; one easily verifies that ")#mi("(e_n)_{n \\in {\\Bbb Z}}")#text(" is an orthonormal system. We claim that it is in fact an orthonormal basis. By Exercise 19, it suffices to show that the algebraic span of the ")#mi("e_n")#text(", i.e. the space of ")#link("http://en.wikipedia.org/wiki/Fourier_series")[#text("trigonometric polynomials")]#text(", is dense in ")#mi("L^2({\\Bbb R}/{\\Bbb Z})")#text(". But from an explicit computation (e.g. using ")#link("http://en.wikipedia.org/wiki/Fejer_kernel")[#text("Fejér kernels")]#text(") one can show that the indicator function of any interval can be approximated to arbitrary accuracy in ")#mi("L^2")#text(" norm by trigonometric polynomials, and is thus in the closure of the trigonometric polynomials. By linearity, the same is then true of an indicator function of a finite union of intervals; since Lebesgue measurable sets in ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(" can be approximated to arbitrary accuracy by finite unions of intervals, the same is true for indicators of measurable sets. By linearity, the same is true for simple functions, and by density (Proposition 2 of ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("Notes 3")]#text(") the same is true for arbitrary ")#mi("L^2")#text(" functions, and the claim follows.")

#text("The ")#link("http://en.wikipedia.org/wiki/Fourier_transform")[#text("Fourier transform")]#text(" ")#mi("\\hat f: {\\Bbb Z} \\to {\\Bbb C}")#text(" of a function ")#mi("f \\in L^2({\\Bbb R}/{\\Bbb Z})")#text(" is defined as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\hat f(n) := \\langle f, e_n \\rangle = \\int_0^1 f(x) e^{-2\\pi i nx}\\ dx.")]]

#text("From Exercise 19, we obtain the Parseval identity")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\in {\\Bbb Z}} \\left|\\hat f(n)\\right|^2 = \\int_{{\\Bbb R}/{\\Bbb Z}} \\left|f(x)\\right|^2\\ dx", block: true)]]

#text("(in particular, ")#mi("\\hat f \\in \\ell^2({\\Bbb Z})")#text(" and the inversion formula")

#align(center)[#tao-fit-display[#mitex("f = \\sum_{n \\in {\\Bbb Z}} \\hat f(n) e_n")]]

#text("where the right-hand side is unconditionally convergent. Indeed, the Fourier transform ")#mi("f \\mapsto \\hat f")#text(" is a unitary transformation between ")#mi("L^2({\\Bbb R}/{\\Bbb Z})")#text(" and ")#mi("\\ell^2({\\Bbb Z})")#text(". (These facts are collectively referred to as ")#link("http://en.wikipedia.org/wiki/Plancherel%27s_theorem")[#text("Plancherel’s theorem")]#text(" for the unit circle.) We will develop Fourier analysis on other spaces than the unit circle later in this course (or next quarter).")

#strong[#text("Remark 5.")]#text(" Of course, much of the theory here generalises the corresponding theory in finite-dimensional linear algebra; we will continue this theme much later in the course when we turn to the spectral theorem. However, not every aspect of finite-dimensional linear algebra will carry over so easily. For instance, it turns out to be quite difficult to take the determinant or trace of a linear transformation from a Hilbert space to itself in general (unless the transformation is particularly well behaved, e.g. of ")#link("http://en.wikipedia.org/wiki/Trace_class")[#text("trace class")]#text("). The ")#link("http://en.wikipedia.org/wiki/Jordan_normal_form")[#text("Jordan normal form")]#text(" also does not translate to the infinite-dimensional setting, leading to the notorious ")#link("http://en.wikipedia.org/wiki/Invariant_subspace_problem")[#text("invariant subspace problem")]#text(" in the subject. It is also worth cautioning that while the theory of orthonormal bases in finite-dimensional Euclidean spaces generalises very nicely to the Hilbert space setting, the more general theory of bases in finite dimensions becomes much more subtle in infinite dimensional Hilbert spaces, unless the basis is “almost orthonormal” in some sense (e.g. if it forms a ")#link("http://en.wikipedia.org/wiki/Frame_of_a_vector_space")[#text("frame")]#text("). ")#mi("\\diamond")

#text("[")#emph[#text("Update")]#text(", Jan 21: notation for Hilbert space adjoint changed from ")#mi("T^*")#text(" to ")#mi("T^\\dagger")#text(", for reasons that will become clearer in the next notes.]")

#text("[")#emph[#text("Update")]#text(", Jan 22: Exercise 19.5 added.]")

#heading(level: 1)[#text("Comments (65)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-35082")[#strong[#text("S")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2009")])]

#text("Title should be 245B instead of 254A. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-35083")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2009")])]

#text("Typo: formula (5) does not parse [I have IE] ")#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-35085")[#strong[#text("S")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2009")])]

#text("Typo in the correction: 245B instead of 254B. ")#emph[#text("[Ack – fixed, this time for real hopefully – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-35108")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2009")])]

#text("Hello Professor Tao,")

#text("Do you have any recommendations on further books to continue studying Hilbert spaces, especially into modern areas of research?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-35110")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2009")])]

#text("Does anyone know why lectures 3 and 5 did not show up in my google reader?? All other lectures for 245B have so far as well as other recent posts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-35112")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2009")])]

#text("Dear Anonymous:")

#text("The same situation happens to my google reader and it is not the first time, I have no idea why this is happening.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9600342ea6c4a9d9b3c467fc166a1c600cb8a5a49b7acc1a145414977e095f9a-e44c4910e771211e44bed0cc8479a2c89f24a6b6a9c6908e32ecf8da5d7ecfcb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ulrich")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-35171")[#strong[#text("Ulrich")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2009")])]

#text("Dear Prof. Tao, do you know whether the minimiser theorem (proposition 1), as you called it, characterizes convex, closed sets in a Hilbert space?")

#text("Thanks for an answer")#linebreak()#text(" Ulrich")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-35172")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2009")])]

#text("While the standard, optimization-based proof of Cauchy-Schwarz has its nice points, there’s another approach (used for example in Axler’s rather audaciously named linear algebra text) which seems less mysterious to me. Assuming ")#mi("x\\neq 0")#text(", you can write ")#mi("y")#text(" as a scalar multiple of ")#mi("x")#text(" plus some vector orthogonal to ")#mi("x")#text(". Once you’ve worked out what those two summands are, plugging this representation of ")#mi("y")#text(" into the inner product and using orthogonality and positivity yields Cauchy-Schwarz immediately.")

#text("What I like about this approach in part is that it immediately introduces the idea of orthogonal projection in a geometric way.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-35173")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2009")])]

#text("Dear Ulrich,")

#text("Well, if you require ")#emph[#text("all")]#text(" the conclusions of the proposition (existence and uniqueness of the minimiser, together with the obtuse angle condition), then the answer seems to be yes: if K is not closed, then picking x to be an adherent point will give a counterexample, and if K is not convex, then picking x to lie outside of K in an interval whose endpoints a, b lie in K will give another counterexample (as it is not possible for a, b to both lie in the half-space ")#mi("\\{ z: Re \\langle z-y,y-x \\rangle \\geq 0 \\}")#text(" without x lying in this space also, which is not possible unless x=y, which forces x to lie in K, a contradiction).")

#text("I don’t know what happens though if one starts dropping assumptions. The obtuse angle condition implies uniqueness; but if one drops both the obtuse angle condition and uniqueness, then any compact set K will have minimisers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9600342ea6c4a9d9b3c467fc166a1c600cb8a5a49b7acc1a145414977e095f9a-e44c4910e771211e44bed0cc8479a2c89f24a6b6a9c6908e32ecf8da5d7ecfcb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ulrich Groh")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-35175")[#strong[#text("Ulrich Groh")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2009")])]

#text("Dear Professor Tao, thank you for the fast answer. As I see, my question was not precise enough. Is the following true: Let H be a Hilbert space and K a closed subset of H with the following property: For every x in H there exist an unique z in K which minimizes the distance of x to the set K. Then K is convex. Maybe I overlooked something and the answer is trivial …")

#text("Thanks.")

#text("Ulrich")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5ac2923fa40b6d9d30a7c5a4ccbefa3f9bbb4392cf00b393fa57e6a51ca6684b-1cb156f584efbabaf7a979b27986c5ff6024f807cf8b07aa8015209d6ec02e08.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dussau")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-35177")[#strong[#text("Dussau")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2009")])]

#text("Dear Ulrich,")

#text("As prof. Tao said if K in not convex then there exists x in H which does not admit only one extremiser. And you can see that this fact is equivalent with the property that you evoke.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/626e53d46c710500df401cd08527c0d77bc41c025132055eb6b1eff8f8e41115-d87af44ed68cc76739d63ca4c13478d58612e8f3dab93013de42dffa7899abb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-35202")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2009")])]

#text("If we drop the obtuse angle condition, I don’t see why uniqueness alone should imply convexity. I can’t come up with a counterexample, but the proof above certainly breaks down.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-35204")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2009")])]

#text("Hmm, an interesting problem. I think I can prove the converse in the case when K is finite-dimensional (say ")#mi("K \\subset {\\Bbb R}^n")#text(") and bounded, by an induction on dimension, though it was trickier than I anticipated. First observe that K must be closed (otherwise any limit point outside K will contradict existence of the minimiser), hence compact. This, together with uniqueness, can be used to show that the function ")#mi("f: x \\mapsto y")#text(" from a point to its unique minimiser must be continuous (for if ")#mi("x_n \\to x")#text(" and the sequence ")#mi("f(x_n) \\in K")#text(" did not converge to f(x), then some subsequence would converge to an alternate minimiser). So now we have a continuous retraction from ")#mi("{\\Bbb R}^n")#text(" to K.")

#text("It is not hard to show (by looking at how nearby balls of the same radius intersect each other) that if one has unique minimisers depending continuously on the initial point x, then ")#tao-math("\\text{dist}(x,K) = \\left|x-f(x)\\right|", block: false)#text(" cannot have a local maximum outside of K. From this we see that the complement of the compact set K contains no bounded connected components, and is therefore connected.")

#text("Now look at the convex hull ")#mi("\\overline{K}")#text(" of K, and let ")#mi("\\pi")#text(" be a tangent hyperplane for ")#mi("\\overline{K}")#text(". We claim that ")#mi("K \\cap \\pi")#text(" has the unique minimiser property inside ")#mi("\\pi")#text("; indeed, if x lies in ")#mi("\\pi")#text(" and does not have unique minimisers to ")#mi("K \\cap \\pi")#text(", then by moving x in the normal direction to ")#mi("\\pi")#text(" away from K and using compactness of K one eventually contradicts unique minimisation for K. By induction hypothesis, this implies ")#mi("K \\cap \\pi")#text(" is convex and thus equal to ")#mi("\\overline{K} \\cap \\pi")#text(". Taking unions over all ")#mi("\\pi")#text(", we conclude that K contains the entire boundary of its convex hull; since the complement of K has only one connected component, we conclude ")#mi("K = \\overline{K}")#text(", which gives convexity.")

#text("It may be that this argument extends to the case of compact K in infinite dimensions, but I do not know what to predict in the non-compact or unbounded case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-35217")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2009")])]

#text("Dear Professor Tao:")

#text("About (22), since the left-hand side is symmetric and the right-hand side is seemingly not, I am thinking if the nonnegative x, y should be asked to satisfy x>y.")

#text("Xiaochuan")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-35218")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2009")])]

#text("Hmm, you’re right. I’ve adjusted the hint somewhat to deal with this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f472aee6f89cc6d948351fd1429e48a345466a7c1a43eebe3c65f7e8ac1b2264-5b19c144e75296804b262543bc8017c8d3b0c24fa37d87cac1b5994d698fbfb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dmitriy")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-35233")[#strong[#text("Dmitriy")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2009")])]

#text("Concerning Ulrich’s question: As far as I know this is an open question in the Hilbert space theory (at least it was about 3 years ago when I heard about it)")#linebreak()#text(" The sets with this property are called Chebyshev sets.")

#text("I just googled it a little and it seems that this problem (whether the class of Chebyshev sets in an infinite-dimensional Hilbert space coincides with the class of convex sets) is still unsolved.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9600342ea6c4a9d9b3c467fc166a1c600cb8a5a49b7acc1a145414977e095f9a-e44c4910e771211e44bed0cc8479a2c89f24a6b6a9c6908e32ecf8da5d7ecfcb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ulrich")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-35234")[#strong[#text("Ulrich")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2009")])]

#text("Prof. Tao, Dmitriy, thank you for the effort and the interesting remark.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-35240")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2009")])]

#text("Dear Prof Tao,")

#text("I’m reading Hahn-Banach Thm, and I’m thinking is it because in the case of Hilbert Space the Thm is trivial, so we want to have this Thm in Banach Space? And we also want to bound the functional with some Norm?")

#text("Paul")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-35241")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2009")])]

#text("Actually, it’s much more general, it’s just a vector space.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 6: Duality and the Hahn-Banach theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-35263")[#strong[#text("245B, Notes 6: Duality and the Hahn-Banach theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2009")])]

#text("[…] other topological space).) In other cases, most notably with Hilbert spaces as discussed in Notes 5, the dual object is identical to X […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-35659")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2009")])]

#text("Dear Terry,")

#text("Does the set of all inner products of a vector space have some (algebraic, analytic, geometric) structure or interpretation?")

#text("Best, Billy Blanc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 实分析0-10 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-35898")[#strong[#text("实分析0-10 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("[…] 第五节更是老朋友了，Hilbert空间。本节中除了一般书籍中常见的知识之外，有一个Hanner不等式（习题6）我从来没有见过，该不等式加强了平行四边形法则。另一个值得注意的地方是，Riesz表示定理竟然可以跟Lebesgue-Radon-Nikodym定理互推。在正交基的存在定理中，传说中的选择公理又来了。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gokhan")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-36742")[#strong[#text("gokhan")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2009")])]

#text("Dear Prof. Tao,")

#text("if we have two seperable Hilbert spaces H, H’, can we say that their tensor product is isometrically isomorphic to the space of Hilbert Schmidt operators from H to H’ with Hilbert Schmidt inner product?")

#text("if we have tensor product of H by itself 3 times ,i.e, ")#mi("H\\otimes H \\otimes H")#text(", is it isometrically isomorphic to the followings:")

#text("1)Hilbert Schmidt operators from H to ")#mi("H\\otimes H")#linebreak()#text(" 2)Hilbert Schmidt operators from ")#mi("H\\otimes H")#text(" to H")

#text("thanks,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-36745")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2009")])]

#text("Dear gokhan,")

#text("For real Hilbert spaces, this is correct. For complex Hilbert spaces, there is a small subtlety: the space of Hilbert-Schmidt operators from H to H’ is naturally isomorphic to ")#mi("\\overline{H} \\otimes H^{\\prime}")#text(" (or ")#mi("H^* \\otimes H^{\\prime}")#text(") rather than ")#mi("H \\otimes H^{\\prime}")#text(". (Of course, if one picks an orthonormal basis, then one can produce an isomorphism between H and ")#mi("\\overline{H}")#text(", and thus between ")#mi("H \\otimes H^{\\prime}")#text(" and ")#mi("\\overline{H} \\otimes H^{\\prime}")#text(", but this isomorphism depends on the choice of basis and is thus not natural (in the category-theoretic sense).)")

#text("(In the above discussion, one has to of course use the Hilbert space tensor product, which is slightly different from the vector space tensor product.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254C, Notes 2: The Fourier transform « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-37983")[#strong[#text("254C, Notes 2: The Fourier transform « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2009")])]

#text("[…] of at the corresponding frequency. Applying the general theory of orthonormal bases (see Notes 5), we obtain the following consequences: Corollary 5 (Plancherel theorem for compact abelian […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-38326")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2009")])]

#text("Dear Professor Tao,")

#text("I encountered an example of a continuous probability measure on a unit sphere of a separable Hilbert space such that the scalar product of two independent copies from this measure is discrete. It sounds counterintuitive, so I was wondering if there is a simple way to see the existence of such measure, or if this contradicts anything you know?")

#text("Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Higher order Hilbert spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-44992")[#strong[#text("Higher order Hilbert spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2010")])]

#text("[…] is extremely standard, and can be found in any graduate real analysis course (I myself covered it here.) But what is perhaps less well known (except inside the fields of additive combinatorics and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82e1b386e902885d97ea288c91542f3c6923379c3d093e709ff15775063b000b-94f7b243bec7ad017d8d84cf49ddd297bfe5b5f6046280fe8361a2385758bd0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kestutis Cesnavicius")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-45446")[#strong[#text("Kestutis Cesnavicius")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2010")])]

#text("Several typos:")

#text("1. In display (15) |b| should be squared.")#linebreak()#text(" 2. In (21) a closing parenthesis is missing.")#linebreak()#text(" 3. In Exercise 9 in the definition of the inner product on the direct sum x’ and y should be switched on the RHS.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The uncertainty principle « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-45722")[#strong[#text("The uncertainty principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2010")])]

#text("[…] Hilbert space duality An element in a Hilbert space can either be thought of in physical space as a vector in that space, or in momentum space as a covector on that space. The fundamental connection between the two is given by the Riesz representation theorem for Hilbert spaces. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0243a785dbbb16ed1ee3c8a0e9e72e26d54da6f5e71ca496865cd04e2a3dda4d-02259f38256a98e583dc9b80dddb2ce4009d62c6016729c97dfcb3a5a97b482b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of QTheorist")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-46684")[#strong[#text("QTheorist")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2010")])]

#text("There is one thing I cannot figure out how to do about Hilbert space.")#linebreak()#text(" Consider an Hilbert space with a countably infinite basis. How can I by taking a limit of some sort, go to an Hilbert space with a continuous (not countable) basis ?")#linebreak()#text(" In other words, consider the following basis vector in the first Hilbert space (……0 0 0 1 0 0 ….) that is with a 1 somewhere. How can I go to the obvious basis vector for the continuous hilbert space, which is a Dirac delta function at some point x by taking a limit of some sort from the first to the second ??")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-46687")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2010")])]

#text("One has to be a little careful with the notion of a basis when one works in the uncountable setting. For instance, when working with the Hilbert space ")#mi("L^2[0,1]")#text(" of square-integrable functions on the unit interval, the Dirac masses ")#mi("\\delta_x")#text(" for ")#mi("x \\in [0,1]")#text(" are technically not a basis for this space, as they do not even lie in the Hilbert space to begin with. Also, while it may appear at first glance that the space of functions on [0,1] has an uncountable number of degrees of freedom, the requirement that the function be measurable (and, ")#emph[#text("a fortiori")]#text(", square-integrable) is actually quite a strong constraint (particularly when combined with the convention of identifying any two functions that agree almost everywhere), and reduces the number of degrees of freedom to only countably many. This for instance can be seen by using the Fourier transform and Plancherel’s theorem to identify ")#mi("L^2[0,1]")#text(" with ")#mi("\\ell^2({\\bf Z})")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0243a785dbbb16ed1ee3c8a0e9e72e26d54da6f5e71ca496865cd04e2a3dda4d-02259f38256a98e583dc9b80dddb2ce4009d62c6016729c97dfcb3a5a97b482b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of QTheorist")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-46718")[#strong[#text("QTheorist")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2010")])]

#text("I am sorry I probably was not clear enough. I am a physicist and used to work with Hilbert spaces more or less as vector spaces for my wave functions. For example if I work with spin-1/2 with two levels I use a wave function which is a vector of functions (F1 F2) and operators acting on it are just 2*2 matrices. The simplest basis for the vectors in this space are (1 0) and (0 1) which is indeed what we use as this basis refers to some bare states of the system we know (like up spin and down spin).")

#text("Now when we deal with continuous degrees of freedom such as position and momentum, my vector of functions (my wave function) is an infinite length vector and operators are infinite matrices. But most importantly, this objects are continuous now. So the most convenient basis we use is the Dirac delta function, which even though it does not lies in the Hilbert space is very convenient for representation of the states. Indeed if I want to represent my wave function in the position basis, momentum states are plane waves, which physicists like for their simple properties. Same thing for position states in the momentum basis. The dirac delta function, which we thus use a for the basis “state” has the usual propoerties we expect for a basis (closure relation, orthogonality)…")

#text("I remarked that even though I seems perfectly natural to use this as basis, there is no evident way of going to the basis I used for the discrete case to the continuous case, by taking for example a limit of some sort that would bring the number of degrees of freedom to infinity and reduce the “distance” between them so as to make the result continuous. How do I get from e.g (1 0) to delta(x) by some limit ?")

#text("This question is very important for new treatments of paths integrals where one knows the discrete limit, the continuous limit, but going from one to the other by taking an obvious limit is mathematically tricky.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-46725")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2010")])]

#text("One way to represent a “continuous” Hilbert space as a limit of “discrete” ones is by letting the finest scale one permits to go to zero. For instance, inside the Hilbert space ")#mi("L^2[0,1]")#text(" of square-integrable functions on [0,1], consider the subspace ")#mi("L^2[0,1]_n")#text(" of functions in ")#mi("L^2[0,1]")#text(" which are constant on the dyadic intervals ")#mi("[i/2^n, (i+1)/2^n)")#text(" for ")#mi("i=0,\\ldots,2^n-1")#text(". This is a finite-dimensional Hilbert space, with an (un-normalised) orthogonal basis given by the ")#mi("2^n")#text(" functions ")#mi("2^n 1_{[i/2^n, (i+1)/2^n)}")#text(" for ")#mi("i=0,\\ldots,2^n-1")#text(", which are approximations to the Dirac delta functions. Letting n go to infinity, the subspaces ")#mi("L^2[0,1]_n")#text(" increase and have ")#mi("L^2[0,1]")#text(" as their direct limit (because the Hilbert space closure of ")#mi("\\bigcup_{n=1}^\\infty L^2[0,1]_n")#text(" is ")#mi("L^2[0,1]")#text("), while the approximate delta functions converge (in the sense of distributions) to Dirac delta functions.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0243a785dbbb16ed1ee3c8a0e9e72e26d54da6f5e71ca496865cd04e2a3dda4d-02259f38256a98e583dc9b80dddb2ce4009d62c6016729c97dfcb3a5a97b482b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of QTheorist")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-46740")[#strong[#text("QTheorist")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2010")])]

#text("This is a very nice idea indeed !")#linebreak()#text(" But I noticed that it does not allow the case of infinite vectors with discrete levels. Indeed I can consider a wave function of the type ")#mi("|\\psi_0\\rangle=(\\ldots \\psi_n\\ldots)")#text(" with ")#mi("n\\in\\mathbb{N}")#text(", which would be the case for a quantum system evolving on an infinite lattice for example. But then if I want to go from this lattice to a continuous space, that is ending up with ")#mi("\\psi_n\\to\\psi(\\alpha)")#text(" varying continuously with some parameter ")#mi("\\langle \\alpha|\\psi\\rangle=\\psi(\\alpha)")#text(" how can I get this from ")#mi("|\\psi_0\\rangle")#text(" ? I cannot see how I can use the trick you presented before as I would need to start with an infinity of intervals ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-46746")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2010")])]

#text("Well, one can truncate in space (to finitise the largest scale) simultaneously with discretising (to finitise the smallest scake). For instance one can approximate ")#mi("L^2({\\bf R})")#text(" by the finite-dimensional subspace ")#mi("L^2({\\bf R})_n")#text(" of functions that are piecewise constant on dyadic intervals of length ")#mi("2^{-n}")#text(", while being supported on the interval ")#mi("[-2^{n}, 2^n]")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0243a785dbbb16ed1ee3c8a0e9e72e26d54da6f5e71ca496865cd04e2a3dda4d-02259f38256a98e583dc9b80dddb2ce4009d62c6016729c97dfcb3a5a97b482b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of QTheorist")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-46759")[#strong[#text("QTheorist")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2010")])]

#text("Thank you that makes perfect sense, I shall try to put this idea in practice shortly !")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/181769477cf0e1352f672b71d0f46979bc8feb8b99f4b1bc23f45d2a241e4a15-6884cfdbbd97d010c43586528bf5830891bf81b69bd1e720a9ded593daa486de.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hilbert spaces from the mathematician’s perspective « Polariton")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-46722")[#strong[#text("Hilbert spaces from the mathematician’s perspective « Polariton")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2010")])]

#text("[…] 245B Notes 5: Hlibert spaces […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-50877")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2011")])]

#text("In exercise 12, what if one drops the assumption that the subspace is “closed”? The decomposition still exists?(Though not unique?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-50879")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2011")])]

#text("This is a good exercise to test your intuition, and I won’t spoil it. (However, I will say that a good example of a non-closed subspace is a dense subspace.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-50883")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2011")])]

#text("When we define the complex inner product space, why use ")#mi("\\langle x,y\\rangle=\\overline{ \\langle y,x\\rangle}")#text(" instead of ")#mi("\\langle x,y\\rangle= \\langle y,x\\rangle")#text(". I remember you mentioned in the linear algebra course that things like ")#mi("\\langle i,i\\rangle=i^2=-1")#text(" may happen and thus lose the positivity property if one only uses symmetry property.(Isn’t is? ) Is there any other reason for this?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-51940")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2011")])]

#text("Dear Prof. Tao,")#linebreak()#text(" In proposition 2, you prove that ” Every Hilbert space has at least one orthonormal basis.” Since you use Zorn’s lemma here, as you said before, the proof is non-constructive. I was wondering that whether one can prove this proposition in some special cases by construction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-51942")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2011")])]

#text("I am not sure I understand your question completely but if it helps, you can construct explicit orthogonal bases for many situations; for example, the trigonometric polynomials are an orthogonal basis for L^2 on the circle, or sine functions with integer frequencies are an orthogonal basis for L^2 on (0,pi) etc.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-255870")[#strong[#text("Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2013")])]

#text("[…] proof of the existence of orthogonal projections in Hilbert spaces (see e.g. Proposition 1 of this previous blog post), so on some level the two proofs of the regularity lemma are essentially equivalent. However, the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An abstract ergodic theorem, and the Mackey-Zimmer theorem | What's new")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-376243")[#strong[#text("An abstract ergodic theorem, and the Mackey-Zimmer theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2014")])]

#text("[…] closed, convex, and non-empty in a Hilbert space, it is a classical fact (see e.g. Proposition 1 of this previous post) that it has a unique element of minimal norm. It is clearly -invariant, since if then the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-464336")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2015")])]

#text("What do you mean mathematically by “Optimising in ")#mi("a, b")#text("” in the proof of Lemma 1?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-464339")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2015")])]

#text("This means selecting the values of ")#mi("a,b")#text(" that give the strongest bound on ")#mi("\\langle x,y \\rangle")#text(" from the non-negativity of (15). In this case, one can select (assuming that ")#mi("x,y")#text(" are non-zero, as the inequality is obvious otherwise) ")#tao-math("a = \\left\\|y\\right\\|", block: false)#text(" and ")#tao-math("b = -\\left\\|x\\right\\| e^{i\\theta}", block: false)#text(" to conclude that ")#tao-math("\\text{Re} e^{-i\\theta} \\langle x,y \\rangle \\leq \\left\\|x\\right\\| \\left\\|y\\right\\|", block: false)#text(", which on further optimising by choosing ")#mi("\\theta")#text(" to be the phase of ")#mi("\\langle x,y\\rangle")#text(" gives the Cauchy-Schwarz inequality.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-464344")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2015")])]

#text("The method you describe (letting ")#tao-math("a = \\left\\|y\\right\\| and b = -\\left\\|x\\right\\| e^{i\\theta}", block: false)#text("), looks quite different from the one you give in")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("Amplification, arbitrage, and the tensor power trick")]
]

#text("While the later one is quite easy to remember and recover, the one you gave (which appears in lots of textbooks also) in the comment looks a little bit “")#emph[#text("ad hoc")]#text("“. Are they essential the same?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b488df94717a94de73656e78f48c2637cf97a3d7c6ce7400d1d37a6fe76a84a7-eff86ee9a4f347d3383f5ac80499c7f10f3a5c1106cef5b23be9cc9a6568adf5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vi")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-672828")[#strong[#text("Vi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2023")])]

#text("Can you please clarify how you selected those values that turned out to give the tightest bound? The selection seems quite mysterious. What am I missing>")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-464340")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2015")])]

#text("In Exercise 6, “as soon as X contains at least two disjoint sets of non-empty finite measure”? What is “non-empty finite measure”?")

#emph[#text("[This was a typo; it should be “non-zero finite measure”. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-466666")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2016")])]

#text("In Example 8, how should one understand the difference between ")#mi("H")#text(" and ")#mi("\\overline{H}")#text("? For instance if ")#mi("H:=\\mathbb{C}^n")#text(", then isn’t is true that ")#mi("\\overline{H}=H")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-466686")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2016")])]

#mi("H")#text(" and ")#mi("\\overline{H}")#text(" are canonically identifiable as ")#emph[#text("sets")]#text(", but not as ")#emph[#text("complex vector spaces")]#text(" (or as Hilbert spaces), because the complex multiplication operations ")#mi("\\cdot: {\\bf C} \\times H \\to H")#text(" and ")#mi("\\cdot: {\\bf C} \\times \\overline{H} \\to \\overline{H}")#text(" are different. For instance, the vector ")#mi("(1,0)")#text(" belongs to both ")#mi("{\\bf C}^2")#text(" and ")#mi("\\overline{{\\bf C}^2}")#text(" (or more precisely, ")#mi("\\overline{{\\bf C}^2}")#text(" contains a copy ")#mi("\\overline{(1,0)}")#text(" of ")#mi("(1,0)")#text("), but the operation of multiplying ")#mi("(1,0)")#text(" by ")#mi("i")#text(" gives ")#mi("(i,0)")#text(" in ")#mi("{\\bf C}^2")#text(" but ")#mi("(-i,0)")#text(" in ")#mi("\\overline{{\\bf C}^2}")#text(" (or more precisely, if one multiplies ")#mi("\\overline{(1,0)}")#text(" by ")#mi("i")#text(", one gets ")#mi("\\overline{(-i,0)}")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-474605")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2016")])]

#text("In the infinite dimensional case, do you have an example that a Hamel basis is also an orthonormal basis for a Hilbert space?")

#text("Are non-separable Hilbert spaces very rare? (Just like non-Lebesgue measurable sets?) I really can’t find an easy example. Do you have any “handy” example for a non-separable Hilbert space?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-474624")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2016")])]

#text("An infinite orthonormal basis, such as ")#mi("(e_n)_{n=1}^\\infty")#text(", cannot be a Hamel basis, since (for instance) ")#mi("\\sum_{n=1}^\\infty 2^{-n} e_n")#text(" will converge to an element not in the algebraic span of that basis. (Similarly for uncountable orthonormal bases.)")

#text("For an example of a non-separable Hilbert space, take ")#mi("\\ell^2(A)")#text(" for any uncountable ")#mi("A")#text(". But it is true that most Hilbert spaces one encounters in analysis and PDE (outside of functional analysis, nonstandard analysis, and other branches of analysis dealing with extremely large spaces) are indeed separable.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-480086")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2017")])]

#text("In Exercise 18.(4), what does “Take adjoints of (2).” mean?")

#emph[#text("[This should have been “Take adjoints of (3)”, i.e., to take adjoints of the linear map used in part (3). -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-480127")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2017")])]

#text("By the existence of orthonormal basis of a Hilbert space ")#mi("H")#text(", any ")#mi("x\\in H")#text(" can be written as ")#mi("x=\\sum (x,e_i)e_i")#text(" and thus for any continuous linear functional ")#mi("f")#text(" on ")#mi("H")#text(", we have")

#mi("\\displaystyle f(x)=\\sum (x,e_i)f(e_i)=(x,\\sum f(e_i)e_i)")

#text("If one sets ")#mi("y=\\sum f(e_i)e_i")#text(", then the Riesz representation is done.")

#text("This works perfectly well in the finite dimensional case. Would we have any trouble in the infinite case? (or even worse, the nonseparable case?)")

#emph[#text("[Yes, this will work in general, even in nonseparable Hilbert spaces, after one uses the Bessel inequality or Plancherel identity to help ensure convergence of all the relevant sums. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-638923")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2021")])]

#text("A particular consequence of Exercise 6 is that every finite dimensional inner product space over ")#mi("\\mathbf{C}")#text(" is a Hilbert space. Isn’t the following a more direct proof of it:")

#text("We would do induction on the dimension.")#linebreak()#text(" For the case of dimension = 1, it is trivial.")#linebreak()#text(" Take any finite dimensional inner product space ")#mi("V")#text(" over ")#mi("\\mathbf{C}")#text(", of dimension ")#mi("k+1")#text(" and let the claim be true for all dimensions ")#mi("\\le k")#text(".")#linebreak()#text(" Let ")#mi("v \\in V")#text(" be a unit vector; set ")#mi("V_1 = v \\mathbf{C}")#text(" (the space spanned by ")#mi("v")#text(") and ")#mi("V_2")#text(" to be the orthogonal complement of ")#mi("V_1")#text(" in ")#mi("V")#text(" (i.e., ")#mi("u \\in V_2 \\iff \\langle u , v \\rangle = 0 , u \\in V")#text(").")#linebreak()#text(" Then ")#mi("V")#text(" is the direct sum of ")#mi("V_1")#text(" and $V_2$. and ")#mi("V_2")#text(" is a ")#mi("k")#text(" dimensional vector space.")#linebreak()#text(" Now take any Cauchy sequence ")#mi("(v_n)_{n \\ge 1}")#text(" in ")#mi("V")#text(", we can write ")#mi("v_n = v c_n + w_n")#text(" for ")#mi("c_n \\in \\mathbf{C}")#text(" and ")#mi("w_n \\in V_2")#text(", and the Cauchy condition of ")#mi("(v_n)")#text(" implies that the sequences ")#mi("(w_n)")#text(" and ")#mi("(c_n)")#text(" are also Cauchy, whence they converge (thanks to the induction hypothesis), thus $(v_n)$ must also converge to an element of ")#mi("V")#text(", which proves the claim. ")#mi("\\square")

#text("Is this appropriate?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-638938")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2022")])]

#text("I think this proof would also allow us to show that the direct sum of two Hilbert spaces is also a Hilbert space.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-638987")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2022")])]

#text("Here is a more detailed discussion on the direct sum of Hilbert spaces being a Hilbert space.")#linebreak()#text(" ")#link("https://proofwiki.org/wiki/Hilbert_Space_Direct_Sum_is_Hilbert_Space")[#text("https://proofwiki.org/wiki/Hilbert_Space_Direct_Sum_is_Hilbert_Space")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-639497")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2022")])]

#text("In the case of ")#mi("L^2([0,1])")#text(", if one consider an orthonormal basis ")#mi("(e_n)")#text(", then ")#mi("\\int fe_n=0")#text(" for all ")#mi("n")#text(" implies that ")#mi("f=0")#text(" a.e..")

#text("Do we have such an analog if we lose orthogonality? For instance, consider the separable space ")#mi("L^1([0,1])")#text(". Let ")#mi("(e_n)")#text(" be a sequence of continuous functions on ")#mi("[0,1]")#text(" so that it is dense in ")#mi("L^1([0,1])")#text(". If ")#mi("\\int fe_n=0")#text(" for all ")#mi("n")#text(", can we say ")#mi("f=0")#text(" a.e.?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-639569")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2022")])]

#text("If the ")#mi("e_n")#text(" span a dense subspace of ")#mi("C([0,1])")#text(" then this follows from the Riesz representation theorem. Not sure if density in ")#mi("L^1")#text(" is sufficient (the natural space to use here is something like a dual or predual to ")#mi("L^1")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-657822")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2022")])]

#text("Some nitpicking: in Exercise 12 the conclusion assumes we are not treating the zero vector orthogonal to every vector; I think then in the statement you should mention that ")#mi("V")#text(" is a “proper” subspace of ")#mi("H.")

#emph[#text("[I believe Exercise 12 is correct as stated, with the conventions on orthogonality as stated – T.]")]

#text("Well I see a proof using Proposition 1 as follows:")#linebreak()#text(" since subspaces are convex sets, closed subspaces are closed convex subsets. Thanks to Proposition 1, for any given ")#mi("x \\in H")#text(" there is a unique ")#mi("y \\in V")#text(" such that ")#tao-math("\\left|\\left| y - x\\right|\\right| < \\left|\\left| z - x\\right|\\right|", block: false)#text(" for all ")#mi("z \\in V \\setminus \\{ y \\}.")#linebreak()#text(" We also have ")#mi("2 \\text{Re} \\langle z-y , y-x \\rangle \\ge 0")#text(" for all ")#mi("z \\in V;")#text(" playing around with this (plugging appropriate transformations of ")#mi("z")#text(" such as ")#mi("-z")#text(" and ")#mi("iz")#text(") gives us ")#mi("\\langle x-y , z \\rangle = 0")#text(" for all ")#mi("z \\in V;")#text(" take ")#mi("x_V = y")#text(" and ")#mi("x_{V^{\\perp}} = x-y;")#text(" we are done.")

#text("Thanks,")#linebreak()#text(" Adi")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-673020")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2023")])]

#text("Inspired by Example 2, is it true that every (complex) Hilbert space can be represented as an ")#mi("L^2(X,\\mathcal{X})")#text(" space for some measure space ")#mi("(X,\\mathcal{X})")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-673657")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2023")])]

#text("I just realized that this stupid question is answered completely by Corollary 1.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-673021")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2023")])]

#text("In the proof of Cauchy-Schwarz in Lemma 1, if one works with the real case, does one have a ")#emph[#text("real")]#text(" version of the amplification trick?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-673033")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2023")])]

#text("You can just set the complex part to be zero.")
]
]
