// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/
// Converted to Typst by tao2typ: "2026-10-14T15:21:23.604510+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A value-based approach to mathematics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A value-based approach to mathematics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/")[#text("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://www.math.columbia.edu/~corwin/")[#text("Ivan Corwin")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("Mathematics and those mathematicians who guide its development have been central to societal advancement since antiquity. AI, like many tools that were invented by mathematicians (e.g., the abacus, slide rule, calculator, and computer), holds the potential to continue to advance this positive trajectory. Indeed, in each epoch of history where a new mathematical tool becomes available, the role and responsibility of mathematicians to society has grown. At the same time, it comes with hazards and challenges that if improperly handled will impede rather than accelerate progress and impact on the world.")

#metadata(none) <tao-5fcee81764861d5649e6>#text(" Most of the value that flows into the world from mathematics and the work of mathematicians will not be replaced by AI, but could be magnified. In applied fields outside of mathematics, what if AI could help bring tools, ideas and modes of thought that mathematicians continue to develop to bear on real world problems and in areas where it was not anticipated. This could lead to new interactions between those fields and mathematicians and help draw mathematics closer to its immense applications. In mathematical research, AI systems have shown promise in connecting and sharing ideas between fields and in using those connections to solve some concretely posed problems (e.g. the unit distance conjecture). It would be a great outcome if AI helps to reduce the siloing of mathematical inquiry and knowledge and allow mathematicians to ask and pursue bigger questions and grapple with more complex systems.")

#text("Improper usage of AI offloads thinking, understanding and learning, thus mortgaging future mathematical development. Students and researchers may not experience the growth that comes from failing and struggling with a problem, and may become risk-averse and engage more with the AI than each other. We have already seen a burst in the number of arXiv postings and problems being solved by AI. If AI is used to indiscriminately solve open problems without mathematicians being deeply involved, it may not produce much societal value from the process or even the product. AI companies have built their tools using the freely shared work and expertise of generations of mathematicians, yet seem to have very little concern for this possibility. They are concerned with their valuation and do so at the cost of trampling on the very community norms that led to the free flow of ideas on which they are built.")

#text("I advocate for a value-based approach to navigating these waters. Moreover, based on this approach, the mathematical community should clearly articulate and communicate its value to society and demonstrate how that value will only increase with the mass adoption of AI. In my framing, there are four loci where the work of mathematicians produces value. This includes the value from cutting edge research, but is also grounded in the broader influence of mathematical thinking on society as well as the value of training and mentoring students at all levels in the traditions and modes of thought of mathematics.")

#strong[#text("Society.")]#text(" History is replete with examples of specific mathematical ideas and methods that have driven progress in society and revolutionized science and knowledge. I am a probabilist and though probability theory is a late-comer into the canon of mathematics (early 20th century), it has been a clear success story in terms of impact. The central limit theorem and extreme value distributions figure centrally in classical statistics. Stochastic processes like Brownian motion fuel the analysis behind the world of finance, and model real diffusive systems across science. Random matrices and spin-glasses provide a starting point to understand how long to train LLMs and which algorithms work best. Understanding of why such probabilistic AI systems work and how and why they fail will require study of novel probabilistic models as well as new vision.")

#text("In all of these examples, problem solving came at the last stage of maturation of a topic, and much of the creativity and innovation came earlier in identifying new areas of interest, developing intuition and predictions, testing that and then formulating precise questions. In this way, though it is often not presented this way, mathematics is quite similar to other sciences.")

#text("It is not just mathematical models and results that impact society, but rather the very essence of mathematics — its modes of thought and language slowly seep deep into the way humanity approaches the world. Toddlers learn to count and young students learn number systems, both basic forms of ")#emph[#text("abstraction")]#text(" that map different systems onto the same internal understanding. Debaters, writers, lawyers and all of us learn to craft and structure arguments based on ideas of ")#emph[#text("rigor")]#text(" and ")#emph[#text("logic")]#text(". Probabilistic ideas like ")#emph[#text("conditioning")]#text(", ")#emph[#text("expected value")]#text(", ")#emph[#text("sampling")]#text(" and ")#emph[#text("independence")]#text(" have become a powerful and widely spoken language to deal with uncertainty and chance.")

#text("Mathematics is not just of practical importance. Mathematicians ensure that it is an ever flowing source of creativity, wonder, beauty and playful joy. Children exercise their minds musing over puzzles, patterns and games that are all inherently mathematical. Fractals, chaos and the process of emergent behavior and phase transitions captures the imagination of the many beyond the world of mathematics.")

#text("The advances, applications and implications of mathematics seldom come in the form of a concrete problem to solve or conjecture to resolve. Rather, they represent the true form of mathematics as it has been for thousands of years. Math is the pursuit of new knowledge and understanding, both in the formal systems in which it is constructed but also in contact with the real world which it serves. That process is non-linear and unpredictable. Sometimes it is driven by societal need, and sometimes other factors such as curiosity, beauty and structure drive mathematical advances forward long before an application becomes apparent. For example, probability theory is built on measure theory, quantum mechanics on Hilbert space theory, and cryptography on number theory. The theory, developed with relatively little concern for its application, ended up being the key to advance more practical and applied understanding.")

#strong[#text("Students.")]#text(" Here I focus on students who, at the college or graduate level have the opportunity to receive rigorous mathematical training from mathematicians. Beyond the specific topics that a student learns and their importance in other fields (e.g. an engineer must learn calculus and linear algebra to understand a mechanical system), mathematical course-work and training teaches students many other lessons. These include how to learn and work within a technical field, how to operate in an abstract or logical system, how to grapple with complex systems, how to work in an open-ended area where it is not always clear what questions should be asked or answers given, how to communicate complex ideas and develop precise language as well as illustrative language to share understanding, and how to fail over and over again while learning something important from that process.")

#text("Mathematical training and education is a vehicle for these deeper lessons and for the maturity that comes with them. When math majors and PhDs are hired, it is in part for what they know, but also in large part for their training and preparedness to take on new and increasingly complex and daunting projects at large scale. This, along with the abstract and technical capacity gained through learning mathematics, explains why math students who do not pursue academia so often land great jobs and are often behind transformative innovation.")

#strong[#text("Community.")]#text(" Here I refer to the community of mathematicians (though much could also be said of the role of mathematicians within other communities including key roles they play in their colleges and universities), often divided into smaller subfields. Perhaps due to a lack of big money or the general nature of many mathematicians, the communities in which mathematicians operate tend to be supportive, collaborative and hold themselves to high ethical standards. The currency within many of these communities tends to be less about results (i.e., problem solving) and more about understanding. When colleagues meet, they often share the questions they are thinking about, the ideas behind their recent progress and new or unexpected phenomena they have discovered. Those who broaden or create new fields through introducing techniques, objects of study or questions are often held in higher regard than those who prove definitive results that end discussion. Slow and deliberate math is valued, in part because of the quality it brings but also because it allows the community to digest and share in the understanding, and for students to become a part of the process. Students are protected and valued, whether or not they plan to stay in academia. Unlike other fields of science and perhaps due to the limited need for resources, mathematical communities tend to avoid hegemonies though they do develop ways to promote their members, raise up their students and support new directions of inquiry. Perhaps this is also in recognition of the fact that new ideas and understanding often arise in unpredictable ways; big ideas do not materialize in a vacuum but rather nucleate on the collective efforts of many smaller results or calculations.")

#strong[#text("Individuals.")]#text(" Mathematicians derive considerable personal joy and fulfillment from their own process and work, and this explains in large part why people enter mathematics and eventually devote their lives to it. Math has many different facets and appeals to different types of thinkers. It can look like a puzzle or game, a challenge or competition; it can be abstract, purely logical and elegant or beautiful; it can be informative and applicable, connected to other fields and the real world. Some find gravity and gratification in being part of the ")#emph[#text("long conversation")]#text(" (in Barry Mazur’s words) which has been unfolding over thousands of years and will continue far beyond today. Many mathematicians are attracted to the focus on deep and careful thinking, and the often shared notion that each mathematician should understand the basis of what they do down to the very last detail. In that spirit, mathematics is a domain in which one must not just understand why something works, but also understand the boundary of why — how it can be broken and why other approaches fail. Finally, each individual mathematician may derive personal value from being part of a community, from teaching and training students and from the impact of mathematics on society.")

#strong[#text("Call to action.")]#text(" The mathematics community should understand, articulate and communicate its value to the broader society and to people who control funding for mathematics. I have provided some of my thoughts on this above, but everyone will have their own version. As a community, we should ground our discussions and decisions about mentoring and resource/reward allocation schemes in pragmatic terms based on the long-term value they produce. These discussions should include younger members such as undergraduate and graduate students. In the past they have been generally sheltered from such considerations that were left to those involved in stewardship of the professor; but this moment calls for their input and the future trajectory of mathematics relies on their decisions.")

#text("We should develop new infrastructure focused on understanding, articulating and communicating the value of mathematics. I believe mathematics will be well-served by creating venues (e.g. journals and conferences) for mathematicians to articulate to the broader public the value of their mathematics and the broader value of their field. This could be done in conjunction with experts who use mathematical ideas in other domains of science and beyond, or with involvement of historians who can help recreate the problems that drove the development of new math in generations past. Other efforts like the new journals of ")#link("https://msp.org/ent/about/journal/about.html")[#text("Essential Number Theory")]#text(" (and soon also Essential Analysis), ")#link("https://www.mathematicaldiscourse.org/")[#text("Mathematical Discourse")]#text(", and ")#link("https://msp.org/galileo/about/journal/about.html")[#text("Galileo")]#text(" (and of course ")#link("https://www.quantamagazine.org/")[#text("Quanta")]#text(") should be supported and people who contribute meaningfully to broader understanding should be given more credit and respect by the community. Research institutes (like ")#link("https://www.slmath.org/")[#text("SLMath")]#text(", for which I co-chair the scientific advisory committee) can play a key role here in allocating resources in support of the value of mathematics.")

#text("We must also recenter our focus on training and all of the positive outcomes from the process of doing mathematics. Teaching, at all levels, should be seen as an opportunity to bring great value to students, not as a matter of service to the university. Great teaching and thoughtful development of new courses that help share mathematics more broadly should be encouraged and rewarded.")

#strong[#text("Conclusion.")]#text(" I have struggled with this blog post for the last two weeks, writing and rewriting it as my thinking has evolved through discussions with family, colleagues, students and self-reflection. Incidentally, this period overlapped with the Jewish period between Rosh Hashanah and Yom Kippur which is called the ten days of ")#emph[#text("T’shuvah")]#text(". This is a period of deep personal and communal reflection and the word T’shuvah literally means “return” or “turning back”. While I do not think we should turn away from AI and the potential it brings, I do believe that we need to return to and revisit the value of mathematics and ensure that value is preserved and enhanced going forward.")

#text("I could have asked AI to write this blog or even help write it and edit it, but then I would not have taken the time to formulate and solidify my thoughts, to share, discuss and then reformulate and rewrite. I would not have thought through the arguments that I ultimately abandoned and did not write here, and I would not have seen this as a call to action for myself. I would have missed out on the learning opportunities from my conversations and email correspondences. The value of math, like so many other forms of knowledge, also comes from the process, not just the product. AI should be used in so far as it enhances the value derived from both.")

#heading(level: 1)[#text("Comments (21)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/#comment-696429")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("Unfortunately, mathematicians are going to be turned into button pushers, there doesn’t seem to be much way to avoid this. And the more they rely on LLMs, the more their skills will atrophy.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/#comment-696444")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("May I ask what is the argument that leads to “mathematicians are going to be turned into button pushers” under an article profound and powerful, but not created by pushing a button?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/#comment-696459")[#strong[#text("Hume Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")]

#text("The key is pen-and-paper math may not be economically viable in the future. Horse-riding becomes marginalized when automobiles were invented. Driving would soon follow once autonomous taxis replace Uber drivers. The production of math knowledge isn’t very different. But I think we can preserve the tradition by having adult IMO where people compete in pen and paper.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/#comment-696466")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("This is a terrible suggestion. So, now, you want to waste a bunch of money to organize a competition where senior mathematicians (or even junior ones) participate for the sake of, what, preserving some tradition that is entirely ego-driven?")

#text("It is simply better to keep one’s skills from dissipating simply by engaging in good practices involving AI. What is considered good depends on the community and will be decided by further conversations.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/#comment-696434")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("One of the stronger opinions to appear on here. Thank you and thanks to professor Tao for hosting these.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97445085d4a2ebf28f626c2a1719ecf230f9741ef678c2fab92c6aee2f59882e-78992b2db9f4571623d1d1174228ff859e9e57b5d355bf3aceda181b1be45b5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alexsotirov")]], [#link("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/#comment-696438")[#strong[#text("alexsotirov")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("When we were young what attracted us to mathematics? We did not think about the impact on society, we did not think about jobs, we did not think about its consequential “value.” We thought about mathematics as being intrinsically interesting, we thought of its beauty. The beauty will be always there. AI cannot change that, instead it can only help reveal more of it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/067e2cf112a44bcae15a6822c4fe32d73c9331314a0468f9bbea605b6b8d12bb-c453134bec7a4dcd24bc6804437c02463e27f8da1f617c6e49398498867c2dc9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gaspar")]], [#link("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/#comment-696460")[#strong[#text("Gaspar")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("Yeah, but we still need jobs. Not everyone can be a dreamer. And not every country has the same structure as others. I feel people here think they’re the average… but I’m not sure about it. I hope you’re on the side that can still be optimistic long-term. AI sucks because the whole structure sucks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/#comment-696472")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("I agree that “the whole structure sucks”, and by that I mean social organisation beyond mathematics, and that’s the bigger problem that will need to be addressed. But that’s a separate question from whether AI helps or hinders mathematics. AI is an example of a complex system in the universe just like we are (the A in AI is a human centric prependix) and it holds great promise for the advancement of mathematics. But yes I am an optimist, however I think we need to focus our energies on changing the system “that sucks” rather than attack AI itself which only serves to expose the flaws.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/#comment-696452")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("Something new is happening in mathematics. Cutting-edge models are capable of finding genuinely original, lengthy, and counterintuitive paths to solutions. Chains of ten or more steps that no human intuition would have dared to attempt. Often, the resulting mathematical outcome proves to be correct and even elegant. Yet, because the glory goes to whoever “plants the flag” first, authors publish a hundred pages of raw machine-generated calculations, without even asking how exactly this miracle came about.")

#text("Mathematics has always relied on an unspoken but firm rule: the person who puts their name on the proof truly understands its essence and is obliged to present the material in a way that makes it comprehensible to the reader. And this raises the central question. If a mathematician cannot step up to the blackboard and explain in their own words why their proof works, then at what point does the “use of ai” begin to border on a breach of ethics? And how do you propose addressing this issue in your vision of the future, Ivan?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/#comment-696530")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("I think all journals should adopt policies like the following, which place the evidentiary burden on the author rather than requiring the journal to conclusively prove the extent of AI use:")

#enum(start: 1, 
[#text("If several referees independently suspect that a paper was written with significant, undisclosed AI assistance, the paper should be rejected. For example, this could apply when an established researcher suddenly begins producing top-level results in a completely new field and the paper contains strong indications of AI use.")],
[#text("If a researcher claims authorship of a paper, even while acknowledging the use of AI assistance, but the paper itself demonstrates a lack of sufficient understanding of the material or of the core ideas behind the proof, the researcher should be permanently prohibited from submitting to that journal.")]
)
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/#comment-696454")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("AI, like many tools that were invented by mathematicians (e.g., the abacus, slide rule, calculator, and computer), holds the potential to continue to advance this positive trajectory.")
]

#text("Dear AI proponents, please stop using this stupid analogy. AI is not an ordinary tool like those listed there. It is an analog of the ")#strong[#text("nuclear weapon")]#text(". Nobody ever says that ")#emph[#text("it is now good to have the nuclear weapon, it is just the next step after previously existing conventional weapons, so let’s just adapt to it and start thinking about how can we fight better by using it.")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/#comment-696471")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("It is of utmost importance to convince students that some part of the mathematics career is ")#strong[#text("economically")]#text(" worth pursuing. Departments should emphasize more that their PhDs and postdocs often end up in high-paying jobs. I cannot possibly see how academia will receive enough funding to retain top talent in any perturbation of our current incentive structure, but it can attract a lot of manpower to train their reasoning abilities in the subject, whether it be solving problems on their own or understanding and digesting AI slop. Departments should work closely with the industry to make their PhD students and postdocs more employable.")

#text("(As someone who signed the letter against the Caltech Mathathon), I now realize our public response to the Caltech mathathon is completely wrong!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/#comment-696488")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2026")])]

#text("The only way a math PhD program survives is by also providing its students the necessary environment to acquire basic skills for an employment in AI or related industry (so math PhD becomes something like double major). Nobody would sign up for %100 pure math PhD after such a devaluation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/#comment-696498")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2026")])]

#text("The necessary skills (be able to press enter)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9aac05a558797d32c15f55d878a48d42da70b746702d86f0d119ed7c3d5d3f7-271938281befc09d4e62e209f9ef583576efda8ebe21909421f3a2ddbe083be5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Oliver")]], [#link("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/#comment-696481")[#strong[#text("William Oliver")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2026")])]

#text("This is a beautiful post. What I love about this post is that its primary focus is not on ‘practical importance’.")

#text("That said, my criticism is essentially the same as the ones I have put on other posts, which is that, in our current crisis, it is not enough to describe the absolute value of mathematics. We must describe, as clearly as possible, the ")#emph[#text("relative ")]#text("value of mathematics: that is, the value that ")#emph[#text("only mathematics brings")]#text(".")

#text("Otherwise, there will be no way to convince the public that mathematics is worth preserving. A critic might say of many of your values that they can be attained from other fields, like engineering, science, or even the field of machine learning and ‘prompt engineering’ itself. Of course we know that this isn’t quite what you mean here, but the average person does not.")

#text("And in this sense, I would pull out this blurb from the ‘individual’ heading, which I really like.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Many mathematicians are attracted to the focus on deep and careful thinking, and the often shared notion that each mathematician should understand the basis of what they do down to the very last detail. In that spirit, mathematics is a domain in which one must not just understand why something works, but also understand the boundary of why — how it can be broken and why other approaches fail.")
]

#text("Rather than group this under ‘individual’ values, I would put this under a different heading: ‘mathematical truth’, or ‘mathematical essence’. And I think in general it should be emphasized far more. To me, this is the value of mathematics that ")#emph[#text("only ")]#text("mathematics can provide.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e84ea4b95d64b53b67cb11029f1a8e90e66034b3876e216e3a4fc8f3c00d060a-26dbde4452bf4b818ceeac8311859259e2891e1f86b3f8b718b36fd592ac5938.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. C.")]], [#link("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/#comment-696507")[#strong[#text("D. C.")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("Mathematics would overcome the AI challenge by qualitatively improving AI beyond simple LLMs, into something more powerful. At some point, the math involved in AI would be much more complicated than the one involved today. That would be the moment when society would need mathematicians again, and would increase funding. Until then, the society at large would say they want savings, not more expenses. C’est la vie.")

#text("Our concerns about the impact of AI on the lives of mathematicians are really of no interest to the society in general, and we should not demand more funds by claiming disruption, because as a reply we might get less.")

#text("We can demand more funds if we offer something new in return to the society. We don’t need to explain them what it is, or for them to understand that new application. We need that new thing to exist.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0407444868fc42987e0e767c3fa8c7571cd73af435533bcece7a36bd594b0514-2ae27efe97fcf1ece7ea67e36afa94eee62825664716dc4ee7cf030a881d77c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shannon7774")]], [#link("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/#comment-696541")[#strong[#text("shannon7774")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("I am reminded of Michel Talagrand’s great work in spin glasses. It was difficult for many mathematicians to understand at first. But some did, and they pushed the field forward even after Talagrand retired. I suspect that there are dividends to collect from mathematicians willing to interact with the new work of AI and explain it to the rest of us.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/#comment-696563")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("Talagrand was not such a bad writer. :-)")

#text("Now imagine trying to explain a 100-page breakthrough paper on the level of Talagrand’s best work, proved by an AI and presented as AI slop by someone who pressed a button and then claimed authorship with the assistance of large language models. Why would anyone want to validate such behavior by doing the hard work of explaining it?")

#text("Until ethical rules around this are developed and enforced, the mathematical landscape may start to look a little like Cleveland in the early days of Standard Oil.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/#comment-696577")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("I never said he was a bad writer. I said his work was difficult to read. There is precedent for mathematicians doing difficult things. And some will rise to the occasion now.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1644c7ada1fe9126712ff045feaa8f551fb55d85d7023f53c7d53b48d0c268d6-8bcc80eff677b687935f6f20ed89884887470a9adbe385af8acab1d6a2aee536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Satya")]], [#link("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/#comment-696549")[#strong[#text("Satya")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("When AI responds to a math question, it does not give credit the sources where it gets the information. I clealry experimenting with the problems of my interest. It pick up information from my own papers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/26/a-value-based-approach-to-mathematics/#comment-696557")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("Thank you for this. I’m an infectious disease modeller, and one thought from outside mathematics: AI may not shrink the role of mathematics at all. It may radically enlarge the domain in which mathematical thinking is useful. You hint at this in your second paragraph; I think it deserves to be the headline.")

#text("You rightly stress that much of the value of mathematics lies before problem solving: finding the right abstraction, identifying structure, deciding what the question actually is. What LLMs change is the cost of translation. Real-world problems arrive as messy arguments in medicine, law, climate science, economics and policy. Turning them into explicit mathematical objects has required a rare combination of domain knowledge and mathematical fluency. LLMs are becoming good at helping with exactly that: extracting assumptions, proposing definitions, surfacing hidden dependencies, and writing candidate formalizations in systems such as Lean.")

#text("The workflow I increasingly use looks like this:")#linebreak()#text("real-world problem → domain expert → LLM-assisted formalization → mathematical model → Lean-checked implications → back to the domain.")

#text("Lean tells us whether a conclusion follows from the assumptions, and the LLM lowers the cost of getting there. Neither can answer the most important question: did we formalize the right thing? In public health, formalizing a vaccination argument quickly shows whether its conclusion quietly depends on homogeneous mixing. Seeing that, and knowing what to do about it, is mathematical judgment: inspecting the abstraction, challenging definitions, finding missing cases, and telling a deep result from a formally correct irrelevance.")

#text("So AI may automate some problem solving while massively expanding the demand for problem formalization. Your concern that we might keep the product and lose the process is exactly right. But the opposite is also possible: AI and proof systems could export the process of mathematics into fields that now operate largely in prose. Mathematics would then become general intellectual infrastructure, a discipline that helps society make its reasoning explicit, testable and corrigible. That is exactly the case for the value of mathematics you call on the community to make.")
]
