// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/12/24/elias-stein/
// Converted to Typst by tao2typ: "2026-10-14T15:20:13.818637+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Elias Stein", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Elias Stein")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 December 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/")[#text("https://terrytao.wordpress.com/2018/12/24/elias-stein/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I was deeply saddened to learn that ")#link("https://en.wikipedia.org/wiki/Elias_M._Stein")[#text("Elias Stein")]#text(" ")#link("https://www.math.princeton.edu/news/elias-m-stein-1931-2018")[#text("died yesterday")]#text(", aged 87.")

#text("I have talked about some of Eli’s older mathematical work in ")#link("https://terrytao.wordpress.com/tag/elias-stein/")[#text("these blog posts")]#text(". He continued to be quite active mathematically in recent years, for instance ")#link("https://arxiv.org/search/?query=elias+stein&searchtype=all&source=header")[#text("finishing six papers")]#text(" (with various co-authors including Jean Bourgain, Mariusz Mirek, Błażej Wróbel, and Pavel Zorin-Kranich) in just this year alone. I last met him at Wrocław, Poland last September for a ")#link("https://math.uni.wroc.pl/analysis2017/")[#text("conference in his honour")]#text("; he was in good health (and good spirits) then. Here is a picture of Eli together with several of his students (including myself) who were at that meeting (taken from the conference web site):")

#image("../assets/041a0978f8f41b45a339e21defa3a46fd58ef487f7ea3703d61bc481abb1cdce-5d644e62100e9f0680c51405b61b9aec11a9bd447067d5ecf08d689ad52169a6.jpg", width: 90%, alt: "S6301678")#text(" Eli was an amazingly effective advisor; throughout my graduate studies I think he never had fewer than five graduate students, and there was often a line outside his door when he was meeting with students such as myself. (The ")#link("https://genealogy.math.ndsu.nodak.edu/")[#text("Mathematics Geneaology Project")]#text(" ")#link("http://www.genealogy.ams.org/id.php?id=6454")[#text("lists 52 students")]#text(" of Eli, but if anything this is an under-estimate.) My weekly meetings with Eli would tend to go something like this: I would report on all the many different things I had tried over the past week, without much success, to solve my current research problem; Eli would listen patiently to everything I said, concentrate for a moment, and then go over to his filing cabinet and fish out a preprint to hand to me, saying “I think the authors in this paper encountered similar problems and resolved it using Method X”. I would then go back to my office and read the preprint, and indeed they had faced something similar and I could often adapt the techniques there to resolve my immediate obstacles (only to encounter further ones for the next week, but that’s the way research tends to go, especially as a graduate student). Amongst other things, these meetings impressed upon me the value of mathematical experience, by being able to make more key progress on a problem in a handful of minutes than I was able to accomplish in a whole week. (There is a well known story about the ")#link("https://www.smithsonianmag.com/history/charles-proteus-steinmetz-the-wizard-of-schenectady-51912022/?no-ist")[#text("famous engineer Charles Steinmetz fixing a broken piece of machinery by making a chalk mark")]#text("; my meetings with Eli often had a similar feel to them.)")

#text("Eli’s lectures were always masterpieces of clarity. In one hour, he would set up a theorem, motivate it, explain the strategy, and execute it flawlessly; even after twenty years of teaching my own classes, I have yet to figure out his secret of somehow always being able to arrive at the natural finale of a mathematical presentation at the end of each hour without having to improvise at least a little bit halfway during the lecture. The clear and self-contained nature of his lectures (and his many books) were a large reason why I decided to specialise as a graduate student in harmonic analysis (though I would eventually return to other interests, such as analytic number theory, many years after my graduate studies).")

#text("Looking back at my time with Eli, I now realise that he was extraordinarily patient and understanding with the brash and naive teenager he had to meet with every week. A key turning point in my own career came after ")#link("https://web.math.princeton.edu/generals/tao_terence")[#text("my oral qualifying exams")]#text(", in which I very nearly failed due to my overconfidence and lack of preparation, particularly in my chosen specialty of harmonic analysis. After the exam, he sat down with me and told me, as gently and diplomatically as possible, that my performance was a disappointment, and that I seriously needed to solidify my mathematical knowledge. This turned out to be exactly what I needed to hear; I got motivated to actually work properly so as not to disappoint my advisor again.")

#text("So many of us in the field of harmonic analysis were connected to Eli in one way or another; the field always felt to me like a large extended family, with Eli as one of the patriarchs. He will be greatly missed.")

#text("[UPDATE: Here is ")#link("https://www.princeton.edu/news/2018/12/28/pioneering-princeton-mathematician-elias-stein-dies")[#text("Princeton’s obituary for Elias Stein")]#text(".]")

#heading(level: 1)[#text("Comments (32)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3e70213003ccd073b80e315c81fe872823884f16498500131d5cd1f05259060-5b0be47db6542147f7d241ef2dc6c3e6600433181762f92f13a74211cd903572.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-509370")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2018")])]

#text("Thank you for the post.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-509374")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("As a young student, I really hated analysis in college.")

#text("Later on, I read the Stein-Shakarchi books, and it completely changed my view of the subject. Now, I use it all the time and always choose it as the first topic to introduce newcomers to advanced math.")

#text("RIP")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-509399")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("My experience exactly with those books")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cb97baf01a8d8775dba0d42cd12419b2a87d303517e0d16d5416e74581fb516-12159c9e4bce1855eee77e6a392e93d0aadb07ea32098b52903e77dded9b9835.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Skylin Chern")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-509378")[#strong[#text("Skylin Chern")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("He is the hero living in our heart, always. It’s enough, right?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eae988277ab5af26a6868faf07ff52f678d6d4e55bf19dbae4de9ccc10f05921-36880b05d4b5563fa1a528f8c5decdf570948629ea58099fd0532ef22820807e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sha_bi_a_ti_ya")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-510170")[#strong[#text("sha_bi_a_ti_ya")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2019")])]

#text("Really like your blog. Wish your dreams come true.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82e494cbb93604545c9a4905674939e942fe943e6102f1c972d6f4672e2857bb-af836d930689c7a8bf7d6376575f8a0e200c0e826d217f3b19db103860d0df48.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wdjoyner")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-509386")[#strong[#text("wdjoyner")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("Sorry to hear of the sad news.")#linebreak()#text(" I have a few memories of him. Stein was the chair of the math dept when I was on an NFS fellowship at Princeton and the IAS. I remember three things about him. As junior faculty they allowed me in committee meetings and, while I didn’t really contribute anything, I do remember how extremely efficient he was at running the meetings. I also remember he generously invited me to stay an extra year at Princeton, which I declined. (A stupid decision on my part.) Finally, with Charlie Fefferman, we were in an oral exam of a PhD candidate. Afterwards, I said the candidate was remarkably poorly prepared, but rather than fail him, he was very kind-hearted. It taught me you can be a great mathematician and be a kind person at the same time.")#linebreak()#text(" May his memory live on.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/521946bb1168802bba546c2476d51f81c8c2ac4f268b2a046b9835981852d4fe-d468af406d4e171db19f7471a94b484ee925097ecd6baffdbe2e15864e5976b5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sundaram Thangavelu")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-509387")[#strong[#text("Sundaram Thangavelu")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("I completely agree with Terence Tao about Eli Stein’s teaching and mentoring. During my time as his graduate student once I got an estimate of an integral using contour integral which ran into several pages. When I met him to show y proof he patiently listened to me and then said: this estimate would follow quickly if you use the method of steepest descent instead. And he was right.")#linebreak()#text(" I last met him during the Wroclaw conference in 2017. Like everyone else I was disappointed to learn in June 2018 (during Ricci’s birthday conference) that Eli would not join the conference in Cartona due to illness. It is hard to believe that he is no more. He will be missed by all his students, descendents and collaborators.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-509395")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("This is indeed a great loss for the mathematical community")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-509396")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("He is perhaps the only advisor who has two Fields medalists as his former students.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/49564b14fdce6060a3fd14862804d038c0ff9bcafffce1868f627bc4c750d47b-0c7b24a987ac7ff1b53ae7b1e4ecd6c86ebf28dbff73d0fc85654708ac7cbb98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of There Were Others")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-509434")[#strong[#text("There Were Others")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("Bott (Smale, Quillen)")#linebreak()#text(" Zariski (Mumford, Hironaka)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-509694")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2018")])]

#text("Laumon (Lafforgue, Ngô)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e69a79bab33625edb901c3c1c78995c27708a32c879178d8651b258802715d2-c975564afbc11cce50ff9a07933c3a83d3dfa3e56b99e77e6adfebdb693eaba3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill Beckner")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-509401")[#strong[#text("Bill Beckner")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("Eli Stein was a special person, an exceptional adviser, and a remarkable mathematician.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-509418")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("Thanks, Terry, for the interesting farewell, showing us a great researcher who was also a caring math advisor and teacher—not an easy find. In my opinion, E. Sten’s paper on strengthening the Banach principle to a weak inequality is a good exhibition of his mathematical personality: a deep insight with even philosophical implications, development of a new technique that has become a standard tool ever since, clear and unpretentious exposition and lots of interesting applications of wide interest.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/019847f303bbab21b9fb4f46990866eb7986e14f35453fa8dd678d3357601080-ed49fd733171e92a686d494ee9c93dc65a968658b59a63707134d312dd44d137.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giuseppe Mingione")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-509421")[#strong[#text("Giuseppe Mingione")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("It is a very nice and touching remembrance. Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6bee38a54cd2271be89034454fa2ba8ff424bf6591e45bc91dda1f9cac5fa17-8f4d488bc24daa25daf62c14b64c16d6318202346fc3b9765214d6fd1010b1f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George Shakan")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-509427")[#strong[#text("George Shakan")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("His work will be sure to leave a lasting impact in mathematics and the art of mathematical exposition.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f5350eab85a64bfc2e9ab260adcbb967ca0f2d7ef967670ce37d1492b33ec20-845cf93aa438b684e3c56cf1b0a38510ac988af035c26858d4cf5fefd2c6e650.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zhou FENG")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-509438")[#strong[#text("Zhou FENG")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("Reblogged this on ")#link("https://mezhoufeng.wordpress.com/2018/12/26/elias-stein/")[#text("Zhou's Blog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ca6442cf9ba0674fe4be28e92a06b7553bebff8172a061748c2649c4d455c67-40201fa9a24dbd10a6a48a19fcdef87363f46631a77cdce592ed75ec4ac10169.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guozhen Lu")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-509460")[#strong[#text("Guozhen Lu")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2018")])]

#text("I was also deeply sadden to learn that Eli Stein passed away. I first time met him when I attended his 60th birthday conference in Princeton. Eli was so kind to young people and I myself benefitted greatly from him. Like almost everyone else in harmonic analysis, most of my works were inspired and closely related to his research. Since some of my works were directly related to his, I had the opportunity to submit them to Eli when he was on the editorial board. This started right after I received my PhD. He handled and considered my papers so kindly and gave insightful suggestions. These meant a lot to a young mathematician. I have always been very grateful to Eli Stein. In addition to being a great mathematician of our times, he was a very kind human being. He will be greatly missed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca3d0f8b0cd7894889aa96766b529b2e8bede0c84407f9385fe46cf8052a150c-df41e00e186ed49d79d0c2625b51f4b67ad50bf44b5c61d84ca7fdb6a1f87774.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dajiangliu")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-509485")[#strong[#text("dajiangliu")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2018")])]

#text("Terry’s memory on his meetings with Eli confirmed that great mathematicians often excel by seeing the connections between different things. In modern math (probably other subjects as well), there are few questions that have not been thought of, and few approaches that have not been tried before in other areas. Knowing their existence often helps tremendously.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3151fb444dac2da9d36c49f7c60ba206c0112d3ee3d64e9d5d29de3c51a4705e-141b070896f757d38f941b6200574842fd0efa4e8b71cb7abb0655f666a1323a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zirui Wang")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-509491")[#strong[#text("Zirui Wang")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2018")])]

#text("Why do you seek his advice and not face the difficulties like a real man?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-509500")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2018")])]

#text("time to take your pills")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b75530ff217a8c2df2cc7c319f7e9dee74f73d1177a36d0c7fe498dafdf9ef5e-727aaa15b84e2515362ae943fb2eaacb047614a307071a554e99be37ac15fbf0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CHRIST AMBASSADOR")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-509651")[#strong[#text("CHRIST AMBASSADOR")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2018")])]

#text("Morning professor Tao, I am a student of Lagos state university(LASU) Nigeria studying pure mathematics. Am a big fan of yours sir. I need your help sir in research works sir, I will be glad if you will grant me the opportunity sir. Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/99512137bb1ca38b1ff186b7782106c472143d066d22e9b8fea226487adda08f-cc6973d21fab7176cdc9612a934949204ba76d2e07968796f727b2be90678700.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anna G")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-509998")[#strong[#text("Anna G")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2018")])]

#text("Thanks, Terry. I too was always so impressed with Stein’s lectures. Each one was a master piece and he held such a commanding presence.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-510313")[#strong[#text("Mathematical Obituaries, December 2018 | The Aperiodical")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2019")]

#text("[…] Elias Stein obituary, at Terry Tao’s blog […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-511303")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2019")])]

#link("https://www.nytimes.com/2019/01/14/obituaries/elias-m-stein-dead.html")[#text("NY Times Obituaries")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-511320")[#strong[#text("Jean | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2019")]

#text("[…] is a beautiful tribute on GLL for Jean Bourgain and Michael Atiya. Let me also add a link to the moving obituary post of Terry Tao on Elias […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cad12a4bef875225871ce69ed14d23819c8e70171d4b940fbf5952804b11000f-9bb2a41b4549cd304020ce1cf78a3519a1844903818b9f80f6ea4c632eeec53e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brainspace726")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-511539")[#strong[#text("brainspace726")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2019")])]

#text("Didn’t you mention him in Spending Symmetry, Tao? Was he the one you quoted when discussing the Argumentum ad ignoratium?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2ea433a8ddbd0066ac3fcc19d2c10d38b07e23907f25ee5066476c9ef0cf138-071154eb5b338714368bbfcd4cfcca7a92ff63f4bb7777f4af6cdf57e07b1605.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Carnival of Mathematics – Math with Bad Drawings")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-512133")[#strong[#text("The Carnival of Mathematics – Math with Bad Drawings")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2019")])]

#text("[…] you’re mourning, it’s worth reading Terry Tao’s tribute to his advisor, the legendary harmonic analyst Elias Stein, who passed away in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-640332")[#strong[#text("纪念Elias Stein - 嘎嘎资讯")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2022")]

#text("[…] 转载至Tao的Blog ")#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/")[#text("https://terrytao.wordpress.com/2018/12/24/elias-stein/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-643238")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2022")])]

#text("Dr. Tao: How do you suggest to read Stein’s famous book, HA: real-variable methods, orthogonality, and oscillatory integrals? Some mathematicians say it is still very much in fashion today, depending on how you read it. But I find the book intimidating. Any suggestions?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elias M. Stein Prize for New Perspectives in Analysis | What's new")]], [#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-677313")[#strong[#text("Elias M. Stein Prize for New Perspectives in Analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2023")])]

#text("[…] (my former advisor) to honor his remarkable legacy in the area of mathematical analysis. Stein, who passed away in 2018, is remembered for identifying many deep principles and methods which transcend their original […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-677321")[#strong[#text("Elias M. Stein Prize for New Perspectives in Analysis - Gud Learn")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2023")]

#text("[…] to recognize his impressive heritage in the location of mathematical evaluation. Stein, that passed away in 2018, is born in mind for recognizing lots of deep concepts and also techniques which transcend their […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/12/24/elias-stein/#comment-678343")[#strong[#text("Elias M. Stein Prize for New Views in Evaluation - Being Teaching 2023")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2023")]

#text("[…] advisor) to honor his outstanding legacy within the space of mathematical evaluation. Stein, who handed away in 2018, is remembered for figuring out many deep ideas and strategies which transcend their authentic […]")
]
