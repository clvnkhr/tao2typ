// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/09/06/two-more-clay-mahler-lectures/
// Converted to Typst by tao2typ: "2026-10-14T16:35:52.653749+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Two more Clay-Mahler lectures", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Two more Clay-Mahler lectures")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 September 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/09/06/two-more-clay-mahler-lectures/")[#text("https://terrytao.wordpress.com/2009/09/06/two-more-clay-mahler-lectures/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I am posting the last two talks in my ")#link("http://www.austms.org.au/tiki-index.php?page=The+Mahler+Lectureship")[#text("Clay-Mahler lecture series")]#text(" here:")

#list(
[#text("“")#link("https://terrytao.wordpress.com/wp-content/uploads/2009/09/structure-and-randomness-in-the-prime-numbers.ppt")[#text("Structure and randomness in the prime numbers")]#text("“. This public lecture is slightly updated from a ")#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/")[#text("previous talk of the same name")]#text(" given last year, but is largely the same material.")],
[#text("“")#link("https://terrytao.wordpress.com/wp-content/uploads/2009/09/poincare1.pdf")[#text("Perelman’s proof of the Poincaré conjecture")]#text("“. Here I try (perhaps ambitiously) to give an overview of Perelman’s proof of the Poincaré conjecture into an hour-length talk for a general mathematical audience. It is a little unpolished, as I have not given any version of this talk before, but I hope to update it a bit in the future.")]
)

#text("[")#emph[#text("Update")]#text(", Sep 14: Poincaré conjecture slides revised.]")

#text("[")#emph[#text("Update")]#text(", Sep 18: Prime slides revised also.]")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/079cb57937093f8327931689e37fbb2200cfc232528e21aa0977888321d71bc7-f2117a98624bb427e54718daad39bba5d3b2ff5987d9b7ab60f6a074ea3be262.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manjil P. Saikia")]], [#link("https://terrytao.wordpress.com/2009/09/06/two-more-clay-mahler-lectures/#comment-41321")[#strong[#text("Manjil P. Saikia")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2009")])]

#text("Great lectures, I enjoyed the prime one, you could have added a few more facts and theorems. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c4a90e5c099aac6c527edc370ea0ea4709757dcef025bc943cd25a2d321e750-6eaec4ff05217293c8ba83e00171d9eb6dd6c9ebb7b4ef697300c9f1e00e9baf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anthony Prod'homme")]], [#link("https://terrytao.wordpress.com/2009/09/06/two-more-clay-mahler-lectures/#comment-41324")[#strong[#text("Anthony Prod'homme")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2009")])]

#text("Lecture about Perelman results is very good but rather challenging in 1 hour time.")

#text("Just a typo on slide 22 in one of the names: Bessières should be read instead of Bessires. (è is Alt+0232) ")#emph[#text("[Corrected, thanks – T.]")]

#text("Best Regards")#linebreak()#text(" Anthony")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/09/06/two-more-clay-mahler-lectures/#comment-41327")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2009")])]

#text("Isn’t the security of prime number encryption put into jeopardy by quantum computers? As I understand it there are polynomial algorithms")#linebreak()#text(" for factoring and discrete logs.")

#text("One has been recently demonstrated see:")

#link("http://www.sciencemag.org/cgi/content/abstract/sci;325/5945/1221")[#text("http://www.sciencemag.org/cgi/content/abstract/sci;325/5945/1221")]

#text("here is the abstract from that page:")

#text("Shor’s quantum factoring algorithm finds the prime factors of a large number exponentially faster than any other known method, a task that lies at the heart of modern information security, particularly on the Internet. This algorithm requires a quantum computer, a device that harnesses the massive parellism afforded by quantum superposition and entanglement of quantum bits (or qubits). We report the demonstration of a compiled version of Shor’s algorithm on an integrated waveguide silica-on-silicon chip that guides four single-photon qubits through the computation to factor 15.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/09/06/two-more-clay-mahler-lectures/#comment-41328")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2009")])]

#text("You might want to change the line")#linebreak()#text(" “It turns out to similarly represent Ricci flow…” on Page 34 of the Perelman lecture. Do you mean that a similar gradient flow interpretation is possible, but for a different “energy”? ")#emph[#text("[Yes, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of joe_grateful")]], [#link("https://terrytao.wordpress.com/2009/09/06/two-more-clay-mahler-lectures/#comment-41336")[#strong[#text("joe_grateful")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2009")])]

#text("Terry, these slides and the others are great!")

#text("I’m sure all your lectures (I’ve seen you’ll repeat them several times) will really bear fruits in terms of youngsters and the public being positively impressed by math as is done by experts.")

#text("Actually is the public mostly students and adults, or perhaps have some high school students been attending with a teacher, so far?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/25c336f0a0551407ffdaf00c040e96ccb85e8d6ab14a76163b73d0b635226eef-710ed4fdabcbc2656cb9dd9ff90753615c52011ee068c2c7a84e09b22292bdeb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Graham Norton")]], [#link("https://terrytao.wordpress.com/2009/09/06/two-more-clay-mahler-lectures/#comment-41369")[#strong[#text("Graham Norton")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2009")])]

#text("Dear Professor Tao,")

#text("Many use the term ‘random’ without ever defining it. Is there a formal i.e. rigourous definition of randomness? For a finite population, one can always say that the population is uniformly distributed, but how does one define randomness when the population is infinite?")

#text("Yours sincerely,")

#text("Still a student.")

#text("PS Enjoyed your recent Clay-Mahler lectures.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/564fcff0df2cbed5f83c67341ae597e073eaf1fb00a9d848ddfc27b798aa3250-8e249f7a34f5b7a4427e5970589cdfc3fe6f976af4a378b8b0b71b1a4d0abe53.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Winslow")]], [#link("https://terrytao.wordpress.com/2009/09/06/two-more-clay-mahler-lectures/#comment-41384")[#strong[#text("Robert Winslow")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2009")])]

#text("Professor Tao,")

#text("I apologize if this set theory question is not germane to your current pursuits, but I would appreciate your quick thoughts on the following question.")

#text("Does the Axiom of Extensionality imply that if we set A = ")#mi("\\emptyset")#text(" and B = ")#mi("\\emptyset")#text(", then {A, B} = {A} = {B}? The reason I ask is that I am writing an exposition on the axioms of set theory for non-mathemeticians, and it seems to me that in order to create a second set in our mathematical universe (after the Axiom of Existence gives us the empty set), we must use the Axiom of Power Set to get us set number two (namely, ")#mi("\\{\\emptyset\\}")#text(").")

#text("If so, then it seems to me that the Axiom of Pair cannot get us from a universe with just the empty set, to one with two sets in it, because A.Pair requires two sets as “input”.")

#text("Again, my question may be ill-posed, but I’m trying to wrap my head around this issue. Perhaps another way to phrase my question is, are variable names “pointers” to sets, or are they new “instantiations” of sets (to abuse the terms of object-oriented programming)?")

#text("Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5f7e36637afc3ffa7a50b38c2ce68d7da06dada7cde20715b6444d2a955bbab-5f940974528ad6ecdc582b7a7f935e1623df8f0968a6ef8ec087b52d53deea54.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nguyễn Duy Khánh")]], [#link("https://terrytao.wordpress.com/2009/09/06/two-more-clay-mahler-lectures/#comment-117618")[#strong[#text("Nguyễn Duy Khánh")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2011")])]

#text("Dear professor Tao,")#linebreak()#text(" Last year, I remembered I did donwloaded two lectures above in mp4 format. But now, I forgot the link and I could not find them.")#linebreak()#text(" Could you please tell me somewhere that the videos are avaiable?")#linebreak()#text(" Thank you very much professor.")
]
