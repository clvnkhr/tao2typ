// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/
// Converted to Typst by tao2typ: "2026-10-14T11:22:21.240965+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Additional recent pieces on math and AI", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Additional recent pieces on math and AI")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/")[#text("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’m collecting here a list of some other recent blog posts or opinion pieces on math and AI beyond the ones posted here or at ")#link("https://proofsandprompts.com/")[#text("Proofs and Prompts")]#text(". Readers are invited to contribute further such links in the comments.")

#list(
[#text("Kevin Buzzard, “")#link("https://xenaproject.wordpress.com/2026/10/01/to-grieve-or-not-to-grieve/")[#text("To grieve, or not to grieve?")]#text("“")],
[#text("Alexander Gamburd, “")#link("https://arxiv.org/abs/2609.28591")[#text("The Siren Call of Silicon Leviathan: Reflections on blowup and Aufklärungsdämmerung")]#text("“")],
[#text("Harald Helfgott, “")#link("https://valuevar.wordpress.com/2026/10/01/mathematics-and-the-ai-crisis/")[#text("Mathematics and the AI crisis")]#text("“")],
[#text("Gil Kalai, “")#link("https://gilkalai.wordpress.com/2026/09/22/be-a-grothendieck-on-ai-and-mathematics/")[#text("“Be a Grothendieck!”—On AI and Mathematics")]#text("“")],
[#text("Asaf Karaglia, “")#link("https://karagila.org/2026/openai-pp/")[#text("OpenAI, the Partition Principle, and mathematics")]#text("“")],
[#text("Matilde Marcolli, “")#link("https://www.its.caltech.edu/~matilde/AImathNew.pdf")[#text("Duet for the end of math")]#text("“")],
[#text("Fenner Stanley Tanswell, “")#link("https://link.springer.com/article/10.1007/s00283-026-10566-7")[#text("Enshittification of Mathematics")]#text("“")]
)

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/#comment-697796")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Thanks for all these links!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/#comment-697801")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Nice collection of essays with a diverse range of perspectives!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5ac5a0b5cec35288d8b9851396f176084f2d4861cd7db5411ec0f15d0b02a000-13f5c3b726c2f5c0b59556ce677835abf6a3faee64389f691e191365580819ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tiago Hirth")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/#comment-697809")[#strong[#text("Tiago Hirth")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Hugo Duminil-Copin’s communication on Oct 8 made headlines recently as he admitted his emotional distress and newspapers picked up on this. ")#link("https://www.youtube.com/watch?v=iRjasLnigsU")[#text("https://www.youtube.com/watch?v=iRjasLnigsU")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71201f395df7767381e6f128fb702b6b806f8684a24a9f379cba33ba9c365fbe-44615daa6b4ed9c2ef237f863a907f77c1fe89e219bd8133ad8fcd03956ddad3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christopher")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/#comment-697820")[#strong[#text("Christopher")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Also interesting: there has been claims of improvements to OpenAI’s claimed QRH result (although as far as I can tell they are also vibe coded). Here is a leaderboard: ")#link("https://gtimg.github.io/QuasiRiemannTracker")[#text("https://gtimg.github.io/QuasiRiemannTracker")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8a3ac8bed9364c0f0d2307e3ea35d1823a72f0967ddb466eef58ad67a0e30b29-0431a5bec382d667d45d793a5d06326e9ac10fb286af946b0496b21229011ba0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/#comment-697827")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("At least some of your guest posts are not tagged as guest posts, so if one posts a link to your guest post tag somewhere it omits some guest posts about LLMs.")

#text("Vi Hart has a really wonderful lay-person discussion:")

#link("https://www.patreon.com/vihart/posts/vi-harts-big-171939430")[#text("https://www.patreon.com/vihart/posts/vi-harts-big-171939430")]

#text("Scott Aaronson has an excellent post about LLM usage in mathematics too, somewhat more targeted towards mathematicians and computer scientists. It’s slightly weakened towards the end by giving credence to AI doomer drama, but that’s easily ignored.")

#link("https://scottaaronson.blog/?p=10169")[#text("https://scottaaronson.blog/?p=10169")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c636a0070b7b6d1259c92b75f7f944c491a6d91ae0affed23f8d861a468064e-6bb7ddc5eae84dc8c8e9231851e2a31f6212888f4ee58db5319d35cd6f43a35f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sma045")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/#comment-697851")[#strong[#text("sma045")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Vi Hart is not a lay person in this context. Presumably Jeff is saying that it is aimed at or suitable for the laity.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d61111c54fd226c4af43050a43cf334104644d8bb2e2c83e21ac190a9b8b84f9-d7aea344848b6849d916d68e63355d4430cbc3364ec25fc6b01756750e3bab5f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas M.")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/#comment-697828")[#strong[#text("Klas M.")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("At the top right on my web page you will find my updating report on growth in the number of preprints in both mathematics and other subjects.")#linebreak()#link("http://abel.math.umu.se/~klasm/")[#text("http://abel.math.umu.se/~klasm/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/#comment-697833")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://thehighergeometer.wordpress.com/2026/10/12/what-even-is-mathematical-output/")[#text("What even is mathematical output?")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7f52a51651ba9a2c30d943a286372194f68cefb8e2183ca118b141f72ba0772d-70e89e3076fcd01910032fc9a4f88d0b5579964ea83d76d2a3ef16150017f4d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of trancuongkhtn")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/#comment-697849")[#strong[#text("trancuongkhtn")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("My thought: ")#link("https://cuongtran.net/2026/10/08/openais-work-on-math-commoditization-moment/")[#text("OpenAI’s work on math: commoditization moment")]

#link("https://www.patreon.com/vihart/posts/vi-harts-big-171939430")[#text("Vi Hart’s Big Navier-Stokes Post")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e4fc75a3eb62a0338f020f0cf2bba96e4293554c41ec1df929f1c1519021f94-cb3ff6abcadfbd58db3d6fe1389fa75c81309c07869bc6f80fb4df1b0a689f52.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/#comment-697856")[#strong[#text("S")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Christian Szegedy, ")#link("https://docs.google.com/document/d/e/2PACX-1vTSh-pyNP3Gi99WMmsinnLmE9V5CDI0HEm6WGbIPMNt3V5SGlClHF8-BetotKHOImrvQDSXmFdiOw8D/pub")[#text("“Is Mathematics Over, or Just Graduating?” (aka “Quo Vadis, Mathematics?”)")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Any")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/#comment-697865")[#strong[#text("Any")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Aggressive, yet hopeful, by Szegedi")

#link("https://docs.google.com/document/d/e/2PACX-1vTSh-pyNP3Gi99WMmsinnLmE9V5CDI0HEm6WGbIPMNt3V5SGlClHF8-BetotKHOImrvQDSXmFdiOw8D/pub")[#text("https://docs.google.com/document/d/e/2PACX-1vTSh-pyNP3Gi99WMmsinnLmE9V5CDI0HEm6WGbIPMNt3V5SGlClHF8-BetotKHOImrvQDSXmFdiOw8D/pub")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/#comment-697872")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Marcolli’s was a breath of fresh air!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e31250526a5b9f6f1463c1abf69b93591d80f40877c1d78e606d35cc858c94bc-d6fb1e585e2ad7f7710f938b6b53a3ff8e0410d89aa0ffcfee5c4b99fe5fad70.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/#comment-697912")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I wrote this one on whether students should consider getting a PhD:")

#link("https://jasonpolak.substack.com/p/ai-does-math-should-you-get-a-phd")[#text("https://jasonpolak.substack.com/p/ai-does-math-should-you-get-a-phd")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a0963647bfd2cee499022aced430c2ac44c1e0d05de18977cea6e8413d4d6c9-bebf58de3c6e49c09447d4fd137e08286dd8d8223cc2a7fc846c94d02703e833.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron Slipper")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/#comment-697928")[#strong[#text("Aaron Slipper")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("Hi Professor Tao,")

#text("I wrote up the following as a rebuttal to the recent statements of the AHM (which you reposted). I also emailed it to you directly, so apologies if this is redundant; since you are explicitly soliciting articles, I link to it here.")

#link("https://aaronslipper.github.io/assets/math-and-ai-response-to-the-ahm.pdf")[#text("https://aaronslipper.github.io/assets/math-and-ai-response-to-the-ahm.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/041e0d8efb404a6a2cf18b2270a848edf2c64e454a9f79bc7b5042d769355180-62fe160b29fccbce5500ff3d0ac989c0d3a0e9678d38be9c88331b114d02c1d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/#comment-697967")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("Very sad to see you go down the OpenAI rabbithole. If you think they are your friends, then you should reconsider")
]
]
