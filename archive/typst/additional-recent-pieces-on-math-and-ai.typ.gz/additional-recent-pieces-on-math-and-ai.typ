// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/
// Converted to Typst by tao2typ: "2026-10-15T08:36:54.452304+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Additional recent pieces on math and AI", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Additional recent pieces on math and AI")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/")[#text("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-15 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’m collecting here a list of some other recent blog posts or opinion pieces on math and AI beyond the ones posted here or at ")#link("https://proofsandprompts.com/")[#text("Proofs and Prompts")]#text(". Readers are invited to contribute further such links in the comments.")

#list(
[#text("Kevin Buzzard, “")#link("https://xenaproject.wordpress.com/2026/10/01/to-grieve-or-not-to-grieve/")[#text("To grieve, or not to grieve?")]#text("“")],
[#text("Alexander Gamburd, “")#link("https://arxiv.org/abs/2609.28591")[#text("The Siren Call of Silicon Leviathan: Reflections on blowup and Aufklärungsdämmerung")]#text("“")],
[#text("Harald Helfgott, “")#link("https://valuevar.wordpress.com/2026/10/01/mathematics-and-the-ai-crisis/")[#text("Mathematics and the AI crisis")]#text("“")],
[#text("Gil Kalai, “")#link("https://gilkalai.wordpress.com/2026/09/22/be-a-grothendieck-on-ai-and-mathematics/")[#text("“Be a Grothendieck!”—On AI and Mathematics")]#text("“")],
[#text("Asaf Karaglia, “")#link("https://karagila.org/2026/openai-pp/")[#text("OpenAI, the Partition Principle, and mathematics")]#text("“")],
[#text("Matilde Marcolli, “")#link("https://www.its.caltech.edu/~matilde/AImathNew.pdf")[#text("Duet for the end of math")]#text("“")],
[#text("Fenner Stanley Tanswell, “")#link("https://link.springer.com/article/10.1007/s00283-026-10566-7")[#text("Enshittification of Mathematics")]#text("“")]
)

#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3a67e42ee6dddacfe12657ab6801ed29cd7965344c6646279b187c7b76fefcd-cebbe0226281f777dfd322b06ca6de71b1485abcc4c199db5f5e8d10bdec0816.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/comment-page-1/#comment-697796")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Thanks for all these links!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/comment-page-1/#comment-697801")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Nice collection of essays with a diverse range of perspectives!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/33ff7914d1144cc96b983b8ecea1e7d76dfdee6aa74dde8366bd82ca1f633ee5-f2aa6adb732a099ddbaa8a9890f7e7778ae072a58e0e431574fd5a6f2273c8e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tiago Hirth")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/comment-page-1/#comment-697809")[#strong[#text("Tiago Hirth")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Hugo Duminil-Copin’s communication on Oct 8 made headlines recently as he admitted his emotional distress and newspapers picked up on this. ")#link("https://www.youtube.com/watch?v=iRjasLnigsU")[#text("https://www.youtube.com/watch?v=iRjasLnigsU")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2068874d615602ace43675e30a28a0ec8c438dbfee801031c9881a1ca800c7f9-1852b80e7c4f00adaaf1c0844747adfe2f495020c395708bdc4abcc3bec48bfb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christopher")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/comment-page-1/#comment-697820")[#strong[#text("Christopher")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Also interesting: there has been claims of improvements to OpenAI’s claimed QRH result (although as far as I can tell they are also vibe coded). Here is a leaderboard: ")#link("https://gtimg.github.io/QuasiRiemannTracker")[#text("https://gtimg.github.io/QuasiRiemannTracker")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/55559b2b66d3a919dc09ddb27cd2a7f5a7b2ee741b6b1fb9ad71d156e342006b-2319d6d0236a070be5b8f6db0b26be1159ae5754a1bea48c20b88051c8e8f34e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/comment-page-1/#comment-697827")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("At least some of your guest posts are not tagged as guest posts, so if one posts a link to your guest post tag somewhere it omits some guest posts about LLMs.")

#text("Vi Hart has a really wonderful lay-person discussion:")

#link("https://www.patreon.com/vihart/posts/vi-harts-big-171939430")[#text("https://www.patreon.com/vihart/posts/vi-harts-big-171939430")]

#text("Scott Aaronson has an excellent post about LLM usage in mathematics too, somewhat more targeted towards mathematicians and computer scientists. It’s slightly weakened towards the end by giving credence to AI doomer drama, but that’s easily ignored.")

#link("https://scottaaronson.blog/?p=10169")[#text("https://scottaaronson.blog/?p=10169")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c788bbd01590d24b7945e2c2cff89bbc403108378e4d541954e46a46e0b6a4f-aadf3525966206fba5a3a95de49c3634f5b5a1205a65a8ab35fd3dcee2c06674.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sma045")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/comment-page-1/#comment-697851")[#strong[#text("sma045")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Vi Hart is not a lay person in this context. Presumably Jeff is saying that it is aimed at or suitable for the laity.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa6171391d795c43a22b89aa28964451364ff63464662037bf5fd767e0258f57-a9e5a57bd76f1fcb11a5c7464b7a90640e62a90af1d4b6930712e4149fc3f994.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas M.")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/comment-page-1/#comment-697828")[#strong[#text("Klas M.")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("At the top right on my web page you will find my updating report on growth in the number of preprints in both mathematics and other subjects.")#linebreak()#link("http://abel.math.umu.se/~klasm/")[#text("http://abel.math.umu.se/~klasm/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c1f39fda4802b07a12426a497a616a2925f6b74301f71b8be661e831a3db403-2059c209ec074d3a72be41d2e6ca3f4b820a344c32e1c151067d6bcddf93fd5a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/comment-page-1/#comment-697833")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://thehighergeometer.wordpress.com/2026/10/12/what-even-is-mathematical-output/")[#text("What even is mathematical output?")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d5aa63ad831649ab9d351712a61aa2ebd4800a7b9832a43ca08f45f7be2e6f5d-4118606c9f193ce8222790ffac357e488adf1e607b477e99f27238a24d1e9491.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of trancuongkhtn")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/comment-page-1/#comment-697849")[#strong[#text("trancuongkhtn")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("My thought: ")#link("https://cuongtran.net/2026/10/08/openais-work-on-math-commoditization-moment/")[#text("OpenAI’s work on math: commoditization moment")]

#link("https://www.patreon.com/vihart/posts/vi-harts-big-171939430")[#text("Vi Hart’s Big Navier-Stokes Post")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b8592cd425054599bda8cc06635ac06f62e27ae92f77a715d6fc89b4b150cc8-db76b75a21fca2b7f9acb26f988473ac86679566939753741d8449f9520f3a46.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/comment-page-1/#comment-697856")[#strong[#text("S")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Christian Szegedy, ")#link("https://docs.google.com/document/d/e/2PACX-1vTSh-pyNP3Gi99WMmsinnLmE9V5CDI0HEm6WGbIPMNt3V5SGlClHF8-BetotKHOImrvQDSXmFdiOw8D/pub")[#text("“Is Mathematics Over, or Just Graduating?” (aka “Quo Vadis, Mathematics?”)")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Any")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/comment-page-1/#comment-697865")[#strong[#text("Any")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Aggressive, yet hopeful, by Szegedi")

#link("https://docs.google.com/document/d/e/2PACX-1vTSh-pyNP3Gi99WMmsinnLmE9V5CDI0HEm6WGbIPMNt3V5SGlClHF8-BetotKHOImrvQDSXmFdiOw8D/pub")[#text("https://docs.google.com/document/d/e/2PACX-1vTSh-pyNP3Gi99WMmsinnLmE9V5CDI0HEm6WGbIPMNt3V5SGlClHF8-BetotKHOImrvQDSXmFdiOw8D/pub")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/comment-page-1/#comment-697872")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Marcolli’s was a breath of fresh air!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0034ededecf4c8af3a0b27bb02c23241832b564237a5c06a1d2e01e8c05e579b-92345ce847ad29f2a22c82ec382f9f22dd3e4b24c78ff35fc93a69d970efb626.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/comment-page-1/#comment-697912")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I wrote this one on whether students should consider getting a PhD:")

#link("https://jasonpolak.substack.com/p/ai-does-math-should-you-get-a-phd")[#text("https://jasonpolak.substack.com/p/ai-does-math-should-you-get-a-phd")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/595eb024583db6b51e00f32a4f261c2580c6c3d4096b79cfb98f050713d2bb6d-3ccd590865198faff9af5ad7b2e774e4c3d6e0bb4eb24c396e40b7aaa84b7f61.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron Slipper")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/comment-page-1/#comment-697928")[#strong[#text("Aaron Slipper")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("Hi Professor Tao,")

#text("I wrote up the following as a rebuttal to the recent statements of the AHM (which you reposted). I also emailed it to you directly, so apologies if this is redundant; since you are explicitly soliciting articles, I link to it here.")

#link("https://aaronslipper.github.io/assets/math-and-ai-response-to-the-ahm.pdf")[#text("https://aaronslipper.github.io/assets/math-and-ai-response-to-the-ahm.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c7296301950cf44e8305ac97f57c919908b45ecce33f97ce9956d337ac81a234-0a783f9bd47dd85317db667314db39a1820e1cf7f9d18be22025bb1f4b142578.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/comment-page-1/#comment-697967")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("Very sad to see you go down the OpenAI rabbithole. If you think they are your friends, then you should reconsider")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/comment-page-1/#comment-698004")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2026")])]

#text("Well said. Let me quote a single one of your paragraphs here, for those who might not follow your link.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("If indeed we had really cared about the “human”")#linebreak()#text("understanding of mathematics, then the important work carried out by the paper referees, text-")#linebreak()#text("book/expository paper writers — not to mention the teaching faculty, high-quality mentors, etc. —")#linebreak()#text("that our community depends upon to transmit understanding would have a lot more prestige. But")#linebreak()#text("rather, we have consistently valued the point of discovery more highly than the points (plural) of")#linebreak()#text("dissemination.")
]

#text("The disruption caused by LLMs is not painless, but potentially one good thing to come out it is a restructuring of the mechanisms of evaluation that we have. For one, the results of non observable work (homework and research) cannot be a measure of individual skills. They have never been adequate, independently of the existence of LLMs, but now we are forced to replacing them.")

#text("In my opinion, in person contests, in person class evaluation, can perfectly replace the current hiring procedures, and do a better job at it.")

#text("Your post left, and nearly every other post in this blog, leaves an avenue unexplored. Understanding, and even human understanding, transmission of knowledge, are all not outside the reach of LLM’s output. The “mathematics is about understanding”, while partially true, is but a temporary bandage. For example, giving value to text-book writing, or any other of the examples in the paragraph that I quoted, would not be an adequate mean to evaluate people, when outputs of the same quality also start being obtained by exclusive LLM use. So, the answer cannot be (solely) to shift weight to the value of those activities. It wouldn’t work in the long (or perhaps short) run. The manner (not only the subject) in which the evaluation is carried also needs to change.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/comment-page-1/#comment-697992")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2026")])]

#text("Gamburd’s article is excellent and it contains some very sharp insights. I summarized my favourite of his here: ")#link("https://rutar.org/writing/mathematical-proof-ai/")[#text("https://rutar.org/writing/mathematical-proof-ai/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87719f3560c2f4c294b46a1a6333174bb33fc341d93e9807ad4a6ad625c5c11c-b00ee8cf7a6104c1ef1e3d1a98e197c0635940f3c973ddc817e041ab578b5e67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pukomuko")]], [#link("https://terrytao.wordpress.com/2026/10/12/additional-recent-pieces-on-math-and-ai/comment-page-1/#comment-698029")[#strong[#text("pukomuko")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2026")])]

#text("Your were mentioned by Steven Strogatz in nytimes podcast:")#linebreak()#link("https://www.nytimes.com/2026/10/13/podcasts/the-daily/mathematicians-problem-ai-jobs.html")[#text("https://www.nytimes.com/2026/10/13/podcasts/the-daily/mathematicians-problem-ai-jobs.html")]#linebreak()#text("“when ai comes for your purpose in life”")
]
