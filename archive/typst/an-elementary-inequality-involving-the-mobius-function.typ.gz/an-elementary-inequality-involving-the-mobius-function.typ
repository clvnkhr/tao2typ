// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/
// Converted to Typst by tao2typ: "2026-10-14T07:26:39.218327+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A remark on partial sums involving the Möbius function", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A remark on partial sums involving the Möbius function")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 August 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/")[#text("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv the paper ")#link("http://arxiv.org/abs/0908.4323")[#text("A remark on partial sums involving the Möbius function")]#text(", submitted to ")#link("http://www.austms.org.au/Bulletin")[#text("Bull. Aust. Math. Soc.")]#text(".")

#text("The ")#link("http://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("Möbius function")]#text(" ")#mi("{\\mu(n)}")#text(" is defined to equal ")#mi("{(-1)^k}")#text(" when ")#mi("{n}")#text(" is the product of ")#mi("{k}")#text(" distinct primes, and equal to zero otherwise; it is closely connected to the distribution of the primes. In 1906, Landau observed that one could show using purely elementary means that the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(" ")#metadata(none) <tao-a160524700113ddd3205>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{p \\leq x} 1 = (1+o(1)) \\frac{x}{\\log x}")]]

#text("(where ")#mi("{o(1)}")#text(" denotes a quantity that goes to zero as ")#mi("{x \\rightarrow \\infty}")#text(") was logically equivalent to the partial sum estimates ")#metadata(none) <tao-7d0e29e1ae5dae0508a3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{n \\leq x} \\mu(n) = o(x)")]]

#text("and ")#metadata(none) <tao-edef86bc418e84615321>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_{n \\leq x} \\frac{\\mu(n)}{n} = o(1);")]]

#text("we give a sketch of the proof of these equivalences below the fold.")

#text("On the other hand, these three inequalities are all easy to prove if the ")#mi("{o()}")#text(" terms are replaced by their ")#mi("{O()}")#text(" counterparts. For instance, by observing that the binomial coefficient ")#mi("{\\binom{2n}{n}}")#text(" is bounded by ")#mi("{4^n}")#text(" on the one hand (by ")#link("http://en.wikipedia.org/wiki/Pascal%27s_triangle")[#text("Pascal’s triangle")]#text(" or the ")#link("http://en.wikipedia.org/wiki/Binomial_theorem")[#text("binomial theorem")]#text("), and is divisible by every prime between ")#mi("{n}")#text(" and ")#mi("{2n}")#text(" on the other hand, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n < p \\leq 2n} \\log p \\leq n \\log 4")]]

#text("from which it is not difficult to show that ")#metadata(none) <tao-d29893ecad6668df84d4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{p \\leq x} 1 = O( \\frac{x}{\\log x} ).")]]

#text("Also, since ")#tao-math("{\\left|\\mu(n)\\right| \\leq 1}", block: false)#text(", we clearly have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\leq x} \\mu(n)\\right| \\leq x.", block: true)]]

#text("Finally, one can also show that ")#metadata(none) <tao-ddc4fcb8796e012de3ab>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left|\\sum_{n \\leq x} \\frac{\\mu(n)}{n}\\right| \\leq 1.", block: true)]]

#text("Indeed, assuming without loss of generality that ")#mi("{x}")#text(" is a positive integer, and summing the inversion formula ")#mi("{1_{n=1} = \\sum_{d|n} \\mu(d)}")#text(" over all ")#mi("{n \\leq x}")#text(" one sees that ")#metadata(none) <tao-e1608f75c5d7813f3d40>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("1 = \\sum_{d \\leq x} \\mu(d) \\left\\lfloor \\frac{x}{d}\\right \\rfloor = \\sum_{d \\leq x} \\mu(d) \\frac{x}{d} - \\sum_{d<x} \\mu(d) \\left \\{ \\frac{x}{d} \\right\\}")]]

#text("and the claim follows by bounding ")#tao-math("{\\left|\\mu(d) \\left \\{ \\frac{x}{d} \\right\\}\\right|}", block: false)#text(" by ")#mi("{1}")#text(".")

#text("In this paper I extend these observations to more general multiplicative subsemigroups of the natural numbers. More precisely, if ")#mi("{P}")#text(" is any set of primes (finite or infinite), I show that ")#metadata(none) <tao-ee5843eff4d693241ad5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left|\\sum_{n \\in \\langle P \\rangle: n \\leq x} \\frac{\\mu(n)}{n}\\right| \\leq 1", block: true)]]

#text("and that ")#metadata(none) <tao-c840a485beb8093aa086>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\sum_{n \\in \\langle P \\rangle: n \\leq x} \\frac{\\mu(n)}{n} = \\prod_{p \\in P} (1-\\frac{1}{p}) + o(1),")]]

#text("where ")#mi("{\\langle P \\rangle}")#text(" is the multiplicative semigroup generated by ")#mi("{P}")#text(", i.e. the set of natural numbers whose prime factors lie in ")#mi("{P}")#text(".")

#text("Actually the methods are completely elementary (the paper is just six pages long), and I can give the proof of ")#link(<tao-ee5843eff4d693241ad5>)[#text("(7)")]#text(" in full here. Again we may take ")#mi("{x}")#text(" to be a positive integer. Clearly we may assume that ")#metadata(none) <tao-82e05dae00a818a38267>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\sum_{n \\in \\langle P \\rangle: n \\leq x} \\frac{1}{n} > 1,")]]

#text("as the claim is trivial otherwise.")

#text("If ")#mi("{P^{\\prime}}")#text(" denotes the primes that are ")#emph[#text("not")]#text(" in ")#mi("{P}")#text(", then Möbius inversion gives us")

#align(center)[#tao-fit-display[#mitex("1_{n \\in \\langle P^{\\prime} \\rangle} = \\sum_{d|n; d \\in \\langle P \\rangle} \\mu(d).")]]

#text("Summing this for ")#mi("{1 \\leq n \\leq x}")#text(" gives")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in \\langle P^{\\prime} \\rangle: n \\leq x} 1 = \\sum_{d \\in \\langle P \\rangle: d \\leq x} \\mu(d) \\frac{x}{d} - \\sum_{d \\in \\langle P \\rangle: d \\leq x} \\mu(d) \\left \\{ \\frac{x}{d} \\right \\}.")]]

#text("We can bound ")#tao-math("{\\left|\\mu(d) \\left \\{ \\frac{x}{d} \\right \\}\\right| \\leq 1 - \\frac{1}{d}}", block: false)#text(" and so")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{d \\in \\langle P \\rangle: d \\leq x} \\mu(d) \\frac{x}{d}\\right| \\leq \\sum_{n \\in \\langle P^{\\prime} \\rangle: n \\leq x} 1 + \\sum_{n \\in \\langle P \\rangle: n \\leq x} 1 - \\sum_{n \\in \\langle P \\rangle: n \\leq x} \\frac{1}{n}.", block: true)]]

#text("The claim now follows from ")#link(<tao-82e05dae00a818a38267>)[#text("(9)")]#text(", since ")#mi("{\\langle P \\rangle}")#text(" and ")#mi("{\\langle P^{\\prime} \\rangle}")#text(" overlap only at ")#mi("{1}")#text(".")

#text("As special cases of ")#link(<tao-ee5843eff4d693241ad5>)[#text("(7)")]#text(" we see that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{d \\leq x: d|m} \\frac{\\mu(d)}{d}\\right| \\leq 1", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\leq x: (m,n)=1} \\frac{\\mu(n)}{n}\\right| \\leq 1", block: true)]]

#text("for all ")#mi("{m,x}")#text(". Since ")#mi("{\\mu(mn) = \\mu(m) \\mu(n) 1_{(m,n)=1}}")#text(", we also have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\leq x} \\frac{\\mu(mn)}{n}\\right| \\leq 1.", block: true)]]

#text("One might hope that these inequalities (which gain a factor of ")#mi("{\\log x}")#text(" over the trivial bound) might be useful when performing effective sieve theory, or effective estimates on various sums involving the primes or arithmetic functions.")

#text("This inequality ")#link(<tao-ee5843eff4d693241ad5>)[#text("(7)")]#text(" is so simple to state and prove that I must think that it was known to, say, Landau or Chebyshev, but I can’t find any reference to it in the literature. ")#text("[")#emph[#text("Update")]#text(", Sep 4: I have learned that similar results have been obtained in a ")#link("http://arxiv.org/abs/math/0508361")[#text("paper by Granville and Soundararajan")]#text(", and have updated the paper appropriately.] The proof of ")#link(<tao-c840a485beb8093aa086>)[#text("(8)")]#text(" is a simple variant of that used to prove ")#link(<tao-ee5843eff4d693241ad5>)[#text("(7)")]#text(" but I will not detail it here.")

#text("Curiously, this is one place in number theory where the elementary methods seem superior to the analytic ones; there is a zeta function ")#mi("{\\zeta_P(s) = \\sum_{n \\in \\langle P \\rangle} \\frac{1}{n^s} = \\prod_{p \\in P} (1-\\frac{1}{p^s})^{-1}}")#text(" associated to this problem, but it need not have a meromorphic continuation beyond the region ")#mi("{\\{ \\text{Re}(s) > 1 \\}}")#text(", and it turns out to be remarkably difficult to use this function to establish the above results. (I do have a proof of this form, which I in fact found before I stumbled on the elementary proof, but it is far longer and messier.)")

#metadata(none) <tao-d5d01b71c7746844fd9d>

#heading(level: 1)[#strong[#text(" — 1. Equivalences — ")]]

#text("We now show the equivalences between ")#link(<tao-a160524700113ddd3205>)[#text("(1)")]#text(", ")#link(<tao-7d0e29e1ae5dae0508a3>)[#text("(2)")]#text(", and ")#link(<tao-edef86bc418e84615321>)[#text("(3)")]#text(". The arguments here are drawn from ")#link("http://www.ams.org/mathscinet-getitem?mr=670132")[#text("this article of Diamond")]#text("; I will skip some of the details in order to focus on the main ideas.")

#text("It is convenient to introduce the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(" ")#mi("{\\Lambda(n)}")#text(", defined as ")#mi("{\\log p}")#text(" when ")#mi("{n}")#text(" is a prime ")#mi("{p}")#text(" (or a power of that prime), and zero otherwise. It is not difficult to see that the prime number theorem ")#link(<tao-a160524700113ddd3205>)[#text("(1)")]#text(" is equivalent to the asymptotic ")#metadata(none) <tao-48b676e2b107da679512>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\sum_{n \\leq x} \\Lambda(n) = (1+o(1)) x.")]]

#text("Now we show that ")#link(<tao-48b676e2b107da679512>)[#text("(10)")]#text(" implies ")#link(<tao-7d0e29e1ae5dae0508a3>)[#text("(2)")]#text(". The starting point is the identity")

#align(center)[#tao-fit-display[#mitex("-\\mu(n) \\log n = \\sum_{d|n} \\mu(d) \\Lambda(\\frac{n}{d})")]]

#text("connecting ")#mi("{\\mu}")#text(" and ")#mi("{\\Lambda}")#text(", which is the coefficient form of the identity")

#align(center)[#tao-fit-display[#mitex("(\\frac{1}{\\zeta(s)})^{\\prime} = \\frac{1}{\\zeta(s)} \\frac{-\\zeta^{\\prime}(s)}{\\zeta(s)}")]]

#text("involving the Riemann zeta function ")#mi("{\\zeta(s)}")#text(". Summing this identity for ")#mi("{1 \\leq n \\leq x}")#text(", one obtains the formula ")#metadata(none) <tao-845d12e49e49e1fc7973>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("- \\sum_{n \\leq x} \\mu(n) \\log n = \\sum_{d \\leq x} \\mu(d) \\sum_{m \\leq x/d} \\Lambda(m).")]]

#text("Using the Chebyshev bound ")#link(<tao-d29893ecad6668df84d4>)[#text("(4)")]#text(", one can bound ")#mi("{\\sum_{m \\leq x/d} \\Lambda(m)}")#text(" by ")#mi("{O(x/d)}")#text("; using ")#link(<tao-48b676e2b107da679512>)[#text("(10)")]#text(", one can refine this to ")#mi("{(1 + O(\\varepsilon)) x/d}")#text(" for any ")#mi("{\\varepsilon > 0}")#text(" when ")#mi("{x/d}")#text(" is large enough. Using these bounds together with ")#link(<tao-ddc4fcb8796e012de3ab>)[#text("(5)")]#text(", one can show that the right-hand side of ")#link(<tao-845d12e49e49e1fc7973>)[#text("(11)")]#text(" is ")#mi("{o( x \\log x )}")#text(". It is not too difficult to get to ")#link(<tao-7d0e29e1ae5dae0508a3>)[#text("(2)")]#text(" from here (e.g. by summation by parts).")

#text("To get from ")#link(<tao-7d0e29e1ae5dae0508a3>)[#text("(2)")]#text(" to ")#link(<tao-edef86bc418e84615321>)[#text("(3)")]#text(", we use ")#link(<tao-e1608f75c5d7813f3d40>)[#text("(6)")]#text(". A summation by parts argument using ")#link(<tao-7d0e29e1ae5dae0508a3>)[#text("(2)")]#text(" shows that")

#align(center)[#tao-fit-display[#mitex("\\sum_{x/A<d<x} \\mu(d) \\left \\{ \\frac{x}{d} \\right\\} = o(x)")]]

#text("for any fixed ")#mi("{A>1}")#text(" (basically because the function ")#mi("{d \\mapsto \\left \\{ \\frac{x}{d} \\right\\} }")#text(" has bounded variation). Letting ")#mi("{A}")#text(" go to infinity and using ")#link(<tao-e1608f75c5d7813f3d40>)[#text("(6)")]#text(" we obtain ")#link(<tao-edef86bc418e84615321>)[#text("(3)")]#text(". Conversely, a summation by parts argument easily deduces ")#link(<tao-7d0e29e1ae5dae0508a3>)[#text("(2)")]#text(" from ")#link(<tao-edef86bc418e84615321>)[#text("(3)")]#text(".")

#text("Finally, to get back from ")#link(<tao-7d0e29e1ae5dae0508a3>)[#text("(2)")]#text(" and ")#link(<tao-edef86bc418e84615321>)[#text("(3)")]#text(" to ")#link(<tao-48b676e2b107da679512>)[#text("(10)")]#text(", we use the identities ")#metadata(none) <tao-3ff68c1502cf515ab9fd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\Lambda(n) = \\sum_{d|n} \\mu(d) \\log \\frac{n}{d},")]]

#text("and ")#metadata(none) <tao-a73da189dac2fb336d14>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("1 = \\sum_{d|n} \\mu(d) \\tau(\\frac{n}{d}),")]]

#text("where ")#mi("{\\tau(n) := \\sum_{d|n} 1}")#text(" is the divisor function; these identities are the coefficient forms of the identities")

#align(center)[#tao-fit-display[#mitex("(\\frac{1}{\\zeta(s)})^{\\prime} = \\frac{1}{\\zeta(s)} \\frac{-\\zeta^{\\prime}(s)}{\\zeta(s)}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) = \\frac{1}{\\zeta(s)}\\zeta^2(s).")]]

#text("Expanding out ")#mi("{\\sum_{n \\leq x} \\Lambda(n)-1}")#text(" using these formulae, we see that to prove ")#link(<tao-48b676e2b107da679512>)[#text("(10)")]#text(" it suffices to show that ")#metadata(none) <tao-af07ff91ab7ce2a7d1f9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\sum_{d, m: dm \\leq x} \\mu(d) [ \\tau(m) - \\log m ] = o(x).")]]

#text("From the ")#link("http://planetmath.org/encyclopedia/HyperbolaMethod.html")[#text("Dirichlet hyperbola method")]#text(" one can show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\leq N} \\tau(m) = N \\log N + c N + O( N^{1/2} )")]]

#text("for some absolute constant ")#mi("{c}")#text(" (in fact ")#mi("{c = 2 \\gamma-1}")#text(", where ")#mi("{\\gamma = 0.577\\ldots}")#text(" is ")#link("http://en.wikipedia.org/wiki/Euler%E2%80%93Mascheroni_constant")[#text("Euler’s constant")]#text("), and from ")#link("http://en.wikipedia.org/wiki/Stirling%27s_formula")[#text("Stirling’s formula")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\leq N} \\log m = N \\log N - N + O(N^{1/2} )")]]

#text("and so")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\leq x/d} \\tau(m) - \\log m = (c+1) \\frac{x}{d} + O( \\sqrt{\\frac{x}{d}} ).")]]

#text("From this, ")#link(<tao-7d0e29e1ae5dae0508a3>)[#text("(2)")]#text(", ")#link(<tao-edef86bc418e84615321>)[#text("(3)")]#text(", and summation by parts one soon obtains ")#link(<tao-af07ff91ab7ce2a7d1f9>)[#text("(14)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" These equivalences are elementary, but somewhat ")#emph[#text("ad hoc")]#text(" in nature. A less elementary, but more “natural”, approach would be to rewrite everything in terms of the Riemann zeta function, and in particular to show that ")#link(<tao-48b676e2b107da679512>)[#text("(10)")]#text(", ")#link(<tao-7d0e29e1ae5dae0508a3>)[#text("(2)")]#text(", ")#link(<tao-edef86bc418e84615321>)[#text("(3)")]#text(" are all equivalent to the assertion that the zeta function has a simple pole at ")#mi("{s=1}")#text(" and no other poles or zeroes on the line ")#mi("{\\{ \\text{Re}(s) = 1 \\}}")#text(". This approach can of course be found in any introductory analytic number theory text.")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (30)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-41205")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2009")])]

#text("Terry:")#linebreak()#text(" Should this be tagged as ‘paper’ instead of ‘expository’? ")#emph[#text("[Corrected, thanks. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-41210")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2009")])]

#text("Dear Prof. Tao,")#linebreak()#text(" The spelling of Hans von Mangoldt’s name seems to be incorrect, in the second paragraph of section 1. (Feel free to delete this nitpicky post, also!) ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-41211")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2009")])]

#text("Dear Terry,")

#text("The arxiv link to the paper doesn’t seem to be the right one. ")#emph[#text("[Oops, the paper hasn’t appeared on the arXiv yet. It should within a day or so. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-41213")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2009")])]

#text("I don’t see how you get the number 1 on the far left of equation (6). Should that be x instead? (in which case you would get 2, not 1, as the desired bound).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-41215")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2009")])]

#text("The sum ")#mi("\\sum_{d|n} \\mu(d)")#text(" equals 1 for n=1 and zero otherwise, so ")#mi("\\sum_{n \\leq x} \\sum_{d|n} \\mu(d)")#text(" is equal to 1 for ")#mi("x \\geq 1")#text(". This sum can then be rearranged as ")#mi("\\sum_{d \\leq x} \\mu(d) \\lfloor \\frac{x}{d} \\rfloor")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-41220")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2009")])]

#text("Thanks!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-41226")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2009")])]

#text("Below is a simple example that I believe proves your conjecture that the sum")#linebreak()#text(" S(G,x) = sum_{n \\ in G : n <= x} mu(n)/n")#linebreak()#text(" diverges for certain mutliplicative subsemigroups G of the natural numbers.")

#text("Let P be the set of positive integers n=pq that are the product of two primes, and let G=. For an element n of G, we have mu(n)=1 when n is square-free and mu(n) = 0 otherwise. In particular, mu(n) >= 0 for all n \\in G, hence if S(G,x) converges, it does so absolutely.")

#text("But note that S(G,x) is bounded below by 1/2 sum_{2<p<=x} 1/p, which diverges, by Mertens' second theorem (sum_{p<=x} 1/p ~ loglog(x)).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-41227")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2009")])]

#text("Here G = \\langle P \\rangle is the semigroup generated by P.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-41230")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2009")])]

#text("Ah, yes, that seems to work, thanks!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-41247")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2009")])]

#text("If you search for “Beurling numbers” on Google (or Math SciNet, I suppose, although I don’t have access at the moment), you’ll find many related articles. Harold Diamond at the University of Illinois is an expert.")

#text("If I recall correctly, Beurling numbers are defined in the following manner. Let {p_1<p_2 < …} be an increasing sequence of real numbers, all larger than 1. These are our \"Beurling primes\". The \"Beurling numbers\" are the semigroup generated by the p_i, counting mulitiplicity. The general idea is that if the Beurling numbers are enough like the positive integers, then the Beurling primes are very similar to the primes. For example, there's a theorem along the lines of \"If the number of Beurling numbers less than x is asymptotically cx (for any positive constant c, with a nice error term), then the number of Beurling primes less than x is asymptotically x/log(x).\" In other words, the prime number theorem isn't really about the integers, it's just talking about semigroups of reals with linear growth.")

#text("Interestingly, the PNT error term can provably not be improved in this setting. It seems that any progress on the error term, the Riemann Hypothesis included, *must* utilize some properties of the integers aside from their multiplicative structure.")

#text("I learned about this line from a grad student at Illinois (Italian, but I don't recall his name) whose thesis was showing that for almost all (in some sense) choices of p_i, the Riemann Hypothesis does hold for the consequent zeta function.")

#text("I just found ")#link("http://www.math.kth.se/~rikardo/beurling.pdf")[#text("http://www.math.kth.se/~rikardo/beurling.pdf")]#text(", which seems relevant.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-41249")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2009")])]

#text("O’Bryant post is very interesting. However, in your next to last paragraph, do you mean “the Riemann Hypothesis doesn’t hold”? I would very much want to see the paper if you really mean otherwise.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-41318")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2009")])]

#text("Unfortunately, I don’t have any references. What I’ve heard has been in casual conversation and at seminars. The Italian student I referred to above is Eugene Balanzario, but I didn’t find any telling links with his name.")

#text("My impression is that the Riemann Hypothesis tends to hold (if the counting function for the Beurling numbers is ‘enough’ linear) in some rigorous sense, but that there are Beurling numbers with very linear growth where it fails. But, this is now third-hand info, that may not have been refereed to begin with. Harold Diamond is the one who should weigh in with the truth of things, what’s known true and known false.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f70d7d9a40e3f5c1710f690c394abb89a586f37d0f5632dd864c10c1846d349c-650e44c9f012ab8595ff7643f3ef362af447f46e2779a5ca5962f1cf50324f1a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eugenio P. Balanzario")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-41418")[#strong[#text("Eugenio P. Balanzario")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2009")])]

#text("Kevin, my second given name is Pacelli, which is certainly Italian, but I am not. You can easily produce examples of Beurling numbers for which the Riemann Hypothesis is either true or false. In my PhD thesis, written under the direction of Prof. Diamond, I considered the Mobius function of a particular set of Beurling numbers. This example is interesting because it shows that the prime number theorem is not equivalent (in the general setting of Beurling) to the statement M(x)=o(x) where M(x) is the sum of the Moubius function.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The prime number theorem in arithmetic progressions, and dueling conspiracies « What’s new")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-41575")[#strong[#text("The prime number theorem in arithmetic progressions, and dueling conspiracies « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2009")])]

#text("[…] noted in this previous post, we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erdos’ divisor bound « What’s new")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-59952")[#strong[#text("Erdos’ divisor bound « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2011")])]

#text("[…] This type of argument is also known as the Dirichlet hyperbola method. A variant of this argument can also deduce the prime number theorem from (3), (4) (and with some additional effort, one can even drop the use of (4)); this is discussed at this previous blog post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Chowla conjecture and the Sarnak conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-182159")[#strong[#text("The Chowla conjecture and the Sarnak conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2012")])]

#text("[…] already equivalent to the prime number theorem, as observed by Landau (see e.g. this previous blog post for a proof), while the much stronger (and still open) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 089l8")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-400585")[#strong[#text("089l8")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2014")])]

#text("I do not know whether there is such a hypothesis or theorem")#linebreak()#text(" I suppose it would be")#linebreak()#text(" ")#mi("\\displaystyle \\sum_{n\\le x}{f(n)\\sim \\frac{1}{\\sum_{n\\le x}{\\mu (n)f(n)}}}")#text(" .")#linebreak()#text(" ")#mi("f\\left(n\\right)-continius\\ function\\ (p{\\rm erhaps}{\\rm \\ }{\\rm other\\ functions})")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d32cceeab664fa2a476ec9cb989b5708e3c0b6d7ee6a2fcb75aea38b080a7f79-56ceefa1a2e06bfc7dee2e56390a06aaf741ea4a6d0cb231047340b60a2c89ae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 089l8")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-400617")[#strong[#text("089l8")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2014")])]

#text("Drew attention to the Dirichlet series is possible using them can be proved")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-471537")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2016")])]

#text("Is it possible to estimate the number of negative values of sums of type (7) on some interval? Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-471538")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2016")])]

#text("Is it possible to extend the above results by requiring that the elements of the set ")#mi("P")#text(" (instead of being primes) are needed only to be “pseudo primes” in the sense of being in ")#mi("(1, + \\infty)")#text(", having no accumulation points, and their logarithms independent over the rationals ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The logarithmically averaged and non-logarithmically averaged Chowla conjectures | What's new")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-487851")[#strong[#text("The logarithmically averaged and non-logarithmically averaged Chowla conjectures | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2017")])]

#text("[…] , this conjecture is equivalent to the prime number theorem (as discussed in this previous blog post), but the conjecture remains open for any […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2eac001fe46354c7f63e161276a653cfc579fb61703d1d073294e328f5d79ad-47afd3062ae7367d276d31554da48dbda4297708458a6f54820be4f78d1f1e8b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PLG")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-488052")[#strong[#text("PLG")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2017")])]

#text("I am working on the combinatorics of walks on graphs, which is actually nothing more than a semi-commutative extension of number theory. Whist the tools provided by this approach are crude from the point of view of number theory (because they must function without knowledge of which primes do or do not commute), they seem to suggest that the average orders relation:")

#mi("\\displaystyle \\frac{1}{x}\\sum_{m=1}^x\\sum_{n\\leq m\\atop p\\nmid n}\\frac{\\mu(n)}{n}\\sim\\frac{\\log x}{x\\log p}")

#text("holds for all ")#mi("p")#text(" prime. While I cannot see how this is consistent with the result of Granville and Soundararajan, I am interested in understanding the relation between their result and the above, especially since the above, if indeed correct, can be obtained from essentially outside of number theory, in fact in a way that would work even in the absence or partial absence of commutativity between the primes. In the general case, the above result can be given a determinantal form valid on all graphs, and where the primes are the self-avoiding walks and polygons of the graph. Would anybody have an idea of the relation between this average order and the relaiton by Granville and Soundararajan?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-488101")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2017")])]

#text("I don’t see any reason to expect this asymptotic; Perron’s formula suggests that the left-hand side should contain terms proportional to ")#mi("x^{\\rho-1}")#text(" for every zero of the zeta function; one would only obtain a term of the form ")#mi("\\log x/x")#text(" if ")#mi("\\zeta(s)")#text(" had a zero at ")#mi("s=0")#text(", which is not the case, and in any event it would be swamped by the zeroes in the critical strip (in particular, the LHS should only decay like ")#mi("x^{-1/2+o(1)}")#text(" assuming standard conjectures such as RH). Some quick and dirty numerics (see ")#link("https://terrytao.files.wordpress.com/2017/10/plot.png")[#text("https://terrytao.files.wordpress.com/2017/10/plot.png")]#text(" ) of the ratio of the LHS and RHS for ")#mi("x \\leq 10,000")#text(" do not seem to indicate to me that the asymptotic holds. Perhaps there is a typo in the proposed asymptotic?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2eac001fe46354c7f63e161276a653cfc579fb61703d1d073294e328f5d79ad-47afd3062ae7367d276d31554da48dbda4297708458a6f54820be4f78d1f1e8b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PLG")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-488106")[#strong[#text("PLG")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2017")])]

#text("The result is supposed to be a statement on average orders, with clear fluctuations expected around. I did numerics as well up to 1000000 with various primes and the result holds pretty well. That said, I forgot a factor of 2 in the equation I wrote, which should read ")#mi("\\frac{2\\log x}{x\\log p}\\sim \\frac{1}{x}\\sum_{m=1}^x\\sum_{n\\leq m\\atop p\\nmid n}\\frac{\\mu(n)}{n}")#text(", where the ")#mi("\\sim")#text(" indicates only truth for the average order.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2eac001fe46354c7f63e161276a653cfc579fb61703d1d073294e328f5d79ad-47afd3062ae7367d276d31554da48dbda4297708458a6f54820be4f78d1f1e8b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PLG")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-488108")[#strong[#text("PLG")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2017")])]

#text("We are not plotting the same thing at all it seems, ")#mi("\\frac{2\\log x}{x\\log p}\\sim \\frac{1}{x}\\sum_{m\\leq x}\\sum_{m\\leq n}\\frac{\\mu(n)}{n}")#text(" holds very well for various primes up to x>100000.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-488126")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2017")])]

#text("Ah, I see what is going on now. The Dirichlet series of ")#mi("\\mu(n) 1_{p \\not | n}")#text(" is ")#mi("(1-1/p^s)^{-1} \\zeta(s)^{-1}")#text(", which has a pole at every zero ")#mi("\\rho")#text(" of ")#mi("\\zeta")#text(", but additionally has a further zero at ")#mi("s=0")#text(". Perron’s formula and the residue theorem indicates that each zero should contribute a term of the form ")#mi("\\frac{x^{\\rho-1}}{\\rho(\\rho-1) \\zeta^{\\prime}(\\rho) (1-1/p^\\rho)}")#text(" if I have calculated correctly, whereas the ")#mi("s=0")#text(" term should contribute ")#mi("\\frac{-1}{\\zeta(0) \\log p} \\frac{\\log x}{x}")#text(" which is indeed ")#mi("\\frac{2 \\log x}{x \\log p}")#text(". This term is lower order than the contribution of the zeroes within the strip so one would not expect to see it in a pointwise sense even on RH, but one could in principle detect it if one averaged in a smooth enough fashion to damp out the effect of the zeroes. (Incidentally my plot previously was for ")#mi("p=2")#text(", and I suppose one could say that it was broadly consistent with the ratio eventually oscillating around 2.)")

#text("The results in Granville and Soundararajan contain error terms such as ")#mi("O( 1 / \\log^{1/5} x )")#text(" that are far larger than any of the orders of magnitude considered here, so there is no conflict between these claims and those in GS.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2eac001fe46354c7f63e161276a653cfc579fb61703d1d073294e328f5d79ad-47afd3062ae7367d276d31554da48dbda4297708458a6f54820be4f78d1f1e8b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PLG")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-488150")[#strong[#text("PLG")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2017")])]

#text("While the result itself is not so interesting, the fact that it holds is actually significant because it was derived from outside of number theory in a fashion that is valid and applicable on all graphs and furthermore because we have an infinite series of correction terms all of which we know perfectly well. I did a calculation to check the first correction term, and found the average order of Granville and Soundararajan second term (the one with 1-")#mi("\\gamma")#text(" in front) etc. The third term is still unknown to number theory but accessible easy from graphs (I used the formalism layed out in our article on algebraic combinatorics in trace monoids), where this third term involves the second derivtive of a determinant, which will give rise to averages of functions of the type ")#mi("\\log^2n \\mu(n)/n")#text(" etc. There is an antire reservoir of advanced results here to be translated in number theory.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18527501c55d86b22191ad1d7408ec05b06fec885df0e4a4a2d74dd8254ede2c-b3228effeccebc914c30a014e4eda55e6117e1810257eb76a8c5f177e00801bb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Seco")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-622509")[#strong[#text("Daniel Seco")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2021")])]

#text("Thanks for this article! Is there any subsequence of the natural numbers for which we know the value or at least the sign of the l.h.s. of (3)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-623572")[#strong[#text("Bound on a scaled sum of the Liouville function ~ MathOverflow ~ mathubs.com")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2021")]

#text("[…] Tao has shown see his blog post […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/#comment-688325")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2025")])]

#text("About Remark 1.5 in your paper on Arxiv, what would happen if one chose the set of primes as the primes ")#mi("<\\sqrt{x}")#text("? I would expect the o(1) error term to still go to zero with growing x, maybe as ")#mi("1/\\log(x)")#text(", even if the set of primes depends on x. Would that be the case? Thanks! Fabio")
]
