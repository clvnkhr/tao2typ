// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/
// Converted to Typst by tao2typ: "2026-10-14T16:35:04.543196+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "John’s blowup theorem for the nonlinear wave equation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("John’s blowup theorem for the nonlinear wave equation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 October 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/")[#text("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Today I’d like to discuss (part of) a ")#link("http://www.ams.org/mathscinet-getitem?mr=535704")[#text("cute and surprising theorem")]#text(" of ")#link("http://en.wikipedia.org/wiki/Fritz_John")[#text("Fritz John")]#text(" in the area of ")#link("http://tosio.math.toronto.edu/wiki/index.php/Wave_equations")[#text("non-linear wave equations")]#text(", and specifically for the equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\partial_{tt} u - \\Delta u = \\left|u\\right|^p", block: true)]]

#text("where ")#mi("u: {\\Bbb R} \\times {\\Bbb R}^3 \\to {\\Bbb R}")#text(" is a scalar function of one time and three spatial dimensions.")

#text("The evolution of this type of non-linear wave equation can be viewed as a “race” between the ")#link("http://tosio.math.toronto.edu/wiki/index.php/Dispersive")[#text("dispersive")]#text(" tendency of the linear wave equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\partial_{tt} u - \\Delta u = 0")]]

#text("and the ")#link("http://en.wikipedia.org/wiki/Positive_feedback")[#text("positive feedback")]#text(" tendencies of the nonlinear ")#link("http://en.wikipedia.org/wiki/Ordinary_differential_equation")[#text("ODE")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\partial_{tt} u = \\left|u\\right|^p.", block: true)]]

#text("More precisely, solutions to (2) tend to decay in time as ")#mi("t \\to +\\infty")#text(", as can be seen from the presence of the ")#mi("\\frac{1}{t}")#text(" term in the explicit formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("u(t,x) =  \\frac{1}{4\\pi t} \\int_{\\left|y-x\\right|=t} \\partial_t u(0,y)\\ dS(y) + \\partial_t[\\frac{1}{4\\pi t} \\int_{\\left|y-x\\right|=t} u(0,y)\\ dS(y)],", block: true)]]

#text("for such solutions in terms of the initial position ")#mi("u(0,y)")#text(" and initial velocity ")#mi("\\partial_t u(0,y)")#text(", where ")#mi("t > 0")#text(", ")#mi("x \\in {\\Bbb R}^3")#text(", and dS is the ")#link("http://mathworld.wolfram.com/AreaElement.html")[#text("area element")]#text(" of the sphere ")#tao-math("\\{ y \\in {\\Bbb R}^3: \\left|y-x\\right|=t \\}", block: false)#text(". (For this post I will ignore the technical issues regarding how smooth the solution has to be in order for the above formula to be valid.) On the other hand, solutions to (3) tend to blow up in finite time from data with positive initial position and initial velocity, even if this data is very small, as can be seen by the family of solutions")

#align(center)[#tao-fit-display[#mitex("u_T(t,x) := c (T-t)^{-2/(p-1)}")]]

#text("for ")#mi("T > 0")#text(", ")#mi("0 < t < T")#text(", and ")#mi("x \\in {\\Bbb R}^3")#text(", where c is the positive constant ")#mi("c := (\\frac{2(p+1)}{(p-1)^2})^{1/(p-1)}")#text(". For T large, this gives a family of solutions which starts out very small at time zero, but still manages to go to infinity in finite time.")

#text("The equation (1) can be viewed as a combination of equations (2) and (3) and should thus inherit a mix of the behaviours of both its “parents”. As a general rule, when the initial data ")#mi("u(0,\\cdot), \\partial_t u(0,\\cdot)")#text(" of solution is small, one expects the dispersion to “win” and send the solution to zero as ")#mi("t \\to \\infty")#text(", because the nonlinear effects are weak; conversely, when the initial data is large, one expects the nonlinear effects to “win” and cause blowup, or at least large amounts of instability. This division is particularly pronounced when p is large (since then the nonlinearity is very strong for large data and very weak for small data), but not so much for p small (for instance, when p=1, the equation becomes essentially linear, and one can easily show that blowup does not occur from reasonable data.)")

#text("The theorem of John formalises this intuition, with a remarkable threshold value for p:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Theorem. Let ")#mi("1 < p < \\infty")#text(".")

#enum(start: 1, 
[#text("If ")#mi("p < 1+\\sqrt{2}")#text(", then there exist solutions which are arbitrarily small (both in size and in support) and smooth at time zero, but which blow up in finite time.")],
[#text("If ")#mi("p > 1+\\sqrt{2}")#text(", then for every initial data which is sufficiently small in size and support, and sufficiently smooth, one has a global solution (which goes to zero uniformly as ")#mi("t \\to \\infty")#text(").")]
)
]

#text("[At the critical threshold ")#mi("p = 1 + \\sqrt{2}")#text(" one also has blowup from arbitrarily small data, as was shown subsequently ")#link("http://www.ams.org/mathscinet-getitem?mr=824205")[#text("by Schaeffer")]#text(".]")

#text("The ostensible purpose of this post is to try to explain why the curious exponent ")#mi("1+\\sqrt{2}")#text(" should make an appearance here, by sketching out the proof of part 1 of John’s theorem (I will not discuss part 2 here); but another reason I am writing this post is to illustrate how to make quick “back-of-the-envelope” calculations in harmonic analysis and PDE which can obtain the correct numerology for such a problem much faster than a fully rigorous approach. These calculations can be a little tricky to handle properly at first, but with practice they can be done very swiftly.")

#metadata(none) <tao-250e3307bb9912e4e36a>

#text("The first step, which is standard in nonlinear evolution equations, is to rewrite the differential equation (1) as an integral equation. Just as the basic ODE")

#align(center)[#tao-fit-display[#mitex("\\partial_t u = F")]]

#text("can be rewritten via the fundamental theorem of calculus in the integral form")

#align(center)[#tao-fit-display[#mitex("u(t) = u(0) + \\int_0^t F(s)\\ ds,")]]

#text("it turns out that the inhomogeneous wave equation")

#align(center)[#tao-fit-display[#mitex("\\partial_{tt} u - \\Delta u = F")]]

#text("can be rewritten via the ")#link("http://en.wikipedia.org/wiki/Fundamental_solution")[#text("fundamental solution")]#text(" (4) of the homogeneous equation (together with ")#link("http://en.wikipedia.org/wiki/Duhamel's_principle")[#text("Duhamel’s principle")]#text(") in the integral form")

#align(center)[#tao-fit-display[#tao-math("u(t,x) = u_{\\rm lin}(t,x) + \\frac{1}{4\\pi} \\int_0^t \\int_{\\left|y-x\\right|=\\left|t-s\\right|} \\frac{1}{t-s} F(s,y)\\ dS(y) ds", block: true)]]

#text("where ")#mi("u_{\\rm lin}")#text(" is the solution to the homogeneous wave equation (2) with initial position ")#mi("u(0,x)")#text(" and initial velocity ")#mi("\\partial_t u(0,x)")#text(" (and is given using (4)). [I plan to write more about this formula in a later post, but today I will just treat it as a miraculous identity. I will note however that the formula generalises Newton’s formula ")#tao-math("u(x) = \\frac{1}{4\\pi} \\int_{{\\Bbb R}^3} \\frac{1}{\\left|x-y\\right|} F(y)\\ dy", block: false)#text(" for the standard solution to Poisson’s equation ")#mi("-\\Delta u = F")#text(".]")

#text("Using the fundamental solution, the nonlinear wave equation (1) can be rewritten in integral form as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("u(t,x) = u_{\\rm lin}(t,x) + \\frac{1}{4\\pi} \\int_0^t \\int_{\\left|y-x\\right|=\\left|t-s\\right|} \\frac{1}{t-s} \\left|u(s,y)\\right|^p\\ dS(y) ds.", block: true)]]

#text("[Strictly speaking, one needs to first show that the solution exists and is sufficiently smooth before (5) can be rigorously applied, but this turns out to be a routine technical detail and I will not discuss it here.]")

#text("John’s argument now exploits a remarkable feature of the fundamental solution of the three-dimensional wave equation, namely that it is non-negative; combining this with the non-negativity of the forcing term ")#tao-math("\\left|u\\right|^p", block: false)#text(", we see that the integral in (5), that represents the cumulative effect of the nonlinearity, is always non-negative. Thus we have the pointwise inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("u(t,x) \\geq u_{\\rm lin}(t,x),")]]

#text("but also we see that any lower bound for u of the form ")#mi("u(t,x) \\geq v(t,x)")#text(" can be immediately bootstrapped via (5) to a new lower bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("u(t,x) \\geq u_{\\rm lin}(t,x) + \\frac{1}{4\\pi} \\int_0^t \\int_{\\left|y-x\\right|=\\left|t-s\\right|} \\frac{1}{t-s} \\left|v(s,y)\\right|^p\\ dS(y) ds.", block: true)]]

#text("This gives a way to iteratively give lower bounds on a solution u, by starting with the lower bound (5) (and computing ")#mi("u_{\\rm lin}(t,x)")#text(" explicitly using (4)) and then feeding this bound repeatedly into (7) to see what one gets. (This iteration procedure is closely related to the method of ")#link("http://en.wikipedia.org/wiki/Picard-Lindel%C3%B6f_theorem")[#text("Picard iteration")]#text(" for constructing solutions to nonlinear ODE or PDE, which is still widely used today in the modern theory.)")

#text("What will transpire is that this iterative process will yield successively larger lower bounds when ")#mi("p < 1 + \\sqrt{2}")#text(", but will yield successively smaller lower bounds when ")#mi("p > 1 + \\sqrt{2}")#text("; this is the main driving force behind John’s theorem. (To actually establish blowup in finite time when ")#mi("p < 1 + \\sqrt{2}")#text(", there is an auxiliary step that uses energy inequalities to show that once the solution gets sufficiently large, it will be guaranteed to develop singularities within a finite amount of additional time. To establish global solutions when ")#mi("p > 1 + \\sqrt{2}")#text(", one needs to show that the lower bounds constructed by this scheme in fact converge to the actual solution, and establish uniform control on all of these lower bounds.)")

#text("The remaining task is a computational one, to evaluate the various lower bounds for u arising from (6) and (7) from some given initial data. In principle, this is just an application of undergraduate several variable calculus, but if one sets about working out the relevant integrals exactly (using polar coordinates, etc.), the computations quickly become tediously complicated. But we don’t actually need exact, closed-form expressions for these integrals; just knowing the order of magnitude of these integrals is enough. For that task, much faster computational techniques are available.")

#text("Let’s see how. We begin with the computation of the linear solution ")#mi("u_{\\rm lin}(t,x)")#text(". This is given in terms of the initial data ")#mi("u(0,x), \\partial_t u(0,x)")#text(" via the formula (4). Now, for the purpose of establishing John’s theorem in the form stated above, we have the freedom to pick the initial data as we please, as long as it is smooth, small, and compactly supported. To make our life easier, we pick initial data with vanishing initial position and non-negative initial velocity, thus ")#mi("u(0,x) = 0")#text(" and ")#mi("\\partial_t u(0,x) \\geq 0")#text("; this eliminates the pesky partial derivative in (4) and makes ")#mi("u_{\\rm lin}")#text(" non-negative. More concretely, let us take")

#align(center)[#tao-fit-display[#mitex("\\partial_t u(0,x) = \\varepsilon \\psi( x / \\varepsilon )")]]

#text("for some fixed non-negative bump function ")#mi("\\psi")#text(" (the exact form is not relevant) and some small ")#mi("\\varepsilon > 0")#text(", thus the initial velocity has very small amplitude and width. To simplify the notation we shall work with macroscopic values of ")#mi("\\varepsilon")#text(", thus ")#mi("\\varepsilon \\sim 1")#text(", but it will be not hard to see that the arguments below also work for very small ")#mi("\\varepsilon")#text(" (though of course the smaller ")#mi("\\varepsilon")#text(" is, the longer it will take for blowup to occur).")

#text("As I said before, we only need an order of magnitude computation. Let us reflect this by describing the initial velocity ")#mi("\\partial_t u(0,x)")#text(" in fuzzier notation:")

#align(center)[#mi("\\partial_t u(0,x) \\sim 1 \\text{ when } x = O(1)")#text(".")]

#text("Geometrically, ")#mi("\\partial_t u")#text(" has “height” ")#mi("\\sim 1")#text(" on a ball of radius O(1) centred at the origin. We will retain this sort of fuzzy notation throughout the rest of the argument; it is not fully rigorous, but we can always go back and make the computations formal (and much lengthier) after we have performed the quick informal calculations to show the way ahead.")

#text("Thus we see from (4) that the linear solution ")#mi("u_{\\rm lin}(t,x)")#text(" can be expressed somewhat fuzzily in the form")

#align(center)[#tao-math("u_{\\rm lin}(t,x) \\sim \\frac{1}{t} \\int_{\\left|y-x\\right|=t; y = O(1)} 1 dS(y)", block: false)#text(".")]

#text("Note that the factor ")#mi("\\frac{1}{4\\pi}")#text(" can be discarded for the purposes of order of magnitude computation. Geometrically, the integral is measuring the area of the portion of the sphere ")#tao-math("\\{\\left|y-x\\right|=t\\}", block: false)#text(" which intersects the ball ")#mi("\\{y = O(1)\\}")#text(". A little bit of geometric visualisation will reveal that for large times ")#mi("t \\gg 1")#text(", this portion of the sphere will vanish unless ")#tao-math("\\left|x\\right|=t+O(1)", block: false)#text(", in which case it is a spherical cap of diameter O(1), and thus area O(1). Thus we are led to the back-of-the-envelope computation")

#align(center)[#tao-fit-display[#tao-math("u_{\\rm lin}(t,x) \\sim \\frac{1}{t} \\text{ when } \\left|x\\right|=t+O(1) \\text { and } t \\gg 1", block: true)]]

#text("with ")#mi("u_{\\rm lin}(t,x)")#text(" zero when ")#tao-math("\\left|x\\right| \\neq t + O(1)", block: false)#text(". (This vanishing outside of a neighbourhood of the light cone ")#tao-math("\\{ \\left|x\\right|=t \\}", block: false)#text(" is a manifestation of the sharp ")#link("http://en.wikipedia.org/wiki/Huygens'_principle")[#text("Huygens principle")]#text(".)")

#text("In particular, from (6) we obtain the initial lower bound")

#align(center)[#tao-math("u(t,x) \\gg \\frac{1}{t} \\text{ when } \\left|x\\right|=t+O(1) \\text { and } t \\gg 1", block: false)#text(".")]

#text("If we then insert this bound into (7) and discard the linear term ")#mi("u_{\\rm lin}")#text(" (which we already know to be positive, and which we have already “used up” in some sense) we obtain the lower bound")

#align(center)[#tao-fit-display[#tao-math("u(t,x) \\gg \\int_0^t \\int_{\\left|y-x\\right|=\\left|t-s\\right|; \\left|y\\right|=s+O(1); s \\gg 1} \\frac{1}{t-s} \\frac{1}{s^p}\\ dS(y) ds.", block: true)]]

#text("This is a moderately scary looking integral. But we can get a handle on it by first looking at it geometrically. For a fixed point (t,x) in spacetime, the region of integration is the intersection of a backwards light cone ")#tao-math("\\{ (s,y): 0 \\leq s \\leq t; \\left|y-x\\right|=\\left|t-s\\right| \\}", block: false)#text(" with a thickened forwards light cone ")#tao-math("\\{ (s,y): \\left|y\\right| = s + O(1); s \\gg 1 \\}", block: false)#text(". If |x| is much larger than t, then these cones will not intersect. If |x| is close to t, the intersection looks complicated, so let us consider the spacelike case when |x| is much less than t, say ")#tao-math("\\left|x\\right| \\leq t/2", block: false)#text("; we also continue working in the asymptotic regime ")#mi("t \\gg 1")#text(". In this case, a bit of geometry or algebra shows that the intersection of the two light cones is a two-dimensional ellipsoid in spacetime of radii ")#mi("\\sim t")#text(" (in particular, its surface area is ")#mi("\\sim t^2")#text("), and living at times s in the interior of ")#mi("{}[0,t]")#text(", thus s and t-s are both comparable to t. Thickening the forward cone, it is then geometrically intuitive that the intersection of the backwards light cone with the thickened forwards light cone is an angled strip around that ellipse of thickness ")#mi("\\sim 1")#text("; thus the total measure of this strip is roughly ")#mi("\\sim t^2")#text(". Meanwhile, since s and t-s are both comparable to t, the integrand is of magnitude ")#mi("\\sim \\frac{1}{t} \\frac{1}{t^p}")#text(". Putting all of this together, we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("u(t,x) \\gg t^2 \\frac{1}{t} \\frac{1}{t^p} = t^{1-p}")]]

#text("whenever we are in the interior cone region ")#tao-math("\\{ (t,x): t \\gg 1; \\left|x\\right| \\leq t/2 \\}", block: false)#text(".")

#text("To summarise so far, the linear evolution filled out the light cone ")#tao-math("\\{ (t,x): t \\gg 1; \\left|x\\right| = t + O(1) \\}", block: false)#text(" with a decay ")#mi("t^{-1}")#text(", and then the nonlinearity caused a secondary wave that filled out the interior region ")#tao-math("\\{ (t,x): t \\gg 1; \\left|x\\right| < t/2 \\}", block: false)#text(" with a decay ")#mi("t^{1-p}")#text(". We now compute the tertiary wave by inserting the secondary wave bound back into (7), to get")

#align(center)[#tao-fit-display[#tao-math("u(t,x) \\gg \\int_0^t \\int_{\\left|y-x\\right|=\\left|t-s\\right|; \\left|y\\right| < s/2; s \\gg 1} \\frac{1}{t-s} \\frac{1}{t^{p(1-p)}}\\ dS(y) ds.", block: true)]]

#text("Let us continue working in an interior region, say ")#tao-math("\\{ (t,x): t \\gg 1; \\left|x\\right| < t/4 \\}", block: false)#text(". The region of integration is the intersection of the backwards light cone ")#tao-math("\\{ (s,y): 0 \\leq s \\leq t; \\left|y-x\\right|=t-s \\}", block: false)#text(" with an interior region ")#tao-math("\\{ (s,t): s \\gg 1; \\left|y\\right| < s/2 \\}", block: false)#text(". A brief sketch of the situation reveals that this intersection basically consists of the portion of the backwards light cone in which s is comparable in size to t. In particular, this intersection has a three-dimensional measure of ")#mi("\\sim t^3")#text(", and on the bulk of this intersection, s and t-s are both comparable to t. So we obtain a lower bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("u(t,x) \\gg t^3 \\frac{1}{t} \\frac{1}{t^{p(1-p)}} = t^{1-p} t^{2 - (p-1)^2}")]]

#text("whenever ")#mi("t \\gg 1")#text(" and ")#tao-math("\\left|x\\right| < t/4", block: false)#text(".")

#text("Now we finally see where the condition ")#mi("p < 1 + \\sqrt{2}")#text(" will come in; if this condition is true, then ")#mi("2 - (p-1)^2")#text(" is positive, and so the tertiary wave is stronger than the secondary wave, and also situated in essentially the same location of spacetime. This is the beginning of a positive feedback loop; the quaternary wave will be even stronger still, and so on and so forth. Indeed, it is not hard to show that if ")#mi("p < 1 + \\sqrt{2}")#text(", then for any constant A, one will have a lower bound of the form ")#mi("u(t,x) \\gg t^A")#text(" in the interior of the light cone. This does not quite demonstrate blowup ")#emph[#text("per se")]#text(" – merely superpolynomial growth instead – but actually one can amplify this growth into blowup with a little bit more effort (e.g. integrating (1) in space to eliminate the Laplacian term and investigating the dynamics of the spatial integral ")#mi("\\int_{{\\Bbb R}^3}  u(t,x)\\ dx")#text(", taking advantage of finite speed of propagation for this equation, which limits the support of u to the cone ")#tao-math("\\{ \\left|x\\right| \\leq t + O(1) \\}", block: false)#text("). A refinement of these arguments, taking into account more of the components of the various waves in the iteration, also gives blowup for the endpoint ")#mi("p = 1 + \\sqrt{2}")#text(".")

#text("In the other direction, if ")#mi("p > 1 + \\sqrt{2}")#text(", the tertiary wave appears to be smaller than the secondary wave (though to fully check this, one has to compute a number of other components of these waves which we have discarded in the above computations). This sets up a negative feedback loop, with each new wave in the iteration scheme being smaller or decaying faster than the previous, and thus suggests global existence of the solution, at least when the size of the initial data (which was represented by ")#mi("\\varepsilon")#text(") was sufficiently small. This heuristic prediction can be made rigorous by controlling these iterates in various function space norms that capture these sorts of decay, but I will not detail them here.")

#text("[More generally, any analysis of a semilinear equation that requires one to compute the tertiary wave tends to give conditions on the exponents which are quadratic in nature; if the quaternary wave was involved also, then cubic constraints might be involved, and so forth. In this particular case, an analysis of the primary and secondary waves alone (which would lead just to linear constraints on p) are not enough, because these waves live in very different regions of spacetime and so do not fully capture the feedback mechanism.]")

#text("[")#emph[#text("Update")]#text(", Oct 27: typo corrected.]")

#text("[")#emph[#text("Update")]#text(", Nov 6: typo corrected.]")

#heading(level: 1)[#text("Comments (22)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/623234b797d68d51d68c8940fc7c41be398874ef3a244975fae64a0e303d62bb-bc6e3174e72df5606bd2736d2c15aaeb4c99d24bf8ce5db7a911280020a81d37.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/#comment-12904")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2007")])]

#text("What happens when u is complex-valued? Most everywhere I see this equation discussed it is real, but most nonlinear wave equations one is treated to the more general case of a complex valued field. Is there some reason that the complex valued case follows immediately or is of no more interest?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/#comment-12949")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2007")])]

#text("Regarding the “miraculous identity”, what happens when F is not just a function of u, but also of its derivatives? That’s what you typically have to deal with in realistic field theories involving more than one field; F then depends on those other fields, their derivatives, and derivatives of u, all mixed up in various hairraising ways. You might be able to get rid of time derivatives of u by a suitable choice of gauge, but not of spatial derivatives.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af64a65caab65fc49b7b8d52fc36918040afe4dbd79619262b00cb7b104c5cd7-32fb8ad828d29bb88943dce4564e36e59e2ae24193d1f0c577f69af54a42e520.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian K")]], [#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/#comment-12958")[#strong[#text("Brian K")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2007")])]

#text("For a good discussion of blow up of the Complex KdV equation, and proof of existence beyond blow-up, see Bjorn Birnir’s paper in SIAM Journ of Applied Math, August 1987.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shuanglin Shao")]], [#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/#comment-12964")[#strong[#text("Shuanglin Shao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2007")])]

#text("I like this trick of back-of-the envelop calculation here: very intuitive but efficient in getting to the point.")

#text("I was wondering what cause the eqution (1) so different from the dispersive NLW with nonlinear term ")#tao-math("\\left|u\\right|^{p-1}u", block: false)#text(" instead of ")#tao-math("\\left|u\\right|^p", block: false)#text(", where we have so-called critical, subcritical or supercritical phenomena? For instance, according to 1. in the Theorem, even for sufficiently small data, we still have finite time blow up if ")#mi("p<1+\\sqrt{2}")#text(".")

#text("A typo I found: a little above Eq. (9) in the post, the interior part should be $\\latex \\{(s,y): s\\gg 1; |y|<s/2 \\}$.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2fec6cda624d52107a9ca52311a6e3b3cad0f6434789ff44cfdc285b2e0ffb7f-f83f3bcd84fabb4e452d15e87221de7935af17d8fcb74d23c84019c0917a31af.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of carlbrannen")]], [#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/#comment-12977")[#strong[#text("carlbrannen")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2007")])]

#text("I appreciate the darker print for the text, thanks Dr. Tao. But now the equations show up in faint print, while the text is dark.")

#text("To make LaTeX equations print out in the same dark print requires that one put a gibberish text string just before the final dollar sign. This text defines the foreground and background colors, and also the size of the LaTeX equation. I use &bg=ffffff&fg=000000&s=1 to make things darker and a little larger. To compare the effects for readability: without: ")#mi("\\int_0^1x^2\\;dx")#text(" and with ")#mi("\\int_0^1x^2\\;dx")#text(" . (Prays briefly that no typos show up in the equations since wordpress won’t let us review comments before submitting.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/#comment-13032")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2007")])]

#text("Regarding extensions of John’s result to other nonlinearities: it is likely that the positive results (global existence for large p) continue to hold in these settings (though the presence of derivatives in the nonlinearity will make things technically more complicated), for instance I think it is known that any nonlinearity which is cubic in u and its first derivatives will lead to global decaying solutions from small data. On the other hand, it is much more difficult to force blowup, even for small p, when the nonlinearity does not have a consistent sign. The focusing nonlinearity ")#tao-math("\\left|u\\right|^{p-1} u", block: false)#text(" is OK since the evolution of this equation will match that of (1) so long as the solution to the latter is non-negative. The defocusing nonlinearity ")#tao-math("- \\left|u\\right|^{p-1} u", block: false)#text(" is a different matter; here one is guaranteed global existence for all ")#mi("1 < p < 1+\\sqrt{2}")#text(" even for large (smooth) complex data, basically because of the coercive nature of the conserved energy ")#tao-math("\\int_{\\Bbb R^3} \\frac{1}{2} \\left|\\nabla u\\right|^2 + \\frac{1}{2} \\left|u_t\\right|^2 + \\frac{1}{p+1} \\left|u\\right|^{p+1}", block: false)#text(".")

#text("Scaling considerations (which compare the relative strengths of the coarse and fine scales) here turn out to not be terribly relevant for these small data problems; as the data is smooth and compactly supported, it is almost entirely based in the medium scales, and the data is too small for any cascade of energy from the medium scales into the very fine or very coarse scales to have a significant effect. Instead, it is really the spatial and temporal interactions at the medium scale which are causing the difficulty here (although the secondary and tertiary waves do happen to have significantly lower frequency than the primary).")

#text("Dear Carl: unfortunately I do not see a way to automatically insert this string into every LaTeX equation (it seems very unlikely that one can do this via manipulating the CSS, for instance, and there does not appear to be support here for a javascript or macro based solution). Insertion by hand into every equation in every post would be rather impractical for obvious reasons. (A greasemonkey script might work, but I am not adept with these things.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/#comment-13074")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2007")])]

#text("Some blogs seem to show dark equations by default, for example:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://continuities.wordpress.com/2007/10/14/latex-with-grapher/")[#text("LaTeX with Grapher")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of GorDon")]], [#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/#comment-13113")[#strong[#text("GorDon")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2007")])]

#text("Dear Terry,")#linebreak()#text(" What do you think about extensions of John’s result which replace")#linebreak()#text(" the Laplacian with less smoothing operators? Maybe the form of")#linebreak()#text(" the nonlinearity might come into play big time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2fec6cda624d52107a9ca52311a6e3b3cad0f6434789ff44cfdc285b2e0ffb7f-f83f3bcd84fabb4e452d15e87221de7935af17d8fcb74d23c84019c0917a31af.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of carlbrannen")]], [#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/#comment-13188")[#strong[#text("carlbrannen")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2007")])]

#text("Terry, yeah, I put them in “by hand”, or more accurately, using a global search and replace as the last step before publishing. I should add in a keyboard macro, but I hate learning new stuff on computers.")

#text("Also, these calculations remind me of some stuff I studied on ")#link("http://en.wikipedia.org/wiki/Subharmonic_function")[#text("subharmonics and superharmonics")]#text(" several decades ago. More recently, I’ve played with nonlinear modifications of the Dirac equation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/#comment-13346")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2007")])]

#text("Hi Terence,")

#text("1+sqrt(2)")#linebreak()#text(" appears to be equivalent to the relatively periodic")#linebreak()#text(" 1+2sin(PI/4)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Orr")]], [#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/#comment-13788")[#strong[#text("Orr")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2007")])]

#text("Hello Prof. Tao,")#linebreak()#text(" In the paragraph after equation (4), you wrote")#linebreak()#text(" “On the other hand, solutions to (2) tend to blow up”")#linebreak()#text(" but I think you meant")#linebreak()#text(" “On the other hand, solutions to (3) tend to blow up”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Orr")]], [#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/#comment-13791")[#strong[#text("Orr")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2007")])]

#text("Hello again,")#linebreak()#text(" Can you clear up a little the case $p=1$?")#linebreak()#text(" First, it seems that your arguments above will work")#linebreak()#text(" for $p=1$.")#linebreak()#text(" Second, it seems very odd that, as you say, for p=1 there is no")#linebreak()#text(" blowup for reasonable data, then for $1 1 + \\sqrt{2}$.")

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Orr")]], [#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/#comment-13792")[#strong[#text("Orr")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2007")])]

#text("There was a mistake in my previous comment, should be:")

#text("Second, it seems very odd that, as you say, for p=1 there is no")#linebreak()#text(" blowup for reasonable data, then for 1 < p 1 + \\sqrt{2}.")

#text("Sorry and thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/#comment-13829")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2007")])]

#text("Dear Orr,")

#text("Thanks for the correction. When p=1, the analysis I described above does show that each new iteration of u grows faster than the previous one, and indeed one can soon show that u grows faster than ")#mi("t^A")#text(" for any fixed A. However, in this case of linear nonlinearity (ugh, you know what I mean), rapid growth does not force finite time blowup, basically because the ODE (3) does not exhibit blowup. Instead, one has exponential growth in time (which can be shown easily using Gronwall’s inequality).")

#text("Dear GorDon: When one changes the power of the dispersive term then the fundamental solution is unlikely to stay positive, which makes a direct application of John’s argument difficult. But there may be a way to salvage matters. For instance, subsequent work of Sideris showed that John’s blowup argument can be adapted to higher dimensions; the point being that even though the fundamental solution is no longer positive, certain antiderivatives of that solution remain positive, and this turns out to be enough positivity to coerce rapid growth and then blowup.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/#comment-13833")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2007")])]

#text("Can anyone inform me about corresponding results or reference when the non-linearity is replaced by u^pf(u,t)? What are the conditions that f should satisfy in order for such an analysis to go through?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/#comment-13834")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2007")])]

#text("Dear Anonymous,")

#text("There is a substantial literature that follows John’s original 1979 paper, see")

#link("http://www.ams.org/mathscinet/search/publications.html?refcit=535704&loc=refcit")[#text("http://www.ams.org/mathscinet/search/publications.html?refcit=535704&loc=refcit")]

#text("I am not sure whether your question is addressed directly, but there are certainly results on blowup on differential ")#emph[#text("inequalities")]#text(" of NLW type which may include some cases of your query as a special case. (There are also results for systems, in the presence of a potential, on manifolds or domains, etc.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a3f5dc4ae3dda8ded8978f3d9b795e29de5651a0e48638c6313955b7b1d2333-14d9de092a5a8feeac2e8d544212f7e73ea4ceba75e5729a80bea7ecd0e2ddd2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of deleted")]], [#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/#comment-13855")[#strong[#text("deleted")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2007")])]

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf535e2e2f8f081c7ea41f9a8d1a90fc556274255a131cf45066749d6fb24d7f-0272796322966bc66d3a685852efdadba6493a33fe71275d4d013a00f360f00b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/#comment-14994")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2007")])]

#text("A bit dumb (I think) question, related to Anonymous’s question (Nov 6th):")#linebreak()#text(" what if the f(x,t) multiplying the nonlinear term is a smooth function of compact support _in spacetime_? Perhaps then one can avoid blowup and have dispersive behaviour of sufiiciently small solutions for rather general nonlinear terms… or not?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/#comment-15087")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2007")])]

#text("Dear Pedro,")

#text("If the nonlinearity is compactly supported in time, then after a fixed period of time T the evolution is simply that of the linear wave equation, which cannot blow up. So then the issue is then simply for the solution to outlast the nonlinearity for this fixed amount of time T. By energy methods (using tools such as Gronwall’s inequality) one can show that this can be done if the initial data is small enough (e.g. exponentially small in T will suffice).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43d6165d4809bf9afee8b3bc1cbaa2d0af80eb285c350e3530a137ac7c1a1aee-17e1b2ca4a055b773fcf70cb5871b60736404325d75401944368c8db4965feec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zarai")]], [#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/#comment-31885")[#strong[#text("Zarai")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2008")])]

#text("Dear Anonymous,")#linebreak()#text(" Please Do you have any idea: How prove nonexistence of solutions if we add to the equation (1) the memory term?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3cd0c27ff430042219d9ccca6653c5a50968deedf243431ea406d27ef614989-eeca1a0377226cb3e9c77cb3a48fc0a6fc1fe56f40b3cf12e045ae1305fb762e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nik")]], [#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/#comment-39832")[#strong[#text("nik")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2009")])]

#text("Dear Terry,")

#text("it’s a nice argument you presented. However, in the case $ p > 1 + \\sqrt{2} $ it is not quite true that “each new wave in the iteration scheme will decay faster”. Actually, each new wave will decay in the the same way as the previous one, with a space-time bound 1/[(1+t+r) (1+|t-r|)^{p-2}]. What makes the scheme convergent is the fact that each next wave gains some extra powers of $ \\epsilon $, where $ \\epsilon $ is a measure of the smallness of initial data. (If the data is not small enough, there is no convergence.)")

#text("I give a very brief explanation of the appearance of the critical value $ p_0 = 1 + \\sqrt{2}$ from the convergence point of view ($p>p_0) in appendix of arXiv:0708.2801")

#text("All the best.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/26/johns-blowup-theorem-for-the-nonlinear-wave-equation/#comment-39834")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2009")])]

#text("Yes, I did manage to oversimplify in my discussion. If one of these waves enters the interior of the light cone (as was the case in the heuristic discussion), then all subsequent waves caused by that component will decay at increasingly more rapid rates, but yes, if one instead considers the contribution of one of these waves closer to the cone (particularly, closer to the spacetime origin at the vertex of the cone) then they will generate waves of smaller amplitude rather than faster decay. I’ve amended the description slightly to reflect this.")
]
