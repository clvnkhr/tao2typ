// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/04/21/the-limiting-absorption-principle/
// Converted to Typst by tao2typ: "2026-10-14T16:36:28.185834+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The limiting absorption principle", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The limiting absorption principle")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 April 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/04/21/the-limiting-absorption-principle/")[#text("https://terrytao.wordpress.com/2011/04/21/the-limiting-absorption-principle/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Perhaps the most fundamental differential operator on Euclidean space ")#mi("{{\\bf R}^d}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Laplace_operator")[#text("Laplacian")]

#align(center)[#tao-fit-display[#mitex("\\Delta := \\sum_{j=1}^d \\frac{\\partial^2}{\\partial x_j^2}.")]]

#text("The Laplacian is a linear translation-invariant operator, and as such is necessarily diagonalised by the Fourier transform")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) := \\int_{{\\bf R}^d} f(x) e^{-2\\pi i x \\cdot \\xi}\\ dx.")]]

#text("Indeed, we have")

#align(center)[#tao-fit-display[#tao-math("\\widehat{\\Delta f}(\\xi) = - 4 \\pi^2 \\left|\\xi\\right|^2 \\hat f(\\xi)", block: true)]]

#text("for any suitably nice function ")#mi("{f}")#text(" (e.g. in the Schwartz class; alternatively, one can work in very rough classes, such as the space of tempered distributions, provided of course that one is willing to interpret all operators in a distributional or weak sense).")

#text("Because of this explicit diagonalisation, it is a straightforward manner to define spectral multipliers ")#mi("{m(-\\Delta)}")#text(" of the Laplacian for any (measurable, polynomial growth) function ")#mi("{m: [0,+\\infty) \\rightarrow {\\bf C}}")#text(", by the formula")

#align(center)[#tao-fit-display[#tao-math("\\widehat{m(-\\Delta) f}(\\xi) := m( 4\\pi^2 \\left|\\xi\\right|^2 ) \\hat f(\\xi).", block: true)]]

#text("(The presence of the minus sign in front of the Laplacian has some minor technical advantages, as it makes ")#mi("{-\\Delta}")#text(" positive semi-definite. One can also define spectral multipliers more abstractly from general ")#link("http://en.wikipedia.org/wiki/Functional_calculus")[#text("functional calculus")]#text(", after establishing that the Laplacian is essentially self-adjoint.) Many of these multipliers are of importance in PDE and analysis, such as the ")#link("http://en.wikipedia.org/wiki/Fractional_derivative")[#text("fractional derivative")]#text(" operators ")#mi("{(-\\Delta)^{s/2}}")#text(", the ")#link("http://en.wikipedia.org/wiki/Heat_kernel")[#text("heat propagators")]#text(" ")#mi("{e^{t\\Delta}}")#text(", the (free) ")#link("http://en.wikipedia.org/wiki/Schr%C3%B6dinger_equation")[#text("Schrödinger propagators")]#text(" ")#mi("{e^{it\\Delta}}")#text(", the ")#link("http://en.wikipedia.org/wiki/Wave_equation")[#text("wave propagators")]#text(" ")#mi("{e^{\\pm i t \\sqrt{-\\Delta}}}")#text(" (or ")#mi("{\\cos(t \\sqrt{-\\Delta})}")#text(" and ")#mi("{\\frac{\\sin(t\\sqrt{-\\Delta})}{\\sqrt{-\\Delta}}}")#text(", depending on one’s conventions), the spectral projections ")#mi("{1_I(\\sqrt{-\\Delta})}")#text(", the ")#link("http://en.wikipedia.org/wiki/Bochner-Riesz_operator")[#text("Bochner-Riesz summation operators")]#text(" ")#mi("{(1 + \\frac{\\Delta}{4\\pi^2 R^2})_+^\\delta}")#text(", or the ")#link("http://en.wikipedia.org/wiki/Resolvent_formalism")[#text("resolvents")]#text(" ")#mi("{R(z) := (-\\Delta-z)^{-1}}")#text(".")

#text("Each of these families of multipliers are related to the others, by means of various integral transforms (and also, in some cases, by analytic continuation). For instance:")

#enum(start: 1, 
[#text("Using the ")#link("http://en.wikipedia.org/wiki/Laplace_transform")[#text("Laplace transform")]#text(", one can express (sufficiently smooth) multipliers in terms of heat operators. For instance, using the identity")

#align(center)[#tao-fit-display[#mitex("\\lambda^{s/2} = \\frac{1}{\\Gamma(-s/2)} \\int_0^\\infty t^{-1-s/2} e^{-t\\lambda}\\ dt")]]

#text("(using analytic continuation if necessary to make the right-hand side well-defined), with ")#mi("{\\Gamma}")#text(" being the ")#link("http://en.wikipedia.org/wiki/Gamma_function")[#text("Gamma function")]#text(", we can write the fractional derivative operators in terms of heat kernels: ")#metadata(none) <tao-6e126c801f89a6649767>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("(-\\Delta)^{s/2} = \\frac{1}{\\Gamma(-s/2)} \\int_0^\\infty t^{-1-s/2} e^{t\\Delta}\\ dt.")]]],
[#text("Using analytic continuation, one can connect heat operators ")#mi("{e^{t\\Delta}}")#text(" to Schrödinger operators ")#mi("{e^{it\\Delta}}")#text(", a process also known as ")#link("http://en.wikipedia.org/wiki/Wick_rotation")[#text("Wick rotation")]#text(". Analytic continuation is a notoriously unstable process, and so it is difficult to use analytic continuation to obtain any quantitative estimates on (say) Schrödinger operators from their heat counterparts; however, this procedure can be useful for propagating ")#emph[#text("identities")]#text(" from one family to another. For instance, one can derive the fundamental solution for the Schrödinger equation from the fundamental solution for the heat equation by this method.")],
[#text("Using the ")#link("http://en.wikipedia.org/wiki/Fourier_inversion_theorem")[#text("Fourier inversion formula")]#text(", one can write general multipliers as integral combinations of Schrödinger or wave propagators; for instance, if ")#mi("{z}")#text(" lies in the upper half plane ")#mi("{{\\bf H} := \\{ z \\in {\\bf C}: \\text{Im} z > 0 \\}}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x-z} = i\\int_0^\\infty e^{-itx} e^{itz}\\ dt")]]

#text("for any real number ")#mi("{x}")#text(", and thus we can write resolvents in terms of Schrödinger propagators: ")#metadata(none) <tao-493ea0b6bae201e248b0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("R(z) = i\\int_0^\\infty e^{it\\Delta} e^{itz}\\ dt.")]]

#text("In a similar vein, if ")#mi("{k \\in {\\bf H}}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x^2-k^2} = \\frac{i}{k} \\int_0^\\infty \\cos(tx) e^{ikt}\\ dt")]]

#text("for any ")#mi("{x>0}")#text(", so one can also write resolvents in terms of wave propagators: ")#metadata(none) <tao-da8d176f739559b1fb9c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("R(k^2) = \\frac{i}{k} \\int_0^\\infty \\cos(t\\sqrt{-\\Delta}) e^{ikt}\\ dt.")]]],
[#text("Using the ")#link("http://en.wikipedia.org/wiki/Cauchy_integral_formula")[#text("Cauchy integral formula")]#text(", one can express (sufficiently holomorphic) multipliers in terms of resolvents (or limits of resolvents). For instance, if ")#mi("{t > 0}")#text(", then from the Cauchy integral formula (and ")#link("http://en.wikipedia.org/wiki/Jordan%27s_lemma")[#text("Jordan’s lemma")]#text(") one has")

#align(center)[#tao-fit-display[#mitex("e^{itx} = \\frac{1}{2\\pi i} \\lim_{\\epsilon \\rightarrow 0^+} \\int_{\\bf R} \\frac{e^{ity}}{y-x+i\\epsilon}\\ dy")]]

#text("for any ")#mi("{x \\in {\\bf R}}")#text(", and so one can (formally, at least) write Schrödinger propagators in terms of resolvents: ")#metadata(none) <tao-6f92aa4976cb1212cd78>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("e^{-it\\Delta} = - \\frac{1}{2\\pi i} \\lim_{\\epsilon \\rightarrow 0^+} \\int_{\\bf R} e^{ity} R(y+i\\epsilon)\\ dy.")]]],
[#text("The imaginary part of ")#mi("{\\frac{1}{\\pi} \\frac{1}{x-(y+i\\epsilon)}}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Poisson_kernel")[#text("Poisson kernel")]#text(" ")#mi("{\\frac{\\epsilon}{\\pi} \\frac{1}{(y-x)^2+\\epsilon^2}}")#text(", which is an approximation to the identity. As a consequence, for any reasonable function ")#mi("{m(x)}")#text(", one has (formally, at least)")

#align(center)[#tao-fit-display[#mitex("m(x) = \\lim_{\\epsilon \\rightarrow 0^+} \\frac{1}{\\pi} \\int_{\\bf R} (\\text{Im} \\frac{1}{x-(y+i\\epsilon)}) m(y)\\ dy")]]

#text("which leads (again formally) to the ability to express arbitrary multipliers in terms of imaginary (or skew-adjoint) parts of resolvents: ")#metadata(none) <tao-079cdc52e64462dfac51>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("m(-\\Delta) = \\lim_{\\epsilon \\rightarrow 0^+} \\frac{1}{\\pi} \\int_{\\bf R} (\\text{Im} R(y+i\\epsilon)) m(y)\\ dy.")]]

#text("Among other things, this type of formula (with ")#mi("{-\\Delta}")#text(" replaced by a more general self-adjoint operator) is used in the resolvent-based approach to the spectral theorem (by using the limiting imaginary part of resolvents to build spectral measure). Note that one can also express ")#mi("{\\text{Im} R(y+i\\epsilon)}")#text(" as ")#mi("{\\frac{1}{2i} (R(y+i\\epsilon) - R(y-i\\epsilon))}")#text(".")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The ability of heat operators, Schrödinger propagators, wave propagators, or resolvents to generate other spectral multipliers can be viewed as a sort of manifestation of the ")#link("http://en.wikipedia.org/wiki/Stone%E2%80%93Weierstrass_theorem")[#text("Stone-Weierstrass theorem")]#text(" (though with the caveat that the spectrum of the Laplacian is non-compact and so the Stone-Weierstrass theorem does not directly apply). Indeed, observe the ")#link("http://en.wikipedia.org/wiki/*-algebra")[#text("*-algebra")]#text(" type properties")

#tao-aligned(keep: true)[


#tao-math("e^{s\\Delta} e^{t\\Delta}  & = e^{(s+t)\\Delta}; \\quad (e^{s\\Delta})^* = e^{s\\Delta}", block: true)



#tao-math("e^{is\\Delta} e^{it\\Delta}  & = e^{i(s+t)\\Delta}; \\quad (e^{is\\Delta})^* = e^{-is\\Delta}", block: true)



#tao-math("e^{is\\sqrt{-\\Delta}} e^{it\\sqrt{-\\Delta}}  & = e^{i(s+t)\\sqrt{-\\Delta}}; \\quad (e^{is\\sqrt{-\\Delta}})^* = e^{-is\\sqrt{-\\Delta}}", block: true)



#tao-math("R(z) R(w)  & = \\frac{R(w)-R(z)}{z-w}; \\quad R(z)^* = R(\\overline{z}).", block: true)
]
]

#text("Because of these relationships, it is possible (in principle, at least), to leverage one’s understanding one family of spectral multipliers to gain control on another family of multipliers. For instance, the fact that the heat operators ")#mi("{e^{t\\Delta}}")#text(" have non-negative kernel (a fact which can be seen from the maximum principle, or from the Brownian motion interpretation of the heat kernels) implies (by ")#link(<tao-6e126c801f89a6649767>)[#text("(1)")]#text(") that the fractional integral operators ")#mi("{(-\\Delta)^{-s/2}}")#text(" for ")#mi("{s>0}")#text(" also have non-negative kernel. Or, the fact that the wave equation enjoys finite speed of propagation (and hence that the wave propagators ")#mi("{\\cos(t\\sqrt{-\\Delta})}")#text(" have distributional convolution kernel localised to the ball of radius ")#tao-math("{\\left|t\\right|}", block: false)#text(" centred at the origin), can be used (by ")#link(<tao-da8d176f739559b1fb9c>)[#text("(3)")]#text(") to show that the resolvents ")#mi("{R(k^2)}")#text(" have a convolution kernel that is essentially localised to the ball of radius ")#tao-math("{O( 1 / \\left|\\text{Im}(k)\\right| )}", block: false)#text(" around the origin.")

#text("In this post, I would like to continue this theme by using the ")#emph[#text("resolvents")]#text(" ")#mi("{R(z) = (-\\Delta-z)^{-1}}")#text(" to control other spectral multipliers. These resolvents are well-defined whenever ")#mi("{z}")#text(" lies outside of the spectrum ")#mi("{[0,+\\infty)}")#text(" of the operator ")#mi("{-\\Delta}")#text(". In the model three-dimensional case ")#mi("{d=3}")#text(", they can be defined explicitly by the formula")

#align(center)[#tao-fit-display[#tao-math("R(k^2) f(x) = \\int_{{\\bf R}^3} \\frac{e^{ik\\left|x-y\\right|}}{4\\pi \\left|x-y\\right|} f(y)\\ dy", block: true)]]

#text("whenever ")#mi("{k}")#text(" lives in the upper half-plane ")#mi("{\\{ k \\in {\\bf C}: \\text{Im}(k) > 0 \\}}")#text(", ensuring the absolute convergence of the integral for test functions ")#mi("{f}")#text(". (In general dimension, explicit formulas are still available, but involve ")#link("http://en.wikipedia.org/wiki/Bessel_function")[#text("Bessel functions")]#text(". But asymptotically at least, and ignoring higher order terms, one simply replaces ")#tao-math("{\\frac{e^{ik\\left|x-y\\right|}}{4\\pi \\left|x-y\\right|}}", block: false)#text(" by ")#tao-math("{\\frac{e^{ik\\left|x-y\\right|}}{c_d \\left|x-y\\right|^{d-2}}}", block: false)#text(" for some explicit constant ")#mi("{c_d}")#text(".) It is an instructive exercise to verify that this resolvent indeed inverts the operator ")#mi("{-\\Delta-k^2}")#text(", either by using Fourier analysis or by Green’s theorem.")

#text("Henceforth we restrict attention to three dimensions ")#mi("{d=3}")#text(" for simplicity. One consequence of the above explicit formula is that for positive real ")#mi("{\\lambda > 0}")#text(", the resolvents ")#mi("{R(\\lambda+i\\epsilon)}")#text(" and ")#mi("{R(\\lambda-i\\epsilon)}")#text(" tend to different limits as ")#mi("{\\epsilon \\rightarrow 0}")#text(", reflecting the jump discontinuity in the resolvent function at the spectrum; as one can guess from formulae such as ")#link(<tao-6f92aa4976cb1212cd78>)[#text("(4)")]#text(" or ")#link(<tao-079cdc52e64462dfac51>)[#text("(5)")]#text(", such limits are of interest for understanding many other spectral multipliers. Indeed, for any test function ")#mi("{f}")#text(", we see that")

#align(center)[#tao-fit-display[#tao-math("\\lim_{\\epsilon \\rightarrow 0^+} R(\\lambda+i\\epsilon) f(x) = \\int_{{\\bf R}^3} \\frac{e^{i\\sqrt{\\lambda}\\left|x-y\\right|}}{4\\pi \\left|x-y\\right|} f(y)\\ dy", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\lim_{\\epsilon \\rightarrow 0^+} R(\\lambda-i\\epsilon) f(x) = \\int_{{\\bf R}^3} \\frac{e^{-i\\sqrt{\\lambda}\\left|x-y\\right|}}{4\\pi \\left|x-y\\right|} f(y)\\ dy.", block: true)]]

#text("Both of these functions")

#align(center)[#tao-fit-display[#tao-math("u_\\pm(x) := \\int_{{\\bf R}^3} \\frac{e^{\\pm i\\sqrt{\\lambda}\\left|x-y\\right|}}{4\\pi \\left|x-y\\right|} f(y)\\ dy", block: true)]]

#text("solve the ")#link("http://en.wikipedia.org/wiki/Helmholtz_equation")[#text("Helmholtz equation")]#text(" ")#metadata(none) <tao-e83664255c6963e962bb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("(-\\Delta-\\lambda) u_\\pm = f,")]]

#text("but have different asymptotics at infinity. Indeed, if ")#mi("{\\int_{{\\bf R}^3} f(y)\\ dy = A}")#text(", then we have the asymptotic ")#metadata(none) <tao-ced2eea28f29d92e3d4f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("u_\\pm(x) = \\frac{A e^{\\pm i \\sqrt{\\lambda}\\left|x\\right|}}{4\\pi\\left|x\\right|} + O( \\frac{1}{\\left|x\\right|^2})", block: true)]]

#text("as ")#tao-math("{\\left|x\\right| \\rightarrow \\infty}", block: false)#text(", leading also to the ")#link("http://en.wikipedia.org/wiki/Sommerfeld_radiation_condition")[#text("Sommerfeld radiation condition")]#text(" ")#metadata(none) <tao-1b71f6d5e519b708c9f0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("u_\\pm(x) = O(\\frac{1}{\\left|x\\right|}); \\quad (\\partial_r \\mp i\\sqrt{\\lambda}) u_\\pm(x) = O( \\frac{1}{\\left|x\\right|^2})", block: true)]]

#text("where ")#tao-math("{\\partial_r := \\frac{x}{\\left|x\\right|} \\cdot \\nabla_x}", block: false)#text(" is the outgoing radial derivative. Indeed, one can show using an integration by parts argument that ")#mi("{u_\\pm}")#text(" is the unique solution of the Helmholtz equation ")#link(<tao-e83664255c6963e962bb>)[#text("(6)")]#text(" obeying ")#link(<tao-1b71f6d5e519b708c9f0>)[#text("(8)")]#text(" (see below). ")#mi("{u_+}")#text(" is known as the ")#emph[#text("outward radiating")]#text(" solution of the Helmholtz equation ")#link(<tao-e83664255c6963e962bb>)[#text("(6)")]#text(", and ")#mi("{u_-}")#text(" is known as the ")#emph[#text("inward radiating")]#text(" solution. Indeed, if one views the function ")#mi("{u_\\pm(t,x) := e^{-i\\lambda t} u_\\pm(x)}")#text(" as a solution to the inhomogeneous Schrödinger equation")

#align(center)[#tao-fit-display[#mitex("(i\\partial_t + \\Delta) u_\\pm = - e^{-i\\lambda t} f")]]

#text("and using the de Broglie law that a solution to such an equation with wave number ")#mi("{k \\in {\\bf R}^3}")#text(" (i.e. resembling ")#mi("{A e^{i k \\cdot x}}")#text(" for some amplitide ")#mi("{A}")#text(") should propagate at (group) velocity ")#mi("{2k}")#text(", we see (heuristically, at least) that the outward radiating solution will indeed propagate radially away from the origin at speed ")#mi("{2\\sqrt{\\lambda}}")#text(", while inward radiating solution propagates inward at the same speed.")

#text("There is a useful quantitative version of the convergence ")#metadata(none) <tao-448401badfb36baab699>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("R(\\lambda \\pm i\\epsilon) f \\rightarrow u_\\pm,")]]

#text("known as the ")#emph[#text("limiting absorption principle")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Limiting absorption principle)")]#text(" ")#metadata(none) <tao-066addf6741e4a75b484>#text(" Let ")#mi("{f}")#text(" be a test function on ")#mi("{{\\bf R}^3}")#text(", let ")#mi("{\\lambda > 0}")#text(", and let ")#mi("{\\sigma > 0}")#text(". Then one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| R(\\lambda \\pm i\\epsilon) f \\right\\|_{H^{0,-1/2-\\sigma}({\\bf R}^3)} \\leq C_\\sigma \\lambda^{-1/2} \\left\\|f\\right\\|_{H^{0,1/2+\\sigma}({\\bf R}^3)}", block: true)]]

#text("for all ")#mi("{\\epsilon > 0}")#text(", where ")#mi("{C_\\sigma > 0}")#text(" depends only on ")#mi("{\\sigma}")#text(", and ")#mi("{H^{0,s}({\\bf R}^3)}")#text(" is the weighted norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{H^{0,s}({\\bf R}^3)} := \\left\\| \\langle x \\rangle^s f \\right\\|_{L^2_x({\\bf R}^3)}", block: true)]]

#text("and ")#tao-math("{\\langle x \\rangle := (1+\\left|x\\right|^2)^{1/2}}", block: false)#text(".")
]

#text("This principle allows one to extend the convergence ")#link(<tao-448401badfb36baab699>)[#text("(9)")]#text(" from test functions ")#mi("{f}")#text(" to all functions in the weighted space ")#mi("{H^{0,1/2+\\sigma}}")#text(" by a density argument (though the radiation condition ")#link(<tao-1b71f6d5e519b708c9f0>)[#text("(8)")]#text(" has to be adapted suitably for this scale of spaces when doing so). The weighted space ")#mi("{H^{0,-1/2-\\sigma}}")#text(" on the left-hand side is optimal, as can be seen from the asymptotic ")#link(<tao-ced2eea28f29d92e3d4f>)[#text("(7)")]#text("; a duality argument similarly shows that the weighted space ")#mi("{H^{0,1/2+\\sigma}}")#text(" on the right-hand side is also optimal.")

#text("We prove this theorem below the fold. As observed ")#link("http://www.ams.org/mathscinet-getitem?mr=190801")[#text("long ago by Kato")]#text(" (and also reproduced below), this estimate is equivalent (via a Fourier transform in the spectral variable ")#mi("{\\lambda}")#text(") to a useful estimate for the free Schrödinger equation known as the ")#emph[#text("local smoothing estimate")]#text(", which in particular implies the well-known ")#emph[#text("RAGE theorem")]#text(" for that equation; it also has similar consequences for the free wave equation. As we shall see, it also encodes some spectral information about the Laplacian; for instance, it can be used to show that the Laplacian has no eigenvalues, resonances, or singular continuous spectrum. These spectral facts are already obvious from the Fourier transform representation of the Laplacian, but the point is that the limiting absorption principle also applies to more general operators for which the explicit diagonalisation afforded by the Fourier transform is not available. (Igor Rodnianski and I are working on a paper regarding this topic, of which I hope to say more about soon.)")

#text("In order to illustrate the main ideas and suppress technical details, I will be a little loose with some of the rigorous details of the arguments, and in particular will be manipulating limits and integrals at a somewhat formal level.")

#metadata(none) <tao-0d3d00ff3bb5290dd9b3>

#heading(level: 1)[#strong[#text(" — 1. Uniqueness — ")]]

#text("We first use an integration by parts argument to show uniqueness of the solution to the Helmholtz equation ")#link(<tao-e83664255c6963e962bb>)[#text("(6)")]#text(" assuming the radiation condition ")#link(<tao-1b71f6d5e519b708c9f0>)[#text("(8)")]#text(". For sake of concreteness we shall work with the sign ")#mi("{\\pm=+}")#text(", and we will ignore issues of regularity, assuming all functions are as smooth as needed. (In practice, the elliptic nature of the Laplacian ensures that issues of regularity are easily dealt with.) If uniqueness fails, then by subtracting the two solutions, we obtain a non-trivial solution ")#mi("{u}")#text(" to the homogeneous Helmholtz equation ")#metadata(none) <tao-f9e012396be65db022bd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("(-\\Delta-\\lambda) u = 0")]]

#text("such that")

#align(center)[#tao-fit-display[#tao-math("u(x) = O(\\frac{1}{\\left|x\\right|}); \\quad (\\partial_r - i\\sqrt{\\lambda}) u(x) = O( \\frac{1}{\\left|x\\right|^2}).", block: true)]]

#text("Next, we introduce the ")#emph[#text("charge current")]

#align(center)[#tao-fit-display[#mitex("{\\bf j}^i := \\text{Im}( \\overline{u} \\partial^i u )")]]

#text("(using the usual Einstein index notations), and observe from ")#link(<tao-e83664255c6963e962bb>)[#text("(6)")]#text(" that this current is divergence-free:")

#align(center)[#tao-fit-display[#mitex("\\partial_i {\\bf j}^i = 0.")]]

#text("(This reflects the phase rotation invariance ")#mi("{u \\mapsto e^{i\\theta} u}")#text(" of the equation ")#link(<tao-e83664255c6963e962bb>)[#text("(6)")]#text(", and can also be viewed as a version of the conservation of the ")#link("http://en.wikipedia.org/wiki/Wronskian")[#text("Wronskian")]#text(".) From Stokes’ theorem, and using polar coordinates, we conclude in particular that")

#align(center)[#tao-fit-display[#mitex("\\int_{S^2} {\\bf j}^r(r\\omega)\\ d\\omega = 0")]]

#text("or in other words that")

#align(center)[#tao-fit-display[#mitex("\\int_{S^2} \\text{Im}(\\overline{u} \\partial_r u)(r\\omega)\\ d\\omega = 0.")]]

#text("Using the radiation condition, this implies in particular that ")#metadata(none) <tao-e5bf1f03cacff6adf049>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\int_{S^2} \\left|u(r\\omega)\\right|^2\\ d\\omega = O(r^{-3})", block: true)]]

#text("and ")#metadata(none) <tao-37f2bf676416d4a54481>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\int_{S^2} \\left|\\partial_r u(r\\omega)\\right|^2\\ d\\omega = O(r^{-3})", block: true)]]

#text("as ")#mi("{r \\rightarrow \\infty}")#text(".")

#text("Now we use the “positive commutator method”. Consider the expression ")#metadata(none) <tao-0551ffc77d5f3a5d68f2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\int_{{\\bf R}^3} [\\partial_r, -\\Delta-\\lambda] u(x) \\overline{u(x)}\\ dx.")]]

#text("(To be completely rigorous, one should insert a cutoff to a large ball, and then send the radius of that ball to infinity, in order to make the integral well-defined but we will ignore this technicality here.) On the one hand, we may integrate by parts (using ")#link(<tao-e5bf1f03cacff6adf049>)[#text("(11)")]#text(", ")#link(<tao-37f2bf676416d4a54481>)[#text("(12)")]#text(" to show that all boundary terms go to zero) and ")#link(<tao-f9e012396be65db022bd>)[#text("(10)")]#text(" to see that this expression vanishes. On the other hand, by expanding the Laplacian in polar coordinates we see that")

#align(center)[#tao-fit-display[#mitex("[-\\Delta-\\lambda, \\partial_r] = -\\frac{2}{r^2} \\partial_r - \\frac{2}{r^3} \\Delta_\\omega.")]]

#text("An integration by parts in polar coordinates (using ")#link(<tao-e5bf1f03cacff6adf049>)[#text("(11)")]#text(", ")#link(<tao-37f2bf676416d4a54481>)[#text("(12)")]#text(" to justify ignoring the boundary terms at infinity) shows that")

#align(center)[#tao-fit-display[#tao-math("-\\int_{{\\bf R}^3} \\frac{2}{r^2} \\partial_r u(x) \\overline{u(x)}\\ dx = 8 \\pi \\left|u(0)\\right|^2", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("-\\int_{{\\bf R}^3} \\frac{2}{r^3} \\Delta_\\omega u(x) \\overline{u(x)}\\ dx = 2 \\int_{{\\bf R}^3} \\frac{\\left|\\nabla_{\\text{ang}}\\right| u(x)|^2}{\\left|x\\right|}\\ dx", block: true)]]

#text("where ")#tao-math("{\\left|\\nabla_{\\text{ang}} u(x)\\right|^2 := \\left|\\nabla u(x)\\right|^2 - \\left|\\partial_r u(x)\\right|^2}", block: false)#text(" is the angular part of the kinetic energy density ")#tao-math("{\\left|\\nabla u(x)\\right|^2}", block: false)#text(". We obtain (a degenerate case of) the ")#emph[#text("Pohazaev-Morawetz identity")]

#align(center)[#tao-fit-display[#tao-math("8 \\pi \\left|u(0)\\right|^2 + 2 \\int_{{\\bf R}^3} \\frac{\\left|\\nabla_{\\text{ang}} u(x)\\right|^2}{\\left|x\\right|}\\ dx = 0", block: true)]]

#text("which implies in particular that ")#mi("{u}")#text(" vanishes at the origin. Translating ")#mi("{u}")#text(" around (noting that this does not affect either the Helmholtz equation or the Sommerfeld radiation condition) we see that ")#mi("{u}")#text(" vanishes completely. (Alternatively, one can replace ")#mi("{\\partial_r}")#text(" by the smoothed out multiplier ")#mi("{\\frac{x \\cdot \\nabla}{\\langle x \\rangle}}")#text(", in which case the Pohazaev-Morawetz identity acquires a term of the form ")#tao-math("{\\int_{{\\bf R}^3} \\frac{\\left|u(x)\\right|^2}{\\langle x \\rangle^5}\\ dx}", block: false)#text(" which is enough to directly ensure that ")#mi("{u}")#text(" vanishes.)")

#heading(level: 1)[#strong[#text(" — 2. Proof of the limiting absorption principle — ")]]

#text("We now sketch a proof of the limiting absorption principle, also based on the positive commutator method. For notational simplicity we shall only consider the case when ")#mi("{\\lambda}")#text(" is comparable to ")#mi("{1}")#text(", though the method we give here also yields the general case after some more bookkeeping.")

#text("Let ")#mi("{\\sigma > 0}")#text(" be a small exponent to be chosen later, and let ")#mi("{f}")#text(" be normalised to have ")#mi("{H^{0,1/2+\\sigma}({\\bf R}^3)}")#text(" norm equal to ")#mi("{1}")#text(". For sake of concreteness let us take the ")#mi("{+}")#text(" sign, so that we wish to bound ")#mi("{u := R( \\lambda + i \\epsilon) f}")#text(". This ")#mi("{u}")#text(" obeys the Helmholtz equation ")#metadata(none) <tao-ab14d3faa25e917efe6e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\Delta u + \\lambda u = f - i \\epsilon u.")]]

#text("For positive ")#mi("{\\epsilon}")#text(", we also see from the spectral theorem that ")#mi("{u}")#text(" lies in ")#mi("{L^2({\\bf R}^3)}")#text("; the bound here though depends on ")#mi("{\\epsilon}")#text(", so we can only use this ")#mi("{L^2({\\bf R}^3)}")#text(" regularity for qualitative purposes (and specifically, for ensuring that boundary terms at infinity from integration by parts vanish) rather than quantitatively.")

#text("Once again, we may apply the positive commutator method. If we again consider the expression ")#link(<tao-0551ffc77d5f3a5d68f2>)[#text("(13)")]#text(", then on the one hand this expression evaluates as before to")

#align(center)[#tao-fit-display[#tao-math("8 \\pi \\left|u(0)\\right|^2 + 2 \\int_{{\\bf R}^3} \\frac{\\left|\\nabla_{\\text{ang}} u(x)\\right|^2}{\\left|x\\right|}\\ dx.", block: true)]]

#text("On the other hand, integrating by parts using ")#link(<tao-ab14d3faa25e917efe6e>)[#text("(14)")]#text(", this expression also evaluates to")

#align(center)[#tao-fit-display[#mitex("2 \\text{Re} \\int_{{\\bf R}^3} (\\partial_r (-f + i \\epsilon u)) \\overline{u}\\ dx.")]]

#text("Integrating by parts and using Cauchy-Schwarz and the normalisation on ")#mi("{f}")#text(" (and also ")#link("http://en.wikipedia.org/wiki/Hardy's_inequality")[#text("Hardy’s inequality")]#text("), we thus see that")

#align(center)[#tao-fit-display[#tao-math("\\left|u(0)\\right|^2 + \\int_{{\\bf R}^3} \\frac{\\left|\\nabla_{\\text{ang}} u(x)\\right|^2}{\\left|x\\right|}\\ dx \\lesssim \\left\\| u\\right\\|_{H^{0,-3/2-\\sigma}} + \\left\\| \\partial_r u \\right\\|_{H^{0,-1/2-\\sigma}} + \\epsilon \\left\\|u\\right\\|_{L^2} \\left\\|\\nabla u\\right\\|_{L^2}.", block: true)]]

#text("A slight modification of this argument, replacing the operator ")#mi("{\\partial_r}")#text(" with the smoothed out variant")

#align(center)[#tao-fit-display[#mitex("(\\frac{r}{\\langle r \\rangle} - \\sigma \\frac{r}{\\langle r \\rangle^{1+2\\sigma}}) \\partial_r")]]

#text("yields (after a tedious computation)")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^3} \\frac{\\left|u(x)\\right|^2}{\\langle x \\rangle^{3+2\\sigma}} + \\frac{\\left|\\nabla u(x)\\right|^2}{\\langle x \\rangle^{1+2\\sigma}}\\ dx \\lesssim \\left\\| u\\right\\|_{H^{0,-3/2-\\sigma}} + \\left\\| \\partial_r u \\right\\|_{H^{0,-1/2-\\sigma}} + \\epsilon \\left\\|u\\right\\|_{L^2}^2.", block: true)]]

#text("The left-hand side is ")#tao-math("{\\left\\| u \\right\\|_{H^{0,-3/2-\\sigma}}^2 + \\left\\| \\nabla u \\right\\|_{H^{0,-1/2-\\sigma}}^2}", block: false)#text("; we can thus absorb the first two terms of the right-hand side onto the left-hand side, leading one with")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u \\right\\|_{H^{0,-3/2-\\sigma}}^2 + \\left\\| \\nabla u \\right\\|_{H^{0,-1/2-\\sigma}}^2 \\lesssim \\epsilon \\left\\| u \\right\\|_{L^2} \\left\\| \\nabla u \\right\\|_{L^2}.", block: true)]]

#text("On the other hand, by taking the inner product of ")#link(<tao-ab14d3faa25e917efe6e>)[#text("(14)")]#text(" against ")#mi("{iu}")#text(" and using the self-adjointness of ")#mi("{\\Delta+\\lambda}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("0 = \\int_{{\\bf R}^3} f \\overline{iu} - \\epsilon \\int_{{\\bf R}^3} \\left|u\\right|^2", block: true)]]

#text("and hence by Cauchy-Schwarz and the normalisation of ")#mi("{f}")

#align(center)[#tao-fit-display[#tao-math("\\epsilon \\left\\|u\\right\\|_{L^2}^2 \\leq \\left\\|u\\right\\|_{H^{0,-1/2-\\sigma}}.", block: true)]]

#text("Elliptic regularity estimates using ")#link(<tao-ab14d3faa25e917efe6e>)[#text("(14)")]#text(" (together with the hypothesis that ")#mi("{\\lambda}")#text(" is comparable to ")#mi("{1}")#text(") also show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u \\right\\|_{H^{0,-1/2-\\sigma}} \\lesssim \\left\\| \\nabla u \\right\\|_{H^{0,-1/2-\\sigma}} + 1", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\nabla u \\right\\|_{L^2} \\lesssim \\left\\| u \\right\\|_{L^2} + 1;", block: true)]]

#text("putting all these estimates together, we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u \\right\\|_{H^{0,-1/2-\\sigma}} \\lesssim 1", block: true)]]

#text("as required.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" In applications it is worth noting some additional estimates that can be obtained by variants of the above method (i.e. lots of integration by parts and Cauchy-Schwarz). From the Pohazaev-Morawetz identity, for instance, we can show some additional decay for the angular derivative:")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\left|\\nabla_{\\text{ang}} u\\right| \\right\\|_{H^{0,-1/2}} \\lesssim \\left\\|f\\right\\|_{H^{0,1/2+\\sigma}}.", block: true)]]

#text("With the positive sign ")#mi("{\\pm = +}")#text(", we also have the Sommerfeld type outward radiation condition")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\partial_r u - i \\sqrt{\\lambda} u \\right\\|_{H^{0,-1/2+\\sigma}} \\lesssim \\left\\|f\\right\\|_{H^{0,1/2+\\sigma}}", block: true)]]

#text("if ")#mi("{\\sigma > 0}")#text(" is small enough. For the negative sign ")#mi("{\\pm = -}")#text(", we have the inward radiating condition")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\partial_r u + i \\sqrt{\\lambda} u \\right\\|_{H^{0,-1/2+\\sigma}} \\lesssim \\left\\|f\\right\\|_{H^{0,1/2+\\sigma}}", block: true)]]
]

#heading(level: 1)[#strong[#text(" — 3. Spectral applications — ")]]

#text("The limiting absorption principle can be used to deduce various basic facts about the spectrum of the Laplacian. For instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Purely absolutely continuous spectrum)")]#text(" As an operator on ")#mi("{L^2({\\bf R}^3)}")#text(", ")#mi("{-\\Delta}")#text(" has only purely absolutely continuous spectrum on any compact subinterval ")#mi("{[a,b]}")#text(" of ")#mi("{(0,+\\infty)}")#text(".")
]

#emph[#text("Proof:")]#text(" (Sketch) By density, it suffices to show that for any test function ")#mi("{f \\in C^\\infty_0({\\bf R}^3)}")#text(", the spectral measure ")#mi("{\\mu_f}")#text(" of ")#mi("{-\\Delta}")#text(" relative to ")#mi("{f}")#text(" is purely absolutely continuous on ")#mi("{[a,b]}")#text(". In view of ")#link(<tao-079cdc52e64462dfac51>)[#text("(5)")]#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\mu_f = \\lim_{\\epsilon \\rightarrow 0^+} \\frac{1}{\\pi} \\text{Im} \\langle R(\\cdot+i\\epsilon) f, f \\rangle")]]

#text("in the sense of distributions, so from Fatou’s lemma it suffices to show that ")#mi("{\\text{Im} \\langle R(\\cdot+i\\epsilon) f, f \\rangle}")#text(" is uniformly bounded on ")#mi("{[a,b]}")#text(", uniformly in ")#mi("{\\epsilon}")#text(". But this follows from the limiting absorption principle and Cauchy-Schwarz. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" The Laplacian ")#mi("{-\\Delta}")#text(" also has no (point) spectrum at zero or negative energies, but this cannot be shown purely from the limiting absorption principle; if one allows a non-zero potential, then the limiting absorption principle holds (assuming suitable “short-range” hypotheses on the potential) but (as is well known in quantum mechanics) one can have eigenvalues (bound states) at zero or negative energies.")
]

#heading(level: 1)[#strong[#text(" — 4. Local smoothing — ")]]

#text("Another key application of the limiting absorption principle is to obtain ")#emph[#text("local smoothing estimates")]#text(" for both the Schrödinger and wave equations. Here is an instance of local smoothing for the Schrödinger equation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Homogeneous local smoothing for Schrödinger)")]#text(" If ")#mi("{f \\in L^2({\\bf R}^3)}")#text(", and ")#mi("{u: {\\bf R} \\times {\\bf R}^3 \\rightarrow {\\bf C}}")#text(" is the (tempered distributional) solution to the homogeneous Schrödinger equation ")#mi("{i u_t + \\Delta u = 0}")#text(", ")#mi("{u(0)=f}")#text(" (or equivalently, ")#mi("{u(t) = e^{it\\Delta} f}")#text("), then one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\left|\\nabla\\right|^{1/2} u \\right\\|_{L^2_t H^{0,-1/2-\\sigma}_x({\\bf R} \\times {\\bf R}^3)} \\lesssim \\left\\| f \\right\\|_{L^2({\\bf R}^3)}", block: true)]]

#text("for any fixed ")#mi("{\\sigma > 0}")#text(".")
]

#text("The ")#tao-math("{\\left|\\nabla\\right|^{1/2}}", block: false)#text(" factor in this estimate is the “smoothing” part of the local smoothing estimate, while the negative weight ")#mi("{-1/2-\\sigma}")#text(" is the “local” part. There is also a version of this local smoothing estimate for the inhomogeneous Schrödinger equation ")#mi("{i u_t + \\Delta u = F}")#text(" which is in fact essentially ")#emph[#text("equivalent")]#text(" to the limiting absorption principle (as observed ")#link("http://www.ams.org/mathscinet-getitem?mr=190801")[#text("by Kato")]#text("), which we will not give here.")

#emph[#text("Proof:")]#text(" We begin by using the ")#mi("{TT^*}")#text(" method. By duality, the claim is equivalent to")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\left|\\nabla\\right|^{1/2} \\int_{\\bf R} e^{-it\\Delta} F(t)\\ dt \\right\\|_{L^2({\\bf R}^3)} \\lesssim \\left\\| F \\right\\|_{L^2_t H^{0,1/2+\\sigma}_x({\\bf R} \\times {\\bf R}^3)}", block: true)]]

#text("which by squaring is equivalent to ")#metadata(none) <tao-a312976c6dbb8212b6e8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left\\| \\left|\\nabla\\right| \\int_{\\bf R} e^{i(t-t^{\\prime})\\Delta} F(t^{\\prime})\\ dt^{\\prime} \\right\\|_{L^2_t H^{0,-1/2-\\sigma}_x({\\bf R} \\times {\\bf R}^3)} \\lesssim \\left\\| F \\right\\|_{L^2_t H^{0,1/2+\\sigma}_x({\\bf R} \\times {\\bf R}^3)}.", block: true)]]

#text("From ")#link(<tao-079cdc52e64462dfac51>)[#text("(5)")]#text(" one has (formally, at least)")

#align(center)[#tao-fit-display[#mitex("e^{it\\Delta} = \\lim_{\\epsilon \\rightarrow 0^+} \\frac{1}{\\pi} \\int_{\\bf R} (\\text{Im} R(y+i\\epsilon)) e^{-ity}\\ dy.")]]

#text("Because ")#mi("{-\\Delta}")#text(" only has spectrum on the positive real axis, ")#mi("{\\text{Im} R(y+i0)}")#text(" vanishes on the negative real axis, and so (after carefully dealing with the contribution near the zero energy) one has")

#align(center)[#tao-fit-display[#mitex("e^{it\\Delta} = \\lim_{\\epsilon \\rightarrow 0^+} \\frac{1}{\\pi} \\int_0^\\infty (\\text{Im} R(y+i\\epsilon)) e^{-ity}\\ dy.")]]

#text("Taking the time-Fourier transform")

#align(center)[#tao-fit-display[#mitex("\\hat F(y) := \\int_{\\bf R} e^{ity} F(t)")]]

#text("we thus have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} e^{i(t-t^{\\prime})\\Delta} F(t^{\\prime})\\ dt^{\\prime} = \\lim_{\\epsilon \\rightarrow 0^+} \\frac{1}{\\pi} \\int_{\\bf R} e^{-ity} (\\text{Im} R(y+i\\epsilon)) \\hat F(y)\\ dy.")]]

#text("Applying Plancherel’s theorem and Fatou’s lemma (and commuting the ")#mi("{L^2_t}")#text(" and ")#mi("{H^{0,-1/2-\\sigma}_x}")#text(" norms), we can bound the LHS of ")#link(<tao-a312976c6dbb8212b6e8>)[#text("(15)")]#text(" by")

#align(center)[#tao-fit-display[#tao-math("\\lesssim \\left\\| \\left|\\nabla\\right| (\\text{Im} R(y+i\\epsilon)) \\hat F(y) \\right\\|_{L^2_y H^{0,-1/2-\\sigma}_x({\\bf R} \\times {\\bf R}^3)}", block: true)]]

#text("while the right-hand side is comparable to")

#align(center)[#tao-fit-display[#tao-math("\\lesssim \\left\\| \\hat F(y) \\right\\|_{L^2_y H^{0,1/2+\\sigma}_x({\\bf R} \\times {\\bf R}^3)}.", block: true)]]

#text("The claim now follows from the limiting absorption principle (and elliptic regularity). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" The above estimate was proven by taking a Fourier transform in time, and then applying the limiting absorption principle, which was in turn proven by using the positive commutator method. An equivalent way to proceed is to establish the local smoothing estimate directly by the analogue of the positive commutator method for Schrödinger flows, namely ")#emph[#text("Morawetz multiplier method")]#text(" in which one contracts the stress-energy tensor (or variants thereof) against well-chosen vector fields, and integrates by parts.")
]

#text("An analogous claim holds for solutions to the wave equation")

#align(center)[#tao-fit-display[#mitex("-\\partial_t^2 u + \\Delta u = 0")]]

#text("with initial data ")#mi("{u(0)= u_0}")#text(", ")#mi("{\\partial_t u(0) = u_1}")#text(", with the relevant estimate being that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\left|\\nabla_{t,x} u\\right| \\right\\|_{L^2_t H^{0,-1/2-\\sigma}({\\bf R} \\times {\\bf R}^3)} \\lesssim \\left\\| u_0 \\right\\|_{H^1({\\bf R}^3)} + \\left\\| u_1 \\right\\|_{L^2({\\bf R}^3)}.", block: true)]]

#text("As before, this estimate can also be proven directly using the Morawetz multiplier method.")

#heading(level: 1)[#strong[#text(" — 5. The RAGE theorem — ")]]

#text("Another consequence of limiting absorption, closely related both to absolutely continuous spectrum and to local smoothing, is the RAGE theorem (named after ")#link("http://www.ams.org/mathscinet-getitem?mr=246603")[#text("Ruelle")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=363267")[#text("Amrein, Georgescu")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=523013")[#text("Enss")]#text("), specialised to the free Schrödinger equation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (RAGE for Schrödinger)")]#text(" If ")#mi("{f \\in L^2({\\bf R}^3)}")#text(", and ")#mi("{K}")#text(" is a compact subset of ")#mi("{{\\bf R}^3}")#text(", then ")#tao-math("{\\left\\|e^{it\\Delta} f \\right\\|_{L^2(K)} \\rightarrow 0}", block: false)#text(" as ")#mi("{t \\rightarrow \\pm \\infty}")#text(".")
]

#emph[#text("Proof:")]#text(" By a density argument we may assume that ")#mi("{f}")#text(" lies in, say, ")#mi("{H^2({\\bf R}^3)}")#text(". Then ")#mi("{e^{it\\Delta} f}")#text(" is uniformly bounded in ")#mi("{H^2({\\bf R}^3)}")#text(", and is Lipschitz in time in the ")#mi("{L^2({\\bf R}^3)}")#text(" (and hence ")#mi("{L^2(K)}")#text(") norm. On the other hand, from local smoothing we know that ")#tao-math("{\\int_T^{T+1} \\left\\|e^{it\\Delta}\\right\\|_{L^2(K)}\\ dt}", block: false)#text(" goes to zero as ")#mi("{T \\rightarrow \\pm \\infty}")#text(". Putting the two facts together we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" One can also deduce this theorem from the fact that ")#mi("{-\\Delta}")#text(" has purely absolutely continuous spectrum, using the abstract form of the RAGE theorem due to the authors listed above (which can be thought of as a Hilbert space-valued version of the ")#link("http://en.wikipedia.org/wiki/Riemann%E2%80%93Lebesgue_lemma")[#text("Riemann-Lebesgue lemma")]#text(").")
]

#text("There is also a similar RAGE theorem for the wave equation (with ")#mi("{L^2}")#text(" replaced by the energy space ")#mi("{H^1 \\times L^2}")#text(") whose precise statement we omit here.")

#heading(level: 1)[#strong[#text(" — 6. The limiting amplitude principle — ")]]

#text("A close cousin to the limiting absorption principle, which governs the limiting behaviour of the resolvent as it approaches the spectrum, is the ")#emph[#text("limiting amplitude principle")]#text(", which governs the asymptotic behaviour of a Schrödinger or wave equation with oscillating forcing term. We give this principle for the Schrödinger equation (the case for the wave equation is analogous):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Limiting amplitude principle)")]#text(" Let ")#mi("{f \\in L^2({\\bf R}^3)}")#text(" be compactly supported, let ")#mi("{\\mu > 0}")#text(", and let ")#mi("{u}")#text(" be a solution to the forced Schrödinger equation ")#mi("{iu_t + \\Delta u = e^{-i\\mu t} f}")#text(" which lies in ")#mi("{L^2({\\bf R}^3)}")#text(" at time zero. Then for any compact set ")#mi("{K}")#text(", ")#mi("{e^{i\\mu T} u}")#text(" converges in ")#mi("{L^2(K)}")#text(" as ")#mi("{T \\rightarrow +\\infty}")#text(" to ")#mi("{v}")#text(", the solution to the Helmholtz equation ")#mi("{\\Delta v + \\mu v = f}")#text(" obeying the outgoing radiation condition ")#link(<tao-ced2eea28f29d92e3d4f>)[#text("(7)")]#text(".")
]

#emph[#text("Proof:")]#text(" (Sketch) By subtracting off the free solution ")#mi("{e^{it\\Delta} u(0)}")#text(" (which decays in ")#mi("{L^2(K)}")#text(" by the RAGE theorem), we may assume that ")#mi("{u(0)=0}")#text(". From the Duhamel formula we then have")

#align(center)[#tao-fit-display[#mitex("u(T) = -i \\int_0^T e^{i (T-t) \\Delta} e^{-i\\mu t} f\\ dt")]]

#text("and thus (after changing variables from ")#mi("{t}")#text(" to ")#mi("{T-t}")#text(")")

#align(center)[#tao-fit-display[#mitex("e^{i\\mu T} u(T) = - i \\int_0^T e^{it(\\Delta+\\mu)} f\\ dt.")]]

#text("We write the right-hand side as")

#align(center)[#tao-fit-display[#mitex("- i \\lim_{\\epsilon \\rightarrow 0^+} \\int_0^T e^{it(\\Delta+\\mu+i\\epsilon)} f\\ dt.")]]

#text("From the limiting absorption principle, the integral ")#mi("{-i \\int_0^\\infty e^{it(\\Delta+\\mu+i\\epsilon)} f\\ dt}")#text(" converges to ")#mi("{v}")#text(", and so it suffices to show that the expression")

#align(center)[#tao-fit-display[#mitex("\\lim_{\\epsilon \\rightarrow 0^+} \\int_T^\\infty e^{it(\\Delta+\\mu+i\\epsilon)} f\\ dt")]]

#text("converges to zero as ")#mi("{T \\rightarrow +\\infty}")#text(" in ")#mi("{L^2(K)}")#text(" norm. Evaluating the integral, we are left with showing that")

#align(center)[#tao-fit-display[#mitex("\\lim_{\\epsilon \\rightarrow 0^+} e^{iT\\Delta} R(\\mu+i\\epsilon) f")]]

#text("converges to zero as ")#mi("{T \\rightarrow +\\infty}")#text(" in ")#mi("{L^2(K)}")#text(" norm.")

#text("By using contour integration, one can write")

#align(center)[#tao-fit-display[#mitex("\\lim_{\\epsilon \\rightarrow 0^+} e^{iT\\Delta} R(\\mu+i\\epsilon) f = \\frac{1}{2\\pi i} \\lim_{\\epsilon \\rightarrow 0^+} \\lim_{\\epsilon^{\\prime} \\rightarrow 0^+} \\int_{\\bf R} \\frac{e^{-iTx}}{x-\\mu-i\\epsilon} R(x+i\\epsilon^{\\prime}) f\\ dx.")]]

#text("On the other hand, from the explicit solution for the resolvent (and the compact support of ")#mi("{f}")#text("), ")#mi("{R(x+i\\epsilon^{\\prime}) f}")#text(" can be shown to vary in a Hölder continuous fashion on ")#mi("{x}")#text(" in the ")#mi("{L^2(K)}")#text(" norm (uniformly in ")#mi("{x, \\epsilon^{\\prime}}")#text("), and to decay at a polynomial rate as ")#mi("{x \\rightarrow \\pm \\infty}")#text(". Since")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\frac{e^{-iTx}}{x-\\mu-i\\epsilon}\\ dx = 0")]]

#text("for ")#mi("{T>0}")#text(", the required decay in ")#mi("{L^2(K)}")#text(" then follows from a routine calculation. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" More abstractly, it was observed ")#link("http://www.ams.org/mathscinet-getitem?mr=601072")[#text("by Eidus")]#text(" that the limiting amplitude principle for a general Schrödinger or wave equation can be deduced from the limiting absorption principle and a Hölder continuity bound on the resolvent.")
]

#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5406d5128b91c329ef4ae21137f201297f434f7a14fbb6c39410cabe2d8fb518-75b8e388d538ab02dd373a447f44cdadee217f0dd2f86fdc74d412aa9dea4e0b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roland Bauerschmidt")]], [#link("https://terrytao.wordpress.com/2011/04/21/the-limiting-absorption-principle/#comment-51945")[#strong[#text("Roland Bauerschmidt")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2011")])]

#text("In the definition of the charge current, both i and j should be the same, I assume.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a718fe0ae1ce222ea33275174bc93b6011081a9ba6d690bd7cf9c39f0317e62a-6170224188d25c8da1133b3e3d9c851d6c93c48eb9e4532aaaf759d38dceb8b4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mfrasca")]], [#link("https://terrytao.wordpress.com/2011/04/21/the-limiting-absorption-principle/#comment-51965")[#strong[#text("mfrasca")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2011")])]

#text("Hi Terry,")

#text("After eq.(13), a few lines below, there is")

#text("(using (11), \\eqref}{ins-2}")

#text("a minor error?")

#text("Best,")

#text("Marco")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c76e16953b7ae11f62bb6b518796c5d930e57a539f6b1f226bdd0627032d6f9-42c2ca64a50dd8701161bb37eded5964a7fca4a88383a1759c24acd8220fb18d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew")]], [#link("https://terrytao.wordpress.com/2011/04/21/the-limiting-absorption-principle/#comment-51971")[#strong[#text("Andrew")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2011")])]

#text("“(a fact which can be seen from the maximum principle, or from the Brownian motion interpretation of the keat kernels”")

#text(".. heat not keat, right?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a718fe0ae1ce222ea33275174bc93b6011081a9ba6d690bd7cf9c39f0317e62a-6170224188d25c8da1133b3e3d9c851d6c93c48eb9e4532aaaf759d38dceb8b4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mfrasca")]], [#link("https://terrytao.wordpress.com/2011/04/21/the-limiting-absorption-principle/#comment-51979")[#strong[#text("mfrasca")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2011")])]

#text("Hi Terry,")

#text("There is another small problem to fix, I think, to this beautiful post. Always after eq.(13) I see a “formula does not parse” error.")

#text("Best,")

#text("Marco")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mads")]], [#link("https://terrytao.wordpress.com/2011/04/21/the-limiting-absorption-principle/#comment-51980")[#strong[#text("Mads")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2011")])]

#text("Me too; three equations after (13), that is (for me).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of none")]], [#link("https://terrytao.wordpress.com/2011/04/21/the-limiting-absorption-principle/#comment-51987")[#strong[#text("none")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2011")])]

#text("Wow, there is some really annoying advertising (“On the PopPressed Radar “) just above the comment form. I’ve never seen those ads on this blog before. Yuck.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21905d928b2afaef59a49add84de796ac62b41f324ae5fb298c7a9e1a242c94a-c228ce720ada52a68a72c978d4b0d9609b43e065b69a9c393f0a74e92f889dd4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max")]], [#link("https://terrytao.wordpress.com/2011/04/21/the-limiting-absorption-principle/#comment-52259")[#strong[#text("Max")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2011")])]

#text("Dear Prof. Tao,")

#text("I have very little background in physics and also in PDEs, and I have a general question concerning the Laplacian: Why is it that the Laplacian occurs in the spatial part of so many PDEs? Is it due to its invariance under orthonormal basis transformations? And what is the best way to think of the Laplacian in this context (since one can think of it as the sum of the eigenvalues of the Hessian, or the divergence of the gradient field, or in a probabilistic way as the generator of Brownian motion etc.)?")#linebreak()#text(" If your time permits it I would be grateful for answer,")

#text("best regards,")

#text("Max")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/04/21/the-limiting-absorption-principle/#comment-52270")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2011")])]

#link("http://mathoverflow.net/questions/54986/why-is-the-laplacian-ubiquitous")[#text("http://mathoverflow.net/questions/54986/why-is-the-laplacian-ubiquitous")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Effective limiting absorption principles, and applications « What’s new")]], [#link("https://terrytao.wordpress.com/2011/04/21/the-limiting-absorption-principle/#comment-52291")[#strong[#text("Effective limiting absorption principles, and applications « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2011")])]

#text("[…] Mathematical Physics. In this paper we derive limiting absorption principles (of type discussed in this recent post) for a general class of Schrödinger operators on a wide class of manifolds, namely the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arch Stanton")]], [#link("https://terrytao.wordpress.com/2011/04/21/the-limiting-absorption-principle/#comment-52998")[#strong[#text("Arch Stanton")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2011")])]

#text("Dear Prof. Tao,")

#text("A small typo. I believe that, in the three equations preceding equation (6), the factors of $4 \\pi |x-y|$ should be in the denominator.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e6c2afec7d135348bba49910d361ecd5a16892d605d3ab7177f2cb010633f515-6467650de12c34bd0f3de0b32c3a9428bb442c0728fecd7ddd2ede458ef9d1a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brett")]], [#link("https://terrytao.wordpress.com/2011/04/21/the-limiting-absorption-principle/#comment-97800")[#strong[#text("Brett")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2011")])]

#text("Prof. Tao,")#linebreak()#text(" What books would you recommend for learning this material and for an advanced reference?")#linebreak()#text(" Thanks,")#linebreak()#text(" B.P.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/04/21/the-limiting-absorption-principle/#comment-451289")[#strong[#text("Carleman estimates | 逝去日子")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2015")]

#text("[…] 3. web: ")#link("https://terrytao.wordpress.com/2011/04/21/the-limiting-absorption-principle/")[#text("https://terrytao.wordpress.com/2011/04/21/the-limiting-absorption-principle/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fee5bb6e63dd92f5068f1c46ddd7e0070b82b7026e3e6abff0ea416e9a9b2d16-0cea98eb97bfd65414a433fe4279f72d9c1cdf18a6da51f4846003885466637a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mourre’s theory and local decay estimates, with some applications to linear damping in fluids | Snapshots in Mathematics !")]], [#link("https://terrytao.wordpress.com/2011/04/21/the-limiting-absorption-principle/#comment-504746")[#strong[#text("Mourre’s theory and local decay estimates, with some applications to linear damping in fluids | Snapshots in Mathematics !")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2018")])]

#text("[…] local smoothing estimate and the scattering RAGE’s theorem; for instance, see this blog post of T. […]")
]
