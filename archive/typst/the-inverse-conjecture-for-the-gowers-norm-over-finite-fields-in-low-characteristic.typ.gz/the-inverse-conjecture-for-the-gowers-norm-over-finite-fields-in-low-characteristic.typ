// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/01/11/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-in-low-characteristic/
// Converted to Typst by tao2typ: "2026-10-14T09:05:57.526818+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The inverse conjecture for the Gowers norm over finite fields in low characteristic", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The inverse conjecture for the Gowers norm over finite fields in low characteristic")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 January 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/01/11/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-in-low-characteristic/")[#text("https://terrytao.wordpress.com/2011/01/11/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-in-low-characteristic/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.technion.ac.il/~tamarzr/")[#text("Tamar Ziegler")]#text(" and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/1101.1469")[#text("The inverse conjecture for the Gowers norm over finite fields in low characteristic")]#text("“, submitted to ")#link("http://www.combinatorics.net/aoc/")[#text("Annals of Combinatorics")]#text(". This paper completes another case of the inverse conjecture for the Gowers norm, this time for vector spaces ")#mi("{{\\bf F}^n}")#text(" over a fixed finite field ")#mi("{{\\bf F} = {\\bf F}_p}")#text(" of prime order; ")#link("https://terrytao.wordpress.com/2009/01/19/an-inverse-theorem-for-the-uniformity-seminorms-associated-with-the-action-of-finfty_p/")[#text("with Vitaly Bergelson")]#text(", we had previously established this claim when the characteristic of the field was large, so the main new result here is the extension to the low characteristic case. (The case of a cyclic group ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(" or interval ")#mi("{[N]}")#text(" was established by ")#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/")[#text("Ben Green and ourselves")]#text(" in another recent paper. For an arbitrary abelian (or nilpotent) group, a general but less explicit description of the obstructions to Gowers uniformity was recently obtained by ")#link("http://arxiv.org/abs/1010.6211")[#text("Szegedy")]#text("; the latter result recovers the high-characteristic case of our result (as was done in a ")#link("http://arxiv.org/abs/1011.1057")[#text("subsequent paper of Szegedy")]#text("), as well as our results with Green, but it is not immediately evident whether Szegedy’s description of the obstructions matches up with the one predicted by the inverse conjecture in low characteristic.)")

#text("The statement of the main theorem is as follows. Given a finite-dimensional vector space ")#mi("{V = {\\bf F}^n}")#text(" and a function ")#mi("{f: V \\rightarrow {\\bf C}}")#text(", and an integer ")#mi("{s \\geq 0}")#text(", one can define the Gowers uniformity norm ")#tao-math("{\\left\\|f\\right\\|_{U^{s+1}(V)}}", block: false)#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^{s+1}(V)} := \\left( \\mathop{\\bf E}_{x,h_1,\\ldots,h_{s+1} \\in V} \\Delta_{h_1} \\ldots \\Delta_{h_{s+1}} f(x) \\right)^{1/2^{s+1}}", block: true)]]

#text("where ")#mi("{\\Delta_h f(x) := f(x+h) \\overline{f(x)}}")#text(". If ")#mi("{f}")#text(" is bounded in magnitude by ")#mi("{1}")#text(", it is easy to see that ")#tao-math("{\\left\\|f\\right\\|_{U^{s+1}(V)}}", block: false)#text(" is bounded by ")#mi("{1}")#text(" also, with equality if and only if ")#mi("{f(x) = e(P)}")#text(" for some ")#emph[#text("non-classical polynomial")]#text(" ")#mi("{P: V \\rightarrow {\\bf R}/{\\bf Z}}")#text(" of degree at most ")#mi("{s}")#text(", where ")#mi("{e(x) := e^{2\\pi ix}}")#text(", and a non-classical polynomial of degree at most ")#mi("{s}")#text(" is a function whose ")#mi("{s+1^{th}}")#text(" “derivatives” vanish in the sense that")

#align(center)[#tao-fit-display[#mitex("\\partial_{h_1} \\ldots \\partial_{h_{s+1}} P(x) = 0")]]

#text("for all ")#mi("{x,h_1,\\ldots,h_{s+1} \\in V}")#text(", where ")#mi("{\\partial_h P(x) := P(x+h) - P(x)}")#text(". Our result generalises this to the case when the uniformity norm is not equal to ")#mi("{1}")#text(", but is still bounded away from zero:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Inverse conjecture)")]#text(" ")#metadata(none) <tao-25e6c9b6be0fb773433c>#text(" Let ")#mi("{f: V \\rightarrow {\\bf C}}")#text(" be bounded by ")#mi("{1}")#text(" with ")#tao-math("{\\left\\|f\\right\\|_{U^{s+1}(V)} \\geq \\delta > 0}", block: false)#text(" for some ")#mi("{s \\geq 0}")#text(". Then there exists a non-classical polynomial ")#mi("{P: V \\rightarrow {\\bf R}/{\\bf Z}}")#text(" of degree at most ")#mi("{s}")#text(" such that ")#tao-math("{\\left|\\langle f, e(P) \\rangle_{L^2(V)}\\right| := \\left|{\\bf E}_{x \\in V} f(x) e(-P(x))\\right| \\geq c(s,p, \\delta) > 0}", block: false)#text(", where ")#mi("{c(s,p, \\delta)}")#text(" is a positive quantity depending only on the indicated parameters.")
]

#text("This theorem is trivial for ")#mi("{s=0}")#text(", and follows easily from Fourier analysis for ")#mi("{s=1}")#text(". The case ")#mi("{s=2}")#text(" was done in odd characteristic by ")#link("http://www.ams.org/mathscinet-getitem?mr=2391635")[#text("Ben Green and myself")]#text(", and in even characteristic by ")#link("http://portal.acm.org/citation.cfm?id=1250864")[#text("Samorodnitsky")]#text(". In ")#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/")[#text("two papers")]#text(", ")#link("https://terrytao.wordpress.com/2009/01/19/an-inverse-theorem-for-the-uniformity-seminorms-associated-with-the-action-of-finfty_p/")[#text("one with Vitaly Bergelson")]#text(", we established this theorem in the “high characteristic” case when the characteristic ")#mi("{p}")#text(" of ")#mi("{{\\bf F}}")#text(" was greater than ")#mi("{s}")#text(" (in which case there is essentially no distinction between non-classical polynomials and their classical counterparts, as ")#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/")[#text("discussed previously on this blog")]#text("). The need to deal with genuinely non-classical polynomials is the main new difficulty in this paper that was not dealt with in previous literature.")

#text("In our previous paper with Bergelson, a “weak” version of the above theorem was proven, in which the polynomial ")#mi("{P}")#text(" in the conclusion had bounded degree ")#mi("{O_{s,p}(1)}")#text(", rather than being of degree at most ")#mi("{s}")#text(". In the current paper, we use this weak inverse theorem to reduce the inverse conjecture to a statement purely about polynomials:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Inverse conjecture for polynomials)")]#text(" ")#metadata(none) <tao-68992173a4b54c5f7908>#text(" Let ")#mi("{s \\geq 0}")#text(", and let ")#mi("{P: V \\rightarrow {\\bf C}}")#text(" be a non-classical polynomial of degree at most ")#mi("{s+1}")#text(" such that ")#tao-math("{\\left\\|e(P)\\right\\|_{U^{s+1}(V)} \\geq \\delta > 0}", block: false)#text(". Then ")#mi("{P}")#text(" has ")#emph[#text("bounded rank")]#text(" in the sense that ")#mi("{P}")#text(" is a function of ")#mi("{O_{s,p,\\delta}(1)}")#text(" polynomials of degree at most ")#mi("{s}")#text(".")
]

#text("This type of inverse theorem was first introduced ")#link("http://www.ams.org/mathscinet-getitem?mr=2644354")[#text("by Bogdanov and Viola")]#text(". The deduction of Theorem ")#link(<tao-25e6c9b6be0fb773433c>)[#text("1")]#text(" from Theorem ")#link(<tao-68992173a4b54c5f7908>)[#text("2")]#text(" and the weak inverse Gowers conjecture is fairly standard, so the main difficulty is to show Theorem ")#link(<tao-68992173a4b54c5f7908>)[#text("2")]#text(".")

#text("The quantity ")#tao-math("{-\\log_{\\left|{\\bf F}\\right|} \\left\\|e(P)\\right\\|_{U^{s+1}(V)}^{1/2^{s+1}}}", block: false)#text(" of a polynomial ")#mi("{P}")#text(" of degree at most ")#mi("{s+1}")#text(" was denoted the ")#emph[#text("analytic rank")]#text(" of ")#mi("{P}")#text(" by ")#link("http://arxiv.org/abs/1002.2208")[#text("Gowers and Wolf")]#text(". They observed that the analytic rank of ")#mi("{P}")#text(" was closely related to the rank of ")#mi("{P}")#text(", defined as the least number of degree ")#mi("{s}")#text(" polynomials needed to express ")#mi("{P}")#text(". For instance, in the quadratic case ")#mi("{s=1}")#text(" the two ranks are identical (in odd characteristic, at least). For general ")#mi("{s}")#text(", it was easy to see that bounded rank implied bounded analytic rank; Theorem ")#link(<tao-68992173a4b54c5f7908>)[#text("2")]#text(" is the converse statement.")

#text("We tried a number of ways to show that bounded analytic rank implied bounded rank, in particular spending a lot of time on ergodic-theoretic approaches, but eventually we settled on a “brute force” approach that relies on classifying those polynomials of bounded analytic rank as precisely as possible. The argument splits up into establishing three separate facts:")

#enum(start: 1, 
[#text("(Classical case) If a ")#emph[#text("classical")]#text(" polynomial has bounded analytic rank, then it has bounded rank.")],
[#text("(Multiplication by ")#mi("{p}")#text(") If a non-classical polynomial ")#mi("{P}")#text(" (of degree at most ")#mi("{s+1}")#text(") has bounded analytic rank, then ")#mi("{pP}")#text(" (which can be shown to have degree at most ")#mi("{\\max(s-p,0)}")#text(") also has bounded analytic rank.")],
[#text("(Division by ")#mi("{p}")#text(") If ")#mi("{Q}")#text(" is a non-clsasical polynomial of degree ")#mi("{\\max(s-p,0)}")#text(" of bounded rank, then there is a non-classical polynomial ")#mi("{P}")#text(" of degree at most ")#mi("{s+1}")#text(" of bounded rank such that ")#mi("{pQ=P}")#text(".")]
)

#text("The multiplication by ")#mi("{p}")#text(" and division by ")#mi("{p}")#text(" facts allow one to easily extend the classical case of the theorem to the non-classical case of the theorem, basically because classical polynomials are the kernel of the multiplication-by-")#mi("{p}")#text(" homomorphism. Indeed, if ")#mi("{P}")#text(" is a non-classical polynomial of bounded analytic rank of the right degree, then the multiplication by ")#mi("{p}")#text(" claim tells us that ")#mi("{pP}")#text(" also has bounded analytic rank, which by an induction hypothesis implies that ")#mi("{pP}")#text(" has bounded rank. Applying the division by ")#mi("{p}")#text(" claim, we find a bounded rank polynomial ")#mi("{P^{\\prime}}")#text(" such that ")#mi("{pP = pP^{\\prime}}")#text(", thus ")#mi("{P}")#text(" differs from ")#mi("{P^{\\prime}}")#text(" by a classical polynomial, which necessarily has bounded analytic rank, hence bounded rank by the classical claim, and the claim follows.")

#text("Of the three claims, the multiplication-by-")#mi("{p}")#text(" claim is the easiest to prove using known results; after a bit of Fourier analysis, it turns out to follow more or less immediately from the multidimensional Szemerédi theorem over ")#link("http://www.ams.org/mathscinet-getitem?mr=2145566")[#text("finite fields of Bergelson, Leibman, and McCutcheon")]#text(" (one can also use the density Hales-Jewett theorem here if one desires).")

#text("The next easiest claim is the classical case. Here, the idea is to analyse a degree ")#mi("{s+1}")#text(" classical polynomial ")#mi("{P: V \\rightarrow {\\bf F}}")#text(" via its derivative ")#mi("{d^{s+1} P: V^{s+1} \\rightarrow {\\bf F}}")#text(", defined by the formula")

#align(center)[#tao-fit-display[#mitex("d^{s+1} P( h_1,\\ldots,h_{s+1}) := \\partial_{h_1} \\ldots \\partial_{h_{s+1}} P(x)")]]

#text("for any ")#mi("{x,h_1,\\ldots,h_{s+1} \\in V}")#text(" (the RHS is independent of ")#mi("{x}")#text(" as ")#mi("{P}")#text(" has degree ")#mi("{s+1}")#text("). This is a multilinear form, and if ")#mi("{P}")#text(" has bounded analytic rank, this form is biased (in the sense that the mean of ")#mi("{e(d^{s+1} P)}")#text(" is large). Applying a general equidistribution theorem of ")#link("http://arxiv.org/abs/0806.4535")[#text("Kaufman and Lovett")]#text(" (based on ")#link("https://terrytao.wordpress.com/2007/11/23/the-distribution-of-polynomials-over-finite-fields-with-applications-to-the-gowers-norms/")[#text("this earlier paper of Green and myself")]#text(") this implies that ")#mi("{d^{s+1} P}")#text(" is a function of a bounded number of multilinear forms of lower degree. Using some “regularity lemma” theory to clean up these forms so that they have good equidistribution properties, it is possible to understand exactly how the original multilinear form ")#mi("{d^{s+1} P}")#text(" depends on these lower degree forms; indeed, the description one eventually obtains is so explicit that one can write down by inspection another bounded rank polynomial ")#mi("{Q}")#text(" such that ")#mi("{d^{s+1} P}")#text(" is equal to ")#mi("{d^{s+1} Q}")#text(". Thus ")#mi("{P}")#text(" differs from the bounded rank polynomial ")#mi("{Q}")#text(" by a lower degree error, which is automatically of bounded rank also, and the claim follows.")

#text("The trickiest thing to establish is the division by ")#mi("{p}")#text(" claim. The polynomial ")#mi("{Q}")#text(" is some function ")#mi("{F(R_1,\\ldots,R_m)}")#text(" of lower degree polynomials ")#mi("{R_1,\\ldots,R_m}")#text(". Ideally, one would like to find a function ")#mi("{F^{\\prime}(R_1,\\ldots,R_m)}")#text(" of the same polynomials with ")#mi("{pF^{\\prime} = F}")#text(", such that ")#mi("{F^{\\prime}(R_1,\\ldots,R_m)}")#text(" has the correct degree; however, we have counterexamples that show that this is not always possible. (These counterexamples are the main obstruction to making the ergodic theory approach work: in ergodic theory, one is only allowed to work with “measurable” functions, which are roughly analogous in this context to functions of the indicated polynomials ")#mi("{Q, R_1,\\ldots,R_m}")#text(" and their shifts.) To get around this we have to first apply a regularity lemma to place ")#mi("{R_1,\\ldots,R_m}")#text(" in a suitably equidistributed form (although the fact that ")#mi("{R_1,\\ldots,R_m}")#text(" may be non-classical leads to a rather messy and technical description of this equidistribution), and then we have to ")#emph[#text("extend")]#text(" each ")#mi("{R_j}")#text(" to a higher degree polynomial ")#mi("{R^{\\prime}_j}")#text(" with ")#mi("{pR^{\\prime}_j = R_j}")#text(". There is a crucial “exact roots” property of polynomials that allows one to do this, with ")#mi("{R^{\\prime}_j}")#text(" having degree exactly ")#mi("{p-1}")#text(" higher than ")#mi("{R_j}")#text(". It turns out that it is possible to find a function ")#mi("{P = F^{\\prime}(R^{\\prime}_1,\\ldots,R^{\\prime}_m)}")#text(" of these extended polynomials that have the right degree and which solves the required equation ")#mi("{pP=Q}")#text("; this is established by classifying completely all functions of the equidistributed polynomials ")#mi("{R_1,\\ldots,R_m}")#text(" or ")#mi("{R^{\\prime}_1,\\ldots,R^{\\prime}_m}")#text(" that are of a given degree.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1335f741ec9d68f6f357d83d88e084d9cd5948a4dfa1cd20a7fc524dfb9e6832-84ab5f924de87d267e4d02822b02bdb8c23a8e8a711cd664631d0aac06850eae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Balazs Szegedy")]], [#link("https://terrytao.wordpress.com/2011/01/11/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-in-low-characteristic/#comment-49581")[#strong[#text("Balazs Szegedy")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2011")])]

#text("Congratulations to this nice result!")

#text("In my approach (that you refer to) certain algebraic structures called “nilspaces” play the crucial role. A few days ago I obtained a structure theorem for general nilspaces which I hope will remove some of the “less explicit” nature that you mention.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Multiple recurrence and convergence results associated to $F_{p}^{omega}$-actions | What's new")]], [#link("https://terrytao.wordpress.com/2011/01/11/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-in-low-characteristic/#comment-230676")[#strong[#text("Multiple recurrence and convergence results associated to $F_{p}^{omega}$-actions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2013")])]

#text("[…] of the structural theory of Host and Kra was worked out by Vitaly, Tamar, and myself in these previous papers (treating the high characteristic and low characteristic cases respectively). In the finite field […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A Host–Kra ${bf F}^omega_2$-system of order 5 that is not Abramov of order 5, and non-measurability of the inverse theorem for the $U^6({bf F}^n_2)$ norm; The structure of totally disconnected Host–Kra–Ziegler factors, and the inverse th")]], [#link("https://terrytao.wordpress.com/2011/01/11/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-in-low-characteristic/#comment-675859")[#strong[#text("A Host–Kra ${bf F}^omega_2$-system of order 5 that is not Abramov of order 5, and non-measurability of the inverse theorem for the $U^6({bf F}^n_2)$ norm; The structure of totally disconnected Host–Kra–Ziegler factors, and the inverse th")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2023")])]

#text("[…] is now known for all (see this paper of Ziegler and myself for the first proof of the general case, and this paper of Milicevic for the most recent […]")
]
