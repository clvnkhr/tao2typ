// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/
// Converted to Typst by tao2typ: "2026-10-14T15:16:17.764809+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Open question: best bounds for cap sets", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Open question: best bounds for cap sets")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 February 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/")[#text("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Earlier this month, in the ")#link("http://www.math.ucla.edu/%7Etao/whatsnew2007.html")[#text("previous incarnation of this page")]#text(", I ")#link("http://www.math.ucla.edu/%7Etao/preprints/Expository/squarecube.dvi")[#text("posed a question")]#text(" which I thought was unsolved, and obtained the answer (in fact, it was ")#link("http://www.ams.org/mathscinet-getitem?mr=682456")[#text("solved 25 years ago")]#text(") within a week. Now that this new version of the page has better feedback capability, I am now tempted to try again, since I have a large number of such questions which I would like to publicise. (Actually, I even have a secret web page full of these somewhere near my ")#link("http://www.math.ucla.edu/%7Etao")[#text("home page")]#text(", though it will take a non-trivial amount of effort to find it!)")

#text("Perhaps my favourite open question is the problem on the maximal size of a ")#emph[#text("cap set")]#text(" – a subset of ")#mi("{\\Bbb F}^n_3")#text(" (")#mi("{\\Bbb F}_3")#text(" being the finite field of three elements) which contains no lines, or equivalently no non-trivial arithmetic progressions of length three. As an upper bound, one can easily modify the proof of ")#link("http://www.ams.org/mathscinet-getitem?mr=51853")[#text("Roth’s theorem")]#text(" to show that cap sets must have size ")#mi("O(3^n/n)")#text(" (see e.g. this ")#link("http://www.ams.org/mathscinet-getitem?mr=1335785")[#text("paper of Meshulam")]#text("). This of course is better than the trivial bound of ")#mi("3^n")#text(" once n is large. In the converse direction, the trivial example ")#mi("\\{0,1\\}^n")#text(" shows that cap sets can be as large as ")#mi("2^n")#text("; the current world record is ")#mi("(2.2174\\ldots)^n")#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2031694")[#text("held by Edel")]#text(". The gap between these two bounds is rather enormous; I would be very interested in either an improvement of the upper bound to ")#mi("o(3^n/n)")#text(", or an improvement of the lower bound to ")#mi("(3-o(1))^n")#text(". (I believe both improvements are true, though a good friend of mine disagrees about the improvement to the lower bound.)")

#metadata(none) <tao-eff9abc55d9b27003d0c>#linebreak()#text(" One reason why I find this question important is that it serves as an excellent model for the analogous question of finding large sets without progressions of length three in the interval ")#mi("\\{1,\\ldots,N\\}")#text(". Here, the best upper bound of ")#mi("O(N \\sqrt{\\frac{\\log \\log N}{\\log N}})")#text(" is ")#link("http://www.ams.org/mathscinet-getitem?mr=1726234")[#text("due to Bourgain")]#text(" (he also has a recent, not yet published, improvement to ")#mi("O(N \\frac{(\\log \\log N)^2}{\\log^{2/3} N})")#text(", while the best lower bound of ")#mi("N e^{-C\\sqrt{\\log N}}")#text(" is an ancient ")#link("http://www.ams.org/mathscinet-getitem?mr=18694")[#text("result of Behrend")]#text(". Using the ")#link("http://www.ams.org/mathscinet-getitem?mr=2187732")[#text("finite field heuristic")]#text(" that ")#mi("{\\Bbb F}^n_3")#text(" “behaves like” ")#mi("\\{1,\\ldots,3^n\\}")#text(", we see that the Bourgain bound should be improvable to ")#mi("O(\\frac{N}{\\log N})")#text(", whereas the Edel bound should be improvable to something like ")#mi("3^n e^{-C\\sqrt{n}}")#text(". However, neither argument extends easily to the other setting. Note that a (still open) ")#link("http://en.wikipedia.org/wiki/Szemeredi%27s_theorem")[#text("conjecture of Erdős-Turán")]#text(" is essentially equivalent (for progressions of length three, up to log log factors) to the problem of improving the Bourgain bound to ")#mi("o(\\frac{N}{\\log N})")#text(".")

#text("The Roth bound of ")#mi("O(3^n/n)")#text(" appears to be the natural limit of the purely Fourier-analytic approach of Roth, and so any breakthrough would be extremely interesting, as it almost certainly would need a radically new idea. The lower bound might be improvable by some sort of algebraic geometry construction, though it is not clear at all how to achieve this.")

#text("(")#text("Update, ")#text("Feb 25: After some feedback and advice, and moving the entire blog to another site, I have finally gotten the math formulae to work out nicely. Thanks for all the help!)")

#text("(")#emph[#text("Update")]#text(", Feb 27: As pointed out in the comments, one can interpret this problem in terms of the wonderful game ")#link("http://en.wikipedia.org/wiki/Set_%28game%29")[#text("Set")]#text(", in which case the problem is to find the largest number of cards one can put on the table for which nobody has a valid move. As far as I know, the best bounds on the cap set problem in small dimensions are the ones cited in the ")#link("http://www.ams.org/mathscinet-getitem?mr=2031694")[#text("Edel paper mentioned above")]#text(".)")

#text("(")#emph[#text("Update")]#text(", Mar 5: After discussions with Jordan Ellenberg, we realised that there is a variant formulation of the problem which may be a little bit more tractable. Given any ")#mi("0 < \\delta < 1")#text(", the fewest number of lines in a set of ")#mi("{\\Bbb F}_3^n")#text(" of density at least ")#mi("\\delta")#text(" is known to be ")#mi("(c(\\delta)+o(1)) 3^{2n}")#text(" for some ")#mi("0 < c(\\delta) < 1")#text("; this is essentially a ")#link("http://www.math.gatech.edu/~ecroot/bens_question_complex2.pdf")[#text("result of Croot")]#text(". The reformulated question is then to get as strong a bound on ")#mi("c(\\delta)")#text(") as one can. For instance, the counterexample ")#mi("\\{0,1\\}^m \\times {\\Bbb F}_3^n")#text(" shows that ")#mi("c(\\delta) \\ll \\delta^{\\log_{3/2} 9/2}")#text(", while the Roth-Meshulam argument gives ")#mi("c(\\delta) \\gg e^{-C/\\delta}")#text(".)")

#heading(level: 1)[#text("Comments (57)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-2/#comment-685511")[#strong[#text("FunSearch: Dokonywanie nowych odkryć w naukach matematycznych przy użyciu dużych modeli językowych - nanostrefa.pl")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2024")]

#text("[…] matematyków z wielu dziedzin badawczych. Znany matematyk Terence Tao opisał to kiedyś jako swoje ulubione otwarte pytanieWspółpracowaliśmy z Jordanem Ellenbergiem, profesorem matematyki na Uniwersytecie […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-2/#comment-685697")[#strong[#text("FunSearch: Making new discoveries in mathematical sciences using Large Language Models – ONE AI")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2024")]

#text("[…] of analysis areas for many years. Famend mathematician Terence Tao as soon as described it as his favorite open question. We collaborated with Jordan Ellenberg, a professor of arithmetic on the College of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-2/#comment-685718")[#strong[#text("FunSearch: Making new discoveries in mathematical sciences using Large Language Models - TechAiReports")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2024")]

#text("[…] in multiple research areas for decades. Renowned mathematician Terence Tao once described it as his favorite open question. We collaborated with Jordan Ellenberg, a professor of mathematics at the University of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-2/#comment-686008")[#strong[#text("FunSearch: Making new discoveries in mathematical sciences using Large Language Models - AI Quantum Intelligence")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2024")]

#text("[…] in multiple research areas for decades. Renowned mathematician Terence Tao once described it as his favorite open question. We collaborated with Jordan Ellenberg, a professor of mathematics at the University of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-2/#comment-686025")[#strong[#text("FunSearch: Making new discoveries in mathematical sciences using Large Language Models - Ai News")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2024")]

#text("[…] in multiple research areas for decades. Renowned mathematician Terence Tao once described it as his favorite open question. We collaborated with Jordan Ellenberg, a professor of mathematics at the University of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-2/#comment-686285")[#strong[#text("FunSearch: Making new discoveries in mathematical sciences utilizing Giant Language Fashions – Machine Daily")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2024")]

#text("[…] of analysis areas for many years. Famend mathematician Terence Tao as soon as described it as his favourite open query. We collaborated with Jordan Ellenberg, a professor of arithmetic on the College of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom")]], [#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-2")[#strong[#text("Tom")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2007")])]

#text("About your postscriptum: apparently there’s an easy way to add some LaTeX in blogger, see:")

#link("http://wolverinex02.googlepages.com/emoticonsforblogger2")[#text("http://wolverinex02.googlepages.com/emoticonsforblogger2")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kate Sanderstead")]], [#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-3")[#strong[#text("Kate Sanderstead")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2007")])]

#text("A word of warning: your math images are going to be very unstable – they rely on a script running at forkosh.com. If this goes offline for some reason all the formulae in your posts will disappear!")

#text("Seeing as this blog is only just starting, I suggest you move to wordpress.com, which seems to have (very recently) acquired LaTeX support without any hacks:")

#link("http://faq.wordpress.com/2007/02/18/can-i-put-math-or-equations-in-my-posts/")[#text("http://faq.wordpress.com/2007/02/18/can-i-put-math-or-equations-in-my-posts/")]

#text("All the best,")#linebreak()#text("Kate")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-19")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2007")])]

#text("The size of the largest cap sets for F_3^n for n=1,2,3 and 4 are 2,4,9 and 20 right?")#linebreak()#text(" Just checking if my second year math project (on the mathematics of ")#link("http://en.wikipedia.org/wiki/Set_(game)")[#text("Set")]#text(") is actually related to this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-59")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2007")])]

#text("Indeed this is a great problem. The Roth-Meshulam argument says something like:")

#text("If the density of a set A is t then there is a co-dimension one subspace where the density is f(t).")

#text("To get f(t) you have to balance between two scenarios: if there is a large Fourier coefficient (for the characteristic function of A) then this gives you a subspace with higher density right a way. If there is not, a little computation based on Parseval’s theorem tells you that you will get the desired improvement “on average”.")

#text("And now you iterate and get the theorem. Because if the density is larger than 2/3 you certainly have a line there. (What is beautiful about Meshulam’s argument is that various difficulties in the method in other cases vanish and we get “right to the point”.)")

#text("In this problem, as in other combinatorial problems, gradually increasing the density (by moving to a co-dimension one subspace) is the only known method to get anything non-trivial. It looks that we already reached the limit of what this method gives. As far as I know there is no known way to jump directly to low-dimensional subspaces and get better density improvements.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil")]], [#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-60")[#strong[#text("Gil")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2007")])]

#text("Correction: I oversimplified the argument a bit: Either you get close to")#linebreak()#text(" the “right number of lines” (calculated for the case that your set is random?) OR you have a subspace with larger density f(t).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-85")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2007")])]

#text("I thought about this a bit and I do not quite understand the finite field heuristic in combinatorics. For instance, we can also define a line in ")#mi("(\\mathbb{Z}/3)^n")#text(" as a triple that sums to 0. If so, then ")#mi("(\\mathbb{Z}/3)^n")#text(" is a terrible approximation to ")#mi("\\mathbb{Z}/(3^n)")#text(", because the latter has sets of positive density without such triples.")

#text("The lines in ")#mi("(\\mathbb{Z}/3)^n")#text(" are an example of a Steiner triple system, or otherwise they may be viewed as just a collection of ")#mi("O(N^2)")#text(" triples of points, where ")#mi("N = 3^n")#text(". I have a heuristic calculation that suggests that if the collection is unstructured, then you can only expect triple-free sets of size ")#mi("O(\\sqrt{N}(\\log N))")#text(". This suggests that the structure of the lines in ")#mi("(\\mathbb{Z}/3)^n")#text(" and the arithmetic progressions in ")#mi("\\mathbb{Z}/N")#text(" are unusually favorable for the existence of large triple-free sets. Granted, Ben Green and others have much more experience with these problems than I do. Can someone say why these two collections of triples are considered to be comparably favorable?")

#text("Does the empirical data have something to do with it? The maximum cap set cardinality is sequence A090245 in Sloane’s Encyclopedia of Integer Sequences. The known terms are 2,4,9,20,45, and (according to a review article by Davis and Maclagan) the next term is between 112 and 114. Well, this small amount of data does suggest that Meshulam’s bound is not far from the truth. What about subsets of ")#mi("\\mathbb{Z}/(3^n)")#text(" that do not have triples in arithmetic progression?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-86")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2007")])]

#text("Dear Greg,")

#text("It does seem on first glance that there should not be much difference between lines ")#mi("\\{x, y, (x+y)/2\\}")#text(" and triples summing to zero ")#mi("\\{x, y, -x-y\\}")#text(", but the theory for these two patterns very different (though of course they are the same for the characteristic 3 setting of ")#mi("({\\Bbb Z}/3)^n")#text("). The reason is the following: any dense set will necessarily contain a large number of ")#emph[#text("trivial")]#text(" lines ")#mi("\\{x, x, (x+x)/2\\}")#text(", but there is no corresponding notion of a “trivial” triple summing to zero that all dense sets will contain lots of (except in characteristic 3). Because of this, we do not expect dense sets to necessarily contain triples summing to zero in general, whereas we do expect dense sets to contain lines (or more precisely arithmetic progressions of length three).")

#text("There appears to be a deep fact, not well understood at present, that if a “low-complexity object” (such as a set) necessarily contains many “trivial” examples of a “high-complexity object” (such as a line), then it must also contain many non-trivial examples of that high-complexity object as well. It is not always true, of course; it seems to require a certain amount of “symmetry” or “homogeneity” present in the problem. (It also requires the trivial solutions to be arranged in a suitably “transverse” manner, which I won’t define here.) Nevertheless, this deep fact seems to be rather important; it explains, for instance, we can find infinitely many arithmetic progressions ")#mi("p, p+r, \\ldots, p+(k-1)r")#text(" in the primes, or even polynomial progressions ")#mi("p + P_1(r), \\ldots, p+P_k(r)")#text(" where all the integer polynomials ")#mi("P_1(r),\\ldots,P_k(r)")#text(" have zero constant coefficient, but we cannot currently find infinitely many twin primes ")#mi("p, p+2")#text(".")

#text("There is a family of results with names such as the “hypergraph removal lemma” which attempt to make this type of intuition precise, and which have led to a number of deep consequences in property testing. Many recurrence theorems in ergodic theory (e.g. the Poincare recurrence theorem) have this flavour also, since a set can trivially recur to itself if you allow to iterate 0 times rather than a positive number of times.")

#text("One well-known place where this deep fact manifests itself is Ramsey theory. One formulation of Ramsey’s theorem is that if there is a symmetric binary relation between sufficiently many people, then one can find (say) 100 people between which the relation is always true or always false. Note that the claim is trivial if you allow the 100 people to be the same. On the other hand, the claim fails if you drop the symmetry assumption.")

#text("To address your final comment, I think the number of empirical data points we have is too small to meaningfully extract any convincing conclusion; the above phenomenon seems to be an asymptotic one only.")

#text("p.s. Regarding the “finite field heuristic”, one caveat is that the characteristic of the finite field should be large enough to avoid various local obstructions; for instance, Roth’s theorem is rather silly in characteristic 2. It turns out that characteristic 3 seems to enough to model arithmetic progressions of length three properly, whereas to model triples summing to zero one needs characteristic 5 at least.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-32698")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2008")])]

#text("While Roth theorem indeed does not make much sense for characteristic 2, the central ingredient of its wonderful proof is quite important also in characteristic 2 in the context of “linearity testing” in TCS.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-32717")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2008")])]

#text("Dear Gil,")

#text("While on the topic of characteristic 2, it is interesting to note that Sanders has recently managed to improve the upper bound for capsets for the space ")#mi("({\\Bbb Z}/4{\\Bbb Z})^n")#text(" instead of ")#mi("{\\Bbb F}_3^n")#text(", precisely by exploiting a certain degeneracy of length three progressions in this setting; see")

#link("http://arxiv.org/abs/0807.5101")[#text("http://arxiv.org/abs/0807.5101")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-35388")[#strong[#text("Mathematics, Science, and Blogs « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2009")]

#text("[…] (There is a famous problem regarding the density needed.) This problem is reviwed by Terry Tao here. I am not sure if the regularity lemma approach works for this problem; Hillel and Izzy proved […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Upper and lower bounds for the density Hales-Jewett problem « What’s new")]], [#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-35568")[#strong[#text("Upper and lower bounds for the density Hales-Jewett problem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("[…] lines, defined as a triple where ; such sets are known as capsets. Clearly . As noted my previous blog post, the best asymptotic bounds […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-35574")[#strong[#text("Frankl-Rodl’s Theorem and Variations on the Cap Set Problem: A Recent Research Project with Roy Meshulam (A) « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")]

#text("[…] upper bound for is more than . The gap is huge! What is the true value? Terry Tao wrote a lovely post on this problem. A set in without a 3-term arithmetic progression (or alternatively not […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-37311")[#strong[#text("An Open Discussion and Polls: Around Roth’s Theorem « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2009")]

#text("[…] closely related problem can be asked in . It is called the cap set problem. A subset of is called a cap set if it contains no arithmetic progression of size three or, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-38710")[#strong[#text("Around the Cap-Set problem (B) « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2009")]

#text("[…] with Roy Meshulam. (The first post is here. For information on the cap set problem itself look here. ) I will use here a different notation than in part A to make it compatible with various posts […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-38820")[#strong[#text("The Cap-Set Problem and Frankl-Rodl Theorem (C) « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2009")]

#text("[…] that the maximum size of a cap set in is . Here is an obvious fact: The maximum size of a set in with the property that every […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-45977")[#strong[#text("Hyper-optimistic conjecture retrospective – Part 1 « Paul Delhanty")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2010")]

#text("[…] problem, that is the maximal size of a subset of that does not contain an affine line, are by Terence Tao and Gil Kalai. Don’t worry that Tao uses the notation instead of . When k is a prime number […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-48242")[#strong[#text("Roth’s Theorem: Tom Sanders Reaches the Logarithmic Barrier | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2010")]

#text("[…] me mention that a closely related problem can be asked in . It is called the cap set problem. A subset of is called a cap set if it contains no arithmetic progression of size three or, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-49537")[#strong[#text("What is difficult about the cap-set problem? « Gowers's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2011")]

#text("[…] you Google “cap set problem” you will find other blog posts about it, including Terence Tao’s first (I think) blog post and various posts by Gil Kalai, of which this is a good introductory […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-50164")[#strong[#text("Polymath6: thoughts on empirically testing the finite-field heuristic for very low ‘n’ « Paul Delhanty")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2011")]

#text("[…] instead of , it is known that AG(n,q) and PG(n,q) have the same aymptotic behaviour. So even if regarding AG(n,3) as of a Steiner system is too specific, it may be worth considering it in the context of design theory rather than as a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-111919")[#strong[#text("Set is not the only version of Set « Quomodocumque")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2011")]

#text("[…] Terry Tao explains why this is one of his favorite open problems. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-114035")[#strong[#text("Cup Sets, Sunflowers, and Matrix Multiplication | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2011")]

#text("[…] The cap set problem asks for the maximum number of elements in a subset of which contains no arithmetic progression […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-168837")[#strong[#text("Combinatorial problems related to matrix multiplication (guest post by Chris Umans) « Speedup in Computational Complexity")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2012")]

#text("[…] is true or false, but one thing that we do know is that it is a popular blog topic (see here, here, here, and the end of this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Multiple recurrence and convergence results associated to $F_{p}^{omega}$-actions | What's new")]], [#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-230677")[#strong[#text("Multiple recurrence and convergence results associated to $F_{p}^{omega}$-actions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2013")])]

#text("[…] (based on Behrend set constructions) do not seem to be present in the finite field setting (cf. this previous blog post on the cap set problem). In particular, we are able to largely settle the question of when one has […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-371373")[#strong[#text("Influence, Threshold, and Noise | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2014")]

#text("[…] the cap set problem see e.g. here, here and here. There is some similarity between problem and techniques between additive […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-468583")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2016")])]

#text("So, the solution to this problem actually took nine years, rather than a week, but anyway: Jordan Ellenberg ")#link("https://quomodocumque.wordpress.com/2016/05/13/bounds-for-cap-sets/")[#text("has just shown")]#text(" that capsets are asymptotically bounded in size by ")#mi("(2.756)^n")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-468636")[#strong[#text("Mind Boggling: Following the work of Croot, Lev, and Pach, Jordan Ellenberg settled the cap set problem! | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2016")]

#text("[…] is amazing! The cap set problem was quite popular here on the blog, see also Tao’s 2007 post, and Jordan made also quite an effort over the years in proving the other direction before proving […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d28195df14800315168ea974f4adf888eace7d3a34fc83513af492698793a2c-e2ad3cdfa379c5dcf139408dc5d555ac7c236dfa87abd3799a789b51ef5d74f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kodlu")]], [#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-468678")[#strong[#text("kodlu")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2016")])]

#text("I found your response to Greg Kuperberg illuminating. Also, the counterexample in the last paragraph of the post may have a typo; shouldn’t it be $\\{0,1\\}^m \\times F_3^n$?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a01f264f48f5e05d5d685b9021d8eabe021cba75bb29f31f0c2c489198037bd-3a332be6c68a6a6e665ca9294ad450f10654091c15e3a2b8f42c50a2c9b259ff.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The new bound on cap sets | Anurag's Math Blog")]], [#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-468701")[#strong[#text("The new bound on cap sets | Anurag's Math Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2016")])]

#text("[…] problem in combinatorics that survived even after a lot of effort from several mathematicians (see this, this, this and this). Ultimately, just like the finite field Kakeya problem, it succumbed to the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A symmetric formulation of the Croot-Lev-Pach-Ellenberg-Gijswijt capset bound | What's new")]], [#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-468721")[#strong[#text("A symmetric formulation of the Croot-Lev-Pach-Ellenberg-Gijswijt capset bound | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("[…] that does not contain any lines. A basic problem in additive combinatorics (discussed in one of the very first posts on this blog) is to obtain good upper and lower bounds for the maximal size of a capset in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-472235")[#strong[#text("Introduction to the polynomial method (and other similar things) | Short, Fat Matrices")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2016")]

#text("[…] The obvious bounds on are and , and with a bit of extra work, these were improved to and . On his blog, Terry Tao suspected that the lower bound could be improved all the way up to , and in one of his […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-494862")[#strong[#text("The Geometry of SET | Infinite Series | Raket Science")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2018")]

#text("[…] Open question: best bounds for cap sets […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-503308")[#strong[#text("The Mathematical Beauty of the Game SET | The Aperiodical")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2018")]

#text("[…] rich mathematics embedded in SET, perhaps fields medalist Terry Tao can convince you otherwise. In his blog in 2007, he wrote, “Perhaps my favourite open question is the problem on the maximal size of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-508531")[#strong[#text("The Geometry of SET | Infinite Series | Wordpress Tutorials")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2018")]

#text("[…] Open Question: Best Bounds for Cap Sets (blog post by Terry Tao) Open question: best bounds for cap sets […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-572661")[#strong[#text("To cheer you up in difficult times 7: Bloom and Sisask just broke the logarithm barrier for Roth’s theorem! | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2020")]

#text("[…] related problem in . It is called the cap set problem. A subset of is called a cap set if it contains no arithmetic progression of size three or, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/801259f0a666edd9b70dd38b0d5cc8eb7f6b72c6587b261eb562b5e6fee671fc-f3f321a07d28b2e2fda10a549fb09a74e10617d3156bc6a319563fef0f905b6b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pjl")]], [#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-682623")[#strong[#text("pjl")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2023")])]

#text("Hi Terry, Any thoughts on the recent Google DeepMind paper: ")#link("https://deepmind.google/discover/blog/funsearch-making-new-discoveries-in-mathematical-sciences-using-large-language-models/")[#text("https://deepmind.google/discover/blog/funsearch-making-new-discoveries-in-mathematical-sciences-using-large-language-models/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eaa2c01a9025dbfdea6cc4d95a256bbee867f67d4b7a7d44ffe79f0f7395ae4f-b9a9eec63bd8c0cb8f4d899e3cb25fd62e4831ef4d280f4645e6c1e6ae534a4a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mitchellporter")]], [#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-682672")[#strong[#text("mitchellporter")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2023")])]

#text("On Twitter I see people saying AI “solved the cap set problem”, but I think all it did is generate new record-breaking examples. That improved the lower bound, but didn’t prove that they are the best possible.")

#text("The technical interest is that this was done through a form of meta-search, in which the AI invented a new search algorithm to explore the problem space")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-682649")[#strong[#text("FunSearch: Making new discoveries in mathematical sciences using Large Language Models - AI Gumbo")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2023")]

#text("[…] in multiple research areas for decades. Renowned mathematician Terence Tao once described it as his favorite open question. We collaborated with Jordan Ellenberg, a professor of mathematics at the University of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-682663")[#strong[#text("Google DeepMind used a large linguistic model to answer an unsolvable mathematical problem - Eggs")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2023")]

#text("[…] the Fields Medal, called the plug set problem “perhaps my favorite open question” in a post blog in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-682745")[#strong[#text("Google DeepMind used a large language model to solve an unsolved math problem - Featured Today Only")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2024")]

#text("[…] It’s super niche, but important. Mathematicians do not even agree on how to solve it, let alone what the solution is. (It is also connected to matrix multiplication, the computation that AlphaTensor found a way to speed up.) Terence Tao at the University of California, Los Angeles, who has won many of the top awards in mathematics, including the Fields Medal, called the cap set problem “perhaps my favorite open question” in a 2007 blog post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-682812")[#strong[#text("Mathematical discoveries from program search with large language models – Nature.com – Insight Chronicle: Uncovering the Stories Behind the Headlines")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2024")]

#text("[…] T. Open question: best bounds for cap sets. WordPress Blog ")#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/")[#text("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-682814")[#strong[#text("FunSearch: Making new discoveries in mathematical sciences utilizing Massive Language Fashions – Aispacesolutions.com")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2024")]

#text("[…] of analysis areas for many years. Famend mathematician Terence Tao as soon as described it as his favourite open query. We collaborated with Jordan Ellenberg, a professor of arithmetic on the College of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-682830")[#strong[#text("FunSearch: Making new discoveries in mathematical sciences utilizing Massive Language Fashions - Techbrusts")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2024")]

#text("[…] of analysis areas for many years. Famend mathematician Terence Tao as soon as described it as his favourite open query. We collaborated with Jordan Ellenberg, a professor of arithmetic on the College of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-682841")[#strong[#text("Google DeepMind used a large language model to solve an unsolved math problem - TECHTELEGRAPH")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2024")]

#text("[…] It’s super niche, but important. Mathematicians do not even agree on how to solve it, let alone what the solution is. (It is also connected to matrix multiplication, the computation that AlphaTensor found a way to speed up.) Terence Tao at the University of California, Los Angeles, who has won many of the top awards in mathematics, including the Fields Medal, called the cap set problem “perhaps my favorite open question” in a 2007 blog post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-684415")[#strong[#text("The Unreasonable Ineffectiveness of AI for Math - Synthesis AI")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2024")]

#text("[…] Fields medalist Terence Tao, by many accounts the best mathematician alive, once called it “perhaps my favourite open question”, so let’s dive into the problem a little […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-684418")[#strong[#text("FunSearch: Making new discoveries in mathematical sciences using Large Language Models – TechnologyX")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2024")]

#text("[…] of analysis areas for many years. Famend mathematician Terence Tao as soon as described it as his favorite open question. We collaborated with Jordan Ellenberg, a professor of arithmetic on the College of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-684468")[#strong[#text("FunSearch: Making new discoveries in mathematical sciences using Large Language Models – AISistible")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2024")]

#text("[…] in multiple research areas for decades. Renowned mathematician Terence Tao once described it as his favorite open question. We collaborated with Jordan Ellenberg, a professor of mathematics at the University of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-684544")[#strong[#text("FunSearch: realizar nuevos descubrimientos en ciencias matemáticas utilizando modelos de habla grandes – Blushmarketing.tech")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2024")]

#text("[…] durante décadas. El renombrado matemático Terence Tao lo describió una vez como su pregunta abierta favorita. Colaboramos con Jordan Ellenberg, profesor de matemáticas en la Universidad de Wisconsin-Madison […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-684552")[#strong[#text("FunSearch: Making new discoveries in mathematical sciences utilizing Giant Language Fashions - Pro News Blog: Dive into the World of Pro News")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2024")]

#text("[…] of analysis areas for many years. Famend mathematician Terence Tao as soon as described it as his favourite open query. We collaborated with Jordan Ellenberg, a professor of arithmetic on the College of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-684709")[#strong[#text("FunSearch: Making new discoveries in mathematical sciences using Large Language Models – Artificial Intelligence")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2024")]

#text("[…] in multiple research areas for decades. Renowned mathematician Terence Tao once described it as his favorite open question. We collaborated with Jordan Ellenberg, a professor of mathematics at the University of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-685022")[#strong[#text("FunSearch: Making new discoveries in mathematical sciences utilizing Massive Language Fashions – Guarym")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2024")]

#text("[…] of analysis areas for many years. Famend mathematician Terence Tao as soon as described it as his favourite open query. We collaborated with Jordan Ellenberg, a professor of arithmetic on the College of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/comment-page-1/#comment-685146")[#strong[#text("FunSearch: Making new discoveries in mathematical sciences using Large Language Models – FLUXSAVAGE")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2024")]

#text("[…] in multiple research areas for decades. Renowned mathematician Terence Tao once described it as his favorite open question. We collaborated with Jordan Ellenberg, a professor of mathematics at the University of […]")
]
