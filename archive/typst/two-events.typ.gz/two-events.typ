// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/02/10/two-events/
// Converted to Typst by tao2typ: "2026-10-14T10:50:55.015800+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Two events", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Two events")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 February 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/02/10/two-events/")[#text("https://terrytao.wordpress.com/2019/02/10/two-events/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Just a quick post to advertise two upcoming events sponsored by institutions I am affiliated with:")

#enum(start: 1, 
[#text("The ")#link("https://www.nationalmathfestival.org/2019-festival/")[#text("2019 National Math Festival")]#text(" will be held in Washington D.C. on May 4 (together with some ")#link("https://www.nationalmathfestival.org/around-the-us/")[#text("satellite events")]#text(" at other US cities). This festival will have numerous games, events, films, and other activities, which are all free and open to the public. (I am on the board of trustees of ")#link("http://www.msri.org/web/cms")[#text("MSRI")]#text(", which is one of the sponsors of the festival.)")],
[#text("The ")#link("http://www.ipam.ucla.edu/")[#text("Institute for Pure and Applied Mathematics")]#text(" (IPAM) is now accepting applications for its second Industrial Short Course for May 16-17 2019, with the topic of “")#link("http://www.ipam.ucla.edu/programs/special-events-and-conferences/an-industrial-short-course-on-deep-learning-and-the-latest-ai-algorithms/")[#text("Deep Learning and the Latest AI Algorithms")]#text("“. (I serve on the Scientific Advisory Board of this institute.) This is an intensive course (in particular requiring active participation) aimed at industrial mathematicians involving both the theory and practice of deep learning and neural networks, taught by Xavier Bresson. (Note: space is very limited, and there is also a registration fee of $2,000 for this course, which is expected to be in high demand.)")]
)

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a97deaa3ef13986dc80176f3b5a6ee0c6b50aac91ea4d586c114a25b4b08bb6f-6c6a6b670c64a488edbfc0a351fa1f415f8fa1a444d247a852145bc16b88533f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jair2018")]], [#link("https://terrytao.wordpress.com/2019/02/10/two-events/#comment-512561")[#strong[#text("jair2018")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2019")])]

#text("Reblogged this on ")#link("https://nricxcrap.wordpress.com/2019/02/13/two-events/")[#text("Crap")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e58291dee497bce05ea715d27484307bf6810870579a769514e9940730a1b41-91b242a82ba4902b5a7c391737fdc8e0f3b74761723d09be9c7c1b4ce0091576.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pring Wong")]], [#link("https://terrytao.wordpress.com/2019/02/10/two-events/#comment-512726")[#strong[#text("Pring Wong")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2019")])]

#text("page not found for “Deep Learning and the Latest AI Algorithms“")

#emph[#text("[Corrected, thanks -T.]")]
]
