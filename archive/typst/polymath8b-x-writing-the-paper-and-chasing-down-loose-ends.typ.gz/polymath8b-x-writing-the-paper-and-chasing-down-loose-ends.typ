// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/
// Converted to Typst by tao2typ: "2026-10-14T16:37:24.140525+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath8b, X: writing the paper, and chasing down loose ends", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath8b, X: writing the paper, and chasing down loose ends")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 April 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/")[#text("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is the tenth thread ")#text("for the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("Polymath8b project")]#text(" to obtain new bounds for the quantity")

#align(center)[#mi("H_m := \\liminf_{n \\to\\infty} p_{n+m} - p_n")#text(";")]

#text("the previous thread may be found ")#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/")[#text("here")]#text(".")

#text("Numerical progress on these bounds have slowed in recent months, although we have very recently lowered the unconditional bound on ")#mi("H_1")#text(" from 252 to 246 (see the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("wiki page")]#text(" for more detailed results). While there may still be scope for further improvement (particularly with respect to bounds for ")#mi("H_m")#text(" with ")#mi("m=2,3,4,5")#text(", which we have not focused on for a while, it looks like we have reached the point of diminishing returns, and it is time to turn to the task of writing up the results.")

#text("A draft version of the paper so far may be found ")#link("https://www.dropbox.com/sh/0xb4xrsx4qmua7u/tfwv3_O_WY/Polymath8b/newergap.pdf")[#text("here")]#text(" (with the directory of source files ")#link("https://www.dropbox.com/sh/0xb4xrsx4qmua7u/WOhuo2Gx7f/Polymath8b")[#text("here")]#text("). Currently, the introduction and the sieve-theoretic portions of the paper are written up, although the sieve-theoretic arguments are surprisingly lengthy, and some simplification (or other reorganisation) may well be possible. Other portions of the paper that have not yet been written up include the asymptotic analysis of ")#mi("M_k")#text(" for large k (leading in particular to results for m=2,3,4,5), and a description of the quadratic programming that is used to estimate ")#mi("M_k")#text(" for small and medium k. Also we will eventually need an appendix to summarise the material from Polymath8a that we would use to generate various narrow admissible tuples.")

#text("One issue here is that our current unconditional bounds on ")#mi("H_m")#text(" for m=2,3,4,5 rely on a distributional estimate on the primes which we believed to be true in Polymath8a, but never actually worked out (among other things, there was some delicate algebraic geometry issues concerning the vanishing of certain cohomology groups that was never resolved). This issue does not affect the m=1 calculations, which only use the Bombieri-Vinogradov theorem or else assume the generalised Elliott-Halberstam conjecture. As such, we will have to rework the computations for these ")#mi("H_m")#text(", given that the task of trying to attain the conjectured distributional estimate on the primes would be a significant amount of work that is rather disjoint from the rest of the Polymath8b writeup. One could simply dust off the old maple code for this (e.g. one could tweak the code ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi1080d13_74487363_m4.mpl")[#text("here")]#text(", with the constraint 1080*varpi/13+ 330*delta/13<1 being replaced by 600*varpi/7+180*delta/7<1), but there is also a chance that our asymptotic bounds for ")#mi("M_k")#text(" (currently given in messy detail ")#link("http://michaelnielsen.org/polymath1/index.php?title=Selberg_sieve_variational_problem#Asymptotic_analysis")[#text("here")]#text(") could be sharpened. I plan to look at this issue fairly soon.")

#text("Also, there are a number of smaller observations (e.g. the parity problem barrier that prevents us from ever getting a better bound on ")#mi("H_1")#text(" than 6) that should also go into the paper at some point; the current outline of the paper as given in the draft is not necessarily comprehensive.")

#heading(level: 1)[#text("Comments (122)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath 8b, XI: Finishing up the paper | What's new")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-2/#comment-343621")[#strong[#text("Polymath 8b, XI: Finishing up the paper | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2014")])]

#text("[…] the previous thread may be found here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72ce42d5babc3b6c5cf4b07e598b75c46bfd929d21d5788d5f3b9cac45b60941-9cba33da02feac9c844ec6c1dad49bdde6fb3ac158bc98d4d4d989a49f2e2643.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of samir.brahim@gmail.com")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-2/#comment-478427")[#strong[#text("samir.brahim@gmail.com")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2017")])]

#text("Dear All,")#linebreak()#text(" I have proved the twin number but no journal would like to review, ti is too scary !!")#linebreak()#text(" I will be happy if any one can read my Sketch of the proof’s section Page 5 and 6 only")

#link("https://arxiv.org/abs/1512.00970")[#text("https://arxiv.org/abs/1512.00970")]

#text("Best regards")#linebreak()#text(" Samir")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0842619b40b080de5f59589ccb82d5e51cd8f7bc0181cc5fa8bbcb7cba4b187-bad285d30d50227a646bb8300032a3e4d1f861a297ec8f9b4e6bf4636dbac760.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-297949")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2014")])]

#text("While I do find these recent breakthroughs incredibly interesting, I am sadly unable to understand the details (yet!). What prerequisites (in terms of classes, e.g “basic understanding of subject X, deep understanding of subject Y) are required to understand the math performed here? In particular, could a (intellectually gifted as any other math undergrad, but still mortal) hope to grasp it? I am looking through a lot of math I don’t really understand yet in hope that “listening to the music while not grasping the lyrics” will eventually pay off, but I feel myself growing a bit impatient. (This might be better suited in some career-advice page, but hey, what’s a comment-field without at least one poster going off-topic?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0842619b40b080de5f59589ccb82d5e51cd8f7bc0181cc5fa8bbcb7cba4b187-bad285d30d50227a646bb8300032a3e4d1f861a297ec8f9b4e6bf4636dbac760.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-297951")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2014")])]

#text("That is supposed to read “could an undergraduate…”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-297993")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2014")])]

#text("One could start by having a look at Andrew Granville’s recent survey article ")#link("http://www.dms.umontreal.ca/~andrew/CEBBrochureFinal.pdf")[#text("http://www.dms.umontreal.ca/~andrew/CEBBrochureFinal.pdf")]#text(" , which starts out fairly gently. But if you haven’t seen, for instance, a proof of the prime number theorem (or, at bare minimum, Mertens’ theorem), it is probably going to be somewhat rough going once one plunges into the details. (The sieve-theoretic aspects of the argument are elementary, and one could in principle understand these aspects at least if one is willing to accept certain estimates (e.g. the Bombieri-Vinogradov theorem) as a black box, but my feeling is that one will not really appreciate what is going on if one solely focuses on the sieve theory.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dab262b249e6b008de2defe2a9d55f776181f2faf2f8a2ae168348cdfb2adaf-097fe507317aee85ccf32427e06a89aeacc09d75464afe95cd265a14b70a7a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-297960")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2014")])]

#text("Do you have written up somewhere exactly what cohomology vanishing statements (or exponential sum bounds) you need to check?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-297990")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2014")])]

#text("Yes, this was briefly stated in ")#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/#comment-247146")[#text("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/#comment-247146")]#text(" and I can reproduce it here.")

#text("Let ")#mi("a,b,c,d")#text(" be generic elements of ")#mi("{\\bf F}_p")#text(" for some large prime p. Form the rational function")

#mi("f(X,Y) := \\frac{1}{(Y+aX+b)(Y+cX+d)} + eY")

#text("and then the Kloosterman-type sum")

#mi("K_f(x) := -\\frac{1}{p^{1/2}} \\sum_{y \\in {\\bf F}_p} \\psi(f(x,y))")

#text("where ")#mi("\\psi")#text(" is a primitive character (and we delete the bounded number of values of ")#mi("y")#text(" for which ")#mi("f(x,y)")#text(" is infinite). Weil tells us that this is a bounded function (it corresponds to a lisse sheaf ")#mi("{\\mathcal K}_f")#text(" with vanishing H^0). By some ad hoc calculations using the sheaf-theoretic Fourier transform, we can also get cancellation for the sums")

#mi("Q(l) := \\frac{1}{p^{1/2}} \\sum_{x \\in {\\bf F}_p} \\overline{K_f(x)} K_f(x+l),")

#text("namely that ")#mi("Q(l) = O(1)")#text(" for any non-zero l; see Theorem 8.17 of Polymath8a.")

#text("But now we need one more round of cancellation, to show that the expression")

#mi("\\frac{1}{\\sqrt{p}} \\sum_l Q(l) \\psi( gl^2 + hl )")

#text("is also O(1) for any ")#mi("g, h \\in {\\bf F}_p")#text(". This expands out to an exponential sum in four variables for which the associated sheaf needs to be middle-extension; this should certainly be true, but we don’t have a systematic way to approach the problem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philippe Michel")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-302878")[#strong[#text("Philippe Michel")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2014")])]

#text("Hi Terry,")

#text("This has been a little while… I have only loosely followed Polymath8b so farbut I was pursuing other projects (with the same usual suspects). One good thing is that we have gained experience further on handling further exponential sums together with new applications not totally unrelated to polymath8. Maybe the moment is ripe for thinking again on improving further the level of distribution of the primes over smooth and not so smooth moduli (maybe a polymath8c ?) which could be further discussed while everybody is at IHES.")

#text("Anyway here is the answer to the above problem (I will write the details into the adequate file of polymath8b wherever you tell me):")

#text("this is again the fourier transform trick (which after all is maybe not so “ad-hoc”)")

#text("one needs to show that ")#mi("l\\mapsto Q(l)")#text(" does not contain a quadratic phase ; by the criterion of polymath8a it is sufficient to look at the Fourier transform but ")#mi("Q")#text(" is an additive convolution of K_f with the conjugate of itself and therefore its fourier transform is the product of the fourier transform and its complex congugate (and the sheaf Fourier transform ")#mi("FT\\mathcal{Q}")#text(" of the sheaf associated to ")#mi("Q")#text(" is the tensor product of the the FT of ")#mi("\\mathcal{K}_f")#text(" and its dual). Again from polymath8a we know ")#mi("FT\\mathcal{K}_f")#text(" is a pullback of a Kloosterman sheaf ")#mi("KL_3")#text(" which is irreducible with known geometric monodromy group (SL_3) it follow that ")#mi("FT\\mathcal{Q}")#text(" decompose as the trivial representation and an 8-dim irreducible representation (the decomposition of the End representation of SL_3).")

#text("This type argument shows that above “quadratic phase” can be replaced by any polynomial phase (with some small care for polynomials of degree 9, whose FT yield an irred 8-dim sheaf but the infinity representation differentiate the two). Therefore it is likely that further games can be played…")

#text("see you in Cambridge soon !")

#text("Philippe")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-302980")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2014")])]

#text("Great news! From your description it sounds like we could squeeze a proof of our tentative MPZ estimate into a technical “Appendix B” for the Polymath8b paper, which would cite heavily from Polymath8a but would otherwise contain all the required details. In that case, it may not be so urgent to redo the m=2,3,4,5 computations with the weaker MPZ estimate (though having both of the numbers out there would be a nice numerical illustration of the gain that the new estimate gives).")

#text("In other news, I’ve almost finished transcribing the M_k asymptotics from the wiki to the paper. Unfortunately I remember now why it is difficult to extend these arguments to M_{k,eps} (and thus to get better bounds using GEH instead of EH, or to improve the unconditional bounds slightly): the bounds from M_k come from carefully estimating the defect in the upper bound ")#mi("M_k \\leq \\frac{k}{k-1} \\log k")#text(". We do have upper bounds for ")#mi("M_{k,\\varepsilon}")#text(", but they are nowhere near as tight as the ")#mi("M_k \\leq \\frac{k}{k-1} \\log k")#text(" bound, so the defect is much larger and we lose a lot more when trying to estimate it.")

#text("Once I’m done transcribing that section, I’ll try to work on “Appendix B”, in particular citing my way through Polymath8a to reduce the MPZ estimate to the exponential sum estimate, which I think I will then turn over to you to fill in. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-304203")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2014")])]

#text("I’ve been going through the exponential sum/ advanced type I parts of Polymath8a again, and realise that the exponential sum estimate we really need is actually slightly different, because we’re not applying two 1-dimensional van der Corput’s one after another, but are instead applying a single two-dimensional van der Corput. The more precise statement we need is that for “generic” ")#mi("\\alpha, \\beta, \\gamma \\in {\\bf F}_q")#text(", if we write ")#mi("K(l,d;q)")#text(" for the Kloosterman-type sum")

#mi("K(l,d;q) := \\frac{1}{\\sqrt{q}} \\sum_{n \\in {\\bf F}_q} e_q( \\frac{\\alpha l}{(n+\\beta d)(n+(\\beta+l)d} + \\gamma n)")

#text("then for “generic” shifts (a,b), we have")

#mi("\\sum_{d,l \\in {\\bf F}_q} K(l+a,d+b;q) \\overline{K(l,d;q)} e_q( \\xi l + \\eta d) = O( q )")

#text("for any ")#mi("\\xi,\\eta \\in {\\bf F}_q")#text(". This should reduce to an assertion to the effect that ")#mi("K")#text(" does not contain a quadratic phase along any (generic) line, but because we now have a 2D exponential sum instead of a 1D exponential sum (and need Deligne-level cancellation rather than Weil-level) I’m not sure how to encode this into the 1D sheaf language properly.")

#text("EDIT: In a little more detail, the objective is to obtain a “2D van der Corput” exponential sum estimate of the form")

#tao-math("\\left|\\sum_{d,l} \\psi_D(d) \\psi_L(l) K(l,d;q)\\right| \\lessapprox (D^{1/2} r^{1/2} + D^{1/2} s^{1/4})", block: false)#linebreak()#text(" ")#mi("\\times (L^{1/2} r^{1/2} + L^{1/2} s^{1/4})")

#text("when ")#mi("q=rs")#text(" and ")#mi("1 \\leq D,L \\leq q")#text(" (actually the main region is when ")#mi("r \\leq D,L \\leq s")#text("). One can try doing two separate 1D van der Corputs to get this bound, but one ends up with something weaker when one does so; it seems that it is only the 2D van der Corput (in which one shifts (l,d) by a 2D vector (a,b)) that gives the best results here, but then we need 2D Deligne type bounds.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-306762")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2014")])]

#text("A little more detail on the precise issue. There are a number of ways to estimate a sum of the form")

#mi("\\sum_{d,l} \\psi_D(d) \\psi_L(l) K(l,d;q).")

#text("assuming that all the completed sums involving ")#mi("K")#text(" exhibit square root cancellation, and that ")#mi("D,L \\leq q")#text(".")#linebreak()#text(" For instance, we have a trivial bound of ")#mi("O(DL)")#text(", while simultaneous completion of sums gives the dual bound ")#mi("O( q^{1/2} \\times q^{1/2} )")#text(". q-van der Corput in d and triangle inequality in l gives an upper bound of")

#mi("L ( D^{1/2} r^{1/2} + D^{1/2} s^{1/4} )")#text(" (1)")

#text("whenever ")#mi("q=rs")#text(", which is what Polymath8a is using. Ideally, a simultaneous q-van der Corput in (d,l) should be available, giving the bound of")

#mi("(L^{1/2} r^{1/2} + L^{1/2} s^{1/4}) (D^{1/2} r^{1/2} + D^{1/2} s^{1/4})")#text(" (2)")

#text("but this requires square root cancellation for a certain two-dimensional sum involving K as in the previous comment, and I don’t see how to get this from 1D trace weight technology. More feasible (and pretty much solved by Phillipe’s previous comment) is to first van der Corput in d, giving an intermediate bound of the form")

#mi("D^{1/2} L^{1/2} ( A^{-1} \\sum_{a=O(A)} | \\sum_{d,l} \\psi_D(d) \\psi_D(d+ar) \\psi_L(l)")#linebreak()#text(" ")#mi("\\overline{K(l,d;q)} K(l,d+ar;q) | )^{1/2}")

#text("where ")#mi("A \\sim D/r")#text(". The ")#mi("a=0")#text(" term contributes ")#mi("L D^{1/2} r^{1/2}")#text(", and the ")#mi("a \\neq 0")#text(" terms contribute ")#mi("L D^{1/2} s^{1/4}")#text(" if one just uses completion of sums in the d aspect; but if one applies a second van der Corput in the l sum also, then one arrives at a bound of")

#mi("L D^{1/2} r^{1/2} + D^{1/2} L^{1/2} s^{1/4} (L^{1/2} r^{1/2} + L^{1/2} s^{1/4})^{1/2}")#text(" (3)")

#text("which is a little better than (1) but not as good as (2), and would ultimately lead to a value of ")#mi("\\varpi")#text(" intermediate between 6/700 and 13/1080 (I haven’t checked exactly what we get though).")

#text("So it’s a little unclear exactly what we can hope to get right now, because it hinges on whether we can get squareroot cancellation for the complicated sum")

#mi("\\sum_{d,l \\in {\\bf F}_q} K(l+a,d+b;q) \\overline{K(l,d;q)} e_q( \\xi l + \\eta d).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-297963")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2014")])]

#text("I can help assemble the material for Appendix A. There are actually a couple of additional tricks I used to more efficiently construct narrow admissible tuples for some of the larger values of k needed to get bounds for m=2,3,4,5.")

#text("But it probably makes sense to wait to finalize this until after we have settled on the exact values of k we want to use for these m.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-298130")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2014")])]

#text("Congratulations to all involved. I think this project has been an excellent opportunity to publicise the ongoing work of mathematicians, and the human, interactive element of what we do.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-298509")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2014")])]

#text("There’s a typo in the definition of ")#mi("H_m")#text(": ")#mi("p_m")#text(" should’ve been ")#mi("p_n")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-298617")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2014")])]

#text("Is it possible to find an explicit (numerical) upper bound on the constant implied by the O-term in theorem 1.4(vi)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-301803")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2014")])]

#text("Yes, this is in principle possible by working through the calculations at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Selberg_sieve_variational_problem#Asymptotic_analysis")[#text("http://michaelnielsen.org/polymath1/index.php?title=Selberg_sieve_variational_problem#Asymptotic_analysis")]#text(" with explicit choices of parameters. I plan to spend some time today revisiting the computations here and seeing if it can be done more cleanly and efficiently; the current calculations are quite a mess and far from optimal, I think.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-299900")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2014")])]

#text("I added ")#link("http://arxiv.org/abs/1404.4007")[#text("Bounded gaps between primes with a given primitive root”")]#text(" to the wiki.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-300839")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2014")])]

#text("I will find some time to compute k values for 600*varpi/7+180*delta/7<1 in a few days.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/396f2960e20c65e3aa777ef94a3c0182596d72c98d3b4d0c5fd49d4381442c68-b6afbafec1c7094e9841f233146023ce851d2891602a9700019b15204786fd0c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-301877")[#strong[#text("Daniel")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2014")])]

#text("Congratulations on the project. Excellent their work to the benefit of us who like the world of mathematics. A greeting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-302031")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2014")])]

#text("Here are the k0 values (under the constraint 600*varpi/7+180*delta/7<1):")

#text("k0=")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi600d7m2_35410.mpl")[#text("35410")]#text(" for m=2")

#text("k0=")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi600d7m3_1649821.mpl")[#text("1649821")]#text(" for m=3")

#text("k0=")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi600d7m4_75845707.mpl")[#text("75845707")]#text(" for m=4")

#text("k0=")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi600d7m5_3473955908.mpl")[#text("3473955908")]#text(" for m=5")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-302182")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2014")])]

#text("For sake of comparison, now that Gergely has observed that James’ bound ")#mi("M_k \\geq \\log k - 2\\log \\log k - 2")#text(" is valid for all k, this gives a criterion for ")#mi("DHL[k,m+1]")#text(" whenever ")#mi("\\log k - 2\\log\\log k - 2 > 4m")#text(", but this gives significantly worse numerology (k ~ 527751 for m=2, for instance).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-317150")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2014")])]

#text("Terry, how did you get 527751 here? It seems to me that k=515738 is the minimum possible.")

#text("Less trivially (I hope): what is the obstacle to refining this bound using MPZ technology, i.e. to replacing 4m by 1080m/283 (giving, e.g., k=334989 for m=2)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-317897")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2014")])]

#text("Sorry, I meant to say 5277510 here (note we are working with m=1 rather than m=2): ")#link("https://www.wolframalpha.com/input/?i=solve+ln%28x%29-2*ln%28ln%28x%29%29-2%3D8")[#text("https://www.wolframalpha.com/input/?i=solve+ln%28x%29-2*ln%28ln%28x%29%29-2%3D8")]

#text("One could probably get some bound like this using MPZ if one went through the argument in Maynard’s paper carefully, but it would probably not beat the bound k=395106 that we currently have.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-302053")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2014")])]

#text("What can be said at this point about the possibility of obtaining better values of H_m assuming GEH versus EH for values of m greater than 1? Since the paper will give such prominence to the achievement of H_1 = 6 assuming GEH versus only 12 assuming only EH, it seems that readers will be quite interested in whether similarly substantial differences arise for H_2 etc.")

#text("Also, while writing: this thread is not yet linked-to from ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")]#text(" .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-302077")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2014")])]

#text("Link added, thanks.")

#text("Regarding GEH vs EH, it is true that the epsilon trick becomes available when GEH is assumed; however, in that setting there is an additional constraint ")#mi("\\varepsilon < \\frac{1}{k-1}")#text(" which has never been important in the small k cases, but becomes so for larger k. For instance, Pace's recent bound ")#mi("M_{50,1/25} > 4")#text(" gave us ")#mi("H_1 \\leq 246")#text(", but does not directly bound ")#mi("H_2")#text(" on GEH because the epsilon choice ")#mi("1/25")#text(" is too large. Presumably one could split the difference and work with some choice like ")#mi("k = 52, \\varepsilon = 1/51")#text(" and improve the EH bound on ")#mi("H_2")#text(" a little bit on GEH, but I don't know how long that would take to compute. There is some parallel gain for the larger values of k in the asymptotic analysis of ")#mi("M_k")#text(" to be had also, though my feeling is that the gain is somewhat modest.")

#text("I'm starting to write up the asymptotic analysis of M_k section, and I'll look out to see if there is some easy way to work in the epsilon trick, which would also improve the non-EH bounds.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-302101")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2014")])]

#text("Preliminary H values for the k0 values posted by xfxie above:")

#text("m=2, k0=35,410, H=398,646")#linebreak()#text(" m=3, k0=1,649,821, H=25,816,462")#linebreak()#text(" m=4, k0=75,845,707, H=1,541,858,666")#linebreak()#text(" m=5, k0=3,473,955,908, H=84,449,123,072")

#text("I just kicked off computations to further optimize these, but this will take some time.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-303059")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2014")])]

#text("Some improved bounds:")

#text("m=2, k0=35,410, H=")#link("http://math.mit.edu/~drew/admissible_35410_398244.txt")[#text("398,244")]#linebreak()#text(" m=3, k0=1,649,821, H=")#link("http://math.mit.edu/~drew/admissible_1649821_24798306.txt")[#text("24,798,306")]#linebreak()#text(" m=4, k0=75,845,707, H=1,541,183,756")#linebreak()#text(" m=5, k0=3,473,955,908, H=84,499,103,908")

#text("The admissible tuple for m=4 is obtained by taking k0 consecutive primes starting with p_4223718=71,910,101.")

#text("The admissible tuple for m=5 is obtained by taking k0 consecutive primes starting with p_166088916=3,473,846,231.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6525d7cd9db10f0f8b9a18fa0e62f21ac78916ee3eed4debea5956daeaf030-72219f07d23f0f1bc893af77a76e1cfd99cff0d2c3626a52796f2e15ac6c7e88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of interested non-expert")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-304311")[#strong[#text("interested non-expert")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2014")])]

#text("Your “improved” value of m=5 is bigger than the original one. I guess there is a typo in either “84,449,123,072” or “84,499,103,908”. (see 8th digit 4 vs. 9)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-304362")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2014")])]

#text("You are right there is a typo, the improved value should be 84,449,103,908, thanks for catching this.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-316813")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2014")])]

#text("Further improvements for the values of k0 ")#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/#comment-302031")[#text("obtained by xfxie")]#text(" under the constraint 600*varpi/7+180*delta/7 < 1.")

#text("m=2, k0=35,410, H=")#link("http://math.mit.edu/~drew/admissible_35410_398130.txt")[#text("398,130")]#text(".")#linebreak()#text(" m=3, k0=1,649,821, H=")#link("http://math.mit.edu/~drew/admissible_1649821_24797814.txt")[#text("24,797,814")]#text(".")#linebreak()#text(" m=4, k0=75,845,707, H=1,526,698,470=p_1533587021-p_6888551.")#linebreak()#text(" m=5, k0=3,473,955,908, H=83,833,839,882=p_3487335728-p_13379821.")

#text("The last two bounds were obtained using a cache-friendly omp-based implementation of the admissiblity testing algorithm described in Section 3.1 of the Polymath8a paper that has been optimized to treat sequences of consecutive primes. I’ll post the source code to the wiki later today (possibly tomorrow).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-316857")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2014")])]

#text("Those are quite big improvements! Is it worth also running your new code on the 1080/13 constraint? – do you think there is more to be squeezed there in acceptable running times?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-316861")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2014")])]

#text("Yes, in fact the computations are running now. I should have some results tomorrow.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-318400")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2014")])]

#text("Fast multi-threaded code that can be used to verify large tuples of consecutive primes has been posted to the wiki and is also available ")#link("https://math.mit.edu/~drew/ompadm_v0.tar")[#text("here")]#text(".")

#text("In the process of testing I found that the code was being a bit too pessimistic in its search for an optimal choice of n <= k0 for which the tuple p_{n+1},…,p_{n+k0} is admissible. Fixing this yielded a slightly better result for the m=5, k0=3,473,955,908 case. Using n=13379818 gives a diameter of")

#text("H=83,833,839,848.")

#text("For anyone who wants to verify the m=4,5 results, compile the code at the link above on a 64-bit linux box and run")

#text("zhangverify 75845707 469552")#linebreak()#text(" zhangverify 3473955908 13379818")

#text("The first case takes about a minute on a 24 core Intel Xeon ")#link("mailto:E5-2697v2@2.7GHz")[#text("E5-2697v2@2.7GHz")]#text(", while the second case takes about 5 hours (for comparison, verifying the largest case k0=3,500,000, n=33,639 listed in the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Finding_narrow_admissible_tuples#Benchmarks")[#text("benchmarks table")]#text(" takes less than a second).")

#text("I am now re-running computations for some of the larger k-values in the current records table that I started yesterday. I should have the results tomorrow morning.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-303279")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2014")])]

#text("It seems that in the DHL sufficient condition below theorem 3.11, it should be “")#mi("m < ...")#text("\" (instead of \"")#mi("m \\geq ...")#text("\")")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-304584")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2014")])]

#text("In the RHS of (6.4), it should be ")#mi("\\log (\\lambda -1)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-305801")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2014")])]

#text("In theorem 3.2(vi), the fraction in the exponent should be updated (and also in the last inequality below theorem 3.11).")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-309506")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2014")])]

#text("There is an extra “-” (in both places).")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-310808")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2014")])]

#text("Abstract, l. 1 + Intro., l. 2: Parentheses around ")#mi("p_{n+m} - p_{n}")#text(".")

#emph[#text("[Parentheses added – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/55e588a56c74835f96638eb089fbcefce3651309f8b7ecdb2bafa2dfca3002b9-d6c652eeddd8aca6e1d7128031259acddcce46f5a41c5f14e41b44abf1d93913.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of einsteins")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-306484")[#strong[#text("einsteins")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2014")])]

#text("Hi,I love all professores of this project.I am sure 100% with current speed, all you prove H=2 within August.2014.I do not joke")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-306825")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2014")])]

#text("I’ve had a first read-through of the sieving sections and in general it all looks good. I’m still going through it slowly (playing with a separate tex file), but this will likely take me a little while.")

#text("A couple of minor thoughts on possible `streamlining’ modifications (although these would only save a few lines at best):")#linebreak()#text(" 1. If we modified Lemma 4.1 to also have the ")#mi("d_i")#text(" coprime to a fixed integer (this is a trivial change), then we could use a Selberg upper bound instead of the large sieve argument on page 23 to bound ")#mi("\\sum_{**}")#text(". This would have the advantage that we could essentially quote the result straight from Lemma 4.1, possibly saving some space.")

#text("2. To establish (4.16), I think we can just pass straight to an Euler product upper bound (taking into account prime powers ")#mi("p\\le x")#text(") since everything is multiplicative and non-negative.")

#text("3. (This is more of an observation) I think the convergence of the ")#mi("c^{\\prime\\prime}_\\epsilon")#text(" is assured by Cauchy-Schwarz and the bound from Proposition 4.2 (this shows ")#mi("c_\\epsilon^{\\prime\\prime} + O(\\epsilon)=O(1)")#text(", and the ")#mi("c^{\\prime\\prime}_\\epsilon")#text(" are increasing for the case ")#mi("F=G")#text(".")

#text("One very minor thing: I just wanted to check I followed the argument correctly. For the bound for ")#mi("L_{a,k}")#text(" at the top of page 31, I had something like ")#mi("K_{s,k}(F^{\\prime}_t)")#text(" instead of ")#mi("K_{a-t,k}(F_T)")#text(" (obviously this would work fine for the subsequent bound). Did I make a mistake?")

#text("James")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-306919")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2014")])]

#text("1. Ah, I see, yes, that would work, and would be conceptually simpler in that we then use the Selberg sieve exclusively for our sieve upper bounds and asymptotics. (Of course, the large sieve and Selberg sieve are very closely related in any case, but this would also make the paper more self-contained.)")

#text("2. Yes, this seems to work; I’m surprised I missed that and went for the more complicated combinatorial approach instead, but I think I was overly nervous about the non-squarefree contribution.")

#text("3. Yes, this can be inserted as a remark. I still feel there should be some more conceptual proof of the computation of the limit of c”_eps than what is given in the notes, though.")

#text("Finally – yes, you’re right, I had the wrong expression here (and on the next display).")

#text("I am not working currently on these sections, planning to look instead at the appendix on Type I estimates. Do you plan to edit in the changes you have found (there are also a lot of other typos and bad formatting to clean up, it is a zeroth draft right now)? Otherwise I can try to work in your comments (and do some other cleanup).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-306990")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2014")])]

#text("I’m planning on going through the section carefully to try to pick up most minor typos etc. I guess its easiest if I add in the above changes to the dropbox tex file when I make the other changes, and leave you to look at the other sections.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-306996")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2014")])]

#text("(I also keep on thinking there should be an `obvious’ approach for the integral identities, or maybe bootstrapping the fact we know it holds for F of small support, but I haven’t seen it. At least the current approach isnt too bad – the original sketch I had which was a horrendous mess)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-307000")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2014")])]

#text("OK, I won’t touch these sections until you’re done with them then.")

#text("I had an idea to try to prove the identities by first working in the case when F is a finite combination of exponential functions ")#mi("t \\mapsto \\exp(-ct)")#text(" in which case things are rather explicit, but in order to take the limit and arrive at general F, I needed to reproduce a large chunk of the machinery already in the paper to justify passage to the limit. Perhaps we can pose as an open problem the task of finding a more conceptual proof of these identities in the general case.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-307621")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2014")])]

#text("I added ")#link("http://arxiv.org/abs/1404.5094")[#text("On limit points of the sequence of normalized prime gaps")]#text(" to the wiki.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d10259e569f7948fb426f219171f06e13dc570f262d4c1ae121b4b024a8b1608-030659b4e829203ccdf0062ebabb0491445396a52c856fea3b1d5e19b723499e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of OMF")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-307867")[#strong[#text("OMF")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2014")])]

#text("Not to sound like a philistine, but when writing up the paper, I think some kind of “greater context” interpretation of the result is warranted. I say this because, since the methods used are fairly accessable, and the more advanced methods may end up being simplified over the years, future generations may end up considering bounded gaps as a standard fact about primes. So the paper should have a section explaining what mathematicians concepts of primes numbers were like before this result, and how the result changed them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-308105")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2014")])]

#text("In the recent preprint by Banks-Freiberg-Maynard (")#link("http://arxiv.org/abs/1404.5094")[#text("http://arxiv.org/abs/1404.5094")]#text(") equation (4.4) says that ")#mi("{M_k} > {\\log k + O(1)}")#text(", and that this result was derived as part of this PolyMath project. Where can I find the proof? I am only aware of the bound ")#mi("\\log k + O(\\log\\log\\log k)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-308122")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2014")])]

#text("I see, this bound is part of Theorem 3.9 in the draft paper.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-309485")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2014")])]

#text("In the assumption for theorem 3.2(xii), it should be GEH (instead of EH).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-311104")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2014")])]

#text("In the asymptotic analysis (below the proof of theorem 6.5), in the last integral estimate of ")#mi("W")#text(", it seems clearer to replace ")#mi("1+s")#text(" in the integrand denominator by ")#mi("1+s/2")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-311416")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2014")])]

#text("Perhaps it is even better to represent ")#mi("W")#text(" as the current integral (with ")#mi("1+s")#text(" in the integrand denominator) + o(1) (i.e. the current integral is the large k asymptotic of ")#mi("W")#text(").")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-314513")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2014")])]

#text("As the situation with the exponential sums (and hence, the best bounds for k and H for m=2,3,4,5) are still in flux (but Phillipe tells me he is going to meet with Emmanuel Kowalski and Paul Nelson soon to try to sort things out), I’m starting to work on other sections that are not directly impacted by this issue. I’ve written up a brief section on the parity problem obstruction, and now plan to write on the M_k bounds for k=3,4,50,53, and trying to glue in what Pace and Ignace have written on these topics.")

#text("On a separate point: I’ve received an offer from Ken Ono to submit this forthcoming Polymath paper to a new open access journal that he is editor of, Research in the Mathematical Sciences ")#link("http://www.resmathsci.com/")[#text("http://www.resmathsci.com/")]#text(" . Another option would be to submit to the same journal (Algebra & Number Theory) that Polymath8a was submitted to (but the refereeing process for that journal is not concluded yet). In any event, we are still many weeks away from having a submittable form of the paper, so there is no urgency to decide yet where to send it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-316108")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2014")])]

#text("My goodness, why on earth does Springer ask for ridiculous formatting constraints on articles submitted to RitMS? And the section headings? And the totally insane detailed referencing style commandments? Someone didn’t check that mathematics articles aren’t the same as articles in experimental sciences. (rant over)")

#text("On a less hysterical note, the style of the journal appears to be such that (sub)sections aren’t numbered. This is a backwards step in my opinion. But I’m not in a position to make this decision, but I applaud the option of an open access journal.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-315084")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2014")])]

#text("I’ve modified introduction.tex, subtheorems.tex and sieving.tex in the dropbox folder.")

#text("I’ve made a number of very minor changes alongside the variations we already talked about. Most of these are just slight rewording or reformatting or correcting a typo. Anything where I’ve tried to make a slightly more significant change I’ve marked with a comment of the form %%JM. Of course, many of these are based on my subjective preferences and anyone is completely free to change anything if they prefer to present it in a different way.")

#text("I’m away next week, but the week after I should be free to start going through the later sections which are written up.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-315334")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2014")])]

#text("The “")#mi("d r")#text("” in (6.15) should be in (6.14).")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-315653")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2014")])]

#text("It seems that certain formula numbering in the following text should be updated.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-318129")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2014")])]

#text("More precisely, it seems that (because of the above correction) in each reference (in the text) to an equation below (6.14), its number should be shifted backward by 1.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-316502")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2014")])]

#text("Typographical comments to the paper:")

#text("(1) One should use “\\colon” instead of “:” in maps to get the correct horizontal spacing. (Example: ")#mi("f \\colon A \\to B")#text(".)")

#text("(2) One should use “\\coloneqq” from the mathtools package instead of “:=” in definitions to avoid bad linebreak among other things.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-317794")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2014")])]

#text("On the monotonicity of ")#mi("M_k")#text(":")

#text("Let ")#mi("k \\geq 3")#text(". Define ")#mi("F")#text(" on ")#mi("\\mathcal R_k")#text(" by")

#text("(1) ")#mi("F(t_1, ... , t_k) := f(t^{\\prime}_1, ... , t^{\\prime}_{k-1}) g(t_k)")

#text("where ")#mi("f \\in L^2(\\mathcal R_{k-1}), g \\in L^2(0,1)")#text(", and")

#text("(2) ")#mi("t^{\\prime}_i := \\frac {t_i}{1 - t_k} , i = 1, ... , k-1")

#text("It follows that for ")#mi("i = 1, ... , k-1")

#text("(3) ")#mi("J_k^{(i)}(F) = J_{k-1}^{(i)}(f) \\int_0 ^1 (1-t)^k g(t)^2 d t")

#text("Since ")#mi("J_k^{(k)}(F) \\geq 0")#text(", summation over ")#mi("i")#text(" gives")

#text("(4) ")#mi("J_k(F) \\geq J_{k-1}(f) \\int_0^1 (1-t)^k g(t)^2 d t")

#text("It is easy to verify that")

#text("(5) ")#mi("I_k(F) = I_{k-1}(f) \\int_0^1 (1-t)^{k-1} g(t)^2 d t")

#text("By taking ")#mi("g(t) = 1_{[0, \\epsilon]}(t)")#text(" for ")#mi("\\epsilon \\in (0, 1)")#text(", the ratio between the integrals in (4), (5) tends to 1 as ")#mi("\\epsilon")#text(" tends to 0. Implying")

#text("(6) ")#mi("J_k(F)/ I_k(F) \\geq J_{k-1}(f)/ I_{k-1}(f)")

#text("Hence (by taking the supremum over ")#mi("f")#text(")")

#text("(7) ")#mi("M_k \\geq M_{k-1}")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-317861")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2014")])]

#text("Correction: the RHS of (6) should be multiplied by")#linebreak()#text(" ")#mi("1+O(\\epsilon)")#text(" (which is the ratio between the integrals in (4), (5)).")#linebreak()#text(" So (7) follows by both taking the supremum over ")#mi("f")#text(", and letting ")#mi("\\epsilon")#text(" tend to 0.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-319900")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2014")])]

#text("Using the new code for fast admissibility testing (available on the wiki), I was able to improve three of the bounds in the current records table.")

#text("Under the 1080/13*varpi+330/13*delta < 1 constraint we have:")

#text("m=5, k0=3,400,000,000, H=81,973,172,502.")

#text("The bound on H uses the tuple p_{n+1},…,p_{n+k0} with n=13,179,173.")

#text("Under the Deligne-free 168*varpi+48*delta < 1 constraint we have:")

#text("m=4, k0=105,754,838, H=2,165,674,446;")#linebreak()#text(" m=5, k0=5,300,000,000, H=130,235,143,908.")

#text("Here the bounds on H use the tuple p_{n+1},…,p_{n+k0} with n=623,411 and n=19,662,782, respectively. To verify these result, compile the fast admissibility testing code and run")

#text("zhangverify 3400000000 13179173")#linebreak()#text(" zhangverify 105754838 623411")#linebreak()#text(" zhangverify 5300000000 19662782")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-320005")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2014")])]

#text("I’m unclear as to how the values for k are being optimised for m greater than 1. In the Maple code, how are you and xfxie finding the best values for c and T ? – does the end result vary smoothly enough that simple interpolation suffices? Also, in the expression that defines g, should the “t” actually be “T” ? (Not knowing or having Maple I don’t know whether case matters, but it seems worth asking!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-320032")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2014")])]

#text("Maple is case sensitive. The lower case t in the definition of g is a symbolic variable that is being integrated over the interval [0,T], as in the script Terry originally ")#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257994")[#text("posted")]#text(" (so g=g(t) is really a function of t).")

#text("The values of k0 I obtained were found by sampling a grid of (c,T) values — interpolating didn’t seem to work that well, the bounds do not vary as smoothly as one might like. But xfxie may be doing something more clever than this.")

#text("Certainly the m=5 bounds k0=3400000000 and the Deligne-free k0=5300000000 can be improved, and I suspect there is still room for improvement in some of the others.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-320036")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2014")])]

#text("Many thanks Drew. I see now – g is basically a macro that is expanded in the subsequent lines.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-322560")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2014")])]

#text("I just reimplemented Terry’s k-validating Maple script in Mathematica and embedded it in a fairly naive hill-climbing algorithm, so as to get good values for m=5, and I checked all other cases too. I think my only other improvements over already-determined values are for m=2, 3 and 4 with no Deligne, on which I don’t think xfxie ever reported. All values reported by xfxie are the same as I get – which I guess constitutes not only validation, but also circumstantial evidence that there are probably no other values of c and T that allow smaller k. Since the previous reports are scattered over so many posts, here is a full tabulation:")

#text("1080/13, 330/13 (provisional, unconditional, Deligne)")#linebreak()#text(" m=2: 35146")#linebreak()#text(" 3: 1628943")#linebreak()#text(" 4: 74487363")#linebreak()#text(" 5: 3393468735 with c=0.04593783, T=0.0340499")

#text("600/7, 180/7 (confirmed, unconditional, Deligne)")#linebreak()#text(" m=2: 35410")#linebreak()#text(" 3: 1649821")#linebreak()#text(" 4: 75845707")#linebreak()#text(" 5: 3473955908")

#text("168, 48 (confirmed, unconditional, no Deligne)")#linebreak()#text(" m=2: 41697 with c=0.0935, T=0.08025 (eclipsed by 41588 from m=4[EH])")#linebreak()#text(" 3: 2113163 with c=0.06893, T=0.05518")#linebreak()#text(" 4: 105754479 with c=0.0544852, T=0.04183")#linebreak()#text(" 5: 5274206963 with c=0.0450055, T=0.0336093")

#text("4, 0 (confirmed, conditional on EH)")#linebreak()#text(" m=2: 698 (eclipsed by other methods, obviously)")#linebreak()#text(" 3: 5511")#linebreak()#text(" 4: 41588")#linebreak()#text(" 5: 309661")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-323235")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2014")])]

#text("Thanks for this Aubrey. Here are H bounds corresponding to your improved k0 values:")

#text("provisional, unconditional, Deligne:")

#text("m=5, k0=3,393,468,735, H=79,929,339,154")

#text("confirmed, unconditional, no Deligne:")

#text("m=3, k0=2,113,163, H=")#link("http://math.mit.edu/~drew/admissible_2113163_32588668.txt")[#text("32,588,668")]#linebreak()#text(" m=4, k0=105,754,479, H=2,111,597,632")#linebreak()#text(" m=5, k0=5,274,206,963, H=126,630,432,986")

#text("The bounds for m > 3 all correspond to Hensley-Richards tuples. They can be verified using:")

#text("hrverify 105754479 659165")#linebreak()#text(" hrverify 3393468735 13773747")#linebreak()#text(" hrverify 5274206963 20369534")

#emph[#text("[Results added, though it seemed the k=3 results do not improve upon your previous result at ")#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258810")[#text("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258810")]#text(" ]")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-323271")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2014")])]

#text("Thanks back! Out of interest, what is your current assessment of the prospects for going beyond Hensley-Richards for the larger values of k?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-323339")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2014")])]

#text("It should be feasible to do an asymmetric version of Hensley-Richards, although I suspect the gain will be fairly small. If I have time I’ll try to take a look at this next week.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-324199")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2014")])]

#text("Terry: is there any straightforward option for further tightening the derivation of lower bounds for M_k that your Maple script implements? I ask mainly because my (and probably xfxie’s) technology for finding the minimal k seems to be fast enough to justify experimenting with more complex computations, in the event that any steps in your current derivation exist just for simplicity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-325584")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2014")])]

#text("There is some room to make some small improvements in this regard, although it would only affect the m=2,3,4,5 bounds and not the m=1 bound, so it has not been a priority thus far (and also I suspect that there may be a completely different way to generate lower bounds for M_k that may be significantly more efficient). I’m somewhat busy this week, but I’ll try to revisit that part of the paper and see if there are any “cheap” improvements that don’t require significant additional justification.")

#text("Incidentally, there was some issue with previous dropbox links to the paper, so I’ve generated a fresh one at ")#link("https://www.dropbox.com/sh/0xb4xrsx4qmua7u/tfwv3_O_WY/Polymath8b/newergap.pdf")[#text("https://www.dropbox.com/sh/0xb4xrsx4qmua7u/tfwv3_O_WY/Polymath8b/newergap.pdf")]#text(" (with directory at ")#link("https://www.dropbox.com/sh/0xb4xrsx4qmua7u/WOhuo2Gx7f/Polymath8b")[#text("https://www.dropbox.com/sh/0xb4xrsx4qmua7u/WOhuo2Gx7f/Polymath8b")]#text(" ).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-324263")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2014")])]

#text("Here is a better tuple for the m=3 unconditional no-Deligne case:")

#text("m=3, k0=2,113,163, H=")#link("http://math.mit.edu/~drew/admissible_2113163_32285928.txt")[#text("32,285,928")]#text(".")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-321171")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2014")])]

#text("I just posted updated fast admissibility testing code to the wiki that now handles Hensley-Richards tuples")

#mi("\\{-p_{n+\\lfloor k_0/2\\rfloor - 1}, \\ldots, -p_{n+1}, -1, 1, p_{n+1},\\ldots, p_{n+\\lfloor (k_0+1)/2\\rfloor-1}\\}.")

#text("This yields improved bounds on H for all the m=4,5 cases.")

#text("Under the 1080/13*varpi+330/13*delta < 1 constraint we now have")

#text("m=4, k0=74,487,363, H=1,460,493,420")#linebreak()#text(" m=5, k0=3,400,000,000, H=80,088,836,006")

#text("Under the weaker 600/7*varpi+180/7*delta < 1 constraint we get")

#text("m=4, k0=75,845,707, H=1,488,227,220")#linebreak()#text(" m=5, k0=3,473,955,908, H=81,912,638,914")

#text("Under the Deligne-free 168*varpi+48*delta < 1 constraint we get")

#text("m=4, k0=105,754,838, H=2,111,605,786")#linebreak()#text(" m=5, k0=5,300,000,000, H=127,277,395,046")

#text("To verify the above results, compile the fast admissibility testing code and then use")

#text("hrverify 74487363 492570")#linebreak()#text(" hrverify 75845707 492570")#linebreak()#text(" hrverify 105754838 659165")#linebreak()#text(" hrverify 3400000000 13773747")#linebreak()#text(" hrverify 3473955908 14132283")#linebreak()#text(" hrverify 5300000000 20479497")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-322203")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2014")])]

#text("I was working on Section 7.1 (lower bounds on ")#mi("M_k")#text(" for medium k, such as k=50 and k=54 and realised that I don’t fully understand how the integrals")

#mi("\\int_{{\\mathcal R}_k} b_i(t_1,\\dots,t_k) b_j(t_1,\\dots,t_k)\\ dt_1 \\dots dt_k")#text(" (*)")

#text("and also the more complicated")

#mi("\\int_{t_1+\\dots+t_k,t_1+\\dots+t_{k-1}+t^{\\prime}_k} b_i(t_1,\\dots,t_k) b_j(t_1,\\dots,t_{k-1},t^{\\prime}_k)\\ dt_1 \\dots dt_k dt^{\\prime}_k")#text(" (**)")

#text("are computed numerically when the ")#mi("b_i")#text(" are functions of the form ")#mi("(1-P_1)^a P_\\alpha")#text(" for some signature ")#mi("\\alpha")#text(" consisting of even exponents. (Firstly, just to clarify: is ")#mi("P_\\alpha")#text(" the sum of all distinct monomials which are permutations of ")#mi("t_1^{\\alpha_1} \\dots t_k^{\\alpha_k}")#text("?) There is a beta function identity to integrate pure monomials (Lemma 7.2 in the current draft), is the idea just to decompose into pure monomials?")

#text("I was thinking about a possible alternate approach to ")#mi("M_k")#text(" and ")#mi("M_{k,\\varepsilon}")#text(" (but I’ll focus here on ")#mi("M_k")#text(" for simplicity), in which one works with ")#mi("b_i")#text(" of the form ")#mi("P_1^{a_1} \\dots P_d^{a_d}")#text(" where ")#mi("P_d = \\sum_{i=1}^k t_i^d")#text(" are the sum of the d^th powers. The point here is that multiplication is very easy, and (for the sum (*) at least) one is reduced to computing integrals of the form")

#mi("\\int_{{\\mathcal R}_k} P_1^{a_1} \\dots P_d^{a_d}.")

#text("The integrand has total degree ")#mi("D := a_1 + \\dots + da_d")#text(", and so one can also rewrite this as")

#mi("\\frac{1}{(D+k)!} \\int_{[0,+\\infty)^k} P_1^{a_1} \\dots P_d^{a_d} e^{-t_1-\\dots-t_k}")

#text("which one can also write as")

#mi("\\frac{1}{(D+k)!} \\frac{\\partial^{a_1}}{\\partial s_1^{a_1}} \\dots \\frac{\\partial^{a_d}}{\\partial s_d^{a_d}} (\\int_0^\\infty \\exp( - t + s_1 t + \\dots + s_d t^d )\\ dt)^k.")

#text("If d is relatively small, say d=10, then perhaps we can compute enough terms of the Taylor series of ")#mi("\\int_0^\\infty \\exp(-t + s_1 t + \\dots + s_d t^d)\\ dt")#text(" in ")#mi("s_1,\\dots,s_d")#text(", and then raise to the ")#mi("k^{th}")#text(" power to extract all the relevant structure constants. But I’m not sure if this is much of a speedup over the existing methods (I’m a bit unclear as to what the bottleneck is.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-322289")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2014")])]

#text("First, yes, ")#mi("P_{\\alpha}")#text(" is the sum of all distinct monomials which are permutations of ")#mi("t_1^{\\alpha_1}\\cdots t_k^{\\alpha_k}")#text(" where ")#mi("\\alpha =(\\alpha_1,\\ldots,\\alpha_k)")#text(".")

#text("Second, again yes, the idea is to just get a pure monomial (possibly with a factor of ")#mi("(1-P_1)^a")#text(" attached) in order to apply the beta function identity.")

#text("Third, finding the relevant structure constants for a simple product ")#mi("P_{\\alpha}P_{\\beta}")#text(" is now very fast, and is not a bottleneck.")

#text("The current bottleneck is actually using the beta-function identity, after first integrating out one variable and squaring (i.e. finding the integrals in the more complicated case) to compute (the exact) rational entries for one of the large matrices corresponding to the quadratic form. It may be the case that this could be sped up. I haven’t taken a look at the code for a while now.")

#text("I have not checked exactly which step is the slowest, but my impression was it occurs when adding a whole bunch of relatively large rational numbers together during the matrix formation stage. [When we apply the beta function identity, after integrating and squaring, there are sometimes a lot of terms, with very big and distinct denominators.] I’ll try to double-check this on Monday (and I wouldn’t mind anyone else taking a look at the code if they have the time).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-322470")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2014")])]

#text("That clarifies things, thanks!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-325278")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2014")])]

#text("It should be remarked that the two matrices needed for")#linebreak()#text(" ")#mi("M_{k, \\epsilon}")#text(" computation may be computed using symbolic ")#mi("\\epsilon")#text(" (since their elements are polynomials in ")#mi("\\epsilon")#text(").")#linebreak()#text(" So they have a representation of the form")

#text("(1) ")#mi("\\sum_d A_d \\epsilon ^d")

#text("with computable matrices ")#mi("A_d")#text(".")

#text("Therefore (using the above matrix representation), there is no need to repeat the numerical computation of the two matrices for each ")#mi("\\epsilon")#text(" (during ")#mi("\\epsilon")#text(" optimization).")

#text("Remark: it may be easier to compute a representation of the form")

#text("(2) ")#mi("\\sum_{i, j} A_{i, j} (1-\\epsilon)^i (1+\\epsilon)^j")

#text("with appropriate (computable) matrices ")#mi("A_{i,j}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/775b164a9fb4ce525531203b392d21f78c3e5fd2c13250dd11a801e48b387ca7-ec3592175e5a9ed760cf0c07a519f84fd8d53989a9765024062737440910c6af.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ignace Bogaert")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-330323")[#strong[#text("Ignace Bogaert")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2014")])]

#text("Hi, I just wanted to point out that the type of symmetric polynomials discussed above:")

#mi("P_d = \\sum_{i = 1}^{k} t_i^d")

#text("was also used (inspired by the comments on this blog) in my calculations for ")#mi("M_k")#text(". The integrals that one encounters")

#mi("\\int_{\\mathcal{R}_k} P_{1}^{a_1} ... P_{d}^{a_d}")

#text("were computed as explicit functions of ")#mi("k")#text(", by means of a recurrence formula between the various integrals. Now, in my code, the integrals were all recursively computed and stored, which eventually led to very high memory requirements (each integral was a polynomial in ")#mi("k")#text("). Perhaps your neat trick with the Taylor series can help in this regard, by recursively computing the integrals for specific ")#mi("k")#text(". Storing values instead of polynomials should require less memory and may allow a somewhat higher degree than my code currently does.")

#text("I also have a question: has anyone constructed the eigenfunction (analytically, if possible) that realizes the maximal value for ")#mi("M_{2,\\varepsilon}")#text("? For ")#mi("\\varepsilon = 0")#text(", this function and its associated eigenvalue are known, but I have been unable to find a similar result for nonzero ")#mi("\\varepsilon")#text("…")

#text("Edit: I have not yet sought very hard for this eigenfunction, I just did not immediately find it on this blog.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-330671")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2014")])]

#text("Thanks for the remark! As far as I am aware the eigenfunction for ")#mi("M_{2,\\varepsilon}")#text(" has not been computed. Eytan has some calculations for the analogue of ")#mi("M_{k,\\varepsilon}")#text(" when the function F is of the one-dimensional form ")#mi("F(t_1,\\dots,t_k) = f(t_1+\\dots+t_k)")#text(", but these do not come close to optimising ")#mi("M_{k,\\varepsilon}")#text(" when ")#mi("F")#text(" is not constrained to be one-dimensional in nature.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/775b164a9fb4ce525531203b392d21f78c3e5fd2c13250dd11a801e48b387ca7-ec3592175e5a9ed760cf0c07a519f84fd8d53989a9765024062737440910c6af.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ignace Bogaert")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-330705")[#strong[#text("Ignace Bogaert")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2014")])]

#text("Thanks back! I may try and look into that, for use as a test case for the numerical equivalent.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/115a332737d466127e666b8bc76f421d6e2ee17a59eeafc2753c8727496919bf-165537e46b4e183b31dbd59ed5f40a44cf0e8f137fae6d455a1f4e32c46e4306.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ignace Bogaert")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-341297")[#strong[#text("Ignace Bogaert")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2014")])]

#text("I have now done some analytical calculations for the eigenfunction associated with ")#mi("M_{2,\\varepsilon}")#text(" (I do hope I did not make any obvious mistakes). It turns out that the calculations do not become more difficult, but just more involved. You can find it at the following link: ")#link("http://users.ugent.be/~ibogaert/KrylovMk/M2eps.pdf")[#text("http://users.ugent.be/~ibogaert/KrylovMk/M2eps.pdf")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-342129")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2014")])]

#text("This very interesting solution has the properties:")

#text("1. For each ")#mi("\\epsilon \\in [0, 1)")#text(", ")#mi("q")#text(" is analytic on")#linebreak()#text(" ")#mi("(0, 1 - \\epsilon)")#text(" – implying that the eigenfunction ")#mi("F")#text(" is real analytic on its support, except on the jump singularities on the intersection of the lines ")#mi("x = 1-\\epsilon")#text(" and ")#mi("y=1-\\epsilon")#text(" with ")#mi("F")#text(" support.")

#text("2. The threshold ")#mi("\\epsilon = 1/3")#text(" is probably related to the same threshold ")#mi("\\epsilon = 1/(2 k -1) =1/3")#text(" above which ")#mi("F")#text(" has a reduced support ")#mi("R^{\\prime}")#text(" (i.e. ")#mi("F")#text(" vanishes on a certain inner triangle ")#mi("S")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-342295")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2014")])]

#text("Very nice! I’ve added a summary of your results to Section 6 of the draft paper. I’m going through the paper now to try to clean it up and move it closer to a publishable state; hopefully I can be done in a few days (modulo some remaining gaps, such as Appendix A) and then I will roll over the thread.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-330776")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2014")])]

#text("In a previous comment, it was remarked that any optimal function for the ")#mi("M_{k, \\epsilon}")#text(" value must vanish on a certain inner simplex (defined by ")#mi("\\inf_{i=1,\\dots,k} \\sum_{j \\neq i} t_j \\ge 1-\\epsilon")#text(") of ")#mi("(1+\\epsilon)  \\mathcal R_k")#text(" – since the functionals ")#mi("J_{i, 1-\\epsilon}, i=1,...,k")#text(" do not(!) depend on the function ")#mi("F")#text(" values on this inner simplex.")#linebreak()#text(" Therefore, any such optimal ")#mi("F")#text(" can’t be real-analytic (and in particular polynomial) over the whole simplex ")#mi("(1+\\epsilon) \\mathcal R_k")#text(".")#linebreak()#text(" This explains why the convergence to ")#mi("M_{k, /epsilon}")#text(" is very slow by using polynomials (which do not vanish on this inner simplex as the optimal function does.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-332636")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2014")])]

#text("This gives the following generalization of Ignace polynomial basis method for the case of ")#mi("M_{k, \\epsilon}")#text(" computation:")

#text("Let ")#mi("R := (1+\\epsilon)\\mathcal R_k")#text(" and")

#mi("R^{\\prime} := R \\setminus S")

#text("where ")#mi("S")#text(" denotes the inner simplex above (on which the optimal ")#mi("F")#text(" should vanish). Clearly, ")#mi("S")#text(" is the intersection of ")#mi("k")#text(" half-spaces defined by")#linebreak()#text(" ")#mi("\\sum_{j \\neq i} t_j > 1-\\epsilon, i= 1, ... ,k")#text(" and an additional half-space defined by ")#mi("\\sum_i t_i  0")#text(" and")

#mi("\\sum_i s_i < (k-1)(1+\\epsilon) - k(1-\\epsilon)")

#text("i.e. in terms of the new variables ")#mi("s_1, \\dots , s_k")#text(", the set ")#mi("S")#text(" is the simplex ")#mi("((2 k -1) \\epsilon - 1)\\mathcal R_k")#text(" – showing that the simplex ")#mi("S")#text(" is empty(!) for ")#mi("\\epsilon < 1/(2 k -1)")#text(".")

#text("So the integral over ")#mi("S")#text(" should be easy (using also the constant Jacobian of the transformation to the variables ")#mi("s_1, ... , s_k")#text(".)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-332725")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2014")])]

#text("It seems that the same problem appeared again (the same(!)s lines in the middle of my last comment above were deleted again). So I’ll try here to give them:")

#text("1. In line 8, after “… and an additional half-space defined by”, it should be")

#mi("\\sum_i t_i  0")#text(", and")

#mi("\\sum_i s_i < (k-1)(1+\\epsilon) - k(1-\\epsilon)")

#text("2. The last five lines in my comment above (starting with \"i.e. in terms of …) should remain.")

#text("[")#emph[#text(" Unfortunately I can’t recover the text between ")#mi("\\sum_i t_i")#text(" and 0. Use &lt; and &gt; instead of < and > to avoid text between < and > from being interpreted as HTML. Or, email me the relevant text and I will paste it in. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-332771")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2014")])]

#text("The problem appeared again! it seems to be a latex problem, so I’ll try to concentrate on the main points:")

#text("1. Since the optimal ")#mi("F")#text(" is supported on ")#mi("R^{\\prime}")#text(", the basic idea is to approximate ")#mi("F")#text(" by polynomials supported on ")#mi("R^{\\prime}")#text(". i.e approximating ")#mi("F")#text(" by ")#mi("1_{R^{\\prime}} P")#text(" where ")#mi("P")#text(" is a polynomial.")

#text("2. The important observation is that for functions ")#mi("F")#text(" supported on ")#mi("R^{\\prime}")#text(" we have")

#mi("\\mathcal L_{k, \\epsilon} F = 1_{R^{\\prime}} \\sum_i \\int_0^{\\infty} F d t_i")

#text("In particular, it follows that repeated applications of this operator (starting with ")#mi("1_{R^{\\prime}}")#text(" – as in Ignace method) generate a sequence of polynomials supported on ")#mi("R^{\\prime}")#text(" and converging to the optimal ")#mi("F")#text(". This is the desired generalization of Ignace method for ")#mi("M_{k, \\epsilon}")#text(" computation!")

#text("3. The needed inner products should be now on ")#mi("L^2(R^{\\prime})")#text(" (instead of ")#mi("L^2(R)")#text(") and can be computed for polynomials")#linebreak()#text(" ")#mi("P,Q")#text(" by")

#mi("\\int_{R^{\\prime}} P Q = \\int_R P Q - \\int_S P Q")

#text("So we need only to compute integrals of polynomials over ")#mi("S")#text(" – which can be done efficiently using the new variables")

#mi("s_i := \\sum_{j \\neq i} t_j - (1- \\epsilon), i = 1, ..., k")

#text("In terms of the new variables the simplex ")#mi("S")#text(" is given as in the above comment (note that ")#mi("S")#text(" is empty(!) for")#linebreak()#text(" ")#mi("\\epsilon < 1/(2 k -1)")#text(") so the integration of polynomials over ")#mi("S")#text(" can be done efficiently (using the constant Jacobian of the transformation).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-334336")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2014")])]

#text("Let ")#mi("R, S, R^{\\prime}")#text(" defined as in my comment above. It is easy to verify that for each function ")#mi("F")#text(" supported on ")#mi("R")#text(", it follows that ")#mi("\\mathcal L_{k, \\epsilon} F")#text(" is supported on ")#mi("R^{\\prime}")#text(" (i.e. vanishes on the inner simplex ")#mi("S")#text(") which is not surprising (since repeated application of this operator should converge to the optimal ")#mi("F")#text(" which is supported on ")#mi("R^{\\prime}")#text("). But now it seems to me that the the simplified representation of this operator for functions supported on ")#mi("R^{\\prime}")#text(", as claimed in my comment above, may be wrong!")#linebreak()#text(" Therefore, unfortunately, the basis functions generated by this operator can be piecewise polynomials (not necessarily polynomials over ")#mi("R^{\\prime}")#text(" – as claimed in my comment above.)")

#text("But we can still improve the current lower bounds for ")#mi("M_{k, \\epsilon}")#text(" by working with polynomials supported on ")#mi("R^{\\prime}")#text(", so the denominator functional for a polynomial ")#mi("P")#text(" should be")

#mi("I(P) = \\int_{R^{\\prime}} P^2 = \\int_R P^2 - \\int_S P^2")

#text("which is smaller(!) than the current denominator ")#mi("\\int_R P^2")

#text("As remarked in my comment above, the elements of the matrix representing the new denominator ")#mi("I(P)")#text(" can be computed efficiently.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/775b164a9fb4ce525531203b392d21f78c3e5fd2c13250dd11a801e48b387ca7-ec3592175e5a9ed760cf0c07a519f84fd8d53989a9765024062737440910c6af.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ignace Bogaert")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-335367")[#strong[#text("Ignace Bogaert")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2014")])]

#text("Thanks, Eytan, for all your thoughts on this. Indeed, it seems that any polynomial is quickly turned into a piecewise polynomial by the repeated application of ")#mi("\\mathcal{L}_{k,\\varepsilon}")#text(". The integration in ")#mi("\\int_{0}^{\\infty} 1_{R^{\\prime}} F dt_i")#text(" produces a piecewise function with its pieces differing from the original one $1_{R’}$. After summing over ")#mi("i")#text(", the function is no longer analytic times ")#mi("1_{R^{\\prime}}")#text(", which is quite unfortunate…")

#text("I think your point about the denominator is an excellent one. Perhaps this will allow the further lowering of ")#mi("k")#text(", without necessarily increasing the degree of the polynomial basis.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-336057")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2014")])]

#text("Thanks for your response!")#linebreak()#text(" In fact, I think that the polynomial convergence rate in ")#mi("L^2(R^{\\prime})")#text(" to the optimal function ")#mi("F")#text(" should depend strongly on the types of possible singularities of ")#mi("F")#text(" inside ")#mi("R^{\\prime}")#text(".")

#text("Since ")#mi("R^{\\prime} = R")#text(" (i.e. the inner simplex ")#mi("S")#text(" is empty) exactly for ")#mi("\\epsilon \\leq 1/(2 k -1)")#text(", it seems that the current method should converge much faster for such ")#mi("epsilon")#text(" values than for ")#mi("\\epsilon")#text(" values above the threshold ")#mi("1/(2 k -1)")#text(".")

#text("This assumption on the dependence of the convergence rate on the values of ")#mi("\\epsilon")#text(", if numerically confirmed, should indicate that the presence of the inner simplex ")#mi("S")#text(" is the main obstruction for fast convergence of the current method (without denominator modification).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-322604")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2014")])]

#text("There was some interest a while back in finding the simplest set of polynomials that would give M_3>2 under GEH using the partitioned half-cube. At that time I posted a set that aimed to minimise the number of monomials (81), but perhaps a more intuitive measure is to minimise the absolute value of the largest coefficient under the constraint that all coefficients are integer. That seems to need somewhat more monomials (97), but unlike the monomial-minimising version it uses only monomials of total degree at most 3. Here’s my best try, with M checked using Pace’s Mathematica code (I don’t have Maple to do the cross-check, unfortunately); I used epsilon=1/4 so as to eliminate the M6 and M8 constraints.")

#text("FA = -268+393 x-602 x^2+528 x^3+527 y-500 x y+426 x^2 y-1170 y^2+1652 y^3+406 z-237 x z+234 x^2 z-400 y z+199 x y z+245 y^2 z-461 z^2+90 x z^2+271 y z^2+207 z^3")

#text("FB = -166+211 x-298 x^2+102 x^3+444 y-272 x y+284 x^2 y-1221 y^2+243 x y^2+1526 y^3+134 z+63 x z+89 x^2 z-163 y z-176 x y z+308 y^2 z-146 z^2-97 x z^2+98 y z^2+82 z^3")

#text("FC = -89+184 x-145 x^2+257 y-406 x y+338 x^2 y-575 y^2+214 x y^2+742 y^3")

#text("FE = -51+36 x+136 y")

#text("FG = 21105-79320 x+74220 x^2-20480 x^3-71976 y+178336 x y-82368 x^2 y+64428 y^2-75840 x y^2-18304 y^3-42828 z+107408 x z-50304 x^2 z+97616 y z-121088 x y z-43776 y^2 z+28964 z^2-36352 x z^2-33088 y z^2-6528 z^3")

#text("FH = 32 z")

#text("FS = -27+36 x+72 y")

#text("FT = 66-107 x+42 x^2+176 y-92 x y-264 y^2-176 z+130 x z+88 z^2")

#text("FU = 370-7360 x+23485 x^2-20480 x^3+240 y-1192 x^2 y+420 y^2+5760 x z-9716 x^2 z-768 y^2 z-508 z^2-1088 x z^2+256 z^3")

#text("Intriguingly, M=1.99 can be achieved with the following much simpler set:")

#text("FA = 53 – 45x – 31y – 35z")

#text("FB = 29 – 19x – 29y – 9z")

#text("FC = 18 – 20x – 17y")

#text("FE = 6")

#text("FH = -6")

#text("FG = FS = FT = FU = 0")

#text("which arguably suggests that a modest amount of additional partitioning of FG and possibly FU, allowing them to be handled by two or three polynomials rather than one, could allow for considerably simpler polynomials to reach M=2. I have insufficient understanding of the partitioning process to be able to explore this, unfortunately.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-327123")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2014")])]

#text("What is the M-value for the above piecewise polynomial? (if it is very close to 2, than the coefficients can’t vary much – so they must have a minimal number of digits. Perhaps the larger number of digits in the coefficients of FG and FU is really needed to satisfy the marginal vanishing conditions.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-322869")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2014")])]

#text("I’m sorry many times,proving H=2 in October.2014,(not August).That’s an earthquake in maths.I bet all the world.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd4ee11e9561e0992302bd40eebde537c101ae33a0d92d3b7989b023a3a577d3-e0c8a4a37da773f1e33327b33382bbc603cf1f00fe1c2f1d21297f602e424cd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alastair Irving")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-325477")[#strong[#text("Alastair Irving")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2014")])]

#text("A few corrections to Section 3:")

#text("1. At the start of section 3:")#linebreak()#text(" “Recall that for any ")#mi("k_0 \\in \\mathbb{N}")#text("”")#linebreak()#text(" ")#mi("k_0")#text(" should be ")#mi("k")#text(".")

#text("2. IN Theorem 3.2 part (xi) it should be DHL[k,m+1] not DHL[k,m].")

#text("3. The ")#mi("\\log_x n")#text(" in (3.6) must be wrong, should it be ")#mi("\\log_x d")#text("?")

#text("4. In Theorem 3.5, the definition of ")#mi("c")#text(", it should presumably be ")#mi("F^{\\prime}_i")#text(" not ")#mi("F^{\\prime}")#text(" and ")#mi("G^{\\prime}_i")#text(" not ")#mi("G^{\\prime}_{i^{\\prime}}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd4ee11e9561e0992302bd40eebde537c101ae33a0d92d3b7989b023a3a577d3-e0c8a4a37da773f1e33327b33382bbc603cf1f00fe1c2f1d21297f602e424cd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alastair Irving")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-325509")[#strong[#text("Alastair Irving")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2014")])]

#text("Lemma 4.1 doesn’t make sense as there is no N on the LHS. I’m guessing there’s a missing constraint on the summation.")

#emph[#text("[Corrected, thanks – T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-326155")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2014")])]

#text("Terry: I just saw your Remark 7.4 in the draft paper. I don’t have the explicit polynomial giving M_4,epsilon=2.05411, I’m afraid: I obtained that value by modifying Pace’s code for k=53 (the version that’s in the dropbox as DegreeOptimizer-2014-02-13-BiggerRegion5.nb), and I can’t immediately see how to extract monomials from the rationalised eigenvector with that code – maybe Pace can. (Pace: if so, possibly we can resolve the outstanding question of whether it is safe to let the degree equal k when k is even. I printed the rationalised eigenvector and notice that its last element is always zero when d=k – is that a clue?) The value 2.05411 is obtained by evaluating Output[4,3,0,5/21]; Output[4,4,0,11/48] (if confirmed safe) is 2.06292. (Note: in looking into this I noticed an error in my post of March 4th, namely that the optimised epsilon that I stated, 0.2294921875, was actually for the quartic computation rather than the cubic one. Terry, please change it to 5/21 in the Remark – thanks.]")

#text("Concerning the last sentence in Remark 7.4, Pace’s same code can be used to get values for k=3; sure enough, Output[3,3,0,56/113] gives 1.91726.")

#text("Also, I realised that “zstart”, the third parameter to Output, which is the power of (1-P1) in the overall polynomial, was always 0 in my tests (including those reported above). The code throws errors for me when I set zstart=k, but not when zstart=k-1. Is it OK to have d+zstart greater than k? I suspect it is, because the best I get with Output[3,1,2,8/33] is 1.87392, just minutely less than the value of 1.87459 that you showed to be optimal when F is not restricted to be a polynomial, and similarly Output[4,1,3,2/11] is 2.01836 versus 2.01869 (twice as close as in the k=3 case – does this constitute encouragement that polynomials are all we need to investigate?) – but please confirm. If so, we can obtain the following marginally better values:")

#text("Output[4,3,3,7/29] = 2.05957")#linebreak()#text(" Output[4,4,3,17/67] = 2.06913 (just in case Pace determines that d=k=4 is indeed OK)")#linebreak()#text(" Output[3,3,2,20/39] = 1.91988")

#text("[In case anyone wonders, all values of epsilon above minimise its denominator subject to maximising M to the five decimal places given, as identified by Mathematica’s Rationalize function. The optimality of Output[k,1,k-1,8/11k] holds extremely accurately for the next few k too.]")

#emph[#text("[Corrections to remark made, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-326358")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2014")])]

#text("I did not test the zstart part of the code as extensively as I would have liked. (It allows the power on (1-P_1) to grow larger than d; and from testing it I seem to recall that it did not provide much improvement.)")

#text("I think there is a chance that setting d>= k can lead to problems, and cannot vouch for the results of the code in those cases.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-326360")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2014")])]

#text("So, for instance, if you set zstart=2 then your set of polynomials is of the form ")#mi("(1-P1)^a P_{\\alpha}")#text(" where ")#mi("\\deg(P_{\\alpha})\\leq d")#text(" and ")#mi("a+\\deg(P_{\\alpha})\\leq 2+d")#text(". But as I said, I didn’t extensively test this part– I always just take zstart=0.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd4ee11e9561e0992302bd40eebde537c101ae33a0d92d3b7989b023a3a577d3-e0c8a4a37da773f1e33327b33382bbc603cf1f00fe1c2f1d21297f602e424cd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alastair Irving")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-327357")[#strong[#text("Alastair Irving")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2014")])]

#text("The links in the post to the paper on Dropbox don’t seem to work any more. Please could someone with access to the folder provide an updated URL?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-327501")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2014")])]

#text("I quickly read through the draft. Here are some (mostly minor) comments.")

#text("1. In Theorems 1.3, 1.4, and so forth, do you want to specify that the absolute constant ")#mi("C")#text(" is effective? [I imagine most people don’t really care. You might just add a comment at the beginning of the paper that all absolute constants in the paper are effective.]")

#text("2. In Equation (1.2) (and elsewhere), the symbol ")#mi("\\lesssim")#text(" is used, although it wasn’t defined in the asymptotic notation section.")

#text("3. When I initially read Claim 2.4, the math symbol ")#mi("a")#text(" looked like the word “a”. Some rewording may help here, maybe something like “If the residue class…”.")

#text("4. Page 7. The word “”sectoins” should be “sections”.")

#text("5. Page 7, the line above 3.2 needs a colon.")

#text("6. In equations (4.13) and (4.14), I believe all ")#mi("i")#text("‘s need to be ")#mi("j")#text("‘s (otherwise I’m seeing a disconnect with (4.12)).")

#text("7. In equation (5.1), should the right-hand side be ")#mi("\\frac{2m}{\\vartheta}")#text("? (I.e. does the numerator need a 2?)")

#text("8. There are 4 places where it reads ")#mi("(t_1,dots,t_k)")#text(", and the dots needs a backslash.")

#text("9. Page 35, line 2, there is no space between ")#mi("\\mathbb{R}")#text(" and “supported”.")

#text("10. Page 45, last line. Is the integral missing a ")#mi("dt")#text("?")

#text("11. Page 49, line -2. Is ")#mi("1\\leq u\\leq 1")#text(" correct?")

#text("That’s it!")

#text("Would you like me to write some text to fill in some of the missing material in Section 7.2? So far, the paper reads VERY well, and I’m sure you could fill in the missing material better than I could, but I’m happy to help.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-329346")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2014")])]

#text("Thanks for the corrections! Yes, any help you could give with Sections 7.1, 7.2, and 7.4 in particular would be great.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-330204")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2014")])]

#text("I updated the fast admissibility testing code to handle verification of asymmetric Hensley-Richards tuples")

#text("\\{-p_{n+\\lfloor k_0/2\\rfloor – 1-i}, \\ldots, -p_{n+1}, -1, 1, p_{n+1},\\ldots, p_{n+\\lfloor (k_0+1)/2\\rfloor-1+i}\\}.")

#text("This yields some small improvements to the bounds on H for the m=4,5 cases.")

#text("Under the 1080/13*varpi+330/13*delta < 1 constraint we now have")

#text("m=4, k0=74,487,363, H=1,460,485,532")#linebreak()#text(" m=5, k0=3,393,468,735 H=79,929,332,990")

#text("Under the weaker 600/7*varpi+180/7*delta < 1 constraint we get")

#text("m=4, k0=75,845,707, H=1,488,222,198")#linebreak()#text(" m=5, k0=3,473,955,908, H=81,912,604,302")

#text("Under the Deligne-free 168*varpi+48*delta < 1 constraint we get")

#text("m=4, k0=105,754,838, H=2,111,417,340")#linebreak()#text(" m=5, k0=5,274,206,963 H=126,630,386,774")

#text("To verify the above results, compile the fast admissibility testing code and then use")

#text("ahrverify 74487363 492570 98449")#linebreak()#text(" ahrverify 75845707 492570 80322")#linebreak()#text(" ahrverify 105754838 654992 626457")#linebreak()#text(" ahrverify 3393468735 13773747 64666")#linebreak()#text(" ahrverify 3473955908 14132283 1872052")#linebreak()#text(" ahrverify 5274206963 20369534 11602015")

#text("I'm also looking into the possibility of implementing greedy sieving for k0 values in this range. If this can be done it would yield much larger improvements, but I'm not sure yet how feasible this is (my guess is we can probably get the m=4 cases, but the m=5 cases may be out of reach).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-332852")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2014")])]

#text("Given the issues with the ")#mi("1080 \\varpi + 330 \\delta < 13")#text(" constraint, I have commented out the portion of the paper using this constraint and reverted to the verified ")#mi("600 \\varpi + 180 \\delta < 7")#text(" constraint. When doing so, I verified the various values of ")#mi("k, c, T")#text(" in the m=2,3,4,5 computations. While they all check out, I am finding an unusual amount of slack in the m=4, k=75845707 and m=5, k=3473955908 calculations (from ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi600d7m4_75845707.mpl")[#text("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi600d7m4_75845707.mpl")]#text(" and ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi600d7m5_3473955908.mpl")[#text("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi600d7m5_3473955908.mpl")]#text(" respectively), in that ")#mi("600 \\varpi + 180 \\delta")#text(" is well below 7 in these cases (of the order of ")#mi("10^{-1}")#text("). But this may be because I am not using sufficient precision in these two cases. All the other values look pretty tight though (e.g. the error between ")#mi("600 \\varpi + 180 \\delta")#text(" and 7 is more like ")#mi("10^{-6}")#text(" in the k=2,3 cases). It may be worth double checking the k=4,5 values.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-332899")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2014")])]

#text("It might be caused by a precision problem as pointed by ")#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258411")[#text("Wouter")]#text(". In the computation for large m values, a high precision (e.g., Digits := 50) should be used.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-333029")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2014")])]

#text("My implementation terminates at 75845709 for m=4 (with c=0.055506225585937443712, T=0.042440185546874981126) and 3473955910 for m=5 (with c=0.045880571365356399849, T=0.034099090576171831035). Each of these k’s is 2 greater than xfxie’s values, but I expect that’s a (different) precision issue – I didn’t explore how to improve that in Mathematica.")

#text("If you can work out the constraint on varpi and delta that you mentioned on April 21st (arising from doing two sequential vdC’s rather than one 2D one), I’ll provide the corresponding best values for k.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-333100")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2014")])]

#text("BTW: For Digits := 50, the slack values in my solutions are:")

#text("m=4: 0.224593440614655464852452317001727394641205E-8")#linebreak()#text(" m=5: 0.107816913476554204615005610883051801771250E-9")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-333935")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2014")])]

#text("Yes, it was a precision issue, my run of Maple now matches your numbers, thanks!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-333770")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2014")])]

#text("In the definition of the operator ")#mi("\\mathcal L")#text(" (now at the end of page 55), the integration upper limit should be corrected.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0bef01fcf553d81b2f09685dbf8c39cd628cf06c09e56d3c5f7269d3de0db937-6f4d17720ffa3ebe1803204c78e04d896e2e357e8592867e1554d8badca75d1d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Svyatoslav Shmidt")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-335694")[#strong[#text("Svyatoslav Shmidt")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2014")])]

#text("Terence, Thank you a lot for yours knowledge! While playing with the function of the gaps between primes, I found an interesting image.Plot of the function g_n=log_2⁡〖(P_(n+1) 〗-P_n) In the polar coordinate system looks like the ripples. (pic. : ")#link("http://cs617127.vk.me/v617127546/8b0f/Hg97K3QccO4.jpg")[#text("http://cs617127.vk.me/v617127546/8b0f/Hg97K3QccO4.jpg")]#text(" ) Good luck in your research!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-337001")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2014")])]

#text("I added ")#link("http://arxiv.org/abs/1405.2593")[#text("Dense clusters of primes in subsets")]#text(" to the wiki.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-337839")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2014")])]

#text("I’m starting to work on section 7. I should have my additions done either later today or tomorrow.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-337907")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2014")])]

#text("I’ve uploaded the changes for section 7 as h1-new.tex and xyplot-new.pdf. If you like the changes, just remove “-new” from the filenames.")

#text("The new plot is to scale when ")#mi("\\varepsilon=1/4")#text(". Because of this, you might want to point out that in the integral formula for ")#mi("J_6")#text(", one of the terms disappears. If you want me to make further changes to the plot, that would be easy to do.")

#text("I made a few comments in the file about possible ways to simplify the exposition (such as modifying the Beta integral identity to account for additional powers of ")#mi("(1-P_{(1)})")#text("). I wasn’t sure what you wanted for section 7.2, so I gave a very “bare-bones” description of the ideas.")

#text("I hope this is somewhat helpful")

#text("As always, thank you for all you do in directing this venture!!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-338201")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2014")])]

#text("@Pace: I just had a look at h1-new.tex and noticed that you used ")#tao-fit-display[#mitex("…")]#text(" for displayed equations. This is not good. (See e.g. ")#link("http://tex.stackexchange.com/questions/503/why-is-preferable-to")[#text("http://tex.stackexchange.com/questions/503/why-is-preferable-to")]#text(".)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-338382")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2014")])]

#text("I’ve just made a number of minor changes to more-sieving.tex and asymptotics.tex. They both look good to me.")

#text("For the Goldbach/Twin prime result, isn’t it the case that (under the assumption of GEH and the falsity of the twin prime conjecture) that we get all sufficiently large even numbers, rather than just multiples of 6? (the admissible set ")#mi("\\{n,n+2,6N-n\\}")#text(" shows that either 6N and 6N+2 are the sum of at most 2 primes, and so both are within 2 of such a number, and similarly the admissible set ")#mi("\\{n,n+2,6N-n-2\\}")#text(", shows that either 6N or 6N-2 are the sum of at most 2 primes, so all of 6N-2,6N and 6N+2 are within 2 of such a number. I guess we should add a remark about the slight modification of the argument needed to deal with two of the linear functions having common factors (since we need a result uniform in the coefficients).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-339776")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2014")])]

#text("Ah, you’re right, we do get every even number within 2 of a sum of two primes from this argument. (What we almost, but don’t quite get, though, is that every odd number is within 1 of a sum of two primes.) I’ve modified the paper slightly to indicate this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-339134")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2014")])]

#text("The exponent in theorem 3.2(vi) should be corrected.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-339197")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2014")])]

#text("I just posted fast admissibility testing code to the wiki that supports Schinzel sieving. Specifically, it sieves a given interval [s,s+d] of all integers congruent to 1 mod 2 and all integers congruent to 0 mod p up to a specified prime p_n. It then checks that the set of survivors is admissible modulo all primes up to k0 and picks a subsequence of k0 survivors that minimizes the diameter.")

#text("This gives improved H bounds for all the m=4,5 cases.")

#text("Under the 1080/13*varpi+330/13*delta < 1 constraint we have")

#text("m=4, k0=74,487,363, H=1,440,495,268")#linebreak()#text(" m=5, k0=3,393,468,735, H=78,807,316,822")

#text("Under the 600/7*varpi+180/7*delta < 1 constraint we have")

#text("m=4, k0=75,845,707, H=1,467,584,468")#linebreak()#text(" m=5, k0=3,473,955,908, H=80,761,835,464")

#text("Under the Deligne-free 168*varpi+48*delta < 1 constraint we have")

#text("m=4, k0=105,754,837, H=2,082,729,956")#linebreak()#text(" m=5, k0=5,274,206,963, H=124,840,189,042")

#text("These bounds can be verified by compiling the fast admissibility testing code and then:")

#text("schinzelverify 74487363 74487363 1441846336 467557")#linebreak()#text(" schinzelverify 75845707 75845707 1468058816 467557")#linebreak()#text(" schinzelverify 105754837 105754837 2084601984 629732")#linebreak()#text(" schinzelverify 3393468735 3393468735 78881864192 13361346")#linebreak()#text(" schinzelverify 3473955908 3473955908 80835304192 13664637")#linebreak()#text(" schinzelverify 5274206963 5274206963 124956217600 19706960")

#text("The four numbers listed in each line above are the values of k0, s, d, and n.")

#text("For the record, I should also note the sub intervals of the sieved interval [s,s+d] that yield the above H bounds are:")

#text("k0=74487363: [74489356,1514984624]")#linebreak()#text(" k0=75845707: [75856874,1543441342]")#linebreak()#text(" k0=105754837: [105767006,2188496962]")#linebreak()#text(" k0=3393468735: [3467835454,82275152276]")#linebreak()#text(" k0=3473955908: [3547420054,84309255518]")#linebreak()#text(" k0=5274206963: [5389030684,130229219726]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-339393")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2014")])]

#text("Quite big improvements, as you predicted. Did you already use this sieve (or a better one) for all the smaller k0 values of interest?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-339423")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2014")])]

#text("For the smaller k0 values I used a greedy sieve, which does even better. For comparison, for k0=2,113,163 using the Schinzel sieve as above yields a diameter of 33,286,862, versus the 32,285,928 obtained using a greedy sieve.")

#text("It should certainly be possible to get further improvements for the m=4,5 cases using a greedy sieve, but the algorithm is more memory intensive and more difficult to parallelize, so this will take some effort (and computer time). I will try to work on this some more over the weekend (I also need to start writing up Appendix A, which I have been delaying until we settle on the best algorithm for obtaining large admissible tuples).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-339764")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2014")])]

#text("In the line above the end of prop. 6.5 proof, inside the parentheses of the RHS integrand, it should be ")#mi("1 - t_1 - ... - t_k + k t_i")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-340354")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2014")])]

#text("In the line above theorem 6.7, it should be “term” (instead of “factor”).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-342412")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2014")])]

#text("In section 7.4, there is a typo in the first term of the polynomial on ")#mi("H_{x y z}")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/comment-page-1/#comment-342831")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2014")])]

#text("Hmmm, Eytan’s corrections have made me realise that many of the last set of changes I attempted to make didn’t seem to go through correctly. I’m not sure why this was, but since you’re looking at the files I thought I’d write out a list of things I’d noticed here to avoid conflicts. I think I’ve managed to recall them all. (The only other changes I tried to make were minor layout/language changes which can be made later).")

#text("Page 33: eq (5.7): integration should be over ")#mi("(0,\\infty)^{k-1}")#text(" instead of ")#mi("(0,\\infty)^k")#text(", and it should be the ")#mi("(k-1)")#text("-fold differential with respect to ")#mi("t_1,\\dots, t_{i-1},t_{i+1},\\dots,t_k")#text(" instead of all variables.")

#text("Paragraph after (5.9): I think the reference (5.5) should be to the set defined in the equation above.")

#text("Page 34: after (5.10): maybe mention ")#mi("J")#text(" is fixed.")#linebreak()#text(" After (5.13): maybe recall definition (3.6) of ")#mi("\\lambda_F")

#text("Page 36: equation after (5.14): again, integration over ")#mi("\\mathcal{R}_{k-1}")#text(", and ")#mi("(k-1)^{th}")#text(" derivative (wrt variables other than ")#mi("t_i")#text(").")

#text("Page 38: first line: ")#mi("j^{\\prime}\\in\\mathcal{I}_1")#text(" not ")#mi("\\mathcal{I}_2")#text(".")#linebreak()#text(" Line 3: ")#mi("S(f_{i,j^{\\prime}})")#text(" instead of ")#mi("S(f_{i,j^{\\prime}}")#text(".")#linebreak()#text(" Eq 5.19: there is an accidental ")#mi(")")#text(" in the second sum.")#linebreak()#text(" Line -7: for ")#mi("l=1,2")#text(" instead of ")#mi("j=1,2")#linebreak()#text(" Line -3: should this be ")#mi("\\beta_k=\\dots")#text(" instead of ")#mi("\\beta_k\\ge \\dots")#text(" (obviously the second is also true). Also for page 39 line 2.")

#text("Page 39: line 5: `.. we prove Theorem 3.14’ instead of Theorem 3.12.")

#text("Page 40: equations after 5.22: I think we use EH to prove the lower bound for the prime sums, and GEH to prove the asymptotic for the non-prime sums, so these should be the other way round. Also (as above) should it be ")#mi("\\beta_i=")#text(" rather than ")#mi("\\beta_i\\geq")#text(".")

#text("Page 42: line -4: ")#mi("G_i:\\mathcal{R}_k\\rightarrow")#text(" instead of ")#mi("G_i:\\mathcal{R}^k\\rightarrow")#text(".")

#text("Page 46: line 10: maybe mention that we are extending ")#mi("g")#text(" to ")#mi("(0,\\infty)")#text(" by ")#mi("0")#text(".")#linebreak()#text(" inequality before (6.20): ")#mi("M_k^{[T]}")#text(" instead of ")#mi("M_k")#text(".")

#text("Page 47: In various places I think we need to swap strict and weak inequalities, since the equation ")#mi("(6.22)")#text(" doesn’t hold if ")#mi("S_{k-1}=r")#text(" (and ")#mi("h")#text(" is not defined at 0). This occurs on line 1 and twice on line 5.")

#text("Line 7: ")#mi("1_{X_k\\leq r-S_{k-1}}")#text(" instead of ")#mi("1_{X_k\\leq S_{k-1}-r}")#text(".")#linebreak()#text(" Line 11: `third equality’ instead of `second equality’.")#linebreak()#text(" Line -3: Maybe note we are using (6.12) here.")#linebreak()#text(" (6.24): There should be a factor of ")#mi("k/(k-1)")#text(" on the right hand side.")

#text("Page 48: line 6: ")#mi("{\\mathbb P}(S_k > 1+\\tau)")#text(" not ")#mi("{\\mathbb P}(S_k < 1+\\tau)")#linebreak()#text(" Line 8: Maybe note we are using (6.10) here.")#linebreak()#text(" Line -6: The use of ")#mi("x_+")#text(" for general ")#mi("x")#text(" hasn’t been defined; maybe better to stick with ")#mi("1_{S_k\\leq r}")#text(".")

#text("Page 49: line 14: any ")#mi("a > 1")#text(" not ")#mi("a\\geq 1")#text(".")

#text("Page 50: line 8: ds missing from integral.")

#text("Page 52: line 5: I get ")#mi("\\beta < (1+\\gamma-\\alpha-\\log{\\beta})^2")#text(" as the final constraint.")

#text("Page 53: before section 7: Maybe mention that the constraints (6.10)-(6.12) hold for each of these choices of parameters.")

#emph[#text("[Added, thanks – T.]")]
]
