// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/
// Converted to Typst by tao2typ: "2026-10-14T16:35:25.141321+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Lucas-Lehmer test for Mersenne primes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Lucas-Lehmer test for Mersenne primes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 October 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/")[#text("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the last few weeks, the ")#link("http://www.mersenne.org/")[#text("Great Internet Mersenne Prime Search")]#text(" (GIMPS) announced the discovery of two new ")#link("http://en.wikipedia.org/wiki/Mersenne_prime")[#text("Mersenne primes")]#text(", both over ten million digits in length, including one discovered by the computing team right here at UCLA (see ")#link("http://www.math.ucla.edu/~edson/prime/")[#text("this page")]#text(" for more information). [I was not involved in this computing effort.] As for the question “Why do we want to find such big primes anyway?”, see ")#link("http://primes.utm.edu/notes/faq/why.html")[#text("this page")]#text(", though this is not the focus of my post today.")

#text("The GIMPS approach to finding Mersenne primes relies of course on modern computing power, parallelisation, and efficient programming, but the number-theoretic heart of it – aside from some basic optimisation tricks such as ")#link("http://en.wikipedia.org/wiki/Sch%C3%B6nhage-Strassen_algorithm")[#text("fast multiplication")]#text(" and preliminary sieving to eliminate some obviously non-prime Mersenne number candidates – is the ")#link("http://en.wikipedia.org/wiki/Lucas%E2%80%93Lehmer_test_for_Mersenne_numbers")[#text("Lucas-Lehmer primality test")]#text(" for Mersenne numbers, which is much faster for this special type of number than any known general-purpose (deterministic) primality test (such as, say, the ")#link("http://en.wikipedia.org/wiki/AKS_primality_test")[#text("AKS test")]#text("). This test is easy enough to describe, and I will do so later in this post, and also has some short elementary proofs of correctness; but the proofs are sometimes presented in a way that involves pulling a lot of rabbits out of hats, giving the argument a magical feel rather than a natural one. In this post, I will try to explain the basic ideas that make the primality test work, seeking a proof which is perhaps less elementary and a little longer than some of the proofs in the literature, but is perhaps a bit better motivated.")

#metadata(none) <tao-cd22647fdee05f6eaf39>

#heading(level: 1)[#text("— Order —")]

#text("We begin with a general discussion of how to tell when a given number n (which is not necessarily of the Mersenne form ")#mi("n = 2^m-1")#text(") is prime or not. One should think of n as being moderately large, e.g. ")#mi("n \\sim 10^{10^7}")#text(" (which is broadly the size of the Mersenne primes discovered recently).")

#text("Our starting point will be ")#link("http://en.wikipedia.org/wiki/Lagrange%27s_theorem_(group_theory)")[#text("Lagrange’s theorem")]#text(", which asserts that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("a^{\\left|G\\right|} = 1", block: true)]]

#text("for any finite group G and any ")#mi("a \\in G")#text(", thus the ")#link("http://en.wikipedia.org/wiki/Order_of_a_group")[#text("order")]#text(" ")#mi("\\text{ord}_G(a)")#text(" of a in G divides |G|. Specialising this to the multiplicative group ")#mi("{\\Bbb F}_p^\\times")#text(" of a ")#link("http://en.wikipedia.org/wiki/Finite_field")[#text("finite field")]#text(" of prime order p, we obtain ")#link("http://en.wikipedia.org/wiki/Fermat%27s_little_theorem")[#text("Fermat’s little theorem")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("a^{p-1} = 1 \\text{ mod } p")]]

#text("for ")#mi("p")#text(" prime and ")#mi("a")#text(" coprime to ")#mi("p")#text("; applying it instead to the multiplicative group ")#mi("({\\Bbb Z}/n{\\Bbb Z})^\\times")#text(" of a cyclic group of order ")#mi("n")#text(", we obtain ")#link("http://en.wikipedia.org/wiki/Euler%27s_theorem")[#text("Euler’s theorem")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("a^{\\phi(n)} = 1 \\text{ mod } n")]]

#text("whenever ")#mi("a")#text(" is coprime to n, where ")#tao-math("\\phi(n) := \\left|({\\Bbb Z}/n{\\Bbb Z})^\\times\\right|", block: false)#text(" is the ")#link("http://en.wikipedia.org/wiki/Euler%27s_totient_function")[#text("Euler totient function")]#text(" of n.")

#text("Fermat’s little theorem (2) already gives a necessary condition for the primality of a candidate prime ")#mi("n")#text(": take any ")#mi("a")#text(" coprime to ")#mi("n")#text(" (typically one picks a small number such as ")#mi("a=2")#text(" or ")#mi("a=3")#text("), and compute ")#mi("a^{n-1}")#text(" modulo ")#mi("n")#text(". If it is not equal to 1, then ")#mi("n")#text(" cannot be prime. This is a (barely) feasible test to execute for ")#mi("n")#text(" as large as ")#mi("10^{10^7}")#text(", because one can compute exponents such as ")#mi("a^{n-1}")#text(" relatively quickly, by the trick of repeatedly squaring a modulo n to obtain ")#mi("a, a^2, a^{2^2}, a^{2^3}, \\ldots \\text{ mod } n")#text(", and then decomposing ")#mi("n-1")#text(" into binary to compute ")#mi("a^{n-1}")#text(". (If ")#mi("n")#text(" is a Mersenne number, then there are some pretty obvious shortcuts one can take for this last step, using division instead of multiplication.) Unfortunately, while this test is necessary for primality, it is not sufficient, due to the existence of ")#link("http://en.wikipedia.org/wiki/Pseudoprime")[#text("pseudoprimes")]#text(". So Fermat’s little theorem alone does not provide the answer, at least if one wants a ")#emph[#text("deterministic")]#text(" certificate of primality rather than a ")#emph[#text("probabilistic")]#text(" one.")

#text("Nevertheless, the above facts do provide some important information about the order ")#mi("\\text{ord}_n(a) := \\text{ord}_{({\\Bbb Z}/n{\\Bbb Z})^*}(a)")#text(" of a modulo ")#mi("n")#text(". If ")#mi("n")#text(" is prime, Fermat’s little theorem (2) tells us that ")#mi("\\text{ord}_n(a)")#text(" is at most ")#mi("n-1")#text(" (in fact, it divides ")#mi("n-1")#text("). On the other hand, if ")#mi("n")#text(" is not prime, then Euler’s theorem (3) tells us that ")#mi("\\text{ord}_n(a)")#text(" cannot be as large as ")#mi("n-1")#text(", but is instead at most ")#mi("\\phi(n)")#text(", which is now strictly less than ")#mi("n-1")#text(". Thus: if we can find a number ")#mi("a")#text(" coprime to ")#mi("n")#text(" such that ")#mi("\\text{ord}_n(a)")#text(" is exactly ")#mi("n-1")#text(", we have certified that ")#mi("n")#text(" is prime.")

#text("Testing whether a given number ")#mi("a")#text(" is coprime to ")#mi("n")#text(" is very easy and fast (thanks to the ")#link("http://en.wikipedia.org/wiki/Euclidean_algorithm")[#text("Euclidean algorithm")]#text("). Unfortunately, it is difficult in general to compute the order ")#mi("\\text{ord}_n(a)")#text(" of a number ")#mi("a")#text(" if the base ")#mi("n")#text(" is large; a brute-force approach would require one to compute up to ")#mi("n-1")#text(" powers of ")#mi("a")#text(", which is prohibitively expensive if ")#mi("n")#text(" has size comparable to ")#mi("10^{10^7}")#text(". (More generally, the problem of computing order exactly in general is closely related to the ")#link("http://en.wikipedia.org/wiki/Discrete_logarithm")[#text("discrete logarithm")]#text(" problem, which is notoriously difficult.) However, there are a few cases in which the order can be found very quickly. Suppose that we somehow find positive integers ")#mi("a")#text(", ")#mi("k")#text(" such that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("a^{2^k} = - 1 \\text{ mod } n")]]

#text("(which in particular implies that ")#mi("a")#text(" is coprime to ")#mi("n")#text("). Squaring this, we obtain")

#align(center)[#tao-fit-display[#mitex("a^{2^{k+1}} = 1 \\text{ mod } n")]]

#text("and so we see that ")#mi("\\text{ord}_n(a)")#text(" divides ")#mi("2^{k+1}")#text(" but not ")#mi("2^k")#text(", and thus must be exactly equal to ")#mi("2^{k+1}")#text(". Conversely, if ")#mi("\\text{ord}_n(a) = 2^{k+1}")#text(", then we must have (4). So in the special case when the order of ")#mi("a")#text(" is a power of 2, we can compute the order using only one exponentiation, which is computationally feasible for the orders of magnitude we are considering.")

#text("Unfortunately, this is not quite what we need for the Mersenne prime problem, because if ")#mi("n")#text(" is a Mersenne number, then it is ")#mi("n")#text(" ")#emph[#text("plus")]#text(" 1 which is a power of 2, rather than ")#mi("n")#text(" ")#emph[#text("minus")]#text(" 1. (The above method would be ideal for finding ")#link("http://en.wikipedia.org/wiki/Fermat_prime")[#text("Fermat primes")]#text(" rather than Mersenne primes, but it is likely that in fact there are no more such primes to be found.)")

#text("So this is a frustrating near miss: if ")#mi("n")#text(" is a Mersenne number, we can easily check if a number has order ")#mi("n+1")#text(" modulo ")#mi("n")#text(", but we needed a test for when a number has order ")#mi("n-1")#text(" instead. And indeed, even when ")#mi("n")#text(" is prime, Fermat’s little theorem (2) shows that it is impossible for a number to have order ")#mi("n+1")#text(" modulo ")#mi("n")#text(", since the order needs to divide ")#mi("n-1")#text(". So we seem to be a bit stuck.")

#text("But while ")#mi("n+1")#text(" clearly does not divide ")#mi("n-1")#text(", it ")#emph[#text("does")]#text(" divide ")#mi("n^2-1")#text(". Looking at Lagrange’s theorem (1), we then see that it could be possible to find elements of order ")#mi("n+1")#text(" in a multiplicative group of order ")#mi("n^2-1")#text(" rather than ")#mi("n-1")#text(". Recall that if ")#mi("n")#text(" was prime, then the multiplicative group ")#mi("{\\Bbb F}_n^\\times")#text(" of the finite field ")#mi("{\\Bbb F}_n")#text(" had order ")#mi("n-1")#text(". But ")#mi("{\\Bbb F}_{n^2}")#text(" is also a finite field, and its multiplicative group ")#mi("{\\Bbb F}_{n^2}^\\times")#text(" has order ")#mi("n^2-1")#text(". Aha!")

#text("So the plan (assuming for sake of argument that ")#mi("n")#text(" is prime) is to somehow work in the finite field ")#mi("{\\Bbb F}_{n^2}")#text(" instead of ")#mi("{\\Bbb F}_n")#text(", in order to find elements of order ")#mi("n+1")#text(". We can get our hands on this larger finite field more concretely by viewing it as a ")#link("http://en.wikipedia.org/wiki/Quadratic_extension")[#text("quadratic extension")]#text(" ")#mi("{\\Bbb F}_n[\\sqrt{a}]")#text(", where a is a ")#link("http://en.wikipedia.org/wiki/Quadratic_residue")[#text("quadratic non-residue")]#text(" of ")#mi("n")#text(".")

#text("Let’s now take n to be a Mersenne prime. What numbers are quadratic non-residues? A quick appeal to ")#link("http://en.wikipedia.org/wiki/Quadratic_reciprocity")[#text("quadratic reciprocity")]#text(" and some elementary number theory soon reveals that 2 is a quadratic residue of ")#mi("n")#text(", but that 3 is not. Thus we can take ")#mi("{\\Bbb F}_{n^2} \\equiv {\\Bbb F}_n[\\sqrt{3}]")#text(". (One could work with other numbers than 3 here, but being the smallest quadratic non-residue available, it is the simplest one to use, and the one which is most likely to be able to take advantage of the ")#link("http://en.wikipedia.org/wiki/Strong_law_of_small_numbers")[#text("strong law of small numbers")]#text(".) Henceforth all calculations will be in this field ")#mi("{\\Bbb F}_n[\\sqrt{3}]")#text(", which of course contains ")#mi("{\\Bbb F}_n")#text(" as a subfield.")

#text("Now we need to look for a field element ")#mi("a")#text(" of order ")#mi("n+1")#text(", which is a power of 2. Thus (by adapting (4) to ")#mi("{\\Bbb F}_n[\\sqrt{3}]")#text(") we need to find a solution to the equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("a^{(n+1)/2} = -1")]]

#text("in this field.")

#text("Let’s compute some expressions of the form ")#mi("a^{(n+1)/2}")#text(". From Fermat’s little theorem (2) we have")

#align(center)[#mi("3^{n-1} = 1")#text(";")]

#text("because 3 is not a quadratic residue, we see (from taking ")#link("http://en.wikipedia.org/wiki/Discrete_logarithm")[#text("discrete logarithms")]#text(") that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("3^{(n-1)/2} = -1")]]

#text("and thus")

#align(center)[#mi("3^{(n+1)/2} = -3")#text(".")]

#text("Similarly we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7).")])
#mitex("2^{(n+1)/2} = +2")]]

#text("These are pretty close to (5), but not quite right. To go further, it is convenient to work with ")#mi("n^{th}")#text(" powers rather than ")#mi("((n+1)/2)^{th}")#text(" powers – i.e. we work with the ")#link("http://en.wikipedia.org/wiki/Frobenius_endomorphism")[#text("Frobenius automorphism")]#text(" ")#mi("x \\mapsto x^n")#text(". Indeed, since ")#mi("{\\Bbb F}_n[\\sqrt{3}]")#text(" has characteristic n, we have the automorphism properties")

#align(center)[#mi("(x+y)^n = x^n + y^n")#text("; ")#mi("(xy)^n = x^n y^n")#text(". (8)")]

#text("From (6) we have ")#mi("(\\sqrt{3})^n = - \\sqrt{3}")#text(", while from (2) we have ")#mi("a^n = a")#text(" for ")#mi("a \\in {\\Bbb F}_n")#text(". From (8) we thus see that")

#align(center)[#tao-fit-display[#mitex("(a + b \\sqrt{3})^n = a - b \\sqrt{3}")]]

#text("for ")#mi("a, b \\in {\\Bbb F_n}")#text("; thus the Frobenius automorphism is nothing more than Galois conjugation. (Actually, this can be deduced quite readily from standard ")#link("http://en.wikipedia.org/wiki/Galois_theory")[#text("Galois theory")]#text(".)")

#text("Now we go back from ")#mi("n^{th}")#text(" powers to ")#mi("((n+1)/2)^{th}")#text(" powers. Multiplying both sides of the preceding equation by ")#mi("a + b \\sqrt{3}")#text(", we obtain")

#align(center)[#mi("(a+b \\sqrt{3})^{n+1} = a^2 - 3b^2")#text(".")]

#text("Squaring ")#mi("a+b\\sqrt{3}")#text(", we conclude")

#align(center)[#mi("(a^2+3b^2 + 2ab\\sqrt{3})^{(n+1)/2} = a^2-3b^2")#text(".")]

#text("Now we in a good position to solve the equation (5). We cannot make ")#mi("a^2 - 3b^2")#text(" equal to -1 – since -1 is not a quadratic residue modulo 3 – but we can make it equal to, say, -2, by setting a=1 and b=-1 (say):")

#align(center)[#mi("(4 + 2 \\sqrt{3})^{(n+1)/2} = -2")#text(".")]

#text("Dividing this by (7) we obtain the desired solution")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\omega^{(n+1)/2} = -1")]]

#text("to (5), where ")#mi("\\omega := 2 + \\sqrt{3}")#text(". (Note that one could also use ")#mi("\\omega^{-1} = 2-\\sqrt{3}")#text(" here; indeed, ")#link("http://en.wikipedia.org/wiki/Galois_theory")[#text("Galois theory")]#text(" tells us that ")#mi("+\\sqrt{3}")#text(" and ")#mi("-\\sqrt{3}")#text(" are interchangeable in these computations.)")

#text("To summarise, we have shown that")

#align(center)[#text("If ")#mi("n")#text(" is a Mersenne prime, then (9) holds.")]

#text("Based on our previous discussion, we expect to be able to reverse this implication. Indeed, we have the following converse:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" Let ")#mi("n")#text(" be a Mersenne number. If (9) holds (in the ring ")#mi("({\\Bbb Z}/n{\\Bbb Z})[\\sqrt{3}]")#text("), then ")#mi("n")#text(" is prime.")
]

#strong[#text("Proof.")]#text(" Let ")#mi("q")#text(" be a prime divisor of ")#mi("n")#text(". Then ")#mi("\\omega^{(n+1)/2}=-1")#text(" in the field ")#mi("{\\Bbb F}_q[\\sqrt{3}]")#text(" (which we define as ")#mi("{\\Bbb F}_q")#text(" if 3 is a quadratic residue there), thus ")#mi("\\omega")#text(" has order exactly n+1 (cf. (4)). By Lagrange’s theorem (1), this means that ")#mi("n+1")#text(" divides the multiplicative order of ")#mi("{\\Bbb F}_q[\\sqrt{3}]^\\times")#text(", which is ")#mi("q^2-1")#text(" (if 3 is a non-residue modulo ")#mi("q")#text(") or ")#mi("q-1")#text(" (if 3 is a residue modulo ")#mi("q")#text("). In particular, ")#mi("q")#text(" has to exceed ")#mi("\\sqrt{n}")#text(". Thus the only prime divisors of ")#mi("n")#text(" exceed ")#mi("\\sqrt{n}")#text(", and so by the ")#link("http://en.wikipedia.org/wiki/Sieve_of_eratosthenes")[#text("sieve of Eratosthenes")]#text(", ")#mi("n")#text(" is prime. (This proof is due ")#link("http://www.ams.org/mathscinet-getitem?mr=1209464")[#text("to Bruce")]#text(".) ")#mi("\\Box")

#text("We have thus shown")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1.")]#text(" (Lucas-Lehmer test, preliminary version) Let ")#mi("n = 2^m-1")#text(" with m odd. Then n is prime if and only if (9) holds in ")#mi("{\\Bbb Z}/n{\\Bbb Z}[\\sqrt{3}]")#text(".")
]

#text("This is already a reasonable criterion, but it is a little non-elementary (and also a little unpleasant numerically) due to the presence of the quadratic extension by ")#mi("\\sqrt{3}")#text(". One can get rid of this extension by the Galois theory trick of taking ")#link("http://en.wikipedia.org/wiki/Field_trace")[#text("traces")]#text(". Indeed, observe that ")#mi("\\omega^{-1} = 2 - \\sqrt{3}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Galois_conjugate")[#text("Galois conjugate")]#text(" of ")#mi("\\omega")#text(". Basic ")#link("http://en.wikipedia.org/wiki/Galois_theory")[#text("Galois theory")]#text(" tells us that ")#mi("\\omega^{(n+1)/4} + \\omega^{-(n+1)/4}")#text(" lies in ")#mi("{\\Bbb Z}/n{\\Bbb Z}")#text(", and vanishes precisely when ")#mi("\\omega^{(n+1)/2}")#text(" is equal to -1. So it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\omega^{(n+1)/4} + \\omega^{-(n+1)/4} = \\omega^{2^{m-2}} + \\omega^{-2^{m-2}} =: S_{m-2}")]]

#text("vanishes in ")#mi("{\\Bbb Z}/n{\\Bbb Z}")#text(".")

#text("The quantity ")#mi("\\omega^{(n+1)/4} = \\omega^{2^{m-2}}")#text(" could be computed by repeated squaring in ")#mi("{\\Bbb Z}/n{\\Bbb Z}[\\sqrt{3}]")#text(". The quantity ")#mi("S_{m-2}")#text(" can be computed by a similar device in ")#mi("{\\Bbb Z}/n{\\Bbb Z}")#text(". Indeed, the sequence ")#mi("S_j := \\omega^{2^j} + \\omega^{-2^j}")#text(" is easily seen to obey the recursion")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("S_j = S_{j-1}^2 - 2; \\quad S_0 = 4")]]

#text("and so we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1. ")]#text("(Lucas-Lehmer test, final version) Let ")#mi("n = 2^m-1")#text(" with m odd. Then n is prime if and only if ")#mi("S_{m-2}")#text(" vanishes modulo n, where ")#mi("S_{m-2}")#text(" is given by the recursion (10).")
]

#text("To apply this test, one needs to perform about ")#mi("m")#text(" squaring operations modulo ")#mi("n")#text(". Doing everything as efficiently as possible (in particular, using ")#link("http://en.wikipedia.org/wiki/Sch%C3%B6nhage-Strassen_algorithm")[#text("fast multiplication")]#text("), the total cost of testing a single Mersenne number ")#mi("n = 2^m-1")#text(" for primality is about ")#mi("O(m^2)")#text(" (modulo some ")#mi("\\log m")#text(" terms). This turns out to barely be within reach of modern computers for ")#mi("m \\sim 10^7")#text(", especially since the algorithm is somewhat ")#link("http://en.wikipedia.org/wiki/Parallel_computing")[#text("parallelisable")]#text(". (In contrast, the best known general-purpose deterministic primality testing algorithm, the ")#link("http://en.wikipedia.org/wiki/AKS_primality_test")[#text("AKS algorithm")]#text(", has a run time of about ")#mi("O(m^6)")#text(" (with a sizable implicit constant), which is not feasible for ")#mi("m \\sim 10^7")#text(".) There are general-purpose probabilistic tests (such as ")#link("http://en.wikipedia.org/wiki/Miller-Rabin_primality_test")[#text("Miller-Rabin")]#text(") which have run-time comparable to the Lucas-Lehmer test, but as mentioned at the beginning, we are only interested here in deterministic (and unconditional, e.g. not relying on ")#link("http://en.wikipedia.org/wiki/Generalized_Riemann_hypothesis")[#text("GRH")]#text(") certificates of primality.")

#text("[")#emph[#text("Updated")]#text(", Nov 16: Lemma 1 corrected.]")

#heading(level: 1)[#text("Comments (26)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-32747")[#strong[#text("Prime Numbers: Mersenne Primes Edition « OU Math Club")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2008")]

#text("[…] used by the GIMPS project to test if a Mersenne number is actually prime. You can check it out here. Note: UCLA computers were used to find one of the new […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-32751")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2008")])]

#text("I think there is a typo in the third paragraph, in the phrase: “prime our not.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-32752")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2008")])]

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b75fc41217ef8fc47665213438303084843f8470098680481afa8d3125f09285-6cca3fd941dec0b593253f915fae0d951279a6264504b44ebb5c3b73e24571cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of François Brunault")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-32768")[#strong[#text("François Brunault")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2008")])]

#text("Thank you for this nice exposition! I should add that B. H. Gross recently devised a beautiful primality test for Mersenne numbers which is based on elliptic curves. The idea is to replace the multiplicative group of a finite field by the group of points of a suitable elliptic curve E over F_p. Here E is given by the Weierstrass equation y^2 = x^3 – 12x. This elliptic curve has complex multiplication, which makes the group of points over F_p easier to compute. It turns out that if p is a Mersenne prime then this group is cyclic of order p+1, which is exactly what one wants. Then successive squaring is replaced by the duplication map on the elliptic curve. Unfortunately, the formula for the duplication map on an elliptic curve is more complicated, so this test seems to be mainly interesting from a theoretical point of view.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-32769")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2008")])]

#text("Dear Prof. Tao,")

#text("Thank you for another interesting post. This is the clearest exposition of the Lucas-Lehmer test I have read. I think there is a typo about 8 lines after formula (8). In the formula following “Squaring a+b\\sqrt{3}…” should be (a^2+3b^2+2ab\\sqrt{3})…. Also 2 lines after that a^2-3b^2 instead of a^2=3b^2.")

#text("Also of couse in looking for Mersenne prime, one needs only consider Mersenne number n=2^m-1, where m is prime since 2^a-1 divides")#linebreak()#text(" 2^(ab)-1. ")#emph[#text("[Corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-32772")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2008")])]

#text("Thanks for a very enjoyable read. A very minor correction: in the sentence beginning “We cannot make ")#mi("a^2 = 3b^2")#text(" equal to ")#mi("-1")#text(",” I think you mean ")#mi("a^2 - 3b^2")#text(". ")#emph[#text("[Corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of david")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-32788")[#strong[#text("david")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2008")])]

#text("Very happy to visit you blog, young hero!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e86d5cdc55af0123ff6e91b48a292830fc4260200f5aa351bcf8c7dad936203-8f4190d6f89b570b253f48c32ca984f39876fd961c8eb250d4dff29f42a963c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jernej")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-32793")[#strong[#text("Jernej")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2008")])]

#text("Hello, I think there’s a small mistake in the text :")

#text("===")#linebreak()#text(" Fermat’s little theorem (2) already gives a necessary condition for the primality of a candidate prime : take any a coprime to n (typically one picks a small number such as a = 2 or a = 3 ), and compute a^{n-1} modulo n . If it is not equal to 1, then p cannot be prime.")#linebreak()#text(" ===")

#text("You probably meant n instead of p.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-32794")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2008")])]

#text("Dear Jernej: thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-32810")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2008")])]

#text("Thank you for your beautiful exposition.")

#text("Another tiny misprint. In the statement Fermat’s little theorem, the “a” in")#linebreak()#text(" ==")#linebreak()#text(" for ")#mi("p")#text(" prime and a coprime to ")#mi("p")#linebreak()#text(" ==")#linebreak()#text(" should be in math mode. ")#emph[#text("[Corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-32849")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2008")])]

#text("Great explanation!")

#text("As another possible justification for why people are searching for larger mersenne primes, there’s a clever construction of Locally Decodable Codes by Yekhanin that works in ")#mi("\\mathbb{Z}/p\\mathbb{Z}")#text(" where ")#mi("p")#text(" is a Mersenne prime. Since his bounds get better as ")#mi("p")#text(" increases, he specifically cites the (then) largest Mersenne prime in his bounds.")

#link("http://portal.acm.org/citation.cfm?id=1250830#")[#text("http://portal.acm.org/citation.cfm?id=1250830#")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f25cfe2e0171970212c1b595a209ebbd956d579ee413a8a7323fecc39d50bc9d-943d6efe2ee974645653eed52575c4e69048f0a8aea99a85a6c257fef9499ff2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jaime Montuerto")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-33277")[#strong[#text("Jaime Montuerto")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2008")])]

#text("Dear Terry,")

#text("Your posts on Mersenne Numbers and your following post about Galois groups and the order in the group gave me several insights for my proposed hypothesis. This hypothesis is that every prime number (in fact all integers) divide a Mersenne number. It is also true that every Mersenne number is a multiple of a prime and sometimes some Mersennes have more prime divisors.")

#text("One of the consequences of this is that the number of primes is almost equal to the number of Mersenne numbers. Almost equal because some Mersennes give off two primes and these Mersennes are those that have prime orders and themselves are composite e.g. M11, M23, and M47. And possibly some Mersennes whose order is a square e.g. M25 = 601 * 1801 * 31, both 601 and 1801 divides M25 as minimum Mersenne whereas 31 divides M5 (which is itself) therefore not the prime in question. There are almost an equal number of Mersennes and primes, primes are a bit more over some given range.")

#text("A further consequence is that there are infinite Mersennes, that is, for every integer there is corresponding Mersenne i.e. integer n means Mn therefore a new prime that divides that. Hence there are infinite primes.")

#text("Another consequence is that the distribution of Mersennes is a recurrence relation, Mnext = Mprevious *2 + 1, i.e. the present Mersennne is almost double the previous one. Therefore the ordering of Mersenne is so predictable and almost so ordered, given a range ‘n’ the number of Mersennes in that range is ‘log n’ on base 2. Then the number of primes in that range is also ‘log n’ almost. I believed this is what Friedrick Gauss has observed in the distribution of primes.")

#text("I am developing two major areas of research in factoring Mersennes:")

#text("(1) Following your post about discrete logarithms I realized that the first algorithm is exactly based on that – it looks for 2^x where the remainder is 1 modulo n or looking for a pair of 2^x and 2^y where there remainder is the same hence the cycle is a difference of x and y, the difference is actually either a multiple, equal or a fraction of this cycle.")

#text("(2) The other algorithm is base on the grammar of partitions. A good metaphor I used is the monetary system, as, some reason, almost everyone can calculate when money is involved. Imagine all notes or bills are doubles of the previous one. The smallest is a dollar ‘1’, next is 2 dollars, and so on – essentially the binary system. The question is, given a certain amount, can we break/partition the bills in such a way that the relationship of each adjacent bills (binary bits) forms a set of predefined law (grammatical laws)? The essence of these is that if a sentence (grammatical sentence) is formed or produced by these laws then we can find the factors of that amount. Prime number amounts do not produce well-formed sentences.")

#text("It is very hard to explain all the details of what I am doing. I only hope that it is clear enough for you to be able to understand a little of my work. There is of course much more that could be said about this.")

#text("I would be very grateful for any comments you could make.")

#text("Thanking you in anticipation.")

#text("Best")

#text("Jaime Montuerto")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70e62d12f15edea0b653b828aedc8ad5cc518192ba98e84a32a01d7841d7f8b8-8f9fbd25d32c241ea62d5b622f47bcb9bc7651f2a278c7940f0b65d6a46e47cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rene' Schoof")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-33551")[#strong[#text("Rene' Schoof")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2008")])]

#text("Dear Prof. Tao,")

#text("I have a question about the proof of")#linebreak()#text(" your Lemma 1. You seem to assume that under the conditions")#linebreak()#text(" of the lemma, automatically 3 is a non-square modulo q for")#linebreak()#text(" any prime divisor q of n.")#linebreak()#text(" How do you see that?")

#text("Best")

#text("Rene’ Schoof")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-33563")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2008")])]

#text("Dear Rene’,")

#text("Thanks for pointing that out! Actually, it turns out that the argument works just as well when 3 is a square modulo q (one simply replaces ")#mi("F_q[\\sqrt{(}3)]")#text(" with ")#mi("F_q")#text(" in this case). I’ve modified the discussion to reflect this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df2daf7703ca488772c4b7faaac22c54dede777827e70dba047a3fc0d77abefe-547bb32fbaeb7ae99ad30708abd44ddf6dea237f32504739b9f035cc1e57bf3a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tarandeep Singh")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-33875")[#strong[#text("Tarandeep Singh")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2008")])]

#text("Dear Professor Tao,")

#text("I was working on the Mersenne primes and it appears there is “some pattern” in all the known Mersenne primes. I have verified it for the 46 known Mersenne Primes and it holds.")

#text("I am not sure if its something “easily provable” or we do have something that has gone unnoticed before.")

#text("Need to know if you would be interested to see the pattern/conjecture and comment on the same.")

#text("Thanks in advance.")

#text("Tarandeep Singh")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24d9a0b9a87d20a0993c0a7a8cf85d9d0747b5c8f7b9aa2b934e3e0f12cb1f67-513242c3e54d12a8cb84c4db7b788bca491764c2d6cc16e095b60b63169e6b5a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tony Reix")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-34729")[#strong[#text("Tony Reix")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2009")])]

#text("Hi Sir,")

#text("Thanks for the proof. I’ll study it and see if it can help me.")

#text("I’m one of the crazy guys who contribute to the GIMPS project, since ages.")#linebreak()#text(" I’ve contributed to checking the last 6 Mersenne primes, on a big Itanium2 machine, with the wonderful Glucas program written by Guillermo Ballester Valor.")

#text("I also spent a lot of time studying the LLT, reading E. Lucas books, HC Williams book about E. Lucas work, Ribenboim famous book about primes, and so on.")#linebreak()#text(" I’ve also found some properties of Mersenne numbers and of the LLT, with proof of myself or by other people. Mq=(8x)^2-(3qy)^2. As an example for LLT, since it is not well known that the LLT can be used to prove that a Fermat number is prime (a number N such that N-1 is easily factorized), I wrote such a proof, based on Ribenboim technic and on Williams’ book.")#linebreak()#text(" So, though I am an “amateur”, I have some knowledge of the LLT test.")

#text("The LLT test makes use of the tree that appears in the DiGraph under x^2-2 modulo a Mersenne prime (see Shallit & Vasiga for details). This DiGraph also has many cycles, of lengh dividing q-1. I found the formula that gives the number of cycles of lengh L, under x^2 and x^2-2 modulo a Mersenne prime. Someone else built the proof.")

#text("I also have conjectured a test that makes use of such a cycle of length q-1 (with a fix seed) instead of the tree (with seed 4). The main difference with the basic LLT test is that the last step of the iteration, instead of leading to 0 (mod Mq), leads to the seed of the iteration: S_0. Thanks to some help of Mr Williams, I’ve been able to prove that, if Mq is prime, then the property holds. But I failed finding a way to prove the reverse…")

#text("In short, the x^2-2 builds trees and cycles modulo a number. If the number is prime, there is symmetry. If the number is composite, then trees and cycles are not symmetric. My idea is that cycles can be used as the tree is used for proving that a number is prime.")

#text("This would not be very interesting to have another test for Mersenne numbers, since it would not be faster than LLT.")

#text("But Anton Vrba built a conjecture about using the same technique for a primality proof for Fermat 2^2^n+1 and Wagstaff (2^q+1)/3 numbers. And he provided a proof for the first (easy) part: a Prime number HAS this property.")

#text("About Wagstaff numbers, proving the conjecture would lead to a brand new primality test as efficient as the LLT is for Mersenne numbers. That would be the first VERY efficient test for a number not N-1 nor N+1. But Anton failed to prove the reverse… Some Mathematician contributing to the GIMPS Math forum think that, though it should be possible for the Mersenne, it does not seem possible to prove the conjecture for Wagstaffs. However, the DiGraph under x^2-2 modulo a Wagstaff prime only has cycles. No tree.")

#text("About Fermat numbers (tree and cycles), I guess (just a guess…) that it could be possible to build a test that could be used to prove that a Fermat number is NOT prime, much faster than running the full Pépin’s test. This could be possible since the Digraph under x^2-2 modulo a Fermat prime generates cycles of length dividing 2^n-1. I expect that a Fermat number that does not verify such a (much shorter) test could not be a prime. Just an idea… but it could help to know what is the status of F33.")

#text("So, there is here an area of research. Simply studying the properties of the cyles and trees for the Mersenne, Fermat and Wagstaff numbers under x^2 or x^2-2 would be very interesting, and useful for further reseach. It could be the subject of a study for a Math student (too hard for me…).")#linebreak()#text(" Succeeding in proving the conjectures would be a great success !")

#text("If you are interested by this subject, just contact me at")#linebreak()#text(" tony . reix @ laposte . net .")

#text("Regards,")#linebreak()#text(" Tony")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The AKS primality test « What’s new")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-40964")[#strong[#text("The AKS primality test « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("[…] numbers. (The situation improves though for more special types of , such as Mersenne numbers; see my earlier post on the Lucas-Lehmer test for more […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24d9a0b9a87d20a0993c0a7a8cf85d9d0747b5c8f7b9aa2b934e3e0f12cb1f67-513242c3e54d12a8cb84c4db7b788bca491764c2d6cc16e095b60b63169e6b5a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of trex58")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-42584")[#strong[#text("trex58")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2009")])]

#text("OK.")#linebreak()#text(" Look at: ")#link("http://tony.reix.free.fr/Mersenne/SummaryOfThe3Conjectures.pdf")[#text("http://tony.reix.free.fr/Mersenne/SummaryOfThe3Conjectures.pdf")]#linebreak()#text(" and: ")#link("http://trex58.wordpress.com/math2matiques/")[#text("http://trex58.wordpress.com/math2matiques/")]#linebreak()#text(" for more information.")#linebreak()#text(" Tony")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24d9a0b9a87d20a0993c0a7a8cf85d9d0747b5c8f7b9aa2b934e3e0f12cb1f67-513242c3e54d12a8cb84c4db7b788bca491764c2d6cc16e095b60b63169e6b5a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of trex58")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-43746")[#strong[#text("trex58")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2010")])]

#text("Thanks to the Vrba-Reix conjecture based on the ideas I talked previously in this page, and thanks to the version 3.8.0 of LLR by Jean Penné, I’ve been able to find a new Wagstaff PRP : (2^4031399+1)/3 , which is today the 3rd biggest PRP number ever found, with 1,213,572 digits. With a proof of Vrba’s conjecture, it would turn into a prime, the 22th biggest one.")#linebreak()#text(" See: ")#link("http://www.primenumbers.net/prptop/prptop.php?page=1#haut")[#text("http://www.primenumbers.net/prptop/prptop.php?page=1#haut")]

#text("Regards,")#linebreak()#text(" Tony Reix")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ac3c76aa80d152ff714ebde7860c6f7faa34ec75003e82518a3612d564cfe22-1ebff00a84a42d109c55c13c09f479a57e6eaee2aac59060c8356b26585ebe2c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guntram Hainke")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-50927")[#strong[#text("Guntram Hainke")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2011")])]

#text("I think one can even do with less magic than in the text. Suppose that $q=2^n-1$ is a Mersenne prime.")#linebreak()#text(" Consider the field $F=F_{q^2}$ and recall that there is a homomorphism $n: F^\\times \\to F_q$ given by $N(x)=x\\cdot x^q$, the norm. Let $N$ denote the kernel of this homomorphism, i.e. the subgroup of elements of norm 1.")#linebreak()#text(" Then $N$ has order $p+1$ and is cyclic as it is a finite subgroup of the multiplicative group of a field.")#linebreak()#text(" The magic of the Lucas-Lehmer test is that $2+\\sqrt{3}$ is a generator for this group, regardless of which Mersenne prime we consider.")#linebreak()#text(" But let me stress that the fact that there is such an element (of norm 1) follows from general theory.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/878699eaa6d217727c4edaeb1db20ddc8952c420bf3b33aa2734601cc4ab72dc-ec6a6fbd29669667ec8085df41dde1c52195a733bff13e4604ba2f5e2801d195.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Two applications of finite fields to computational number theory | Matt Baker's Math Blog")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-253782")[#strong[#text("Two applications of finite fields to computational number theory | Matt Baker's Math Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2013")])]

#text("[…] is due to Michael Rosen, with simplifications by J.W. Bruce. Our exposition was influenced by this blog post written by Terry Tao, which the interested reader should definitely […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-420737")[#strong[#text("My great WordPress blog – Econlinks")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2014")]

#text("[…] are interested in finding prime numbers with tens of millions of digits. And a nice exposition of the Lucas-Lehmer test for Mersenne primes by Terry Tao, to whom I owe also the previous […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71dc76e39b896600977ddc4a20cd93b0548ce5dc1a18a1d43593fc9492ac7a6c-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy Rocketman")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-491304")[#strong[#text("Andy Rocketman")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2018")])]

#text("Dear Prof. Tao,")

#text("I don’t know if this is even a proper question, but:")

#text("The LL test with starting values of 4 generates an accompanying sequence of Heronian triangles, as in: [13,14,15],[193,194,195],[37633,37634,37635]")

#text("The second to last and final LL residual sometimes have an accompanying Pythagorean triple (depending on the Lehmer symbol), as in: [15,112,113],[511,130560,130561],[1023,523264,523265]")

#text("Does this suggest some geometric analogy underlying the test that involves triangles?")

#text("Sorry if this is a silly question!")

#text("Andy")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a474a2954360efecb5ae4ffca9f1da1667332bba7d2fd0de36a34a646a7d1096-59a12bc0abd4a2eac43ac9b84015872da39a13aa6e84b9332c4d065c9c6148d8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LUIS MARTINEZ")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-669607")[#strong[#text("LUIS MARTINEZ")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2022")])]

#text("Mersenne Primes Problem Solved (Enfer Diez)")

#text("That is to say, to know which Mersenne number is prime (without the factorization), ieasy to verify with the known primes and, in turn; determine new primes whatever the digit number.")

#text("If ")#mi("2^{p} - 1 = p_{n}")#text(" is a Mersenne prime we will have:")

#text("If ")#mi("3p - 1 = \\frac{3[4x+1] + 1}{5}")

#text("Then: ")#mi("p_{n} + 1 = \\frac{3[4x+1] + 1}{5} = 2^{p}")#text(".")

#text("Examples")

#mi("3*11-1 = \\frac{3[4*13 + 1] + 1}{5}")

#mi("3*43-1 = \\frac{3[4*53 + 1] + 1}{5}")

#mi("3*2731 - 1 = \\frac{3[4*3413 + 1] + 1}{5}")

#mi("3*174763 - 1 = \\frac{3[4*218453 + 1] + 1}{5}")

#mi("3*715827883 - 1 = \\frac{3[4*894784853 + 1] + 1}{5}")

#mi("3*768614336404564651 - 1 = \\frac{3[4*960767920505455813 + 1] + 1}{5}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luis martinez")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-670367")[#strong[#text("Luis martinez")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2022")])]

#text("For those interested in the Mersenne primes and in the of Enfer method; (x) always follows a pattern:")

#mi("3*4^{a} + 4^{a-1} + 4^{a-2} + .........+ 4^{a-a}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/#comment-689169")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2025")])]

#text("What do you mean by the algorithm is “somewhat ")#link("http://en.wikipedia.org/wiki/Parallel_computing")[#text("parallelisable")]#text(".”?")
]
