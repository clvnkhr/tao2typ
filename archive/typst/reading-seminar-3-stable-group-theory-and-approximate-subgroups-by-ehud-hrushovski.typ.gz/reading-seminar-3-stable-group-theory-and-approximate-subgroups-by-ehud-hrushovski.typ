// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/10/29/reading-seminar-3-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/
// Converted to Typst by tao2typ: "2026-10-14T15:17:30.451019+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Reading seminar 3: “Stable group theory and approximate subgroups”, by Ehud Hrushovski", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Reading seminar 3: “Stable group theory and approximate subgroups”, by Ehud Hrushovski")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 October 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/10/29/reading-seminar-3-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/")[#text("https://terrytao.wordpress.com/2009/10/29/reading-seminar-3-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("This week, ")#link("http://www.math.ucla.edu/~hpt/")[#text("Henry Towsner")]#text(" continued some model-theoretic preliminaries for the ")#link("https://terrytao.wordpress.com/category/teaching/logic-reading-seminar/")[#text("reading seminar")]#text(" of the ")#link("http://arxiv.org/abs/0909.2190")[#text("Hrushovski paper")]#text(", particularly regarding the behaviour of wide types, leading up to the main model-theoretic theorem (Theorem 3.4 of Hrushovski) which in turn implies the various combinatorial applications (such as Corollary 1.2 of Hrushovski). Henry’s notes can be found ")#link("https://terrytao.wordpress.com/wp-content/uploads/2009/10/hrushovskinotes-1.pdf")[#text("here")]#text(".")

#text("A key theme here is the phenomenon that any pair of large sets contained inside a definable set of finite measure (such as ")#mi("{X \\cdot X^{-1}}")#text(") must intersect if they are sufficiently “generic”; the notion of a wide type is designed, in part, to capture this notion of genericity.")

#metadata(none) <tao-a4f943722f2cd53491bb>

#heading(level: 1)[#strong[#text(" — 1. Global types — ")]]

#text("Throughout this post, we begin with a countable structure ")#mi("{M}")#text(" of a language ")#mi("{L}")#text(", and then consider a universal elementary extension ")#mi("{{\\Bbb U}}")#text(" of ")#mi("{M}")#text(" (i.e. one that obeys the saturation and homogeneity properties as discussed in ")#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/")[#text("Notes 1")]#text(". Later on, ")#mi("{L}")#text(" will contain the language of groups, and then we will rename ")#mi("{{\\Bbb U}}")#text(" as ")#mi("{G}")#text(" to emphasise this.")

#text("Recall from ")#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/")[#text("Notes 1")]#text(" that a ")#emph[#text("partial type")]#text(" over a set ")#mi("{A}")#text(" is a set of formulae (with ")#mi("{n}")#text(" variables for some fixed ")#mi("{n}")#text(") using ")#mi("{A}")#text(" as constant symbols, which is consistent and contains the theory of ")#mi("{M}")#text("; if the set of formulae is maximal (i.e. complete), then it is a ")#emph[#text("type")]#text(". One can also think of a type as an ultrafilter over the ")#mi("{A}")#text("-definable sets; if ")#mi("{p}")#text(" is a type and ")#mi("{B}")#text(" is an ")#mi("{A}")#text("-definable set given by some formula ")#mi("{\\phi}")#text(", then either ")#mi("{\\phi}")#text(" lies in ")#mi("{p}")#text(" (in which case we write ")#mi("{p \\subset B}")#text(") or ")#mi("{\\neg \\phi}")#text(" lies in ")#mi("{p}")#text(" (in which case we write ")#mi("{p \\subset \\overline{B}}")#text(") but not both.")

#text("When the set ")#mi("{A}")#text(" is small (i.e. has cardinality less than that of ")#mi("{{\\Bbb U}}")#text(", which in particular would be true of ")#mi("{A}")#text(" consisted of ")#mi("{M}")#text(" union with a finite set, which is a very typical situation), then by saturation one can identify types (or partial types) with the subset ")#mi("{p({\\Bbb U})}")#text(" of ")#mi("{{\\Bbb U}^n}")#text(" that they cut out. In particular, these sets are non-empty. Adding more formulae to a partial type corresponds to shrinking the set that they cut out, and vice versa.")

#text("However, if we have a ")#emph[#text("global")]#text(" type ")#mi("{p}")#text(" – a type defined over the entire model ")#mi("{{\\Bbb U}}")#text(" – then one can no longer identify types with the set ")#mi("{p({\\Bbb U})}")#text(" that they cut out, because these sets are usually empty! However, what we can do is ")#emph[#text("restrict")]#text(" ")#mi("{p}")#text(" to some smaller set ")#mi("{A}")#text(" of constants to create a type ")#mi("{p\\downharpoonright_A}")#text(" over ")#mi("{A}")#text(", defined as the set of all formulae in ")#mi("{p}")#text(" that only involve the constants in ")#mi("{A}")#text(". It is easy to see that this is still a type, and if ")#mi("{A}")#text(" is small, it cuts out a non-empty set in ")#mi("{{\\Bbb U}^n}")#text(".")

#text("A global type ")#mi("{p}")#text(" is said to be ")#emph[#mi("{M}")#text("-invariant")]#text(", or ")#emph[#text("invariant")]#text(" for short, if the set of formulae in ")#mi("{p}")#text(" is invariant under any automorphism ")#mi("{\\sigma}")#text(" of ")#mi("{{\\Bbb U}}")#text(" that fixes ")#mi("{M}")#text(". In particular, given any ")#mi("{M}")#text("-definable set ")#mi("{A \\subset {\\Bbb U}^n \\times {\\Bbb U}^m}")#text(" and ")#mi("{b \\in {\\Bbb U}^m}")#text(", we see that ")#mi("{p \\subset A_b}")#text(" if and only if ")#mi("{p \\subset A_{\\sigma(b)}}")#text(", where ")#mi("{A_b := \\{ a \\in {\\Bbb U}^n: (a,b) \\in A \\}}")#text(" is a slice of ")#mi("{A}")#text(". (Indeed, this gives an equivalent definition of invariance.)")

#text("A trivial example of an invariant global type would be the type of an element ")#mi("{m \\in M}")#text(" (or in ")#mi("{M^n}")#text("). This cuts out a singleton set ")#mi("{\\{m\\}}")#text(". This is in fact the only invariant global type that cuts out anything at all:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1")]#text(" Let ")#mi("{p}")#text(" be a global invariant type. Then ")#mi("{p}")#text(" is realisable in ")#mi("{{\\Bbb U}}")#text(" (i.e. ")#mi("{p({\\Bbb U})}")#text(" is non-empty) if and only if it is realisable in ")#mi("{M}")#text(" (and is the type of a single element in ")#mi("{M}")#text(").")
]

#emph[#text("Proof:")]#text(" Suppose ")#mi("{p}")#text(" is realisable in ")#mi("{{\\Bbb U}}")#text(" by some ")#mi("{a \\in p({\\Bbb U})}")#text(". Since the formula ")#mi("{x=a}")#text(" is definable in ")#mi("{{\\Bbb U}}")#text(", we see that ")#mi("{p \\subset \\{ x: x = a \\}}")#text(", i.e. ")#mi("{p}")#text(" cuts out precisely the singleton set ")#mi("{\\{a\\}}")#text(". As ")#mi("{p}")#text(" is invariant, ")#mi("{\\{a\\}}")#text(" must then be invariant under all ")#mi("{M}")#text("-fixing automorphisms of ")#mi("{{\\Bbb U}}")#text(". By homogeneity, this means that there is no element distinct from ")#mi("{a}")#text(" which is elementarily indistinguishable from ")#mi("{a}")#text(" over ")#mi("{M}")#text("; in other words, ")#mi("{\\{a\\}}")#text(" is the set cut out by the type ")#mi("{tp(a/M)}")#text(" of ")#mi("{a}")#text(" over ")#mi("{M}")#text(".")

#text("By saturation, the formula ")#mi("{x \\neq a}")#text(" together with the formulae in ")#mi("{tp(a/M)}")#text(" is not satisfiable, hence not finitely satisfiable. Thus there is a finite set of formulae in ")#mi("{tp(a/M)}")#text(" that cut out ")#mi("{\\{a\\}}")#text(", i.e. ")#mi("{\\{a\\}}")#text(" is definable over ")#mi("{M}")#text(". But as ")#mi("{{\\Bbb U}}")#text(" is an elementary extension of ")#mi("{M}")#text(", these formulae must also be realisable in ")#mi("{M}")#text(", i.e. ")#mi("{a}")#text(" lies in ")#mi("{M}")#text(", and the claim follows. ")#mi("\\Box")

#text("(Because of this, one should regard the notation ")#mi("{p \\subset B}")#text(" carefully; the set ")#mi("{p({\\Bbb U})}")#text(" that ")#mi("{p}")#text(" cuts out in the model ")#mi("{{\\Bbb U}}")#text(" may in fact be empty, but when we write ")#mi("{p \\subset B}")#text(" for some definable ")#mi("{B}")#text(", we interpret this syntactically rather than semantically (or equivalently, that ")#mi("{p({\\Bbb U}^{\\prime}) \\subset B({\\Bbb U}^{\\prime})}")#text(" holds in all extensions ")#mi("{{\\Bbb U}^{\\prime}}")#text(" of ")#mi("{{\\Bbb U}}")#text(", and not just in ")#mi("{{\\Bbb U}}")#text(" itself.)")

#text("On the other hand, invariant global types exist in abundance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" ")#metadata(none) <tao-a7e7e2f59b128bdb0aa6>#text(" Let ")#mi("{p}")#text(" be a type over ")#mi("{M}")#text(". Then there exists an invariant global type ")#mi("{q}")#text(" that refines ")#mi("{p}")#text(" (i.e. it contains all the formulae that ")#mi("{p}")#text(" does).")
]

#emph[#text("Proof:")]#text(" We view ")#mi("{p}")#text(" as a collection of logically consistent formulae. We enlarge this collection to a larger one ")#mi("{p^{\\prime}}")#text(" by adding in the negations of all the formulae definable over ")#mi("{{\\Bbb U}}")#text(" that are not realisable in ")#mi("{M}")#text(". Observe that this collection remains logically consistent, because any finite set of formulae in ")#mi("{p}")#text(" were realisable in ")#mi("{{\\Bbb U}}")#text(", hence in ")#mi("{M}")#text(" (which is an elementary substructure). Hence, by Zorn’s lemma, one can extend ")#mi("{p^{\\prime}}")#text(" to a global type ")#mi("{q}")#text(".")

#text("We now claim that ")#mi("{q}")#text(" is invariant. Indeed, let ")#mi("{\\phi}")#text(" be a sentence over ")#mi("{{\\Bbb U}}")#text(" that is contained in ")#mi("{q}")#text(", and let ")#mi("{\\sigma}")#text(" be an automorphism that fixes ")#mi("{M}")#text(". If ")#mi("{\\sigma(\\phi)}")#text(" is not in ")#mi("{q}")#text(", then ")#mi("{\\neg \\sigma(\\phi)}")#text(" must be in ")#mi("{q}")#text(" (by completeness), and hence ")#mi("{\\phi \\wedge \\neg \\sigma(\\phi)}")#text(" is in ")#mi("{q}")#text(" also, and hence must be realisable in ")#mi("{M}")#text(" (otherwise its negation would be in ")#mi("{p^{\\prime}}")#text(", and hence in ")#mi("{q}")#text("). But this is absurd since ")#mi("{\\sigma}")#text(" fixes ")#mi("{M}")#text(". Thus ")#mi("{\\sigma(\\phi)}")#text(" does lie in ")#mi("{q}")#text(", yielding invariance.")

#text("A major use of invariant global types for us will be that they can be used to generate sequences of indiscernibles (as defined in ")#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/")[#text("previous notes")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" ")#metadata(none) <tao-7dd04b0145ffa5646536>#text(" Let ")#mi("{p}")#text(" be a global invariant type of some arity ")#mi("{d}")#text(", and construct recursively a sequence ")#mi("{b_1, b_2, \\ldots \\in {\\Bbb U}^d}")#text(" by requiring ")#mi("{b_n \\in p\\downharpoonright_{M \\cup \\{b_1,\\ldots,b_{n-1}\\}}({\\Bbb U})}")#text(" for all ")#mi("{n=1,2,\\ldots}")#text(". (This is always possible since types are satisfiable once restricted to small sets, by saturation, as discussed earlier). Then ")#mi("{b_1,b_2,\\ldots}")#text(" are indiscernible over ")#mi("{M}")#text(", i.e. the tuples ")#mi("{(b_{i_1},\\ldots,b_{i_k})}")#text(" for ")#mi("{i_1 < \\ldots < i_k}")#text(" are elementarily indistinguishable (over ")#mi("{M}")#text(") for any fixed ")#mi("{k}")#text(".")
]

#emph[#text("Proof:")]#text(" This is achieved by an induction on ")#mi("{k}")#text(". The ")#mi("{k=1}")#text(" case is clear since the ")#mi("{b_n}")#text(" all have type ")#mi("{p\\downharpoonright_M}")#text(" over ")#mi("{M}")#text(". Now we do the ")#mi("{k=2}")#text(" case. It suffices to show that ")#mi("{(b_1,b_2)}")#text(" and ")#mi("{(b_i,b_j)}")#text(" are elementarily indistinguishable over ")#mi("{M}")#text(" for all ")#mi("{i < j}")#text(".")

#text("By construction, ")#mi("{b_2}")#text(" and ")#mi("{b_j}")#text(" have the same type over ")#mi("{M \\cup \\{b_1\\}}")#text(", and so ")#mi("{(b_1,b_2)}")#text(" and ")#mi("{(b_1,b_j)}")#text(" are elementarily indistinguishable over ")#mi("{M}")#text(". So it remains to show that ")#mi("{(b_1,b_j)}")#text(" and ")#mi("{(b_i,b_j)}")#text(" are elementarily indistinguishable.")

#text("Let ")#mi("{A}")#text(" be an ")#mi("{M}")#text("-definable relation that contains ")#mi("{(b_1,b_j)}")#text("; we need to show that ")#mi("{A}")#text(" contains ")#mi("{(b_i,b_j)}")#text(" also.")

#text("Since ")#mi("{b_1}")#text(" and ")#mi("{b_i}")#text(" have the same type over ")#mi("{M}")#text(", by homogeneity there exists an automorphism ")#mi("{\\sigma}")#text(" of ")#mi("{{\\Bbb U}}")#text(" fixing ")#mi("{M}")#text(" that maps ")#mi("{b_1}")#text(" to ")#mi("{b_i}")#text(". Since ")#mi("{b_j}")#text(" realises ")#mi("{p\\downharpoonright_{M \\cup \\{b_1\\}}}")#text(", we see that ")#mi("{p}")#text(" contains the sentence ")#mi("{(b_1,x) \\in A}")#text(", hence by invariance ")#mi("{p}")#text(" contains ")#mi("{(b_i,x) \\in A}")#text(" also. Since ")#mi("{b_j}")#text(" realises ")#mi("{p\\downharpoonright_{M \\cup \\{b_i\\}}}")#text(", we conclude ")#mi("{(b_i,b_j) \\in A}")#text(", as required.")

#text("This concludes the ")#mi("{k=2}")#text(" case. The higher ")#mi("{k}")#text(" case is similar and is left as an exercise. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 2. Intersections of wide types — ")]]

#text("Now we assume that the structure ")#mi("{{\\Bbb U}}")#text(" is equipped with an ")#mi("{M}")#text("-invariant Kiesler measure ")#mi("{\\mu}")#text(". This leads to the notion of a ")#emph[#text("wide type")]#text(" – a type such that all the ")#mi("{{\\Bbb U}}")#text("-definable sets containing this type have positive measure. Intuitively, elements of a wide type are distributed “generically” in the structure.")

#text("In the ")#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/")[#text("previous notes")]#text(" we showed that wide types can be “split” amongst indiscernables, as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4")]#text(" ")#metadata(none) <tao-f350df2d9f2e51fd0413>#text(" Let ")#mi("{b}")#text(" be an element or tuple in ")#mi("{{\\Bbb U}}")#text(", let ")#mi("{a}")#text(" be a wide type over ")#mi("{M \\cup \\{b\\}}")#text(" for some set of constants ")#mi("{M}")#text(", and let ")#mi("{b_1,b_2,\\ldots}")#text(" be a sequence of indiscernibles (over ")#mi("{M}")#text(") that has the same type as ")#mi("{b}")#text(" (over ")#mi("{M}")#text("). Then for any finite number ")#mi("{b_1,\\ldots,b_n}")#text(" in this sequence, one can find a type ")#mi("{a^{\\prime}}")#text(" such that ")#mi("{a^{\\prime}}")#text(" has the same type over ")#mi("{b_i}")#text(" as ")#mi("{a}")#text(" does over ")#mi("{b}")#text(", for all ")#mi("{1 \\leq i \\leq n}")#text(".")
]

#text("We now use this lemma to show that sets defined by wide types intersect each other in a uniform fashion.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5")]#text(" ")#metadata(none) <tao-c9df2895b19aed79f482>#text(" Let ")#mi("{p,q}")#text(" be types over ")#mi("{M}")#text(", and let ")#mi("{a,a^{\\prime} \\in p({\\Bbb U})}")#text(", ")#mi("{b,b^{\\prime} \\in q({\\Bbb U})}")#text(" be realisations of ")#mi("{a,b}")#text(" such that ")#mi("{tp(a/M \\cup \\{b\\})}")#text(" and ")#mi("{tp(a^{\\prime}/M \\cup \\{b^{\\prime}\\})}")#text(" are wide. Let ")#mi("{A_x}")#text(", ")#mi("{B_y}")#text(" be ")#mi("{M}")#text("-definable sets with parameters, contained inside an ")#mi("{M}")#text("-definable set ")#mi("{X}")#text(" of finite measure; then ")#mi("{\\mu(A_a \\cap B_b) > 0}")#text(" if and only if ")#mi("{\\mu(A_{a^{\\prime}} \\cap B_{b^{\\prime}}) > 0}")#text(".")
]

#emph[#text("Proof:")]#text(" By homogeneity, there is an automorphism fixing ")#mi("{M}")#text(" that sends ")#mi("{b}")#text(" to ")#mi("{b^{\\prime}}")#text(", and maps ")#mi("{a}")#text(" to another element of ")#mi("{p({\\Bbb U})}")#text(". Thus without loss of generality we may assume ")#mi("{b=b^{\\prime}}")#text(".")

#text("We assume for contradiction that ")#mi("{\\mu(A_a \\cap B_b) > \\delta > 0}")#text(" and ")#mi("{\\mu(A_{a^{\\prime}} \\cap B_{b^{\\prime}}) = 0}")#text(".")

#text("By Lemma ")#link(<tao-a7e7e2f59b128bdb0aa6>)[#text("2")]#text(", we may extend ")#mi("{q}")#text(" to an invariant global type ")#mi("{q^{\\prime}}")#text(". Observe that for any ")#mi("{\\epsilon > 0}")#text(", either one has ")#mi("{\\mu(A_a \\cap B_x) \\geq \\epsilon}")#text(" for all ")#mi("{x \\in q^{\\prime}\\downharpoonright_{M \\cup \\{a\\}}}")#text(", or one has ")#mi("{\\mu(A_a \\cap B_x) \\leq \\epsilon}")#text(" for all ")#mi("{x \\in q^{\\prime}\\downharpoonright_{M \\cup \\{a\\}}}")#text(" (since there is a ")#mi("{M \\cup \\{a\\}}")#text("-definable set between ")#mi("{\\{ x: \\mu(A_a \\cap B_x) \\geq \\epsilon \\}}")#text(" and ")#mi("{\\{ x: \\mu(A_a \\cap B_x) > \\epsilon \\}}")#text(". Suppose first that the former option holds for some ")#mi("{\\epsilon}")#text(", thus there is a uniform lower bound ")#mi("{\\mu(A_a \\cap B_x) > \\epsilon}")#text(". We now define a sequence ")#mi("{a_1,a_2,\\ldots \\in p({\\Bbb U})}")#text(" and an indiscernible sequence ")#mi("{b_1,b_2,\\ldots \\in q({\\Bbb U})}")#text(" as follows:")

#list(
[#text("We initialise ")#mi("{a_1=a}")#text(" and ")#mi("{b_1}")#text(" to be a realisation of ")#mi("{q^{\\prime}\\downharpoonright_{M \\cup \\{a_1\\}}}")#text(".")],
[#text("Now suppose that ")#mi("{a_1,\\ldots,a_n,b_1,\\ldots,b_n}")#text(" have been chosen with ")#mi("{b_1,\\ldots,b_n}")#text(" indiscernible. By Lemma ")#link(<tao-f350df2d9f2e51fd0413>)[#text("4")]#text(", we can find ")#mi("{a_{n+1} \\in p({\\Bbb U})}")#text(" that has the same type over ")#mi("{b_i}")#text(" that ")#mi("{a^{\\prime}}")#text(" has over ")#mi("{b^{\\prime}}")#text(" for all ")#mi("{1 \\leq i \\leq n}")#text(". Since ")#mi("{\\mu(A_{a^{\\prime}} \\cap B_{b^{\\prime}}) = 0}")#text(", this implies that ")#mi("{\\mu( A_{a_{n+1}} \\cap B_{b_i} ) = 0}")#text(" for all ")#mi("{1 \\leq i \\leq n}")#text(". (Here we use the fact that ")#mi("{\\mu( A_x \\cap B_b )=0}")#text(" is a type-definable formula over ")#mi("{M}")#text(" and ")#mi("{b}")#text(".)")],
[#text("Now, let ")#mi("{b_{n+1}}")#text(" be a realisation of ")#mi("{q^{\\prime}\\downharpoonright_{M \\cup \\{a_1,\\ldots,a_{n+1},b_1,\\ldots,b_n\\}}}")#text(". With this construction and Lemma ")#link(<tao-7dd04b0145ffa5646536>)[#text("3")]#text(" we see by induction that ")#mi("{b_1,\\ldots,b_{n+1}}")#text(" is also indiscernible; now we iterate the procedure.")]
)

#text("Let ")#mi("{C_i}")#text(" be the set ")#mi("{C_i := A_{a_i} \\cap B_{b_i}}")#text(", then observe from the above construction that ")#mi("{C_i}")#text(" lies in ")#mi("{X}")#text(" and ")#mi("{\\mu(C_i \\cap C_j) = 0}")#text(" for all ")#mi("{i < j}")#text(". On the other hand, we claim that ")#mi("{\\mu(C_i)}")#text(" is uniformly bounded away from zero, this contradicts the finite measure of ")#mi("{\\mu(X)}")#text(" by the pigeonhole principle.")

#text("To see the uniform lower bound, find an automorphism ")#mi("{\\sigma_i}")#text(" fixing ")#mi("{M}")#text(" that maps ")#mi("{a_1}")#text(" to ")#mi("{a_i}")#text(". By hypothesis, ")#mi("{\\mu(A_{a_1} \\cap B_{b_1}) > 0}")#text(", thus there exists a rational ")#mi("{r > 0}")#text(" such that the predicate that models ")#mi("{\\mu(A_{a_1} \\cap B_x) > r}")#text(" is in ")#mi("{\\tilde q}")#text(", hence in ")#mi("{q^{\\prime}}")#text(". By invariance, the predicate ")#mi("{\\mu(A_{a_i} \\cap B_x) > r}")#text(" is in ")#mi("{q^{\\prime}}")#text(" also, hence by construction of ")#mi("{b_i}")#text(", ")#mi("{\\mu(A_{a_i} \\cap B_{b_i}) > r}")#text(", and the claim follows.")

#text("Now we consider the opposite case, in which ")#mi("{\\mu(A_a \\cap B_x) = 0}")#text(" for all ")#mi("{x \\in q^{\\prime}\\downharpoonright_{M \\cup \\{a\\}}}")#text(". Then we run the construction slightly differently: for each ")#mi("{n}")#text(" in turn, set ")#mi("{b_n}")#text(" to be a realisation of ")#mi("{q^{\\prime}\\downharpoonright_{M \\cup \\{a_1,\\ldots,a_{n-1},b_1,\\ldots,b_{n-1}}}")#text(", then set ")#mi("{a_n \\in p({\\Bbb U})}")#text(" so that ")#mi("{\\mu(A_{a_n} \\cap B_{b_n}) > \\delta}")#text(". (This is possible because for any definable set ")#mi("{C}")#text(" containing ")#mi("{p}")#text(", the ")#mi("{\\bigwedge}")#text("-definable set ")#mi("{\\{ x \\in C: \\mu(A_x \\cap B_b) \\geq \\delta \\}}")#text(" contains ")#mi("{p}")#text(" and thus has positive measure, and so the same is true for ")#mi("{b_n}")#text("; now use saturation.) Then again we see that the ")#mi("{C_i}")#text(" lie in ")#mi("{X}")#text(", have intersection of measure zero, and have measure uniformly bounded from below, and we again obtain a contradiction. ")#mi("\\Box")

#text("Now we place a group structure on ")#mi("{{\\Bbb U}}")#text(", and obtain a variant of the above result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6")]#text(" Let ")#mi("{p, q}")#text(" be types in ")#mi("{M}")#text(", with ")#mi("{p}")#text(" wide. Suppose that ")#mi("{p}")#text(", ")#mi("{q}")#text(" are contained in ")#mi("{M}")#text("-definable sets ")#mi("{X, X^{\\prime}}")#text(" such that ")#mi("{XX^{\\prime}}")#text(" has finite measure. Let ")#mi("{a,b \\in q}")#text(" be such that the type of ")#mi("{a}")#text(" over ")#mi("{M \\cup \\{b\\}}")#text(" is wide. Assume also that the Keisler measure is translation-invariant. Then ")#mi("{pa \\cap pb}")#text(" is also wide.")
]

#emph[#text("Proof:")]#text(" Suppose this is not the case, so that there exists an ")#mi("{M}")#text("-definable set ")#mi("{A}")#text(" containing ")#mi("{p}")#text(" such that ")#mi("{Aa \\cap Ab}")#text(" has zero measure. (Initially, one would need two different definable sets containing ")#mi("{p}")#text(", but one can simply take their intersection.) On the other hand, as ")#mi("{p}")#text(" is wide, ")#mi("{A}")#text(" itself has positive measure. We can place ")#mi("{A}")#text(" in ")#mi("{X}")#text(".")

#text("By using the fact that wide types over one set of constants can be refined to wide types over larger sets of constants (Lemma 2 from the ")#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/")[#text("previous notes")]#text("), we see that we can recursively construct a sequence ")#mi("{a_1, a_2, \\ldots \\in q({\\Bbb U})}")#text(" with ")#mi("{tp(a_n/M \\cup \\{a_1,\\ldots,a_{n-1}\\})}")#text(" wide for all ")#mi("{n}")#text(". Since ")#mi("{\\mu(Aa \\cap Ab) = 0}")#text(", we conclude from Lemma ")#link(<tao-c9df2895b19aed79f482>)[#text("5")]#text(" that ")#mi("{\\mu(A a_n \\cap A a_i)=0}")#text(" for all ")#mi("{1 \\leq i < n}")#text(". On the other hand, the ")#mi("{\\mu(Aa_i)}")#text(" all have the same measure as ")#mi("{\\mu(A)}")#text(", which is positive. Finally, the ")#mi("{Aa_i}")#text(" are all contained in ")#mi("{XX^{\\prime}}")#text(", which has finite measure; this leads to a contradictoin. ")#mi("\\Box")

#text("This “generic intersection” property of translates of ")#mi("{p}")#text(" will be important in later arguments when creating near-groups.")

#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c346a8d5495c19291c880f60e4b1aea5cdd6890a37ad36e5d011577689045ff-ee9cf8a938002502ac2fdab30a6951026abb1b6e1e49386bca5e4044a5fc7b7d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ayhangunaydin")]], [#link("https://terrytao.wordpress.com/2009/10/29/reading-seminar-3-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-42100")[#strong[#text("ayhangunaydin")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2009")])]

#text("I think the type p should be invariant in Lemma 1. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/29/reading-seminar-3-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-42215")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2009")])]

#text("Lou van den Dries has kindly made his own notes on the Hrushovski paper available at")

#link("http://www.math.uiuc.edu/~vddries/approx.dvi")[#text("http://www.math.uiuc.edu/~vddries/approx.dvi")]

#text("I understand that they may continue to be updated in the future. (I think that in the next post in this series I will collect all the various links to other notes that people have been supplying.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Link")]], [#link("https://terrytao.wordpress.com/2009/10/29/reading-seminar-3-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-42219")[#strong[#text("Link")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2009")])]

#text("How do you open .dvi files?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/29/reading-seminar-3-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-42225")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2009")])]

#text("A PDF version is also available at")

#link("http://www.math.uiuc.edu/~vddries/approx.pdf")[#text("Click to access approx.pdf")]
]
]
