// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/
// Converted to Typst by tao2typ: "2026-10-14T16:36:37.886508+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 2: Building Lie structure from representations and metrics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 2: Building Lie structure from representations and metrics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 September 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/")[#text("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://en.wikipedia.org/wiki/Hilbert's_fifth_problem")[#text("Hilbert’s fifth problem")]#text(" concerns the minimal hypotheses one needs to place on a ")#link("http://en.wikipedia.org/wiki/Topological_group")[#text("topological group")]#text(" ")#mi("{G}")#text(" to ensure that it is actually a ")#link("http://en.wikipedia.org/wiki/Lie_group")[#text("Lie group")]#text(". In the previous set of notes, we saw that one could reduce the regularity hypothesis imposed on ")#mi("{G}")#text(" to a “")#mi("{C^{1,1}}")#text("” condition, namely that there was an open neighbourhood of ")#mi("{G}")#text(" that was isomorphic (as a local group) to an open subset ")#mi("{V}")#text(" of a Euclidean space ")#mi("{{\\bf R}^d}")#text(" with identity element ")#mi("{0}")#text(", and with group operation ")#mi("{\\ast}")#text(" obeying the asymptotic")

#align(center)[#tao-fit-display[#tao-math("x \\ast y = x + y + O(\\left|x\\right| \\left|y\\right|)", block: true)]]

#text("for sufficiently small ")#mi("{x,y}")#text(". We will call such local groups ")#mi("{(V,\\ast)}")#text(" ")#emph[#mi("{C^{1,1}}")#text(" local groups")]#text(".")

#text("We now reduce the regularity hypothesis further, to one in which there is no explicit Euclidean space that is initially attached to ")#mi("{G}")#text(". Of course, Lie groups are still locally Euclidean, so if the hypotheses on ")#mi("{G}")#text(" do not involve any explicit Euclidean spaces, then one must somehow build such spaces from other structures. One way to do so is to exploit an ambient space with Euclidean or Lie structure that ")#mi("{G}")#text(" is embedded or immersed in. A trivial example of this is provided by the following basic fact from linear algebra:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1")]#text(" If ")#mi("{V}")#text(" is a finite-dimensional vector space (i.e. it is isomorphic to ")#mi("{{\\bf R}^d}")#text(" for some ")#mi("{d}")#text("), and ")#mi("{W}")#text(" is a linear subspace of ")#mi("{V}")#text(", then ")#mi("{W}")#text(" is also a finite-dimensional vector space.")
]

#text("We will establish a non-linear version of this statement, known as Cartan’s theorem. Recall that a subset ")#mi("{S}")#text(" of a ")#mi("{d}")#text("-dimensional smooth manifold ")#mi("{M}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Submanifold")[#mi("{d^{\\prime}}")#text("-dimensional smooth (embedded) submanifold")]#text(" of ")#mi("{M}")#text(" for some ")#mi("{0 \\leq d^{\\prime} \\leq d}")#text(" if for every point ")#mi("{x \\in S}")#text(" there is a smooth coordinate chart ")#mi("{\\phi: U \\rightarrow V}")#text(" of a neighbourhood ")#mi("{U}")#text(" of ")#mi("{x}")#text(" in ")#mi("{M}")#text(" that maps ")#mi("{x}")#text(" to ")#mi("{0}")#text(", such that ")#mi("{\\phi(U \\cap S) = V \\cap {\\bf R}^{d^{\\prime}}}")#text(", where we identify ")#mi("{{\\bf R}^{d^{\\prime}} \\equiv {\\bf R}^{d^{\\prime}} \\times \\{0\\}^{d-d^{\\prime}}}")#text(" with a subspace of ")#mi("{{\\bf R}^d}")#text(". Informally, ")#mi("{S}")#text(" locally sits inside ")#mi("{M}")#text(" the same way that ")#mi("{{\\bf R}^{d^{\\prime}}}")#text(" sits inside ")#mi("{{\\bf R}^d}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Cartan’s theorem)")]#text(" ")#metadata(none) <tao-9b3fea8ad52e1f62033b>#text(" If ")#mi("{H}")#text(" is a (topologically) closed subgroup of a Lie group ")#mi("{G}")#text(", then ")#mi("{H}")#text(" is a smooth submanifold of ")#mi("{G}")#text(", and is thus also a Lie group.")
]

#text("Note that the hypothesis that ")#mi("{H}")#text(" is closed is essential; for instance, the rationals ")#mi("{{\\bf Q}}")#text(" are a subgroup of the (additive) group of reals ")#mi("{{\\bf R}}")#text(", but the former is not a Lie group even though the latter is.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Let ")#mi("{H}")#text(" be a subgroup of a locally compact group ")#mi("{G}")#text(". Show that ")#mi("{H}")#text(" is closed in ")#mi("{G}")#text(" if and only if it is locally compact.")
]

#text("A variant of the above results is provided by using (faithful) representations instead of embeddings. Again, the linear version is trivial:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" If ")#mi("{V}")#text(" is a finite-dimensional vector space, and ")#mi("{W}")#text(" is another vector space with an injective linear transformation ")#mi("{\\rho: W \\rightarrow V}")#text(" from ")#mi("{W}")#text(" to ")#mi("{V}")#text(", then ")#mi("{W}")#text(" is also a finite-dimensional vector space.")
]

#text("Here is the non-linear version:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (von Neumann’s theorem)")]#text(" ")#metadata(none) <tao-094f686e92c888ae99f8>#text(" If ")#mi("{G}")#text(" is a Lie group, and ")#mi("{H}")#text(" is a locally compact group with an injective continuous homomorphism ")#mi("{\\rho: H \\rightarrow G}")#text(", then ")#mi("{H}")#text(" also has the structure of a Lie group.")
]

#text("Actually, it will suffice for the homomorphism ")#mi("{\\rho}")#text(" to be locally injective rather than injective; related to this, von Neumann’s theorem localises to the case when ")#mi("{H}")#text(" is a local group rather a group. The requirement that ")#mi("{H}")#text(" be locally compact is necessary, for much the same reason that the requirement that ")#mi("{H}")#text(" be closed was necessary in Cartan’s theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" Let ")#mi("{G = ({\\bf R}/{\\bf Z})^2}")#text(" be the two-dimensional torus, let ")#mi("{H = {\\bf R}}")#text(", and let ")#mi("{\\rho: H \\rightarrow G}")#text(" be the map ")#mi("{\\rho(x) := (x,\\alpha x)}")#text(", where ")#mi("{\\alpha \\in {\\bf R}}")#text(" is a fixed real number. Then ")#mi("{\\rho}")#text(" is a continuous homomorphism which is locally injective, and is even globally injective if ")#mi("{\\alpha}")#text(" is irrational, and so Theorem ")#link(<tao-094f686e92c888ae99f8>)[#text("4")]#text(" is consistent with the fact that ")#mi("{H}")#text(" is a Lie group. On the other hand, note that when ")#mi("{\\alpha}")#text(" is irrational, then ")#mi("{\\rho(H)}")#text(" is not closed; and so Theorem ")#link(<tao-094f686e92c888ae99f8>)[#text("4")]#text(" does not follow immediately from Theorem ")#link(<tao-9b3fea8ad52e1f62033b>)[#text("2")]#text(" in this case. (We will see, though, that Theorem ")#link(<tao-094f686e92c888ae99f8>)[#text("4")]#text(" follows from a local version of Theorem ")#link(<tao-9b3fea8ad52e1f62033b>)[#text("2")]#text(".)")
]

#text("As a corollary of Theorem ")#link(<tao-094f686e92c888ae99f8>)[#text("4")]#text(", we observe that any locally compact Hausdorff group ")#mi("{H}")#text(" with a faithful linear representation, i.e. a continuous injective homomorphism from ")#mi("{H}")#text(" into a linear group such as ")#mi("{GL_n({\\bf R})}")#text(" or ")#mi("{GL_n({\\bf C})}")#text(", is necessarily a Lie group. This suggests a representation-theoretic approach to Hilbert’s fifth problem. While this approach does not seem to readily solve the entire problem, it can be used to establish a number of important special cases with a well-understood representation theory, such as the compact case or the abelian case (for which the requisite representation theory is given by the ")#link("http://en.wikipedia.org/wiki/Peter%E2%80%93Weyl_theorem")[#text("Peter-Weyl theorem")]#text(" and ")#link("http://en.wikipedia.org/wiki/Pontryagin_duality")[#text("Pontryagin duality")]#text(" respectively). We will discuss these cases further in later notes.")

#text("In all of these cases, one is not really building up Euclidean or Lie structure completely from scratch, because there is already a Euclidean or Lie structure present in another object in the hypotheses. Now we turn to results that can create such structure assuming only what is ostensibly a weaker amount of structure. In the linear case, one example of this is is the following classical result in the theory of ")#link("http://en.wikipedia.org/wiki/Topological_vector_space")[#text("topological vector spaces")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5")]#text(" ")#metadata(none) <tao-58c03ad628eba440e219>#text(" Let ")#mi("{V}")#text(" be a locally compact Hausdorff topological vector space. Then ")#mi("{V}")#text(" is isomorphic (as a topological vector space) to ")#mi("{{\\bf R}^d}")#text(" for some finite ")#mi("{d}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The ")#link("http://en.wikipedia.org/wiki/Banach%E2%80%93Alaoglu_theorem")[#text("Banach-Alaoglu theorem")]#text(" asserts that in a normed vector space ")#mi("{V}")#text(", the closed unit ball in the dual space ")#mi("{V^*}")#text(" is always compact in the ")#link("http://en.wikipedia.org/wiki/Weak_topology")[#text("weak-* topology")]#text(". Of course, this dual space ")#mi("{V^*}")#text(" may be infinite-dimensional. This however does not contradict the above theorem, because the closed unit ball is ")#emph[#text("not")]#text(" a neighbourhood of the origin in the weak-* topology (it is only a neighbourhood with respect to the strong topology).")
]

#text("The full non-linear analogue of this theorem would be the Gleason-Yamabe theorem, which we are not yet ready to prove in this set of notes. However, by using methods similar to that used to prove Cartan’s theorem and von Neumann’s theorem, one can obtain a partial non-linear analogue which requires an additional hypothesis of a special type of metric, which we will call a ")#emph[#text("Gleason metric")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 6")]#text(" Let ")#mi("{G}")#text(" be a topological group. A ")#emph[#text("Gleason metric")]#text(" on ")#mi("{G}")#text(" is a left-invariant metric ")#mi("{d: G \\times G \\rightarrow {\\bf R}^+}")#text(" which generates the topology on ")#mi("{G}")#text(" and obeys the following properties for some constant ")#mi("{C>0}")#text(", writing ")#tao-math("{\\left\\|g\\right\\|}", block: false)#text(" for ")#mi("{d(g,\\text{id})}")#text(":")

#list(
[#text("(Escape property) If ")#mi("{g \\in G}")#text(" and ")#mi("{n \\geq 1}")#text(" is such that ")#tao-math("{n \\left\\|g\\right\\| \\leq \\frac{1}{C}}", block: false)#text(", then ")#tao-math("{\\left\\|g^n\\right\\| \\geq \\frac{1}{C} n \\left\\|g\\right\\|}", block: false)#text(".")],
[#text("(Commutator estimate) If ")#mi("{g, h \\in G}")#text(" are such that ")#tao-math("{\\left\\|g\\right\\|, \\left\\|h\\right\\| \\leq \\frac{1}{C}}", block: false)#text(", then")

#metadata(none) <tao-79ada907e679ba85642c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\|[g,h]\\right\\| \\leq C \\left\\|g\\right\\| \\left\\|h\\right\\|,", block: true)]]

#text("where ")#mi("{[g,h] := g^{-1}h^{-1}gh}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Commutator")[#text("commutator")]#text(" of ")#mi("{g}")#text(" and ")#mi("{h}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Let ")#mi("{G}")#text(" be a topological group that contains a neighbourhood of the identity isomorphic to a ")#mi("{C^{1,1}}")#text(" local group. Show that ")#mi("{G}")#text(" admits at least one Gleason metric.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Building Lie structure from Gleason metrics)")]#text(" ")#metadata(none) <tao-f5a85b0ee2bfa3637a1c>#text(" Let ")#mi("{G}")#text(" be a locally compact group that has a Gleason metric. Then ")#mi("{G}")#text(" is isomorphic to a Lie group.")
]

#text("We will rely on Theorem ")#link(<tao-f5a85b0ee2bfa3637a1c>)[#text("7")]#text(" to solve Hilbert’s fifth problem; this theorem reduces the task of establishing Lie structure on a locally compact group to that of building a metric with suitable properties. Thus, much of the remainder of the solution of Hilbert’s fifth problem will now be focused on the problem of how to construct good metrics on a locally compact group.")

#text("In all of the above results, a key idea is to use ")#emph[#text("one-parameter subgroups")]#text(" to convert from the nonlinear setting to the linear setting. Recall from ")#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/")[#text("the previous notes")]#text(" that in a Lie group ")#mi("{G}")#text(", the one-parameter subgroups are in one-to-one correspondence with the elements of the Lie algebra ")#mi("{{\\mathfrak g}}")#text(", which is a vector space. In a general topological group ")#mi("{G}")#text(", the concept of a one-parameter subgroup (i.e. a continuous homomorphism from ")#mi("{{\\bf R}}")#text(" to ")#mi("{G}")#text(") still makes sense; the main difficulties are then to show that the space of such subgroups continues to form a vector space, and that the associated exponential map ")#mi("{\\exp: \\phi \\mapsto \\phi(1)}")#text(" is still a local homeomorphism near the origin.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" The purpose of this exercise is to illustrate the perspective that a topological group can be viewed as a non-linear analogue of a vector space. Let ")#mi("{G, H}")#text(" be locally compact groups. For technical reasons we assume that ")#mi("{G, H}")#text(" are both ")#link("http://en.wikipedia.org/wiki/Sigma_compact")[#mi("{\\sigma}")#text("-compact")]#text(" and metrisable.")

#list(
[#text("(i) (Open mapping theorem) Show that if ")#mi("{\\phi: G \\rightarrow H}")#text(" is a continuous homomorphism which is surjective, then it is ")#link("http://en.wikipedia.org/wiki/Open_map")[#text("open")]#text(" (i.e. the image of open sets is open). (")#emph[#text("Hint:")]#text(" mimic the proof of the ")#link("http://en.wikipedia.org/wiki/Open_mapping_theorem_(functional_analysis)")[#text("open mapping theorem")]#text(" for Banach spaces, as discussed for instance in ")#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/")[#text("these notes")]#text(". In particular, take advantage of the ")#link("http://en.wikipedia.org/wiki/Baire_category_theorem")[#text("Baire category theorem")]#text(".)")],
[#text("(ii) (Closed graph theorem) Show that if a homomorphism ")#mi("{\\phi: G \\rightarrow H}")#text(" is closed (i.e. its graph ")#mi("{\\{ (g, \\phi(g)): g \\in G \\}}")#text(" is a closed subset of ")#mi("{G \\times H}")#text("), then it is continuous. (")#emph[#text("Hint:")]#text(" mimic the derivation of the ")#link("http://en.wikipedia.org/wiki/Closed_graph_theorem")[#text("closed graph theorem")]#text(" from the open mapping theorem in the Banach space case, as again discussed in ")#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/")[#text("these notes")]#text(".)")],
[#text("(iii) Let ")#mi("{\\phi: G \\rightarrow H}")#text(" be a homomorphism, and let ")#mi("{\\rho: H \\rightarrow K}")#text(" be a continuous injective homomorphism into another Hausdorff topological group ")#mi("{K}")#text(". Show that ")#mi("{\\phi}")#text(" is continuous if and only if ")#mi("{\\rho \\circ \\phi}")#text(" is continuous.")],
[#text("(iv) Relax the condition of metrisability to that of being Hausdorff. (")#emph[#text("Hint:")]#text(" Now one cannot use the Baire category theorem for metric spaces; but there is an analogue of this theorem for locally compact Hausdorff spaces.)")]
)
]

#metadata(none) <tao-ddff5773aed9090e5a91>

#heading(level: 1)[#strong[#text(" — 1. The theorems of Cartan and von Neumann — ")]]

#text("We now turn to the proof of Cartan’s theorem. As indicated in the introduction, the fundamental concept here will be that of a one-parameter subgroup:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 8 (One-parameter subgroups)")]#text(" Let ")#mi("{G}")#text(" be a topological group. A ")#emph[#text("one-parameter subgroup")]#text(" of ")#mi("{G}")#text(" is a continuous homomorphism ")#mi("{\\phi: {\\bf R} \\rightarrow G}")#text(". The space of all such one-parameter subgroups is denoted ")#mi("{L(G)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" Strictly speaking, the terminology “one-parameter subgroup” is a misnomer, because it is the image ")#mi("{\\phi(G)}")#text(" of ")#mi("{\\phi}")#text(" which is a subgroup of ")#mi("{G}")#text(", rather than ")#mi("{\\phi}")#text(" itself. Note that we consider reparameterisations ")#mi("{t \\mapsto \\phi(\\lambda t)}")#text(" of a one-parameter subgroup ")#mi("{t \\mapsto \\phi(t)}")#text(", where ")#mi("{\\lambda}")#text(" is a non-zero real number, to be distinct from ")#mi("{\\phi}")#text(" when ")#mi("{\\lambda \\neq 1}")#text(", even though both one-parameter subgroups have the same image.")
]

#text("We recall Exercise 12 from the ")#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/")[#text("previous set of notes")]#text(", which we reformulate here as a lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 9 (Classification of one-parameter subgroups)")]#text(" Let ")#mi("{G}")#text(" be a Lie group, with Lie algebra ")#mi("{{\\mathfrak g}}")#text(". Then if ")#mi("{X}")#text(" is an element of ")#mi("{{\\mathfrak g}}")#text(", then ")#mi("{t \\mapsto \\exp(tX)}")#text(" is a one-parameter subgroup; conversely, if ")#mi("{\\phi}")#text(" is a one-parameter subgroup, then there is a unique ")#mi("{X \\in {\\mathfrak g}}")#text(" such that ")#mi("{\\phi(t)=\\exp(tX)}")#text(" for all ")#mi("{t \\in {\\bf R}}")#text(". Thus we have a canonical one-to-one correspondence between ")#mi("{{\\mathfrak g}}")#text(" and ")#mi("{L(G)}")#text(".")
]

#text("Now let ")#mi("{H}")#text(" be a closed subgroup of a Lie group ")#mi("{G}")#text(". Every one-parameter subgroup of ")#mi("{H}")#text(" is clearly also a one-parameter subgroup of ")#mi("{G}")#text(", which by the above lemma can be viewed as an element of ")#mi("{{\\mathfrak g}}")#text(":")

#align(center)[#tao-fit-display[#mitex("L(H) \\subset L(G) \\equiv {\\mathfrak g}.")]]

#text("Thus we can think of ")#mi("{L(H)}")#text(" as a subset ")#mi("{{\\mathfrak h}}")#text(" of ")#mi("{{\\mathfrak g}}")#text(":")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak h} := \\{ X \\in {\\mathfrak g}: \\exp(tX) \\in H \\text{ for all } t \\in {\\bf R}\\}.")]]

#text("We claim that ")#mi("{{\\mathfrak h}}")#text(" is in fact a linear subspace of ")#mi("{{\\mathfrak g}}")#text(". Indeed, it contains the zero element of ")#mi("{{\\mathfrak g}}")#text(" (which corresponds to the trivial one-parameter subgroup ")#mi("{t \\mapsto 1}")#text("), and from reparameterisation we see that if ")#mi("{X \\in {\\mathfrak h}}")#text(", then ")#mi("{\\lambda X \\in {\\mathfrak h}}")#text(" for all ")#mi("{\\lambda \\in {\\bf R}}")#text(". Finally, if ")#mi("{X, Y \\in {\\mathfrak h}}")#text(", then by definition we have ")#mi("{\\exp(tX), \\exp(tY) \\in H}")#text(" for all ")#mi("{t \\in {\\bf R}}")#text(". But recall from Exercise 11(ii) of ")#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/")[#text("the previous notes")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\exp(t(X+Y)) = \\lim_{n \\rightarrow \\infty} (\\exp(tX/2^n) \\exp(tY/2^n))^{2^n}.")]]

#text("Since ")#mi("{H}")#text(" is a group, we see that ")#mi("{(\\exp(tX/2^n) \\exp(tY/2^n))^{2^n}}")#text(" lies in ")#mi("{H}")#text(". Since ")#mi("{H}")#text(" is closed, we conclude that ")#mi("{\\exp(t(X+Y)) \\in H}")#text(" for all ")#mi("{t \\in {\\bf R}}")#text(", which implies that ")#mi("{X+Y \\in {\\mathfrak h}}")#text(". Thus ")#mi("{{\\mathfrak h}}")#text(" is closed under both addition and scalar multiplication, and so it is a vector space. (It turns out that ")#mi("{{\\mathfrak h}}")#text(" is in fact a Lie algebra, but we will not need this fact yet.)")

#text("The next step is to show that ")#mi("{{\\mathfrak h}}")#text(" is “large” enough to serve as the “Lie algebra” of ")#mi("{H}")#text(". To illustrate this type of fact, let us first establish a simple special case.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 10")]#text(" ")#metadata(none) <tao-a6a517dc1b0d60227bc1>#text(" Suppose that the identity ")#mi("{1}")#text(" is not an isolated point of ")#mi("{H}")#text(" (i.e. ")#mi("{H}")#text(" is not discrete). Then ")#mi("{{\\mathfrak h}}")#text(" is non-trivial (i.e. it does not consist solely of ")#mi("{0}")#text(").")
]

#emph[#text("Proof:")]#text(" As ")#mi("{1}")#text(" is not isolated, there exists a sequence ")#mi("{h_n \\neq 1}")#text(" of elements of ")#mi("{H}")#text(" that converge to ")#mi("{1}")#text(". As ")#mi("{\\exp: {\\mathfrak g} \\rightarrow G}")#text(" is a local homeomorphism near the identity, we may thus find a sequence ")#mi("{X_n \\neq 0}")#text(" of elements of ")#mi("{{\\mathfrak g}}")#text(" converging to zero such that ")#mi("{\\exp(X_n) = h_n}")#text(" for all sufficiently large ")#mi("{n}")#text(".")

#text("Let us arbitrarily endow the finite-dimensional vector space ")#mi("{{\\mathfrak g}}")#text(" with a norm (it will not matter which norm we select). Then the sequence ")#tao-math("{X_n/\\left\\|X_n\\right\\|}", block: false)#text(" lies on the unit sphere with respect to this norm, and thus by the Heine-Borel theorem (and passing to a subsequence) we may assume that ")#tao-math("{X_n/\\left\\|X_n\\right\\|}", block: false)#text(" converges to some element ")#mi("{\\omega}")#text(" of norm ")#mi("{1}")#text(".")

#text("Let ")#mi("{t}")#text(" be any positive real number. Then ")#tao-math("{X_n \\lfloor t/\\left\\|X_n\\right\\|\\rfloor}", block: false)#text(" converges to ")#mi("{t\\omega}")#text(", and so ")#tao-math("{\\exp(X_n)^{\\lfloor t/\\left\\|X_n\\right\\|\\rfloor}}", block: false)#text(" converges to ")#mi("{\\exp(t\\omega)}")#text(". As ")#mi("{\\exp(X_n) = h_n}")#text(" lies in ")#mi("{H}")#text(", so does ")#tao-math("{\\exp(X_n)^{\\lfloor t/\\left\\|X_n\\right\\|\\rfloor}}", block: false)#text("; as ")#mi("{H}")#text(" is closed, we conclude that ")#mi("{\\exp(t\\omega) \\in H}")#text(" for all positive ")#mi("{t \\in {\\bf R}}")#text(", and hence for all ")#mi("{t \\in {\\bf R}}")#text(". We conclude that ")#mi("{\\omega \\in {\\mathfrak h}}")#text(", and the fclaim follows. ")#mi("\\Box")

#text("Now we establish a stronger version of the above lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11")]#text(" ")#metadata(none) <tao-e314a742ccb49d92d465>#text(" There exists a neighbourhood ")#mi("{U}")#text(" of the identity in ")#mi("{H}")#text(", and a neighbourhood ")#mi("{V}")#text(" of the origin in ")#mi("{{\\mathfrak h}}")#text(", such that ")#mi("{\\exp: V \\rightarrow U}")#text(" is a homeomorphism.")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{V}")#text(" be a neighbourhood of the origin in ")#mi("{{\\mathfrak h}}")#text(" such that ")#mi("{\\exp: V \\rightarrow \\exp(V)}")#text(" is a homeomorphism (this exists since ")#mi("{\\exp}")#text(" is a local homeomorphism in a neighbourhood of the origin in ")#mi("{{\\mathfrak g}}")#text(". Clearly ")#mi("{\\exp(V)}")#text(" lies in ")#mi("{H}")#text(" and contains ")#mi("{1}")#text(". If ")#mi("{\\exp(V)}")#text(" contains a neighbourhood of the ")#mi("{1}")#text(" in ")#mi("{H}")#text(" then we are done, so suppose that this is not the case. Then we can find a sequence ")#mi("{h_n \\not \\in \\exp(V)}")#text(" of elements in ")#mi("{H}")#text(" that converge to ")#mi("{1}")#text(". We may write ")#mi("{h_n = \\exp(X_n)}")#text(" for some ")#mi("{X_n \\not \\in V}")#text(" converging to zero in ")#mi("{{\\mathfrak g}}")#text(".")

#text("As ")#mi("{{\\mathfrak h}}")#text(" is a subspace of the finite-dimensional vector space ")#mi("{{\\mathfrak g}}")#text(", we may write ")#mi("{{\\mathfrak g} = {\\mathfrak h} + {\\mathfrak k}}")#text(" for some vector space ")#mi("{{\\mathfrak k}}")#text(" transverse to ")#mi("{{\\mathfrak h}}")#text(" (i.e. ")#mi("{{\\mathfrak h} \\cap {\\mathfrak k} = 0}")#text("). (We do not require ")#mi("{{\\mathfrak k}}")#text(" to be a Lie algebra.) From the inverse function theorem, the map ")#mi("{(Y,Z) \\mapsto \\exp(Y) \\exp(Z)}")#text(" from ")#mi("{{\\mathfrak h} \\times {\\mathfrak k}}")#text(" to ")#mi("{G}")#text(" is a local homeomorphism near the identity. Thus we may write ")#mi("{\\exp(X_n) = \\exp(Y_n) \\exp(Z_n)}")#text(" for sufficiently large ")#mi("{n}")#text(", where ")#mi("{Y_n \\in {\\mathfrak h}}")#text(" and ")#mi("{Z_n \\in {\\mathfrak k}}")#text(" both go to zero as ")#mi("{n \\rightarrow \\infty}")#text(". Since ")#mi("{X_n \\not \\in V}")#text(", we see that ")#mi("{Z_n}")#text(" is non-zero for ")#mi("{n}")#text(" sufficiently large.")

#text("We arbitrarily place a norm on ")#mi("{{\\mathfrak k}}")#text(". As before, we may pass to a subsequence and assume that ")#tao-math("{Z_n/\\left\\|Z_n\\right\\|}", block: false)#text(" converges to some limit ")#mi("{\\omega}")#text(" in the unit sphere of ")#mi("{{\\mathfrak k}}")#text("; in particular, ")#mi("{\\omega \\not \\in {\\mathfrak h}}")#text(".")

#text("Since ")#mi("{\\exp(X_n)}")#text(" and ")#mi("{\\exp(Y_n)}")#text(" both lie in ")#mi("{H}")#text(", ")#mi("{\\exp(Z_n)}")#text(" does also. By arguing as in the proof of Lemma ")#link(<tao-a6a517dc1b0d60227bc1>)[#text("10")]#text(" we conclude that ")#mi("{\\exp(t\\omega)}")#text(" lies in ")#mi("{H}")#text(" for all ")#mi("{t \\in {\\bf R}}")#text(", and so ")#mi("{\\omega \\in {\\mathfrak h}}")#text(", yielding the desired contradiction. ")#mi("\\Box")

#text("From the above lemma we see that ")#mi("{H}")#text(" locally agrees with ")#mi("{\\exp(V)}")#text(" near the identity, and thus locally agrees with ")#mi("{\\exp(V) h}")#text(" near ")#mi("{h}")#text(" for every ")#mi("{h \\in H}")#text(". This implies that ")#mi("{H}")#text(" is a smooth submanifold of ")#mi("{G}")#text("; since it is also a topological group, it is thus a Lie group. This establishes Cartan’s theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" Observe ")#emph[#text("a posteriori")]#text(" that ")#mi("{{\\mathfrak h}}")#text(" is the Lie algebra of ")#mi("{H}")#text(", and in particular is closed with respect to Lie brackets. This fact can also be established directly using ")#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/")[#text("Exercise 22")]#text(" from the previous notes.")
]

#text("There is a local version of Cartan’s theorem, in which groups are replaced by local groups:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 12 (Local Cartan’s theorem)")]#text(" ")#metadata(none) <tao-de4b6eef0a4182d6450f>#text(" If ")#mi("{H}")#text(" is a locally compact local subgroup of a local Lie group ")#mi("{G}")#text(", then there is an open neighbourhood ")#mi("{H^{\\prime}}")#text(" of the identity in ")#mi("{H}")#text(" that is a smooth submanifold of ")#mi("{G}")#text(", and is thus also a local Lie group.")
]

#text("The proof of this theorem follows the lines of the global Cartan’s theorem, with some minor technical changes, and we set this proof out in the following exercise.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Define a ")#emph[#text("local one-parameter subgroup")]#text(" of a local group ")#mi("{H}")#text(" to be a continuous homomorphism ")#mi("{\\phi: (-\\epsilon,\\epsilon) \\rightarrow H}")#text(" from the (additive) local group ")#mi("{(-\\epsilon,\\epsilon)}")#text(" to ")#mi("{H}")#text(". Call two local one-parameter subgroups ")#emph[#text("equivalent")]#text(" if they agree on a neighbourhood of the origin, and let ")#mi("{L(H)}")#text(" be the set of all equivalence classes of local one-parameter subgroups. Establish the following claims:")

#list(
[#text("(i) If ")#mi("{H}")#text(" is a global group, then there is a canonical one-to-one correspondence that identifies this definition of ")#mi("{L(H)}")#text(" with the definition of ")#mi("{L(H)}")#text(" given previously.")],
[#text("(ii) In the situation of Theorem ")#link(<tao-de4b6eef0a4182d6450f>)[#text("12")]#text(", show that ")#mi("{L(H)}")#text(" can be identified with a linear subspace ")#mi("{{\\mathfrak h}}")#text(" of ")#mi("{{\\mathfrak g}}")#text(", namely")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak h} := \\{ X \\in {\\mathfrak g}: \\exp(tX) \\in H \\text{ for all sufficiently small } t \\}.")]]],
[#text("(iii) Let the notation and assumptions be as in (ii). For any neighbourhood ")#mi("{H^{\\prime}}")#text(" of the identity in ")#mi("{H}")#text(", there is a neighbourhood ")#mi("{V}")#text(" of the origin in ")#mi("{{\\mathfrak h}}")#text(" such that ")#mi("{\\exp(V) \\subset H^{\\prime}}")#text(".")],
[#text("(iv) Let the notation and assumptions be as in (ii). There exists a neighbourhood ")#mi("{U}")#text(" of the identity in ")#mi("{H}")#text(", and a neighbourhood ")#mi("{V}")#text(" of the origin in ")#mi("{{\\mathfrak h}}")#text(", such that ")#mi("{\\exp: V \\rightarrow U}")#text(" is a homeomorphism.")],
[#text("(v) Prove Theorem ")#link(<tao-de4b6eef0a4182d6450f>)[#text("12")]#text(".")]
)
]

#text("One can then use Theorem ")#link(<tao-de4b6eef0a4182d6450f>)[#text("12")]#text(" to establish von Neumann’s theorem, as follows. Suppose that ")#mi("{H}")#text(" is a locally compact group with an injective continuous homomorphism ")#mi("{\\rho: H \\rightarrow G}")#text(" into a Lie group ")#mi("{G}")#text(". As ")#mi("{H}")#text(" is locally compact, there is an open neighbourhood ")#mi("{U}")#text(" of the origin in ")#mi("{H}")#text(" whose closure ")#mi("{\\overline{U}}")#text(" is compact. The map ")#mi("{\\rho}")#text(" from ")#mi("{\\overline{U}}")#text(" to ")#mi("{\\rho(\\overline{U})}")#text(" is a continuous bijection from a compact set to a Hausdorff set, and is therefore a homeomorphism (since it maps closed (and hence compact) subsets of ")#mi("{\\overline{U}}")#text(" to compact (and hence closed) subsets of ")#mi("{\\rho(\\overline{U})}")#text("). The set ")#mi("{\\rho(U)}")#text(" is then a locally compact local subgroup of ")#mi("{G}")#text(" and thus has a neighbourhood of the identity which is a local Lie group, by Theorem ")#link(<tao-de4b6eef0a4182d6450f>)[#text("12")]#text(". Pulling this back by ")#mi("{\\rho}")#text(", we see that some neighbourhood of the identity in ")#mi("{H}")#text(" is a local Lie group, and thus ")#mi("{H}")#text(" is a global Lie group by Exercise 15 of ")#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/")[#text("the previous notes")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" State and prove a local version of von Neumann’s theorem, in which ")#mi("{G}")#text(" and ")#mi("{H}")#text(" are local groups rather than global groups, and the global injectivity condition is similarly replaced by local injectivity.")
]

#heading(level: 1)[#strong[#text(" — 2. Locally compact vector spaces — ")]]

#text("We will now turn to the study of ")#link("http://en.wikipedia.org/wiki/Topological_vector_space")[#text("topological vector spaces")]#text(", which we will need to establish Theorem ")#link(<tao-f5a85b0ee2bfa3637a1c>)[#text("7")]#text(". We begin by recalling the definition of a topological vector space.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 13 (Topological vector space)")]#text(" A ")#emph[#text("topological vector space")]#text(" is a (real) vector space ")#mi("{V}")#text(" equipped with a topology that makes the vector space operations ")#mi("{+: V \\times V \\rightarrow V}")#text(" and ")#mi("{\\cdot: {\\bf R} \\times V \\rightarrow {\\bf R}}")#text(" (jointly) continuous. (In particular, ")#mi("{(V,+)}")#text(" is necessarily a topological group.)")
]

#text("One can also consider complex topological vector spaces, but the theory for such spaces is almost identical to the real case, and we will only need the real case for what follows. In the literature, it is often common to restrict attention to Hausdorff topological vector spaces, although this is not a severe restriction in practice, as the following exercise shows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Let ")#mi("{V}")#text(" be a topological vector space. Show that the closure ")#mi("{W := \\overline{\\{0\\}}}")#text(" of the origin is a closed subspace of ")#mi("{V}")#text(", and the quotient space ")#mi("{V/W}")#text(" is a Hausdorff topological vector space. Furthermore, show that a set is open in ")#mi("{V}")#text(" if and only if it is the preimage of an open set in ")#mi("{V/W}")#text(" under the quotient map ")#mi("{\\pi: V \\rightarrow V/W}")#text(".")
]

#text("An important class of topological vector spaces are the ")#link("http://en.wikipedia.org/wiki/Normed_linear_space")[#text("normed vector spaces")]#text(", in which the topology is generated by a norm ")#mi("{\\| \\|}")#text(" on the vector space. However, not every topological vector space is generated by a norm. See ")#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/")[#text("these notes")]#text(" for some further discussion.")

#text("We emphasise that in order to be a topological vector space, the vector space operations ")#mi("{+, \\cdot}")#text(" need to be ")#emph[#text("jointly continuous")]#text("; merely being continuous in the individual variables is not sufficient to qualify for being a topological vector space. We illustrate this with some non-examples of topological vector spaces:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" Consider the one-dimensional vector space ")#mi("{{\\bf R}}")#text(" with the ")#emph[#text("co-compact")]#text(" topology (a non-empty set is open iff its complement is compact in the usual topology). In this topology, the space is a ")#link("http://en.wikipedia.org/wiki/T1_space")[#mi("{T_1}")#text(" space")]#text(" (though not Hausdorff), the scalar multiplication map ")#mi("{\\cdot: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf R}}")#text(" is jointly continuous, and the addition map ")#mi("{+: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf R}}")#text(" is continuous in each coordinate (i.e. translations are continuous), but not jointly continuous; for instance, the set ")#mi("{\\{ (x,y) \\in {\\bf R}: x+y \\not \\in [0,1]\\}}")#text(" does not contain a non-trivial Cartesian product of two sets that are open in the co-compact topology. So this is not a topological vector space. Similarly for the cocountable or cofinite topologies on ")#mi("{{\\bf R}}")#text(" (the latter topology, incidentally, is the same as the ")#link("http://en.wikipedia.org/wiki/Zariski_topology")[#text("Zariski topology")]#text(" on ")#mi("{{\\bf R}}")#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" Consider the topology of ")#mi("{{\\bf R}}")#text(" inherited by pulling back the usual topology on the unit circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(". This pullback topology is not quite Hausdorff, but the addition map ")#mi("{+: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf R}}")#text(" is jointly continuous (so that this gives ")#mi("{{\\bf R}}")#text(" the structure of a topological group). On the other hand, the scalar multiplication map ")#mi("{\\cdot: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf R}}")#text(" is not continuous at all. A slight variant of this topology comes from pulling back the usual topology on the torus ")#mi("{({\\bf R}/{\\bf Z})^2}")#text(" under the map ")#mi("{x \\mapsto (x,\\alpha x)}")#text(" for some irrational ")#mi("{\\alpha}")#text("; this restores the Hausdorff property, and addition is still jointly continuous, but multiplication remains discontinuous.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4")]#text(" Consider ")#mi("{{\\bf R}}")#text(" with the discrete topology; here, the topology is Hausdorff, addition is jointly continuous, and every dilation is continuous, but multiplication is not jointly continuous. If one instead gives ")#mi("{{\\bf R}}")#text(" the ")#link("http://en.wikipedia.org/wiki/Lower_limit_topology")[#text("half-open topology")]#text(", then again the topology is Hausdorff and addition is jointly continuous, but scalar multiplication is only jointly continuous once one restricts the scalar to be non-negative.")
]

#text("These examples illustrate that a vector space such as ")#mi("{{\\bf R}}")#text(" can have many topologies on it (and many topological group structures), but only one topological vector space structure. More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 14")]#text(" ")#metadata(none) <tao-25bf8e1a2393f1108d37>#text(" Every finite-dimensional Hausdorff topological vector space has the usual topology.")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{V}")#text(" be a finite-dimensional Hausdorff topological space, with topology ")#mi("{{\\mathcal F}}")#text(". We need to show that every set which is open in the usual topology, is open in ")#mi("{{\\mathcal F}}")#text(", and conversely.")

#text("Let ")#mi("{v_1,\\ldots,v_n}")#text(" be a basis for the finite-dimensional space ")#mi("{V}")#text(". From the continuity of the vector space operations, we easily verify that the linear map ")#mi("{T: {\\bf R}^n \\rightarrow V}")#text(" given by")

#align(center)[#tao-fit-display[#mitex("T( x_1,\\ldots,x_n) := x_1 v_1 + \\ldots + x_n v_n")]]

#text("is continuous. From this, we see that any set which is open in ")#mi("{{\\mathcal F}}")#text(", is also open in the usual topology.")

#text("Now we show conversely that every set which is open in the usual topology, is open in ")#mi("{{\\mathcal F}}")#text(". It suffices to show that there is a bounded open neighbourhood of the origin in ")#mi("{{\\mathcal F}}")#text(", since one can then translate and dilate this open neighbourhood to obtain a (sub-)base for the usual topology. (Here, “bounded” refers to the usual sense of the term, for instance with respect to an arbitrarily selected norm on ")#mi("{V}")#text(" (note that on a finite-dimensional space, all norms are equivalent).)")

#text("We use ")#mi("{T}")#text(" to identify ")#mi("{V}")#text(" (as a vector space) with ")#mi("{{\\bf R}^n}")#text(". As ")#mi("{T}")#text(" is continuous, every set which is compact in the usual topology, is compact in ")#mi("{{\\mathcal F}}")#text(". In particular, the unit sphere ")#tao-math("{S^{n-1} := \\{x \\in {\\bf R}^n: \\left\\|x\\right\\|=1\\}}", block: false)#text(" (in, say, the Euclidean norm ")#mi("{\\| \\|}")#text(" on ")#mi("{{\\bf R}^n}")#text(") is compact in ")#mi("{{\\mathcal F}}")#text(". Using this and the Hausdorff assumption on ")#mi("{{\\mathcal F}}")#text(", we can find an open neighbourhood ")#mi("{U}")#text(" of the origin in ")#mi("{F}")#text(" which is disjoint from ")#mi("{S^{n-1}}")#text(".")

#text("At present, ")#mi("{U}")#text(" need not be bounded (note that we are not assuming ")#mi("{V}")#text(" to be ")#link("http://en.wikipedia.org/wiki/Locally_connected_space")[#text("locally connected")]#text(" ")#emph[#text("a priori")]#text("). However, we can fix this as follows. Using the joint continuity of the scalar multiplication map, one can find another open neighbourhood ")#mi("{U^{\\prime}}")#text(" of the origin and an open interval ")#mi("{(-\\epsilon,\\epsilon)}")#text(" around ")#mi("{0}")#text(" such that the product set ")#mi("{(-\\epsilon,\\epsilon) \\cdot U^{\\prime} := \\{ t x: t \\in (-\\epsilon,\\epsilon); x \\in U^{\\prime} \\}}")#text(" is contained in ")#mi("{U}")#text(". In particular, since ")#mi("{U}")#text(" avoids the unit sphere ")#mi("{S^{n-1}}")#text(", ")#mi("{U^{\\prime\\prime}}")#text(" must avoid the region ")#tao-math("{\\{ x \\in {\\bf R}^n: \\left\\|x\\right\\| > 1/\\epsilon \\}}", block: false)#text(" and is thus bounded, as required. ")#mi("\\Box")

#text("We isolate one important consequence of the above theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 15")]#text(" ")#metadata(none) <tao-5835a2460f0994134d10>#text(" In a Hausdorff topological space ")#mi("{V}")#text(", every finite-dimensional subspace ")#mi("{W}")#text(" is closed.")
]

#emph[#text("Proof:")]#text(" It suffices to show that every vector ")#mi("{x \\in V \\backslash W}")#text(" is in the exterior of ")#mi("{W}")#text(". But this follows from Theorem ")#link(<tao-25bf8e1a2393f1108d37>)[#text("14")]#text(" after restricting to the finite-dimensional space spanned by ")#mi("{W}")#text(" and ")#mi("{x}")#text(". ")#mi("\\Box")

#text("We can now prove Theorem ")#link(<tao-58c03ad628eba440e219>)[#text("5")]#text(". Let ")#mi("{V}")#text(" be a locally compact Hausdorff space, thus there exists a compact neighbourhood ")#mi("{K}")#text(" of the origin. Then the dilate ")#mi("{\\frac{1}{2} K}")#text(" is also a neighbourhood of the origin, and so by compactness ")#mi("{K}")#text(" can be covered by finitely many translates of ")#mi("{\\frac{1}{2} K}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("K \\subset S + \\frac{1}{2} K")]]

#text("for some finite set ")#mi("{S}")#text(". If we let ")#mi("{W}")#text(" be the finite-dimensional vector space generated by ")#mi("{S}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("K \\subset W + \\frac{1}{2} K.")]]

#text("Iterating this we have")

#align(center)[#tao-fit-display[#mitex("K \\subset W + 2^{-n} K")]]

#text("for any ")#mi("{n \\geq 1}")#text(". On the other hand, if ")#mi("{U}")#text(" is a neighbourhood of the origin, then for every ")#mi("{x \\in V}")#text(" we see that ")#mi("{2^{-n} x \\in U}")#text(" for sufficiently large ")#mi("{n}")#text(". By compactness of ")#mi("{K}")#text(" (and continuity of the scalar multiplication map at zero), we conclude that ")#mi("{2^{-n} K \\subset U}")#text(" for some sufficiently large ")#mi("{n}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("K \\subset W + U")]]

#text("for any neighbourhood ")#mi("{U}")#text(" of the origin; thus ")#mi("{K}")#text(" is in the closure of ")#mi("{W}")#text(". By Corollary ")#link(<tao-5835a2460f0994134d10>)[#text("15")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("K \\subset W.")]]

#text("But ")#mi("{K}")#text(" is a neighbourhood of the origin, thus for every ")#mi("{x \\in V}")#text(" we have ")#mi("{2^{-n} x \\in K}")#text(" for all sufficiently large ")#mi("{n}")#text(", and thus ")#mi("{x \\in 2^n W = W}")#text(". Thus ")#mi("{V=W}")#text(", and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Establish the ")#link("http://en.wikipedia.org/wiki/Riesz_lemma")[#text("Riesz lemma")]#text(": if ")#mi("{V = (V,\\| \\|)}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Normed_linear_space")[#text("normed vector space")]#text(", ")#mi("{W}")#text(" is a proper closed subspace of ")#mi("{V}")#text(", and ")#mi("{\\epsilon > 0}")#text(", then there exists a vector ")#mi("{x}")#text(" in ")#mi("{V}")#text(" with ")#tao-math("{\\left\\|x\\right\\|=1}", block: false)#text(" and ")#mi("{\\text{dist}(x,V) \\geq 1-\\epsilon}")#text(". (")#emph[#text("Hint:")]#text(" pick an element ")#mi("{y}")#text(" of ")#mi("{V}")#text(" not in ")#mi("{W}")#text(", and then pick ")#mi("{z \\in W}")#text(" that nearly minimises ")#tao-math("{\\left\\|y-z\\right\\|}", block: false)#text(". Use these two vectors to construct a suitable ")#mi("{x}")#text(".) Using this lemma and the Heine-Borel theorem, give an alternate proof of Theorem ")#link(<tao-58c03ad628eba440e219>)[#text("5")]#text(" in the case when ")#mi("{V}")#text(" is a normed vector space.")
]

#heading(level: 1)[#strong[#text(" — 3. From Gleason metrics to Lie groups — ")]]

#text("Now we prove Theorem ")#link(<tao-f5a85b0ee2bfa3637a1c>)[#text("7")]#text(". The argument will broadly follow the lines of Cartan’s theorem, but we will have to work harder in many stages of the argument in order to compensate for the lack of an obvious ambient Lie structure in the initial hypotheses. In particular, the Gleason metric hypothesis will substitute for the ")#mi("{C^{1,1}}")#text(" type structure enjoyed by Lie groups, which as we saw in the ")#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/")[#text("previous set of notes")]#text(" was needed to obtain good control on the exponential map.")

#text("Henceforth, ")#mi("{G}")#text(" is a locally compact group with a Gleason metric ")#mi("{d}")#text(" (and an associated “norm” ")#tao-math("{\\left\\|g\\right\\| = d(g, \\text{id})}", block: false)#text("). In particular, by the Heine-Borel theorem, ")#mi("{G}")#text(" is complete with this metric.")

#text("We use the asymptotic notation ")#mi("{X \\ll Y}")#text(" in place of ")#mi("{X \\leq CY}")#text(" for some constant ")#mi("{C}")#text(" that can vary from line to line (in particular, ")#mi("{C}")#text(" need not be the constant appearing in the definition of a Gleason metric), and write ")#mi("{X \\sim Y}")#text(" for ")#mi("{X \\ll Y \\ll X}")#text(". We also let ")#mi("{\\epsilon > 0}")#text(" be a sufficiently small constant (depending only on the constant in the definition of a Gleason metric) to be chosen later.")

#text("Note that the left-invariant metric properties of ")#mi("{d}")#text(" give the symmetry property")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g^{-1} \\right\\| = \\left\\|g\\right\\|", block: true)]]

#text("and the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g_1 \\ldots g_n \\right\\| \\leq \\sum_{i=1}^n \\|g_i\\|.", block: true)]]

#text("From the commutator estimate ")#link(<tao-79ada907e679ba85642c>)[#text("(1)")]#text(" and the triangle inequality we also obtain a conjugation estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| ghg^{-1} \\right\\| \\sim \\left\\|h\\right\\|", block: true)]]

#text("whenever ")#tao-math("{\\left\\|g\\right\\|, \\left\\|h\\right\\| \\leq \\epsilon}", block: false)#text(". Since left-invariance gives")

#align(center)[#tao-fit-display[#tao-math("d(g,h) = \\left\\| g^{-1} h \\right\\|", block: true)]]

#text("we then conclude an approximate right invariance")

#align(center)[#tao-fit-display[#mitex("d(gk,hk) \\sim d(g,h)")]]

#text("whenever ")#tao-math("{\\left\\|g\\right\\|, \\left\\|h\\right\\|, \\left\\|k\\right\\| \\leq \\epsilon}", block: false)#text(". In a similar spirit, the commutator estimate ")#link(<tao-79ada907e679ba85642c>)[#text("(1)")]#text(" also gives ")#metadata(none) <tao-861ef4e9fdbbff6a151f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("d(gh,hg) \\ll \\left\\|g\\right\\| \\left\\|h\\right\\|", block: true)]]

#text("whenever ")#tao-math("{\\left\\|g\\right\\|, \\left\\|h\\right\\| \\leq \\epsilon}", block: false)#text(".")

#text("This has the following useful consequence, which asserts that the power maps ")#mi("{g \\mapsto g^n}")#text(" behave like dilations:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 16")]#text(" ")#metadata(none) <tao-2f8c0b475a71847a5766>#text(" If ")#mi("{n \\geq 1}")#text(" and ")#tao-math("{\\left\\|g\\right\\|, \\left\\|h\\right\\| \\leq \\epsilon/n}", block: false)#text(", then")

#align(center)[#tao-fit-display[#tao-math("d(g^n h^n, (gh)^n) \\lesssim n^2 \\left\\|g\\right\\| \\left\\|h\\right\\|", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#mitex("d(g^n,h^n) \\sim n d(g,h).")]]
]

#emph[#text("Proof:")]#text(" We begin with the first inequality. By the triangle inequality, it suffices to show that ")#metadata(none) <tao-b14311345409a01c4bee>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("d( (gh)^i g^{n-i} h^{n-i}, (gh)^{i+1} g^{n-i-1} h^{n-i-1} ) \\ll n \\left\\|g\\right\\| \\left\\|h\\right\\|", block: true)]]

#text("uniformly for all ")#mi("{0 \\leq i < n}")#text(". By left-invariance and approximate right-invariance, the left-hand side is comparable to")

#align(center)[#tao-fit-display[#mitex("d( g^{n-i-1} h, h g^{n-i-1} ),")]]

#text("which by ")#link(<tao-861ef4e9fdbbff6a151f>)[#text("(2)")]#text(" is bounded above by")

#align(center)[#tao-fit-display[#tao-math("\\ll \\left\\|g^{n-i-1}\\right\\| \\left\\|h\\right\\| \\ll n \\left\\|g\\right\\| \\left\\|h\\right\\|", block: true)]]

#text("as required.")

#text("Now we prove the second estimate. Write ")#mi("{g = hk}")#text(", then ")#tao-math("{\\left\\|k \\right\\| = d(g,h) \\leq 2\\epsilon/n}", block: false)#text(". We have")

#align(center)[#tao-fit-display[#tao-math("d(h^n k^n,h^n) = \\left\\|k^n\\right\\| \\sim n \\left\\|k\\right\\|", block: true)]]

#text("thanks to the escape property (shrinking ")#mi("{\\epsilon}")#text(" if necessary). On the other hand, from the first inequality, we have")

#align(center)[#tao-fit-display[#tao-math("d(g^n, h^n k^n) \\ll n^2 \\left\\|h\\right\\| \\left\\|k\\right\\|.", block: true)]]

#text("If ")#mi("{\\epsilon}")#text(" is small enough, the claim now follows from the triangle inequality. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" Lemma ")#link(<tao-2f8c0b475a71847a5766>)[#text("16")]#text(" implies (by a standard covering argument) that the group ")#mi("{G}")#text(" is locally of bounded doubling, though we will not use this fact here. The bounds above should be compared with the bounds in Exercise 9 of the ")#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/")[#text("previous notes")]#text(". Indeed, just as the bounds in that exercise were used in the previous notes to build the exponential map for Lie groups, the bounds in Lemma ")#link(<tao-2f8c0b475a71847a5766>)[#text("16")]#text(" are crucial for controlling the exponential function on the locally compact group ")#mi("{G}")#text(" equipped with the Gleason metric ")#mi("{d}")#text(".")
]

#text("Now we bring in the space ")#mi("{L(G)}")#text(" of one-parameter subgroups. We give this space the ")#link("http://en.wikipedia.org/wiki/Compact-open_topology")[#text("compact-open topology")]#text(", thus the topology is generated by balls of the form")

#align(center)[#tao-fit-display[#mitex("\\{ \\phi \\in L(G): \\sup_{t \\in I} d(\\phi(t),\\phi_0(t)) < r \\}")]]

#text("for ")#mi("{\\phi_0 \\in L(G)}")#text(", ")#mi("{r > 0}")#text(", and compact ")#mi("{I}")#text(". Actually, using the homomorphism property, one can use a single compact interval ")#mi("{I}")#text(", such as ")#mi("{[-1,1]}")#text(", to generate the topology if desired, thus making ")#mi("{L(G)}")#text(" a metric space.")

#text("Given that ")#mi("{G}")#text(" is eventually going to be shown to be a Lie group, ")#mi("{L(G)}")#text(" must be isomorphic to a Euclidean space. We now move towards this goal by establishing various properties of ")#mi("{L(G)}")#text(" that Euclidean spaces enjoy.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 17")]#text(" ")#mi("{L(G)}")#text(" is locally compact.")
]

#emph[#text("Proof:")]#text(" It is easy to see that ")#mi("{L(G)}")#text(" is complete. Let ")#mi("{\\phi_0 \\in L(G)}")#text(". As ")#mi("{\\phi_0}")#text(" is continuous, we can find an interval ")#mi("{I = [-T,T]}")#text(" small enough that ")#tao-math("{\\left\\| \\phi_0(t) \\right\\| \\leq \\epsilon}", block: false)#text(" for all ")#mi("{t \\in [-T,T]}")#text(". By the Heine-Borel theorem, it will suffice to show that the set")

#align(center)[#tao-fit-display[#mitex("B := \\{ \\phi \\in L(G): \\sup_{t \\in [-T,T]} d(\\phi(t),\\phi_0(t)) < \\epsilon \\}")]]

#text("is totally bounded. By the ")#link("http://en.wikipedia.org/wiki/Arzel%C3%A0%E2%80%93Ascoli_theorem")[#text("Arzelá-Ascoli theorem")]#text(", it suffices to show that the family of functions in ")#mi("{B}")#text(" is ")#link("http://en.wikipedia.org/wiki/Equicontinuous")[#text("equicontinuous")]#text(".")

#text("By construction, we have ")#tao-math("{\\left\\| \\phi(t) \\right\\| \\leq 2\\epsilon}", block: false)#text(" whenever ")#tao-math("{\\left|t\\right| \\leq T}", block: false)#text(". By the escape property, this implies (for ")#mi("{\\epsilon}")#text(" small enough, of course) that ")#tao-math("{\\left\\| \\phi(t/n) \\right\\| \\ll \\epsilon/n}", block: false)#text(" for all ")#tao-math("{\\left|t\\right| \\leq T}", block: false)#text(" and ")#mi("{n \\geq 1}")#text(", thus ")#tao-math("{\\left\\| \\phi(t) \\right\\| \\ll \\epsilon \\left|t\\right| / T}", block: false)#text(" whenever ")#tao-math("{\\left|t\\right| \\leq T}", block: false)#text(". From the homomorphism property, we conclude that ")#tao-math("{d(\\phi(t),\\phi(t^{\\prime})) \\ll \\epsilon \\left|t-t^{\\prime}\\right| / T}", block: false)#text(" whenever ")#tao-math("{\\left|t\\right|, \\left|t^{\\prime}\\right| \\leq T}", block: false)#text(", which gives uniform Lipschitz control and hence equicontinuity as desired. ")#mi("\\Box")

#text("We observe for future reference that the proof of the above lemma also shows that all one-parameter subgroups are locally Lipschitz.")

#text("Now we put a vector space structure on ")#mi("{L(G)}")#text(", which we define by analogy with the Lie group case, in which each tangent vector ")#mi("{X}")#text(" generates a one-parameter subgroup ")#mi("{t \\mapsto \\exp(tX)}")#text(". From this analogy, the scalar multiplication operation has an obvious definition: if ")#mi("{\\phi \\in L(G)}")#text(" and ")#mi("{c \\in {\\bf R}}")#text(", we define ")#mi("{c\\phi \\in L(G)}")#text(" to be the one-parameter subgroup ")#metadata(none) <tao-094f48d4280524d428cc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("c \\phi(t) := \\phi(ct)")]]

#text("which is easily seen to actually be a one-parameter subgroup.")

#text("Now we turn to the addition operation. In the Lie group case, one can express the one-parameter subgroup ")#mi("{t \\mapsto \\exp(t(X+Y))}")#text(" in terms of the one-parameter subgroups ")#mi("{t \\mapsto \\exp(tX)}")#text(", ")#mi("{t \\mapsto \\exp(tY)}")#text(" by the limiting formula")

#align(center)[#tao-fit-display[#mitex("\\exp(t(X+Y)) = \\lim_{n \\rightarrow \\infty} (\\exp(tX/n) \\exp(tY/n))^n;")]]

#text("cf. Exercise 15 from the ")#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/")[#text("previous notes")]#text(". In view of this, we would like to define the sum ")#mi("{\\phi+\\psi}")#text(" of two one-parameter subgroups ")#mi("{\\phi, \\psi \\in L(G)}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("(\\phi+\\psi)(t) := \\lim_{n \\rightarrow \\infty} (\\phi(t/n) \\psi(t/n))^n.")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 18")]#text(" ")#metadata(none) <tao-fd7275bbea343cb9700f>#text(" If ")#mi("{\\phi, \\psi \\in L(G)}")#text(", then ")#mi("{\\phi+\\psi}")#text(" is well-defined and also lies in ")#mi("{L(G)}")#text(".")
]

#emph[#text("Proof:")]#text(" To show well-definedness, it suffices to show that for each ")#mi("{t}")#text(", the sequence ")#mi("{(\\phi(t/n) \\psi(t/n))^n}")#text(" is a Cauchy sequence. It suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sup_{m \\geq 1} d( (\\phi(t/n) \\psi(t/n))^n, (\\phi(t/nm) \\psi(t/nm))^{nm}) \\rightarrow 0")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(". We will in fact prove the slightly stronger claim")

#align(center)[#tao-fit-display[#mitex("\\sup_{m \\geq 1} \\sup_{1 \\leq n^{\\prime} \\leq n} d( (\\phi(t/n) \\psi(t/n))^{n^{\\prime}}, (\\phi(t/nm) \\psi(t/nm))^{n^{\\prime}m}) \\rightarrow 0.")]]

#text("Observe from continuity of multiplication that to prove this claim for a given ")#mi("{t}")#text(", it suffices to do so for ")#mi("{t/2}")#text("; thus we may assume without loss of generality that ")#mi("{t}")#text(" is small.")

#text("Let ")#mi("{\\epsilon > 0}")#text(" be a small number to be chosen later. Since ")#mi("{\\phi,\\psi}")#text(" are locally Lipschitz, we see (if ")#mi("{t}")#text(" is sufficiently small depending on ")#mi("{\\epsilon}")#text(") that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\phi(t/n) \\right\\|, \\left\\| \\psi(t/n) \\right\\| \\ll \\epsilon / n", block: true)]]

#text("for all ")#mi("{n}")#text(". From Lemma ")#link(<tao-2f8c0b475a71847a5766>)[#text("16")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("d( \\phi(t/n) \\psi(t/n), (\\phi(t/nm) \\psi(t/nm)^m) ) \\ll m^2 (\\epsilon/nm) (\\epsilon/nm) = \\epsilon^2 / n^2")]]

#text("if ")#mi("{m \\geq 1}")#text(" and ")#mi("{n}")#text(" is sufficiently large. Another application of Lemma ")#link(<tao-2f8c0b475a71847a5766>)[#text("16")]#text(" then gives")

#align(center)[#tao-fit-display[#mitex("d( (\\phi(t/n) \\psi(t/n))^{n^{\\prime}}, (\\phi(t/nm) \\psi(t/nm)^{n^{\\prime}m}) ) \\ll n^{\\prime} \\epsilon^2 / n^2 \\ll \\epsilon^2 / n")]]

#text("if ")#mi("{m \\geq 1}")#text(", ")#mi("{n}")#text(" is sufficiently large, and ")#mi("{1 \\leq n^{\\prime} \\leq \\epsilon n}")#text(". The claim follows.")

#text("The above argument in fact shows that ")#mi("{(\\phi(t/n) \\psi(t/n))^n}")#text(" is uniformly Cauchy for ")#mi("{t}")#text(" in a compact interval, and so the pointwise limit ")#mi("{\\phi+\\psi}")#text(" is in fact a uniform limit of continuous functions and is thus continuous. To prove that ")#mi("{\\phi+\\psi}")#text(" is a homomorphism, it suffices by density of the rationals to show that")

#align(center)[#tao-fit-display[#mitex("(\\phi+\\psi)( at ) (\\phi+\\psi)( bt ) = (\\phi+\\psi)( (a+b)t )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(\\phi+\\psi)(-t) = (\\phi+\\psi)(t)^{-1}")]]

#text("for all ")#mi("{t \\in {\\bf R}}")#text(" and all positive integers ")#mi("{a,b}")#text(". To prove the first claim, we observe that")

#tao-aligned(keep: true)[


#tao-math("(\\phi+\\psi)(at)  & = \\lim_{n \\rightarrow \\infty} (\\phi(at/n) \\psi(at/n))^n", block: true)



#tao-math(" & = \\lim_{n \\rightarrow \\infty} (\\phi(t/n) \\psi(t/n))^{an}", block: true)
]

#text("and similarly for ")#mi("{(\\phi+\\psi)(bt)}")#text(" and ")#mi("{(\\phi+\\psi)((a+b)t)}")#text(", whence the claim. To prove the second claim, we see that")

#tao-aligned(keep: true)[


#tao-math("(\\phi+\\psi)(-t)^{-1}  & = \\lim_{n \\rightarrow \\infty} (\\phi(-t/n) \\psi(-t/n))^{-n}", block: true)



#tao-math(" & = \\lim_{n \\rightarrow \\infty} (\\psi(t/n) \\phi(t/n))^n,", block: true)
]

#text("but ")#mi("{(\\psi(t/n) \\phi(t/n))^n}")#text(" is ")#mi("{(\\phi(t/n) \\psi(t/n))^n}")#text(" conjugated by ")#mi("{\\psi(t/n)}")#text(", which goes to the identity; and the claim follows. ")#mi("\\Box")

#mi("{L(G)}")#text(" also has an obvious zero element, namely the trivial one-parameter subgroup ")#mi("{t \\mapsto \\text{id}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 19")]#text(" ")#mi("{L(G)}")#text(" is a topological vector space.")
]

#emph[#text("Proof:")]#text(" We first show that ")#mi("{L(G)}")#text(" is a vector space. It is clear that the zero element ")#mi("{0}")#text(" of ")#mi("{L(G)}")#text(" is an additive and scalar multiplication identity, and that scalar multiplication is associative. To show that addition is commutative, we again use the observation that ")#mi("{(\\psi(t/n) \\phi(t/n))^n}")#text(" is ")#mi("{(\\phi(t/n) \\psi(t/n))^n}")#text(" conjugated by an element that goes to the identity. A similar argument shows that ")#mi("{(-\\phi) + (-\\psi) = -(\\phi+\\psi)}")#text(", and a change of variables argument shows that ")#mi("{(a\\phi) + (a\\psi) = a(\\phi+\\psi)}")#text(" for all positive integers ")#mi("{a}")#text(", hence for all rational ")#mi("{a}")#text(", and hence by continuity for all real ")#mi("{a}")#text(". The only remaining thing to show is that addition is associative, thus if ")#mi("{\\phi, \\psi, \\eta \\in L(G)}")#text(", that ")#mi("{((\\phi+\\psi)+\\eta)(t) = (\\phi+(\\psi+\\eta))(t)}")#text(" for all ")#mi("{t \\in {\\bf R}}")#text(". By the homomorphism property, it suffices to show this for all sufficiently small ")#mi("{t}")#text(".")

#text("An inspection of the argument used to establish ")#link(<tao-fd7275bbea343cb9700f>)[#text("(18)")]#text(" reveals that there is a constant ")#mi("{\\epsilon > 0}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("d( (\\phi+\\psi)(t), (\\phi(t/n) \\psi(t/n))^n ) \\ll \\epsilon^2 / n")]]

#text("for all small ")#mi("{t}")#text(" and all large ")#mi("{n}")#text(", and hence also that")

#align(center)[#tao-fit-display[#mitex("d( (\\phi+\\psi)(t/n), \\phi(t/n) \\psi(t/n) ) \\ll \\epsilon^2 / n^2")]]

#text("(thanks to Lemma ")#link(<tao-2f8c0b475a71847a5766>)[#text("16")]#text("). Similarly we have (after adjusting ")#mi("{\\epsilon}")#text(" if necessary)")

#align(center)[#tao-fit-display[#mitex("d( ((\\phi+\\psi)+\\eta)(t), ((\\phi+\\psi)(t/n) \\eta(t/n))^n ) \\ll \\epsilon^2 / n.")]]

#text("From Lemma ")#link(<tao-2f8c0b475a71847a5766>)[#text("16")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("d( ((\\phi+\\psi)(t/n) \\eta(t/n))^n, (\\phi(t/n) \\psi(t/n)\\eta(t/n))^n ) \\ll \\epsilon^2/n")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("d( ((\\phi+\\psi)+\\eta)(t), (\\phi(t/n) \\psi(t/n) \\eta(t/n))^n ) \\ll \\epsilon^2 / n.")]]

#text("Similarly for ")#mi("{\\phi+(\\psi+\\eta)}")#text(". By the triangle inequality we conclude that")

#align(center)[#tao-fit-display[#mitex("d( ((\\phi+\\psi)+\\eta)(t), (\\phi+(\\psi+\\eta))(t)) \\ll \\epsilon^2 / n;")]]

#text("sending ")#mi("{t}")#text(" to zero, the claim follows.")

#text("Finally, we need to show that the vector space operations are continuous. It is easy to see that scalar multiplication is continuous, as are the translation operations; the only remaining thing to verify is that addition is continuous at the origin. Thus, for every ")#mi("{\\epsilon > 0}")#text(" we need to find a ")#mi("{\\delta > 0}")#text(" such that ")#tao-math("{\\sup_{t \\in [-1,1]} \\left\\| (\\phi+\\psi)(t) \\right\\| \\leq \\epsilon}", block: false)#text(" whenever ")#tao-math("{\\sup_{t \\in [-1,1]} \\left\\| \\phi(t) \\right\\| \\leq \\delta}", block: false)#text(" and ")#tao-math("{\\sup_{t \\in [-1,1]} \\left\\| \\psi(t) \\right\\| \\leq \\delta}", block: false)#text(". But if ")#mi("{\\phi, \\psi}")#text(" are as above, then by the escape property (assuming ")#mi("{\\delta}")#text(" small enough) we conclude that ")#tao-math("{\\left\\| \\phi(t)\\right\\|, \\left\\|\\psi(t)\\right\\| \\ll \\delta \\left|t\\right|}", block: false)#text(" for ")#mi("{t \\in [-1,1]}")#text(", and then from the triangle inequality we conclude that ")#tao-math("{\\left\\| (\\phi+\\psi)(t) \\right\\| \\ll \\delta}", block: false)#text(" for ")#mi("{t \\in [-1,1]}")#text(", giving the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Show that for any ")#mi("{\\phi \\in L(G)}")#text(", the quantity")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\phi \\right\\| := \\lim_{n \\rightarrow \\infty} n \\left\\|\\phi(1/n)\\right\\|", block: true)]]

#text("exists and defines a norm on ")#mi("{L(G)}")#text(" that generates the topology on ")#mi("{L(G)}")#text(".")
]

#text("As ")#mi("{L(G)}")#text(" is both locally compact, metrisable, and a topological vector space, it must be isomorphic to a finite-dimensional vector space ")#mi("{{\\bf R}^n}")#text(" with the usual topology, thanks to Theorem ")#link(<tao-25bf8e1a2393f1108d37>)[#text("14")]#text(".")

#text("In analogy with the Lie algebra setting, we define the ")#emph[#text("exponential map")]#text(" ")#mi("{\\exp: L(G) \\rightarrow G}")#text(" by setting ")#mi("{\\exp(\\phi) := \\phi(1)}")#text(". Given the topology on ")#mi("{L(G)}")#text(", it is clear that this is a continuous map.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" ")#metadata(none) <tao-e6f2ad814692e3f553d6>#text(" Show that the exponential map is locally injective near the origin. (")#emph[#text("Hint:")]#text(" from Lemma ")#link(<tao-2f8c0b475a71847a5766>)[#text("16")]#text(", obtain the unique square roots property: if ")#mi("{g, h \\in G}")#text(" are sufficiently close to the identity and ")#mi("{g^2=h^2}")#text(", then ")#mi("{g=h}")#text(".)")
]

#text("We have proved a number of useful things about ")#mi("{L(G)}")#text(", but at present we have not established that ")#mi("{L(G)}")#text(" is ")#emph[#text("large")]#text(" in any substantial sense; indeed, at present, ")#mi("{L(G)}")#text(" could be completely trivial even if ")#mi("{G}")#text(" was large. In particular, the image of the exponential map ")#mi("{\\exp}")#text(" could conceivably be quite small. We now address this issue. As a warmup, we show that ")#mi("{L(G)}")#text(" is at least non-trivial if ")#mi("{G}")#text(" is non-discrete (cf. Lemma ")#link(<tao-a6a517dc1b0d60227bc1>)[#text("10")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 20")]#text(" Suppose that ")#mi("{G}")#text(" is not a discrete group. Then ")#mi("{L(G)}")#text(" is non-trivial.")
]

#text("Of course, the converse is obvious; discrete groups do not admit any non-trivial one-parameter subgroups.")

#emph[#text("Proof:")]#text(" As ")#mi("{G}")#text(" is not discrete, there is a sequence ")#mi("{g_n}")#text(" of non-identity elements of ")#mi("{G}")#text(" such that ")#tao-math("{\\left\\|g_n\\right\\| \\rightarrow 0}", block: false)#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". Writing ")#mi("{N_n}")#text(" for the integer part of ")#tao-math("{\\epsilon / \\left\\|g_n\\right\\|}", block: false)#text(", then ")#mi("{N_n \\rightarrow \\infty}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", and we conclude from the escape property that ")#tao-math("{\\left\\| g_n^{N_n} \\right\\| \\sim \\epsilon}", block: false)#text(" for all ")#mi("{n}")#text(".")

#text("We define the approximate one-parameter subgroups ")#mi("{\\phi_n: [-1,1] \\rightarrow G}")#text(" by setting")

#align(center)[#tao-fit-display[#mitex("\\phi_n(t) := g_n^{\\lfloor t N_n \\rfloor}.")]]

#text("Then we have ")#tao-math("{\\left\\|\\phi_n(t) \\right\\| \\ll \\epsilon \\left|t\\right| + \\frac{\\epsilon}{N_n}}", block: false)#text(" for ")#tao-math("{\\left|t\\right| \\leq 1}", block: false)#text(", and we have the approximate homomorphism property")

#align(center)[#tao-fit-display[#mitex("d( \\phi_n(t+s), \\phi_n(t) \\phi_n(s) ) \\rightarrow 0")]]

#text("uniformly whenever ")#tao-math("{\\left|t\\right|, \\left|s\\right|, \\left|t+s\\right| \\leq 1}", block: false)#text(". As a consequence, ")#mi("{\\phi_n}")#text(" is asymptotically equicontinuous on ")#mi("{[-1,1]}")#text(", and so by (a slight generalisation of) the Arzéla-Ascoli theorem, we may pass to a subsequence in which ")#mi("{\\phi_n}")#text(" converges uniformly to a limit ")#mi("{\\phi: [-1,1] \\rightarrow G}")#text(", which is a genuine homomorphism that is genuinely continuous, and is thus can be extended to a one-parameter subgroup. Also, ")#tao-math("{\\left\\|\\phi_n(1)\\right\\| = \\left\\|g_n^{N_n} \\right\\| \\sim \\epsilon}", block: false)#text(" for all ")#mi("{n}")#text(", and thus ")#tao-math("{\\left\\|\\phi(1)\\right\\| \\sim \\epsilon}", block: false)#text("; in particular, ")#mi("{\\phi}")#text(" is non-trivial, and the claim follows. ")#mi("\\Box")

#text("We now generalise the above proposition to a more useful result (cf. Lemma ")#link(<tao-e314a742ccb49d92d465>)[#text("11")]#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 21")]#text(" ")#metadata(none) <tao-8e567ee3e03f4b0bf31a>#text(" For any neighbourhood ")#mi("{K}")#text(" of the origin in ")#mi("{L(G)}")#text(", ")#mi("{\\exp(K)}")#text(" is a neighbourhood of the identity in ")#mi("{G}")#text(".")
]

#emph[#text("Proof:")]#text(" We use an argument ")#link("http://www.ams.org/mathscinet-getitem?mr=967314")[#text("of Hirschfeld")]#text(" (communicated to me by van den Dries and Goldbring). By shrinking ")#mi("{K}")#text(" if necessary, we may assume that ")#mi("{K}")#text(" is a compact star-shaped neighbourhood, with ")#mi("{\\exp(K)}")#text(" contained in the ball of radius ")#mi("{\\epsilon}")#text(" around the origin. As ")#mi("{K}")#text(" is compact, ")#mi("{\\exp(K)}")#text(" is compact also.")

#text("Suppose for contradiction that ")#mi("{\\exp(K)}")#text(" is not a neighbourhood of the identity, then there is a sequence ")#mi("{g_n}")#text(" of elements of ")#mi("{G \\backslash K}")#text(" such that ")#tao-math("{\\left\\|g_n\\right\\| \\rightarrow 0}", block: false)#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". By the compactness of ")#mi("{K}")#text(", we can find an element ")#mi("{h_n}")#text(" of ")#mi("{K}")#text(" that minimises the distance ")#mi("{d(g_n,h_n)}")#text(". If we then write ")#mi("{g_n = h_n k_n}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left\\|k_n\\right\\| = d(g_n,h_n) \\leq d(g_n,\\text{id}) = \\left\\|g_n\\right\\|", block: true)]]

#text("and hence ")#tao-math("{\\left\\|h_n\\right\\|, \\left\\|k_n\\right\\| \\rightarrow 0}", block: false)#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".")

#text("Let ")#mi("{N_n}")#text(" be the integer part of ")#tao-math("{\\epsilon_n / \\left\\|k_n\\right\\|}", block: false)#text(", then ")#mi("{N_n \\rightarrow \\infty}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", and ")#tao-math("{\\left\\|k_n^{N_n} \\right\\| \\sim \\epsilon}", block: false)#text(" for all ")#mi("{n}")#text(".")

#text("Let ")#mi("{\\phi_n: [-1,1] \\rightarrow G}")#text(" be the approximate one-parameter subgroups defined as")

#align(center)[#tao-fit-display[#mitex("\\phi_n(t) := k_n^{\\lfloor t N_n \\rfloor}.")]]

#text("As before, we may pass to a subsequence such that ")#mi("{\\phi_n}")#text(" converges uniformly to a limit ")#mi("{\\phi: [-1,1] \\rightarrow G}")#text(", which extends to a one-parameter subgroup ")#mi("{\\phi \\in L(G)}")#text(".")

#text("In a similar vein, since ")#mi("{h_n \\in \\exp(K)}")#text(", we can find ")#mi("{\\psi_n \\in K}")#text(" such that ")#mi("{\\psi_n(1) = h_n}")#text(", which by the escape property (and the smallness of ")#mi("{K}")#text(" implies that ")#tao-math("{\\left\\| \\psi_n(t) \\right\\| \\ll t \\left\\| h_n\\right\\|}", block: false)#text(" for ")#tao-math("{\\left|t\\right| \\leq 1}", block: false)#text(". In particular, ")#mi("{\\psi_n}")#text(" goes to zero in ")#mi("{L(G)}")#text(".")

#text("We now claim that ")#mi("{\\exp( \\psi_n + \\frac{1}{N_n} \\phi )}")#text(" is close to ")#mi("{g_n}")#text(". Indeed, from Lemma ")#link(<tao-2f8c0b475a71847a5766>)[#text("16")]#text(" we see that")

#align(center)[#tao-fit-display[#mitex("d( \\exp( \\psi_n + \\frac{1}{N_n} \\phi ), \\exp( \\psi_n ) \\exp( \\frac{1}{N_n} \\phi ) ) \\ll \\frac{1}{N_n} \\| h_n \\|.")]]

#text("Since ")#mi("{\\exp(\\psi_n) = h_n}")#text(", we conclude from the triangle inequality and left-invariance that")

#align(center)[#tao-fit-display[#tao-math("d( \\exp( \\psi_n + \\frac{1}{N_n} \\phi ), g_n) \\ll \\frac{1}{N_n} \\left\\| h_n \\right\\| + d( k_n, \\exp( \\frac{1}{N_n} \\phi ) ).", block: true)]]

#text("But from Lemma ")#link(<tao-2f8c0b475a71847a5766>)[#text("16")]#text(" again, one has")

#align(center)[#tao-fit-display[#mitex("d( k_n, \\exp( \\frac{1}{N_n} \\phi ) ) \\ll \\frac{1}{N_n} d( k_n^{N_n}, \\exp( \\phi ) ) = o( 1/N_n )")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("d( \\exp( \\psi_n + \\frac{1}{N_n} \\phi ), g_n) = o(1/N_n).")]]

#text("But for ")#mi("{n}")#text(" large enough, ")#mi("{\\psi_n + \\frac{1}{N_n} \\phi}")#text(" lies in ")#mi("{K}")#text(", and so the distance from ")#mi("{g_n}")#text(" to ")#mi("{K}")#text(" is ")#mi("{o(1/N_n) = o(d(g_n,h_n))}")#text(". But this contradicts the minimality of ")#mi("{h_n}")#text(" for ")#mi("{n}")#text(" large enough, and the claim follows. ")#mi("\\Box")

#text("If ")#mi("{K}")#text(" is a sufficiently small compact neighbourhood of the identity in ")#mi("{L(G)}")#text(", then ")#mi("{\\exp: K \\rightarrow \\exp(K)}")#text(" is bijective by Lemma ")#link(<tao-e6f2ad814692e3f553d6>)[#text("8")]#text("; since it is also continuous, ")#mi("{K}")#text(" is compact, and ")#mi("{\\exp(K)}")#text(" is Hausdorff, we conclude that ")#mi("{\\exp: K \\rightarrow \\exp(K)}")#text(" is a homeomorphism. The local group structure ")#mi("{G\\downharpoonright_{\\exp(K)}}")#text(" on ")#mi("{\\exp(K)}")#text(" then pulls back to a local group structure on ")#mi("{K}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" ")#metadata(none) <tao-fadeca3c739cb730b13b>#text(" If we identify ")#mi("{L(G)}")#text(" with ")#mi("{{\\bf R}^d}")#text(" for some ")#mi("{d}")#text(", show that the exponential map ")#mi("{\\exp: K \\rightarrow \\exp(K)}")#text(" is bilipschitz.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 22")]#text(" ")#mi("{K}")#text(" is a radially homogeneous ")#mi("{C^{1,1}}")#text(" local group (as defined in Definition 7 and (11) from ")#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/")[#text("the previous notes")]#text("), after identifying ")#mi("{L(G)}")#text(" with ")#mi("{{\\bf R}^d}")#text(" for some finite ")#mi("{d}")#text(".")
]

#emph[#text("Proof:")]#text(" The radial homogeneity is clear from ")#link(<tao-094f48d4280524d428cc>)[#text("(4)")]#text(" and the homomorphism property, so the main task is to establish the ")#mi("{C^{1,1}}")#text(" property")

#align(center)[#tao-fit-display[#tao-math("x \\ast y = x + y + O(\\left|x\\right| \\left|y\\right|)", block: true)]]

#text("for the local group law ")#mi("{\\ast}")#text(" on ")#mi("{K}")#text(". By Exercise ")#link(<tao-fadeca3c739cb730b13b>)[#text("9")]#text(", this is equivalent to the assertion that")

#align(center)[#tao-fit-display[#tao-math("d( \\phi(1) \\psi(1), (\\phi+\\psi)(1)) \\ll \\left\\| \\phi(1) \\right\\| \\left\\| \\psi(1) \\right\\|", block: true)]]

#text("for ")#mi("{\\phi, \\psi}")#text(" sufficiently close to the identity in ")#mi("{L(G)}")#text(". By definition of ")#mi("{\\phi+\\psi}")#text(", it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("d( \\phi(1) \\psi(1), (\\phi(1/n)\\psi(1/n))^n) \\ll \\left\\| \\phi(1) \\right\\| \\left\\| \\psi(1) \\right\\|", block: true)]]

#text("for all ")#mi("{n}")#text("; but this follows from Lemma ")#link(<tao-2f8c0b475a71847a5766>)[#text("16")]#text(" (and the observation, from the escape property, that ")#tao-math("{\\left\\|\\phi(1/n)\\right\\| \\ll \\left\\|\\phi(1)\\right\\|/n}", block: false)#text(" and ")#tao-math("{\\left\\| \\psi(1/n) \\right\\| \\ll \\left\\| \\psi(1)\\right\\|/n}", block: false)#text("). ")#mi("\\Box")

#text("Combining this proposition with Lemma 16 from the ")#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/")[#text("previous notes")]#text(", we obtain Theorem ")#link(<tao-f5a85b0ee2bfa3637a1c>)[#text("7")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" State and prove a version of Theorem ")#link(<tao-f5a85b0ee2bfa3637a1c>)[#text("7")]#text(" for local groups. (In order to do this, you must first decide how to define an analogue of a Gleason metric on a local group.)")
]

#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/#comment-77454")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2011")])]

#text("The last sentence of the first paragraph should be ‘we call such local groups…’.")

#text("Also, the sentence ‘the one-parameter subgroups are in one-to-one correspondence with the Lie algebra g’ doesn’t make sense. Do you mean ‘elements of the Lie algebra g’?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3: Haar measure and the Peter-Weyl theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/#comment-85824")[#strong[#text("254A, Notes 3: Haar measure and the Peter-Weyl theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2011")])]

#text("[…] the last few notes, we have been steadily reducing the amount of regularity needed on a topological group in order to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 4: Building metrics on groups, and the Gleason-Yamabe theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/#comment-89084")[#strong[#text("254A, Notes 4: Building metrics on groups, and the Gleason-Yamabe theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2011")])]

#text("[…] Gleason-Yamabe theorem, we will use three major tools developed in previous notes. The first (from Notes 2) is a criterion for Lie structure in terms of a special type of metric, which we will call a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 5: The structure of locally compact groups, and Hilbert’s fifth problem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/#comment-90830")[#strong[#text("254A, Notes 5: The structure of locally compact groups, and Hilbert’s fifth problem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2011")])]

#text("[…] to the quotient of by a compact normal subgroup . By Cartan’s theorem (Theorem 2 of Notes 2), is also a Lie group. Among other things, this implies that the quotient homomorphism from the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel zorin")]], [#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/#comment-90975")[#strong[#text("pavel zorin")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2011")])]

#text("Dear Prof. Tao,")

#text("In the proof of theorem 14 one can use the continuity of scalar multiplication at (0,0) to make U bounded. This is easier and also shows that the continuity of addition is not needed in this step.")

#text("best regards,")#linebreak()#text(" pavel")

#emph[#text("[Good point; I’ve made the change. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Hayes")]], [#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/#comment-93302")[#strong[#text("Ben Hayes")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2011")])]

#text("In Lemma 17 I don’t quite see how you apply the escape property. To apply the escape property, you need to already know that ")#tao-math("n\\left\\|\\phi(t/n)\\right\\|\\leq 1/C,", block: false)#text(" whereas it appears that at this stage you only know ")#tao-math("n\\left\\|\\phi(t/n)\\right\\|\\leq \\varepsilon n.", block: false)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/#comment-93334")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2011")])]

#text("If ")#tao-math("n \\left\\|\\phi(t/n)\\right\\|", block: false)#text(" exceeds 1/C, then one works instead with the largest positive integer m for which ")#tao-math("m \\left\\|\\phi(t/n)\\right\\| \\leq 1/C", block: false)#text("; this will be an integer between 1 and n, and for ")#mi("\\varepsilon")#text(" small enough one can show that one must have ")#mi("m \\gg n")#text(" to avoid a contradiction.")

#text("(More generally, one often encounters “almost circular reasoning” issues in these sorts of problems, in which one almost has to assume the result one is trying to prove as a hypothesis. Often, one has to deal with the apparent circularity by an induction argument, a bootstrap argument, a continuity argument, an infinite descent argument, or passing to the “first counterexample” or “last example”. The above is an instance of the latter strategy.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Hayes")]], [#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/#comment-93358")[#strong[#text("Ben Hayes")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2011")])]

#text("Ah, when I go through the estimates I see the contradiction now. Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 7: Models of ultra approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/#comment-97540")[#strong[#text("254A, Notes 7: Models of ultra approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2011")])]

#text("[…] create a metric structure on strong approximate groups analogous to the Gleason metrics studied in previous notes, which can in turn be exploited (together with an induction on dimension argument) to fully […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The microstructure of approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/#comment-111730")[#strong[#text("254A, Notes 8: The microstructure of approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2011")])]

#text("[…] was a key difficulty in the theory surrounding Hilbert’s fifth problem that was discussed in previous notes. A key tool in being able to resolve such structure was to build left-invariant metrics (or […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The closed graph theorem in various categories « What’s new")]], [#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/#comment-194634")[#strong[#text("The closed graph theorem in various categories « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2012")])]

#text("[…] There is also a number of closed graph theorems for topological groups, of which the following is typical (see Exercise 3 of these previous blog notes): […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on simple groups of Lie type | What's new")]], [#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/#comment-243958")[#strong[#text("Notes on simple groups of Lie type | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2013")])]

#text("[…] complex Lie group but are clearly not a Lie group. However, a basic theorem of Cartan (proven in this previous post) says that any subgroup of a real Lie group which is topologically closed, is also a real Lie […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c1c7a10c0f7425b92545b8bdd5201144a3eafab5bea23c58928178cfbfb150c-02c61f8095e198a50ca4d4b041a81089211cdb9048409ebe7f6d9f89505268e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Piotr")]], [#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/#comment-509142")[#strong[#text("Piotr")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2018")])]

#text("Dear Professor Tao!")

#text("For a few months I’m deeply studying your book about Hilbert’s Fifth Problem. I stacked in Exercise 9 (formulated above on the web page), which is crucial in the proof of Proposition 22. One of Lipschitz conditions in Exercise 9 is equivalent to the following:")

#text("If (in a NSS group with Gleason metric):")#linebreak()#text(" n ||g|| < A and n ||h|| < A (for sufficiently small A), then:")#linebreak()#text(" ||(gh)^n|| < B ||g^n h^n|| (for sufficiently large, but fixed, B)")#linebreak()#text(" I have no idea how to show this property! I spent many hours on this and finally gave up. Thus, I'd kindly like to ask you about any hint to show that the inverse of exp is Lipschitz in a small neighbourhood of the unit of G.")

#text("Thanks in advance for your help.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c1c7a10c0f7425b92545b8bdd5201144a3eafab5bea23c58928178cfbfb150c-02c61f8095e198a50ca4d4b041a81089211cdb9048409ebe7f6d9f89505268e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Piotr")]], [#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/#comment-509163")[#strong[#text("Piotr")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2018")])]

#text("OK, got it – it is hidden in the proof of Lemma 16.")
]
]
