// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/
// Converted to Typst by tao2typ: "2026-10-18T11:27:48.422644+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Starting a new journal", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Starting a new journal")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/")[#text("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-18 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://sites.google.com/view/shaomingguo")[#text("Shaoming Guo")]#text(" – T.]")]

#text("Several math colleagues and I are preparing to launch a new journal. As we considered which values we wanted the journal to uphold, we realized that there may be many other values worth exploring as a community, potentially through the creation of additional journals. We would like to use Terry’s blog to open a discussion of these possibilities. There are many dimensions to this discussion: what journals should aim to accomplish, what kinds of mathematical contributions they should recognize and reward, how papers should be evaluated, and how mathematical knowledge can best be communicated and made reliable. As new tools change the way mathematics is developed and shared, we have an opportunity to reconsider long standing conventions and imagine new possibilities for mathematical publishing.")

#text("For the journal we are currently planning, we envision two core values (in additional to traditional values like open access):")

#strong[#text("Prioritizing understanding over being first.")]#text(" We place far greater value on how much a paper deepens our understanding of its results and proofs than on whether it provides the first proof of those results.")

#strong[#text("Ensuring rigor through formal verification.")]#text(" As large language models (LLMs) are increasingly used to develop mathematical proofs, the potential for subtle, hard-to-detect errors is a growing concern. To be accepted, a paper will need to have its proofs formally verified in Lean.")

#text("Alongside feedback on this proposal, we welcome ideas for substantially different visions of future journals: the values they might uphold, the needs they might serve, and the practices they might adopt. A single journal is unlikely to accommodate every worthwhile idea, and combining too many requirements could place excessive constraints on authors. We hope this discussion will inspire a variety of new journals and other platforms, allowing the community to explore different approaches to the future of mathematical publishing.")

#text("_______")

#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698281")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("It seems like Lean has become the dominant proof-checking software. It seems to me that this is risky, because it is putting all of our (proof-checking) eggs in one basket – a bug (or bugs) may propagate. It seems like other proof checking software ought to be allowed, although maybe it is easy enough to translate between them using AI at this point. I suppose also at this point the Lean library is much further developed than others, so maybe this makes it preferable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698282")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("If you are already requiring verification in Lean, then the quality of the exposition should be emphasized by reviewers in quick opinions and reports. Referee are primarily concerned with correctness traditionally, but they should feel more freedom to develop the presentation as correctness is not in doubt.")

#text("I also think all journals should mandate AI use statements in the manuscripts themselves.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44a5fcb217b9c8556cf9f0d5f639fb8ae250a9e5579074ddded545d602cf5d83-71ec8f269291541dd7bf924ba58371566515417e220a84308a08ef761ed96cd7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Suhas Sreehari")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698283")[#strong[#text("Suhas Sreehari")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#enum(start: 1, 
[#text("Something like Explainable Math?")],
[#text("Is there a good way to quantify “understanding”?")]
)

#text("Both these items seem to be function of both the mathematics presented itself and the level of the readers. I faced similar challenges while working on explainable AI.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698284")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("If you ask proofs written in lean then you explicitly exclude researchers without access to sufficiently strong llms, or researchers who do not enter their thoughts into them. Nobody not specializing in lean itself can have the time to formalize all proofs in lean if not using llms for that.")

#text("In that you explicitly exclude mathematicians from low income countries who cannot afford sufficiently strong llms and researchers who do not have access for geopolitical reasons.")

#text("I also could not see how you plan to counter LLMs generating hundred thousands lines of lean to not exploiting soundness bugs to achieve their target.")

#text("I think if you have to start a new journal, then better do something that actually is healthy for mathematics. Have you ever thought of doing something inclusive? If you really want formally verified math (still, how you avoid llms from exploiting soundness bugs?), then run the llm yourself and translate conditionally accepted papers to lean yourself on your journal compute, that could maybe be an innovative futuristic journal.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3a67e42ee6dddacfe12657ab6801ed29cd7965344c6646279b187c7b76fefcd-cebbe0226281f777dfd322b06ca6de71b1485abcc4c199db5f5e8d10bdec0816.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698285")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("One very concrete proposal: Make/keep the new jounal open for good digests of results from the 372-OpenAI batch. Of course this may not cary a journal over decades. But I expect other AI-company batches to fall on us.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2a2651fe8138c53b598edda970badadaceeefb161081633370ce9fcd8b3ef9b9-1cdd0d1164d7ceb648f7751ba805dc56b387240cf99cd839536855114256a5eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of delectably8f1f83aa5f")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698286")[#strong[#text("delectably8f1f83aa5f")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("The journal should explicitly value and welcome good expositions of AI-generated mathematical results. We can still value “being first”, but priority and full scholarly credit should go to the first person who provides a clear and rigorous explanation of a result, rather than to whoever first obtained it through AI prompting.")

#text("Individuals or AI companies whose contribution was limited to obtaining the result through prompting should receive no credit in the body of the paper, only attribution in the reference list. Similarly, the names of LLMs used should not appear at all.")
]
