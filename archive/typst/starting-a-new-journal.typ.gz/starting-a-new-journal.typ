// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/
// Converted to Typst by tao2typ: "2026-10-29T13:24:14.997025+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Starting a new journal", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Starting a new journal")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/")[#text("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-29 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://sites.google.com/view/shaomingguo")[#text("Shaoming Guo")]#text(" – T.]")]

#text("Several math colleagues and I are preparing to launch a new journal. As we considered which values we wanted the journal to uphold, we realized that there may be many other values worth exploring as a community, potentially through the creation of additional journals. We would like to use Terry’s blog to open a discussion of these possibilities. There are many dimensions to this discussion: what journals should aim to accomplish, what kinds of mathematical contributions they should recognize and reward, how papers should be evaluated, and how mathematical knowledge can best be communicated and made reliable. As new tools change the way mathematics is developed and shared, we have an opportunity to reconsider long standing conventions and imagine new possibilities for mathematical publishing.")

#text("For the journal we are currently planning, we envision two core values (in additional to traditional values like open access):")

#strong[#text("Prioritizing understanding over being first.")]#text(" We place far greater value on how much a paper deepens our understanding of its results and proofs than on whether it provides the first proof of those results.")

#strong[#text("Ensuring rigor through formal verification.")]#text(" As large language models (LLMs) are increasingly used to develop mathematical proofs, the potential for subtle, hard-to-detect errors is a growing concern. To be accepted, a paper will need to have its proofs formally verified in Lean.")

#text("Alongside feedback on this proposal, we welcome ideas for substantially different visions of future journals: the values they might uphold, the needs they might serve, and the practices they might adopt. A single journal is unlikely to accommodate every worthwhile idea, and combining too many requirements could place excessive constraints on authors. We hope this discussion will inspire a variety of new journals and other platforms, allowing the community to explore different approaches to the future of mathematical publishing.")

#heading(level: 1)[#text("Comments (36)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698281")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("It seems like Lean has become the dominant proof-checking software. It seems to me that this is risky, because it is putting all of our (proof-checking) eggs in one basket – a bug (or bugs) may propagate. It seems like other proof checking software ought to be allowed, although maybe it is easy enough to translate between them using AI at this point. I suppose also at this point the Lean library is much further developed than others, so maybe this makes it preferable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698282")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("If you are already requiring verification in Lean, then the quality of the exposition should be emphasized by reviewers in quick opinions and reports. Referee are primarily concerned with correctness traditionally, but they should feel more freedom to develop the presentation as correctness is not in doubt.")

#text("I also think all journals should mandate AI use statements in the manuscripts themselves.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44a5fcb217b9c8556cf9f0d5f639fb8ae250a9e5579074ddded545d602cf5d83-71ec8f269291541dd7bf924ba58371566515417e220a84308a08ef761ed96cd7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Suhas Sreehari")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698283")[#strong[#text("Suhas Sreehari")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#enum(start: 1, 
[#text("Something like Explainable Math?")],
[#text("Is there a good way to quantify “understanding”?")]
)

#text("Both these items seem to be function of both the mathematics presented itself and the level of the readers. I faced similar challenges while working on explainable AI.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698284")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("If you ask proofs written in lean then you explicitly exclude researchers without access to sufficiently strong llms, or researchers who do not enter their thoughts into them. Nobody not specializing in lean itself can have the time to formalize all proofs in lean if not using llms for that.")

#text("In that you explicitly exclude mathematicians from low income countries who cannot afford sufficiently strong llms and researchers who do not have access for geopolitical reasons.")

#text("I also could not see how you plan to counter LLMs generating hundred thousands lines of lean to not exploiting soundness bugs to achieve their target.")

#text("I think if you have to start a new journal, then better do something that actually is healthy for mathematics. Have you ever thought of doing something inclusive? If you really want formally verified math (still, how you avoid llms from exploiting soundness bugs?), then run the llm yourself and translate conditionally accepted papers to lean yourself on your journal compute, that could maybe be an innovative futuristic journal.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2c6be8eae1133cc49924bf2642a16d02fdebf47661f20a6a9bfe91bcdb24189-25c8364ff23a3cc3e6654aab462233982e3fa40f123fc7f7b5d2d33381b19017.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jarno Niklas Alanko")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698291")[#strong[#text("Jarno Niklas Alanko")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("I don’t think it’s unreasonable to assume that research requires some investment in resources. This is already the case in most natural sciences. If people don’t want to use commercial models (understandable), open models exist. So far, they have been only about 6 months behind the frontier models.")

#text("Soundness bugs might not be such a big problem because the Lean certificate is accompanied by a human-understandable proof which would presumably be checkable by humans. The certificate would provide a building block which people could tinker with or try plugging into other results.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698325")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("Currently a non-quantized GLM-5.2 requires four Nvidia RTX 6000 at least and will cost between $50,000-$75,000.")

#text("I also highly doubt that in 6 months GLM or Kimi will solve a millennium problem on local hardware.")

#text("Local models are the perpetual carrot to make people think that there is no oligarchy.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698317")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("Disagree. First of all the journal does not prioritise the first person to get a result. Thus there is no reason to rush in an LLM formalized proof. A good quality handcrafted formalization that people can actually explore would add much more to improve readability for those don’t feel too inconvenienced to learn a little bit of lean.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/830a92db291d7bd0689d679c082a210b53a9f6381227b0ce188726f8e6fc3893-d716d859c5e78db1350560ad826680df67b8136b1669b953432a3424bc60f79c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shreyas")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698318")[#strong[#text("Shreyas")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("I challenge the basic assumption that the proof needs to be autoformalized. One can build a human formalization or even an incrementally AI assisted formalization at a much lower cost.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c362f3735b211c22413bc8c3ad496aeba4d5f0261acab76e3f1522ab660816f3-1176ea5ca7062b5905272d590bbc6941a0f42c89c5d8f0843babd657e962b537.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of turtleluminousa613153523")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698385")[#strong[#text("turtleluminousa613153523")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("Making verified proofs in Lean a core value, it seems reasonable to expect at least one collaborator is a “Lean specialist”. To be meaningful, the Lean accompanying a new proof of an existing, Lean verified, result must follow the reasoning of the exposition. In all cases, the Lean version of the hypothesis must be checked.")

#text("If, say, generating Lean code from a document’s LaTeX is going to be a common path, perhaps there is need for an open source “LaTeX to Lean” project, incorporating a (possible tuned) open weight LLM?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/830a92db291d7bd0689d679c082a210b53a9f6381227b0ce188726f8e6fc3893-d716d859c5e78db1350560ad826680df67b8136b1669b953432a3424bc60f79c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shreyas")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698391")[#strong[#text("Shreyas")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("I think this problem will solve itself as more people learn lean, same as they learned LateX in the 90s.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c362f3735b211c22413bc8c3ad496aeba4d5f0261acab76e3f1522ab660816f3-1176ea5ca7062b5905272d590bbc6941a0f42c89c5d8f0843babd657e962b537.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of turtleluminousa613153523")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698410")[#strong[#text("turtleluminousa613153523")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("Which is fine, but it does make Lean, like LaTeX, an essential tool for research Mathematicians. But there is a genuine bit of a philosophical concern here: the requirement isn’t for a formal proof verified with some trusted tool, but specifically Lean. Either the journal is focused on the subset of Math using Lean as a tool, or is going further and taking a step toward “Math=Lean”. That’s fine, but it would be helpful to clarify if this journal is not ideal for those who have reservations about Lean and whether there is interest in encouraging new journals which are less Lean-centric.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7d6051394e3fcc0690785b8c3bccef691d265abc387c7fbbc8d3ef827fed2a69-72521d1e9b590910c216016611f65bb56bec893c8a062b8e0616a20919031c94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shaoming Guo")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698912")[#strong[#text("Shaoming Guo")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("Thanks for bringing this up. We totally agree. Indeed at least at the beginning stage of the journal, we will have a third party supporting the formalization step. (My earlier response was not displayed.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3a67e42ee6dddacfe12657ab6801ed29cd7965344c6646279b187c7b76fefcd-cebbe0226281f777dfd322b06ca6de71b1485abcc4c199db5f5e8d10bdec0816.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698285")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("One very concrete proposal: Make/keep the new jounal open for good digests of results from the 372-OpenAI batch. Of course this may not cary a journal over decades. But I expect other AI-company batches to fall on us.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2a2651fe8138c53b598edda970badadaceeefb161081633370ce9fcd8b3ef9b9-1cdd0d1164d7ceb648f7751ba805dc56b387240cf99cd839536855114256a5eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of delectably8f1f83aa5f")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698286")[#strong[#text("delectably8f1f83aa5f")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("The journal should explicitly value and welcome good expositions of AI-generated mathematical results. We can still value “being first”, but priority and full scholarly credit should go to the first person who provides a clear and rigorous explanation of a result, rather than to whoever first obtained it through AI prompting.")

#text("Individuals or AI companies whose contribution was limited to obtaining the result through prompting should receive no credit in the body of the paper, only attribution in the reference list. Similarly, the names of LLMs used should not appear at all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698289")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("I suspect that the people behind the new proposed journal don’t fully digest the transformative effect of AI on the human practice of mathematics. It is only a matter of short time before the concept of math journals becomes obsolete, or before human beings clinging to the past and seeking credit for mathematical advances will become laughable. The issues of making proofs intelligible and navigable will eventually be resolved by OpenAI and/or by the release of more advanced models, and I see no point in wasting human effort on something that’s going to happen any way.")

#text("TL;DR Our efforts no longer matter for anything, we’ve reached a point of singularity where actions such as founding a new journal are negligible in the big scheme of things. So let’s just sit back and watch how mathematical history unfolds/ends, it’s not like we really have a choice.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698306")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("nice try 🙂")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fausto")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698290")[#strong[#text("Fausto")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("Are you sure it is a good idea to make Lean formalization mandatory in this new journal? If we want to keep it human, it suffices to do what we learn during the process of becoming a mathematician: 1. write a proof in little steps each of which can be easily checked, 2. give to a proof a conceptual shape, by inventing new structures in terms of which it has a definite meaning; 3. avoid the use of the expression «it is easy to see that» as a shortcut that leads us to mistakes. The use of Lean, instead, seems to me a way to drive us away from the human dimension of mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9681b2f87ea33b181f1f387879a6aadb32e8043588f75ad4b2465fe683caf52-9539735cb8c54f60b13f396b80e5a0252000a028903da6822a98b4424753ef59.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wp1651893662")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698292")[#strong[#text("wp1651893662")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("I think this is a genuinely promising direction, but I want to point out a tension between the two stated values.")

#text("Lean verification certifies correctness. It does not certify understanding — and understanding is a property of a person, not of a proof object. Worse, the availability of machine verification may reduce the pressure on human referees to actually follow an argument, since the hardest part of checking has been delegated. The mechanism may therefore quietly work against the value it is meant to serve.")

#text("If the goal is understanding rather than correctness, it might be worth asking authors to preserve the human traces of the process: failed approaches, partial drafts, revision history, the record of what was tried and abandoned. These are not merely pedagogical material. They are largely what distinguishes a proof that someone understands from a proof that merely compiles — and unlike the finished text, they are hard to fabricate after the fact.")

#text("Formal verification tells us the artefact is sound. It cannot tell us whether anyone can carry it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698377")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("I wish this piece of misinformation would go away. Writing a good, well-documented lean proof requires understanding and organising a proof properly. It enables a lean-competent reader to actually read and understand proofs much better even if they don’t have immediate access to an expert.")

#text("Of course an autoformalization has none of these useful characteristics. But nobody needs to autoformalize. One can actually learn lean and build formalizations incrementally with AI assistance and understand the proof one is communicating.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9681b2f87ea33b181f1f387879a6aadb32e8043588f75ad4b2465fe683caf52-9539735cb8c54f60b13f396b80e5a0252000a028903da6822a98b4424753ef59.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wp1651893662")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698386")[#strong[#text("wp1651893662")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("Fair — I think we agree. I wasn’t claiming that writing a Lean proof requires no understanding; quite the opposite, and your description of incremental formalization with AI assistance is exactly the practice I’d want to encourage.")

#text("My point was narrower, and about the artefact rather than the author. A verified proof guarantees soundness. It doesn’t tell a reader whether anyone has actually carried it — and your own phrasing makes the gap visible: it helps “a lean-competent reader”. Someone still has to become that reader.")

#text("So the question I meant to raise is only this: a journal organised around understanding may want to ask for that second thing explicitly, since it doesn’t follow from the first.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/742d254828b86e85e6fd653e970061760fc6660594191553cd45c5b954820776-c63e55a8497f447af5a7d016b96074cdf9b8a2e4edfa1a3fc9110d231d170c62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Witt Nyström")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698294")[#strong[#text("David Witt Nyström")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("A welcome initiative!")

#text("I am also in the process of launching a new journal, to be called ")#emph[#text("Confessiones Mathematicae")]#text(". It will publish autobiographical (or autohistorical) articles written by mathematicians. The aim is to encourage mathematicians (here understood in a broad sense) to share stories from their mathematical lives, and to collect these stories, making them freely available and easy to find. An important point to make here is that we look for stories, not only from famous people, but from all kinds of mathematicians, and we hope this will benifit the mathematical community as well as provide valuable source material for future historians of mathematics.")

#text("As an example, an article could focus on an old research project, and in addition to explaining the mathematics, it could describe how the author got interested in the problem, and it could also give an account on the actual work process.")

#text("The webpage will soon be found at confessionesmathematicae.com (it is not quite ready yet), and several people that I know have already promised to contribute.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c362f3735b211c22413bc8c3ad496aeba4d5f0261acab76e3f1522ab660816f3-1176ea5ca7062b5905272d590bbc6941a0f42c89c5d8f0843babd657e962b537.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of turtleluminousa613153523")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698299")[#strong[#text("turtleluminousa613153523")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("Requiring Lean verification seems to make the Lean code the “real math”. Would a journal publishing “Literate Lean Proofs” (like Knuth’s “Literate Programming”) make sense?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698383")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("This already exists in the form of the Annals of Formalized Mathematics : ")#link("https://afm.episciences.org")[#text("https://afm.episciences.org")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c362f3735b211c22413bc8c3ad496aeba4d5f0261acab76e3f1522ab660816f3-1176ea5ca7062b5905272d590bbc6941a0f42c89c5d8f0843babd657e962b537.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel M Gessel")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698515")[#strong[#text("Daniel M Gessel")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("The articles don’t appear to be written in a “Literate Programming” style, only including a part of the formal proof in the language of the verifier.")

#text("On the other hand, I may have been the only student to ever check out Knuth’s TeX and Metafont books at my undergraduate institution – “Literate Programming” never did become standard practice.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7d1fad8d5cb3915bde1249e808bd8994af411148244924e89ac1d70823f720a8-d127ba3a49ca28335d1c4eddea84f3b43b6ff4ba52fb7836d556e26bee45bdcc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shreyas")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698520")[#strong[#text("Shreyas")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("I don’t think they died out entirely. They survived in places like the PL community and have been revived in lean.")

#text("Examples :")

#enum(start: 1, 
[#text("From unimath in the ITP Agda : ")#link("https://unimath.github.io/agda-unimath/complex-numbers.html")[#text("https://unimath.github.io/agda-unimath/complex-numbers.html")]],
[#text("The analysis vol 1 book of Terence Tao in lean : ")#link("https://teorth.github.io/analysis/")[#text("https://teorth.github.io/analysis/")]]
)
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fdc94626fb3f1d14afd48c0102842980e6950c98012c6b5b6a51777f7788402-4fc6cc3b74447582f22292ac2d32af7fbad470059d4ca65937d23b2547ea7499.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dpthurst")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698302")[#strong[#text("dpthurst")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("I love a new journal focusing on exposition!")

#text("I would agree with other commenters that Lean verifications might be encouraged, but should not be required. To summarize some points:")

#list(
[#text("The foundations of Lean are surprisingly shaky (to me). See the end of Thomas Hales post: ")#link("https://terrytao.wordpress.com/2026/10/09/what-mathematicians-should-know-about-the-lean-theorem-proverquestions-of-reliability-and-ai/")[#text("https://terrytao.wordpress.com/2026/10/09/what-mathematicians-should-know-about-the-lean-theorem-proverquestions-of-reliability-and-ai/")]#text(" It’s probably OK, but the “probably” worries me since it does happen that type theories are found to be unsound.")],
[#text("It is practically impossible to produce Lean-verified proofs without AI assistance. Insisting on such verification takes (IMO) the focus away from the exposition, which is the aspect that seems most important.")],
[#text("A Lean formalisation is no guarantee that the text as written is correct, since checking that the formalisation agrees with the English text appears to remain challenging even for AIs.")],
[#text("Some areas of math are much easier to formalize than others. See the Annals Challenge for some discussion: ")#link("https://xenaproject.wordpress.com/2026/08/13/the-annals-challenge/")[#text("https://xenaproject.wordpress.com/2026/08/13/the-annals-challenge/")]#text(" or at ")#link("https://arxiv.org/abs/2610.18301v1")[#text("https://arxiv.org/abs/2610.18301v1")]#text(". Currently you’d be cutting out any of the (human-proved) theorems rated “4” or “5”.")],
[#text("There are of course going to be some problems that *cannot* be formalised in Lean. For instance, a proof that Lean is consistent could not be published under these terms.")]
)

#text("It seems you’re worried about getting fooled by AI, but I think the best defense is what mathematicians have always done: aiming for transparency and clarity of exposition, building on solid theories rather than ad hoc arguments as much as possible.")

#text("I also think it would be a mistake to stick to results that have been proved by AI; I’m sure we can all think of human-written results that could use a new exposition, and indeed that has happened historically with, for instance, the 3D Poincaré conjecture.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c444a848a8495e95d351f13559266fe8adcc121d3f7201306c7460a495c0933e-3365f5dfa24141ba2151c926ee663dd6a34f890061a120ece14ba8db40f4a070.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698311")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("How about this: submissions with lean certificates are guaranteed fast track (e.g., one month) review process.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f26479d0eb8456249d7e0cc1febfe3401f29038bd929d77f16804a75e77dcd00-19a7d34cc3645ce953a73432dcba44c0ae84df427219ae75585febb86d7d3546.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shreyas")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698384")[#strong[#text("Shreyas")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("I must push back against two points here.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The foundations of Lean are surprisingly shaky (to me). See the end of Thomas Hales post: ")#link("https://terrytao.wordpress.com/2026/10/09/what-mathematicians-should-know-about-the-lean-theorem-proverquestions-of-reliability-and-ai/")[#text("https://terrytao.wordpress.com/2026/10/09/what-mathematicians-should-know-about-the-lean-theorem-proverquestions-of-reliability-and-ai/")]#text(" It’s probably OK, but the “probably” worries me since it does happen that type theories are found to be unsound")
]

#text("I think the nature and risk of soundness bugs in lean has been severely overstated by recent press and blog stories. In computer science, one measures security against a set of basic model assumptions and attack surface area. In that sense the surface area of attack for trusting lean is much much smaller than trusting natural language exposition by human mathematicians or AI. Concretely it is 10000 lines of rigorous executable code with multiple implementations vs trusting people and bots to do the right thing.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("It is practically impossible to produce Lean-verified proofs without AI assistance. Insisting on such verification takes (IMO) the focus away from the exposition, which is the aspect that seems most important.")
]

#text("This is a good reason to invest time and effort in lean formalization both with and without AI. I wish mathematicians would not show such reluctance to learning a new tool on such flimsy pretexts.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fdc94626fb3f1d14afd48c0102842980e6950c98012c6b5b6a51777f7788402-4fc6cc3b74447582f22292ac2d32af7fbad470059d4ca65937d23b2547ea7499.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dpthurst")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698468")[#strong[#text("dpthurst")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("@Shreyas, I agree with you on the reliability of the implementations; indeed those have been hyped up a lot, and it is getting more and more reliable. What I was surprised by was the uncertainty of the *foundations*, per the very end of Thomas Hales post. No amount of competing implementations can help with that.")

#text("Broadly speaking, writing formal proof systems is a balance between usability to prove theorems we care about and excess flexibility that would let you prove False. How sure are we (by which I guess I mean the logicians) that Lean is on the correct side of that line?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7d1fad8d5cb3915bde1249e808bd8994af411148244924e89ac1d70823f720a8-d127ba3a49ca28335d1c4eddea84f3b43b6ff4ba52fb7836d556e26bee45bdcc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shreyas")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698486")[#strong[#text("Shreyas")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("I guess I mean the logicians) that Lean is on the correct side of that line?")
]

#text("I think the answer is “extremely sure”, in the sense that we know CIC is sound. The gap with nested inductive types is being filled as we discuss, but it is considered sound by experts. It is extremely unlikely that the theory is faulty. Even if it were by some epsilon chance, the FRO would invest effort to make that part of the foundations more conservative, and adapt mathlib (which might not require any adaptations since it barely uses nested inductives).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fdc94626fb3f1d14afd48c0102842980e6950c98012c6b5b6a51777f7788402-4fc6cc3b74447582f22292ac2d32af7fbad470059d4ca65937d23b2547ea7499.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dpthurst")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698493")[#strong[#text("dpthurst")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("Thank you, that was informative!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fcf3ef9fe421fec143272f0f8d1adf2e6a5680c84c325fd0792f01b49136f0a-df11664b77e09e9c5cf9e6be717c27c6e03f0b93762c2db5ae938f24835fb009.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of C.Stefan")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698336")[#strong[#text("C.Stefan")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("Would work for a while? I am trying to convey a broader picture a bit beyond the same methodology yet more like Math3.0 mindset (first principles started 2023). By the fact we are not “alone” anymore so to speak, a methodology and with it a mindset would emerge anew too. It’s the minimal “self-promotion” I will do because obviously this is quite new and not that easy to convey (feedback would be appreciated.) To underline that this is not coming from AI (framework latent for more than 20 years) and more of that, discussing with it, it has itself difficulties to express it. Maybe worth a look, starting with tackling also the “unreasonable effectiveness”: ")#link("https://essentialworks.wordpress.com/2026/10/16/ai-and-the-proof-creates-a-new-concept/")[#text("https://essentialworks.wordpress.com/2026/10/16/ai-and-the-proof-creates-a-new-concept/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f02bfdb443ba9b728568f79e6ab4e520918f373a98af4c585c7f14fafcb91f4d-00708e333ae2e15293fba50387bf1b9baa9e1fbf669d9b53a9d68ba8374d2aeb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan Dougherty")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698339")[#strong[#text("Ryan Dougherty")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("I would really caution how to structure the research lifecycle. I’m an associate editor of a moderate CS education journal and a program chair of a large CS education conference. What we’ve seen is a massive increase in submissions but also a substantial number of AI-generated reviews. (I do CS theory work as my main “other” research area.)")

#text("I’d recommend spending extra time working through the governance structure, such as reviewers, or even if you want human reviewers at all. What I’m doing in my venues is changing the focus of a human reviewer to provide their own humanity in reviews: what do you like about this paper? What reservations do you have in implementing this in your own course? Etc. vs. the standard questions we normally ask, like background research quality, impact, clarity, etc. We are also looking into having a “traditional” AI reviewer alongside the human ones, but only as feedback provided to authors.")

#text("I’d also spend time thinking about what the “main artifact” format type should be. Obviously the traditional one as LaTeX/manuscript PDF but determine if this is what you want (or *only* what you want).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6599acef3981495d0a26ea11afe8e0913d2c68fe3b3f2f11d614cdfd4e5d6bad-7d38e781ffac49209be2ecab1523aff30550ed9d34cff12d675d9db3e09bcdef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pessimist")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698395")[#strong[#text("Pessimist")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("Sounds like a pretty short termed initiatives. LLM will become great at exposition, insight etc too and probably sooner than you expect.")

#text("Then your journal too will be flooded of artificial submissions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698424")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("There’s no “love” in “math”, but “could I have a side of Lean proof with that?” would take any amount of remaining compassion out of nearly every mathematician’s working life, who got into it for the love of the game.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5706fb8c954ed97d6a05ffe7f2243421ce72185264ab5d92fd278b7caa097488-997d03b3ab06884d6d876a78a5d63ba75012d57c96d6f922c9ed731e5cec48c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maciej Capinski")]], [#link("https://terrytao.wordpress.com/2026/10/17/starting-a-new-journal/comment-page-1/#comment-698816")[#strong[#text("Maciej Capinski")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("If we are to do things differently why not go a bit further. Blackboard/slides and spoken word have always been the best means of explaining the core ideas of mathematics. Each paper could be accompanied by a recorded lecture, in which the author(s) could give intuition, present the key steps and core ideas. The lecture could be part of the submission and be reviewed alongside the manuscript. Moreover, if we are to do things differently, the review process could include the possibility of an interview with the author(s). The reviewers should have a chance to hear what the authors have to say and allow them to advocate for their results. If we are to make the new journal and mathematics more human, maybe we could aim to increase human interaction in the review process.")
]
