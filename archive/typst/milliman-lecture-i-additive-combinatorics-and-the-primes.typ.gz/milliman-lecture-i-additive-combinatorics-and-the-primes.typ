// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/12/04/milliman-lecture-i-additive-combinatorics-and-the-primes/
// Converted to Typst by tao2typ: "2026-10-14T16:35:05.897671+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Milliman Lecture I: Additive combinatorics and the primes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Milliman Lecture I: Additive combinatorics and the primes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 December 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/12/04/milliman-lecture-i-additive-combinatorics-and-the-primes/")[#text("https://terrytao.wordpress.com/2007/12/04/milliman-lecture-i-additive-combinatorics-and-the-primes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This week I am visiting the ")#link("http://www.math.washington.edu/")[#text("University of Washington")]#text(" in Seattle, giving the ")#link("http://www.math.washington.edu/Seminars/milliman_lectures.php")[#text("Milliman Lecture Series")]#text(" for 2007-2008. My chosen theme here is “")#link("http://www.math.washington.edu/Seminars/milliman_0708.php")[#text("Recent developments in arithmetic combinatorics")]#text("“. In my first lecture, I will speak (once again) on how methods in additive combinatorics have allowed us to detect additive patterns in the prime numbers, in particular discussing my joint work with ")#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(". In the second lecture I will discuss how additive combinatorics has made it possible to study the invertibility and spectral behaviour of random discrete matrices, in particular discussing my joint work with ")#link("http://www.math.rutgers.edu/~vanvu/")[#text("Van Vu")]#text("; and in the third lecture I will discuss how sum-product estimates have recently led to progress in the theory of expanders relating to Lie groups, as well as to sieving over orbits of such groups, in particular presenting work of Jean Bourgain and his coauthors.")

#metadata(none) <tao-eb5ba9c568c3a3377fe4>#emph[#text("Additive combinatorics")]#text(" is focused, among other things, on the task of studying additive patterns in general sets of integers (or more generally, sets in an additive group). It is descended in part from the more classical subject of ")#emph[#text("additive number theory")]#text(": the study of additive patterns, structures, and operations on explicit sets of integers, such as the primes ")#mi("{\\mathcal P} := \\{2,3,5,7,11,\\ldots\\}")#text(" and the squares ")#mi("{\\mathcal S} := \\{0,1,4,9,16,\\ldots\\}")#text(". Here are some typical results and conjectures in the subject for both the primes and the squares, side by side for comparison:")

#table(columns: 2, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Squares ")#mi("{\\mathcal S}")],
table.cell(colspan: 1, rowspan: 1)[#text("Primes ")#mi("{\\mathcal P}")],
table.cell(colspan: 1, rowspan: 1)[#link("http://en.wikipedia.org/wiki/Lagrange's_four-square_theorem")[#text("Lagrange’s four square theorem")]#text(": For every positive integer N, there exists a pattern in ")#mi("{\\mathcal S}")#text(" of the form ")#mi("a,b,c, N-a-b-c")#text(".")],
table.cell(colspan: 1, rowspan: 1)[#link("http://en.wikipedia.org/wiki/Vinogradov%27s_theorem")[#text("Vinogradov’s theorem")]#text(": For every sufficiently large integer N, there exists a pattern in ")#mi("{\\mathcal P}")#text(" of the form ")#mi("a, b, c, N-a-b-c")#text(".")],
table.cell(colspan: 1, rowspan: 1)[#link("http://en.wikipedia.org/wiki/Fermat's_theorem_on_sums_of_two_squares")[#text("Fermat’s two square theorem")]#text(": For every prime number ")#mi("N = 1 \\text{ mod } 4")#text(", there exists a pattern in ")#mi("{\\mathcal S}")#text(" of the form ")#mi("a, N-a")#text(".")],
table.cell(colspan: 1, rowspan: 1)[#link("http://en.wikipedia.org/wiki/Goldbach's_conjecture")[#text("Even Goldbach conjecture")]#text(": For every even number ")#mi("N \\geq 4")#text(", there exists a pattern in ")#mi("{\\mathcal P}")#text(" of the form ")#mi("a, N-a")#text(".")],
table.cell(colspan: 1, rowspan: 1)[#text("Fermat’s four square theorem: There does not exist any pattern in ")#mi("{\\mathcal S}")#text(" of the form ")#mi("a, a+b, a+2b, a+3b")#text(" with ")#mi("b \\neq 0")#text(".")],
table.cell(colspan: 1, rowspan: 1)[#link("http://en.wikipedia.org/wiki/Green-Tao_theorem")[#text("Green-Tao theorem")]#text(": For any ")#mi("k \\geq 1")#text(", there exist infinitely many patterns in ")#mi("{\\mathcal P}")#text(" of the form ")#mi("a, a+b,\\ldots,a+(k-1)b")#text(" with ")#mi("b \\neq 0")#text(".")],
table.cell(colspan: 1, rowspan: 1)[#link("http://en.wikipedia.org/wiki/Pell's_equation")[#text("Pell’s equation")]#text(": There are infinitely many patterns in ")#mi("{\\mathcal S}")#text(" of the form ")#mi("a, 2a+1")#text(".")],
table.cell(colspan: 1, rowspan: 1)[#link("http://en.wikipedia.org/wiki/Sophie_Germain_prime")[#text("Sophie Germain conjecture")]#text(": There are infinitely many patterns in ")#mi("{\\mathcal P}")#text(" of the form ")#mi("a, 2a+1")#text(".")]
)

#text("I have deliberately phrased the above results in a unified format, namely that of counting additive patterns with one or more free parameters ")#mi("a, b, \\ldots")#text(" in either the squares or the primes. However, this apparent unification is actually an illusion: the results involving square numbers are much older (the Pell equation solutions, for instance, was essentially known to ")#link("http://en.wikipedia.org/wiki/Diophantus")[#text("Diophantus")]#text(", as well as the ancient Indians) and are proven using completely different methods than for the prime numbers. For the square numbers, there are some key algebraic identities and connections, ranging from the high-school factorisations ")#mi("a^2-b^2 = (a-b)(a+b)")#text(", ")#mi("a^2 - 2b^2 = (a-\\sqrt{2}b)(a+\\sqrt{2}b)")#text(" and ")#mi("a^2+b^2 = (a-ib)(a+ib)")#text(" to deeper connections between quadratic forms and elliptic curves, which allow one to prove the results on the left-hand column via the methods of algebraic number theory. For the primes, on the other hand, there are very few usable algebraic properties available: one has ")#emph[#text("local")]#text(" (mod q) information, such as the fact that all primes are odd (with one exception), or adjacent to a multiple of 6 (with two exceptions), but there are essentially no ")#emph[#text("global")]#text(" algebraic identities or structures to exploit amongst the primes (except, perhaps, for the identities such as the ")#link("http://en.wikipedia.org/wiki/Riemann_zeta_function#Euler_product_formula")[#text("Euler product formula")]#text(" ")#mi("\\zeta(s) = \\prod_p (1 - p^{-s})^{-1}")#text(" connecting the prime numbers to the ")#link("http://en.wikipedia.org/wiki/Riemann_zeta_function")[#text("Riemann zeta function")]#text(" and its relatives, although this only directly helps one count ")#emph[#text("multiplicative")]#text(" patterns in the primes rather than additive ones). So, whereas the square numbers can be profitably studied by cleverly exploiting their special algebraic structure, when dealing with the prime numbers it is in fact better to rely instead on more general tools which require very little structural control on the set being studied. In particular, in recent years we have learned that the methods of ")#emph[#text("additive combinatorics")]#text(", which offers tools to count additive patterns in ")#emph[#text("arbitrary")]#text(" sets of integers (or more generally, subsets of an additive group), can be remarkably effective in additive prime number theory. Thus – rather counter-intuitively – some of our strongest results about additive patterns in primes have been obtained by using very little information about the primes at all!")

#text("To give a very simple example of how additive combinatorics can be applied to the primes, let us consider the problem of finding ")#emph[#text("parallelograms")]#text(" inside the primes – patterns of the form ")#mi("a, a+b, a+c, a+b+c")#text(" with ")#mi("b, c")#text(" positive integers; for instance, 3, 7, 43, 47 is a parallelogram of primes. It is very hard to produce any parallelograms of primes by algebraic means (such as an explicit formula); however, there is a simple combinatorial argument that shows that such parallelograms exist in abundance. The only actual information needed about the primes for this argument is the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(", which says that the number of primes less than a large number N is equal to ")#mi("(1+o(1)) N/\\log N")#text(" in the limit ")#mi("N \\to\\infty")#text(". (Actually, we won’t even need the full strength of the prime number theorem; the weaker statement that there are ")#mi("\\gg N/\\log N")#text(" primes less than N which was known to Chebyshev and can be established by elementary means based on the prime factorisation of ")#mi("\\binom{2N}{N}")#text(", will suffice.)")

#text("Let N be a large number, then there are ")#mi("(1+o(1)) N/\\log N")#text(" primes less than N. This allows us to form roughly ")#mi("(\\frac{1}{2}+o(1)) N^2/\\log^2 N")#text(" differences ")#mi("p-q")#text(" of primes ")#mi("1 < q < p \\leq N")#text(". But each of these differences takes values between 1 and N. For N large enough, we can thus use the ")#link("http://en.wikipedia.org/wiki/Pigeonhole_principle")[#text("pigeonhole principle")]#text(" to conclude that there are two differences ")#mi("p-q")#text(" and ")#mi("p^{\\prime}-q^{\\prime}")#text(" of primes which have the same value, which implies that the quadruplet ")#mi("p, q, q^{\\prime}, p^{\\prime}")#text(" forms a parallelogram. In fact, a slight refinement this argument (using the ")#link("http://en.wikipedia.org/wiki/Cauchy-Schwarz")[#text("Cauchy-Schwarz inequality")]#text(", which can provide a more quantitative version of the pigeonhole principle) shows that there are ")#mi("\\gg N^3 / \\log^4 N")#text(" parallelograms of primes less than N, and in particular that there are infinitely many parallelograms of primes.")

#text("The above example shows how one can detect additive patterns in the primes using very little information about the primes themselves; in the above case, the only information we actually needed about the primes was about their cardinality. (Indeed, the argument is not really about primes at all, and is best viewed as a general statement about dense sets of integers, known as the ")#emph[#text("Szemerédi cube lemma")]#text(".) More generally, the strategy of the additive combinatorial approach is to minimise the number of facts one actually needs to establish about the primes, and rely primarily on tools which are valid for rather general classes of sets of integers.")

#text("A good example of this type of tool is ")#link("http://www.scholarpedia.org/article/Szemer%C3%A9di's_Theorem")[#text("Szemerédi’s theorem")]#text(", which asserts any set of integers A of positive density contains arbitrarily long arithmetic progressions; as with the case of parallelograms, the only information needed about the set is that it is large. This theorem does not directly apply to the prime numbers ")#mi("{\\mathcal P}")#text(", as they have density zero, but it turns out that there is a trick (which Ben Green and I call the ")#emph[#text("transference principle")]#text(") which (very roughly speaking) lets one locate a dense set of integers A which “models” the primes, in the sense that there is a relationship between additive patterns in A and additive patterns in ")#mi("{\\mathcal P}")#text(". (The relationship here is somewhat analogous to ")#link("http://en.wikipedia.org/wiki/Monte_Carlo_integration")[#text("Monte Carlo integration")]#text(", which uses the average value of a function f on a sparse set to approximate the average value of f on a much larger domain.) As a consequence of this principle, Ben and I were able to use Szemerédi’s theorem to establish that the primes contained arbitrarily long arithmetic progressions. There have since been a number of similar results in which Szemerédi-type results for dense sets of integers have been transferred to yield similar statements about the primes and related sets (e.g. ")#link("http://front.math.ucdavis.edu/math.CO/0501314")[#text("constellations in Gaussian primes")]#text(", or ")#link("http://arxiv.org/abs/math.NT/0610050")[#text("polynomial patterns in the ordinary primes")]#text(").")

#text("In this talk, though, I am not going to discuss the above results further, but instead focus on the task of using additive combinatorics to detect more general classes of additive patterns in sets of integers such as the primes, with the philosophy of always trying to use as little structural information about these sets as possible.")

#text("To illustrate some of the ideas, let us consider the ")#link("http://en.wikipedia.org/wiki/Goldbach%27s_weak_conjecture")[#text("odd Goldbach conjecture")]#text(", which asserts that any odd integer larger than 5 can be expressed as the sum of three primes. Let’s first tackle a model problem in the same spirit: we’ll work in a cyclic group ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(" instead of the integers, we will pick three sets A, B, C in this group as well as an element x, and we will ask whether x can be expressed as the sum of an element a from A, an element b from B, and an element c from C.")

#text("Of course, to make any headway on this problem we have to make some assumptions on A, B, C. Let us first assume that A, B, C are relatively dense subsets of ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(", say ")#tao-math("\\left|A\\right|, \\left|B\\right|, \\left|C\\right| \\geq \\frac{1}{10} N", block: false)#text(". Even with such large sets, there is no guarantee that every element x can be expressed as a sum of elements from A, B, and C respectively. For instance, if ")#mi("A=B=C = \\{1,\\ldots,\\lfloor N/10\\rfloor+1\\}")#text(", we see that only about 30% of the numbers in ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(" can be expressed in this way. Or, if N is a multiple of 10 and ")#mi("A=B=C=\\{10,20,30,\\ldots\\}")#text(" consist of those elements in ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(" which are multiples of 10, then only 10% of the elements in ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(" can be expressed in this fashion. Thus there are some non-trivial obstructions to this Goldbach-type problem.")

#text("However, it turns out that if one of the sets, say A, is sufficiently “uniform” or “pseudorandom”, then one can always solve this Goldbach-type problem, regardless of what the other two sets are. This type of fact is often established by Fourier-analytic means (or by closely related techniques, such as spectral theory), but let me give a heuristic combinatorial argument to indicate why one would expect this type of phenomenon to occur. We will work in the contrapositive: we assume that we can find an x which cannot be expressed as the sum of elements from A, B, and C, and somehow eliminate the role of x, B, and C to to deduce some “non-uniformity” or “structure” for A.")

#text("So, suppose that ")#mi("x \\neq a+b+c")#text(" for all a in A, b in B, c in C. This implies that x-a-b always avoids C. Thus x-a-b does not range freely throughout ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(", but is instead concentrated in a set of 90% the size or smaller. Because of this more confined space, one would expect more “collisions” than usual, in the sense that there should be more solutions to the equation ")#mi("x-a-b = x-a^{\\prime}-b^{\\prime}")#text(" with a,a’ in A and b,b’ in B than one would normally expect. Rearranging, we conclude that there are more solutions to the equation ")#mi("a-a^{\\prime} = b-b^{\\prime}")#text(" than one might first expect. This means that the differences a-a’ and the differences b-b’ have to cluster in the same region of ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(", which then suggests that we should have more collisions ")#mi("a-a^{\\prime} = a^{\\prime\\prime}-a^{\\prime\\prime\\prime}")#text(" with a,a’,a”,a” in A than one might first expect. To put it another way, A should contain a higher than expected number of parallelograms ")#mi("a, a+r, a+s, a+r+s")#text(".")

#text("The above argument can be made rigorous by two quick applications of the Cauchy-Schwarz inequality. If we had ")#tao-math("\\left|A\\right|, \\left|B\\right|, \\left|C\\right|\\geq \\delta N", block: false)#text(" for some ")#mi("\\delta > 0")#text(", say, then it is not hard to use Cauchy-Schwarz to show that A will contain at least ")#mi("\\delta^4 N^3")#text(" parallelograms (where we allow degenerate parallelograms, in order to simplify the formulae a little); but if there existed an x which was not the sum of an element from A, an element from B, and an element of C, one can use this to conclude that A must have a few more parallelograms, in fact it must have at least ")#mi("(1+c\\delta) \\delta^4 N^3")#text(" for some absolute constant ")#mi("c > 0")#text(".")

#text("Taking contrapositives, we conclude that if A has a near-minimal number of parallelograms (between ")#mi("\\delta^4 N^3")#text(" and ")#mi("(1+c\\delta) \\delta^4 N^3")#text("), then we can solve the Goldbach problem for any x and any choice of sets B, C of density ")#mi("\\delta")#text(".")

#text("So, by using elementary additive combinatorics, we can reduce Goldbach-type problems to the problem of counting parallelograms in a given set A. But how can one achieve the latter task? It turns out that for this specific problem, there is an elegant formula from Fourier analysis: the number of parallelograms in a set ")#mi("A \\subset {\\Bbb Z}/N{\\Bbb Z}")#text(" is equal to")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("N^3 \\sum_{\\xi \\in {\\Bbb Z}/N{\\Bbb Z}} \\left|\\hat 1_A(\\xi)\\right|^4", block: true)]]

#text("where ")#mi("\\hat 1_A(\\xi)")#text(" is the Fourier coefficient of the indicator function ")#mi("1_A")#text(" at frequency ")#mi("\\xi")#text(":")

#align(center)[#tao-fit-display[#mitex("\\hat 1_A(\\xi) := \\frac{1}{N} \\sum_{x \\in A} e^{-2\\pi i x \\xi/N}.")]]

#text("The connection between Fourier analysis and parallelograms ")#mi("a, a+r, a+s, a+r+s")#text(" might not be immediately evident, but a link between the two can be discerned from the algebraic identity")

#align(center)[#tao-fit-display[#mitex("e^{-2\\pi i a \\xi / N} e^{2\\pi i (a+r) \\xi/N} e^{2\\pi i (a+s)\\xi/N} e^{-2\\pi i (a+r+s)\\xi/N} = 1")]]

#text("which is a fancy way of saying that the linear function ")#mi("x \\mapsto x \\xi / N \\text{ mod } 1")#text(" has a vanishing second derivative.")

#text("Anyway, returning to the formula (1), in the case when A has density exactly ")#mi("\\delta")#text(", thus ")#tao-math("\\left|A\\right|=\\delta N", block: false)#text(", we see that the number of parallelograms is equal to")

#align(center)[#tao-math("(\\delta^4 + \\sum_{\\xi \\neq 0} \\left|\\hat 1_A(\\xi)\\right|^4) N^3", block: false)#text(".")]

#text("Thus we see (informally, at least) that a set A is going to have near-minimal number of parallelograms precisely when it is ")#emph[#text("Fourier-pseudorandom")]#text(" in the sense that its Fourier coefficients at non-zero frequencies are all small, or in other words that the set ")#mi("A")#text(" exhibits no correlation or bias with respect to any non-trivial linear phase function ")#mi("x \\mapsto e^{2\\pi i x \\xi/N}")#text(". (It is instructive to consider our two counterexamples to the toy Goldbach problem, namely ")#mi("A = \\{1,\\ldots,\\lfloor N/10\\rfloor +1\\}")#text(" and ")#mi("A = \\{10,20,30,\\ldots\\}")#text(". The first set is biased with respect to the phase ")#mi("x \\mapsto e^{2\\pi i x/N}")#text("; the second set is biased with respect to ")#mi("x \\mapsto e^{2\\pi i x/10}")#text(".)")

#text("This gives us a strategy to solve Goldbach-type problems: if we can show somehow that a set A does not correlate strongly with any non-trivial linear phase function, then it should be sufficiently Fourier pseudorandom that there is no further obstruction to the Goldbach problem. If instead A does closely resemble something related to a non-trivial linear phase function, then that is quite a bit of structural information on A and that we should be able to solve the Goldbach type problem by explicit algebraic counting of solutions (as is for instance the case in the two model examples ")#mi("A = \\{1,2,\\ldots,\\lfloor N/10\\rfloor+1\\}")#text(" and ")#mi("A = \\{10,20,30,\\ldots\\}")#text(" discussed earlier).")

#text("In the case of sets of integers such as the primes, this type of strategy is known as the ")#emph[#text("Hardy-Littlewood circle method")]#text(". It was successfully used by Vinogradov to establish his theorem that every sufficiently large odd number is the sum of three primes (and thus every sufficiently large number is the sum of four primes); the problem boils down to getting sufficiently strong estimates for exponential sums over primes such as ")#mi("\\sum_{p < N} e^{2\\pi i \\alpha p}")#text(". In the “major arc” case where ")#mi("\\alpha")#text(" is rational (or very close to rational) with small denominator then methods from multiplicative number theory, based on zeta functions and L-functions, become useful; in contrast, in the complementary “minor arc” case where ")#mi("\\alpha")#text(" behaves irrationally, one can use more analytic methods (based, ultimately, on the equidistribution of multiples of ")#mi("\\alpha")#text(" modulo 1 on the unit circle, and on the obvious fact that the product of two primes is a non-prime) to obtain good estimates. (I hope to discuss this in more detail in a later post.) A similar argument was used by van der Corput to establish that the prime numbers contained arbitrarily many arithmetic progressions of length three. These arguments are actually quite quantitative and precise; for instance, Vinogradov’s theorem not only gives the existence of a representation ")#mi("N = p_1 + p_2 + p_3")#text(" of any sufficiently large odd number as the sum of three primes, but in fact gives an asymptotically precise formula as ")#mi("N \\to \\infty")#text(" as to how many such representations exist. Similarly, van der Corput’s argument gives an asymptotically precise formula as to how many arithmetic progressions of length three consisting of primes less than N there are, as ")#mi("N \\to \\infty")#text(".")

#text("This strategy unfortunately fails miserably for the even Goldbach problem, which asks whether every even number greater than 2 is the sum of two primes; it turns out that there is no useful analogue of the parallelogram in this problem, basically due to the fact that there is only one free parameter in the pattern one is looking for. However, it is possible to adapt the strategy to more complicated patterns with two or more free parameters, such as arithmetic progressions of length greater than three. For instance, if one wants to find arithmetic progressions of length 4 in a set A, it turns out that this problem is controlled by the number of ")#emph[#text("parallelopipeds ")]

#align(center)[#tao-fit-display[#mitex("a, a+r, a+s, a+t, a+r+s, a+r+t,a+s+t,a+r+s+t")]]

#text("that A contains, in much the same way that the odd Goldbach problem was controlled by parallelograms. So, if one knows how to count how many parallelopipeds there are in a set, one can (in principle) count how many progressions of length 4 there are as well (and one can also count a large variety of other patterns too). One would then hope for an elegant formula analogous to (1) to count these objects, but unfortunately it seems that no such formula exists. Part of the problem is that while parallelograms are closely tied to the linear (or Fourier) phases ")#mi("x \\mapsto x \\xi / N")#text(", because such phases have vanishing second derivative, parallelopipeds are more naturally tied to the larger class of phases which have vanishing third derivative, such as the quadratic phases ")#mi("x \\mapsto x^2 \\xi / N")#text(". (Actually, there are also many more “pseudoquadratic” phases, such as ")#mi("x \\mapsto \\lfloor \\alpha x \\rfloor \\beta x")#text(" for various real numbers ")#mi("\\alpha,\\beta")#text(", whose third derivative exhibits some cancellation but does not vanish entirely, and are connected to flows on nilmanifolds, but I will not discuss them in detail here.) With this much larger class of potentially relevant phases, it appears that there is no useful analogue of the formula (1) (basically because there are so many such phases out there, most of which having no significant correlation with the set A, that the noise from these irrelevant phases drowns out the signal from those few phases that are actually important). Nevertheless, there are a set of tools, developed initially by Timothy Gowers, in what might loosely be called ")#emph[#text("quadratic Fourier analysis")]#text(", which can make precise the connection between parallelopipeds and correlations with quadratic (or pseudoquadratic) phases; there is also the beginnings of a more general theory connecting higher dimensional parallelopipeds and higher degree phases. This is still work in progress, but we have already been able to use the theory to understand several types of linear patterns already; for instance, Ben and I showed that the number of arithmetic progressions of length four consisting of primes less than a given large number N is equal to")

#align(center)[#tao-fit-display[#mitex("(\\frac{3}{4} \\prod_{p\\geq 5}(1 - \\frac{3p-1}{(p-1)^3} + o(1)) \\frac{N^2}{\\log^4 N} \\approx 0.4764 \\frac{N^2}{\\log^4 N}.")]]

#text("Very briefly, the role of additive combinatorics (and generalised Fourier analysis) is to replace problems of counting patterns involving multiple prime parameters, with that of counting correlations that involve a single prime parameter (e.g. computing a sum ")#mi("\\sum_{p < N} e^{2\\pi i \\alpha p^2}")#text(" for various real numbers ")#mi("\\alpha")#text("), which is significantly easier (though not entirely trivial) and amenable to a current technology from analytic number theory. So we don’t dispense with the number theory entirely, but thanks to combinatorics we can reduce the amount of difficult number theoretical work that we have to do to a feasible level.")

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2f8227a846b36e3e309bf24cf32c945871ca072445ad29d145457e6656bff2b-ca21191d89242f09621f597bdb4eacf9d9f2f92a71e86a08c5d40967c298da18.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ninguem")]], [#link("https://terrytao.wordpress.com/2007/12/04/milliman-lecture-i-additive-combinatorics-and-the-primes/#comment-19046")[#strong[#text("ninguem")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2007")])]

#text("Lagrange’s theorem, in your box, was inadvertently stated with three squares only.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of error74")]], [#link("https://terrytao.wordpress.com/2007/12/04/milliman-lecture-i-additive-combinatorics-and-the-primes/#comment-19047")[#strong[#text("error74")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2007")])]

#text("Dear Terry,")#linebreak()#text(" It looks like a similarly looking combinatoric pattern was detected")#linebreak()#text(" some time ago in discrete variational thermodynamics. Traveling")#linebreak()#text(" waves in a noncubic lattice are well posed only if support of the")#linebreak()#text(" interaction kernel contains two relatively prime numbers. AC")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/12/04/milliman-lecture-i-additive-combinatorics-and-the-primes/#comment-19071")[#strong[#text("Pseudo-Polymath » Blog Archive » Wednesday Highlights")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2007")]

#text("[…] Arithmetic. Not just for the primary school age. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/932ed592f893eef3bc636a8f4beb1296a0e591646747b9b56c21c30da01c6440-328e45c09d3dd1e43bcff04745a90e7031cd3f2c8e9e5a53a55855f03a975551.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Richter")]], [#link("https://terrytao.wordpress.com/2007/12/04/milliman-lecture-i-additive-combinatorics-and-the-primes/#comment-19111")[#strong[#text("Johan Richter")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2007")])]

#text("ninguem, the fourth square is N-a-b-c.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d67543d378b8c6cfb59d4861227bf722aa662275fd15d0b209da4feabac117b7-3f6416f339765bd83897fdb9ed59f500c2831ef2a321efa93ad1a92af2d178f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Julian")]], [#link("https://terrytao.wordpress.com/2007/12/04/milliman-lecture-i-additive-combinatorics-and-the-primes/#comment-19116")[#strong[#text("Julian")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2007")])]

#text("Really enjoyed your talk yesterday (Tuesday). Though I’m not a traditional “math” guy (grad student in Biostatistics with an undergrad degree in Math/CS), I felt that I was still able to follow most of the lecture and get something out of it. Kudos!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbf445dd3ded972a5d1b62126dac2900bf47db6c85c39b95626f92b945e4f092-821d2a67ec2aa6fd2150e7112d80a9cf9bad4da7b90b8dab1f324d9a6a89f5c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2007/12/04/milliman-lecture-i-additive-combinatorics-and-the-primes/#comment-19213")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2007")])]

#text("There are several sequences appropriate for the Online Encyclopedia of Integer Sequences lurking in Terry Tao’s Milliman Lecture I: Additive combinatorics and the primes")#linebreak()#text(" One comes from his example:")

#text("“To give a very simple example of how additive combinatorics can be applied to the primes, let us consider the problem of finding parallelograms inside the primes – patterns of the form a, a+b, a+c, a+b+c with b, c positive integers; for instance, 3, 7, 43, 47 is a parallelogram of primes. It is very hard to produce any parallelograms of primes by algebraic means (such as an explicit formula); however, there is a simple combinatorial argument that shows that such")#linebreak()#text(" parallelograms exist in abundance. The only actual information needed")#linebreak()#text(" about the primes for this argument is the prime number theorem, which")#linebreak()#text(" says that the number of primes less than a large number N is equal to")#linebreak()#text(" (1+o(1)) N/\\log N in the limit N \\to\\infty. (Actually, we won’t even")#linebreak()#text(" need the full strength of the prime number theorem; the weaker")#linebreak()#text(" statement that there are \\gg N/\\log N primes less than N which was")#linebreak()#text(" known to Chebyshev and can be established by elementary means based on")#linebreak()#text(" the prime factorisation of \\binom{2N}{N}, will suffice.)…”")

#text("Suppose we generate the infinite number of triples (a,b,c) such that a, a+b, a+c, a+b+c are all prime. Sort them on n=a+b+c, and lexicographically on a, b.")

#text("Now, if we have n=prime(k), we enumerate a(k) = how many triples there are for n=prime(k).")

#text("I did this first try entirely by hand, while waiting for my son’s car to be smog checked, so it needs to be checked.")

#text("for k = 6, 7, 8, 9, … I get a(k) = 1,2,4,5,4,7,6,… and a table that begins:")#linebreak()#text(" a b c a+b a+c a+b+c")#linebreak()#text(" 3 2 8 5 11 13")#linebreak()#text(" 3 4 10 7 13 17")#linebreak()#text(" 7 4 6 11 13 17")#linebreak()#text(" 3 2 14 5 17 19")#linebreak()#text(" 5 2 12 7 17 19")#linebreak()#text(" 5 6 8 11 13 19")#linebreak()#text(" 11 2 6 13 17 19")#linebreak()#text(" 3 4 16 7 19 23")#linebreak()#text(" 5 6 12 11 17 23")#linebreak()#text(" 7 4 12 11 19 23")#linebreak()#text(" 7 6 10 13 17 23")#linebreak()#text(" 13 4 6 17 19 23")#linebreak()#text(" 5 6 18 11 23 29")#linebreak()#text(" 7 6 16 13 23 29")#linebreak()#text(" 7 10 12 17 19 29")#linebreak()#text(" 11 6 12 17 23 29")#linebreak()#text(" 3 2 26 5 29 31")#linebreak()#text(" 3 8 20 11 23 31")#linebreak()#text(" 5 2 24 7 29 31")#linebreak()#text(" 5 8 18 13 23 31")#linebreak()#text(" 11 2 18 13 29 31")#linebreak()#text(" 11 8 12 19 23 31")#linebreak()#text(" 17 2 12 19 29 31")#linebreak()#text(" 3 8 26 11 29 37")#linebreak()#text(" 5 6 26 11 31 37")#linebreak()#text(" 5 8 24 13 29 37")#linebreak()#text(" 7 6 24 13 31 37")#linebreak()#text(" 11 6 20 17 31 37")#linebreak()#text(" 11 8 18 19 29 37")

#text("Ofr course, Terry Tao’s asymptotics and methods and big picture context are the whole point, but I’d love to see this table corrected and extended, and the sequence I’ve identified, to get the ball rolling.")

#text("Happy Hanukkah,")

#text("Jonathan Vos Post")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2f8227a846b36e3e309bf24cf32c945871ca072445ad29d145457e6656bff2b-ca21191d89242f09621f597bdb4eacf9d9f2f92a71e86a08c5d40967c298da18.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ninguem")]], [#link("https://terrytao.wordpress.com/2007/12/04/milliman-lecture-i-additive-combinatorics-and-the-primes/#comment-19270")[#strong[#text("ninguem")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2007")])]

#text("Thanks, Johan. I was tripped by the unusual formulation of Vinogradov’s three primes theorem. I guess Terry is trying to say that given an integer N sufficiently large either N-2 or N-3 is a sum of three odd primes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AMS lecture: Structure and randomness in the prime numbers « What’s new")]], [#link("https://terrytao.wordpress.com/2007/12/04/milliman-lecture-i-additive-combinatorics-and-the-primes/#comment-23460")[#strong[#text("AMS lecture: Structure and randomness in the prime numbers « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2008")])]

#text("[…] numbers“. Of course, I’ve talked about this general topic many times before, (e.g. at my Simons lecture at MIT, my Milliman lecture at U. Washington, and my Science Research Colloquium at UCLA), and I have […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/12/04/milliman-lecture-i-additive-combinatorics-and-the-primes/#comment-39105")[#strong[#text("Structure and Randomness: Pages from Year One of a Mathematical Blog « Abner’s Postgraduate Days")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2009")]

#text("[…] Milliman Lecture I: Additive combinatorics and the primes […]")
]
