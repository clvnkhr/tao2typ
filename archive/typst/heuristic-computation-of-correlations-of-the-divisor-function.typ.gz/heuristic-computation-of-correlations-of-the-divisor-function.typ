// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/08/30/heuristic-computation-of-correlations-of-the-divisor-function/
// Converted to Typst by tao2typ: "2026-10-14T10:35:59.169032+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Heuristic computation of correlations of the divisor function", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Heuristic computation of correlations of the divisor function")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 August 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/08/30/heuristic-computation-of-correlations-of-the-divisor-function/")[#text("https://terrytao.wordpress.com/2016/08/30/heuristic-computation-of-correlations-of-the-divisor-function/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{\\tau(n) := \\sum_{d|n} 1}")#text(" be the ")#link("https://en.wikipedia.org/wiki/Divisor_function")[#text("divisor function")]#text(". A classical application of the Dirichlet hyperbola method gives the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\tau(n) \\sim x \\log x")]]

#text("where ")#mi("{X \\sim Y}")#text(" denotes the estimate ")#mi("{X = (1+o(1))Y}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(". Much better error estimates are possible here, but we will not focus on the lower order terms in this discussion. For somewhat idiosyncratic reasons I will interpret this estimate (and the other analytic number theory estimates discussed here) through the probabilistic lens. Namely, if ")#mi("{{\\bf n} = {\\bf n}_x}")#text(" is a random number selected uniformly between ")#mi("{1}")#text(" and ")#mi("{x}")#text(", then the above estimate can be written as ")#metadata(none) <tao-e40d16db6ea0c7b0cca1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("{\\bf E} \\tau( {\\bf n} ) \\sim \\log x,")]]



#text(" that is to say the random variable ")#mi("{\\tau({\\bf n})}")#text(" has mean approximately ")#mi("{\\log x}")#text(". (But, somewhat paradoxically, this is not the median or mode behaviour of this random variable, which instead concentrates near ")#mi("{\\log^{\\log 2} x}")#text(", basically thanks to the ")#link("https://en.wikipedia.org/wiki/Hardy%E2%80%93Ramanujan_theorem")[#text("Hardy-Ramanujan theorem")]#text(".)")

#text("Now we turn to the pair correlations ")#mi("{\\sum_{n \\leq x} \\tau(n) \\tau(n+h)}")#text(" for a fixed positive integer ")#mi("{h}")#text(". There is a classical ")#link("http://www.ams.org/mathscinet-getitem?mr=1574426")[#text("computation of Ingham")]#text(" that shows that ")#metadata(none) <tao-0e07cf830957701d43c1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{n \\leq x} \\tau(n) \\tau(n+h) \\sim \\frac{6}{\\pi^2} \\sigma_{-1}(h) x \\log^2 x,")]]



#text(" where")

#align(center)[#tao-fit-display[#mitex("\\sigma_{-1}(h) := \\sum_{d|h} \\frac{1}{d}.")]]

#text("The error term in ")#link(<tao-0e07cf830957701d43c1>)[#text("(2)")]#text(" has been refined by many subsequent authors, as has the uniformity of the estimates in the ")#mi("{h}")#text(" aspect, as these topics are related to other questions in analytic number theory, such as fourth moment estimates for the Riemann zeta function; but we will not consider these more subtle features of the estimate here. However, we will look at the next term in the asymptotic expansion for ")#link(<tao-0e07cf830957701d43c1>)[#text("(2)")]#text(" below the fold.")

#text("Using our probabilistic lens, the estimate ")#link(<tao-0e07cf830957701d43c1>)[#text("(2)")]#text(" can be written as ")#metadata(none) <tao-f9b7e0c39aaeffb56e35>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("{\\bf E} \\tau( {\\bf n} ) \\tau( {\\bf n} + h ) \\sim \\frac{6}{\\pi^2} \\sigma_{-1}(h) \\log^2 x.")]]



#text(" From ")#link(<tao-e40d16db6ea0c7b0cca1>)[#text("(1)")]#text(" (and the asymptotic negligibility of the shift by ")#mi("{h}")#text(") we see that the random variables ")#mi("{\\tau({\\bf n})}")#text(" and ")#mi("{\\tau({\\bf n}+h)}")#text(" both have a mean of ")#mi("{\\sim \\log x}")#text(", so the additional factor of ")#mi("{\\frac{6}{\\pi^2} \\sigma_{-1}(h)}")#text(" represents some arithmetic coupling between the two random variables.")

#text("Ingham’s formula can be established in a number of ways. Firstly, one can expand out ")#mi("{\\tau(n) = \\sum_{d|n} 1}")#text(" and use the hyperbola method (splitting into the cases ")#mi("{d \\leq \\sqrt{x}}")#text(" and ")#mi("{n/d \\leq \\sqrt{x}}")#text(" and removing the overlap). If one does so, one soon arrives at the task of having to estimate sums of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x: d|n} \\tau(n+h)")]]

#text("for various ")#mi("{d \\leq \\sqrt{x}}")#text(". For ")#mi("{d}")#text(" much less than ")#mi("{\\sqrt{x}}")#text(" this can be achieved using a further application of the hyperbola method, but for ")#mi("{d}")#text(" comparable to ")#mi("{\\sqrt{x}}")#text(" things get a bit more complicated, necessitating the use of non-trivial estimates on ")#link("https://en.wikipedia.org/wiki/Kloosterman_sum")[#text("Kloosterman sums")]#text(" in order to obtain satisfactory control on error terms. A more modern approach proceeds using automorphic form methods, as discussed in ")#link("https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/")[#text("this previous post")]#text(". A third approach, which unfortunately is only heuristic at the current level of technology, is to apply the ")#link("https://en.wikipedia.org/wiki/Hardy%E2%80%93Littlewood_circle_method")[#text("Hardy-Littlewood circle method")]#text(" (discussed in ")#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/")[#text("this previous post")]#text(") to express ")#link(<tao-0e07cf830957701d43c1>)[#text("(2)")]#text(" in terms of exponential sums ")#mi("{\\sum_{n \\leq x} \\tau(n) e(\\alpha n)}")#text(" for various frequencies ")#mi("{\\alpha}")#text(". The contribution of “major arc” ")#mi("{\\alpha}")#text(" can be computed after a moderately lengthy calculation which yields the right-hand side of ")#link(<tao-0e07cf830957701d43c1>)[#text("(2)")]#text(" (as well as the correct lower order terms that are currently being suppressed), but there does not appear to be an easy way to show directly that the “minor arc” contributions are of lower order, although the methods discussed previously do indirectly show that this is ultimately the case.")

#text("Each of the methods outlined above requires a fair amount of calculation, and it is not obvious while performing them that the factor ")#mi("{\\frac{6}{\\pi^2} \\sigma_{-1}(h)}")#text(" will emerge at the end. One can at least explain the ")#mi("{\\frac{6}{\\pi^2}}")#text(" as a normalisation constant needed to balance the ")#mi("{\\sigma_{-1}(h)}")#text(" factor (at a heuristic level, at least). To see this through our probabilistic lens, introduce an independent copy ")#mi("{{\\bf n}^{\\prime}}")#text(" of ")#mi("{{\\bf n}}")#text(", then ")#metadata(none) <tao-aed16835160e0853b06b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("{\\bf E} \\tau( {\\bf n} ) \\tau( {\\bf n}^{\\prime} ) = ({\\bf E} \\tau ({\\bf n}))^2 \\sim \\log^2 x;")]]



#text(" using symmetry to order ")#mi("{{\\bf n}^{\\prime} > {\\bf n}}")#text(" (discarding the diagonal case ")#mi("{{\\bf n} = {\\bf n}^{\\prime}}")#text(") and making the change of variables ")#mi("{{\\bf n}^{\\prime} = {\\bf n}+h}")#text(", we see that ")#link(<tao-aed16835160e0853b06b>)[#text("(4)")]#text(" is heuristically consistent with ")#link(<tao-f9b7e0c39aaeffb56e35>)[#text("(3)")]#text(" as long as the asymptotic mean of ")#mi("{\\frac{6}{\\pi^2} \\sigma_{-1}(h)}")#text(" in ")#mi("{h}")#text(" is equal to ")#mi("{1}")#text(". (This argument is not rigorous because there was an implicit interchange of limits present, but still gives a good heuristic “sanity check” of Ingham’s formula.) Indeed, if ")#mi("{{\\bf E}_h}")#text(" denotes the asymptotic mean in ")#mi("{h}")#text(", then we have (heuristically at least)")

#tao-aligned(keep: true)[


#tao-math("{\\bf E}_h \\sigma_{-1}(h)  & = \\sum_d {\\bf E}_h \\frac{1}{d} 1_{d|h}", block: true)



#tao-math(" & = \\sum_d \\frac{1}{d^2}", block: true)



#tao-math(" & = \\frac{\\pi^2}{6}", block: true)
]

#text("and we obtain the desired consistency after multiplying by ")#mi("{\\frac{6}{\\pi^2}}")#text(".")

#text("This still however does not explain the presence of the ")#mi("{\\sigma_{-1}(h)}")#text(" factor. Intuitively it is reasonable that if ")#mi("{h}")#text(" has many prime factors, and ")#mi("{{\\bf n}}")#text(" has a lot of factors, then ")#mi("{{\\bf n}+h}")#text(" will have slightly more factors than average, because any common factor to ")#mi("{h}")#text(" and ")#mi("{{\\bf n}}")#text(" will automatically be acquired by ")#mi("{{\\bf n}+h}")#text(". But how to quantify this effect?")

#text("One heuristic way to proceed is through analysis of local factors. Observe from the fundamental theorem of arithmetic that we can factor")

#align(center)[#tao-fit-display[#mitex("\\tau(n) = \\prod_p \\tau_p(n)")]]

#text("where the product is over all primes ")#mi("{p}")#text(", and ")#mi("{\\tau_p(n) := \\sum_{p^j|n} 1}")#text(" is the local version of ")#mi("{\\tau(n)}")#text(" at ")#mi("{p}")#text(" (which in this case, is just one plus the ")#mi("{p}")#text("–")#link("https://en.wikipedia.org/wiki/Valuation_(algebra)")[#text("valuation")]#text(" ")#mi("{v_p(n)}")#text(" of ")#mi("{n}")#text(": ")#mi("{\\tau_p = 1 + v_p}")#text("). Note that all but finitely many of the terms in this product will equal ")#mi("{1}")#text(", so the infinite product is well-defined. In a similar fashion, we can factor")

#align(center)[#tao-fit-display[#mitex("\\sigma_{-1}(h) = \\prod_p \\sigma_{-1,p}(h)")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\sigma_{-1,p}(h) := \\sum_{p^j|h} \\frac{1}{p^j}")]]

#text("(or in terms of valuations, ")#mi("{\\sigma_{-1,p}(h) = (1 - p^{-v_p(h)-1})/(1-p^{-1})}")#text("). Heuristically, the Chinese remainder theorem suggests that the various factors ")#mi("{\\tau_p({\\bf n})}")#text(" behave like independent random variables, and so the correlation between ")#mi("{\\tau({\\bf n})}")#text(" and ")#mi("{\\tau({\\bf n}+h)}")#text(" should approximately decouple into the product of correlations between the local factors ")#mi("{\\tau_p({\\bf n})}")#text(" and ")#mi("{\\tau_p({\\bf n}+h)}")#text(". And indeed we do have the following local version of Ingham’s asymptotics:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Local Ingham asymptotics)")]#text(" ")#metadata(none) <tao-3d66f74fd48822744da1>#text(" For fixed ")#mi("{p}")#text(" and integer ")#mi("{h}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\tau_p({\\bf n}) \\sim \\frac{p}{p-1}")]]

#text("and")

#tao-aligned(keep: true)[


#tao-math("{\\bf E} \\tau_p({\\bf n}) \\tau_p({\\bf n}+h)  & \\sim (1-\\frac{1}{p^2}) \\sigma_{-1,p}(h) (\\frac{p}{p-1})^2", block: true)



#tao-math(" & = \\frac{p+1}{p-1} \\sigma_{-1,p}(h)", block: true)
]
]

#text("From the Euler formula")

#align(center)[#tao-fit-display[#mitex("\\prod_p (1-\\frac{1}{p^2}) = \\frac{1}{\\zeta(2)} = \\frac{6}{\\pi^2}")]]

#text("we see that")

#align(center)[#tao-fit-display[#mitex("\\frac{6}{\\pi^2} \\sigma_{-1}(h) = \\prod_p (1-\\frac{1}{p^2}) \\sigma_{-1,p}(h)")]]

#text("and so one can “explain” the arithmetic factor ")#mi("{\\frac{6}{\\pi^2} \\sigma_{-1}(h)}")#text(" in Ingham’s asymptotic as the product of the arithmetic factors ")#mi("{(1-\\frac{1}{p^2}) \\sigma_{-1,p}(h)}")#text(" in the (much easier) local Ingham asymptotics. Unfortunately we have the usual “local-global” problem in that we do not know how to rigorously derive the global asymptotic from the local ones; this problem is essentially the same issue as the problem of controlling the minor arc contributions in the circle method, but phrased in “physical space” language rather than “frequency space”.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The relation between the local means ")#mi("{\\sim \\frac{p}{p-1}}")#text(" and the global mean ")#mi("{\\sim \\log^2 x}")#text(" can also be seen heuristically through the application")

#align(center)[#tao-fit-display[#mitex("\\prod_{p \\leq x^{1/e^\\gamma}} \\frac{p}{p-1} \\sim \\log x")]]

#text("of ")#link("https://en.wikipedia.org/wiki/Mertens%27_theorems")[#text("Mertens’ theorem")]#text(", where ")#mi("{1/e^\\gamma}")#text(" is ")#link("http://www.ams.org/mathscinet-getitem?mr=104639")[#text("Pólya’s magic exponent")]#text(", which serves as a useful heuristic limiting threshold in situations where the product of local factors is divergent.")
]

#text("Let us now prove this proposition. One could brute-force the computations by observing that for any fixed ")#mi("{j}")#text(", the valuation ")#mi("{v_p({\\bf n})}")#text(" is equal to ")#mi("{j}")#text(" with probability ")#mi("{\\sim \\frac{p-1}{p} \\frac{1}{p^j}}")#text(", and with a little more effort one can also compute the joint distribution of ")#mi("{v_p({\\bf n})}")#text(" and ")#mi("{v_p({\\bf n}+h)}")#text(", at which point the proposition reduces to the calculation of various variants of the geometric series. I however find it cleaner to proceed in a more recursive fashion (similar to how one can prove the geometric series formula by induction); this will also make visible the vague intuition mentioned previously about how common factors of ")#mi("{{\\bf n}}")#text(" and ")#mi("{h}")#text(" force ")#mi("{{\\bf n}+h}")#text(" to have a factor also.")

#text("It is first convenient to get rid of error terms by observing that in the limit ")#mi("{x \\rightarrow \\infty}")#text(", the random variable ")#mi("{{\\bf n} = {\\bf n}_x}")#text(" converges ")#link("https://en.wikipedia.org/wiki/Vague_topology")[#text("vaguely")]#text(" to a uniform random variable ")#mi("{{\\bf n}_\\infty}")#text(" on the ")#link("https://en.wikipedia.org/wiki/Profinite_integer")[#text("profinite integers")]#text(" ")#mi("{\\hat {\\bf Z}}")#text(", or more precisely that the pair ")#mi("{(v_p({\\bf n}_x), v_p({\\bf n}_x+h))}")#text(" converges vaguely to ")#mi("{(v_p({\\bf n}_\\infty), v_p({\\bf n}_\\infty+h))}")#text(". Because of this (and because of the easily verified uniform integrability properties of ")#mi("{\\tau_p({\\bf n})}")#text(" and their powers), it suffices to establish the exact formulae ")#metadata(none) <tao-0a7cb27e52927eacabbb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("{\\bf E} \\tau_p({\\bf n}_\\infty) = \\frac{p}{p-1}")]]



#text(" and ")#metadata(none) <tao-055993a9156086898671>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("{\\bf E} \\tau_p({\\bf n}_\\infty) \\tau_p({\\bf n}_\\infty+h) = (1-\\frac{1}{p^2}) \\sigma_{-1,p}(h) (\\frac{p}{p-1})^2 = \\frac{p+1}{p-1} \\sigma_{-1,p}(h)")]]



#text(" in the profinite setting (this setting will make it easier to set up the recursion).")

#text("We begin with ")#link(<tao-0a7cb27e52927eacabbb>)[#text("(5)")]#text(". Observe that ")#mi("{{\\bf n}_\\infty}")#text(" is coprime to ")#mi("{p}")#text(" with probability ")#mi("{\\frac{p-1}{p}}")#text(", in which case ")#mi("{\\tau_p({\\bf n}_\\infty)}")#text(" is equal to ")#mi("{1}")#text(". Conditioning to the complementary probability ")#mi("{\\frac{1}{p}}")#text(" event that ")#mi("{{\\bf n}_\\infty}")#text(" is divisible by ")#mi("{p}")#text(", we can factor ")#mi("{{\\bf n}_\\infty = p {\\bf n}^{\\prime}_\\infty}")#text(" where ")#mi("{{\\bf n}^{\\prime}_\\infty}")#text(" is also uniformly distributed over the profinite integers, in which event we have ")#mi("{\\tau_p( {\\bf n}_\\infty ) = 1 + \\tau_p( {\\bf n}^{\\prime}_\\infty )}")#text(". We arrive at the identity")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\tau_p({\\bf n}_\\infty) = \\frac{p-1}{p} + \\frac{1}{p} ( 1 + {\\bf E} \\tau_p( {\\bf n}^{\\prime}_\\infty ) ).")]]

#text("As ")#mi("{{\\bf n}_\\infty}")#text(" and ")#mi("{{\\bf n}^{\\prime}_\\infty}")#text(" have the same distribution, the quantities ")#mi("{{\\bf E} \\tau_p({\\bf n}_\\infty)}")#text(" and ")#mi("{{\\bf E} \\tau_p({\\bf n}^{\\prime}_\\infty)}")#text(" are equal, and ")#link(<tao-0a7cb27e52927eacabbb>)[#text("(5)")]#text(" follows by a brief amount of high-school algebra.")

#text("We use a similar method to treat ")#link(<tao-055993a9156086898671>)[#text("(6)")]#text(". First treat the case when ")#mi("{h}")#text(" is coprime to ")#mi("{p}")#text(". Then we see that with probability ")#mi("{\\frac{p-2}{p}}")#text(", ")#mi("{{\\bf n}_\\infty}")#text(" and ")#mi("{{\\bf n}_\\infty+h}")#text(" are simultaneously coprime to ")#mi("{p}")#text(", in which case ")#mi("{\\tau_p({\\bf n}_\\infty) = \\tau_p({\\bf n}_\\infty+h) = 1}")#text(". Furthermore, with probability ")#mi("{\\frac{1}{p}}")#text(", ")#mi("{{\\bf n}_\\infty}")#text(" is divisible by ")#mi("{p}")#text(" and ")#mi("{{\\bf n}_\\infty+h}")#text(" is not; in which case we can write ")#mi("{{\\bf n} = p {\\bf n}^{\\prime}}")#text(" as before, with ")#mi("{\\tau_p({\\bf n}_\\infty) = 1 + \\tau_p({\\bf n}^{\\prime}_\\infty)}")#text(" and ")#mi("{\\tau_p({\\bf n}_\\infty+h)=1}")#text(". Finally, in the remaining event with probability ")#mi("{\\frac{1}{p}}")#text(", ")#mi("{{\\bf n}+h}")#text(" is divisible by ")#mi("{p}")#text(" and ")#mi("{{\\bf n}}")#text(" is not; we can then write ")#mi("{{\\bf n}_\\infty+h = p {\\bf n}^{\\prime}_\\infty}")#text(", so that ")#mi("{\\tau_p({\\bf n}_\\infty+h) = 1 + \\tau_p({\\bf n}^{\\prime}_\\infty)}")#text(" and ")#mi("{\\tau_p({\\bf n}_\\infty) = 1}")#text(". Putting all this together, we obtain")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\tau_p({\\bf n}_\\infty) \\tau_p({\\bf n}_\\infty+h) = \\frac{p-2}{p} + 2 \\frac{1}{p} (1 + {\\bf E} \\tau_p({\\bf n}^{\\prime}_\\infty))")]]

#text("and the claim ")#link(<tao-055993a9156086898671>)[#text("(6)")]#text(" in this case follows from ")#link(<tao-0a7cb27e52927eacabbb>)[#text("(5)")]#text(" and a brief computation (noting that ")#mi("{\\sigma_{-1,p}(h)=1}")#text(" in this case).")

#text("Now suppose that ")#mi("{h}")#text(" is divisible by ")#mi("{p}")#text(", thus ")#mi("{h=ph^{\\prime}}")#text(" for some integer ")#mi("{h^{\\prime}}")#text(". Then with probability ")#mi("{\\frac{p-1}{p}}")#text(", ")#mi("{{\\bf n}_\\infty}")#text(" and ")#mi("{{\\bf n}_\\infty+h}")#text(" are simultaneously coprime to ")#mi("{p}")#text(", in which case ")#mi("{\\tau_p({\\bf n}_\\infty) = \\tau_p({\\bf n}_\\infty+h) = 1}")#text(". In the remaining ")#mi("{\\frac{1}{p}}")#text(" event, we can write ")#mi("{{\\bf n}_\\infty = p {\\bf n}^{\\prime}_\\infty}")#text(", and then ")#mi("{\\tau_p({\\bf n}_\\infty) = 1 + \\tau_p({\\bf n}^{\\prime}_\\infty)}")#text(" and ")#mi("{\\tau_p({\\bf n}_\\infty+h) = 1 + \\tau_p({\\bf n}^{\\prime}_\\infty+h^{\\prime})}")#text(". Putting all this together we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\tau_p({\\bf n}_\\infty) \\tau_p({\\bf n}_\\infty+h) = \\frac{p-1}{p} + \\frac{1}{p} {\\bf E} (1+\\tau_p({\\bf n}^{\\prime}_\\infty)(1+\\tau_p({\\bf n}^{\\prime}_\\infty+h)")]]

#text("which by ")#link(<tao-0a7cb27e52927eacabbb>)[#text("(5)")]#text(" (and replacing ")#mi("{{\\bf n}^{\\prime}_\\infty}")#text(" by ")#mi("{{\\bf n}_\\infty}")#text(") leads to the recursive relation")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\tau_p({\\bf n}_\\infty) \\tau_p({\\bf n}_\\infty+h) = \\frac{p+1}{p-1} + \\frac{1}{p} {\\bf E} \\tau_p({\\bf n}_\\infty) \\tau_p({\\bf n}_\\infty+h)")]]

#text("and ")#link(<tao-055993a9156086898671>)[#text("(6)")]#text(" then follows by induction on the number of powers of ")#mi("{p}")#text(".")

#text("The estimate ")#link(<tao-0e07cf830957701d43c1>)[#text("(2)")]#text(" of Ingham was refined ")#link("http://www.ams.org/mathscinet-getitem?mr=1581262")[#text("by Estermann")]#text(", who obtained the more accurate expansion ")#metadata(none) <tao-d5682b641f1d5488c13d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\sum_{n \\leq x} \\tau(n) \\tau(n+h) = \\frac{6}{\\pi^2} \\sigma_{-1}(h) x \\log^2 x + a_1(h) x \\log x + a_2(h) x")]]





#align(center)[#tao-fit-display[#mitex("+ O( x^{11/12+o(1)} )")]]

#text("for certain complicated but explicit coefficients ")#mi("{a_1(h), a_2(h)}")#text(". For instance, ")#mi("{a_1(h)}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#mitex("a_1(h) = (\\frac{12}{\\pi^2} (2\\gamma-1) + 4 a^{\\prime}) \\sigma_{-1}(h) - \\frac{24}{\\pi^2} \\sigma^{\\prime}_{-1}(h)")]]

#text("where ")#mi("{\\gamma}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Euler%E2%80%93Mascheroni_constant")[#text("Euler-Mascheroni constant")]#text(", ")#metadata(none) <tao-f60f09f8d7c9ce90f701>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("a^{\\prime} := - \\sum_{r=1}^\\infty \\frac{\\mu(r)}{r^2} \\log r,")]]



#text(" and")

#align(center)[#tao-fit-display[#mitex("\\sigma^{\\prime}_{-1}(h) := \\sum_{d|h} \\frac{\\log d}{d}.")]]

#text("The formula for ")#mi("{a_2(h)}")#text(" is similar but even more complicated. The error term ")#mi("{O( x^{11/12+o(1)})}")#text(" was improved ")#link("http://www.ams.org/mathscinet-getitem?mr=532980")[#text("by Heath-Brown")]#text(" to ")#mi("{O( x^{5/6+o(1)})}")#text("; it is conjectured (for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=1828303")[#text("by Conrey and Gonek")]#text(") that one in fact has square root cancellation ")#mi("{O( x^{1/2+o(1)})}")#text(" here, but this is well out of reach of current methods.")

#text("These lower order terms are traditionally computed either from a Dirichlet series approach (using Perron’s formula) or a circle method approach. It turns out that a refinement of the above heuristics can also predict these lower order terms, thus keeping the calculation purely in physical space as opposed to the “multiplicative frequency space” of the Dirichlet series approach, or the “additive frequency space” of the circle method, although the computations are arguably as messy as the latter computations for the purposes of working out the lower order terms. We illustrate this just for the ")#mi("{a_1(h) x \\log x}")#text(" term below the fold.")

#metadata(none) <tao-1c7b5723c40c843ce788>

#heading(level: 1)[#strong[#text(" — 1. More refined heuristics — ")]]

#text("To begin with we revisit the heuristic justification of ")#link(<tao-0e07cf830957701d43c1>)[#text("(2)")]#text(" and modify it a bit, in the spirit of the “modified Cramér models” from ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("this previous blog post")]#text(". Our arguments here will be even less rigorous than in the preceding section, for instance we shall be quite cavalier with the use of the ")#mi("{\\approx}")#text(" symbol without precisely quantifying error terms.")

#text("For this section, it will be convenient to set ")#mi("{{\\bf n} = {\\bf n}_x}")#text(" not to be the uniform distribution from ")#mi("{1}")#text(" to ")#mi("{x}")#text(" as before, but rather the uniform distribution from ")#mi("{x}")#text(" to ")#mi("{(1+\\delta) x}")#text(" for some fairly small ")#mi("{\\delta>0}")#text(" (e.g. ")#mi("{\\delta = 1/\\log^{10} x}")#text(" will suffice). The reason for this is that we need to start keeping track of the magnitude of ")#mi("{{\\bf n}}")#text(" to a relative accuracy of at least ")#mi("{1/\\log x}")#text(", and with this new choice of ")#mi("{{\\bf n}}")#text(" the magnitude is simply ")#mi("{x}")#text(" (up to this accuracy). By “differentiating” asymptotics such as ")#link(<tao-d5682b641f1d5488c13d>)[#text("(7)")]#text(" in ")#mi("{h}")#text(" we see that")

#align(center)[#tao-fit-display[#mitex("\\sum_{x < n \\leq (1+\\delta) x} \\tau(n) \\tau(n+h) \\approx \\delta x ( \\frac{6}{\\pi^2} \\sigma_{-1}(h) \\log^2 x + a^{\\prime}_1(h) \\log x )")]]

#text("where we ignore terms of lower order than the ")#mi("{\\log x}")#text(" term and")

#tao-aligned(keep: true)[


#tao-math("a^{\\prime}_1(h)  & := a_1(h) + 2 \\times \\frac{6}{\\pi^2} \\sigma_{-1}(h)", block: true)



#tao-math(" & = (\\frac{24 \\gamma}{\\pi^2} + 4 a^{\\prime}) \\sigma_{-1}(h) - \\frac{24}{\\pi^2} \\sigma^{\\prime}_{-1}(h)", block: true)
]

#text("and so our task is now to heuristically justify the statement ")#metadata(none) <tao-ea4b35e8f83279eab1e6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("{\\bf E} \\tau({\\bf n}_x) \\tau({\\bf n}_x + h) \\approx \\frac{6}{\\pi^2} \\sigma_{-1}(h) \\log^2 x + a^{\\prime}_1(h) \\log x.")]]



#text(" Let us begin by revisiting the derivation of the simpler asymptotic ")#metadata(none) <tao-4f90272251751ca35eb8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("{\\bf E} \\tau({\\bf n}_x) \\tau({\\bf n}_x + h) \\approx \\frac{6}{\\pi^2} \\sigma_{-1}(h) \\log^2 x")]]



#text(" without passing immediately to local factors, but instead using a modified Cramér type model that will be more amenable to keeping careful track of the magnitude ")#mi("{x}")#text(". For any square-free ")#mi("{q}")#text(", write")

#align(center)[#tao-fit-display[#mitex("\\tau_q(n) := \\prod_{p|q} \\tau_p(n)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\tau_{(q)}(n) := \\prod_{p \\not | q} \\tau_p(n)")]]

#text("so that we have the factorisation ")#mi("{\\tau(n) = \\tau_q(n) \\tau_{(q)}(n)}")#text(". From the Chinese remainder theorem we expect ")#mi("{\\tau_q({\\bf n}_x)}")#text(" and ")#mi("{\\tau_{(q)}({\\bf n}_x)}")#text(" to behave approximately independently, at least when ")#mi("{q}")#text(" is fixed and ")#mi("{x}")#text(" is large.")

#text("We can use statistics of ")#mi("{\\tau}")#text(" to deduce statistics of ")#mi("{\\tau_{(q)}}")#text(". This is traditionally done using the device of Möbius inversion, but we will use a recursive probabilistic approach here similar to that used to prove Proposition ")#link(<tao-3d66f74fd48822744da1>)[#text("1")]#text(". Let’s start with understanding ")#mi("{\\tau_{(p)}}")#text(" for some prime ")#mi("{p}")#text(". With probability about ")#mi("{\\frac{p-1}{p}}")#text(", ")#mi("{{\\bf n}_x}")#text(" is coprime to ")#mi("{p}")#text(", so that ")#mi("{\\tau({\\bf n}_x) = \\tau_{(p)}({\\bf n}_x)}")#text(". In the remaining event of probability about ")#mi("{\\frac{1}{p}}")#text(", we may write ")#mi("{{\\bf n}_x = p {\\bf n}^{\\prime}_{x/p}}")#text(" where ")#mi("{{\\bf n}^{\\prime}_{x/p}}")#text(" is uniformly distributed near ")#mi("{x/p}")#text(", and then ")#mi("{\\tau({\\bf n}_x) = \\tau({\\bf n}^{\\prime}_{x/p}) + \\tau_{(p)}({\\bf n}^{\\prime}_{x/p})}")#text(". This leads to the approximate identity ")#metadata(none) <tao-a60ec1cf58f49cd2fab6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("{\\bf E} \\tau({\\bf n}_x) \\approx \\frac{p-1}{p} {\\bf E}(\\tau_{(p)}({\\bf n}_x) | ({\\bf n}_x,p)=1)")]]





#align(center)[#tao-fit-display[#mitex("+ \\frac{1}{p}( {\\bf E} \\tau({\\bf n}^{\\prime}_{x/p}) + \\tau_{(p)}({\\bf n}^{\\prime}_{x/p})).")]]

#text("To work with this equation we make two further heuristic assumptions, which turn out to be reasonable at the level of accuracy required for justifying ")#link(<tao-4f90272251751ca35eb8>)[#text("(10)")]#text(", but not for ")#link(<tao-ea4b35e8f83279eab1e6>)[#text("(9)")]#text(". Firstly, we assume that the distribution of ")#mi("{\\tau_{(p)}({\\bf n}_x)}")#text(" is largely unchanged after conditioning to the event ")#mi("{({\\bf n}_x,p)=1}")#text(", which is plausible from the Chinese remainder theorem. Secondly, we assume that the distribution of ")#mi("{\\tau({\\bf n}^{\\prime}_{x/p})}")#text(" is largely the same as that of ")#mi("{\\tau({\\bf n}_x)}")#text(", and similarly for ")#mi("{\\tau_{(p)}}")#text(". With these assumptions, ")#link(<tao-a60ec1cf58f49cd2fab6>)[#text("(11)")]#text(" simplifies to")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\tau({\\bf n}_x) \\approx \\frac{p-1}{p} {\\bf E} \\tau_{(p)}({\\bf n}_x) + \\frac{1}{p}( {\\bf E} \\tau({\\bf n}_x) + \\tau_{(p)}({\\bf n}_x))")]]

#text("which rearranges as ")#metadata(none) <tao-7d445240c97cb8b39b22>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("{\\bf E} \\tau_{(p)}({\\bf n}_x) \\approx \\frac{p-1}{p} {\\bf E} \\tau({\\bf n}_x)")]]



#text(" (note that this is consistent with Proposition ")#link(<tao-3d66f74fd48822744da1>)[#text("1")]#text(" and the presumed independence of ")#mi("{\\tau_p({\\bf n}_x)}")#text(" and ")#mi("{\\tau_{(p)}({\\bf n}_x)}")#text("). Iterating this argument gives")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\tau_{(q)}({\\bf n}_x) \\approx (\\prod_{p|q} \\frac{p-1}{p}) {\\bf E} \\tau({\\bf n}_x)")]]

#text("for any fixed squarefree ")#mi("{q}")#text(". Applying ")#link(<tao-e40d16db6ea0c7b0cca1>)[#text("(1)")]#text(" we conclude ")#metadata(none) <tao-b1811cfc3c9ea20642dc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("{\\bf E} \\tau_{(q)}({\\bf n}_x) \\approx (\\prod_{p|q} \\frac{p-1}{p}) \\log x.")]]





#text("Now let ")#mi("{w}")#text(" be a moderately large number (growing very slowly with ")#mi("{x}")#text(", e.g. ")#mi("{w = \\log\\log\\log x}")#text("), and let ")#mi("{W := \\prod_{p \\leq w} p}")#text(" be the ")#link("https://en.wikipedia.org/wiki/Primorial")[#text("primorial")]#text(" of ")#mi("{w}")#text(". We factor ")#metadata(none) <tao-e0c85f7b2112fbf034af>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("{\\bf E} \\tau({\\bf n}_x) \\tau({\\bf n}+h) = {\\bf E} \\tau_W({\\bf n}_x) \\tau_W({\\bf n}_x+h) \\tau_{(W)}({\\bf n}_x) \\tau_{(W)}({\\bf n}_x+h).")]]



#text(" There is arithmetic coupling between the ")#mi("{\\tau_W({\\bf n})}")#text(" and ")#mi("{\\tau_W({\\bf n}+h)}")#text(" factors; indeed from Proposition ")#link(<tao-3d66f74fd48822744da1>)[#text("1")]#text(" and the Chinese remainder theorem we have ")#metadata(none) <tao-40460da8c882cdc79183>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("{\\bf E} \\tau_W({\\bf n}_x) \\tau_W({\\bf n}_x+h) \\approx \\prod_{p \\leq w} (1-\\frac{1}{p^2}) \\sigma_{-1,p}(h) (\\frac{p}{p-1})^2.")]]



#text(" Meanwhile, from ")#link(<tao-b1811cfc3c9ea20642dc>)[#text("(13)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\tau_{(W)}({\\bf n}_x) \\approx (\\prod_{p \\leq w} \\frac{p-1}{p}) \\log x")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\tau_{(W)}({\\bf n}_x+h) \\approx (\\prod_{p \\leq w} \\frac{p-1}{p}) \\log x")]]

#text("In analogy with the modified Cramér model for the primes, we now assume that the random variables ")#mi("{\\tau_W({\\bf n}_x) \\tau_W({\\bf n}_x+h)}")#text(", ")#mi("{\\tau_{(W)}({\\bf n}_x)}")#text(", and ")#mi("{\\tau_{(W)}({\\bf n}_x+h)}")#text(" behave like independent random variables; this turns out to be sufficiently accurate for predicting ")#link(<tao-4f90272251751ca35eb8>)[#text("(10)")]#text(", but not ")#link(<tao-ea4b35e8f83279eab1e6>)[#text("(9)")]#text(". This leads to the prediction")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\tau({\\bf n}_x) \\tau({\\bf n}_x+h)\\approx (\\prod_{p \\leq w} (1-\\frac{1}{p^2}) \\sigma_{-1,p}(h)) \\log^2 x,")]]

#text("and if ")#mi("{w}")#text(" goes to infinity with ")#mi("{x}")#text(" then we recover ")#link(<tao-4f90272251751ca35eb8>)[#text("(10)")]#text(".")

#text("We now repeat the above analysis but expanding to the next order in ")#mi("{\\log x}")#text(", which will require keeping better track of the ")#mi("{x}")#text(" parameter. The Dirichlet hyperbola method actually gives the refinement")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\tau(n) = x \\log x - x + 2 \\gamma x + O( \\sqrt{x} ),")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("\\sum_{x < n \\leq (1+\\delta) x} \\tau(n) \\approx \\delta x ( \\log x + 2 \\gamma )")]]

#text("so that ")#metadata(none) <tao-d8c59e8348e0c03f9d21>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("{\\bf E} \\tau({\\bf n}_x) \\approx \\log x + 2 \\gamma.")]]



#text(" We previously computed the expectation ")#mi("{\\mathop{\\bf E} \\tau_{(q)}({\\bf n}_x)}")#text(". Now that we want to be more accurate, it turns out that it is better to compute the slightly different ")#emph[#text("conditional expectation")]#text(" ")#mi("{\\mathop{\\bf E}(\\tau_{(q)}({\\bf n}_x) | ({\\bf n}_x,q)=1)}")#text(". Now we compute the mean of ")#mi("{\\tau_{(q)}({\\bf n}_x)}")#text(" a bit more carefully. Again we begin with ")#mi("{\\tau_{(p)}({\\bf n}_x)}")#text(" for ")#mi("{p}")#text(" prime. From ")#link(<tao-a60ec1cf58f49cd2fab6>)[#text("(11)")]#text(" and ")#link(<tao-d8c59e8348e0c03f9d21>)[#text("(16)")]#text(", and by replacing ")#mi("{{\\bf n}^{\\prime}_{x/p}}")#text(" with ")#mi("{{\\bf n}_{x/p}}")#text(", we have ")#metadata(none) <tao-e8bc163c82eee1873328>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\log x + 2 \\gamma \\approx \\frac{p-1}{p} {\\bf E}(\\tau_{(p)}({\\bf n}_x) | ({\\bf n}_x,p)=1) + \\frac{1}{p}( \\log \\frac{x}{p} + 2 \\gamma + \\tau_{(p)}({\\bf n}_{x/p})).")]]



#text(" Previously we simplified this equation by assuming that the conditioning ")#mi("{({\\bf n}_x,p)=1}")#text(" had negligible impact on ")#mi("{\\tau_{(p)}({\\bf n}_x)}")#text(", and that ")#mi("{\\tau_{(p)}({\\bf n}_{x/p})}")#text(" had similar distribution to ")#mi("{\\tau_{(p)}({\\bf n}_{x})}")#text(". As it turns out, we can no longer afford to assume these simplifying assumptions at this level of accuracy, and must argue more carefully. With probability about ")#mi("{\\frac{p-1}{p}}")#text(" ")#mi("{{\\bf n}_x}")#text(" is coprime to ")#mi("{p}")#text(", and in the remaining event of probability about ")#mi("{\\frac{1}{p}}")#text(", we have ")#mi("{{\\bf n}_x = p {\\bf n}^{\\prime}_{x/p}}")#text(" and ")#mi("{\\tau_{(p)}({\\bf n}_x) = \\tau_{(p)}( {\\bf n}^{\\prime}_{x/p} )}")#text(". This gives the approximate identity ")#metadata(none) <tao-ad328846aa18b32a3358>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("{\\bf E} \\tau_{(p)}({\\bf n}_x) \\approx \\frac{p-1}{p} {\\bf E}(\\tau_{(p)}({\\bf n}_x) | ({\\bf n}_x,p)=1 ) + \\frac{1}{p} {\\bf E} \\tau_{(p)}({\\bf n}_{x/p}).")]]



#text(" If we refine the approximation ")#link(<tao-7d445240c97cb8b39b22>)[#text("(12)")]#text(" to give the ansatz")

#align(center)[#tao-fit-display[#mitex("{\\bf E}(\\tau_{(p)}({\\bf n}_x) | ({\\bf n}_x,p)=1 ) \\approx \\frac{p-1}{p} (\\log x + 2 \\gamma + A)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\tau_{(p)}({\\bf n}_x) \\approx \\frac{p-1}{p} (\\log x + 2 \\gamma + B)")]]

#text("for some constants ")#mi("{A,B}")#text(" to be worked out momentarily, the above two equations give after some computation (and canceling out all the ")#mi("{\\log x + 2\\gamma}")#text(" terms")

#tao-aligned(keep: true)[


#tao-math("0  & = \\frac{(p-1)^2}{p^2} A - \\frac{(2p-1)\\log p}{p^2} + \\frac{p-1}{p^2} B", block: true)



#tao-math("B  & = \\frac{p-1}{p} A + \\frac{1}{p} B - \\frac{\\log p}{p}", block: true)
]

#text("which can be solved as")

#align(center)[#tao-fit-display[#mitex("A = \\frac{2 \\log p}{p-1}; \\quad B = \\frac{\\log p}{p-1}.")]]

#text("Thus we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E}(\\tau_{(p)}({\\bf n}_x) | ({\\bf n}_x,p)=1 ) \\approx \\frac{p-1}{p} (\\log x + 2 \\gamma + \\frac{2 \\log p}{p-1}).")]]

#text("Iterating this we arrive at ")#metadata(none) <tao-3eca4424d164d0e02850>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("{\\bf E}(\\tau_{(q)}({\\bf n}_x) | ({\\bf n}_x,q)=1 ) \\approx (\\prod_{p|q} \\frac{p-1}{p}) (\\log x + 2 \\gamma + \\sum_{p|q} \\frac{2 \\log p}{p-1}).")]]



#text(" It is instructive (albeit lengthy) to deduce this asymptotic rigorously for fixed square-free ")#mi("{q}")#text(" and large ")#mi("{x}")#text(" by using Möbius inversion and the hyperbola method; one can also proceed a bit more quickly by using Perron’s formula and inspecting the pole of the relevant Dirichlet series at ")#mi("{s=1}")#text(". (Not surprisingly, similar calculations appear when computing major arc contributions to ")#link(<tao-0e07cf830957701d43c1>)[#text("(2)")]#text(".)")

#text("Now we are ready to predict the value of ")#mi("{{\\bf E} \\tau({\\bf n}_x) \\tau({\\bf n}_x + h)}")#text(". Our starting point is again the expansion ")#link(<tao-e0c85f7b2112fbf034af>)[#text("(14)")]#text(", except that we now strip out the factors within ")#mi("{\\tau_{(W)}}")#text(" that divide ")#mi("{W}")#text(", in order to use ")#link(<tao-3eca4424d164d0e02850>)[#text("(19)")]#text(". More precisely, we adopt the factorisation ")#mi("{n = n_W n_{(W)}}")#text(" of arbitrary natural numbers ")#mi("{n}")#text(" by the formulae")

#align(center)[#tao-fit-display[#mitex("n_W := \\prod_{p|W} p^{v_p(n)}; \\quad n_{(W)} := \\prod_{p \\not | W} p^{v_p(n)}")]]

#text("and observe that")

#align(center)[#tao-fit-display[#mitex("\\tau_{(W)}({\\bf n}_x) = \\tau_{(W)}( ({\\bf n}_x)_{(W)} )")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("\\tau_{(W)}({\\bf n}_x+h) = \\tau_{(W)}( ({\\bf n}_x+h)_{(W)} ).")]]

#text("We are now faced with computing the expression ")#metadata(none) <tao-9a105749cfcbac2e07d7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("{\\bf E} \\tau_W({\\bf n}_x) \\tau_W({\\bf n}_x+h) \\tau_{(W)}(({\\bf n}_x)_{(W)}) \\tau_{(W)}(({\\bf n}_x+h)_{(W)}).")]]



#text(" Previously we had assumed that the factors ")#mi("{\\tau_W({\\bf n}_x) \\tau_W({\\bf n}_x+h)}")#text(", ")#mi("{\\tau_{(W)}(({\\bf n}_x)_{(W)})}")#text(", and ")#mi("{\\tau_{(W)}(({\\bf n}_x+h)_{(W)})}")#text(" behaved independently. However this is not quite true at the current level of accuracy, because the magnitude of the natural numbers ")#mi("{({\\bf n}_x)_{(W)}}")#text(" and ")#mi("{({\\bf n}_x+h)_{(W)}}")#text(" are influenced by the size of ")#mi("{({\\bf n}_x)_W}")#text(" and ")#mi("{({\\bf n}_x+h)_W}")#text(" respectively, and these in turn are certainly correlated with ")#mi("{\\tau_W({\\bf n}_x) \\tau_W({\\bf n}_x+h)}")#text(". Because of the non-trivial dependence on ")#mi("{x}")#text(" on the right-hand side of ")#link(<tao-3eca4424d164d0e02850>)[#text("(19)")]#text(" at this level of accuracy, the size of ")#mi("{({\\bf n}_x)_W}")#text(" and ")#mi("{({\\bf n}_x+h)_W}")#text(" influences the expected value of ")#mi("{\\tau_{(W)}(({\\bf n}_x)_{(W)})}")#text(" and ")#mi("{\\tau_{(W)}(({\\bf n}_x+h)_{(W)})}")#text(", causing a coupling between the three factors of ")#link(<tao-9a105749cfcbac2e07d7>)[#text("(20)")]#text(". However, if we first condition the magnitude of ")#mi("{({\\bf n}_x)_{W}}")#text(" and ")#mi("{({\\bf n}_x+h)_{W}}")#text(" to be fixed, then we expect the three factors to be ")#emph[#text("conditionally")]#text(" independent (at this level of accuracy). Heuristically, with this conditioning, ")#mi("{({\\bf n}_x)_{(W)}}")#text(" behaves like a random element of size about ")#mi("{x / ({\\bf n}_x)_W}")#text(" that is coprime to ")#mi("{W}")#text(", and hence by ")#link(<tao-3eca4424d164d0e02850>)[#text("(19)")]

#align(center)[#tao-fit-display[#mitex("{\\bf E}(\\tau_{(W)}(({\\bf n}_x)_W) | ({\\bf n}_x)_{W}, ({\\bf n}_x+h)_{W})")]]

#align(center)[#tao-fit-display[#mitex("\\approx (\\prod_{p \\leq w} \\frac{p-1}{p}) (\\log \\frac{x}{({\\bf n}_x)_W} + 2 \\gamma + \\sum_{p \\leq w} \\frac{2 \\log p}{p-1})")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("{\\bf E}(\\tau_{(W)}(({\\bf n}_x+h)_W) | ({\\bf n}_x)_{W}, ({\\bf n}_x+h)_{W})")]]

#align(center)[#tao-fit-display[#mitex("\\approx (\\prod_{p \\leq w} \\frac{p-1}{p}) (\\log \\frac{x}{({\\bf n}_x+h)_W} + 2 \\gamma + \\sum_{p \\leq w} \\frac{2 \\log p}{p-1}).")]]

#text("We can thus heuristically estimate ")#link(<tao-9a105749cfcbac2e07d7>)[#text("(20)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\tau_W({\\bf n}_x) \\tau_W({\\bf n}_x+h)")]]

#align(center)[#tao-fit-display[#mitex("\\times (\\prod_{p \\leq w} \\frac{p-1}{p}) (\\log \\frac{x}{({\\bf n}_x)_W} + 2 \\gamma + \\sum_{p \\leq w} \\frac{2 \\log p}{p-1})")]]

#align(center)[#tao-fit-display[#mitex("\\times (\\prod_{p \\leq w} \\frac{p-1}{p}) (\\log \\frac{x}{({\\bf n}_x+h)_W} + 2 \\gamma + \\sum_{p \\leq w} \\frac{2 \\log p}{p-1}).")]]

#text("This can be expanded as")

#align(center)[#tao-fit-display[#mitex("a_0 \\log^2 x + a_1 \\log x + a_2")]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("a_0  & := (\\prod_{p \\leq w} \\frac{p-1}{p})^2 {\\bf E} \\tau_W({\\bf n}_x) \\tau_W({\\bf n}_x+h)", block: true)



#tao-math("a_1  & := 2 (2 \\gamma + \\sum_{p \\leq w} \\frac{2 \\log p}{p-1}) a_0", block: true)



#tao-math(" & - (\\prod_{p \\leq w} \\frac{p-1}{p})^2 {\\bf E} \\tau_W({\\bf n}_x) \\tau_W({\\bf n}_x+h) \\log({\\bf n}_x)_W", block: true)



#tao-math(" & - (\\prod_{p \\leq w} \\frac{p-1}{p})^2 {\\bf E} \\tau_W({\\bf n}_x) \\tau_W({\\bf n}_x+h) \\log({\\bf n}_x+h)_W", block: true)
]

#text("and ")#mi("{a_2}")#text(" is something complicated that we do not compute here. Using ")#link(<tao-40460da8c882cdc79183>)[#text("(15)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("a_0 \\approx \\frac{6}{\\pi^2} \\sigma_{-1}(h)")]]

#text("which recovers the Ingham estimate ")#link(<tao-4f90272251751ca35eb8>)[#text("(10)")]#text(". To obtain the finer approximation ")#link(<tao-ea4b35e8f83279eab1e6>)[#text("(9)")]#text(" we need to show that")

#align(center)[#tao-fit-display[#mitex("a_1 \\approx a^{\\prime}_1(h).")]]

#text("It will suffice to obtain the asymptotic ")#metadata(none) <tao-c353f7dabebea3a68d63>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("{\\bf E} \\tau_W({\\bf n}_x) \\tau_W({\\bf n}_x+h) \\log({\\bf n}_x)_W")]]





#tao-aligned(keep: true)[


#tao-math(" & \\approx \\prod_{p \\leq w} (1-\\frac{1}{p^2}) \\sigma_{-1,p}(h) (\\frac{p}{p-1})^2 \\times 2 (\\sum_{p \\leq w} \\frac{\\log p}{p-1}- \\frac{\\pi^2}{6} a^{\\prime})", block: true)



#tao-math(" & + \\prod_{p \\leq w}(1-\\frac{1}{p^2}) (\\frac{p}{p-1})^2 \\times 2 \\sigma^{\\prime}_{-1}(h)", block: true)
]

#text("together with the analogue of ")#link(<tao-c353f7dabebea3a68d63>)[#text("(21)")]#text(" with ")#mi("{\\log({\\bf n}_x)_W}")#text(" replaced by ")#mi("{\\log({\\bf n}_x+h)_W}")#text(". (One in fact has the approximation ")#mi("{\\sum_{p \\leq w} \\frac{\\log p}{p-1} \\approx \\log w - \\gamma}")#text(", which reflects the Laurent approximation ")#mi("{-\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)} \\approx \\frac{1}{s-1} - \\gamma}")#text(" near ")#mi("{s=1}")#text(", but we will not need this.)")

#text("We will just prove ")#link(<tao-c353f7dabebea3a68d63>)[#text("(21)")]#text(", as the analogue of ")#link(<tao-c353f7dabebea3a68d63>)[#text("(21)")]#text(" for ")#mi("{\\log({\\bf n}_x+h)_W}")#text(" is proven similarly. As this is a local calculation we may replace ")#mi("{{\\bf n}_x}")#text(" by ")#mi("{{\\bf n}_\\infty}")#text(". Splitting")

#align(center)[#tao-fit-display[#mitex("\\log({\\bf n}_\\infty)_W = \\sum_{p \\leq w} \\log({\\bf n}_\\infty)_p")]]

#text("we can write the left-hand side of ")#link(<tao-c353f7dabebea3a68d63>)[#text("(21)")]#text(" as a sum over primes,")

#align(center)[#tao-fit-display[#mitex("\\sum_p {\\bf E} \\tau_{W/p}({\\bf n}_\\infty) \\tau_{W/p}({\\bf n}_\\infty+h) \\tau_p({\\bf n}_\\infty) \\tau_p({\\bf n}_\\infty+h) \\log({\\bf n}_\\infty)_p.")]]

#text("The ")#mi("{W/p}")#text(" and ")#mi("{p}")#text(" terms decouple, so by Proposition ")#link(<tao-3d66f74fd48822744da1>)[#text("1")]#text(" this becomes")

#align(center)[#tao-fit-display[#mitex("\\sum_p (\\prod_{p^{\\prime} \\leq w: p^{\\prime} \\neq p} (1-\\frac{1}{(p^{\\prime})^2}) \\sigma_{-1,p^{\\prime}}(h) (\\frac{p^{\\prime}}{p^{\\prime}-1})^2 ) {\\bf E} \\tau_p({\\bf n}_\\infty) \\tau_p({\\bf n}_\\infty+h) \\log({\\bf n}_\\infty)_p.")]]

#text("Extracting a common factor of ")#mi("{(\\prod_{p^{\\prime} \\leq w} (1-\\frac{1}{(p^{\\prime})^2}) \\sigma_{-1,p^{\\prime}}(h) (\\frac{p^{\\prime}}{p^{\\prime}-1})^2 )}")#text(", we reduce to showing that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq w} (1-\\frac{1}{p^2})^{-1} \\sigma_{-1,p}(h)^{-1} (\\frac{p-1}{p})^2 {\\bf E} \\tau_p({\\bf n}_\\infty) \\tau_p({\\bf n}_\\infty+h) \\log({\\bf n}_\\infty)_p")]]

#tao-aligned(keep: true)[


#tao-math(" & \\approx 2 (\\sum_{p \\leq w} \\frac{\\log p}{p-1}- \\frac{\\pi^2}{6} a^{\\prime})", block: true)



#tao-math(" & + 2 \\frac{\\sigma^{\\prime}_{-1}(h)}{\\sigma_{-1}(h)}.", block: true)
]

#text("The left-hand side is a sum over primes ")#mi("{p}")#text(", so we work on making the right-hand side a sum over primes as well. This is achieved by the following two lemmas:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" We have ")#mi("{\\frac{\\pi^2}{6} a^{\\prime} = \\sum_p \\frac{\\log p}{p^2-1}}")#text(".")
]

#emph[#text("Proof:")]#text(" While this identity can be proven elementarily, it is fastest to proceed using Dirichlet series. From Taylor expansion and ")#link(<tao-f60f09f8d7c9ce90f701>)[#text("(8)")]#text(" we have")

#tao-aligned(keep: true)[


#tao-math("\\frac{1}{\\zeta(s)}  & = \\sum_n \\frac{\\mu(n)}{n^s}", block: true)



#tao-math(" & \\approx \\frac{1}{\\zeta(2)} + (s-2) a^{\\prime}", block: true)



#tao-math(" & = \\frac{6}{\\pi^2} ( 1 + \\frac{\\pi^2}{6} a^{\\prime} (s-2) )", block: true)
]

#text("for ")#mi("{s}")#text(" close to ")#mi("{2}")#text(". Inverting, we have")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) \\approx \\frac{\\pi^2}{6} ( 1 - \\frac{\\pi^2}{6} a^{\\prime} (s-2) )")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("- \\frac{\\zeta^{\\prime}(2)}{\\zeta(2)} = \\frac{\\pi^2}{6} a^{\\prime}.")]]

#text("The left-hand side is ")#mi("{\\sum_n \\frac{\\Lambda(n)}{n^2} = \\sum_p \\frac{\\log p}{p^2-1}}")#text(", giving the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4")]#text(" We have ")#mi("{\\frac{\\sigma^{\\prime}_{-1}(h)}{\\sigma_{-1}(h)} = \\sum_p \\frac{\\sigma^{\\prime}_{-1,p}(h)}{\\sigma_{-1,p}(h)}}")#text(".")
]

#emph[#text("Proof:")]#text(" Again it is fastest to proceed using Dirichlet series. Setting ")#mi("{\\sigma_s(h) := \\sum_{d|h} \\frac{1}{d^s}}")#text(" and ")#mi("{\\sigma_{s,p}(h) := \\sum_{p^k|h} \\frac{1}{p^{ks}}}")#text(", we have from the fundamental theorem of arithmetic that")

#align(center)[#tao-fit-display[#mitex("\\log \\sigma_s(h) = \\sum_p \\log \\sigma_{s,p}(h).")]]

#text("Differentiating this at ")#mi("{s=-1}")#text(" we obtain the claim. ")#mi("\\Box")

#text("We remark that ")#mi("{\\sigma^{\\prime}_{-1}}")#text(" is an example of a derived multiplicative function, discussed in ")#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/")[#text("this previous blog post")]#text(".")

#text("In view of these expansions, we can reduce matters to establishing a purely local estimate at a single prime ")#mi("{p}")#text(", namely that")

#align(center)[#tao-fit-display[#mitex("(1-\\frac{1}{p^2})^{-1} \\sigma_{-1,p}(h)^{-1} (\\frac{p-1}{p})^2 {\\bf E} \\tau_p({\\bf n}_\\infty) \\tau_p({\\bf n}_\\infty+h) \\log({\\bf n}_\\infty)_p")]]

#tao-aligned(keep: true)[


#tao-math(" & = 2 (\\frac{\\log p}{p-1}- \\frac{\\log p}{p^2-1})", block: true)



#tao-math(" & + 2 \\frac{\\sigma^{\\prime}_{-1,p}(h)}{\\sigma_{-1,p}(h)},", block: true)
]

#text("which rearranges as ")#metadata(none) <tao-3ac1ecbd2220c6757eb9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("{\\bf E} \\tau_p({\\bf n}_\\infty) \\tau_p({\\bf n}_\\infty+h) \\log({\\bf n}_\\infty)_p = \\frac{2p \\log p}{(p-1)^2} \\sigma_{-1,p}(h) + \\frac{2(p+1)}{p-1} \\sigma^{\\prime}_{-1,p}(h)")]]



#text(" (compare with Proposition ")#link(<tao-3d66f74fd48822744da1>)[#text("1")]#text(").")

#text("We need two preliminary estimates to handle lower order terms:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5")]#text(" ")#metadata(none) <tao-2804bad6fe94a55f18b2>#text(" We have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\tau_p({\\bf n}_\\infty) \\log({\\bf n}_\\infty)_p = \\frac{2p \\log p}{(p-1)^2}.")]]
]

#emph[#text("Proof:")]#text(" Once again we use recursion. With probability ")#mi("{\\frac{p-1}{p}}")#text(", ")#mi("{{\\bf n}_\\infty}")#text(" is coprime to ")#mi("{p}")#text(", so ")#mi("{\\tau_p({\\bf n}_\\infty) \\log({\\bf n}_\\infty)_p}")#text(" vanishes. Otherwise, ")#mi("{{\\bf n}_\\infty = p {\\bf n}^{\\prime}_\\infty}")#text(", ")#mi("{\\tau_p({\\bf n}_\\infty) = 1 + \\tau_p({\\bf n}^{\\prime}_\\infty)}")#text(", and ")#mi("{\\log ({\\bf n}_\\infty)_p = \\log p + \\log ({\\bf n}^{\\prime}_\\infty)_p}")#text(". We conclude that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\tau_p({\\bf n}_\\infty) \\log({\\bf n}_\\infty)_p = \\frac{1}{p} {\\bf E} (1+\\tau_p({\\bf n}_\\infty)) (\\log p + \\log({\\bf n}_\\infty)_p).")]]

#text("From Proposition ")#link(<tao-3d66f74fd48822744da1>)[#text("1")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\tau_p({\\bf n}_\\infty) = \\frac{p}{p-1}")]]

#text("and from the identity ")#mi("{\\log ({\\bf n}_\\infty)_p = \\log p ( \\tau_p({\\bf n}_\\infty) - 1)}")#text(" we thus have ")#metadata(none) <tao-3e23e8160039594a3389>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("{\\bf E} \\log ({\\bf n}_\\infty)_p = \\frac{1}{p-1} \\log p")]]



#text(" so that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\tau_p({\\bf n}_\\infty) \\log({\\bf n}_\\infty)_p = \\frac{1}{p} {\\bf E} \\tau_p({\\bf n}_\\infty)) \\log({\\bf n}_\\infty)_p) + \\frac{2 \\log p}{p-1}")]]

#text("and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6")]#text(" ")#metadata(none) <tao-8a1cee436cbac1489a18>#text(" We have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\tau_p({\\bf n}_\\infty+h) \\log({\\bf n}_\\infty)_p =\\frac{\\log p}{p-1} ((p+1)\\sigma_{-1,p}(h) - p).")]]
]

#text("Note that one can view Lemma ")#link(<tao-2804bad6fe94a55f18b2>)[#text("5")]#text(" as the ")#mi("{h=0}")#text(" (p-adic) limiting case of Lemma ")#link(<tao-8a1cee436cbac1489a18>)[#text("6")]#text(".")

#emph[#text("Proof:")]#text(" First suppose that ")#mi("{h}")#text(" is coprime to ")#mi("{p}")#text(". Then ")#mi("{\\tau_p({\\bf n}_\\infty+h)}")#text(" is equal to ")#mi("{1}")#text(" whenever ")#mi("{\\log({\\bf n}_\\infty)_p}")#text(" is non-zero, so the claim follows from ")#link(<tao-3e23e8160039594a3389>)[#text("(23)")]#text(" in this case. Now suppose that ")#mi("{h = ph^{\\prime}}")#text(" for some integer ")#mi("{h^{\\prime}}")#text(".")

#text("When ")#mi("{h}")#text(" is coprime to ")#mi("{p}")#text(" the left-hand side is equal to ")#mi("{0}")#text(" when ")#mi("{{\\bf n}_\\infty}")#text(" is coprime to ")#mi("{p}")#text(" and ")#mi("{1}")#text(" otherwise, giving the claim. Now suppose that ")#mi("{h=ph^{\\prime}}")#text(" for some integer ")#mi("{h^{\\prime}}")#text(". With probability ")#mi("{\\frac{p-1}{p}}")#text(", ")#mi("{{\\bf n}_\\infty}")#text(" is coprime to ")#mi("{p}")#text(", so ")#mi("{\\tau_p({\\bf n}_\\infty+h) \\log({\\bf n}_\\infty)_p}")#text(" vanishes; otherwise,")#mi("{{\\bf n}_\\infty = p {\\bf n}^{\\prime}_\\infty}")#text(", ")#mi("{\\tau_p({\\bf n}_\\infty+h) = 1 + \\tau_p({\\bf n}^{\\prime}_\\infty+h^{\\prime})}")#text(", and ")#mi("{\\log ({\\bf n}_\\infty)_p = \\log p + \\log ({\\bf n}^{\\prime}_\\infty)_p}")#text(". We conclude that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\tau_p({\\bf n}_\\infty+h) \\log({\\bf n}_\\infty)_p = \\frac{1}{p} {\\bf E} (1+\\tau_p({\\bf n}_\\infty+h^{\\prime})) (\\log p + \\log({\\bf n}_\\infty)_p).")]]

#text("Arguing as before we conclude that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\tau_p({\\bf n}_\\infty+h) \\log({\\bf n}_\\infty)_p = \\frac{1}{p} {\\bf E} \\tau_p({\\bf n}_\\infty+h^{\\prime})) \\log({\\bf n}_\\infty)_p) + \\frac{2 \\log p}{p-1}")]]

#text("and the claim follows by induction on the number of times ")#mi("{p}")#text(" divides ")#mi("{h}")#text(" (noting that ")#mi("{\\sigma_{-1,p}(h) = 1 + \\frac{1}{p} \\sigma_{-1,p}(h^{\\prime})}")#text("). ")#mi("\\Box")

#text("Now we can prove ")#link(<tao-3ac1ecbd2220c6757eb9>)[#text("(22)")]#text(". First suppose ")#mi("{h}")#text(" is coprime to ")#mi("{p}")#text(". In this case, the random variable ")#mi("{\\tau_p({\\bf n}_\\infty) \\tau_p({\\bf n}_\\infty+h) \\log({\\bf n}_\\infty)_p}")#text(" is only non-zero when ")#mi("{{\\bf n}_\\infty}")#text(" is divisible by ")#mi("{p}")#text(", which forces ")#mi("{\\tau_p({\\bf n}_\\infty+h)}")#text(" to equal ")#mi("{1}")#text(". By Lemma ")#link(<tao-2804bad6fe94a55f18b2>)[#text("5")]#text(", the left-hand side of ")#link(<tao-3ac1ecbd2220c6757eb9>)[#text("(22)")]#text(" is thus equal to ")#mi("{\\frac{2p \\log p}{(p-1)^2}}")#text(", thus proving ")#link(<tao-3ac1ecbd2220c6757eb9>)[#text("(22)")]#text(" in this case.")

#text("Now suppose that ")#mi("{h}")#text(" is divisible by ")#mi("{p}")#text(". With probability ")#mi("{\\frac{p-1}{p}}")#text(", ")#mi("{{\\bf n}_\\infty}")#text(" is coprime to ")#mi("{p}")#text(", so ")#mi("{\\tau_p({\\bf n}_\\infty) \\tau_p({\\bf n}_\\infty+h) \\log({\\bf n}_\\infty)_p}")#text(" vanishes. Otherwise, we write ")#mi("{{\\bf n}_\\infty = p {\\bf n}^{\\prime}_\\infty}")#text(" and observe that")

#tao-aligned(keep: true)[


#tao-math("\\tau_p({\\bf n}_\\infty)  & = 1 + \\tau_p({\\bf n}^{\\prime}_\\infty)", block: true)



#tao-math("\\tau_p({\\bf n}_\\infty+h)  & = 1 + \\tau_p({\\bf n}^{\\prime}_\\infty+h^{\\prime})", block: true)



#tao-math("\\log({\\bf n}_\\infty)_p  & = \\log p + \\log({\\bf n}^{\\prime}_\\infty)_p", block: true)
]

#text("thus the left-hand side of ")#link(<tao-3ac1ecbd2220c6757eb9>)[#text("(22)")]#text(" expands as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{p} {\\bf E} (1 + \\tau_p({\\bf n}^{\\prime}_\\infty))(1 + \\tau_p({\\bf n}^{\\prime}_\\infty+h^{\\prime}))(\\log p + \\log({\\bf n}^{\\prime}_\\infty)_p).")]]

#text("This expands into eight terms that can be computed using Proposition ")#link(<tao-3d66f74fd48822744da1>)[#text("1")]#text(", ")#link(<tao-3e23e8160039594a3389>)[#text("(23)")]#text(", and Lemmas ")#link(<tao-2804bad6fe94a55f18b2>)[#text("5")]#text(", ")#link(<tao-8a1cee436cbac1489a18>)[#text("(6)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{p} \\log p")]]

#align(center)[#tao-fit-display[#mitex("+ \\frac{1}{p} \\frac{1}{p-1} \\log p")]]

#align(center)[#tao-fit-display[#mitex("+ \\frac{1}{p} \\frac{p}{p-1} \\log p")]]

#align(center)[#tao-fit-display[#mitex("+ \\frac{1}{p} \\frac{\\log p}{p-1} ((p+1)\\sigma_{-1,p}(h^{\\prime}) - p)")]]

#align(center)[#tao-fit-display[#mitex("+ \\frac{1}{p} \\frac{p}{p-1} \\log p")]]

#align(center)[#tao-fit-display[#mitex("+ \\frac{1}{p} \\frac{2p \\log p}{(p-1)^2}")]]

#align(center)[#tao-fit-display[#mitex("+ \\frac{1}{p} \\frac{p+1}{p-1} \\sigma_{-1,p}(h^{\\prime}) \\log p")]]

#align(center)[#tao-fit-display[#mitex("+ \\frac{1}{p} {\\bf E} \\tau_p({\\bf n}_\\infty)\\tau_p({\\bf n}_\\infty+h^{\\prime})\\log({\\bf n}_\\infty)_p.")]]

#text("The claim then follows by induction on the number of times ")#mi("{p}")#text(" divides ")#mi("{h}")#text(", together with a tedious computation using the identities")

#align(center)[#tao-fit-display[#mitex("\\sigma_{-1,p}(h) = 1 + \\frac{1}{p} \\sigma_{-1,p}(h^{\\prime})")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\sigma^{\\prime}_{-1,p}(h)= \\frac{\\log p}{p} \\sigma_{-1,p}(h^{\\prime}) + \\frac{1}{p} \\sigma^{\\prime}_{-1,p}(h^{\\prime}).")]]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/08/30/heuristic-computation-of-correlations-of-the-divisor-function/#comment-472025")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2016")])]

#text("A simpler explanation for the local factorization of ")#mi("\\tau(n)")#text(" is by its multiplicativity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03d490c1ec3136ab44a803a326b50d79af41a7a97bec2d21777c5953210cae3c-03511cbabfd77102129f23632ac1bd331b3a26566bde810cfd698f52c181161e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marco Barone")]], [#link("https://terrytao.wordpress.com/2016/08/30/heuristic-computation-of-correlations-of-the-divisor-function/#comment-472026")[#strong[#text("Marco Barone")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2016")])]

#text("Hi, everybody, how can I open a new post? It is about a set of measures on N, that may lead to some new ways of weighing certain special sets of integers. It has something to do with this thread but not enough to be a comment to it. Please help, I really can’t figure this out. I can only comment here. Apologies for writing here!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98d192abd70f5311db8ec60dec56a48604f76cb7ff6a4cf4f5df43803680c3ff-cb5dcadf7bcf8b56cb8857c450f2fddd18645e59e478b53d2f6ab76b378a6646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jhon Manugal")]], [#link("https://terrytao.wordpress.com/2016/08/30/heuristic-computation-of-correlations-of-the-divisor-function/#comment-472039")[#strong[#text("Jhon Manugal")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2016")])]

#text("I recall the day in Probability class the teacher explained ")#mi("dB_t = \\sqrt{dt}")#text(" that was sufficient to make all my computations work (and pass the class).")

#text("Here I am tempted to write ")#mi("\\tau(n+h) = \\tau(n) + h \\tau^{\\prime}(n)")#text(" but this became circular reasoning. Somehow we need to find the two-point function (or correlation) $")#mi("\\langle \\tau(n) \\tau(n+h) \\rangle = \\langle \\tau(n)^2 \\rangle + h \\langle \\tau(n) \\tau^{\\prime}(n) \\rangle")#text("$ and such elementary reasoning led nowhere.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heuristic computation of correlations of higher order divisor functions | What's new")]], [#link("https://terrytao.wordpress.com/2016/08/30/heuristic-computation-of-correlations-of-the-divisor-function/#comment-472046")[#strong[#text("Heuristic computation of correlations of higher order divisor functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2016")])]

#text("[…] is a postscript to the previous blog post which was concerned with obtaining heuristic asymptotic predictions for the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2016/08/30/heuristic-computation-of-correlations-of-the-divisor-function/#comment-472049")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2016")])]

#text("If all you want is the asymptotic behaviour then the estimate ")#mi("\\sum_{n\\leq x}\\tau(n) =  x\\log x + O(x)")#text(" follows from changing the order of summation. The hyperbola method is needed to get the correct error term (")#mi("(2\\gamma-1)x + O(\\sqrt {x})")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d28195df14800315168ea974f4adf888eace7d3a34fc83513af492698793a2c-e2ad3cdfa379c5dcf139408dc5d555ac7c236dfa87abd3799a789b51ef5d74f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kodlu")]], [#link("https://terrytao.wordpress.com/2016/08/30/heuristic-computation-of-correlations-of-the-divisor-function/#comment-472094")[#strong[#text("kodlu")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2016")])]

#text("Very nice post. Right above equation (4) is the phrase:")

#text("“introduce an independent copy ${{\\bf n}’}$ is an independent copy of ${{\\bf n}}$”")

#text("which probably could be changed to")

#text("“introduce an independent copy ${{\\bf n}’}$ of ${{\\bf n}}$”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb0fa742e5acc39ef1a62d4394779e5f5fa933093247d9fcffb98c42548443aa-998895777a2a8e989ce42e01b4a6f74c37d291e9813fe0726403209e8de7c18e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Bary-Soroker")]], [#link("https://terrytao.wordpress.com/2016/08/30/heuristic-computation-of-correlations-of-the-divisor-function/#comment-472126")[#strong[#text("Lior Bary-Soroker")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2016")])]

#text("Can you say something about the heuristics of the correlation of twisted divisor function, e.g., replacing ")#mi("\\tau")#text(" by ")#mi("\\tau \\chi")#text(", where ")#mi("\\chi")#text(" is the quadratic character modulo 4?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/08/30/heuristic-computation-of-correlations-of-the-divisor-function/#comment-472128")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2016")])]

#text("Yes, the same arguments apply (evaluating local factors and then multiplying the correlations together to predict the main term). In many cases the correlations will now have a vanishing main term and thus be very small, though not always. For instance ")#mi("\\sum_{n \\leq x} \\tau(n) \\chi(n) \\tau(n+2) \\chi(n+2)")#text(" will not be small because ")#mi("\\chi(n+2)=-\\chi(n)")#text(" and so the summand is consistently negative.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/010df765105ce34e909d32e048742a010efe062bbd36c2f8dd19b0f5d8696624-674c360e65f00aef448537ac10f62e98585537d42a371884d863a417fe6f0980.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ravi A. Bajaj")]], [#link("https://terrytao.wordpress.com/2016/08/30/heuristic-computation-of-correlations-of-the-divisor-function/#comment-472796")[#strong[#text("Ravi A. Bajaj")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2016")])]

#text("There is a typo in the first sentence of the paragraph where you “use a recursive probabilistic approach” instead of a Mobius transformation at that point of the article. It says, “We can statistics of” — a word is missing.")

#emph[#text("[Corrected, thanks – T.]")]
]
