// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/11/03/asymptotic-decay-for-a-one-dimensional-nonlinear-wave-equation/
// Converted to Typst by tao2typ: "2026-10-14T16:36:21.937510+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Asymptotic decay for a one-dimensional nonlinear wave equation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Asymptotic decay for a one-dimensional nonlinear wave equation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 November 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/11/03/asymptotic-decay-for-a-one-dimensional-nonlinear-wave-equation/")[#text("https://terrytao.wordpress.com/2010/11/03/asymptotic-decay-for-a-one-dimensional-nonlinear-wave-equation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.ucsd.edu/~lindblad/")[#text("Hans Lindblad")]#text(" and I have just uploaded to the arXiv our joint paper “")#link("http://arxiv.org/abs/1011.0949")[#text("Asymptotic decay for a one-dimensional nonlinear wave equation")]#text("“, submitted to ")#link("http://pjm.math.berkeley.edu/apde/about/journal/about.html")[#text("Analysis & PDE")]#text(". This paper, to our knowledge, is the first paper to analyse the asymptotic behaviour of the one-dimensional defocusing nonlinear wave equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("{}-u_{tt}+u_{xx} = \\left|u\\right|^{p-1} u", block: true)]]

#text("where ")#mi("u: {\\bf R} \\times {\\bf R} \\to {\\bf R}")#text(" is the solution and ")#mi("p>1")#text(" is a fixed exponent. Nowadays, this type of equation is considered a very simple example of a non-linear wave equation (there is only one spatial dimension, the equation is semilinear, the conserved energy is positive definite and coercive, and there are no derivatives in the nonlinear term), and indeed it is not difficult to show that any solution whose conserved energy")

#align(center)[#tao-fit-display[#tao-math("E[u] := \\int_{{\\bf R}} \\frac{1}{2} \\left|u_t\\right|^2 + \\frac{1}{2} \\left|u_x\\right|^2 + \\frac{1}{p+1} \\left|u\\right|^{p+1}\\ dx", block: true)]]

#text("is finite, will exist globally for all time (and remain finite energy, of course). In particular, from the one-dimensional Gagliardo-Nirenberg inequality (a variant of the Sobolev embedding theorem), such solutions will remain uniformly bounded in ")#mi("L^\\infty_x({\\bf R})")#text(" for all time.")

#text("However, this leaves open the question of the ")#emph[#text("asymptotic")]#text(" behaviour of such solutions in the limit as ")#mi("t \\to \\infty")#text(". In higher dimensions, there are a variety of ")#emph[#text("scattering")]#text(" and ")#emph[#text("asymptotic completeness")]#text(" results which show that solutions to nonlinear wave equations such as (1) decay asymptotically in various senses, at least if one is in the ")#emph[#text("perturbative")]#text(" regime in which the solution is assumed small in some sense (e.g. small energy). For instance, a typical result might be that spatial norms such as ")#tao-math("\\left\\|u(t)\\right\\|_{L^q({\\bf R})}", block: false)#text(" might go to zero (in an average sense, at least). In general, such results for nonlinear wave equations are ultimately based on the fact that the ")#emph[#text("linear")]#text(" wave equation in higher dimensions also enjoys an analogous decay as ")#mi("t \\to +\\infty")#text(", as linear waves in higher dimensions spread out and disperse over time. (This can be formalised by decay estimates on the fundamental solution of the linear wave equation, or by basic estimates such as the (long-time) Strichartz estimates and their relatives.) The idea is then to view the nonlinear wave equation as a perturbation of the linear one.")

#text("On the other hand, the solution to the linear one-dimensional wave equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("-u_{tt} + u_{xx} = 0")]]

#text("does not exhibit any decay in time; as one learns in an undergraduate PDE class, the general (finite energy) solution to such an equation is given by the superposition of two travelling waves,")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("u(t,x) = f(x+t) + g(x-t)")]]

#text("where ")#mi("f")#text(" and ")#mi("g")#text(" also have finite energy, so in particular norms such as ")#tao-math("\\left\\|u(t)\\right\\|_{L^\\infty_x({\\bf R})}", block: false)#text(" cannot decay to zero as ")#mi("t \\to \\infty")#text(" unless the solution is completely trivial.")

#text("Nevertheless, we were able to establish a nonlinear decay effect for equation (1), caused more by the nonlinear right-hand side of (1) than by the linear left-hand side, to obtain ")#mi("L^\\infty_x({\\bf R})")#text(" decay on the average:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" (Average ")#mi("L^\\infty_x")#text(" decay) If ")#mi("u")#text(" is a finite energy solution to (1), then ")#tao-math("\\frac{1}{2T} \\int_{-T}^T \\left\\|u(t)\\right\\|_{L^\\infty_x({\\bf R})}", block: false)#text(" tends to zero as ")#mi("T \\to \\infty")#text(".")
]

#text("Actually we prove a slightly stronger statement than Theorem 1, in that the decay is uniform among all solutions with a given energy bound, but I will stick to the above formulation of the main result for simplicity.")

#text("Informally, the reason for the nonlinear decay is as follows. The linear evolution tries to force waves to move at constant velocity (indeed, from (3) we see that linear waves move at the speed of light ")#mi("c=1")#text("). But the defocusing nature of the nonlinearity will spread out any wave that is propagating along a constant velocity worldline. This intuition can be formalised by a Morawetz-type energy estimate that shows that the nonlinear potential energy must decay along any rectangular slab of spacetime (that represents the neighbourhood of a constant velocity worldline).")

#text("Now, just because the linear wave equation propagates along constant velocity worldlines, this does not mean that the nonlinear wave equation does too; one could imagine that a wave packet could propagate along a more complicated trajectory ")#mi("t \\mapsto x(t)")#text(" in which the velocity ")#mi("x^{\\prime}(t)")#text(" is not constant. However, energy methods still force the solution of the nonlinear wave equation to obey ")#emph[#text("finite speed of propagation")]#text(", which in the wave packet context means (roughly speaking) that the nonlinear trajectory ")#mi("t \\mapsto x(t)")#text(" is a Lipschitz continuous function (with Lipschitz constant at most ")#mi("1")#text(").")

#text("And now we deploy a trick which appears to be new to the field of nonlinear wave equations: we invoke the ")#link("http://en.wikipedia.org/wiki/Rademacher's_theorem")[#text("Rademacher differentiation theorem")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Lebesgue_differentiation_theorem")[#text("Lebesgue differentiation theorem")]#text("), which asserts that Lipschitz continuous functions are almost everywhere differentiable. (By coincidence, I am teaching this theorem in my current course, both in ")#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/")[#text("one dimension")]#text(" (which is the case of interest here) and ")#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/")[#text("in higher dimensions")]#text(".) A compactness argument allows one to extract a quantitative estimate from this theorem (cf. ")#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/")[#text("this earlier blog post of mine")]#text(") which, roughly speaking, tells us that there are large portions of the trajectory ")#mi("t \\mapsto x(t)")#text(" which behave approximately linearly at an appropriate scale. This turns out to be a good enough control on the trajectory that one can apply the Morawetz inequality and rule out the existence of persistent wave packets over long periods of time, which is what leads to Theorem 1.")

#text("There is still scope for further work to be done on the asymptotics. In particular, we still do not have a good understanding of what the asymptotic profile of the solution should be, even in the perturbative regime; standard nonlinear geometric optics methods do not appear to work very well due to the extremely weak decay.")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1075172adc0367bf2fc3f936f14cfdebf9a30115b7d1f71f5e22adf8ac8789b1-9bb77dd3968d49dcba8fb6871d4cadb994c433318002c62bb267211aa6dbff3f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of windfarmmusic")]], [#link("https://terrytao.wordpress.com/2010/11/03/asymptotic-decay-for-a-one-dimensional-nonlinear-wave-equation/#comment-47977")[#strong[#text("windfarmmusic")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2010")])]

#text("Typo in Theorem 1 – integral limits should be 0 to T?")

#emph[#text("[-T to T, actually. Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73ae26e337d96003f9c37524bf92581174ab96694513e1ef70c875408dda4eee-b31f45d429f6728d503ce39ebb4978c0822428741044b61cbb8c02da06bd88d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of scot")]], [#link("https://terrytao.wordpress.com/2010/11/03/asymptotic-decay-for-a-one-dimensional-nonlinear-wave-equation/#comment-47998")[#strong[#text("scot")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2010")])]

#text("near eqn 3, should “cannot decay to zero as t->0” instead be t->inf ? ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4514941d939bcef900e626ddde66fad70a4d7ce517ec98a7260ab82e54f56f4-3ec7286dccac13182ba58953e5421dd8e4bfac68008adf391d2c13c5aecfc590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hustblackcat")]], [#link("https://terrytao.wordpress.com/2010/11/03/asymptotic-decay-for-a-one-dimensional-nonlinear-wave-equation/#comment-48007")[#strong[#text("hustblackcat")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2010")])]

#text("By Sobolev embedding, ergodic theorem and your Theorem 1, then $\\lim_{t\\rightarrow \\infty} \\|u(t)\\|_{L^\\infty(R)} = 0$. It’s unbelievable. Does this equation exist a explicit solution?")#linebreak()#text(" On the other hand, if we exchange the varialbes x, t then we get a corresponding result to focusing equation. Does this display some new information?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/03/asymptotic-decay-for-a-one-dimensional-nonlinear-wave-equation/#comment-48009")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2010")])]

#text("The ergodic theorem is not directly applicable here for a number of reasons (for instance, there is no obvious invariant measure to use on the phase space (though Gibbs measure is one possible candidate); there is no guarantee that this measure would be ergodic; the ergodic theorem only controls almost all orbits, rather than all orbits; and the ergodic theorem only controls time averages of the dynamics, and not the dynamics itself).")

#text("The only known globally explicit finite energy solution for this PDE is the zero solution. One can create local explicit solutions by starting with an explicit infinite energy solution (e.g. by working with solutions that are independent of the x variable and solving the ODE) and then localising using finite speed of propagation. This technique can be used for instance to show that the focusing solutions can blow up in finite time. (There is an asymmetry here because of the initial data surface {t=0}, which is not preserved by interchanging the x and t variables.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/11/03/asymptotic-decay-for-a-one-dimensional-nonlinear-wave-equation/#comment-48028")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2010")])]

#text("Prof. Tao,")

#text("Your strong intuition for PDE come across immediately to anyone familiar with your blogs on the topic.")

#text("I am simply curious as to how you build up intuition for PDE problems. For example, in combinatorics problems one can build up intuition by getting ones hands dirty and playing around with small cases etc… This approach of looking at simple cases first caries over to many other types of problems as well.")

#text("However, for PDE problems there seems to be no analogous ‘small cases’ starting point. For example, most nonlinear PDE don’t have many, if any at all, explicit closed-form solutions for one to get their hands dirty with and gain some intuition from.")

#text("So repeating my initial question, I am simply curious how you start to think about a PDE problem and build your intuition about it?")

#text("Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/03/asymptotic-decay-for-a-one-dimensional-nonlinear-wave-equation/#comment-48038")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2010")])]

#text("Linear PDEs and nonlinear ODEs form excellent model cases with which to start understanding nonlinear PDEs. (And linear ODEs are the simplest of all, though they do not capture the full range of phenomena.) I take this perspective for instance in my nonlinear dispersive PDE book.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50ce0af4d8f4056f8d222dbcb534a22a33e34aafb25828779fb2188b36774549-77aef8e6608a22cac4dda67426fb93aad790372de669fcae235344da72f6f182.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ji Jin Tao")]], [#link("https://terrytao.wordpress.com/2010/11/03/asymptotic-decay-for-a-one-dimensional-nonlinear-wave-equation/#comment-48030")[#strong[#text("Ji Jin Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2010")])]

#text("@Anonymous: I guess you just have to be as smart as Terry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e08207609b01b3ff77c889101f1923c9255d7218f3973e17fe5bc78d0b7f68b7-5d53e31ea86fc4af3a287d73fd63dea5360d5790ea80ef208b13f8ee7860964a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mario")]], [#link("https://terrytao.wordpress.com/2010/11/03/asymptotic-decay-for-a-one-dimensional-nonlinear-wave-equation/#comment-48053")[#strong[#text("Mario")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2010")])]

#text("Hello,")#linebreak()#text(" Thank you for this very interesting posting.")

#text("Do you use computer programs to visualize the equation and its solutions in any way?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/03/asymptotic-decay-for-a-one-dimensional-nonlinear-wave-equation/#comment-48057")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2010")])]

#text("Hans and I did actually do some numerics, but it was difficult to see the asymptotic behaviour as ")#mi("t \\to +\\infty")#text(" with the computational power we had. In particular, for waves of unit amplitude and wavelength, we only got convincingly accurate numerics for two or three oscillations (i.e. t of size about 2 or 3), which did not really give much indication of anything beyond confirming the accuracy of linearised approximations at this time scale. But we did not try a fancy iteration scheme (basically a forward Euler). Presumably an adaptive mesh scheme would give better results, but by that point we had decided to rely on theoretical methods instead.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e2f4f98c9f2a2cc50ca6567bf3fb2d402f79c7250e60f492b5e78ac635c4937d-2241d5de9d170d6458bf02ee29ebee9d951594ac8fd0db2c918c2b8cf6cbb07c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Matthews")]], [#link("https://terrytao.wordpress.com/2010/11/03/asymptotic-decay-for-a-one-dimensional-nonlinear-wave-equation/#comment-48125")[#strong[#text("Paul Matthews")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2010")])]

#text("Computer programs can be useful for getting an intuition about what the solutions look like. For example, you could see numerically what the decay rate was, and then try to prove it.")#linebreak()#text(" Here is a space-time plot of the solution for p=2 with initial condition sech(x):")

#link("http://www.maths.nottingham.ac.uk/personal/pcm/nlw.jpg")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i0.wp.com/www.maths.nottingham.ac.uk/personal/pcm/nlw.jpg")[Original image]]]]

#text("You can see how the solution spreads out along the lines x = +- t and gets weaker.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82107e4192a7d0d0712810d2fbc888629ea870d4f1069955b3304d0f508e9ab6-9d6adbd323b978c92e8e75137874f245a6813e6e9a92daadf2a6c24142bf8307.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zhang")]], [#link("https://terrytao.wordpress.com/2010/11/03/asymptotic-decay-for-a-one-dimensional-nonlinear-wave-equation/#comment-48058")[#strong[#text("Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2010")])]

#text("There seems a typo in your preprint, page 5, the last equation")#linebreak()#text(" the right hand side should be (1-v^2)u_x^2+……")

#emph[#text("[Thanks! This correction will be incorporated into the next version of the paper.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/11/03/asymptotic-decay-for-a-one-dimensional-nonlinear-wave-equation/#comment-48210")[#strong[#text("Asymptotic decay for a one-dimensional nonlinear wave equation (via What's new) « 猪草草")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2010")]

#text("[…] 看看人家这blog写的。。 Hans Lindblad and I have just uploaded to the arXiv our joint paper \"Asymptotic decay for a one-dimensional nonlinear wave equation\", submitted to Analysis & PDE. This paper, to our knowledge, is the first paper to analyse the asymptotic behaviour of the one-dimensional defocusing nonlinear wave equation (1) where is the solution and is a fixe … Read More […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50ebe8746a1244ed1e5aee1bb113e6d429f93324886f1a91f0fec84ddf9d3dec-55f5f796cc5f5df2725a5e6c828aff5628ea975f430c6afec2e5512fba059e65.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Lindsay")]], [#link("https://terrytao.wordpress.com/2010/11/03/asymptotic-decay-for-a-one-dimensional-nonlinear-wave-equation/#comment-48853")[#strong[#text("Alan Lindsay")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2010")])]

#text("Another interesting phenomena associated with such PDES/ODES is singularity formation. For example, the simple ode $y’ = y^2, y(0) = y_$0 has solution $y = y_0/(1-t y_0)$ and therefore blows up at $t= 1/y_0$ whenever $y_0>0$.")

#text("An interesting question which has been well studied over the last 20 years or so is how diffusion can mitigate this blow effect. For instance does the equation.")

#tao-fit-display[#mitex("u_t = D^2 u + u^{p-1} u")]

#text("blow up or not? The differential term is the diffusion operator and therefore has a smoothing, spreading effect while the nonlinear term ( as the previous simple ode shows ) has a concentrating effect. As you might expect, the combination of these two effects creates a threshold $p_0$ such that if $p>p_0$ the solution blows up, while the solution remains smooth for $p<p_0$. The case $p=p_0$ requires special attention.")

#text("Interesting to see that the hyperbolic case is relatively unstudied. I might add that higher order PDES, i.e.")

#tao-fit-display[#mitex("u_t =  – (-D^2)^n u + f(u)")]

#text("are quite poorly understood at the moment ( see williams/ budd/ Galaktionov though ). A very interesting topic though!!")

#text("Alan")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/919ad4b08132f14e669faf510830813f5318bd8e580da5345e0361f657dc1961-3d47fbbea34243a2b7cd7583f09efbe174061587516b00301736ddb4ddde8d3f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J. M.")]], [#link("https://terrytao.wordpress.com/2010/11/03/asymptotic-decay-for-a-one-dimensional-nonlinear-wave-equation/#comment-49370")[#strong[#text("J. M.")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2011")])]

#text("Hi Terry,")

#text("I had a few questions about the proof of Lemma 3.3.")

#text("In the final paragraph, when you define \\Delta_1^{”’}, you refer to some point t’. Should this t’ be t_1 or t_2?")

#text("You also refer to times being “timelike” w.r.t. other times, and while you have previously defined timelike wordlines, I’m not sure how to read “timelike” in this case. Should one define timelike just like spacelike but with the inequality flipped, or does timelike refer to the Lipschitz condition (16) being satisfied?")

#text("Thanks! –Jason")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/03/asymptotic-decay-for-a-one-dimensional-nonlinear-wave-equation/#comment-49379")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2011")])]

#text("t’ should be t_1, and “timelike” should be “spacelike”. There are a number of other corrections of this nature which will be fixed in the next version of the paper (which I hope to put on the arXiv shortly).")
]
]
