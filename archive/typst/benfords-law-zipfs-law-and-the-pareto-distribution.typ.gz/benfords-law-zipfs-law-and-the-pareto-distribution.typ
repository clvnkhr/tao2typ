// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/
// Converted to Typst by tao2typ: "2026-10-14T15:17:20.164252+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Benford’s law, Zipf’s law, and the Pareto distribution", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Benford’s law, Zipf’s law, and the Pareto distribution")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 July 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/")[#text("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A remarkable phenomenon in probability theory is that of ")#emph[#text("universality")]#text(" – that many seemingly unrelated probability distributions, which ostensibly involve large numbers of unknown parameters, can end up converging to a universal law that may only depend on a small handful of parameters. One of the most famous examples of the universality phenomenon is the ")#link("http://en.wikipedia.org/wiki/Central_limit_theorem")[#text("central limit theorem")]#text("; another rich source of examples comes from ")#link("http://en.wikipedia.org/wiki/Random_matrix_theory")[#text("random matrix theory")]#text(", which is one of the areas of my own research.")

#text("Analogous universality phenomena also show up in ")#emph[#text("empirical")]#text(" distributions – the distributions of a statistic ")#mi("{X}")#text(" from a large population of “real-world” objects. Examples include ")#link("http://en.wikipedia.org/wiki/Benford%27s_law")[#text("Benford’s law")]#text(", ")#link("http://en.wikipedia.org/wiki/Zipf%27s_law")[#text("Zipf’s law")]#text(", and the ")#link("http://en.wikipedia.org/wiki/Pareto_distribution")[#text("Pareto distribution")]#text(" (of which the ")#link("http://en.wikipedia.org/wiki/Pareto_principle")[#text("Pareto principle")]#text(" or ")#emph[#text("80-20 law")]#text(" is a special case). These laws govern the asymptotic distribution of many statistics ")#mi("{X}")#text(" which")

#list(
[#text("(i) take values as positive numbers;")],
[#text("(ii) range over many different orders of magnitude;")],
[#text("(iiii) arise from a complicated combination of largely independent factors (with different samples of ")#mi("{X}")#text(" arising from different independent factors); and")],
[#text("(iv) have not been artificially rounded, truncated, or otherwise constrained in size.")]
)

#text("Examples here include the population of countries or cities, the frequency of occurrence of words in a language, the mass of astronomical objects, or the net worth of individuals or corporations. The laws are then as follows:")

#list(
[#strong[#text("Benford’s law:")]#text(" For ")#mi("{k=1,\\ldots,9}")#text(", the proportion of ")#mi("{X}")#text(" whose first digit is ")#mi("{k}")#text(" is approximately ")#mi("{\\log_{10} \\frac{k+1}{k}}")#text(". Thus, for instance, ")#mi("{X}")#text(" should have a first digit of ")#mi("{1}")#text(" about ")#mi("{30\\%}")#text(" of the time, but a first digit of ")#mi("{9}")#text(" only about ")#mi("{5\\%}")#text(" of the time.")],
[#strong[#text("Zipf’s law:")]#text(" The ")#mi("{n^{th}}")#text(" largest value of ")#mi("{X}")#text(" should obey an approximate power law, i.e. it should be approximately ")#mi("{C n^{-\\alpha}}")#text(" for the first few ")#mi("{n=1,2,3,\\ldots}")#text(" and some parameters ")#mi("{C, \\alpha > 0}")#text(". In many cases, ")#mi("{\\alpha}")#text(" is close to ")#mi("{1}")#text(".")],
[#strong[#text("Pareto distribution:")]#text(" The proportion of ")#mi("{X}")#text(" with at least ")#mi("{m}")#text(" digits (before the decimal point), where ")#mi("{m}")#text(" is above the median number of digits, should obey an approximate exponential law, i.e. be approximately of the form ")#mi("{c 10^{-m/\\alpha}}")#text(" for some ")#mi("{c, \\alpha > 0}")#text(". Again, in many cases ")#mi("{\\alpha}")#text(" is close to ")#mi("{1}")#text(".")]
)

#text("Benford’s law and Pareto distribution are stated here for base ")#mi("{10}")#text(", which is what we are most familiar with, but the laws hold for any base (after replacing all the occurrences of ")#mi("{10}")#text(" in the above laws with the new base, of course). The laws tend to break down if the hypotheses (i)-(iv) are dropped. For instance, if the statistic ")#mi("{X}")#text(" concentrates around its mean (as opposed to being spread over many orders of magnitude), then the ")#link("http://en.wikipedia.org/wiki/Normal_distribution")[#text("normal distribution")]#text(" tends to be a much better model (as indicated by such results as the central limit theorem). If instead the various samples of the statistics are highly correlated with each other, then other laws can arise (for instance, the eigenvalues of a random matrix, as well as many empirically observed matrices, are correlated to each other, with the behaviour of the largest eigenvalues being governed by laws such as the ")#emph[#text("Tracy-Widom law")]#text(" rather than Zipf’s law, and the bulk distribution being governed by laws such as the ")#link("http://en.wikipedia.org/wiki/Wigner_semicircle_distribution")[#text("semicircular law")]#text(" rather than the normal or Pareto distributions).")

#text("To illustrate these laws, let us take as a data set the populations of 235 countries and regions of the world in 2007 (using the ")#link("http://www.umsl.edu/services/govdocs/wofact2007/index.html")[#text("CIA world factbook")]#text("); I have put the raw data ")#link("http://spreadsheets.google.com/pub?key=rj_3TkLJrrVuvOXkijCHelQ&output=html")[#text("here")]#text(". This is a relatively small sample (cf. ")#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/")[#text("my previous post")]#text("), but is already enough to discern these laws in action. For instance, here is how the data set tracks with Benford’s law (rounded to three significant figures):")

#table(columns: 4, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#mi("{k}")],
table.cell(colspan: 1, rowspan: 1)[#text("Countries")],
table.cell(colspan: 1, rowspan: 1)[#text("Number")],
table.cell(colspan: 1, rowspan: 1)[#text("Benford prediction")],
table.cell(colspan: 1, rowspan: 1)[#text("1")],
table.cell(colspan: 1, rowspan: 1)[#text("Angola, Anguilla, Aruba, Bangladesh, Belgium, Botswana, Brazil, Burkina Faso, Cambodia, Cameroon, Chad, Chile, China, Christmas Island, Cook Islands, Cuba, Czech Republic, Ecuador, Estonia, Gabon, (The) Gambia, Greece, Guam, Guatemala, Guinea-Bissau, India, Japan, Kazakhstan, Kiribati, Malawi, Mali, Mauritius, Mexico, (Federated States of) Micronesia, Nauru, Netherlands, Niger, Nigeria, Niue, Pakistan, Portugal, Russia, Rwanda, Saint Lucia, Saint Vincent and the Grenadines, Senegal, Serbia, Swaziland, Syria, Timor-Leste (East-Timor), Tokelau, Tonga, Trinidad and Tobago, Tunisia, Tuvalu, (U.S.) Virgin Islands, Wallis and Futuna, Zambia, Zimbabwe")],
table.cell(colspan: 1, rowspan: 1)[#text("59 (")#mi("{25.1\\%}")#text(")")],
table.cell(colspan: 1, rowspan: 1)[#text("71 (")#mi("{30.1\\%}")#text(")")],
table.cell(colspan: 1, rowspan: 1)[#text("2")],
table.cell(colspan: 1, rowspan: 1)[#text("Armenia, Australia, Barbados, British Virgin Islands, Cote d’Ivoire, French Polynesia, Ghana, Gibraltar, Indonesia, Iraq, Jamaica, (North) Korea, Kosovo, Kuwait, Latvia, Lesotho, Macedonia, Madagascar, Malaysia, Mayotte, Mongolia, Mozambique, Namibia, Nepal, Netherlands Antilles, New Caledonia Norfolk Island, Palau, Peru, Romania, Saint Martin, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Slovenia, Sri Lanka, Svalbard, Taiwan, Turks and Caicos Islands, Uzbekistan, Vanuatu, Venezuela, Yemen")],
table.cell(colspan: 1, rowspan: 1)[#text("44 (")#mi("{18.7\\%}")#text(")")],
table.cell(colspan: 1, rowspan: 1)[#text("41 (")#mi("{17.6\\%}")#text(")")],
table.cell(colspan: 1, rowspan: 1)[#text("3")],
table.cell(colspan: 1, rowspan: 1)[#text("Afghanistan, Albania, Algeria, (The) Bahamas, Belize, Brunei, Canada, (Rep. of the) Congo, Falkland Islands (Islas Malvinas), Iceland, Kenya, Lebanon, Liberia, Liechtenstein, Lithuania, Maldives, Mauritania, Monaco, Morocco, Oman, (Occupied) Palestinian Territory, Panama, Poland, Puerto Rico, Saint Kitts and Nevis, Uganda, United States of America, Uruguay, Western Sahara")],
table.cell(colspan: 1, rowspan: 1)[#text("29 (")#mi("{12.3\\%}")#text(")")],
table.cell(colspan: 1, rowspan: 1)[#text("29 (")#mi("{12.5\\%}")#text(")")],
table.cell(colspan: 1, rowspan: 1)[#text("4")],
table.cell(colspan: 1, rowspan: 1)[#text("Argentina, Bosnia and Herzegovina, Burma (Myanmar), Cape Verde, Cayman Islands, Central African Republic, Colombia, Costa Rica, Croatia, Faroe Islands, Georgia, Ireland, (South) Korea, Luxembourg, Malta, Moldova, New Zealand, Norway, Pitcairn Islands, Singapore, South Africa, Spain, Sudan, Suriname, Tanzania, Ukraine, United Arab Emirates")],
table.cell(colspan: 1, rowspan: 1)[#text("27 (")#mi("{11.4\\%}")#text(")")],
table.cell(colspan: 1, rowspan: 1)[#text("22 (")#mi("{9.7\\%}")#text(")")],
table.cell(colspan: 1, rowspan: 1)[#text("5")],
table.cell(colspan: 1, rowspan: 1)[#text("(Macao SAR) China, Cocos Islands, Denmark, Djibouti, Eritrea, Finland, Greenland, Italy, Kyrgyzstan, Montserrat, Nicaragua, Papua New Guinea, Slovakia, Solomon Islands, Togo, Turkmenistan")],
table.cell(colspan: 1, rowspan: 1)[#text("16 (")#mi("{6.8\\%}")#text(")")],
table.cell(colspan: 1, rowspan: 1)[#text("19 (")#mi("{7.9\\%}")#text(")")],
table.cell(colspan: 1, rowspan: 1)[#text("6")],
table.cell(colspan: 1, rowspan: 1)[#text("American Samoa, Bermuda, Bhutan, (Dem. Rep. of the) Congo, Equatorial Guinea, France, Guernsey, Iran, Jordan, Laos, Libya, Marshall Islands, Montenegro, Paraguay, Sierra Leone, Thailand, United Kingdom")],
table.cell(colspan: 1, rowspan: 1)[#text("17 (")#mi("{7.2\\%}")#text(")")],
table.cell(colspan: 1, rowspan: 1)[#text("16 (")#mi("{6.7\\%}")#text(")")],
table.cell(colspan: 1, rowspan: 1)[#text("7")],
table.cell(colspan: 1, rowspan: 1)[#text("Bahrain, Bulgaria, (Hong Kong SAR) China, Comoros, Cyprus, Dominica, El Salvador, Guyana, Honduras, Israel, (Isle of) Man, Saint Barthelemy, Saint Helena, Saint Pierre and Miquelon, Switzerland, Tajikistan, Turkey")],
table.cell(colspan: 1, rowspan: 1)[#text("17 (")#mi("{7.2\\%}")#text(")")],
table.cell(colspan: 1, rowspan: 1)[#text("14 (")#mi("{5.8\\%}")#text(")")],
table.cell(colspan: 1, rowspan: 1)[#text("8")],
table.cell(colspan: 1, rowspan: 1)[#text("Andorra, Antigua and Barbuda, Austria, Azerbaijan, Benin, Burundi, Egypt, Ethiopia, Germany, Haiti, Holy See (Vatican City), Northern Mariana Islands, Qatar, Seychelles, Vietnam")],
table.cell(colspan: 1, rowspan: 1)[#text("15 (")#mi("{6.4\\%}")#text(")")],
table.cell(colspan: 1, rowspan: 1)[#text("12 (")#mi("{5.1\\%}")#text(")")],
table.cell(colspan: 1, rowspan: 1)[#text("9")],
table.cell(colspan: 1, rowspan: 1)[#text("Belarus, Bolivia, Dominican Republic, Fiji, Grenada, Guinea, Hungary, Jersey, Philippines, Somalia, Sweden")],
table.cell(colspan: 1, rowspan: 1)[#text("11 (")#mi("{4.5\\%}")#text(")")],
table.cell(colspan: 1, rowspan: 1)[#text("11 (")#mi("{4.6\\%}")#text(")")]
)

#text("Here is how the same data tracks Zipf’s law for the first twenty values of ")#mi("{n}")#text(", with the parameters ")#mi("{C \\approx 1.28 \\times 10^9}")#text(" and ")#mi("{\\alpha \\approx 1.03}")#text(" (selected by log-linear regression), again rounding to three significant figures:")

#table(columns: 5, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#mi("{n}")],
table.cell(colspan: 1, rowspan: 1)[#text("Country")],
table.cell(colspan: 1, rowspan: 1)[#text("Population")],
table.cell(colspan: 1, rowspan: 1)[#text("Zipf prediction")],
table.cell(colspan: 1, rowspan: 1)[#text("Deviation from prediction")],
table.cell(colspan: 1, rowspan: 1)[#text("1")],
table.cell(colspan: 1, rowspan: 1)[#text("China")],
table.cell(colspan: 1, rowspan: 1)[#text("1,330,000,000")],
table.cell(colspan: 1, rowspan: 1)[#text("1,280,000,000")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+4.1\\%}")],
table.cell(colspan: 1, rowspan: 1)[#text("2")],
table.cell(colspan: 1, rowspan: 1)[#text("India")],
table.cell(colspan: 1, rowspan: 1)[#text("1,150,000,000")],
table.cell(colspan: 1, rowspan: 1)[#text("626,000,000")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+83.5\\%}")],
table.cell(colspan: 1, rowspan: 1)[#text("3")],
table.cell(colspan: 1, rowspan: 1)[#text("USA")],
table.cell(colspan: 1, rowspan: 1)[#text("304,000,000")],
table.cell(colspan: 1, rowspan: 1)[#text("412,000,000")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-26.3\\%}")],
table.cell(colspan: 1, rowspan: 1)[#text("4")],
table.cell(colspan: 1, rowspan: 1)[#text("Indonesia")],
table.cell(colspan: 1, rowspan: 1)[#text("238,000,000")],
table.cell(colspan: 1, rowspan: 1)[#text("307,000,000")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-22.5\\%}")],
table.cell(colspan: 1, rowspan: 1)[#text("5")],
table.cell(colspan: 1, rowspan: 1)[#text("Brazil")],
table.cell(colspan: 1, rowspan: 1)[#text("196,000,000")],
table.cell(colspan: 1, rowspan: 1)[#text("244,000,000")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-19.4\\%}")],
table.cell(colspan: 1, rowspan: 1)[#text("6")],
table.cell(colspan: 1, rowspan: 1)[#text("Pakistan")],
table.cell(colspan: 1, rowspan: 1)[#text("173,000,000")],
table.cell(colspan: 1, rowspan: 1)[#text("202,000,000")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-14.4\\%}")],
table.cell(colspan: 1, rowspan: 1)[#text("7")],
table.cell(colspan: 1, rowspan: 1)[#text("Bangladesh")],
table.cell(colspan: 1, rowspan: 1)[#text("154,000,000")],
table.cell(colspan: 1, rowspan: 1)[#text("172,000,000")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-10.9\\%}")],
table.cell(colspan: 1, rowspan: 1)[#text("8")],
table.cell(colspan: 1, rowspan: 1)[#text("Nigeria")],
table.cell(colspan: 1, rowspan: 1)[#text("146,000,000")],
table.cell(colspan: 1, rowspan: 1)[#text("150,000,000")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-2.6\\%}")],
table.cell(colspan: 1, rowspan: 1)[#text("9")],
table.cell(colspan: 1, rowspan: 1)[#text("Russia")],
table.cell(colspan: 1, rowspan: 1)[#text("141,000,000")],
table.cell(colspan: 1, rowspan: 1)[#text("133,000,000")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+5.8\\%}")],
table.cell(colspan: 1, rowspan: 1)[#text("10")],
table.cell(colspan: 1, rowspan: 1)[#text("Japan")],
table.cell(colspan: 1, rowspan: 1)[#text("128,000,000")],
table.cell(colspan: 1, rowspan: 1)[#text("120,000,000")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+6.7\\%}")],
table.cell(colspan: 1, rowspan: 1)[#text("11")],
table.cell(colspan: 1, rowspan: 1)[#text("Mexico")],
table.cell(colspan: 1, rowspan: 1)[#text("110,000,000")],
table.cell(colspan: 1, rowspan: 1)[#text("108,000,000")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+1.7\\%}")],
table.cell(colspan: 1, rowspan: 1)[#text("12")],
table.cell(colspan: 1, rowspan: 1)[#text("Philippines")],
table.cell(colspan: 1, rowspan: 1)[#text("96,100,000")],
table.cell(colspan: 1, rowspan: 1)[#text("98,900,000")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-2.9\\%}")],
table.cell(colspan: 1, rowspan: 1)[#text("13")],
table.cell(colspan: 1, rowspan: 1)[#text("Vietnam")],
table.cell(colspan: 1, rowspan: 1)[#text("86,100,000")],
table.cell(colspan: 1, rowspan: 1)[#text("91,100,000")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-5.4\\%}")],
table.cell(colspan: 1, rowspan: 1)[#text("14")],
table.cell(colspan: 1, rowspan: 1)[#text("Ethiopia")],
table.cell(colspan: 1, rowspan: 1)[#text("82,600,000")],
table.cell(colspan: 1, rowspan: 1)[#text("84,400,000")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-2.1\\%}")],
table.cell(colspan: 1, rowspan: 1)[#text("15")],
table.cell(colspan: 1, rowspan: 1)[#text("Germany")],
table.cell(colspan: 1, rowspan: 1)[#text("82,400,000")],
table.cell(colspan: 1, rowspan: 1)[#text("78,600,000")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+4.8\\%}")],
table.cell(colspan: 1, rowspan: 1)[#text("16")],
table.cell(colspan: 1, rowspan: 1)[#text("Egypt")],
table.cell(colspan: 1, rowspan: 1)[#text("81,700,000")],
table.cell(colspan: 1, rowspan: 1)[#text("73,500,000")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+11.1\\%}")],
table.cell(colspan: 1, rowspan: 1)[#text("17")],
table.cell(colspan: 1, rowspan: 1)[#text("Turkey")],
table.cell(colspan: 1, rowspan: 1)[#text("71,900,000")],
table.cell(colspan: 1, rowspan: 1)[#text("69,100,000")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+4.1\\%}")],
table.cell(colspan: 1, rowspan: 1)[#text("18")],
table.cell(colspan: 1, rowspan: 1)[#text("Congo")],
table.cell(colspan: 1, rowspan: 1)[#text("66,500,000")],
table.cell(colspan: 1, rowspan: 1)[#text("65,100,000")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+2.2\\%}")],
table.cell(colspan: 1, rowspan: 1)[#text("19")],
table.cell(colspan: 1, rowspan: 1)[#text("Iran")],
table.cell(colspan: 1, rowspan: 1)[#text("65,900,000")],
table.cell(colspan: 1, rowspan: 1)[#text("61,600,000")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+6.9\\%}")],
table.cell(colspan: 1, rowspan: 1)[#text("20")],
table.cell(colspan: 1, rowspan: 1)[#text("Thailand")],
table.cell(colspan: 1, rowspan: 1)[#text("65,500,000")],
table.cell(colspan: 1, rowspan: 1)[#text("58,400,000")],
table.cell(colspan: 1, rowspan: 1)[#mi("{+12.1\\%}")]
)

#text("As one sees, Zipf’s law is not particularly precise at the extreme edge of the statistics (when ")#mi("{n}")#text(" is very small), but becomes reasonably accurate (given the small sample size, and given that we are fitting twenty data points using only two parameters) for moderate sizes of ")#mi("{n}")#text(".")

#text("This data set has too few scales in base ")#mi("{10}")#text(" to illustrate the Pareto distribution effectively – over half of the country populations are either seven or eight digits in that base. But if we instead work in base ")#mi("{2}")#text(", then country populations range in a decent number of scales (the majority of countries have population between ")#mi("{2^{23}}")#text(" and ")#mi("{2^{32}}")#text("), and we begin to see the law emerge, where ")#mi("{m}")#text(" is now the number of digits in binary, the best-fit parameters are ")#mi("{\\alpha \\approx 1.18}")#text(" and ")#mi("{c \\approx 1.7 \\times 2^{26} / 235}")#text(":")

#table(columns: 4, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#mi("{m}")],
table.cell(colspan: 1, rowspan: 1)[#text("Countries with ")#mi("{\\geq m}")#text(" binary digit populations")],
table.cell(colspan: 1, rowspan: 1)[#text("Number")],
table.cell(colspan: 1, rowspan: 1)[#text("Pareto prediction")],
table.cell(colspan: 1, rowspan: 1)[#text("31")],
table.cell(colspan: 1, rowspan: 1)[#text("China, India")],
table.cell(colspan: 1, rowspan: 1)[#text("2")],
table.cell(colspan: 1, rowspan: 1)[#text("1")],
table.cell(colspan: 1, rowspan: 1)[#text("30")],
table.cell(colspan: 1, rowspan: 1)[#text("”")],
table.cell(colspan: 1, rowspan: 1)[#text("2")],
table.cell(colspan: 1, rowspan: 1)[#text("2")],
table.cell(colspan: 1, rowspan: 1)[#text("29")],
table.cell(colspan: 1, rowspan: 1)[#text("“, United States of America")],
table.cell(colspan: 1, rowspan: 1)[#text("3")],
table.cell(colspan: 1, rowspan: 1)[#text("5")],
table.cell(colspan: 1, rowspan: 1)[#text("28")],
table.cell(colspan: 1, rowspan: 1)[#text("“, Indonesia, Brazil, Pakistan, Bangladesh, Nigeria, Russia")],
table.cell(colspan: 1, rowspan: 1)[#text("9")],
table.cell(colspan: 1, rowspan: 1)[#text("8")],
table.cell(colspan: 1, rowspan: 1)[#text("27")],
table.cell(colspan: 1, rowspan: 1)[#text("“, Japan, Mexico, Philippines, Vietnam, Ethiopia, Germany, Egypt, Turkey")],
table.cell(colspan: 1, rowspan: 1)[#text("17")],
table.cell(colspan: 1, rowspan: 1)[#text("15")],
table.cell(colspan: 1, rowspan: 1)[#text("26")],
table.cell(colspan: 1, rowspan: 1)[#text("“, (Dem. Rep. of the) Congo, Iran, Thailand, France, United Kingdom, Italy, South Africa, (South) Korea, Burma (Myanmar), Ukraine, Colombia, Spain, Argentina, Sudan, Tanzania, Poland, Kenya, Morocco, Algeria")],
table.cell(colspan: 1, rowspan: 1)[#text("36")],
table.cell(colspan: 1, rowspan: 1)[#text("27")],
table.cell(colspan: 1, rowspan: 1)[#text("25")],
table.cell(colspan: 1, rowspan: 1)[#text("“, Canada, Afghanistan, Uganda, Nepal, Peru, Iraq, Saudi Arabia, Uzbekistan, Venezuela, Malaysia, (North) Korea, Ghana, Yemen, Taiwan, Romania, Mozambique, Sri Lanka, Australia, Cote d’Ivoire, Madagascar, Syria, Cameroon")],
table.cell(colspan: 1, rowspan: 1)[#text("58")],
table.cell(colspan: 1, rowspan: 1)[#text("49")],
table.cell(colspan: 1, rowspan: 1)[#text("24")],
table.cell(colspan: 1, rowspan: 1)[#text("“, Netherlands, Chile, Kazakhstan, Burkina Faso, Cambodia, Malawi, Ecuador, Niger, Guatemala, Senegal, Angola, Mali, Zambia, Cuba, Zimbabwe, Greece, Portugal, Belgium, Tunisia, Czech Republic, Rwanda, Serbia, Chad, Hungary, Guinea, Belarus, Somalia, Dominican Republic, Bolivia, Sweden, Haiti, Burundi, Benin")],
table.cell(colspan: 1, rowspan: 1)[#text("91")],
table.cell(colspan: 1, rowspan: 1)[#text("88")],
table.cell(colspan: 1, rowspan: 1)[#text("23")],
table.cell(colspan: 1, rowspan: 1)[#text("“, Austria, Azerbaijan, Honduras, Switzerland, Bulgaria, Tajikistan, Israel, El Salvador, (Hong Kong SAR) China, Paraguay, Laos, Sierra Leone, Jordan, Libya, Papua New Guinea, Togo, Nicaragua, Eritrea, Denmark, Slovakia, Kyrgyzstan, Finland, Turkmenistan, Norway, Georgia, United Arab Emirates, Singapore, Bosnia and Herzegovina, Croatia, Central African Republic, Moldova, Costa Rica")],
table.cell(colspan: 1, rowspan: 1)[#text("123")],
table.cell(colspan: 1, rowspan: 1)[#text("159")]
)

#text("Thus, with each new scale, the number of countries introduced increases by a factor of a little less than ")#mi("{2}")#text(", on the average. This approximate doubling of countries with each new scale begins to falter at about the population ")#mi("{2^{23}}")#text(" (i.e. at around ")#mi("{4}")#text(" million), for the simple reason that one has begun to run out of countries. (Note that the median-population country in this set, Singapore, has a population with ")#mi("{23}")#text(" binary digits.)")

#text("These laws are not merely interesting statistical curiosities; for instance, Benford’s law is often used to help detect fraudulent statistics (such as those arising from accounting fraud), as many such statistics are invented by choosing digits at random, and will therefore deviate significantly from Benford’s law. (This is nicely discussed in Robert Matthews’ New Scientist article “")#link("http://www.newscientist.com/article/mg16321944.600")[#text("The power of one")]#text("“; this article can also be found on the web at a number of other places.) In a somewhat analogous spirit, Zipf’s law and the Pareto distribution can be used to mathematically test various models of real-world systems (e.g. formation of astronomical objects, accumulation of wealth, population growth of countries, etc.), without necessarily having to fit all the parameters of that model with the actual data.")

#text("Being empirically observed phenomena rather than abstract mathematical facts, Benford’s law, Zipf’s law, and the Pareto distribution cannot be “proved” the same way a mathematical theorem can be proved. However, one can still ")#emph[#text("support")]#text(" these laws mathematically in a number of ways, for instance showing how these laws are compatible with each other, and with other plausible hypotheses on the source of the data. In this post I would like to describe a number of ways (both technical and non-technical) in which one can do this; these arguments do not fully explain these laws (in particular, the empirical fact that the exponent ")#mi("{\\alpha}")#text(" in Zipf’s law or the Pareto distribution is often close to ")#mi("{1}")#text(" is still quite a mysterious phenomenon), and do not always have the same universal range of applicability as these laws seem to have, but I hope that they do demonstrate that these laws are not completely arbitrary, and ought to have a satisfactory basis of mathematical support. ")#metadata(none) <tao-60805dbdc6180272dd68>

#heading(level: 1)[#strong[#text(" — 1. Scale invariance — ")]]

#text("One consistency check that is enjoyed by all of these laws is that of ")#emph[#text("scale invariance")]#text(" – they are invariant under rescalings of the data (for instance, by changing the units).")

#text("For example, suppose for sake of argument that the country populations ")#mi("{X}")#text(" of the world in 2007 obey Benford’s law, thus for instance about ")#mi("{30.1\\%}")#text(" of the countries have population with first digit ")#mi("{1}")#text(", ")#mi("{17.6\\%}")#text(" have population with first digit ")#mi("{2}")#text(", and so forth. Now, imagine that several decades in the future, say in 2067, all of the countries in the world double their population, from ")#mi("{X}")#text(" to a new population ")#mi("{\\tilde X := 2X}")#text(". (This makes the somewhat implausible assumption that growth rates are uniform across all countries; I will talk about what happens when one omits this hypothesis later.) To further simplify the experiment, suppose that no countries are created or dissolved during this time period. What happens to Benford’s law when passing from ")#mi("{X}")#text(" to ")#mi("{\\tilde X}")#text("?")

#text("The key observation here, of course, is that the first digit of ")#mi("{X}")#text(" is linked to the first digit of ")#mi("{\\tilde X = 2X}")#text(". If, for instance, the first digit of ")#mi("{X}")#text(" is ")#mi("{1}")#text(", then the first digit of ")#mi("{\\tilde X}")#text(" is either ")#mi("{2}")#text(" or ")#mi("{3}")#text("; conversely, if the first digit of ")#mi("{\\tilde X}")#text(" is ")#mi("{2}")#text(" or ")#mi("{3}")#text(", then the first digit of ")#mi("{X}")#text(" is ")#mi("{1}")#text(". As a consequence, the proportion of ")#mi("{X}")#text("‘s with first digit ")#mi("{1}")#text(" is equal to the proportion of ")#mi("{\\tilde X}")#text("‘s with first digit ")#mi("{2}")#text(", plus the proportion of ")#mi("{\\tilde X}")#text("‘s with first digit ")#mi("{3}")#text(". This is consistent with Benford’s law holding for both ")#mi("{X}")#text(" and ")#mi("{\\tilde X}")#text(", since")

#align(center)[#tao-fit-display[#mitex("\\log_{10} \\frac{2}{1} = \\log_{10} \\frac{3}{2} + \\log_{10} \\frac{4}{3} ( = \\log_{10} \\frac{4}{2} )")]]

#text("(or numerically, ")#mi("{30.1\\% = 17.6\\% + 12.5\\%}")#text(" after rounding). Indeed one can check the other digit ranges also and that conclude that Benford’s law for ")#mi("{X}")#text(" is compatible with Benford’s law for ")#mi("{\\tilde X}")#text("; to pick a contrasting example, a uniformly distributed model in which each digit from ")#mi("{1}")#text(" to ")#mi("{9}")#text(" is the first digit of ")#mi("{X}")#text(" occurs with probability ")#mi("{1/9}")#text(" totally fails to be preserved under doubling.")

#text("One can be even more precise. Observe (through telescoping series) that Benford’s law implies that ")#metadata(none) <tao-50630d3e3fcfaeda314d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("{\\Bbb P}( \\alpha 10^n \\leq X < \\beta 10^n \\text{ for some integer } n ) = \\log_{10} \\frac{\\beta}{\\alpha}")]]

#text("for all integers ")#mi("{1 \\leq \\alpha \\leq \\beta < 10}")#text(", where the left-hand side denotes the proportion of data for which ")#mi("{X}")#text(" lies between ")#mi("{\\alpha 10^n}")#text(" and ")#mi("{\\beta 10^n}")#text(" for some integer ")#mi("{n}")#text(". Suppose now that we generalise Benford’s law to the ")#emph[#text("continuous Benford’s law")]#text(", which asserts that ")#link(<tao-50630d3e3fcfaeda314d>)[#text("(1)")]#text(" is true for all ")#emph[#text("real")]#text(" numbers ")#mi("{1 \\leq \\alpha \\leq \\beta < 10}")#text(". Then it is not hard to show that a statistic ")#mi("{X}")#text(" obeys the continuous Benford’s law if and only if its dilate ")#mi("{\\tilde X =2X}")#text(" does, and similarly with ")#mi("{2}")#text(" replaced by any other constant growth factor. (This is easiest seen by observing that ")#link(<tao-50630d3e3fcfaeda314d>)[#text("(1)")]#text(" is equivalent to asserting that the fractional part of ")#mi("{\\log_{10} X}")#text(" is uniformly distributed.) In fact, the continuous Benford law is the ")#emph[#text("only")]#text(" distribution for the quantities on the left-hand side of ")#link(<tao-50630d3e3fcfaeda314d>)[#text("(1)")]#text(" with this scale-invariance property; this fact is a special case of the general fact that Haar measures are unique (see e.g. ")#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/")[#text("these lecture notes")]#text(").")

#text("It is also easy to see that Zipf’s law and the Pareto distribution also enjoy this sort of scale-invariance property, as long as one generalises the Pareto distribution ")#metadata(none) <tao-80e45578c9a98a2018fd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("{\\Bbb P}( X \\geq 10^m ) = c 10^{-m/\\alpha}")]]

#text("from integer ")#mi("{m}")#text(" to real ")#mi("{m}")#text(", just as with Benford’s law. Once one does that, one can phrase the Pareto distribution law independently of any base as ")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("{\\Bbb P}( X \\geq x ) = c x^{-1/\\alpha}")]]

#text("for any ")#mi("{x}")#text(" much larger than the median value of ")#mi("{X}")#text(", at which point the scale-invariance is easily seen.")

#text("One may object that the above thought-experiment was too idealised, because it assumed uniform growth rates for all the statistics at once. What happens if there are non-uniform growth rates? To keep the computations simple, let us consider the following toy model, where we take the same 2007 population statistics ")#mi("{X}")#text(" as before, and assume that half of the countries (the “high-growth” countries) will experience a population doubling by 2067, while the other half (the “zero-growth” countries) will keep their population constant, thus the 2067 population statistic ")#mi("{\\tilde X}")#text(" is equal to ")#mi("{2X}")#text(" half the time and ")#mi("{X}")#text(" half the time. (We will assume that our sample sizes are large enough that the ")#link("http://en.wikipedia.org/wiki/Law_of_large_numbers")[#text("law of large numbers")]#text(" kicks in, and we will therefore ignore issues such as what happens to this “half the time” if the number of samples is odd.) Furthermore, we make the plausible but crucial assumption that the event that a country is a high-growth or a zero-growth country is ")#emph[#text("independent")]#text(" of the first digit of the 2007 population; thus, for instance, a country whose population begins with ")#mi("{3}")#text(" is assumed to be just as likely to be high-growth as one whose population begins with ")#mi("{7}")#text(".")

#text("Now let’s have a look again at the proportion of countries whose 2067 population ")#mi("{\\tilde X}")#text(" begins with either ")#mi("{2}")#text(" or ")#mi("{3}")#text(". There are exactly two ways in which a country can fall into this category: either it is a zero-growth country whose 2007 population ")#mi("{X}")#text(" also began with either ")#mi("{2}")#text(" or ")#mi("{3}")#text(", or it was a high-growth country whose population in 2007 began with ")#mi("{1}")#text(". Since all countries have a probability ")#mi("{1/2}")#text(" of being high-growth regardless of the first digit of their population, we conclude the identity ")#metadata(none) <tao-6ee2cc105a67743140cf>

#tao-aligned(keep: true)[


#tao-math("{\\Bbb P}( \\tilde X \\text{ has first digit } 2, 3 )  & = \\frac{1}{2} {\\Bbb P}( X \\text{ has first digit } 2, 3 )", block: true, numbering: n => [#text("(4)")])



#tao-math(" & + \\frac{1}{2} {\\Bbb P}( X \\text{ has first digit } 1 )", block: true)
]

#text("which is once again compatible with Benford’s law for ")#mi("{\\tilde X}")#text(" since")

#align(center)[#tao-fit-display[#mitex("\\log_{10} \\frac{4}{2} = \\frac{1}{2} \\log_{10} \\frac{4}{2} + \\frac{1}{2} \\log \\frac{2}{1}.")]]

#text("More generally, it is not hard to show that if ")#mi("{X}")#text(" obeys the continuous Benford’s law ")#link(<tao-50630d3e3fcfaeda314d>)[#text("(1)")]#text(", and one multiplies ")#mi("{X}")#text(" by some positive multiplier ")#mi("{Y}")#text(" which is independent of the first digit of ")#mi("{X}")#text(" (and, ")#emph[#text("a fortiori")]#text(", is independent of the fractional part of ")#mi("{\\log_{10} X}")#text("), one obtains another quantity ")#mi("{\\tilde X=XY}")#text(" which also obeys the continuous Benford’s law. (Indeed, we have already seen this to be the case when ")#mi("{Y}")#text(" is a deterministic constant, and the case when ")#mi("{Y}")#text(" is random then follows simply by conditioning ")#mi("{Y}")#text(" to be fixed.)")

#text("In particular, we see an absorptive property of Benford’s law: if ")#mi("{X}")#text(" obeys Benford’s law, and ")#mi("{Y}")#text(" is any positive statistic independent of ")#mi("{X}")#text(", then the product ")#mi("{\\tilde X=XY}")#text(" also obeys Benford’s law – ")#emph[#text("even if ")#mi("{Y}")#text(" did not obey this law")]#text(". Thus, if a statistic is the product of many independent factors, then it only requires a single factor to obey Benford’s law in order for the whole product to obey the law also. For instance, the population of a country is the product of its area and its population density. Assuming that the population density of a country is independent of the size of that country (which is not a completely reasonable assumption, but let us take it for the sake of argument), then we see that Benford’s law for the population would follow if just one of the area or population density obeyed this law. It is also clear that Benford’s law is the only distribution with this absorptive property (if there was another law with this property, what would happen if one multiplied a statistic with that law with an independent statistic with Benford’s law?). Thus we begin to get a glimpse as to why Benford’s law is universal for quantities which are the product of many separate factors, in a manner that no other law could be.")

#text("As an example: for any given number ")#mi("{N}")#text(", the uniform distribution from ")#mi("{1}")#text(" to ")#mi("{N}")#text(" does not obey Benford’s law; for instance, if one picks a random number from ")#mi("{1}")#text(" to ")#mi("{999,999}")#text(" then each digit from ")#mi("{1}")#text(" to ")#mi("{9}")#text(" appears as the first digit with an equal probability of ")#mi("{1/9}")#text(" each. However, if ")#mi("{N}")#text(" is not fixed, but instead obeys Benford’s law, then a random number selected from ")#mi("{1}")#text(" to ")#mi("{N}")#text(" also obeys Benford’s law (ignoring for now the distinction between continuous and discrete distributions), as it can be viewed as the product of ")#mi("{N}")#text(" with an independent random number selected from between ")#mi("{0}")#text(" and ")#mi("{1}")#text(".")

#text("Actually, one can say something even stronger than the absorption property. Suppose that the continuous Benford’s law ")#link(<tao-50630d3e3fcfaeda314d>)[#text("(1)")]#text(" for a statistic ")#mi("{X}")#text(" did not hold exactly, but instead held with some accuracy ")#mi("{\\varepsilon > 0}")#text(", thus ")#metadata(none) <tao-56d6d59352153f0a2f87>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\log_{10} \\frac{\\beta}{\\alpha} - \\varepsilon \\leq {\\Bbb P}( \\alpha 10^n \\leq X < \\beta 10^n \\text{ for some integer } n ) \\leq \\log_{10} \\frac{\\beta}{\\alpha} + \\varepsilon")]]

#text("for all ")#mi("{1 \\leq \\alpha \\leq \\beta < 10}")#text(". Then it is not hard to see that any dilated statistic, such as ")#mi("{\\tilde X = 2X}")#text(", or more generally ")#mi("{\\tilde X=XY}")#text(" for any fixed deterministic ")#mi("{Y}")#text(", also obeys ")#link(<tao-56d6d59352153f0a2f87>)[#text("(5)")]#text(" with exactly the same accuracy ")#mi("{\\varepsilon}")#text(". But now suppose one uses a variable multiplier; for instance, suppose one uses the model discussed earlier in which ")#mi("{\\tilde X}")#text(" is equal to ")#mi("{2X}")#text(" half the time and ")#mi("{X}")#text(" half the time. Then the relationship between the distribution of the first digit of ")#mi("{\\tilde X}")#text(" and the first digit of ")#mi("{X}")#text(" is given by formulae such as ")#link(<tao-6ee2cc105a67743140cf>)[#text("(4)")]#text(". Now, in the right-hand side of ")#link(<tao-6ee2cc105a67743140cf>)[#text("(4)")]#text(", each of the two terms ")#mi("{{\\Bbb P}( X \\text{ has first digit } 2, 3 )}")#text(" and ")#mi("{{\\Bbb P}( X \\text{ has first digit } 1 )}")#text(" differs from the Benford’s law predictions of ")#mi("{\\log_{10} \\frac{4}{2}}")#text(" and ")#mi("{\\log_{10} \\frac{2}{1}}")#text(" respectively by at most ")#mi("{\\varepsilon}")#text(". Since the left-hand side of ")#link(<tao-6ee2cc105a67743140cf>)[#text("(4)")]#text(" is the average of these two terms, it also differs from the Benford law prediction by at most ")#mi("{\\varepsilon}")#text(". But the averaging opens up an opportunity for cancelling; for instance, an overestimate of ")#mi("{+\\varepsilon}")#text(" for ")#mi("{{\\Bbb P}( X \\text{ has first digit } 2, 3 )}")#text(" could cancel an underestimate of ")#mi("{-\\varepsilon}")#text(" for ")#mi("{{\\Bbb P}( X \\text{ has first digit } 1 )}")#text(" to produce a spot-on prediction for ")#mi("{\\tilde X}")#text(". Thus we see that variable multipliers (or variable growth rates) not only preserve Benford’s law, but in fact ")#emph[#text("stabilise")]#text(" it by averaging out the errors. In fact, if one started with a distribution which did not initially obey Benford’s law, and then started applying some variable (and independent) growth rates to the various samples in the distribution, then under reasonable assumptions one can show that the resulting distribution will converge to Benford’s law over time. This helps explain the universality of Benford’s law for statistics such as populations, for which the independent variable growth law is not so unreasonable (at least, until the population hits some maximum capacity threshold).")

#text("Note that the independence property is crucial; if for instance population growth always slowed down for some inexplicable reason to a crawl whenever the first digit of the population was ")#mi("{6}")#text(", then there would be a noticeable deviation from Benford’s law, particularly in digits ")#mi("{6}")#text(" and ")#mi("{7}")#text(", due to this growth bottleneck. But this is not a particularly plausible scenario (being somewhat analogous to ")#link("http://en.wikipedia.org/wiki/Maxwell%27s_demon")[#text("Maxwell’s demon")]#text(" in thermodynamics).")

#text("The above analysis can also be carried over to some extent to the Pareto distribution and Zipf’s law; if a statistic ")#mi("{X}")#text(" obeys these laws approximately, then after multiplying by an independent variable ")#mi("{Y}")#text(", the product ")#mi("{\\tilde X=XY}")#text(" will obey the same laws with equal or higher accuracy, so long as ")#mi("{Y}")#text(" is small compared to the number of scales that ")#mi("{X}")#text(" typically ranges over. (One needs a restriction such as this because the Pareto distribution and Zipf’s law must break down below the median.) These laws are also stable under other multiplicative processes, for instance if some fraction of the samples in ")#mi("{X}")#text(" spontaneously split into two smaller pieces, or conversely if two samples in ")#mi("{X}")#text(" spontaneously merge into one; as before, the key is that the occurrence of these events should be independent of the actual size of the objects being split. If one considers a generalisation of the Pareto or Zipf law in which the exponent ")#mi("{\\alpha}")#text(" is not fixed, but varies with ")#mi("{n}")#text(" or ")#mi("{k}")#text(", then the effect of these sorts of multiplicative changes is to blur and average together the various values of ")#mi("{\\alpha}")#text(", thus “flattening” the ")#mi("{\\alpha}")#text(" curve over time and making the distribution approach Zipf’s law and/or the Pareto distribution. This helps explain why ")#mi("{\\alpha}")#text(" eventually becomes constant; however, I do not have a good explanation as to why ")#mi("{\\alpha}")#text(" is often close to ")#mi("{1}")#text(".")

#heading(level: 1)[#strong[#text(" — 2. Compatibility between laws — ")]]

#text("Another mathematical line of support for Benford’s law, Zipf’s law, and the Pareto distribution are that the laws are highly compatible with each other. For instance, Zipf’s law and the Pareto distribution are formally equivalent: if there are ")#mi("{N}")#text(" samples of ")#mi("{X}")#text(", then applying ")#link(<tao-80e45578c9a98a2018fd>)[#text("(3)")]#text(" with ")#mi("{x}")#text(" equal to the ")#mi("{n^{th}}")#text(" largest value ")#mi("{X_n}")#text(" of ")#mi("{X}")#text(" gives")

#align(center)[#tao-fit-display[#mitex("\\frac{n}{N} = {\\Bbb P}( X \\geq X_n ) = c X_n^{-1/\\alpha}")]]

#text("which implies Zipf’s law ")#mi("{X_n = C n^{-\\alpha}}")#text(" with ")#mi("{C := (Nc)^\\alpha}")#text(". Conversely one can deduce the Pareto distribution from Zipf’s law. These deductions are only formal in nature, because the Pareto distribution can only hold exactly for continuous distributions, whereas Zipf’s law only makes sense for discrete distributions, but one can generate more rigorous variants of these deductions without much difficulty.")

#text("In some literature, Zipf’s law is applied primarily near the extreme edge of the distribution (e.g. the top ")#mi("{0.1\\%}")#text(" of the sample space), whereas the Pareto distribution in regions closer to the bulk (e.g. between the top ")#mi("{0.1\\%}")#text(" and and top ")#mi("{50\\%}")#text("). But this is mostly a difference of degree rather than of kind, though in some cases (such as with the example of the 2007 country populations data set) the exponent ")#mi("{\\alpha}")#text(" for the Pareto distribtion in the bulk can differ slightly from the exponent for Zipf’s law at the extreme edge.")

#text("The relationship between Zipf’s law or the Pareto distribution and Benford’s law is more subtle. For instance Benford’s law predicts that the proportion of ")#mi("{X}")#text(" with initial digit ")#mi("{1}")#text(" should equal the proportion of ")#mi("{X}")#text(" with initial digit ")#mi("{2}")#text(" or ")#mi("{3}")#text(". But if one formally uses the Pareto distribution ")#link(<tao-80e45578c9a98a2018fd>)[#text("(3)")]#text(" to compare those ")#mi("{X}")#text(" between ")#mi("{10^m}")#text(" and ")#mi("{2 \\times 10^m}")#text(", and those ")#mi("{X}")#text(" between ")#mi("{2 \\times 10^m}")#text(" and ")#mi("{4 \\times 10^m}")#text(", it seems that the former is larger by a factor of ")#mi("{2^{1/\\alpha}}")#text(", which upon summing by ")#mi("{m}")#text(" appears inconsistent with Benford’s law (unless ")#mi("{\\alpha}")#text(" is extremely large). A similar inconsistency is revealed if one uses Zipf’s law instead.")

#text("However, the fallacy here is that the Pareto distribution (or Zipf’s law) does not apply on the entire range of ")#mi("{X}")#text(", but only on the upper tail region when ")#mi("{X}")#text(" is significantly higher than the median; it is a law for the ")#emph[#text("outliers")]#text(" of ")#mi("{X}")#text(" only. In contrast, Benford’s law concerns the behaviour of ")#emph[#text("typical")]#text(" values of ")#mi("{X}")#text("; the behaviour of the top ")#mi("{0.1\\%}")#text(" is of negligible significance to Benford’s law, though it is of prime importance for Zipf’s law and the Pareto distribution. Thus the two laws describe different components of the distribution and thus complement each other. Roughly speaking, Benford’s law asserts that the bulk distribution of ")#mi("{\\log_{10} X}")#text(" is locally uniform at unit scales, while the Pareto distribution (or Zipf’s law) asserts that the tail distribution of ")#mi("{\\log_{10} X}")#text(" decays exponentially. Note that Benford’s law only describes the fine-scale behaviour of the bulk distribution; the coarse-scale distribution can be a variety of distributions (e.g. log-gaussian).")

#heading(level: 1)[#text("Comments (69)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e582c967b122511310c934b2c2701c59b7fd897bcc9b1b45be7864bff5e20464-550dbcbacc25223d6e5fc43cff538b9bad479ac46ae73ed76f8074e41fb27052.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lawyer")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-2/#comment-512353")[#strong[#text("lawyer")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2019")])]

#text("i think still a lot of research is yet to be done on Benford’s Law")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fb4dc508a50da3a1d4230df2c1e77a45947ba18950c3af9439c1adc67eda90c-3f687a45ec087026c2af166c613d646a24b8f7e16ed74d23e5262120e7ab645d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Fernholz")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-2/#comment-514925")[#strong[#text("Robert Fernholz")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2019")])]

#text("You can find a mathematical explanation for the universality of Zipf’s law here: ")#link("https://arxiv.org/pdf/1707.04285.pdf")[#text("https://arxiv.org/pdf/1707.04285.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf8413dbe9211afaeaa17b9c27a5c9c0f77b88a9be6e786ca1771eec0c62d1aa-99b743ddb7f6b8a8d2a7d333090f90a901a327e10a42932aaf9e5a76ce7b3571.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oded Kafri")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-2/#comment-514982")[#strong[#text("Oded Kafri")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2019")])]

#text("Benford law is an outcome of simple probability. There is nothing more to explore. Read for example “A Novel Approach to Probability”, Scientific Research Publishing-Advances in Pure Mathematics.2016, 6, 201-211 ")#link("https://arxiv.org/pdf/1606.03696")[#text("https://arxiv.org/pdf/1606.03696")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eafcb035346317b21de0f224e5182da556b1128abc7996fa38fd11f0eef91a22-2bdb7c6f17842fc3ae1b04961d0db0b5dcee42de261b1cdf1e5c263b4fa78ae2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Fakos")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-2/#comment-616313")[#strong[#text("Alex Fakos")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2021")])]

#text("This is such a great post! Thank you for taking the time to make math accessible to the general public.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39784ca4a092391cbdf579fdbb5adba270b44a3ec5e604caf14ab4cbc102b3e0-52c6d864555db97c7b2bc2d478a62aceb000a846d9489dcacff07c632757eb95.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cost-effectiveness distributions, power laws and scale invariance | Stijn Bruers, the rational ethicist")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-2/#comment-623756")[#strong[#text("Cost-effectiveness distributions, power laws and scale invariance | Stijn Bruers, the rational ethicist")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2021")])]

#text("[…] of a country. So we can consider the distribution of country population sizes. This distribution is close to a power law (with a few outliers, such as India), having estimated power parameter p = 0,9. Now we can consider […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/07b25158160bf2e3e7bec3c93531c2167f087d57ca07436ed4c77b1a23ef7603-206e65dc2fc76de754a8bd5c3cee6e7eaaf9a48d8906f5823a300842e99c87e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Ciriani")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-2/#comment-640562")[#strong[#text("Giovanni Ciriani")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2022")])]

#text("Wonderful article, thanks! I’d never heard of Benford’s law before, but it makes sense, as Oded Kafri pointed out in a previous comment. I think that with a sufficiently large data set it could be expanded to two or more digits, for instance the percentage of numbers in the data set starting with 12 is log(13/12) = 3.5%")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b32650936ca38af03d97d740fa38d42240d9e87daea24f3141ce98e3bace4a16-51019a82ddbb4e24dfb05348b49293e384cee1f6badd6c0d8e023538ed2037e9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric Toombs")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-2/#comment-657386")[#strong[#text("Eric Toombs")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2022")])]

#text("IDG what the big deal is. It’s just 3 different regimes of the log normal distribution. Over many orders of magnitude, the central limit theorem goes from random independent additions and subtractions to random independent multiplications and divisions. Very obvious.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of What are the odds? | What's new")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-2/#comment-658387")[#strong[#text("What are the odds? | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2022")])]

#text("[…] If these corrupt officials are indeed choosing their predetermined winning numbers randomly, then the probability would in fact be just the same probability as , and in this case the seemingly unusual event would in fact have no effect on the odds of the alternative hypothesis, because it was just as unlikely for the alternative hypothesis to generate this multiples-of-nine pattern as for the null hypothesis to. In fact, one would imagine that these corrupt officials would avoid “suspicious” numbers, such as the multiples of , and only choose numbers that look random, in which case would in fact be less than and so the event would actually lower the odds of the alternative hypothesis in this case. (In fact, one can sometimes use this tendency of fraudsters to not generate truly random data as a statistical tool to detect such fraud; violations of Benford’s law for instance can be used in this fashion, though only in situations where the null hypothesis is expected to obey Benford’s law, as discussed in this previous blog post.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-39877")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2009")])]

#text("Another use of these laws: detecting election fraud . See ")#link("http://science.slashdot.org/story/09/06/16/2137203/Statistical-Suspicions-In-Irans-Election")[#text("http://science.slashdot.org/story/09/06/16/2137203/Statistical-Suspicions-In-Irans-Election")]#text(" for Benford’s Law, and ")#link("http://yro.slashdot.org/article.pl?sid=07/12/07/2222212")[#text("http://yro.slashdot.org/article.pl?sid=07/12/07/2222212")]#text(" for a different sort of election fraud.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a22cabb8a2875d9fb426b2df32792821fdcd8c35777d166d14e8db3247557469-a84d6da367f3fb798d5d6f2c44a083e6403fac8ee32d95cf80ca80bb7a24adc7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of john")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-452520")[#strong[#text("john")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2015")])]

#text("Googling Benford’s Law brings up a link to a very elementary, but quite illuminating, paper by R. M. Fewster “A Simple Explanation of Benford’s Law”, who gives a very simple explanation to why it should hold ( the different digits correspond to “stripes” of different width, in the range [n,n+1] for all integer n, on the graph of the p.d.f. of log(X), where X is the random variable in question – if the p.d.f. of log(X) is “smooth enough” – for example log(X) is NOT smooth is this sense when X is distributed uniformly – Benford’s law just comes out from the hat). The big advantage of such an intuitive explanation, in what regards myself, that by just inspecting the distribution of log(X), also for X generated artificially (I played with various distributions plotting their histograms in R), one may already tell with some accuracy whether some approximation to Benford’s law holds for such distribution.")

#text("Probably this is already contained in the present blog entry, but Fewster article was for me easier to follow.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a22cabb8a2875d9fb426b2df32792821fdcd8c35777d166d14e8db3247557469-a84d6da367f3fb798d5d6f2c44a083e6403fac8ee32d95cf80ca80bb7a24adc7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of john")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-452521")[#strong[#text("john")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2015")])]

#text("sorry, did not mean to put it here as an answer to Kevin O’Bryant comment, done by mistake.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8472461435b9f02a2a588743050d6b3d37ea445ede9a1c9b9c89df96e4990b2-af1f20d8f6f26c18f0a7bf3cf223c584ece5b850ecc48c95d14415207aa91a66.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve Lawford")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-39882")[#strong[#text("Steve Lawford")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2009")])]

#text("Prof. Tao,")

#text("Xavier Gabaix (NYU stern) has done a lot of work on this in Economics, e.g. ")#link("http://pages.stern.nyu.edu/%7Exgabaix/papers/zipf.pdf")[#text("http://pages.stern.nyu.edu/%7Exgabaix/papers/zipf.pdf")]#text(" and the survey paper ")#link("http://ssrn.com/abstract=1257822")[#text("http://ssrn.com/abstract=1257822")]#text(".")

#text("Regards,")

#text("Steve Lawford")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-39883")[#strong[#text("Rules of Thumb « OU Math Club")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2009")]

#text("[…] we will leave it to Terence Tao to explain all three. You can read his recent blog post on the mathematics of these three rules of thumb here. Another Rule of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-39886")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2009")]

#text("[…] Benford’s law, Zipf’s law, and the Pareto distribution A remarkable phenomenon in probability theory is that of universality – that many seemingly unrelated […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b4f637c64b6dfbfd42e6017d2967e100c8c063bc3d9c1cff4c486e973b652d6-360663d37afe9f51830abfef1d1059c4cf545367ce5c87547d9126331e770509.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mario Figueiredo")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-39893")[#strong[#text("Mario Figueiredo")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2009")])]

#text("Very interesting post.")#linebreak()#text(" Maybe you already know this, but an interesting “derivation” of Benford’s law can be found in the following paper by Ted Hill (”A statistical derivation of the significant-digit law,” Statistical Science 10, 354-363 (1995)):")

#link("http://www.tphill.net/publications/BENFORD%20PAPERS/statisticalDerivationSigDigitLaw1995.pdf")[#text("Click to access statisticalDerivationSigDigitLaw1995.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-39898")[#strong[#text("links for 2009-07-05 « Blarney Fellow")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2009")]

#text("[…] Benford’s law, Zipf’s law, and the Pareto distribution « What’s new (tags: statistics probability math physics) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f4a3d12d7dd8396e2e24ca4a348a8719fa8b8dd6dd66f1e759f56bbd500149f-7a9f909d0347c714a63dc084b1ca768a3700e11ce70c7d02d2034787a9a322c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of robert")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-39900")[#strong[#text("robert")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2009")])]

#text("Has anyone done a visual representation of Terence Tao’s interesting findings? Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-39923")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2009")])]

#text("This is probably standard material, but are there similar scale invariance-type arguments supporting the Gaussian distribution?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d16748755f72f2245cf7d76271ef24bf6211a05587775c0018440e64692942fe-cab85b756ce58d92eeb39033c3652949ff38e82fa28fde4dde4b74c0ef6d2d55.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of robertfurber")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-39938")[#strong[#text("robertfurber")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2009")])]

#text("@ Qiaochu Yuan")

#text("The Gaussian distribution is supported by the central limit theorem, and is to do with adding random variables rather than multiplying. There are also the “stable distributions” which can turn up if some of the assumptions of the CLT fail to hold.")

#link("http://en.wikipedia.org/wiki/Central_limit_theorem")[#text("http://en.wikipedia.org/wiki/Central_limit_theorem")]#linebreak()#text(" ")#link("http://en.wikipedia.org/wiki/Stable_distribution")[#text("http://en.wikipedia.org/wiki/Stable_distribution")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-39945")[#strong[#text("피타고라스의 창 » ‘벤포드의 법칙’ 대전")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2009")]

#text("[…] Benford’s law, Zipf’s law, and the Pareto distribution […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/abffa09c500faecb8705951eb7f2b185311b080188e03cd5a0b3b1a934ca6e1d-1d7ff34fbdca5b1d6bd974f014ace44847c3ae402435ce26786f6aa134ba1f0f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of More on Benford’s Law « Xi'an's Og")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-39971")[#strong[#text("More on Benford’s Law « Xi'an's Og")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2009")])]

#text("[…] In connection with an earlier post on Benford’s Law, I want to point out a recent entry on Terry Tiao’s blog. He points out that Benford’s Law is the Haar measure in that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-40009")[#strong[#text("Generality of power law distributions « The Metropolis Sampler")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2009")]

#text("[…] of power law distributions Terry Tao has posted an intriguing discussion of Benford’s law, Zipf’s law and the Pareto distribution. These probability distribution functions appear to arise quite often from empirical data and Tao […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd526f9edb179fd17c02fe710b5b5ea15c71acca83b8844013d7ff90eb2f5f3d-65e50116ce76e2a8d9a3e84ff0f85f6063561a45ea019aabfe2f1df7baa09b27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tom w")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-40010")[#strong[#text("tom w")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2009")])]

#text("The above post was very enjoyable reading. I’ve seen power-law distributions derived from maximum entropy principles, but the multiplicative property is very neat and indicates that there is a (to my mind) more satisfactory explanation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/19f2fe7b7f034d9d01d35e97bd62d141f6d6f7b2be0ee205896fe4b60644c30f-8099a62c3618dbfb13c35296e6d3b6595d6dfdd53918b78bc84faac0071523cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of eitan bachmat")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-40053")[#strong[#text("eitan bachmat")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2009")])]

#text("Very interesting post. One can relate the appearance of \\alpha=1 to another well known law, Murphy’s law.")

#text("it can be shown that in several queueing theoretic settings, the Pareto distribution with parameter \\alpha =1 (or its discrete counterparts) is the worst possible service time distribution in the sense that it leads (asymptotically over ever increasing scales) to the longest waiting times or slowdown.")

#text("This is partially related to the fact that the distribution satisfies a modular transformation law with weight 4. Following the Pollaczek-Khinchine formula and Riemann’s trick for producing functional equations from modular transformations, this distribution has some nice symmetries")#linebreak()#text(" when computing waiting times.")

#text("its appearance in measurments of file and job sizes in large computing environments may explain why we sometimes wait a long time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b1e4ee72bf1b18281f5e4880a09958ec2088ef9b74e685dbcf7b808b447c3a0-ca2b2e64b4d6270fca574ca97af9f9ef5a4e09f5ebc8af414b19d1d607024476.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nathan Shewmaker")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-40812")[#strong[#text("Nathan Shewmaker")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2009")])]

#text("The best explanation I’ve read of Benford’s Law was in terms of Digital Signal Processing, written by Steven W. Smith.")

#link("http://www.dspguide.com/ch34.htm")[#text("http://www.dspguide.com/ch34.htm")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17213490e0e435a3232894a87d0f887bb84b41bc87c8750951aacccc6d287072-4a05a98c1951f87526f64ce22e741d697667679fc779f58901038325818ce649.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oded")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-42064")[#strong[#text("Oded")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2009")])]

#text("Below is a maxentropy explanation of all this rules based on inert balls in boxes statistics.")

#link("http://arxiv.org/abs/0907.4852")[#text("http://arxiv.org/abs/0907.4852")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb3883af90764c26ff6e19212292d9513a53f5bd2a353afa84da1bbae36f94d0-ab03bd1fdec8b17ae4ca32f616ef1a7dda11bd1a90b48a37c1b1e128efe873f4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Takis Konstantopoulos")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-42301")[#strong[#text("Takis Konstantopoulos")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2009")])]

#text("I’d be interested to find out how, in an elementary probability class, you would introduce the normal distribution. As you know, most classes do it by fiat: here is a formula, here is how we use it, and, perhaps (…) a bit of a posteriori motivation via the CLT (which is never, really, explained). I happen to like explaining the reason right upfront (the universality, that is), even though I can’t be 100% rigorous. Nevertheless, it seems (to me) to be hitting more notes if you can explain something through its properties rather than as a blunt formula.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-42344")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2009")])]

#text("Hmm. I’ve actually never taught a probability class, but if one had to, I suppose one could first begin with an explicit derivation of CLT for Bernoulli distributions (discrete random walk) using Stirling’s formula. This is still quite lengthy but it is at least elementary.")

#text("One can also do a relatively short computation showing that the sum of two independent gaussians is again a gaussian. This already shows that the only possible universal limit for the CLT is a gaussian, and if one also uses the Lindeberg exchange trick one can in fact derive the full CLT from this.")

#text("The “correct” way to view the CLT, I guess, is via either the Fourier transform or the heat equation, but these are not easy to introduce rapidly in an elementary probability theory class. One can also start from the observation that the gaussian is the stationary point of the Ornstein-Uhlenbeck process (which, infinitesimally, corresponds to renormalised Brownian motion) but this is even less elementary…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17213490e0e435a3232894a87d0f887bb84b41bc87c8750951aacccc6d287072-4a05a98c1951f87526f64ce22e741d697667679fc779f58901038325818ce649.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oded")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-42311")[#strong[#text("Oded")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2009")])]

#text("When I wrote my paper about the maximum entropy distribution functions of system with high occupation number, I decided to add a paragraph about the standard maximum entropy solution namely, the low occupation canonic distribution. To my surprise I have not found any analysis based on probability that connects the canonic exponential distribution to the normal (Gaussian) distribution. (Maybe someone in this forum can show such a derivation?).")#linebreak()#text(" When I derived it myself, I found that the probability function that results from the canonic distribution is a distorted bell-like function very similar to the distribution of speed of molecule in gas and the death distribution function. However, this function is not the normal distribution. When the density of a particle increases the distribution function decreases exponentially and yields the Maxwell Boltzmann distribution as explained in my paper.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/abffa09c500faecb8705951eb7f2b185311b080188e03cd5a0b3b1a934ca6e1d-1d7ff34fbdca5b1d6bd974f014ace44847c3ae402435ce26786f6aa134ba1f0f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Versions of Benford’s Law « Xi'an's Og")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-44990")[#strong[#text("Versions of Benford’s Law « Xi'an's Og")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2010")])]

#text("[…] note picks at the scale-invariant characterisation of Benford’s Law when Terry Tao’s entry represents it as a special case of Haar […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-45756")[#strong[#text("Accelerating Future » Why Benford’s Law?")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2010")]

#text("[…] law. A new preprint has been published on the topic at arXiv, kickstarting an entertaining round of debate. Here’s the Wikipedia description: Benford’s law, also called the first-digit law, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/305903351e4d696128ee2d0d392d3db893bb80928b954ac1d0f00801b4e97a05-486996c86e340dcd4f38ece49423f59098dc9b0cc33f8c0384d2ea0ab4ca1180.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Irrational rotations of the circle and Benford’s law « Division by Zero")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-46878")[#strong[#text("Irrational rotations of the circle and Benford’s law « Division by Zero")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("[…] distributed, but obey Benford’s law: the leading digit occurs with frequency . [See Terence Tao's post for details on when Benford's law applies, but roughly speaking the data must be very spread out […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A second draft of a non-technical article on universality « What’s new")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-46994")[#strong[#text("A second draft of a non-technical article on universality « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2010")])]

#text("[…] Tao, “Benford’s law, Zipf’s law, and the Pareto distribution“, blog post, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-48214")[#strong[#text("What is a random positive integer? | Quasi-Coherent")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2010")]

#text("[…] recommend reading Terence Tao‘s article on Benford’s Law and other phenomena of a similar flavor for further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e2d7012f1ce8dc48656a287f774f5a2f027acb76a5d2b23e90095a36c5f9327c-4944e88e7753979bbde0bb895db6a4c0c71057c13677a2ec7d49b7767349b272.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Hardy")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-50568")[#strong[#text("Michael Hardy")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2011")])]

#text("If you like the Pareto distribution, here’s a paper I wrote showing equivalence of 80/20-type laws and the power law:")

#text("Michael Hardy (2010) “Pareto’s Law”, Mathematical Intelligencer, 32 (3), 38–43. doi: 10.1007/s00283-010-9159-2")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-54191")[#strong[#text("Jason Long")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2011")]

#text("It’s much more of a layman’s demonstration, but a friend and I are working on a site that shows Benford’s Law in action against publicly available datasets (hopefully more to come).")

#link("http://testingbenfordslaw.com")[#text("http://testingbenfordslaw.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-59280")[#strong[#text("Power Laws - Blog – Stack Exchange")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2011")]

#text("[…] don’t have a good conceptual explanation for Lotka’s law. There are certain mathematical reasons why power laws are plausible in certain situations, but I don’t know of any good explanations […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-59290")[#strong[#text("Update « Annoying Precision")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2011")]

#text("[…] Curiously enough, the Zipf distribution which shows up in that post is the same as the zeta distribution that shows up when trying to motivate the definition of the Riemann zeta function. I’m sure there is a conceptual explanation of this connection somewhere, probably coming from statistical mechanics, but I don’t know it. I suppose the approximate scale invariance of the zeta distribution is relevant to its appearance in many real-life statistics, as described in Terence Tao’s blog post on the subject here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4a486d550cad911976d7e3d151762edf2d6f7a38d828fbd81acc75835115d0-5a827d159d829661f4c59a850efc9c1613d82fceeeb827723bc5e12eaa9e954e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-59397")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2011")])]

#text("I think you write 30,7% two times where is should be 30,1% ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-60828")[#strong[#text("Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2011")]

#strong[#text("Why is it that, in many data sets, there are about six times more numbers starting with the digit 1 than with the digit 9 — a phenomenon called Benford’s Law?…")]

#text("If you list all the countries in the world and their populations, 27% of the numbers will start with the digit 1. Only 3% of them will start with the digit 9. Something very similar holds if you look at the heights of the 60 tallest structures in the w…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-62162")[#strong[#text("Pearson-Wong Diffusions | Research Notebook")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2011")]

#text("[…] (1999) or Tao (2009). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b194b47e1d95c1bdb9d1f45cd921e08d98d7590cb09352f0a2eb78df23dcc0c-078027dd33064506412ef3fa6708d06c9d511e7a3a4cf711ac0487359a56541f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Drawing a natural number at random, foundations of probability, determinism, Laplace (8) « Frank Waaldijk's math & science & philosophy blog")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-144782")[#strong[#text("Drawing a natural number at random, foundations of probability, determinism, Laplace (8) « Frank Waaldijk's math & science & philosophy blog")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2012")])]

#text("[…] and discrepancy between Benford’s law and Zipf’s law A good reference for this is Terry Tao’s blogpost on Benford’s law. We quote: Analogous universality phenomena also show up in empirical distributions – the […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2d6e336135daf93a9bf69cdcdca17b420027559ec18ccd8a934f31d8e0fe0fb-47467e602d6d1183cc58c650215770262f1bc724b8cf5ce8c58f9e43537f37c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fwaaldijk")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-260160")[#strong[#text("fwaaldijk")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2013")])]

#text("Since I’m being listed here anyway due to some pingback, I might as well add my 2¢ worth. Benford’s law opens up an interesting view on the question: `can we draw a natural number at random?’. It turns out that we can, provided that we speak of relative probabilities only. (The role of the number 0 remains mysterious).")

#text("For 0< n,m in N let’s denote the relative chance of drawing n vs. drawing m by: P(n)/P(m). Then P(n)/P(m) = (log (n+1)/n)/(log (m+1)/m), see the series posted last year on my blog fwaaldijk.wordpress.com. These relative probabilities can be derived heuristically, and are in accordance with Benford's law. The heuristics are interesting I think, but also quite speculative.")

#text("A `discrete' or `Zipfian' case can also be stated, which then yields P(n)/P(m)=m/n. But I did not study this in any detail.")

#text("I would be happy to receive some feedback on these ideas. Kind regards, Frank")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44a28963456d7a9be6f33c72157605272a54577f998b78bd8129b2a40c06b6d5-95aa5c5c712d24820a96c68bd41607ebf832eef678ca4cbc90532306e36d1fdf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M. Hampton")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-147616")[#strong[#text("M. Hampton")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2012")])]

#text("In the book “Information Theory, Inference, and Learning Algorithms”, by David MacKay, he points out that the scale-free (improper) prior distribution proportional to 1/x can be thought of as the exponential of a uniform distribution on ln(x). The empirical prevalence of distributions close to C/x (i.e. Zipf’s law in the discrete case) might reflect that if a positive quantity is arising from an approximately scale-free system (over some finite but large range of scales), the probability density of the logarithm of that quantity should be approximately uniform.")#linebreak()#text(" While imprecise, I find this a compelling line of thought.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17213490e0e435a3232894a87d0f887bb84b41bc87c8750951aacccc6d287072-4a05a98c1951f87526f64ce22e741d697667679fc779f58901038325818ce649.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oded Kafri")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-147630")[#strong[#text("Oded Kafri")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2012")])]

#text("I would like to draw your attention to the paper arXiv:0907.4852 “the distributions in nature and entropy principle” that show the solution to Benford’s law Pareto rule and Zipf law all bases on Planck equation and requires no parameters at all!")#linebreak()#text(" Have fun.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c514ac24f83e4b5cff3f5a8f7e69c7739d466a090d3ebc0000c588118688049e-fe4a375bd51d7782ba3def1fd9da15f0083a08a89282e2849f5d6a48a1048243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petequinn")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-147688")[#strong[#text("petequinn")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2012")])]

#text("Thanks for sharing that Oded, I will read it more carefully when I find some quiet time!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7bd79ccc17907103f59d86fb20316d47cd1b97b6e5da97c6784bb34597ecff0-0d4f3e22196665cd23c0b63eb88a1c5d6701288f8a5ee038d7b21ba2ca261e47.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-151118")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2012")])]

#text("Of interest is Hammings paper “On the Distribution of Numbers” at ")#link("http://www.alcatel-lucent.com/bstj/vol49-1970/articles/bstj49-8-1609.pdf")[#text("http://www.alcatel-lucent.com/bstj/vol49-1970/articles/bstj49-8-1609.pdf")]

#text("In it, he presents a derivation of Benford’s law for multiplicative processes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-155747")[#strong[#text("Benford’s Law and Baseball « Gödel’s Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2012")]

#text("[…] to certain mixtures of uniform distributions by Élise Janvresse and Thierry de la Rue, and a post three years ago by Terry Tao. The upshot is that data resulting from a complex mix of factors will […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-174956")[#strong[#text("OMG, so much Data! | Notepad PlusPlus")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2012")]

#text("[…] [5] https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/ […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-174963")[#strong[#text("OMG, so much Data! | ugresearchspur")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2012")]

#text("[…] [5] https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/ Share this:TwitterFacebookLike this:LikeBe the first to like this. This entry was posted in Uncategorized on September 25, 2012 by isaaspur. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-211671")[#strong[#text("Benford's Law | Citizen Scientists League")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2013")]

#text("[…] Note: For the more mathematically inclined, Terence Tao wrote an excellent blog post on Benford’s Law and other universal laws, which can be found here: ")#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/. ")[#text("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/. ")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3cb2edb352a2cc19b539e29dcc1c1c9d0b3cfd1dde18a34edc5e0f20373e710-56171540f803a7ea4b2e632ea3d14a784690526b7e2d656e570072188af3b7b7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roland")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-213019")[#strong[#text("Roland")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2013")])]

#text("Thank you Terence, this is a precious post.")

#text("I was actually looking for turbulence, where also this blog provides some brillant food for thought, guess am becoming a new fan.")

#text("Never heard about Benford before so I appreciate especially the Benford application to country population.")

#text("It is beautiful in, conversely, showing that")#linebreak()#text(" a) national borders are perfectly chaotic")#linebreak()#text(" b) since Benford overestimates 1, but consistently underestimates 2..9, that human population is far from infinite.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17213490e0e435a3232894a87d0f887bb84b41bc87c8750951aacccc6d287072-4a05a98c1951f87526f64ce22e741d697667679fc779f58901038325818ce649.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oded Kafri")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-213076")[#strong[#text("Oded Kafri")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2013")])]

#text("I read the above comment about the description of Benford’ law which is result of phenomena “which ostensibly involve large numbers of unknown parameters”. Since I provided a derivation of all these laws, which is based on 1901 Planck’s calculation of the radiation law, I would like to comment that, Pareto, Zipf and Benford’s law are purely statistical, exactly as the Bell like distribution (Maxwell-Boltzmann distribution). There are no free parameters, etc. The Zipf distribution is an approximation of the Planck’s distribution for high occupation numbers which means a random statistical distribution in which there are more particles than boxes. A good example for this distribution is the distribution of population in cities, as there are obviously more peoples than cities. Another example is the famous original Zipf’s example of the distribution of words in texts. There are more words in texts then the number of different words. The Maxwell-Boltzmann distribution is an approximation of Planck distribution for law occupation numbers, which means, a random distribution in which the number of particles is smaller than the number of boxes. IQ is a good example, as every man has only one IQ number from many possibilities. Another example is the death probability. Every man dies in one date from numerous possibilities.")#linebreak()#text(" For more reading O. Kafri “The distribution in nature and entropy principle” arXiv:0907.4852 and references therein.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3cb2edb352a2cc19b539e29dcc1c1c9d0b3cfd1dde18a34edc5e0f20373e710-56171540f803a7ea4b2e632ea3d14a784690526b7e2d656e570072188af3b7b7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roland")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-213507")[#strong[#text("Roland")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2013")])]

#text("To whom it may concern:")

#text("i am well aware of a weak form of maxwellian demon who is looking ceaselessly after all these threads.")#linebreak()#text(" i have recently seen him at work. he is cleaning things up very helpfully.")

#text("i am trying to make a meaningful point here.")#linebreak()#text(" in doing so, various fragments of this post are slightly missing the focus of this thread’s subject matter.")#linebreak()#text(" perhaps more slightly than is tolerable by the blog administrator.")#linebreak()#text(" also, please accept my apologies for all that self promotion after you have read this entire post.")

#text("this is an empirical experiment on the acceptable limits of commenting.")#linebreak()#text(" if the experiment does not go terribly wrong,")#linebreak()#text(" i am excited about becoming a happy participant of this lively community.")#linebreak()#text(" any feedback what so ever highly appreciated.")

#text("thank you very much for your attention.")

#text("********************************************")

#text("Dear blog administrator,")

#text("in the event that interference with this post is inevitable,")#linebreak()#text(" please inform any one concerned, by any means deemed necessary, of what is going on.")

#text("thank you.")

#text("********************************************")

#text("Dear Oded,")

#text("you were so promptly drawing my attention to your paper.")#linebreak()#text(" i could not fail to notice how many times you drew attention to some one before,in the previous couple of years, on this very thread.")#linebreak()#text(" you deserve a feedback.")

#text("so i felt obligued to commit my quiet time to your paper.")

#text("Oded, i am very sorry but you are not deriving all these laws.")#linebreak()#text(" i want to believe your concepts, am almost there, but not quite, no.")#linebreak()#text(" you have truly stunning ideas and you firmly know your stuff.")

#text("but in its current form, i am not able to comprehend your paper fully.")#linebreak()#text(" your narrative is bumpy – that is, lengthy in the easy parts but non existant in the dificult (and interesting) parts.")#linebreak()#text(" also i am too lazy to do all of your research (again).")

#text("therefore it is not possible for me (and i suppose not very much any one) to have a meaningful discussion of its content.")#linebreak()#text(" (as if i knew anything !!)")

#text("Let me draw your attention to Terry’s wonderful (as usual) advice “on writing” here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/advice-on-writing-papers/")[#text("On writing")]
]

#linebreak()#text(" You tripped some of those land mines, if not most of them.")#linebreak()#text(" Your paper needs major pimping in order to be taken seriously.")

#text("On a different level:")#linebreak()#text(" exactly the form of your paper (which i just criticized so cruelly)")#linebreak()#text(" reveals much of your personality.")#linebreak()#text(" a personality that reminds me much of my self when i was at graduate school.")

#text("*** self promotion alert, start ***")#linebreak()#text(" oh how i love the proof by excel sheet !!")

#text("also, i am reminded (painfully so)")#linebreak()#text(" of how the pursuit of academic maturity is so incredibly painful.")#linebreak()#text(" and it never stops once it got started.")

#text("academic maturity has little to do with academic status or glory.")#linebreak()#text(" sorry i was stealing that line from somewhere. i will do it again.")

#text("having studied neither pure math nor computer science,")#linebreak()#text(" i bet aspirants in both these fields get as good a deal of masochistic drill as in any discipline (except medicine where doctor training aims at sadistic tendencies).")

#text("i have failed to achieve ph.d. status on three separate accounts and have never ever published anything.")#linebreak()#text(" one such failure relates closely to me being fed up with latex. latex sucks!")

#text("i assure any one caring to ask:")#linebreak()#text(" academic status is non essential and academic maturity is unlearnable from university alone.")#linebreak()#text(" academic status in fact hurts certain career options.")#linebreak()#text(" i have met math doctors working for a fraction of my income,")#linebreak()#text(" *** self promotion alert, end ***")#linebreak()#text(" and i earn low coin.")

#text("Dear Oded, you are well on your way.")#linebreak()#text(" You need to cheer up and keep going.")#linebreak()#text(" Please do your homework: pimp that paper and re-load it.")#linebreak()#text(" You owe it to your self.")#linebreak()#text(" And the community.")

#text("If you re-load, i promise i will re-view.")

#text("Perhaps i will motivate myself and do some home work of my own.")#linebreak()#text(" Turbulence needs fixing, after all.")

#text("Most sincerely,")#linebreak()#text(" Roland")

#text("********************************************")

#text("In relating to the subject matter at hand, i know of other good Benford examples i like to share:")

#text("my undergrad math teacher (with a background in telecommunication) talked about huge samples")#linebreak()#text(" of lengths of telephone conversations.")#linebreak()#text(" it seemed there was no way of predicting how much longer a conversation (in progress) is going to last, given it is in progress already for so many minutes.")

#text("so conversation statistics would be more perfectly chaotic than death statistics.")#linebreak()#text(" in analogy to Oded’s notion, there are more conversation boxes than death boxes.")

#text("everything else from said math class (which may very well have been about Benford) i have genuinely forgotten by the way.")

#text("coincidentally, i stumbled on a very enlightening non math article elaborating on (among other interesting things) the randomness of cancer. cancer positively qualifies as the mother of all Benfordian statistics with an infinite number of boxes.")#linebreak()#text(" I fell in love with the wording. Two thumbs up !!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3cb2edb352a2cc19b539e29dcc1c1c9d0b3cfd1dde18a34edc5e0f20373e710-56171540f803a7ea4b2e632ea3d14a784690526b7e2d656e570072188af3b7b7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roland")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-213508")[#strong[#text("Roland")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2013")])]

#text("Whoops, i always seem to forget something important at the end.")

#text("The paper on perfect randomness of cancer:")

#link("https://www.nsfwcorp.com/dispatch/watson-cancer")[#text("https://www.nsfwcorp.com/dispatch/watson-cancer")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17213490e0e435a3232894a87d0f887bb84b41bc87c8750951aacccc6d287072-4a05a98c1951f87526f64ce22e741d697667679fc779f58901038325818ce649.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oded Kafri")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-250718")[#strong[#text("Oded Kafri")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2013")])]

#text("Hi Poland, thank you for reading my arxiv post . I Just published a popular book about logical distributions that includes the derivations only in the appendixes. The book’s name is “Entropy God’s Dice Game”. I hope that you and also Professor Tao will be exposed to a physical approach to probability. Also there is blog ")#link("http://www.entropy-book.com")[#text("http://www.entropy-book.com")]#text(" that discuss the subject matter. I hope that you will find this material helpful.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-246540")[#strong[#text("Artificial Intelligence Blog · Zipf’s Law, ArtEnt Blog Hits")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2013")]

#text("[…] (Though Zipf’s “law” has been known for a long time, this post is at least partly inspired by Tarence Tao’s wonderful post “Benford’s law, Zipf’s law, and the Pareto distribution“.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/194d00dc323c002700888091359436eb256a1f179ad1b15f646e6d0187e5e2de-73739b2602fcdb496d6badcbc313660c8c58d454936625988460b8caa0f7cf0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Wright")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-246810")[#strong[#text("Joe Wright")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2013")])]

#text("Amazing work. It’s amazing how many things this theory applies to.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e38b02441ca07807b16f30123189bec6a349380468095fb6d3e36cbb908366e-84d9b77a7f898d99b31262a23cfa4744da9d01d4003951da7ddddc422c49d0cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Johnson")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-262898")[#strong[#text("Richard Johnson")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2014")])]

#text("These phenomena are plausibly results of the Central Limit Theorem rather than any other law. If you add i.i.d. errors with a finite variance you get a normal distribution. In the Zipf law settings one tends to multiply together i.i.d. errors instead. But the log of this product of errors is again a sum of i.i.d. errors which is asymptotically normal. Thus the log of e.g. city size is asymptotically normal and the distribution of city sizes is lognormal.")

#text("This would certainly explain how ‘Zipf’s law seems to turn up everywhere’ if it is a manifestation of the Central Limit Theorem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-262927")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2014")])]

#text("Benford’s law can indeed often be explained through a central limit theorem analysis, but Zipf’s law and Pareto’s law cannot; the log-normal distribution has different tails than the power law distribution, and so something else is going on at the extreme end of city sizes (or extremely popular words, etc.) I posed a question on MathOverflow about this at ")#link("http://mathoverflow.net/questions/39224/is-there-a-natural-random-process-that-is-rigorously-known-to-produce-zipfs-law")[#text("http://mathoverflow.net/questions/39224/is-there-a-natural-random-process-that-is-rigorously-known-to-produce-zipfs-law")]#text(" , and got some fairly satisfactory answers for the case of frequent words, but the situation was murkier for things like the largest cities.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-456492")[#strong[#text("A reddit visualization | Done Is Better Than Perfect")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2015")]

#text("[…] is. It’s reasonable to expect the subreddits population to follow a pareto distribution (see this post by Terence Tao for a definition of “reasonable”). The simplest way to check is to see if the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d494455863b08e5322e79422f9a224d8d8fc84bae9101196f4754c9a23b145c-b9593ffb2bebf0c32fb96f7a18b03269e4921c0a981f44a1909ce58821b1b226.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jeffdelezen")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-456935")[#strong[#text("jeffdelezen")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2015")])]

#text("Reblogged this on ")#link("https://oildatablog.wordpress.com/2015/07/05/benfords-law-zipfs-law-and-the-pareto-distribution/")[#text("Siamese Submarine")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9d9e1a811b91eaef212079e0c1a61028a53c6311f2f5341b3b7550a2495b6a05-7d93beef4ac1d6d1baeed80b5b81183ae1b1db186d3528130130a172e36ac197.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-463400")[#strong[#text("Joe")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2015")])]

#text("Professor Tao, I am a novice here, so I am not sure if this is totally trivial, but if X follows Zipf’s law, does any monotonic transformation of X also follow Zipf’s law? What about Pareto? Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-465046")[#strong[#text("2 – Benford’s law, Zipf’s law, and the Pareto distribution (2009)")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2016")]

#text("[…] Read more here: ")#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/")[#text("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/282c2fed4c0b2fd2623c62e83d5800f39598ff8af988c334818261386298faed-1bf57836d99a2390aefd437a402aff29864bd48469d0ed59404aef57a6f2f76e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Наша статистика ок | minimumlikelihood")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-467773")[#strong[#text("Наша статистика ок | minimumlikelihood")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2016")])]

#text("[…] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-468734")[#strong[#text("zawy (@loganspappy)")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")]

#text("Benford’s law also holds better for language than Madelbrot’s modification to Zipf’s law 1/(r+2.7). Use ~2.2 times Benford’s law, and divide both by ln(1.78*unique words in language).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-468775")[#strong[#text("Zipf’s law, Power-law distributions in “The Anatomy of Melancholy”. Part I | Buridan's Ass")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")]

#text("[…] law and it’s sister laws: Benford’s law and the Pareto distribution. (Terry tao has a nice post describing all three and how they relate to each […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d44f2215dbe70717d4470b46e81b77f025d6a1012dc6c72a8f778353c0620330-0cbdb898f2c27990e7b8bcdeb2526c354165101a0fe7dea09abea29f9c8a28a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dynamics on emerging spaces: modeling the emergence of novelties | the morning paper")]], [#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-477491")[#strong[#text("Dynamics on emerging spaces: modeling the emergence of novelties | the morning paper")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("[…] dataset should follow four conditions for the law to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/03/benfords-law-zipfs-law-and-the-pareto-distribution/comment-page-1/#comment-481263")[#strong[#text("When the Average is a Poor Metric for Measuring Application Performance | Loggly")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2017")]

#text("[…] Tao, Terence. “Benford’s Law, Zipf’s Law, and the Pareto Distribution.” 3 July 2009. […]")
]
