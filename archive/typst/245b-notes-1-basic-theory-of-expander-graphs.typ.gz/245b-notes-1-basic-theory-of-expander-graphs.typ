// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/
// Converted to Typst by tao2typ: "2026-10-14T09:21:33.623303+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254B, Notes 1: Basic theory of expander graphs", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254B, Notes 1: Basic theory of expander graphs")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 December 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/")[#text("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The objective of this course is to present a number of recent constructions of ")#link("http://en.wikipedia.org/wiki/Expander_graph")[#text("expander graphs")]#text(", which are a type of sparse but “pseudorandom” graph of importance in computer science, the theory of random walks, geometric group theory, and in number theory. The subject of expander graphs and their applications is an immense one, and we will not possibly be able to cover it in full in this course. In particular, we will say almost nothing about the important applications of expander graphs to computer science, for instance in constructing good pseudorandom number generators, derandomising a probabilistic algorithm, constructing error correcting codes, or in building probabilistically checkable proofs. For such topics, I recommend the ")#link("http://www.ams.org/mathscinet-getitem?mr=2247919")[#text("survey of Hoory-Linial-Wigderson")]#text(". We will also only pass very lightly over the other applications of expander graphs, though if time permits I may discuss at the end of the course the application of expander graphs in finite groups such as ")#mi("{SL_2(F_p)}")#text(" to certain sieving problems in analytic number theory, following the ")#link("http://www.ams.org/mathscinet-getitem?mr=2246331")[#text("work of Bourgain, Gamburd, and Sarnak")]#text(".")

#text("Instead of focusing on applications, this course will concern itself much more with the task of ")#emph[#text("constructing")]#text(" expander graphs. This is a surprisingly non-trivial problem. On one hand, an easy application of the probabilistic method shows that a randomly chosen (large, regular, bounded-degree) graph will be an expander graph with very high probability, so expander graphs are extremely abundant. On the other hand, in many applications, one wants an expander graph that is more deterministic in nature (requiring either no or very few random choices to build), and of a more specialised form. For the applications to number theory or geometric group theory, it is of particular interest to determine the expansion properties of a very symmetric type of graph, namely a ")#link("http://en.wikipedia.org/wiki/Cayley_graph")[#text("Cayley graph")]#text("; we will also occasionally work with the more general concept of a ")#link("http://en.wikipedia.org/wiki/Schreier_coset_graph")[#text("Schreier graph")]#text(". It turns out that such questions are related to deep properties of various groups ")#mi("{G}")#text(" of Lie type (such as ")#mi("{SL_2({\\bf R})}")#text(" or ")#mi("{SL_2({\\bf Z})}")#text("), such as ")#link("http://en.wikipedia.org/wiki/Kazhdan_property_T")[#text("Kazhdan’s property (T)")]#text(", the first nontrivial eigenvalue of a Laplacian on a symmetric space ")#mi("{G/\\Gamma}")#text(" associated to ")#mi("{G}")#text(", the quasirandomness of ")#mi("{G}")#text(" (as measured by the size of irreducible representations), and the product theory of subsets of ")#mi("{G}")#text(". These properties are of intrinsic interest to many other fields of mathematics (e.g. ergodic theory, operator algebras, additive combinatorics, representation theory, finite group theory, number theory, etc.), and it is quite remarkable that a single problem – namely the construction of expander graphs – is so deeply connected with such a rich and diverse array of mathematical topics. (Perhaps this is because so many of these fields are all grappling with aspects of a single general problem in mathematics, namely when to determine whether a given mathematical object or process of interest “behaves pseudorandomly” or not, and how this is connected with the symmetry group of that object or process.)")

#text("(There are also other important constructions of expander graphs that are not related to Cayley or Schreier graphs, such as those graphs constructed by the ")#link("http://en.wikipedia.org/wiki/Zig-zag_product")[#text("zigzag product construction")]#text(", but we will not discuss those types of graphs in this course, again referring the reader to ")#link("http://www.ams.org/mathscinet-getitem?mr=2247919")[#text("the survey of Hoory, Linial, and Wigderson")]#text(".)")

#metadata(none) <tao-863ddcae98b9eaebcff9>

#heading(level: 1)[#strong[#text(" — 1. Expander graphs — ")]]

#text("We begin by defining the concept of an expander graph formally. As with many fundamentally important concepts in mathematics, there are a number of equivalent definitions of this concept. We will adopt a “spectral” perspective towards expander graphs, defining them in terms of a certain spectral gap, but will relate this formulation of expansion to the more classical notion of edge expansion later in this section.")

#text("We begin by recalling the notion of a graph. To avoid some very minor technical issues, we will work with undirected, loop-free, multiplicity-free graphs (though later, when we discuss Cayley graphs, we will allow loops and repetition).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1")]#text(" A ")#emph[#text("graph")]#text(" is a pair ")#mi("{G = (V,E)}")#text(", where ")#mi("{V}")#text(" is a set (called the ")#emph[#text("vertex set")]#text(" of ")#mi("{G}")#text("), and ")#mi("{E \\subset \\binom{V}{2}}")#text(" is a collection of unordered pairs ")#mi("{\\{v,w\\}}")#text(" of distinct elements ")#mi("{v,w}")#text(" of ")#mi("{V}")#text(", known as the ")#emph[#text("edge set")]#text(" of ")#mi("{E}")#text(". Elements of ")#mi("{V}")#text(" or ")#mi("{E}")#text(" are called ")#emph[#text("vertices")]#text(" and ")#emph[#text("edges")]#text(" of ")#mi("{E}")#text(" A graph is ")#emph[#text("finite")]#text(" if the vertex set (and hence the edge set) is finite. If ")#mi("{k \\geq 0}")#text(" is a natural number, we say that a graph ")#mi("{G = (V,E)}")#text(" is ")#emph[#mi("{k}")#text("-regular")]#text(" if each vertex of ")#mi("{V}")#text(" is contained in exactly ")#mi("{k}")#text(" edges in ")#mi("{E}")#text("; we refer to ")#mi("{k}")#text(" as the ")#emph[#text("degree")]#text(" of the regular graphs.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" The ")#link("http://en.wikipedia.org/wiki/Complete_graph")[#text("complete graph")]#text(" ")#mi("{(V, \\binom{V}{2})}")#text(" on a vertex set ")#mi("{V}")#text(" has edge set ")#mi("{\\binom{V}{2} := \\{ \\{v,w\\}: v,w \\in V, v \\neq w \\}}")#text(". If ")#mi("{V}")#text(" has ")#mi("{n}")#text(" elements, the complete graph is ")#mi("{n-1}")#text("-regular.")
]

#text("In this course, we will mostly be interested in ")#emph[#text("constant-degree")]#text(" large finite regular graphs, in which ")#mi("{k}")#text(" is fixed (e.g. ")#mi("{k=4}")#text("), and the number ")#tao-math("{n=\\left|V\\right|}", block: false)#text(" of vertices is going off to infinity.")

#text("Given a finite graph ")#mi("{G = (V,E)}")#text(", one can define the ")#emph[#text("adjacency operator")]#text(" ")#mi("{A: \\ell^2(V) \\rightarrow \\ell^2(V)}")#text(" on functions ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("A f(v) := \\sum_{w \\in V: \\{v,w\\} \\in E} f(w),")]]

#text("thus ")#mi("{Af(v)}")#text(" is the sum of ")#mi("{f}")#text(" over all of the neighbours of ")#mi("{v}")#text(". If one enumerates the vertices ")#mi("{V}")#text(" as ")#mi("{v_1,\\ldots,v_n}")#text(" in some fashion, then one can associate ")#mi("{A}")#text(" with an ")#mi("{n \\times n}")#text(" matrix, known as the ")#link("http://en.wikipedia.org/wiki/Adjacency_matrix")[#text("adjacency matrix")]#text(" of ")#mi("{G}")#text(" (with this choice of vertex enumeration).")

#text("As our graphs are undirected, the adjacency operator ")#mi("{A}")#text(" is clearly self-adjoint (and the adjacency matrix is real symmetric). By the spectral theorem, ")#mi("{A}")#text(" thus has ")#mi("{n}")#text(" real eigenvalues")

#align(center)[#tao-fit-display[#mitex("\\lambda_1 \\geq \\ldots \\geq \\lambda_n.")]]

#text("We will write ")#mi("{\\lambda_i}")#text(" as ")#mi("{\\lambda_i(G)}")#text(" whenever we need to emphasise the dependence on the graph ")#mi("{G}")#text(".")

#text("The largest eigenvalue ")#mi("{\\lambda_1}")#text(" is easily understood for ")#mi("{k}")#text("-regular graphs:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" If ")#mi("{G}")#text(" is a ")#mi("{k}")#text("-regular graph, then")

#align(center)[#tao-fit-display[#mitex("k = \\lambda_1 \\geq \\lambda_n \\geq -k.")]]
]

#emph[#text("Proof:")]#text(" Clearly ")#mi("{A1 = k1}")#text(" (where we write ")#mi("{1 \\in \\ell^2(V)}")#text(" for the constant function), and so ")#mi("{k}")#text(" is an eigenvalue of ")#mi("{A}")#text(" with eigenvector ")#mi("{1}")#text(". On the other hand, for any ")#mi("{f, g \\in \\ell^2(V)}")#text(" with norm one, one has")

#tao-aligned(keep: true)[


#tao-math("\\left|\\langle Af, g \\rangle_{\\ell^2(V)}\\right|  & = \\left|\\sum_{v, w \\in V: \\{v,w\\} \\in E} f(w) \\overline{g(v)}\\right|", block: true)



#tao-math(" & \\leq \\frac{1}{2} \\sum_{v, w \\in V: \\{v,w\\} \\in E} \\left|f(w)\\right|^2 + \\left|g(v)\\right|^2", block: true)



#tao-math(" & \\leq \\frac{1}{2} k \\sum_{w \\in V} \\left|f(w)\\right|^2 + \\frac{1}{2} k \\sum_{v \\in V} \\left|g(v)\\right|^2", block: true)



#tao-math(" & = k,", block: true)
]

#text("and so ")#mi("{A}")#text(" has operator norm ")#mi("{k}")#text(" (or equivalently, all eigenvalues of ")#mi("{A}")#text(" lie between ")#mi("{-k}")#text(" and ")#mi("{k}")#text("). The claim follows. ")#mi("\\Box")

#text("Now we turn to the next eigenvalue after ")#mi("{\\lambda_1}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 4")]#text(" Let ")#mi("{\\varepsilon > 0}")#text(" and ")#mi("{k \\geq 1}")#text(". A finite ")#mi("{k}")#text("-regular graph is said to be a (one-sided) ")#emph[#mi("{\\varepsilon}")#text("-expander")]#text(" if one has")

#align(center)[#tao-fit-display[#mitex("\\lambda_2 \\leq (1-\\varepsilon) k")]]

#text("and a ")#emph[#text("two-sided ")#mi("{\\varepsilon}")#text("-expander")]#text(" if one also has")

#align(center)[#tao-fit-display[#mitex("\\lambda_n \\geq -(1-\\varepsilon) k.")]]

#text("A sequence ")#mi("{G_i = (V_i,E_i)}")#text(" of finite ")#mi("{k}")#text("-regular graphs is said to be a one-sided (resp. two-sided) ")#emph[#text("expander family")]#text(" if there is an ")#mi("{\\varepsilon>0}")#text(" such that ")#mi("{G_i}")#text(" is a one-sided (resp. two-sided) ")#mi("{\\varepsilon}")#text("-expander for all sufficiently large ")#mi("{i}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" The operator ")#mi("{\\Delta := 1-\\frac{1}{k} A}")#text(" is sometimes known as the ")#link("http://en.wikipedia.org/wiki/Laplacian_matrix")[#text("graph Laplacian")]#text(" (though note that it is also common to use the normalisation ")#mi("{k-A}")#text(" instead of ")#mi("{1-\\frac{1}{k} A}")#text(" in many texts, particularly if one wishes to generalise to graphs that are not perfectly regular). This is a positive semi-definite operator with at least one zero eigenvalue (corresponding to the eigenvector ")#mi("{1}")#text("). A graph is an ")#mi("{\\varepsilon}")#text("-expander if and only if there is a ")#emph[#text("spectral gap")]#text(" of size ")#mi("{\\varepsilon}")#text(" in ")#mi("{\\Delta}")#text(", in the sense that the first eigenvalue of ")#mi("{\\Delta}")#text(" exceeds the second by at least ")#mi("{\\varepsilon}")#text(". The graph Laplacian is analogous to the classical Laplacian in Euclidean space (or the Laplace-Beltrami operator on Riemannian manifolds); we will see some formalisations of this analogy later in this course.")
]

#text("The original definition of expander graphs focused on one-sided expanders, but it will be slightly more natural in this course to focus on the two-sided expanders.")

#text("Strictly speaking, we have not defined the notion of a (one or two-sided) expander graph in the above definition; we have defined an ")#mi("{\\varepsilon}")#text("-expander graph for any given parameter ")#mi("{\\varepsilon>0}")#text(", and have defined the notion of an expander family, which is a ")#emph[#text("sequence")]#text(" of graphs rather than for an individual graph. One could propose defining an expander graph to be a graph that is a one or two-sided ")#mi("{\\varepsilon}")#text("-expander for some ")#mi("{\\varepsilon>0}")#text(" (or equivalently, a graph ")#mi("{G}")#text(" such that the constant sequence ")#mi("{G,G,\\ldots}")#text(" is an expander family), but this definition collapses to existing concepts in graph theory:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6 (Qualitative expansion)")]#text(" Let ")#mi("{k \\geq 1}")#text(", and let ")#mi("{G = (V,E)}")#text(" be a finite ")#mi("{k}")#text("-regular graph.")

#list(
[#text("Show that ")#mi("{\\lambda_2 = k}")#text(" if and only if ")#mi("{G}")#text(" is not ")#link("http://en.wikipedia.org/wiki/Connectivity_(graph_theory)")[#text("connected")]#text(".")],
[#text("Show that ")#mi("{\\lambda_n = -k}")#text(" if and only if ")#mi("{G}")#text(" contains a non-empty ")#link("http://en.wikipedia.org/wiki/Bipartite_graph")[#text("bipartite graph")]#text(" as a connected component.")]
)

#text("Thus, a graph is a one-sided expander for some ")#mi("{\\varepsilon>0}")#text(" if and only if it is connected, and a two-sided expander for some ")#mi("{\\varepsilon>0}")#text(" if and only if it is connected and not bipartite.")
]

#text("It is therefore necessary to either keep a more quantitative track of the ")#mi("{\\varepsilon}")#text(" parameter, or work with expander families (typically involving vertex sets whose cardinality goes to infinity) rather than with individual graphs. (Alternatively, one could adopt a ")#link("http://en.wikipedia.org/wiki/Non-standard_analysis")[#text("nonstandard analysis")]#text(" viewpoint and work with ")#emph[#text("ultra expander graphs")]#text(" – i.e. ultraproducts of expander families – but we will postpone using this viewpoint until much later in the course.) Nevertheless, we will often informally drop the ")#mi("{\\varepsilon}")#text(" parameter (or the use of families) and informally refer simply to “expander graphs” in our discussion.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7 (Trace formulae)")]#text(" ")#metadata(none) <tao-c912eef2e5eb9fe09f9b>#text(" Let ")#mi("{G}")#text(" be a ")#mi("{k}")#text("-regular graph on ")#mi("{n}")#text(" vertices for some ")#mi("{n > k \\geq 1}")#text(".")

#list(
[#text("(i) Show that ")#mi("{\\sum_{i=1}^n \\lambda_i = 0}")#text(".")],
[#text("(ii) Show that ")#mi("{\\sum_{i=1} \\lambda_i^2 = nk}")#text(".")],
[#text("(iii) Show that ")#tao-math("{\\max( \\left|\\lambda_2\\right|, \\left|\\lambda_n\\right| ) \\geq \\sqrt{k} - o_{n \\rightarrow \\infty;k}(1)}", block: false)#text(", where ")#mi("{o_{n \\rightarrow \\infty;k}(1)}")#text(" denotes a quantity that goes to zero as ")#mi("{n \\rightarrow \\infty}")#text(" for fixed ")#mi("{k}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" The above exercise places an upper bound on how strong of a two-sided expansion one can obtain for a large ")#mi("{k}")#text("-regular graph. It is not quite sharp; it turns out that one can obtain the improvement")

#align(center)[#tao-fit-display[#tao-math("\\max( \\left|\\lambda_2\\right|, \\left|\\lambda_n\\right| ) \\geq 2\\sqrt{k-1} - o_{n \\rightarrow \\infty;k}(1),", block: true)]]

#text("a result of Alon and Boppana; see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=2247919")[#text("the survey of Hoory-Linial-Wigderson")]#text(" for a proof. Graphs with ")#tao-math("{\\max( \\left|\\lambda_2\\right|, \\left|\\lambda_n\\right| ) \\leq 2\\sqrt{k-1}}", block: false)#text(" are known as ")#link("http://en.wikipedia.org/wiki/Ramanujan_graph")[#text("Ramanujan graphs")]#text(", and (as the name suggests) have connections to number theory, but we will not discuss this topic here; see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=1989434")[#text("this text of Davidoff, Sarnak, and Valette")]#text(" for more discussion.")
]

#text("We will give a probabilistic construction of an expander family later, but let us first give an example of a family of regular graphs that is ")#emph[#text("not")]#text(" an expander family.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" ")#metadata(none) <tao-3cfc2e817770fc62e308>#text(" For each ")#mi("{n \\geq 3}")#text(", let ")#mi("{G_n}")#text(" be the ")#mi("{2}")#text("-regular graph whose vertex set is the cyclic group ")#mi("{{\\bf Z}/n{\\bf Z}}")#text(", and whose edge set is the set of pairs ")#mi("{\\{x,x+1\\}}")#text(" for ")#mi("{x \\in {\\bf Z}/n{\\bf Z}}")#text(". (This is a basic example of a ")#link("http://en.wikipedia.org/wiki/Cayley_graph")[#text("Cayley graph")]#text(". Cayley graphs will be discussed in more depth in the next set of notes.)")

#list(
[#text("Show that the eigenvalues of the adjacency operator ")#mi("{A_n}")#text(" associated to ")#mi("{G_n}")#text(" are ")#mi("{2\\cos(2\\pi j/n)}")#text(" for ")#mi("{j=0,\\ldots,n-1}")#text(". (")#emph[#text("Hint:")]#text(" you may find the ")#link("http://en.wikipedia.org/wiki/Discrete_fourier_transform")[#text("discrete Fourier transform")]#text(" to be helpful.)")],
[#text("Show that ")#mi("{G_n}")#text(" is not a one-sided expander family (and is thus not a two-sided expander family either). This is despite ")#mi("{G_n}")#text(" always being connected (and non-bipartite for ")#mi("{n}")#text(" odd).")]
)
]

#text("The next exercise shows that the complete graph is an excellent expander; the whole point, though, of expander graph constructions is to come up with much sparser graphs that still has many of the connectivity and expansion properties of the complete graph.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Let ")#mi("{G}")#text(" be the ")#link("http://en.wikipedia.org/wiki/Complete_graph")[#text("complete graph")]#text(" on ")#mi("{n}")#text(" vertices, which is of course a ")#mi("{n-1}")#text("-regular graph. Show that")

#align(center)[#tao-fit-display[#mitex("\\lambda_2 = \\ldots = \\lambda_n = -1")]]

#text("and so ")#mi("{G}")#text(" is a one-sided ")#mi("{1+\\frac{1}{n-1}}")#text("-expander and a two-sided ")#mi("{1-\\frac{1}{n-1}}")#text("-expander. (This is not a counterexample to Exercise ")#link(<tao-c912eef2e5eb9fe09f9b>)[#text("7")]#text("(iii), because the error term ")#mi("{o_{n \\rightarrow \\infty;k}(1)}")#text(" is only negligible in the regime when ")#mi("{k}")#text(" is either fixed or is a very slowly growing function of ")#mi("{n}")#text(", and this is definitely not the case for the complete graph.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" ")#metadata(none) <tao-8f9c2b353e9982ae0e91>#text(" Let ")#mi("{G=(V,E)}")#text(" be a ")#mi("{k}")#text("-regular graph on ")#mi("{n}")#text(" vertices. Let ")#mi("{G^c=(V,\\binom{V}{2} \\backslash E)}")#text(" be the ")#link("http://en.wikipedia.org/wiki/Complement_graph")[#text("complement graph")]#text(", consisting of all the edges connecting two vertices in ")#mi("{V}")#text(" that are not in ")#mi("{E}")#text(", thus ")#mi("{G^c}")#text(" is an ")#mi("{n-k-1}")#text("-regular graph. Show that")

#align(center)[#tao-fit-display[#mitex("\\lambda_i(G^c) = - 1 - \\lambda_{n+2-i}(G)")]]

#text("for all ")#mi("{2 \\leq i \\leq n}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" Let ")#mi("{n \\geq 2}")#text(" be an even number, and let ")#mi("{G = K_{n/2,n/2}}")#text(" be the complete bipartite graph between two sets of ")#mi("{n/2}")#text(" vertices each, thus ")#mi("{G}")#text(" is an ")#mi("{n/2}")#text("-regular graph. Show that ")#mi("{\\lambda_n = -n/2}")#text(" and ")#mi("{\\lambda_2 = \\ldots = \\lambda_{n-1} = 0}")#text(". Thus, ")#mi("{G}")#text(" is a one-sided ")#mi("{1}")#text("-expander, but is not a two-sided expander at all.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Expansion and Poincaré inequality)")]#text(" If ")#mi("{G = (V,E)}")#text(" is a ")#mi("{k}")#text("-regular graph and ")#mi("{f: V \\rightarrow {\\bf C}}")#text(" is a function, define the gradient magnitude ")#tao-math("{\\left|\\nabla f\\right|: V \\rightarrow {\\bf C}}", block: false)#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left|\\nabla f(v)\\right| := (\\sum_{w \\in V: \\{v,w\\} \\in E} \\left|f(w)-f(v)\\right|^2)^{1/2}.", block: true)]]

#text("Show that ")#mi("{G}")#text(" is a one-sided ")#mi("{\\varepsilon}")#text("-expander if and only if one has the ")#emph[#text("Poincaré inequality")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\nabla f \\right\\|_{\\ell^2(V)}^2 \\geq 2 k \\varepsilon \\left\\| f \\right\\|_{\\ell^2(V)}^2", block: true)]]

#text("whenever ")#mi("{f}")#text(" has mean zero.")
]

#heading(level: 1)[#strong[#text(" — 2. Connection with edge expansion — ")]]

#text("The intuition to explain Exercise ")#link(<tao-3cfc2e817770fc62e308>)[#text("9")]#text(" should be that while ")#mi("{G_n}")#text(" is, strictly speaking, connected, it is not very ")#emph[#text("strongly")]#text(" connected; the paths connecting a typical pair of points are quite long (comparable to ")#mi("{n}")#text(", the number of vertices) and it is easy to disconnect the graph into two large pieces simply by removing a handful of edges.")

#text("We now make this intuition more precise. Given two subsets ")#mi("{F_1,F_2}")#text(" of the vertex set ")#mi("{V}")#text(" in a graph ")#mi("{G = (V,E)}")#text(", define ")#mi("{E(F_1,F_2) \\subset F_1 \\times F_2}")#text(" to be the set of all pairs ")#mi("{(v_1,v_2) \\in F_1 \\times F_2}")#text(" such that ")#mi("{\\{v_1,v_2\\} \\in E}")#text(". Note that the cardinality of this set can be expressed in terms of the adjacency operator as")

#align(center)[#tao-fit-display[#tao-math("\\left|E(F_1,F_2)\\right| = \\langle A 1_{F_1}, 1_{F_2} \\rangle_{\\ell^2(V)}.", block: true)]]

#text("Define the ")#emph[#text("boundary")]#text(" ")#mi("{\\partial F}")#text(" of a subset ")#mi("{F}")#text(" of ")#mi("{V}")#text(" to be the set ")#mi("{\\partial F := E( F, V \\backslash F )}")#text(", thus ")#mi("{\\partial F}")#text(" is essentially the set of all edges that connect an element of ")#mi("{F}")#text(" to an element outside of ")#mi("{F}")#text(". We define the ")#emph[#text("edge expansion ratio")]#text(" ")#mi("{h(G)}")#text(" of the graph ")#mi("{G}")#text(" to be given by the formula")

#align(center)[#tao-fit-display[#tao-math("h(G) := \\min_{F \\subset V: \\left|F\\right| \\leq \\left|V\\right|/2} \\frac{\\left|\\partial F\\right|}{\\left|F\\right|},", block: true)]]

#text("where ")#mi("{F}")#text(" ranges over all subsets of ")#mi("{V}")#text(" of cardinality at most ")#tao-math("{\\left|F\\right| \\leq \\left|V\\right|/2}", block: false)#text(". (Some upper bound on ")#mi("{F}")#text(" is needed to avoid this quantity from degenerating, since ")#mi("{\\partial F}")#text(" becomes empty when ")#mi("{F=V}")#text(".) The quantity ")#mi("{h(G)}")#text(" can be interpreted as a type of isoperimetric constant for ")#mi("{G}")#text(", analogous to the ")#link("http://en.wikipedia.org/wiki/Cheeger_constant")[#text("Cheeger constant")]#text(" of a compact Riemannian manifold, and so ")#mi("{h(G)}")#text(" is sometimes known as the ")#emph[#text("Cheeger constant")]#text(" of the graph ")#mi("{G}")#text(".")

#text("Note that ")#mi("{h(G)}")#text(" is non-zero precisely when ")#mi("{G}")#text(" is connected. (If ")#mi("{G}")#text(" is disconnected, at least one of the components ")#mi("{F}")#text(" will have cardinality less than ")#tao-math("{\\left|V\\right|/2}", block: false)#text(".) We have an analogous statement for one-sided expansion:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 14 (Weak discrete Cheeger inequality)")]#text(" ")#metadata(none) <tao-14d25136a59e5e017992>#text(" Let ")#mi("{k \\geq 1}")#text(", and let ")#mi("{G_n}")#text(" be a family of finite ")#mi("{k}")#text("-regular graphs. Then the following are equivalent:")

#list(
[#text("(i) ")#mi("{G_n}")#text(" form a one-sided expander family.")],
[#text("(ii) There exists ")#mi("{c>0}")#text(" such that ")#mi("{h(G_n) \\geq c}")#text(" for all sufficiently large ")#mi("{n}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" Let ")#mi("{n}")#text(" be a large number. We abbreviate ")#mi("{G_n}")#text(" as ")#mi("{G = (V,E)}")#text(".")

#text("We first establish the easy direction of this proposition, namely that (i) implies (ii). If ")#mi("{n}")#text(" is large enough, then from the hypothesis (i) we have ")#mi("{\\lambda_2 \\leq (1-\\varepsilon) k}")#text(" for some ")#mi("{\\varepsilon>0}")#text(" independent of ")#mi("{n}")#text(".")

#text("Let ")#mi("{F}")#text(" be a subset of ")#mi("{V}")#text(" with ")#tao-math("{\\left|F\\right| \\leq \\left|V\\right|/2}", block: false)#text(". We consider the quantity ")#metadata(none) <tao-543b4bb6a59be2120f33>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\langle A 1_F, 1_F \\rangle_{\\ell^2(V)}.")]]

#text(" We split ")#mi("{1_F}")#text(" into a multiple ")#tao-math("{\\frac{\\left|F\\right|}{\\left|V\\right|} 1}", block: false)#text(" of the first eigenvector ")#mi("{1}")#text(", plus the remainder ")#tao-math("{1_F - \\frac{\\left|F\\right|}{\\left|V\\right|} 1}", block: false)#text(", Using the spectral decomposition of ")#mi("{A}")#text(", we can upper bound ")#link(<tao-543b4bb6a59be2120f33>)[#text("(1)")]#text(" by")

#align(center)[#tao-fit-display[#tao-math("k \\left\\|\\frac{\\left|F\\right|}{\\left|V\\right|} 1\\right\\|_{\\ell^2(V)}^2 + (1-\\varepsilon) k \\left\\|1_F - \\frac{\\left|F\\right|}{\\left|V\\right|} 1\\right\\|_{\\ell^2(V)}^2", block: true)]]

#text("which after a brief calculation evaluates to")

#align(center)[#tao-fit-display[#tao-math("(1-\\varepsilon) k \\left|F\\right| + \\varepsilon k \\frac{\\left|F\\right|^2}{\\left|V\\right|} \\leq (1-\\varepsilon/2) k |F|.", block: true)]]

#text("On the other hand, ")#link(<tao-543b4bb6a59be2120f33>)[#text("(1)")]#text(" is also equal to the number of (ordered) pairs of adjacent vertices ")#mi("{v,w \\in F}")#text(". Since each ")#mi("{v \\in F}")#text(" is adjacent to exactly ")#mi("{k}")#text(" vertices, we conclude that there are at least ")#tao-math("{\\varepsilon k\\left|F\\right|/2}", block: false)#text(" pairs ")#mi("{(v,w)}")#text(" such that ")#mi("{v \\in F}")#text(" and ")#mi("{w \\not \\in F}")#text(". Thus")

#align(center)[#tao-fit-display[#tao-math("\\left|\\partial F\\right| \\geq \\varepsilon k\\left|F\\right|/4,", block: true)]]

#text("and so ")#mi("{h(G_n) \\geq \\varepsilon k/4}")#text(", and the claim (ii) follows.")

#text("Now we establish the harder direction, in which we assume (ii) and prove (i). Thus we may assume that ")#mi("{h(G) \\geq c}")#text(" for some ")#mi("{c>0}")#text(" independent of ")#mi("{n}")#text(".")

#text("The difficulty here is basically that the hypothesis (ii) only controls the action ")#mi("{A 1_F}")#text(" of ")#mi("{A}")#text(" on indicator functions ")#mi("{1_F}")#text(", whereas the conclusion (ii) basically requires us to understand ")#mi("{A f}")#text(" for arbitrary functions ")#mi("{f \\in \\ell^2(V)}")#text(". Indeed, from the spectral decomposition one has")

#align(center)[#tao-fit-display[#tao-math("\\lambda_2 = \\sup_{f: \\left\\|f\\right\\|_{\\ell^2(V)}=1; \\langle f, 1 \\rangle_{\\ell^2(V)}=0} \\langle A f, f \\rangle_{\\ell^2(V)}", block: true)]]

#text("so it suffices to show that ")#metadata(none) <tao-f8e53476da761fb2ebac>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\langle A f, f \\rangle_{\\ell^2(V)} \\leq (1-\\varepsilon) k,")]]

#text(" whenever ")#mi("{f \\in \\ell^2(V)}")#text(" has norm one and mean zero, and ")#mi("{\\varepsilon>0}")#text(" is independent of ")#mi("{n}")#text(". Since ")#mi("{A}")#text(" has real matrix coefficients, we may assume without loss of generality that ")#mi("{f}")#text(" is real.")

#text("The mean zero hypothesis is needed to keep the function ")#mi("{f}")#text(" away from ")#mi("{1}")#text(", but it forces ")#mi("{f}")#text(" to change sign. It will be more convenient to first establish a variant of ")#link(<tao-f8e53476da761fb2ebac>)[#text("(2)")]#text(", namely that ")#metadata(none) <tao-2d1e283e6cee32edde57>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\langle A f, f \\rangle_{\\ell^2(V)} \\leq (1-c) k \\left\\|f\\right\\|_{\\ell^2(V)}^2", block: true)]]

#text(" whenever ")#mi("{f}")#text(" is non-negative and supported on a set of cardinality at most ")#tao-math("{\\left|V\\right|/2}", block: false)#text(".")

#text("Let us assume ")#link(<tao-2d1e283e6cee32edde57>)[#text("(3)")]#text(" for now and see why it implies ")#link(<tao-f8e53476da761fb2ebac>)[#text("(2)")]#text(". Let ")#mi("{f \\in \\ell^2(V)}")#text(" have norm one and mean zero. We split ")#mi("{f = f_+ - f_-}")#text(" into positive and negative parts, where ")#mi("{f_+, f_-}")#text(" are non-negative with disjoint supports. Observe that ")#mi("{\\langle A f_+, f_- \\rangle_{\\ell^2(V)} = \\langle A f_-, f_+ \\rangle_{\\ell^2(V)}}")#text(" is positive, and so")

#align(center)[#tao-fit-display[#mitex("\\langle A f, f \\rangle_{\\ell^2(V)} \\leq \\langle A f_+, f_+ \\rangle_{\\ell^2(V)} + \\langle A f_-, f_- \\rangle_{\\ell^2(V)}.")]]

#text("Also we have")

#align(center)[#tao-fit-display[#tao-math("1 = \\left\\|f_+\\right\\|_{\\ell^2(V)}^2 + \\left\\|f_-\\right\\|_{\\ell^2(V)}^2.", block: true)]]

#text("At least one of ")#mi("{f_+}")#text(" and ")#mi("{f_-}")#text(" is supported on a set of size at most ")#tao-math("{\\left|V\\right|/2}", block: false)#text(". By symmetry we may assume that ")#mi("{f_-}")#text(" has this small support. Let ")#mi("{\\sigma>0}")#text(" be a small quantity (depending on ")#mi("{c}")#text(") to be chosen later. If ")#mi("{f_-}")#text(" has ")#mi("{\\ell^2(V)}")#text(" norm at least ")#mi("{\\sigma}")#text(", then applying ")#link(<tao-2d1e283e6cee32edde57>)[#text("(3)")]#text(" to ")#mi("{f_-}")#text(" (and the trivial bound ")#tao-math("{\\langle A f, f \\rangle_{\\ell^2(V)} \\leq k \\left\\|f\\right\\|_{\\ell^2(V)}^2}", block: false)#text(" for ")#mi("{f_+}")#text(") we have")

#align(center)[#tao-fit-display[#mitex("\\langle A f, f \\rangle_{\\ell^2(V)} \\leq (1-c \\sigma^2) k")]]

#text("which would suffice. So we may assume that ")#mi("{f_-}")#text(" has norm at most ")#mi("{\\sigma}")#text(". By Cauchy-Schwarz, this implies that ")#tao-math("{\\sum_{x \\in V} f_-(x) \\leq \\sigma \\left|V\\right|^{1/2}}", block: false)#text(", and thus (as ")#mi("{f}")#text(" has mean zero) ")#tao-math("{\\sum_{x \\in V} f_+(x) \\leq \\sigma \\left|V\\right|^{1/2}}", block: false)#text(". Ordering the values ")#mi("{f_+(x)}")#text(" and applying Markov’s inequality, we see that we can split ")#mi("{f_+}")#text(" as the sum of a function ")#mi("{f^{\\prime}_+}")#text(" supported on a set of size at most ")#tao-math("{\\left|V\\right|/2}", block: false)#text(", plus an error of ")#mi("{\\ell^2}")#text(" norm ")#mi("{O(\\sigma)}")#text(". Applying ")#link(<tao-2d1e283e6cee32edde57>)[#text("(3)")]#text(" to ")#mi("{f^{\\prime}_+}")#text(" and ")#mi("{f_-}")#text(" and using the triangle inequality (and Cauchy-Schwarz) to deal with the error term, we see that")

#align(center)[#tao-fit-display[#mitex("\\langle A f, f \\rangle_{\\ell^2(V)} \\leq (1-c+O(\\sigma)) k")]]

#text("which also suffices (if ")#mi("{\\sigma}")#text(" is sufficiently small).")

#text("It remains to prove ")#link(<tao-2d1e283e6cee32edde57>)[#text("(3)")]#text(". We use the “wedding cake” decomposition, writing ")#mi("{f}")#text(" as an integral")

#align(center)[#tao-fit-display[#mitex("f = \\int_0^\\infty 1_{F_t}\\ dt")]]

#text("where ")#tao-math("{F_t := \\{ x \\in V: \\left|f(x)\\right| > t \\}}", block: false)#text(". By construction, all the ")#mi("{F_t}")#text(" have cardinality at most ")#tao-math("{\\left|V\\right|/2}", block: false)#text(" and are non-increasing in ")#mi("{t}")#text(". Also, a computation of the ")#mi("{\\ell^2}")#text(" norm shows that ")#metadata(none) <tao-4003bb018f9865700ee5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\|f\\right\\|_{\\ell^2(V)}^2 = \\int_0^\\infty 2t |F_t|\\ dt.", block: true)]]

#text(" Expanding ")#mi("{\\langle A f, f \\rangle_{\\ell^2(V)}}")#text(" and using symmetry, we obtain")

#align(center)[#tao-fit-display[#mitex("2 \\int_0^\\infty \\int_0^t \\langle A 1_{F_s}, 1_{F_t} \\rangle\\ ds dt.")]]

#text("We can bound the integrand in two ways. Firstly, since ")#mi("{A 1_{F_s}}")#text(" is bounded by ")#mi("{k}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\langle A 1_{F_s}, 1_{F_t} \\rangle \\leq k |F_t|.")]]

#text("Secondly, we may bound ")#mi("{\\langle A 1_{F_s}, 1_{F_t} \\rangle}")#text(" by ")#mi("{\\langle A 1_{F_s}, 1_{F_s} \\rangle}")#text(".")

#text("On the other hand, from the hypothesis ")#mi("{h(G) \\geq c}")#text(" we see that ")#tao-math("{\\left|\\partial F_s\\right| \\geq c \\left|F_s\\right|}", block: false)#text(", and hence")

#align(center)[#tao-fit-display[#mitex("\\langle A 1_{F_s}, 1_{F_t} \\rangle \\leq (k-c) |F_s|.")]]

#text("We insert the first bound for ")#mi("{s \\leq (1-\\varepsilon) t}")#text(" and the second bound for ")#mi("{(1-\\varepsilon) t < s \\leq t}")#text(", for some ")#mi("{\\varepsilon>0}")#text(" to be determined later, and conclude that")

#align(center)[#tao-fit-display[#mitex("\\langle A f, f \\rangle_{\\ell^2(V)} \\leq 2 \\int_0^\\infty k (1-\\varepsilon) t |F_t|\\ dt + 2 \\int_0^\\infty \\int_{(1-\\varepsilon)t}^t (k-c) |F_s|\\ ds dt.")]]

#text("Interchanging the integrals in the second integral, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\langle A f, f \\rangle_{\\ell^2(V)} \\leq 2 \\int_0^\\infty k (1-\\varepsilon) t |F_t|\\ dt + 2 \\int_0^\\infty (k-c)\\frac{\\varepsilon}{1-\\varepsilon} s |F_s|\\ ds.")]]

#text("For ")#mi("{\\varepsilon}")#text(" small enough, one can check that ")#mi("{k(1-\\varepsilon) + (k-c) \\frac{\\varepsilon}{1-\\varepsilon} < k (1- \\varepsilon^{\\prime})}")#text(" for some ")#mi("{\\varepsilon^{\\prime}>0}")#text(" depending only on ")#mi("{\\varepsilon,k,c}")#text(", and the claim ")#link(<tao-2d1e283e6cee32edde57>)[#text("(3)")]#text(" then follows from ")#link(<tao-4003bb018f9865700ee5>)[#text("(4)")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 15")]#text(" The graphs in Exercise ")#link(<tao-3cfc2e817770fc62e308>)[#text("9")]#text(" contain large sets with small boundary (e.g. ")#mi("{\\{ 1,\\ldots,m\\} \\mod n}")#text(" for ")#mi("{1 \\leq m \\leq n/2}")#text("), which gives a non-spectral way to establish that they do not form an expander family.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Show that if ")#mi("{k \\leq 2}")#text(", then the only expander families of ")#mi("{k}")#text("-regular graphs are those families of bounded size (i.e. the vertex sets ")#mi("{V_n}")#text(" have cardinality bounded in ")#mi("{n}")#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 17")]#text(" There is a more precise relationship between the edge expansion ratio ")#mi("{h(G)}")#text(" and the best constant ")#mi("{\\varepsilon}")#text(" that makes ")#mi("{G}")#text(" a one-sided ")#mi("{\\varepsilon}")#text("-expander, namely the ")#emph[#text("discrete Cheeger inequality")]#text(" ")#metadata(none) <tao-7507462c842221b8e6a8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\frac{\\varepsilon}{2} k \\leq h(G) \\leq \\sqrt{2\\varepsilon} k,")]]

#text(" first proven ")#link("http://www.ams.org/mathscinet-getitem?mr=0743744")[#text("by Dodzuik")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=0782626")[#text("by Alon-Milman")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=1447810")[#text("by Alon")]#text(" (and based on a continuous isoperimetric inequality ")#link("http://www.ams.org/mathscinet-getitem?mr=0402831")[#text("of Cheeger")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=0683635")[#text("of Buser")]#text("); see for instance ")#link("http://lucatrevisan.wordpress.com/2008/05/11/the-spectral-partitioning-algorithm/")[#text("this blog post of Luca Trevisan")]#text(" for a proof of the second inequality (the first inequality is already implicit in the proof of the above lemma). However, we will not use this more precise inequality here.")
]

#text("There is an analogous criterion for two-sided expansion, but it is more complicated to state. Here is one formulation that is quite useful:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18 (Expander mixing lemma)")]#text(" Let ")#mi("{G(V,E)}")#text(" be a ")#mi("{k}")#text("-regular graph on ")#mi("{n}")#text(" vertices which is a two-sided ")#mi("{\\varepsilon}")#text("-expander. Show that for any subsets ")#mi("{F_1, F_2}")#text(" of ")#mi("{V}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\left|E(F_1,F_2)\\right| - \\frac{k}{n} \\right|F_1\\left| \\left|F_2\\right|\\right| \\leq (1-\\varepsilon) k \\sqrt{\\left|F_1\\right| \\left|F_2\\right|}.", block: true)]]

#text("(Actually, the factors ")#tao-math("{\\left|F_1\\right|, \\left|F_2\\right|}", block: false)#text(" on the right-hand side can be refined slightly to ")#tao-math("{\\left|F_1\\right| - \\frac{\\left|F_1\\right|^2}{n}}", block: false)#text(" and ")#tao-math("{\\left|F_2\\right| - \\frac{\\left|F_2\\right|^2}{n}}", block: false)#text(" respectively.)")
]

#text("Thus, two-sided expanders behave analogously to the pseudorandom graphs that appear in the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(" (but with the caveat that expanders are usually sparse graphs, whereas pseudorandom graphs are usually dense).")

#text("Here is variant of the above lemma that more closely resembles Proposition ")#link(<tao-14d25136a59e5e017992>)[#text("14")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" ")#metadata(none) <tao-5ee38f046aa8ff08eb61>#text(" Let ")#mi("{k \\geq 1}")#text(", and let ")#mi("{G_n}")#text(" be a family of finite ")#mi("{k}")#text("-regular graphs. Show that the following are equivalent:")

#list(
[#text("(i) ")#mi("{G_n}")#text(" form a one-sided expander family.")],
[#text("(ii) There exists ")#mi("{c>0}")#text(" such that whenever ")#mi("{n}")#text(" is sufficiently large and ")#mi("{F_1, F_2}")#text(" are subsets of ")#mi("{V_n}")#text(" of cardinality at most ")#tao-math("{\\left|V_n\\right|/2}", block: false)#text(", then ")#tao-math("{\\left|E(F_1,F_2)\\right| \\leq (k-c) \\sqrt{\\left|F_1\\right| \\left|F_2\\right|}}", block: false)#text(".")]
)
]

#text("The exercises below connect expansion to some other graph-theoretic properties. On a connected graph ")#mi("{G}")#text(", one can define the ")#link("http://en.wikipedia.org/wiki/Distance_(graph_theory)")[#text("graph metric")]#text(" ")#mi("{d: G \\times G \\rightarrow {\\bf R}^+}")#text(" by defining ")#mi("{d(v,w)}")#text(" to be the length of the shortest path from ")#mi("{v}")#text(" to ")#mi("{w}")#text(" using only edges of ")#mi("{G}")#text(". This is easily seen to be a metric on ")#mi("{G}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20 (Expanders have low diameter)")]#text(" Let ")#mi("{G}")#text(" be a ")#mi("{k}")#text("-regular graph on ")#mi("{n}")#text(" vertices that is a one-sided ")#mi("{\\varepsilon}")#text("-expander for some ")#mi("{n > k \\geq 1}")#text(" and ")#mi("{\\varepsilon>0}")#text(". Show that there is a constant ")#mi("{c>0}")#text(" depending only on ")#mi("{k}")#text(" and ")#mi("{\\varepsilon}")#text(" such that for every vertex ")#mi("{v \\in V}")#text(" and any radius ")#mi("{r \\geq 0}")#text(", the ball ")#mi("{B(v,r) := \\{ w \\in V: d(v,w) \\leq r \\}}")#text(" has cardinality")

#align(center)[#tao-fit-display[#tao-math("\\left|B(v,r)\\right| \\geq \\min((1+c)^r,n).", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" first establish the weaker bound ")#tao-math("{\\left|B(v,r)\\right| \\geq \\min((1+c)^r,n/2)}", block: false)#text(".) In particular, ")#mi("{G}")#text(" has diameter ")#mi("{O(\\log n)}")#text(", where the implied constant can depend on ")#mi("{k}")#text(" and ")#mi("{\\varepsilon}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21 (Expanders have high connectivity)")]#text(" Let ")#mi("{G}")#text(" be a ")#mi("{k}")#text("-regular graph on ")#mi("{n}")#text(" vertices that is a one-sided ")#mi("{\\varepsilon}")#text("-expander for some ")#mi("{n > k \\geq 1}")#text(" and ")#mi("{\\varepsilon>0}")#text(". Show that if one removes ")#mi("{m}")#text(" edges from ")#mi("{G}")#text(" for some ")#mi("{m \\geq 0}")#text(", then the resulting graph has a connected component of size at least ")#mi("{n - C m}")#text(", where ")#mi("{C}")#text(" depends only on ")#mi("{k}")#text(" and ")#mi("{\\varepsilon}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22 (Expanders have high chromatic number)")]#text(" Let ")#mi("{G}")#text(" be a ")#mi("{k}")#text("-regular graph on ")#mi("{n}")#text(" vertices that is a two-sided ")#mi("{\\varepsilon}")#text("-expander for some ")#mi("{n > k \\geq 1}")#text(" and ")#mi("{\\varepsilon>0}")#text(".")

#list(
[#text("(i) Show that any ")#link("http://en.wikipedia.org/wiki/Independent_set_(graph_theory)")[#text("independent set")]#text(" in ")#mi("{G}")#text(" has cardinality at most ")#mi("{(1-\\varepsilon) n}")#text(".")],
[#text("(ii) Show that the ")#link("http://en.wikipedia.org/wiki/Chromatic_number#Definition_and_terminology")[#text("chromatic number")]#text(" of ")#mi("{G}")#text(" is at least ")#mi("{\\frac{1}{1-\\varepsilon}}")#text(". (Of course, this bound only becomes non-trivial for ")#mi("{\\varepsilon}")#text(" close to ")#mi("{1}")#text("; however, it is still useful for constructing bounded-degree graphs of high chromatic number and large ")#link("http://en.wikipedia.org/wiki/Girth_(graph_theory)")[#text("girth")]#text(".)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23 (Expansion and concentration of measure)")]#text(" Let ")#mi("{G}")#text(" be a ")#mi("{k}")#text("-regular graph on ")#mi("{n}")#text(" vertices that is a one-sided ")#mi("{\\varepsilon}")#text("-expander for some ")#mi("{n > k \\geq 1}")#text(" and ")#mi("{\\varepsilon>0}")#text(". Let ")#mi("{f: G \\rightarrow {\\bf R}}")#text(" be a function which is Lipschitz with some Lipschitz constant ")#mi("{K}")#text(", thus ")#tao-math("{\\left|f(v)-f(w)\\right| \\leq K d(v,w)}", block: false)#text(" for all ")#mi("{v,w \\in V}")#text(". Let ")#mi("{M}")#text(" be a median value of ")#mi("{f}")#text(" (thus ")#mi("{f(v) \\geq M}")#text(" for at least half of the vertices ")#mi("{v}")#text(", and ")#mi("{f(v) \\leq M}")#text(" for at least half the vertices ")#mi("{v}")#text("; note that the median may be non-unique in some cases.) Show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ v \\in V: \\left|f(v)-M\\right| \\geq \\lambda K \\}\\right| \\leq C n \\exp( - c \\lambda )", block: true)]]

#text("for all ")#mi("{\\lambda > 0}")#text(" and some constants ")#mi("{C, c>0}")#text(" depending only on ")#mi("{k, \\varepsilon}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 3. Random walks on expanders — ")]]

#text("We now discuss a connection between expanders and random walks, which will be of particular importance in this course as a tool for demonstrating expansion. Given a ")#mi("{k}")#text("-regular graph ")#mi("{G}")#text(" for some ")#mi("{k \\geq 1}")#text(", and an initial vertex ")#mi("{v_0 \\in G}")#text(", we define the random walk on ")#mi("{G}")#text(" starting at ")#mi("{v_0}")#text(" to be a random sequence ")#mi("{v_0, v_1, v_2, \\ldots}")#text(" of vertices in ")#mi("{G}")#text(" defined recursively by setting, once ")#mi("{v_0,\\ldots,v_i}")#text(" have been chosen, ")#mi("{v_{i+1}}")#text(" to be one of the ")#mi("{k}")#text(" neighbours of ")#mi("{v_i}")#text(", chosen at random. (The existence of such a random process can be easily justified by using the ")#link("http://en.wikipedia.org/wiki/Kolmogorov_extension_theorem")[#text("Kolmogorov extension theorem")]#text(".) For each ")#mi("{i}")#text(", let ")#mi("{\\mu^{(i)}: G \\rightarrow {\\bf R}^+}")#text(" be the probability distribution of ")#mi("{v_i}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\mu^{(i)}(v) = {\\bf P}( v_i = v ).")]]

#text("Thus ")#mi("{\\mu^{(0)}}")#text(" is the Dirac mass ")#mi("{\\delta_{v_0}}")#text(" at ")#mi("{v_0}")#text(", and we have the recursion")

#align(center)[#tao-fit-display[#mitex("\\mu^{(i+1)} = \\frac{1}{k} A \\mu^{(i)}")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\mu^{(i)} = k^{-i} A^i \\delta_{v_0}.")]]

#text("Among other things, this shows that the quantity ")#tao-math("{\\left\\| \\mu^{(i)} - \\frac{1}{\\left|V_n\\right|} \\right\\|_{\\ell^2(V_n)}}", block: false)#text(", which measures the extent to which ")#mi("{v_i}")#text(" is uniformly distributed, is non-increasing in ")#mi("{i}")#text(". The rate of this decrease is tied to the expansion properties of the graph:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" Let ")#mi("{k \\geq 1}")#text(", and let ")#mi("{G_n = (V_n,E_n)}")#text(" be a family of finite ")#mi("{k}")#text("-regular graphs. Let ")#mi("{\\alpha>1/2}")#text(". Show that the following are equivalent:")

#list(
[#text("(i) The ")#mi("{G_n}")#text(" are a two-sided expander family.")],
[#text("(ii) There is a ")#mi("{C>0}")#text(" independent of ")#mi("{n}")#text(", such that for all sufficiently large ")#mi("{n}")#text(" one has ")#tao-math("{\\left\\| \\mu^{(i)} - \\frac{1}{\\left|V_n\\right|} \\right\\|_{\\ell^2(V_n)} \\leq \\left|V_n\\right|^{-\\alpha}}", block: false)#text(" for all ")#tao-math("{i \\geq C \\log \\left|V_n\\right|}", block: false)#text(", and all choices of initial vertex ")#mi("{v_0}")#text(".")]
)
]

#text("Informally, the above exercise asserts that a two-sided expander on ")#mi("{n}")#text(" vertices is one for which random walks (from an arbitrary starting point) become very close to uniform in just ")#mi("{O(\\log n)}")#text(" steps. (Compare with, say, the graphs in ")#link(<tao-3cfc2e817770fc62e308>)[#text("(9)")]#text(", in which the random walks do not come close to mixing until time well beyond ")#mi("{n^2}")#text(", as indicated by the central limit theorem.) This rapid mixing is useful for many applications; for instance, it can be used in computer science to generate almost perfectly uniformly distributed random elements of various interesting sets (e.g. elements of a finite group); see the ")#link("http://www.ams.org/mathscinet-getitem?mr=2247919")[#text("survey of Hoory-Linial-Wigderson")]#text(" for more discussion. It is also useful in number theory to facilitate certain sieving estimates, as I hope to discuss later in this course.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 25")]#text(" In the above exercise, we assumed that the initial vertex ")#mi("{v_0}")#text(" was deterministic rather than random. However, it is easy to see (from Minkowski’s inequality) that the exercise also holds if we permit ")#mi("{v_0}")#text(" to be drawn from an arbitrary probability distribution on ")#mi("{V_n}")#text(", rather than being a single deterministic vertex. Thus one can view the uniform distribution in a two-sided expander to be a very strong attractor for all the other probability distributions on the vertex set.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 26")]#text(" The ")#mi("{\\ell^2}")#text(" norm is the most convenient norm to use when using the spectral theorem, but one can certainly replace this norm if desired by other norms (e.g. the ")#mi("{\\ell^1}")#text(" norm, which in this finite setting is the same thing as the ")#link("http://en.wikipedia.org/wiki/Total_variation_distance_of_probability_measures")[#text("total variation norm")]#text("), after adjusting the lower bound of ")#mi("{A}")#text(" slightly, since all norms on a finite-dimensional space are equivalent (though one typically has to concede some powers of ")#tao-math("{\\left|V_n\\right|}", block: false)#text(" to attain this equivalency). One can also use some other norm-like quantities here to measure distance to uniformity, such as ")#link("http://en.wikipedia.org/wiki/Entropy_(information_theory)")[#text("Shannon entropy")]#text(", although we will not do so here.")
]

#text("Note that for graphs that are only one-sided expanders instead of two-sided expanders, the random walk is only partially mixing, in that the probability distribution tends to flatten out rapidly, but not converge as rapidly (or at all) to the uniform distribution. For instance, in the case of the complete bipartite graph ")#mi("{K_{n/2,n/2}}")#text(", it is clear that the random walk simply alternates between the two vertex sets of size ")#mi("{n/2}")#text(" in the bipartite graph (although it is uniformly distributed in each set). But this lack of rapid mixing can be dealt with by replacing the random walk with the ")#emph[#text("lazy random walk")]#text(" ")#mi("{w_0, w_1, w_2, \\ldots}")#text(", which is defined similarly to the random walk ")#mi("{v_0, v_1, v_2, \\ldots}")#text(" except that ")#mi("{w_{i+1}}")#text(" is only set equal to a randomly chosen neighbour of ")#mi("{w_i}")#text(" with probability ")#mi("{1/2}")#text(", and remains equal to ")#mi("{w_i}")#text(" with probability ")#mi("{1/2}")#text(". (One can also select other probabilities here than ")#mi("{1/2}")#text(", as this will not significantly affect the exercise below.) Indeed, we have:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" Let ")#mi("{k \\geq 1}")#text(", and let ")#mi("{G_n = (V_n,E_n)}")#text(" be a family of finite ")#mi("{k}")#text("-regular graphs. Let ")#mi("{\\alpha>1/2}")#text(". Show that the following are equivalent:")

#list(
[#text("(i) The ")#mi("{G_n}")#text(" are a one-sided expander family.")],
[#text("(ii) There is a ")#mi("{C>0}")#text(" independent of ")#mi("{n}")#text(", such that for all sufficiently large ")#mi("{n}")#text(" one has ")#tao-math("{\\left\\| \\nu^{(i)} - \\frac{1}{\\left|V_n\\right|} \\right\\|_{\\ell^2(V_n)} \\leq \\left|V_n\\right|^{-\\alpha}}", block: false)#text(" for all ")#mi("{i \\geq C \\log n}")#text(", and all choices of initial vertex ")#mi("{w_0}")#text(", where ")#mi("{\\nu^{(i)}}")#text(" is the law of the random walk ")#mi("{w_i}")#text(".")]
)
]

#heading(level: 1)[#strong[#text(" — 4. Random graphs as expanders — ")]]

#text("We now turn to the task of constructing expander families of ")#mi("{k}")#text("-regular graphs. The first result in this direction was by Pinsker in 1973 (with a closely related result also established by Barzdin and Kolmogorov in 1967), who showed that if one chose a ")#mi("{k}")#text("-regular graph on ")#mi("{n}")#text(" vertices randomly, and then sent ")#mi("{n}")#text(" to infinity along a sufficiently sparse sequence, the resulting sequence would be almost surely be an expander family. (Here, of course, one needs to avoid the parity obstruction that one cannot have a ")#mi("{k}")#text("-regular graph on ")#mi("{n}")#text(" vertices if ")#mi("{k}")#text(" and ")#mi("{n}")#text(" are both odd.) We will not quite prove this result here (because it requires some understanding of the probability distribution of ")#mi("{k}")#text("-regular graphs, which has some subtleties as the parity obstruction already indicates), but establish a closely related result, in which ")#mi("{k}")#text(" is restricted to be even (to avoid parity problems) and sufficiently large (for convenience) and the ")#mi("{k}")#text("-regular graph is drawn from a slightly non-uniform distribution.")

#text("Before we do this, though, let us perform a heuristic computation as to why, when ")#mi("{k}")#text(" is fixed but large, and ")#mi("{n}")#text(" goes to infinity, one expects a “random” ")#mi("{k}")#text("-regular graph ")#mi("{G=(V,E)}")#text(" on ")#mi("{n}")#text(" vertices to be an expander. For simplicity, we work with the one-sided expansion condition. By Proposition ")#link(<tao-14d25136a59e5e017992>)[#text("14")]#text(", we would then like to say that with high probability, one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\partial F\\right| \\geq c \\left|F\\right|", block: true)]]

#text("for all ")#mi("{F \\subset V}")#text(" with cardinality at most ")#mi("{n/2}")#text(", and some ")#mi("{c>0}")#text(" independent of ")#mi("{n}")#text(". An equivalent formulation would be to say that the neighbourhood ")#mi("{N(F)}")#text(" of ")#mi("{F}")#text(" has to have cardinality at least ")#tao-math("{(1+c^{\\prime}) \\left|F\\right|}", block: false)#text(" for all ")#mi("{F \\subset V}")#text(" with cardinality at most ")#mi("{n/2}")#text(", and some ")#mi("{c^{\\prime}>0}")#text(" independent of ")#mi("{n}")#text(". Thus, we wish to exclude the possibility that there are sets ")#mi("{F \\subset F^{\\prime} \\subset V}")#text(" with ")#tao-math("{\\left|F\\right| \\leq n/2}", block: false)#text(" and ")#tao-math("{\\left|F^{\\prime}\\right| \\leq (1+c^{\\prime}) \\left|F\\right|}", block: false)#text(", for which all the edges starting from ")#mi("{F}")#text(" end up in ")#mi("{F^{\\prime}}")#text(".")

#text("To bound this failure probability, we use the union bound: we try each pair ")#mi("{F, F^{\\prime}}")#text(" in turn, bound the probability that the claim follows for that particular value of ")#mi("{F,F^{\\prime}}")#text(", and then sum in ")#mi("{F, F^{\\prime}}")#text(". The goal is to obtain a total probability bound of ")#mi("{o_{n \\rightarrow \\infty;k}(1)}")#text(", that goes to zero as ")#mi("{n \\rightarrow \\infty}")#text(" for fixed ")#mi("{k}")#text(".")

#text("Accordingly, pick ")#mi("{1 \\leq r \\leq n/2}")#text(", and then pick ")#mi("{F \\subset V}")#text(" of cardinality ")#mi("{r}")#text(", and then ")#mi("{F \\subset F^{\\prime} \\subset V}")#text(" of cardinality ")#mi("{r+r^{\\prime}}")#text(", where ")#mi("{r^{\\prime} := \\lfloor c^{\\prime} r\\rfloor + 1}")#text(" for some small constant ")#mi("{c^{\\prime}>0}")#text(" to be chosen later. For each fixed ")#mi("{r}")#text(", there are ")#mi("{\\frac{n!}{r! r^{\\prime}! (n-r-r^{\\prime})!}}")#text(" choices of ")#mi("{F}")#text(" and ")#mi("{F^{\\prime}}")#text(". For each ")#mi("{F,F^{\\prime}}")#text(", there are ")#mi("{kr}")#text(" edges emenating from ")#mi("{F}")#text(". Intuitively, if we choose the graph randomly, each edge has a probability about ")#mi("{\\frac{r+r^{\\prime}}{n}}")#text(" of landing back in ")#mi("{F^{\\prime}}")#text(", so the probability that they all do is about ")#mi("{(\\frac{r+r^{\\prime}}{n})^{kr}}")#text(". So the failure rate should be about")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq r \\leq n/2} \\frac{n!}{r! r^{\\prime}! (n-r-r^{\\prime})!} (\\frac{r+r^{\\prime}}{n})^{kr}.")]]

#text("We can bound ")#mi("{\\frac{n!}{r! r^{\\prime}! (n-r-r^{\\prime})!}}")#text(" somewhat crudely as ")#mi("{\\frac{n^{r+r^{\\prime}}}{(r+r^{\\prime})!} O(1)^r}")#text(". Applying Stirling’s formula, we obtain a bound of")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq r \\leq n/2} O(1)^r (\\frac{r+r^{\\prime}}{n})^{kr - r - r^{\\prime}}.")]]

#text("For ")#mi("{c}")#text(" small enough, ")#mi("{(r+r^{\\prime})/n}")#text(" is less than ")#mi("{0.6}")#text(" (say), and then (for ")#mi("{k}")#text(" large enough) we see that this series is bounded by ")#mi("{o_{n \\rightarrow \\infty;k}(1)}")#text(" as required.")

#text("Now we turn to the rigorous construction of random expander graphs. We will assume that ")#mi("{k}")#text(" is a large (but fixed) even integer, ")#mi("{k=2l}")#text(". To build a ")#mi("{2l}")#text("-regular graph on ")#mi("{n}")#text(" vertices ")#mi("{\\{1,\\ldots,n\\}}")#text(", what we will do is pick ")#mi("{l}")#text(" permutations ")#mi("{\\pi_1,\\ldots,\\pi_l: \\{1,\\ldots,n\\} \\rightarrow \\{1,\\ldots,n\\}}")#text(", and let ")#mi("{G}")#text(" be the graph formed by connecting ")#mi("{v}")#text(" to ")#mi("{\\pi_i(v)}")#text(" for all ")#mi("{v \\in \\{1,\\ldots,n \\}}")#text(" and ")#mi("{i=1,\\ldots,l}")#text(". This is not always a ")#mi("{2l}")#text("-regular graph, but we will be able to show the following two claims (if ")#mi("{k}")#text(" is large enough):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 28 (")#mi("{G}")#text(" can be ")#mi("{k}")#text("-regular)")]#text(" ")#metadata(none) <tao-f64551fcd6f07823cb87>#text(" The graph ")#mi("{G}")#text(" is ")#mi("{2l}")#text("-regular with probability at least ")#mi("{c-o_{n \\rightarrow \\infty;k}(1)}")#text(", where ")#mi("{c>0}")#text(" depends only on ")#mi("{k}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 29 (")#mi("{G}")#text(" usually expands)")]#text(" ")#metadata(none) <tao-3946ca64ff78d93ca610>#text(" There is an ")#mi("{\\varepsilon>0}")#text(" depending only on ")#mi("{k=2l}")#text(", such that the probability that ")#mi("{G}")#text(" is ")#mi("{2l}")#text("-regular but not a one-sided ")#mi("{\\varepsilon}")#text("-expander is ")#mi("{o_{n \\rightarrow \\infty;k}(1)}")#text(".")
]

#text("Putting these two propositions together, we conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 30")]#text(" ")#metadata(none) <tao-43bb00d0ce7790a53b91>#text(" With probability at least ")#mi("{c-o_{n \\rightarrow \\infty;k}(1)}")#text(", ")#mi("{G}")#text(" is a ")#mi("{2l}")#text("-regular one-sided ")#mi("{\\varepsilon}")#text("-expander.")
]

#text("In particular, this allows us to construct one-sided expander families of ")#mi("{k}")#text("-regular graphs for any fixed large even ")#mi("{k}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 31")]#text(" If one allowed graphs to have multiple edges and loops, then it would be possible to dispense with the need for Proposition ")#link(<tao-f64551fcd6f07823cb87>)[#text("28")]#text(", and show that ")#mi("{G}")#text(" (now viewed as a ")#mi("{2l}")#text("-regular graph with multiple edges and loops) is a one-sided ")#mi("{\\varepsilon}")#text("-expander with probability ")#mi("{1-o_{n \\rightarrow \\infty;k}(1)}")#text(". (This requires extending results such as the weak discrete Cheeger inequality to the case when there are multiple edges and loops, but this turns out to be straightforward.) However, we will not do so here as it requires one to introduce a slight amount of additional notation.")
]

#text("Let us prove Proposition ")#link(<tao-3946ca64ff78d93ca610>)[#text("29")]#text(" first, which will follow the informal sketch at the beginning of this section. By Proposition ")#link(<tao-14d25136a59e5e017992>)[#text("14")]#text(", it suffices to show that there is a ")#mi("{c>0}")#text(" depending only on ")#mi("{k}")#text(" such that the probability that ")#mi("{G}")#text(" is ")#mi("{2l}")#text("-regular with ")#mi("{h(G) \\leq c}")#text(" is ")#mi("{o_{n \\rightarrow \\infty;k}(1)}")#text(". As in the sketch, we first bound for each ")#mi("{1 \\leq r \\leq n/2}")#text(" and ")#mi("{F \\subset F^{\\prime} \\subset \\{1,\\ldots,n\\}}")#text(" with ")#tao-math("{\\left|F\\right|=r}", block: false)#text(" and ")#tao-math("{\\left|F^{\\prime}\\right| = r+r^{\\prime}}", block: false)#text(", where ")#mi("{r^{\\prime} := \\lfloor cr\\rfloor+1}")#text(", the probability that all the edges from ")#mi("{F}")#text(" end up in ")#mi("{F^{\\prime}}")#text(". A necessary condition for this to occur is that ")#mi("{\\pi_i(F) \\subset F^{\\prime}}")#text(" for each ")#mi("{i=1,\\ldots,k}")#text(". For each ")#mi("{i}")#text(", and for fixed ")#mi("{r,F,F^{\\prime}}")#text(", the probability that the random permutation ")#mi("{\\pi_i}")#text(" does this is")

#align(center)[#tao-fit-display[#mitex("\\frac{\\binom{r+r^{\\prime}}{r}}{\\binom{n}{r}} \\leq (\\frac{r+r^{\\prime}}{n})^r")]]

#text("so the total failure probability can be bounded by")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq r \\leq n/2} \\frac{n!}{r! r^{\\prime}! (n-r-r^{\\prime})!} (\\frac{r+r^{\\prime}}{n})^{kr/2}")]]

#text("which is acceptable as discussed previously.")

#text("Now we turn to Proposition ")#link(<tao-f64551fcd6f07823cb87>)[#text("28")]#text(". We observe that ")#mi("{G}")#text(" will be ")#mi("{2l}")#text("-regular unless there are distinct ")#mi("{i,j}")#text(" and a vertex ")#mi("{v \\in \\{1,\\ldots,n\\}}")#text(" such that either ")#mi("{\\pi_i(v) = \\pi_j(v)}")#text(", ")#mi("{\\pi_i(v) = \\pi_j^{-1}(v)}")#text(", ")#mi("{\\pi_i(v) = v}")#text(", or ")#mi("{\\pi_i(v) = \\pi_i^{-1}(v)}")#text(" (as such cases lead to repeated edges or loops). Unfortunately, each of these events can occur with a fairly sizeable probability (e.g. for each ")#mi("{i,j}")#text(", the probability that ")#mi("{\\pi_i(v)=\\pi_j(v)}")#text(" for some ")#mi("{v}")#text(" is about ")#mi("{1-1/e}")#text(", by the classical theory of ")#link("http://en.wikipedia.org/wiki/Derangement")[#text("derangements")]#text("), so the union bound is not enough here. Instead, we will proceed by an interpolant between the union bound and the ")#link("http://en.wikipedia.org/wiki/Inclusion%E2%80%93exclusion_principle")[#text("inclusion-exclusion formula")]#text(", known as the ")#link("http://en.wikipedia.org/wiki/Boole's_inequality")[#text("Bonferroni inequalities")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32 (Bonferroni inequalities)")]

#list(
[#text("(i) Show that if ")#mi("{n, k \\geq 0}")#text(" are natural numbers, that")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=0}^k (-1)^j \\binom{n}{j} \\geq 1_{n=0}")]]

#text("when ")#mi("{k}")#text(" is even, and")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=0}^k (-1)^j \\binom{n}{j} \\leq 1_{n=0}")]]

#text("when ")#mi("{k}")#text(" is odd, where we adopt the convention that ")#mi("{\\binom{n}{j}=0}")#text(" when ")#mi("{j>n}")#text(".")],
[#text("(ii) Show that if ")#mi("{N, k \\geq 0}")#text(" and ")#mi("{E_1,\\ldots,E_N}")#text(" are events, then")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=0}^k (-1)^j \\sum_{1 \\leq i_1 < \\ldots < i_j \\leq N} {\\bf P}( E_{i_1} \\cap \\ldots \\cap E_{i_j} ) \\geq {\\bf P}( \\overline{\\bigcup_{i=1}^N E_i} )")]]

#text("when ")#mi("{k}")#text(" is even, and")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=0}^k (-1)^j \\sum_{1 \\leq i_1 < \\ldots < i_j \\leq N} {\\bf P}( E_{i_1} \\cap \\ldots \\cap E_{i_j} ) \\leq {\\bf P}( \\overline{\\bigcup_{i=1}^N E_i} )")]]

#text("when ")#mi("{k}")#text(" is odd. (Note that the ")#mi("{k=1}")#text(" case of this inequality is essentially the union bound, and the ")#mi("{k=N}")#text(" case is the inclusion-exclusion formula.) Here we adopt the convention that the empty intersection occurs with probability ")#mi("{1}")#text(".")]
)
]

#text("We return to the proof of Proposition ")#link(<tao-f64551fcd6f07823cb87>)[#text("28")]#text(". By a conditioning argument, it suffices to show the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 33")]#text(" ")#metadata(none) <tao-af1ccaa2a9deb8cd38df>#text(" Let ")#mi("{1 \\leq i \\leq k}")#text(", and suppose that the permutations ")#mi("{\\pi_1,\\ldots,\\pi_{i-1}}")#text(" have already been chosen (and are now viewed as fixed deterministic objects). Let ")#mi("{\\pi_i: \\{1,\\ldots,n\\} \\rightarrow \\{1,\\ldots,n\\}}")#text(" be a permutation chosen uniformly at random. Then with probability at least ")#mi("{c - o_{n \\rightarrow \\infty;k}(1)}")#text(" for some ")#mi("{c>0}")#text(" depending only on ")#mi("{k}")#text(", one has ")#mi("{\\pi_i(v) \\neq \\pi_j(v), v, \\pi_i^{-1}(v)}")#text(" for all ")#mi("{v \\in \\{1,\\ldots,n\\}}")#text(" and ")#mi("{j=1,\\ldots,i-1}")#text(".")
]

#text("It remains to establish Proposition ")#link(<tao-af1ccaa2a9deb8cd38df>)[#text("33")]#text(". We modify an ")#link("http://www.ams.org/mathscinet-getitem?mr=1864966")[#text("argument of Bollobas")]#text(". Consider the set ")#mi("{\\Omega \\subset \\{1,\\ldots,n\\} \\times \\{1,\\ldots,n\\}}")#text(" of pairs")

#align(center)[#tao-fit-display[#mitex("\\Omega := \\{ (v, \\pi_j(v)): v = 1,\\ldots,n; j=1,\\ldots,i-1 \\} \\cup \\{ (v, \\pi_j(v)^{-1}): v = 1,\\ldots,n; j=1,\\ldots,i-1 \\} \\cup \\{ (v,v): v = 1,\\ldots, n \\}.")]]

#text("Each pair ")#mi("{(v,w)}")#text(" in ")#mi("{\\Omega}")#text(" gives rise to a bad event ")#mi("{(\\pi_i(v)=w)}")#text(". Each vertex ")#mi("{v}")#text(" gives rise to another bad event")

#align(center)[#tao-fit-display[#mitex("(\\pi_i(v)=\\pi_i^{-1}(v)) \\wedge ((v,\\pi_i(v)) \\not \\in \\Omega).")]]

#text("In all, this gives ")#tao-math("{\\left|\\Omega\\right|+n =: n \\alpha}", block: false)#text(" separate events for some ")#mi("{\\alpha \\sim_k 1}")#text(", which we enumerate as ")#mi("{E_1,\\ldots,E_{\\alpha n}}")#text(". Our task is to show that")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( \\overline{\\bigcup_{s=1}^{\\alpha n} E_s} ) \\geq c - o_{n \\rightarrow \\infty;k}(1).")]]

#text("It is easy to check (by direct counting arguments) that ")#metadata(none) <tao-c2ba348d1ffd70736f32>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("{\\bf P}(E_s) = \\frac{1}{n} + O(\\frac{1}{n^2})")]]

#text(" for each ")#mi("{i=1,\\ldots,\\alpha n}")#text(". More generally, for any fixed ")#mi("{j}")#text(", the same sort of counting arguments (which we leave as an exercise) the approximate independence ")#metadata(none) <tao-4f682b71153ffa91e608>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("{\\bf P}(E_{s_1} \\cap \\ldots \\cap E_{s_j}) = \\frac{1}{n^j} + O_{j,k}(\\frac{1}{n^{j+1}})")]]

#text(" for all but ")#mi("{O_{j,k}(n^{j-1})}")#text(" of the tuples ")#mi("{(s_1,\\ldots,s_j)}")#text(" with ")#mi("{1 \\leq s_1 < \\ldots < s_j \\leq \\alpha n}")#text(", with ")#metadata(none) <tao-ff6668c9c0541301b18b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("{\\bf P}(E_{s_1} \\cap \\ldots \\cap E_{s_j}) = O_{j,k}(\\frac{1}{n^j})")]]

#text(" for the exceptional tuples. (The subscripts in the ")#mi("{O()}")#text("-notation indicate that the implied constant in that notation can depend on the subscripted parameters.) In particular, we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq s_1 < \\ldots < s_j \\leq n \\alpha} {\\bf P}( E_{s_1} \\cap \\ldots \\cap E_{s_j} ) = \\frac{\\alpha^j}{j!} + O_{j,k}(\\frac{1}{n})")]]

#text("and thus by the Bonferroni inequalities")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( \\overline{\\bigcup_{s=1}^{2in} E_s} ) \\geq \\sum_{j=0}^m (-1)^j \\frac{\\alpha^j}{j!} + O_{m,k}(\\frac{1}{n})")]]

#text("for any odd ")#mi("{m}")#text(". But from Taylor series expansion, the sum on the right-hand side converges to the positive quantity ")#mi("{e^{-\\alpha}}")#text(", and the claim follows by taking ")#mi("{m}")#text(" to be a sufficiently large odd number depending on ")#mi("{k}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34")]#text(" Verify the estimates ")#link(<tao-c2ba348d1ffd70736f32>)[#text("(6)")]#text(", ")#link(<tao-4f682b71153ffa91e608>)[#text("(7)")]#text(", ")#link(<tao-ff6668c9c0541301b18b>)[#text("(8)")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35")]#text(" Show that the total number ")#mi("{N := \\sum_{s=1}^{n(i+1)} 1_{E_s}}")#text(" of failure events is asymptotically distributed according to the ")#link("http://en.wikipedia.org/wiki/Poisson_distribution")[#text("Poisson distribution")]#text(" of intensity ")#mi("{2i}")#text(", or more precisely that")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(N = m) = \\frac{(2i)^m e^{-2i}}{m!} + o_{n \\rightarrow \\infty;k,m}(1)")]]

#text("for any natural number ")#mi("{m}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 36")]#text(" Another way to establish Proposition ")#link(<tao-f64551fcd6f07823cb87>)[#text("28")]#text(", via the “swapping method”, was pointed out to me by Brendan McKay ")#link("http://mathoverflow.net/questions/86118/non-enumerative-proof-that-there-are-many-derangements/86202#86202")[#text("here")]#text(". The key observation is that if ")#mi("{l}")#text(" permutations ")#mi("{\\pi_1,\\ldots,\\pi_l}")#text(" have ")#mi("{m}")#text(" problematic edges (i.e. edges that are either repeated or loops), and then one applies ")#mi("{m}")#text(" random transpositions to the ")#mi("{\\pi_1,\\ldots,\\pi_l}")#text(" (as selected at random), then with probability ")#mi("{\\gg_m n^{-m}}")#text(" (if ")#mi("{n}")#text(" is sufficiently large depending on ")#mi("{m}")#text("), all problematic edges are erased and one obtains a random regular graph. Conversely, if one starts with a random regular graph and applies ")#mi("{m}")#text(" random transpositions, the probability of obtaining ")#mi("{m}")#text(" problematic edges as a result is ")#mi("{O_m(n^{-m})}")#text(". Combining the two facts, we see that ")#mi("{p_m}")#text(" is the probability of having ")#mi("{m}")#text(" problematic edges, then ")#mi("{p_0 \\gg p_m}")#text(" for each fixed ")#mi("{m}")#text(" (and ")#mi("{n}")#text(" sufficiently large depending on ")#mi("{m}")#text("). Since the expected number of problematic edges is bounded ,the desired bound ")#mi("{p_0 \\gg 1}")#text(" then follows from Markov’s inequality and the pigeonhole principle.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37")]#text(" Show that “one-sided” can be replaced with “two-sided” in Proposition ")#link(<tao-3946ca64ff78d93ca610>)[#text("29")]#text(" and hence in Corollary ")#link(<tao-43bb00d0ce7790a53b91>)[#text("30")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 38")]#text(" It turns out that the random ")#mi("{k}")#text("-regular graphs formed by taking ")#mi("{l}")#text(" permutations as indicated above, and conditioning on the event that there are no “collisions” (so that one genuinely gets a ")#mi("{k}")#text("-regular graph) does not quite give a uniform distribution on the ")#mi("{k}")#text("-regular graphs. However, it is close enough to one that any property which is true with probability ")#mi("{1-o_{n \\rightarrow \\infty;k}(1)}")#text(" for this model of random ")#mi("{k}")#text("-regular graph, is also true with probability ")#mi("{1-o_{n \\rightarrow \\infty;k}(1)}")#text(" for uniform ")#mi("{k}")#text("-regular graphs, and conversely. This fact (known as ")#emph[#text("contiguity")]#text(" of the two random models, and analogous to the concept of mutually absolutely continuous measures in measure theory) is established for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=1725006")[#text("in this survey of Wormald")]#text(". As a consequence of this fact (and a more refined version of the above analysis), one can show that ")#mi("{1-o_{n \\rightarrow \\infty;k}(1)}")#text(" of all ")#mi("{k}")#text("-regular graphs on ")#mi("{n}")#text(" vertices are ")#mi("{\\varepsilon}")#text("-expanders for some ")#mi("{\\varepsilon = \\varepsilon_k > 0}")#text(" if ")#mi("{k \\geq 3}")#text(" (assuming of course the parity requirement that ")#mi("{nk}")#text(" be even, otherwise there are no ")#mi("{k}")#text("-regular graphs at all).")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (52)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c60fb002fac958ac61874654f834513f8ad2e79a220118feb88e48e16dcdbf14-72de779f47ae137c9e2b8759a76762c685f9a30b0f71ca71c1fbff6d491caf95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Wieland")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-112380")[#strong[#text("Ben Wieland")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2011")])]

#text("Some comments on one-sided vs two-sided:")

#text("The statement of Exercise 1 seems unnecessarily complicated to me. Such an induced subgraph is graph is necessarily disconnected from the rest of the graph, so one might talk of a bipartite component. Moreover, for the final summary, where you assume it is already that it is connected, the condition is simply that the whole graph is not bipartite.")

#text("It seems to me a little misleading to say that on a one-sided expander “the random walk will not mix rapidly.” This implies that it will mix slowly, but the failure is that it will not mix. To the extent that it does mix, approaching uniformity on each the vertices of a each parity, it does so quickly. Of course, your example make this clear.")

#emph[#text("[Fair enough; I’ve edited the text accordingly. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9d6c587f0179a9e9cd79521e2b6e113d0cb1f812e0a24e3149da324234575b5-b393abd8e95f8ff6c0382edd82d629c7d085349005e0c6c3c8751e025646bf26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-112467")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2011")])]

#text("Looking at Exercise 7, I am wondering if when we take the size of the graph to infinity (I don’t know yet which way we will do this) it will be useful to seek better control of the form ")#tao-math("\\left|\\left|\\bigtriangledown f\\right|\\right|_2\\ge C\\left|\\left|f\\right|\\right|_q", block: false)#text(", say, where how large we can take ")#mi("q")#text(" will be determined by the “dimension” ")#mi("d")#text(" of the limit graph (and ")#mi("C")#text(" depending on ")#mi("d")#text("). Could higher derivatives and general Sobolev inequalities be useful for studying graphs? It would make sense that we could have these on a family of graphs converging (in some sense) to the torus or to ")#mi("\\mathbb{R}^d")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-112476")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2011")])]

#text("Yes, one can certainly study these sorts of Sobolev inequalities for “finite-dimensional” graphs that resemble discretisations of finite-dimensional Riemannian manifolds. That’s a different regime, though, from the expander graph regime, which behaves more like an infinite-dimensional space (or like the large-scale geometry of hyperbolic space), for instance with balls that grow exponentially rather than polynomially.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9d6c587f0179a9e9cd79521e2b6e113d0cb1f812e0a24e3149da324234575b5-b393abd8e95f8ff6c0382edd82d629c7d085349005e0c6c3c8751e025646bf26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-112471")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2011")])]

#text("Exercise 15 (where we are considering the discrete time semigroup ")#mi("e^{-t(1-A/k)}")#text(") makes me wonder if analogously to Exercise 7 we can characterize two-sided expander graphs as those having a log-Sobolev inequality.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-112480")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2011")])]

#text("There are some entropy inequalities for expander graphs that vaguely resemble log-Sobolev inequalities, but the log Sobolev constants themselves are not completely favourable; for instance, in ")#link("http://www.ams.org/mathscinet-getitem?mr=2120475")[#text("this paper of Bobkov and Tetali")]#text(" it is shown that the log-Sobolev constant of a bounded degree expander tends to zero like ")#tao-math("1/\\log\\left|V\\right|", block: false)#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af1765d48075e3d38cf3d17191ac75be2b88871327cf97fbe71a9098ab39f065-8a737e0a8aa0dfca201ac287e7f01696272b8632bbaa16460ee93741dbd21a55.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of itai")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-112489")[#strong[#text("itai")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2011")])]

#text("An expanders problem: Is there a family ")#mi("G_n")#text(" of finite d-regular graphs, with size growing to infinity,")#linebreak()#text(" so that all balls in all the ")#mi("G_n")#text("‘s are uniform expanders?")

#text("Since the graphs restricted to balls may not be regular, by expanders we mean bounded degree graphs with a uniform edge expansion.")

#text("(That is, there is ")#mi("h > 0")#text(", for all ")#mi("r> 0")#text(" and any v in any of the graphs ")#mi("G_n")#text("‘s")#linebreak()#text(" the ball B(v,r) is h- expander, expander with a uniform expansion constant h.")#linebreak()#text(" Note e.g. that if ")#mi("G_n")#text(" is a sequence of expanders with girth growing to infinity, then if r is smaller then girth then balls of radius r are trees and thus not uniformly expanders as r grows).")

#text("I conjecture that there is no such family.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 2: Cayley graphs and Kazhdan’s property (T) « What’s new")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-113278")[#strong[#text("254B, Notes 2: Cayley graphs and Kazhdan’s property (T) « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2011")])]

#text("[…] the previous set of notes we introduced the notion of expansion in arbitrary -regular graphs. For the rest of the course, we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0b9a28ae3d72eaa2b1caf0da5217d9217092be0c19e4e8f241357adcdf66fb7-fe2df1914822a413e57175e1d4c02bbee1992d8238be631f51377ccffa315705.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arie Israel")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-113343")[#strong[#text("Arie Israel")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2011")])]

#text("In the second part of Exercise 1, I think the statement should read as: $\\lambda_n=-k$ if and only if $G$ contains a non-empty bipartite graph as a connected component.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1de735fa27a69a8efe44ff56d5e17917d2a5dbf93881626187879849dc9c239-76f06f3a3d2ea44d49c3b6253babead8b129d6205db6034382ea04835d035fd1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gabriel")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-113534")[#strong[#text("Gabriel")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2011")])]

#text("In Exercise 10, shouldn’t the inequality in (ii) be reverted? Thanks! ")#emph[#text("[Actually, I believe the inequality signs are in the right direction here. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-113698")[#strong[#text("Weekly Picks « Mathblogging.org — the Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2011")]

#text("[…] Terry Tao started a lecture notes series on expander graphs while E. Kowalski mused about his notes on expanders and two different Caley graphs of the group of order 2. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82e494cbb93604545c9a4905674939e942fe943e6102f1c972d6f4672e2857bb-af836d930689c7a8bf7d6376575f8a0e200c0e826d217f3b19db103860d0df48.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of david joyner")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-115058")[#strong[#text("david joyner")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2011")])]

#text("Is there a typo in the statement of Remark 2? I think the 2 is supposed to go outside the square root in both the statement of the Alon-Boppana bound and the definition of the Ramanujan graph.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-115092")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2011")])]

#text("I think the title ought to read “254B…” (rather than “245B…”). ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 3: Quasirandom groups, expansion, and Selberg’s 3/16 theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-116198")[#strong[#text("254B, Notes 3: Quasirandom groups, expansion, and Selberg’s 3/16 theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2011")])]

#text("[…] (compare with the expander mixing lemma, Exercise 9 from Notes 1). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-116369")[#strong[#text("Введение в теорию экспандеров « sementry blog")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2011")]

#text("[…] английском (Terence Tao, UCLA): ")#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/")[#text("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/")]#text(" На русском (Андрей Ромащенко, CSClub): […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-116396")[#strong[#text("Piero Giacomelli (@pierogiacomelli)")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2011")]

#text("thanks for sharing your notes on expanders, apart form the survey of Hoory do you have any other introductory paper to suggest?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-116422")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2011")])]

#text("Some further surveys on expanders can be found at the class web page ")#link("http://www.math.ucla.edu/~tao/254b.1.12w/")[#text("http://www.math.ucla.edu/~tao/254b.1.12w/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df59c61dafad977652e1a4415300e637a8501d5d7e59c432f4383a646ecacb77-58c8f9a60c5bb2d85ec88e6a038629761e6ce21a45bcd1854a3d5a4c6c08a384.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jayadev Athreya")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-116465")[#strong[#text("Jayadev Athreya")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2011")])]

#text("Just as a historical note, shouldn’t the name of Margulis be mentioned here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-116468")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2011")])]

#text("Margulis’s contributions are discussed in Notes 2: ")#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/")[#text("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-116769")[#strong[#text("254B, Notes 1: Basic theory of expander graphs « Another Word For It")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2011")]

#text("[…] 254B, Notes 1: Basic theory of expander graphs […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4db7f931b7831845d5ad9a27b1a6319cf65192de9454a28bb64b50d9e9f9875b-09b27acb458a076240e9968737c42ca77e5653b215ae746d53770326465c5608.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-121655")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2012")])]

#text("Couple of typos: There seems to be a superfluous ")#mi("\\delta")#text(" in Proposition 4 (discrete Cheeger) just above equation (3), and a few lines below that you say ")#mi("\\langle Af_+, f_-\\rangle")#text(" is negative when I think you mean positive.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9d6c587f0179a9e9cd79521e2b6e113d0cb1f812e0a24e3149da324234575b5-b393abd8e95f8ff6c0382edd82d629c7d085349005e0c6c3c8751e025646bf26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-123612")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2012")])]

#text("So does a Lovasz local lemma turn out not to be the right tool for Proposition 5? Our example didn’t meet the low-dependency hypothesis of the version I tried, but I don’t know if there are stronger variants.")

#text("Also some small typos: in the formula in Exercise 9 we should have ")#tao-math("\\left|E(F_1,F_2)\\right|", block: false)#text(". In proofs of Props 5 and 8 should we also include the bad events ")#mi("\\pi_i(v)=\\pi_j^{-1}(v)")#text("? And a few lines under Proposition 8, surely we don’t want to consider ")#mi("\\pi_i(v)=\\pi_i(v)")#text(" a rare event! :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-123620")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2012")])]

#text("Thanks for the corrections! I tried for a while to use the Lovasz local lemma but eventually decided that there wasn’t enough genuine independence in the problem for the lemma (or the various variants of it that I know of) to be applicable. I am still wondering if there is a “non-enumerative” proof of Proposition 5 that does not require so much exact computation; I posed this as a problem on MathOverflow but thus far none of the proposed arguments seems to give this without using at least as much computation as is given in the above post.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da1d070b54aeb9fa4ebc7e53260c827cd0e93db5a2e6025ce04c4afbfcc2bab0-b6c853235856d1b166cd9702c6b945c6d2d4e5ed3fb635aab6cb2848913321be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Choongbum Lee")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-124914")[#strong[#text("Choongbum Lee")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2012")])]

#text("It seems like there is something missing in condition (ii) of Exercise 10; a vertex disjoint union of two copies of k-regular two-sided expanders will satisfy the condition (it is a disconnected graph). Shouldn’t the condition look more similar to something like that given in Exercise 9?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-124917")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2012")])]

#text("If a graph ")#mi("G = (V,E)")#text(" is a vertex-disjoint union of two subgraphs, one of the two vertex classes, say ")#mi("V_1")#text(", will have cardinality at most ")#tao-math("\\left|V\\right|/2", block: false)#text(". Setting ")#mi("F_1")#text(" and ")#mi("F_2")#text(" to both be ")#mi("V_1")#text(", we see that (ii) will fail.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da1d070b54aeb9fa4ebc7e53260c827cd0e93db5a2e6025ce04c4afbfcc2bab0-b6c853235856d1b166cd9702c6b945c6d2d4e5ed3fb635aab6cb2848913321be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Choongbum Lee")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-124937")[#strong[#text("Choongbum Lee")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2012")])]

#text("Aha! You are right. Thank you very much.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/527a47a35134db930c9632716e4782971bbc7a5cc2023fd36f0b090549ff8ca7-92cdfb033d9be6da1e1fff6a583a5cfb5c83445c7f9ccc311fe0006a2fd5b3b6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikhail")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-125735")[#strong[#text("Mikhail")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2012")])]

#text("1. I would be thankful for more detailed information on Pinsker’s paper of 1973. Have you seen it? Is it possible to download it from somewhere?")

#text("Some corrections:")

#text("2. “Bardin” should be “Barzdin” (the beginning of Section 4).")

#text("3. Before Proposition 5: $\\pi_1,\\dots,\\pi_l$ map $\\{1,\\dots,n\\}$ onto $\\{1,\\dots,n\\}$.")

#text("4. Exercise 13: I think that you meant “large girth” rather than “low girth”.")

#text("5. End of the proof of Proposition 4: $k$ is lost from the right-hand side of")#linebreak()#text(" ")#tao-fit-display[#tao-math("\\left|\\partial F\\right|\\ge\\epsilon\\left|F\\right|/2", block: true)]#text(".")

#text("6. Exercise 14: It is strange to ask for existence of $M$ since $M$ is your notation for a median.")

#text("7. Exercises 15 and 16. Possibly it is better to replace $A$ by another letter since $A$ is your notation for the adjacency matrix.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-125755")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2012")])]

#text("Thanks for the corrections!")

#text("I have unfortunately not been able to find an online link to Pinsker’s paper (M. Pinsker, On the complexity of a concentrator, 7th")#linebreak()#text(" Annual Teletraffi\u{e}c Conference (1973), 1-4), and have been forced to rely on secondary sources. If any reader knows of a link to the original paper, it would be greatly appreciated.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-125781")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2012")])]

#text("There you go:")

#link("http://itc-conf.org/fileadmin/ITCBibDatabase/1973/pinsker731.pdf")[#text("Click to access pinsker731.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-125790")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2012")])]

#text("Thanks!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-129678")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2012")])]

#text("In Proposition 4 you write:")

#text("“Let ")#mi("{F}")#text(" be a subset of ")#mi("{V}")#text(" with ")#tao-math("{\\left|F\\right| \\leq \\left|V\\right|/2}", block: false)#text(". We consider the quantity")

#mi("\\displaystyle \\langle A 1_F, 1_F \\rangle_{\\ell^2(V)}. \\ \\ \\ \\ \\ (1)")#text("”")

#text("I believe this formula should read")

#mi("\\displaystyle \\langle A 1_{V - F}, 1_F \\rangle_{\\ell^2(V)}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-129680")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2012")])]

#text("Oops, nevermind. I mistook it for the boundary of F.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/118e2200ffa7910da0fec1d6013d9d0fe77fc9d718d4f42dc2fca15eebe48d49-795b8150327b1ea029c0675956091f2d56adbd0f7e162346a42533efa03cac01.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abhishek Bhowmick")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-130318")[#strong[#text("Abhishek Bhowmick")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2012")])]

#text("In the very last step of the proof of Proposition 4 (Cheeger inequality, just before example 2 starts), in the step after you reverse the order of integration of s and t, I think it should be s|F_s|ds instead of just |F_s|ds")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0074d4c837416ed381718904fcdcede6a732277a3e77090286dce3e4290fa45-4888a993b4cc021398bad1c06afd99eb856a65c0987c8b1000647982e82bb6b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michał Kotowski")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-136535")[#strong[#text("Michał Kotowski")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2012")])]

#text("Do you know any direct applications of the concentration of measure for expanders? (i.e. results where having tight concentration for such graphs would be an important element of the proof)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-136545")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2012")])]

#text("Well, the fact that expanders have logarithmic diameter is used all over the place, and this can be viewed as a special case of concentration of measure (applied to the distance function from some arbitrary origin). But I don’t know of a place in the literature where concentration of measure is directly used in some application.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7bd79ccc17907103f59d86fb20316d47cd1b97b6e5da97c6784bb34597ecff0-0d4f3e22196665cd23c0b63eb88a1c5d6701288f8a5ee038d7b21ba2ca261e47.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-151312")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2012")])]

#text("Terry,")

#text("In Remark 1, you say “in the sense that the second eigenvalue of … exceeds the first by at least…”")

#text("Shouldn’t it be reversed?")

#text("Thanks")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/99ee7f99a639e2a4bd9599491d56f28620d1fc1721a343806c3764b9c434c2b8-c04800ce3a44c1cc686ea968759b53fa21bdf380ebcc98285f258a9fe4e42c08.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of robinson")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-155053")[#strong[#text("robinson")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2012")])]

#text("I’m a little confused by a missing factor of 2 in the proof of Proposition 6, immediately following the words “so that the total probability of failure is…” Now the preceeding sentence has bounded the probability that ")#mi("\\pi")#text(" sends $\\latex F$ to a subset of ")#mi("F^{\\prime}")#text(", and this probability is raised to the power of k in the ensuing sum. But to generate a k-regular graph, we used ")#mi("k/2")#text(" permutations, so it seems to me it should be raised to the power of ")#mi("k/2")#text("; some additional argumentation is necessary to justify raising it to the power of $k$. Is this right or did I miss a key detail?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/99ee7f99a639e2a4bd9599491d56f28620d1fc1721a343806c3764b9c434c2b8-c04800ce3a44c1cc686ea968759b53fa21bdf380ebcc98285f258a9fe4e42c08.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of robinson")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-155054")[#strong[#text("robinson")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2012")])]

#text("On second thought, I guess this is glossed over because it makes no difference – ")#mi("k")#text(" is taken be large enough anyway.")

#emph[#text("[Corrected anyway – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d75c1e506dc65356d0041c9ba11820cec5bd9dc4f51b1bfa0b6c26aa39d6149-4bb23d56be5f0bf17292f32542c2eca8123dbf53855b965bdefda6353bbcc15c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew Kahle")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-175844")[#strong[#text("Matthew Kahle")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2012")])]

#text("It seems like starting with “Now we turn to the rigorous construction of random expander graphs.” there are several places where it says “$3K$-regular graphs. Should this say “$k$-regular” instead?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/344faee768b6e7932113a74d1bd89280b36f19bf8751a5f7957f785fdfec0353-c298759329a9d2990ece551ac57dc96bd23760205031ee2c1962ed554b4cf06c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ajthemathematician")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-218704")[#strong[#text("ajthemathematician")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2013")])]

#text("Reblogged this on ")#link("http://ajxuhangjun2007.wordpress.com/2013/03/06/3/")[#text("amathematician")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e992c9d6bd69dd80732ca5390a35dcd2f41def765f7553ed62128e4fb9b21ecb-4768d42197c2c4f660569b64d7705d69c7ec4ef2e7e1cbee040f09e195407ee1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 1: Basic theory of expander graphs | What’s new | Peter's ruminations")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-231446")[#strong[#text("254B, Notes 1: Basic theory of expander graphs | What’s new | Peter's ruminations")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2013")])]

#text("[…] ")#link(<tao-863ddcae98b9eaebcff9>)[#text("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#more-5525")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Expansion in finite simple groups of Lie type | What's new")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-244503")[#strong[#text("Expansion in finite simple groups of Lie type | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2013")])]

#text("[…] we show that the distinction between one-sided expansion and two-sided expansion (see this set of lecture notes of mine for definitions) is erased in the context of Cayley graphs of bounded degree, in the sense […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5d712ad6f5a78a749b10dcdbda5168b68f6d5ff12e664d7855e70552b1c0a71-59b6006e9bb2847d088bda33144700abbac588df66fab6affdfe638646317ddf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Shamov")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-248842")[#strong[#text("Alexander Shamov")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2013")])]

#text("Is there a way of doing Exercise 10 without relying on the harder part of Cheeger’s inequality (or re-proving it)? Or maybe a point of view from which both become easy?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3e94b6d26f1352c6e42edf0523d8ba285514da6d7e1f63265a4d3eadee064f4-1d0d0299c31ffffc7cd49371c46ed8bcc94088f6929e880648b7049c98d5b557.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shivkumar Chandrasekaran")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-275666")[#strong[#text("Shivkumar Chandrasekaran")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2014")])]

#text("In Exercise 7 should it be ")#mi("f: V\\rightarrow C")#text(", rather than ")#mi("f:G\\rightarrow C")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ce44bb49d10a8f3a290040b7d0b25b1e17a3f55b751fe165cc3629e44fea1dd-c3949ee0ec00fede36b8c75d4696e63ddd29645bef9b115bb836b225bb650e61.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sai")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-452610")[#strong[#text("sai")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2015")])]

#text("Do you know how to prove question Exercise 12 ??")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8bf5f0c70af1dbe68292e79edaca19680a66dab85ac63905790e0b67001275ac-cfbbb1c7f09f9b4414091b10ef8d99624cd65a712b49028f6912fb4ca8d42b0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ConstantinK")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-550525")[#strong[#text("ConstantinK")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2020")])]

#text("Proof of (i) implies (ii) of Proposition 4: In the last sentence of the proof, I believe you want to replace ")#mi("\\varepsilon")#text(" by ")#mi("k\\varepsilon")#text(" in the two displayed equations. Moreover, I believe there is also a small argumentative inaccuracy in this last sentence of the proof. Namely, you write that there are ")#tao-math("\\varepsilon k\\left|F\\right|/2", block: false)#text(" pairs ")#mi("v,w")#text(" so that ")#mi("v \\in F")#text(" and ")#mi("w \\not\\in F")#text(". In fact, you count here ordered pairs ")#mi("(v,w)")#text(" so this double counts the number of edges. Using your definition of ")#mi("E(F,V\\backslash F)")#text(", we thus only can conclude ")#tao-math("\\left|\\partial F\\right| \\geq \\varepsilon k\\left|F\\right|/4", block: false)#text(" and not over ")#mi("2")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8bf5f0c70af1dbe68292e79edaca19680a66dab85ac63905790e0b67001275ac-cfbbb1c7f09f9b4414091b10ef8d99624cd65a712b49028f6912fb4ca8d42b0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ConstantinK")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-550531")[#strong[#text("ConstantinK")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2020")])]

#text("The “problem” here is somewhat the definition of ")#mi("E(F_1,F_2)")#text(". Namely, with the above definition it holds that $")#tao-math("E(F,F) + 2E(F,F^c) = k\\left|F\\right|,", block: false)#text("$ as ")#mi("E(F,F)")#text(" double counts the edges, whereas ")#mi("E(F,F^c)")#text(" does not")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ConstantinK")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-551530")[#strong[#text("ConstantinK")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2020")])]

#text("In Exercise 20, all the constants can be chosen to depend only on ")#mi("\\varepsilon")#text(" and in particular not on ")#mi("k")#text(". (I don’t know if you care about this.)")

#emph[#text("[Fair enough, but given that the various measures of expansion are only equivalent up to constants that depend on ")#mi("k")#text(", the independence of the growth constant here on ")#mi("k")#text(" using this specific measure of expansion ")#mi("\\varepsilon")#text(" can be slightly misleading – for instance if one wishes to control ")#mi("c")#text(" in terms of the spectral gap ")#mi("h(G)")#text(" instead then I think there is now a ")#mi("k")#text("-dependence. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/562f778a672442c36297f0c0c5e35b7944dd7437388dfb60710ae12dee5e6add-263540662e9778abf68885a1f03e6dfebbe13cf20c048d7e863f8113eb90a95f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohammed Mannan")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-673459")[#strong[#text("Mohammed Mannan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2023")])]

#text("For Exercise 19, I believe we need a stronger form of the mixing lemma closer to the statement in Exercise 18 to show equivalence of (i) and (ii). This is for the following reason: In exercise 18, if we only have one-sided expansion, we can prove the inequality without the absolute value. Thus E(F_1,F_2) <= (1-epsilon)k*root(F_1 F_2)root(1-F_1/n)root(1-F_2/n) + (k/n)|F_1||F_2| <= k((1/2) + (1-epsilon)/2)root(F_1 F_2). (The second inequality holds when |F_1|, |F_2| <= n/2 = |V|/2. As is currently stated in Exercise 19, we can prove equivalence if \"two-sided\" is replaced with \"one-sided\". The converse to expander mixing proven by Bilu and Linial in their 2006 paper \"Lifts, discrepancy, and nearly optimal spectral gap\" uses the stronger statement of the expander mixing lemma as in exercise 18.")

#emph[#text("[“two-sided” replaced with “one-sided” in Exercise 19 – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/562f778a672442c36297f0c0c5e35b7944dd7437388dfb60710ae12dee5e6add-263540662e9778abf68885a1f03e6dfebbe13cf20c048d7e863f8113eb90a95f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohammed Mannan")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-673467")[#strong[#text("Mohammed Mannan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2023")])]

#text("For exercise 20, the inequality |B(v,r)| >= min( (1+c)^r, n/2) is straightforward induction, using estimates for the lower bound of the size of the boundary of the ball depending on the interior when the size of the ball is less than or equal to n/2. I am not sure how to sharpen this to min( (1+c)^r, n). If s is the greatest such that |B(v,s)| <= n/2, then one can show that B(v,s+t)^complement = n – C n exp(-ct) but I’m not sure if we can proceed by bounding n- C n exp(-ct) from below by (n/2)*(1 + c’)^t >= (1 + c’)^(s + t).")

#emph[#text("[If two balls ")#mi("B(v,r), B(w,r)")#text(" both have cardinality greater than ")#mi("n/2")#text(", then they intersect, hence ")#mi("w")#text(" lies in ")#mi("B(v,2r)")#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/562f778a672442c36297f0c0c5e35b7944dd7437388dfb60710ae12dee5e6add-263540662e9778abf68885a1f03e6dfebbe13cf20c048d7e863f8113eb90a95f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohammed Mannan")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-673471")[#strong[#text("Mohammed Mannan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2023")])]

#text("If we have a sharp bound |B(v,r)| >= min( (1+c)^r, |V(G)|), I believe if there is an epsilon-expander family G_n with vertex size going to infinity, and v_n, w_n in V(G_n) are such that d(v_n, w_n) = diam(G_n), then the number of points a distance diam(G_n) from v_n must also go to infinity. So an epsilon-expander family contradicting the previous sentence would contradict the sharp bound. If we did not require k-regular and instead required degree-bounded-by-k for our definition of expander graph, it seems like we should be able to construct such a contradictory family, so to prove a sharp bound k regularity would be crucial.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63a34c8ee437cd2a53331b5d67fd8a59555e48ec563469fe3515ebccb94eb2f6-532003e2fdaa60099792939a24fdb6e2c4a175e9340a37c2c9e322d0d54e4ed5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-688048")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2025")])]

#text("Hi, there is something wrong with how the definitions, examples, etc., appear. Here is an image showing the same: ")#link("https://ibb.co/bggFJmYh")[#text("https://ibb.co/bggFJmYh")]

#emph[#text("[Unfortunately I cannot replicate this issue on my end. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/#comment-692614")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2026")])]

#text("great post I only point out that when dealing with expander the definition of the graph object by using the expansion function is more formal and clean IMHO. Professor Kowalsky released a very interesting set of notes on the subject ")#link("https://people.math.ethz.ch/~kowalski/expander-graphs.pdf")[#text("https://people.math.ethz.ch/~kowalski/expander-graphs.pdf")]#text(". I recently released a preprint that link expander graphs to evolution algebras allowing to redefine in algebrical terms the expander constant of a graph ")#link("https://arxiv.org/abs/2605.12672")[#text("https://arxiv.org/abs/2605.12672")]
]
