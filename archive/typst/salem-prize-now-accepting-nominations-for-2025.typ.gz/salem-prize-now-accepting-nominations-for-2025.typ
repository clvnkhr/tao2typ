// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/07/08/salem-prize-now-accepting-nominations-for-2025/
// Converted to Typst by tao2typ: "2026-10-14T16:39:18.654487+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Salem Prize now accepting nominations for 2025", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Salem Prize now accepting nominations for 2025")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 July 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/07/08/salem-prize-now-accepting-nominations-for-2025/")[#text("https://terrytao.wordpress.com/2025/07/08/salem-prize-now-accepting-nominations-for-2025/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The ")#link("https://en.wikipedia.org/wiki/Salem_Prize")[#text("Salem prize")]#text(" was established in 1968 and named in honor of Raphaël Salem (1898-1963), a mathematician famous notably for his deep study of the links between Fourier series and number theory and for pioneering applications of probabilistic methods to these fields. It was not awarded from 2019-2022, due to both the COVID pandemic and the death of Jean Bourgain who had been almost single-handedly administering the prize, but is ")#link("https://www.ias.edu/math/activities/salem-prize")[#text("now active again")]#text(", being administered by Akshay Ventakesh and the IAS. I chair the scientific committee for this prize, whose other members are Guy David and Mikhail Sodin. Last year, the prize was awarded to ")#link("https://www.ias.edu/math/2023-salem-prize-winners")[#text("https://www.ias.edu/math/2023-salem-prize-winners")]#link("https://www.ias.edu/math/2024-salem-prize-winners")[#text("Miguel Walsh and Yilin Wang")]#text(".")

#text("Nominations for the 2025 Salem Prize are ")#link("https://www.mathprograms.org/db/programs/1788")[#text("now open")]#text(" until September 15th. Nominations should include a CV of the nominee and a nomination letter explaining the significance of the nominee’s work. Supplementary documentation, such as supporting letters of recommendation or key publications, can additionally be provided, but are not required.")

#text("Nominees may be individuals from any country or institution. Preference will be given to nominees who have received their PhD in the last ten years, although this rule may be relaxed if there are mitigating personal circumstances, or if there have been few Salem prize winners in recent years. Self-nominations will not be considered, nor are past Prize winners or Scientific Committee members eligible.")

#text("The prize does not come with a direct monetary award, but winners will be invited to visit the IAS and to give a lecture associated with the award of the prize.")

#text("See also ")#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/")[#text("the previous year’s announcement")]#text(" of the Salem prize nomination period.")

#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee00f54fa7ae8d6fc174b8d1bc4e473ffc1bcec1e5b88e1067306a55f30b0e67-f11de4c7cf137244780c13ff80c6c8d387a468fa9a9cafb1dd893797a7c8a64e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mason Porter")]], [#link("https://terrytao.wordpress.com/2025/07/08/salem-prize-now-accepting-nominations-for-2025/#comment-688415")[#strong[#text("Mason Porter")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2025")])]

#text("Given the name of the prize, at first I was hoping that it is awarded in recognition of achievements in mathematical witchcraft (which I suppose is true in a certain sense for some areas of mathematics).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/07/08/salem-prize-now-accepting-nominations-for-2025/#comment-688416")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2025")])]

#text("I nominate Hong Wang (again).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/07/08/salem-prize-now-accepting-nominations-for-2025/#comment-688420")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2025")])]

#text("She will win the Fields medal instead.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2012b6135b45cac63d35b9bd8c81bf95cb591596b76c826fa2a4adf0049718d2-3b843ddfe0611b39de10e584527432998e3ef7958bfbccc9faa356ef89b70d42.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Pezzi")]], [#link("https://terrytao.wordpress.com/2025/07/08/salem-prize-now-accepting-nominations-for-2025/#comment-688417")[#strong[#text("Daniel Pezzi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2025")])]

#text("Is there any chance of writing of blog post detailing the mathematical accomplishments of the winners? There was an announcement for nominations for the last two prizes, but not a follow up on the winners that I could find.")

#text("(or, perhaps, make one of the conditions of receiving the prize a guest post on here!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64c91e76a2a38e004d9e7c7cc97c366fc52afb23e10d669036bf9106d5150dfc-aa59039b0cffa858b50a47812fe9891dc74a5930c8b1e5187b839c4a3b498827.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/07/08/salem-prize-now-accepting-nominations-for-2025/#comment-688521")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2025")])]

#text("I nominate Danylo Radchenko.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/07/08/salem-prize-now-accepting-nominations-for-2025/#comment-688900")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2025")])]

#text("The Salem prize for 2025 is <A HREF=”")#link("https://www.ias.edu/math/2025-salem-prize-winners")[#text("https://www.ias.edu/math/2025-salem-prize-winners")]#text("“>awarded separately</A> to Vesselin Dimitrov and Hong Wang.")
]
