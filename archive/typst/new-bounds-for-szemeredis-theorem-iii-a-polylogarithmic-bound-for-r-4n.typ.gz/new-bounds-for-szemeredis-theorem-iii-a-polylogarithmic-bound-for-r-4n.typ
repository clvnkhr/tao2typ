// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/05/05/new-bounds-for-szemeredis-theorem-iii-a-polylogarithmic-bound-for-r_4n/
// Converted to Typst by tao2typ: "2026-10-14T10:40:24.919590+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "New bounds for Szemerédi’s theorem, III: A polylogarithmic bound for r_4(N)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("New bounds for Szemerédi’s theorem, III: A polylogarithmic bound for r_4(N)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 May 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/05/05/new-bounds-for-szemeredis-theorem-iii-a-polylogarithmic-bound-for-r_4n/")[#text("https://terrytao.wordpress.com/2017/05/05/new-bounds-for-szemeredis-theorem-iii-a-polylogarithmic-bound-for-r_4n/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://people.maths.ox.ac.uk/greenbj/")[#text("Ben Green")]#text(" and I have (finally!) uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/1705.01703")[#text("New bounds for Szemerédi’s theorem, III: A polylogarithmic bound for ")#mi("{r_4(N)}")]#text("“, submitted to ")#link("https://www.cambridge.org/core/journals/mathematika")[#text("Mathematika")]#text(". This is the sequel to ")#link("http://www.ams.org/mathscinet-getitem?mr=2481952")[#text("two")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2508645")[#text("previous")]#text(" papers (and an ")#link("https://arxiv.org/abs/1205.1330")[#text("erratum to the former paper")]#text("), concerning quantitative versions of ")#link("https://en.wikipedia.org/wiki/Szemer%C3%A9di%27s_theorem")[#text("Szemerédi’s theorem")]#text(" in the case of length four progressions. This sequel has been delayed for over a decade for a number of reasons, but we have finally managed to write the arguments up to our satisfaction and submit it (to a special issue of Mathematika honouring the work of Klaus Roth).")

#text("For any natural number ")#mi("{N}")#text(", define ")#mi("{r_4(N)}")#text(" to be the largest cardinality of a subset ")#mi("{A}")#text(" of ")#mi("{[N] = \\{1,\\dots,N\\}}")#text(" which does not contain any non-trivial arithmetic progressions ")#mi("{a, a+r, a+2r, a+3r}")#text(" of length four (where “non-trivial” means that ")#mi("{r}")#text(" is non-zero). Trivially we have ")#mi("{r_4(N) \\leq N}")#text(". In 1969, ")#link("http://www.ams.org/mathscinet-getitem?mr=245555")[#text("Szemerédi showed")]#text(" that ")#mi("{r_4(N) = o(N)}")#text(". However, the decay rate that could be theoretically extracted from this argument (and from several subsequent proofs of this bound, including ")#link("http://www.ams.org/mathscinet-getitem?mr=369311")[#text("one by Roth")]#text(") were quite poor. The first significant quantitative bound on this quantity was ")#link("http://www.ams.org/mathscinet-getitem?mr=1631259")[#text("by Gowers")]#text(", who showed that ")#mi("{r_4(N) \\ll N (\\log \\log N)^{-c}}")#text(" for some absolute constant ")#mi("{c>0}")#text(". In ")#link("http://www.ams.org/mathscinet-getitem?mr=2508645")[#text("the second paper in the above-mentioned series")]#text(", we managed to improve this bound to ")#mi("{r_4(N) \\ll N \\exp( - c \\sqrt{\\log \\log N})}")#text(". In this paper, we improve the bound further to ")#mi("{r_4(N) \\ll N (\\log N)^{-c}}")#text(", which seems to be the limit of the methods. (We remark that if we could take ")#mi("{c}")#text(" to be larger than one, this would imply the length four case of a ")#link("https://en.wikipedia.org/wiki/Erd%C5%91s_conjecture_on_arithmetic_progressions")[#text("well known conjecture of Erdös")]#text(" that any set of natural numbers whose sum of reciprocals diverges would contain arbitrarily long arithmetic progressions. Thanks to the work ")#link("http://www.ams.org/mathscinet-getitem?mr=2811612")[#text("of Sanders")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=3509957")[#text("of Bloom")]#text(", the corresponding case of the conjecture for length three conjectures is nearly settled, as it is known that for the analogous bound on ")#mi("{r_3(N)}")#text(" one can take any ")#mi("{c}")#text(" less than one.)")

#text("Most of the previous work on bounding ")#mi("{r_4(N)}")#text(" relied in some form or another on the ")#emph[#text("density increment argument")]#text(" introduced ")#link("http://www.ams.org/mathscinet-getitem?mr=51853")[#text("by Roth")]#text(" back in 1953; roughly speaking, the idea is to show that if a dense subset ")#mi("{A}")#text(" of ")#mi("{[N]}")#text(" fails to contain arithmetic progressions of length four, one seeks to then locate a long subprogression of ")#mi("{[N]}")#text(" in which ")#mi("{A}")#text(" has increased density. This was the basic method for instance underlying our previous bound ")#mi("{r_4(N) \\ll N \\exp( - c \\sqrt{\\log \\log N})}")#text(", as well as a finite field analogue of the bound ")#mi("{r_4(N) \\ll N (\\log N)^{-c}}")#text("; however we encountered significant technical difficulties for several years in extending this argument to obtain the result of the current paper. Our method is instead based on “energy increment arguments”, and more specifically on establishing quantitative version of a Khintchine-type recurrence theorem, similar to the qualitative recurrence theorems established (in the ergodic theory context) ")#link("http://www.ams.org/mathscinet-getitem?mr=2138068")[#text("by Bergelson-Host-Kra")]#text(", and (in the current combinatorial context) by ")#link("http://www.ams.org/mathscinet-getitem?mr=2815606")[#text("Ben Green and myself")]#text(".")

#text("One way to phrase the latter recurrence theorem is as follows. Suppose that ")#mi("{A \\subset [N]}")#text(" has density ")#mi("{\\delta}")#text(". Then one would expect a “randomly” selected arithmetic progression ")#mi("{{\\bf a}, {\\bf a}+{\\bf r}, {\\bf a}+2{\\bf r}, {\\bf a}+3{\\bf r}}")#text(" in ")#mi("{[N]}")#text(" (using the convention that random variables will be in boldface) to be contained in ")#mi("{A}")#text(" with probability about ")#mi("{\\delta^4}")#text(". This is not true in general, however it was shown by Ben and myself that for any ")#mi("{\\eta>0}")#text(", there was a set of shifts ")#mi("{r \\in [-N,N]}")#text(" of cardinality ")#mi("{\\gg_{\\delta,\\eta} N}")#text(", such that for any such ")#mi("{r}")#text(" one had")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( {\\bf a}, {\\bf a}+r, {\\bf a}+2r, {\\bf a}+3r \\in A ) \\geq \\delta^4 - \\eta")]]

#text("if ")#mi("{{\\bf a}}")#text(" was chosen uniformly at random from ")#mi("{[N]}")#text(". This easily implies that ")#mi("{r_4(N) = o(N)}")#text(", but does not give a particularly good bound on the decay rate, because the implied constant in the cardinality lower bound ")#mi("{\\gg_{\\delta,\\eta} N}")#text(" is quite poor (in fact of tower-exponential type, due to the use of regularity lemmas!), and so one has to take ")#mi("{N}")#text(" to be extremely large compared to ")#mi("{\\delta,\\eta}")#text(" to avoid the possibility that the set of shifts in the above theorem consists only of the trivial shift ")#mi("{r=0}")#text(".")

#text("We do not know how to improve the lower bound on the set of shifts to the point where it can give bounds that are competitive with those in this paper. However, we can obtain better quantitative results if we permit ourselves to ")#emph[#text("couple")]#text(" together the two parameters ")#mi("{{\\bf a}}")#text(" and ")#mi("{{\\bf r}}")#text(" of the length four progression. Namely, with ")#mi("{A}")#text(", ")#mi("{\\delta}")#text(", ")#mi("{\\eta}")#text(" as above, we are able to show that there exist random variables ")#mi("{{\\bf a}, {\\bf r}}")#text(", not necessarily independent, such that ")#metadata(none) <tao-fb8e20fc2e4c3f248c60>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("{\\bf P}( {\\bf a}, {\\bf a}+{\\bf r}, {\\bf a}+2{\\bf r}, {\\bf a}+3{\\bf r} \\in A ) \\geq \\delta^4 - \\eta")]]

#text("and such that we have the non-degeneracy bound")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( {\\bf r} = 0 ) \\ll \\exp( \\eta^{-O(1)} ) / N.")]]

#text("This then easily implies the main theorem.")

#text("The energy increment method is then deployed to locate a good pair ")#mi("{({\\bf a}, {\\bf r})}")#text(" of random variables that will obey the above bounds. One can get some intuition on how to proceed here by considering some model cases. Firstly one can consider a “globally quadratically structured” case in which the indicator function ")#mi("{1_A}")#text(" “behaves like” a globally quadratic function such as ")#mi("{F( \\alpha n^2 )}")#text(", for some irrational ")#mi("{\\alpha}")#text(" and some smooth periodic function ")#mi("{F: {\\bf R}/{\\bf Z} \\rightarrow {\\bf R}}")#text(" of mean ")#mi("{\\delta}")#text(". If one then takes ")#mi("{{\\bf a}, {\\bf r}}")#text(" to be uniformly distributed in ")#mi("{[N]}")#text(" and ")#mi("{[-\\varepsilon N, \\varepsilon N]}")#text(" respectively for some small ")#mi("{\\varepsilon>0}")#text(", with no coupling between the two variables, then the left-hand side of ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(" is approximately of the form ")#metadata(none) <tao-225637ee5f9591be070a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\int_{(x,y,z,w) \\in ({\\bf R}/{\\bf Z})^4: x-3y+3z-w = 0} F(x) F(y) F(z) F(w)")]]

#text("where the integral is with respect to the probability Haar measure, and the constraint ")#mi("{x-3y+3z-w=0}")#text(" ultimately arises from the algebraic constraint")

#align(center)[#tao-fit-display[#mitex("\\alpha {\\bf a}^2 - 3 \\alpha ({\\bf a}+{\\bf r})^2 + 3 \\alpha ({\\bf a}+2{\\bf r})^2 - \\alpha ({\\bf a}+3{\\bf r})^2 = 0.")]]

#text("However, an application of the Cauchy-Schwarz inequality and Fubini’s theorem shows that the integral in ")#link(<tao-225637ee5f9591be070a>)[#text("(2)")]#text(" is at least ")#mi("{(\\int_{{\\bf R}/{\\bf Z}} F)^4}")#text(", which (morally at least) gives ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(" in this case.")

#text("Due to the nature of the energy increment argument, it also becomes necessary to consider “locally quadratically structured” cases, in which ")#mi("{[N]}")#text(" is partitioned into some number of structured pieces ")#mi("{B_c}")#text(" (think of these as arithmetic progressions, or as “Bohr sets), and on each piece ")#mi("{B_c}")#text(", ")#mi("{1_A}")#text(" behaves like a locally quadratic function such as ")#mi("{F_c( \\alpha_c n^2 )}")#text(", where ")#mi("{\\alpha_c}")#text(" now varies with ")#mi("{c}")#text(", and the mean of ")#mi("{F_c}")#text(" will be approximately ")#mi("{\\delta}")#text(" on the average after averaging in ")#mi("{c}")#text(" (weighted by the size of the pieces ")#mi("{B_c}")#text("). Now one should select ")#mi("{{\\bf a}}")#text(" and ")#mi("{{\\bf r}}")#text(" in the following coupled manner: first one chooses ")#mi("{{\\bf a}}")#text(" uniformly from ")#mi("{[N]}")#text(", then one defines ")#mi("{{\\bf c}}")#text(" to be the label ")#mi("{c}")#text(" such that ")#mi("{{\\bf a} \\in B_c}")#text(", and then selects ")#mi("{{\\bf r}}")#text(" uniformly from a set ")#mi("{B_{c,\\varepsilon}}")#text(" which is related to ")#mi("{B_c}")#text(" in much the same way that ")#mi("{[-\\varepsilon N, \\varepsilon N]}")#text(" is related to ")#mi("{[N]}")#text(". If one does this correctly, the analogue of ")#link(<tao-225637ee5f9591be070a>)[#text("(2)")]#text(" becomes")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\int_{(x,y,z,w) \\in ({\\bf R}/{\\bf Z})^4: x-3y+3z-w = 0} F_{\\mathbf c}(x) F_{\\mathbf c}(y) F_{\\mathbf c}(z) F_{\\mathbf c}(w),")]]

#text("and one can again use Cauchy-Schwarz and Fubini’s theorem to conclude.")

#text("The general case proceeds, very roughly, by an iterative argument. At each stage of the iteration, one has some sort of quadratic model of ")#mi("{1_A}")#text(" which involves a decomposition of ")#mi("{[N]}")#text(" into structured pieces ")#mi("{B_c}")#text(", and a quadratic approximation to ")#mi("{1_A}")#text(" on each piece. If this approximation is accurate enough (or more precisely, if a certain (averaged) local Gowers uniformity norm ")#mi("{U^3}")#text(" of the error is small enough) to model the count in ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(1)")]#text(" (for random variables ")#mi("{{\\bf a}, {\\bf r}}")#text(" determined by the above partition of ")#mi("{[N]}")#text(" into pieces ")#mi("{B_c}")#text("), and if the frequencies (such as ")#mi("{\\alpha_c}")#text(") involved in the quadratic approximation are “high rank” or “linearly independent over the rationals” in a suitably quantitative sense, then some version of the above arguments can be made to work. If there are some unwanted linear dependencies in the frequencies, we can do some linear algebra to eliminate one of the frequencies (using some geometry of numbers to keep the quantitative bounds under control) and continue the iteration. If instead the approximation is too inaccurate, then the error will be large in a certain averaged local Gowers uniformity norm ")#mi("{U^3}")#text(". A significant fraction of the paper is then devoted to establishing a quantitative ")#emph[#text("inverse theorem")]#text(" for that norm that concludes (with good bounds) that the error must then locally correlate with locally quadratic phases, which can be used to refine the quadratic approximation to ")#mi("{1_A}")#text(" in a manner that significantly increases its “energy” (basically an ")#mi("{L^2}")#text(" norm). Such energy increments cannot continue indefinitely, and when they terminate we obtain the desired claim.")

#text("There are existing inverse theorems for ")#mi("{U^3}")#text(" type norms in the literature, going back to ")#link("http://www.ams.org/mathscinet-getitem?mr=1631259")[#text("the pioneering work of Gowers mentioned previously")]#text(", and relying on arithmetic combinatorics tools such as Freiman’s theorem and the Balog-Szemerédi-Gowers lemma, which are good for analysing the “")#mi("{1\\%}")#text("-structured homomorphisms” that arise in Gowers’ argument. However, when we applied these methods to the local Gowers norms we obtained inferior quantitative results that were not strong enough for our application. Instead, we use arguments from a ")#link("http://www.ams.org/mathscinet-getitem?mr=1844079")[#text("different paper of Gowers")]#text(" in which he tackled Szemerédi’s theorem for arbitrary length progressions. This method produces “")#mi("{99\\%}")#text("-structured homomorphisms” associated to any function with large Gowers uniformity norm; however the catch is that such homomorphisms are initially supported only on a sparse unstructured set, rather than a structured set such as a Bohr set. To proceed further, one first has to locate inside the sparse unstructured set a sparse ")#emph[#text("pseudorandom")]#text(" subset of a Bohr set, and then use “error-correction” type methods (such as “majority-vote” based algorithms) to locally upgrade this ")#mi("{99\\%}")#text("-structured homomorphism on pseudorandom subsets of Bohr sets to a ")#mi("{100\\%}")#text("-structured homomorphism on the entirety of a Bohr set. It is then possible to use some “approximate cohomology” tools to “integrate” these homomorphisms (and discern a key “local symmetry” property of these homomorphisms) to locate the desired local quadratic structure (in much the same fashion that a ")#mi("{1}")#text("-form on ")#mi("{{\\bf R}^n}")#text(" that varies linearly with the coordinates can be integrated to be the derivative of a quadratic function if we know that the ")#mi("{1}")#text("-form is closed). These portions of the paper are unfortunately rather technical, but broadly follow the methods already used in previous literature.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/05/05/new-bounds-for-szemeredis-theorem-iii-a-polylogarithmic-bound-for-r_4n/#comment-480327")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2017")])]

#text("Is this method effective in finding any explicit numerical value for the exponent ")#mi("c")#text(" ?")#linebreak()#text(" Is there any conjecture on the maximal possible value of such ")#mi("c")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/05/05/new-bounds-for-szemeredis-theorem-iii-a-polylogarithmic-bound-for-r_4n/#comment-480338")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2017")])]

#text("In principle the exponent can be explicitly calculated from the arguments in the paper, but we made no efforts to optimise it and so it is likely to be quite terrible (on the order of ")#mi("10^{-100}")#text(" or so). As I mentioned in the blog post, the Erdos conjecture on arithmetic progressions roughly corresponds to the assertion that ")#mi("c")#text(" can be taken to be larger than 1. In view of the strong bounds now available for three-term progressions in the finite field setting, it is probably reasonable to conjecture that ")#mi("c")#text(" can in fact be taken to be arbitrarily large.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/05/05/new-bounds-for-szemeredis-theorem-iii-a-polylogarithmic-bound-for-r_4n/#comment-480348")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2017")])]

#text("Motivated by the introduction in your paper, for each ")#mi("k \\geq 3")#text(", define ")#mi("c_k")#text(" as the supremum over all nonnegative exponents ")#mi("c")#text(" for which ")#mi("r_k(N) \\ll N(\\log N)^{-c}")#linebreak()#text(" Sanders’ result implies that ")#mi("c_3 \\geq 1")#text(" and your result implies that ")#mi("c_4 >0")#text(". Is it possible that all ")#mi("c_k")#text(" are positive and finite ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/05/05/new-bounds-for-szemeredis-theorem-iii-a-polylogarithmic-bound-for-r_4n/#comment-480373")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2017")])]

#text("I would conjecture this to be the case. The known Behrend-type lower bounds are of the shape ")#mi("r_k(N) \\gg N \\exp( - \\log^{c_k} N )")#text(", and it is quite conceivable that these are close to sharp, though it looks like we are still far off from settling this claim (unless there is some further breakthrough, e.g. if the polynomial method that works so well for the cap set problem can somehow be extended to the cyclic group setting).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/05/05/new-bounds-for-szemeredis-theorem-iii-a-polylogarithmic-bound-for-r_4n/#comment-480345")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2017")])]

#text("In the definition of ")#mi("r_4(N)")#text(", it is not clear why such (unique) largest set ")#mi("A")#text(" should exist.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/05/05/new-bounds-for-szemeredis-theorem-iii-a-polylogarithmic-bound-for-r_4n/#comment-480372")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2017")])]

#text("There are only finitely many subsets ")#mi("A")#text(" of ")#mi("[N]")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/05/05/new-bounds-for-szemeredis-theorem-iii-a-polylogarithmic-bound-for-r_4n/#comment-480378")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2017")])]

#text("I meant that (since the property of such subset ")#mi("A")#text(" is translation-invariant) it is possible that there are several maximal subsets ")#mi("A")#text(" with this property without any largest one (on which the above definition of ")#mi("r_4(N)")#text(" is based), so in the above definition of ")#mi("r_4(N)")#text(" it seems clearer to replace “cardinality of the largest subset ")#mi("A")#text("” by “largest cardinality of a subset ")#mi("A")#text("” (as in the definition of ")#mi("r_4(N)")#text(" in the abstract of your paper.)")

#emph[#text("[Wording changed – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5532625b5077728d3b36ee69ade51a3091f374b35f8cc6e36a974cda3cca0d11-051c4e4b8691f0d7e520b97aa39a976bf545595ab27c2e734bec837b4024af09.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klaus85")]], [#link("https://terrytao.wordpress.com/2017/05/05/new-bounds-for-szemeredis-theorem-iii-a-polylogarithmic-bound-for-r_4n/#comment-480386")[#strong[#text("Klaus85")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2017")])]

#text("“This sequel has been delayed for over a decade for a number of reasons”. I find this very surprising. Does it mean that you had the results already a decade ago, and just did not write it up? Do you have more close-to-finished projects from very long time ago which are unpublished?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/05/05/new-bounds-for-szemeredis-theorem-iii-a-polylogarithmic-bound-for-r_4n/#comment-480497")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2017")])]

#text("It’s a long story, and I’ve actually forgotten parts of it at this point, but basically the first version of our argument (based on density increment methods) turned out to have some significant technical difficulties, so we put it aside for a few years until we found a different argument (based on energy increment methods) which worked; however the write up of this paper was extremely technical and we did not feel it was readable enough to be in a publishable state (though we did share the preprint with some close colleagues who requested it), so the paper again languished. About a year ago we were contacted to submit an article for a special issue of Mathematika honouring the work of Klaus Roth, and this encouraged us to rewrite the (quite lengthy) paper to a state that we were both happy with for submission, but we were only able to do so after we were both at MSRI earlier this year, and could devote a significant portion of time to the task.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0294d933df36a41ccf093f3aa51c2871c09d90fe74122b89b84100af6572448d-9e1c808e0cec5e9b34094623ef1f509d45b7de0012c99b795703fcb40e417309.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathlog")]], [#link("https://terrytao.wordpress.com/2017/05/05/new-bounds-for-szemeredis-theorem-iii-a-polylogarithmic-bound-for-r_4n/#comment-480392")[#strong[#text("mathlog")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2017")])]

#text("Why do you call it a polylogarithmic bound?")

#emph[#text("[ See ")#link("https://en.wikipedia.org/wiki/Time_complexity#Polylogarithmic_time")[#text("https://en.wikipedia.org/wiki/Time_complexity#Polylogarithmic_time")]#text(" -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/05/05/new-bounds-for-szemeredis-theorem-iii-a-polylogarithmic-bound-for-r_4n/#comment-480424")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2017")])]

#text("Page 2, paragraph 2 in the paper contains: “A major")#linebreak()#text(" breakthrough was made by in 1998 by Gowers”; but should probably say, “A major breakthrough was made by Gowers in 1998”?")

#emph[#text("[Thanks, this will be corrected in the next version of the ms. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/05/05/new-bounds-for-szemeredis-theorem-iii-a-polylogarithmic-bound-for-r_4n/#comment-480431")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2017")])]

#text("Is there any apparent obstruction for applying this method (with similar estimates) to ")#mi("r_5(N)")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/05/05/new-bounds-for-szemeredis-theorem-iii-a-polylogarithmic-bound-for-r_4n/#comment-480494")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2017")])]

#text("There are two obstacles to this currently. The first is that one would need a quantitative (local) inverse U^4 theorem of comparable strength to the quantitative (local) inverse U^3 theorem that is used in this paper, and at present no such quantitative theorem is known. Secondly (and more seriously), the application of Cauchy-Schwarz inequality that lower bounds (2) is not available for the analogue to (2) in the k=5 setting (which is a somewhat complicated quintilinear integral expression on a certain nilmanifold); indeed there is a counterexample by Ruzsa in the appendix to the Bergelson-Host-Kra paper mentioned in the post that suggests that no analogue of the Khintchine-type recurrence theorems proven here in the k=4 case will be available for k equal to 5 or higher.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Danilo")]], [#link("https://terrytao.wordpress.com/2017/05/05/new-bounds-for-szemeredis-theorem-iii-a-polylogarithmic-bound-for-r_4n/#comment-480503")[#strong[#text("Danilo")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2017")])]

#text("Perfect!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/05/05/new-bounds-for-szemeredis-theorem-iii-a-polylogarithmic-bound-for-r_4n/#comment-480553")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2017")])]

#text("It seems that people are very close to prove that any set of natural numbers whose sum of reciprocals diverges would contain arithmetic progressions of length 3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/05/05/new-bounds-for-szemeredis-theorem-iii-a-polylogarithmic-bound-for-r_4n/#comment-481214")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2017")])]

#text("Comments to the bibliography:")#linebreak()#text(" * [8]: “93-128” –> “93–128”")#linebreak()#text(" * [9]: The title should be in italic")#linebreak()#text(" * [10]: “261-264” –> “261–264”")#linebreak()#text(" * [16]: “327,1–29” –> “327, 1–29”")#linebreak()#text(" * [23]: The URL should be put in typewriter font, i.e., \\href{https://arxiv.org/abs/1205.1330}{\\texttt{https://arxiv.org/abs/1205.1330}}.")#linebreak()#text(" * [26]: “2009. 180–204” –> “2009, 180–204”")#linebreak()#text(" * [32]: “AMS 1994” –> “AMS, 1994”")#linebreak()#text(" * [33]: “R.A.” –> ” R. A.”")#linebreak()#text(" * [40]: The title should be in italic")#linebreak()#text(" * [44]: “Hungar.56” –> “Hungar. 56”")#linebreak()#text(" * [44]: “no. 1-2” –> “no. 1–2”")#linebreak()#text(" * [46]: Should “2004 El Escorial conference proceedings” be in italic?")

#emph[#text("[Thanks, this will be corrected in the next version of the ms. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0071c5503c4fb88b4c53152b9ea1a78a0826281448827e2a6f15161b620a1bfc-f421b3ac8b1e2310c90ba85e4cd3e6b890c69b102b7dedfbcfa6f8574466c7ab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Leng")]], [#link("https://terrytao.wordpress.com/2017/05/05/new-bounds-for-szemeredis-theorem-iii-a-polylogarithmic-bound-for-r_4n/#comment-641112")[#strong[#text("James Leng")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2022")])]

#text("Is there a typo in Theorem 8.1 condition (8.2)? I believe i and i + 1 should be switched around?")

#emph[#text("[Yes, this is a typo – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/05/05/new-bounds-for-szemeredis-theorem-iii-a-polylogarithmic-bound-for-r_4n/#comment-644161")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2022")])]

#text("Shouldn’t it be ")#mi("P(r=0) = O( \\exp(\\eta^{-O(1)})/N )")#text(" (without the negative sign in the argument of exp)?")

#emph[#text("[Corrected, thanks – T.]")]
]
