// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/
// Converted to Typst by tao2typ: "2026-10-14T15:20:02.222409+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath15, fifth thread: finishing off the test problem?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath15, fifth thread: finishing off the test problem?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 March 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/")[#text("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is the fifth “research” thread of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("Polymath15 project")]#text(" to upper bound the ")#link("https://en.wikipedia.org/wiki/De_Bruijn%E2%80%93Newman_constant")[#text("de Bruijn-Newman constant")]#text(" ")#mi("{\\Lambda}")#text(", continuing ")#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/")[#text("this post")]#text(". Discussion of the project of a non-research nature can continue for now in ")#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/")[#text("the existing proposal thread")]#text(". Progress will be summarised at ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("this Polymath wiki page")]#text(".")

#text("We have almost finished off the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem")[#text("test problem")]#text(" of showing that ")#mi("{H_t(x+iy) \\neq 0}")#text(" whenever ")#mi("{t = y = 0.4}")#text(". We have two useful approximations for ")#mi("{H_t}")#text(", which we have denoted ")#mi("{A^{eff}+B^{eff}}")#text(" and ")#mi("{A^{eff}+B^{eff}-C^{eff}}")#text(", and a normalising quantity ")#mi("{B^{eff}_0}")#text(" that is asymptotically equal to the above expressions; see ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem")[#text("the wiki page")]#text(" for definitions. In practice, the ")#mi("{A^{eff}+B^{eff}}")#text(" approximation seems to be accurate within about one or two significant figures, whilst the ")#mi("{A^{eff}+B^{eff}-C^{eff}}")#text(" approximation is accurate to about three or four. We have an effective upper bound")

#align(center)[#tao-fit-display[#tao-math("\\left|H_t - A^{eff} - B^{eff}\\right| \\leq E_1 + E_2 + E_3^*", block: true)]]

#text("where the expressions ")#mi("{E_1,E_2,E_3^*}")#text(" are quite small in practice (")#mi("{E_3^*}")#text(" is typically about two orders of magnitude smaller than the main term ")#mi("{B^{eff}_0}")#text(" once ")#mi("{x}")#text(" is moderately large, and the error terms ")#mi("{E_1,E_2}")#text(" are even smaller). See ")#link("http://michaelnielsen.org/polymath1/index.php?title=Controlling_H_t-A-B/B_0")[#text("this page for details")]#text(". In principle we could also obtain an effective upper bound for ")#tao-math("{\\left|H_t - (A^{eff} + B^{eff} - C^{eff})\\right|}", block: false)#text(" (the ")#mi("{E_3^*}")#text(" term would be replaced by something smaller).")

#text("The ratio ")#mi("{\\frac{A^{eff}+B^{eff}}{B^{eff}_0}}")#text(" takes the form of a difference ")#mi("{\\sum_{n=1}^N \\frac{b_n}{n^s} - e^{i\\theta} \\sum_{n=1}^N \\frac{a_n}{n^s}}")#text(" of two Dirichlet series, where ")#mi("{e^{i\\theta}}")#text(" is a phase whose value is explicit but perhaps not terribly important, and the coefficients ")#mi("{b_n, a_n}")#text(" are explicit and relatively simple (")#mi("{b_n}")#text(" is ")#mi("{\\exp( \\frac{t}{4} \\log^2 n)}")#text(", and ")#mi("{a_n}")#text(" is approximately ")#mi("{(n/N)^y b_n}")#text("). To bound this away from zero, we have found it advantageous to mollify this difference by multiplying by an Euler product ")#mi("{\\prod_{p \\leq P} (1 - \\frac{b_p}{p^s})}")#text(" to cancel much of the initial oscillation; also one can take advantage of the fact that the ")#mi("{b_n}")#text(" are real and the ")#mi("{a_n}")#text(" are (approximately) real. See ")#link("http://michaelnielsen.org/polymath1/index.php?title=Controlling_A%2BB/B_0")[#text("this page")]#text(" for details. The upshot is that we seem to be getting good lower bounds for the size of this difference of Dirichlet series starting from about ")#mi("{x \\geq 5 \\times 10^5}")#text(" or so. The error terms ")#mi("{E_1,E_2,E_3^*}")#text(" are already quite small by this stage, so we should soon be able to rigorously keep ")#mi("{H_t}")#text(" from vanishing at this point. We also have a scheme for lower bounding the difference of Dirichlet series below this range, though it is not clear at present how far we can continue this before the error terms ")#mi("{E_1,E_2,E_3^*}")#text(" become unmanageable. For very small ")#mi("{x}")#text(" we may have to explore some faster ways to compute the expression ")#mi("{H_t}")#text(", which is still difficult to compute directly with high accuracy. One will also need to bound the somewhat unwieldy expressions ")#mi("{E_1,E_2}")#text(" by something more manageable. For instance, right now these quantities depend on the continuous variable ")#mi("{x}")#text("; it would be preferable to have a quantity that depends only on the parameter ")#mi("{N = \\lfloor \\sqrt{ \\frac{x}{4\\pi} + \\frac{t}{16} }\\rfloor}")#text(", as this could be computed numerically for all ")#mi("{x}")#text(" in the remaining range of interest quite quickly.")

#text("As before, any other mathematical discussion related to the project is also welcome here, for instance any summaries of previous discussion that was not covered in this post.")

#heading(level: 1)[#text("Comments (121)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493397")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2018")])]

#text("As a preliminary step towards bounding ")#mi("E_1, E_2")#text(" by more tractable quantities, I have computed in ")#link("http://michaelnielsen.org/polymath1/index.php?title=Controlling_H_t-A-B/B_0#Estimation_of_E_1.2CE_2")[#text("http://michaelnielsen.org/polymath1/index.php?title=Controlling_H_t-A-B/B_0#Estimation_of_E_1.2CE_2")]#text(" an upper bound on ")#tao-math("E_1/\\left|B^{eff}_0\\right|", block: false)#text(" and ")#tao-math("E_2/\\left|B^{eff}_0\\right|", block: false)#text(" that depends only on ")#mi("N")#text(" (and on ")#mi("t, y")#text(" of course) and not directly on ")#mi("x")#text(" or ")#mi("T")#text(", thus the bound is uniform in each interval ")#mi("I_N := [ (4\\pi N^2) - \\frac{\\pi t}{4}, (4\\pi (N+1)^2) - \\frac{\\pi t}{4})")#text(". The formula is a bit messy, but looks like it can be computed numerically for ")#mi("N")#text(" up to say ")#mi("1000")#text(", and then we can use some other means of estimating ")#mi("E_1, E_2")#text(" for larger values of ")#mi("N")#text(" (at that point these errors are very small, and our lower bound for ")#tao-math("\\left|A^{eff}+B^{eff}\\right|/\\left|B^{eff}_0\\right|", block: false)#text(" fairly good, so probably even a very crude bound would suffice.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493424")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2018")])]

#text("To establish a conservative upper bound for (|E1|+|E2|+|E3|)/|B0_eff| depending only on N, should we use two T’s, T1 and T2? Where T1=(x_N)/2 and T2 = (x_(N+1))/2 (and corresponding T’1 and T’2). I was thinking where T or T’ is present in the denominator (as in E1 or E2 and most of E3 calculations), T1 and T’1 should be used, and where T’ is present in the numerator (as in E3 T’^(3/2)calculation), T’2 should be used.")

#text("Also, it seems that |E3| is not present in normalized form like |E1|/|B0_eff| and |E2|/|B0_eff|. Is there a bound on B0_eff depending only on N that can be used?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493451")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2018")])]

#text("Yes, this is a good general strategy (using upper and lower bounds on ")#mi("T")#text("), though for ")#mi("E_1")#text(" and ")#mi("E_2")#text(" it is a little tricky due to the presence of the complex quantity ")#mi("\\alpha_1(\\frac{1\\pm y + ix}{2})")#text(" in the expression.")

#text("As for ")#tao-math("E_3^* / \\left|B^{eff}_0\\right|", block: false)#text(", it is probably a good idea to factor this as ")#mi("E_3^* / ((T^{\\prime})^{3/2} e^{-\\pi T/4})")#text(" and ")#tao-math("((T^{\\prime})^{3/2} e^{-\\pi T/4}) / \\left|B^{eff}_0\\right|", block: false)#text(". The former should be comparable to 1 and the latter should be decreasing in ")#mi("x")#text(" once ")#mi("x")#text(" is moderately large (this should be provable rigorously, by computing the log-derivative of this latter ratio; I’ll try to do this when I have a bit more time this weekend, but I think it should also be visible numerically, as this ratio is fairly easy to calculate). So one can bound this latter ratio by replacing ")#mi("x")#text(" by the minimum value ")#mi("x_N = 4\\pi N^2 - \\frac{\\pi t}{4}")#text(". For the former ratio one replaces ")#mi("T")#text(" similarly with ")#mi("T_N/2")#text(" (and ")#mi("a")#text(" with ")#mi("\\sqrt{T_N/2\\pi}")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493453")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2018")])]

#text("I have been able to get a good match for the normalized E1, E2, and E3 data in the wiki (powers of 10). Was able to generate for all N from 3 to 2000, |E1|/|B0_eff| and |E2|/|B0_eff| values, and these are kept as a table in the python research folder in the repo. Even for N as low as 16, both values go below 10^-3.")

#text("Also, while B0_eff seems to monotonically decrease beyond x as low as 5 (verified this for x at intervals of 0.1 upto 100k), I realized after some basic exercises that E3 at T1 and B0_eff at T2 can’t be directly divided as the B0_eff decay is exponential and the ratio gets astronomically large. So I started evaluating |E3|/|B0_eff| for all x at intervals of 0.1 upto x=1 million, which is not yet complete but going pretty fast. Will now try out the approach you outlined above.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493466")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2018")])]

#text("Thanks for this data. Your data for |E^*_3| / |B^0_{eff}| can presumably be checked against Rudolph’s graphs at ")#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493384")[#text("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493384")]#text(", which also indicate that this ratio should be monotone decreasing in time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493478")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2018")])]

#text("Match with Rudolph’s |E3/B0| graphs (red curves) looks quite good.")

#text("For dependence only on N, taking T as x_N/2 and breaking |E3/B0| into two factors, we see that the first one is indeed comparable to 1. It decreases and settles around 0.21, beyond which it decreases quite slowly.")#linebreak()#text(" The second factor is the main decay term in the ratio and decreases faster (not as fast as the normalized E1 or E2 error bounds). Thus, as expected the overall normalized error bound |E/B0| follows the lead of the |E3/B0| bound.")

#text("The table with normalized E1, E2, E3 factors, E3 and overall error bounds is kept alongside the previous one.")

#text("Looking at |E/B0| (last column), we see that it is")#linebreak()#text(" below 0.1 at N=16,")#linebreak()#text(" below 0.01 at N=67,")#linebreak()#text(" below 0.001 at N=253,")#linebreak()#text(" below 0.0001 at N=830")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493499")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2018")])]

#text("Great! Combined with the lower bounds we are able to establish on ")#tao-math("\\left|A^{eff}+B^{eff}\\right|/\\left|B^{eff}_0\\right|", block: false)#text(", this should rigorously establish non-vanishing of ")#mi("H_t")#text(" in a range something like ")#mi("300 \\leq N \\leq 2000")#text(". To handle the large range ")#mi("N \\geq 2000")#text(" we need rigorous analytic upper bounds on ")#tao-math("E_1/\\left|B^{eff}_0\\right|", block: false)#text(", ")#tao-math("E_2/\\left|B^{eff}_0\\right|", block: false)#text(", ")#tao-math("E^*_3/\\left|B^{eff}_0\\right|", block: false)#text(" and rigorous analytic lower bounds on ")#tao-math("\\left|A^{eff} + B^{eff}\\right|/\\left|B^{eff}_0\\right|", block: false)#text(" but there seems to be a fair amount of room available (particularly with regards to the upper bounds on error terms). I can work on these.")

#text("For intermediate values of N, e.g. ")#mi("20 \\leq N \\leq 300")#text(", the error bounds seem good enough that the adaptive mesh strategy to numerically lower bound ")#tao-math("\\left|A^{eff}+B^{eff}\\right|/\\left|B^{eff}_0\\right|", block: false)#text(" should be sufficient. This leaves the very small values of N, something like ")#mi("N \\leq 20")#text(". One can either proceed here by using the ")#mi("A^{eff}+B^{eff}-C^{eff}")#text(" approximation, in which case we have to obtain explicit error terms on the accuracy of this approximation, or we can try to compute ")#mi("H_t")#text(" directly on a mesh. The latter strategy needs a rigorous upper bound on the first derivative of ")#mi("H_t")#text(". One way to do this which is straightforward but a bit tedious is to repeat the error analysis on ")#mi("H_t - A^{eff} - B^{eff}")#text(" to also give upper bounds on ")#mi("H^{\\prime}_t - (A^{eff})^{\\prime} - (B^{eff})^{\\prime}")#text(". The Cauchy integral formula already gives some bound this way, but this is probably too lousy a bound (as we would have to vary ")#mi("y")#text(" to use this formula). But I think a direct repetition of the arguments will give a reasonable bound, though I’m not really looking forward to the computation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493501")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2018")])]

#text("I also got the E1 and E2 code working in Pari/gp and do get an exact match with KM’s csv-data.")

#text("Here is a plot for ")#mi("t=y=0.4")#text(", that shows both normalised E1, E2-error terms and their bounds for ")#mi("500 \\le x \\le 5000")#text(". For each ")#mi("x+0.4i")#text(", I established its associated ")#mi("N")#text(" and used that to compute the bound-value (hope that is correct). The bound therefore shows as a step function and I guess there might ‘smoother’ ways to visualize this.")

#text("The bounds do seem to work pretty well.")

#link("https://ibb.co/kkpODS")[#text("https://ibb.co/kkpODS")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493505")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2018")])]

#text("Thanks Prof. Tao. For intermediate N values with the mesh, do we also need a separate calculation of the derivative at x or an upper bound for N (like calculated for (A_toy+B_toy)/B_toy) or are the bounds obtained then reusable? I used a symbolic derivative procedure to calculate d/dx(B_eff/B0_eff) and got an automated expression (complex valued, but modulus can also be obtained)")

#text("exp((t/4)*log(n)**2) * (n**(-t*(0.5*log((0.5*I*x + y/2 + 1/2)/(2*pi)) + 1/(I*x + y + 1) + 1/(0.5*I*x + y/2 – 1/2))/2 – 0.5*I*x – y/2 – 1/2)*(-t*(-I/(I*x + y + 1)**2 + 0.25*I/(0.5*I*x + y/2 + 1/2) – 0.5*I/(0.5*I*x + y/2 – 1/2)**2)/2 – 0.5*I)*log(n))")

#text("The values at different x match well with those of d/dx(B_toy/B0_toy), and the agreement gets better as x increases.")

#text("Also, the automated expression for d/dx(A_eff/B0_eff) is quite long and not posting it here. I haven’t been able to match it’s values yet with those of d/dx(A_toy/B0_toy).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493513")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2018")])]

#text("Hmm. The ratio ")#mi("B^{eff}/B^{eff}_0")#text(" takes the form")

#mi("\\sum_{n=1}^N \\frac{1}{n^{(1+y-ix)/2 + \\frac{t}{2} \\alpha_1(\\frac{1+y-ix}{2}) - \\frac{t}{4} \\log n}}")

#text("compared against the ratio ")#mi("B^{toy}/B^{toy}_0")#text(", which takes the form")

#mi("\\sum_{n=1}^N \\frac{1}{n^{(1+y-ix)/2 + \\frac{t}{2} \\log N - \\frac{t}{4} \\log n}}.")

#text("The quantity ")#mi("\\alpha_1(\\frac{1+y-ix}{2})")#text(" is fairly close to ")#mi("\\log N")#text(" in real part. The main new difficulty is that it varies in ")#mi("x")#text("; but the variation is very slow and I think its contribution should be lower order. By the chain rule, the derivative of the first expression is (I think) the sum of")#linebreak()#text(" ")#mi("\\sum_{n=1}^N \\frac{\\frac{i}{2} \\log n}{n^{(1+y-ix)/2 + \\frac{t}{2} \\alpha_1(\\frac{1+y-ix}{2}) - \\frac{t}{4} \\log n}}")#linebreak()#text(" and")#linebreak()#text(" ")#mi("\\sum_{n=1}^N \\frac{-\\frac{it}{2} \\alpha^{\\prime}_1(\\frac{1+y-ix}{2}) \\log n}{n^{(1+y-ix)/2 + \\frac{t}{2} \\alpha_1(\\frac{1+y-ix}{2}) - \\frac{t}{4} \\log n}}")#text(".")#linebreak()#text(" The first display here is similar to what we got for the derivative of ")#mi("B^{toy}/B^{toy}_0")#text(". Hopefully if we just take absolute values everywhere we will get a usable bound, unfortunately I can’t think of any slick shortcuts to avoid doing this.")

#text("As for ")#mi("A^{eff}/B^{eff}_0")#text(", one may wish to factor this into ")#mi("A^{eff}/A^{eff}_0")#text(" and ")#mi("A^{eff}_0/B^{eff}_0")#text(". The latter expression is a bit messy its magnitude (which is called ")#mi("\\lambda")#text(" in ")#link("http://michaelnielsen.org/polymath1/index.php?title=Controlling_A%2BB/B_0#Analysing_the_effective_model")[#text("http://michaelnielsen.org/polymath1/index.php?title=Controlling_A%2BB/B_0#Analysing_the_effective_model")]#text(" ) can be bounded in magnitude by ")#mi("e^\\delta N^{-y}")#text(" where ")#mi("\\delta")#text(" is given in")#linebreak()#text(" ")#link("http://michaelnielsen.org/polymath1/index.php?title=Controlling_A%2BB/B_0#Analysing_the_effective_model")[#text("http://michaelnielsen.org/polymath1/index.php?title=Controlling_A%2BB/B_0#Analysing_the_effective_model")]#text(" . So one could work with the triangle inequality")

#tao-math("\\displaystyle \\left|\\frac{A^{eff}+B^{eff}}{B^{eff}_0}\\right| \\geq \\left|\\frac{B^{eff}}{B^{eff}_0}\\right| - e^\\delta N^{-y} \\left|\\frac{A^{eff}}{A^{eff}_0}\\right|", block: false)

#text("and then we would only need derivative bounds on ")#mi("\\frac{A^{eff}}{A^{eff}_0}")#text(" rather than ")#mi("\\frac{A^{eff}}{B^{eff}_0}")#text(". This should be about as difficult as getting derivative bounds on ")#mi("\\frac{B^{eff}}{B^{eff}_0}")#text(". Probably the bounds will be slightly worse, but on the other hand we have the factor of ")#mi("N^{-y}")#text(" which should ultimately make the bound on this term better than for the ")#mi("B")#text(" factor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493533")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2018")])]

#text("Oh, what I was proposing was not to bound ")#tao-math("\\left|\\frac{A^{eff}+B^{eff}}{B_0^{eff}}\\right|", block: false)#text(" directly by evaluation at a mesh and upper bound on first derivative (due to the messy nature of the derivative of ")#mi("A^{eff}/B^{eff}_0")#text(", but rather to bound the smaller quantity ")#tao-math("\\left|B^{eff}\\right|/\\left|B^{eff}_0\\right| - e^\\delta N^{-y} \\left|A^{eff}/A_0^{eff}\\right|", block: false)#text(", by evaluating that a mesh and getting an upper bound for the derivatives of ")#mi("B^{eff}/B^{eff}_0")#text(" and ")#mi("A^{eff}/A_0^{eff}")#text(".")

#text("But perhaps what we should do first is get an approximation to the size of the derivatives involved. At any given point, one can upper bound the derivative of say ")#mi("B^{eff}/B^{eff}_0")#text(" by evaluating the derivative of each summand ")#mi("\\frac{1}{n^{\\frac{1-y}{2} + \\frac{t}{2} \\alpha_1 - \\frac{t}{4} \\log n}}")#text(", taking absolute values, and then summing. This removes all the oscillation and should give a bound that doesn’t vary much in x; probably it will in fact be decreasing in x. So evaluating it at just one point, say the left endpoint ")#mi("x = x_N = 4\\pi N^2 - \\pi t/4")#text(" of the interval ")#mi("[x_N,x_{N+1})")#text(" associated to a given value of ")#mi("N")#text(", will give a reasonable proxy for an actual uniform upper bound on the derivative on the entire interval. Similarly for any other ratio (e.g ")#mi("B^{eff}+A^{eff}/B^{eff}_0")#text(", ")#mi("A^{eff}/A^{eff}_0")#text(", etc.) that we would be interested in. If these bounds are reasonable then we could just simply take a conservative fixed mesh and then try later to justify the required bounds on the first derivative across the interval. (One possibility would be to evaluate the first derivative upper bound at one point of the interval and use bounds on the derivatives of that upper bound to extend them to the rest of the interval. That may seem even more complicated, but my guess is that the derivative of the upper bound should be roughly ")#mi("1/x")#text(" of the upper bound itself (basically because all the oscillation is gone), so even with rather crude estimates this should give fairly good estimate.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493514")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2018")])]

#text("Thanks. Also maybe a typo. For the derivative upper bound, should we use the reverse triangle inequality?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493541")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2018")])]

#text("These were some of the sample bounds I obtained for |d/dx(B_eff/B0_eff)| and |d/dx(A_eff/A0_eff)| (by taking the sum of the absolute values of the summands)")

#text("N, |d/dx(B_eff/B0_eff)| , |d/dx(A_eff/A0_eff)|")#linebreak()#text(" 20, 1.94, 4.62")#linebreak()#text(" 50, 2.33, 7.13")#linebreak()#text(" 100, 2.27, 8.36")#linebreak()#text(" 150, 2.12, 8.64")#linebreak()#text(" 200, 1.98, 8.63")#linebreak()#text(" 250, 1.86, 8.50")

#text("Both the bounds do seem to slowly decrease with x for a given N, although there are discontinuities at the N jumps. Eventually both decrease with N as well.")#linebreak()#text(" Also, the |d/dx(A_eff/A0_eff)| bound goes much higher than the |d/dx(B_eff/B0_eff)| bound.")

#text("Before proceeding, I just wanted to check about these sample estimates and the formula for d/dx(B_eff/B0_eff). For each summand, the numerator expression is coming out to be (i/2)(1 + (t/2)*alpha1′(s))*log(n)")#linebreak()#text(" with s as (1+y-ix)/2, which seems different from the derivation above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493551")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2018")])]

#text("Oops, I had for some reason differentiated with respect to ")#mi("n")#text(" instead of ")#mi("x")#text(" which is of course completely wrong. I’ve corrected my previous comment accordingly. But it does mean that the derivative is not as complicated as I had feared.")

#text("There is some chance that the oscillation in ")#mi("A_0^{eff} / B^{eff}_0")#text(" counteracts the oscillation in ")#mi("A^{eff}/A^{eff}_0")#text(", leading to a fairly good bound for the derivative of the ratio ")#mi("A^{eff} +B^{eff}/B^{eff}_0")#text(" as opposed to ")#tao-math("\\left|B^{eff}/B^{eff}_0\\right| - e^\\delta N^{-y} \\left|A^{eff}/A^{eff}_0\\right|", block: false)#text(". This may be useful for very small values of ")#mi("x")#text(" or ")#mi("N")#text(" as the former may stay a little bit further away from the origin. I will try to calculate some usable bounds for these quantities soon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493581")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2018")])]

#text("I have now computed a messy but explicit upper bound on the derivative of ")#mi("\\frac{A^{eff}+B^{eff}}{B^{eff}_0}")#text(" that depends only on ")#mi("N")#text(" at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Controlling_A%2BB/B_0#Derivative_bounds")[#text("http://michaelnielsen.org/polymath1/index.php?title=Controlling_A%2BB/B_0#Derivative_bounds")]#text(" . I haven’t checked yet how well it compares numerically with the actual derivative.")

#text("Incidentally, the wiki pages are beginning to sprawl a bit. I plan to write up a more logically ordered description of the argument, perhaps in the next blog post when hopefully we would have completed the verification of the test problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493608")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2018")])]

#text("I think in the large N case in the wiki, the 0.8 factor should be 0.08. Although the quantity in the exponential is quite small, so the calculations do not change.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493617")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2018")])]

#text("For N from 1 to 500, I was able to compute the upper bounds of |d/dx[(A_eff+B_eff)/B0_eff]| using the new formula.")

#text("Maximum value is at N=38 -> 7.1826, after which it shows a consistent decrease. The file with values for each N is also kept in the research folder.")#linebreak()#text(" Although these bounds seem to be about twice compared to the one obtained in the toy model case (")#link("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493109")[#text("https://terrytao.wordpress.com/2018/02/24/polymath15-fourth-thread-closing-in-on-the-test-problem/#comment-493109")]#text("), they should not pose a major challenge during large scale computations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493620")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2018")])]

#text("Is the 4*pi*n^2 factor in the A_eff section of the formula actually 4*pi^2*n^2? In which case, there is some improvement in the upper bound.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493625")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2018")])]

#text("Wow, good catch! Indeed it is even better, it is ")#mi("(4\\pi)^2 n^2 = 16 \\pi^2 n^2")#text(". I’ve corrected the wiki accordingly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493626")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2018")])]

#text("Thanks. I have updated the formula and the table. The maximum is now at N=45 -> 6.2573, post which there is a consistent decline.")

#text("Rudolph and I have been also attempting to calculate the |exact derivative| at any x. One nuance we wanted to check on is whether we should here use −logn * ddx(sA) – ddx(logλ) instead of −logn * ddx(sA) + ddx(logλ), since ddx(logλ) has been derived using s=(1+y-ix)/2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493629")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2018")])]

#text("I think it should be the plus sign:")

#mi("\\frac{d}{dx} \\log(\\lambda \\frac{1}{n^{s_A}}) = \\frac{d}{dx} (\\log \\lambda - (\\log n) s_A) = \\frac{d}{dx} \\log \\lambda - (\\log n) \\frac{d}{dx} s_A")

#text("and hence")

#mi("\\frac{d}{dx} (\\lambda \\frac{1}{n^{s_A}}) = \\lambda \\frac{1}{n^{s_A}} ( - (\\log n)\\frac{d}{dx} s_A + \\frac{d}{dx} \\log \\lambda).")

#text("Of course, by the chain rule, we then have ")#mi("\\frac{d}{dx} \\log \\lambda = -\\frac{i}{2} \\frac{d}{ds} \\log \\lambda")#text(".")

#text("One could numerically compare the exact derivative that one computes in this fashion against a Newton quotient for ")#mi("(A^{eff}+B^{eff})/B^{eff}_0")#text(", evaluated at some moderately small spacing (e.g. ")#mi("h=0.001")#text(") that is smaller than the expected wavelength of oscillation but larger than the numerical accuracy, as this would provide another checksum to make sure that we haven’t made any further typos or freshman calculus errors somewhere.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493654")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2018")])]

#text("KM and I have now checked and matched our results for ")#tao-math("\\left|\\frac{d}{dx} \\frac{A^{eff}+B^{eff}}{B^{eff}_0}\\right|", block: false)#text(" as well as for its bound. We have also numerically compared some values to the Newton quotient and do get a very good match for -logn * ddx(sA) – ddx(logλ), however for -logn * ddx(sA) + ddx(logλ) (per wiki) the numbers seem off. Could a minus sign maybe ‘hide’ somewhere in the definition of ddx(logλ) ?")

#text("Below are a few graphs to visualise the results. The derivative seems to stay well within its bound even for small values of ")#mi("x")#text(" :)")

#mi("15 \\le x \\le 10^2")#text(" ")#link("https://ibb.co/eMTwq7")[#text("https://ibb.co/eMTwq7")]#linebreak()#text(" ")#mi("100 \\le x \\le 10^3")#text(" ")#link("https://ibb.co/btbzA7")[#text("https://ibb.co/btbzA7")]#linebreak()#text(" ")#mi("100 \\le x \\le 10^4")#text(" ")#link("https://ibb.co/eGmo3S")[#text("https://ibb.co/eGmo3S")]#linebreak()#text(" ")#mi("100 \\le x \\le 10^5")#text(" ")#link("https://ibb.co/dAU83S")[#text("https://ibb.co/dAU83S")]#linebreak()#text(" ")#mi("100 \\le x \\le 10^6")#text(" ")#link("https://ibb.co/escBOS")[#text("https://ibb.co/escBOS")]#linebreak()#text(" ")#mi("100 \\le x \\le 10^7")#text(" ")#link("https://ibb.co/gxYkiS")[#text("https://ibb.co/gxYkiS")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493666")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2018")])]

#text("Ah, I think I identified the problem: I had written ")#mi("s")#text(" incorrectly on the wiki as ")#mi("\\frac{1+y-ix}{2} = 1-s")#text(", when instead it is ")#mi("\\frac{1-y+ix}{2}")#text("; this effectively causes ")#mi("\\lambda")#text(" to be incorrectly replaced by ")#mi("1/\\lambda")#text(" which presumably explains the wrong sign for ")#mi("\\frac{d}{dx} \\log \\lambda")#text(". Also I had incorrectly written the main term of ")#mi("\\frac{d}{dx} s_A")#text(" as ")#mi("-i/2")#text(" instead of ")#mi("i/2")#text(". Hopefully it all matches now!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493619")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2018")])]

#text("There is probably a small typo in the wiki about the estimation of E1, E2. These two currently show as:")

#mi("s^+_N := \\frac{1+y+i(x_N+x_{N+1})/2}{2}")

#mi("s^-_N := \\frac{1-y+i(x_N + x_{N+1})}{2}")

#text("I guess the first display is the correct one and the /2 is just missing in the second one? Impact on the overall result is minor.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493622")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2018")])]

#text("Yes, this was a typo, now corrected. Thanks for pointing it out.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of VGM Kin")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493428")[#strong[#text("VGM Kin")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2018")])]

#text("Hi Professor Tao, I read a paper claiming that there exists general solution to equations of fifth degree and above which contradicts with Galois group theory. What’s your view on that?")

#text("The General Quintic Equation, its Solution by Factorization into Cubic and Quadratic Factors")

#link("http://www.rroij.com/open-access/pdfdownload.php?download=open-access/the-general-quintic-equation-its-solution-by-factorization-into-cubicand-quadratic-factors-.pdf&aid=86295")[#text("http://www.rroij.com/open-access/pdfdownload.php?download=open-access/the-general-quintic-equation-its-solution-by-factorization-into-cubicand-quadratic-factors-.pdf&aid=86295")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493434")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2018")])]

#text("I’m not Prof. Tao but that paper sounds not much different from an angle trisection construction or a claim that two even numbers can add up to an odd number. You can tell it’s wrong just from what it claims.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493448")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2018")])]

#text("In the wiki page ")#link("http://michaelnielsen.org/polymath1/index.php?title=Controlling_H_t-A-B/B_0")[#text("http://michaelnielsen.org/polymath1/index.php?title=Controlling_H_t-A-B/B_0")]#text(" what values of t and y are used to generate the tables? Are the test problem values t=y=0.4 used for all tables?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493457")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2018")])]

#text("For the tables with x ranging from 160 to 3200, by increments of 160, I set y = 0 , and t = 0.4 . For the table that follows, showing a “spike” or discontinuity near x = 804, I think I also set t = 0.4, y=0.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493460")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2018")])]

#text("I recalculated ")#mi("(H^{eff}(z) - (A(z)+B(z) - C(z))/B_{0}(z)")#text(", in absolute value, but this time with ")#mi("t = y = 0.4")#text(".")

#text("I’d say it’s roughly comparable to the ")#mi("y = 0")#text(" case.")

#text("? for(K=1, 5, x50= 160*K+0.4*I ;s=0.0;for(J=0,40,s=s+intnumgauss(X=J/14,(J+1)/14, exp(t*X*X)*Phi(X)*cos((x50)*X),)); s2=Heff2(x50); b0=B0(x50);s4 = abs((s2-s)/b0);w20[K] = s4;)")

#text("? for(K=1, 5, print(160*K,” “, w20[K]))")#linebreak()#text(" 160 0.00708556855789")#linebreak()#text(" 320 0.00243908316749")#linebreak()#text(" 480 0.000342587313046")#linebreak()#text(" 640 0.00107187454359")#linebreak()#text(" 800 0.00185702885238")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493456")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2018")])]

#text("The test problem is to show that ")#mi("H_t(x+iy) \\neq 0")#text(" whenever ")#mi("t = y = 0.4")#text(" so it might be helpful to people joining the project if we had some reference evaluations of this function for a few values of ")#mi("x")#text(". I couldn’t find this on the wiki or in blog posts for this project (although I would be surprised if I did not simply overlook it) so I’ll write some down here, to be cross-checked by others I hope.")

#mi("H_{0.4}(10 + 0.4 i) = 0.034420270187052311229 - 0.0016782531784355935738 i")

#mi("H_{0.4}(30 + 0.4 i) = -0.00010001026469315639165 - 7.1357019921469872653 \\times 10^{-6} i")

#mi("H_{0.4}(100 + 0.4 i) = 6.7021522172791266841 \\times 10^{-16} + 3.1337965840705569244 \\times 10^{-16} i")

#mi("H_{0.4}(300 + 0.4 i) = -4.0159674206251463625 \\times 10^{-49} - 1.4006524430296850032 \\times 10^{-49} i")

#mi("H_{0.4}(1000 + 0.4 i) = 1.4847586783170623283 \\times 10^{-169} + 3.0506306235580557897 \\times 10^{-167} i")

#mi("H_{0.4}(3000 + 0.4 i) = -1.1441895900436789748 \\times 10^{-507} + 1.5701563504659934332 \\times 10^{-507} i")

#mi("H_{0.4}(10000 + 0.4 i) = -5.5773401535231430494 \\times 10^{-1701} - 4.0878432123908616412 \\times 10^{-1700} i")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493465")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2018")])]

#text("Thanks for this! I put this data, together with the various approximations we have for ")#mi("H_t")#text(" at these values of ")#mi("x")#text(". The accuracy of approximation is pretty terrible for small values of ")#mi("x")#text(" (and for ")#mi("x=10")#text(" we in fact have no approximation at all because ")#mi("N=0")#text(" and several terms degenerate), but they all improve as ")#mi("x")#text(" increases and our most advanced approximation ")#mi("A^{eff}+B^{eff}-C^{eff}")#text(" does surprisingly well even for ")#mi("x")#text(" as small as 30. [EDIT: actually it even does passably well for ")#mi("x=10")#text("!]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493547")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2018")])]

#text("I got the same values for ")#mi("H_{0.4}(10+0.4i)")#text(" to ")#mi("H_{0.4} (3000+0.4i)")#text(", using the integral in PARI/gp. The computation of ")#mi("H_{0.4} (10000+0.4i)")#text(" isn’t finished.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493671")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2018")])]

#text("Got some more exact Ht values for lower ")#mi("x")#text(". Using the integral, I have computed Ht at 40 digits accuracy for ")#mi("x = 0 \\dots 300")#text(" in steps of ")#mi("0.1")#text(". As usual ")#mi("t=y=0.4")#text(". The three files can be found on the link below. I can confirm an exact match with the x=10, 30, 100 and 300 mentioned above.")

#link("https://github.com/km-git-acc/dbn_upper_bound/tree/master/dbn_upper_bound/python/research/H_t%20at%20small%20x")[#text("https://github.com/km-git-acc/dbn_upper_bound/tree/master/dbn_upper_bound/python/research/H_t%20at%20small%20x")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493686")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2018")])]

#text("Thanks for this! To complete the verification of a zero-free region here, we will need derivative bounds on ")#mi("H_t")#text(". I think I know a way to do this using integration by parts. Will write details later, but for now: using the notation of ")#link("http://michaelnielsen.org/polymath1/index.php?title=Effective_bounds_on_H_t_-_second_approach")[#text("http://michaelnielsen.org/polymath1/index.php?title=Effective_bounds_on_H_t_-_second_approach")]#text(" , we have ")#mi("H_t(z) = \\frac{1}{8} \\xi_t(s)")#text(", where ")#mi("s = \\frac{1+iz}{2}")#text(" and ")#mi("\\xi_t")#text(" has an expansion")

#mi("\\displaystyle \\xi_t(s) = \\sum_{n=1}^N F_{t,n}(s) + F_{t,n}(1-s) + G_{t,N}(s) + G_{t,N}(1-s)")

#text("where ")#mi("F_{t,n}")#text(" in turn has an integral representation")

#mi("\\displaystyle F_{t,n}(s) = \\exp( - \\frac{t}{4} \\alpha_n^2 ) \\int_{-\\infty}^\\infty \\exp( -\\sqrt{t} \\alpha_n u)F_{0,n}( s + \\sqrt{t} u + \\frac{t}{2} \\alpha_n ) \\frac{1}{\\sqrt{\\pi}} e^{-u^2}\\ du")

#text("with a similar formula for ")#mi("G_{t,N}")#text(".")

#text("Now by the chain rule we have ")#mi("\\frac{d}{dz} H_t(z) = \\frac{i}{16} \\frac{d}{ds} \\xi_t(s)")#text(", which in turn expands to a sum of terms such as ")#mi("\\frac{d}{ds} F_{t,n}(s)")#text(". If we differentiate the above formula by ")#mi("s")#text(" (presumably we can justify differentiation under the integral sign as everything is analytic and has good decay at infinity) we obtain")

#mi("\\displaystyle \\frac{d}{ds} F_{t,n}(s) = \\exp( - \\frac{t}{4} \\alpha_n^2 ) \\int_{-\\infty}^\\infty \\exp( -\\sqrt{t} \\alpha_n u) \\frac{d}{ds} F_{0,n}( s + \\sqrt{t} u + \\frac{t}{2} \\alpha_n ) \\frac{1}{\\sqrt{\\pi}} e^{-u^2}\\ du.")

#text("One can replace ")#mi("\\frac{d}{ds}")#text(" here by ")#mi("\\frac{1}{\\sqrt{t}} \\frac{\\partial}{\\partial u}")#text(" and integrate by parts and eventually end up at")

#mi("\\displaystyle \\frac{d}{ds} F_{t,n}(s) = \\alpha_n F_{t,n}(s) + \\exp( - \\frac{t}{4} \\alpha_n^2 ) \\int_{-\\infty}^\\infty \\exp( -\\sqrt{t} \\alpha_n u) F_{0,n}( s + \\sqrt{t} u + \\frac{t}{2} \\alpha_n ) \\frac{1}{\\sqrt{\\pi}} 2u e^{-u^2}\\ du.")

#text("One can upper bound this using the techniques on the wiki, and similarly for the other terms in the expansion for ")#mi("\\xi_t")#text(". The upshot should be that we get bounds for ")#mi("\\frac{d}{dz} H_t(z)")#text(" that are not much larger than ")#mi("H_t")#text(" itself (it’s looking like it will be about ")#mi("O(\\log T)")#text(" larger, which is what one should expect given that ")#mi("H_t")#text(" oscillates at scale ")#mi("1/\\log T")#text(" as one already sees from the asymptotics of zeroes). I’ll try to work out an explicit bound on wiki soon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493688")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2018")])]

#text("It seems that by repeating this differentiation trick, it is possible to get similar expression (with extra factor ")#mi("O(\\log T)")#text(") for the second derivative (and higher derivatives)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493693")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2018")])]

#text("Is there any connection to Bernstein’s inequality for the derivative of a trigonometrical polynomial?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493715")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2018")])]

#text("More evaluations of Ht with t=y=0.4:")#linebreak()#text(" x=200 to x=600 with step size 0.1: ")#link("https://pastebin.com/fim2swFu")[#text("https://pastebin.com/fim2swFu")]#linebreak()#text(" x=600 to x=1000 with step size 0.1: ")#link("https://pastebin.com/jvSvDP69")[#text("https://pastebin.com/jvSvDP69")]#linebreak()#text(" x=30000:")#linebreak()#text(" ")#mi("3.1592485183221675757 \\times 10^{-5110} - 6.7370201647463853979 \\times 10^{-5110}i")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493732")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2018")])]

#text("Thanks for this! I have put the data on the wiki at the bottom of ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem")[#text("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem")]#text(" . If the plots of this data (perhaps normalised by dividing by ")#mi("B^{eff}_0")#text(" look smooth (in particular having enough resolution to capturing each wavelength of the oscillation of ")#mi("H_t")#text(") then there is a good chance that one can establish analytic upper bounds on the first derivative of ")#mi("H_t")#text(" to fill in the gaps between the step size 0.1 mesh.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493767")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2018")])]

#text("Below is a link to some ‘snapshot’ scatter plots to visually inspect the behaviour of ")#mi("Ht^{act}")#text(" (normalised by ")#tao-math("\\left|B0^{eff}\\right|", block: false)#text("). It appears that the wavelengths of the oscillations of ")#mi("Ht^{act}")#text(" in this domain are way larger than ")#mi("0.1")#text(", so it looks good :)")

#link("https://ibb.co/fOroa7")[#text("https://ibb.co/fOroa7")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493768")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2018")])]

#text("Your evaluations at such large ")#mi("x")#text(" are really impressive, Anonymous. I actually start to struggle, both in terms of computation time and accuracy required, for ")#mi("x \\geq 1000")#text(". Would you be willing to share how you performed these exact computations?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493788")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2018")])]

#text("Rudolph I used the plain integral of ")#mi("\\Phi")#text(" formula, with the tail errors of the integral and sum bounded by the values derived in ")#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493653")[#text("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493653")]#text(". This is a crude way to compute Ht because of the oscillation, and I hope someone can help to derive similar tail error bounds for the sum ")#mi("K")#text(" and integral ")#mi("I")#text(" that are defined in the first Polymath15 thread ")#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/")[#text("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/")]#text(" so that Ht can be computed faster and more accurately if more Ht values are still needed for this project.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493799")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2018")])]

#text("I’ll look into this. I’m finding that the existing techniques to control ")#mi("H_t")#text(" and its first derivative deteriorate as ")#mi("x")#text(" (or ")#mi("T")#text(") become relatively small (e.g. ")#mi("x \\sim 100")#text(") for a number of reasons, including the fact that one is getting a bit too close to the singularities of the Gamma function. This is unfortunately because this is the region where we really need derivative bounds! So one may indeed have to go back to earlier ways to compute ")#mi("H_t")#text(" to bound things. A model problem would be to get an effective bound of the shape ")#mi("H_t(x+iy) \\ll x^{O(1)} e^{-\\pi x/8}")#text(" that works for smallish ")#mi("x")#text(", e.g. ")#mi("0 \\leq x \\leq 100")#text("; I know that this is what happens asymptotically (in fact ")#mi("H_t(x+iy)")#text(" is roughly like ")#mi("x^{\\frac{7+y}{4}} e^{-\\pi x/8}")#text(") but as mentioned above the arguments (based on the fundamental solution to the heat equation) lose potency for small ")#mi("x")#text(". A naive triangle inequality estimate will give some bound on ")#mi("H_t(x+iy)")#text(", but it’s likely to be useless if it doesn’t have the ")#mi("e^{-\\pi x/8}")#text(" decay factor. Perhaps contour shifting the original definition of ")#mi("H_t")#text(" will do the trick; I’ll think about it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493830")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2018")])]

#text("OK, I’ve written some estimates on both ")#mi("H_t(x+iy)")#text(" and ")#mi("H^{\\prime}_t(x+iy)")#text(" at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_second_approach")[#text("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_second_approach")]#text(" that should be amenable for numerical computation at low values of ")#mi("x")#text(". As discussed in an early blog post, there is a splitting")

#mi("H_t(x+iy) = \\frac{1}{2} \\sum_{n=1}^\\infty 2\\pi^2 n^4 I_{t,\\theta}(x-(9-y)i, \\pi n^2) - 3\\pi n^2 I_{t,\\theta}(x-(5-y)i, \\pi n^2)")#linebreak()#text(" ")#mi("+ 2\\pi^2 n^4 \\overline{I_{t,\\theta}(x-(9+y)i, \\pi n^2)} - 3\\pi n^2 \\overline{I_{t,\\theta}(x-(5+y)i, \\pi n^2)}")

#text("where ")#mi("0 < \\theta < \\pi/8")#text(" is a parameter one is free to choose, and ")#mi("I_{t,\\theta}(b,\\beta)")#text(" are certain oscillatory integrals. It seems that a good choice to reduce oscillation is ")#mi("\\theta = \\frac{\\pi}{8} - \\arctan \\frac{9+y}{x}")#text(". On the wiki there are tail bounds for each individual ")#mi("I_{t,\\theta}(b,\\beta)")#text(" that should allow one to cut off each individual integral at some reasonable cutoff (something like a large multiple of ")#mi("\\log x")#text(" should work) with an exponentially decaying bound on the tail, and then there is also a bound for the tail of the sum when n is large (something like a large multiple of ")#mi("\\sqrt{x/4\\pi}")#text(" should work). There is also a similar analysis for the derivative ")#mi("H^{\\prime}_t(x+iy)")#text(". One should first test that these estimates are actually effective for evaluating ")#mi("H_t(x+iy)")#text(" and then look at how they bound ")#mi("H^{\\prime}_t(x+iy)")#text(", hopefully they can get good uniform bounds on intervals such as ")#mi("x \\in [x_0, x_0+0.1]")#text(" which is the mesh size we are dealing with.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493801")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2018")])]

#text("For very small values like x < 20 it is possible to use brute force interval computation of the original Ht formula on a reasonably sized mesh to bound Ht away from zero. If the analysis of the derivative bounds of Ht breaks down for x in this range then the interval approach may be a practical although less elegant option.")

#text("As x becomes larger like between 30 and 100, this brute force computation with intervals begins to require unreasonably sized meshes, although I suppose it could be done that way if absolutely necessary.")

#text("If the rearranged Ht formula that uses ")#mi("K")#text(" and ")#mi("I")#text(" improves numerical stability then I would be surprised if it doesn't also extend the range of x for which brute force interval computation allows Ht to be bounded away from zero with a mesh of practical size. Maybe it could reach x=100. I don't know. I hadn't tried that formula yet because I don't have truncation error bounds for the series or the integral, but maybe I will give it a closer look.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493804")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2018")])]

#text("For smaller ")#mi("t")#text(" values, it seems that ")#mi("H_t")#text(" asymptotic approximations would become less efficient (requiring larger ")#mi("x")#text(" values) such that for sufficiently small ")#mi("t")#text(" and moderately large ")#mi("x")#text(", the current approximation methods might become impractical.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493809")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2018")])]

#text("I agree with Rudolph, there’s a lot of computation involved. Would you mind sharing what software package you use to compute the integral with the function ")#mi("\\Phi")#text(" ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493831")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2018")])]

#text("Maybe a small typo in the first display under “or any cutoff X≥0, where”. Shouldn’t it read ")#mi("I_{t,\\theta,\\leq X}(b,\\beta)")#text(" ?")

#emph[#text("[Corrected, thanks. Also corrected some missing factors of ")#mi("2tX")#text(" in some of the formulae. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493904")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2018")])]

#text("Found two more small typo’s on the “second approach”-wiki.")

#text("Under the header “and by arguing as before” in the RHS of the inequality, ")#mi("\\pi n^2")#text(" should be ")#mi("\\pi n_0^2")#text(" and ")#mi("\\cos \\theta")#text(" should be ")#mi("\\cos 4\\theta")#text(". Under “and similarly” also ")#mi("\\pi n^2")#text(" should become ")#mi("\\pi n_0^2")#text(" in the RHS.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493905")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2018")])]

#text("To update a bit on the ongoing effort for small x, we now have the H_t integral estimates and the A+B-C estimates staying close to each other, and similarly for the H’_t and newton quotient estimates, indicating the estimates are being generated correctly.")

#text("The integral estimates require setting increasing amounts of precision as x is increased, which slows things down. For eg. at x=1500, the single point evaluation of Ht took me around 13 minutes. @Anonymous, it would be cool to know your tool or optimization techniques given you had generated many estimates around these x magnitudes.")

#text("I seem to have got a |H’t|/|B0| bound of 6.85 using the two triangle inequalities at x=20 (and the corresponding theta). Evaluating exact |H’t|/|B0| at a few hundred points, the values seem to stay sufficiently below the bound value, but it needs to be double checked.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493933")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2018")])]

#text("Prof. Tao, it seems my earlier attempt to find the upper bound of H'(t) was not correct, and I have attempted again (also in the wiki, the triangle inequality for J with limit 0 to X has a cos(theta) factor, which looks like it should be cos(4*theta) and I used the latter here.")

#text("Using a constant theta_c (and large n0 and X), since the bound on J varies as D * exp(-theta_c * x), with D being a constant, which decreases less rapidly than |B0(x)|, the earlier approach of using f(x) = H_t/B0 results in rapidly decreasing mesh gaps.")

#text("It seems then we should let f(x) = H_t and then the adaptive mesh gap (without the c term) would be |H_t(x)| * exp(theta_c * x)/D. Also, using theta_c closer to 0 still results in too small mesh gaps.")

#text("Using theta_c as Pi/8 – arctan(9.4/1600) results in theta_c = 0.3868.. and D = 5969.080.. and then using c = c0 * exp(-theta_c*x) (with c0 for example 0.02, or lower if the gaps become negative), we can compute the mesh gaps as (|H_t(x)| * exp(theta_c * x) – 0.02)/D,")#linebreak()#text(" where the gaps now seem to stay reasonable if occasionally a bit small (0.0002 to 0.165 (evaluated at around 1600 points)). Is this approach correct?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493934")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2018")])]

#text("When mentioning the relationship between exp(-theta_c*x) and |B0(x)|, since whether the ratio is increasing or decreasing with x depends on theta_c, possibly it would be better to say they don’t tend to keep the same order of magnitude.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493940")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2018")])]

#text("Sorry about the typos in the wiki – all the appearances of ")#mi("\\cos \\theta")#text(" have now been corrected to ")#mi("\\cos 4\\theta")#text(".")

#text("We won’t need the factor ")#mi("c")#text(" any more in the adaptive mesh (at least for the toy problem of showing that ")#mi("H_t")#text(" is non-zero) because there is no longer any error term ")#mi("E_1+E_2+E_3")#text(" that one has to beat. So if one has a derivative bound of ")#mi("D e^{-\\theta_c x}")#text(" for all ")#mi("x \\geq x_0")#text(" and one is currently at some ")#mi("x_i \\geq x_0")#text(", then one can select the next mesh point as ")#tao-math("x_i + \\left|H_t(x_i+iy)\\right| / (D e^{-\\theta_c x_i})", block: false)#text(" as you indicate.")

#text("I wonder if it is possible to see how these upper bounds on ")#tao-math("\\left|H^{\\prime}_t(x+iy)\\right|", block: false)#text(" compare with the true value of ")#tao-math("\\left|H^{\\prime}_t(x+iy)\\right|", block: false)#text(" (or proxies for this, such as the derivative of ")#mi("A^{eff} + B^{eff}")#text(", if this is easier to compute). The fact that the mesh size needed is currently somewhat poor suggests that there may be room for improvement in the estimate. Also, I was hoping that by shifting the contour as on the wiki one could compute ")#mi("H_t(x+iy)")#text(" faster than we currently are doing – a 10-fold speedup in the evaluation of each ")#mi("H_t(x+iy)")#text(" is roughly equivalent in performance to a 10-fold improvement in the upper bound for ")#tao-math("\\left|H^{\\prime}_t\\right|", block: false)#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493944")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2018")])]

#text("On checking the match between the exact |H’t| and the newton quotient of (A+B-C), we find a good match; for example,")

#text("x abs(H’t/NQ_ABC)")#linebreak()#text(" 20 0.991")#linebreak()#text(" 30 1.067")#linebreak()#text(" 100 1.004")#linebreak()#text(" 500 1.003")

#text("so I used the quotient as a proxy for the derivative below.")#linebreak()#text(" The ratio R = abs(D*exp(-theta_c * x)/NQ_ABC) has a large range (evaluated for each (D,theta_c) pair at around 16000 points between x = 20 and 1600). There seems to be some theta_c (corresponding to x_c between 1000 and 2000) at which the variance is smallest.")

#text("theta_c D min R max R stdev R")#linebreak()#text(" Pi/8 – atan(9.4/50) 0.18835 2.1 2.24E+18 2.32E+17")#linebreak()#text(" Pi/8 – atan(9.4/500) 222.823 5.0 7.49E+10 6.41E+09")#linebreak()#text(" Pi/8 – atan(9.4/1000) 1592.94 7.2 181906 19500.1")#linebreak()#text(" Pi/8 – atan(9.4/1600) 5969.08 9.0 6377 371.4")#linebreak()#text(" Pi/8 – atan(9.4/2000) 11146.7 10.3 11484 385.6")#linebreak()#text(" Pi/8 – atan(9.4/5000) 143062 15.7 135087 4505.5")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493956")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2018")])]

#text("Thanks for this! I guess the reciprocal 1/R is a slightly more useful statistic than R because R is distorted by those occasions where the oscillations of NQ_ABC bring it close to the origin. But if I understand your data correctly, it seems that even in the worst case, our upper bound for H’_t is about a factor of 15 or so worse than the true size of H’_t, which basically means that we need a resolution which is something like 15 times finer than the oscillation wavelength of H_t to be able to rigorously control things.")

#text("It may be the case that the theoretical choice ")#mi("\\theta_c = \\pi/8 - \\arctan \\frac{9+y}{x}")#text(" for ")#mi("\\theta")#text(" may not quite be the optimal choice numerically. One could perhaps try to assemble a collection of upper bounds ")#mi("D(\\theta) \\exp^{-\\theta x}")#text(" for various ")#mi("\\theta")#text(" (bearing in mind that each such bound may require also a lower bound ")#mi("x \\geq x(\\theta)")#text(") and try to locate the minimum of these bounds for various given ")#mi("\\theta")#text(" to come up with a numeric rule of thumb for what the optimal ")#mi("\\theta")#text(" is for each ")#mi("x")#text(" (or simply store all the upper bounds and work with the ")#link("https://en.wikipedia.org/wiki/Envelope_(mathematics)")[#text("envelope")]#text(" of all of them).")

#text("A more advanced possibility is to work with analytic upper bounds on the second derivatives rather than the first, and work with numerical evaluations of the first derivative at mesh points, combined with maybe a second order Taylor expansion. This looks to be the more complicated option (in particular, more prone to bugs and typos) and probably should be kept as something of a last resort. (But in principle, given that we can sample ")#mi("H_t")#text(" at a resolution significantly lower than its wavelength oscillation, each higher derivative used should lead to higher accuracy.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493962")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2018")])]

#text("By the way, there is a slight improvement to the upper bound on ")#mi("J_{t,\\theta,\\leq X}")#text(" in the wiki; one can replace the factor ")#mi("\\theta+u")#text(" by ")#tao-math("\\left|i\\theta+u\\right| = \\sqrt{\\theta^2+u^2}", block: false)#text(". This is unlikely to lead to any dramatic gain though (a factor of ")#mi("\\sqrt{2}")#text(" at best).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493945")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2018")])]

#text("Also, we have been able to speed up computations significantly using in built optimizations in the numerical integration procedures. However from a formula perspective, the rate determining parameter is n0 (currently default value of 6 is being used), and possibly we have been too conservative to keep the tail estimates small.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493967")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2018")])]

#text("After experimenting with a set of theta values and x points, it seems the minimum of the derivative bound (older bound) for x occurs at theta_c = Pi/8 – atan(9.4/x_c) where x/x_c generally falls between 1/3 and 1/4.")

#text("If we take x_c = Pi*x, and evaluate |H_t(x)|/(D(theta_c(x))*exp(-theta_c(x)*x)) at some sample x points upto 1600, we find these mesh gaps are on average around 0.04, with the minimum mesh gap slightly below 0.01, which is quite workable. Can we go ahead with such a derivative bound?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493972")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2018")])]

#text("Looks promising! I don’t have a theoretical explanation yet as to why the optimal value of ")#mi("\\theta")#text(" was about a factor of 3 closer to ")#mi("\\pi/8")#text(" than the stationary phase prediction of ")#mi("\\frac{\\pi}{8} - \\mathrm{arctan}\\frac{9+y}{x}")#text(", but I will think about it. In the meantime, we can go ahead and use this choice of ")#mi("\\theta")#text(" and the mesh step size indicated and hopefully this lets us cover the numeric ranges needed. (It does seem remarkable that the initial choice of parameters ")#mi("t=y=0.4")#text(" ends up landing quite close to the limit to what we can easily verify numerically – looks like we’re not going to push much beyond 0.48, though we should certainly give it a shot once we perfect our methodology.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-494005")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2018")])]

#text("Aha! I tracked down my error. The stationary point is at ")#mi("\\frac{\\pi}{8} - \\frac{1}{4} \\mathrm{arctan} \\frac{9+y}{x}")#text(", not ")#mi("\\frac{\\pi}{8} - \\mathrm{arctan} \\frac{9+y}{x}")#text(" as previously claimed on wiki (now fixed). This I think explains the discrepancy reasonably well, and perhaps also allows us to treat small ")#mi("x")#text(", e.g. ")#mi("x \\leq 30")#text(", without having the problem of ")#mi("\\theta")#text(" becoming negative for no good reason.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493980")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2018")])]

#text("Thanks. We have started running the adaptive mesh. The optimized J bound is around 1.33 times smaller than earlier, helping increase the mesh gap accordingly.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493786")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2018")])]

#text("Two more batches of evaluations of Ht at t=y=0.4.")#linebreak()#text(" x=1000 to x=1300 with step size 0.1 : ")#link("https://pastebin.com/NkFKs3pB")[#text("https://pastebin.com/NkFKs3pB")]#linebreak()#text(" x=1300 to x=1600 with step size 0.1 : ")#link("https://pastebin.com/k7vC6e7n")[#text("https://pastebin.com/k7vC6e7n")]

#emph[#text("[Added to wiki, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493984")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2018")])]

#text("With 16,000 precise datapoints available for ")#mi("H_t^{act}")#text(" covering ")#mi("x=0 \\dots 1600")#text(" in steps of ")#mi("0.1")#text(", I couldn’t resist plotting a quick visual to help loosely verify whether:")

#tao-math("\\frac{\\left|H_t^{act} - A^{eff} - B^{eff}\\right|}{\\left|B_0^{eff}\\right|} \\le \\frac{\\left|E_1\\right| + \\left|E_2\\right| + \\left|E_3^{*}\\right|}{\\left|B_0^{eff}\\right|}", block: false)

#text("would still hold in this domain and it seems to all work pretty well :)")

#link("https://ibb.co/n9Gw2x")[#text("https://ibb.co/n9Gw2x")]#linebreak()#text(" ")#link("https://ibb.co/cRTLUc")[#text("https://ibb.co/cRTLUc")]

#emph[#text("[Added to wiki, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-494030")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2018")])]

#text("Just spotted that I had used ")#mi("C^{eff}")#text(" as a proxy for ")#mi("E_{3}^{*}")#text(" in my code for the plots… Although it gives a nice picture, it is not very informative and certainly not helpful for the wiki page.")

#text("Here is a corrected plot, now using the vwf-integral to estimate E3 giving a much smoother overall error term and it now also properly compares:")

#tao-math("\\frac{\\left|H_t^{act} - A^{eff} - B^{eff}\\right|}{\\left|B_0^{eff}\\right|} \\le \\frac{\\left|E_1\\right| + \\left|E_2\\right| + \\left|E_3\\right|}{\\left|B_0^{eff}\\right|}", block: false)

#link("https://ibb.co/b7baZc")[#text("https://ibb.co/b7baZc")]

#emph[#text("[Link corrected, thanks. I was wondering why the fit was so excellent… -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493998")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2018")])]

#text("Below are links to exact data (40 digit accuracy) for ")#mi("H^{^{\\prime}}_{0.4}(x+0.4i)")#text(" covering ")#mi("0 \\le x \\le 300")#text(" in steps of ")#mi("0.1")#text(":")

#mi("0 \\le x \\le 100")#text(": ")#link("https://drive.google.com/open?id=1mtzrJ_-hBMyt90gVzJdNCq4RU6Pz_dQQ")[#text("https://drive.google.com/open?id=1mtzrJ_-hBMyt90gVzJdNCq4RU6Pz_dQQ")]

#mi("100.1 \\le x \\le 200")#text(": ")#link("https://drive.google.com/open?id=1wSZJgoPp9-6C8CJqLr5g3E1uhEBHKmTJ")[#text("https://drive.google.com/open?id=1wSZJgoPp9-6C8CJqLr5g3E1uhEBHKmTJ")]

#mi("200.1 \\le x \\le 300")#text(": ")#link("https://drive.google.com/open?id=1q3h0x8jSF0Z1KQ9iLx23JI1oCXfrx0RL")[#text("https://drive.google.com/open?id=1q3h0x8jSF0Z1KQ9iLx23JI1oCXfrx0RL")]

#text("Since the “second”-integral is (currently) difficult to control for ")#mi("x \\le 10")#text(", attached is for ")#mi("0 \\le x \\le 30")#text(" in steps of ")#mi("0.01")#text(" a dataset with 20-digit accurate values for the following comma-separated fields (")#mi("y=t=0.4")#text("):")

#mi("x")#text(", pari/gp prec, ")#tao-math("H_{t}, H^{^{\\prime}}_{t}, \\left|H_{t}\\right|, \\left|H^{^{\\prime}}_{t}\\right|, \\frac{\\left|H_{t}\\right|}{\\left|B_{0}^{eff}\\right|}, \\frac{\\left|H^{^{\\prime}}_{t}\\right|}{\\left|B_{0}^{eff}\\right|}", block: false)

#link("https://drive.google.com/open?id=1ge0TD5hvs1O6BKLAz34JmTqxSrguvjsJ")[#text("https://drive.google.com/open?id=1ge0TD5hvs1O6BKLAz34JmTqxSrguvjsJ")]

#emph[#text("[Links added to wiki, thanks -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493973")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2018")])]

#text("At ")#link("https://pastebin.com/ThDzc4bn")[#text("https://pastebin.com/ThDzc4bn")]#text(" I’ve made available a more nearly self-contained program from the code that I had been using to compute Ht. It requires a library called arb which can be found at ")#link("http://arblib.org/")[#text("http://arblib.org/")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-494009")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2018")])]

#text("I’ve got it working up to x = 2000, but at x = 3000, it says “core dumped”…")#linebreak()#text(" This is the data output for 1000 and 2000:")

#text("$ time ./a.out 0.4 1000 0.4 20")#linebreak()#text(" Re[H]: 1.4847586783170623283e-169")#linebreak()#text(" Im[H]: 3.0506306235580557897e-167")

#text("real 0m1.540s // 1.5 seconds")

#text("and")

#text("$ time ./a.out 0.4 2000 0.4 20")#linebreak()#text(" Re[H]: -5.9377117202337490654e-337")#linebreak()#text(" Im[H]: -2.0564217656272998761e-337")

#text("real 0m17.648s")

#text("It seems very fast.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-494010")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2018")])]

#text("Thanks, I see that it aborted (not segfault) because its integral didn’t numerically converge. I’ll look into why it does that. Maybe I made some errors when I converted my pile of code into a single C file, or maybe the ad hoc way of increasing precision is too ambitious for the absolute error tolerance target that I’m giving the integration routine or something.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-494011")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2018")])]

#text("I found the cause, and a workaround is that you can change prec=8 in the code to prec=500 or something like that. I’ll work on a better solution.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-494017")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2018")])]

#text("Ok, thanks! The values I got for x = 10 , 30, 100, 300 and 1000 agree with those given by someone that goes by Anonymous.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-494013")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2018")])]

#text("Here’s an updated code where I’ve changed how the working precision is initialized and removed the hard abort if an integral doesn’t converge at a given working precision ")#link("https://pastebin.com/QDPvWa3g")[#text("https://pastebin.com/QDPvWa3g")]#text(". I checked it at x=3000 and x=10000. By the way, your timings are similar to the ones on my system.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-494247")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2018")])]

#text("Line 36: should arb_get_mag be arb_get_mag_lower?")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493534")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2018")])]

#text("Is something like interval analysis should be required at some point for a rigorous treatment of numerical rounding errors?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493552")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2018")])]

#text("I guess so, but I think the main priority would be to get to the point where the numerical verifications are routine enough (and have enough “room” that one does not need extreme amounts of numerical precision) that they can be replicated in reasonable time (e.g. less than a day) by multiple computer software packages, including those that use interval arithmetic. Given that the numerical conclusions of this project are unlikely to be crucial in future research work (in contrast to, say, numerical work on RH, which is often used elsewhere in effective number theory), I think this standard of replicability will be sufficient for publication purposes, though there is of course always the possibility that the referees may disagree.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493545")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2018")])]

#text("Thank you for hosting this polymath! I have a couple of embarrassingly simple questions related to naive evaluation of Ht and Phi from their definitions at the top of the wiki page ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")]

#text("Phi is represented as a sum from n=1 to n=infinity, and I would like to know an explicit but possibly loose upper bound of the size of the sum from say n=k to n=infinity. The formula for this remainder bound would be a function of u and k, and I would like it to hold for complex u when -pi/8 < Im(u) < pi/8 and when the real part of u is unrestricted so that it can be either positive or negative or zero.")

#text("Ht is represented as an improper integral from u=0 to u=infinity, and I'd also like to know an upper bound for the size of the remainder of this integral. In other words, I'd like to know an upper bound for the absolute value of the integral from u=a to u=infinity. This bound would be a function of z, t, and a.")

#text("I know that this probably isn't the best way to numerically evaluate Ht, and I also know that you can probably just take k = a = 100 and the remainder would be negligible, but I would still like to know explicit bounds for these remainders.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493554")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2018")])]

#text("I don’t know if anyone has explicitly computed bounds for the tail of ")#mi("\\Phi")#text(" here, but given the rapid decay, perhaps even very crude bounds would be sufficient, as long as ")#mi("\\mathrm{Im}(u)")#text(" stays a little bit away from ")#mi("\\pm \\pi/8")#text(", say ")#mi("\\mathrm{Im}(u) \\leq \\frac{\\pi}{8}-\\varepsilon")#text(" so that ")#mi("e^{4u}")#text(" has some substantial real part in the sense that its argument is between ")#mi("-\\frac{\\pi}{4}+4\\varepsilon")#text(" and ")#mi("\\frac{\\pi}{4} - 4\\varepsilon")#text(", so that ")#tao-math("\\left|e^{4u}\\right| \\leq \\mathrm{cosec(4\\varepsilon)} \\mathrm{Re} e^{4u}", block: false)#text(". If for ")#mi("\\theta = 5/4, 9/4")#text(" one lets ")#mi("C_\\theta")#text(" be a constant for which ")#mi("x^\\theta \\leq C \\exp(x)")#text(" for all ")#mi("C>0")#text(", then")

#tao-math("2\\pi^2 n^4 \\left|e^{9u}\\right| \\leq \\mathrm{cosec}(4\\varepsilon)^{9/4} 2\\pi^2 (\\pi/2)^{-9/4} (\\pi n^2 \\mathrm{Re}(e^{4u})/2)^{9/4}", block: false)#linebreak()#text(" ")#mi("\\leq \\mathrm{cosec}(4\\varepsilon)^{9/4} 2\\pi^2 (\\pi/2)^{-9/4} C_{9/4} \\exp( \\pi n^2 \\mathrm{Re}(e^{4u})/2)")

#text("and similarly for ")#tao-math("3\\pi n^2 \\left|e^{5u}\\right|", block: false)#text(", which should allow one to bound each summand in ")#mi("\\Phi")#text(" by an explicit multiple of ")#mi("\\exp( -\\pi n^2 \\mathrm{Re} e^{4u} /2)")#text(" in magnitude. One can then control the tail of such a sum ")#mi("\\sum_{n \\geq n_0} \\exp( -\\pi n^2 \\mathrm{Re} e^{4u} /2)")#text(" by for instance comparing it with a geometric series (e.g. replacing ")#mi("n^2")#text(" with ")#mi("n n_0")#text("). Presumably these sorts of bounds can also then be used to control the tail of ")#mi("H_t")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493600")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2018")])]

#text("Thanks for the response! After reading it carefully I’m still slightly confused on some small points. I assume that “one lets ")#mi("C_\\sigma")#text("” should be “one lets ")#mi("C_\\theta")#text(" and that this is just a typo. Next I think that “for all ")#mi("C > 0")#text("” should be “for all ")#mi("x > 0")#text(" but I’m not as sure. Later in the main inequality chain, I think that ")#tao-math("\\left| \\exp( \\pi n^2 \\text{Re}(\\exp^{4u})/2) \\right|", block: false)#text(" shouldn’t need the absolute value because it’s the exponential of a real value. Maybe it’s written this way on purpose and it doesn’t matter that it’s redundant, but I don’t know. Finally I think that “explicit multiple of ")#mi("\\exp(-\\pi n^2 \\text{Re} \\exp^{4u})")#text("” should be “explicit multiple of ")#mi("\\exp(-(1/2)\\pi n^2 \\text{Re} \\exp^{4u})")#text("“, but this is the part I’m least sure about and is my main point of confusion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493623")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2018")])]

#text("Thanks for the corrections! Another slightly different way to proceed is just to bound ")#mi("n^2")#text(" by ")#mi("nn_0")#text(" from the beginning and use the generalised geometric series formulae to evaluate expressions such as ")#mi("\\sum_{n \\geq n_0} 2\\pi^2 n^4 \\exp( - \\pi n n_0 \\mathrm{Re} e^{4u})")#text(" explicitly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493653")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2018")])]

#text("I’ve followed this procedure for both the series remainder and the integral remainder.")

#text("For the series remainder I began by choosing eps=pi/24 so that pi/8 – eps = pi/12 and cosec(4 eps)=2. Then I set ")#mi("C_{9/4} = 1")#text(" and ")#mi("C_{5/4} = 1/2")#text(" and checked that ")#mi("x^{9/4} < e^x")#text(" and ")#mi("x^{5/4}  0")#text(". This gives a constant coefficient ")#mi("(2 \\pi^2 + (3/2) \\pi) 2^{9/4} (\\pi / 2)^{-9/4} < 50")#text(" as a multiple for each summand. Summing the geometric series ")#mi("\\sum_{n \\ge n_0} 50 \\exp(-\\pi n n_0 \\mathrm{Re}(e^{4u})/2)")#text(" gives the upper bound ")#mi("\\frac{50 \\exp(-\\pi n^2_0 \\mathrm{Re}(e^{4u})/2)}{1 - \\exp(-\\pi n_0 \\mathrm{Re}(e^{4u})/2)}")#text(".")

#text("In preparation for the integral remainder we can find a more convenient bound for the series remainder when ")#mi("n_0 = 1")#text(". Using the inequality ")#mi("1/(\\exp(\\pi x / 2 - 1) < 2 \\exp(\\pi x / 2)")#text(" for any $x \\ge 1$ we have the bound ")#mi("50/(\\exp(\\frac{\\pi}{2}\\mathrm{Re}(e^{4u}) - 1)) < 100 \\exp(-\\frac{\\pi}{2}\\mathrm{Re}(e^{4u}))")#text(".")

#text("This lets us bound the integral remainder by ")#mi("100 \\int_b^\\infty e^{tu^2} \\exp(-\\frac{\\pi}{2}e^{4u})\\cos(zu) du")#text(". For our test problem we can let ")#mi("t < 1/2")#text(" and ")#tao-math("\\left| \\mathrm{Im}(z) \\right| < 1/2", block: false)#text(", so the integrand is bounded by ")#mi("\\exp(u(u+1)/2 - \\frac{\\pi}{2}e^{4u})")#text(" which is less than ")#mi("\\exp(4u - e^{4u})")#text(" when $u \\ge 0$. This gives an integral remainder upper bound of ")#mi("100 \\int_b^\\infty \\exp(4u - e^{4u}) du = 25 e^{-e^{4b}}")#text(". A consequence of this bound would be that in the direct evaluation of $H_{0.4}(z)$ for our test problem, approximating the improper integral ")#mi("\\int_0^\\infty")#text(" by the incomplete integral ")#mi("\\int_0^3")#text(" gives an absolute error of less than ")#mi("10^{-70000}")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493560")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2018")])]

#text("In the wiki page “controlling ")#mi("H_t - A - B / B_0")#text("” there are two unprocessed displayed formulas.")

#emph[#text("[Fixed, hopefully -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493618")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2018")])]

#text("Is it possible to deduce (for any ")#mi("t > 0")#text(") from the effective approximation on ")#mi("H_t(z)")#text(", a lower bound of the form ")#mi("C_t/\\log T")#text(" on the horizontal gap between any two zeros of ")#mi("H_t")#text(" with real parts greater than ")#mi("T")#text("?")#linebreak()#text(" If true, this should limit (via ")#mi("H_t")#text(" zero dynamics) the horizontal velocities of the zeros to about ")#mi("O(\\log T)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493624")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2018")])]

#text("This should be the case (and is consistent with Theorem 1.4 of ")#link("http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.164.5595&rep=rep1&type=pdf")[#text("Ki-Kim-Lee")]#text("), provided ")#mi("T")#text(" is large enough depending on ")#mi("t")#text(" (basically one needs ")#mi("t \\log T")#text(" to be sufficiently small); see also the bottom of ")#link("http://michaelnielsen.org/polymath1/index.php?title=Asymptotics_of_H_t")[#text("http://michaelnielsen.org/polymath1/index.php?title=Asymptotics_of_H_t")]#text(" . This indeed keeps the dynamics stable for large values of ")#mi("t")#text(". However the problem is with the very small values of ")#mi("t")#text(", e.g. ")#mi("0 \\leq t \\leq 10^{-10}")#text(", in which the Ki-Kim-Lee asymptotics (or the ones in our project) are largely unusable. This epoch is somewhat analogous to the period shortly after the Big Bang in cosmology: while we understand pretty well what happens after this period, the dynamics in this period are really quite unclear, and in particular I don’t have a good way of preventing a huge number of zeroes coming in from infinity to settle into small and medium values of T during this period, other than to start evaluating ")#mi("H_t")#text(" for larger values of ")#mi("t")#text(" to verify that such zeroes are no longer present.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493636")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2018")])]

#text("It seems that there is no clear numerical threshold obstruction (i.e. “very small” ")#mi("t")#text(") for further analytical(!) progress in our understanding of the minimal distances among ")#mi("H_t")#text(" zeros.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493635")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2018")])]

#text("I’ve written some notes on the wiki (")#link("http://michaelnielsen.org/polymath1/index.php?title=Controlling_A%2BB/B_0")[#text("here")]#text(" and ")#link("http://michaelnielsen.org/polymath1/index.php?title=Controlling_H_t-A-B/B_0")[#text("here")]#text(") indicating how to finish off the case of very large ")#mi("x")#text(" (in which ")#mi("N \\geq 2000")#text("). Here there is a fair amount of room and even relatively crude estimates work. In particular, from the triangle inequality one can bound ")#tao-math("\\left|\\frac{A^{eff}+B^{eff}}{B^{eff}_0}\\right| \\geq 0.128", block: false)#text(" and from crude (and somewhat inelegant and inefficient) bounds on error terms one can bound ")#tao-math("\\left|E_1/B^{eff}_0\\right| \\leq 2.8 \\times 10^{-8}", block: false)#text(", ")#tao-math("\\left|E_2/B^{eff}_0\\right| \\leq 2.9 \\times 10^{-7}", block: false)#text(", and ")#tao-math("\\left|E_3^*/B^{eff}_0\\right| \\leq 1.6 \\times 10^{-5}", block: false)#text(" (this follows from ")#link("https://github.com/km-git-acc/dbn_upper_bound/blob/master/dbn_upper_bound/python/research/bounded_normalized_E1_and_E2_and_E3_and_overall_error.csv")[#text("this table")]#text(" and the monotone nature of this ratio), so there is plenty of room to keep ")#mi("H_t/B^{eff}_0")#text(" away from zero here (indeed even the real part stays positive).")

#text("Presumably by using Euler factor mollifiers and the lemma refining the triangle inequality, together with the table on ")#mi("E_1,E_2,E_3^*")#text(" bounds, one can cover all ")#mi("N")#text(" between roughly 300 and 2000, leaving only the ")#mi("N \\leq 300")#text(" case to be verified numerically.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493658")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2018")])]

#text("On evaluating the exact |derivative| (matched with the newton quotient) of the effective f = (A+B)/B0 at a few thousand points, we see that the upper bound is reasonably sharp, and the derivative has a tendency to jump towards the bound from time to time. The average derivative is much lower.")#linebreak()#text(" So we will start with the large scale adaptive mesh calculations using x_next = x + |f(x)|/max|f'(x)|")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493667")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2018")])]

#text("KM, one thing is that using the adaptive mesh ")#tao-math("x_{next} = x + \\frac{\\left|f(x)\\right|}{\\max \\left|f^{\\prime}(x)\\right|}", block: false)#text(" will only let one verify that ")#tao-math("\\left|f(x)\\right| > 0", block: false)#text(" throughout the interval. If one wants to instead prove a lower bound of the form ")#tao-math("\\left|f(x)\\right| > c", block: false)#text(" throughout an interval, one will need to use the finer mesh ")#tao-math("x_{next} = x + \\frac{\\left|f(x)\\right|-c}{\\max \\left|f^{\\prime}(x)\\right|}", block: false)#text(". Here presumably one should take ")#mi("c")#text(" to be the upper bound for ")#tao-math("\\frac{E_1+E_2+E_3^*}{\\left|B^{eff}_0\\right|}", block: false)#text(" that one has from the tables in the repository.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493681")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2018")])]

#text("Thanks. I will use the finer mesh as you outlined.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493687")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2018")])]

#text("One final thing: you should set the mesh to halt if ")#tao-math("\\left|f(x)\\right| \\leq c", block: false)#text(", since otherwise the mesh will go backwards or stay still and one may end up with an infinite loop (or wander beyond the left edge of the interval). In fact one may wish to call for a halt if ")#tao-math("\\left|f(x)\\right| \\leq c + \\varepsilon", block: false)#text(" for a very small ")#mi("\\varepsilon")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493705")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2018")])]

#text("Since for N>=20, maximum |overall error/B0| was around 0.0647, I have set c to a constant 0.065 to simplify things. This takes care of the small epsilon factor as well for the halting part.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493734")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2018")])]

#text("The mesh exercise for N=151 to 300, y=0.4, t=0.4, c=0.065 is complete. There were around 4.4 mil mesh points. I have kept the file (somewhat large) as a Google drive link ")#link("https://drive.google.com/file/d/1NvEv-1R4KTEchWMbJCpZA6Uf1xLkiYWM/view")[#text("here")]#text(". There are 4 columns -> N, x, |f(x), |f'(x)| (although computing f'(x) wasn’t necessary for the exercise). There is also a much larger file with complex valued f(x) and f'(x) which can be shared if needed.")

#text("Some interesting rows in the file:")#linebreak()#text(" N, x, |f(x)|, |f'(x)|, remark")#linebreak()#text(" 151, 286834.3928, 0.5097, 0.4773, min |f(x)|")#linebreak()#text(" 152, 291266.7808, 2.9525, 3.7539, max |f(x)|")#linebreak()#text(" 191, 462997.2589, 0.6210, 0.1150, min |f'(x)|")#linebreak()#text(" 155, 304719.4104, 2.9371, 3.8945, max |f'(x)|")

#text("Average |f(x)| and |f'(x)| values were 0.9617 and 0.6104 respectively.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493736")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2018")])]

#text("Thanks for this! I assume ")#mi("f(x)")#text(" is ")#mi("A^{eff}+B^{eff}/B^{eff}_0(x)")#text(". So if I understand correctly, your computation verifies that this quantity is at least 0.065 for all ")#mi("x")#text(" in the range ")#mi("151 \\leq N \\leq 300")#text("? Combined with the upper bounds for ")#mi("E_1+E_2+E_3^*/B^{eff}_0")#text(" from ")#link("https://github.com/km-git-acc/dbn_upper_bound/blob/master/dbn_upper_bound/python/research/bounded_normalized_E1_and_E2_and_E3_and_overall_error.csv")[#text("this table")]#text(", this seems to finish off the verification of ")#mi("H_t(x+iy) \\neq 0")#text(" in this range. We also have the range ")#mi("N \\geq 2000")#text(" covered, and I believe your previous analysis of lower bounds for ")#mi("A^{eff}+B^{eff}/B^{eff}_0")#text(" should also handle the range ")#mi("300 < N \\leq 2000")#text(" (do you have a table for those bounds by the way?), so this would just leave ")#mi("N \\leq 150")#text(" as the remaining range. Presumably the mesh method should be able to push down a bit further?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493762")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2018")])]

#text("Yeah, I used f(x) = ((A_eff+B_eff)/B0_eff)(x,y=0.4,t=0.4) with y and t treated as constants. I have kept the table with N dependent lower bounds of |A_eff+B_eff|/|B0_eff| ")#link("https://github.com/km-git-acc/dbn_upper_bound/blob/master/dbn_upper_bound/python/research/mod_abbeff_lower_Nbounds.csv")[#text("here")]#text(".")#linebreak()#text(" Some of the mollifier based bounds for larger N are unfilled, since they were slow to compute. I will update the table with them later. At meaningful heights N, there is practically no difference between the toy and the effective bounds.")

#text("Rudolph was handling the mesh for N=20 to 150, and I think he will be commenting soon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493769")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2018")])]

#text("The mesh for N=20 to 150 is complete and I have transferred the detailed results to KM for inspection and post-processing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493771")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2018")])]

#text("For N=20 to 150, the smaller file with 4 columns N,x,|f(x)|,|f'(x)| is kept ")#link("https://drive.google.com/open?id=1YBIA5gRv2DUXX74MLwfn9F2J0QJBWUh_")[#text("here")]#text(", and the larger raw file with structure Sr.no, N, ddx_upper_bound, c, x, f(x), |f(x), f'(x), |f'(x)| is ")#link("https://drive.google.com/open?id=1ZBX7jNGXhQZQ50t8UX4boTPW93dmRAun")[#text("here")]#text(".")

#text("Interesting rows in the file:")#linebreak()#text(" N, x, |f(x)|, |f'(x)|, remark")#linebreak()#text(" 20, 5484.3940, 0.3553, 0.5006, min |f(x)|")#linebreak()#text(" 21, 5637.7493, 4.1903, 4.7830, max |f(x)|")#linebreak()#text(" 27, 9179.2848, 0.5447, 0.0550, min |f'(x)|")#linebreak()#text(" 33, 13850.9274, 4.1195, 5.0151, max |f'(x)|")

#text("Interestingly, we also checked whether the N=11 to 19 range could be tackled with a higher c value. We set c to 0.165 (since bound |E/B0| at N=11 is 0.1633). These were the results obtained.")

#text("N, x, |f(x)|, |f'(x)|, remark")#linebreak()#text(" 13, 2166.6170, 0.3106, 0.4819, min |f(x)|")

#text("Hence this N range too may not need to go through direct evaluation.")

#text("The data for this range is kept ")#link("https://drive.google.com/open?id=1qbkvCBIt_OHnrtcDJWQvN_FUt-1zPv4m")[#text("here")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493776")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2018")])]

#text("Thanks for all the data! I have put links to them at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem")[#text("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem")]#text(" . If the ")#mi("A^{eff}+B^{eff}")#text(" approximation works for N as low as 11, then we only need to evaluate ")#mi("H_t")#text(" numerically up to ")#mi("x= 4\\pi (11)^2 - \\pi t/4 \\approx 1500")#text(", which looks within reach.")

#text("I have started to write up in LaTeX form the explicit bounds and this should appear on the git repository soon. In the process of cleaning things up I think I can make a slight improvement to the ")#mi("E_1,E_2")#text(" bounds and also obtain an error estimate for ")#mi("H_t - (A^{eff}+B^{eff}-C^{eff})")#text(", though the way things are going we may not even need this improved approximation. But I am thinking that our paper should have two purposes: firstly to record a number of effective estimates for ")#mi("H_t")#text(", and secondly to bound the de Bruijn-Newman constant. The former part will probably be useful for any future work on improving the constant. (We can also use these estimates to give some effective versions of the theorems in Ki-Kim-Lee, for instance giving an explicit threshold beyond which all the zeroes of ")#mi("H_t")#text(" are provably real.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493694")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2018")])]

#text("Below are some graphs that indeed show that the choice of bounds for very large ")#mi("x")#text(" leaves sufficient room to reduce N a bit below 2000 and/or play with the fixed bound itself. Only ")#mi("E^{*}_{3}")#text(" looks a bit tight, although it is difficult to tell from just looking at a graph at these scales.")

#tao-math("\\left|A^{eff}+B^{eff}\\right|", block: false)#text(" ")#link("https://ibb.co/gZHBQ7")[#text("https://ibb.co/gZHBQ7")]

#mi("E1, E2")#text(" ")#link("https://ibb.co/mR7vk7")[#text("https://ibb.co/mR7vk7")]

#mi("E3")#text(" ")#link("https://ibb.co/dZ7T57")[#text("https://ibb.co/dZ7T57")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493700")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2018")])]

#text("What should be the optimal number ")#mi("P")#text(" of factors in an Euler product type moliffier as a function of the number ")#mi("N")#text(" of terms in the approximating sums?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81cc97a0893cd1b51eb74322100857a7399825bc632bb04b9807aebf0221d175-86f01103f91e365d9d1978f4dcbcdfe40fda696c9caad8214e2f1982f6b5c5f4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sylvain JULIEN")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493731")[#strong[#text("Sylvain JULIEN")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2018")])]

#text("I have a probably very naive question due my huge lack of understanding of the problem. It seems $ \\Lambda $ is defined from the zeros of some function $ H(\\lambda,z) $ which are all real iff $ \\lambda\\geq\\Lambda $. Call such a function depending on the two parameters $ \\lambda $ and $ z $ whose all zeros are real iff $\\lambda\\geq\\Lambda $ a $ \\Lambda $ -function. Could the structure of the automorphism group of the set of all $ \\Lambda $ -functions shed a light on the actual value of $ \\Lambda $?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493828")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2018")])]

#text("Dear Terry,")#linebreak()#text(" Be joyful and relax some minutes.Can you guess who will win Abel prize on March 20, 2018.I predict the mathematician whose name has 10 words will be able to get it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493837")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2018")])]

#text("The function ")#mi("H_{t^2}(z)")#text(" is symmetric also in ")#mi("t")#text(", and since it has the same information on its zero set, it seems (slightly) better to work with (than ")#mi("H_t(z)")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493876")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2018")])]

#text("One of the secondary goals that was established for this polymath project, is to gain better understanding (both analytic and numerical) of ")#mi("H_{t}")#text(". In this context, I made two implicit plots; one in 3D for ")#mi("\\Re(H_{t}(x+yi))=0")#text(" and a 2D-slice of it for ")#mi("\\Re(H_{t}(x+0i))=0")#text(". The 3D plot just nicely illustrates the ‘scary beauty’ of the complexity we are dealing with.")

#text("The 2D plot shows, as predicted, that the zeros move a bit to the left when ")#mi("t")#text(" increases above ")#mi("0")#text(", however what I hadn’t expected, is that for larger ")#mi("t \\ge 10")#text(", the zeros seem to ‘go full circle’ (or ‘collide’). Furthermore, there appears to be very regular, monotonically increasing pattern emerging for the zeros at the tops of these ‘closed strings’. Also checked this for higher ")#mi("x")#text(" and the pattern firmly remains. Could there be a logical explanation for the zeros ‘vanishing’ in such a regular pattern when ")#mi("t")#text(" growth large?")

#link("https://ibb.co/mG15QH")[#text("https://ibb.co/mG15QH")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493880")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2018")])]

#text("The behaviour at ")#mi("t \\geq 10")#text(" is very odd, and not what I would expect asymptotically at all. What I would have expected was that the ")#mi("A^{eff}_0 + B^{eff}_0")#text(" term of ")#mi("A^{eff}+B^{eff}")#text(" would dominate at this value of ")#mi("t")#text(", and the zeroes of this sum should arrange like an arithmetic progression marching steadily leftwards as t increases. Would it be possible to run the same computation using ")#mi("A^{eff}_0 + B^{eff}_0")#text(" in place of ")#mi("A^{eff} +B^{eff}")#text("? (here by ")#mi("A^{eff}_0")#text(" I mean the ")#mi("n=1")#text(" term of ")#mi("A^{eff}")#text("). Presumably the same phenomenon also holds for the other approximations ")#mi("A+B, A^{\\prime}+B^{\\prime}, A^{toy}+B^{toy}")#text(" given as they all seem to be rather close to each other. Finally when ")#mi("y=0")#text(" all of the approximations should be essentially real, the imaginary part should basically be only because of numerical error.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493885")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2018")])]

#text("That explains it indeed! The odd behaviour disappears when using ")#mi("A_0^{eff}+B_0^{eff}")#text(" for ")#mi("t")#text(" large and after comparison with some actual values of ")#mi("H_t")#text(" (using the integral), I found that the strange pattern is caused by the error terms ")#mi("E_{1,2,3}")#text(" that start to dominate when ")#mi("t \\ge 10")#text(" (in this x-range).")

#text("Attached is a new plot that compares ")#mi("A^{eff}+B^{eff}")#text(" including all error terms (red), with the error terms only switched on for ")#mi("-1 \\le t \\le 1")#text(" (green). When ")#mi("t")#text(" increases, the zeros are now indeed ‘marching steadily leftwards’ wearing little green berets :)")

#link("https://ibb.co/ndhwZc")[#text("https://ibb.co/ndhwZc")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493932")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2018")])]

#text("Is there a reliable upper bound on the “typical” value of | log(| H_{0.4}(x+0.4*i)|)/log(10) | ?")#linebreak()#text(" This might help in setting the local precision in integral calculations involving ")#mi("\\Phi")#text(" or the second integral method.")#linebreak()#text(" The code below, which adjusts calculation precision with “x”, agrees with Anonymous’ ")#mi("H_{0.4}")#text(" values at 100+0.4*i and 300+0.4*i:")

#text("(based on KM’s code):")

#text("? for(K=5,30,localprec(10*K); t=0.4; y = 0.4; x = 10*K; print(precision(x,19),” “, precision(Ht_integral(x),19 )) )")

#text("50 -2.1047124718785808346 E-8 – 3.006030784162775084 E-8*I")#linebreak()#text(" 60 -8.797417339471680766 E-10 + 1.0580539791535436879 E-9*I")#linebreak()#text(" 70 -2.355154931010125629 E-10 + 2.8393742774037032383 E-11*I")#linebreak()#text(" 80 2.2576611190131208935 E-12 – 8.927938709799100864 E-13*I")#linebreak()#text(" 90 1.6901585151951934327 E-13 – 1.5317581587046806339 E-14*I")#linebreak()#text(" 100 6.702152217279126684 E-16 + 3.133796584070556925 E-16*I")#linebreak()#text(" 110 -7.364834657345354450 E-17 + 1.7548391366479612142 E-17*I")#linebreak()#text(" 120 -5.258352161799536371 E-19 + 8.099278955197521748 E-20*I")#linebreak()#text(" 130 -5.297614494427621701 E-21 – 5.872076288890267898 E-21*I")#linebreak()#text(" 140 -4.552049395696165212 E-22 – 6.099763216616073607 E-23*I")#linebreak()#text(" 150 7.057048184192585515 E-24 – 5.048132691648078404 E-24*I")#linebreak()#text(" 160 -3.894071621449979314 E-25 – 3.790281812824059439 E-26*I")#linebreak()#text(" 170 -3.570556479082531282 E-27 – 1.0730598815421024207 E-27*I")#linebreak()#text(" 180 -2.959277374063902186 E-28 + 9.529944891026918017 E-30*I")#linebreak()#text(" 190 -1.3400959121627429409 E-30 + 3.570717316287886905 E-32*I")#linebreak()#text(" 200 -1.0360928396386564604 E-31 + 1.9808093691630687907 E-32*I")#linebreak()#text(" 210 -4.747677152569013952 E-34 + 3.659779803543006900 E-34*I")#linebreak()#text(" 220 -3.489228591177793899 E-35 + 1.8401441099778526225 E-35*I")#linebreak()#text(" 230 6.649995257466365986 E-37 – 4.386090012622009025 E-38*I")#linebreak()#text(" 240 2.1731405677097774617 E-38 – 4.979808010644137820 E-39*I")#linebreak()#text(" 250 -4.595766631889382604 E-40 – 4.992715219111431987 E-41*I")#linebreak()#text(" 260 -4.472080722580684381 E-42 + 1.5078116247080648595 E-43*I")#linebreak()#text(" 270 8.201349077729028997 E-44 + 4.900772781466248864 E-44*I")#linebreak()#text(" 280 1.4176271036085426800 E-45 + 1.5787181626920506794 E-46*I")#linebreak()#text(" 290 9.548085707499014585 E-47 – 3.744714763671142931 E-47*I")#linebreak()#text(" 300 -4.015967420625229432 E-49 – 1.4006524430296841232 E-49*I")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493942")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2018")])]

#text("Judging by the values of ")#mi("H_t(x+0.4i)")#text(", I’d suggest a real precision close to floor(x/5)+20.")#linebreak()#text(" As I wrote on the mailing list, for x = 1000, one has to be careful about the integral step, e.g.:")

#text("? for(K=100,100,localprec(2*K); t=0.4; y = 0.4; x = 10*K; print(precision(x,9),” “, precision(Ht_integral(x),9 )) )")

#text("1000 1.1947262584148883838 E-169 + 3.0568169693909478745 E-167*I // inaccurate")

#text("? MSTEP")#linebreak()#text(" %108 = 2")

#text("same with MSTEP=4:")#linebreak()#text(" ? for(K=100,100,localprec(2*K); t=0.4; y = 0.4; x = 10*K; print(precision(x,9),” “, precision(Ht_integral(x),9 )) )")

#text("1000 1.4847586909758082343 E-169 + 3.0506306236221504103 E-167*I //accurate")

#text("? MSTEP")#linebreak()#text(" %111 = 4")

#text("This is where MSTEP appears as a parameter influencing the integration step:")

#text("I_t_th =")#linebreak()#text(" (t,th,X,b,beta)->return(intnum(u=I*th,I*th+X,exp(t*u^2-beta*exp(4*u)+I*b*u),MSTEP))")

#text("?intnum for on-line help with intnum:")

#text("intnum(X=a,b,expr,{tab}): numerical integration of expr from a to b with")#linebreak()#text(" respect to X. Plus/minus infinity is coded as +oo/-oo. Finally tab is either")#linebreak()#text(" omitted (let the program choose the integration step), a non-negative integer")#linebreak()#text(" m (divide integration step by 2^m), or data precomputed with intnuminit.")

#text("===")

#text("Does n0 increase with “x” in KM’s code?")

#text("Ht_integral =")#linebreak()#text(" (x,y=0.4,t=0.4,n0=26,X=6)->th=Pi/8-atan((9+y)/x);")#linebreak()#text(" [ I seem to recall KM had n0=6, so I might try n0 =6, x=1000, MSTEP=4.]")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493946")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2018")])]

#text("It seems more natural to construct the adaptive grid points using the derivative (with respect to ")#mi("x")#text(") of ")#tao-math("\\log \\left|H_t(x+ i y)\\right|", block: false)#text(" (instead of ")#mi("H_t(x+ i y)")#text(" derivative) which has much smaller dynamic variation with respect to ")#mi("x")#text(" (for fixed ")#mi("t, y > 0")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493953")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2018")])]

#text("In fact, to verify that ")#mi("H_t(x + iy) \\neq 0")#text(" (for fixed ")#mi("t, y > 0")#text("), it is sufficient to prove the nonvanishing of ")#tao-math("\\left|H_t(x + iy)\\right|", block: false)#text(", or even better, the lower boundedness of ")#tao-math("\\log \\left|H_t(x + iy)\\right|", block: false)#text(" which is a real function of ")#mi("x")#text(" with slow dynamics (thereby more suitable for graphs or tables.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493963")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2018")])]

#text("What computations or bounds remain to be calculated or derived so that the test problem can be finished off? I noticed that one of the github issues is serving as a de facto mailing list and at least one of the participants is no longer able to post on this blog for technical(?) reasons ")#link("https://github.com/km-git-acc/dbn_upper_bound/issues/50")[#text("https://github.com/km-git-acc/dbn_upper_bound/issues/50")]#text(". This thread is approaching 100 comments and it’s no longer clear to me which parts of the problem are being most actively worked on, or if some parts mentioned in the blog or on the github are now dead ends.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493981")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2018")])]

#text("Rudolph had recently given a good summary here")#linebreak()#text(" ")#link("https://github.com/km-git-acc/dbn_upper_bound/issues/50#issuecomment-373954432")[#text("https://github.com/km-git-acc/dbn_upper_bound/issues/50#issuecomment-373954432")]#linebreak()#text(" Essentially, we are right now working on clearing the x range upto 1600 (N~ 11). After optimizations on several aspects, we are planning to finish this mesh exercise in the next few days (barring maybe the very small x where the I integral diverges, but we are planning to replace it with the original integral for that range).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493982")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2018")])]

#text("I’ll plan to evaluate Ht with t=y=0.4 from x=1000 to x=1600 with spacing of 0.005 which should take maybe like a day using code like in ")#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493973")[#text("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493973")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493983")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2018")])]

#text("Wow, that’s serious speed. Is it because of the library or the machines available to you? Will check out your script as well.")#linebreak()#text(" While a spacing of 0.005 would certainly work, the average gap is around 0.05 with an adaptive mesh, so you could consider using that approach to get even faster results.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-494036")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2018")])]

#text("This is finished now, but the file it made is too big for the internet to handle. It didn’t fit on pastebin.com so I made a github account which was immediately flagged (hidden from public) for some reason before I even did anything on it. Then I tried uploading the file as a github gist with that flagged account, but the file is truncated in the plain gist and the associated link to the raw untruncated file is 404.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-494038")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2018")])]

#text("Amazing job, Anonymous! You could try to use Google-drive. It offers you 15Gb for free and is easy to install. You can just upload a file directly from your PC and with a ‘right click’ you get create and publish a ‘shareable link’.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-494061")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2018")])]

#text("I just received an email from github saying that they manually reviewed the account and cleared the flag, so maybe the file is visible now at ")#link("https://gist.githubusercontent.com/p15-git-acc/b0548c398183233e654956b450f36c85/raw/36581e3dd6c9adb4e034e08e6551018555e3b361/gistfile1.txt")[#text("https://gist.githubusercontent.com/p15-git-acc/b0548c398183233e654956b450f36c85/raw/36581e3dd6c9adb4e034e08e6551018555e3b361/gistfile1.txt")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-494063")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2018")])]

#text("Great. I will run the derivative bound check, and add an indicator column which points clear the check (there should be few if any points where it doesn’t, which can be tackled easily)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-494166")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2018")])]

#text("Using your script, David was able to generate H_t data for 10<=x<1000 with a fixed mesh of step size 0.01. To that I also added the data for x<10 with the same step size.")#linebreak()#text(" After checking the intervals between the mesh points using the derivative bound, I think we can clear this range.")

#text("The verified output has been kept ")#link("https://drive.google.com/open?id=1h_OWfgCb4W2WoXtWIkbtxL-jPGLJJEjH")[#text("here")]

#text("The indicator column has three possible values 0,1 and 2. 1 means the allowed step was greater than the fixed step, so no additional work was required. 0 means the allowed step was less than the fixed step. There were 96 such points or about 0.1%. Near those points, additional mesh points were added which have an indicator value of 2.")

#text("for x<10, theta_c used was Pi/8-(1/4)*atan(9.4/30)")#linebreak()#text(" for x<100, theta_c used was Pi/8-(1/4)*atan(9.4/100)")#linebreak()#text(" and after that, theta_c was varied when x crossed a multiple of 2. These values could have been chosen differently.")

#text("ble.")

#text("The data for 1000 less than x less than 1600 should be on the way.")

#text("There was a lot of tinkering the last few days, with some learnings for the way ahead.")#linebreak()#text(" 1. Arb (and possibly compiled PariGP) is much faster for both fixed and adaptive meshes than other tools.")#linebreak()#text(" 2. Data from a fixed mesh requires to be then verified against the derivative bound to clear the intervals between mesh points. To improve verification speed, one can skip points and choose the next point just below the one recommended by an adaptive approach.")#linebreak()#text(" 3) Also, one could change theta_c and D values periodically instead of changing them at every x (since computing D for many points takes time).")

#text("with my conclusion being the fastest approach would be an adaptive mesh with an Arb like library.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-494175")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2018")])]

#text("Building on KM’s comments.")

#text("The numerical verification process, to ensure that ")#mi("H_{0.4}(x+0.4i)")#text(" doesn’t vanish in the domain ")#mi("x=1000 \\dots1600")#text(", has now been completed using a fixed mesh approach with steps of ")#mi("0.005")#text(". The mesh-runs went in two batches and the output is on the links below.")

#text("[batch x=1000..1300](")#link("https://drive.google.com/open?id=1UE6khYy0k4IGEL1Joi9ipltTCeSgOAUW")[#text("https://drive.google.com/open?id=1UE6khYy0k4IGEL1Joi9ipltTCeSgOAUW")]#text(")")

#text("min. mesh : 0.00743669151431375 at x= 1275.695")#linebreak()#text(" max. mesh : 0.10845848437334255, ‘ at x= 1052.37")#linebreak()#text(" #mesh below 0.01: 1355 times, out of: 60001")

#text("[batch x=1300..1600](")#link("https://drive.google.com/open?id=16E-TiGtC8JXnFoyxzOEzXIZaD8Tdxn8H")[#text("https://drive.google.com/open?id=16E-TiGtC8JXnFoyxzOEzXIZaD8Tdxn8H")]#text(")")

#text("min. mesh : 0.006968664138389287, ‘ at x=’, 1423.495)")#linebreak()#text(" max. mesh : 0.10180996783467539, ‘ at x=’, 1304.12)")#linebreak()#text(" #mesh below 0.01: 3134 times, out of: 60001")

#text("File csv-layout: x, H_t, interval_cleared?(1=y,0=n), H_t/B0_eff, H_t_ABC, theta_c, D, Ht_derivative_bound/B0_eff, newton_quotient (of H_t_ABC/B0_eff)")

#text("We also managed to stretch the adaptive mesh, that was used to clear ")#mi("N=11 \\dots 300")#text(", to now also include ")#mi("N=8 \\dots 10\\,\\, (x=803 \\dots 1520)")#text(". Below is a plot outlining the c-parameter choices we made and also the links the batch output.")

#link("https://ibb.co/dMe6fH")[#text("https://ibb.co/dMe6fH")]

#text("[N=8](")#link("https://drive.google.com/open?id=1EfNA54bI8ghM4Y9kDVqfsMVW3_Q8yMaQ")[#text("https://drive.google.com/open?id=1EfNA54bI8ghM4Y9kDVqfsMVW3_Q8yMaQ")]#text(")")

#text("[N=9](")#link("https://drive.google.com/open?id=1H4BSflE6A1JMvIDzAal_Ru5xGsBK9NBw")[#text("https://drive.google.com/open?id=1H4BSflE6A1JMvIDzAal_Ru5xGsBK9NBw")]#text(")")

#text("[N=10](")#link("https://drive.google.com/open?id=14V1p-Cn9a3zg69LFtptHuWs5mis8uGvH")[#text("https://drive.google.com/open?id=14V1p-Cn9a3zg69LFtptHuWs5mis8uGvH")]#text(")")

#text("File csv-layout: seq_nr, N, Ht_AB_derivative_bound, c_used, x-mesh, Ht_AB, abs_Ht_AB, Derivative_Ht_AB, abs_Derivative_Ht_AB")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath15, sixth thread: the test problem and beyond | What's new")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-494014")[#strong[#text("Polymath15, sixth thread: the test problem and beyond | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2018")])]

#text("[…] thread of the Polymath15 project to upper bound the de Bruijn-Newman constant , continuing this post. Discussion of the project of a non-research nature can continue for now in the existing proposal […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-494056")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2018")])]

#text("I tried carefully reading the math in equations (4) in ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_second_approach")[#text("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_second_approach")]#text(", and it looks like it uses elementary but clever tricks to find the sum from n=n0 to n=infinity of (n^4*c^n). Maybe this is what had been referred to in ")#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493623")[#text("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-493623")]#text(" as a generalized geometric series formula. Does anyone have wikipedia links or other references for these formulas? My google skills aren’t good enough.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-494058")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2018")])]

#text("Differentiating the geometric series formula ")#mi("\\sum_{n=0}^\\infty x^n = \\frac{1}{1-x}")#text(" term by term (assuming ")#tao-math("\\left|x\\right| < 1", block: false)#text(" throughout) yields")

#mi("\\displaystyle \\sum_{n=0}^\\infty (n+1) x^n = \\sum_{n=1}^\\infty n x^{n-1} = \\frac{1}{(1-x)^2}")

#mi("\\displaystyle \\sum_{n=0}^\\infty (n+2) (n+1) x^n = \\sum_{n=2}^\\infty n (n-1) x^{n-2} = \\frac{2}{(1-x)^3}")

#mi("\\displaystyle \\sum_{n=0}^\\infty (n+3) (n+2) (n+1) x^n = \\sum_{n=3}^\\infty n (n-1) (n-2) x^{n-3} = \\frac{6}{(1-x)^4}")

#mi("\\displaystyle \\sum_{n=0}^\\infty (n+4) (n+3) (n+2) (n+1) x^n")

#mi("\\displaystyle = \\sum_{n=4}^\\infty n (n-1) (n-2) (n-3) x^{n-4}")

#mi("\\displaystyle = \\frac{24}{(1-x)^5}")

#text("which after some linear algebra gives")

#mi("\\displaystyle \\sum_{n=0}^\\infty n x^n = \\frac{x}{(1-x)^2}")

#mi("\\displaystyle \\sum_{n=0}^\\infty n^2 x^n = \\frac{x^2+x}{(1-x)^3}")

#mi("\\displaystyle \\sum_{n=0}^\\infty n^3 x^n = \\frac{x^3+4x^2+x}{(1-x)^4}")

#mi("\\displaystyle \\sum_{n=0}^\\infty n^4 x^n = \\frac{x^4+11x^3+11x^2+x}{(1-x)^5}.")

#text("The general formula is")

#mi("\\displaystyle \\sum_{n=0}^\\infty n^k x^n = \\frac{\\sum_{m=0}^{k-1} A(k,m) x^{m+1}}{(1-x)^{k+1}}")

#text("for ")#mi("k \\geq 1")#text(", where ")#mi("A(k,m)")#text(" are the ")#link("https://en.wikipedia.org/wiki/Eulerian_number")[#text("Eulerian numbers")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e27015fabeefbc23a85fc5c66f76764ed08527eef678c8bb7230e03ad58933bf-cdd63233831046a993079e0c695fb45a43d9133c3ce6fdd95c2fa9322ffeb012.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-494094")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2018")])]

#text("The number of twin primes Only 11-13, 41-13 this type of twin prime number")

#text("Natural number")#linebreak()#text(" The number of twin primes")#linebreak()#text(" ratio")#linebreak()#text(" 00000000019 1 ")#linebreak()#text(" 00000000029 1 1")#linebreak()#text(" 00000000049 2 2")#linebreak()#text(" 00000000089 3 1.5")#linebreak()#text(" 00000000169 4 1.333333")#linebreak()#text(" 00000000329 7 1.75")#linebreak()#text(" 00000000649 11 1.571429")#linebreak()#text(" 00000001289 17 1.545455")#linebreak()#text(" 00000002569 27 1.588235")#linebreak()#text(" 00000005129 46 1.703704")#linebreak()#text(" 00000010249 68 1.478261")#linebreak()#text(" 00000020489 119 1.75")#linebreak()#text(" 00000040969 205 1.722689")#linebreak()#text(" 00000081929 346 1.687805")#linebreak()#text(" 00000163849 604 1.745665")#linebreak()#text(" 00000327689 1082 1.791391")#linebreak()#text(" 00000655369 1938 1.791128")#linebreak()#text(" 00001310729 3442 1.776058")#linebreak()#text(" 00002621449 6220 1.807089")#linebreak()#text(" 00005242889 11265 1.811093")#linebreak()#text(" 00010485769 20652 1.833289")#linebreak()#text(" 00020971529 37550 1.818226")#linebreak()#text(" 00041943049 68405 1.821704")#linebreak()#text(" 00083886089 125868 1.840041")#linebreak()#text(" 00167772169 232302 1.8456")#linebreak()#text(" 00335544329 429878 1.850514")#linebreak()#text(" 00671088649 797856 1.856006")#linebreak()#text(" 01342177289 1486882 1.863597")#linebreak()#text(" 02684354569 2776461 1.867304")#linebreak()#text(" 05368709129 5195786 1.8714")#linebreak()#text(" 10737418249 9747328 1.8760")#linebreak()#text(" How do you explain that twin prime numbers are doubling as natural numbers grow?")
]
]
]
