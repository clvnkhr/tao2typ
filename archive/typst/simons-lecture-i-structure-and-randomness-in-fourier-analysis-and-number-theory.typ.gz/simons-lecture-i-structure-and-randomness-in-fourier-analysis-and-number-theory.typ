// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/
// Converted to Typst by tao2typ: "2026-10-13T06:05:08.227728+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Simons Lecture I: Structure and randomness in Fourier analysis and number theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set par(justify: true, leading: 0.65em, spacing: 0.9em)
#set heading(numbering: none)
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#text(size: 23pt, weight: "semibold")[#text("Simons Lecture I: Structure and randomness in Fourier analysis and number theory")]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 April 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/")[#text("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-13 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("This week I am in Boston, giving this year’s ")#link("http://www-math.mit.edu/seminars/simons07.html")[#text("Simons lectures")]#text(" at MIT together with ")#link("http://www-stat.stanford.edu/~donoho/")[#text("David Donoho")]#text(". (These lectures, incidentally, are endowed by ")#link("http://en.wikipedia.org/wiki/James_Harris_Simons")[#text("Jim Simons")]#text(", who was mentioned in ")#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/#comments")[#text("some earlier discussion here")]#text(".) While preparing these lectures, it occurred to me that I may as well post my lecture notes on this blog, since this medium is essentially just an asynchronous version of a traditional lecture series, and the hypertext capability is in some ways more convenient and informal than, say, ")#mi("\\LaTeX")#text(" slides.")

#text("I am giving three lectures, each expounding on some aspects of the theme “the dichotomy between structure and randomness”, which I also ")#link("http://www.math.ucla.edu/%7Etao/preprints/Slides/icmslides2.pdf")[#text("spoke about")]#text(" (and ")#link("http://front.math.ucdavis.edu/math.NT/0512114")[#text("wrote about")]#text(") for the ")#link("http://www.icm2006.org/paginas/home_ing.html")[#text("ICM")]#text(" last August. This theme seems to pervade many of the areas of mathematics that I work in, and my lectures aim to explore how this theme manifests itself in several of these. In this, the first lecture, I describe the dichotomy as it appears in Fourier analysis and in number theory. (In ")#link("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/")[#text("the second")]#text(", I discuss the dichotomy in ergodic theory and graph theory, while in ")#link("https://terrytao.wordpress.com/2007/04/08/simons-lecture-iii-structure-and-randomness-in-pde/")[#text("the third")]#text(", I discuss PDE.)")

#metadata(none) <tao-2c8418b84cde64e467e6>

#text("The “dichotomy between structure and randomness” seems to apply in circumstances in which one is considering a “high-dimensional” class of objects (e.g. sets of integers, functions on a space, dynamical systems, graphs, solutions to PDE, etc.). For sake of concreteness, let us focus today on sets of integers (later lectures will focus on other classes of objects). There are many different types of objects in these classes, however one can broadly classify them into three categories:")

#list(
[#emph[#text("Structured")]#text(" objects – objects with a high degree of predictability and algebraic structure. A typical example are the odd integers A = {…,-3,-1,1,3,5,…}. Note that if some large number n is known to lie in A, this reveals a lot of information about whether n+1, n+2, etc. will also lie in A. Structured objects are best studied using the tools of algebra and geometry.")],
[#emph[#text("Pseudorandom")]#text(" objects – the opposite of structured; these are highly unpredictable and totally lack any algebraic structure. A good example is a randomly chosen set B of integers, in which each element n lies in B with an independent probability of 1/2. (One can imagine flipping a coin for each integer n, and defining B to be the set of n for which the coin flip resulted in heads.) Note that if some integer n is known to lie in B, this conveys no information whatsoever about the relationship of n+1, n+2, etc. with respect to B. Pseudorandom objects are best studied using the tools of analysis and probability.")],
[#emph[#text("Hybrid")]#text(" sets – sets which exhibit some features of structure and some features of pseudorandomness. A good example is the primes P = {2,3,5,7,…}. The primes have some obvious structure in them: for instance, the prime numbers are all positive, they are all odd (with one exception), they are all adjacent to a multiple of six (with two exceptions), and their last digit is always 1, 3, 7, or 9 (with two exceptions). On the other hand, there is evidence that the primes, despite being a deterministic set, behave in a very “pseudorandom” or “uniformly distributed” manner. For instance, from the ")#link("http://en.wikipedia.org/wiki/Siegel-Walfisz_theorem")[#text("Siegel-Walfisz theorem")]#text(" we know that the last digit of large prime numbers is uniformly distributed in the set {1,3,7,9}; thus, if N is a large integer, the number of primes less than N ending in (say) 3, divided by the total number of primes less than N, is known to converge to 1/4 in the limit as N goes to infinity. In order to study hybrid objects, one needs a large variety of tools: one needs tools such as algebra and geometry to understand the structured component, one needs tools such as analysis and probability to understand the pseudorandom component, and one needs tools such as decompositions, algorithms, and evolution equations to separate the structure from the pseudorandomness. (More on this in later talks.)")]
)

#text("A recurring question in many areas of analysis is the following: given a specific object (such as the prime numbers), can one determine precisely what the structured components are within the object, and how pseudorandom the remaining components of the object are? One reason for asking this question is that it often helps one compute various ")#emph[#text("statistics")]#text(" (averages, sums, integrals, correlations, norms, etc.) of the object being studied. For instance, one can ask for how many twin pairs {n, n+2}, with n between 1 and N, one can find within a given set. In the structured set A given above, the answer is roughly N/2. For the random set B given above, the answer is roughly N/4; thus one sees that while A and B have exactly the same density (namely, 1/2), their statistics are rather different due to the fact that one is structured and one is random. As for the prime numbers, nobody knows what the answer is (though ")#link("http://en.wikipedia.org/wiki/Twin_prime_conjecture")[#text("it is conjectured")]#text(" to be roughly ")#mi("1.32 \\frac{N}{\\log^2 N}")#text("), because we do not know enough yet about the pseudorandomness of the primes. On the other hand, the parity structure of the prime numbers is enough to show that the number of ")#emph[#text("adjacent ")]#text("pairs {n, n+1} in the primes is exactly one: {2,3}.")

#text("The problem of determining exactly what the structured and pseudorandom components are of any given object is still largely intractable. However, what we have learnt in many cases is that we can at least show that an arbitrary object can be ")#emph[#text("decomposed")]#text(" into some structured component and some pseudorandom component. Also there is often an ")#emph[#text("orthogonality")]#text(" property (or ")#emph[#text("dichotomy")]#text("): if an object is orthogonal (or has small correlation with) all structured objects, then it is necessarily pseudorandom, and vice versa. Finally, we are sometimes lucky enough to be able to ")#emph[#text("classify")]#text(" all the structured objects which are relevant for any given problem (e.g. computing a particular statistic). In such cases, one merely needs (in principle) to compute how the given object correlates with each member in one’s list of structured objects in order to determine what the desired statistic is. This is often simpler (though still non-trivial) than computing the statistic directly.")

#text("To illustrate these general principles, let us focus now on a specific area in analytic number theory, namely that of finding additive patterns in the prime numbers {2, 3, 5, 7, …}. Despite centuries of progress on these problems, many questions are still unsolved, for instance:")

#list(
[#link("http://en.wikipedia.org/wiki/Twin_prime_conjecture")[#text("Twin prime conjecture")]#text(": There are infinitely many positive integers n such that n, n+2 are both prime.")],
[#link("http://en.wikipedia.org/wiki/Sophie_Germain_prime")[#text("Sophie Germain prime conjecture")]#text(": There are infinitely many positive integers n such that n, 2n+1 are both prime.")],
[#link("http://en.wikipedia.org/wiki/Goldbach%27s_conjecture")[#text("Even Goldbach conjecture")]#text(": For every even number ")#mi("N \\geq 4")#text(", there is a natural number n such that n, N-n are both prime.")]
)

#text("On the other hand, we do have some positive results:")

#list(
[#link("http://en.wikipedia.org/wiki/Vinogradov%27s_theorem")[#text("Vinogradov’s theorem")]#text(": For every sufficiently large odd number N, there are positive integers n, n’ such that n, n’, N-n-n’ are all prime. (The ")#link("http://www.ams.org/mathscinet-getitem?mr=1932763")[#text("best explicit bound currently known")]#text(" for “sufficiently large” is ")#mi("N \\geq 10^{1346}")#text("; the result ")#link("http://www.ams.org/mathscinet-getitem?mr=1451327")[#text("has also been verified")]#text(" for ")#mi("7 \\leq N \\leq 10^{20}")#text(".)")],
[#link("http://primes.utm.edu/references/refs.cgi?author=Corput")[#text("van der Corput’s theorem")]#text(": There are infinitely many positive integers n, n’ such that n, n+n’, n+2n’ are all prime.")],
[#link("http://en.wikipedia.org/wiki/Green-Tao_theorem")[#text("Green-Tao theorem")]#text(": For any positive integer k, there are infinitely many positive integers n, n’ such that n, n+n’, …, n+(k-1)n’ are all prime.")],
[#link("http://arxiv.org/abs/math.NT/0610050")[#text("A polynomial generalisation")]#text(": For any integer-valued polynomials ")#mi("P_1(n), \\ldots, P_k(n)")#text(" with ")#mi("P_1(0) = \\ldots = P_k(0) = 0")#text(", there are infinitely many positive integers n, n’ such that ")#mi("n+P_1(n'), \\ldots, n+P_k(n')")#text(" are all prime.")]
)

#text("As a general rule, it appears that it is feasible (after non-trivial effort) to find patterns in the primes involving two or more degrees of freedom (as described by the parameters n, n’ in above examples), but we still do not have the proper technology for finding patterns in the primes involving only one degree of freedom n. (This is of course an oversimplification; for instance, the pattern n, n+2, n’, n’+2 has two degrees of freedom, but finding infinitely many of these patterns in the primes is equivalent to the twin prime conjecture. If however one makes a non-degeneracy assumption, ")#link("http://arxiv.org/abs/math/0606088")[#text("one can make the above claim more precise")]#text(".)")

#text("One useful tool for establishing some (but not all) of the above positive results is Fourier analysis (which in this context is also known as the ")#emph[#text("Hardy-Littlewood circle method")]#text("). Rather than give the textbook presentation of that method here, let us try to motivate why Fourier analysis is an essential feature of many of these problems from the perspective of the dichotomy between structure and randomness, and in particular viewing structure as an obstruction to computing statistics which needs to be understood before the statistic can be accurately computed.")

#text("To treat many of the above questions concerning the primes in a unified manner, let us consider the following general setting. We consider k affine-linear forms ")#mi("\\psi_1, \\ldots, \\psi_k: {\\Bbb Z}^r \\to {\\Bbb Z}")#text(" on r integer unknowns, and ask")

#list(
[#strong[#text("Question")]#text(": does there there exist infinitely many r-tuples ")#mi("\\vec n = (n_1,\\ldots,n_r) \\in {\\Bbb Z}_+^r")#text(" of positive integers such that ")#mi("\\psi_1(\\vec n), \\ldots, \\psi_k(\\vec n)")#text(" are simulatenously prime?")]
)

#text("For instance, the twin prime conjecture is the case when k=2, r=1, ")#mi("\\psi_1(n) = n")#text(", and ")#mi("\\psi_2(n) = n+2")#text("; van der Corput’s theorem is the case when k=3, r=2, and ")#mi("\\psi_j(n,n') = n + (j-1)n'")#text(" for j=0,1,2; and so forth.")

#text("Because of the “obvious” structures in the primes, the answer to the above question can be “no”. For instance, since all but one of the primes are odd, we know that there are not infinitely many patterns of the form n, n+1 in the primes, because it is not possible for n, n+1 to both be odd. More generally, given any prime q, we know that all but one of the primes is coprime to q. Hence, if it is not possible for ")#mi("\\psi_1(\\vec n), \\ldots, \\psi_k(\\vec n)")#text(" to all be coprime to q, the answer to the above question is basically no (modulo some technicalities which I wish to gloss over) and we say that there is an ")#emph[#text("obstruction at q")]#text(". For instance, the pattern n, n+1 has an obstruction at 2. The pattern n, n+2, n+4 has no obstruction at 2, but has an obstruction at 3, because it is not possible for n, n+2, n+4 to all be coprime to 3. And so forth.")

#text("Another obstruction comes from the trivial observation that the primes are all positive. Hence, if it is not possible for ")#mi("\\psi_1(\\vec n), \\ldots, \\psi_k(\\vec n)")#text(" to all be positive for infinitely many values of ")#mi("\\vec n")#text(", then we say that there is an ")#emph[#text("obstruction at infinity")]#text(", and the answer to the question is again “no” in this case. For instance, for any fixed N, the pattern n, N-n can only occur finitely often in the primes, because there are only finitely many n for which n, N-n are both positive.")

#text("It is conjectured that these “local” obstructions are the only ")#emph[#text("obstructions ")]#text("to solvability of the above question. More precisely, we have")

#list(
[#link("http://primes.utm.edu/glossary/page.php?sort=DicksonsConjecture")[#text("Dickson’s conjecture")]#text(": If there are no obstructions at any prime q, and there are no obstructions at infinity, then the answer to the above question is “yes”.")]
)

#text("This conjecture would imply the twin prime and Sophie Germain conjectures, as well as the Green-Tao theorem; it also implies the ")#link("http://primes.utm.edu/glossary/page.php?sort=PrimeKtupleConjecture")[#text("Hardy-Littlewood prime tuples conjecture")]#text(" as a special case. There is a quantitative version of this conjecture which predicts a more precise count as to how many solutions there are in a given range, and which would then also imply Vinogradov’s theorem, as well as Goldbach’s conjecture (for sufficiently large N); see ")#link("http://arxiv.org/abs/math.NT/0606088")[#text("this paper")]#text(" for further discussion. As one can imagine, this conjecture is still largely unsolved, however there are many important special cases that have now been established – several of which via the Hardy-Littlewood circle method.")

#text("One can view Dickson’s conjecture as an ")#emph[#text("impossibility statement")]#text(": that it is impossible to find any other obstructions to solvability for linear patterns in the primes than the obvious local obstructions at primes q and at infinity. (It is also a good example of a ")#emph[#text("local-to-global principle")]#text(", that local solvability implies global solvability.) Impossibility statements have always been very difficult to prove – one has to locate all possible obstructions to solvability, and eliminate each one of them in turn. In particular, one has to exclude various exotic “conspiracies” between the primes to behave in an unusually structured manner that somehow manages to always avoid all the patterns that one is seeking within the primes. How can one disprove a conspiracy?")

#text("To give an example of what such a “conspiracy” might look like, consider the twin prime conjecture, that of finding infinitely many pairs n, n+2 which are both prime. This pattern encounters no obstructions at primes q or at infinity and so Dickson’s conjecture predicts that there should be infinitely many such patterns. In particular, there are no obstructions at 3 because prime numbers can equal 1 or 2 mod 3, and it is possible to find pairs n, n+2 which also have this property. But suppose that it transpired that all but finitely many of the primes ended up being 2 mod 3. From looking at tables of primes this seems to be unlikely, but it is not immediately obvious how to disprove it; it could well be that once one reaches, say, ")#mi("10^{100}")#text(", there are no more primes equal to 1 mod 3. If this unlikely “conspiracy” in the primes was true, then there would be only finitely many twin primes. Fortunately, we have ")#link("http://en.wikipedia.org/wiki/Dirichlet%27s_theorem_on_arithmetic_progressions")[#text("Dirichlet’s theorem")]#text(", which guarantees infinitely many primes equal to a mod q whenever a, q are coprime, and so we can rule out this particular type of conspiracy. (This does strongly suggest, though, that knowledge of Dirichlet’s theorem is a necessary but not sufficient condition in order to solve the twin prime conjecture.) But perhaps there are other conspiracies that one needs to rule out also?")

#text("To look for other conspiracies that one needs to eliminate, let us rewrite the conspiracy “all but finitely many of the primes are 2 mod 3” in the more convoluted format")

#align(center)[#mitex("0.6 < \\{ \\frac{1}{3} p \\} < 0.7")#text(" for all but finitely many primes p")]

#text("where {x} is the fractional part of x. This type of conspiracy can now be generalised, for instance consider the statement")

#align(center)[#mitex("0 < \\{ \\sqrt{2} p \\} < 0.01")#text(" for all but finitely many primes p. (*)")]

#text("Again, such a conspiracy seems very unlikely – one would expect these fractional parts to be uniformly distributed between 0 and 1, rather than concentrate all in the interval [0, 0.01] – but it is hard to rule this conspiracy out ")#emph[#text("a priori")]#text(". And if this conspiracy (*) was in fact true, then the twin prime conjecture would be false, as can be quickly seen by considering the identity")

#align(center)[#mitex("\\{ \\sqrt{2} (n+2) \\} - \\{ \\sqrt{2} n \\} = 2 \\sqrt{2} \\hbox{ mod } 1")#text(",")]

#text("which forbids the two fractional parts on the left-hand side to simultaneously fall in the interval [0, 0.01]. Thus, in order to solve the twin prime conjecture, one must rule out (*). Fortunately, it has been known since the work of Vinogradov that ")#mi("\\{ \\sqrt{2} p \\}")#text(" is in fact uniformly distributed in the interval [0,1], and more generally that ")#mi("\\{ \\alpha p \\}")#text(" is uniformly distributed in [0,1] whenever ")#mi("\\alpha")#text(" is irrational. Indeed, by ")#link("http://en.wikipedia.org/wiki/Weyl%27s_criterion")[#text("Weyl’s criterion")]#text(", this is equivalent to the exponential sum estimate")

#align(center)[#mitex("\\sum_{p < N} e^{2\\pi i \\alpha p} = o( \\sum_{p < N} 1 )")#text(",")]

#text("and we now see the appearance of Fourier analysis in this subject.")

#text("One can rather easily concoct an endless stream of further conspiracies, each of which could contradict the twin prime conjecture; this is one of the reasons why this conjecture is considered so difficult. Let us thus leave this conjecture for now and consider some two-parameter problems. Consider for instance the problem of finding infinitely many patterns of the form n, n+n’, n+2n’+2 (i.e. arithmetic progressions of length 3, but with the last element shifted by 2). Once again, the conspiracy (*), if true, would obstruct solvability for this pattern, due to the easily verified identity")

#align(center)[#mitex("\\{ \\sqrt{2} n \\} - 2 \\{ \\sqrt{2} (n+n') \\} + \\{ \\sqrt{2} (n+2n'+2) \\} = 2 \\sqrt{2} \\hbox{ mod } 1")]

#text("which is related to the fact that the function ")#mi("\\sqrt{2} n")#text(" has a vanishing second derivative. (Note however that the same conspiracy does not obstruct solvability of an unmodified arithmetic progression n, n+n’, n+2n’. This highlights a special property of arithmetic progressions, which most other patterns do not have: namely that arithmetic progressions tend to exist both in structured objects and in pseudorandom objects, or in hybrids of the two. This is why results about arithmetic progressions have tended to be easier to establish than those about more general patterns, as one does not need to know as much about the structured and random components of the set in which one is looking for progressions.)")

#text("More generally, we can see that if the primes correlate in some unusual way with a linear character ")#mi("e^{2\\pi i \\alpha p}")#text(", then this is likely to bias or distort the number of patterns {n, n+n’, n+2n’+2} in a significant manner. However, thanks to Fourier analysis, we can show that these “Fourier conspiracies” are in fact the ")#emph[#text("only")]#text(" obstructions to counting this type of pattern. Very roughly, one can sketch the reason for this as follows. Firstly, it is helpful to create a counting function for the primes, namely the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(" ")#mi("\\Lambda(n)")#text(", defined as ")#mi("\\log p")#text(" whenever n is a power of a prime p, and 0 otherwise. This rather strange-looking function is actually rather natural, because of the identity")

#align(center)[#mitex("\\sum_{d|n} \\Lambda(d) = \\log n")]

#text("for all positive integers n; this identity is a restatement of the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_arithmetic")[#text("fundamental theorem of arithmetic")]#text(", and in fact defines the von Mangoldt function uniquely. The problem of counting patterns {n, n+n’, n+2n’+2} is then roughly equivalent to the task of computing sums such as")

#align(center)[#mitex("\\sum_n \\sum_{n'} \\Lambda(n) \\Lambda(n+n') \\Lambda(n+2n'+2)")#text(" (**)")]

#text("where we shall be intentionally vague as to what range the variables n, n’ will be summed over. We have the Fourier inversion formula")

#align(center)[#mitex("\\Lambda(n) = \\int_0^1 e^{2\\pi i n \\theta} \\hat \\Lambda(\\theta) d\\theta")]

#text("where")

#align(center)[#mitex("\\hat \\Lambda(\\theta) = \\sum_n \\Lambda(n) e^{-2\\pi i n \\theta}")]

#text("is a sum very similar in nature to the sums ")#mi("\\sum_{p < N} e^{2\\pi i p \\alpha}")#text(" mentioned earlier. Substituting this formula into (**), we essentially get an expression of the form")

#align(center)[#mitex("\\int_0^1 \\hat \\Lambda(\\theta)^2 \\hat \\Lambda(-2\\theta) e^{4\\pi i \\theta}\\ d\\theta.")]

#text("Thus, if one gets good enough control on the Fourier coefficients ")#mi("\\hat \\Lambda(\\theta)")#text(", which can be viewed as a measure of how much the primes “conspire” with a linear phase oscillation with frequency ")#mi("\\theta")#text(", then one can (in principle, at least) count the solutions to the pattern {n, n+n’, n+2n’+2} in the primes. This is the Hardy-Littlewood circle method in a nutshell, and this is for instance how van der Corput’s theorem and Vinogradov theorem were first proven.")

#text("I have glossed over the question of how one actually ")#emph[#text("computes")]#text(" the Fourier coefficients ")#mi("\\hat \\Lambda(\\theta)")#text(". It turns out that there are two cases. In the “major arc” case when ")#mi("\\theta")#text(" is rational, or close to rational (with a reasonably small denominator), then the problem turns out to be essentially equivalent to counting primes in arithmetic progressions, and so one uses tools related to Dirichlet’s theorem (")#link("http://en.wikipedia.org/wiki/Dirichlet_L-function")[#text("L-functions")]#text(", the ")#link("http://en.wikipedia.org/wiki/Siegel-Walfisz_theorem")[#text("Siegel-Walfisz theorem")]#text(", etc.). In the “minor arc” case when ")#mi("\\theta")#text(" is far from rational, one instead uses identities such as")

#align(center)[#mitex("\\Lambda(n) = \\sum_{d|n} \\mu(d) \\log\\frac{n}{d},")]

#text("where ")#mi("\\mu")#text(" is the ")#link("http://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("Möbius function")]#text(", to split the Fourier coefficient as")

#align(center)[#mitex("\\hat \\Lambda(\\theta) = \\sum_d \\sum_m \\mu(d) \\log(m) e^{2\\pi i \\alpha dm}")]

#text("and then one uses the irrationality of ")#mi("\\alpha")#text(" to exhibit some significant oscillation in the phase ")#mi("e^{2\\pi i \\alpha dm}")#text(", which cannot be fully canceled out by the oscillation in the ")#mi("\\mu(d)")#text(" factor. (In practice, the above strategy does not work directly, and one has to work with various truncated or smoothed out versions of the above identities; this is technical and will not be discussed here.)")

#text("Now suppose we look at progressions of length 4: n, n+n’, n+2n’, n+3n’. As with progressions of length 3, “linear” or “Fourier” conspiracies such as (*) will bias or distort the total count of such progressions in the primes less than a given number N. But, in contrast to the length 3 case where these are the only conspiracies that actually influence things, for length 4 progressions there are now “quadratic” conspiracies which can cause trouble. Consider for instance the conspiracy")

#align(center)[#mitex("0 < \\{ \\sqrt{2} p^2 \\} < 0.01")#text(" for all but finitely many primes p (***).")]

#text("This conspiracy, which can exist even when all linear conspiracies are eliminated, will significantly bias the number of progressions of length 4, due to the identity")

#align(center)[#mitex("\\{ \\sqrt{2} n^2 \\} - 3 \\{ \\sqrt{2} (n+n')^2 \\} + 3\\{ \\sqrt{2} (n+2n')^2 \\} - \\{ \\sqrt{2} (n+3n')^2 \\}")]

#align(center)[#mitex("= 0 \\hbox{ mod } 1")]

#text("which is related to the fact that the function ")#mi("\\sqrt{2} n^2")#text(" has a vanishing third derivative. In this case, the conspiracy works in one’s favour, increasing the total number of progressions of length 4 beyond what one would have naively expected; as mentioned before, this is related to a remarkable “indestructability” property of progressions, which can be used to establish things like the Green-Tao theorem without having to deal directly with these obstructions. Thus, in order to count progressions of length 4 in the primes accurately (and not just to establish the qualitative result that there are infinitely many of them), one needs to eliminate conspiracies such as (***), which necessitates understanding exponential sums such as ")#mi("\\sum_{p < N} e^{2\\pi i \\alpha p^2}")#text(" for various rational or irrational numbers ")#mi("\\alpha")#text(". What’s worse, there are several further “generalised quadratic” conspiracies which can also bias this count, for instance the conspiracy")

#align(center)[#mitex("0 < \\{ [\\sqrt{2} p] \\sqrt{3} p \\} < 0.01")#text(" for all but finitely many primes p,")]

#text("where [] is the greatest integer function. The point here is that the function ")#mi("{}[\\sqrt{2} x] \\sqrt{3} x")#text(" has a third divided difference which does not entirely vanish (as with the genuine quadratic ")#mi("\\sqrt{2} x^2")#text("), but does vanish a significant portion of the time (because the greatest integer function obeys the linearity property [x+y] = [x] + [y] a significant fraction of the time), which does lead ultimately to a non-trivial bias effect. Because of this, one is also faced with estimating exponential sums such as ")#mi("\\sum_{p < N} e^{2\\pi i [\\sqrt{2} p] \\sqrt{3} p}")#text(". It turns out that the correct way to phrase all of these obstructions is via the machinery of ")#emph[#text("2-step nilsequences")]#text(": details can be found in ")#link("http://front.math.ucdavis.edu/math.NT/0503014")[#text("these")]#text(" ")#link("http://arxiv.org/abs/math.NT/0606087")[#text("three")]#text(" ")#link("http://arxiv.org/abs/math.NT/0606088")[#text("papers")]#text(" of Ben Green and myself. As a consequence, we can in fact give a precise count as to how many arithmetic progressions of primes of length 4 with all primes less than N; it turns out to be")

#align(center)[#mitex("(\\frac{3}{4} \\prod_{p \\geq 5} (1 - \\frac{3p-1}{(p-1)^3}) + o(1)) \\frac{N^2}{\\log^4 N} \\approx 0.4764 \\frac{N^2}{\\log^4 N}.")]

#text("The method also works for other linear patterns of comparable “complexity” to progressions of length 4. We are currently working on the problem of longer progressions, in which cubic and higher order obstructions appear (which should be modeled by 3-step and higher nilsequences); some work related to this should appear here shortly.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (45)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-316")[#strong[#text("stevenm")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2007")

#text("Hi Terry,")#linebreak()#text(" Your chosen theme “dichotomy between structure and randomness” is certainly a very interesting one not only in mathematics but in theoretical physics, complexity and biology: fluctuations or randomness will give")#linebreak()#text(" rise to the growth of structure, whether it is galaxies arising from")#linebreak()#text(" randomness in the early universe, or the complexity and the evolution of biological structures. The effect of random noise on multi-dimensional nonlinear systems is also of much interest, for example in turbulence or pattern formation. As regards the pseudorandom objects you mention, an open problem should surely still be whether one can truly distinguish")#linebreak()#text(" between a pseudorandom sequence and a truly random sequence, without knowing the generating algorithm that was used and the state in which it was initially prepared. The security of most encryption algorithms I assume would be based on the assumption that it is actually totally impossible to distinguish between these. (Is it though?). Von Neumann remarked that those who think they can generate random numbers using arithmetical algorithms are “in sin”. But since his time some rather sophisticated pseudorandom number generators have evolved such as the ‘Blum Blum Shub’, the ‘Fortuna’ and the ‘Mersenne Twister’. Could the output of one of these be distinguished–within a tractable sample size–from a truly random number sequence that has been generated via a physical process such as thermal noise or a quantum process like radioactive decay? Monte Carlo simulations in physics and finance etc. will assume that a pseudo-random sequence is good enough for the simulation of processes that are expected to be truly random. I was also curious whether your interests have ever included, or currently include, stochastic partial differential equations (SPDEs) or “stochastic geometries”; geometries or geometric structures that fluctuate or evolve in a random way?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-318")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2007")

#text("Dear Stevenm,")

#text("There is certainly an analogy between algorithmic pseudorandomness, and the type of pseudorandomness that I will talk about in these lectures (Fourier pseudorandomness (Gowers uniformity), ergodic pseudorandomness (mixing), graph pseudorandomness (regularity), and dispersive pseudorandomness (local decay). For instance, if one views an algorithm as a finite state machine, then the running of this algorithm does resemble a kind of discrete version of a dynamical system. I am not an expert in computational complexity, but it appears though that the analogous questions for algorithmic pseudorandomness are significantly more difficult to answer, touching on major unsolved problems such as ")#mi("P \\neq NP")#text(" and ")#mi("P = BPP")#text(".")

#text("There is a heuristic conjecture that the primes (or more precisely, the Möbius function ")#mi("\\mu(n)")#text(") are so “algorithmically pseudorandom” that they having vanishing asymptotic correlation with any “finite complexity” bounded sequence a(n), though I am not sure I can define what “finite complexity” means precisely (something like the output at time n of a dynamical system which can be described algebraically using only finitely many symbols). This conjecture, even if it is stated rigorously, is probably beyond the reach of current technology.")

#text("Incidentally, I do have a project on random quasiconformal geometries, which should appear here in a few months.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-319")[#strong[#text("Simons Lecture II: Structure and randomness in ergodic theory and graph theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2007")

#text("[…] the last lecture we saw that sets of integers could be divided (rather informally) into structured sets, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-320")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2007")

#text("The conjecture that ")#mi("P = BPP")#text(" is much more to the point of algorithmic pseudorandomness than ")#mi("P \\ne NP")#text(". There is a theorem that ")#mi("P = BPP")#text(" relative to a random oracle, i.e., that ")#mi("P^A = BPP^A")#text(" if ")#mi("A")#text(" is a randomly chosen Boolean function. The exponential notation means that that ")#mi("A")#text(" is supplied to the computer as a black-box function. The proof is the classic, original derandomization argument. If you run the randomized algorithm with the pseudorandom source with enough trials, and then combine the results with majority rule, then consensus will be wrong for only finitely many inputs with probability 1, with respect to the random choice of ")#mi("A")#text(". An algorithm that is only wrong for finitely many inputs can be repaired to one that is always right.")

#text("Much of the work in showing that ")#mi("P = BPP")#text(" has gone into replacing ")#mi("A")#text(" with a cryptographic function ")#mi("f")#text(". If you imagine using ")#mi("f")#text(" is the above derandomization argument, then the requirement on ")#mi("f")#text(" is exactly that it should be cryptographically pseudorandom. Because, you can pick the algorithm to be anything that attempts to distinguish ")#mi("f")#text(" from a truly random ")#mi("A")#text(". (Note the two uses of the word “random” here. ")#mi("BPP")#text(" means algorithms that are allowed randomness on the fly, whlie ")#mi("P^A")#text(" is deterministic algorithms with a randomly chosen, infinite ROM table.)")

#text("Essentially, people believe that ")#mi("P = BPP")#text(" because they believe that universal pseudorandom functions ")#mi("f")#text(" exist. In fact, they can make specific examples, they just can’t prove that they work. I have the feeling that there are weaker circumstances that still prove that ")#mi("P = BPP")#text(", but this is a summary of what people think is really going on.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-330")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2007")

#text("Concerning exponential sums over primes, I wonder what you might think about exponential sums involving sqrt(p), in particular what kind of “conspiracies” or")#linebreak()#text(" natural problems they could be related to?")#linebreak()#text(" The point is that Iwaniec, Luo and Sarnak have related such exponential sums")#linebreak()#text(" to the Riemann Hypothesis for certain modular L-functions (see")#linebreak()#text(" ")#link("http://www.numdam.org/numdam-bin/fitem?id=PMIHES_2000__91__55_0")[#text("http://www.numdam.org/numdam-bin/fitem?id=PMIHES_2000__91__55_0")]#linebreak()#text(" specifically their Hypothesis (S), discussed in Section 10, and Appendix C;")#linebreak()#text(" technically, good cancellation in sums with sqrt(p) uniformly over arithmetic")#linebreak()#text(" progressions would lead to a zero-free strip, under some condition).")#linebreak()#text(" There is definitely a group underlying their work, namely SL(2,Z).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-336")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2007")

#text("Dear Emmanuel,")

#text("Thank you very much for your comment! I had heard of the ILS paper before but had not had a chance to seriously look at it.")

#text("There are two sorts of conspiracies: ")#emph[#text("blatant conspiracies")]#text(", which for instance prevent ")#mi("\\sum_{p \\le x} e(\\phi(p)) = o( \\sum_{p \\le x} 1)")#text(" for various “algebraic” functions ")#mi("\\phi")#text(", and the much weaker ")#emph[#text("spoiler conspiracies")]#text(", which instead cause just enough non-randomness to prevent ")#mi("\\sum_{p \\le x} e(\\phi(p)) = O_\\epsilon(x^{1/2+\\epsilon})")#text(". A single zero of an L-function off the critical line, for instance, is a spoiler conspiracy, whereas one at 1 or at 1+it is a blatant conspiracy. I don’t really have the courage to state what spoiler conspiracies are possible – and the Hypothesis S in ILS is of a “no spoiler conspiracy” type. But it seems plausible that the only blatant conspiracies that the primes have are the “obvious” ones, coming from local considerations.")

#text("The story may be more complicated if one restricts to a thinner set than the full integers or the full primes, such as polynomial sequences f(T), where T ranges over the integers. For instance, in the “finite field model” in which the integers are replaced by a polynomial ring ")#mi("k[u]")#text(" over a finite field, ")#link("http://www.math.lsa.umich.edu/~bdconrad/papers/hlsingle.pdf")[#text("Conrad-Conrad-Gross")]#text(" have a blatant conspiracy that shows that certain one-variable polynomials f(T) are biased to not be prime despite avoiding all obvious local obstructions (e.g. reducibility) – though this particular conspiracy is very much a feature of the finite characteristic of the underlying field. Then of course there are all the Hilbert 10th problem constructions, such as polynomials whose positive values are precisely the primes, and so forth. So I would be hesitant to make any grand conjectures on sparse sets, such as those given by polynomials or group actions, at present (though I hear that Bourgain, Gamburd, and Sarnak have made some very recent advances in this direction, at least regarding almost primes instead of primes).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-342")[#strong[#text("Paul Krapivsky")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2007")

#text("Sorry, this is the last try…")

#text("Dear Terry and Emmanuel,")

#text("Another potentially interesting problem is the distribution of gaps in the sequence of fractional part of square-roots of primes. If one considers the sequence {n^a}, with some 0")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-344")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2007")

#text("Dear Paul,")

#text("I think your comments are turning the < signs into HTML. You can try using &lt; and &gt; instead. I know, it’s a pain, I wish I could do something about it…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-351")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2007")

#text("I definitely agree with the distinction between “spoiler” and “blatant” conspiracies.")#linebreak()#text(" In classical prime number theory, it seems that most “blatant” conspiracies")#linebreak()#text(" are really symptoms of ignorance: they can/should be incorporated to the “main")#linebreak()#text(" term” (but of course that can be wishful thinking…), or used to reformulate the original")#linebreak()#text(" problem (e.g. p-1 can not be prime infinitely often, but (p-1)/2 can…).")#linebreak()#text(" Another (maybe) interesting point is that when we deal with prime numbers, sometimes")#linebreak()#text(" difficulties are really inherited from the integers. This is very clear when using sieve methods; for instance, in the type of problems that Bourgain, Sarnak and Gamburd are investigating (looking at points with prime or almost prime coordinates in orbits of certain groups actions, etc) even the corresponding counting problem for integers are hard, but they more or less have to be used as a starting point for looking at primes with sieve.")#linebreak()#text(" On the other hand, their problems, as far as I understand, do not actually involve sums")#linebreak()#text(" over primes (or integers) with functions like sqrt(p) — and correspondingly, the source")#linebreak()#text(" of cancellation lies in spectral gaps of various types (Selberg’s theorem, approximations to Ramanujan-Petersson conjecture, and especially expanding graphs in the more combinatorial settings, etc).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-355")[#strong[#text("Paul Krapivsky")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2007")

#text("Dear Terry and Emmanuel,")

#text("Another potentially interesting problem is the distribution of gaps in the sequence of fractional part of square-roots of primes. If one considers the sequence {n^A} of natural numbers n=1,…,N, and multiplies the gap lengths by N, the gap distribution becomes exponential in the large N limit for all exponents A (between 0 and 1) except A=1/2. This is an astonishing experimental observation; for A=1/2 the gap length distribution was recently found by Elskies and McMullen, and it is indeed very different from exponential — it exhibits two `phase transitions’ and it has an algebraic tail. It is possible of course that the replacement of the whole numbers by primes merely makes the problem difficult but does not alter the gap distribution.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-382")[#strong[#text("Not Even Wrong » Blog Archive » Math and Physics Roundup")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2007")

#text("[…] of the highest possible quality, see Terry Tao’s postings on his Simons lectures at MIT, here, here and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-466")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2007")

#text("Dear Paul,")

#text("Gap distributions in any statistics related to primes are of course very interesting, but also well beyond our current technology; they seem to require knowing an incredible amount of “fine-scale” or “local” behaviour for the primes, whereas our current analytic knowledge primarily extends to rather “coarse-scale” or “aggregate” statistics; even the generalised Riemann hypothesis, while it would dramatically improve our coarse-scale control of the primes, doesn’t actually do much for the fine-scale questions (e.g. the twin prime conjecture doesn’t seem to become much easier on GRH). Even finding the right conjectures to make for, say, the asymptotic distribution of prime gaps ")#mi("p_{n+1} - p_n")#text(", is remarkably subtle. Perhaps the best way to proceed here is simply by numerics, to see if anything unexpected happens – I would guess that the gap distribution for {p^A} would be similar to {n^A}, especially near generic (e.g. Diophantine) points in [0,1], but it could well be that some unusual irregularity emerges.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-519")[#strong[#text("As coisinhas interessantes de hoje… at It’s Equal but It’s Different")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2007")

#text("[…] Simons Lecture I: Structure and randomness in Fourier analysis and number theory; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-715")[#strong[#text("Fields Medalist Symposium « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2007")

#text("[…] I gave a more detailed presentation of the material I had discussed in my first Simons lecture, and focussing a bit more on the role of nilflows in characterising the “structure” or […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-771")[#strong[#text("Distinguished Lecture Series I: Shou-wu Zhang, \"Overview of rational points on curves\" « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2007")

#text("[…] the to be non-zero (otherwise there is a local obstruction at p, similar to what I discussed in my first Simons lecture). Hasse formed his famous local-to-global principle, which is the heuristic that the converse […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-1001")[#strong[#text("warren smith")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2007")

#text("I want to know the following.")#linebreak()#text(" Are there an infinite number of 2-tuples (p,q) of odd primes such that")#linebreak()#text(" (p-1)*(q-1) is a product of at most a constant number of primes.")#linebreak()#text(" And is this still true if we demand both p and q be larger than C")#linebreak()#text(" (for any particular C)?")

#text("It sounds like this is similar to things you and Chen Jing-Run could do…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-1006")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2007")

#text("Dear Warren,")

#text("The argument of Chen will give infinitely many primes p for which (p-1)/2 is the product of at most 2 primes, which then in turn gives arbitrarily large pairs (p-1)(q-1) which is the product of at most 4 primes, times 4 (so six primes in all). This is probably the best one can do with current technology, due to the parity problem (I plan to post more on this in the future).")

#text("One does not quite need the full power of Chen’s result to get a qualitative result of this nature; using slightly lower-tech methods such as the Selberg sieve coupled with the Bombieri-Vinogradov inequality, one can achieve the same result but with O(1) primes in the prime factorisation of (p-1)(q-1).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-1027")[#strong[#text("warren smith")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2007")

#text("to TT: I sent you some email, it appears your precediing post is the extra ingredient I needed to solve an open problem in coding theory.")#linebreak()#text(" (Or I’m just wrong.) Anyway, read the email. Cheerio.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-1206")[#strong[#text("Primes in Pre-K « Home Schooled")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2007")

#text("[…] primes. See, pattern!” For a second I thought he’d been to one of Terry Tao’s lectures… The number 33 sort of burst his bubble. Still, he keeps […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-5318")[#strong[#text("Structure and randomness in combinatorics « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2007")

#text("[…] 2007 conference in October. This tutorial covers similar ground as my ICM paper (or slides), or my first two Simons lectures, but focuses more on the “nuts-and-bolts” of how structure theorems […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-6815")[#strong[#text("Martin Winer")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2007")

#text("Hi Terry,")

#text("I don’t claim to be in your league in mathematics, just the same, you never know. Sometimes an amature’s view of the problem can help the pro’s figure things out. In my mind randomness is determinism cross recursive self complication. I use this idea to probe primes using a recursively self complicating algorithm Pat(f(n)) which lays down the primes.")

#text("The quick explanation is here:")#linebreak()#text(" ")#link("http://www.rankyouragent.com/primes/primes_simple.htm")[#text("http://www.rankyouragent.com/primes/primes_simple.htm")]#linebreak()#text(" The more detailed version is here:")#linebreak()#text(" ")#link("http://www.rankyouragent.com/primes/primes.htm")[#text("http://www.rankyouragent.com/primes/primes.htm")]

#text("Best regards and good luck in your search…MCW")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-8343")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2007")

#text("you are good on elementry prime number methods but do not discuss the langlands conjecture")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-11486")[#strong[#text("Mario")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2007")

#text("It is always interesting to consider the subject of generating random")#linebreak()#text(" numbers – but – given that ‘EVERYTHING’ around us in the physical")#linebreak()#text(" sense is ‘computing’ and given that ALL ‘computations are at least")#linebreak()#text(" ‘POTENTIALLY’ reversible (if you could live long enough…what exactly")#linebreak()#text(" is ‘RANDOM’?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-11505")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2007")

#text("Dear Mario,")

#text("It may well be that the universe itself is completely deterministic (though this depends on what the “true” laws of physics are, and also to some extent on certain ontological assumptions about reality), in which case randomness is simply a mathematical concept, modeled using such abstract mathematical objects as probability spaces. Nevertheless, the concept of ")#emph[#text("pseudorandomness")]#text(" – objects which “behave” randomly in various statistical senses – still makes sense in a purely deterministic setting. A typical example are the digits of ")#mi("\\pi = 3.14159\\ldots")#text("; this is a deterministic sequence of digits, but is widely believed to behave pseudorandomly in various precise senses (e.g. each digit should asymptotically appear 10% of the time). If a deterministic system exhibits a sufficient amount of pseudorandomness, then random mathematical models (e.g. statistical mechanics) can yield accurate predictions of reality, even if the underlying physics of that reality has no randomness in it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-42652")[#strong[#text("AJ")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2009")

#text("Professor Tao:")#linebreak()#text(" I think your explanation assumes “the universe” as a mathematical object is representable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-23463")[#strong[#text("AMS lecture: Structure and randomness in the prime numbers « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2008")

#text("[…] I’ve talked about this general topic many times before, (e.g. at my Simons lecture at MIT, my Milliman lecture at U. Washington, and my Science Research Colloquium at UCLA), and I have given similar talks to the one here – […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-39102")[#strong[#text("Structure and Randomness: Pages from Year One of a Mathematical Blog « Abner’s Postgraduate Days")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2009")

#text("[…] Simons Lecture I: Structure and randomness in Fourier analysis and number theory For instance, from the Siegel-Walfisz theorem we know that the last digit of large prime numbers is uniformly distributed in the set {1,3,7,9}; thus, if N is a large integer, the number of primes less than N ending in (say) 3, divided by the total number of primes less than N, is known to converge to 1/4 in the limit as N goes to infinity. Fourier analysis is an essential feature of many of these problems from the perspective of the dichotomy between structure and randomness, and in particular viewing structure as an obstruction to computing statistics which needs to be understood before the statistic can be accurately computed. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-42721")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2009")

#text("Primes do have a distributive pattern althought very complex they")#linebreak()#text(" are associated with Mercenne triangle numbers and all 2^n and the")#linebreak()#text(" Fermat triangle numbers in a unique way as you will see below!")

#text("My studies of triangle number factoring where the addition and negation")#linebreak()#text(" of this series below produces no primes.")

#text("Except for the very beginning of this summation and negation there is an")#linebreak()#text(" actual pattern that can be observed disproving any sort of randomness")#linebreak()#text(" or psudo randomness to the primes.")

#text("9+3+2+1")#linebreak()#text(" +3+2")#linebreak()#text(" -2")#linebreak()#text(" +4+3+2")#linebreak()#text(" -6")#linebreak()#text(" +5+4+3+2")#linebreak()#text(" -11")#linebreak()#text(" +6+5+4+3+2")#linebreak()#text(" -17")#linebreak()#text(" +7+6+5+4+3+2")#linebreak()#text(" -24")#linebreak()#text(" +8+7+6+5+4+3+2")#linebreak()#text(" -32")#linebreak()#text(" +9+8+7+6+5+4+3+2")#linebreak()#text(" -41")#linebreak()#text(" +10+9+8+7+6+5+4+3+2")#linebreak()#text(" -51")#linebreak()#text(" +11+10+9+8+7+6+5+4+3+2")#linebreak()#text(" -62")#linebreak()#text(" …")#linebreak()#text(" You will note the negation is predicated on a natural progression")#linebreak()#text(" after each set of summations and negation of just (3) from the previous")#linebreak()#text(" set of summations and negation. After the negation the value will")#linebreak()#text(" allways be congruent to 0(mod 3).")

#text("This simple series does not produce any primes but does produce")#linebreak()#text(" all odd composites and even integers except for the special even")#linebreak()#text(" integers below.")

#text("A few even integer exceptions also are not produced such as —")#linebreak()#text(" Where n = 1,2,3,4..n then all 2^n are not produced.")#linebreak()#text(" Also all even Mercenne triangle numbers–")#linebreak()#text(" 6,28,496,8128.. are not produced. Also known as even perfect numbers.")

#text("Also not produced are all even Fermat triangle numbers of the form —")#linebreak()#text(" When n>1 then ((2^(2^n)) +1)= prime then —")#linebreak()#text(" when n = 2,4,8,16 then Fermat t(n) = (2^(n-1))*(2^n)+1) =")#linebreak()#text(" 10,136,32896,2147516416")

#text("There are other integers other than primes as I show above that are")#linebreak()#text(" not produced but they are all even or prime (2). So Just observing all")#linebreak()#text(" odd integer only odd composites are produced in the above sumations")#linebreak()#text(" and negations.")

#text("The primes shurely have a complex distribution but still a complex")#linebreak()#text(" ordered distribution by not appearing in the above summations and")#linebreak()#text(" negations.")

#text("Taking all integers that are not produced as being the primes and the special cases of the other even integers that also do not get produced")#linebreak()#text(" from this summation and negation sequence, is there a orderly reversal")#linebreak()#text(" of my sum and negation that will produce the primes and all the special")#linebreak()#text(" evens that are associated with the primes?")

#text("It would make the case for the not so complex distribution of the primes.")

#text("Dan")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-43636")[#strong[#text("Math/Stat")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2010")

#text("[…] (about string theory and enumerative geometry), the Szemeredi Festival (where we went through Terry Tao’s The Dichotomy between Structure and Randomness, Arithmetic Progression, and the Primes), […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-46774")[#strong[#text("Ana")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2010")

#text("As stated above: Primes are all adjacent to a multiple of six (with two exceptions). I found that one is for n=20. What is the other exception?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-46776")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2010")

#text("2 and 3 are the only primes that are not adjacent to a multiple of six. Note that the converse statement (all numbers adjacent to a multiple of six are prime) is certainly false, with 25 being the first counterexample.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-47897")[#strong[#text("Arnie Dris")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2010")

#text("Dear Professor Tao,")

#text("I have some number-theoretic investigations going on at ")#link("http://arnienumbers.blogspot.com")[#text("http://arnienumbers.blogspot.com")]#text(". (e.g. the last 3 blog posts)")

#text("Please do take a look when you get the time.")

#text("Cheers,")#linebreak()#text(" Arnie")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-49531")[#strong[#text("Hugh")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2011")

#text("My attempt at a twin prime proof, for anyone who is interested…")

#link("http://barkerhugh.blogspot.com/2011/01/twin-prime-proof-compressed-version.html")[#text("http://barkerhugh.blogspot.com/2011/01/twin-prime-proof-compressed-version.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-229614")[#strong[#text("E.L. Wisty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2013")

#text("Reblogged this on ")#link("http://jsandber.wordpress.com/2013/05/16/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/")[#text("Pink Iguana")]#text(" and commented:")#linebreak()#text(" Look up Simons lectures and David Donoho")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-230912")[#strong[#text("The Beauty of Bounded Gaps | sladisworld")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2013")

#text("[…] (A few suggestions for further reading for those with more technical tastes: Number theorist Emmanuel Kowalski offers a first report on Zhang’s paper. And here’s Terry Tao on the dichotomy between structure and randomness.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-241682")[#strong[#text("Transferrific Day | Mathematics & Statistics")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2013")

#text("[…] (about string theory and enumerative geometry), the Szemeredi Festival (where we went through Terry Tao’s The Dichotomy between Structure and Randomness, Arithmetic Progression, and the Primes), […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-428732")[#strong[#text("Fred")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2014")

#text("“For instance, from the Siegel-Walfisz theorem we know that the last digit of large prime numbers is uniformly distributed in the set {1,3,7,9};”")

#text("I do not think this holds.")

#text("We can define the set of 1’s as S1 = {1,11,21,31,…} and equal to some length (B).")#linebreak()#text(" The set of 3’s (S3), 7’s (S7) and 9’s (S9) are all equal to (B). Incidentally, B = 0.1N")

#text("We can define the set of prime 1’s as S1’ = {11, 31, 41,…} and equal to some length (a).")#linebreak()#text(" The set of prime 3’s (S3’), prime 7’s (S7) and prime 9’s (S9) are all equal to (a) according to this theorem.")

#text("We can further define the set of composite 1’s as S1c = {1,21,51,…} and equal to some length (c).")#linebreak()#text(" The set of 3’s (S3c), 7’s (S7c) and 9’s (S9c) are all equal to (c) if all primes (a) are equal.")

#text("The set of primes (a) is equal to the full set (B) – the composite set (c).")#linebreak()#text(" a =B – c")

#text("There are 3 ways to generate a composite 1, S1c:")#linebreak()#text(" (S1’ * S1’) which equals (a*a)")#linebreak()#text(" (S3’ * S7’) which equals (a*a)")#linebreak()#text(" (S9’ * S9’) which equals (a*a)")

#text("Yielding S1c = B – 3a^2")#linebreak()#text(" *The same holds for S9c such that S1c = S9c")

#text("However, there are only 2 ways to generate a composite 3, S3c:")#linebreak()#text(" (S3’ * S1’) which equals (a*a)")#linebreak()#text(" (S9’ * S7’) which equals (a*a)")

#text("Yielding S3c = B – 2a^2")#linebreak()#text(" *The same holds for S7c such that S3c = S7c")

#text("Thus S1c does not equal S3c whereby S1c > S3c")

#text("If all of the sets of composite numbers (c) are not equal, then all of the sets of prime numbers (a) are not equal.")

#text("There should be more primes ending in 3’s and 7’s due to the smaller number of composite matrices.")

#text("In fact, when I check up to N = 15,000,000 there are (excuse the R printout):")#linebreak()#text(" > sum(substrRight(Primes[Primes sum(substrRight(Primes[Primes sum(substrRight(Primes[Primes sum(substrRight(Primes[Primes<15000000],1)==9)")#linebreak()#text(" [1] 242574")

#text("This difference is quite small for small N, but should grow without bound as N goes to infinity reflecting the difference number of composite matrices for each set. Maybe…I think. Please feel free to point out any inconsistencies or thoughts as to why this would not hold.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-428742")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2014")

#text("There is a small (and rather interesting) bias of one digit over another at most scales, but the effect is asymptotically negligible when compared against the total number of primes ending in a given digit; see ")#link("http://www.dms.umontreal.ca/~andrew/PDF/PrimeRace.pdf")[#text("http://www.dms.umontreal.ca/~andrew/PDF/PrimeRace.pdf")]#text(" for more information. (The typical size of the bias does grow slowly in N, but nowhere near as fast as the total number of primes, so as long as one is only measuring things in a relative sense, as I am doing in this post, such biases are irrelevant.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-428749")[#strong[#text("Fred")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2014")

#text("Thanks for answering, I see the “asymptotically negligible” argument. But that does not explain the numerator in this relative measurement and it is similar to the fact that π(x)>x/ln(x) for all x e for for all x < ∞ and consequently why x/ln(x) underestimates π(x).")

#text("Solving for x=10,000 , π(10,000) = 10,000/Log_3.1017 (10,000) ……greater than e. Even at x=10^24, the optimum Log base for x/log_OptimumBase(x) is 2.76983, again greater than e. At some point it will get to e, but not for any x except for the one at ∞.")

#text("I have done some work on retrieving the implied log bases from various approximations of π(x) which can be read here:")

#text("I think by sweeping biases under the rug for asymptotic arguments (they are valid arguments at infinity, please don’t misinterpret as a slight against them) has further clouded our vision of an already murky landscape.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-453108")[#strong[#text("Fred")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2015")

#text("The known pairings to generate a composite or semiprime per this comment led to a trial multiplication method for factorization. I posted a preliminary algorithm and discussion here:")

#link("http://codereview.stackexchange.com/questions/83997/trial-multiplication-for-factorization")[#text("http://codereview.stackexchange.com/questions/83997/trial-multiplication-for-factorization")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-428733")[#strong[#text("Fred")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2014")

#text("The results did not display correctly in my post:")

#text("> sum(substrRight(Primes[Primes sum(substrRight(Primes[Primes sum(substrRight(Primes[Primes sum(substrRight(Primes[Primes<15000000],1)==9)")#linebreak()#text(" [1] 242574")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-474166")[#strong[#text("A huge discovery about prime numbers – Emmanuel A. Otchere's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2016")

#text("[…] (A few suggestions for further reading for those with more technical tastes: Number theorist Emmanuel Kowalski offers a first report on Zhang’s paper. And here’s Terry Tao on the dichotomy between structure and randomness.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-658128")[#strong[#text("SM")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2022")

#text("I thank you very much for this great lecture series. This topic is very fascinating.")

#text("You make a strong case for the possibility and relevance of decomposing a system into structured and random components. You mention that this happens in many “high-dimensional” situations. Seeing a great variety of situations where this applies fills me with joy but what are some neat examples to grasp the limitations of the leitmotiv when we get to “low-dimensional situations”?")

#text("Besides, I am interested in the precise choice of term “randomness”. From my very naive perspective and my main focus on measure-preserving actions of Z on a probability space, it seems that “random” is a perfect word for the layman and intuition but maybe a bit too wide in the technical sense (whenever we have a probability space, we have random variables, even if they exhibit arithmetic regularities). “Mixing” would seem to me technically satisfying but maybe too technical for the layman. Then, I thought maybe “disorder” could satisfy both the layman and the technically-inclined reader (or “chaos”?). I do not have a proper question to ask regarding this choice of word but in case you have a comment to make as a reaction to what I have just written, I will read it gladly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-658142")[#strong[#text("SM")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2022")

#text("I guess my question about “high-dimension” is most probably silly. For the order/disorder question to make sense, our object must be made of “constituents”, the arrangement of which is studied. For the question to really make sense and for the dichotomy to hold, it is quite clear that we need a large number of “constituents”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/#comment-693424")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2026")

#text("This idea is really fascinating and powerful. Since you have a background in signal processing and compressed sensing, I’m thinking that perhaps signal and noise could also correspond to structure and randomness? Could you provide some concrete examples?")
]
