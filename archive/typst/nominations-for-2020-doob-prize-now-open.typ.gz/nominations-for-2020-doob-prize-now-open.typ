// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/04/12/nominations-for-2020-doob-prize-now-open/
// Converted to Typst by tao2typ: "2026-10-14T15:20:15.775284+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Nominations for 2020 Doob Prize now open", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Nominations for 2020 Doob Prize now open")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 April 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/04/12/nominations-for-2020-doob-prize-now-open/")[#text("https://terrytao.wordpress.com/2019/04/12/nominations-for-2020-doob-prize-now-open/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Just a brief announcement that the AMS is now accepting (until June 30) nominations for the 2020 ")#link("http://www.ams.org/prizes-awards/paview.cgi?parent_id=21")[#text("Joseph L. Doob Prize")]#text(", which recognizes a single, relatively recent, outstanding research book that makes a seminal contribution to the research literature, reflects the highest standards of research exposition, and promises to have a deep and long-term impact in its area. The book must have been published within the six calendar years preceding the year in which it is nominated. Books may be nominated by members of the Society, by members of the selection committee, by members of AMS editorial committees, or by publishers. (I am ")#link("http://www.ams.org/about-us/governance/committees/doob-past.html")[#text("currently on the committee for this prize")]#text(".) A list of previous winners ")#link("http://www.ams.org/prizes-awards/pabrowse.cgi?parent_id=21")[#text("may be found here")]#text(". The nomination procedure may be found at the bottom of ")#link("http://www.ams.org/prizes-awards/paview.cgi?parent_id=21")[#text("this page")]#text(".")

#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2019/04/12/nominations-for-2020-doob-prize-now-open/#comment-514866")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2019")])]

#text("Do they accept self-published books? If yes, I want the prize.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2019/04/12/nominations-for-2020-doob-prize-now-open/#comment-514882")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2019")])]

#text("Nobody replied, so I assume it means my book may be considered for the competition. Please read it and nominate. My book is easy to read for every mathematician. Such discoveries are done just a few times in tens years. Read online ")#link("http://www.mathematics21.org/algebraic-general-topology.html")[#text("http://www.mathematics21.org/algebraic-general-topology.html")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2019/04/12/nominations-for-2020-doob-prize-now-open/#comment-514917")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2019")])]

#text("If anyone decides to nominate me, I propose you to include like the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The book was self-published, but the only reason why it was not a thesis published e.g. by an University press was severe discrimination of the author. So, as your rules don’t explicitly forbid nominating self-published books, I am sending it to be considered.")

#text("The book despite of being self-published is quality, except that formatting of some math formulas is not enough good. Bad formatting of some formulas in no way should be reason for not awarding.")

#text("The exact date of publication is questionable because the book had really many editions and is available in a public version control repository. The last change was 7 Feb 2019. Many changes are planned (for example solutions of yet open problems to be added), but the book is finished.")
]

#text("You can contact me (porton@narod.ru) for more information and for possible quotes on how to describe my book. One additional quote:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Several mathematicians refused to believe me when I told them that there was discovered algebraic general topology. General topology cannot be algebraic, they said.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed9945458be687811f4558b42acdd57084d85d5e5bc833803c3f31216f130574-1b396572c4c94bb5444694ebe5430ecdbcfc43bb7081940b8f2e9ec101d7f17b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kociątko Miauczenieński")]], [#link("https://terrytao.wordpress.com/2019/04/12/nominations-for-2020-doob-prize-now-open/#comment-514892")[#strong[#text("Kociątko Miauczenieński")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2019")])]

#text("I would like to nominate my own book “Quantum Ergodicity, Approximate Cohomology and Their Number-Theoretic Applications: A Homotopical Perspective” to appear in the Annals of Mathematics Studies (available for free on my website) in which I detail in a self-contained way the foundations of (quantum) ergodicity and its links to the equidistribution of the primes (as developed in the seminal works of Venkatesh et al.) as well as more recent work related to approximate cohomology by Kazdhan and his collaborators. The novel component of my book is the use of homotopy theory to control nonlinearities outside the grasp of the usual (co)homological machinery rather than the old-fashioned analytic machinery that obscures the deeper algebro-topological structure of additive-combinatorial and related number-theoretic problems once we look at their categorifications and can derive painlessly many of the quantitative results present in the literature.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/12/nominations-for-2020-doob-prize-now-open/#comment-515001")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2019")])]

#text("April Fools’ Day was a while ago…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ecc079a057986bc366cdca94aa507d914293d0ec2957a32130e101cb49ed4e19-357b49664e3d95c9e692583407b78ea01c6a21004c6ca7469a50fbb0235e7532.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Please nominate me for Doob Prize in matheamatics | Victor Porton's Math Blog")]], [#link("https://terrytao.wordpress.com/2019/04/12/nominations-for-2020-doob-prize-now-open/#comment-514918")[#strong[#text("Please nominate me for Doob Prize in matheamatics | Victor Porton's Math Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2019")])]

#text("[…] be easily read by every mathematician) for Doob Prize. All necessary information can be found at this page at Terry Tao’s blog and subcomments. And yes, my book is worth […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/12/nominations-for-2020-doob-prize-now-open/#comment-514929")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2019")])]

#text("I was going to ask commenters here if they had any particularly notable books to recommend. I’m not looking to make any nominations but am just wondering what the current universe of potential candidates for this prize might look like. But, the self-nominations may have pre-empted that question.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/12/nominations-for-2020-doob-prize-now-open/#comment-514957")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2019")])]

#text("Take a look at the monographs in the series where previous winners have appeared (Grundlehren der mathematischen Wissenschaften, AMS Colloquium Publications) or other series dedicated to high-quality mathematical research books (AMS Mathematical Surveys and Monographs, Cambridge New Mathematical Monographs etc.). Some of the more advanced texts in “Cambridge Studies in Advanced Mathematics,” AMS “University Lecture Series,” and Springer “Graduate Texts in Mathematics” sit between what one would call a textbook versus a research monograph and are possibly within the scope of this award as well. But very few of these texts exhibit both the remarkable contribution to the research literature in distilling an active research into the form of an accessible book form and the masterful exposition of previous winners.")

#text("If I had to choose some of my recent favorites, then they would be quite biased toward my own research interests. The committee for this award (like most others) comprises mathematicians of disparate backgrounds to reduce these sorts of person biases, so I will abstain from any particular recommendations.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/12/nominations-for-2020-doob-prize-now-open/#comment-515017")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2019")])]

#text("Thanks. I looked at some of the previous years’ winners and that gave me a decent picture.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/12/nominations-for-2020-doob-prize-now-open/#comment-515002")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2019")])]

#text("High-dimensional probability by Vershynin")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/12/nominations-for-2020-doob-prize-now-open/#comment-515009")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2019")])]

#text("That looks like a good book but not a research monograph. It’s about known results. The final draft is on the author’s site if anyone wants a download:")

#link("https://www.math.uci.edu/~rvershyn/papers/HDP-book/HDP-book.pdf")[#text("Click to access HDP-book.pdf")]

#text("You might also like Hopcroft et al’s book-in-progress:")

#link("https://www.cs.cornell.edu/jeh/book.pdf")[#text("Click to access book.pdf")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2019/04/12/nominations-for-2020-doob-prize-now-open/#comment-515128")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2019")])]

#text("Is it much easier to get Doob prize that say Nobel prize, Fields medal, Abel prize?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20791c979dd38d1d9e56a114259a0451e2a85ab73ae6826baa8cac3a31f7f341-f8d8a0e405496e47b1bc849f1b27e72d61f7b7b8d4dfef591d1efdd94d4359ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/12/nominations-for-2020-doob-prize-now-open/#comment-515190")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2019")])]

#text("It is “easier” in some abstract sense, but you’re in no danger of getting any of these kinds of prizes. People seem reluctant to say it, so I will: you’re making a fool of yourself. I have not studied your work, but major mathematical prizes are given only to people where there is a broad consensus in the mathematical community that the work is outstanding. You seem to be hoping that you can get such a prize and as a consequence have your work recognized, but this is very much putting the cart before the horse.")

#text("I suggest working on publishing your results in mathematical journals. If it is genuinely important, then this is the first step in getting people to notice it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cd6e5aad292560f64aa9b45f206b0b28bb1653f6fa014816cacacbed78552fc-c80b60e7a5c2a123c91bafc7bcbdd6449b4a89fd888c4af3c56d500dd860cd71.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of test")]], [#link("https://terrytao.wordpress.com/2019/04/12/nominations-for-2020-doob-prize-now-open/#comment-515223")[#strong[#text("test")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2019")])]

#text("I nominate the book Geometric Geometry.")
]
