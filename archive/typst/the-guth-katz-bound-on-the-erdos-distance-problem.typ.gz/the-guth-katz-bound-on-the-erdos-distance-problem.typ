// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/
// Converted to Typst by tao2typ: "2026-10-14T15:17:57.335320+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Guth-Katz bound on the Erdős distance problem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Guth-Katz bound on the Erdős distance problem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 November 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/")[#text("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://en.wikipedia.org/wiki/Combinatorial_geometry")[#text("Combinatorial incidence geometry")]#text(" is the study of the possible combinatorial configurations between geometric objects such as lines and circles. One of the basic open problems in the subject has been the ")#link("http://www.cs.umd.edu/~gasarch/erdos_dist/erdos_dist.html")[#text("Erdős distance problem")]#text(", posed in 1946:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 1 (Erdős distance problem)")]#text(" Let ")#mi("{N}")#text(" be a large natural number. What is the least number ")#tao-math("{\\# \\{ \\left|x_i-x_j\\right|: 1 \\leq i < j \\leq N \\}}", block: false)#text(" of distances that are determined by ")#mi("{N}")#text(" points ")#mi("{x_1,\\ldots,x_N}")#text(" in the plane?")
]

#text("Erdős called this least number ")#mi("{g(N)}")#text(". For instance, one can check that ")#mi("{g(3)=1}")#text(" and ")#mi("{g(4)=2}")#text(", although the precise computation of ")#mi("{g}")#text(" rapidly becomes more difficult after this. By considering ")#mi("{N}")#text(" points in arithmetic progression, we see that ")#mi("{g(N) \\leq N-1}")#text(". By considering the slightly more sophisticated example of a ")#mi("{\\sqrt{N} \\times \\sqrt{N}}")#text(" lattice grid (assuming that ")#mi("{N}")#text(" is a square number for simplicity), and using some analytic number theory, one can obtain the slightly better asymptotic bound ")#mi("{g(N) = O( N / \\sqrt{\\log N} )}")#text(".")

#text("On the other hand, lower bounds are more difficult to obtain. As observed by Erdős, an easy argument, ultimately based on the incidence geometry fact that any two circles intersect in at most two points, gives the lower bound ")#mi("{g(N) \\gg N^{1/2}}")#text(". The exponent ")#mi("{1/2}")#text(" has been slowly increasing over the years by a series of increasingly intricate arguments combining incidence geometry facts with other known results in combinatorial incidence geometry (most notably the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di%E2%80%93Trotter_theorem")[#text("Szemerédi-Trotter theorem")]#text(") and also some tools from additive combinatorics; however, these methods seemed to fall quite short of getting to the optimal exponent of ")#mi("{1}")#text(". (Indeed, previously to last week, the best lower bound known was approximately ")#mi("{N^{0.8641}}")#text(", due to ")#link("http://www.ams.org/mathscinet-getitem?mr=2065258")[#text("Katz and Tardos")]#text(".)")

#text("Very recently, though, ")#link("http://arxiv.org/abs/1011.4105")[#text("Guth and Katz")]#text(" have obtained a near-optimal result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" ")#metadata(none) <tao-b6a5db8c56444d8bc30b>#text(" One has ")#mi("{g(N) \\gg N / \\log N}")#text(".")
]

#text("The proof neatly combines together several powerful and modern tools in a new way: a recent geometric reformulation of the problem ")#link("http://arxiv.org/abs/1005.0982")[#text("due to Elekes and Sharir")]#text("; the polynomial method as used recently by Dvir, Guth, and Guth-Katz on related incidence geometry problems (and ")#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/")[#text("discussed previously on this blog")]#text("); and the somewhat older method of cell decomposition (also ")#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/")[#text("discussed on this blog")]#text("). A key new insight is that the polynomial method (and more specifically, the ")#emph[#text("polynomial Ham Sandwich theorem")]#text(", ")#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/")[#text("also discussed previously on this blog")]#text(") can be used to efficiently create cells.")

#text("In this post, I thought I would sketch some of the key ideas used in the proof, though I will not give the full argument here (the paper itself is largely self-contained, well motivated, and of only moderate length). In particular I will not go through all the various cases of configuration types that one has to deal with in the full argument, but only some illustrative special cases.")

#text("To simplify the exposition, I will repeatedly rely on “pigeonholing cheats”. A typical such cheat: if I have ")#mi("{n}")#text(" objects (e.g. ")#mi("{n}")#text(" points or ")#mi("{n}")#text(" lines), each of which could be of one of two types, I will assume that either all ")#mi("{n}")#text(" of the objects are of the first type, or all ")#mi("{n}")#text(" of the objects are of the second type. (In truth, I can only assume that at least ")#mi("{n/2}")#text(" of the objects are of the first type, or at least ")#mi("{n/2}")#text(" of the objects are of the second type; but in practice, having ")#mi("{n/2}")#text(" instead of ")#mi("{n}")#text(" only ends up costing an unimportant multiplicative constant in the type of estimates used here.) A related such cheat: if one has ")#mi("{n}")#text(" objects ")#mi("{A_1,\\ldots,A_n}")#text(" (again, think of ")#mi("{n}")#text(" points or ")#mi("{n}")#text(" circles), and to each object ")#mi("{A_i}")#text(" one can associate some natural number ")#mi("{k_i}")#text(" (e.g. some sort of “multiplicity” for ")#mi("{A_i}")#text(") that is of “polynomial size” (of size ")#mi("{O(N^{O(1)})}")#text("), then I will assume in fact that all the ")#mi("{k_i}")#text(" are in a fixed dyadic range ")#mi("{[k,2k]}")#text(" for some ")#mi("{k}")#text(". (In practice, the dyadic pigeonhole principle can only achieve this after throwing away all but about ")#mi("{n/\\log N}")#text(" of the original ")#mi("{n}")#text(" objects; it is this type of logarithmic loss that eventually leads to the logarithmic factor in the main theorem.) Using the notation ")#mi("{X \\sim Y}")#text(" to denote the assertion that ")#mi("{C^{-1} Y \\leq X \\leq CY}")#text(" for an absolute constant ")#mi("{C}")#text(", we thus have ")#mi("{k_i \\sim k}")#text(" for all ")#mi("{i}")#text(", thus ")#mi("{k_i}")#text(" is morally constant.")

#text("I will also use asymptotic notation rather loosely, to avoid cluttering the exposition with a certain amount of routine but tedious bookkeeping of constants. In particular, I will use the informal notation ")#mi("{X \\lll Y}")#text(" or ")#mi("{Y \\ggg X}")#text(" to denote the statement that ")#mi("{X}")#text(" is “much less than” ")#mi("{Y}")#text(" or ")#mi("{Y}")#text(" is “much larger than” ")#mi("{X}")#text(", by some large constant factor.")

#text("See also ")#link("http://gilkalai.wordpress.com/2010/11/20/janos-pach-guth-and-katzs-solution-of-erdos-distinct-distances-problem/")[#text("Janos Pach’s recent reaction to the Guth-Katz paper on Kalai’s blog.")]

#metadata(none) <tao-952d5e99de1b28a670aa>

#heading(level: 1)[#strong[#text(" — 1. Reduction to a linear problem — ")]]

#text("Traditionally, the Erdős distance problem has been attacked by first casting it as a question about incidences between circles, by starting with the trivial observation that if two points ")#mi("{x_i,x_j}")#text(" are equidistant from a third point ")#mi("{x_k}")#text(", then ")#mi("{x_i, x_j}")#text(" lie on a circle centred at ")#mi("{x_k}")#text(".")

#text("The incidence geometry of circles, however, is not quite as well understood as the incidence geometry of lines, and so one often then converted the circle incidence problem to a line incidence problem, for instance by using the elementary Euclidean geometry fact that if two circles intersected at a pair of points, then the centres of these circles would lie on the perpendicular bisector of that pair of points. Indeed, by combining this elementary observation with the celebrated ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di%E2%80%93Trotter_theorem")[#text("Szemerédi-Trotter theorem")]#text(" that gives a sharp incidence bound for a collection of lines and points, ")#link("http://www.ams.org/mathscinet-getitem?mr=1134448")[#text("Chung, Szemerédi, and Trotter")]#text(" were already able to obtain the respectable lower bound of ")#mi("{g(N) \\gg N^{4/5-o(1)}}")#text(".")

#text("The first innovation of Guth and Katz (which builds upon earlier work in this direction by ")#link("http://arxiv.org/abs/1005.0982")[#text("Elekes and Sharir")]#text(") is to use elementary Euclidean geometry to recast the distance problem as a linear problem in a slightly different fashion, namely as an incidence problem of lines in ")#emph[#text("three dimensions")]#text(" ")#mi("{{\\bf R}^3}")#text(" rather than two.")

#text("Let’s see how this works. To prove the main theorem, we will argue by contradiction, assuming that ")#mi("{g(N) \\lll N/\\log N}")#text(" for some large ")#mi("{N}")#text(". Thus, we can find ")#mi("{N}")#text(" points ")#mi("{x_1,\\ldots,x_N}")#text(" in the plane which only subtend ")#mi("{g(N) \\lll N/\\log N}")#text(" distances. We think of these distances as the lengths of line segments ")#mi("{\\overline{x_i x_j}}")#text(" connecting two of the points ")#mi("{x_i, x_j}")#text(". There are ")#mi("{\\binom{N}{2} \\sim N^2}")#text(" different line segments ")#mi("{\\overline{x_i x_j}}")#text(" that have these lengths. A standard application of the Cauchy-Schwarz inequality then shows that there must be many pairs of distinct but congruent line segments ")#mi("{\\overline{x_i x_j}}")#text(", ")#mi("{\\overline{x_k x_l}}")#text(" (i.e. line segments of equal length ")#tao-math("{\\left|x_i-x_j\\right| = \\left|x_k-x_l\\right|}", block: false)#text("); in fact, their number must be")

#align(center)[#tao-fit-display[#mitex("\\frac{\\binom{N}{2}^2}{g(N)} - \\binom{N}{2} \\ggg N^3 \\log N.")]]

#text("So, we have a lot (")#mi("{\\ggg N^3 \\log N}")#text(") of pairs ")#mi("{\\overline{x_i x_j}, \\overline{x_k x_l}}")#text(" of congruent line segments. Now we use a trivial but fundamentally important observation of Elekes and Sharir to recast the problem in terms of rigid motions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3")]#text(" Two line segments ")#mi("{\\overline{AB}, \\overline{CD}}")#text(" in the plane are congruent if and only if there is an orientation-preserving ")#link("http://en.wikipedia.org/wiki/Euclidean_group")[#text("rigid motion")]#text(" that maps ")#mi("{A}")#text(" to ")#mi("{C}")#text(" and ")#mi("{B}")#text(" to ")#mi("{D}")#text(". Furthermore, this rigid motion is unique.")
]

#emph[#text("Proof:")]#text(" Translate ")#mi("{A}")#text(" to ")#mi("{C}")#text(" and then rotate appropriately. ")#mi("\\Box")

#text("Let us call the space of orientation-preserving rigid motions ")#mi("{SE(2) \\equiv SO(2) \\ltimes {\\bf R}^2}")#text(" (the two-dimensional special Euclidean group); it is a three-dimensional Lie group. From the above proposition we thus see that we can find ")#mi("{\\ggg N^3\\log N}")#text(" quintuples ")#mi("{(x_i, x_j, x_k, x_l, R)}")#text(", where ")#mi("{R \\in SE(2)}")#text(" is such that ")#mi("{R(x_i) = R(x_k)}")#text(" and ")#mi("{R(x_j) = R(x_l)}")#text(".")

#text("We now dualise the problem; rather than think about rigid motions acting on pairs of points, we think about pairs of points describing a set of rigid motions. For any pair of points ")#mi("{x, y}")#text(", let ")#mi("{\\ell_{x \\rightarrow y} \\subset SE(2)}")#text(" of all rigid motions that map ")#mi("{x}")#text(" to ")#mi("{y}")#text(". This is a one-dimensional subset of ")#mi("{SE(2)}")#text("; indeed, ")#mi("{\\ell_{x \\rightarrow y}}")#text(" consists of the translation from ")#mi("{x}")#text(" to ")#mi("{y}")#text(", together with rotations around an origin ")#mi("{p}")#text(" that lies on the perpendicular bisector of ")#mi("{\\overline{xy}}")#text(", with a rotation angle ")#mi("{\\theta}")#text(" obeying the relation")

#align(center)[#tao-fit-display[#tao-math("\\left|\\cot \\frac{\\theta}{2}\\right| = \\frac{\\left|\\overline{pm}\\right|}{\\left|\\overline{mx}\\right|}", block: true)]]

#text("where ")#mi("{m := \\frac{x+y}{2}}")#text(" is the midpoint of ")#mi("{x}")#text(" and ")#mi("{y}")#text(". If we discard the translation (which can easily be dealt with by a separate argument) as well as the point reflection (corresponding to the case ")#mi("{p=m, \\theta=\\pi}")#text("), and focus only on the rotations by angles less than ")#mi("{\\pi}")#text(", we in fact see that the origin ")#mi("{p}")#text(" of the rotation depends in a linear fashion on the quantity ")#mi("{\\cot \\frac{\\theta}{2}}")#text(". Thus, if we parameterise (most of) ")#mi("{SE(2)}")#text(" by the coordinates ")#mi("{(p, \\cot \\frac{\\theta}{2}) \\in {\\bf R}^3}")#text(", we thus see that we can view each ")#mi("{\\ell_{x \\rightarrow y}}")#text(" as a line in ")#mi("{{\\bf R}^3}")#text(", and we will adopt this perspective for the rest of this post.")

#text("[I do not know if there is any higher explanation (coming, say, from Lie group theory) as to why the set of rigid motions from ")#mi("{x}")#text(" to ")#mi("{y}")#text(" in ")#mi("{{\\bf R}^2}")#text(" happens to form a line in ")#mi("{{\\bf R}^3}")#text(" when viewed in the appropriate coordinate system. Perhaps this is just a miraculous coincidence arising from the low-dimensional (and low-degree) nature of the problem.]")

#text("Let ")#mi("{{\\mathcal L}}")#text(" be the collection of all the lines ")#mi("{\\ell_{x_i \\rightarrow x_k} \\subset {\\bf R}^3}")#text(" generated by pairs of points ")#mi("{x_i, x_k}")#text(" from our collection, thus there are ")#mi("{\\sim N^2}")#text(" such lines. (It is easy to see that different pairs of points ")#mi("{(x_i,x_k)}")#text(" lead to different lines.) The ")#mi("{\\ggg N^3 \\log N}")#text(" quintuples ")#mi("{(x_i, x_j, x_k, x_l, R)}")#text(" described earlier give rise to ")#mi("{\\ggg N^3 \\log N}")#text(" intersecting pairs ")#mi("{\\ell, \\ell^{\\prime} \\in {\\mathcal L}}")#text(" of lines in ")#mi("{{\\mathcal L}}")#text(". So the question now comes down to a simple question about incidences of lines: is it possible for ")#mi("{\\sim N^2}")#text(" lines in three-dimensional space ")#mi("{{\\bf R}^3}")#text(" to generate ")#mi("{\\ggg N^3 \\log N}")#text(" pairs ")#mi("{\\ell, \\ell^{\\prime}}")#text(" of intersecting lines? If the answer to this question is “no”, then we are done.")

#text("Unfortunately, the answer to the question is “yes”. One quickly comes up with two basic counterexamples to that question:")

#enum(start: 1, 
[#text("(Concurrency) If one has ")#mi("{\\sim N^2}")#text(" lines that all go through the same point ")#mi("{p}")#text(", then we will have ")#mi("{\\sim N^4}")#text(" pairs of intersecting lines.")],
[#text("(Coplanarity) If one has ")#mi("{\\sim N^2}")#text(" lines that all lie in the same plane ")#mi("{\\pi}")#text(", with no two lines being parallel, then we will have ")#mi("{\\sim N^4}")#text(" pairs of intersecting lines.")]
)

#text("Slightly less obviously, there is a third counterexample that comes from a ")#emph[#text("regulus")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Hyperbolic_paraboloid")[#text("hyperbolic paraboloid")]#text(") – a doubly ")#link("http://en.wikipedia.org/wiki/Ruled_surface")[#text("ruled surface")]#text(" in ")#mi("{{\\bf R}^3}")#text(". A typical example of a regulus is the set ")#mi("{\\{ (x,y,z) \\in {\\bf R}^3: z = xy \\}}")#text(". On the one hand, this surface is ruled by the lines ")#mi("{\\{ (x,y,xy): y \\in {\\bf R} \\}}")#text(" for ")#mi("{x \\in {\\bf R}}")#text("; on the other hand, it is also ruled by the lines ")#mi("{\\{ (x,y,xy): x \\in {\\bf R} \\}}")#text(" for ")#mi("{y \\in {\\bf R}}")#text(". If we then pick ")#mi("{\\sim N^2}")#text(" lines from the first family of lines and ")#mi("{\\sim N^2}")#text(" from the second family, then we obtain another family of ")#mi("{\\sim N^2}")#text(" lines that lead to ")#mi("{\\sim N^4}")#text(" pairs of intersecting lines.")

#text("However, all is not lost here, because we are not dealing with an ")#emph[#text("arbitrary")]#text(" family ")#mi("{{\\mathcal L}}")#text(" of ")#mi("{\\sim N^2}")#text(" lines in ")#mi("{{\\bf R}^3}")#text(", but rather with a ")#emph[#text("special")]#text(" family that was generated ultimately by ")#mi("{N}")#text(" points ")#mi("{x_1,\\ldots,x_N}")#text(" in ")#mi("{{\\bf R}^2}")#text(". As such, the special structure of this family can be used to rule out the concurrency, coplanarity, and regulus counterexmaples. Indeed, observe that if a rigid motion ")#mi("{R}")#text(" maps ")#mi("{x_i}")#text(" to ")#mi("{x_j}")#text(", then it cannot also map ")#mi("{x_i}")#text(" to ")#mi("{x_k}")#text(" for some ")#mi("{k \\neq j}")#text(". This implies that ")#mi("{\\ell_{x_i \\rightarrow x_j}}")#text(" and ")#mi("{\\ell_{x_i \\rightarrow x_k}}")#text(" cannot intersect. This limits the amount of concurrency in ")#mi("{{\\mathcal L}}")#text("; letting ")#mi("{i}")#text(" run from ")#mi("{1}")#text(" to ")#mi("{N}")#text(", we indeed conclude that at most ")#mi("{N}")#text(" lines in ")#mi("{{\\mathcal L}}")#text(" can meet at a point, which eliminates the concurrency counterexample. (Now, the best one can do is get ")#mi("{\\sim N}")#text(" groups of ")#mi("{N}")#text(" concurrent lines, but this only yields ")#mi("{\\sim N^3}")#text(" pairs of intersecting lines, which is acceptable.)")

#text("In a similar spirit, observe that for a given plane ")#mi("{\\pi}")#text(", the requirement that a line in ")#mi("{{\\bf R}^3}")#text(" lie in that plane is a codimension two constraint on that line (the space of lines in a plane is two-dimensional, while the space of lines in ")#mi("{{\\bf R}^3}")#text(" is four-dimensional). Thus, for fixed ")#mi("{x_i}")#text(", the requirement that ")#mi("{\\ell_{x_i \\rightarrow x_j}}")#text(" lie in ")#mi("{\\pi}")#text(" is a codimension two constraint on ")#mi("{x_j}")#text(", and thus by ")#link("http://en.wikipedia.org/wiki/Bezout's_theorem")[#text("Bezout’s theorem")]#text(", it should only be satisfiable by ")#mi("{O(1)}")#text(" values of ")#mi("{x_j}")#text(". (One has to check that the constraints are non-degenerate, but this is routine; actually, in this particular case one can also argue directly using elementary Euclidean geometry.) Letting ")#mi("{i}")#text(" run from ")#mi("{1}")#text(" to ")#mi("{N}")#text(", we conclude that any plane ")#mi("{\\pi}")#text(" can contain at most ")#mi("{O(N)}")#text(" lines from ")#mi("{{\\mathcal L}}")#text(", thus neutralising the coplanarity counterexample. The same argument also shows that any regulus also can contain at most ")#mi("{O(N)}")#text(" lines from ")#mi("{{\\mathcal L}}")#text(" (because a regulus is an algebraic surface of degree ")#mi("{2}")#text(", and so the Bezout argument still applies).")

#text("Now, it turns out that the elimination of the concurrency, coplanarity, and regulus obstructions allows us to now give the right answer to the previous question. Indeed, Guth and Katz show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4")]#text(" ")#metadata(none) <tao-02d5c5673dec22342c64>#text(" Let ")#mi("{{\\mathcal L}}")#text(" be a collection of ")#mi("{\\sim N^2}")#text(" lines in ")#mi("{{\\bf R}^3}")#text(", such that at most ")#mi("{N}")#text(" lines in ")#mi("{{\\mathcal L}}")#text(" meet at a point, and such that any plane or regulus contains at most ")#mi("{O(N)}")#text(" lines in ")#mi("{{\\mathcal L}}")#text(". Then there are at most ")#mi("{O(N^3 \\log N)}")#text(" pairs ")#mi("{\\ell, \\ell^{\\prime} \\in {\\mathcal L}}")#text(" of intersecting lines in ")#mi("{{\\mathcal L}}")#text(".")
]

#text("The above discussion has shown (modulo a few details) that Theorem ")#link(<tao-02d5c5673dec22342c64>)[#text("4")]#text(" implies Theorem ")#link(<tao-b6a5db8c56444d8bc30b>)[#text("2")]#text(", so it suffices now to show Theorem ")#link(<tao-02d5c5673dec22342c64>)[#text("4")]#text(". This is a significant simplification, because it is an assertion about incidences of lines, rather than congruence of line segments or incidences of circles, and we know a lot more about how configurations of lines intersect than we do about configurations of circles or of congruences of line segments.")

#text("Of course, it remains to prove Theorem ")#link(<tao-02d5c5673dec22342c64>)[#text("4")]#text(". It is convenient to pigeonhole based on the concurrency of the lines in ")#mi("{{\\mathcal L}}")#text(". Let ")#mi("{k \\geq 2}")#text(", and suppose that has a set of points ")#mi("{S}")#text(", such that for each point ")#mi("{p}")#text(" in ")#mi("{S}")#text(" there are at least ")#mi("{k}")#text(" lines in ")#mi("{{\\mathcal L}}")#text(" passing through ")#mi("{p}")#text(". From the concurrency bound we know that ")#mi("{k \\leq N}")#text(". Then each point in ")#mi("{p}")#text(" contributes ")#mi("{\\sim k^2}")#text(" pairs of intersecting lines, so we need to show that ")#mi("{P}")#text(" does not get much larger than ")#mi("{N^3/k^2}")#text(". And indeed this is the case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5")]#text(" ")#metadata(none) <tao-f616a5464694c0f6ff5c>#text(" Let ")#mi("{{\\mathcal L}}")#text(" be a collection of ")#mi("{\\sim N^2}")#text(" lines in ")#mi("{{\\bf R}^3}")#text(", such that any plane or regulus contains at most ")#mi("{O(N)}")#text(" lines in ")#mi("{{\\mathcal L}}")#text(". Let ")#mi("{2 \\leq k \\leq N}")#text(", and let ")#mi("{S}")#text(" be a set of points, each of which has at least ")#mi("{k}")#text(" lines in ")#mi("{{\\mathcal L}}")#text(" passing through it. Then ")#tao-math("{\\left|S\\right| \\ll N^3/k^2}", block: false)#text(".")
]

#text("A simple dyadic summation argument allows one to deduce Theorem ")#link(<tao-02d5c5673dec22342c64>)[#text("4")]#text(" from Theorem ")#link(<tao-f616a5464694c0f6ff5c>)[#text("5")]#text(". (Note that the case ")#mi("{k=1}")#text(" is not relevant, as such points do not contribute any pairs of intersecting lines.) The hypothesis that each plane or regulus contains at most ")#mi("{O(N)}")#text(" lines, incidentally, is very reminiscent of the ")#emph[#text("Wolff axiom")]#text(" in the work on the Kakeya conjecture.")

#text("It is worth noting that the bound in Theorem ")#link(<tao-f616a5464694c0f6ff5c>)[#text("5")]#text(" is completely sharp. Indeed, consider two parallel grids")

#align(center)[#tao-fit-display[#mitex("\\{ (i,j,0) \\in {\\bf Z}^2 \\times \\{0\\}: 1 \\leq i,j \\leq \\sqrt{N} \\}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\{ (i,j,1) \\in {\\bf Z}^2 \\times \\{0\\}: 1 \\leq i,j \\leq \\sqrt{N} \\}")]]

#text("and let ")#mi("{{\\mathcal L}}")#text(" be the set of lines connecting a point in the first grid to a point in the second grid. Then one can verify that ")#mi("{{\\mathcal L}}")#text(" obeys the required hypotheses for Theorem ")#link(<tao-f616a5464694c0f6ff5c>)[#text("5")]#text(", and a number-theoretic calculation shows that for any ")#mi("{2 \\leq k \\ll N}")#text(", the number of points in ")#mi("{{\\bf R}^3}")#text(" that are incident to at least ")#mi("{k}")#text(" lines in ")#mi("{{\\mathcal L}}")#text(" is ")#mi("{\\sim N^3/k^2}")#text(". (To see this, first look at the cases ")#mi("{k=2}")#text(" and ")#mi("{k \\sim N^2}")#text(", and then interpolate the arguments; details are given in the Guth-Katz paper.)")

#text("It is also worth noting that if one replaces the real line ")#mi("{{\\bf R}}")#text(" by a finite field ")#mi("{{\\bf F}_q}")#text(", then the claim fails for large ")#mi("{k}")#text(". Indeed, if one sets ")#mi("{N = q^2}")#text(" and ")#mi("{{\\mathcal L}}")#text(" to be the set of ")#emph[#text("all")]#text(" lines in ")#mi("{{\\bf F}_q^3}")#text(", then the hypotheses of Theorem ")#link(<tao-f616a5464694c0f6ff5c>)[#text("5")]#text(" hold, but each of the ")#mi("{q^3}")#text(" points in ")#mi("{{\\bf F}_q^3}")#text(" is incident to ")#mi("{\\sim q^2}")#text(" lines in ")#mi("{{\\mathcal L}}")#text(", which soon leads to a significant violation of the conclusion of that theorem. Thus, any proof of Theorem ")#link(<tao-f616a5464694c0f6ff5c>)[#text("5")]#text(" in the large ")#mi("{k}")#text(" case cannot be purely algebraic in nature must somehow use a property of the real line that is not shared by finite fields. This property will be the ")#emph[#text("ordered")]#text(" nature of the real line, which manifests itself in the Szemerédi-Trotter theorem and in the ham sandwich theorem, both of which are used in the proof. However, this example does not prevent the small ")#mi("{k}")#text(" case from being purely algebraic.")

#text("So, the only thing left to do is to prove Theorem ")#link(<tao-f616a5464694c0f6ff5c>)[#text("5")]#text(". It turns out that the multiplicity ")#mi("{2}")#text(" case ")#mi("{k=2}")#text(" and the higher multiplicity case ")#mi("{k > 2}")#text(" have to be treated separately, basically because ")#mi("{k}")#text(" concurrent lines will be trapped in a plane when ")#mi("{k=2}")#text(", but will usually not be so trapped when ")#mi("{k>2}")#text(". Also, note that the regulus obstruction only generates intersections of multiplicity ")#mi("{2}")#text("; when ")#mi("{k>2}")#text(", the hypothesis that a regulus contains ")#mi("{O(N)}")#text(" points is not used and so can be dropped.")

#heading(level: 1)[#strong[#text(" — 2. The ")#mi("{k=2}")#text(" case — ")]]

#text("We first verify Theorem ")#link(<tao-f616a5464694c0f6ff5c>)[#text("5")]#text(" in the ")#mi("{k=2}")#text(" case, i.e. we show that the lines ")#mi("{{\\mathcal L}}")#text(" in that theorem can intersect in at most ")#mi("{O(N^3)}")#text(" points. As hinted in the previous discussion, the argument here is purely algebraic in nature, using just the polynomial method (similar to, say, how Dvir proved the finite fields Kakeya conjecture, as discussed in ")#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/")[#text("this previous blog post")]#text("). As such, the ")#mi("{k=2}")#text(" result in fact holds over an arbitrary field, but we will stick to ")#mi("{{\\bf R}}")#text(" for sake of notational consistency.")

#text("The polynomial method rests on two basic facts:")

#enum(start: 1, 
[#text("Given a set ")#mi("{S}")#text(" of points in ")#mi("{{\\bf R}^3}")#text(", there is a non-trivial polynomial ")#mi("{P: {\\bf R}^3 \\rightarrow {\\bf R}}")#text(" of degree ")#tao-math("{O(\\left|S\\right|^{1/3})}", block: false)#text(" that vanishes at all of these points simultaneously.")],
[#text("If a polynomial ")#mi("{P: {\\bf R}^3 \\rightarrow {\\bf R}}")#text(" of degree at most ")#mi("{d}")#text(" vanishes on more than ")#mi("{d}")#text(" points of a line ")#mi("{\\ell}")#text(", then it must in fact vanish on all of ")#mi("{\\ell}")#text(".")]
)

#text("Both facts are easy to prove (see e.g. ")#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/")[#text("this previous blog post")]#text("). But, as we will see, they have to be applied carefully in order to obtain a good estimate.")

#text("Suppose for sake of contradiction that we can find a set ")#mi("{S}")#text(" of points in ")#mi("{{\\bf R}^3}")#text(" of cardinality ")#tao-math("{\\left|S\\right| \\gg N^3}", block: false)#text(" such that each point in ")#mi("{S}")#text(" is incident to at least two lines from ")#mi("{{\\mathcal L}}")#text(". The strategy is then to use Fact 1 find a low-degree polynomial ")#mi("{P}")#text(" that vanishes on ")#mi("{S}")#text(", so that ")#mi("{S}")#text(" is contained in the low-degree surface ")#mi("{\\Sigma := \\{ x \\in {\\bf R}^3: P(x)=0\\}}")#text(". This surface ")#mi("{\\Sigma}")#text(" is not necessarily irreducible; it may be the union of several irreducible subsurfaces. By the nature of ")#mi("{S}")#text(", there will be lots of lines in ")#mi("{{\\mathcal L}}")#text(" that intersect this surface ")#mi("{\\Sigma}")#text(" quite frequently; by Fact 2, this should force the lines to be trapped inside ")#mi("{\\Sigma}")#text(". Thus we have a low-degree surface ")#mi("{\\Sigma}")#text(" that contains a lot of lines. Hopefully, this forces many of the irreducible components of ")#mi("{\\Sigma}")#text(" to be singly ruled surfaces, doubly ruled surfaces, or planes. The latter two cases cannot contain too many lines in ")#mi("{{\\mathcal L}}")#text(" by hypothesis, so we expect the dominant family of lines in ")#mi("{{\\mathcal L}}")#text(" to be those coming from the singly ruled surfaces. But one can use Bezout-type theorems to control the number of times lines from one singly ruled surface of controlled degree can intersect lines from another such surface, and hopefully this gives the desired ")#mi("{O(N^3)}")#text(" bound for ")#mi("{P}")#text(".")

#text("Let’s now execute this strategy. Fact 1 gives a non-trivial polynomial ")#mi("{P}")#text(" of degree ")#tao-math("{O(\\left|S\\right|^{1/3})}", block: false)#text(" that vanishes at all the points in ")#mi("{S}")#text(". This turns out to be too large of a degree bound to close the argument. The problem is that the set of points ")#mi("{S}")#text(" that we want to apply this fact to is not completely arbitrary; in fact, by its nature, many points in ")#mi("{S}")#text(" are going to be collinear (because each point in ")#mi("{S}")#text(" is incident to at least two lines from ")#mi("{{\\mathcal L}}")#text("), and so heuristically many of these points in ")#mi("{S}")#text(" are in fact “redundant” for the purposes of finding a polynomial that vanishes on all of ")#mi("{S}")#text(".")

#text("We can handle this by the “random refinement” trick. Let us write ")#tao-math("{\\left|S\\right| = Q N^3}", block: false)#text(" for some ")#mi("{Q \\ggg 1}")#text(". Each of these ")#mi("{Q N^3}")#text(" points is incident to two lines in ")#mi("{{\\mathcal L}}")#text("; as there are ")#mi("{\\sim N^2}")#text(" lines in ")#mi("{{\\mathcal L}}")#text(", we thus expect each line in ")#mi("{{\\mathcal L}}")#text(" to be incident to ")#mi("{\\sim QN}")#text(" points in ")#mi("{S}")#text(". (Actually, what could happen more generally is that only a fraction of the lines in ")#mi("{{\\mathcal L}}")#text(", say ")#mi("{\\alpha N^2}")#text(" lines for some ")#mi("{0 < \\alpha \\leq 1}")#text(", are contributing the bulk of the incidences, with each line being incident to about ")#mi("{\\sim QN/\\alpha}")#text(" points in ")#mi("{S}")#text("; but let us consider the ")#mi("{\\alpha=1}")#text(" case here for simplicity, as it is the worst case, and the other cases are similar but require a bit more bookkeeping.)")

#text("Now, let us destroy some of this collinearity by taking a random subset ")#mi("{S^{\\prime}}")#text(" of ")#mi("{S}")#text(" of density about ")#mi("{1/Q}")#text(". Then ")#mi("{S^{\\prime}}")#text(" will have size about ")#mi("{N^3}")#text(", and each line in ")#mi("{{\\mathcal L}}")#text(" is now expected to be incident to ")#mi("{O(N)}")#text(" elements of ")#mi("{S^{\\prime}}")#text(". We apply Fact 1 to get a non-trivial polynomial ")#mi("{P}")#text(" of degree ")#mi("{O(N)}")#text(" that vanishes at every point in ")#mi("{S^{\\prime}}")#text(". Applying Fact 2 (and assuming that certain constants were chosen properly), this implies that ")#mi("{P}")#text(" also vanishes at every line in ")#mi("{{\\mathcal L}}")#text(", and thus also at every point in ")#mi("{S}")#text(". This should be contrasted with what would have happened if we applied Fact 1 to ")#mi("{S}")#text(" directly, giving a degree bound of ")#mi("{O(Q^{1/3} N)}")#text(" rather than ")#mi("{O(N)}")#text(".")

#text("So now we have a surface ")#mi("{\\Sigma := \\{ x \\in {\\bf R}^3: P(x)=0\\}}")#text(" of degree ")#mi("{O(N)}")#text(" that contains all the ")#mi("{\\sim N^2}")#text(" lines in ")#mi("{{\\mathcal L}}")#text(". We split this surface into irreducible components. These components may be planes, reguli, singly ruled surfaces, or not ruled at all. To simplify things let us just consider four extreme cases:")

#enum(start: 1, 
[#mi("{\\Sigma}")#text(" consists of the union of planes.")],
[#mi("{\\Sigma}")#text(" consists of the union of reguli.")],
[#mi("{\\Sigma}")#text(" consists of the union of singly ruled surfaces.")],
[#mi("{\\Sigma}")#text(" consists of the union of non-ruled surfaces.")]
)

#text("(For the full proof, one also has to consider hybrid cases in which more than one of the above four types appear, and so there are some cross-terms to deal with, but these are relatively easy to control and will not be discussed here.)")

#text("In the first case, degree considerations tell us that there are at most ")#mi("{O(N)}")#text(" planes, and by hypothesis each of them contains ")#mi("{O(N)}")#text(" lines in ")#mi("{{\\mathcal L}}")#text(". Within each plane, there are at most ")#mi("{O(N^2)}")#text(" points of intersection, and between any two planes ")#mi("{\\pi_1, \\pi_2}")#text(", all points of intersection must lie in the common line ")#mi("{\\pi_1 \\cap \\pi_2}")#text(", which is incident to the ")#mi("{O(N)}")#text(" lines of ")#mi("{{\\mathcal L}}")#text(" in ")#mi("{\\pi_1, \\pi_2}")#text(" in at most ")#mi("{O(N)}")#text(" points. Adding this all together we get at most ")#mi("{O(N^3)}")#text(" points of intersection, which is acceptable.")

#text("A similar argument (which we omit) handles the second case, so we move on to the third case. Let’s assume for simplicity that each singly ruled surface has the same degree ")#mi("{d}")#text("; since the total degree of ")#mi("{\\Sigma}")#text(" is ")#mi("{O(N)}")#text(", we must then have at most ")#mi("{O(N/d)}")#text(" such surfaces. In a singly ruled surface ")#mi("{\\Gamma}")#text(", all but ")#mi("{O(1)}")#text(" of the lines in ")#mi("{\\Gamma}")#text(" will come from the single ruling of ")#mi("{\\Gamma}")#text(" (i.e. all but ")#mi("{O(1)}")#text(" of the lines will be generators); the contribution of these exceptional lines is negligible (as there at most ")#mi("{O(N)}")#text(" such lines in all, leading to ")#mi("{O(N^3)}")#text(" points of intersection) and we shall simply ignore them. There are two remaining types of intersection to consider; the intersections between two lines from the same ruling of a single ruled surface, and the intersections from lines that do not lie in the same ruled surface.")

#text("For the first type of intersection, one can show that in a ruled surface of degree ")#mi("{d}")#text(", any line in the ruling can intersect the other lines in the ruling in at most ")#mi("{O(d)}")#text(" points. So the total number of intersections arising in this way is ")#mi("{O(N^2 d)}")#text("; since ")#mi("{d = O(N)}")#text(", this is acceptable.")

#text("To handle the second type of intersection, observe that any line not incident to a ruled surface ")#mi("{\\Gamma}")#text(" can intersect ")#mi("{\\Gamma}")#text(" at most ")#mi("{O(d)}")#text(" times; summing over the ")#mi("{O(N/d)}")#text(" surfaces ")#mi("{\\Gamma}")#text(" and the ")#mi("{O(N^2)}")#text(" lines in ")#mi("{{\\mathcal L}}")#text(" we obtain at most ")#mi("{O(N^3)}")#text(" incidences, as desired.")

#text("Finally, we consider the fourth case, where there are no ruled surfaces anywhere in ")#mi("{\\Sigma}")#text(". Here, one uses an algebraic observation of Cayley that classifies ruled surfaces by a bounded number of algebraic conditions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6")]#text(" A surface ")#mi("{\\Gamma}")#text(" is ruled if and only if, for every point ")#mi("{p}")#text(" in ")#mi("{\\Gamma}")#text(", there exists a line ")#mi("{\\ell_p}")#text(" through ")#mi("{p}")#text(" that is tangent to ")#mi("{\\Gamma}")#text(" to order three (thus, if ")#mi("{P}")#text(" is a defining function for ")#mi("{\\Gamma}")#text(", there exists a non-zero vector ")#mi("{v}")#text(" such that ")#mi("{P(p) = D_v P(p) = D_v^2 P(p) = D_v^3 P(p) = 0}")#text(").")
]

#text("The “only if” direction is obvious, but what we need here is the more difficult “if” operation. The basic idea is to show (e.g. by using the ")#link("http://en.wikipedia.org/wiki/Picard%E2%80%93Lindel%C3%B6f_theorem")[#text("Picard uniqueness theorem")]#text(" for ODE) that the foliation induced by the tangent lines ")#mi("{\\ell_p}")#text(" consist entirely of straight lines, thus giving the desired ruling of ")#mi("{\\Sigma}")#text(". The precise order of vanishing is not required for this argument; any bounded number instead of three would suffice here. (I would be interested to know that if there was a slick, computation-free proof of the above proposition, perhaps using a larger order of vanishing than three.)")

#text("The condition that there exists a non-zero vector ")#mi("{v \\in {\\bf R}^3}")#text(" such that ")#mi("{D_v P(p)= D_v^2 P(p) = D_v^3 P(p)=0}")#text(" can be combined by elementary elimination theory (or high school algebra, for that matter) into a single algebraic condition ")#mi("{FL(P)(p)=0}")#text(" on ")#mi("{p}")#text(", where ")#mi("{FL(P)}")#text(" is a polynomial of degree ")#mi("{O( \\text{deg}(P) )}")#text(" known as the ")#emph[#text("flecnode polynomial")]#text(" of ")#mi("{P}")#text(". If ")#mi("{\\Sigma := \\{ x: P(x) = 0 \\}}")#text(" contains no ruled surfaces, then the above proposition tells us that the flecnode polynomial ")#mi("{FL(P)}")#text(" shares no common factors with ")#mi("{P}")#text(".")

#text("On the other hand, if ")#mi("{\\ell}")#text(" is a line in ")#mi("{{\\mathcal L}}")#text(" oriented in the direction ")#mi("{v}")#text(", and ")#mi("{p}")#text(" is a point in ")#mi("{{\\mathcal L}}")#text(", then ")#mi("{\\ell}")#text(" lies in ")#mi("{\\Sigma}")#text(", and thus ")#mi("{P(p) = D_v P(p)= D_v^2 P(p) = D_v^3 P(p)=0}")#text(". Thus we see that each line ")#mi("{\\ell}")#text(" in ")#mi("{{\\mathcal L}}")#text(" is contained in the zero locus of both ")#mi("{P}")#text(" and its flecnode polynomial ")#mi("{FL(P)}")#text(". However, by applying Bezout’s theorem to a generic two-dimensional slice of ")#mi("{{\\bf R}^3}")#text(", we see that the zero locus of ")#mi("{P}")#text(" and of ")#mi("{FL(P)}")#text(" can only intersect in ")#mi("{O( \\text{deg}(P) \\times \\text{deg}(FL(P)) ) = O( \\text{deg}(P)^2 )}")#text(" lines at most. But if we chose the constants correctly, this number will be less than the number of lines in ")#mi("{{\\mathcal L} \\sim N^2}")#text(", leading to the required contradiction.")

#heading(level: 1)[#strong[#text(" — 3. The ")#mi("{k>2}")#text(" case — ")]]

#text("Now we turn to the ")#mi("{k>2}")#text(" case. Our starting point here will be the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di%E2%80%93Trotter_theorem")[#text("Szemerédi-Trotter theorem")]#text(", which asserts that given a finite set ")#mi("{P}")#text(" of points and a finite set ")#mi("{L}")#text(" of lines, the number of incidences ")#tao-math("{\\left|I(P,L)\\right| := \\left|\\{ (p,\\ell) \\in P \\times L: p \\in \\ell \\}\\right|}", block: false)#text(" is bounded by")

#align(center)[#tao-fit-display[#tao-math("\\left|I(P,L)\\right| \\ll \\left|P\\right|^{2/3} \\left|L\\right|^{2/3} + \\left|P\\right| + \\left|L\\right|.", block: true)]]

#text("The theorem is usually stated in the plane ")#mi("{{\\bf R}^2}")#text(", but it automatically extends to higher dimensions, and in particular to ")#mi("{{\\bf R}^3}")#text(", by a random projection argument. This theorem can be proven by crossing number methods (as discussed in ")#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/")[#text("this previous blog post")]#text(") or by cell decomposition (as discussed in ")#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/")[#text("this previous blog post")]#text("). In both cases, the order structure of ")#mi("{{\\bf R}}")#text(" (and in particular, the fact that a line divides a plane into two half-planes) is crucial. But we will not need to know the proof of this theorem, instead using it as a black box.")

#text("An easy corollary of this theorem is that if ")#mi("{L}")#text(" is a family of lines, ")#mi("{P}")#text(" is a family of points, and ")#tao-math("{2 \\leq k \\ll \\left|L\\right|^{1/2}}", block: false)#text(" is such that each point in ")#mi("{P}")#text(" is incident to at least ")#mi("{k}")#text(" points in ")#mi("{L}")#text(", then ")#metadata(none) <tao-f7dd2a8db07f2367c615>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|P\\right| \\ll \\left|L\\right|^2/k^3.", block: true)]]

#text("If one applies this bound directly to our situation, we obtain the bound ")#tao-math("{\\left|P\\right| \\ll N^4/k^3}", block: false)#text(", which is inferior to the desired bound ")#tao-math("{\\left|P\\right| \\ll N^3/k^2}", block: false)#text(". Actually, it is not surprising that we get an inferior bound, because we have not yet exploited the crucial non-coplanarity hypothesis.")

#text("However, it is possible to amplify the Szemerédi-Trotter bound by the method of ")#emph[#text("cell decomposition")]#text(". As discussed in ")#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/")[#text("this previous blog post")]#text(", the idea is to carefully carve up the ambient space (which, in this case, is ")#mi("{{\\bf R}^3}")#text(") into smaller regions or “cells”, each of which only contains a small fraction of the points ")#mi("{P}")#text(" and which encounters only a small fraction of the lines ")#mi("{L}")#text(". One then applies an existing bound (in this case, ")#link(<tao-f7dd2a8db07f2367c615>)[#text("(1)")]#text(") to each cell, and sums up over all cells to get what should presumably be a better bound (where the key point being that the cells should be constructed in such a way that each line only encounters a small fraction of the cells).")

#text("There is however a catch to this method: if one creates too many cells, then one starts running into the problem that too many points in ")#mi("{P}")#text(" and too many lines in ")#mi("{L}")#text(" will now lie on the ")#emph[#text("boundary")]#text(" of the cell, rather than in the ")#emph[#text("interior")]#text(". So one has to carefully optimise the complexity of the cell decomposition.")

#text("In previous literature, the most popular way to create cells was by a random construction, for instance using randomly chosen points and lines from ")#mi("{P}")#text(" and ")#mi("{L}")#text(" to create planes, which one then uses to slice up space into polytope cells, possibly with an additional non-random “cleanup” stage to remove some degeneracies or other potential difficulties in the cell structure. One of the key innovations in the Guth-Katz paper is to instead create cells via the polynomial method, and specifically by the polynomial Ham Sandwich theorem. This allows for a very efficient and even cell decomposition; the walls of the cell will no longer be flat planes, but will still be algebraic sets of controlled degree, and this turns out to be good enough for the application at hand. This is inspired by previous applications of the polynomial ham sandwich theorem to incidence geometry problems, as discussed in ")#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/")[#text("this previous blog post")]#text(".")

#text("Let us first recall the polynomial ham sandwich theorem (for three dimensions), which one can think of as a continuous version of Fact 1 from the previous section:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Polynomial ham sandwich theorem)")]#text(" Let ")#mi("{X_1,\\ldots,X_m}")#text(" be ")#mi("{m}")#text(" bounded open sets in ")#mi("{{\\bf R}^3}")#text(". Then there exists a non-trivial polynomial ")#mi("{P: {\\bf R}^3 \\rightarrow {\\bf R}}")#text(" of degree ")#mi("{O(m^{1/3})}")#text(" such that the algebraic set ")#mi("{\\{ x \\in {\\bf R}^3: P(x)=0\\}}")#text(" bisects each of the ")#mi("{X_i}")#text(", thus ")#mi("{\\{ x \\in X_i: P(x) < 0\\}}")#text(" and ")#mi("{\\{ x \\in X_i: P(x) > 0\\}}")#text(" have volume equal to half that of ")#mi("{X_i}")#text(".")
]

#text("See for instance ")#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/")[#text("this previous blog post")]#text(" for a proof of this fact (based on the ")#link("http://en.wikipedia.org/wiki/Borsuk%E2%80%93Ulam_theorem")[#text("Borsuk-Ulam theorem")]#text(").")

#text("By taking the ")#mi("{X_1,\\ldots,X_m}")#text(" to be the ")#mi("{\\varepsilon}")#text("-neighbourhood of finite sets ")#mi("{S_1,\\ldots,S_m}")#text(", and sending ")#mi("{\\varepsilon}")#text(" to zero (using some basic compactness properties of the (projective) space of polynomials to extract a limit), one can conclude a useful combinatorial corollary:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 8 (Discretised polynomial ham sandwich theorem)")]#text(" ")#metadata(none) <tao-be5f82f84e563360d41d>#text(" Let ")#mi("{S_1,\\ldots,S_m}")#text(" be finite sets of points in ")#mi("{{\\bf R}^3}")#text(". Then there exists a non-trivial polynomial ")#mi("{P: {\\bf R}^3 \\rightarrow {\\bf R}}")#text(" of degree ")#mi("{O(m^{1/3})}")#text(" such that the algebraic set ")#mi("{\\{ x \\in {\\bf R}^3: P(x)=0\\}}")#text(" bisects each of the ")#mi("{S_i}")#text(", in the sense that ")#mi("{\\{ x \\in S_i: P(x) < 0\\}}")#text(" and ")#mi("{\\{ x \\in S_i: P(x) > 0\\}}")#text(" each have cardinality at most ")#tao-math("{\\left|S_i\\right|/2}", block: false)#text(".")
]

#text("Note that the algebraic set ")#mi("{\\{ x \\in {\\bf R}^3: P(x)=0\\}}")#text(" may capture some of the points of ")#mi("{S_i}")#text("; indeed, this is necessarily the case if ")#tao-math("{\\left|S_i\\right|}", block: false)#text(" is odd. This possibility will need to be addressed later in the argument.")

#text("We can iterate this corollary to obtain a nice cell decomposition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 9 (Cell decomposition)")]#text(" Let ")#mi("{S}")#text(" be a finite set of points in ")#mi("{{\\bf R}^3}")#text(", and let ")#mi("{m \\geq 1}")#text(". Then there exists a non-trivial polynomial ")#mi("{P}")#text(" of degree ")#mi("{O(m^{1/3})}")#text(" and a decomposition of ")#mi("{\\{ x \\in {\\bf R}^3: P(x) \\neq 0 \\}}")#text(" into at most ")#mi("{O(m)}")#text(" cells ")#mi("{C}")#text(", each of which is an open set with boundary in ")#mi("{\\{ x \\in {\\bf R}^3: P(x) = 0 \\}}")#text(", and each of which contains at most ")#tao-math("{O(\\left|S\\right|/m)}", block: false)#text(" points of ")#mi("{S}")#text(". (We allow ")#mi("{C}")#text(" to be disconnected.)")
]

#emph[#text("Proof:")]#text(" Without loss of generality we may take ")#mi("{m=2^j}")#text(" to be a power of two. The proposition is trivial for ")#mi("{m=1}")#text(", and by using Corollary ")#link(<tao-be5f82f84e563360d41d>)[#text("8")]#text(" it is easy to see (with the right choice of implied constants) that the claim for ")#mi("{m}")#text(" implies the claim for ")#mi("{2m}")#text(" (with the same implied constants), by bisecting each of the cells obtained for ")#mi("{m}")#text(" by an additional bisecting polynomial that one then multiplies with the existing polynomial. ")#mi("\\Box")

#text("Note that Fact 1 from the previous section can be viewed as the case ")#tao-math("{m=\\left|S\\right|}", block: false)#text(" of the above decomposition, in which the cell walls have now absorbed all the points in ")#mi("{S}")#text(". But for us, the optimal value of ")#mi("{m}")#text(" will be significantly less than ")#tao-math("{\\left|S\\right|}", block: false)#text(", to balance the contribution of the points on the cell walls with the points in the interior.")

#text("We now apply this situation to the situation in Theorem ")#link(<tao-f616a5464694c0f6ff5c>)[#text("5")]#text(". Fix ")#mi("{3 \\leq k \\leq N}")#text(", and suppose for contradiction that we can find a set ")#mi("{S}")#text(" of points with ")#tao-math("{\\left|S\\right| \\ggg N^3/k^2}", block: false)#text(", with each point in ")#mi("{S}")#text(" incident to at least ")#mi("{k}")#text(" lines in ")#mi("{{\\mathcal L}}")#text(".")

#text("We will apply the cell decomposition for a certain parameter ")#mi("{m}")#text("; it turns out that the optimal value here is ")#mi("{m \\sim (N/k)^3}")#text(". Thus we obtain a non-trivial polynomial ")#mi("{P}")#text(" of degree ")#mi("{O(N/k)}")#text(", and a collection of ")#mi("{O((N/k)^3)}")#text(" cells, each of which contains ")#tao-math("{O((k/N)^3 \\left|S\\right|)}", block: false)#text(" points of ")#mi("{S}")#text(" in the interior.")

#text("By throwing away at most half of the points in ")#mi("{S}")#text(", we can end up in one of two extreme cases:")

#enum(start: 1, 
[#text("(Cellular case) All points in ")#mi("{S}")#text(" are in the interior of a cell.")],
[#text("(Algebraic case) All points in ")#mi("{S}")#text(" are in the boundary of a cell.")]
)

#text("The cellular case becomes easier for ")#mi("{m}")#text(" large, while the algebraic case becomes easier for ")#mi("{m}")#text(" small; the choice ")#mi("{m \\sim (N/k)^3}")#text(" is used to balance the two cases.")

#text("Let us first consider the cellular case. Then we ")#mi("{\\gg (N/k)^3}")#text(" cells ")#mi("{C}")#text(" will contain ")#tao-math("{\\gg (k/N)^3 \\left|S\\right|}", block: false)#text(" points of ")#mi("{S}")#text(". Each such point in such a cell ")#mi("{C}")#text(" is incident to at least ")#mi("{k}")#text(" lines from ")#mi("{{\\mathcal L}}")#text(". Applying the Szemerédi-Trotter bound ")#link(<tao-f7dd2a8db07f2367c615>)[#text("(1)")]#text(" inside this cell ")#mi("{C}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("(k/N)^3 \\left|S\\right| \\ll \\left|{\\mathcal L}_C\\right|^2/k^3,", block: true)]]

#text("where ")#mi("{{\\mathcal L}_C}")#text(" is the set of lines in ")#mi("{{\\mathcal L}}")#text(" that intersect ")#mi("{C}")#text(". Since ")#tao-math("{\\left|S\\right| \\ggg N^3/k^2}", block: false)#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\mathcal L}_C\\right| \\ggg k^2.", block: true)]]

#text("On the other hand, as ")#mi("{P}")#text(" has degree ")#mi("{O(N/k)}")#text(", we see from Bezout’s theorem that each line in ")#mi("{{\\mathcal L}}")#text(" intersects ")#mi("{O(N/k)}")#text(" cells, and so")

#align(center)[#tao-fit-display[#tao-math("\\sum_C \\left|{\\mathcal L}_C\\right| \\ll (N/k) \\left|{\\mathcal L}\\right| \\ll N^3 / k.", block: true)]]

#text("Since the number of cells here is ")#mi("{\\gg (N/k)^3}")#text(", we obtain")

#align(center)[#tao-fit-display[#mitex("(N/k)^3 k^2 \\lll N^3/k")]]

#text("which is a contradiction.")

#text("Now consider the algebraic case. We have ")#mi("{S}")#text(" points, each incident to ")#mi("{k}")#text(" lines from ")#mi("{{\\mathcal L}}")#text(", which has cardinality ")#mi("{\\sim N^2}")#text(". We thus expect each line to be incident to ")#tao-math("{\\sim k\\left|S\\right|/N^2 \\ggg N/k}", block: false)#text(" points in ")#mi("{S}")#text(". For simplicity we will assume that every line is of this type (in reality, we would have to throw out some lines that do not intersect enough points in ")#mi("{S}")#text(").")

#text("By construction, all the points in ")#mi("{S}")#text(" lie in the algebraic set ")#mi("{\\Sigma := \\{ x \\in {\\bf R}^3: P(x)=0\\}}")#text(", which has degree ")#mi("{O(N/k)}")#text(". Applying Fact 2, we conclude that every line in ")#mi("{{\\mathcal L}}")#text(" is in fact trapped inside ")#mi("{\\Sigma}")#text(".")

#text("This is now a situation fairly similar to that of the previous section. However, we now use the hypothesis that ")#mi("{k \\geq 3}")#text(" to obtain a better bound. Every point ")#mi("{p}")#text(" in ")#mi("{S}")#text(" has at least three lines of ")#mi("{{\\mathcal L}}")#text(" passing through it, each of which lies in ")#mi("{\\Sigma}")#text(". This leads to two possibilities for ")#mi("{p}")#text(":")

#enum(start: 1, 
[#text("(Singular case) ")#mi("{p}")#text(" is a singular point of ")#mi("{\\Sigma}")#text(" (i.e. ")#mi("{\\nabla P(p) = 0}")#text(").")],
[#text("(Flat case) ")#mi("{p}")#text(" is a flat point of ")#mi("{\\Sigma}")#text(" (i.e. the ")#mi("{p}")#text(" is non-singular, but the second fundamental form of ")#mi("{\\Sigma}")#text(" vanishes at ")#mi("{p}")#text(").")]
)

#text("Indeed, if ")#mi("{p}")#text(" was non-singular, then ")#mi("{\\Sigma}")#text(" has a unique tangent plane at ")#mi("{p}")#text(" along which at least three lines of ")#mi("{{\\mathcal L}}")#text(" are tangent; as they all lie in ")#mi("{\\Sigma}")#text(", this forces the second fundamental form of ")#mi("{\\Sigma}")#text(" to vanish.")

#text("By throwing out at most half of the points in ")#mi("{S}")#text(", we may now reduce to two subcases:")

#enum(start: 1, 
[#text("(Singular subcase) All points of ")#mi("{S}")#text(" are singular points of ")#mi("{\\Sigma}")#text(".")],
[#text("(Flat subcase) All points of ")#mi("{S}")#text(" are flat points of ")#mi("{\\Sigma}")#text(".")]
)

#text("Let us consider first the singular subcase. The points ")#mi("{S}")#text(" are now contained in the zero locus of ")#mi("{P}")#text(" and of ")#mi("{\\nabla P}")#text("; the latter is an intersection of three algebraic surfaces of degree ")#mi("{O(N/k)}")#text("; by reducing ")#mi("{P}")#text(" to be square-free, we can assume that ")#mi("{P}")#text(" and ")#mi("{\\nabla P}")#text(" have no common factor. We already saw from Fact 2 that all the lines in ")#mi("{{\\mathcal L}}")#text(" were trapped in the zero locus of ")#mi("{P}")#text("; the same argument shows that they are also trapped in the zero locus of ")#mi("{\\nabla P}")#text(". But by Bezout’s theorem applied to a generic two-dimensional slice of ")#mi("{{\\bf R}^3}")#text(" (as was done in the previous section, using ")#mi("{FL(P)}")#text(" instead of ")#mi("{\\nabla P}")#text("), we see that the zero locus of ")#mi("{P}")#text(" and ")#mi("{\\nabla P}")#text(" can intersect in at most ")#mi("{O( N/k) \\times O(N/k)}")#text(" lines, which will contradict the bound ")#tao-math("{\\left|{\\mathcal L}\\right| \\sim N^2}", block: false)#text(" if the constants are chosen properly.")

#text("Now we turn to the flat subcase. Just as the three polynomial components ")#mi("{\\partial_{e_1} P, \\partial_{e_2} P, \\partial_{e_3} P}")#text(" of ")#mi("{\\nabla P}")#text(" detects singular points of ")#mi("{\\Sigma}")#text(", there are nine polynomials that detect flat points of ")#mi("{\\Sigma}")#text(", namely the components ")#mi("{Q_{i,j}}")#text(" of the three-dimensional vector fields")

#align(center)[#tao-fit-display[#mitex("Q_i := (D_{e_i \\times \\nabla P} \\nabla P) \\times \\nabla P")]]

#text("for ")#mi("{i,j=1,2,3}")#text(". All nine polynomials ")#mi("{Q_{i,j}}")#text(" vanish at a flat point. (This observation was also used in ")#link("http://arxiv.org/abs/0812.1043")[#text("a previous paper of Guth and Katz")]#text(" in which they solve the joints problem.)")

#text("The argument for the singular subcase almost carries over without difficulty to the flat subcase, but there is one problem: it is not necessarily the case that ")#mi("{P}")#text(" does not share a common factor with the ")#mi("{Q_{i,j}}")#text(", so that we cannot quite apply the Bezout argument immediately. Indeed, ")#mi("{P}")#text(" could contain a plane, which of course consists entirely of flat points. However, if ")#mi("{P}")#text(" has no planes, then the set of flat points has positive codimension, and the argument proceeds as before. At the other extreme, if ")#mi("{P}")#text(" consists entirely of planes, then by degree considerations there are at most ")#mi("{O(N/k)}")#text(" planes present. But by hypothesis, each plane contains at most ")#mi("{O(N)}")#text(" lines from ")#mi("{{\\mathcal L}}")#text(". Since ")#tao-math("{\\left|{\\mathcal L}\\right| \\sim N^2}", block: false)#text(", this leads to a contradiction (if the implied constants are chosen correctly). The general case (in which ")#mi("{P}")#text(" has some planes, but does not consist entirely of planes) can be established by combining the previous two arguments properly.")

#heading(level: 1)[#text("Comments (23)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4bf1a369b46f80a37f403db0a1d4dbd97381cf2eadc130998d4b8613975c4009-3d94e632824227280875c9bb6bec278e2bc310ca9f1b74e6a4e1022ecb30e2d4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Derrick")]], [#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-48206")[#strong[#text("Derrick")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2010")])]

#text("I guess this automatically improves the exponent in all dimensions using Solymosi-Vu. Do you think that this method will prove the d-dimensional conjecture?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-48226")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2010")])]

#text("I think that this is certainly a definite possibility. Now that we know that two of the most powerful tools in combinatorial incidence geometry – the cell decomposition and the polynomial method – can be combined to give nearly sharp results that were out of reach of each of the methods separately, it seems worthwhile to revisit all of the other standard problems in the subject and see if we can advance the partial results for these problems a bit more. If nothing else, this should give us a better sense of what the strengths and limitations of this combination are; currently we only have one data point to work with, although admittedly a rather impressive one.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10363e310bcdb54abcb59c65fb564f203d0022984d3e0814b67c8c4d6252d093-4042af8a57ba07ecc00848c889610a827652d19e91beae7a2b42a15620ff9dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nets Katz")]], [#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-48207")[#strong[#text("Nets Katz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2010")])]

#text("Terry,")

#text("Thanks for this remarkable exposition. I wanted to comment on a slight inaccuracy which may cause confusion for some readers.")

#text("You write that the lines in the ruling of a singly ruled surface do not intersect")#linebreak()#text(" each other, but in fact they can do so (and over the complex numbers they must) at singularities of the surface. However, we can carefully bound")#linebreak()#text(" the number of intersections as follows:")

#text("Let X be a ruled surface of degree d and l an element of the ruling.")#linebreak()#text(" Intersect X with P any plane going through l. The intersection is a curve")#linebreak()#text(" of degree d, one of whole components is the line l. The other component c,")#linebreak()#text(" is a curve of degree d-1. This curve intersects l at d-1 points. One of these")#linebreak()#text(" points is the point where P is tangent to the surface. (There is only one")#linebreak()#text(" such point because the tangent spaces along l agree with those of an osculating regulus.) The remaining d-2 points are intersections of the")#linebreak()#text(" line with other lines of the ruling.")

#text("However even if the degree were N, this would only give rise to N^2 (N-2)")#linebreak()#text(" points of intersection.")

#text("Segre had a theorem which said that any regular algebraic surface of degree N>2 contains at most 11N^2 – 24 N lines. This makes sense")#linebreak()#text(" when one realize that (over the complex numbers) all ruled surfaces")#linebreak()#text(" of degree N>2 are singular!")

#text("For more information on the classical theory of ruled surfaces, one can look here:")

#link("http://ia311029.us.archive.org/1/items/cu31924001521065/cu31924001521065.pdf")[#text("Click to access cu31924001521065.pdf")]

#text("Nets")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gkpaperreader")]], [#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-50770")[#strong[#text("gkpaperreader")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2011")])]

#text("I can’t open the link…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1a29b83d3715f084733cbf3b4d6ebeb0bd60852598b56cfdcefb1ca59292e95-be295ea13410f76f66eab689ea4c87a5f2c5418a1f6f3a28544dee0db39727c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of konradswanepoel")]], [#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-51111")[#strong[#text("konradswanepoel")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2011")])]

#text("Try this:")

#link("http://www.archive.org/details/cu31924001521065")[#text("http://www.archive.org/details/cu31924001521065")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-48228")[#strong[#text("János Pach: Guth and Katz’s Solution of Erdős’s Distinct Distances Problem | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2010")]

#text("[…] exposition of the main ideas of the proof of Guth and Katz can be found on Terry Tao Blog. This entry was posted in Combinatorics, Geometry, Guest blogger, Open problems and tagged Larry […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7f273d4ba69952362d533e47b75a65520d156cc112af31de14420724acfe2d54-32621774b7937b33ce1f54b3e00115a0cc9f20080430903839f28fe4a2630fa3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Akatin")]], [#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-48270")[#strong[#text("Akatin")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2010")])]

#text("I seriousely enjoy reading this new exposition.i am realy impressed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7f273d4ba69952362d533e47b75a65520d156cc112af31de14420724acfe2d54-32621774b7937b33ce1f54b3e00115a0cc9f20080430903839f28fe4a2630fa3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Akatin")]], [#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-48271")[#strong[#text("Akatin")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2010")])]

#text("I seriousely enjoy reading this new exposition.but how can i get new mathematical info in my email?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d75c1e506dc65356d0041c9ba11820cec5bd9dc4f51b1bfa0b6c26aa39d6149-4bb23d56be5f0bf17292f32542c2eca8123dbf53855b965bdefda6353bbcc15c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew Kahle")]], [#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-48443")[#strong[#text("Matthew Kahle")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2010")])]

#text("Terry, do you think there’s any hope that this kind of methods can improve the upper bound on the number of unit distances between n points, or will we need another major breakthrough before this happens?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-48444")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2010")])]

#text("Well, I’d have to give pretty much the same answer as in my earlier comment: it’s possible, but we need more data points.")

#text("For a given configuration of points, and a distance d, let f(d) be the number of pairs of points at distance d. The Guth-Katz method basically estimates the L^2 norm of f, and the L^1 norm is obviously ~n^2, but the unit distance problem requires one to control instead the L^infty norm of f. One possibility perhaps is to look at intermediate L^p norms of f for p=3,4,5,…. It may well be that the Guth-Katz method extends to these expressions. So there is hope, but I would imagine that there would be nontrivial technical obstacles. (For instance, the group of Euclidean motions is not sufficiently transitive for the naive analogue of Proposition 3 to hold for higher p; I do not see immediately how to get around this difficulty.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Szemeredi-Trotter theorem via the polynomial ham sandwich theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-50312")[#strong[#text("The Szemeredi-Trotter theorem via the polynomial ham sandwich theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2011")])]

#text("[…] proof is sketched in this previous blog post. The cells in the argument are not necessarily connected (being instead formed by intersecting […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lines in the Euclidean group SE(2) « What’s new")]], [#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-50593")[#strong[#text("Lines in the Euclidean group SE(2) « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2011")])]

#text("[…] | Tags: Euclidean geometry, projective geometry, spherical geometry | by Terence Tao In a previous blog post, I discussed the recent result of Guth and Katz obtaining a near-optimal bound on the Erdos […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An incidence theorem in higher dimensions « What’s new")]], [#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-50821")[#strong[#text("An incidence theorem in higher dimensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2011")])]

#text("[…] Geometry. In this paper we use the polynomial Ham Sandwich method of Guth and Katz (as discussed previously on this blog) to establish higher-dimensional versions of the Szemerédi-Trotter theorem, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2a53b1bf67466136711a2ed119e3214aa74947b78a526c1ac8fd85337c804730-1517ccf3c75bcb2db94dbfd8ee45e8216809077a0fb0bd838b701793fd1d9d7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Zaslavsky")]], [#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-137752")[#strong[#text("Thomas Zaslavsky")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2012")])]

#text("I beg to differ with one point in this good exposition. This is not called incidence geometry. The name of the field to which this problem belongs is “combinatorial geometry”. There is no incidence question; it’s a packing problem since you’re packing N circles or balls of maximum radius.")

#text("A combinatorial incidence geometry problem might be to find the minimum number of 2-point lines generated by N points in the Euclidean plane, not all collinear. (An extended Sylvester-Gallai problem.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-137756")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2012")])]

#text("Hmm, it seems a gray area to me. It is true that the distance problem, strictly speaking, does not involve incidences, but Theorem 4, which is the core of the Guth-Katz argument, is certainly an incidence geometry result (being a cousin of the Szemeredi-Trotter theorem), and the deduction of the distance bound from the incidence bound is not particularly difficult. Perhaps the precise thing to say is that the Guth-Katz bound is an application of incidence geometry methods to a combinatorial geometry problem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Algebraic combinatorial geometry: the polynomial method in arithmetic combinatorics, incidence combinatorics, and number theory | What's new")]], [#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-249020")[#strong[#text("Algebraic combinatorial geometry: the polynomial method in arithmetic combinatorics, incidence combinatorics, and number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2013")])]

#text("[…] More recently, it underlies Dvir’s proof of the Kakeya conjecture over finite fields and Guth and Katz’s near-complete solution to the Erdos distance problem in the plane, and can be used to give a short proof of the Szemeredi-Trotter theorem. One of the aims of this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Cayley-Salmon theorem via classical differential geometry | What's new")]], [#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-280130")[#strong[#text("The Cayley-Salmon theorem via classical differential geometry | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2014")])]

#text("[…] of Guth and Katz that almost solved the Erdos distance problem in two dimensions, as discussed in this previous blog post. Vanishing to third order is necessary: observe that in a surface of negative curvature, such as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67c60f310ec909b8fb0447c5700d07336d4279e991d0cd0302014c7990a66cb0-e94c58550505d5b6aff7d1b9778bd052740af23d799ba9b2faa0d36a5704d1f0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rbharath")]], [#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-280562")[#strong[#text("rbharath")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2014")])]

#text("There’s a small typo “By considing” instead of “By considering” shortly after the statement of Problem 1.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bbd9a48dd1f99215c7d02785bf23c029e75b5b16efebd83e01c019286645800-893dd466a56f669deedd0126dac9faf84f5e4597285fe3c36507cfd9a49ddd0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of [2016.01.01] Erdős distinct distances problem -1 | leftmath")]], [#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-464613")[#strong[#text("[2016.01.01] Erdős distinct distances problem -1 | leftmath")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2015")])]

#text("[…] 사실 어렵지만, 중요한 아이디어들은 캐치할 수 있다(이하 내용은 Terrence Tao의 블로그에서 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bbd9a48dd1f99215c7d02785bf23c029e75b5b16efebd83e01c019286645800-893dd466a56f669deedd0126dac9faf84f5e4597285fe3c36507cfd9a49ddd0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of [2016.01.01] Erdős distinct distances problem | leftmath")]], [#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-464675")[#strong[#text("[2016.01.01] Erdős distinct distances problem | leftmath")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2016")])]

#text("[…] 사실 어렵지만, 중요한 아이디어들은 캐치할 수 있다(이하 내용은 Terrence Tao의 블로그에서 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lines in the Euclidean group SE(2) | What's new")]], [#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-476818")[#strong[#text("Lines in the Euclidean group SE(2) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2017")])]

#text("[…] a previous blog post, I discussed the recent result of Guth and Katz obtaining a near-optimal bound on the Erdos […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e83045ee1784bf91fa9a10805f1a09bdafc4ac7f1a2743390ede8176c2d38fe-191cf52af127f77cd932fc2fccbb2837fcd12d24c40d08604fec95a4ed47c6e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Zhao")]], [#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-572234")[#strong[#text("Jason Zhao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2020")])]

#text("Inspired by your remark on the rigid motions in the plane between two points forming a line and whether it is a coincidence, I was wondering if one could apply the Guth-Katz-(Elekes-Sharir) framework to the distinct distance problem on the sphere, with the role of rigid motions being replaced by the rotation group SO(3).")

#text("Most of the set up is analogous; the only modification we have to make is disallowing antipodal points on the sphere, as otherwise we gain a degree of freedom, namely our isometries between pairs of points will not be unique.")

#text("The remaining issue is choosing the right coordinate system. Angle-axis seems like the natural choice (again, very much analogous to the rigid motions case), though my spherical geometry is a bit lacking, so I haven’t been able to work out the right dependence between angle and axis. Moreover, compactness of SO(3) and the structure of the set of rotations between two points seems to suggest that we would get circles rather than lines.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Planar point sets with forbidden four-point patterns and few distinct distances | What's new")]], [#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/#comment-685704")[#strong[#text("Planar point sets with forbidden four-point patterns and few distinct distances | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2024")])]

#text("[…] that this is best possible up to constants. A celebrated result of Guth and Katz, discussed in this previous blog post, shows that will determine at least distances. Note that the lower bound here is far larger, and […]")
]
