// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/
// Converted to Typst by tao2typ: "2026-10-14T16:35:15.605649+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "285G, Lecture 0: Riemannian manifolds and curvature", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("285G, Lecture 0: Riemannian manifolds and curvature")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 March 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/")[#text("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("Next week (starting on Wednesday, to be more precise), I will begin ")#link("http://www.math.ucla.edu/%7Etao/285g.1.08s/")[#text("my class on Perelman’s proof of the Poincaré conjecture")]#text(". As I only have ten weeks in which to give this proof, I will have to move rapidly through some of the more basic aspects of ")#link("http://en.wikipedia.org/wiki/Riemannian_geometry")[#text("Riemannian geometry")]#text(" which will be needed throughout the course. In particular, in this preliminary lecture, I will quickly review the basic notions of infinitesimal (or microlocal) Riemannian geometry, and in particular defining the ")#link("http://en.wikipedia.org/wiki/Riemann_curvature_tensor")[#text("Riemann")]#text(", ")#link("http://en.wikipedia.org/wiki/Ricci_curvature")[#text("Ricci")]#text(", and ")#link("http://en.wikipedia.org/wiki/Scalar_curvature")[#text("scalar ")]#text("curvatures of a Riemannian manifold. (The more “global” aspects of Riemannian geometry, for instance concerning the relationship between distance, curvature, ")#link("http://en.wikipedia.org/wiki/Injectivity_radius")[#text("injectivity radius")]#text(", and volume, will be discussed later in this course.) This is a review only, in particular omitting any leisurely discussion of examples or motivation for Riemannian geometry; it is impossible to compress this subject into a single lecture, and I will have to refer you to a textbook on the subject for a more complete treatment (I myself am using the text “")#link("http://www.ams.org/mathscinet-getitem?mr=1480173")[#text("Riemannian geometry")]#text("” by my colleague here at UCLA, ")#link("http://www.math.ucla.edu/~petersen/")[#text("Peter Petersen")]#text(").")

#metadata(none) <tao-d8b7604bf9269268679b>

#heading(level: 1)[#text("— Smooth manifolds —")]

#text("Riemannian geometry takes place on ")#emph[#text("smooth manifolds")]#text(" M of some dimension ")#mi("d = 0,1,2,\\ldots")#text(". Recall that a d-dimensional manifold (or ")#emph[#text("d-manifold")]#text(" for short) M consists of the following structures:")

#list(
[#text("A topological space M (which for technical reasons we assume to be ")#link("http://en.wikipedia.org/wiki/Hausdorff_space")[#text("Hausdorff")]#text(" and ")#link("http://en.wikipedia.org/wiki/Second-countable")[#text("second countable")]#text(");")],
[#text("An ")#link("http://en.wikipedia.org/wiki/Atlas_%28topology%29")[#text("atlas")]#text(" of ")#link("http://en.wikipedia.org/wiki/Chart_%28topology%29")[#text("charts")]#text(" ")#mi("\\phi_\\alpha: U_\\alpha \\to V_\\alpha")#text(", which are homeomorphisms from open sets ")#mi("U_\\alpha")#text(" in M to open sets ")#mi("V_\\alpha")#text(" in ")#mi("{\\Bbb R}^d")#text(", such that the ")#mi("U_\\alpha")#text(" cover M.")]
)

#text("We say that the manifold M is ")#emph[#text("smooth")]#text(" if the charts ")#mi("\\phi_\\alpha")#text(" define a consistent smooth structure, in the sense that the maps ")#mi("\\phi_\\alpha \\circ \\phi_\\beta^{-1}")#text(" is smooth (i.e. infinitely differentiable) on ")#mi("\\phi_\\beta( U_\\alpha \\cap U_\\beta )")#text(" for every ")#mi("\\alpha, \\beta")#text(". One can then assert that a function ")#mi("f: M \\to X")#text(" from M to another space with a smooth structure (e.g. ")#mi("{\\Bbb R}")#text(" or ")#mi("{\\Bbb C}")#text(") is smooth if ")#mi("f \\circ \\phi_\\alpha^{-1}")#text(" is smooth on ")#mi("V_\\alpha")#text(" for every ")#mi("\\alpha")#text("; a smooth map with an inverse which is also smooth is known as a ")#emph[#link("http://en.wikipedia.org/wiki/Diffeomorphism")[#text("diffeomorphism")]]#text(". The space of all smooth functions ")#mi("f: M \\to {\\Bbb R}")#text(" is denoted ")#mi("C^\\infty(M)")#text("; this is a topological ")#link("http://en.wikipedia.org/wiki/Algebra_over_a_field")[#text("algebra")]#text(" over the reals. More generally, we have the algebra ")#mi("C^\\infty(U)")#text(" for any open subset of M. (It is possible to view smooth manifolds more abstractly (and in a fully coordinate-independent fashion) by using the ")#link("http://en.wikipedia.org/wiki/Structure_sheaf")[#text("structure sheaf")]#text(" of algebras ")#mi("C^\\infty(U)")#text(" to define the smooth structure, rather than the atlas of charts, but we will not need to take this perspective here.)")

#strong[#text("Remark 1.")]#text(" The most intuitive way to view manifolds is from an ")#emph[#text("extrinsic ")]#text("viewpoint: as subsets of some larger-dimensional space (e.g. viewing curves as subsets of the plane, surfaces as subsets of a Euclidean space such as ")#mi("{\\Bbb R}^3")#text("). While every smooth manifold can be viewed this way (thanks to the ")#link("http://en.wikipedia.org/wiki/Whitney_embedding_theorem")[#text("Whitney embedding theorem")]#text("), we will in fact not use the extrinsic perspective at all in this course! Instead, we will rely exclusively on the intrinsic perspective – by studying the various structures on a smooth manifold M purely in terms of objects that can be defined in terms of the atlas. In fact, once we set up the most basic such structure – the ")#link("http://en.wikipedia.org/wiki/Tangent_bundle")[#text("tangent bundle")]#text(" – we will often not use the atlas directly at all (thus working in a “coordinate-free” fashion). However, the “local coordinates” provided by the charts in an atlas will be useful for computations at various junctures. ")#mi("\\diamond")

#strong[#text("Remark 2.")]#text(" It is a surprising and unintuitive fact that a single topological manifold can have two distinct smooth structures which are not ")#link("http://en.wikipedia.org/wiki/Diffeomorphism")[#text("diffeomorphic")]#text(" to each other! This is most famously the case for 7-spheres ")#mi("S^7")#text(", giving rise to ")#link("http://en.wikipedia.org/wiki/Exotic_sphere")[#text("exotic spheres")]#text(". However, in the case of 3-manifolds – which is the focus of this course – all smooth structures are diffeomorphic (a result of ")#link("http://www.ams.org/mathscinet-getitem?mr=121804")[#text("Munkres")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=124917")[#text("Whitehead")]#text("; see also ")#link("http://www.ams.org/mathscinet-getitem?mr=137124")[#text("Smale")]#text(" for higher-dimensional variants), and so this subtlety need not concern us. ")#mi("\\diamond")#text(" ")#text("[")#emph[#text("Aside")]#text(": I was unable to find the relevant reference of Smale – does anyone know it?]")

#strong[#text("Remark 3. ")]#text(" As ")#mi("C^\\infty(M)")#text(" is commutative, we will multiply by functions in this space on the left or on the right interchangeably. In ")#link("http://en.wikipedia.org/wiki/Noncommutative_geometry")[#text("noncommutative geometry")]#text(", this algebra is replaced by a noncommutative algebra, and one has to take substantially more care with the order of multiplication, but we will not use noncommutative geometry here. ")#mi("\\diamond")

#text("We will be interested in various ")#link("http://en.wikipedia.org/wiki/Vector_bundle")[#text("vector bundles")]#text(" over a smooth manifold M. A ")#emph[#text("vector bundle")]#text(" V is a collection of (real) vector spaces ")#mi("V_x")#text(" of a fixed dimension k (the ")#emph[#link("http://en.wikipedia.org/wiki/Fiber_bundle")[#text("fibres")]]#text(" of the bundle) associated to each point ")#mi("x \\in M")#text(", whose disjoint union ")#mi("V = \\biguplus_{x \\in M} V_x")#text(" can itself be given the structure of a smooth (d+k-dimensional) manifold, in such a way that for all sufficiently small neighbourhoods U of any given point x, the set ")#mi("\\biguplus_{x \\in U} V_x")#text(" has a ")#emph[#text("trivialisation")]#text(", i.e. there is a diffeomorphism between ")#mi("\\biguplus_{x \\in U} V_x")#text(" and ")#mi("U \\times {\\Bbb R}^k")#text(", with each fibre ")#mi("V_x")#text(" being identified in a linearly isomorphic way with the vector space ")#mi("\\{x\\} \\times {\\Bbb R}^k \\equiv {\\Bbb R}^k")#text(". A (global) ")#link("http://en.wikipedia.org/wiki/Section_%28fiber_bundle%29")[#emph[#text("section")]]#text(" of a vector bundle V is a smooth map ")#mi("f: M \\to V")#text(" such that ")#mi("f(x) \\in V_x")#text(" for every ")#mi("x \\in V")#text(". The space of all sections is denoted ")#mi("\\Gamma(V)")#text("; it is a vector space over ")#mi("{\\Bbb R}")#text(", and furthermore is a module over ")#mi("C^\\infty(M)")#text(". We will sometimes also be interested in ")#emph[#text("local")]#text(" sections ")#mi("f: U \\to V")#text(" on some open subset U of M; the space of such sections (which form a module over ")#mi("C^\\infty(U)")#text(") will be denoted ")#mi("\\Gamma(U \\to V)")#text(". All of the discussion below on the global manifold M can be easily adapted to local open sets U in this manifold (indeed, one can interpret U itself as a manifold); as all our computations will be entirely local (and because of the ready availability of smooth ")#link("http://en.wikipedia.org/wiki/Cutoff_function")[#text("cutoff functions")]#text("), the theory on M and the theory on U will be completely compatible.")

#strong[#text("Example 1. ")]#text(" The space ")#mi("C^\\infty(M)")#text(" can be canonically identified with the space of sections ")#mi("\\Gamma(M \\times {\\Bbb R})")#text(" of the trivial line bundle ")#mi("M \\times {\\Bbb R}")#text(". ")#mi("\\diamond")

#text("In Riemannian geometry, the most fundamental vector bundle over a manifold M is the ")#emph[#link("http://en.wikipedia.org/wiki/Tangent_bundle")[#text("tangent bundle")]]#text(" TM, defined by letting the ")#link("http://en.wikipedia.org/wiki/Tangent_space")[#emph[#text("tangent space")]]#text(" ")#mi("T_x M")#text(" at a point ")#mi("x \\in M")#text(" be the space of all ")#emph[#text("tangent vectors")]#text(" in M at x. A tangent vector ")#mi("v \\in T_x M")#text(" can be defined as a vector which can be expressed as the (formal) derivative ")#mi("v=\\gamma^{\\prime}(0)")#text(" of some smooth curve ")#mi("\\gamma: (-\\varepsilon, \\varepsilon) \\to M")#text(" which passes through x at time zero, thus ")#mi("\\gamma(0) = x")#text(". One can express these tangent vectors concretely by using any chart that covers x.")

#text("To be somewhat informal, given any point ")#mi("x \\in M")#text(" and tangent vector ")#mi("v \\in T_x M")#text(", one can define a trajectory of points ")#mi("x + tv + O(t^2) \\in M")#text(" for all “infinitesimal” t, which is only defined up to an error of ")#mi("O(t^2)")#text(" (as measured, for instance, in some coordinate chart), but whose derivative at ")#mi("t=0")#text(" is equal to v. Thus, while the global manifold M need not have any reasonable notion of vector addition, we do have this infinitesimal notion of translation by a tangent vector which is well-defined up to second-order errors.")

#text("Given a tangent vector ")#mi("v \\in T_x M")#text(" and a smooth function ")#mi("f \\in C^\\infty(M)")#text(", we can define the ")#link("http://en.wikipedia.org/wiki/Directional_derivative")[#text("directional derivative")]#text(" ")#mi("\\nabla_v f(x)")#text(" by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\nabla_v f(x) := \\lim_{t \\to 0} \\frac{f(x+vt+O(t^2)) - f(x)}{t}")]]

#text("(or, a bit more formally, ")#mi("\\nabla_v f(x) = \\frac{d}{dt} f(\\gamma(t))")#text(" for any curve ")#mi("\\gamma: (-\\varepsilon, \\varepsilon) \\to M")#text(" with ")#mi("\\gamma(0)=x")#text(" and ")#mi("\\gamma^{\\prime}(0)=v")#text("). This is a linear functional on ")#mi("C^\\infty(M)")#text(" which annihilates constants and obeys the ")#link("http://en.wikipedia.org/wiki/Leibniz_rule_%28generalized_product_rule%29")[#text("Leibniz rule")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\nabla_v(fg)(x) = f(x) \\nabla_v g(x) + \\nabla_v f(x) g(x).")]]

#text("Conversely, one can ")#emph[#text("define")]#text(" the tangent space ")#mi("T_x V")#text(" to be the space of all linear functionals on ")#mi("C^\\infty(M)")#text(" with the above two properties, though we will not need to do so here.")

#text("A section ")#mi("X \\in \\Gamma(TM)")#text(" of M is known as a ")#link("http://en.wikipedia.org/wiki/Vector_field")[#text("vector field")]#text("; it assigns a tangent vector ")#mi("X(x) \\in T_x M")#text(" to each point ")#mi("x \\in M")#text(". A vector field X determines a ")#emph[#text("first-order differential operator")]#text(" ")#mi("\\nabla_X: C^\\infty(M) \\to C^\\infty(M)")#text(", defined by setting ")#mi("\\nabla_X f(x) := \\nabla_{X(x)} f(x)")#text(". From (2), we see that ")#mi("\\nabla_X")#text(" is a ")#link("http://en.wikipedia.org/wiki/Differential_algebra")[#text("derivation")]#text(", i.e. it is linear over ")#mi("{\\Bbb R}")#text(" and obeys the Leibniz rule")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\nabla_X (fg) = f \\nabla_X g + (\\nabla_X f) g.")]]

#text("Conversely, one can easily show that every derivation on ")#mi("C^\\infty(M)")#text(" arises uniquely in this manner. This provides a convenient means to define new types of vector fields. For example, if X and Y are two vector fields, one can easily see (from (3)) that the commutator ")#mi("{}[\\nabla_X, \\nabla_Y] := \\nabla_X \\nabla_Y - \\nabla_Y \\nabla_X")#text(" is also a derivation, and must thus be given by another vector field [X,Y], thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\nabla_X \\nabla_Y f - \\nabla_Y \\nabla_X f - \\nabla_{[X,Y]} f = 0")]]

#text("for all vector fields X, Y and all scalar fields f.")

#strong[#text("Example 2.")]#text(" Suppose we have a local coordinate chart ")#mi("\\phi: U \\to V \\subset {\\Bbb R}^d")#text(". The standard first-order differential operators ")#mi("\\frac{d}{dx^1},\\ldots,\\frac{d}{dx^d}")#text(" induced by the coordinates ")#mi("x^1,\\ldots,x^d")#text(" on ")#mi("{\\Bbb R}^d")#text(" can be viewed as vector fields, and pulled back via ")#mi("\\phi")#text(" to vector fields ")#mi("\\phi^* \\frac{d}{dx^1}, \\ldots, \\phi^* \\frac{d}{dx^d}")#text(" on U. These in fact form a ")#link("http://en.wikipedia.org/wiki/Frame_bundle")[#text("frame")]#text(" for U since they span the tangent space at every point. Since ")#mi("\\frac{d}{dx^i}")#text(" and ")#mi("\\frac{d}{dx^j}")#text(" commute in ")#mi("{\\Bbb R}^d")#text(", we see that ")#mi("{}[ \\phi^* \\frac{d}{dx^i}, \\phi^* \\frac{d}{dx^j} ] = 0")#text(". ")#mi("\\diamond")

#strong[#text("Exercise 1.")]#text(" Show that the map ")#mi("(X, Y) \\mapsto [X,Y]")#text(" endows the space ")#mi("\\Gamma(TM)")#text(" of vector fields with the structure of an abstract ")#link("http://en.wikipedia.org/wiki/Lie_algebra")[#text("Lie algebra")]#text(". Also establish the Leibniz rule")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("{}[X, fY] = (\\nabla_X f) Y + f [X,Y]")]]

#text("for all ")#mi("X, Y \\in \\Gamma(TM)")#text(" and ")#mi("f \\in C^\\infty(M)")#text(". ")#mi("\\diamond")

#text("Various operations on finite-dimensional vector spaces generalise easily to vector bundles. For instance, every finite-dimensional vector space V has a ")#link("http://en.wikipedia.org/wiki/Dual_space")[#text("dual")]#text(" ")#mi("V^*")#text(", and similarly every vector bundle V also has a dual bundle ")#mi("V^*")#text(", whose fibres ")#mi("V_x^*")#text(" are the dual to the fibres ")#mi("V_x")#text(" of V; one can also view ")#mi("V^*")#text(" as the space of ")#mi("C^\\infty(M)")#text("-linear functionals from V to ")#mi("C^\\infty(M)")#text(". Similarly, given two vector bundles ")#mi("V, W")#text(" over M, one can define the ")#link("http://en.wikipedia.org/wiki/Direct_sum")[#text("direct sum")]#text(" ")#mi("V \\oplus W")#text(", the ")#link("http://en.wikipedia.org/wiki/Tensor_product")[#text("tensor product")]#text(" ")#mi("V \\otimes W")#text(", the space ")#mi("\\text{Hom}(V,W)")#text(" of fibre-wise linear transformations from V to W, the ")#link("http://en.wikipedia.org/wiki/Symmetric_algebra")[#text("symmetric powers")]#text(" ")#mi("\\text{Sym}^k(V)")#text(" and ")#link("http://en.wikipedia.org/wiki/Exterior_power")[#text("exterior powers")]#text(" ")#mi("\\bigwedge^k(V)")#text(", and so forth. The construction of all of these concepts is straightforward but rather tedious, and will be omitted here.")

#text("Applying these constructions to the tangent bundle TM, one gets a variety of useful bundles for doing Riemannian geometry:")

#list(
[#text("The bundle ")#mi("T^* M := (TM)^*")#text(" is the ")#emph[#link("http://en.wikipedia.org/wiki/Cotangent_bundle")[#text("cotangent bundle")]]#text("; elements of ")#mi("T^*_x M")#text(" are ")#emph[#text("cotangent vectors")]#text(".")],
[#text("Sections of ")#mi("\\bigwedge^k(T^* M)")#text(" are known as ")#link("http://en.wikipedia.org/wiki/Differential_form")[#emph[#text("k-forms")]]#text(".")],
[#text("Sections of ")#mi("(TM)^{\\otimes k} \\otimes (T^* M)^{\\otimes l}")#text(" are known as ")#emph[#text("rank (k,l) tensor fields")]#text(", and individual elements of this bundle are ")#emph[#text("rank (k,l) ")#link("http://en.wikipedia.org/wiki/Tensor")[#text("tensors")]]#text(". Many tensors of interest obey various symmetry or antisymmetry properties, for instance k-forms are totally anti-symmetric rank (0,k) tensors. (To fully enumerate the various symmetry properties available to tensors is essentially equivalent to the finite-dimensional ")#link("http://en.wikipedia.org/wiki/Representation_theory")[#text("representation theory")]#text(" of the ")#link("http://en.wikipedia.org/wiki/Permutation_group")[#text("permutation group")]#text(", which is a beautiful and important subject but will not be discussed here.)")]
)

#text("It is convenient to use ")#link("http://en.wikipedia.org/wiki/Abstract_index_notation")[#text("abstract index notation")]#text(", denoting rank (k,l) tensor fields using k superscripted Greek indices and l subscripted Greek indices, thus for instance ")#mi("\\text{Riem} = \\text{Riem}_{\\alpha \\beta \\gamma}^\\delta")#text(" denotes a rank (1,3) tensor. One should think of these indices as placeholders; if one chooses a ")#link("http://en.wikipedia.org/wiki/Frame_bundle")[#text("frame")]#text(" ")#mi("(e_a)_{a \\in A}")#text(" for the tangent bundle (i.e. a collection of vector fields which form a basis for the tangent space at every point), which induces the associated ")#link("http://en.wikipedia.org/wiki/Dual_basis")[#text("dual frame")]#text(" ")#mi("(e^a)_{a \\in A}")#text(" for the cotangent bundle, then this notation can be viewed as describing the coefficients of the tensor in terms of the basis generated by such frames, thus for instance")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\text{Riem} = \\sum_{a,b,c,d \\in A} \\text{Riem}_{abc}^d e^a \\otimes e^b \\otimes e^c \\otimes e_d.")]]

#text("But it is perhaps better to view a tensor such as ")#mi("\\text{Riem}_{\\alpha \\beta \\gamma}^\\delta")#text(" as existing independently of any choice of frame, in which case the labels ")#mi("\\alpha, \\beta, \\gamma, \\delta")#text(" are abstract placeholders.")

#strong[#text("Example 3. ")]#text(" We continue Example 2. A local coordinate chart ")#mi("\\phi: U \\to {\\Bbb R}^d")#text(" generates a (local) frame ")#mi("e_a := \\phi^* \\frac{d}{dx^a}")#text(" with an associated dual frame ")#mi("e^a := \\phi^*(dx^a)")#text(". These frames can be slightly easier to work with for computations than general frames, because we automatically have ")#mi("{}[e_a,e_b] = 0")#text(" as already noted in Example 2. On the other hand, it is often convenient to work in frames that don’t come from coordinate charts in order to obtain other good properties; in particular, it is very convenient to work in ")#link("http://en.wikipedia.org/wiki/Orthonormal_frame")[#emph[#text("orthonormal")]#text(" frames")]#text(", which are usually unavailable if one restricts attention to frames arising from coordinate charts. ")#mi("\\diamond")

#text("We use the usual (and very handy) ")#link("http://en.wikipedia.org/wiki/Einstein_summation_convention")[#text("Einstein summation convention")]#text(": repeated indices (with each repeated index appearing exactly once as a superscript and once as a subscript) are implicitly summed over a choice of frame (the exact choice is not important). For instance, the rank (0,4) tensor ")#mi("X_{\\alpha \\beta \\sigma \\mu} := \\text{Riem}_{\\alpha \\beta \\gamma}^\\delta \\text{Riem}_{\\delta \\sigma \\mu}^\\gamma")#text(" is defined to be the tensor which is given by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("X_{absm} = \\sum_{g,d \\in A} \\text{Riem}_{abg}^d \\text{Riem}_{dsm}^g")]]

#text("for any choice of frame ")#mi("(e_a)_{a \\in A}")#text(" (one can easily verify that this definition is independent of the choice of frame). We will also apply this summation convention when the Greek labels are replaced with concrete counterparts arising from a frame, thus for instance we can now abbreviate (6) as")

#align(center)[#mi("\\text{Riem} = \\text{Riem}_{abc}^d e^a \\otimes e^b \\otimes e^c \\otimes e_d")#text(". (6′)")]

#heading(level: 1)[#text("— Connections —")]

#text("We have seen that vector fields ")#mi("X \\in \\Gamma(TM)")#text(" allow us to differentiate scalar functions ")#mi("f \\in C^\\infty(M)")#text(" to obtain a differentiated function ")#mi("\\nabla_X f")#text(". Furthermore, this concept obeys the Leibniz rule (3), and is linear over ")#mi("C^\\infty(M)")#text(" in X, or in other words")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\nabla_{gX+Y} f = g \\nabla_X f + \\nabla_Y f")]]

#text("for all ")#mi("g \\in C^\\infty(M)")#text(" and ")#mi("X, Y \\in \\Gamma(TM)")#text(". As a consequence, one can interpret ")#mi("X \\mapsto \\nabla_X f")#text(" as a ")#mi("C^\\infty(M)")#text("-linear functional on ")#mi("\\Gamma(TM)")#text(", which is identified with a section ")#mi("df \\in \\Gamma(T^* M)")#text(" of the cotangent bundle, thus ")#mi("\\nabla_X f = df(X)")#text(".")

#text("Now suppose one wants to differentiate ")#mi("\\nabla_X f")#text(", where ")#mi("f \\in \\Gamma(V)")#text(" is now a section of a bundle V. It turns out that there is now more than one good notion of differentiation. Each such notion can be formalised by the concept of a (linear) ")#link("http://en.wikipedia.org/wiki/Affine_connection")[#text("connection")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1.")]#text(" A ")#emph[#text("connection")]#text(" ")#mi("\\nabla")#text(" on a bundle V is an assignment of a section ")#mi("\\nabla_X f \\in \\Gamma(V)")#text(" (the ")#emph[#link("http://en.wikipedia.org/wiki/Covariant_derivative")[#text("covariant derivative")]]#text(" of f in the direction X via the connection ")#mi("\\nabla")#text(") to each vector field ")#mi("X \\in \\Gamma(TM)")#text(" and section ")#mi("f \\in \\Gamma(V)")#text(", in such a way that ")#mi("(f,X) \\mapsto \\nabla_X f")#text(" is bilinear in f and X, that the Leibniz rule (3) is obeyed for ")#mi("f \\in C^\\infty(M)")#text(" and ")#mi("g \\in \\Gamma(V)")#text(" (or vice versa), and the linearity rule (8) is obeyed for all ")#mi("g \\in C^\\infty(M)")#text(" and ")#mi("X,Y \\in \\Gamma(TM)")#text(".")

#text("If ")#mi("f \\in \\Gamma(V)")#text(" is such that ")#mi("\\nabla_X f = 0")#text(" for all vector fields X, we say that f is ")#text("parallel ")#text("to the connection ")#mi("\\nabla")#text(".")

#text("A connection on the tangent bundle TM is known as an ")#link("http://en.wikipedia.org/wiki/Affine_connection")[#emph[#text("affine connection")]]#text(".")
]

#strong[#text("Remark 4. ")]#text(" Informally, a connection assigns an infinitesimal linear isomorphism ")#mi("\\phi_v: V_x \\to V_{x+v}")#text(" (the ")#link("http://en.wikipedia.org/wiki/Parallel_transport")[#text("parallel transport ")]#text("map) to each infinitesimal tangent vector ")#mi("v \\in V")#text(", in a manner which is linear in v for fixed x. The connection between this informal definition and the above formal one is given by the formula ")#mi("\\nabla_X f(x) = \\lim_{t \\to 0} \\frac{\\phi_{t X(x)}^{-1}(f(x+tX(x))) - f(x)}{t}")#text(". One can make this informal definition more precise (e.g. using non-standard analysis) but we will not do so here. An alternate definition of a connection is as a complementary subbundle to the ")#link("http://en.wikipedia.org/wiki/Vertical_bundle")[#text("vertical bundle")]#text(" ")#mi("\\biguplus_{x \\in M} TV_x")#text(" in TV, known as a ")#link("http://en.wikipedia.org/wiki/Horizontal_bundle")[#text("horizontal bundle")]#text(", obeying some additional linearity conditions in the vertical variable. ")#mi("\\diamond")

#text("Once one has a connection on a bundle V, one automatically can define a connection on the dual bundle ")#mi("V^*")#text(" and more generally on tensor powers ")#mi("V^{\\otimes k} \\otimes (V^*)^{\\otimes l}")#text(", by enforcing all possible instances of the Leibniz rule, e.g.")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\nabla_X(f^{\\alpha \\beta}_\\gamma g^{\\gamma}_{\\delta}) = (\\nabla_X f^{\\alpha \\beta}_\\gamma) g^\\gamma_\\delta + f^{\\alpha \\beta}_\\gamma \\nabla_X g^\\gamma_\\delta")]]

#text("for all rank (2,1) tensors f and rank (1,1) tensors g. (It is a straightforward but tedious task to verify that all the Leibniz rules are consistent with each other, and that (9) and its relatives uniquely define a connection on every tensor power of V.) In particular, any connection on the tangent bundle (which is the case of importance in Riemannian geometry) naturally induces a connection on the cotangent bundle and the bundle of rank (k,l) tensors.")

#text("Here it is important to note that the indices are abstract, rather than corresponding to some frame: for instance, if ")#mi("\\nabla")#text(" is a connection on the tangent bundle TM, then after choosing a frame ")#mi("(e_a)_{a \\in A}")#text(", it is usually ")#emph[#text("not")]#text(" the case that the coefficient ")#mi("(\\nabla_X f)^a")#text(" of a vector field ")#mi("f \\in \\Gamma(TM)")#text(" at a is equal to the derivative ")#mi("\\nabla_X (f^a)")#text(" of that component of f. Instead, one has a relationship of the form")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("(\\nabla_X f)^a = \\nabla_X (f^a) + \\Gamma^a_{bc} X^b f^c")]]

#text("where for each ")#mi("a,b,c")#text(", the ")#link("http://en.wikipedia.org/wiki/Christoffel_symbol")[#text("Christoffel symbol")]#text(" ")#mi("\\Gamma^a_{bc} := e^a(\\nabla_{e_b} e_c)")#text(" of the connection relative to the frame ")#mi("(e_a)_{a \\in A}")#text(" is a smooth function on M. It is important to note that Christoffel symbols are ")#emph[#text("not")]#text(" tensors, because the expression ")#mi("\\Gamma^a_{bc} e_a \\otimes e^b \\otimes e^c")#text(" turns out to depend on the choice of frame.")

#text("Using the Leibnitz rule repeatedly, it is not hard to use (10) to give a formula for the components of derivatives of other tensors, e.g.")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("(\\nabla_X \\omega)_a = \\nabla_X (\\omega_a) - \\Gamma^c_{ba} X^b \\omega_c")]]

#text("for any 1-form ")#mi("\\omega")#text(",")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("(\\nabla_X g)_{ab} = \\nabla_X (g_{ab}) - \\Gamma^c_{da} X^d g_{cb} - \\Gamma^c_{db} X^d g_{ac}")]]

#text("for any rank (0,2) tensor g, and so forth.")

#text("We have remarked that Christoffel symbols are not tensors. On the other hand, because ")#mi("\\nabla_X f")#text(" is linear in X, we can legitimately define a tensor field ")#mi("\\nabla_\\alpha f")#text(", which is a section of ")#mi("T^* M \\otimes V \\equiv \\text{Hom}(TM, V)")#text(", thus ")#mi("\\nabla_X f = X^\\alpha \\nabla_\\alpha f")#text(". It is also possible to express the ")#emph[#text("difference")]#text(" of two connections as a tensor:")

#strong[#text("Exercise 2. ")]#text("Let ")#mi("\\nabla, \\nabla^{\\prime}")#text(" be two connections on TM. Show that there exists a unique rank (1,2) tensor ")#mi("\\Gamma^\\alpha_{\\beta \\gamma} = \\nabla^{\\prime} - \\nabla")#text(" such that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\nabla^{\\prime}_\\beta f^\\alpha - \\nabla_\\beta f^\\alpha = \\Gamma^\\alpha_{\\beta \\gamma} f^\\gamma")]]

#text("for all vector fields ")#mi("f^\\alpha")#text(". Now interpret the Christoffel symbol ")#mi("\\Gamma^a_{bc}")#text(" of a connection ")#mi("\\nabla")#text(" on TM relative to a frame ")#mi("e = (e_a)_{a \\in A}")#text(" as the difference ")#mi("\\nabla - \\nabla^{(e)}")#text(" of that connection with the ")#emph[#text("flat connection")]#text(" ")#mi("\\nabla^{(e)}")#text(" induced by the trivialisation of the tangent bundle induced by that frame. ")#mi("\\diamond")

#text("Let ")#mi("\\nabla")#text(" be a connection on TM. We say that this connection is ")#emph[#text("torsion-free")]#text(" if we have the pleasant identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\nabla_\\alpha \\nabla_\\beta f = \\nabla_\\beta \\nabla_\\alpha f")]]

#text("(cf. ")#link("http://en.wikipedia.org/wiki/Symmetry_of_second_derivatives")[#text("Clairaut’s theorem")]#text(") for all scalar fields ")#mi("f \\in C^\\infty(M)")#text(", or in other words that the ")#link("http://en.wikipedia.org/wiki/Hessian_matrix")[#text("Hessian")]#text(" ")#mi("\\text{Hess}(f)_{\\alpha \\beta} := \\nabla_\\alpha \\nabla_\\beta f")#text(" of f is a symmetric rank (0,2) tensor.")

#strong[#text("Exercise 3.")]#text(" Show that ")#mi("\\nabla")#text(" is torsion-free if and only if")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("{}[X,Y]^\\alpha = X^\\beta \\nabla_\\beta Y^\\alpha - Y^\\beta \\nabla_\\beta X^\\alpha")]]

#text("for all vector fields X, Y (or in coordinate-free notation, ")#mi("{}[X,Y] = \\nabla_X Y - \\nabla_Y X")#text("). ")#mi("\\diamond")

#strong[#text("Remark 5. ")]#text(" Roughly speaking, the torsion-free connections are those which have a good notion of an infinitesimal ")#emph[#text("parallelogram")]#text(" with corners ")#mi("x, x+tv+O(t^2), x+tw+O(t^2), x+tv+tw+O(t^2)")#text(" for some infinitesimal t, such that each edge is the parallel transport of the opposing edge to error ")#mi("O(t^3)")#text(". (Without the torsion-free hypothesis, the error is merely ")#mi("O(t^2)")#text(".) ")#mi("\\diamond")

#text("It would be nice if (14) extended to tensor fields f. This is true for flat connections, but false in general. The defect in (14) for such fields is measured by the ")#emph[#link("http://en.wikipedia.org/wiki/Curvature_form")[#text("curvature tensor")]]#text(" ")#mi("R \\in \\Gamma( \\text{Hom}( \\bigwedge^2 T M, \\text{Hom}(TM, TM) ) )")#text(" of the connection ")#mi("\\nabla")#text(", defined by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\nabla_X \\nabla_Y Z - \\nabla_Y \\nabla_X Z - \\nabla_{[X,Y]} Z =: R(X,Y) Z")]]

#text("for all vector fields X,Y,Z (cf. (4)). One easily sees that R is indeed a section of ")#mi("\\text{Hom}( \\bigwedge^2 T M, \\text{Hom}(TM, TM) )")#text(" and can thus be viewed as a rank (1,3) tensor.")

#strong[#text("Exercise 4. ")]#text(" If ")#mi("\\nabla")#text(" is a torsion-free connection on TM, and ")#mi("R_{\\alpha \\beta \\gamma}^\\delta")#text(" is the tensor form of the curvature R, defined by requiring that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("(R(X,Y) Z)^\\delta = R_{\\alpha \\beta \\gamma}^\\delta X^\\alpha Y^\\beta Z^\\gamma,")]]

#text("then show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\nabla_\\alpha \\nabla_\\beta X^\\delta - \\nabla_\\beta \\nabla_\\alpha X^\\delta = R_{\\alpha \\beta \\gamma}^\\delta X^\\gamma")]]

#text("for all vector fields ")#mi("X^\\delta")#text(". What is the analogue of (18) if ")#mi("X^\\delta")#text(" is replaced by a rank (k,l) tensor? ")#mi("\\diamond")

#text("Connections describe a way to transport tensors as one moves from point to point in the manifold. There is another way to transport tensors, which is induced by diffeomorphisms ")#mi("\\phi: M \\to M")#text(" of the base manifold; this transportation procedure maps points ")#mi("x \\in M")#text(" to points ")#mi("\\phi(x) \\in M")#text(", maps tangent vectors ")#mi("v \\in T_x M")#text(" to tangent vectors ")#mi("\\phi_*(v) \\in T_{\\phi(x)} M")#text(" (defined by requiring that the chain rule ")#mi("\\frac{d}{dt} (\\phi\\circ \\gamma) = \\phi_* (\\frac{d}{dt} \\gamma)")#text(" hold for all curves ")#mi("\\gamma")#text(") and then maps other tensors in the unique manner consistent with the tensor operations (e.g. ")#mi("\\phi_*(v \\otimes w) = \\phi_*(v) \\otimes\\phi_*(w)")#text("). This procedure is important for describing symmetries of tensor fields (consider, for instance, what it means for the vector field ")#mi("(y,-x)")#text(" in ")#mi("{\\Bbb R}^2")#text(" to be invariant under rotations around the origin). To relate this diffeomorphism transport to infinitesimal differential geometry, though, we have to look at an ")#emph[#text("infinitesimal")]#text(" diffeomorphism, which we can view as the derivative ")#mi("\\frac{d}{dt} \\phi_t|_{t=0}")#text(" of a smoothly varying family ")#mi("\\phi_t")#text(" of diffeomorphisms, with ")#mi("\\phi_0")#text(" equal to the identity. By chasing all the definitions we see that ")#mi("\\frac{d}{dt} \\phi_t|_{t=0}")#text(" is just a vector field X. The infinitesimal rate of change ")#mi("\\frac{d}{dt} \\phi_*(v)|_{t=0}")#text(" of a tensor field v under this diffeomorphism is known as the ")#link("http://en.wikipedia.org/wiki/Lie_derivative")[#emph[#text("Lie derivative")]]#text(" ")#mi("{\\mathcal L}_X v")#text(" of v with respect to the vector field X (it does not depend on any aspect of ")#mi("\\phi")#text(" other than its infinitesimal vector field). On scalars f, it agrees with directional derivative")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("{\\mathcal L}_X f = \\nabla_X f,")]]

#text("while on vector fields Y, it agrees with the commutator:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("{\\mathcal L}_X Y = [X,Y],")]]

#text("and its action on all other tensors can be given by the Leibniz rule (as is the case for connections). It should be emphasised, though, that the Lie derivative is ")#emph[#text("not")]#text(" a connection, because it is not linear (over ")#mi("C^\\infty(M)")#text(") in X; ")#mi("{\\mathcal L}_{fX} w \\neq f {\\mathcal L}_X w")#text(" in general.")

#heading(level: 1)[#text("— Riemannian manifolds and curvature tensors —")]

#text("We now specialise our attention from smooth manifolds to our main topic of interest, namely ")#link("http://en.wikipedia.org/wiki/Riemannian_manifold")[#text("Riemannian manifolds")]#text(". Informally, a Riemannian manifold is a manifold equipped with notions of length, angle, area, etc. which are infinitesimally isomorphic at every point to the corresponding notions in Euclidean space. In Euclidean space, all these geometric notions can be defined in terms of a positive definite inner product, and Riemannian manifolds are similarly founded on a positive definite ")#emph[#text("Riemannian metric")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2.")]#text(" A ")#emph[#text("Riemannian manifold")]#text(" (M,g) is a smooth manifold M, together with a ")#emph[#link("http://en.wikipedia.org/wiki/Riemannian_manifold#Riemannian_metrics")[#text("Riemannian metric")]]#text(" ")#mi("g = g_{\\alpha \\beta}")#text(" on M, i.e. a section of ")#mi("\\text{Sym}^2( T^* M )")#text(" which is positive definite in the sense that ")#mi("g(v,w) := \\langle v,w \\rangle_{g(x)} := g_{\\alpha \\beta}(x) v^\\alpha w^\\beta")#text(" is a positive-definite inner product on ")#mi("T_x M")#text(" for every point x.")
]

#text("We now use the metric g to build several other tensors of interest. Firstly, we have the inverse metric ")#mi("g^{-1} = g^{\\alpha \\beta}")#text(", which is the unique rank (2,0) tensor that inverts the (0,2) tensor g in the sense that ")#mi("g^{\\alpha \\beta} g_{\\beta \\gamma} = g_{\\gamma \\beta} g^{\\beta \\alpha} = \\delta^{\\alpha}_\\gamma")#text(" is the identity section of ")#mi("\\text{Hom}(TM,TM)")#text("; this tensor is also symmetric and positive-definite. One can use these tensors to raise and lower the indices of other tensors; for instance, given a rank (0,2) tensor ")#mi("\\pi_{\\alpha \\beta}")#text(", one can define the rank (1,1) tensors ")#mi("\\pi_\\alpha^{\\ \\beta} = g^{\\beta \\gamma} \\pi_{\\alpha \\gamma}")#text(" and ")#mi("\\pi_{\\ \\alpha}^{\\beta} = g^{\\beta \\gamma} \\pi_{\\gamma \\alpha}")#text(" and the rank (2,0) tensor ")#mi("\\pi^{\\alpha \\beta} := g^{\\alpha \\gamma} g^{\\beta \\delta} \\pi_{\\gamma \\delta}")#text(". We will generally only use these conventions when there is enough symmetry that there is no danger of ambiguity.")

#strong[#text("Remark 6.")]#text(" All Riemannian manifolds can be viewed extrinsically (locally, at least) as subsets of a Euclidean space, thanks to the famous ")#link("http://en.wikipedia.org/wiki/Nash_embedding_theorem")[#text("Nash embedding theorem")]#text(". But we will not need this extrinsic viewpoint in this course. ")#mi("\\diamond")

#text("After the metric, the next fundamental object in Riemannian geometry is the ")#link("http://en.wikipedia.org/wiki/Levi-Civita_connection")[#text("Levi-Civita connection")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_Riemannian_geometry")[#text("Fundamental theorem of Riemannian geometry")]#text(".")]#text(" Let (M,g) be a Riemannian manifold. Then there exists a unique affine connection ")#mi("\\nabla")#text(" (which is known as the ")#emph[#text("Levi-Civita connection")]#text(") which is torsion-free and ")#emph[#text("respects")]#text(" the metric g in the sense that ")#mi("\\nabla g = 0")#text(".")
]

#strong[#text("Exercise 5. ")]#text("Prove this theorem. (Hint: one can either (a) use abstract index notation and study expressions such as ")#mi("\\nabla_\\alpha X^\\beta")#text(", (b) use coordinate-free notation and study expressions such as ")#mi("g( \\nabla_X Y, Z )")#text(", or (c) use local coordinates (e.g. use a frame ")#mi("e_a := \\phi^* \\frac{d}{dx^a}")#text(" arising from a chart ")#mi("\\phi")#text(" as in Example 2) and work with the Christoffel symbols ")#mi("\\Gamma^a_{bc}")#text(". It is instructive to do this exercise in all three possible ways in order to appreciate the equivalence (and relative advantages and disadvantages) between these three perspectives. ")#mi("\\diamond")

#text("Geometrically, the condition ")#mi("\\nabla g = 0")#text(" asserts that parallel transport by the Levi-Civita connection is an isometry. At a computational level, it means (in conjunction with the Leibnitz rule) that covariant differentiation using the Levi-Civita connection commutes with the raising and lowering operations, for instance given a vector field ")#mi("X^\\alpha")#text(" we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("(\\nabla_\\alpha X)_\\beta = g_{\\beta \\gamma} \\nabla_\\alpha X^\\gamma = \\nabla_\\alpha (g_{\\beta \\gamma} X^\\gamma) = \\nabla_\\alpha (X_\\beta)")]]

#text("and so we may safely use raising and lowering operations in the presence of Levi-Civita covariant derivatives without much risk of serious error. We can also raise and lower the covariant derivative itself, defining")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\nabla^\\alpha := g^{\\alpha \\beta} \\nabla_\\beta = \\nabla_\\beta g^{\\alpha \\beta}.")]]

#text("This leads to the ")#emph[#text("covariant Laplacian")]#text(" (or ")#emph[#text("Bochner Laplacian")]#text(")")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\Delta := \\nabla_\\alpha \\nabla^\\alpha = \\nabla^\\alpha \\nabla_\\alpha = g^{\\alpha \\beta} \\nabla_\\alpha \\nabla_\\beta")]]

#text("defined on all tensor fields (for instance, when applied to scalar fields it becomes the ")#link("http://en.wikipedia.org/wiki/Trace_%28linear_algebra%29")[#text("trace")]#text(" of the Hessian, and is known as the ")#link("http://en.wikipedia.org/wiki/Laplace-Beltrami_operator")[#text("Laplace-Beltrami operator")]#text("). When applied to non-scalar fields, the covariant Laplacian differs slightly from the ")#emph[#link("http://en.wikipedia.org/wiki/Laplace-Beltrami_operator#Laplace-de_Rham_operator")[#text("Hodge Laplacian")]]#text(" (or ")#emph[#text("Laplace-de Rham operator")]#text(") by a lower order term which is given by the ")#link("http://en.wikipedia.org/wiki/Weitzenb%C3%B6ck_identity")[#text("Weitzenböck identity")]#text(".")

#text("As discussed earlier, all connections on TM have a curvature tensor in ")#mi("\\text{Hom}( \\bigwedge^2 TM, \\text{Hom}(TM,TM) )")#text(". The curvature of the Levi-Civita connection is known as the ")#emph[#link("http://en.wikipedia.org/wiki/Riemann_curvature_tensor")[#text("Riemann curvature tensor")]]#text(" ")#mi("\\text{Riem} = \\text{Riem}_{\\alpha \\beta \\gamma}^\\delta")#text(", thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\nabla_\\alpha \\nabla_\\beta X^\\delta - \\nabla_\\beta \\nabla_\\alpha X^\\delta = \\text{Riem}_{\\alpha \\beta \\gamma}^\\delta X^\\gamma.")]]

#text("One also writes ")#mi("\\text{Riem}")#text(" in co-ordinate free notation by defining ")#mi("\\text{Riem}(X,Y)Z")#text(" for vector fields X,Y,Z by the formula")

#align(center)[#mi("\\nabla_X \\nabla_Y Z - \\nabla_Y \\nabla_X Z - \\nabla_{[X,Y]} Z = \\text{Riem}(X,Y) Z")#text(" (24′)")]

#text("or equivalently as ")#mi("(\\text{Riem}(X,Y)Z)^\\delta = \\text{Riem}_{\\alpha \\beta \\gamma}^\\delta X^\\alpha Y^\\beta Z^\\gamma")#text(".")

#text("Because ")#mi("\\nabla")#text(" respects g, one eventually deduces from (24) and the Leibniz rule that ")#mi("\\text{Riem}_{\\alpha \\beta \\gamma}^\\delta")#text(" is skew-adjoint in the ")#mi("\\gamma, \\delta")#text(" indices:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\text{Riem}_{\\alpha \\beta \\gamma}^\\delta = - g_{\\gamma \\mu} g^{\\delta \\sigma} \\text{Riem}_{\\alpha \\beta \\sigma}^\\mu.")]]

#text("It is also clearly skew-symmetric in the ")#mi("\\alpha,\\beta")#text(" indices. Also, from the analogue of (24) for 1-forms, i.e.")

#align(center)[#mi("\\nabla_\\alpha \\nabla_\\beta \\omega_\\delta - \\nabla_\\beta \\nabla_\\alpha \\omega_\\delta = -\\text{Riem}_{\\alpha \\beta \\delta}^\\gamma \\omega_\\gamma")#text(". (24”)")]

#text("and the torsion-free nature of the connection, we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\nabla_\\alpha \\nabla_\\beta \\nabla_\\delta f - \\nabla_\\beta \\nabla_\\alpha \\nabla_\\delta f = -\\text{Riem}_{\\alpha \\beta \\delta}^\\gamma \\nabla_\\gamma f")]]

#text("for all scalar fields f. Cyclically summing this in ")#mi("\\alpha,\\beta,\\delta")#text(" we obtain the ")#emph[#text("first Bianchi identity")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\text{Riem}_{\\alpha \\beta \\delta}^\\gamma + \\text{Riem}_{\\beta \\delta \\alpha}^\\gamma + \\text{Riem}_{\\delta \\alpha \\beta}^\\gamma = 0.")]]

#strong[#text("Exercise 6. ")]#text("Show that the above three symmetries of ")#mi("\\text{Riem}")#text(" imply that ")#mi("\\text{Riem}")#text(" is a self-adjoint section of ")#mi("\\text{Hom}( \\bigwedge^2 TM, \\bigwedge^2 TM )")#text(", and that these conditions are in fact equivalent in three and fewer dimensions. (The claim fails in four and higher dimensions; see comments.) ")#mi("\\diamond")

#strong[#text("Exercise 7.")]#text(" By differentiating (24) and cyclically summing, establish the ")#emph[#text("second Bianchi identity")]

#mi("\\nabla_\\mu \\text{Riem}_{\\alpha \\beta \\delta}^\\gamma + \\nabla_\\beta \\text{Riem}_{\\mu \\alpha \\delta}^\\gamma + \\nabla_\\alpha \\text{Riem}_{\\beta \\mu \\delta}^\\gamma = 0")#text(". ")#mi("\\diamond")#text(" (28)")

#strong[#text("Exercise 8.")]#text(" Show that a Riemannian manifold (M,g) is locally isomorphic (as Riemannian manifolds) to Euclidean space if and only if the Riemann curvature tensor vanishes. (Hint: one direction is easy. For the other direction, the quickest way is to apply the ")#link("http://en.wikipedia.org/wiki/Frobenius_theorem_%28differential_topology%29")[#text("Frobenius theorem")]#text(" to obtain a local trivialisation of the tangent bundle which is flat with respect to the Levi-Civita connection.) This illustrates the point that the Riemann curvature captures all the local obstructions that prevent a Riemannian manifold from being flat. (Compare this situation with the superficially similar subject of ")#link("http://en.wikipedia.org/wiki/Symplectic_geometry")[#text("symplectic geometry")]#text(", in which ")#link("http://en.wikipedia.org/wiki/Darboux%27s_theorem")[#text("Darboux’s theorem")]#text(" guarantees that there are no local obstructions whatsoever to a ")#link("http://en.wikipedia.org/wiki/Symplectic_manifold")[#text("symplectic manifold")]#text(" ")#mi("(M,\\omega)")#text(" being flat.) ")#mi("\\diamond")

#text("The Riemann curvature measures the “infinitesimal ")#link("http://en.wikipedia.org/wiki/Monodromy")[#text("monodromy")]#text("” of parallel transport. For our applications we will need to study a slightly different curvature, the ")#emph[#text("Ricci curvature")]#text(" ")#mi("\\text{Ric}_{\\alpha \\beta}")#text(", which measures how much the volume-radius relationship on infinitesimal sectors has been distorted from the Euclidean one. (This will not be obvious presently, as we have not yet defined the volume measure ")#mi("dg")#text(" on a Riemannian manifold.) It is defined as the trace of the Riemannian tensor, or more precisely as")

#mi("\\text{Ric}_{\\alpha \\beta} := \\text{Riem}_{\\gamma \\alpha \\beta}^\\gamma")#text(". (29)")

#text("(One could also contract other indices than these, but due to the various symmetry properties of the Riemann tensor, one ends up with essentially the same tensor as a consequence.) We also write ")#mi("\\text{Ric}(X,Y)")#text(" for ")#mi("\\text{Ric}_{\\alpha \\beta} X^\\alpha Y^\\beta")#text(" when X, Y are vector fields. The symmetries of ")#mi("\\text{Riem}")#text(" easily imply that ")#mi("\\text{Ric}")#text(" is a symmetric rank (0,2) tensor – just like the metric g! This observation will of course be vital for defining ")#link("https://terrytao.wordpress.com/2008/03/12/pcm-article-ricci-flow/")[#text("Ricci flow")]#text(" later. (This observation, as well as a similar observation for the ")#link("http://en.wikipedia.org/wiki/Stress-energy_tensor")[#text("stress-energy tensor")]#text(", was also decisive in leading Einstein to the ")#link("http://en.wikipedia.org/wiki/Einstein_field_equations")[#text("equations of general relativity")]#text(", but that’s a ")#link("http://en.wikipedia.org/wiki/History_of_general_relativity")[#text("whole other story")]#text(".)")

#text("We can take the trace of the Ricci tensor to form the ")#link("http://en.wikipedia.org/wiki/Scalar_curvature")[#text("scalar curvature")]

#mi("R := g^{\\alpha \\beta} \\text{Ric}_{\\alpha \\beta} = g^{\\alpha \\beta} \\text{Riem}_{\\gamma \\alpha \\beta}^{\\gamma}")#text("; (30)")

#text("up to normalisations, R can also be viewed as the trace of the Riemann tensor (viewed as a section of ")#mi("\\text{Hom}(\\bigwedge^2 TM, \\bigwedge^2 TM)")#text("). The scalar curvature measures how the relationship of volume of infinitesimal balls to their radius is distorted by the geometry.")

#text("The relationship between the Riemannian, Ricci, and scalar curvatures depends on the dimension:")

#enum(start: 1, 
[#text("In one dimension, all three curvatures vanish; there are no degrees of freedom.")],
[#text("In two dimensions, the Riemannian and Ricci curvatures are just multiples of the scalar curvature (by some tensor depending algebraically on the metric); there is only one degree of freedom.")],
[#text("In three dimensions, the Riemann tensor is a linear combination of the Ricci curvature (see also Exercise 9 below). On the other hand, the scalar curvature does not control Ricci (or Riemann); the Ricci tensor contains an additional ")#link("http://en.wikipedia.org/wiki/Ricci_curvature#Trace-free_Ricci_tensor")[#text("trace-free component")]#text(". (However, once we start evolving by Ricci flow, we shall see that the ")#emph[#text("Hamilton-Ivey pinching phenomenon")]#text(" will allow us to use the scalar curvature to mostly control Ricci and hence Riemann near singularities.)")],
[#text("In four and higher dimensions, the Riemann tensor is not fully controlled by the Ricci curvature; there is an additional component to the Riemann tensor, namely the ")#link("http://en.wikipedia.org/wiki/Weyl_tensor")[#text("Weyl tensor")]#text(". Similarly, the Ricci curvature is not fully controlled by the scalar curvature.")]
)

#strong[#text("Exercise 9. ")]#text("(Ricci controls Riemann in three dimensions) In three dimensions, suppose that the (necessarily real) eigenvalues of the Riemann curvature at a point x (viewed as an element of ")#mi("\\text{Hom}(\\bigwedge^2 TM, \\bigwedge^2 TM)")#text(") are ")#mi("\\lambda, \\mu, \\nu")#text(". Show that the eigenvalues of the Ricci curvature at x (viewed as an element of ")#mi("\\text{Hom}( TM, TM )")#text(" are ")#mi("\\lambda+\\mu, \\mu+\\nu, \\nu+\\lambda")#text(". Conclude in particular that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#tao-math("\\left\\|\\text{Riem}\\right\\|_g = O( \\left\\|\\text{Ric}\\right\\|_g )", block: true)]]

#text("where we endow the (fibres of the) spaces ")#mi("\\text{Hom}(\\bigwedge^2 TM, \\bigwedge^2 TM)")#text(" and ")#mi("\\text{Hom}( TM, TM )")#text(" with the Hilbert (or ")#link("http://en.wikipedia.org/wiki/Hilbert-Schmidt_operator")[#text("Hilbert-Schmidt")]#text(") structure induced by the metric g. ")#mi("\\diamond")

#strong[#text("Remark 7.")]#text(" The fact that Ricci controls Riemann in three dimensions, without itself degenerating into scalar curvature or zero, seems to explain why Ricci flow is especially powerful in three dimensions; it is still useful, but harder to work with, in two dimensions, useless in one dimension, and too weak to fully control the geometry in four and higher dimensions. It seems to me that the special nature of three dimensions stems from the fact that it is the unique number of dimensions in which 2-forms (which are naturally associated with curvature) are ")#link("http://en.wikipedia.org/wiki/Hodge_dual")[#text("Hodge dual")]#text(" to vector fields (as opposed to scalars, or to higher-rank tensors); this is the same special feature of three dimensions which gives us the ")#link("http://en.wikipedia.org/wiki/Cross_product")[#text("cross product ")]#text("(as opposed to the more general ")#link("http://en.wikipedia.org/wiki/Wedge_product")[#text("wedge product")]#text("). ")#mi("\\diamond")

#text("Because of the variety of curvatures, there are various notions of what it means for a manifold to have “non-negative curvature” at some point.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3.")]#text(" Let x be a point on a Riemannian manifold (M,g). We say that x has")

#enum(start: 1, 
[#emph[#text("non-negative scalar curvature")]#text(" if ")#mi("R(x) \\geq 0")#text(";")],
[#emph[#text("non-negative Ricci curvature")]#text(" if ")#mi("\\text{Ric}(x) \\geq 0")#text(" ")#link("http://en.wikipedia.org/wiki/Positive_definite_bilinear_form")[#text("as a quadratic form")]#text(" on TM, i.e. ")#mi("\\text{Ric}_{\\alpha\\beta}(x) v^\\alpha v^\\beta \\geq 0")#text(" for all vectors ")#mi("v \\in T_x M")#text(";")],
[#emph[#text("non-negative sectional curvature")]#text(" if ")#mi("g( \\text{Riem}(x)(X,Y) X, Y)(x) = \\text{Riem}_{\\alpha\\beta \\gamma}^\\delta(x) X_\\alpha Y_\\beta X^\\gamma Y_\\delta \\geq 0")#text(" for all vectors ")#mi("X, Y \\in T_x M")#text(";")],
[#emph[#text("non-negative Riemann curvature")]#text(" if ")#mi("\\text{Riem}(x) \\geq 0")#text(" as a quadratic form on ")#mi("\\bigwedge^2 TM")#text(", thus ")#mi("\\text{Riem}_{\\alpha \\beta \\gamma}^\\delta(x) \\omega^{\\alpha \\beta}(x) \\omega^{\\gamma}_{\\ \\delta}(x) \\geq 0")#text(" for all two-forms ")#mi("\\omega")#text(".")]
)
]

#text("It is not hard to show that, in arbitrary dimension, 4. implies 3. implies 2. implies 1. In one dimension, these conditions are vacuously true; in two dimensions; these conditions are all equivalent; and in three dimensions, non-negative Riemann curvature is equivalent to non-negative sectional curvature (because every 2-form is the wedge product of two one-forms in this case) but these conditions are otherwise distinct. In four and higher dimensions all of these conditions are distinct. One can also define the analogous notions of positive curvature (or negative curvature, or non-positive curvature) in the usual manner.")

#text("[Geometrically, positive scalar curvature means that infinitesimal balls have slightly less volume than in the Euclidean case; positive Ricci curvature means that infinitesimal sectors have slightly less volume than in the Euclidean case; and positive sectional curvature means that all infinitesimally geodesic two-dimensional surfaces have positive ")#text("gaussian curvature")#text(". I don’t know of a geometrically simple way to describe positive Riemann curvature.]")

#text("A couple lectures from now, we shall compute these curvatures explicitly in a number of model cases (such as that of a ")#link("http://en.wikipedia.org/wiki/Homogeneous_space")[#text("homogeneous space")]#text("). For now, we give a “cartoon” or “schematic” description of these curvatures when viewed in some local coordinate system ")#mi("\\phi")#text(", using the associated frame ")#mi("e_a := \\phi^* \\frac{d}{dx^a}")#text(" as in Example 2 to express all tensors as arrays of numbers. Writing ")#mi("g_{ab} = O(g)")#text(", we thus schematically have the following relationships:")

#enum(start: 1, 
[#text("The Christoffel symbols ")#mi("\\Gamma^a_{bc}")#text(" are schematically of the form ")#mi("O( g^{-1} \\partial g )")#text(". Thus a covariant derivative ")#mi("\\nabla_a w")#text(" of a tensor w looks schematically like ")#mi("O( \\partial w + g^{-1} (\\partial g) w )")#text(", and the Laplacian ")#mi("\\Delta w")#text(" looks like ")#mi("O( g^{-1} \\partial^2 w + g^{-2} (\\partial g) \\partial w + g^{-2} (\\partial^2 g) w + g^{-3} (\\partial g)^2 w)")#text(".")],
[#text("The Riemann curvature tensor ")#mi("\\text{Riem}_{abc}^d")#text(" and the Ricci curvature tensor ")#mi("\\text{Ric}_{ab}")#text(" schematically take the form ")#mi("O( g^{-1} \\partial^2 g + g^{-2} (\\partial g)^2 )")#text(".")],
[#text("The scalar curvature R schematically takes the form ")#mi("O( g^{-2} \\partial^2 g + g^{-3} (\\partial g)^2 )")#text(". (Thus the scalar curvature has the same scaling as the Laplacian.)")]
)

#strong[#text("Remark 8.")]#text(" Note how in all of these expressions, the “number of derivatives” and “number of g’s” stays fixed among all terms in a given expression. This can be viewed as an example of ")#link("http://en.wikipedia.org/wiki/Dimensional_analysis")[#text("dimensional analysis")]#text(" in action, and is useful for catching errors in manipulations with these sorts of expressions. From a more representation-theoretic viewpoint, what is going on is that all of the above expressions have constant ")#link("http://en.wikipedia.org/wiki/Weight_%28representation_theory%29")[#text("weight")]#text(" with respect to the joint (commuting) actions of the dilation operation ")#mi("x^i \\mapsto \\lambda x^i")#text(" on the underlying coordinate chart (which essentially controls the number of derivatives ")#mi("\\partial")#text(" that appear) and the homogeneity operation ")#mi("g \\mapsto cg")#text(" (which, naturally enough, controls the number of g’s that appear). ")#mi("\\diamond")

#text("[")#emph[#text("Update")]#text(", Mar 27: more remarks added; various corrections.]")

#heading(level: 1)[#text("Comments (75)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-691590")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2026")])]

#text("Prof. Tao, In the definition of a d-dimensional manifold M, why would you assume M to be Hausdorff and second countable? What are the technical reasons here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-691592")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2026")])]

#text("I am ")#link("https://chatgpt.com/share/696e6e3a-ec88-800e-934d-efe2745da667")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-691712")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2026")])]

#text("Looking at the AI response is interesting: it hits the standard doubled line as a counterexample (not surprising), but it also makes the following false claim:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Basic theorems fail without Hausdorffness")

#text("Many standard results silently use Hausdorffness:")

#list(
[#text("Closed subsets of compact sets need not be compact")],
[#text("Continuous images of compact sets may fail to be compact")],
[#text("Graphs of functions may fail to be closed")],
[#text("Embedding theorems can break")]
)

#text("For example, in a non-Hausdorff manifold, a smooth function may fail to be determined by its pointwise values in the usual way")
]

#text("The second point is just straight up false, isn’t it? There is no need to have a topological space be compact for continuous images of compact sets to be compact; that’s just a general theorem in topology.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-691713")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2026")])]

#text("Yes, the AI slipped up here (I was not using the higher compute models for this casual question). As a substitute, the AI offered the assertion that continuous bijections between compact sets need not be homeomorphisms if the Hasudorff axiom is dropped.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a99656eb39916dabeb69618cab77a266c3c8971eb0ff53bc92a626c7c6b4ffc2-0fc8ce418f965de8e9c8fb9819259dd4e87598f997745aa91112c73cb0fb193a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Divyanshu Pandey")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-692283")[#strong[#text("Divyanshu Pandey")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2026")])]

#text("Prof. Tao, In the 6th line of paragraph after exercise 5 there seems to be a misprint “chain rule ")#mi("\\frac{d}{dt} (\\phi \\circ \\gamma) = \\phi_{*}\\left(\\frac{d}{dt}\\gamma\\right)")#text(" ” i.e. order of \\phi and \\gamma needs to be reversed.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-692286")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2026")])]

#text("Also, in 5th line after equation (29) should say Ric is a (0,2) tensor.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-693361")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("Prof. Tao, you mentioned it is better to adopt an intrinsic perspective of manifolds in this set of notes. What are the benefits of this “coordinate-free” approach?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-693363")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("I am ")#link("https://claude.ai/share/cfbec2b4-6da9-402f-9371-ad18dd943d64")[#text("outsourcing this question to an AI")]#text(".")

#text("One addendum to the AI-generated answer is that by enforcing the discipline to only use coordinate-free notations, one can significantly reduce the possibility of introducing errors such as sign errors that break coordinate invariance. See also my comments on generally desirable properties of mathematical notation at ")#link("https://mathoverflow.net/questions/366070/what-are-the-benefits-of-writing-vector-inner-products-as-langle-u-v-rangle/366118#366118")[#text("https://mathoverflow.net/questions/366070/what-are-the-benefits-of-writing-vector-inner-products-as-langle-u-v-rangle/366118#366118")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-693787")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2026")])]

#text("The connection on a Riemannian manifold is not unique, and the Levi-Civita connection is a fundamental object. But my question is why do we focus on the Levi-Civita connection here instead of other connections?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-693794")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2026")])]

#text("I am ")#link("https://claude.ai/share/b4dee7bd-9fc9-40f7-8fda-180feff098cc")[#text("outsourcing this question to an AI")]#text(". Basically, the Levi-Civita connection is the canonical choice when there is a preferred metric, but is usually not used when the situation does not come with a preferred metric.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-693802")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2026")])]

#text("The idea is that Riemannian manifolds are described by the metric and tangent space over a single point. How these two objects change as you move from this point to the next being infinitesimally close is then governed by the Levi-Civita connection. To correctly understand Riemannian manifolds, these information comes as a package which frees us from seeing manifolds as being “locally defined by functions embedded in R^n”. More philosophically in the spirit of Klein, instead of describing a manifold as just being a solution to f(x)=0, we rather ask “what are the structures on the manifold and how do they tell a point to move”. Levi-Civita connections encode these pieces of information. As a digression, this implies what are the groups that preserve the solutions of f(x)=0. It doesn’t take long to realise in fact Galois theory inspires this. In short, instead of seeing manifolds as where the points are, we are now seeing manifolds as how can the points move.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-693809")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2026")])]

#text("In this set of notes, some knowledge of Lie theory is mentioned. In the proof of the Poincaré conjecture, is the structure of Lie groups or Lie algebras also a key structure?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-693812")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2026")])]

#text("I am ")#link("https://claude.ai/share/6b69c9ab-0731-48ba-a6e9-982e2befdf1d")[#text("outsourcing this question to an AI")]#text(". (Short answer: no, but for the geometrization conjecture or higher-dimensional followup work, Lie structure is more relevant.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-694038")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2026")])]

#emph[#text("We will be interested in various vector bundles over a smooth manifold M.")]

#text("I think a vector bundle is basically the same thing as a vector space. Thus, why in differential geometry, don’t people use “space” directly? Or rather, why does differential geometry focus on the concept of a ")#emph[#text("bundle")]#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-694042")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2026")])]

#text("A vector bundle is, as a first approximation, a family of vector spaces parameterized by a base space; an individual vector space then corresponds to a vector bundle over a point. In general, bundles are used to describe geometric data (e.g., tangent spaces) that vary (often continuously or smoothly) with one’s choice of base point, so are particularly good for distinguishing “local” goemetric information from “global” ones.")

#text("It can be profitable to think about a bundle itself as a high-dimensional space with a projection map to a base space; with this point of view, a vector bundle becomes a manifold foliated by subspaces that admit vector space structure, although the bundle as a whole need not be a vector space in any natural fashion. But this is only one point of view amongst many, much as how a function ")#mi("f: X \\to Y")#text(" can either be thought of as an element ")#mi("f(x)")#text(" of ")#mi("Y")#text(" parameterized by a base point ")#mi("x \\in X")#text(", or as a graph ")#mi("\\{ (x, f(x)): x \\in X \\}")#text(" in the product space ")#mi("X \\times Y")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-694129")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2026")])]

#text("Prof. Tao,")

#text("It seems that the (first and second) Bianchi identities are often needed in some parts of the Poincaré conjecture (and they also frequently appear in general relativity). But I wonder why would they show up. Thus in Riemannian geometry, what exactly do the Bianchi identities convey?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-694133")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2026")])]

#text("I am ")#link("https://claude.ai/share/2a206299-f7d6-4765-a636-07d0c39b1c3f")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-694139")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2026")])]

#text("Prof. Tao, I am confused about the condition on the Levi-Civita connections: why do the Levi-Civita connections needs to be torsion-free?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-694144")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2026")])]

#text("This is a convenient way to assign a canonical connection (the Levi-Civita connection) to a Riemannian manifold; the torsion-free assumption, together with the requirement ")#mi("\\nabla_\\alpha g_{\\beta \\delta} = 0")#text(" that the metric is parallel to the connection, uniquely determines the Levi-Civita connection.")

#text("One is still free to use other connections than Levi-Civita if one really wants to, but they will generally have worse properties; for instance, the Hessian ")#mi("\\nabla_\\alpha \\nabla_\\beta u")#text(" of a (smooth) function will no longer be guaranteed to be symmetric if one no longer requires the torsion-free property.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e0a3a6e9a298b8a8565bd6b399ea378aa3d7e10839aa2a9d56b32c0e2f090ce-5635bd23a56c9c207a956867ed4fb3b6aa9756c5a19aa5729300bcf0b263cb3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Huzaifa Mumit")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-694149")[#strong[#text("Huzaifa Mumit")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2026")])]

#text("In Remark 1, you mention we won’t use the extrinsic perspective at all. Since the Nash embedding theorem guarantees we could view Riemannian manifolds extrinsically, what are the main advantages of the intrinsic perspective for the Ricci flow proof? Is it primarily because the evolution equations are simpler intrinsically?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-694156")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2026")])]

#text("The non-uniqueness of embeddings is one major reason why they are avoided; as you point out, they make the evolution equations underdetermined which is undesirable for analysis.")

#text("Another reason for avoiding embeddings is similar to how one avoids the use of explicit coordinate systems in modern geometry: it introduces many geometrically irrelevant (and non-invariant) objects into the conceptual framework which can distract from the underlying mathematics. In particular, in contrast with the notation of modern intrinsic geometry, by using extrinsic embeddings it is much easier to accidentally start working with non-intrinsic concepts that are dependent on the choice of embedding rather than on invariants of the manifold, which greatly increases the chance of making mistakes or introducing proof ideas that are unlikely to work.")

#text("One final reason to avoid embeddings is that they can make certain operations, such as connected sum, quotienting by a suitable action, or constructing a universal cover, unnecessarly complicated because the embedding of the output of the operation is not related in any simple fashion to the embedding(s) of the input(s) of the operation. A Klein bottle, for instance, is easy to describe intrinsically (glue the two ends of a cylinder together in an orientation-reversing fashion) but very ugly to represent as an embedded surface in four-dimensional space.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-694164")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2026")])]

#text("Therefore, between intrinsic curvature and extrinsic curvature, does modern geometry also lean more toward intrinsic curvature, just as there is a preference for intrinsic geometric flows mentioned here? For curvature, what is the advantage of adopting the intrinsic perspective?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-694191")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2026")])]

#text("A related question: Why are intrinsic flows (like the Ricci flow) more useful in the Geometrization Conjecture (or the Poincaré Conjecture) than extrinsic flows?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-2/#comment-694192")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2026")])]

#text("The lack of uniqueness referred to my previous answer would be my preferred explanation. Ricci flow is canonical: if one applies a diffeomorphism to the underlying manifold, the Ricci flow transforms by the same diffeomorphism, and the property of being geometrizable is also unchanged by diffeomorphism: everything is consistent. But if one is working with an external flow (e.g., mean curvature flow), changing the embedding changes the flow, but does not change the property of being geometrizable. So now there is a mismatch between the symmetries of the problem and the symmetries of the proposed solution, which is generally speaking a warning light that one is not using the correct solution method. (There are exceptions to this rule of thumb, for instance when one deliberately “breaks” or “spends” a symmetry to fix a favorable gauge, but this generally only works when one is purposefully trading the symmetry in for a specific tactical advantage, rather than just discarding the symmetry for no evident gain.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf535e2e2f8f081c7ea41f9a8d1a90fc556274255a131cf45066749d6fb24d7f-0272796322966bc66d3a685852efdadba6493a33fe71275d4d013a00f360f00b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-27676")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2008")])]

#text("The contribution of Smale to the uniqueness of the diffeomorphism")#linebreak()#text(" class of differentiable structures of S^3 is actually Theorem J (cf. p.")#linebreak()#text(" 393) of his landmark paper on the proof of the Poincare conjecture in")#linebreak()#text(" higher dimensions (S. Smale, “Generalized Poincare Conjecture in")#linebreak()#text(" Dimensions Greater than Four”, Ann. Math. 74 (1961) 391-406).")#linebreak()#text(" There, he proves that there is a finite number of diffeomorphism")#linebreak()#text(" classes of differentiable structures in S^n, n odd, but when it comes")#linebreak()#text(" to the actual uniqueness for S^3, he quotes the result of Munkres.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-27686")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2008")])]

#text("Dear Pedro: thanks for clarifying that point!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of davidspeyer")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-27687")[#strong[#text("davidspeyer")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2008")])]

#text("I am tremendously excited about this series of posts. Therefore, I will celebrate with some nitpicks and questions. :)")

#text("Regarding Exercise 6: In dimension four and above, the first Bianchi identity and the skew symmetry in ")#mi("(\\alpha, \\beta)")#text(", ")#mi("(\\gamma, \\delta)")#text(" are strictly stronger conditions on a ")#mi("(3,1)")#text(" tensor then being a self-adjoint operator from ")#mi("\\bigwedge^2 V")#text(" to itself.")

#text("To see this, work with ")#mi("R_{abcd}=g_{a a^{\\prime}} R^a_{bcd}")#text(". Then the symmetries you refer to are")

#mi("R_{abcd}+R_{bacd}=R_{abcd}+R_{abdc}=0 (1)")#text(" and")

#mi("R_{abcd}+R_{acdb}+R_{adbc}=0 (2)")#text(".")

#text("The condition that ")#mi("R")#text(" be a self-adjoint map from ")#mi("\\bigwedge^2 V")#text(" to itself is condition (1) combined with")

#mi("R_{abcd}=R_{cdab} (3)")

#text("Consider the case where ")#mi("R_{abcd}")#text(" is antisymmetric in all its indices. This satisfies (1) and (3) (the latter because the permutation 3412 is even) but not (2).")

#text("The symmetries above state that ")#mi("R_{abcd}")#text(" lies in ")#mi("S^{22} V")#text(" where ")#mi("S^{22}")#text(" is the (2,2) Schur functor. (Exactly the beautiful and important topic you said you would avoid!) Here are two good ways of thinking about ")#mi("S^{2,2} V")#text(". One is that it is the subspace of ")#mi("Sym^2 \\bigwedge^2 V")#text(" which maps to zero under the natural map to ")#mi("\\bigwedge^4 V")#text(". An equivalent formulation is that ")#mi("Sym^2 \\bigwedge^2 V")#text(" is the space of quadratic polynomials on ")#mi("\\bigwedge^2 V^*")#text(", while ")#mi("S^{22} V")#text(" is the quotient space of ")#mi("Sym^2 \\bigwedge^2 V")#text(" where we identify two quadratic polynomials if they agree on tensors of rank one.")

#text("There is a typo in equation (26).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of davidspeyer")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-27688")[#strong[#text("davidspeyer")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2008")])]

#text("A question regarding the definition of torsion free connections by saying that ")#mi("\\nabla_{a} \\nabla_{b} f= \\nabla_{b} \\nabla_{a} f")#text(". I read this as saying that, if ")#mi("X")#text(" and ")#mi("Y")#text(" are two coordinate vector fields then ")#mi("\\nabla_X \\nabla_Y f = \\nabla_Y \\nabla_X f")#text(". As you say, “any connection on the tangent bundle (which is the case of importance in Riemannian geometry) naturally induces a connection on the cotangent bundle and the bundle of rank (k,l) tensors.” I thought that the connection on (0,0)-forms which was induced in this way was simply ")#mi("\\nabla_X f=Xf")#text(". Nothing else seems consistent with the Liebnitz rule. And, in this case, the requirement above is automatic.")

#text("I do understand the definition by equation (15), so I in some sense know what torsion free connections are, but I don’t understand this way of thinking about them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kestutis Cesnavicius")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-27692")[#strong[#text("Kestutis Cesnavicius")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2008")])]

#text("A small typo: in the comment on the definition of the directional derivative (before “This is a linear functional…”) I believe it should be ")#mi("\\gamma^{\\prime}(0) = v")#text(" instead of ")#mi("\\gamma^{\\prime}(0) = t")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-27697")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2008")])]

#text("Thanks a lot! Very nice exposition.")

#text("In Definition 1, isn’t g a section of V and f a scalar field?")

#text("There is a typo in (26), and a zero missing from (27).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-27698")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2008")])]

#text("Thanks for the corrections! But in definition 1, the Leibnitz rule works both ways (everything here is commutative, as we are not doing noncommutative geometry).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-27699")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2008")])]

#text("Dear David,")

#text("For some reason wordpress classified all your posts as spam; I’ve retrieved them manually, but if you (or anyone else) continues to have problems, please let me know (e.g. by email).")

#text("You’re right about Exercise 6; I’ve amended it accordingly. (I may have issues later in the course distinguishing what is true in three-dimensional Riemannian geometry, with what is true in general, since I will be primarily focused on the former; but please continue to nitpick these issues. :-) )")

#text("As for the torsion-free business, this is a little subtlety in the abstract placeholder notation (see also the discussion near (10)). Given a frame ")#mi("(e_a)_{a \\in A}")#text(", the ab coefficient ")#mi("\\nabla_a \\nabla_b f")#text(" of the Hessian ")#mi("\\nabla_\\alpha \\nabla_\\beta f")#text(" is ")#emph[#text("not")]#text(" just ")#mi("\\nabla_{e_a} \\nabla_{e_b} f")#text(", because the outer derivative ")#mi("\\nabla_\\alpha")#text(" is acting on the vector field ")#mi("\\nabla_\\beta f")#text(" rather than on each component ")#mi("\\nabla_{e_b} f")#text(" separately. Indeed, what one is doing here is first computing the first derivative ")#mi("\\nabla_\\beta f")#text(", which in coordinates is ")#mi("(\\nabla_{e_b} f) e^b_\\beta")#text(" and in differential geometry notation is just df, and then taking the covariant derivative ")#mi("\\nabla_\\alpha \\nabla_\\beta f = \\nabla(df)")#text(" of that, giving the rank (0,2) tensor whose ab component is equal to ")#mi("{}[\\nabla_{e_a} (df)] e_b = \\nabla_{e_a}(\\nabla_{e_b} f) + \\Gamma_{ab}^c \\nabla_{e_c} f")#text(", where ")#mi("\\Gamma_{ab}^c := - (\\nabla_{e_a} e_b) e^c = (\\nabla_{e_a} e^c) e_b")#text(" is the Christoffel symbol of the connection relative to the frame. If the vector fields ")#mi("e_a")#text(" commute with each other (which is for instance the case if they arise from a local coordinate system), the torsion free condition is equivalent to the symmetry ")#mi("\\Gamma_{ab}^c = \\Gamma_{ba}^c")#text(" of the Christoffel symbol.")

#text("It takes a bit of getting used to, but I find abstract placeholder notation to be by far the quickest way to do Riemannian geometry computations; I have trouble getting the d’s and ")#mi("\\iota")#text("‘s and ")#mi("\\neg")#text("‘s and *’s sorted out once I have to deal with rank 4 tensors with various idiosyncratic symmetry properties (which happens a lot in Riemannian geometry) :-) .")

#text("There is some abstract way to interpret abstract placeholder notation as some sort of morphism from an abstract tensor bundle to a concrete one, but I don’t recall exactly how to set it up properly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee1c6342ac1721745a7353468cd3c901d2f73a04aa0acaf218a02ff62ff1eb2d-c7a0c0f4d89df933bff8c10095e5496289ddc8d307ba1797246a4882182011ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dsilvestre")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-27700")[#strong[#text("dsilvestre")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2008")])]

#text("I think on (27) on the first Bianchi identity a “= 0” is missing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91841f5e59201923e09be98a5cf5917591fef164a2a040b79e78d927874dd4bf-c2c4379bfc95793e545279b1b6a44f80c80394352dfb8cc2ea2a9f97264ce0e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-27704")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2008")])]

#text("Dear Prof. Tao,")

#text("Missing from the “Online Resources” section of the course webpage is your own “short story” writeup of Perelman’s proof. Perhaps a link would be appropriate?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ea5e8351bc52b04b984facb313dfb2122bc3ce8edda88d8889e3525e72587c0-8906d1b3c4a21b122a16401ca8fa5747c4e5992900e673f0be4f8b586cfa768e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dylan Thurston")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-27713")[#strong[#text("Dylan Thurston")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2008")])]

#text("Re the definition of torsion-free: the way I understood an expression like ")#mi("\\nabla_\\alpha \\nabla_\\beta f")#text(" was to notice that ")#mi("\\nabla_\\beta f")#text(" is a section of ")#mi("T^*M")#text(", independent of the connection. Then you can differentiate again, using the connection this time, to get a rank (0,2) tensor, which is required to be symmetric.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ea5e8351bc52b04b984facb313dfb2122bc3ce8edda88d8889e3525e72587c0-8906d1b3c4a21b122a16401ca8fa5747c4e5992900e673f0be4f8b586cfa768e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dylan Thurston")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-27714")[#strong[#text("Dylan Thurston")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2008")])]

#text("Hmm, I don’t know how to get math to come out. Perhaps there should be a link to a reference near the Submit button?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-27724")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2008")])]

#text("You have to write “latex ” (without double quotes) just after the first dollar sign of the equation. For example: $ latex R^n$ (remove the first empty space before “latex”) becomes ")#mi("R^n")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-27725")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2008")])]

#text("Thanks for the suggestions! I can’t quite seem to modify the CSS to change the comment box directly, but I put some text about LaTeX just below and to the left of it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 1: Flows on Riemannian manifolds « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-27727")[#strong[#text("285G, Lecture 1: Flows on Riemannian manifolds « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2008")])]

#text("[…] Exercise 1. Show that (12) is consistent with the antisymmetry properties of the Riemann tensor, and with the Bianchi identities, as presented in the previous lecture. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29f6616efa6af27237211ff6a1f90c0be2068900a7fdc4a91a7da3222ae0da9c-7116c3d155a232d696fb77bebe59df9f46911db2e4d84de8e6560fbf4c3aa8a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nobody")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-27733")[#strong[#text("nobody")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2008")])]

#text("Dear Professor Tao,")

#text("What exactly makes a connection as in definition 1 “affine”? I was under the impression that an affine connection was one on the tangent bundle.")

#text("Also, in remark 5, what is the ambiguity in the O(t^3) characterization of torsion-freeness that leads you to say that this is only “roughly speaking”? It seems to me that this would be a perfectly valid alternative definition.")

#text("By the way, if my understanding is correct, the curvature does not measure the monodromy of parallel transport; it only does so infinitesimally. In particular, it is insensitive to the topology (in particular, the fundamental group) of the manifold.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-27736")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2008")])]

#text("Dear nobody,")

#text("Hmm, you’re right. I was confusing “affine connection” with “linear connection”. (Somewhat counterintuitively, the latter is a special case of the former, rather than the other way around.)")

#text("One can make remark 5 more precise but one has to make clearer what it means to transport an edge of length t “by parallel transport” by a distance t up to accuracy ")#mi("O(t^3)")#text(". This can be done, but requires a small amount of care.")

#text("I’ve amended the remark on monodromy to emphasise it is only measuring _infinitesimal_ monodromy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/086fffb5e07bc6794374ab66b785bda9fffab5f3f33bdd6aa42a199d09d101a2-91fbf3eed2d2c362cffe07e05a089b5971e48081078cd2e95a3747e0ac183ef5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Kinyon")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-27741")[#strong[#text("Michael Kinyon")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2008")])]

#text("In the sentence preceding Definition 1, I think “notation” should be “notion”. (When reading it, I flashed on the old joke about differential geometry being the study of properties which are invariant under change of notation.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-27745")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2008")])]

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arbieto")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-27776")[#strong[#text("Arbieto")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2008")])]

#text("Dear Prof. Tao")

#text("I´m quite impressive for your exposition on geometric flows.")

#text("Oh, and I think that there is a typo when you talk about symmetric powers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 2: The Ricci flow approach to the Poincaré conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-27818")[#strong[#text("285G, Lecture 2: The Ricci flow approach to the Poincaré conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2008")])]

#text("[…] structure, and with two manifolds considered equivalent if they are homeomorphic. As mentioned in Lecture 0, in three dimensions it is not difficult to move from the topological category back to the smooth […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 7: Rescaling of Ricci flows and kappa-noncollapsing « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-29240")[#strong[#text("285G, Lecture 7: Rescaling of Ricci flows and kappa-noncollapsing « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2008")])]

#text("[…] one is the minimal scalar curvature . One can check (cf. the dimensional analysis at the end of Lecture 0) that scalar curvature has dimension -2 and is thus subcritical. The quantity , that measures the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285A, Lecture 8: Ricci flow as a gradient flow, log-Sobolev inequalities, and Perelman entropy « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-29316")[#strong[#text("285A, Lecture 8: Ricci flow as a gradient flow, log-Sobolev inequalities, and Perelman entropy « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2008")])]

#text("[…] prove the second identity, differentiate (30) and use the second Bianchi identity (Exercise 7 from Lecture 0).) Use the maximum principle to then conclude that the only compact gradient steady solitons are […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 12: High curvature regions of Ricci flow and κ-solutions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-29836")[#strong[#text("285G, Lecture 12: High curvature regions of Ricci flow and κ-solutions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2008")])]

#text("[…] RIemann curvature is equivalent to that of non-negative sectional curvature; see the discussion in Lecture 0. In any dimension, the conditions of non-negative bounded Riemann curvature imply that R and are […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 13: Li-Yau-Hamilton Harnack inequalities and κ-solutions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-29899")[#strong[#text("285G, Lecture 13: Li-Yau-Hamilton Harnack inequalities and κ-solutions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2008")])]

#text("[…] identities make the Riemann, Ricci, and scalar curvatures are all essentially equivalent (see Lecture 0); in particular one has the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e90a1841c2be185719cd431c2afc1101aba5dc3ebef8c680a6c82773239f8b9-4ecc9bbb92751eb7b02e59973964912e8248c990ebccd806fb112351b323d61f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Weiqi Gao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-29968")[#strong[#text("Weiqi Gao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2008")])]

#text("The definition of ")#mi("{}[\\nabla_X, \\nabla_Y]")#text(" between formulas (3) and (4) contains a formula typo. Shouldn’t it be ")#mi("\\nabla_X\\nabla_Y - \\nabla_Y \\nabla_X")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-29970")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2008")])]

#text("Dear Weiqi: Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 16: Classification of asymptotic gradient shrinking solitons « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-30160")[#strong[#text("285G, Lecture 16: Classification of asymptotic gradient shrinking solitons « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2008")])]

#text("[…] the Ricci tensor is conformal: . Comparing this with the Bianchi identity (equation (28) from Lecture 0) we conclude that , and thus . Thus M has constant sectional curvature and is therefore a round […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-30642")[#strong[#text("The trouble with commuting II « The Pablog")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2008")]

#text("[…] Physics. An excellent review of the basic structures used in Riemannian Geometry may be found on here on Terry Tao’s blog. Possibly related posts: (automatically generated)Living With The […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21aa472f8f494bc91b3f99127ecfb240005ad8fd92924bde9342f28755854eba-7971f5b8170dffe3c80165b7c231573ce5686efec2b955b95c917ec0dd874252.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohammad")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-30877")[#strong[#text("Mohammad")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2008")])]

#text("Dear Prof Tao,")

#text("I think there is a typo in the schematic representation of Laplacian ( number 1 above the Remark 8 ), the second term should be g^-2*(dg)*dw .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-30944")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2008")])]

#text("Dear Mohammad: thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JC")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-30960")[#strong[#text("JC")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2008")])]

#text("Hi, now the formula pointed out by Mohammed doesn’t parse.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-30963")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2008")])]

#text("Oops! Fixed now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of BD")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-31011")[#strong[#text("BD")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2008")])]

#text("The formula pointed out by Mohammad has been corrected wrongly!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-31023")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2008")])]

#text("Ack! Glad to know that people are paying attention, at least.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6ec7d34d1d6bbc60a6bebc0d007032de738a2520e323d64f947957347ce999b-ceac5869a61076cb51b4ecae0129a7326da77d3cf40d023a2d73de1b831bf557.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ahmad")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-32695")[#strong[#text("ahmad")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2008")])]

#text("too high qualified ,u r talended thank u")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of What is a gauge? « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-32705")[#strong[#text("What is a gauge? « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2008")])]

#text("[…] a manner as possible; the precise definition is a little technical (see e.g. my lecture notes for a brief description). Suppose for instance one starts at some location x on the equator of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e09b98d8ff43c625fd1bec55b9e713195e124cfe7588ff649b5b83194ae79b11-da8cd304022fcdc2f84f73382702aec1cdd306a6648270a1b93e23b839bcb870.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Cernea")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-38234")[#strong[#text("Paul Cernea")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2009")])]

#text("Dear Professor Tao,")

#text("First, thanks for posting this lecture series (and in fact the whole blog)! It’s truly illuminating for students like me who are trying to understand Ricci Flow.")

#text("Second, below Definition 3 you give a geometric interpretation of the different kinds of positive curvatures. I think I may have found a typo, but I’m not sure. You write that positive sectional curvature means that all infinitesimally geodesic surfaces have positive mean curvature. I know the analogous statement holds for positive Gaussian curvature. Is it also true for mean curvature?")

#text("Best regards,")#linebreak()#text(" Paul")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-38240")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2009")])]

#text("Ah yes, you’re right, I meant positive Gaussian curvature here, thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-46080")[#strong[#text("Problemy milenijne matematyki – zaczyn do dyskusji « Jaronwoj Blog Warszawa Polska")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2010")]

#text("[…] ")#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/")[#text("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 3: Quasirandom groups, expansion, and Selberg’s 3/16 theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-116199")[#strong[#text("254B, Notes 3: Quasirandom groups, expansion, and Selberg’s 3/16 theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2011")])]

#text("[…] geometry, as well as the functional analysis of Sobolev spaces and distributions. See for instance this blog post for a very brief introduction to Riemannian geometry, and these two previous posts for an […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A mathematical formalisation of dimensional analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-211410")[#strong[#text("A mathematical formalisation of dimensional analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2012")])]

#text("[…] One can also assign dimensions to higher rank tensors, such as matrices, -vectors, or -forms; the notation here becomes rather complicated, but is perhaps best described using abstract index notation. The dimensional consistency of equations involving such tensors then becomes the requirement in abstract index notation that the subscripts and superscripts on the left-hand side of a tensor equation must match those on the right-hand side, after “canceling” any index that appears as both a subscript and a superscript on one side. (Abstract index notation is discussed further in this previous blog post.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymousCoward")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-218363")[#strong[#text("anonymousCoward")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2013")])]

#text("Could you please clarify Exercise 2. Is the expectation to show uniqueness or to show that the difference of two covariant derivatives has the desired transformation property between overlapping charts?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-218366")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2013")])]

#text("The question asks for both existence and uniqueness of the tensor ")#mi("\\Gamma^\\alpha_{\\beta \\gamma}")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-223715")[#strong[#text("Conjectura de Poincaré explicada por Terry Tao | Adsu's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2013")]

#text("[…] en 20 posts de la demostración de la conjetura de Poincaré hecha por Perelman. Enlazo aquí su Lecture 0 que nos puede servir tanto como introducción de los conceptos básicos de la geometría […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f8ce61a9bca39e7003fa7f6f37cf464bb4984a1caa9ae48e7d7f42c799698c1-722c8d2f8d74e8f264b242de54849d279b407ba3d092b682c9f886eea496f7f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-456073")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2015")])]

#text("Hi, huge thanks for this great crash course. A few typos:")#linebreak()#text(" 1) Before Definition 1: an connection -> a connection")#linebreak()#text(" 2) Before (10): Gamma(M) -> Gamma(TM)")#linebreak()#text(" 3) After (14): ref to Clairaut’s theorem should refer to ")#link("http://en.wikipedia.org/wiki/Symmetry_of_second_derivatives")[#text("http://en.wikipedia.org/wiki/Symmetry_of_second_derivatives")]#linebreak()#text(" 4) (26) : exchange Del_alpha and Del_delta in the second summand")#linebreak()#text(" 5) Some lines above Exercice 9: Change (see Exercice 8 below) to (see Exercice 9 below)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-465466")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2016")])]

#text("what is the formula (26)? “formula does not parse”")

#emph[#text("[Not sure why this formula was not parsing before, but it seems to work now -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-465563")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2016")])]

#text("Formula (26) is just formula (24”) with omega replaced by nabla f. You can see the LaTeX for (26) by hovering your mouse over it, but beware that it has a typo (indices on the LHS should be “alpha beta delta – beta alpha delta”) although that shouldn’t cause the parse error.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-487044")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2017")])]

#text("I’ve thought about whether in the informal description of tangent vectors, already ")#mi("o(t)")#text(" would be enough; I mean, this would already determine the derivative at ")#mi("0")#text(", right?")

#emph[#text("[Yes, though as long as the manifold is smooth, there is no real distinction between the two error rates (and for rough manifolds, defining geometric concepts such as curvature can become quite problematic if not done carefully -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1d21ecc16f7adb52d130a639f55434f340ed696e8c4aa9df8b448cb04478763-4dc8b1b98b8b8093d3b2b4ce903e628fd1a8baa5eb608c9851bdc4f5a6c3d102.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qinyu95")]], [#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-488065")[#strong[#text("qinyu95")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2017")])]

#text("Reblogged this on ")#link("https://qinyugong.wordpress.com/2017/10/26/285g-lecture-0-riemannian-manifolds-and-curvature/")[#text("qinyugong")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/comment-page-1/#comment-680572")[#strong[#text("[讲义]黎曼流形入门 – 王俊凯@Physics")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2023")]

#text("[…] 285G, Lecture 0: Riemannian manifolds and curvature […]")
]
