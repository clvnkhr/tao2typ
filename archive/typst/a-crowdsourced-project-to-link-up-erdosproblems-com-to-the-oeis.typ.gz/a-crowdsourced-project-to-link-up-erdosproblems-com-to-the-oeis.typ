// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/08/31/a-crowdsourced-project-to-link-up-erdosproblems-com-to-the-oeis/
// Converted to Typst by tao2typ: "2026-10-14T15:21:07.469473+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A crowdsourced project to link up erdosproblems.com to the OEIS", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A crowdsourced project to link up erdosproblems.com to the OEIS")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 31 August 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/08/31/a-crowdsourced-project-to-link-up-erdosproblems-com-to-the-oeis/")[#text("https://terrytao.wordpress.com/2025/08/31/a-crowdsourced-project-to-link-up-erdosproblems-com-to-the-oeis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Thomas Bloom’s ")#link("https://www.erdosproblems.com/")[#text("erdosproblems.com")]#text(" site hosts nearly a thousand questions that originated, or were communicated by, Paul Erdős, as well as the current status of these questions (about a third of which are currently solved). The site is now a couple years old, and has been steadily adding features, the most recent of which has been a ")#link("https://www.erdosproblems.com/forum")[#text("discussion forum")]#text(" for each individual question. For instance, a discussion I had with Stijn Cambie and Vjeko Kovac on ")#link("https://www.erdosproblems.com/379")[#text("one of these problems")]#text(" recently led to it being solved (and even formalized in Lean!).")

#text("A significantly older site is the ")#link("https://oeis.org/")[#text("On-line Encyclopedia of Integer Sequences (OEIS)")]#text(", which records hundreds of thousands of integer sequences that have some mathematician has encountered at some point. It is a highly useful resource, enabling researchers to discover relevant literature for a given problem so long as they can calculate enough of some integer sequence that is “canonically” attached to that problem that they can search for it in the OEIS.")

#text("A large fraction of problems in the Erdos problem webpage involve (either explicitly or implicitly) some sort of integer sequence – typically the largest or smallest size ")#mi("{f(n)}")#text(" of some ")#mi("{n}")#text("-dependent structure (such as a graph of ")#mi("{n}")#text(" vertices, or a subset of ")#mi("{\\{1,\\dots,n\\}}")#text(") that obeys a certain property. In some cases, the sequence is already in the OEIS, and is noted in the Erdos problem web page. But in a large number of cases, the sequence either has not yet been entered into the OEIS, or it does appear but has not yet been noted on the Erdos web page.")

#text("Thomas Bloom and I are therefore proposing a crowdsourced project to systematically compute the hundreds of sequences associated to the Erdos problems and cross-check them against the OEIS. We have created a ")#link("https://github.com/teorth/erdosproblems")[#text("github repository")]#text(" to coordinate this process; as a by-product, this repository will also be tracking other relevant statistics about the Erdos problem website, such as the current status of formalizing the statements of these problems in the ")#link("https://github.com/google-deepmind/formal-conjectures")[#text("Formal Conjectures Repository")]#text(".")

#text("The main feature of our repository is a ")#link("https://github.com/teorth/erdosproblems/blob/main/README.md#table")[#text("large table")]#text(" recording the current status of each Erdos problem. For instance, ")#link("https://www.erdosproblems.com/3")[#text("Erdos problem #3")]#text(" is currently listed as open, and additionally has the status of linkage with the OEIS listed as “possible”. This means that there are one or more sequences attached to this problem which *might* already be in the OEIS, or would be suitable for submission to the OEIS. Specifically, if one reads ")#link("https://www.erdosproblems.com/3")[#text("the commentary for that problem")]#text(", one finds mention of the functions ")#mi("{r_k(N)}")#text(" for ")#mi("{k=3,4,\\dots}")#text(", defined as the size of the largest subset of ")#mi("{\\{1,\\dots,N\\}}")#text(" without a ")#mi("{k}")#text("-term progression. It is likely that several of the sequences ")#mi("{r_3(N)}")#text(", ")#mi("{r_4(N)}")#text(", etc. are in the OEIS, but it is a matter of locating them, either by searching for key words, or by calculating the first few values of these sequences and then looking for a match. (EDIT: a contributor has noted that the first foursequences appear as ")#link("https://oeis.org/A003002")[#text("A003002")]#text(", ")#link("https://oeis.org/A003003")[#text("A003003")]#text(", ")#link("https://oeis.org/A003004")[#text("A003004")]#text(", and ")#link("https://oeis.org/A003005")[#text("A003005")]#text(" in the OEIS, and the table has been updated accordingly.)")

#text("We have set things up so that new contributions (such as the addition of an OEIS number to the table) can be made by a Github pull request, specifically to modify ")#link("https://github.com/teorth/erdosproblems/blob/main/data/problems.yaml")[#text("this YAML file")]#text(". Alternatively, one can create a Github issue for such changes, or simply leave a comment either on the appropriate Erdos problem forum page, or here on this blog.")

#text("Many of the sequences do not require advanced mathematical training to compute, and so we hope that this will be a good “citizen mathematics” project that can bring in the broader math-adjacent community to contribute to research-level mathematics problems, by providing experimental data, and potentially locating relevant references or connections that would otherwise be overlooked. This may also be a use case for AI assistance in mathematics through generating code to calculate the sequences in question, although of course one should always stay mindful of potential bugs or hallucinations in any AI-generated code, and find ways to independently verify the output. (But if the AI-generated sequence leads to a match with an existing sequence in the OEIS that is clearly relevant to the problem, then the task has been successfully accomplished, and no AI output needs to be directly incorporated into the database in such cases.)")

#text("This is an experimental project, and we may need to adjust the workflow as the project progresses, but we hope that it will be successful and lead to further progress on some fraction of these problems. The comment section of this blog can be used as a general discussion forum for the project, while the github issue page and the erdosproblems.com forum pages can be used for more specialized discussions of specific problems.")

#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/08/31/a-crowdsourced-project-to-link-up-erdosproblems-com-to-the-oeis/#comment-688698")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2025")])]

#text("From past experience with online collaborative projects, it is helpful to have some sort of “dashboard” to measure progress, so I have now placed one at the start of the table. Yesterday there were 56 problems that had been linked to at least one OEIS sequence, together with 393 “possible” problems that could potentially have such a link; thanks to the contributions that have already come in in the last twelve hours or so, these numbers have updated to 60 and 389 respectively. Will be interesting to see how these numbers evolve further…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/31/a-crowdsourced-project-to-link-up-erdosproblems-com-to-the-oeis/#comment-688701")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2025")])]

#text("Maybe the daily response will be an interesting OEIS sequence :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/08/31/a-crowdsourced-project-to-link-up-erdosproblems-com-to-the-oeis/#comment-688703")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2025")])]

#text("Here is a first proof-of-concept demonstration of an actual outcome for this project. There are a number of Erdos problems relating to irrationality of specific series. ")#link("https://chatgpt.com/share/68b7160a-3d4c-800e-a834-415ee9aac2a8“")[#text("I asked an AI to compute several of these series to several decimal places")]#text(", then entered in these decimal strings into the OEIS search bar. I found several hits, which I ")#link("https://github.com/teorth/erdosproblems/commit/89c3a9c977fd40de74c0ea18d30ff258af053ff3")[#text("then uploaded to the project")]#text(". In particular, I linked ")#link("https://www.erdosproblems.com/259")[#text("Erdos problem 259")]#text(" to ")#link("https://oeis.org/A371134")[#text("OEIS A371134")]#text(". In the latter page, there was a reference to a solution to the ")#link("https://doi.org/10.1023/A:1004742930674")[#text("problem by Chen and Ruzsa")]#text(" that was not known to the erdosproblems.com site. So now we can mark that problem as solved!")

#text("I think this type of semi-automated literature search could be a good use case for AI tooling, since the (potentially unreliable) output of such AI tools is only used to locate more reliable human-generated resources, rather than being directly incorporated into the final product.")

#text("EDIT: May as well post some updated statistics. We now have 84 Erdos problems attached to an OEIS sequence, with 370 possible further problems to be linked up.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/31/a-crowdsourced-project-to-link-up-erdosproblems-com-to-the-oeis/#comment-688704")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2025")])]

#text("The link “problem by Chen and Ruzsa” goes to this blog post.")

#emph[#text("[Fixed, thanks -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/31/a-crowdsourced-project-to-link-up-erdosproblems-com-to-the-oeis/#comment-688705")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2025")])]

#text("Partly related to the ")#link("https://www.erdosproblems.com/270")[#text("Problem 270")]#text(" is the sequence ")#link("https://oeis.org/A073016")[#text("https://oeis.org/A073016")]#text(" (for the case f(n)=n)")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/31/a-crowdsourced-project-to-link-up-erdosproblems-com-to-the-oeis/#comment-688711")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2025")])]

#text("Hello Terence. I believe Erdos Problem #822 corresponds to A121048 on the OEIS website. I’m not really used to Github, so hopefully you see this and can add it to the table.")

#text("Erdos #822: ")#link("https://www.erdosproblems.com/822")[#text("https://www.erdosproblems.com/822")]#linebreak()#text("OEIS A121048: ")#link("https://oeis.org/A121048")[#text("https://oeis.org/A121048")]

#emph[#text("[Added, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/31/a-crowdsourced-project-to-link-up-erdosproblems-com-to-the-oeis/#comment-688716")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2025")])]

#link("https://oeis.org/A155085")[#text("https://oeis.org/A155085")]#text(" is related to the question mentioned in the same problem 822. So not directly Erdos question, but related.")

#emph[#text("[I think that meets the bar for relevance; now added. -T]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/31/a-crowdsourced-project-to-link-up-erdosproblems-com-to-the-oeis/#comment-688712")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2025")])]

#text("Hey Terry, thanks for kicking off this crowdsourcing thing—it’s a cool idea to connect Erdős problems with OEIS entries. I’ve always loved how those old puzzles pop up in sequences, like the one with Problem #3 linking to A003002 and that Chen-Ruzsa stuff for #259. Makes me think there are tons of hidden gems waiting to be dug up. If anyone’s crunching numbers for new sequences to submit, I’ve used this math calculator tool at ")#link("https://fcalculator.com/math.html%E2%80%94it's")[#text("https://fcalculator.com/math.html—it's")]#text(" pretty straightforward for quick calcs on factorials or whatever without firing up heavy software.")

#text("Quick idea: Maybe add a basic script example in the GitHub repo for generating sequences? Could help newbies avoid mistakes and cut down on the AI checks.")

#text("Excited to watch the links pile up—aiming for 100 soon?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/08/31/a-crowdsourced-project-to-link-up-erdosproblems-com-to-the-oeis/#comment-688715")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2025")])]

#text("Could you expand on what you mean by “basic script example”? Some of the contributors have also supplied the code they used to locate their sequences (see e.g., this ")#link("https://github.com/teorth/erdosproblems/pull/41")[#text("recent pull request")]#text(" where the Python code was provided), but I am not sure if this is what you meant.")

#text("We’ve had quite a large number of submissions in the last few days; currently 111 problems are now linked to an OEIS, and the number of possible problems still unlinked to any OEIS sequence has dropped down to 343. And we have our ")#link("https://github.com/teorth/erdosproblems/pull/40")[#text("first new sequence submitted to the OEIS")]#text(" which will hopefully get approved there in a few days. At some point we will run out of low-hanging fruit and be left with sequences that are somewhat non-trivial to compute the first few values of, but it looks like we are not yet at that point yet. (I have found for instance that simply entering in key words or key references from an Erdos problem into the OEIS search bar already can lead to some relevant hits even without computing any sequence whatsoever.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8499392cda91fd718607ff3161c88dce42086d2710f835662883590c08459a42-6a14589141b33c369623e2fb346d584cb73a760f2b47ce0c9e2d33fee1cd106e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A J")]], [#link("https://terrytao.wordpress.com/2025/08/31/a-crowdsourced-project-to-link-up-erdosproblems-com-to-the-oeis/#comment-688714")[#strong[#text("A J")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2025")])]

#text("This might be unrelated but still got to do with crowdsourcing mathematics and given that you do encourage collaborative mathematics especially given your experience with PolyMath projects that led to your success with the Ërdos discrepancy problem for instance, I would like to have your thoughts around this.")

#text("I’m from Antwerp in Belgium and have been working on the perfect cuboid problem over the last months and recently had some partial results. From a recent correspondence I had with Dr. Bogdan Grechuk (whom you ever interacted with here: ")#link("https://mathoverflow.net/questions/400714/can-you-solve-the-listed-smallest-open-diophantine-equations")[#text("https://mathoverflow.net/questions/400714/can-you-solve-the-listed-smallest-open-diophantine-equations")]#text("), he suggested that if I thought my proof, which was rather elementary then (which I have since gone on to improve over the last few weeks), was right, it’d be good idea to formalize it in Lean. I have since watched some youtube videos on Lean, with still a whole lot to learn. In later correspondences where I told him of how I was incorporating AI models into these formalizations, which was in fact, partly inspired by your YouTube videos, he further suggested that even if I do not solve it eventually, it’d be a good idea to write a paper on how I was incorporating AI into these Lean formalisations as it could be interesting and useful for people who want to formalize their (correct) proofs but do not know Lean.")

#text("In light of these helpful feedbacks and suggestions I received, further inspired by your YouTube channel, your online seminar I attended (organized by PIMS on AI and Mathematics September 2024) where I first learned of Lean and also your approaches to PolyMath projects, I recently created a YouTube channel (")#link("https://www.youtube.com/@JAgbanwa")[#text("https://www.youtube.com/@JAgbanwa")]#text(") dedicated to sharing my partial results on open problems, which initially is likely to understandably raise eyebrows, but these are focused on problems more within my reach like perfect cuboids, and as time goes on, hopefully 3×3 magic square of squares, or any other problem of interest and their formalizations in Lean language with AI assistance. The goal of this channel is to welcome all constructive feedbacks and criticisms that further advance the problem and if these feedbacks culminated into significant progress or in the best case, a full proof, due acknowledgements would be given in the final paper.")

#text("It’d be great to have your thoughts on this approach to mathematics.")

#text("Jamal,")

#text("(")#link("https://jamalagbanwa.wordpress.com")[#text("https://jamalagbanwa.wordpress.com")]#text(")")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/890e375a0bf33e7cff6ed02cc1e43eb03da865feae76a8ba93114f5e5f2d3ae8-3f7b66d78133ac022d59c01916e293c34e19ecbf32e3fe4d827a6ff3d1470320.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of charlesrmatthews")]], [#link("https://terrytao.wordpress.com/2025/08/31/a-crowdsourced-project-to-link-up-erdosproblems-com-to-the-oeis/#comment-688719")[#strong[#text("charlesrmatthews")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2025")])]

#text("The general problem of cross-walking between database IDs is well handled via Wikidata. The OEIS ID is property P829 on Wikidata. I make the general suggestion that a Wikidata property be created for erdosproblems.com. With the two properties, tracking progress matching could become rather simple via SPARQL query.")

#text("To state the obvious, the new property would increase the prominence of the problems. It would also allow the tagging of mathematical papers, on Wikidata, by relevant problems as topic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/31/a-crowdsourced-project-to-link-up-erdosproblems-com-to-the-oeis/#comment-688754")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2025")])]

#text("Over the past week I have entered links in OEIS to all the entries that are mentioned in Bloom and the spreadsheet. Therefore, the OEIS side of the bridge is built as far as existing sequence citations are concerned.")

#text("A new draft A387698 recently arose that is linked to Problem 534.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/31/a-crowdsourced-project-to-link-up-erdosproblems-com-to-the-oeis/#comment-688884")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2025")])]

#text("Hello Terence,")

#text("I took up your challenge and I have found the next term for ")#link("https://oeis/org/A276661")[#text("https://oeis/org/A276661")]#text(", which is related to ")#link("https://www.erdosproblems.com/go_to/1")[#text("Erdos problem 1 ")]#text(", concerning distinct subset sums.")

#text("It took about two and a half weeks using an exhaustive search running on 17 computers of various ages and abilities. I then spent another 4 weeks rerunning the calculation slightly differently to confirm the answer.")

#text("I would appreciate it if you could point me to any other sequences with this level of computation needed to find additional terms.")

#text("It was a fun problem as there were a couple of optimizations to find to enable this to run in a reasonable time.")

#text("I have uploaded the code and the results to Github along with an explanation of the sequence and the optimizations used: ")#link("https://github.com/pwdyson/erdos_1")[#text("https://github.com/pwdyson/erdos_1")]

#text("Over the last few years I have been running multi-month long searches to contribute to various prime related sequences in the OEIS. The computers used for that search were repurposed to perform this search for distinct subset sums.")

#text("I have submitted the term for A276661 to the OEIS and am awaiting a response.")

#text("Cheers,")#linebreak()#text("Paul Dyson")#linebreak()#text("Sydney, Australia")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/08/31/a-crowdsourced-project-to-link-up-erdosproblems-com-to-the-oeis/#comment-688887")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2025")])]

#text("Thanks! If you are looking for further projects, perhaps you can help conclude the computations of F(n) and t(n) at ")#link("https://github.com/teorth/erdosproblems/issues/94")[#text("https://github.com/teorth/erdosproblems/issues/94")]#text(" where there were several initial members of these sequences computed, but the submission has not yet taken place.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/31/a-crowdsourced-project-to-link-up-erdosproblems-com-to-the-oeis/#comment-688889")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2025")])]

#text("Thanks. I’ll take a look.")

#text("Paul")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/31/a-crowdsourced-project-to-link-up-erdosproblems-com-to-the-oeis/#comment-692212")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2026")])]

#text("Thanks again for putting me on to this problem. I teamed up with Brendan McKay and we have written this paper:")

#text("Ramsey numbers for regular induced subgraphs,")#linebreak()#text("Paul W. Dyson and Brendan D. McKay,")#linebreak()#link("https://arxiv.org/abs/2604.08215")[#text("https://arxiv.org/abs/2604.08215")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/31/a-crowdsourced-project-to-link-up-erdosproblems-com-to-the-oeis/#comment-689083")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2025")])]

#text("Hi Terence!")

#text("A new oeis sequence for ")#link("https://www.erdosproblems.com/forum/thread/954")[#text("Erdos Problem #954")]#text(" is now available in comments section of that problem. Go oeis team!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf3ea8f43e6d18518581a8b0c70a25ad0fcf69115605f9be4fd41a6d352085bc-5cfe1eb9188e0239fbe63102247d260aff986ee0cfa34e6d83051adae6c10f4c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Formalization of Erdős problems | Xena")]], [#link("https://terrytao.wordpress.com/2025/08/31/a-crowdsourced-project-to-link-up-erdosproblems-com-to-the-oeis/#comment-689230")[#strong[#text("Formalization of Erdős problems | Xena")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2025")])]

#text("[…] including (but not at all limited to) Erdős problems. In August 2025, Thomas Bloom and Terence Tao proposed a crowdsourced project to link up erdosproblems.com to the Online Encyclopedia of Integer Sequences (OEIS). These are both […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/585260e13957b3b3fb21f67b8f8f524d89249edb84971cb0bc5fb2d5edb963e3-d86b76b3f6cf4554bf505745786995e394bbc1cfac4916f25b13702bc9584e0e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thoughtfullyd4c9a86b93")]], [#link("https://terrytao.wordpress.com/2025/08/31/a-crowdsourced-project-to-link-up-erdosproblems-com-to-the-oeis/#comment-691825")[#strong[#text("thoughtfullyd4c9a86b93")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2026")])]

#text("OEIS has one major defect … it does not appear to categorize sequences which include limit terms such as singularity or various infinities, which makes it hard to locate relevant works.")
]
