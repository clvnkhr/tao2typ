// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/
// Converted to Typst by tao2typ: "2026-10-14T16:37:28.879806+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Large gaps between consecutive prime numbers", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Large gaps between consecutive prime numbers")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 August 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/")[#text("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Kevin Ford, Ben Green, Sergei Konyagin, and myself have just posted to the arXiv our preprint “")#link("http://arxiv.org/abs/1408.4505")[#text("Large gaps between consecutive prime numbers")]#text("“. This paper concerns the “opposite” problem to that considered by the recently concluded Polymath8 project, which was concerned with very small values of the prime gap ")#mi("{p_{n+1}-p_n}")#text(". Here, we wish to consider the ")#emph[#text("largest")]#text(" prime gap ")#mi("{G(X) = p_{n+1}-p_n}")#text(" that one can find in the interval ")#mi("{[X] = \\{1,\\dots,X\\}}")#text(" as ")#mi("{X}")#text(" goes to infinity.")

#text("Finding lower bounds on ")#mi("{G(X)}")#text(" is more or less equivalent to locating long strings of consecutive composite numbers that are not too large compared to the length of the string. A classic (and quite well known) construction here starts with the observation that for any natural number ")#mi("{n}")#text(", the consecutive numbers ")#mi("{n!+2, n!+3,\\dots,n!+n}")#text(" are all composite, because each ")#mi("{n!+i}")#text(", ")#mi("{i=2,\\dots,n}")#text(" is divisible by some prime ")#mi("{p \\leq n}")#text(", while being strictly larger than that prime ")#mi("{p}")#text(". From this and Stirling’s formula, it is not difficult to obtain the bound ")#metadata(none) <tao-6f8422f479ef784c70b7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("G(X) \\gg \\frac{\\log X}{\\log\\log X}.")]]



#text(" A more efficient bound comes from the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(": there are only ")#mi("{(1+o(1)) \\frac{X}{\\log X}}")#text(" primes up to ")#mi("{X}")#text(", so just from the pigeonhole principle one can locate a string of consecutive composite numbers up to ")#mi("{X}")#text(" of length at least ")#mi("{(1-o(1)) \\log X}")#text(", thus ")#metadata(none) <tao-e9dc96f7526216bbcead>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("G(X) \\gtrsim \\log X")]]



#text(" where we use ")#mi("{X \\gtrsim Y}")#text(" or ")#mi("{Y \\lesssim X}")#text(" as shorthand for ")#mi("{X \\geq (1-o(1)) Y}")#text(" or ")#mi("{Y \\leq (1+o(1)) X}")#text(".")

#text("What about upper bounds? The ")#emph[#text("Cramér random model")]#text(" predicts that the primes up to ")#mi("{X}")#text(" are distributed like a random subset ")#mi("{\\{1,\\dots,X\\}}")#text(" of density ")#mi("{1/\\log X}")#text(". Using this model, ")#link("http://en.wikipedia.org/wiki/Cram%C3%A9r's_conjecture")[#text("Cramér arrived at the conjecture")]

#align(center)[#tao-fit-display[#mitex("G(X) \\ll \\log^2 X.")]]

#text("In fact, if one makes the extremely optimistic assumption that the random model perfectly describes the behaviour of the primes, one would arrive at the even more precise prediction")

#align(center)[#tao-fit-display[#mitex("G(X) \\sim \\log^2 X.")]]

#text("However, it is no longer widely believed that this optimistic version of the conjecture is true, due to some additional irregularities in the primes coming from the basic fact that large primes cannot be divisible by very small primes. Using the ")#link("http://en.wikipedia.org/wiki/Maier's_matrix_method")[#text("Maier matrix method")]#text(" to capture some of this irregularity, ")#link("http://www.ams.org/mathscinet-getitem?mr=1349149")[#text("Granville was led")]#text(" to the conjecture that")

#align(center)[#tao-fit-display[#mitex("G(X) \\gtrsim 2e^{-\\gamma} \\log^2 X")]]

#text("(note that ")#mi("{2e^{-\\gamma} = 1.1229\\dots}")#text(" is slightly larger than ")#mi("{1}")#text("). For comparison, the known upper bounds on ")#mi("{G(X)}")#text(" are quite weak; unconditionally one has ")#mi("{G(X) \\ll X^{0.525}}")#text(" by the ")#link("http://www.ams.org/mathscinet-getitem?mr=1851081")[#text("work of Baker, Harman, and Pintz")]#text(", and even on the Riemann hypothesis one only gets down to ")#mi("{G(X) \\ll X^{1/2} \\log X}")#text(", as shown by Cramér (a slight improvement is also possible if one additionally assumes the pair correlation conjecture; see ")#link("http://www.ams.org/mathscinet-getitem?mr=667711")[#text("this article of Heath-Brown")]#text(" and the references therein).")

#text("This conjecture remains out of reach of current methods. In 1931, Westzynthius managed to improve the bound ")#link(<tao-e9dc96f7526216bbcead>)[#text("(2)")]#text(" slightly to")

#align(center)[#tao-fit-display[#mitex("G(X) \\gg \\frac{\\log\\log\\log X}{\\log\\log\\log\\log X} \\log X ,")]]

#text("which Erdös in 1935 improved to")

#align(center)[#tao-fit-display[#mitex("G(X) \\gg \\frac{\\log\\log X}{(\\log\\log\\log X)^2} \\log X")]]

#text("and Rankin in 1938 improved slightly further to ")#metadata(none) <tao-c1cbb8108bc8f123dd63>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("G(X) \\gtrsim c \\frac{(\\log\\log X) \\log\\log\\log\\log X}{(\\log\\log\\log X)^2} \\log X")]]



#text(" with ")#mi("{c=1/3}")#text(". Remarkably, this rather strange bound then proved extremely difficult to advance further on; until recently, the only improvements were to the constant ")#mi("{c}")#text(", which was raised to ")#mi("{c=\\frac{1}{2} e^\\gamma}")#text(" in 1963 ")#link("http://www.ams.org/mathscinet-getitem?mr=146154")[#text("by Schönhage")]#text(", to ")#mi("{c= e^\\gamma}")#text(" in 1963 ")#link("http://www.ams.org/mathscinet-getitem?mr=160767")[#text("by Rankin")]#text(", to ")#mi("{c = 1.31256 e^\\gamma}")#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=972703")[#text("by Maier and Pomerance")]#text(", and finally to ")#mi("{c = 2e^\\gamma}")#text(" in 1997 ")#link("http://www.ams.org/mathscinet-getitem?mr=1443763")[#text("by Pintz")]#text(".")

#text("Erdös listed the problem of making ")#mi("{c}")#text(" arbitrarily large one of his favourite open problems, even ")#link("http://books.google.com/books?id=tmORL-UYOyEC&pg=PA467&lpg=PA467#v=onepage&q&f=false")[#text("offering")]#text(" (“somewhat rashly”, in his words) a cash prize for the solution. Our main result answers this question in the affirmative:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" The bound ")#link(<tao-c1cbb8108bc8f123dd63>)[#text("(3)")]#text(" holds for arbitrarily large ")#mi("{c>0}")#text(".")
]

#text("In principle, we thus have a bound of the form")

#align(center)[#tao-fit-display[#mitex("G(X) \\geq f(X) \\frac{(\\log\\log X) \\log\\log\\log\\log X}{(\\log\\log\\log X)^2} \\log X")]]

#text("for some ")#mi("{f(X)}")#text(" that grows to infinity. Unfortunately, due to various sources of ineffectivity in our methods, we cannot provide any explicit rate of growth on ")#mi("{f(X)}")#text(" at all.")

#text("We decided to announce this result the old-fashioned way, as part of a research lecture; more precisely, Ben Green announced the result in ")#link("http://www.icm2014.org/en/program/scientific/plenary")[#text("his ICM lecture")]#text(" this Tuesday. (The ICM staff have very efficiently put up video of his talks (and most of the other plenary and prize talks) online; Ben’s talk is ")#link("https://www.youtube.com/watch?v=XQyXFaM4G_U")[#text("here")]#text(", with the announcement beginning ")#link("http://www.youtube.com/watch?v=XQyXFaM4G_U&t=48m11s")[#text("at about 0:48")]#text(". Note a slight typo in his slides, in that the exponent of ")#mi("{\\log\\log\\log X}")#text(" in the denominator is ")#mi("{3}")#text(" instead of ")#mi("{2}")#text(".) Ben’s lecture slides may be found ")#link("https://docs.google.com/file/d/0B8Xg7dl88Ow7T3A5X0VDc050OEk/edit?hl=en&forcehl=1")[#text("here")]#text(".")

#text("By coincidence, an independent proof of this theorem has also been obtained very recently by James Maynard.")

#text("I discuss our proof method below the fold.")

#metadata(none) <tao-0d5ed481f0b0fbc14c21>

#heading(level: 1)[#strong[#text(" — 1. Sketch of proof — ")]]

#text("Our method is a modification of Rankin’s method, combined with some work of myself and Ben Green (and of Tamar Ziegler) on counting various linear patterns in the primes. To explain this, let us first go back to Rankin’s argument, presented in a fashion that allows for comparison with our own methods. Let’s first go back to the easy bound ")#link(<tao-6f8422f479ef784c70b7>)[#text("(1)")]#text(" that came from using the consecutive string ")#mi("{n!+2,\\dots,n!+n}")#text(" of composite numbers. This bound was inferior to the prime number theorem bound ")#link(<tao-e9dc96f7526216bbcead>)[#text("(2)")]#text(", however this can be easily remedied by replacing ")#mi("{n!}")#text(" with the somewhat smaller ")#link("http://en.wikipedia.org/wiki/Primorial")[#text("primorial")]#text(" ")#mi("{P(n)}")#text(", defined as the product of the primes up to and including ")#mi("{n}")#text(". It is still easy to see that ")#mi("{P(n)+2,\\dots,P(n)+n}")#text(" are all composite, with each ")#mi("{P(n)+i, i \\leq n}")#text(" divisible by some prime ")#mi("{p \\leq n}")#text(" while being larger than that prime. On the other hand, the prime number theorem tells us that ")#mi("{P(n) = \\exp( (1+o(1)) n)}")#text(". From this, one can recover an alternate proof of ")#link(<tao-e9dc96f7526216bbcead>)[#text("(2)")]#text(" (perhaps not so surprising, since the prime number theorem is a key ingredient in both proofs).")

#text("This gives hope that further modification of this construction can be used to go beyond ")#link(<tao-e9dc96f7526216bbcead>)[#text("(2)")]#text(". If one looks carefully at the above proof, we see that the key fact used here is that the discrete interval of integers ")#mi("{\\{2,\\dots,n\\}}")#text(" is ")#emph[#text("completely sieved out")]#text(" by the residue classes ")#mi("{0 \\text{ mod } p}")#text(" for primes ")#mi("{p \\leq n}")#text(", in the sense that each element in this interval is contained in at least one of these residue classes. More generally (and shifting the interval by ")#mi("{1}")#text(" for a more convenient normalisation), suppose we can find an interval ")#mi("{[y] := \\{ n \\in {\\bf N}: n \\leq y \\}}")#text(" which is completely sieved out by one residue class ")#mi("{a_p \\text{ mod } p}")#text(" for each ")#mi("{p \\leq x}")#text(", for some ")#mi("{x}")#text(" and ")#mi("{y}")#text(". Then the string of consecutive numbers ")#mi("{m+1,\\dots,m+\\lfloor y\\rfloor}")#text(" will be composite, whenever ")#mi("{m}")#text(" is an integer larger than or equal to ")#mi("{x}")#text(" with ")#mi("{m = - a_p \\text{ mod } p}")#text(" for each prime ")#mi("{p \\leq x}")#text(", since each of the ")#mi("{m+i, i \\leq y}")#text(" will be divisible by some prime ")#mi("{p \\leq x}")#text(" while being larger than that prime. From the Chinese remainder theorem, one can find such an ")#mi("{m}")#text(" that is of size at most ")#mi("{x+P(x)}")#text(". From this and the prime number theorem, one can obtain lower bounds on ")#mi("{G(X)}")#text(" if one can get lower bounds on ")#mi("{y}")#text(" in terms of ")#mi("{x}")#text(". In particular, if for any large ")#mi("{x}")#text(" one can completely sieve out ")#mi("{[y]}")#text(" with a residue class ")#mi("{a_p \\text{ mod } p}")#text(" for each ")#mi("{p \\leq x}")#text(", and ")#metadata(none) <tao-f2cf188a1e7f126914e0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("y \\sim c \\frac{(\\log x) \\log\\log\\log x}{(\\log\\log x)^2} x,")]]



#text(" then one can establish the bound ")#link(<tao-c1cbb8108bc8f123dd63>)[#text("(3)")]#text(". (The largest ")#mi("{y}")#text(" one can take for a given ")#mi("{x}")#text(" is known as the ")#link("http://oeis.org/wiki/Jacobsthal_function")[#text("Jacobsthal function")]#text(" of the primorial ")#mi("{P(x)}")#text(".) So the task is basically to find a smarter set of congruence classes ")#mi("{a_p \\text{ mod } p}")#text(" than just the zero congruence classes ")#mi("{0 \\text{ mod } p}")#text(" that can sieve out a larger interval than ")#mi("{x}")#text(". (Unfortunately, this approach by itself is unlikely to reach the Cramér conjecture; it was shown ")#link("http://www.ams.org/mathscinet-getitem?mr=499895")[#text("by Iwaniec")]#text(" using the large sieve that ")#mi("{y}")#text(" is necessarily of size ")#mi("{O(x^2)}")#text(" (which somewhat coincidentally matches the Cramér bound), but ")#link("http://www.ams.org/mathscinet-getitem?mr=972703")[#text("Maier and Pomerance")]#text(" conjecture that in fact one must have ")#mi("{y \\leq x \\log^{2+o(1)} x}")#text(", which would mean that the limit of this method would be to establish a bound of the form ")#mi("{G(X) \\geq (\\log\\log X)^{2+o(1)} \\log X}")#text(".)")

#text("So, how can one do better than just using the “Eratosthenes” sieve ")#mi("{0 \\text{ mod } p}")#text("? We will divide the sieving into different stages, depending on the size of ")#mi("{p}")#text(". It turns out that a reasonably optimal division of primes ")#mi("{p}")#text(" up to ")#mi("{x}")#text(" will be into the following four classes:")

#list(
[#text("Stage 1 primes: primes ")#mi("{p}")#text(" that are either tiny (less than ")#mi("{\\log x}")#text(") or medium size (between ")#mi("{z}")#text(" and ")#mi("{x/4}")#text("), where ")#mi("{z}")#text(" is a parameter to be chosen later.")],
[#text("Stage 2 primes: primes that are small (between ")#mi("{\\log x}")#text(" and ")#mi("{z}")#text(").")],
[#text("Stage 3 primes: Primes that are very large (between ")#mi("{x/2}")#text(" and ")#mi("{x}")#text(").")],
[#text("Stage 4 primes: Primes that are fairly large (between ")#mi("{x/4}")#text(" and ")#mi("{x/2}")#text(").")]
)

#text("We will take an interval ")#mi("{[y]}")#text(", where ")#mi("{y}")#text(" is given by ")#link(<tao-f2cf188a1e7f126914e0>)[#text("(4)")]#text(", and sieve out first by Stage 1 primes, then Stage 2 primes, then Stage 3 primes, then Stage 4 primes, until none of the elements of ")#mi("{[y]}")#text(" are left.")

#text("Let’s first discuss the final sieving step, which is rather trivial. Suppose that our sieving by the first three sieving stages is so efficient that the number of surviving elements of ")#mi("{[y]}")#text(" is less than or equal to the number of Stage 4 primes (by the prime number theorem, this will for instance be the case for sufficiently large ")#mi("{x}")#text(" if there are fewer than ")#mi("{(\\frac{1}{5}+o(1)) \\frac{x}{\\log x}}")#text(" survivors). Then one can finish off the remaining survivors simply by using each of the Stage 4 primes ")#mi("{p}")#text(" to remove one of the surviving integers in ")#mi("{[y]}")#text(" by an appropriate choice of residue class ")#mi("{a_p \\text{ mod } p}")#text(". So we can recast our problem as an approximate sieving problem rather than a perfect sieving problem; we now only need to eliminate ")#emph[#text("most")]#text(" of the elements of ")#mi("{[y]}")#text(" rather than ")#emph[#text("all")]#text(" of them, at the cost of only using primes from the Stages 1-3, rather than 1-4. Note though that for ")#mi("{y}")#text(" given by ")#link(<tao-f2cf188a1e7f126914e0>)[#text("(4)")]#text(", the Stage 1-3 sieving has to be reasonably efficient, in that the proportion of survivors cannot be too much larger than ")#mi("{1/\\log^2 x}")#text(" (ignoring factors of ")#mi("{\\log\\log x}")#text(" etc.).")

#text("Next, we discuss the Stage 1 sieving process. Here, we will simply copy the classic construction and use the Eratosthenes sieve ")#mi("{0 \\text{ mod } p}")#text(" for these primes. The elements of ")#mi("{[y]}")#text(" that survive this process are those elements that are not divisible by any Stage 1 primes, that is to say they are only divisible by small (Stage 2) primes, or else contain at least one prime factor larger than ")#mi("{x/4}")#text(", and no prime factors less than ")#mi("{\\log x}")#text(". In the latter case, the survivor has no choice but to be a prime in ")#mi("{(x/4,y]}")#text(" (since from ")#link(<tao-f2cf188a1e7f126914e0>)[#text("(4)")]#text(" we have ")#mi("{y \\leq x \\log x}")#text(" for ")#mi("{x}")#text(" large enough). In the former case, the survivor is a ")#link("http://en.wikipedia.org/wiki/Smooth_number")[#mi("{z}")#text("-smooth number")]#text(" – a number with no prime factors greater than ")#mi("{z}")#text(". How many such survivors are there? Here we can use a somewhat crude upper bound of Rankin:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" Let ")#mi("{1 < z \\leq y}")#text(" be large quantities, and write ")#mi("{u := \\frac{\\log y}{\\log z}}")#text(". Suppose that")

#align(center)[#tao-fit-display[#mitex("\\log u = o( \\log z ).")]]

#text("Then the number of ")#mi("{z}")#text("-smooth numbers in ")#mi("{[y]}")#text(" is at most ")#mi("{e^{-u\\log u + O(u)} y \\log z}")#text(".")
]

#emph[#text("Proof:")]#text(" We use a Dirichlet series method commonly known as “Rankin’s trick”. Let ")#mi("{0<\\rho<1}")#text(" be a quantity to be optimised in later, and abbreviate “")#mi("{z}")#text("-smooth” as “smooth”. Observe that if ")#mi("{n}")#text(" is a smooth number less than ")#mi("{y}")#text(", then ")#metadata(none) <tao-ddee947e8a825ca4e994>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("1 \\leq \\frac{y}{y^\\rho} \\frac{1}{n^{1-\\rho}}.")]]



#text(" Thus, the number of smooth numbers in ")#mi("{y}")#text(" is at most")

#align(center)[#tao-fit-display[#mitex("\\frac{y}{y^\\rho} \\sum_{n \\text{smooth}} \\frac{1}{n^{1-\\rho}}")]]

#text("where we have simply discarded the constraint ")#mi("{n \\leq y}")#text(". The point of doing this is that the above expression factors into a tractable Euler product")

#align(center)[#tao-fit-display[#mitex("\\frac{y}{y^\\rho} \\prod_{p \\leq z} (1 + \\frac{1}{p^{1-\\rho}} + \\frac{1}{p^{2(1-\\rho)}} + \\dots).")]]

#text("We will choose ")#metadata(none) <tao-f2496a9ad2efec1e4921>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\rho := \\frac{u \\log u}{\\log y} = \\frac{\\log u}{\\log z}")]]



#text(" so that ")#mi("{y^\\rho = e^{u \\log u}}")#text(" and ")#mi("{\\rho=o(1)}")#text(". Then the above expression simplifies to")

#align(center)[#tao-fit-display[#mitex("\\ll \\frac{y}{e^{u \\log u}} \\exp( \\sum_{p \\leq z} \\frac{1}{p^{1-\\rho}} ).")]]

#text("To compute the sum here, we first observe from ")#link("http://en.wikipedia.org/wiki/Mertens'_theorems")[#text("Mertens’ theorem")]#text(" (discussed in ")#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/")[#text("this previous blog post")]#text(") that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq z} \\frac{1}{p} = \\log \\log z + O(1),")]]

#text("so we may bound the previous expression by")

#align(center)[#tao-fit-display[#mitex("\\ll \\frac{y \\log z}{e^{u \\log u}} \\exp( \\sum_{p \\leq z} \\frac{1}{p^{1-\\rho}} - \\frac{1}{p} )")]]

#text("which we rewrite using ")#link(<tao-f2496a9ad2efec1e4921>)[#text("(6)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\ll \\frac{y \\log z}{e^{u \\log u}} \\exp( \\sum_{p \\leq z} \\frac{\\exp( \\frac{\\log p}{\\log z} \\log u ) - 1}{p} ).")]]

#text("Next, we use the convexity inequality")

#align(center)[#tao-fit-display[#mitex("\\exp( ct ) - 1 \\leq (\\exp(c) - 1 ) t")]]

#text("for ")#mi("{c > 0}")#text(" and ")#mi("{0 \\leq t \\leq 1}")#text(", applied with ")#mi("{c := \\log u}")#text(" and ")#mi("{t := \\frac{\\log p}{\\log z}}")#text(", to conclude that")

#align(center)[#tao-fit-display[#mitex("\\exp( \\frac{\\log p}{\\log z} \\log u ) - 1 \\leq u \\frac{\\log p}{\\log z}")]]

#text("Finally, from the prime number theorem we have ")#mi("{\\sum_{p \\leq z} \\frac{\\log p}{\\log z} \\ll 1}")#text(". The bound follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" One can basically eliminate the ")#mi("{\\log z}")#text(" factor here (at the cost of worsening the ")#mi("{O(u)}")#text(" error slightly to ")#mi("{O(u\\log\\log(3u))}")#text(") by a more refined version of the Rankin trick, based on replacing the crude bound ")#link(<tao-ddee947e8a825ca4e994>)[#text("(5)")]#text(" by the more sophisticated inequality")

#tao-aligned(keep: true)[


#tao-math("1  & = \\frac{\\log \\frac{y}{n}}{\\log n} + \\sum_{p^\\nu || n; p \\leq z} \\frac{\\nu \\log p}{\\log y},", block: true)



#tao-math(" & \\ll \\frac{y}{y^\\rho \\log y} \\frac{1}{n^{1-\\rho}} + \\sum_{p^\\nu || n; p \\leq z} \\frac{\\nu \\log p}{\\log y},", block: true)
]

#text("where ")#mi("{p^\\nu||n}")#text(" denotes the assertion that ")#mi("{p}")#text(" divides ")#mi("{n}")#text(" exactly ")#mi("{\\nu}")#text(" times. (Thanks to Kevin Ford for pointing out this observation to me.) In fact, the number of ")#mi("{z}")#text("-smooth numbers in ")#mi("{[y]}")#text(" is known to be asymptotically ")#mi("{e^{-u\\log u + O( u \\log\\log(3u) )} y}")#text(" in the range ")#mi("{\\log^3 y \\leq z \\leq y}")#text(", a ")#link("http://www.ams.org/mathscinet-getitem?mr=46375")[#text("result of de Bruijn")]#text(".")
]

#text("In view of the error term permitted by the Stage 4 process, we would like to take ")#mi("{z}")#text(" as large as possible while still leaving only ")#mi("{o(x/\\log x)}")#text(" smooth numbers in ")#mi("{[y]}")#text(". A somewhat efficient choice of ")#mi("{z}")#text(" here is")

#align(center)[#tao-fit-display[#mitex("z := \\exp( \\frac{\\log\\log\\log x}{4 \\log\\log x} \\log x ),")]]

#text("so that ")#mi("{u \\sim 4 \\frac{\\log\\log x}{\\log\\log\\log x}}")#text(" and ")#mi("{u\\log u \\sim 4 \\log\\log x}")#text(", and then one can check that the above lemma does indeed show that there are ")#mi("{o(x/\\log x)}")#text(" smooth numbers in ")#mi("{[y]}")#text(". (If we use the sharper bound in the remark, we can reduce the ")#mi("{4}")#text(" here to a ")#mi("{3}")#text(", although this makes little difference to the final bound.) If we let ")#mi("{{\\mathcal Q}}")#text(" denote all the primes in ")#mi("{(x/4,y]}")#text(", the remaining task is then to sieve out all but ")#mi("{(\\frac{1}{5}+o(1)) \\frac{x}{\\log x}}")#text(" of the primes in ")#mi("{{\\mathcal Q}}")#text(" by using one congruence class from each of the Stage 2 and Stage 3 primes.")

#text("Note that ")#mi("{{\\mathcal Q}}")#text(" is still quite large compared to the error that the Stage 4 primes can handle – it is of size about ")#mi("{y/\\log x}")#text(", whereas we need to get down to a bit less than ")#mi("{x/\\log x}")#text(". Still, this is some progress (the remaining sparsification needed is of the order of ")#mi("{1/\\log^{1+o(1)} x}")#text(" rather than ")#mi("{1/\\log^{2+o(1)} x}")#text(").")

#text("For the Stage 2 sieve, we will just use a random construction, choosing ")#mi("{a_p \\text{ mod } p}")#text(" uniformly at random for each Stage 2 prime. This sieve is expected to sparsify the set ")#mi("{{\\mathcal Q}}")#text(" of survivors by a factor")

#align(center)[#tao-fit-display[#mitex("\\gamma := \\prod_{\\text{Stage 2 primes} p} (1-\\frac{1}{p}),")]]

#text("which by Mertens’ theorem is of size")

#align(center)[#tao-fit-display[#mitex("\\gamma \\sim \\frac{\\log \\log x}{\\log z} \\sim 4 \\frac{(\\log \\log x)^2}{\\log x \\log\\log\\log x}.")]]

#text("In particular, if ")#mi("{y}")#text(" is given by ")#link(<tao-f2cf188a1e7f126914e0>)[#text("(4)")]#text(", then all the strange logarithmic factors cancel out and")

#align(center)[#tao-fit-display[#mitex("\\gamma y \\sim 4c x.")]]

#text("In particular, we expect ")#mi("{{\\mathcal Q}}")#text(" to be cut down to a random set (which we have called ")#mi("{{\\mathcal Q}({\\bf a})}")#text(" in our paper) of size about ")#mi("{4c \\frac{x}{\\log x}}")#text(". This would already finish the job for very small ")#mi("{c}")#text(" (e.g. ")#mi("{c \\leq 1/20}")#text("), and indeed Rankin’s original argument proceeds more or less along these lines. But now we want to take ")#mi("{c}")#text(" to be large.")

#text("Fortunately, we still have the Stage 3 primes to play with. But the number of Stage 3 primes is about ")#mi("{\\frac{1}{2} \\frac{x}{\\log x}}")#text(", which is a bit smaller than the number of surviving primes ")#mi("{{\\mathcal Q}({\\bf a})}")#text(", which is about ")#mi("{4c \\frac{x}{\\log x}}")#text(". So to make this work, most of the Stage 3 congruence classes ")#mi("{a_p \\text{ mod } p}")#text(" need to sieve out many primes from ")#mi("{{\\mathcal Q}({\\bf a})}")#text(", rather than just one or two. (Rankin’s original argument is based on sieving out one prime per congruence class; the subsequent work of Maier-Pomerance and Pintz is basically based on sieving out two primes per congruence class.)")

#text("Here, one has to take some care because the set ")#mi("{{\\mathcal Q}({\\bf a})}")#text(" is already quite sparse inside ")#mi("{[y]}")#text(" (its density is about ")#mi("{1/\\log^{2+o(1)} x}")#text("). So a randomly chosen ")#mi("{a_p \\text{ mod } p}")#text(" would in fact most likely catch none of the primes in ")#mi("{{\\mathcal Q}({\\bf a})}")#text(" at all. So we need to restrict attention to congruence classes ")#mi("{a_p \\text{ mod } p}")#text(" which already catch a large number of primes in ")#mi("{{\\mathcal Q}}")#text(", so that even after the Stage 2 sieving one can hope to be left with many congruence classes that also catch a large number of primes in ")#mi("{{\\mathcal Q}({\\bf a})}")#text(".")

#text("Here’s where my work with Ben came in. Suppose one has an arithmetic progression ")#mi("{a, a+d, \\dots, a+(r-1)d}")#text(" of length ")#mi("{r}")#text(" consisting entirely of primes in ")#mi("{{\\mathcal Q}}")#text(", and with ")#mi("{d}")#text(" a multiple of ")#mi("{p}")#text(", then the congruence class ")#mi("{a \\text{ mod } p}")#text(" is guaranteed to pick up at least ")#mi("{k}")#text(" primes in ")#mi("{{\\mathcal Q}}")#text(". My ")#link("http://www.ams.org/mathscinet-getitem?mr=2415379")[#text("first theorem with Ben")]#text(" shows that no matter how large ")#mi("{k}")#text(" is, the set ")#mi("{{\\mathcal Q}}")#text(" does indeed contain some arithmetic progressions ")#mi("{a,a+d,\\dots,a+(r-1)d}")#text(" of length ")#mi("{r}")#text(". This result is not quite suitable for our applications here, because (a) we need the spacing ")#mi("{d}")#text(" to also be divisible by a Stage 3 prime ")#mi("{p}")#text(" (in our paper, we take ")#mi("{d = r! p}")#text(" for concreteness, although other choices are certainly possible), and (b) for technical reasons, it is insufficient to simply have a large number of arithmetic progressions of primes strewn around ")#mi("{{\\mathcal Q}}")#text("; they have to be “evenly distributed” in some sense in order to be able to still cover most of ")#mi("{{\\mathcal Q}({\\bf a})}")#text(" after throwing out any progression that is partly or completely sieved out by the Stage 2 primes. Fortunately, though, these distributional results for linear equations in primes were established by a ")#link("http://www.ams.org/mathscinet-getitem?mr=2680398")[#text("subsequent paper of Ben and myself")]#text(", contingent on two conjectures (the Mobius-Nilsequences conjecture and the inverse conjecture for the Gowers norms) which we also proved (the latter with Tamar Ziegler) in ")#link("http://www.ams.org/mathscinet-getitem?mr=2877066")[#text("some")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2950773")[#text("further papers")]#text(". (Actually, strictly speaking our work does not quite cover the case needed here, because the progressions are a little “narrow”; we need progressions of primes in ")#mi("{[y]}")#text(" whose spacing ")#mi("{d}")#text(" is comparable to ")#mi("{x}")#text(" instead of ")#mi("{y}")#text(", whereas our paper only considered the situation in which the spacing was comparable to the elements of the progression. It turns out though that the arguments can be modified (somewhat tediously) to extend to this case though.)")

#heading(level: 1)[#text("Comments (44)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-408005")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2014")])]

#text("Is there a way to get the pdf files of ICM proceedings of this year online?")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-408083")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2014")])]

#text("I would imagine that they will eventually be available at ")#link("http://www.mathunion.org/ICM/")[#text("http://www.mathunion.org/ICM/")]#text(" . But one may have to wait some weeks or perhaps months before they are all done with the typesetting etc..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-408118")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2014")])]

#text("For ICM2010 it took about two years for the proceedings to become freely available in the above site. Meanwhile about 50 of the ICM 2014 proceedings’ contributions are already available on arXiv, via this search.")#link("http://arxiv.org/find/all/1/co:+icm/0/1/0/all/0/1")[#text("http://arxiv.org/find/all/1/co:+icm/0/1/0/all/0/1")]#text(" (I got it from Peter Woit’s blog.) Videos of lectures can already be found here. ")#link("http://www.icm2014.org/en/vod/vod")[#text("http://www.icm2014.org/en/vod/vod")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hyun Woo Kwon")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-408196")[#strong[#text("Hyun Woo Kwon")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2014")])]

#text("I’m a technical Editor on this year ICM Proceedings. Actually, they are already given in USB except for plenary lectures. “USB” is given to participants. I’m not sure when it will be uploaded in IMU websites.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/661a4bd2440e45d7d877948667a384dab349535a109247be3b29b4e4554b7e67-7852b0cb6523b8444847f5dd3b48baa26ed9dd1736da589bc391bb956e46837b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-408007")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2014")])]

#text("I understand James Maynard’s preprint will be appearing later today. There is a sense in which he uses progress on small prime gaps to say something about large prime gaps! The method is quite different to ours, so it is remarkable that these papers should appear within a day of one another after a 75-year wait.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/584cd02f839ef6f42551e80d351f9a4a15cb388eea2c96194a9925dcd6248b8b-d4a31d6f5ab8c8b59637f67c32594b522a6199cfd232e67ffe727dace4462076.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-408057")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2014")])]

#text("Maynard’s preprint is up (")#link("http://arxiv.org/abs/1408.5110")[#text("http://arxiv.org/abs/1408.5110")]#text("). Congratulations to all of you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-408080")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2014")])]

#text("Ben Green’s announcement talk at the ICM was very interesting. One of the things that stuck out to me most was his statement about double ineffectivity [I think this was in answer to a question after the talk(?)], so I was looking to see if James could get around that. It looks like he has!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-408109")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2014")])]

#text("Congratulations!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f62b4f33915948c6986138cdbeab9f680724a06fdaf20b173dbcf7c3467111e2-add5ddfb7da91cc184b8df96cbd8a7a683ec94c2c217348eb2c094c1e3539af6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of BQ")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-408156")[#strong[#text("BQ")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2014")])]

#text("Yes, I think more people should announce their results in this old-fashioned way — by giving a plenary lecture at ICM.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6525d7cd9db10f0f8b9a18fa0e62f21ac78916ee3eed4debea5956daeaf030-72219f07d23f0f1bc893af77a76e1cfd99cff0d2c3626a52796f2e15ac6c7e88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of interested non-expert")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-408200")[#strong[#text("interested non-expert")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2014")])]

#text("Congratulations to all authors! As Ben Green pointed out, it is a strange coincidence that your team and James Maynard found a proof at the same time (after 75years). Some questions:")

#text("1) Has there been a major breakthrough recently, which both of you have used? What are other explanations?")

#text("2) What are the major differences between your proofs and conclusions? Are the involved/developed methods of the similar powerful?")

#text("3) As in the case for small gaps, which is a special case of a weaker variant of a great unknown conjecture (twin-prime conjecture), is there an analog for large primes?")

#text("Thanks!!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-408202")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2014")])]

#text("Both of our papers need some recent results on how to catch primes inside arithmetic progressions, but we use different results. The paper of Kevin, Ben, Sergei and myself use the results of Ben and myself (and of Tamar Ziegler) on linear equations in primes to locate arithmetic progressions that consist ")#emph[#text("solely")]#text(" of primes. James’ argument instead uses a variant of his result on admissible prime tuples that can catch many primes but are also allowed to catch composites (in particular, he uses the same engine to establish both small gaps between primes and large gaps between primes, which is a pleasing symmetry). The latter has the advantage of coming with explicit bounds (the Siegel zero ineffectivity issue is still present, due to the reliance on the Bombieri-Vinogradov theorem, but there are ways to deal with the exceptional zero, e.g. via effective variants of Bombieri-Vinogradov). On the other hand, the sieving process in our paper is a bit simpler to analyse than the one in James’ paper, although they are broadly both of Erdos-Rankin type. There is a good chance that one can combine the most efficient parts of both papers to obtain a cleaner proof of the result that also provides a better bound; we’re looking into that right now.")

#text("The analogue of the twin prime conjecture here is probably the ")#link("http://en.wikipedia.org/wiki/Cram%C3%A9r's_conjecture")[#text("Cramer conjecture")]#text(" (although the obstruction to solving the latter is different, it is the sheer difficulty of locating very rare events, rather than the parity problem). This conjecture is well out of reach of any of the Erdos-Rankin-based methods (which have a natural limit at ")#mi("\\log X (\\log\\log X)^{2+o(1)}")#text(", stopping well short of the Cramer prediction ")#mi("\\asymp (\\log X)^2")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-408614")[#strong[#text("Polymath 8 – a Success! | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2014")]

#text("[…] Update (August 23): Before moving to small gaps, Sound’s 2007 survey briefly describes the situation for large gaps. The Cramer probabilistic heuristic suggests that there are consecutive primes in [1,n] which are apart, but not apart where c and C are some small and large positive constants. It follows from the prime number theorem that there is a gap of at least . And there were a few improvements in the 30s ending with a remarkable result by Rankin who showed that there is a gap as large as times . Last week Kevin Ford, Ben Green, Sergei Konyagin, and Terry Tao and independently James Maynard were able to improve Rankin’s estimate by a function that goes to infinity with n. See this post on “What’s new.” […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9946c9121e0cb957d136b5263170c8a16bc3714a9752b67f86f1a8e55f6903c-d05b29fec6ff76805e2997f2a2e0fd4a3c2f601ae9c890328792ae8a4468c320.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jozsef")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-408857")[#strong[#text("jozsef")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2014")])]

#text("I was wondering if there is a two-sided variant of the result; if there are primes so that the nearest prime, above or below, is far.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-408864")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2014")])]

#text("This looks likely; a result of this form (with a weaker gap bound) was established by Erdos back in 1949, and in 1981 Maier (using his famous matrix method) ")#link("http://www.ams.org/mathscinet-getitem?mr=614163")[#text("established this result")]#text(" with a Rankin-type gap bound (in fact he could get k consecutive large prime gaps for any fixed k). It looks likely that our arguments can be combined with Maier’s, but there are some technical issues to sort out; we’re planning to look into this question soon.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8ffb3195df67eea4b820a906999add9e87ef95921db11420106bf971c00800b-695d322d85efc921a3c86f4bed042a3f0561636110dc6a2953508c9a7c539f3c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of math stat")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-408868")[#strong[#text("math stat")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2014")])]

#text("Hi Professor Tao;")

#text("1. There is no Granville conjecture, which improves the Cramer conjecture, he said himself on Mathoverflow.")

#text("2. Why there is no specific bound for G(X) given? The PNT should implies that G(X) < 0 small.")

#text("3. Does the Jacothal function implies that G(X) << (log X)^2 ?")

#text("Thank you.")

#emph[#text("[Wordpress interprets any text between < and > as HTML and deletes it. Use &lt; and &gt; instead. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-408893")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2014")])]

#text("1. Granville did not make a conjecture for the precise value of ")#mi("\\limsup_n \\frac{p_{n+1}-p_n}{\\log^2 p_n}")#text(", but he did make the conjecture that this limsup will be at least ")#mi("2e^{-\\gamma}")#text(" (see the bottom of page 12 of his paper ")#link("https://www.dartmouth.edu/~chance/chance_news/for_chance_news/Riemann/cramer.pdf")[#text("here")]#text(").")

#text("2. (See formatting note above.)")

#text("3. I am presuming that the intended question here is whether one can use known or conjectural bounds on the Jacobsthal function to imply that ")#mi("G(X) \\ll \\log^2 X")#text(". Unfortunately this does not appear to be the case. The Jacobsthal function lets one control one special type of prime gap, caused by a string of consecutive numbers that each have a quite small prime factor (of size comparable to the logarithm of the numbers in the string). However, it does not say anything much about other prime gaps, that is to say strings of composite numbers, some of which contain large prime factors instead of small ones. The Cramer model suggests that the gaps with ")#mi("G(X) \\sim \\log^2 X")#text(" will be of this latter type and will thus be out of reach of constructions based on the Jacobsthal function. (Maier and Pomerance have a probabilistic heuristic bound on the Jacobsthal function that suggests that the largest prime gap that can be created from optimisers to that function is of size at most ")#mi("\\log X (\\log\\log X)^{2+o(1)}")#text(", but this is not expected to be the true value of ")#mi("G(X)")#text(", merely the limit of this method.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f994878e8d7396b268ab6ac3f054c0708a7f5439eeda380f6bad9d558bdd74-087cdc5448e655a3195f0fe12bb0b035630cb1ad976f7c08f13f2e3cfdc8b245.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Janko Bračič")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-409043")[#strong[#text("Janko Bračič")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2014")])]

#text("Dear Professor Tao,")

#text("I have a question which is not directly related to the topic of this blog, but it is about the pairs of primes. Maybe the question is easy for an expert however I am not able to find an answer.")

#text("Question: Let ")#mi("d\\geq 2")#text(" be an integer. What is the best known upper bound for number of pairs ")#mi("(p, p+d)")#text(" up to ")#mi("X>0")#text(", i.e., ")#mi("p\\leq X")#text(", such that ")#mi("p")#text(" and ")#mi("p+d")#text(" both are primes?")

#text("Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d85c0a27a788d1724ca0b531d5d2a337ff03f68b01b99b9e9a682ff21fa6a213-46c07a03980a31e3b80178ec8c3699aa7f77a60c9c87dd27d403be0950a8f8e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-409077")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2014")])]

#text("I think about 4 times the expected truth of $c X/\\log^2 X$ is a well-known exercise in sieve theory. The 4 has been improved to about 3.4 using much more elaborate sieve theoretic methods. Here is a free to view reference for these matters in the case $d = 2$: ")#link("http://arxiv.org/pdf/1205.0774.pdf")[#text("http://arxiv.org/pdf/1205.0774.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f994878e8d7396b268ab6ac3f054c0708a7f5439eeda380f6bad9d558bdd74-087cdc5448e655a3195f0fe12bb0b035630cb1ad976f7c08f13f2e3cfdc8b245.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Janko Bračič")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-409097")[#strong[#text("Janko Bračič")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2014")])]

#text("Thank you for the answer and the link!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ce0660eba213843216bcb7abc171e73744d76ac6ebb9f5faaa5ca1e7319c11da-8599afa21cedde4b32ebe61e9debffbf1875d1d0de560582f1f1809307a0a8d8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dwu")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-409271")[#strong[#text("dwu")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2014")])]

#text("Hi Professor Tao:")

#text("I had a question about the particular choice of the division of the primes into these four separate classes or stages.")

#text("It’s quite understandable from the paper and from the above proof sketch how these sets of primes are used effectively to sieve out the desired interval, but is there any easily-explainable intuition for why this particular division is more effective than other known approaches for choosing residue classes? At a superficial level, it seems rather strange that one would want to partition the primes in this way, with one of the sets even being composed of two disjoint intervals, namely the stage 1 primes for which we simply choose the zero residue class.")

#text("Is the choice of these four stages mostly just an artifact of trying to exploit the tools we have available at the moment (e.g. strong bounds on the density of smooth numbers), or is there a more fundamental reason? For example, if one could actually find the optimal or a near-optimal selection of the residue classes for this sieve, would one broadly expect it to bear any similarities to the construction here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-409612")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2014")])]

#text("I would say that this is primarily an artifact of trying to optimise between the known reasonably effective sieving methods we have (random, greedy, Eratosthenes). We chose the Stage 1 (Eratosthenes sieve) primes to be disconnected because it had the convenient consequence that the sifted set was essentially the set of primes (as opposed to almost primes, which is what would have happened if we did not include the tiny primes into this stage), so we could (almost) use off-the-shelf theorems about primes. But these theorems are likely also true for almost primes, and one would probably get comparable results if the tiny primes were shifted into Stage 2 (incidentally, this is basically what Maynard does in his paper; also, his Stage 2 uses a shifted Eratosthenes sieve instead of a random sieve, and this also gives comparable results although it requires a bit more sieve theory to analyse).")

#text("There isn’t much known as to what the truly optimal sieving process is – there is no known practical algorithm for locating these things once the size of the interval gets even moderately large. Even if the exact optimisers were known numerically, they could end up being rather unedifying – the problem is so combinatorially complicated that there is no particular reason to suspect any particularly nice structure to the exact optimiser. (There might be an interestingly structured ")#emph[#text("quasi")]#text("-optimiser, though, even if it is technically “beaten” by some semi-random set of congruence classes that manages by pure chance to beat the structured quasi-optimiser by a little bit.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0d38ac55a0ee44000066dcb33b14672f60b65d61db23ae06fb80e11b6c1ec7f-8c13bd9fd34724d5b0835b20d13d8c3690855e3d548980a6987d92d2b31b52a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Billy")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-409899")[#strong[#text("Billy")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2014")])]

#text("Dear Professor Tao")

#link("http://planetmath.org/sites/default/files/texpdf/38128.pdf")[#text("Click to access 38128.pdf")]

#text("In the above link which shows a one-page paper it is stated that")#linebreak()#text(" “the density of Chen primes gradually thins” . Is this enough to prove that there exist infinite non-Chen primes ? Or does the conclusion that there are infinite non-Chen primes come some way from the infinity of Chen primes in arithmetic progression, proved by you and B.Green?")

#text("Any proof that there is an infinite number of non-Chen primes could help me significantly proceed with an attempt of proving a conjecture that I ve been working on as an amateur for a long time.")

#text("Thank you in advance")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-409911")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2014")])]

#text("The set of Chen primes has a significantly smaller density than the set of all primes. For instance, a minor modification of the proof of ")#link("http://en.wikipedia.org/wiki/Brun's_theorem")[#text("Brun’s theorem")]#text(" shows that the sum of reciprocals of the Chen primes is convergent, whereas the sum of the reciprocals of all the primes is divergent. More quantitatively, for large ")#mi("x")#text(", the number of primes up to ")#mi("x")#text(" is approximately ")#mi("x/\\log x")#text(" (the prime number theorem), but standard sieve theory techniques (e.g the Selberg sieve) show that the number of Chen primes up to ")#mi("x")#text(" is ")#mi("O(x/\\log^2 x)")#text(", which is asymptotically smaller. (Technically, this depends on whether one permits one of the prime factors of the Chen prime to be small or not. If one allows small prime factors, the bound is actually a little bit bigger, namely ")#mi("O( x \\log\\log x/\\log^2 x)")#text(".)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0d38ac55a0ee44000066dcb33b14672f60b65d61db23ae06fb80e11b6c1ec7f-8c13bd9fd34724d5b0835b20d13d8c3690855e3d548980a6987d92d2b31b52a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Billy")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-410149")[#strong[#text("Billy")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2014")])]

#text("Thank you very much professor Tao.")#linebreak()#text(" Should I finish my attempt of proving the conjecture, to which mathematical union should I send my work to get its validity examined ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/318c21e03549232532ba40248dbd7f1d212da5f84e4e003c954b80189feba4d4-038039ecb74a0d97e1ed2f8baed80547c8ee70949e03ee2a557bad902c5d3de8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philip Lee")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-410830")[#strong[#text("Philip Lee")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2014")])]

#text("I am just a science student, and I am not very familiar with deep maths. I don’t quite see how the prime number theorem could give such a tight bound that can lead to a pigeonhole principle, just by itself. It seems clear that anomalous clusters of primes becomes well, anomalous, but we see that the PNT is an asymptotic result. Anyone care to give a short explanation, if possible? Prime numbers make very interesting work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-410941")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2014")])]

#text("Suppose for instance that one knows that there are at most 99 primes in the interval ")#mi("\\{1,\\dots,1000\\}")#text(" (this is asymptotically the type of information one gets from the prime number theorem, replacing 99 and 1000 with larger numbers). We can divide the interval ")#mi("\\{1,\\dots,1000\\}")#text(" into 100 intervals of ")#mi("\\{n+1,\\dots,n+10\\}")#text(" of length 10. By the pigeonhole principle (applied in the opposite direction to its traditional formulation), at least one of these intervals must be completely devoid of primes, giving rise to a prime gap of size at least 11.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/318c21e03549232532ba40248dbd7f1d212da5f84e4e003c954b80189feba4d4-038039ecb74a0d97e1ed2f8baed80547c8ee70949e03ee2a557bad902c5d3de8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philip Lee")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-411147")[#strong[#text("Philip Lee")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2014")])]

#text("Thanks for the reply. I wasn’t thinking about limits as I did not see the inequality with the tilde, which has a little o(1) in it (so the inequality depends on precision, or the smallness of 1/”1000″).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cafc1691c25b0017e6fbfe871095e0b53c02df11c288901819581821c660c385-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Dybdahl Ahle")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-410861")[#strong[#text("Thomas Dybdahl Ahle")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2014")])]

#text("“where ")#mi("f(X)")#text(" grows to infinity” – I suppose you could write that as ")#mi("\\omega(1)")#text(" then? since you already use ")#mi("o(1)")#text(" for sub-constants.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-410944")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2014")])]

#text("Yes, although this can cause some conflict in analytic number theory because ")#mi("\\omega(n)")#text(" is also used to denote the number of prime divisors of ")#mi("n")#text(". (Admittedly, we don’t use that notation in this particular paper, but it shows up often enough in other analytic number theory papers that it can lead to confusion if we use it here. Given that it is only needed once in our paper, we felt that it was not worth introducing a notation for it, even if it is standard in some fields of mathematics.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6525d7cd9db10f0f8b9a18fa0e62f21ac78916ee3eed4debea5956daeaf030-72219f07d23f0f1bc893af77a76e1cfd99cff0d2c3626a52796f2e15ac6c7e88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of interested non-expert")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-411298")[#strong[#text("interested non-expert")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2014")])]

#text("This week, an article dealing with prime/natural number networks has been published in a serious physics journal: ")#link("http://journals.aps.org/pre/abstract/10.1103/PhysRevE.90.022806")[#text("http://journals.aps.org/pre/abstract/10.1103/PhysRevE.90.022806")]#text(" It also deals with the Cramer-conjecture on large gaps between primes. As it seem to be partially connected with the statistical analysis in this blog-article, I wonder what are the connections and whether it presents new insights? Thanks alot!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/318c21e03549232532ba40248dbd7f1d212da5f84e4e003c954b80189feba4d4-038039ecb74a0d97e1ed2f8baed80547c8ee70949e03ee2a557bad902c5d3de8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of curious non-expert")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-412630")[#strong[#text("curious non-expert")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2014")])]

#text("Does this relate to Perron Frobenius properties of stochastic matrices? I am at a level of non-expertise that it seems incredible that a theorem like PF could be proved. The up-shot, as I see it, is that for mixing to occur in a network and reach a static steady state, all cycles in the network should have lengths which have their gcd = 1. This is kind of like factoring. What about random stochastic matrices? What about a steady state for the grown network with a ‘prime’ law distribution for the links. It would seem that half the numbers have a prime factor of two, some other fraction with a factor of 3, and so on. Is there an efficient method to label the nodes in the network? It turns out the combinatorix and discrete structures, and complex and asymptotic analysis have a deep connection (I guess the series representation (harmonics), and generating functions are quite natural for those fields). As with all curious people, I have my own other ideas on the representation of primes and the entropy for the set of primes.")

#text("Knowing so little, and might being so wrong, it can look like that I am a very strange troll from the internet.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-413003")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2014")])]

#text("Terry, where is your paper submitted to?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Long gaps between primes | What's new")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-445339")[#strong[#text("Long gaps between primes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2014")])]

#text("[…] gaps between primes“. This is a followup work to our two previous papers (discussed in this previous post), in which we had simultaneously shown that the maximal […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0d38ac55a0ee44000066dcb33b14672f60b65d61db23ae06fb80e11b6c1ec7f-8c13bd9fd34724d5b0835b20d13d8c3690855e3d548980a6987d92d2b31b52a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of billy")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-447065")[#strong[#text("billy")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2014")])]

#text("Dear professor Tao")

#text("If one divides the set of natural numbers into smaller sets based on their divisibility with a random prime number p , what he gets are p sequences of natural numbers of which only p-1 can contain prime numbers.For example, dividing all natural numbers with 5, will produce 5 sequences,")#linebreak()#text(" containing numbers of the form 5k+1 or 5k+2 or 5k+3 or 5k+4 or 5k.")#linebreak()#text(" Of course, a prime can only belong in one of the first four mentioned sequences.")#linebreak()#text(" So, my question is:")#linebreak()#text(" Are prime numbers equally distributed in those 4 sequences ?")#linebreak()#text(" For instance is 1 prime per 4 of the form 5k+1?")#linebreak()#text(" Or is 1 prime per 12 of the form 13k+7?")

#text("In general is there any proof that 1 prime per p-1 is of the form pk+b")#linebreak()#text(" where p is a prime")#linebreak()#text(" k is a natural number and")#linebreak()#text(" b is a natural number smaller than p ?")

#emph[#text("[Yes, this is the prime number theorem in arithmetic progressions, discussed for instance in the recent post ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")]#text(" . See also Dirichlet’s theorem, ")#link("http://en.wikipedia.org/wiki/Dirichlet%27s_theorem_on_arithmetic_progressions")[#text("http://en.wikipedia.org/wiki/Dirichlet%27s_theorem_on_arithmetic_progressions")]#text(" -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/51c8beb3d67fe7e2eea8e6cfd0b9c0e152170ac67b18cbf0519d9b269e408680-8386918f01bb22904994ea2507754effbc1547cf3e0d091cdba069fc9834e743.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carl L. Lambert")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-447169")[#strong[#text("Carl L. Lambert")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2014")])]

#text("See #PrimeNumberGuy tweets on Twitter for a simple view of consecutive composite numbers, including groups of trillions of such consecutive composites in the mega number ranges.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-452296")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2015")])]

#text("Prof. Tao")

#text("I’m confused about your definition of z-smooth numbers. For one, it is quite opposite what the wiki page you linked to says. For the other, after stage 1 of the sieve what is left should be smooth numbers as defined by Wikipedia rather than your definition.")

#emph[#text("[A typo, now corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-452298")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2015")])]

#text("What is the x in Lemma 2? Is it the same as before or a typo?")

#emph[#text("[A typo, now corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-452303")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2015")])]

#text("Nice article. Only kind of lost on the last paragraph.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/42333bb67be77e5c075671cb4b2f324fed4eb94b4a96e90428a4fb44a4964021-d587015a8f3357c13c9f36f5a6b4775b25e2c031547e318441bcd15e5f026980.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abhishek")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-460379")[#strong[#text("Abhishek")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2015")])]

#text("I would like to understand the choice of \\rho . In particular, is there any reason to set \\rho = log(u)/log(z) in the Proof of the Rankin Trick.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-460383")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2015")])]

#text("One can try other choices of ")#mi("\\rho")#text(", but they lead to poorer bounds; the choice given is the one which optimises the bound for the given method.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-466507")[#strong[#text("Are there arbitrarily large gaps between consecutive primes? – math.stackexchange.com #JHedzWorlD | JHedzWorlD")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2016")]

#text("[…] $g$, then you should look at integers $leq e^sqrtg$ (which, for $g = 10000$ is pretty large). See this post of Terence Tao for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32065b81c16f187944d8c30e760cd8d517709c8ac8b7fd61fc96b9e15e310ac3-26bbdb9819ad9c35bc05f817557b45172536330a2f6cd94c8a4ec0de03846620.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gaps between prime-like sets | google-site-verification: google1edf67008356a9e1.html")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-480836")[#strong[#text("Gaps between prime-like sets | google-site-verification: google1edf67008356a9e1.html")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2017")])]

#text("[…] This post was inspired by a question of Trevor Wooley after a talk of James Maynard at MSRI. He asked what was known for lower bounds of large gaps between integers that have a representation as the sum of two squares. This posts assume some familiarity with the large gaps between primes problem. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db5b900080762b438dedfcf20e0fb3eb6cd6817998be40133a8b4fbc29dfac8f-ae866009f310b160c42c6dbbe0b659a31ee56709b4e37e18ad33dcbe2b148ac7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M.F.")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-486233")[#strong[#text("M.F.")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2017")])]

#text("I find it strange, ambiguous, and confusing to write “log A(log B) “. If you mean “(log A) log B” the (..) should be around the first factor. If you don’t mean this, then you must mean ” log (A log B) “, so why don’t you choose this unambiguous way of writing it? The chosen variant “log A(log B)” is no better than ” log A log B” without parentheses (and actually the latter is more likely understood (correctly?) as (log A) log B than the former). Just wondering — with all due respect!")

#emph[#text("[Typo corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/51c8beb3d67fe7e2eea8e6cfd0b9c0e152170ac67b18cbf0519d9b269e408680-8386918f01bb22904994ea2507754effbc1547cf3e0d091cdba069fc9834e743.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carl L. Lambert")]], [#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/#comment-583475")[#strong[#text("Carl L. Lambert")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2020")])]

#text("To: Terrence Tao, August 19, 2020")#linebreak()#text(" The Lambert Prime Number Formula not only produces all the prime numbers and eliminates all the composite numbers, but it also can produce all the consecutive composite number clusters. Try this:")#linebreak()#text(" n * p# + v or n * p# – v")#linebreak()#text(" … where n is any integer between 0 and infinity, the * is the multiplication")#linebreak()#text(" symbol, and # indicates the primorial function, and p is any prime number.")#linebreak()#text(" Now then, simply assign any value to v between 2 and p+1, inclusive, and a composite number will be produced, which means that, for any value of n and any particular value of p, all those values for v constitute a contiguous composite number cluster consisting of p number of composite numbers (plus more when smaller clusters are enveloped by larger clusters in the larger number ranges). This is well covered in my Treatise #9, “The Mirror Images of Contiguous Composite Number Clusters”, 2015. It is not necessary to play with factorials here because all the prime numbers used in a primorial provide all the necessary divisors to be used either side of the plus (or minus) sign to prove a result of the expression to be composite.")

#text("Example:")

#text("n * 223092827# + v")#linebreak()#text(" produces an infinite number of contiguous composite number clusters, each consisting of 223092827 consecutive composite numbers and")#linebreak()#text(" n * 223092827# – v")#linebreak()#text(" produces a different but also infinite number of contiguous composite number clusters, each consisting of 223092827 consecutive composite numbers.")

#text("Carl L. Lambert")#linebreak()#text(" #PrimeNumberGuy")
]
