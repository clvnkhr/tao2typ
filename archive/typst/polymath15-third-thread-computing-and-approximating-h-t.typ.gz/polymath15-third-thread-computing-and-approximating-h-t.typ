// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/
// Converted to Typst by tao2typ: "2026-10-14T16:38:17.508050+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath15, third thread: computing and approximating H_t", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath15, third thread: computing and approximating H_t")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 February 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/")[#text("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is the third “research” thread of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("Polymath15 project")]#text(" to upper bound the ")#link("https://en.wikipedia.org/wiki/De_Bruijn%E2%80%93Newman_constant")[#text("de Bruijn-Newman constant")]#text(" ")#mi("{\\Lambda}")#text(", continuing ")#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/")[#text("this previous thread")]#text(". Discussion of the project of a non-research nature can continue for now in ")#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/")[#text("the existing proposal thread")]#text(". Progress will be summarised at ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("this Polymath wiki page")]#text(".")

#text("We are making progress on the following test problem: can one show that ")#mi("{H_t(x+iy) \\neq 0}")#text(" whenever ")#mi("{t = 0.4}")#text(", ")#mi("{x \\geq 0}")#text(", and ")#mi("{y \\geq 0.4}")#text("? This would imply that")

#align(center)[#tao-fit-display[#mitex("\\Lambda \\leq 0.4 + \\frac{1}{2} (0.4)^2 = 0.48")]]

#text("which would be the first quantitative improvement over the de Bruijn bound of ")#mi("{\\Lambda \\leq 1/2}")#text(" (or the Ki-Kim-Lee refinement of ")#mi("{\\Lambda < 1/2}")#text("). Of course we can try to lower the two parameters of ")#mi("{0.4}")#text(" later on in the project, but this seems as good a place to start as any. One could also potentially try to use finer analysis of dynamics of zeroes to improve the bound ")#mi("{\\Lambda \\leq 0.48}")#text(" further, but this seems to be a less urgent task.")

#text("Probably the hardest case is ")#mi("{y=0.4}")#text(", as there is a good chance that one can then recover the ")#mi("{y>0.4}")#text(" case by a suitable use of the argument principle. Here we appear to have a workable Riemann-Siegel type formula that gives a tractable approximation for ")#mi("{H_t}")#text(". To describe this formula, first note that in the ")#mi("{t=0}")#text(" case we have")

#align(center)[#tao-fit-display[#mitex("H_0(z) = \\frac{1}{8} \\xi( \\frac{1+iz}{2} )")]]

#text("and the ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93Siegel_formula")[#text("Riemann-Siegel formula")]#text(" gives")

#tao-aligned(keep: true)[


#tao-math("\\xi(s)  & = \\frac{s(s-1)}{2} \\pi^{-s/2} \\Gamma(s/2) \\sum_{n=1}^N \\frac{1}{n^s}", block: true)



#tao-math(" & + \\frac{s(s-1)}{2} \\pi^{-(1-s)/2} \\Gamma((1-s)/2) \\sum_{m=1}^M \\frac{1}{m^{1-s}}", block: true)



#tao-math(" & + \\frac{s(s-1)}{2} \\pi^{-s/2} \\Gamma(s/2) \\frac{e^{-i\\pi s} \\Gamma(1-s)}{2\\pi i} \\int_{C_M} \\frac{w^{s-1} e^{-Nw}}{e^w-1}\\ dw", block: true)
]

#text("for any natural numbers ")#mi("{N,M}")#text(", where ")#mi("{C_M}")#text(" is a contour from ")#mi("{+\\infty}")#text(" to ")#mi("{+\\infty}")#text(" that winds once anticlockwise around the zeroes ")#tao-math("{e^{2\\pi im}, \\left|m\\right| \\leq M}", block: false)#text(" of ")#mi("{e^w-1}")#text(" but does not wind around any other zeroes. A good choice of ")#mi("{N,M}")#text(" to use here is ")#metadata(none) <tao-2ca7289b5248632c8fe5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("N=M=\\lfloor \\sqrt{\\mathrm{Im}(s)/2\\pi}\\rfloor = \\lfloor \\sqrt{\\mathrm{Re}(z)/4\\pi} \\rfloor.")]]



#text(" In this case, a classical steepest descent computation (see ")#link("http://michaelnielsen.org/polymath1/index.php?title=Asymptotics_of_H_t")[#text("wiki")]#text(") yields the approximation")

#align(center)[#tao-fit-display[#mitex("\\int_{C_M} \\frac{w^{s-1} e^{-Nw}}{e^w-1}\\ dw \\approx - (2\\pi i M)^{s-1} \\Psi( \\frac{s}{2\\pi i M} - N )")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\Psi(\\alpha) := 2\\pi \\frac{\\cos \\pi(\\frac{1}{2}\\alpha^2 - \\alpha - \\pi/8)}{\\cos(\\pi \\alpha)} \\exp( \\frac{i\\pi}{2} \\alpha^2 - \\frac{5\\pi i}{8} ).")]]

#text("Thus we have")

#align(center)[#tao-fit-display[#mitex("H_0(z) \\approx A^{(0)} + B^{(0)} - C^{(0)}")]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("A^{(0)}  & := \\frac{1}{8} \\frac{s(s-1)}{2} \\pi^{-s/2} \\Gamma(s/2) \\sum_{n=1}^N \\frac{1}{n^s}", block: true)



#tao-math("B^{(0)}  & := \\frac{1}{8} \\frac{s(s-1)}{2} \\pi^{-(1-s)/2} \\Gamma((1-s)/2) \\sum_{m=1}^M \\frac{1}{m^{1-s}}", block: true)



#tao-math("C^{(0)}  & := \\frac{s(s-1)}{2} \\pi^{-s/2} \\Gamma(s/2) \\frac{e^{-i\\pi s} \\Gamma(1-s)}{2\\pi i} (2\\pi i M)^{s-1} \\Psi( \\frac{s}{2\\pi i M} - N )", block: true)
]

#text("with ")#mi("{s := \\frac{1+iz}{2}}")#text(" and ")#mi("{N,M}")#text(" given by ")#link(<tao-2ca7289b5248632c8fe5>)[#text("(1)")]#text(".")

#text("Heuristically, we have derived (see ")#link("http://michaelnielsen.org/polymath1/index.php?title=Asymptotics_of_H_t")[#text("wiki")]#text(") the more general approximation")

#align(center)[#tao-fit-display[#mitex("H_t(z) \\approx A + B - C")]]

#text("for ")#mi("{t>0}")#text(" (and in particular for ")#mi("{t=0.4}")#text("), where")

#tao-aligned(keep: true)[


#tao-math("A  & := \\frac{1}{8} \\frac{s(s-1)}{2} \\pi^{-s/2} \\Gamma(s/2) \\sum_{n=1}^N \\frac{\\exp(\\frac{t}{16} \\log^2 \\frac{s+4}{2\\pi n^2} )}{n^s}", block: true)



#tao-math("B  & := \\frac{1}{8} \\frac{s(s-1)}{2} \\pi^{-(1-s)/2} \\Gamma((1-s)/2) \\sum_{m=1}^M \\frac{\\exp(\\frac{t}{16} \\log^2 \\frac{5-s}{2\\pi m^2} )}{m^{1-s}}", block: true)



#tao-math("C  & := \\exp(-\\frac{t \\pi^2}{64}) C^{(0)}.", block: true)
]

#text("In practice it seems that the ")#mi("{C}")#text(" term is negligible once the real part ")#mi("{x}")#text(" of ")#mi("{z}")#text(" is moderately large, so one also has the approximation")

#align(center)[#tao-fit-display[#mitex("H_t(z) \\approx A + B.")]]

#text("For large ")#mi("{x}")#text(", and for fixed ")#mi("{t,y>0}")#text(", e.g. ")#mi("{t=y=0.4}")#text(", the sums ")#mi("{A,B}")#text(" converge fairly quickly (in fact the situation seems to be significantly better here than the much more intensively studied ")#mi("{t=0}")#text(" case), and we expect the first term")

#align(center)[#tao-fit-display[#mitex("B_0 := \\frac{1}{8} \\frac{s(s-1)}{2} \\pi^{-(1-s)/2} \\Gamma((1-s)/2) \\exp( \\frac{t}{16} \\log^2 \\frac{5-s}{2\\pi} )")]]

#text("of the ")#mi("{B}")#text(" series to dominate. Indeed, analytically we know that ")#mi("{\\frac{A+B-C}{B_0} \\rightarrow 1}")#text(" (or ")#mi("{\\frac{A+B}{B_0} \\rightarrow 1}")#text(") as ")#mi("{x \\rightarrow \\infty}")#text(" (holding ")#mi("{y}")#text(" fixed), and it should also be provable that ")#mi("{\\frac{H_t}{B_0} \\rightarrow 1}")#text(" as well. Numerically with ")#mi("{t=y=0.4}")#text(", it seems in fact that ")#mi("{\\frac{A+B-C}{B_0}}")#text(" (or ")#mi("{\\frac{A+B}{B_0}}")#text(") stay within a distance of about ")#mi("{1/2}")#text(" of ")#mi("{1}")#text(" once ")#mi("{x}")#text(" is moderately large (e.g. ")#mi("{x \\geq 2 \\times 10^5}")#text("). This raises the hope that one can solve the toy problem of showing ")#mi("{H_t(x+iy) \\neq 0}")#text(" for ")#mi("{t=y=0.4}")#text(" by numerically controlling ")#mi("{H_t(x+iy) / B_0}")#text(" for small ")#mi("{x}")#text(" (e.g. ")#mi("{x \\leq 2 \\times 10^5}")#text("), numerically controlling ")#mi("{(A+B)/B_0}")#text(" and analytically bounding the error ")#mi("{(H_t - A - B)/B_0}")#text(" for medium ")#mi("{x}")#text(" (e.g. ")#mi("{2 \\times 10^5 \\leq x \\leq 10^7}")#text("), and analytically bounding both ")#mi("{(A+B)/B_0}")#text(" and ")#mi("{(H_t-A-B)/B_0}")#text(" for large ")#mi("{x}")#text(" (e.g. ")#mi("{x \\geq 10^7}")#text("). (These numbers ")#mi("{2 \\times 10^5}")#text(" and ")#mi("{10^7}")#text(" are arbitrarily chosen here and may end up being optimised to something else as the computations become clearer.)")

#text("Thus, we now have four largely independent tasks (for suitable ranges of “small”, “medium”, and “large” ")#mi("{x}")#text("):")

#enum(start: 1, 
[#text("Numerically computing ")#mi("{H_t(x+iy) / B_0}")#text(" for small ")#mi("{x}")#text(" (with enough accuracy to verify that there are no zeroes)")],
[#text("Numerically computing ")#mi("{(A+B)/B_0}")#text(" for medium ")#mi("{x}")#text(" (with enough accuracy to keep it away from zero)")],
[#text("Analytically bounding ")#mi("{(A+B)/B_0}")#text(" for large ")#mi("{x}")#text(" (with enough accuracy to keep it away from zero); and")],
[#text("Analytically bounding ")#mi("{(H_t - A - B)/B_0}")#text(" for medium and large ")#mi("{x}")#text(" (with a bound that is better than the bound away from zero in the previous two tasks).")]
)

#text("Note that tasks 2 and 3 do not directly require any further understanding of the function ")#mi("{H_t}")#text(".")

#text("Below we will give a progress report on the numeric and analytic sides of these tasks.")

#heading(level: 1)[#strong[#text(" — 1. Numerics report (contributed by Sujit Nair) — ")]]

#text("There is some progress on the code side but not at the pace I was hoping. Here are a few things which happened (rather, mistakes which were taken care of).")

#enum(start: 1, 
[#text("We got rid of code which wasn’t being used. For example, @dhjpolymath computed ")#mi("{H_t}")#text(" based on an old version but only realized it after the fact.")],
[#text("We implemented tests to catch human/numerical bugs before a computation starts. Again, we lost some numerical cycles but moving forward these can be avoided.")],
[#text("David got set up on GitHub and he is able to compare his output (in C) with the Python code. That is helping a lot.")]
)

#text("Two areas which were worked on were")

#enum(start: 1, 
[#text("Computing ")#mi("{H_t}")#text(" and zeroes for ")#mi("{t}")#text(" around ")#mi("{0.4}")],
[#text("Computing quantities like ")#mi("{(A+B-C)/B_0}")#text(", ")#mi("{(A+B)/B_0}")#text(", ")#mi("{C/B_0}")#text(", etc. with the goal of understanding the zero free regions.")]
)

#text("Some observations for ")#mi("{t=0.4}")#text(", ")#mi("{y=0.4}")#text(", ")#mi("{x \\in ( 10^4, 10^7)}")#text(" include:")

#list(
[#mi("{(A+B) / B_0}")#text(" does seem to avoid the negative real axis")],
[#tao-math("{\\left|(A+B) / B0\\right| > 0.4}", block: false)#text(" (based on the oscillations and trends in the plots)")],
[#tao-math("{\\left|C/B_0\\right|}", block: false)#text(" seems to be settling around ")#mi("{10^{-4}}")#text(" range.")]
)

#text("See the figure below. The top plot is on the complex plane and the bottom plot is the absolute value. The code to play with this is ")#link("https://github.com/km-git-acc/dbn_upper_bound/tree/compare_abc_b0")[#text("here")]#text(".")

#image("../assets/0863cb5da44588105c86ec7c316391ca4517ee3ece1ea4cd07b8cbaffe910855-23277155539f5db0aecc4ba898a694f0757ac04679920b0c782f72d29009507d.png", width: 90%)

#heading(level: 1)[#strong[#text(" — 2. Analysis report — ")]]

#text("The Riemann-Siegel formula and some manipulations (see ")#link("http://michaelnielsen.org/polymath1/index.php?title=Asymptotics_of_H_t")[#text("wiki")]#text(") give ")#mi("{H_0 = A^{(0)} + B^{(0)} - \\tilde C^{(0)}}")#text(", where")

#tao-aligned(keep: true)[


#tao-math("A^{(0)}  & = \\frac{2}{8} \\sum_{n=1}^N \\int_C \\exp( \\frac{s+4}{2} u - e^u - \\frac{s}{2} \\log(\\pi n^2) )\\ du", block: true)



#tao-math(" & - \\frac{3}{8} \\sum_{n=1}^N \\int_C \\exp( \\frac{s+2}{2} u - e^u - \\frac{s}{2} \\log(\\pi n^2) )\\ du", block: true)



#tao-math("B^{(0)}  & = \\frac{2}{8} \\sum_{m=1}^M \\int_{\\overline{C}} \\exp( \\frac{5-s}{2} u - e^u - \\frac{1-s}{2} \\log(\\pi m^2) )\\ du", block: true)



#tao-math(" & - \\frac{3}{8} \\sum_{m=1}^M \\int_C \\exp( \\frac{3-s}{2} u - e^u - \\frac{1-s}{2} \\log(\\pi m^2) )\\ du", block: true)



#tao-math("\\tilde C^{(0)}  & := -\\frac{2}{8} \\sum_{n=0}^\\infty \\frac{e^{-i\\pi s/2} e^{i\\pi s n}}{2^s \\pi^{1/2}} \\int_{\\overline{C}} \\int_{C_M} \\frac{w^{s-1} e^{-Nw}}{e^w-1} \\exp( \\frac{5-s}{2} u - e^u)\\ du dw", block: true)



#tao-math(" & +\\frac{3}{8} \\sum_{n=0}^\\infty \\frac{e^{-i\\pi s/2} e^{i\\pi s n}}{2^s \\pi^{1/2}} \\int_{\\overline{C}} \\int_{C_M} \\frac{w^{s-1} e^{-Nw}}{e^w-1} \\exp( \\frac{3-s}{2} u - e^u)\\ du dw", block: true)
]

#text("where ")#mi("{C}")#text(" is a contour that goes from ")#mi("{+i\\infty}")#text(" to ")#mi("{+\\infty}")#text(" staying a bounded distance away from the upper imaginary and right real axes, and ")#mi("{\\overline{C}}")#text(" is the complex conjugate of ")#mi("{C}")#text(". (In each of these sums, it is the first term that should dominate, with the second one being about ")#mi("{O(1/x)}")#text(" as large.) One can then evolve by the heat flow to obtain ")#mi("{H_t = \\tilde A + \\tilde B - \\tilde C}")#text(", where")

#tao-aligned(keep: true)[


#tao-math("\\tilde A  & := \\frac{2}{8} \\sum_{n=1}^N \\int_C \\exp( \\frac{s+4}{2} u - e^u - \\frac{s}{2} \\log(\\pi n^2) + \\frac{t}{16} (u - \\log(\\pi n^2))^2)\\ du", block: true)



#tao-math(" & - \\frac{3}{8} \\sum_{n=1}^N \\int_C \\exp( \\frac{s+2}{2} u - e^u - \\frac{s}{2} \\log(\\pi n^2) + \\frac{t}{16} (u - \\log(\\pi n^2))^2)\\ du", block: true)



#tao-math("\\tilde B  & := \\frac{2}{8} \\sum_{m=1}^M \\int_{\\overline{C}} \\exp( \\frac{5-s}{2} u - e^u - \\frac{1-s}{2} \\log(\\pi m^2) + \\frac{t}{16} (u - \\log(\\pi m^2))^2)\\ du", block: true)



#tao-math(" & - \\frac{3}{8} \\sum_{m=1}^M \\int_C \\exp( \\frac{3-s}{2} u - e^u - \\frac{1-s}{2} \\log(\\pi m^2) + \\frac{t}{16} (u - \\log(\\pi m^2))^2)\\ du", block: true)



#tao-math("\\tilde C  & := -\\frac{2}{8} \\sum_{n=0}^\\infty \\frac{e^{-i\\pi s/2} e^{i\\pi s n}}{2^s \\pi^{1/2}} \\int_{\\overline{C}} \\int_{C_M}", block: true)
]

#align(center)[#tao-fit-display[#mitex("\\frac{w^{s-1} e^{-Nw}}{e^w-1} \\exp( \\frac{5-s}{2} u - e^u + \\frac{t}{4} (i \\pi(n-1/2) + \\log \\frac{w}{2\\sqrt{\\pi}} - \\frac{u}{2})^2) \\ du dw")]]

#align(center)[#tao-fit-display[#mitex("+\\frac{3}{8} \\sum_{n=0}^\\infty \\frac{e^{-i\\pi s/2} e^{i\\pi s n}}{2^s \\pi^{1/2}} \\int_{\\overline{C}} \\int_{C_M}")]]

#align(center)[#tao-fit-display[#mitex("\\frac{w^{s-1} e^{-Nw}}{e^w-1} \\exp( \\frac{3-s}{2} u - e^u + \\frac{t}{4} (i \\pi(n-1/2) + \\log \\frac{w}{2\\sqrt{\\pi}} - \\frac{u}{2})^2)\\ du dw.")]]

#text("Steepest descent heuristics then predict that ")#mi("{\\tilde A \\approx A}")#text(", ")#mi("{\\tilde B \\approx B}")#text(", and ")#mi("{\\tilde C \\approx C}")#text(". For the purposes of this project, we will need effective error estimates here, with explicit error terms.")

#text("A start has been made towards this goal at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Effective_bounds_on_H_t")[#text("this wiki page")]#text(". Firstly there is a “")#link("https://en.wikipedia.org/wiki/Laplace_Method")[#text("effective Laplace method")]#text("” lemma that gives effective bounds on integrals of the form ")#mi("{\\int_I e^{\\phi(x)} \\psi(x)\\ dx}")#text(" if the real part of ")#mi("{\\phi(x)}")#text(" is either monotone with large derivative, or has a critical point and is decreasing on both sides of that critical point. In principle, all one has to do is manipulate expressions such as ")#mi("{\\tilde A - A}")#text(", ")#mi("{\\tilde B - B}")#text(", ")#mi("{\\tilde C - C}")#text(" by change of variables, contour shifting and integration by parts until it is of the form to which the above lemma can be profitably applied. As one may imagine though the computations are messy, particularly for the ")#mi("{\\tilde C}")#text(" term. As a warm up, I have begun by trying to estimate integrals of the form")

#align(center)[#tao-fit-display[#mitex("\\int_C \\exp( s (1+u-e^u) + \\frac{t}{16} (u+b)^2 )\\ du")]]

#text("for smallish complex numbers ")#mi("{b}")#text(", as these sorts of integrals appear in the form of ")#mi("{\\tilde A, \\tilde B, \\tilde C}")#text(". As of this time of writing, there are effective bounds for the ")#mi("{b=0}")#text(" case, and I am currently working on extending them to the ")#mi("{b \\neq 0}")#text(" case, which should give enough control to approximate ")#mi("{\\tilde A - A}")#text(" and ")#mi("{\\tilde B-B}")#text(". The most complicated task will be that of upper bounding ")#mi("{\\tilde C}")#text(", but it also looks eventually doable.")

#heading(level: 1)[#text("Comments (105)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492508")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2018")])]

#text("In the course of writing down completely effective bounds for oscillatory integrals, I needed a particular effective bound on the Stirling approximation for the Gamma function, namely that")

#tao-math("\\left|\\exp( - s \\log s + s) \\Gamma(s) - \\sqrt{\\frac{2\\pi}{s}}\\right| \\leq \\frac{1}{C \\left|s\\right|^{3/2}}", block: false)

#text("for all ")#mi("s")#text(" in the half-plane ")#mi("\\mathrm{Re}(s) > 1/2")#text(" and some absolute constant ")#mi("C")#text(". From the Stirling series I know that I can asymptotically take ")#mi("C")#text(" to be ")#mi("\\frac{12}{\\sqrt{2\\pi}}")#text(", but I need a bound which is effective for even relatively small ")#mi("s")#text(" (e.g. ")#mi("\\mathrm{Im} s \\geq 10^4")#text("). If anyone knows a reference for effective bounds on Stirling’s theorem that could provide such bounds that would be helpful.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492510")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2018")])]

#text("Abramowitz & Stegun Handbook gives such bound in 6.1.42")

#text("Additional bounds and more recent references can be found in")

#link("https://dlmf.nist.gov/5.11")[#text("https://dlmf.nist.gov/5.11")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492518")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2018")])]

#text("Section 6.3 of Edwards’ book is entitled: “Evaluation of ")#mi("\\Pi")#text(" by Euler-Maclaurin summation, Stirling’s series”. Formula (3) there is Stirling’s series for ")#mi("log(\\Pi(s))")#text(" with a remainder term. The remainder term involves the Bernoulli polynomials, defined in Section 6.2 . Edwards writes that the form of the remainder term in formula (3) is attributed to Stieltjes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92de18753b09812cfe78cbce04b76697dc7573ea3c4722016f2b8a9b4502f3a4-5e12eff0f87d0e218c957596559df00bf9c36b15eba61d0bb1667c6f3b57e4e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit Nair")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492511")[#strong[#text("Sujit Nair")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2018")])]

#text("As KM and David pointed out in the earlier thread, computing ")#mi("H_t")#text(" is expensive at large height.")

#text("KM, David, any further thoughts on efficiently computing ")#mi("{(H_t - A - B)/B_0}")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492520")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2018")])]

#text("Well, right now there are 3 ways to compute H_t. One is the ABC estimate which works well for large scale computations, and the other two are integral approaches (either the original one with cos(zu) in the integrand, or the K_(t,theta) and I(t,theta) derivation). Between the two integral approaches, the latter may do well for larger values of T, but would face the same hurdles after a point, since integrals and such oscillatory functions don’t go well together during computations.")#linebreak()#text(" David recently asked in one of the repo threads about a possible Euler Maclaurin approach.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492530")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2018")])]

#text("In the wiki page on ")#mi("H_t")#text(" asymptotics, in the section “A contour integral”, ")#mi("\\Phi")#text(" should be ")#mi("\\Psi")#text(" in the fifth displayed formula and also in the last two lines.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492532")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2018")])]

#text("From the perspective of numeric (A+B)/B0 estimates (Task 2) for t=0.4 and y=0.4, they were generated for around a million points x+yi with x between 1 and 1 million, and the behavior at the upper end had turned out to be as expected. Are there any other numerical exercises to be run to complete this task?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492541")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2018")])]

#text("Two things come to mind. Firstly, for the purposes of bounding the relative error ")#tao-math("\\left|H_t - A - B\\right|/\\left|B_0\\right|", block: false)#text(", it appears that it may be slightly more convenient to adjust the definition of ")#mi("A,B")#text(" slightly, first by approximating ")#mi("\\frac{s(s-1)}{2} \\Gamma(s/2) = 2 \\Gamma((s+4)/2) - 3 \\Gamma((s+2)/2)")#text(" by ")#mi("2 \\Gamma((s+4)/2)")#text(" and then using the Stirling approximation for ")#mi("\\Gamma")#text(". Thus, the revised definition of ")#mi("A")#text(" would be")#linebreak()#text(" ")#mi("\\displaystyle A^{\\prime} := \\frac{1}{8} 2 \\sqrt{2\\pi} \\pi^{-s/2} \\exp( (\\frac{s+4}{2} - \\frac{1}{2}) \\log \\frac{s+4}{2} - \\frac{s+4}{2})")

#mi("\\displaystyle \\sum_{n=1}^N \\frac{\\exp(\\frac{t}{16}\\log^2 \\frac{s+4}{2\\pi n^2})}{n^s}")

#text("and similarly")

#mi("\\displaystyle B^{\\prime} := \\frac{1}{8} 2 \\sqrt{2\\pi} \\pi^{-(1-s)/2} \\exp( (\\frac{5-s}{2} - \\frac{1}{2}) \\log \\frac{5-s}{2} - \\frac{5-s}{2})")

#mi("\\displaystyle \\sum_{m=1}^M \\frac{\\exp(\\frac{t}{16}\\log^2 \\frac{5-s}{2\\pi m^2})}{m^{1-s}}")

#text("Of course the main term ")#mi("B^{\\prime}_0")#text(" of ")#mi("B^{\\prime}")#text(" will similarly adjust to")

#mi("\\displaystyle B^{\\prime}_0 := \\frac{1}{8} 2 \\sqrt{2\\pi} \\pi^{-(1-s)/2}")

#mi("\\displaystyle \\exp( (\\frac{5-s}{2} - \\frac{1}{2}) \\log \\frac{5-s}{2} - \\frac{5-s}{2} + \\frac{t}{16}\\log^2 \\frac{5-s}{2\\pi})")#text(".")

#text("Presumably the numerical behaviour of ")#mi("A^{\\prime}+B^{\\prime}")#text(" should be nearly identical to that of ")#mi("A+B")#text(" once ")#mi("x")#text(" is moderately large, but it is worth checking, as well as testing the accuracy of the ")#mi("A^{\\prime}+B^{\\prime}")#text(" and ")#mi("A+B")#text(" approximations to ")#mi("H_t")#text(" at some medium-sized values of ")#mi("x")#text(". It may be that A’ and B’ are in fact a little better to work with numerically in any case, as I would imagine that exponentials and logarithms are slightly faster to compute than Gamma functions. There is an analogous correction to be made to ")#mi("C")#text(", but this term is so small that probably we will be bounding it analytically even for relatively small values of ")#mi("x")#text(" so I don’t think it is worth trying to compute it too exactly at this time.")

#text("The other thing is not entirely numerical, but we would need to somehow control ")#mi("(A+B)/B_0")#text(" or ")#mi("(A^{\\prime}+B^{\\prime})/B^{\\prime}_0")#text(" between the mesh points as well as on the mesh points. The crudest thing to do is to use some upper bound on the derivative ")#mi("\\frac{d}{dx} (A+B)/B_0")#text(" or ")#mi("\\frac{d}{dx} (A^{\\prime}+B^{\\prime})/B^{\\prime}_0")#text(" at these points (bearing in mind that the ")#mi("N=M = \\sqrt{\\lfloor x / 4\\pi \\rfloor}")#text(" variable has discrete jumps), and hope that the fundamental theorem of calculus bound is enough to keep ")#mi("(A+B)/B_0")#text(" or ")#mi("(A^{\\prime}+B^{\\prime})/B^{\\prime}_0")#text(" away from zero outside of the mesh points as well. For instance, we have")

#mi("\\displaystyle B/B_0 = B^{\\prime}/B^{\\prime}_0 =  \\sum_{m=1}^M \\frac{\\exp(\\frac{t}{16}\\log^2 \\frac{5-s}{2\\pi m^2} - \\frac{t}{16} \\log^2 \\frac{5-s}{2\\pi})}{m^{1-s}}")

#text("and the ")#mi("x")#text(" derivative (bearing in mind that ")#mi("s = \\frac{1+ix-y}{2}")#text(", and staying away from the points where ")#mi("N=M")#text(" jumps) contains a term of the form")

#mi("\\displaystyle \\frac{i}{2} \\sum_{m=1}^M \\frac{\\exp(\\frac{t}{16}\\log^2 \\frac{5-s}{2\\pi m^2} - \\frac{t}{16} \\log^2 \\frac{5-s}{2\\pi})}{m^{1-s}} \\log m")

#text("(plus some terms coming from differentiating the logarithm functions, which I think will be lower order and will thus be ignored for the current discussion) which can be bounded in absolute value using the triangle inequality by")

#mi("\\displaystyle \\frac{i}{2} \\sum_{m=1}^M \\frac{\\exp( \\frac{t}{16} \\mathrm{Re}( \\log^2 \\frac{5-s}{2\\pi m^2} - \\log^2 \\frac{5-s}{2\\pi}) )}{m^{\\frac{1+y}{2}}} \\log m.")

#text("This is just one term in the eventual upper bound for ")#tao-math("\\frac{d}{dx} \\left|A^{\\prime}+B^{\\prime}\\right|/\\left|B^{\\prime}\\right|", block: false)#text(", but it is presumably typical (the other terms are messier though); one could evaluate this at a few values of ")#mi("x")#text(" to get some sense of what the derivative might look like, which would indicate what mesh size one would need to keep the function bounded away from zero (basically the mesh size would be the distance from zero at the mesh points divided by the largest value of the derivative).")

#text("If it turns out that this simple approach requires a numerically prohibitive mesh size, one could try more advanced things involving control of second or higher derivatives and using a more advanced interpolation formula than the fundamental theorem of calculus (alternatively one could also start computing first or higher derivatives of ")#mi("A^{\\prime}+B^{\\prime}/B^{\\prime}_0")#text(" at mesh points and using some sort of Taylor theorem with remainder).")

#emph[#text("[Several factors of ")#mi("t")#text(" corrected to ")#mi("t/16")#text(". -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492547")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2018")])]

#text("Thanks. I will run the computations along these lines.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492601")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2018")])]

#text("The (truncated) expressions for ")#mi("A^{\\prime}, B^{\\prime}, B^{\\prime}_0")#text(" are “too long” (for one line).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492654")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2018")])]

#text("I think the t in the above formulas should be t/16. Just tested the adjusted formula for some values and the agreement is good (gets much better with higher T)")

#text("for eg. for z=1000+0.4j")#linebreak()#text(" A+B = -4.794e-168 + 3.127e-167j")#linebreak()#text(" A’+B’ = -5.165e-168 + 3.135e-167j")#linebreak()#text(" d/dx(B’/B’0) = -0.215 – 0.209j")

#text("for eg. for z=100000+0.4j")#linebreak()#text(" A+B = -9.32670e-17047 + 4.38004e-17047j")#linebreak()#text(" A’+B’ = -9.32705e-17047 + 4.37969e-17047j")#linebreak()#text(" d/dx(B’/B’0) = 0.21478 + 0.05395j")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492658")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2018")])]

#text("Good catch, thanks! (This is one key role that numerics will be playing, by the way – catching sign errors and other typos from the analysis side of things.)")

#text("ADDED LATER: By the way, do you have a sense on the relative size of the A and B terms once one is away from the real axis (on the real axis they should of course be complex conjugates of each other). If the A term is much smaller than the B term in practice then we may be able to get away with bounding it by rather crude estimates.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492682")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2018")])]

#text("On evaluating |B/A| in a grid of (x,y,t) where x is powers of 10, we see it increasing at an accelerating pace as x or y or t are increased.")

#text("These are some sample values where |B/A| is around 10 for t=0.4")#linebreak()#text(" val1=|B/A| for t=0.4")#linebreak()#text(" val2=|B’/A’| for t=0.4")#linebreak()#text(" val3=|B/A| for t=0.0")

#text("z—————val1—-val2—-val3")#linebreak()#text(" 10^3+1.1i—-11.74—11.74—7.92")#linebreak()#text(" 10^4+0.8i—-10.55—10.55—5.87")#linebreak()#text(" 10^5+0.6i—-11.39—11.39—5.05")#linebreak()#text(" 10^6+0.5i—-11.35—11.35—3.96")#linebreak()#text(" 10^7+0.4i—-10.75—10.75—3.63")

#text("for t=0.4, y=1.3, x=10^5, |B/A| = 132.03")

#text("Also, the script evaluating d/dx(B’/B’0) and (A’+B’)/B’0 has been able to run for around 0.7 million points.")

#text("Max value of |d/dx(B’/B’0)| seems to be fluctuating but decreasing slowly, while the avg and stdev values decrease more consistently (does not include mesh points which have jumps in N=M)")

#text("val=|d/dx(B’/B0′)|")#linebreak()#text(" T range——max val—–avg val—–stdev val")#linebreak()#text(" ———————————————–")#linebreak()#text(" upto 1k——1.04——–0.33——–0.19")#linebreak()#text(" 1k-2k——–1.25——–0.39——–0.24")#linebreak()#text(" 2k-3k——–1.31——–0.39——–0.25")#linebreak()#text(" 3k-4k——–1.39——–0.38——–0.27")#linebreak()#text(" 4k-5k——–1.64——–0.37——–0.26")#linebreak()#text(" 5k-6k——–1.60——–0.36——–0.27")#linebreak()#text(" 6k-7k——–1.61——–0.36——–0.26")#linebreak()#text(" 7k-8k——–1.55——–0.36——–0.27")#linebreak()#text(" 8k-9k——–1.65——–0.34——–0.26")#linebreak()#text(" 9k-10k——-1.47——–0.34——–0.26")#linebreak()#text(" ————————————————–")#linebreak()#text(" upto 100k—-1.78——–0.28——–0.23")#linebreak()#text(" 100k-200k—-1.66——–0.22——–0.18")#linebreak()#text(" 200k-300k—-1.55——–0.20——–0.17")#linebreak()#text(" 300k-400k—-1.53——–0.19——–0.16")#linebreak()#text(" 400k-500k—-1.31——–0.18——–0.15")#linebreak()#text(" 500k-600k—-1.34——–0.18——–0.14")#linebreak()#text(" 600k-700k—-1.33——–0.17——–0.14")

#text("at z = 28608+0.4i, we get the derivative value (-0.74 + 1.61i) leading to the abs value ~ 1.78 above.")

#text("min and max values of the real and imaginary parts of d/dx(B’/B0′) show a similar trend")#linebreak()#text(" val = d/dx(B’/B0′)")#linebreak()#text(" val1=min(real(val))")#linebreak()#text(" val2=max(real(val))")#linebreak()#text(" val3=min(imag(val))")#linebreak()#text(" val2=max(imag(val))")#linebreak()#text(" T range——val1——val2—-val3——val4")#linebreak()#text(" ——————————————————")#linebreak()#text(" upto 100k—-(1.48)—-1.52—-(1.05)—-1.73")#linebreak()#text(" 100k-200k—-(1.40)—-1.33—-(0.79)—-1.65")#linebreak()#text(" 200k-300k—-(1.15)—-1.26—-(0.67)—-1.49")#linebreak()#text(" 300k-400k—-(1.27)—-1.13—-(0.67)—-1.49")#linebreak()#text(" 400k-500k—-(1.11)—-1.08—-(0.60)—-1.31")#linebreak()#text(" 500k-600k—-(1.04)—-1.03—-(0.49)—-1.30")#linebreak()#text(" 600k-700k—-(1.03)—-1.00—-(0.47)—-1.27")

#text("Also, for t=0.4, the deviation between (A+B)/B0 and (A’+B’)/B’0 is pretty small after x=1000")

#text("val=|(A+B)/B0-(A’+B’)/B’0|/|(A+B)/B0|")

#text("T range——max val")#linebreak()#text(" ————————-")#linebreak()#text(" upto 1k——-1.031")#linebreak()#text(" 1k-2k———-0.009")#linebreak()#text(" 2k-3k———-0.004")#linebreak()#text(" upto 100k—-1.031")#linebreak()#text(" 100k-200k—-3.548E-05")#linebreak()#text(" 200k-300k—-1.535E-05")#linebreak()#text(" 300k-400k—-9.097E-06")#linebreak()#text(" 400k-500k—-6.636E-06")#linebreak()#text(" 500k-600k—-4.839E-06")#linebreak()#text(" 600k-700k—-3.963E-06")

#text("In fact the largest value occurs at x=28, and between x=100 to 1000, the average deviation is ~ 1.3%")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492690")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2018")])]

#text("Thanks for this! Is this the exact derivative of B’/B’_0, or the upper bound for it that I gave previously? I guess it must be the former since the latter wouldn’t oscillate as much as you indicated. In either case it suggests that a unit spacing mesh size will not quite be sufficient to rigorously lower bound (A+B)/B_0 or (A’+B’)/B’_0 in the above ranges, though we “only” have to refine the mesh size by an order of magnitude so we are still within the range of computational feasibility (as long as we don’t have to increase x too much).")

#text("It does seem that A is only a smaller than B than one order of magnitude, so we have a little bit of room to estimate A by crude estimates but not too much room. (One could imagine for instance evaluating A on a slightly coarser mesh than B to save on some computing time.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492683")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2018")])]

#text("Assuming conservatively that |d/dx(B’/B’0)| is around 2, and having observed earlier that |(A+B)/B0| (and hence also it’s adjusted version) starts staying above 0.4 at the integer mesh points consistently beyond x=10^5, can we consider a mesh size of 0.2 between x=10^5 and 10^6 to make the estimates effective for this region?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492710")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2018")])]

#text("Yeah, I had calculated the modulus of the complex valued d/dx(B’/B’_0). On using the triangle inequality estimate for around 0.5 million points, we notice a higher bound (and quite low variance in the bound for a given M).")

#text("T range———max of upper bound |d/dx(B’/B’_0)|")#linebreak()#text(" upto 30k——–2.320")#linebreak()#text(" 30k-60k———2.341")#linebreak()#text(" 60k-90k———2.336")#linebreak()#text(" 90k-120k——–2.311")#linebreak()#text(" ————————")#linebreak()#text(" upto 100k——-2.341")#linebreak()#text(" 100k-200k——-2.299")#linebreak()#text(" 200k-300k——-2.195")#linebreak()#text(" 300k-400k——-2.109")#linebreak()#text(" 400k-500k——-2.039")

#text("Maximum of 2.341 occurs around x ~ 48000, after which there is a general decline.")

#text("With the integer x mesh points, min value of |A’+B’|/|B’_0| is above 0.43 after x ~ 20k (and above 0.39 after x ~ 10k), which suggests a mesh size below 0.15. Having the mesh size as 0.1 would also leave some buffer.")

#text("Also, for faster computation of A’ and B’,")#linebreak()#text(" using log(z1)^2 – log(z2)^2 = log(z1*z2)log(z1/z2)")#linebreak()#text(" and making some manipulations, we can compute B’ as")

#text("B’ = B’_0 * sum_(1 to M)_[1/m^(B_exponent – (t/4)logm)]")#linebreak()#text(" and correspondingly defining an A’_0 term,")#linebreak()#text(" A’ = A’_0 * sum_(1 to N)_[1/n^(A_exponent – (t/4)logn)]")

#text("where B_exponent = 1 – s + (t/4)log[(5-s)/(2*PI)]")#linebreak()#text(" and A_exponent = s + (t/4)log[(s+4)/(2*PI)]")

#text("Since the summation is the bulk operation, and two power operations have been reduced to 1, we expect around a 2x speedup. Running some sample tests, we do observe such a speedup in practice while evaluating H_t as A’+B’.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492792")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2018")])]

#text("That’s not as bad as I had feared – it sounds like a mesh size of 0.10 is feasible to work with as long as x doesn’t have to get much larger than ")#mi("10^6")#text(", and maybe we can push to ")#mi("10^7")#text(" or ")#mi("10^8")#text(" with further speedups and maybe some serious computer power. Hopefully the bound on the error estimates begins to become good before this range!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492534")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2018")])]

#text("Also, a separate exercise was run where the normalized stdev of the zero gaps (stdev/avg) was evaluated by estimating a few hundred roots near powers of 10 for multiple t.")

#text("normalized stdev for zero gaps (metric)")#linebreak()#text(" ————-t")#linebreak()#text(" T height—-0.50—-0.45—-0.40—-0.35—-0.30—-0.25—-0.20—-0.15—-0.10—-0.05—-0.00")#linebreak()#text(" ———————————————————————————————-")#linebreak()#text(" near 10^3—21.0%—22.2%—23.4%—24.8%—26.3%—27.9%—29.7%—31.7%—33.9%—36.2%—39.2%")#linebreak()#text(" near 10^4—13.7%—14.9%—16.7%—18.5%—19.8%—22.0%—24.4%—27.2%—30.6%—34.5%—39.9%")#linebreak()#text(" near 10^5—-7.3%—-8.4%—-9.7%—11.2%—13.2%—15.5%—18.3%—21.8%—26.2%—32.0%—40.3%")#linebreak()#text(" near 10^6—-4.0%—-4.7%—-5.6%—-6.9%—-8.2%—10.2%—12.9%—16.3%—21.2%—28.1%—40.7%")#linebreak()#text(" near 10^7—-2.4%—-2.8%—-3.4%—-4.2%—-5.2%—-6.8%—-8.9%—12.1%—16.3%—23.8%—41.0%")

#text("Away from t=0 and as T increases, we get smooth trends in how the metric evolves. This could be used, for example, to predict for a given t at what T height the metric would reach a desired target, say 1%. If there is a rough relation between such T and beyond which the analytically derived zero free region starts, it could also provide a better idea of the expected numerical effort.")

#text("Interestingly, for t=0 the behavior of the metric is quite different from that of t>0. It seems to increase as T increases. For t=0, no roots were estimated separately. Instead, 10000 zeta zeroes near each power of 10 were used, as generated by Platt and Odlyzko (which allows us to check the behavior even near 10^22)")

#text("normalized stdev for H_0 zero gaps")#linebreak()#text(" T height——–metric——-metric using 25th to 75th %tile gaps")#linebreak()#text(" near 10^3——39.23%")#linebreak()#text(" near 10^4——39.90%")#linebreak()#text(" near 10^5——40.30%—–15.75%")#linebreak()#text(" near 10^6——40.73%—–16.08%")#linebreak()#text(" near 10^7——41.05%—–16.12%")#linebreak()#text(" near 10^8——41.48%—–16.44%")#linebreak()#text(" near 10^9——41.62%—–16.85%")#linebreak()#text(" near 10^10—–41.92%—–16.79%")#linebreak()#text(" near 2*10^12–42.03%—–16.75%")#linebreak()#text(" near 2*10^21–42.37%—–17.13%")#linebreak()#text(" near 2*10^22–41.93%—–16.55%")

#text("To counter the GUE distribution effect, and bring it closer to a normal distribution, the same metric was also observed for H_0 gaps lying in the 2th to 75th percentile. While the behavior is weaker, it still seems to be increasing. It may be worth investigating whether such behavior holds for H_0 at even larger values of T.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492535")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2018")])]

#text("Minor correction – that should be the 25th percentile in the last paragraph. Also, the upper table is wrapping around, so posting some plots instead.")

#link("https://imgur.com/a/pO9wW")[#text("https://imgur.com/a/pO9wW")]#linebreak()#text(" ")#link("https://imgur.com/a/u2AiR")[#text("https://imgur.com/a/u2AiR")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492542")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2018")])]

#text("Does the vertical axis of the bottom-right plot need updating? Currently it shows some |C/B0| values as negative.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492545")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2018")])]

#text("In the expression for ")#mi("B_0")#text(", should ")#mi("5-s")#text(" instead be ")#mi("(5-s)/\\pi")#text("?")

#emph[#text("[Corrected, thanks – in fact there was also factor of 2 in the denominator that was missing also. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492602")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2018")])]

#text("I think I may have a better way of analytically estimating the various components of ")#mi("H_t")#text(" than is in the wiki that seems to involve a little less computation. It follows a suggestion made some time back to exploit the fundamental solution to the backwards heat equation ")#mi("\\partial_t H_t(z) = - \\partial_{zz} H_t(z)")#text(" of ")#mi("H_t")#text(". It is convenient to work in the ")#mi("s = \\frac{1+iz}{2}")#text(" coordinates, thus ")#mi("H_t(z) = \\frac{1}{8} \\xi_t(\\frac{1+iz}{2})")#text(" where ")#mi("\\xi_t")#text(" solves the forward heat equation ")#mi("\\partial_t \\xi_t(s) = \\frac{1}{4} \\partial_{ss} \\xi_t(s)")#text(" with initial data ")#mi("\\xi_0(s) = \\xi(s)")#text(" the Riemann xi function. The fundamental solution then gives")

#mi("\\displaystyle \\xi_t(s) = \\int_{-\\infty}^\\infty \\xi(s + \\sqrt{t} w) \\frac{1}{\\sqrt{\\pi}} e^{-w^2}\\ dw.")

#text("So one is interested in computing expressions of the form")

#mi("\\displaystyle F_t(s) :=  \\int_{-\\infty}^\\infty F_0(s + \\sqrt{t} w) \\frac{1}{\\sqrt{\\pi}} e^{-w^2}\\ dw")

#text("for various meromorphic functions ")#mi("F_0(s)")#text(", in particular the terms that arise in the Riemann-Siegel formula such as ")#mi("\\frac{s(s-1)}{2} \\pi^{-s/2} \\Gamma(s/2) \\frac{1}{n^s}")#text(". One can of course use the triangle inequality to bound this by")

#mi("\\displaystyle  \\int_{-\\infty}^\\infty |F_0(s + \\sqrt{t} w)| \\frac{1}{\\sqrt{\\pi}} e^{-w^2}\\ dw")

#text("but this is only a good estimate when ")#mi("F_0")#text(" does not oscillate too much near ")#mi("s")#text(". It seems that for the error term ")#mi("\\frac{s(s-1)}{2} \\pi^{-s/2} \\Gamma(s/2) \\frac{e^{-i\\pi s} \\Gamma(1-s)}{2\\pi i} \\int_{C_M} \\frac{w^s e^{-Nw}}{e^w-1}\\ dw")#text(", there is in fact not much oscillation in the total expression (there is a lot of oscillation in individual factors, but it turns out that they largely cancel out in the product) and this could actually be a rather good way of controlling the heat flow for this term. For other terms such as ")#mi("\\frac{s(s-1)}{2} \\pi^{-s/2} \\Gamma(s/2) \\frac{1}{n^s}")#text(", there is a fair bit of oscillation and exponential growth, but one can deal with this by a change of variables. Indeed for each of the terms ")#mi("F_0")#text(" that show up, and at each point ")#mi("s")#text(" of interest, there is a complex number ")#mi("\\alpha")#text(" for which ")#mi("F_0")#text(" behaves like ")#mi("e^{\\alpha s}")#text(" in the sense that")

#mi("\\displaystyle  F_0(s^{\\prime}) = e^{\\alpha (s^{\\prime}-s)} G(s^{\\prime})")

#text("for ")#mi("s^{\\prime}")#text(" near ")#mi("s")#text(" and some meromorphic function ")#mi("G")#text(" that doesn’t oscillate or grow too much near ")#mi("F_0")#text(". For instance if ")#mi("F_0")#text(" is ")#mi("\\frac{s(s-1)}{2} \\pi^{-s/2} \\Gamma(s/2) \\frac{1}{n^s}")#text(" then ")#mi("\\alpha")#text(" can be taken to be ")#mi("\\frac{1}{2} \\log \\frac{s+4}{2\\pi n^2}")#text(", basically thanks to Stirling’s formula. After contour shifting ")#mi("w")#text(" by ")#mi("\\sqrt{t} \\alpha / 2")#text(" (assuming that we don’t run into any poles, but I think this will not be an issue as ")#mi("\\alpha")#text(" will be relatively small compared to the imaginary part of ")#mi("s")#text(" in our application), one can check that the heat evolution")

#mi("\\displaystyle F_t(s) = \\int_{-\\infty}^\\infty F_0(s + \\sqrt{t} w) \\frac{1}{\\sqrt{\\pi}} e^{-w^2}\\ dw")

#text("can be rewritten as")

#mi("\\displaystyle F_t(s) = \\exp( \\frac{t}{4} \\alpha^2 ) \\int_{-\\infty}^\\infty G(s + \\sqrt{t} w + \\frac{t}{2} \\alpha) \\frac{1}{\\sqrt{\\pi}} e^{-w^2}\\ dw")

#text("(this is related by the way to the Galilean symmetry of the Schrodinger equation). In particular if ")#mi("G")#text(" is so slowly varying that one can approximate ")#mi("G(s + \\sqrt{t} w + \\frac{t}{2} \\alpha)")#text(" to high accuracy by ")#mi("G(s) = F_0(s)")#text(", then we have")

#mi("\\displaystyle F_t(s) \\approx \\exp( \\frac{t}{4} \\alpha^2 ) F_0(s)")

#text("which is basically where the ")#mi("A+B-C")#text(" approximation to ")#mi("H_t")#text(" is coming from.")

#text("I am cautiously optimistic that all this can be made explicitly effective with reasonable constants, particularly because we can use effective Stirling formula asymptotics which have already been worked out in the literature to deal with all the Gamma function factors. Will work on this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492651")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2018")])]

#text("By using some Gamma function estimates ")#link("http://www.jstor.org/stable/52450")[#text("of Boyd")]#text(", I have been able to implement the above strategy to get effective asymptotics (with explicit error terms) for the first two terms ")#mi("\\tilde A, \\tilde B")#text(" of the decomposition ")#mi("H_t = \\tilde A + \\tilde B - \\tilde C")#text(" in the blog post, see ")#link("http://michaelnielsen.org/polymath1/index.php?title=Effective_bounds_on_H_t_-_second_approach")[#text("this wiki page")]#text(". This is a work in progress and so one should not take the bounds too seriously yet, but the error term of each summand in ")#mi("\\tilde A")#text(" is about ")#mi("O(1/x)")#text(" of the corresponding term in ")#mi("A")#text(" which is a good sign (however, there seems to be significant cancellation in the ")#mi("A")#text(" summation and one cannot necessarily assume that there is analogous cancellation for the error terms in the worst-case analysis, so the final relative error may not be as good as this). Similarly for the ")#mi("\\tilde B")#text(" terms. One thing that emerged from the computations is that the approximant to ")#mi("\\tilde A")#text(" that emerges from the heat flow analysis differs very slightly from the original approximation ")#mi("A")#text(" and also from the revised version ")#mi("A^{\\prime}")#text(" above, however I think these differences are inessential (the difference between the various approximations is of order comparable to the error of any of these to the true sum ")#mi("\\tilde A")#text("). It seems possible to push the asymptotic computations further and obtain a more complicated approximation with an error that is only ")#mi("O(1/x^2)")#text(" as large, but this is probably overkill for our application.")

#text("To upper bound the final term ")#mi("\\tilde C")#text(" of the decomposition one will need explicit bounds for the error term in the Riemann-Siegel formula. There is extensive literature on this as long as one stays on the critical line (the main reference seems to be this ")#link("https://pdfs.semanticscholar.org/802b/b98d33aa59a6ff431cc5482334e67e095968.pdf")[#text("thesis of Gabke")]#text("), but we will definitely need estimates away from the critical line and so far I have not been able to locate existing references that do this effectively. However the estimation of this error term is a quite classical steepest descent problem (it’s done in Section 4.14 of Titchmarsh for instance, but not with explicit constants) and it should just be a matter of performing the calculation (though it is slightly annoying because the deformed contour is a weird shape, one needs something that looks a bit like a half-infinite rectangle with a corner cut off, leading to three or four separate integrals to estimate; but all but one of them should be exponentially small).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492653")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2018")])]

#text("In the wiki page on effective bounds on ")#mi("H_t")#text(" (second approach), it seems that in the definition of ")#mi("\\epsilon_n")#text(" a second integral symbol is missing, and in the second and third upper bounds on ")#mi("\\epsilon_n")#text(", the integrals should be (as already stated there) over the positive axis. Perhaps the resulting bound should be corrected accordingly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492660")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2018")])]

#text("Thanks for the correction! Actually I intended to estimate the gaussian integral on the positive real axis by the integral on the entire line because I have an explicit formula for the latter and not the former. One could be slightly more precise by using the error function erf instead but this leads to an even more complicated bound and I think the gain is rather tiny in practice. (There is definitely a tradeoff in the precision of the error estimate, and how simple the estimate looks. I think it is safe to be somewhat wasteful with lower order errors, such as those of size ")#mi("1/x^2")#text(" or ")#mi("e^{-cx}")#text(" times the main term, if it helps in cleaning up the form of the estimate; it is only the main components of the error, comparable to ")#mi("1/x")#text(" times the main term, that are worth being particularly frugal with.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5869d8b1448ca10fca0bd94d7cbc089633423849ab93255b0123f887992ce41a-6ba6395656430792a6ea6ae7d9ac3e6b5677fa135c4d519e4810981160304521.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492661")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2018")])]

#text("It seems that the paper of Arias de Reyna contains some effective estimation of Riemann-Siegel type formula away from the critical line, see ")#link("https://pdfs.semanticscholar.org/7964/fbdc0caeec0a41304deb8d2d8b2e2be639ee.pdf")[#text("https://pdfs.semanticscholar.org/7964/fbdc0caeec0a41304deb8d2d8b2e2be639ee.pdf")]#text(" .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492664")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2018")])]

#text("This looks very useful, thanks! I’ll see what they produce.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492691")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2018")])]

#text("I’ve now reworked the computations at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Effective_bounds_on_H_t_-_second_approach")[#text("http://michaelnielsen.org/polymath1/index.php?title=Effective_bounds_on_H_t_-_second_approach")]#text(" using the Arias de Reyna effective Riemann-Siegel formula to give a completely effective approximation to ")#mi("H_t")#text(". It was convenient to change coordinates and write")

#mi("H_t(z) = \\frac{1}{8} \\xi_t( s )")

#text("where ")#mi("s = \\frac{1+iz}{2} = \\sigma+iT")#text(" with ")#mi("\\sigma = \\frac{1-y}{2}")#text(" and ")#mi("T =\\frac{x}{2}")#text(". The explicit formula for ")#mi("\\xi_t(s)")#text(" is given in the final section of the above wiki. The formula is messy, but the main terms (analogous to the A+B approximation to ")#mi("H_t")#text(") are")

#mi("\\xi_t(s) \\approx \\exp( \\frac{t}{4} \\alpha_1(\\sigma+iT)^2 ) H_{0,1}(\\sigma+iT)")#linebreak()#text(" ")#mi("\\sum_{n=1}^N \\frac{1}{n^{\\sigma+iT + \\frac{t}{2} \\alpha_1(\\sigma+iT) - \\frac{t}{4} \\log n}}")#linebreak()#text(" ")#mi("+ \\exp( \\frac{t}{4} \\overline{\\alpha_1(1-\\sigma+iT)^2} ) \\overline{H_{0,1}(1-\\sigma+iT)}")#linebreak()#text(" ")#mi("\\sum_{n=1}^N \\frac{1}{n^{1-\\sigma-iT + \\frac{t}{2} \\overline{\\alpha_1(1-\\sigma+iT)} - \\frac{t}{4} \\log n}}")

#text("where")

#mi("\\alpha_1(s) := \\frac{1}{2s} + \\frac{1}{s-1} + \\frac{1}{2} \\log \\frac{s}{2\\pi}")

#mi("H_{0,1}(s) := \\frac{s(s-1)}{2} \\pi^{-s/2} \\sqrt{2\\pi} \\exp( (\\frac{s}{2}-\\frac{1}{2}) \\log \\frac{s}{2} - \\frac{s}{2}).")

#mi("N := \\lfloor \\sqrt{(T - \\pi t/8) / 2\\pi} \\rfloor = \\lfloor \\sqrt{(x - \\pi t / 4) / 4 \\pi} \\rfloor")

#text("This is a slight variant of the A’+B’ type approximation used previously (which replaced ")#mi("\\alpha_1(s)")#text(" by the slightly different quantity ")#mi("\\frac{1}{2} \\log \\frac{s+4}{2\\pi n^2}")#text(", and also took ")#mi("N")#text(" to equal ")#mi("\\lfloor \\sqrt{T/2\\pi}\\rfloor")#text(" rather than ")#mi("\\lfloor \\sqrt{(T-\\pi t/8)/2\\pi} \\rfloor")#text("). It should ultimately lead to almost the same approximation (in much the same way that A+B is close to A’+B’ in practice). The dominant term (analogous to B_0) should be the first term ")#mi("\\exp( \\frac{t}{4} \\overline{\\alpha_1(1-\\sigma+iT)} ) \\overline{H_{0,1}(1-\\sigma+iT)}")#text(" in the second sum.")

#text("There are three terms in the error estimate. The final term is an integral which should be numerically computable (it depends on a prescribed lower bound ")#mi("T_0")#text(" for ")#mi("T")#text(") and should be quite small (it is analogous to the “C” term). Then there are two other errors called ")#mi("\\epsilon^{\\prime}(s), \\epsilon^{\\prime}(1-s)")#text(" which I believe are even smaller expressions. They are given as sums of size N so their computation is about as difficult as computation of the A,B terms, but there is a crude upper bound for these terms in (3.8) of the wiki page which is quicker to compute and possibly might be enough for applications.")

#text("This should give a rigorous bound of the form ")#tao-math("\\left|H_t - \\tilde A - \\tilde B\\right|/\\left|\\tilde B_0\\right| \\leq \\epsilon", block: false)#text(" for some variants ")#mi("\\tilde A, \\tilde B, \\tilde B_0")#text(" of ")#mi("A,B,B_0")#text(" and some computable ")#mi("\\epsilon")#text(". If we can get this error ")#mi("\\epsilon")#text(" down to below about 0.4 as soon as ")#mi("x")#text(" exceeds say ")#mi("10^4")#text(" then we will be well on track to rigorously keeping ")#mi("H_t(x+iy)")#text(" away from zero for ")#mi("t=y=0.4")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5869d8b1448ca10fca0bd94d7cbc089633423849ab93255b0123f887992ce41a-6ba6395656430792a6ea6ae7d9ac3e6b5677fa135c4d519e4810981160304521.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492692")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2018")])]

#text("Dear Prof. Tao, I am not sure whether there is a sign error in the final bound for H_t in the wiki. The factor e^{\\pi T/4} in the last term of (5.1) grows exponentially as T tends to infinity,while H_0 decays exponentially to zero.")

#emph[#text("[This was indeed a typo – now corrected, I think. Thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492701")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2018")])]

#text("Since for large ")#mi("T_0")#text(" the integral in the final bound should be (as stated) close to ")#mi("1")#text(", it seems simpler for sufficiently large ")#mi("T_0")#text(" to replace it by a suitable upper bound close to ")#mi("1")#text(" (e.g. in ")#mi("[1.1, 2]")#text(")")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492702")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2018")])]

#text("for ")#mi("t > 0")#text(", is this effective approximation to ")#mi("H_t")#text(" sufficiently strong to imply an effective upper bound (as explicit function of ")#mi("t")#text(") for the real part of any (hypothetical) nonreal zero of ")#mi("H_t")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492791")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2018")])]

#text("Yes, I believe this should be the case; my preliminary expectation would be that the upper bound to be roughly of the form ")#mi("O( \\exp( O(1/t) ) )")#text(". It is worth working this out properly at some point, though it probably won’t be directly necessary for the project.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492778")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2018")])]

#text("I have tested the H_t effective approx formula and compared it with the ABC estimate for some values. At large T, the agreement seems good, but some more testing is left. Also, some work is left (the vwf integral) on the error estimation part.")

#text("Some minor corrections in the formulas in the comment (they are correct in the wiki):")

#text("-> (t/4)*alpha should be (t/4)*alpha^2 (similarly for the conjugate one)")#linebreak()#text(" -> alpha_1 won’t have the n^2 factor")#linebreak()#text(" -> In the second summation, the exponent should start as 1- sigma – iT instead of 1-sigma+iT (unlike everywhere else in the formula).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492793")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2018")])]

#text("Many thanks for the corrections! It’s good that people aren’t just plugging in these formulae blindly, they should definitely be tested numerically and not just taken on faith.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492809")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2018")])]

#text("It is not clear (from its definition) how the new ")#mi("H_{0,1}")#text("– based approximation gives (approximately) the (previous approximation) main terms of ")#mi("H_t(x)")#text(" (with its exponential decay in ")#mi("x")#text(")")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492829")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2018")])]

#text("It comes from the imaginary part of the logarithm. If ")#mi("s = \\sigma+iT")#text(" with ")#mi("T = x/2")#text(" large, then ")#mi("\\log \\frac{s}{2}")#text(" has imaginary part close to ")#mi("\\pi/2")#text(", which gives a contribution of about ")#mi("- \\pi T/4 = - \\pi x/8")#text(" to the real part of ")#mi("\\frac{s}{2}-\\frac{1}{2})\\log \\frac{s}{2} - \\frac{s}{2}")#text(", which gives a factor of ")#mi("\\exp(-\\pi x/8)")#text(" in ")#mi("H_{0,1}")#text(". (See also the Gamma function approximation in equation (1.7) of ")#link("http://michaelnielsen.org/polymath1/index.php?title=Asymptotics_of_H_t")[#text("http://michaelnielsen.org/polymath1/index.php?title=Asymptotics_of_H_t")]#text(" which came from working out the Stirling approximation.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6803f451a822a44c3357dffe0946273ac8b678c1381d8f6f15471f78bf5064e-c0cdd6fbf9fa11cb38f669d32e0c33214ced4ab5f9e837265aa2a25f482e13f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492874")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2018")])]

#text("Do we know how much spare room there is in getting good bounds for ")#tao-math("\\left|H_t - \\tilde{A} - \\tilde{B}\\right|/\\left|\\tilde{B}_0\\right|", block: false)#text("? There are lots of ways to break up for instance the integral of ")#mi("\\nu w f")#text(", some of them lose quite a bit though. Numerically does this quantity seem to be close to .4 for ")#mi("x")#text(" around 10^4, or is it in reality much smaller?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492882")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2018")])]

#text("Asymptotically this error should be something like ")#mi("O( x^{-\\frac{1+y}{2}} )")#text(" I think; numerically I don’t think we have actual data yet, but I am hoping that it is not much larger than ")#tao-math("\\left|C\\right|/\\left|B_0\\right|", block: false)#text(" which was pretty small in practice (ranging between 0.01 and 0.05 in ")#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492445")[#text("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492445")]#text(" ). So we may have about an order of magnitude of spare room.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492893")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2018")])]

#text("I was facing some problems integrating vwf directly using the inbuilt procedures, so decided to use the Euler Maclaurin approach without derivatives, limits -10 to 10 and h=0.01 (although a smaller limit and larger h also seem to be fine). Since f in vwf rapidly decays on either like a steep bell curve, a low lower and upper limit doesn’t seem to hurt.")

#text("Evaluating (|Heff-A’-B’| + |Heff_error|)/|B’0| as a conservative proxy for |H_t – A’ – B’|/|B’0| on some sample values we observe it to be much lower than 0.4 (last column)")#linebreak()#text(" (Heff is taken as the sum of the first two terms in the effective approximation, and Heff error as |err1|+|err2|+|err3| of the three error terms)")

#text("val1 = |Heff|/|B’0|")#linebreak()#text(" val2 = |A’+B’|/|B’0|")#linebreak()#text(" val3 = |Heff-A’-B’|/|B’0|")#linebreak()#text(" val4 = (|Heff-A’-B’| + |Heff_error|)/|B’0|")

#text("t——x——–y——val1–val2–val3——val4")#linebreak()#text(" 0.4–10000–0.4—0.52–0.52–0.0006–0.039")#linebreak()#text(" 0.4–12131–0.4—1.28–1.28–0.0004–0.033")#linebreak()#text(" 0.4–15256–0.4—0.97–0.97–0.0003–0.027")#linebreak()#text(" 0.4–18432–0.4—0.68–0.68–0.0003–0.023")#linebreak()#text(" 0.4–20567–0.4—0.98–0.98–0.0004–0.022")#linebreak()#text(" 0.4–30654–0.4—1.93–1.93–0.0004–0.016")

#text("I am now planning to run this with x mesh size of 0.1 for x beyond 10k, and calculate the upper bound d/dx |B’/B’0| at each point as well.")

#text("Also, Heff, A’+B’ and A+B-C more or less match even at smallish values of x, but the error estimate in Ht_effective is conservative and increases a lot with decreasing x (last column)")

#text("(estimates shown without main exponent term)")

#text("t—-x—–y—-ABC—————-A’+B’—————H_eff————%Hf_err")#linebreak()#text(" 0.4–1k–0.4–(-0.479+3.127i)—(-0.516+3.135i)–(-0.474+3.125i)–27.4%")#linebreak()#text(" 0.4–5k–0.4–(-1.102+0.141i)—(-1.102+0.140i)–(-1.102+0.141i)—9.5%")#linebreak()#text(" 0.4–10k—0.4–(-0.692-4.067i)—(-0.687-4.067i)–(-0.692-4.066i)—7.3%")#linebreak()#text(" 0.4–50k—0.4–(5.443-2.695i)—-(5.443-2.694i)—(5.442-2.695i)—-0.6%")#linebreak()#text(" 0.4–100k–0.4–(-9.327+4.380i)—(-9.327+4.380i)–(-9.327+4.380i)—0.5%")#linebreak()#text(" 0.4–150k–0.4–(1.124-0.354i)—-(1.124-0.354i)—(1.124-0.354i)—-0.3%")#linebreak()#text(" 0.4–200k–0.4–(-1.342-0.098i)—(-1.342-0.098i)–(-1.342-0.098i)—0.2%")

#text("Given the three estimates are close to each other, one can be quite confident the repo scripts are correct for Ht_Effective, but having no independent benchmark for the error estimate and the error formulas being complicated, it would be good if others can verify the scripts are computing those correctly (mputility.py in the adjusted_AB_estimates branch).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492896")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2018")])]

#text("This is very promising! It seems to indicate that there is indeed a fair amount of room in the error estimates, to the point where we can afford to lose up to an order of magnitude in them and still have a chance of closing the argument (at ")#mi("t = y = 0.4")#text(" at least – presumably if we push lower then there will be less room to spare). Do you have a sense of the relative size of the three components of the error? I think err3 should be the largest (and it should be broadly comparable to |C|/|B_0| in magnitude).")

#text("For err1 and err2 there is a cruder but simpler bound available (for x large enough) in equation (3.8) of the wiki, it may be that it will suffice for our purposes. As pointed out in a different comment, it would be good to have a cleaner bound for err3; now that I know that we have some room to lose something here it should be possible to do something.")

#text("Looking at what we have, it seems the main place where we are still missing something is in Step 3 of the blog post, that is to say bounding ")#tao-math("\\left|A^{\\prime}+B^{\\prime}\\right|/\\left|B^{\\prime}_0\\right|", block: false)#text(" (or something analogous like ")#tao-math("\\left|H_{eff}\\right|/\\left|B^{\\prime}_0\\right|", block: false)#text(") for large ")#mi("x")#text(", say ")#mi("x \\geq 10^6")#text(". Numerically we have that this expression seems to be staying away from 0, but this could be due to cancellation in the sum. There is a worst-case bound of ")#tao-math("\\left|A^{\\prime}+B^{\\prime} - B^{\\prime}_0\\right|/\\left|B^{\\prime}_0\\right|", block: false)#text(" coming from the triangle inequality, which is (if I have computed it correctly)")

#mi("\\displaystyle \\sum_{m=2}^M \\frac{\\exp( \\mathrm{Re} \\frac{t}{16} \\log^2 \\frac{5-s}{2\\pi m^2} - \\frac{t}{16} \\log^2 \\frac{5-s}{2\\pi} )}{n^{(1+y)/2}}")#linebreak()#text(" ")#mi("\\displaystyle + \\pi^{y/2} \\exp( \\mathrm{Re} (\\frac{s+4}{2} - \\frac{1}{2}) \\log \\frac{s+4}{2} - \\frac{s+4}{2} - ((\\frac{5-s}{2} - \\frac{1}{2}) \\log \\frac{5-s}{2} - \\frac{5-s}{2}) ) \\times")#linebreak()#text(" ")#mi("\\displaystyle \\sum_{n=1}^N \\frac{\\exp( \\mathrm{Re} \\frac{t}{16} \\log^2 \\frac{s+4}{2\\pi n^2} - \\frac{t}{16} \\log^2 \\frac{5-s}{2\\pi} )}{n^{(1-y)/2}}")

#text("and if we can get this expression below say 0.9 for say ")#mi("x \\geq 10^6")#text(" then this may be enough to analytically guarantee no zeroes for ")#mi("x+iy")#text(" in this range.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492922")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2018")])]

#text("|err3| is approx an order of magnitude higher than the other two errors in H_t effective, and the ratio keeps increasing as expected.")

#text("t=0.4,y=0.4")#linebreak()#text(" x———-|err3|/(|err1|+|err2|)")#linebreak()#text(" 10000—9.11")#linebreak()#text(" 15000—14.97")#linebreak()#text(" 20000—19.26")#linebreak()#text(" 50000—32.39")#linebreak()#text(" 100000–42.99")#linebreak()#text(" 10mil—–87.23")

#text("The zeta approximation for epsilon errors becomes effective only at larger heights")

#text("val = sigma + (t/2)*Re(alpha1(s)) – (t/4)*log(N)")#linebreak()#text(" t=0.4")#linebreak()#text(" z————val")#linebreak()#text(" (10^5+0.4j)–0.7493")#linebreak()#text(" (10^6+0.4j)–0.8643")#linebreak()#text(" (10^7+0.4j)–0.9794")#linebreak()#text(" (10^8+0.4j)–1.0945")

#text("The upper bound for |A’+B’-B’0|/|B’0| goes below 0.9 only near x=4*10^7")

#text("t=0.4")#linebreak()#text(" z—————upper bound |A’+B’-B’0|/|B’0|")#linebreak()#text(" (10^6+0.4j)——-2.0498")#linebreak()#text(" (10^6+5k+0.4j)—2.0465")#linebreak()#text(" (10^6+10k+0.4j)–2.0449")#linebreak()#text(" (10^7+0.4j)——–1.2250")#linebreak()#text(" (4*10^7+0.4j)——0.8947")#linebreak()#text(" (5*10^7+0.4j)——0.8519")#linebreak()#text(" (10*10^7+0.4j)—–0.7348")

#text("Also, if we check actual values of |A’+B’-B’0|/|B’0| near 10^6 we see it is below 0.9 most of the time, but keeps going over it now and then.")

#text("t=0.4")

#text("z—————|A’+B’-B’0|/|B’0|")#linebreak()#text(" (1026000+0.4j)–1.110910")#linebreak()#text(" (1038000+0.4j)–0.948970")#linebreak()#text(" (1057000+0.4j)–0.900985")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492934")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2018")])]

#text("Thanks for this! Hmm, the fact that we only get good analytic bounds beyond ")#mi("x = 4 \\times 10^7")#text(" is slightly worrying – combined with a mesh size of 0.1 this would mean a fairly intensive numerical computation to control ")#tao-math("\\left|A+B\\right|/\\left|B_0\\right|", block: false)#text(" up to this scale, unless some speedups are found. (There is an alternative route though, as mentioned in some previous posts, in which we only exclude zeroes ")#mi("H_t(x+iy)")#text(" in a narrow range of ")#mi("x")#text(", e.g. ")#mi("4 \\times 10^7 \\leq x \\leq 4 \\times 10^7+1")#text(", but the price one pays for this is that we need to check all values of ")#mi("t")#text(" between ")#mi("0")#text(" and ")#mi("0.4")#text(", not just ")#mi("t = 0.4")#text(". But perhaps the effective approximations we have now are usable in these ranges also…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492949")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2018")])]

#text("When ")#mi("s=y=0.4")#text(", one can use approximations such as Stirling’s approximation to find that the expression ")#mi("(A+B)/B_0")#text(" is roughly of the form")

#mi("\\displaystyle \\sum_{n=1}^N \\frac{1}{n^{0.7 - \\frac{ix}{2} + 0.1 \\log \\frac{N^2}{n}}} + \\frac{e^{i (\\frac{x}{2} \\log \\frac{x}{4\\pi} - \\frac{x}{2} + \\frac{\\pi}{4})}}{N^{0.4}} \\sum_{n=1}^N \\frac{1}{n^{0.3 + \\frac{ix}{2} + 0.1 \\log \\frac{N^2}{n}}} \\quad (1)")

#text("where ")#mi("N := \\sqrt{x/4\\pi}")#text(" (note: the phase ")#mi("\\frac{x}{2} \\log \\frac{x}{4\\pi} - \\frac{x}{2} + \\frac{\\pi}{4}")#text(" has now been corrected)). A model problem is then to find a threshold ")#mi("x_0")#text(" such that one can analytically guarantee the non-vanishing of the above expression (1) for ")#mi("x \\geq x_0")#text(" (or equivalently ")#mi("N \\geq N_0")#text(", where ")#mi("N_0 := \\sqrt{x_0/4\\pi}")#text("). The triangle inequality bound shows that this occurs as soon as")

#mi("\\displaystyle \\sum_{n=2}^N \\frac{1}{n^{0.7 + 0.1 \\log \\frac{N^2}{n}}} + \\frac{1}{N^{0.4}} \\sum_{n=1}^N \\frac{1}{n^{0.3 + 0.1 \\log \\frac{N^2}{n}}} < 1\\quad (2)")

#text("and this can be verified to be true for ")#mi("x")#text(" larger than ")#mi("4 \\times 10^7")#text(" (with a little bit of room to spare) as in KM's calculations. The question is whether one can do better than this by somehow exploiting cancellation in the phases. It seems that the bulk of the LHS in (1) is dominated by the first few terms of the first sum, which suggests a couple of potential strategies:")

#text("1. Numerically compute just the first few terms of (1) (which should be a lot faster than computing the whole thing) and use the triangle inequality for the rest.")#linebreak()#text(" 2. Try to use trig identities such as ")#mi("3 + 4 \\cos \\theta + \\cos 2\\theta \\geq 0")#text(" to get some lower bounds on the real part of (1) that improve upon the triangle inequality, for instance by lower bounding the net contribution of the n=1, n=2, and n=4 terms in the first sum of (1).")#linebreak()#text(" 3. Multiply the LHS of (1) by some factor such as ")#mi("1 - \\frac{1}{2^{0.7 - \\frac{ix}{2} + 0.1 \\log N^2}}")#text(" to try to partially cancel off some terms.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492959")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2018")])]

#text("Looks like strategy 3 can cut down the threshold for x by about an order of magnitude (i.e. it can handle ")#mi("x \\geq 4 \\times 10^6")#text("). To make (1) non-zero it suffices to show that")

#tao-math("\\displaystyle \\left|\\sum_{n=1}^N \\frac{1}{n^{0.7 + ix + 0.1 \\log \\frac{N^2}{n}}}\\right| > N^{-0.4} |\\sum_{n=1}^N \\frac{1}{n^{0.3 + ix + 0.1 \\log \\frac{N^2}{n}}}|.", block: false)

#text("Multiply both sums by ")#mi("1 - \\frac{1}{2^{0.7 + ix + 0.1 \\log \\frac{N^2}{2}}}")#text(" (the point being that this cancels off a large portion of the contribution of the even ")#mi("n")#text(" to the sum). The sum in the LHS becomes")

#mi("\\displaystyle \\sum_{n=1}^{2N} \\frac{1}{n^{0.7 + ix + 0.1 \\log \\frac{N^2}{n}}} (1_{n \\leq N} - \\frac{1_{2|n}}{(n/2)^{0.2 \\log 2}})")

#text("and the sum in the RHS similarly becomes")

#mi("\\displaystyle \\sum_{n=1}^{2N} \\frac{1}{n^{0.3 + ix + 0.1 \\log \\frac{N^2}{n}}} (1_{n \\leq N} - \\frac{1_{2|n}}{2^{0.4} (n/2)^{0.2 \\log 2}}).")

#text("So by the triangle inequality we now win if")

#tao-math("\\displaystyle \\sum_{n=2}^{2N} \\frac{1}{n^{0.7 + 0.1 \\log \\frac{N^2}{n}}} \\left|1_{n \\leq N} - \\frac{1_{2|n}}{(n/2)^{0.2 \\log 2}}\\right|", block: false)#linebreak()#text(" ")#tao-math("\\displaystyle + \\sum_{n=1}^{2N} \\frac{1}{n^{0.3 + 0.1 \\log \\frac{N^2}{n}}} \\left|1_{n \\leq N} - \\frac{1_{2|n}}{2^{0.4} (n/2)^{0.2 \\log 2}}\\right| < 1.", block: false)

#text("Numerically this seems to occur for ")#mi("N")#text(" close to 500 (so ")#mi("x")#text(" close to ")#mi("\\pi \\times 10^6")#text("). I would expect similar results for other versions of the ")#mi("(A+B)/B_0")#text(" expression that we have discussed previously.")

#text("In principle one could obtain a further improvement by also multiplying through by ")#mi("1 - \\frac{1}{3^{0.7 + ix + 0.1 \\log \\frac{N^2}{2}}}")#text(", but the calculations get messy and I doubt one would have as dramatic a gain in ")#mi("x")#text(" as a consequence. It does show though that the ")#mi("H_t")#text(" do retain some partial vestige of an Euler product, which I did not expect.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492984")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2018")])]

#text("4*10^6 is much more manageable numerically than 4*10^7 :)")

#text("At x=pi*10^6, the triangle inequality bound is 0.976, while at 3.5*10^6, it goes below 0.95. Stopping numerically here would cut down the computation time further by about 10-20%")

#text("I also checked for z=4*10^7+0.4j, the t value till which H_t effective is useful. The error at t=10^-8 is around 19%, below which the error term increases quickly.")

#text("t———-%error in H_t_eff")#linebreak()#text(" 10^-9—60.9%")#linebreak()#text(" 10^-8—19.3%")#linebreak()#text(" 10^-7—-6.1%")#linebreak()#text(" 0.01——0.2%")#linebreak()#text(" 0.1——–0.09%")#linebreak()#text(" 0.4——–0.0016%")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-493022")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2018")])]

#text("Not completely sure about the derivation below, but if we follow the template and multiply the 1-1/3^() factor, we get triangle inequality eqns like below")

#tao-math("L = \\sum_{n=2}^{6N} \\frac{1}{n^{0.7 + 0.1 \\log \\frac{N^2}{n}}} \\left|1_{n \\leq N} - \\frac{1_{2|n,n \\leq 2N}}{(n/2)^{0.2 \\log 2}} - \\frac{1_{3|n,n \\leq 3N}}{(n/3)^{0.2 \\log 3}} + \\frac{1_{6|n}}{(n/6)^{0.2 \\log 6} exp(0.2\\log 2\\log 3)}\\right|", block: false)

#tao-math("R = N^{-0.4} \\sum_{n=1}^{6N} \\frac{1}{n^{0.3 + 0.1 \\log \\frac{N^2}{n}}} \\left|1_{n \\leq N} - \\frac{1_{2|n,n \\leq 2N}}{2^{0.4} (n/2)^{0.2 \\log 2}} - \\frac{1_{3|n,n \\leq 3N}}{3^{0.4} (n/3)^{0.2 \\log 3}} + \\frac{1_{6|n}}{6^{0.4} (n/6)^{0.2 \\log 6} exp(0.2\\log 2\\log 3)}\\right|", block: false)

#text("where we then have to find the threshold for L + R < 1")

#text("Similarly, if we multiply 1-1/5^(), we get 8 conditional factors in both L and R, with the final one in R being")

#mi("\\frac{1_{30|n}}{30^{0.4} (n/30)^{0.2 \\log 30} exp(0.2(\\log 2\\log 3+\\log 2\\log 5+\\log 3\\log 5))}")

#text("Using this, the eqn with 3 multiplication factors just goes below 1 at x=1 mil.")

#text("Also, I noticed that while calculating the inequality, we did not divide back by a factor like ")#mi("1 - \\frac{1}{2^{0.7 + 0.1 \\log \\frac{N^2}{2}}}")#linebreak()#text(" which would again increase the LHS. If we divide back by the factors used, we get these results. The eqn with 3 multiplication factors is around 0.965 for x=5.5 mil.")

#text("x———orig—fac2–fac2,3–fac2,3,5")#linebreak()#text(" [2.5mil, 1.68, 1.44, 1.33, 1.29]")#linebreak()#text(" [3.0mil, 1.61, 1.36, 1.25, 1.21]")#linebreak()#text(" [3.5mil, 1.56, 1.30, 1.19, 1.14]")#linebreak()#text(" [4.0mil, 1.51, 1.25, 1.13, 1.09]")#linebreak()#text(" [5.0mil, 1.44, 1.17, 1.05, 1.00]")#linebreak()#text(" [5.5mil, 1.41, 1.14, 1.01, 0.96]")#linebreak()#text(" [6.0mil, 1.38, 1.11, 0.98, 0.93]")#linebreak()#text(" [6.5mil, 1.35, 1.08, 0.95, 0.91]")#linebreak()#text(" [10 mil, 1.23, 0.95, 0.82, 0.77]")#linebreak()#text(" [40 mil, 0.89, 0.62, 0.49, 0.45]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-493050")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2018")])]

#text("Thanks for this! I think we don’t need to pay factors like ")#mi("1 - 1/2^{0.7 + 0.1 \\log N^2/2}")#text(" because they appear on both sides of the inequality. So the gain may be slightly more than indicated. Still it seems from your preliminary analysis that the additional savings from adding in the 3 and 5 primes are perhaps worth the increased complexity.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64cdcf6c5ad2c4a5b929477f6c6f6bc307654f648757e49291f4a15228879b96-65ec6802d77367cb10a2bfcf950b269cfbdf743be840fe341c5f6b3d13792b27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vassilis Papanicolaou")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492609")[#strong[#text("Vassilis Papanicolaou")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2018")])]

#text("(I’ve just posted this comment at Thread 1. I am reposting it here, since it seems that the attention has shifted to Thread 3).")

#text("I would like to share few rough ideas regarding the dynamics of the zeros z_j(t) of H_t(z):")

#text("It seems clear that H_t(z) is entire in both z and t. Hence the zeros z_j(t) are the branches of a global analytic function, say Z(t), defined on an infinite-sheeted Riemann surface S. The projections of the branch points of S on the complex plane are the values of t for which we will have multiple zeros of H_t(z), and these are countably many points, say t_k, k = 1, 2, … (possibly without accumulation points in the complex plane). Then, by analytic continuation one expects that the equations giving the dynamics of the zeros will continue to hold (in some sense?) for any complex t, except at t = t_k.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492615")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2018")])]

#text("Any simple zero ")#mi("z_j(t)")#text(" has a local representation by its (locally convergent) Taylor series, while multiple zeros are locally represented by the locally convergent branches (around each branch point ")#mi("t_k")#text(") of their Puiseux series, see")

#link("https://en.wikipedia.org/wiki/Puiseux_series")[#text("https://en.wikipedia.org/wiki/Puiseux_series")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492618")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2018")])]

#text("The current proof of the ODE Dynamics of ")#mi("H_t")#text(" zeros depends on the fact that H_t is an even entire function of order less than ")#mi("2")#text(" (needed for its simple form of Hadamard factorization) for any real ")#mi("t")#text(". It is not clear if ")#mi("H_t")#text(" has all these properties for some non-real ")#mi("t")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64cdcf6c5ad2c4a5b929477f6c6f6bc307654f648757e49291f4a15228879b96-65ec6802d77367cb10a2bfcf950b269cfbdf743be840fe341c5f6b3d13792b27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vassilis Papanicolaou")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492634")[#strong[#text("Vassilis Papanicolaou")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2018")])]

#text("Thanks for the comments. I will try to check the order and the evenness of ")#mi("H_t(z)")#text(" for non-real ")#mi("t")#text(". I suspect that the order is not affected by the imaginary part of ")#mi("t")#text(".")#linebreak()#text(" If I may ask, is the exact ")#mi("z")#text("-order (and type) of ")#mi("H_t(z)")#text(" known for any real ")#mi("t")#text("?")#linebreak()#text(" Also, it should not be hard to estimate the ")#mi("t")#text("-order of ")#mi("H_t(z)")#text(" (possibly 1 of infinite type?). Then, it may be helpful to look at the zeros ")#mi("t_j(z)")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492650")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2018")])]

#text("On page 2 of the ")#link("http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.164.5595&rep=rep1&type=pdf")[#text("Ki-Kim-Lee paper")]#text(" it is noted that ")#mi("\\Xi_t")#text(" (which is related to ")#mi("H_t")#text(" by the simple transformation ")#mi("H_t(z) = \\frac{1}{8} \\Xi_t(\\frac{1+iz}{2})")#text(" is of order 1 and maximal type because it is the Fourier transform of an extremely rapidly decaying function (this is an application of the Paley-Wiener theorem). It looks to me like this argument would also apply for complex values of ")#mi("t")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64cdcf6c5ad2c4a5b929477f6c6f6bc307654f648757e49291f4a15228879b96-65ec6802d77367cb10a2bfcf950b269cfbdf743be840fe341c5f6b3d13792b27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vassilis Papanicolaou")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492676")[#strong[#text("Vassilis Papanicolaou")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2018")])]

#text("Thanks for the reply!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492612")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2018")])]

#text("It seems as though there may already be a Python procedure that can do Gauss-Legendre quadrature, which is the method I use to evaluate ")#mi("H_{t}")#text(" by integration.")

#text("Reference and link:")

#link("https://en.wikipedia.org/wiki/Gaussian_quadrature")[#text("https://en.wikipedia.org/wiki/Gaussian_quadrature")]

#text("and")

#link("https://docs.scipy.org/doc/scipy-0.14.0/reference/generated/scipy.integrate.quadrature.html")[#text("https://docs.scipy.org/doc/scipy-0.14.0/reference/generated/scipy.integrate.quadrature.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492622")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2018")])]

#text("I have played quite a bit with the ABC-approximation formula for ")#mi("\\big{\\left(H_t(2(x+yi))\\right)}")#text(" and managed to produce some ‘x-ray’-plots (also called ‘implicit plots’) that show all points on an x,y-plane where ")#mi("\\Re\\big{\\left(H_t(2(x+yi))\\right)}=0")#text(" and ")#mi("\\Im\\big{\\left(H_t(2(x+yi))\\right)}=0")#text(". The first plot just illustrates how well the approximation formula works for ")#mi("t=0")#text(" around the first Lehmer pair (zeros reside at those points where the red and green lines cross):")

#link("https://ibb.co/fe9AGS")[#text("https://ibb.co/fe9AGS")]

#text("The second plot shows the evolution of this Lehmer pair when ")#mi("t")#text(" varies. Note that the Lehmer-phenomenom becomes more or less invisible when ")#mi("t > 0.4")#text(". I fully realise the focus is on the positive domain ")#mi("0 \\le t < \\frac12")#text(", however the approximation formula appears to continue to work pretty well for negative t.")

#text("The bottom row of the plot shows the 'birth' of a pair of zeros off the critical line (and it happens indeed 'barely' below ")#mi("t=0")#text(").")

#link("https://ibb.co/eNQT37")[#text("https://ibb.co/eNQT37")]

#text("Note that the imaginary lines (red) are much better behaved (and spaced) than the real ones (green). Two subsequent red lines seem to constrain the 'wiggle room' for the green lines to stay on the critical line. Based on this observation, I wrote a root finding program that first establishes two subsequent red points on a line just above the x-axis at ")#mi("x+0.1i")#text(" and then uses these as the precise interval for the pari/gp solver to establish where a real (green) line crosses the x-axis at ")#mi("x+0i")#text(". This method automatically revealed the zero pair: 2*5229.198 and 2*5229.242 (also found by David and KM) that lies just above the x-axis (note this is clearly an approximation error, not a zero lying off the line :-) ). In these cases, the algorithm just spots two subsequent empty 'bins', so there is no need to check back against the known non-trivial Riemann zeros to spot a missing pair (which can't be done for t larger than 0 anyway). This method is of course slower (since it requires two solving steps) than the root finders proposed earlier, however it is less sensitive for accidentally \"jumping over\" e.g. a Lehmer pair when the step size for finding the next sign change is set too large.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5869d8b1448ca10fca0bd94d7cbc089633423849ab93255b0123f887992ce41a-6ba6395656430792a6ea6ae7d9ac3e6b5677fa135c4d519e4810981160304521.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492628")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2018")])]

#text("Very interesting graphs. I remember Csordas et al. used an extreme Lehmer pair near Im z=388858886.00228512… and Im z=388858886.00239368… to produce a lower bound of de Bruijn-Newman constant. Is it possible to produce similar “X-ray” graphs near these two zeros?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492649")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2018")])]

#text("Sure, will try to run the plots (note that at these heights of x the processing is time required is considerable, I expect to have to scale down the plotting resolution a bit).")

#text("Thanks for this extreme Lehmer pair, since it provides a great opportunity to test my root finding algorithm. Searching for zeros from 388858885 to 388858887, using a step size of 0.1 and the line 2*(x+0.01y) to establish the search intervals, I found for t=0 and the full ABC-approximation (numbers truncated at 6 decimals):")

#text("388858885.231056")#linebreak()#text(" 388858885.384337")#linebreak()#text(" 388858886.002152")#linebreak()#text(" 388858886.002526")#linebreak()#text(" 388858886.690744")#linebreak()#text(" 388858886.891322")#linebreak()#text(" 388858887.016571")

#text("However, without the C-factor, this Lehmer pair lies just above the x-axis, but its absence is automatically spotted:")

#text("388858885.232052")#linebreak()#text(" 388858885.383403")#linebreak()#text(" no zero between: 388858885.648782 388858886.002360")#linebreak()#text(" no zero between: 388858886.002360 388858886.346191")#linebreak()#text(" 388858886.691773")#linebreak()#text(" 388858886.888967")#linebreak()#text(" 388858887.018302")

#text("It seems that for root finding purposes the C-factor remains important even at higher values of x.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492655")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2018")])]

#text("I think at large heights, the C factor would be important for t=0 where Lehmer pairs exist, but would probably not be critical away from t=0 where the gaps get more regular. Corresponding zeroes for this zero pair may be worth checking for t small, say 0.05 or 0.1 and t large, closer to 0.5, with and without using C.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492686")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2018")])]

#text("Here are the ‘x-ray’ plots that show the evolution of the Lehmer pair 388858886.00228512, 388858886.00239368. For the graphs I have used the Sagemath (implicit) plotting capability and for the computations Pari/GP. Each graph took roughly 6 hours to complete on my 2013 iMac (i5 CPU). No doubt this can be sped up with better hardware. The last three plots have been processed in parallel in the Cocalc cloud (they have a slightly different color), however they still took about the same time to generate. Compared to the previous plot, I reduced the plot-point density from 150 to 60 to keep computing time in a ‘decent’ range.")

#link("https://ibb.co/doqBAn")[#text("https://ibb.co/doqBAn")]

#text("Few observations:")#linebreak()#text(" 1) For negative t, I assumed the ")#mi("H_t(s)")#text(" approximation formula remains valid, however this needs to be confirmed.")#linebreak()#text(" 2) Assuming 1), the collision of the Lehmer pair occurs somewhere between t=-0.0000000688 and t=-0.0000000689 (I used the root finder to establish the ")#mi("t")#text("-threshold after which the Lehmer pair is no longer found). This is already significantly lower than t=-0.000825 where about the first Lehmer pair collision occurs (see these graphs for a zoomed-in view of that actual collision: ")#link("https://ibb.co/g9OxgS")[#text("https://ibb.co/g9OxgS")]#text(" ).")#linebreak()#text(" 3) The ")#mi("H_0(s)")#text(" graph now also shows that the imaginary (red) lines could bend ‘to the left’ (like the real lines already did for the upper member of a Lehmer pair).")#linebreak()#text(" 4) Apparently for increasing heights of ")#mi("x")#text(", the ‘wrinkles’ in the lines induced by a Lehmer pair, seem to get ‘ironed out’ much faster when ")#mi("t")#text(" moves up from ")#mi("0")#text(", compared to Lehmer pairs at lower heights of ")#mi("x")#text(". If this is true, then this indeed could be another indication that a mix of computation up to a certain height and an analytical solution above that, is a promising approach to reduce the upper bound of ")#mi("\\Lambda")#text(". I’ll try to produce a (low resolution) plot for a Lehmer pair in the ")#mi("10^12")#text(" domain to see if this effect remains.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492677")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2018")])]

#text("In the wiki page “effective bounds on ")#mi("H_t")#text("“, what is the precise meaning of ")#mi("O_{\\leq}")#text(" ?")

#emph[#text("[This is now explained in a rewritten version of the page – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492695")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2018")])]

#text("I did some computations of ")#mi("(H_{0.4} - (A+B-C))/B_{0}")#text(" for ")#mi("z")#text(" from 160 to 3200, by increments of 160. This took 4 hours for 20 points.")#linebreak()#text(" The command to PARI/gp was:")#linebreak()#text(" for(K=1, 20, x50= K*160 ;")#linebreak()#text(" s=0.0;")#linebreak()#text(" for(J=0,30,")#linebreak()#text(" s=s+intnumgauss(X=J/13,(J+1)/13, exp(t*X*X)*Phi(X)*cos((x50)*X),));")#linebreak()#text(" s2=H(x50);")#linebreak()#text(" b0=HM(x50);")#linebreak()#text(" s4 = abs((s2-s)/b0);")#linebreak()#text(" w20[K] = s4;)")

#text("Thus, for each point ")#mi("z")#text(", I did 31 Gauss-Legendre quadratures, each over an interval of length 1/13, and summed the 31 values.")#linebreak()#text(" Also, for ")#mi("z")#text(" real with z>100, the time to compute ")#mi("H_{t}(z)")#text(" by the integral method increases roughly like ")#mi("z^{2}")#text(" .")

#text("The output is copied below:")

#text("? for(K=1,20, print(K*160,” “, w20[K]))")#linebreak()#text(" 160 0.06993270565802375041")#linebreak()#text(" 320 0.006716674125965016299")#linebreak()#text(" 480 0.005332893070605698501")#linebreak()#text(" 640 0.003363431256036816251")#linebreak()#text(" 800 0.1548144749150572349")#linebreak()#text(" 960 0.03009229958121352990")#linebreak()#text(" 1120 0.004507664238680722472")#linebreak()#text(" 1280 0.002283591962997851167")#linebreak()#text(" 1440 0.01553727684468691873")#linebreak()#text(" 1600 0.001778051951547709718")#linebreak()#text(" 1760 0.02763769444052338578")#linebreak()#text(" 1920 0.002108779890256530964")#linebreak()#text(" 2080 0.02746770886040058927")#linebreak()#text(" 2240 0.001567020041379128455")#linebreak()#text(" 2400 0.01801417530687959747")#linebreak()#text(" 2560 0.001359561117436848149")#linebreak()#text(" 2720 0.008503327577240081269")#linebreak()#text(" 2880 0.001089253262122934826")#linebreak()#text(" 3040 0.003004181560093288747")#linebreak()#text(" 3200 0.02931455383125538672")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492707")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2018")])]

#text("I see that in mpmath, there is a way to divide up the interval of integration into sub-intervals;")#linebreak()#text(" copied from:")#linebreak()#text(" ")#link("http://mpmath.org/doc/current/calculus/integration.html")[#text("http://mpmath.org/doc/current/calculus/integration.html")]#text(" :")#linebreak()#text(" “One solution is to break the integration into 10 intervals of length 100:")#linebreak()#text(" >>> quad(sin, linspace(0, 1000, 10)) # Good")#linebreak()#text(" 0.437620923709297 ”")

#text("The answer is 1-cos(1000) ~= 0.437620923709297.")#linebreak()#text(" I might try in Python interactively.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492789")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2018")])]

#text("Looks reassuringly small, though the spike at x=800 is weird and I don’t have any plausible explanation for it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492811")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2018")])]

#text("My preliminary analysis is that the quotient has jump discontinuities for values of ")#mi("x")#text(" of the form ")#mi("x = 4\\pi n^{2}")#text(" for positive integers n, including at ")#mi("x= 196\\pi")#text(" and ")#mi("256 \\pi")#text(", which is about 804.247. The error goes from moderate to small across the discontinuity:")#linebreak()#text(" x50=256*Pi-0.0001;")#linebreak()#text(" s=0.0;for(J=0, 50, s=s+intnumgauss(X=J/15, (J+1)/15, exp(t*X*X)*Phi(X)*cos((x50)*X),));s2=H(x50); b0=HM(x50); s4 = abs((s2-s)/b0);s4")#linebreak()#text(" = 0.17313")#linebreak()#text(" and:")#linebreak()#text(" x50=256*Pi+0.0001;")#linebreak()#text(" s=0.0;for(J=0, 50, s=s+intnumgauss(X=J/15, (J+1)/15, exp(t*X*X)*Phi(X)*cos((x50)*X),));s2=H(x50); b0=HM(x50); s4 = abs((s2-s)/b0);s4")#linebreak()#text(" = 0.00305 .")#linebreak()#text(" For the choices I make in the Riemann-Siegel formula, both M and N have discontinuous jumps for ")#mi("x = 256\\pi")#text(" .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492822")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2018")])]

#text("It might be worth studying numerically the size of the discontinuities in ")#mi("A + B - C")#text(" , where ")#mi("M, N")#text(" have jumps. I find semi-empirically that the Riemann-Siegel approximation to ")#mi("H_{t} (z)")#text(" has discontinuities for ")#mi("z = 4 \\pi n^2")#text(". The reason to look at the size of discontinuous jumps in ")#mi("A + B - C")#text(" is that Terry’s Riemann-Siegel formula is much faster to compute than the integral that defines ")#mi("H_{t} (z)")#text(" . The idea being that hopefully the discontinuities could be useful proxies for the error in the ")#mi("A + B - C")#text(" formula with respect to the integral defining ")#mi("H_{t}")#text(" .")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492823")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2018")])]

#text("If the sizes of the discontinuities can’t be explained by the (effective) upper bound on the remainder term, this would indicate that there is an error in the formula.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492825")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2018")])]

#text("Here is what I got for the absolute values of the discontinuous jumps in ")#mi("A + B - C")#text(" , relative to the continuous ")#mi("B_{0}")#text(":")

#text("for(JJ=3, 8,K=2^JJ;")#linebreak()#text(" x50= 4*Pi*(K^2) ;")#linebreak()#text(" s2=H(x50-epsilon);")#linebreak()#text(" s3= H(x50+epsilon);")#linebreak()#text(" b0=HM(x50);")#linebreak()#text(" s4 = abs((s2-s3)/b0); // s4 is abs. rel. jump")#linebreak()#text(" print(x50,” “,s4))")

#text("x50: s4:")#linebreak()#text(" ———————-")#linebreak()#text(" 804.247 0.176")#linebreak()#text(" 3216.990 0.0375")#linebreak()#text(" 12867.963 0.00794")#linebreak()#text(" 51471.854 0.00159")#linebreak()#text(" 205887.416 0.000295")#linebreak()#text(" 823549.664 5.028 E-5")

#text("epsilon")#linebreak()#text(" 1.000 E-20")

#text("Note: No use is made of the integral formula for ")#mi("H_{0.4} (z)")#text(" above.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492831")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2018")])]

#text("Interesting! The “C” term has the property that it also has discontinuities at these places, but the jumps in the “C” term are supposed to largely (but not completely) cancel the jumps in the “A” and “B” terms. So presumably things would be much worse near these discontinuities if we only had the A+B term. I do indeed agree that it is worth studying the numerical behavior of ")#mi("H_t, A, B, C")#text(" in the vicinity (and in particular on both sides) of say ")#mi("x = 256 \\pi")#text(", as this looks like it will give the worst-case behaviour with regards to accuracy of approximation. (Certainly this is where the ")#mi("C")#text(" term should be largest in magnitude; it should roughly be the size of the final summand in the A or B terms.)")

#text("EDIT: it seems from your more recent data that the size of the jump in A+B-C decays rather rapidly as x increases, so it seems the cancelling effect alluded to above is kicking in but only for largish x.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492839")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2018")])]

#text("Some more data of the form log( | jump/B_0 |)/log(x), for x from ")#mi("256 \\pi = 4^{4} \\pi")#text(" to ")#mi("4194304 \\pi = 4^{11} \\pi")#text(" ; it shows a steady decrease from -0.259 to -0.836:")#linebreak()#text(" for(JJ=3, 10,K=2^JJ;")#linebreak()#text(" x50= 4*Pi*(K^2) ;")#linebreak()#text(" s2=H(x50-epsilon);")#linebreak()#text(" s3= H(x50+epsilon);")#linebreak()#text(" b0=HM(x50);")#linebreak()#text(" s4 = abs((s2-s3)/b0);")#linebreak()#text(" s5=log(s4)/log(x50);")#linebreak()#text(" print(x50,” “, s5))")

#text("x: s5:")#linebreak()#text(" 804.247 -0.259")#linebreak()#text(" 3216.990 -0.406")#linebreak()#text(" 12867.963 -0.511")#linebreak()#text(" 51471.854 -0.593")#linebreak()#text(" 205887.416 -0.664")#linebreak()#text(" 823549.664 -0.726")#linebreak()#text(" 3294198.658 -0.783")#linebreak()#text(" 13176794.633 -0.836")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492845")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2018")])]

#text("I did for ")#mi("t = 0")#text(" what I did previously for ")#mi("t = 0.4")#text(". What I find numerically is that the jump discontinuities in ")#mi("H_{t}")#text(" , relative to ")#mi("B_{0}")#text(" decay faster for ")#mi("t=0.4")#text(" than for ")#mi("t = 0.0")#text(" … This is for ")#mi("x = 4^{4} \\pi")#text(" to ")#mi("x = 4^{11} \\pi")

#text("t=0.0;")#linebreak()#text(" for(JJ=3, 10,K=2^JJ;")#linebreak()#text(" x50= 4*Pi*(K^2) ;")#linebreak()#text(" s2=H(x50-epsilon);")#linebreak()#text(" s3= H(x50+epsilon);")#linebreak()#text(" b0=HM(x50);")#linebreak()#text(" s4 = abs((s2-s3)/b0);")#linebreak()#text(" s5=log(s4)/log(x50);")#linebreak()#text(" print(x50,” “, s5))")

#text("x: s5:")#linebreak()#text(" 804.24 -0.194")#linebreak()#text(" 3216.99 -0.311")#linebreak()#text(" 12867.96 -0.384")#linebreak()#text(" 51471.85 -0.434")#linebreak()#text(" 205887.41 -0.471")#linebreak()#text(" 823549.66 -0.500")#linebreak()#text(" 3294198.65 -0.524")#linebreak()#text(" 13176794.63 -0.543")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492947")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2018")])]

#text("Here are some results for ")#mi("(H_{0.4} - (A+B-C))/B_{0}")#text(", in absolute value, for x ranging from ")#mi("198\\pi")#text(" to ")#mi("258\\pi")#text(", going by increments of ")#mi("3\\pi")#text(" in x; the largest of these is for ")#mi("255\\pi")#text(" in the next-to-last row:")

#text("622.035345 0.003667321")#linebreak()#text(" 631.460123 0.004268055")#linebreak()#text(" 640.884901 0.003284407")#linebreak()#text(" 650.309679 0.004453589")#linebreak()#text(" 659.734457 0.003872174")#linebreak()#text(" 669.159235 0.005048162")#linebreak()#text(" 678.584013 0.005009254")#linebreak()#text(" 688.008791 0.007418686")#linebreak()#text(" 697.433569 0.007464541")#linebreak()#text(" 706.858347 0.010692337")#linebreak()#text(" 716.283125 0.012938629")#linebreak()#text(" 725.707903 0.017830524")#linebreak()#text(" 735.132681 0.022428596")#linebreak()#text(" 744.557459 0.030907876")#linebreak()#text(" 753.982237 0.040060298")#linebreak()#text(" 763.407015 0.053652069")#linebreak()#text(" 772.831793 0.071092824")#linebreak()#text(" 782.256571 0.094081856")#linebreak()#text(" 791.681349 0.123108726")#linebreak()#text(" 801.106127 0.159299234")#linebreak()#text(" 810.530905 0.002870724")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64cdcf6c5ad2c4a5b929477f6c6f6bc307654f648757e49291f4a15228879b96-65ec6802d77367cb10a2bfcf950b269cfbdf743be840fe341c5f6b3d13792b27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vassilis Papanicolaou")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492696")[#strong[#text("Vassilis Papanicolaou")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2018")])]

#text("The de Bruijn function ")#mi("H_t(z)")#text(" is entire in ")#mi("(z, t)")#text(" and it obviously satisfies ")#mi("H_t(-z) = H_t(z)")#text(", i.e. it is even in ")#mi("z")#text(".")

#text("Furthermore, as a function of ")#mi("z")#text(", ")#mi("H_t(z)")#text(" is of order ")#mi("1")#text(" (and of maximal type) for any complex ")#mi("t")#text(".")

#text("(It seems, too, that as a function of ")#mi("t")#text(", ")#mi("H_t(z)")#text(" is of order ")#mi("1")#text(" (and of maximal type) for any complex ")#mi("z")#text(").")

#text("The zeros ")#mi("z_k(t)")#text(" are analytic in ")#mi("t")#text(" except at certain (branch) points ")#mi("t = t_m")#text(", ")#mi("m = 1,2, ...")#text(", where two zeros cross.")

#text("In the G. Csordas, W. Smith, and R.S. Varga (1994) paper it has been shown that if ")#mi("t")#text(" is real and ")#mi("t > \\Lambda")#text(", then the zeros are (real and)")#linebreak()#text(" simple and satisfy the dynamics")

#mi("\\displaystyle z^{\\prime}_k(t) = 2 \\sum_{j \\ne k} \\frac{1}{z_k(t) - z_j(t)}.")

#text("Since ")#mi("H_t(z)")#text(", is even in ")#mi("z")#text(", we have that ")#mi("z_k(t)")#text(" is a zero of ")#mi("H_t(z)")#text(" if and only if ")#mi("-z_k(t)")#text(" is a zero (counting multiplicities, of course).")#linebreak()#text(" Hence, the above dynamics can be written as")

#mi("\\displaystyle z^{\\prime}_k(t) = \\sum_{j \\ne k} \\frac{1}{z_k(t) - z_j(t)} + \\sum_{j \\ne k} \\frac{1}{z_k(t) + z_j(t)} = 2z_k(t) \\sum_{j \\ne k} \\frac{1}{z_k(t)^2 - z_j(t)^2}")

#text("(we can also multiply by ")#mi("2z_k(t)")#text(" and get the dynamics of ")#mi("z_k^2")#text("). Since ")#mi("H_t(z)")#text(" is of order ")#mi("1")#text(", the last sum above converges absolutely. Therefore, by analytic continuation, the above dynamics should continue to hold for any complex ")#mi("t \\ne t_m")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6525d7cd9db10f0f8b9a18fa0e62f21ac78916ee3eed4debea5956daeaf030-72219f07d23f0f1bc893af77a76e1cfd99cff0d2c3626a52796f2e15ac6c7e88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492774")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2018")])]

#text("Dear Vassilis, you can use inbuilt latex with DOLLARlatex … DOLLAR, for example when you write DOLLAR latex \\frac{x}{y}DOLLAR, it compiles to ")#mi("\\frac{x}{y}")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64cdcf6c5ad2c4a5b929477f6c6f6bc307654f648757e49291f4a15228879b96-65ec6802d77367cb10a2bfcf950b269cfbdf743be840fe341c5f6b3d13792b27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vassilis Papanicolaou")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492853")[#strong[#text("Vassilis Papanicolaou")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2018")])]

#text("Thanks! Does the same work for displayed formulas?")

#emph[#text("[The latex parser here does not recognise environments such as \\begin{equation}…\\end{equation}, but it accepts the \\displaystyle command at least. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64cdcf6c5ad2c4a5b929477f6c6f6bc307654f648757e49291f4a15228879b96-65ec6802d77367cb10a2bfcf950b269cfbdf743be840fe341c5f6b3d13792b27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vassilis Papanicolaou")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492873")[#strong[#text("Vassilis Papanicolaou")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2018")])]

#text("Thanks!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492721")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2018")])]

#text("@Vassilis,")

#text("I had already wondered about what would happen when we make ")#mi("t=a+bi")#text(" and hadn’t appreciated that analytic continuation works for all ")#mi("t \\ne t_m")#text(".")

#text("Therefore made some X-ray plots to visualise how a Lehmer pair would respond to changes in ")#mi("b")#text(". Below are the ‘collision’ plots for respectively ")#mi("a = 0")#text(" and ")#mi("a = 0.1")#text(" when ")#mi("b")#text(" varies:")

#link("https://ibb.co/fAL3rS")[#text("https://ibb.co/fAL3rS")]#linebreak()#text(" ")#link("https://ibb.co/mNnYrS")[#text("https://ibb.co/mNnYrS")]

#text("Note: the plots for ")#mi("t=a-bi")#text(" are just versions mirrored over the x-axis.")

#text("Also checked at which ")#mi("0+bi")#text(" the collision would happen for the larger Lehmer pair (388858886.00228512, 388858886.00239368) and that is at about ")#mi("b=0.000008342")#text(" (compared to ")#mi("b=0.021")#text(" for the first Lehmer pair).")

#text("It seems that zeros already move off the critical line at pretty small ")#mi("b")#text(" and this might be an early indication that defining a complex ")#mi("t")#text(" with for instance an associated complex ")#mi("\\Lambda")#text(" doesn’t look to be a very promising route. However, when ")#mi("t")#text(" is complex the ‘red lines’ do start to move when ")#mi("b")#text(" changes. I found that for any ")#mi("a \\ge 0")#text(", there is a corresponding ")#mi("b")#text(" where now the red lines will collide (almost like an ‘echo’ of the Lehmer pair collision on the real line just below it). I produced the attached graph for ")#mi("t=0.4-0.986i")#text(" to illustrate this observation:")

#link("https://ibb.co/ksw7kn")[#text("https://ibb.co/ksw7kn")]

#text("P.S. for latex to work on this forum, just put dollarlatex in front and a single dollar at the end of your code (substitute the dollar sign where I wrote dollar).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Ruxton")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492724")[#strong[#text("Michael Ruxton")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2018")])]

#text("0 + ib with b = 0.025 or b = 0.0025 ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492744")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2018")])]

#text("Good catch. It is 0.025 of course. Corrected graph below.")

#link("https://ibb.co/dWbrvn")[#text("https://ibb.co/dWbrvn")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ef5e7c93b176a7617e0416f01e04497ff82ab5c2c8a9a015396c34d0d8687f-c34001fba30c1ceff6ba27b0aca55b12eda5633cec557f8295aa918df4469699.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug Stoll")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492925")[#strong[#text("Doug Stoll")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2018")])]

#text("You chose a good early example .")#linebreak()#text(" Are you also able to examine the pairs starting at:")

#text("10854395965.14210 with actual gap to next zero of 0.00002420")

#text("1239587702.54745 with actual gap to next zero of 0.00007356 and the numerically challenging one way out at")

#text("1034741742903.35376 with actual gap of 0.00001709")

#text("Thank you.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64cdcf6c5ad2c4a5b929477f6c6f6bc307654f648757e49291f4a15228879b96-65ec6802d77367cb10a2bfcf950b269cfbdf743be840fe341c5f6b3d13792b27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vassilis Papanicolaou")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492766")[#strong[#text("Vassilis Papanicolaou")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2018")])]

#text("Dear Rudolph,")

#text("Thanks for the reply. One strategy, then, to approach RH maybe the following: The zeros ")#mi("z_k(t)")#text(" of ")#mi("H_t(z)")#text(" are the branches of a global analytic function ")#mi("Z(T)")#text(" defined on an infinite-sheeted Riemann surface ")#mi("S")#text(".")

#text("If (i) the set of ramified points of ")#mi("S")#text(" is discrete and (ii) the ramification indices of these points are finite, then ")#mi("H_0(z)")#text(" has at most finitely many nonreal zeros.")

#text("(I hope I did corrrectly what you indicated to me regarding the latex appearance).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64cdcf6c5ad2c4a5b929477f6c6f6bc307654f648757e49291f4a15228879b96-65ec6802d77367cb10a2bfcf950b269cfbdf743be840fe341c5f6b3d13792b27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vassilis Papanicolaou")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492767")[#strong[#text("Vassilis Papanicolaou")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2018")])]

#text("Sorry,")

#text("instead of “(ii) the ramification indices of these points are finite”")

#text("I meant to say that there are only finitely many points on ")#mi("S")#text(" whose projection on the complex plane is ")#mi("t_m")#text(" (at least for each real ")#mi("t_m")#text(", ")#mi("t_m < \\Lambda")#text(".")

#text("This is somehow in accordance with the Ki-Kim_Lee paper.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492780")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2018")])]

#text("It seems that the extreme difficulty of RH indicates that (probably) (ii) does not hold (but RH is still possible, of course.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492723")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2018")])]

#text("Dear Terry,")#linebreak()#text(" If this project pulls about 100 mathematicians,the Riemann problem can be solved soon")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492813")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2018")])]

#text("In the main wiki page, it seems that ")#mi("\\sigma_{max}(t)^2 + t")#text(" should be “non-increasing” (instead of “non-decreasing”).")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492820")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2018")])]

#text("For ")#mi("t > 0")#text(" (by the KKL paper), any nonreal zero of ")#mi("H_t")#text(" is simple. Is it possible by the new effective approximation to ")#mi("H_t")#text(" to derive an effective positive lower bound (as explicit function of ")#mi("t")#text(") for the distance of any nonreal zero of ")#mi("H_t")#text(" from the other zeros of ")#mi("H_t")#text(" ?")

#text("Such a bound should imply (via the zeros ODE dynamics) an effective upper bound on the velocities of the nonreal zeros of ")#mi("H_t")#text(" – which can be used to establish a zero-free domain of ")#mi("H_t")#text(" from a known zero-free domain of ")#mi("H_0")#text(".")

#text("It seems that the current difficulty for establishing such zero-free domain for ")#mi("H_t")#text(" is the lack of such an effective upper bound on the horizontal velocities of incoming nonreal zeros of ")#mi("H_t")#text(" into a known zero-free domain of ")#mi("H_0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492830")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2018")])]

#text("Unfortunately Theorem 1.3 of KKL only ensures that all but finitely many zeroes are simple at any given time ")#mi("t>0")#text("; it looks like one could make this more effective now by giving an explicit value ")#mi("X")#text(" such that all zeroes of real part greater than ")#mi("X")#text(" are both real and simple. However we don’t seem to have any way to prevent a finite number of collisions at medium-sized real parts and non-zero imaginary parts in which the approximations available are not useful. Probabilistic heuristics would suggest that this does not happen (basically because the set of polynomials of a given degree with real coefficients but a repeated complex zero has codimension 2 and the heat flow is a trajectory of dimension 1) but I don’t see a mechanism to rule it out ")#emph[#text("a priori")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492850")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2018")])]

#text("It seems that in the wiki page on effective bounds on ")#mi("H_t")#text(" (second approach) there are certain errors")

#text("1. In the (first) definition of ")#mi("a")#text(", it seems that ")#mi("Im(s)")#text(" should be ")#tao-math("\\left| Im(s)\\right|", block: false)#text(" (to ensure that ")#mi("a")#text(" remains real and non-negative as required by the definition of ")#mi("N")#text("). ")#emph[#text("[In the discussion here it is assumed that ")#mi("\\mathrm{Im}(s)")#text(" is positive (in fact it is at least ")#mi("T_0 \\geq 10")#text("). -T.]")]

#text("2. In the definition of ")#mi("T^{\\prime} = T - \\pi i t /8")#text(", it is complex (which seems incompatible with the bounding of ")#tao-math("\\left|G_{0, N}(\\sigma + i T^{\\prime})\\right|", block: false)#text(" which seems to assume ")#mi("T^{\\prime}")#text(" to be real, and also with the second definition of ")#mi("a")#text(" by complex ")#mi("T^{\\prime}")#text("). ")#emph[#text("[The ")#mi("i")#text(" was a typo, now corrected – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492863")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2018")])]

#text("Another typo: in the third integral bound on ")#tao-math("\\left|G_{t, N}(s)\\right|", block: false)#text(", it should be ")#mi("d \\sigma")#text(" (instead of ")#mi("d u")#text(").")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6803f451a822a44c3357dffe0946273ac8b678c1381d8f6f15471f78bf5064e-c0cdd6fbf9fa11cb38f669d32e0c33214ced4ab5f9e837265aa2a25f482e13f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492871")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2018")])]

#text("Another small typo, at the end (in section ‘Final bound’): it should read that `f is defined by (4.1)’ rather than (4.8). Also in (4.1) there is an errant ‘du’.")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64cdcf6c5ad2c4a5b929477f6c6f6bc307654f648757e49291f4a15228879b96-65ec6802d77367cb10a2bfcf950b269cfbdf743be840fe341c5f6b3d13792b27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vassilis Papanicolaou")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492852")[#strong[#text("Vassilis Papanicolaou")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2018")])]

#text("In my comment regarding the dynamics of the zeros (February 16 2018, 10:19pm) there was an ERROR. Here is the corrected version:")

#text("In the G. Csordas, W. Smith, and R.S. Varga (1994) paper it has been shown that if ")#mi("t")#text(" is real and ")#mi("t > \\Lambda")#text(", then the zeros are (real and) simple and satisfy the dynamics")

#mi("\\displaystyle z^{\\prime}_k(t) = 2 \\sum_{z_j \\ne z_k} \\frac{1}{z_k(t) - z_j(t)}.")

#text("Since ")#mi("H_t(z)")#text(", is even in ")#mi("z")#text(", we have that ")#mi("z_k(t)")#text(" is a zero of ")#mi("H_t(z)")#text(" if and only if ")#mi("-z_k(t)")#text(" is a zero (counting multiplicities, of course). Hence, the above dynamics can be written as")

#mi("\\displaystyle z^{\\prime}_k(t) = \\frac{1}{z_k(t)}\\, +  2 \\sum_{z_j \\ne \\pm z_k} \\frac{1}{z_k(t) - z_j(t)} = \\frac{1}{z_k(t)} \\, + \\sum_{z_j \\ne \\pm z_k} \\frac{1}{z_k(t) - z_j(t)} \\, + \\sum_{z_j \\ne \\pm z_k} \\frac{1}{z_k(t) + z_j(t)}")

#text("or")

#mi("\\displaystyle z^{\\prime}_k(t) = \\frac{1}{z_k(t)}\\, + 2z_k(t) \\sum_{z_j \\ne \\pm z_k} \\frac{1}{z_k(t)^2 - z_j(t)^2}.")

#text("We can also multiply by ")#mi("2z_k(t)")#text(" and get the dynamics of ")#mi("z_k(t)^2")#text(":")

#mi("\\displaystyle [z_k^2(t)]^{\\prime} = 2 \\, + 4z_k(t)^2 \\sum_{z_j \\ne \\pm z_k} \\frac{1}{z_k(t)^2 - z_j(t)^2}.")

#text("Since ")#mi("H_t(z)")#text(" is of order 1 (and, being even, ")#mi("H_t(z) = F_t(z^2)")#text(", where ")#mi("F_t(\\cdot)")#text(" is entire of order ")#mi("1/2")#text("), the last sum above converges absolutely. Therefore, by analytic continuation, one expects that the above dynamics should continue to hold for any complex ")#mi("t \\ne t_m")#text(", where ")#mi("t_m")#text(" are the branch points.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492890")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2018")])]

#text("In the wiki page on effective bounds on ")#mi("H_t")#text(" (second approach), is there a simple bound (for moderately large ")#mi("T_0")#text(") for the integral in the final bound (to simplify its numerical computation)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492897")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2018")])]

#text("It is not clear from the final bound, what is the relative magnitude of the integral error term with respect to the main term of ")#mi("H_t(z)")#text(" (i.e. its asymptotic decay rate for large ")#mi("x")#text(" relative to the magnitude of ")#mi("H_t(x + i y)")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492932")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2018")])]

#text("The expression ")#mi("H_{0,1}(\\sigma+iT)")#text(" has size about ")#mi("T^{\\sigma + 3/2}e^{-\\pi T/4}")#text(", so the first term (now called ")#mi("A^{eff}")#text(" in the wiki) should have size about ")#mi("x^{\\frac{3}{2} + \\frac{1-y}{4}} e^{-\\pi x/8}")#text(" times the sum ")#mi("\\sum_{n=1}^N \\frac{1}{n^{\\frac{1-y+ix}{2} + t \\alpha_1(\\frac{1-y+ix}{2})/2 - t \\log n/4}}")#text(" (which is bounded in practice, but analytically can only be bounded efficiently currently for large ")#mi("x")#text("). Similarly, the second term (now called ")#mi("B^{eff}")#text(") has size about ")#mi("x^{\\frac{3}{2} + \\frac{1+y}{4}} e^{-\\pi x/8}")#text(" times ")#mi("\\sum_{n=1}^N \\frac{1}{n^{\\frac{1+y+ix}{2} + t \\alpha_1(\\frac{1-y+ix}{2})/2 - t \\log n/4}}")#text(". The main term here (call it ")#mi("B^{eff}_0")#text(" has magnitude about ")#mi("x^{\\frac{3}{2} + \\frac{1+y}{4}} e^{-\\pi x/8}")#text(". Of the error terms (now called ")#mi("E_1, E_2, E_3")#text(" on the wiki), the first term should be about ")#mi("x^{\\frac{1}{2} + \\frac{1-y}{4}} e^{-\\pi x/8}")#text(" in size (so about ")#mi("x^{-1-\\frac{y}{2}}")#text(" of ")#mi("B^{eff}_0")#text("), the second term should be about ")#mi("x^{\\frac{1}{2} + \\frac{1+y}{4}} e^{-\\pi x/8}")#text(" in size (so about ")#mi("x^{-1}")#text(" of ")#mi("B^{eff}_0")#text("), and the third should be about ")#mi("x^{\\frac{3}{2}} e^{-\\pi x/8}")#text(" in size (so about ")#mi("x^{-\\frac{1+y}{4}}")#text(" of ")#mi("B^{eff}_0")#text("). This seems broadly consistent with the numerical data showing that ")#mi("E_3")#text(" is the most significant error.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492931")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2018")])]

#text("It seems that the jumps near ")#mi("4\\pi^2 n^2")#text(" are due to ")#mi("\\cos(\\pi  p)")#text(" in the denominator of the expression for ")#mi("C_0(p)")#text(" which (because of rounding errors) should be computed more accurately near the removable singularities ")#mi("p = 1/2, -1/2")#text(" (for which both the numerator and denominator nearly vanish – therby loosing many significant digits!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492939")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2018")])]

#text("Since ")#mi("C_0(p)")#text(" is currently considered to be an error term, I think now that most probably, the jumps are due to jumps in the value of ")#mi("N")#text(" (i.e. when ")#mi("a = (T^{\\prime} / 2\\pi)^{1/2}")#text(" is an integer.")#linebreak()#text(" Is it possible to reduce these jumps (and the size of ")#mi("E_3")#text(") by refining the current estimate to include the detailed influence of ")#mi("C_0(p)")#text(" (i.e. not considering it as a merely “error term” – as done in the current estimate)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492945")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2018")])]

#text("Yes, this amounts to using an “A+B-C” type approximation to ")#mi("H_t")#text(" rather than the “A+B” approximations that we are currently discussing. It seems though that the C term is in practice one or two orders of magnitude less than the A and B terms, so this level of precision is probably not necessary for our application (though it would be helpful for looking at dynamics of zeroes, as some other commenters have done).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492963")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2018")])]

#text("I still think that ")#mi("C_0(p)")#text(" contribute the “main term” to the error term ")#mi("G_{t, N}(s)")#text(". To show that, note that")

#mi("G_{0, N}(\\sigma + i T^{\\prime})")

#text("appearing in the integral representation of ")#mi("G_{t, N}(s)")#text(" can be represented as")

#mi("W(\\sigma) a^{\\sigma} E_{0, N} (s^{\\prime})")#text(",")

#text("where ")#mi("s^{\\prime} := \\sigma + i T^{\\prime}")#text(" , and")

#mi("W(\\sigma) := (s^{\\prime} (1-s^{\\prime})/2) \\pi^{-s^{\\prime}/2} \\Gamma (s^{\\prime}/2) a^{-\\sigma}")

#text("Since")

#mi("a^{\\sigma} E_{0, N}(s^{\\prime}) = (-1)^{N-1}U (C_0(p) + O_{\\sigma}(1/a))")

#text("Where the error term ")#mi("O_{\\sigma}(1/a)")#text(" is effective, it is clear that ")#mi("C_0(p)")#text(" contribute the main term to the integral representation of ")#mi("G_{t, N}(s)")#text(" (with relative error of ")#mi("O(1/a)")#text(").")

#text("Hence, my suggestion is to first extract the contribution of ")#mi("C_0(p)")#text(" (i.e. the “main term”) to the integral representation of ")#mi("G_{t, N}(s)")#text(", and only then bound the remaining terms (which are ")#mi("O(1/a) = O(T^{-1/2})")#text(" relative to the already extracted “main term”).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492974")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2018")])]

#text("I agree that the ")#mi("C_0(p)")#text(" term will be the dominant contribution to the ")#mi("G_{t,N}")#text(" portion of ")#mi("H_t")#text(", and extracting it amounts more or less to replacing the “A+B” type approximate functional equation currently used with an “A+B-C” refinement. However, relative to ")#mi("B_0")#text(", it seems numerically that A+B has magnitude at least 0.4 or so, while C has magnitude about 0.01, and the upper bounds for the error including C are only a little larger at 0.02 or 0.03. So at present it seems there is not a pressing need to refine the approximation by extracting the “C” term. However one may well need to do so if one later aims to lower the value of t or y.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-492988")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2018")])]

#text("In the wiki page on effective bounds on ")#mi("H_t")#text(" (second approach), in the section “Bounding ")#mi("G_{t, N}(s)")#text("“, it seems that the argument ")#mi("s = \\sigma_0 + i T")#text(" appearing (5 times in the section) in ")#mi("E_{0, N}(s)")#text(" should be ")#mi("\\sigma + i T^{\\prime}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-493008")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2018")])]

#text("I will roll over the thread shortly, but just a heads up that I am in the process of writing a new wiki page ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem")[#text("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem")]#text(" on the problem of showing that ")#mi("H_t(x+iy) \\neq 0")#text(" whenever ")#mi("t = y = 0.4")#text(". So far I have written the four A+B type approximations we have available (finding some typos in the definition of the “toy” approximation in particular) and computed some numerical values. It looks like all of the approximations are in good agreement. Tomorrow I will try to input some of the other data that other commenters have made on the approximation and then write a fourth thread post for the polymath project.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-493014")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2018")])]

#text("It would be interesting to see (for each type of approximation) the explicit functional relationship between ")#mi("A(s)")#text(" and ")#mi("B(s)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-493052")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2018")])]

#text("I think in all cases the equation is ")#mi("A(s) = \\overline{B(\\overline{1-s})}")#text(" (or, if one extends ")#mi("A,B")#text(" to the lower half-plane by reflection, ")#mi("A(s) = B(1-s)")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George Szekers")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-493016")[#strong[#text("George Szekers")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2018")])]

#text("Dear Terry,")

#text("In your page please change /\\ < = 0.96 to /\\ <= 0.48")

#text("(")#linebreak()#text(" this is below the definition of the test problem, line 5 in the document")#linebreak()#text(" ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem")[#text("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem")]#linebreak()#text(" )")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-493020")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2018")])]

#text("In the wiki page on the test problem, the (expected) new upper bound should be 0.48 (instead of 0.96).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath15, fourth thread: closing in on the test problem | What's new")]], [#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/#comment-493061")[#strong[#text("Polymath15, fourth thread: closing in on the test problem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2018")])]

#text("[…] thread of the Polymath15 project to upper bound the de Bruijn-Newman constant , continuing ")#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-cons&#8230")[#text("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-cons&#8230")]#text(";. Progress will be summarised at this Polymath wiki […]")
]
