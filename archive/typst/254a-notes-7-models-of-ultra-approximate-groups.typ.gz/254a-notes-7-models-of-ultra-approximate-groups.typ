// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/
// Converted to Typst by tao2typ: "2026-10-27T12:30:27.250299+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 7: Models of ultra approximate groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 7: Models of ultra approximate groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 October 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/")[#text("https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-27 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the ")#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/")[#text("previous set of notes")]#text(", we introduced the notion of an ")#emph[#text("ultra approximate group")]#text(" – an ultraproduct ")#mi("{A = \\prod_{n \\rightarrow\\alpha} A_n}")#text(" of finite ")#mi("{K}")#text("-approximate groups ")#mi("{A_n}")#text(" for some ")#mi("{K}")#text(" independent of ")#mi("{n}")#text(", where each ")#mi("{K}")#text("-approximate group ")#mi("{A_n}")#text(" may lie in a distinct ambient group ")#mi("{G_n}")#text(". Although these objects arise initially from the “finitary” objects ")#mi("{A_n}")#text(", it turns out that ultra approximate groups ")#mi("{A}")#text(" can be profitably analysed by means of ")#emph[#text("infinitary")]#text(" groups ")#mi("{L}")#text(" (and in particular, locally compact groups or Lie groups ")#mi("{L}")#text("), by means of certain ")#emph[#text("models")]#text(" ")#mi("{\\rho: \\langle A \\rangle \\rightarrow L}")#text(" of ")#mi("{A}")#text(" (or of the group ")#mi("{\\langle A \\rangle}")#text(" generated by ")#mi("{A}")#text("). We will define precisely what we mean by a model later, but as a first approximation one can view a model as a representation of the ultra approximate group ")#mi("{A}")#text(" (or of ")#mi("{\\langle A \\rangle}")#text(") that is “macroscopically faithful” in that it accurately describes the “large scale” behaviour of ")#mi("{A}")#text(" (or equivalently, that the kernel of the representation is “microscopic” in some sense). In the next section we will see how one can use “Gleason lemma” technology to convert this macroscopic control of an ultra approximate group into microscopic control, which will be the key to classifying approximate groups.")

#text("Models of ultra approximate groups can be viewed as the multiplicative combinatorics analogue of the more well known concept of an ")#link("http://en.wikipedia.org/wiki/Ultralimit#Ultralimit_of_metric_spaces_with_specified_base-points")[#text("ultralimit")]#text(" of metric spaces, which we briefly review below the fold as motivation.")

#text("The crucial observation is that ultra approximate groups enjoy a ")#emph[#text("local compactness")]#text(" property which allows them to be usefully modeled by locally compact groups (and hence, through the Gleason-Yamabe theorem from ")#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/")[#text("previous notes")]#text(", by Lie groups also). As per the ")#link("http://en.wikipedia.org/wiki/Heine%E2%80%93Borel_theorem")[#text("Heine-Borel theorem")]#text(", the local compactness will come from a combination of a ")#link("http://en.wikipedia.org/wiki/Complete_metric_space")[#text("completeness")]#text(" property and a local ")#link("http://en.wikipedia.org/wiki/Totally_bounded_space")[#text("total boundedness")]#text(" property. The completeness property turns out to be a direct consequence of the ")#link("http://en.wikipedia.org/wiki/Non-standard_analysis#.CE.BA-saturation")[#text("countable saturation")]#text(" property of ultraproducts, thus illustrating one of the key advantages of the ultraproduct setting. The local total boundedness property is more interesting. Roughly speaking, it asserts that “large bounded sets” (such as ")#mi("{A}")#text(" or ")#mi("{A^{100}}")#text(") can be covered by finitely many translates of “small bounded sets” ")#mi("{S}")#text(", where “small” is a topological group sense, implying in particular that large powers ")#mi("{S^m}")#text(" of ")#mi("{S}")#text(" lie inside a set such as ")#mi("{A}")#text(" or ")#mi("{A^4}")#text(". The easiest way to obtain such a property comes from the following lemma ")#link("http://arxiv.org/abs/0912.0306")[#text("of Sanders")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Sanders lemma)")]#text(" ")#metadata(none) <tao-fb4e71f75b173583843c>#text(" Let ")#mi("{A}")#text(" be a finite ")#mi("{K}")#text("-approximate group in a (global) group ")#mi("{G}")#text(", and let ")#mi("{m \\geq 1}")#text(". Then there exists a symmetric subset ")#mi("{S}")#text(" of ")#mi("{A^4}")#text(" with ")#tao-math("{\\left|S\\right| \\gg_{K,m} \\left|A\\right|}", block: false)#text(" containing the identity such that ")#mi("{S^m \\subset A^4}")#text(".")
]

#text("This lemma has an elementary combinatorial proof, and is the key to endowing an ultra approximate group with locally compact structure. There is also a closely related lemma ")#link("http://arxiv.org/abs/1003.2978")[#text("of Croot and Sisask")]#text(" which can achieve similar results, and which will also be discussed below. (The locally compact structure can also be established more abstractly using the much more general methods of definability theory, as was first done ")#link("http://arxiv.org/abs/0909.2190")[#text("by Hrushovski")]#text(", but we will not discuss this approach here.)")

#text("By combining the locally compact structure of ultra approximate groups ")#mi("{A}")#text(" with the Gleason-Yamabe theorem, one ends up being able to model a large “ultra approximate subgroup” ")#mi("{A^{\\prime}}")#text(" of ")#mi("{A}")#text(" by a Lie group ")#mi("{L}")#text(". Such Lie models serve a number of important purposes in the structure theory of approximate groups. Firstly, as all Lie groups have a dimension which is a natural number, they allow one to assign a natural number “dimension” to ultra approximate groups, which opens up the ability to perform “induction on dimension” arguments. Secondly, Lie groups have an ")#emph[#text("escape property")]#text(" (which is in fact equivalent to ")#link("http://en.wikipedia.org/wiki/No_small_subgroup")[#text("no small subgroups")]#text(" property): if a group element ")#mi("{g}")#text(" lies outside of a very small ball ")#mi("{B_\\epsilon}")#text(", then some power ")#mi("{g^n}")#text(" of it will escape a somewhat larger ball ")#mi("{B_1}")#text(". Or equivalently: if a long orbit ")#mi("{g, g^2, \\ldots, g^n}")#text(" lies inside the larger ball ")#mi("{B_1}")#text(", one can deduce that the original element ")#mi("{g}")#text(" lies inside the small ball ")#mi("{B_\\epsilon}")#text(". Because all Lie groups have this property, we will be able to show that all ultra approximate groups ")#mi("{A}")#text(" “essentially” have a similar property, in that they are “controlled” by a nearby ultra approximate group which obeys a number of escape-type properties analogous to those enjoyed by small balls in a Lie group, and which we will call a ")#emph[#text("strong ultra approximate group")]#text(". This will be discussed in the next set of notes, where we will also see how these escape-type properties can be exploited to create a metric structure on strong approximate groups analogous to the Gleason metrics studied in ")#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/")[#text("previous notes")]#text(", which can in turn be exploited (together with an induction on dimension argument) to fully classify such approximate groups (in the finite case, at least).")

#text("There are some cases where the analysis is particularly simple. For instance, in the bounded ")#link("http://en.wikipedia.org/wiki/Torsion_(algebra)")[#text("torsion")]#text(" case, one can show that the associated Lie model ")#mi("{L}")#text(" is necessarily zero-dimensional, which allows for a easy classification of approximate groups of bounded torsion.")

#text("Some of the material here is drawn from my ")#link("http://arxiv.org/abs/1110.5008")[#text("recent paper with Ben Green and Emmanuel Breuillard")]#text(", which is in turn inspired by a ")#link("http://arxiv.org/abs/0909.2190")[#text("previous paper of Hrushovski")]#text(".")

#heading(level: 1)[#strong[#text(" — 1. Ultralimits of metric spaces (Optional) — ")]]

#text("Suppose one has a sequence ")#mi("{(X_n,d_n)}")#text(" of metric spaces. Intuitively, there should be a sense in which such a sequence can (in certain circumstances) “converge” to a limit ")#mi("{(X,d)}")#text(" that is another metric space. Some informal examples of this intuition:")

#list(
[#text("(i) The sets ")#mi("{\\{-n,\\ldots,n\\}}")#text(" (with the usual metric) should “converge” as ")#mi("{n \\rightarrow \\infty}")#text(" to the integers ")#mi("{{\\bf Z}}")#text(" (with the usual metric).")],
[#text("(ii) The cyclic groups ")#mi("{{\\bf Z}/n{\\bf Z}}")#text(" (with the “discrete” metric ")#mi("{d(i,j) := \\text{dist}(i+nZ, j+nZ)}")#text(") should also “converge” as ")#mi("{n \\rightarrow \\infty}")#text(" to the integers ")#mi("{{\\bf Z}}")#text(" (with the usual metric).")],
[#text("(iii) The sets ")#mi("{\\{ 0, \\frac{1}{n}, \\ldots, \\frac{n-1}{n}\\}}")#text(" (with the usual metric) should “converge” as ")#mi("{n \\rightarrow \\infty}")#text(" to the interval ")#mi("{[0,1]}")#text(" (with the usual metric).")],
[#text("(iv) The cyclic groups ")#mi("{{\\bf Z}/n{\\bf Z}}")#text(" (with the “bounded” metric ")#mi("{d(i,j) := \\frac{1}{n} \\text{dist}(i+nZ, j+nZ)}")#text(") should “converge” as ")#mi("{n \\rightarrow \\infty}")#text(" to the unit circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(" (with the usual metric).")],
[#text("(v) A Euclidean circle of radius ")#mi("{n}")#text(" (such as ")#mi("{\\{ (x,y) \\in {\\bf R}^2: x^2+(y-n)^2=n^2\\}}")#text(") should “converge” as ")#mi("{n \\rightarrow \\infty}")#text(" to a Euclidean line (such as ")#mi("{\\{ (x,0) \\in {\\bf R}^2: x \\in {\\bf R} \\}}")#text(").")

#text("Let us now try to formalise this intuition, proceeding in stages. The first attempt to formalise the above concepts is via the ")#link("http://en.wikipedia.org/wiki/Hausdorff_distance")[#text("Hausdoff distance")]#text(", which already made an appearance in ")#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/")[#text("Notes 4")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2 (Hausdorff distance)")]#text(" Let ")#mi("{X = (X,d)}")#text(" be a metric space. The ")#emph[#text("Hausdorff distance")]#text(" ")#mi("{d_H(E,F)}")#text(" between two non-empty subsets ")#mi("{E, F}")#text(" of ")#mi("{X}")#text(" is defined by the formula")

#align(center)[#tao-fit-display[#mitex("d_H(E,F) := \\max( \\sup_{x \\in E} d(x,F), \\sup_{y \\in F} d(E,y) ).")]]

#text("Thus, if ")#mi("{d_H(E,F) < r}")#text(", then every point in ")#mi("{E}")#text(" lies within a distance less than ")#mi("{r}")#text(" of a point in ")#mi("{F}")#text(", and every point in ")#mi("{F}")#text(" lies within a distance less ")#mi("{r}")#text(" of a point in ")#mi("{E}")#text(" (thus ")#mi("{E \\subset N_r(F)}")#text(" and ")#mi("{F \\subset N_r(E)}")#text(", where ")#mi("{N_r(F)}")#text(" is the ")#mi("{r}")#text("-neighbourhood of ")#mi("{E}")#text("); and conversely, if the latter claim holds, then ")#mi("{d_H(E,F) \\leq r}")#text(".")
]

#text("This distance is always symmetric, non-negative, and obeys the triangle inequality. If one restricts attention to non-empty compact sets ")#mi("{E, F}")#text(", then one easily verifies that ")#mi("{d_H(E,F)=0}")#text(" if and only if ")#mi("{E=F}")#text(", so that the Hausdorff distance becomes a metric. In particular, it becomes meaningful to discuss the concept of a sequence ")#mi("{E_n}")#text(" of non-empty compact subsets of ")#mi("{X}")#text(" converging in the Hausdorff distance to a (unique) limit non-empty compact set ")#mi("{E}")#text(". Note that this concept captures the intuitive example (iii) given above, but not any of the others. Nevertheless, we will discuss it first as it is slightly simpler than the more general notions we will be using.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1 (Hausdorff convergence and connectedness)")]#text(" Let ")#mi("{E_n}")#text(" be a sequence of non-empty compact subsets of a metric space ")#mi("{X}")#text(" converging to another non-empty compact set ")#mi("{E}")#text(".")

#list(
[#text("(i) If the ")#mi("{E_n}")#text(" are all connected, show that ")#mi("{E}")#text(" is connected also.")],
[#text("(ii) If the ")#mi("{E_n}")#text(" are all path-connected, does this imply that ")#mi("{E}")#text(" is path-connected also? Support your answer with a proof or counterexample.")],
[#text("(iii) If the ")#mi("{E_n}")#text(" are all disconnected, does this imply that ")#mi("{E}")#text(" is disconnected also? Support your answer with a proof or counterexample.")]
)
]

#text("One of the key properties of Hausdorff distance in a compact set is that it is itself compact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Compactness of the Hausdorff metric)")]#text(" ")#metadata(none) <tao-8df0d60370026aeef033>#text(" Let ")#mi("{E_n}")#text(" be a sequence of compact subsets of a compact metric space ")#mi("{X}")#text(". Then there is a subsequence of the ")#mi("{E_n}")#text(" that is convergent in the Hausdorff metric.")
]

#text("The proof of this lemma was set as Exercise 13 of ")#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/")[#text("Notes 4")]#text(". It can be proven by “conventional” means (relying in particular on the Heine-Borel theorem), but we will now sketch how one can establish this result using ultralimits instead. As in the ")#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/")[#text("previous set of notes")]#text(", we fix a standard universe ")#mi("{{\\mathfrak U}}")#text(" and a non-principal ultrafilter ")#mi("{\\alpha}")#text(" in order to define ultrapowers.")

#text("If ")#mi("{X = (X,d)}")#text(" is a (standard) metric space with metric ")#mi("{d: X \\times X \\rightarrow {\\bf R}^+}")#text(", then the ultrapower ")#mi("{{}^* X}")#text(" comes with a “nonstandard metric” ")#mi("{{}^* d: {}^* X \\times {}^* X \\rightarrow {}^* {\\bf R}^+}")#text(" that extends ")#mi("{d}")#text(". (In the previous notes, we referred to this metric as ")#mi("{d}")#text(" rather than ")#mi("{{}^* d}")#text(", but here it will be convenient to use a different symbol for this extension of ")#mi("{d}")#text(" to reduce confusion.) Let us say that two elements ")#mi("{x, y}")#text(" of ")#mi("{{}^* X}")#text(" are ")#emph[#text("infinitesimally close")]#text(" if ")#mi("{{}^* d(x,y) = o(1)}")#text(". (The set of points infinitesimally close to a standard point ")#mi("{x}")#text(" is sometimes known as the ")#link("http://en.wikipedia.org/wiki/Monad_(non-standard_analysis)")[#text("monad")]#text(" of ")#mi("{x}")#text(", although we will not use this terminology.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Let ")#mi("{(X,d)}")#text(" be a (standard) compact metric space. Show that for any nonstandard point ")#mi("{x \\in {}^* X}")#text(" there exists a unique standard point ")#mi("{\\text{st}(x) \\in {}^* X}")#text(" which is infinitesimally close to ")#mi("{x}")#text(", with")

#align(center)[#tao-fit-display[#mitex("d( \\text{st}(x), \\text{st}(y) ) = \\text{st} ( {}^* d(x,y) ).")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3 (Automatic completeness)")]#text(" Let ")#mi("{(X,d)}")#text(" be a (standard) compact metric space, and let ")#mi("{E = \\prod_{n \\rightarrow \\alpha} E_n}")#text(" be a nonstandard subset of ")#mi("{{}^* X}")#text(" (i.e. an ultraproduct of standard subsets ")#mi("{E_n}")#text(" of ")#mi("{X}")#text("), and let ")#mi("{\\text{st}: {}^* X \\rightarrow X}")#text(" be the standard part function as defined in the previous exercise. Show that ")#mi("{\\text{st}(E)}")#text(" is complete (and thus compact, by the Heine-Borel theorem). (")#emph[#text("Hint:")]#text(" take advantage of the countable saturation property from the ")#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/")[#text("previous notes")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Let ")#mi("{(X,d)}")#text(" be a compact metric space, and let ")#mi("{E_n}")#text(" for ")#mi("{n \\in {\\bf N}}")#text(" be a sequence of non-empty compact subsets of ")#mi("{X}")#text(". Write ")#mi("{E := \\prod_{n \\rightarrow \\alpha} E_n}")#text(" for the ultraproduct of the ")#mi("{E_n}")#text(", and let ")#mi("{\\text{st}: {}^* X \\rightarrow X}")#text(" be the standard part function as defined in the previous exercises. Show that ")#mi("{\\text{st}(E)}")#text(" is a non-empty compact subset of ")#mi("{X}")#text(", and that ")#mi("{\\lim_{n \\rightarrow \\alpha} d_H( E_n, \\text{st}(E) ) = o(1)}")#text(". Use this to give an alternate proof of Lemma ")#link(<tao-8df0d60370026aeef033>)[#text("3")]#text(".")
]

#text("One can extend some of the above theory from compact metric spaces to locally compact metric spaces.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Let ")#mi("{(X,d)}")#text(" be a (standard) locally compact metric space. Let ")#mi("{X \\subset O(X) \\subset {}^* X}")#text(" denote the set of ultralimits ")#mi("{\\lim_{n \\rightarrow \\alpha} x_n}")#text(" of ")#link("http://en.wikipedia.org/wiki/Precompact_set")[#text("precompact")]#text(" sequences ")#mi("{x_n}")#text(" in ")#mi("{X}")#text(".")

#list(
[#text("Show that ")#mi("{O(X) = {}^* X}")#text(" if and only if ")#mi("{X}")#text(" is compact.")],
[#text("Show that there is a unique function ")#mi("{\\text{st}: O(X) \\rightarrow X}")#text(" such that ")#mi("{x}")#text(" is infinitesimally close to ")#mi("{\\text{st}(x)}")#text(" for all ")#mi("{x \\in O(X)}")#text(".")],
[#text("If ")#mi("{E}")#text(" is a nonstandard subset of ")#mi("{{}^* X}")#text(", show that ")#mi("{\\text{st}( E \\cap O(X) )}")#text(" is complete.")],
[#text("Show that if ")#mi("{K}")#text(" is a compact set and ")#mi("{\\epsilon > 0}")#text(" is a (standard) real number, then ")#mi("{K \\cap E \\subset N_\\epsilon(E_n)}")#text(" and ")#mi("{K \\cap E_n \\subset N_\\epsilon(E)}")#text(" for all ")#mi("{n}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(".")]
)
]

#text("Now we consider limits of metric spaces ")#mi("{(X_n,d_n)}")#text(" that are not necessarily all embedded in a single metric space. We begin by considering the case of bounded metric spaces.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 4 (Gromov-Hausdorff distance)")]#text(" The ")#emph[#text("Gromov-Hausdorff distance")]#text(" ")#mi("{d_{GH}(X,Y)}")#text(" between two bounded metric spaces ")#mi("{(X,d_X)}")#text(", ")#mi("{(Y,d_Y)}")#text(" is the infimum of the Hausdorff distance ")#mi("{d_H( \\iota_{X \\rightarrow Z}(X), \\iota_{Y \\rightarrow Z}(Y) )}")#text(", ranging over all isometric embeddings ")#mi("{\\iota_{X \\rightarrow Z}: X \\rightarrow Z}")#text(", ")#mi("{\\iota_{Y \\rightarrow Z}: Y \\rightarrow Z}")#text(" from ")#mi("{X, Y}")#text(" respectively to ")#mi("{Z}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]

#list(
[#text("(i) Show that Gromov-Hausdorff distance is a pseudometric (i.e. symmetric, non-negative, and obeys the triangle inequality). (")#emph[#text("Hint:")]#text(" to show that ")#mi("{d_{GH}(X,Z) \\leq d_{GH}(X,Y)+d_{GH}(Y,Z)}")#text(", build a metric on the disjoint union ")#mi("{X \\uplus Z}")#text(" which intuitively captures the idea of the shortest path from ")#mi("{X}")#text(" to ")#mi("{Z}")#text(" via ")#mi("{Y}")#text(".)")],
[#text("(ii) If ")#mi("{E}")#text(" is a dense subset of a bounded metric space ")#mi("{X}")#text(", show that ")#mi("{d_{GH}(E,X)=0}")#text(". In particular, any bounded metric space ")#mi("{E}")#text(" is at a zero Gromov-Hausdorff distance from its metric completion ")#mi("{\\overline{E}}")#text(".")],
[#text("(iii) Show that if ")#mi("{X, Y}")#text(" are compact metric spaces, then ")#mi("{d_{GH}(X,Y) = 0}")#text(" if and only if ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are isometric. (")#emph[#text("Hint:")]#text(" If ")#mi("{d_{GH}(X,Y)=0}")#text(", find a sequence of “approximate isometries” from ")#mi("{X}")#text(" to ")#mi("{Y}")#text(" and from ")#mi("{Y}")#text(" to ")#mi("{X}")#text(" which almost invert each other. Then adapt the Arzelá-Ascoli theorem to take a limit (or one can use ultralimits and standard parts).)")]
)
]

#text("We say that a sequence ")#mi("{X_n=(X_n,d_n)}")#text(" of bounded metric spaces ")#emph[#text("converges in the Gromov-Hausdorff sense")]#text(" to another bounded metric space ")#mi("{X_\\infty}")#text(" if one has ")#mi("{d_{GH}(X_n,X_\\infty) \\rightarrow 0}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". This is a more general notion of convergence than Hausdorff convergence, and encompasses examples (iii) and (iv) at the beginning of this section.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Show that every compact metric space is the limit (in the Gromov-Hausdorff sense) of finite metric spaces.")
]

#text("Now we turn to an important compactness result about Gromov-Hausdorff convergence. We say that a sequence ")#mi("{X_n = (X_n,d_n)}")#text(" of metric spaces is ")#emph[#text("uniformly totally bounded")]#text(" if the diameters of the ")#mi("{X_n}")#text(" are bounded, and, for every ")#mi("{\\epsilon > 0}")#text(", there exists ")#mi("{C_\\epsilon}")#text(" such that each ")#mi("{X_n}")#text(" can be covered by at most ")#mi("{C_\\epsilon}")#text(" balls of radius ")#mi("{\\epsilon}")#text(" in the ")#mi("{d_n}")#text(" metric. (Of course, this implies that each ")#mi("{X_n}")#text(" is individually ")#link("http://en.wikipedia.org/wiki/Totally_bounded_space")[#text("totally bounded")]#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5 (Uniformly total bounded spaces are Gromov-Hausdorff precompact)")]#text(" ")#metadata(none) <tao-ebfa5fd45fa439ff406d>#text(" Let ")#mi("{X_n}")#text(" be a sequence of uniformly totally bounded metric spaces. Then there exists a subsequence ")#mi("{X_{n_j}}")#text(" which converges in the Gromov-Hausdorff space to a compact limit ")#mi("{X_\\infty}")#text(".")
]

#text("We will prove this proposition using ultrafilters. Let ")#mi("{X_n = (X_n,d_n)}")#text(" be a sequence of uniformly totally bounded metric spaces, which we will assume to be standard (by defining the standard universe in a suitable fashion). Then we can form the ultraproduct ")#mi("{X := \\prod_{n \\rightarrow \\alpha} X_n}")#text(" and the ultralimit ")#mi("{d := \\lim_{n \\rightarrow \\alpha} d_n}")#text(", thus ")#mi("{d: X \\times X \\rightarrow {}^* {\\bf R}^+}")#text(" is a nonstandard metric (obeying the nonstandard symmetry, triangle inequality, and positivity properties). As the ")#mi("{X_n}")#text(" are uniformly bounded, ")#mi("{d}")#text(" has bounded range. If we then take the standard part ")#mi("{\\text{st}(d): X \\times X \\rightarrow {\\bf R}^+}")#text(" of ")#mi("{d}")#text(", then ")#mi("{\\text{st}(d)}")#text(" is a pseudometric on ")#mi("{X}")#text(" (i.e. it obeys all the axioms of a metric except possibly for positivity.) We can then construct a quotient metric space ")#mi("{X_\\infty := X/\\sim}")#text(" in the usual manner, by declaring two points ")#mi("{x,y}")#text(" in ")#mi("{X}")#text(" to be equivalent, ")#mi("{x \\sim y}")#text(", if ")#mi("{\\text{st}(d)(x,y)=0}")#text(" (or equivalently if ")#mi("{d(x,y)=o(1)}")#text("). The pseudometric ")#mi("{\\text{st}(d)}")#text(" then descends to a genuine metric ")#mi("{d_\\infty:X_\\infty \\times X_\\infty \\rightarrow {\\bf R}^+}")#text(" on ")#mi("{X_\\infty}")#text(". The space ")#mi("{(X_\\infty,d_\\infty)}")#text(" is known as a ")#link("http://en.wikipedia.org/wiki/Ultralimit")[#text("metric ultralimit")]#text(" (or ")#emph[#text("ultralimit")]#text(" for short) of the ")#mi("{(X_n,d_n)}")#text(" (note that this is a slightly different usage of the term “ultralimit” from what we have been using previously).")

#text("One can easily establish compactness:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8 (Compactness)")]

#list(
[#text("(i) Show that ")#mi("{(X_\\infty, d_\\infty)}")#text(" is totally bounded. (")#emph[#text("Hint:")]#text(" use the uniform total boundedness of the ")#mi("{X_n}")#text(" together with Los’s theorem.)")],
[#text("(ii) Show that ")#mi("{(X_\\infty,d_\\infty)}")#text(" is complete. (")#emph[#text("Hint:")]#text(" use countable saturation).")]
)

#text("In particular, by the Heine-Borel theorem, ")#mi("{X_\\infty}")#text(" is compact.")
]

#text("Now we establish Gromov-Hausdorff convergence, in the sense that for every standard ")#mi("{\\epsilon > 0}")#text(", one has ")#mi("{d_{GH}(X_n,X_\\infty) < \\epsilon}")#text(" for all ")#mi("{n}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(". From this it is easy to extract a subsequence ")#mi("{X_{n_j}}")#text(" that converges in the Gromov-Hausdorff sense to ")#mi("{X_\\infty}")#text(" as required.")

#text("Fix a standard ")#mi("{\\epsilon>0}")#text(". As ")#mi("{X_\\infty}")#text(" is totally bounded, we can cover it by at most ")#mi("{M}")#text(" balls ")#mi("{B_\\infty(x_{1,\\infty},\\epsilon/10), \\ldots, B_\\infty(x_{M,\\infty},\\epsilon/10)}")#text(" of radius ")#mi("{\\epsilon/10}")#text(" (say) in the metric ")#mi("{d_\\infty}")#text(" for some standard natural number ")#mi("{M}")#text(". Lifting back to the ultraproduct ")#mi("{X}")#text(", we conclude that we may cover ")#mi("{X}")#text(" by ")#mi("{M}")#text(" balls ")#mi("{B(x_1,2\\epsilon/10),\\ldots,B(x_M,2\\epsilon/10)}")#text(" in the nonstandard metric ")#mi("{d}")#text(".")

#text("Note that ")#mi("{d_\\infty(x_{i,\\infty},x_{j,\\infty})}")#text(" is the standard part of ")#mi("{d(x_i,x_j)}")#text(", and in particular")

#align(center)[#tao-fit-display[#mitex("d_\\infty(x_{i,\\infty},x_{j,\\infty}) - \\epsilon/10 < d(x_i,x_j) < d_\\infty(x_{i,\\infty},x_{j,\\infty}) + \\epsilon/10.")]]

#text("Each ball centre ")#mi("{x_i}")#text(" is an ultralimit ")#mi("{x_i = \\lim_{n \\rightarrow \\alpha} x_{i,n}}")#text(" of points ")#mi("{x_{i,n}}")#text(" in ")#mi("{X_n}")#text(". By Los’s theorem, we conclude that for ")#mi("{n}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(", ")#mi("{X_n}")#text(" is covered by the ")#mi("{M}")#text(" balls ")#mi("{B_n(x_{1,n},2\\epsilon/10), \\ldots, B_n(x_{M,n},2\\epsilon/10)}")#text(" in the metric ")#mi("{d_n}")#text(", and")

#align(center)[#tao-fit-display[#mitex("d_\\infty(x_{i,\\infty},x_{j,\\infty}) - \\epsilon/10 < d_n(x_{i,n},x_{j,n}) < d_\\infty(x_{i,\\infty},x_{j,\\infty}) + \\epsilon/10")]]

#text("for all ")#mi("{1 \\leq i,j \\leq M}")#text(".")

#text("Because of this, we can embed both ")#mi("{X_n}")#text(" and ")#mi("{X_\\infty}")#text(" in the disjoint union ")#mi("{X_n \\uplus X_\\infty}")#text(", with a metric ")#mi("{d^{(n)}}")#text(" extending the metrics on ")#mi("{X_n}")#text(" and ")#mi("{X_\\infty}")#text(", with the cross distances ")#mi("{d^{(n)}( x, y )}")#text(" between points ")#mi("{x \\in X_n}")#text(" and ")#mi("{y \\in X_\\infty}")#text(" defined by the formula")

#align(center)[#tao-fit-display[#mitex("d^{(n)}(x,y) = d^{(n)}(y,x) := \\inf \\{ d_\\infty(x_{i,\\infty},y) + d_\\infty(x_{i,n},x) + \\epsilon/2: 1 \\leq i \\leq M \\};")]]

#text("informally, this connects each ball center ")#mi("{x_{i,\\infty}}")#text(" to its counterpart ")#mi("{x_{i,n}}")#text(" by a path of length ")#mi("{\\epsilon/2}")#text(". It is a routine matter to verify that ")#mi("{d^{(n)}}")#text(" is indeed a metric, and that ")#mi("{X_n}")#text(" and ")#mi("{X_\\infty}")#text(" are separated by a Hausdorff distance less than ")#mi("{\\epsilon}")#text(" in ")#mi("{X_n \\uplus X_\\infty}")#text(", and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Prove Proposition ")#link(<tao-ebfa5fd45fa439ff406d>)[#text("5")]#text(" without using ultrafilters.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Completeness)")]#text(" Let ")#mi("{X_n}")#text(" be a sequence of bounded metric spaces which is Cauchy in the Gromov-Hausdorff sense (i.e. ")#mi("{d_{GH}(X_n,X_m) \\rightarrow 0}")#text(" as ")#mi("{n,m \\rightarrow \\infty}")#text("). Show that ")#mi("{X_n}")#text(" converges in the Gromov-Hausdorff sense to some limit ")#mi("{X}")#text(".")
]

#text("Now we generalise Gromov-Hausdorff convergence to the setting of unbounded metric spaces. To motivate the definition, let us first give an equivalent form of Gromov-Hausdorff convergence:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Let ")#mi("{(X_n,d_n)}")#text(" be a sequence of bounded metric spaces, and let ")#mi("{(X_\\infty,d_\\infty)}")#text(" be another bounded metric space. Show that the following are equivalent:")

#list(
[#text("(i) ")#mi("{(X_n,d_n)}")#text(" converges in the Gromov-Hausdorff sense to ")#mi("{(X_\\infty,d_\\infty)}")#text(".")],
[#text("(ii) There exist maps ")#mi("{\\phi_n: X_\\infty \\rightarrow X_n}")#text(" which are asymptotically isometric isomorphisms in the sense that ")#tao-math("{\\sup_{x,y \\in X} \\left|d_n(\\phi_n(x),\\phi_n(y)) - d(x,y)\\right| \\rightarrow 0}", block: false)#text(" and ")#mi("{\\sup_{x_n \\in X_n} \\text{dist}_n( x_n, \\phi_n(X_\\infty) ) \\rightarrow 0}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".")]
)
]

#text("Define a ")#emph[#text("pointed metric space")]#text(" to be a triplet ")#mi("{(X,d,p)}")#text(", where ")#mi("{(X,d)}")#text(" is a metric space and ")#mi("{p}")#text(" is a point in ")#mi("{X}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 6 (Pointed Gromov-Hausdorff convergence)")]#text(" A sequence of pointed metric spaces ")#mi("{(X_n,d_n,p_n)}")#text(" is said to ")#emph[#text("converge in the pointed Gromov-Hausdorff sense")]#text(" to another pointed metric space ")#mi("{(X_\\infty,d_\\infty,p_\\infty)}")#text(" if there exists a sequence of maps ")#mi("{\\phi_n: X_\\infty \\rightarrow X_n}")#text(" such that")

#list(
[#mi("{d_n(\\phi_n(p_\\infty),p_n) \\rightarrow 0}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(";")],
[#text("(Asymptotic isometry) For each ")#mi("{R>0}")#text(", one has ")#tao-math("{\\sup_{x,y \\in B_\\infty(p_\\infty,R)} \\left|d_n(\\phi_n(x),\\phi_n(y)) - d_\\infty(x,y)\\right| \\rightarrow 0}", block: false)#text(" as ")#mi("{n \\rightarrow \\infty}")#text(";")],
[#text("(Asymptotic surjectivity) For each ")#mi("{R^{\\prime}>R>0}")#text(", one has ")#mi("{\\sup_{x \\in B_n(p_n,R)} \\text{dist}_n( x, \\phi_n(B_\\infty(p_\\infty,R^{\\prime})) ) \\rightarrow 0}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" Verify that all the examples (i)-(v) given at the start of the section are examples of pointed Gromov-Hausdorff convergence, once one selects a suitable point in each space.")
]

#text("The above definition is by no means the only definition of pointed Gromov-Hausdorff convergence. Here is another (which is basically the ")#link("http://www.ams.org/mathscinet-getitem?mr=623534")[#text("original definition of Gromov")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Let ")#mi("{(X_n,d_n,p_n)}")#text(" be a sequence of pointed metric spaces, and let ")#mi("{(X_\\infty,d_\\infty,p_\\infty)}")#text(" be another pointed metric space. Show that the following are equivalent:")

#list(
[#mi("{(X_n,d_n,p_n)}")#text(" converges in the pointed Gromov-Hausdorff sense to ")#mi("{(X_\\infty,d_\\infty,p_\\infty)}")#text(".")],
[#text("There exist metrics ")#mi("{\\tilde d_n}")#text(" on the disjoint union ")#mi("{X_n \\cup X_\\infty}")#text(" extending the metrics ")#mi("{d_n, d_\\infty}")#text(" such that for some sequence ")#mi("{\\epsilon_n \\rightarrow 0}")#text(", one has ")#mi("{\\tilde d_n(p_n,p_\\infty) \\leq \\epsilon_n}")#text(", ")#mi("{B_n(p_n,1/\\epsilon_n) \\subset N_{\\epsilon_n}(X_\\infty)}")#text(", and ")#mi("{B_\\infty(p_\\infty,1/\\epsilon_n) \\subset N_{\\epsilon_n}(X_n)}")#text(".")]
)

#text("Using this equivalence, construct a pseudometric between pointed metric spaces that describes pointwise Gromov-Hausdorff convergence.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Let ")#mi("{(X_n,d_n,p_n)}")#text(" be a sequence of pointed metric spaces which converge in the pointed Gromov-Hausdorff sense to a limit ")#mi("{(X_\\infty,d_\\infty,p_\\infty)}")#text(", and also to another limit ")#mi("{(X^{\\prime}_\\infty,d^{\\prime}_\\infty,p^{\\prime}_\\infty)}")#text(". Suppose that these two limit spaces are ")#link("http://en.wikipedia.org/wiki/Proper_map")[#text("proper")]#text(", which means that the closed balls ")#mi("{\\overline{B_\\infty(p_\\infty,R)}}")#text(" and ")#mi("{\\overline{B^{\\prime}_\\infty(p^{\\prime}_\\infty,R)}}")#text(" are compact. Show that the two limit spaces are pointedly isometric, thus there is an ")#link("http://en.wikipedia.org/wiki/Isometry")[#text("isometric isomorphism")]#text(" ")#mi("{\\phi: X_\\infty \\rightarrow X^{\\prime}_\\infty}")#text(" that maps ")#mi("{p_\\infty}")#text(" to ")#mi("{p^{\\prime}_\\infty}")#text(".")
]

#text("In the compact case, Gromov-Hausdorff convergence and pointwise Gromov-Hausdorff convergence are almost equivalent:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" Let ")#mi("{(X_n,d_n,p_n)}")#text(" be a sequence of bounded pointed metric spaces, and let ")#mi("{(X_\\infty,d_\\infty,p_\\infty)}")#text(" be a compact pointed metric space.")

#list(
[#text("(i) Show that if ")#mi("{(X_n,d_n,p_n)}")#text(" converges in the pointed Gromov-Hausdorff sense to ")#mi("{(X_\\infty,d_\\infty,p_\\infty)}")#text(", then ")#mi("{(X_n,d_n)}")#text(" converges in the Gromov-Hausdorff sense to ")#mi("{(X_\\infty,d_\\infty)}")#text(".")],
[#text("(ii) Conversely, if ")#mi("{(X_n,d_n)}")#text(" converges in the Gromov-Hausdorff sense to ")#mi("{(X_\\infty,d_\\infty)}")#text(", show that some subsequence ")#mi("{(X_{n_j},d_{n_j},p_{n_j})}")#text(" converges in the pointed Gromov-Hausdorff sense to ")#mi("{(X_\\infty,d_\\infty,q)}")#text(" for some ")#mi("{q \\in X_\\infty}")#text(".")]
)
]

#text("There is a compactness theorem for pointed Gromov-Hausdorff convergence analogous to that for ordinary Gromov-Hausdorff convergence (Proposition ")#link(<tao-ebfa5fd45fa439ff406d>)[#text("5")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7 (Locally uniformly total bounded spaces are pointed Gromov-Hausdorff precompact)")]#text(" ")#metadata(none) <tao-832f4cf4c8755d9a05e9>#text(" Let ")#mi("{X_n = (X_n,d_n,p_n)}")#text(" be a sequence of pointed metric spaces such that the balls ")#mi("{B_n(p_n,R)}")#text(" are uniformly totally bounded in ")#mi("{n}")#text(" for each fixed ")#mi("{R>0}")#text(". Then there exists a subsequence ")#mi("{X_{n_j}}")#text(" which converges in the pointed Gromov-Hausdorff space to a limit ")#mi("{X_\\infty = (X_\\infty,d_\\infty,p_\\infty)}")#text(" which is proper (i.e. every closed ball is compact).")
]

#text("We sketch a proof of this proposition in the exercise below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Let ")#mi("{X_n}")#text(" be as in the above proposition; we assume the ")#mi("{X_n}")#text(" to be standard. Let ")#mi("{X := \\prod_{n \\rightarrow \\alpha} X_n}")#text(" be the ultraproduct of the ")#mi("{X_n}")#text(", and define the ultralimits ")#mi("{d := \\prod_{n \\rightarrow \\alpha} d_n}")#text(" and ")#mi("{p := \\prod_{n \\rightarrow \\alpha}}")#text(". Let ")#mi("{O(X) := \\{x \\in X: d(x,p) = O(1)\\}}")#text(" be the points in ")#mi("{X}")#text(" that are a bounded distance from ")#mi("{p}")#text(".")

#list(
[#text("(i) Show that ")#mi("{\\text{st}(d): O(X) \\times O(X) \\rightarrow {\\bf R}^+}")#text(" is a pseudometric on ")#mi("{O(X)}")#text(".")],
[#text("(ii) Show that the associated quotient space ")#mi("{X_\\infty := O(X)/\\sim}")#text(" with the quotient metric ")#mi("{d_\\infty}")#text(" is a proper metric space.")],
[#text("(iii) Show that some subsequence of the ")#mi("{(X_n,p_n)}")#text(" converge in the pointed Gromov-Hausdorff sense to ")#mi("{(X_\\infty,p_\\infty)}")#text(", where ")#mi("{p_\\infty}")#text(" is the image of ")#mi("{p}")#text(" under the quotient map, thus establishing Proposition ")#link(<tao-832f4cf4c8755d9a05e9>)[#text("7")]#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" Establish Proposition ")#link(<tao-832f4cf4c8755d9a05e9>)[#text("7")]#text(" without using ultrafilters.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" Let ")#mi("{G}")#text(" be a locally compact group with a Gleason metric ")#mi("{d}")#text(". Show that the pointed metric spaces ")#mi("{(G, n d, 1)}")#text(" converge in the pointed Gromov-Hausdorff sense as ")#mi("{n \\rightarrow \\infty}")#text(" to the vector space ")#mi("{L(G)}")#text(" with the metric ")#tao-math("{d_{L(G)}(x,y) := \\left\\|x-y\\right\\|}", block: false)#text(" and distinguished point ")#mi("{0}")#text(", where the norm ")#mi("{\\| \\|}")#text(" on ")#mi("{L(G)}")#text(" was defined in Exercise 7 of ")#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/")[#text("Notes 2")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The above exercise suggests that one could attack Hilbert’s fifth problem by somehow “blowing up” the locally compact group ")#mi("{G}")#text(" around the origin and extracting a Gromov-Hausdorff limit using ultraproducts. This approach can be formalised using the language of nonstandard analysis, and in particular can be used to describe ")#link("http://www.ams.org/mathscinet-getitem?mr=967314")[#text("Hirschfeld’s nonstandard solution to Hilbert’s fifth problem")]#text(", as well as the ")#link("http://www.ams.org/mathscinet-getitem?mr=2680491")[#text("later work of Goldbring")]#text(". However, we will not detail this approach extensively here (though, on some level, it contains much the same ingredients as the known “standard” solutions to that problem, such as the one given in previous notes).")
]

#heading(level: 1)[#strong[#text(" — 2. Sanders-Croot-Sisask theory — ")]]

#text("We now prove Sanders’ lemma (Lemma ")#link(<tao-fb4e71f75b173583843c>)[#text("1")]#text("), which roughly speaking will be needed to establish an important “total boundedness” property of ultra approximate groups, which in turn is necessary to ensure local compactness for models of such groups.")

#text("Let ")#mi("{A}")#text(" be a ")#mi("{K}")#text("-approximate group for some ")#mi("{K>1}")#text(", and let ")#mi("{m}")#text(" be a (large) natural number. Our task is to locate a large set ")#mi("{S}")#text(" such that the iterated power ")#mi("{S^m}")#text(" is contained inside ")#mi("{A^4}")#text(". Sanders’ strategy for doing this is to pick a set ")#mi("{S}")#text(" that nearly stabilises a set ")#mi("{B}")#text(" that is comparable in some sense to ")#mi("{A}")#text(". More precisely, suppose we have non-empty finite sets ")#mi("{S}")#text(" and ")#mi("{B}")#text(" with the property that")

#align(center)[#tao-fit-display[#tao-math("\\left|B \\backslash sB\\right| < \\frac{1}{m} \\left|B\\right|", block: true)]]

#text("for all ")#mi("{s \\in S}")#text(". Then an easy induction shows that")

#align(center)[#tao-fit-display[#tao-math("\\left|B \\backslash gB\\right| < \\frac{k}{m} \\left|B\\right|", block: true)]]

#text("for all ")#mi("{g \\in S^k}")#text(" and all ")#mi("{k \\geq 1}")#text(". In particular, ")#mi("{B}")#text(" and ")#mi("{gB}")#text(" are not disjoint whenever ")#mi("{g \\in S^m}")#text(", which means that ")#mi("{S^m \\subset B B^{-1}}")#text(". Thus, to prove Sanders’ lemma, it suffices to find a non-empty set ")#mi("{B \\subset A^2}")#text(" with the property that the set ")#metadata(none) <tao-b831b33e0c05b45e15bb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("S := \\{ s \\in G: \\left|B \\backslash sB\\right| < \\frac{1}{m} \\left|B\\right| \\}", block: true)]]

#text("has cardinality ")#tao-math("{\\gg_{K,m} \\left|A\\right|}", block: false)#text(". (Note that this set ")#mi("{S}")#text(" will automatically be symmetric and contain the origin.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The set ")#link(<tao-b831b33e0c05b45e15bb>)[#text("(1)")]#text(" is known as a ")#emph[#text("symmetry set")]#text(" of ")#mi("{B}")#text(" and is sometimes denoted ")#mi("{Sym_{1/m}(B)}")#text(". One can also interpret this set as a ball, using the mapping ")#tao-math("{g \\mapsto \\frac{1}{\\left|B\\right|} 1_{gB}}", block: false)#text(" of ")#mi("{G}")#text(" into ")#mi("{\\ell^1(G)}")#text(" to pull back the ")#mi("{\\ell^1(G)}")#text(" metric to ")#mi("{G}")#text(", in which case ")#mi("{S}")#text(" is the ball of radius ")#mi("{\\frac{1}{m}}")#text(" centred at the origin.")
]

#text("It remains to find a set ")#mi("{B}")#text(" for which the set ")#link(<tao-b831b33e0c05b45e15bb>)[#text("(1)")]#text(" is large. To motivate how we would do this, let us naively try setting ")#mi("{B := A^2}")#text(". If the set ")#link(<tao-b831b33e0c05b45e15bb>)[#text("(1)")]#text(" associated to this set is large, we will be done, so let us informally consider the opposite case in which ")#mi("{S}")#text(" is extremely small; in particular, we have")

#align(center)[#tao-fit-display[#tao-math("\\left|A^2 \\backslash gA^2\\right| \\geq \\frac{1}{m} \\left|A^2\\right|", block: true)]]

#text("for “most” choices of ")#mi("{g \\in G}")#text(". In particular,")

#align(center)[#tao-fit-display[#tao-math("\\left|A^2 \\cap gA^2\\right| \\leq (1-\\frac{1}{m}) |A^2|.", block: true)]]

#text("Now observe that ")#mi("{(A \\cap gA) A}")#text(" is contained in ")#mi("{A^2 \\cap gA^2}")#text(", and so")

#align(center)[#tao-fit-display[#tao-math("\\left|(A \\cap gA) A\\right| \\leq (1-\\frac{1}{m}) |A^2|.", block: true)]]

#text("We have thus achieved a dichotomy: either the choice ")#mi("{B := A^2}")#text(" “works”, or else the set ")#mi("{B^{\\prime} := A^{\\prime} A}")#text(" is significantly smaller than ")#mi("{B = A^2}")#text(" for some ")#mi("{A^{\\prime} = A \\cap gA}")#text(". We can then try to repeat this dichotomy, to show that the choice ")#mi("{B^{\\prime} = A^{\\prime} A}")#text(" either “works”, or else the set ")#mi("{B^{\\prime\\prime} := A^{\\prime\\prime} A}")#text(" is significantly smaller than ")#mi("{B^{\\prime} = A^{\\prime} A}")#text(" for some ")#mi("{A^{\\prime\\prime} = A^{\\prime} \\cap g^{\\prime} A^{\\prime}}")#text(". We can keep iterating this dichotomy, creating ever smaller sets of the form ")#mi("{B_n = A_n A}")#text("; but on the other hand, these sets should be at least as large as ")#tao-math("{\\left|A\\right|}", block: false)#text(" (provided that we choose ")#mi("{g}")#text(", ")#mi("{g^{\\prime}}")#text(", etc. to prevent the sets ")#mi("{A^{\\prime}, A^{\\prime\\prime}}")#text(", etc. from becoming completely empty). So at some point this iteration has to terminate, at which point we should get a set that “works”.")

#text("The ")#link("http://arxiv.org/abs/0912.0306")[#text("original paper of Sanders")]#text(" contains a formalisation of the above argument. We present a slightly different arrangement of the argument below, which is focused on making sure that sets such as ")#mi("{A^{\\prime}}")#text(" do not get too small.")

#text("For any ")#mi("{0 < t \\leq 1}")#text(", define the quantity")

#align(center)[#tao-fit-display[#tao-math("f(t) := \\inf \\{ \\frac{\\left|A^{\\prime} A\\right|}{\\left|A\\right|}: A^{\\prime} \\subset A; \\left|A^{\\prime}\\right| \\geq t\\left|A\\right| \\}.", block: true)]]

#text("Then ")#mi("{f}")#text(" is a non-decreasing function that takes values between ")#mi("{1}")#text(" and ")#mi("{K}")#text(". By the pigeonhole principle, we can find ")#mi("{t \\gg_{K,m} 1}")#text(" such that ")#metadata(none) <tao-d77fae8fb7a58aaa0365>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("f( \\frac{t^2}{2K} ) > (1 - \\frac{1}{m}) f(t).")]]

#text("(The reasons for these particular choices of parameters will become clearer shortly.) Fix this ")#mi("{t}")#text(", and let ")#mi("{A^{\\prime}}")#text(" attain the infimum for ")#mi("{f(t)}")#text(", thus ")#mi("{A^{\\prime} \\subset A}")#text(", ")#tao-math("{\\left|A^{\\prime}\\right| \\geq t\\left|A\\right|}", block: false)#text(", and")

#align(center)[#tao-fit-display[#tao-math("\\left|A^{\\prime} A\\right| = f(t) |A|.", block: true)]]

#text("(Such an ")#mi("{A^{\\prime}}")#text(" exists since the infimum is only being taken over a finite set.) Set ")#mi("{B := A^{\\prime} A}")#text(", and let ")#mi("{S}")#text(" be the set in ")#link(<tao-b831b33e0c05b45e15bb>)[#text("(1)")]#text(". Observe that if ")#mi("{g \\not \\in S}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left|A^{\\prime} A \\backslash gA^{\\prime} A\\right| \\geq \\frac{1}{m} \\left|A^{\\prime} A\\right|,", block: true)]]

#text("and so by arguing as before we see that")

#align(center)[#tao-fit-display[#tao-math("\\left|(A^{\\prime} \\cap gA^{\\prime}) A\\right| \\leq \\left|A^{\\prime} A\\right| - \\frac{1}{m} |A^{\\prime} A|.", block: true)]]

#text("Since ")#tao-math("{\\left|A^2\\right| \\geq \\left|A\\right|}", block: false)#text(" and ")#tao-math("{\\left|A^{\\prime} A\\right| = f(t) \\left|A\\right|}", block: false)#text(", we thus have")

#align(center)[#tao-fit-display[#tao-math("\\left|(A^{\\prime} \\cap gA^{\\prime}) A\\right| \\leq (1 - \\frac{1}{m}) f(t) |A|.", block: true)]]

#text("In particular, from ")#link(<tao-d77fae8fb7a58aaa0365>)[#text("(2)")]#text(" and the definition of ")#mi("{f}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|A^{\\prime} \\cap gA^{\\prime}\\right| < \\frac{t^2}{2K} \\left|A\\right|", block: true)]]

#text("for all ")#mi("{g \\not \\in S}")#text(". In other words, ")#metadata(none) <tao-2af0abed05a8a1c25031>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("S \\supset \\{ g \\in G: \\left|A^{\\prime} \\cap gA^{\\prime}\\right| \\geq \\frac{t^2}{2K} \\left|A\\right| \\}.", block: true)]]

#text("So to finish the proof of Sanders’ lemma, it will suffice to obtain a lower bound on the right-hand side of ")#link(<tao-2af0abed05a8a1c25031>)[#text("(3)")]#text(". But this can be done by a standard Cauchy-Schwarz argument: starting with the identity")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\in A^2} \\sum_{a \\in A} 1_{aA^{\\prime}}(x) = \\left|A\\right| \\left|A^{\\prime}\\right| \\geq t \\left|A\\right|^2", block: true)]]

#text("and using the Cauchy-Schwarz inequality and the bound ")#tao-math("{\\left|A^2\\right| \\leq K\\left|A\\right|}", block: false)#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\in A^2} \\sum_{a,b \\in A} 1_{aA^{\\prime}}(x) 1_{bA^{\\prime}}(x) \\geq \\frac{t^2}{K} \\left|A\\right|^3", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\sum_{a,b \\in A} \\left|aA^{\\prime} \\cap bA^{\\prime}\\right| \\geq \\frac{t^2}{K} \\left|A\\right|^3.", block: true)]]

#text("By the pigeonhole principle, we may thus find ")#mi("{a \\in A}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{b \\in A} \\left|aA^{\\prime} \\cap bA^{\\prime}\\right| \\geq \\frac{t^2}{K} \\left|A\\right|^2,", block: true)]]

#text("and thus (setting ")#mi("{g := a^{-1} b}")#text(")")

#align(center)[#tao-fit-display[#tao-math("\\sum_{g \\in a^{-1} A} \\left|A^{\\prime} \\cap gA^{\\prime}\\right| \\geq \\frac{t^2}{K} \\left|A\\right|^2.", block: true)]]

#text("Since ")#mi("{a^{-1} A}")#text(" has cardinality ")#tao-math("{\\left|A\\right|}", block: false)#text(", this forces ")#tao-math("{\\left|A^{\\prime} \\cap gA^{\\prime}\\right|}", block: false)#text(" to exceed ")#tao-math("{\\frac{t^2}{2K} \\left|A\\right|}", block: false)#text(" for at least ")#tao-math("{\\frac{t^2}{2K} \\left|A\\right|}", block: false)#text(" values of ")#mi("{g}")#text(", and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" The lower bound on ")#mi("{S}")#text(" obtained by this argument is of the shape ")#tao-math("{\\left|S\\right| \\geq \\exp(-K^{O(m)}) \\left|A\\right|}", block: false)#text(". This is not optimal; see Remark ")#link(<tao-c27338c453067b437471>)[#text("5")]#text(" below.")
]

#text("We now present an alternate approach to Sanders’ lemma, using the ")#link("http://arxiv.org/abs/1003.2978")[#text("Croot-Sisask theory")]#text(" of ")#emph[#text("almost periods")]#text(". Whereas in the Sanders argument, one selected the set ")#mi("{S}")#text(" to be the set of group elements that almost stabilised a set ")#mi("{B}")#text(", we now select ")#mi("{S}")#text(" to be the set of group elements that almost stabilise (or are ")#emph[#text("almost periods")]#text(" of) the convolution")

#align(center)[#tao-fit-display[#mitex("1_A * 1_A(x) := \\sum_{y \\in G} 1_A(y) 1_A(y^{-1} x).")]]

#text("It is convenient to work in the ")#mi("{\\ell^2(G)}")#text(" metric. Since the function ")#mi("{1_A * 1_A}")#text(" has an ")#mi("{\\ell^1}")#text(" norm of ")#tao-math("{\\left|A\\right|^2}", block: false)#text(" and is supported in ")#mi("{A^2}")#text(", which has cardinality at most ")#tao-math("{K\\left|A\\right|}", block: false)#text(", we see from Cauchy-Schwarz that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| 1_A * 1_A \\right\\|_{\\ell^2(G)} \\geq \\left|A\\right|^{3/2} / K^{1/2}.", block: true)]]

#text("We now set")

#align(center)[#tao-fit-display[#tao-math("S := \\{ g \\in G: \\left\\| 1_A * 1_A - \\tau(g) 1_A * 1_A \\right\\|_{\\ell^2(G)} < \\frac{1}{m} \\frac{\\left|A\\right|^{3/2}}{K^{1/2}} \\}.", block: true)]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Show that ")#mi("{S}")#text(" is symmetric, contains the origin, and that ")#mi("{S^m \\subset A^4}")#text(".")
]

#text("To finish the proof of Sanders’ lemma, it suffices to show that there are lots of almost periods of ")#mi("{1_A * 1_A}")#text(" in the sense that ")#tao-math("{\\left|S\\right| \\gg_{K,m} \\left|A\\right|}", block: false)#text(".")

#text("The key observation here is that the translates ")#mi("{\\tau(g) 1_A * 1_A}")#text(" of ")#mi("{1_A * 1_A}")#text(", as ")#mi("{g}")#text(" varies in ")#mi("{A}")#text(", range in a “totally bounded” set. This in turn comes from a “compactness” property of the convolution operator ")#mi("{f \\mapsto f * 1_A}")#text(". when ")#mi("{f}")#text(" is supported on ")#mi("{A^2}")#text(". Croot and Sisask establish this by using a random sampling argument to approximate this convolution operator by a bounded rank operator. More precisely, let ")#mi("{M \\geq 1}")#text(" be an integer parameter to be chosen later, and select ")#mi("{M}")#text(" sample points ")#mi("{y_1,\\ldots,y_M}")#text(" from ")#mi("{A^2}")#text(" independently and uniformly at random (allowing repetitions). We will approximate the operator")

#align(center)[#tao-fit-display[#mitex("Tf := f * 1_A = \\sum_{y \\in A^2} f(y) 1_{y A}")]]

#text("for ")#mi("{f}")#text(" supported on ")#mi("{A^2}")#text(" by the operator")

#align(center)[#tao-fit-display[#tao-math("Sf := \\frac{\\left|A^2\\right|}{M} \\sum_{i=1}^M f(y_i) 1_{y_i A}.", block: true)]]

#text("The point is that as ")#mi("{M}")#text(" gets larger, ")#mi("{Sf}")#text(" becomes an increasingly good approximation to ")#mi("{Tf}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Let ")#mi("{f}")#text(" be a function supported on ")#mi("{A^2}")#text(" that is bounded in magnitude by ")#mi("{1}")#text(". Show that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} Sf = Tf")]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E} \\left\\| Sf - Tf\\right\\|_{\\ell^2(G)}^2 \\ll_K \\left|A\\right|^3 / M.", block: true)]]

#text("In particular, with probability at least ")#mi("{1/2}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Sf - Tf\\right\\|_{\\ell^2(G)} \\ll_K \\left|A\\right|^{3/2} M^{-1/2}.", block: true)]]
]

#text("Thus, for any ")#mi("{g \\in A}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| S 1_{gA} - T 1_{gA} \\right\\|_{\\ell^2(G)} \\ll_K \\left|A\\right|^{3/2} M^{-1/2}", block: true)]]

#text("with probability at least ")#mi("{1/2}")#text(". By the pigeonhole principle (or the first moment method), we thus conclude that there exists a choice of sample points ")#mi("{y_1,\\ldots,y_M}")#text(" for which ")#metadata(none) <tao-362f872e5bd9d979874c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\| S 1_{gA} - T 1_{gA} \\right\\|_{\\ell^2(G)} \\ll_K \\left|A\\right|^{3/2} M^{-1/2}", block: true)]]

#text("for at least ")#tao-math("{\\left|A\\right|/2}", block: false)#text(" choices of ")#mi("{g \\in A}")#text(".")

#text("Let ")#mi("{A^{\\prime}}")#text(" denote the set of all ")#mi("{g \\in A}")#text(" indicated above. For each ")#mi("{g \\in A^{\\prime}}")#text(", the function ")#mi("{S 1_{gA}}")#text(" is a linear combination of the ")#mi("{M}")#text(" functions ")#tao-math("{\\frac{\\left|A^2\\right|}{M} 1_{y_i A}}", block: false)#text(" with coefficients between ")#mi("{0}")#text(" and ")#mi("{1}")#text(". Each of these functions ")#tao-math("{\\frac{\\left|A^2\\right|}{M} 1_{y_i A}}", block: false)#text(" has an ")#mi("{\\ell^2(G)}")#text(" norm of ")#tao-math("{O_K( \\left|A\\right|^{3/2} )}", block: false)#text(". Thus, by the pigeonhole principle, one can find a subset ")#mi("{A^{\\prime\\prime}}")#text(" of ")#mi("{A^{\\prime}}")#text(" of size ")#tao-math("{\\left|A^{\\prime\\prime}\\right| \\gg_{K,m,M} \\left|A\\right|}", block: false)#text(" such that the functions ")#mi("{S 1_{gA}}")#text(" for ")#mi("{g \\in A^{\\prime\\prime}}")#text(" all lie within ")#tao-math("{\\frac{1}{2m} \\frac{\\left|A\\right|^{3/2}}{K^{1/2}}}", block: false)#text(" in ")#mi("{\\ell^2(G)}")#text(" norm of each other. If ")#mi("{M}")#text(" is large enough depending on ")#mi("{K,m}")#text(", we then conclude from ")#link(<tao-362f872e5bd9d979874c>)[#text("(4)")]#text(" and the triangle inequality that the functions ")#mi("{T 1_{gA}}")#text(" for ")#mi("{g \\in A^{\\prime\\prime}}")#text(" all lie within ")#tao-math("{\\frac{1}{m} \\frac{\\left|A\\right|^{3/2}}{K^{1/2}}}", block: false)#text(" in ")#mi("{\\ell^2(G)}")#text(" norm of each other. Translating by some fixed element of ")#mi("{A^{\\prime\\prime}}")#text(", we obtain the claim.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" For future reference, we observe that the above argument did not need the full strength of the hypothesis that ")#mi("{A}")#text(" was an ")#mi("{K}")#text("-approximate group; it would have sufficed for ")#mi("{A}")#text(" to be finite and non-empty with ")#tao-math("{\\left|A^2\\right| \\leq K\\left|A\\right|}", block: false)#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" ")#metadata(none) <tao-c27338c453067b437471>#text(" The above version of the Croot-Sisask argument gives a lower bound on ")#mi("{S}")#text(" of the shape ")#tao-math("{\\left|S\\right| \\geq \\exp(-O( m^2 K \\log K)) \\left|A\\right|}", block: false)#text(". As was observed ")#link("http://arxiv.org/abs/1011.0107")[#text("by Sanders")]#text(", by optimising the argument (in particular, replacing ")#mi("{\\ell^2}")#text(" with ")#mi("{\\ell^p}")#text(" for a large value of ")#mi("{p}")#text(", and replacing ")#mi("{1_A * 1_A}")#text(" by ")#mi("{1_A * 1_{A^2}}")#text("), one can improve this to ")#tao-math("{\\left|S\\right| \\geq \\exp( -O( m^2 \\log^2 K ) ) \\left|A\\right|}", block: false)#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" It is also possible to replace the random sampling argument above by a ")#link("http://en.wikipedia.org/wiki/Singular_value_decomposition")[#text("singular value decomposition")]#text(" of ")#mi("{T}")#text(" (restricted to something like ")#mi("{A^2}")#text(") to split it as the sum of a bounded rank component and a small operator norm component, after computing the Frobenius norm of ")#mi("{T}")#text(" in order to limit the number of large singular values. (In the abelian setting, this corresponds to a Fourier decomposition into large and small Fourier coefficients, which is a fundamental tool in additive combinatorics.) We will however not pursue this approach here.")
]

#text("As mentioned previously, the Sanders lemma will be useful in building topological group structure on ultra approximate groups ")#mi("{A}")#text(" (and the group ")#mi("{\\langle A \\rangle}")#text(" that they generate). The connection can be seen from the simple observation that if ")#mi("{U}")#text(" is a neighbourhood of the identity in a topological group and ")#mi("{m \\geq 1}")#text(", then there exists another neighbourhood ")#mi("{S}")#text(" of the identity such that ")#mi("{S^m \\subset U}")#text(". However, in addition to this multiplicative structure, we will also need to impose some conjugacy structure as well. (Strangely, even though the conjugation operation ")#mi("{(g,h) \\mapsto ghg^{-1}}")#text(" can be defined in terms of the more “primitive” operations of multiplication ")#mi("{(g,h) \\mapsto gh}")#text(" and inversion ")#mi("{g \\mapsto g^{-1}}")#text(", it almost seems to be an independent group operation in some ways, at least for the purposes of studying approximate groups, and the most powerful results tend to come from combining multiplicative structure and conjugation structure together. I do not know a fundamental reason for this “product-conjugation phenomenon” but it does seem to come up a lot in this subject.) Given two non-empty subsets ")#mi("{A, B}")#text(" of a group ")#mi("{G}")#text(", define")

#align(center)[#tao-fit-display[#mitex("A^B := \\{ a^b: a \\in A, b \\in B \\}")]]

#text("where ")#mi("{a^b := b^{-1} a b}")#text(" is the conjugate of ")#mi("{a}")#text(" by ")#mi("{b}")#text(". (Thus, for instance, ")#mi("{H^B = H}")#text(" whenever ")#mi("{H}")#text(" is a subgroup normalised by ")#mi("{B}")#text(".)")

#text("We can now establish a stronger version of the Sanders lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8 (Normal Sanders lemma)")]#text(" ")#metadata(none) <tao-e1e0e94fa8160f99f29f>#text(" Let ")#mi("{A}")#text(" be a finite ")#mi("{K}")#text("-approximate group in a (global) group ")#mi("{G}")#text(", let ")#mi("{m \\geq 1}")#text(", and let ")#mi("{B}")#text(" be a symmetric subset of ")#mi("{A}")#text(" with ")#tao-math("{\\left|B\\right| \\geq \\delta \\left|A\\right|}", block: false)#text(" for some ")#mi("{\\delta>0}")#text(". Then there exists a symmetric subset ")#mi("{N}")#text(" of ")#mi("{A^4}")#text(" with ")#tao-math("{\\left|N\\right| \\gg_{K,m,\\delta} \\left|A\\right|}", block: false)#text(" containing the identity such that ")#mi("{(N^{A^m})^m \\subset B^4}")#text(".")
]

#text("Roughly speaking, one can think of the set ")#mi("{S}")#text(" in Lemma ")#link(<tao-fb4e71f75b173583843c>)[#text("1")]#text(" as a “finite index subgroup” of ")#mi("{A^4}")#text(", while the set in Lemma ")#link(<tao-e1e0e94fa8160f99f29f>)[#text("8")]#text(" is a “finite index normal subgroup” of ")#mi("{A^4}")#text(". To get from the former to the latter, we will mimic the proof of the following well-known fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 9")]#text(" Suppose that ")#mi("{H}")#text(" is a finite index subgroup of a group ")#mi("{G}")#text(". Then there is a finite index normal subgroup ")#mi("{N}")#text(" of ")#mi("{G}")#text(" that is contained in ")#mi("{H}")#text(".")
]

#emph[#text("Proof:")]#text(" Consider all the conjugates ")#mi("{H^g}")#text(" of the finite index subgroup ")#mi("{H}")#text(" as ")#mi("{g}")#text(" ranges over ")#mi("{G}")#text(". As all the elements ")#mi("{g}")#text(" from the same right coset ")#mi("{Hk}")#text(" give the same conjugate ")#mi("{H^g}")#text(", and ")#mi("{H}")#text(" is finite index, we see that there are only finitely many such conjugates. Since the intersection of two finite index subgroups is again a finite index subgroup (why?), the intersection ")#mi("{N := \\bigcap_{g \\in G} H^g}")#text(" is thus a finite index subgroup of ")#mi("{G}")#text(". But we have ")#mi("{N = N^g}")#text(" for all ")#mi("{g \\in G}")#text(", and so ")#mi("{N}")#text(" is normal as desired. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" An inspection of the argument reveals that if ")#mi("{H}")#text(" had index ")#mi("{k}")#text(" in ")#mi("{G}")#text(", then the normal subgroup ")#mi("{N}")#text(" has index at most ")#mi("{k^k}")#text(". One can do slightly better than this by looking at the left action of ")#mi("{G}")#text(" on the ")#mi("{k}")#text("-element quotient space ")#mi("{G/H}")#text(", which one can think of as a homomorphism from ")#mi("{G}")#text(" to the symmetric group ")#mi("{S_k}")#text(" of ")#mi("{k}")#text(" elements. The kernel ")#mi("{N}")#text(" of this homomorphism is then clearly a normal subgroup of ")#mi("{G}")#text(" of index at most ")#tao-math("{\\left|S_k\\right|=k!}", block: false)#text(" that is contained in ")#mi("{H}")#text(". However, this slightly more efficient argument seems to be more “fragile” than the more robust proof given above, in that it is not obvious (to me, at least) how to adapt it to the approximate group setting of the Sanders lemma. (Thus we see the advantages of knowing multiple proofs for various basic facts in mathematics.)")
]

#text("Inspired by the above argument, we now prove Lemma ")#link(<tao-e1e0e94fa8160f99f29f>)[#text("8")]#text(". The main difficulty is to find an approximate version of the claim that the intersection of two finite index subgroups is again a finite index subgroup. This is provided by the following lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 10")]#text(" ")#metadata(none) <tao-952a7955d3c55b0102dc>#text(" Let ")#mi("{A}")#text(" be a ")#mi("{K}")#text("-approximate group, and let ")#mi("{A_1, A_2 \\subset A}")#text(" be such that ")#tao-math("{\\left|A_1\\right| \\geq \\delta_1 \\left|A\\right|}", block: false)#text(" and ")#tao-math("{\\left|A_2\\right| \\geq \\delta_2 \\left|A\\right|}", block: false)#text(". Then there exists a subset ")#mi("{B}")#text(" of ")#mi("{A}")#text(" with ")#mi("{B B^{-1} \\subset A_1 A_1^{-1} \\cap A_2 A_2^{-1}}")#text(" and ")#tao-math("{\\left|B\\right| \\geq \\delta_1 \\delta_2 \\left|A\\right|/K}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" Since ")#mi("{A^{-1}_1 A_2 \\subseteq A^2}")#text(", we have ")#tao-math("{\\left|A^{-1}_1 A_2\\right| \\leq K\\left|A\\right|}", block: false)#text(". It follows that there is some ")#mi("{x}")#text(" with at least ")#tao-math("{\\delta_1\\delta_2\\left|A\\right|/K}", block: false)#text(" representations as ")#mi("{a^{-1}_1 a_2}")#text(". Let ")#mi("{B}")#text(" be the set of all values of ")#mi("{a_2}")#text(" that appear. Obviously ")#mi("{B B^{-1} \\subseteq A_2 A^{-1}_2}")#text(". Suppose that ")#mi("{a_2, a^{\\prime}_2 \\in B}")#text(". Then there are ")#mi("{a_1, a^{\\prime}_1}")#text(" such that ")#mi("{x = a_1^{-1} a_2 = (a^{\\prime}_1)^{-1} a^{\\prime}_2}")#text(", and so ")#mi("{a^{\\prime}_1 a^{-1}_1 = a^{\\prime}_2 a_2^{-1}}")#text(". Thus ")#mi("{B B^{-1}}")#text(" lies in ")#mi("{A_1A_1^{-1}}")#text(" as well. ")#mi("\\Box")

#text("Now we prove Lemma ")#link(<tao-e1e0e94fa8160f99f29f>)[#text("8")]#text(". By Lemma ")#link(<tao-fb4e71f75b173583843c>)[#text("1")]#text(", we may find a symmetric set ")#mi("{S}")#text(" of ")#mi("{B^4}")#text(" containing the identity such that ")#mi("{S^{8m}}")#text(" (say) is contained in ")#mi("{B^4}")#text(" and ")#tao-math("{\\left|S\\right| \\gg_{K,m,\\delta} \\left|A\\right|}", block: false)#text(". We need the following simple covering lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21 (Ruzsa covering lemma)")]#text(" ")#metadata(none) <tao-965c2d9c5200c50411f5>#text(" Let ")#mi("{A, B}")#text(" be finite non-empty subsets of a group ")#mi("{G}")#text(" such that ")#tao-math("{\\left|AB\\right| \\leq K \\left|B\\right|}", block: false)#text(". Show that ")#mi("{A}")#text(" can be covered by at most ")#mi("{K}")#text(" left-translates ")#mi("{aB B^{-1}}")#text(" of ")#mi("{B B^{-1}}")#text(" for various ")#mi("{a \\in A}")#text(". (")#emph[#text("Hint:")]#text(" find a maximal disjoint family of ")#mi("{aB}")#text(" with ")#mi("{a \\in A}")#text(".)")
]

#text("From the above lemma we see that ")#mi("{A}")#text(" can be covered by ")#mi("{O_{K,m}(1)}")#text(" left translates of ")#mi("{S^2}")#text(". As ")#mi("{A^m}")#text(" can be covered by ")#mi("{O_{K,m}(1)}")#text(" left-translates of ")#mi("{A}")#text(", we conclude that ")#mi("{A^m}")#text(" can be covered by ")#mi("{O_{K,m}(1)}")#text(" left-translates of ")#mi("{S^2}")#text(". Since ")#mi("{S^2 \\subset A^8}")#text(", we conclude that ")#mi("{A^m \\subset \\bigcap_{j=1}^J a_j S^2}")#text(" for some ")#mi("{J=O_{K,m}(1)}")#text(" and ")#mi("{a_1,\\ldots,a_J \\in A^{m+8}}")#text(".")

#text("The conjugates ")#mi("{a_j^{-1} S a_j^{-1}}")#text(" all lie in ")#mi("{A^{2m+20}}")#text(". By many applications of Lemma ")#link(<tao-952a7955d3c55b0102dc>)[#text("10")]#text(", we see that we may find a subset ")#mi("{D}")#text(" of ")#mi("{A^{2m+4}}")#text(" with ")#tao-math("{\\left|D\\right| \\gg_{K,m} \\left|A\\right|}", block: false)#text(" such that")

#align(center)[#tao-fit-display[#mitex("D D^{-1} \\subset a_j S^4 a_j^{-1}")]]

#text("for all ")#mi("{j=1,\\ldots,J}")#text(". In particular, if ")#mi("{N := DD^{-1}}")#text(", then ")#mi("{N^{a_j} \\subset S^4}")#text(" for all ")#mi("{j=1,\\ldots,J}")#text(", and thus ")#mi("{N^{A^m} \\subset S^8}")#text(". Thus ")#mi("{(N^{A^m})^m \\subset B^4}")#text(", and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" The quantitative bounds on ")#tao-math("{\\left|N\\right|}", block: false)#text(" given by this argument are quite poor, being of triple exponential type (!) in ")#mi("{K}")#text(". It is likely that this can be improved by a more sophisticated argument.")
]

#heading(level: 1)[#strong[#text(" — 3. Locally compact models of ultra approximate groups — ")]]

#text("We now use the normal Sanders lemma to place a topology on ultra approximate groups. We first build a “neighbourhood base” associated to an ultra approximate group:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Let ")#mi("{A}")#text(" be an ultra approximate group. Show that there exist a sequence of ultra approximate groups")

#align(center)[#tao-fit-display[#mitex("A^4 = A_0 \\supset A_1 \\supset A_2 \\supset \\ldots \\supset \\ldots")]]

#text("such that")

#align(center)[#tao-fit-display[#mitex("(A_m^{A^m})^2 \\subset A_{m-1}")]]

#text("for all ")#mi("{m \\geq 1}")#text(", and such that ")#mi("{A^4}")#text(" can be covered by finitely many left-translates of ")#mi("{A_m}")#text(" for each ")#mi("{m}")#text(". (")#emph[#text("Hint:")]#text(" you will need Lemma ")#link(<tao-e1e0e94fa8160f99f29f>)[#text("8")]#text(", Lemma ")#link(<tao-952a7955d3c55b0102dc>)[#text("10")]#text(", Exercise ")#link(<tao-965c2d9c5200c50411f5>)[#text("21")]#text(", and some sort of recursive construction.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" ")#metadata(none) <tao-b5e906c79dfd3193762d>#text(" A simple example to keep in mind here is the nonstandard interval ")#mi("{A = [-N,N]}")#text(" for some unbounded nonstandard natural number ")#mi("{N}")#text(", with ")#mi("{A_m := [-4N/2^m, 4N/2^m]}")#text(".")
]

#text("This gives a good topology on the group ")#mi("{\\langle A \\rangle = \\bigcup_{m=1}^\\infty A^m}")#text(" generated by ")#mi("{A}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" Let ")#mi("{A}")#text(" be an ultra approximate group, and let ")#mi("{\\langle A \\rangle}")#text(" be the group generated by ")#mi("{A}")#text(". Let ")#mi("{A_0, A_1, \\ldots}")#text(" be as in the preceding exercise. Given a subset ")#mi("{E}")#text(" of ")#mi("{\\langle A \\rangle}")#text(", call a point ")#mi("{g}")#text(" in ")#mi("{E}")#text(" an ")#emph[#text("interior point")]#text(" of ")#mi("{E}")#text(" if one has ")#mi("{g A_m \\subset E}")#text(" for some (standard) ")#mi("{m}")#text(". Call ")#mi("{E}")#text(" ")#emph[#text("open")]#text(" if every element of ")#mi("{E}")#text(" is an interior point.")

#list(
[#text("(i) Show that this defines a topology on ")#mi("{E}")#text(".")],
[#text("(ii) Show that this topology makes ")#mi("{\\langle A \\rangle}")#text(" into a topological group (i.e. the group operations are continuous).")],
[#text("(iii) Show that this topology is first countable (and thus pseudo-metrisable by the Birkhoff-Kakutani theorem (see Theorem 6 from ")#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/")[#text("Notes 4")]#text(")).")],
[#text("(iv) Show that one can build a left-invariant pseudometric ")#mi("{d: \\langle A \\rangle \\times \\langle A \\rangle \\rightarrow {\\bf R}^+}")#text(" on ")#mi("{\\langle A \\rangle}")#text(" which generates the topology on ")#mi("{\\langle A \\rangle}")#text(", with the property that")

#align(center)[#tao-fit-display[#mitex("B(1, c 2^{-m}) \\subset A_m \\subset B(1, C 2^{-m} )")]]

#text("for all (standard) ")#mi("{m \\geq 0}")#text(" and some (standard) ")#mi("{C > c > 0}")#text(". (")#emph[#text("Hint:")]#text(" inspect the proof of the Birkhoff-Kakutani theorem.)")],
[#text("(v) Show that ")#mi("{\\langle A \\rangle}")#text(" with this pseudometric is complete (i.e. every Cauchy sequence is convergent). (")#emph[#text("Hint:")]#text(" use the countable saturation property.)")],
[#text("(vi) Show that ")#mi("{A^m}")#text(" is totally bounded for each standard ")#mi("{m}")#text(" (i.e. covered by a finite number of ")#mi("{\\epsilon}")#text("-balls for each ")#mi("{\\epsilon>0}")#text(").")],
[#text("(vii) Show that ")#mi("{\\langle A \\rangle}")#text(" is locally compact.")]
)
]

#text("With this topology, the group ")#mi("{\\langle A \\rangle}")#text(" becomes a locally compact topological group. However, in general this group will not be Hausdorff, because the identity ")#mi("{1}")#text(" need not be closed. Indeed, it is easy to see that the closure of ")#mi("{1}")#text(" is the set ")#mi("{\\bigcap_{m=1}^\\infty A_m}")#text(", which is not necessarily trivial. For instance, using the example from Remark ")#link(<tao-b5e906c79dfd3193762d>)[#text("9")]#text(", ")#mi("{\\langle A \\rangle}")#text(" is the group ")#mi("{\\{ n \\in {}^* {\\bf Z}: n = O(N) \\}}")#text(", and the closure of the identity is ")#mi("{\\{ n \\in {}^* {\\bf Z}: n=o(N)\\}}")#text(". However, we may quotient out by this closure of the identity to obtain a locally compact ")#emph[#text("Hausdorff")]#text(" group ")#mi("{L}")#text(", which is now metrisable (with the metric induced from the pseudometric ")#mi("{d}")#text(" on ")#mi("{\\langle A \\rangle}")#text("). Let ")#mi("{\\pi: \\langle A \\rangle \\rightarrow L}")#text(" be the quotient homomorphism. This homomorphism obeys a number of good properties, which we formalise as a definition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 11")]#text(" Let ")#mi("{A}")#text(" be an ultra approximate group. A (global) ")#emph[#text("good model")]#text(" for ")#mi("{A}")#text(" is a homomorphism ")#mi("{\\pi: \\langle A \\rangle \\rightarrow L}")#text(" from ")#mi("{\\langle A \\rangle}")#text(" to a locally compact Hausdorff group ")#mi("{L}")#text(" that obeys the following axioms:")

#list(
[#text("(Thick image) There exists a neighbourhood ")#mi("{U_0}")#text(" of the identity in ")#mi("{L}")#text(" such that ")#mi("{\\pi^{-1}(U_0) \\subset A}")#text(" and ")#mi("{U_0 \\subset \\pi(A)}")#text(". (In particular, the kernel of ")#mi("{\\pi}")#text(" lies in ")#mi("{A}")#text(".)")],
[#text("(Compact image) ")#mi("{\\pi(A)}")#text(" is precompact.")],
[#text("(Approximation by nonstandard sets) Suppose that ")#mi("{F \\subset U \\subset U_0}")#text(", where ")#mi("{F}")#text(" is compact and ")#mi("{U}")#text(" is open. Then there exists a nonstandard finite set ")#mi("{B}")#text(" (i.e. an ultraproduct of finite sets) such that ")#mi("{\\pi^{-1}(F) \\subset B \\subset \\pi^{-1}(U)}")#text(".")]
)

#text("We will often abuse notation and refer to ")#mi("{L}")#text(" as the good model, rather than ")#mi("{\\pi}")#text(". (Actually, to be truly pedantic, it is the ordered pair ")#mi("{(\\pi,L)}")#text(" which is the good model, but we will not use this notation often.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 10")]#text(" In the next set of notes we will also need to consider ")#emph[#text("local")]#text(" good models, which only model (say) ")#mi("{A^8}")#text(" rather than all of ")#mi("{\\langle A \\rangle}")#text(", and in which ")#mi("{L}")#text(" is a local group rather than a global one. However, for simplicity we will not discuss local good models for the moment.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 11")]#text(" The thick and compact image axioms imply that the geometry of ")#mi("{L}")#text(" in some sense corresponds to the geometry of ")#mi("{A}")#text(". In particular, if ")#mi("{a}")#text(" is an element of ")#mi("{\\langle A \\rangle}")#text(", then ")#mi("{a}")#text(" will be “small” (in the sense that it lies in ")#mi("{A}")#text(") if ")#mi("{\\pi(a)}")#text(" is close to the identity, and “large” (in the sense that it lies outside ")#mi("{A}")#text(") if ")#mi("{\\pi(a)}")#text(" is far away from the identity. Thus ")#mi("{\\pi}")#text(" is “faithful” in some “coarse” or “macroscopic” sense. The inclusion ")#mi("{U_0 \\subset \\pi(A)}")#text(" is a sort of “local surjectivity” condition, and ensures that ")#mi("{L}")#text(" does not contain any “excess” or “redundant” components. The approximation by nonstandard set axiom is a technical “measurability” axiom, that ensures that the model of the ultra approximate group actually has something nontrivial to say about the finite approximate groups that were used to build that ultra approximate group (as opposed to being some artefact of the ultrafilter itself).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" ")#metadata(none) <tao-43511e29ea202ad36a5d>#text(" We continue the example from Remark ")#link(<tao-b5e906c79dfd3193762d>)[#text("9")]#text(". A good model for ")#mi("{A = [-N,N]}")#text(" is provided by the homomorphism ")#mi("{\\pi: \\langle A \\rangle \\rightarrow {\\bf R}}")#text(" given by the formula ")#mi("{\\pi(x) := \\text{st}(x/N)}")#text(". The thick image and compact image properties are clear. To illustrate the approximation by nonstandard set property, take ")#mi("{F = [-r,r]}")#text(" and ")#mi("{U = (-s,s)}")#text(" for some (standard) real numbers ")#mi("{0 < r < s}")#text(". The preimages ")#tao-math("{\\pi^{-1}(F) = \\{ n \\in {}^* {\\bf Z}: \\left|n\\right| \\leq rN + o(N) \\}}", block: false)#text(" and ")#tao-math("{\\pi^{-1}(U) = \\{ n \\in {}^* {\\bf Z}: \\left|n\\right| < (s-\\epsilon) N \\text{ for some standard } \\epsilon>0\\}}", block: false)#text(" are not nonstandard finite sets (why? use the least upper bound axiom), but one can find a nonstandard integer ")#mi("{M}")#text(" such that ")#mi("{r < \\text{st}(M/N) < s}")#text(", and ")#mi("{[-M,M]}")#text(" will be a nonstandard finite set between ")#mi("{F}")#text(" and ")#mi("{U}")#text(".")
]

#text("The following fundamental observation is essentially ")#link("http://arxiv.org/abs/0909.2190")[#text("due to Hrushovski")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" ")#metadata(none) <tao-eda6f634f26637a07eb0>#text(" Let ")#mi("{A}")#text(" be an ultra approximate group. Show that ")#mi("{A^4}")#text(" has a good model by a locally compact Hausdorff metrisable group, given by the construction discussed previously.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" The purpose of this exercise is to show why it is necessary to model ")#mi("{A^4}")#text(", rather than ")#mi("{A}")#text(", in Exercise ")#link(<tao-eda6f634f26637a07eb0>)[#text("24")]#text(". Let ")#mi("{F_2}")#text(" be the field of two elements. For each positive integer ")#mi("{n}")#text(", let ")#mi("{A_n}")#text(" be a random subset of ")#mi("{F_2^n}")#text(" formed by selecting one element uniformly at random from the set ")#mi("{x, x+e_n}")#text(" for each ")#mi("{x \\in F_2^{n-1} \\times \\{0\\}}")#text(", and also selecting the identity ")#mi("{0}")#text(". Clearly, ")#mi("{A_n}")#text(" is a ")#mi("{2}")#text("-approximate group, since ")#mi("{A_n}")#text(" is contained in ")#mi("{F_2^n = A_n + \\{0,e_n\\}}")#text(".")

#list(
[#text("(i) Show that almost surely, for all but finitely many ")#mi("{n}")#text(", ")#mi("{A_n}")#text(" does not contain any set of the form ")#mi("{B+B}")#text(", with ")#tao-math("{\\left|B\\right| \\geq 2^{0.9 n}}", block: false)#text(". (")#emph[#text("Hint:")]#text(" use the ")#link("http://en.wikipedia.org/wiki/Borel%E2%80%93Cantelli_lemma")[#text("Borel-Cantelli lemma")]#text(".)")],
[#text("(ii) Show that almost surely, the ultraproduct ")#mi("{\\prod_{n \\rightarrow \\alpha} A_n}")#text(" cannot be modeled by any locally compact group.")]
)
]

#text("Let us now give some further examples of good models, beyond that given by Example ")#link(<tao-43511e29ea202ad36a5d>)[#text("1")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2 (Nonstandard finite groups)")]#text(" ")#metadata(none) <tao-d85db0a54febab6113cc>#text(" Suppose that ")#mi("{A_n}")#text(" is a sequence of (standard) finite groups; then the ultraproduct ")#mi("{A := \\prod_{n \\rightarrow \\alpha} A_n}")#text(" is an ultra approximate group. In this case, ")#mi("{A}")#text(" is in fact a genuine group, thus ")#mi("{A = \\langle A \\rangle}")#text(". In this case, the trivial homomorphism ")#mi("{\\pi: \\langle A \\rangle \\rightarrow L = \\{1\\}}")#text(" to the trivial group ")#mi("{\\{1\\}}")#text(" is a good model of ")#mi("{A}")#text(". Conversely, it is easy to see that this is the only case in which ")#mi("{\\{1\\}}")#text(" is a good model for ")#mi("{A}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3 (Generalised arithmetic progression)")]#text(" ")#metadata(none) <tao-54d5dbf0124e59afba31>#text(" We still work in the integers ")#mi("{{\\bf Z}}")#text(", but now take ")#mi("{A_n}")#text(" to be the rank two generalised arithmetic progression")

#align(center)[#tao-fit-display[#mitex("A_n := P(1,n^{10}; n,n) := \\{ a+bn^{10}: a,b \\in \\{-n,\\ldots,n\\}\\}.")]]

#text("Then the ultraproduct ")#mi("{A := \\prod_{n \\rightarrow \\alpha} A_n}")#text(" is the subset of the nonstandard integers ")#mi("{{}^* {\\bf Z}}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("A = P(1,N^{10};N,N) = \\{ a+bN^{10}: a,b \\in \\{-N,\\ldots,N\\}\\},")]]

#text("where ")#mi("{N}")#text(" is the unbounded natural number ")#mi("{N := \\lim_{n \\rightarrow \\alpha} n}")#text(". This is an ultra approximate group, with")

#align(center)[#tao-fit-display[#mitex("\\langle A \\rangle = \\{ a + b N^{10}: a,b \\in {}^* {\\bf Z}; a,b = O(N) \\}.")]]

#text("Then ")#mi("{\\langle A \\rangle}")#text(" can be modeled by the Euclidean plane ")#mi("{{\\bf R}^2}")#text(", using the model maps ")#mi("{\\pi: \\langle A \\rangle \\rightarrow {\\bf R}^2}")#text(" defined for each standard ")#mi("{m}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\pi( a + bN^{10} ) := \\left( \\text{st} \\frac{a}{N}, \\text{st} \\frac{b}{N} \\right)")]]

#text("whenever ")#mi("{a,b = O(N)}")#text(". The image ")#mi("{\\pi(A^m)}")#text(" is then the square ")#mi("{[-m,m]^2}")#text(" for any standard ")#mi("{m}")#text(". Note here that while ")#mi("{A}")#text(" lives in a “one-dimensional” group ")#mi("{{}^* {\\bf Z}}")#text(", the model ")#mi("{{\\bf R}^2}")#text(" is “two-dimensional”. This is also reflected in the volume growth of the powers ")#mi("{A_n^m}")#text(" of ")#mi("{A_n}")#text(" for small ")#mi("{m}")#text(" and large ")#mi("{n}")#text(", which grow quadratically rather than linearly in ")#mi("{m}")#text(". Informally, ")#mi("{A}")#text(" is “modeled” by the unit square in ")#mi("{{\\bf R}^2}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" With the notation of Example ")#link(<tao-54d5dbf0124e59afba31>)[#text("3")]#text(", show that ")#mi("{A}")#text(" cannot be modeled by the one-dimensional Lie group ")#mi("{{\\bf R}}")#text(". (")#emph[#text("Hint:")]#text(" If ")#mi("{A}")#text(" was modeled by ")#mi("{{\\bf R}}")#text(", conclude that ")#mi("{A^m}")#text(" could be covered by ")#mi("{O(m)}")#text(" translates of ")#mi("{A}")#text(" for each standard ")#mi("{m}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27 (Heisenberg box, I)")]#text(" ")#metadata(none) <tao-ce371d3c6bedcfcabbfe>#text(" We take each ")#mi("{A_n}")#text(" to be the “nilbox”")

#align(center)[#tao-fit-display[#tao-math("A_n := \\left\\{ \\left(\\begin{smallmatrix} 1 & x_{n} & z_{n} \\\\ 0 & 1 & y_{n} \\\\ 0 & 0 & 1\\end{smallmatrix}\\right) \\in \\left(\\begin{smallmatrix} 1 & {\\bf Z} & {\\bf Z} \\\\ 0 & 1 & {\\bf Z} \\\\ 0 & 0 & 1\\end{smallmatrix}\\right) : \\left|x_{n}\\right|, \\left|y_{n}\\right| \\leq {n}, \\left|z_{n}\\right| \\leq n^{2}\\right\\}.", block: true)]]

#text("Consider the ultraproduct ")#mi("{A := \\prod_{n \\rightarrow \\alpha} A_n}")#text("; this is a subset of the nilpotent (nonstandard) group ")#mi("{\\left(\\begin{smallmatrix} 1 & {}^* {\\bf Z} & {}^* {\\bf Z} \\\\ 0 & 1 & {}^* {\\bf Z} \\\\ 0 & 0 & 1\\end{smallmatrix}\\right)}")#text(", consisting of all elements ")#mi("{\\left(\\begin{smallmatrix} 1 & x & z \\\\ 0 & 1 & y \\\\ 0 & 0 & 1\\end{smallmatrix}\\right)}")#text(" with ")#tao-math("{\\left|x\\right|, \\left|y\\right| \\leq N}", block: false)#text(" and ")#tao-math("{\\left|z\\right| \\leq N^2}", block: false)#text(", where ")#mi("{N := \\lim_{n \\rightarrow \\alpha} n}")#text(". Thus")

#align(center)[#tao-fit-display[#mitex("\\langle A \\rangle = \\left(\\begin{smallmatrix} 1 & O(N) & O(N^2) \\\\ 0 & 1 & O(N) \\\\ 0 & 0 & 1\\end{smallmatrix}\\right).")]]

#text("Consider now the map")

#align(center)[#tao-fit-display[#mitex("\\pi : \\langle A\\rangle \\rightarrow \\left(\\begin{smallmatrix} 1 & {\\bf R} & {\\bf R} \\\\ 0 & 1 & {\\bf R} \\\\ 0 & 0 & 1\\end{smallmatrix}\\right)")]]

#text("defined by ")#metadata(none) <tao-a56ddc3cd2a8a1f526c5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\pi\\left( \\left(\\begin{smallmatrix} 1 & x & z \\\\ 0 & 1 & y \\\\ 0 & 0 & 1\\end{smallmatrix}\\right)\\right) := \\left(\\begin{smallmatrix} 1 & \\text{st} \\frac{x}{N} & \\text{st} \\frac{z}{N^2} \\\\ 0 & 1 & \\text{st} \\frac{y}{N} \\\\ 0 & 0 & 1\\end{smallmatrix}\\right).")]]

#list(
[#text("(i) Show that ")#mi("{A \\cup A^{-1}}")#text(" is an ultra approximate group.")],
[#text("(ii) Show that ")#mi("{\\pi}")#text(" is a good model of ")#mi("{A \\cup A^{-1}}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28 (Heisenberg box, II)")]#text(" ")#metadata(none) <tao-1d31823c188596b1859c>#text(" This is a variant of the preceding exercise, in which the ")#mi("{A_n}")#text(" is now defined as ")#metadata(none) <tao-a26e2114ec561740ed56>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("A_n := \\left\\{ \\left(\\begin{smallmatrix} 1 & x_{n} & z_{n} \\\\ 0 & 1 & y_{n} \\\\ 0 & 0 & 1\\end{smallmatrix}\\right) : \\left|x_n\\right|, \\left|y_n\\right| \\leq n, \\left|z_{n}\\right| \\leq n^{10}\\right\\}", block: true)]]

#text("so that the ultralimit ")#mi("{A := \\prod_{n \\rightarrow \\alpha} A_n}")#text(" takes the form")

#align(center)[#tao-fit-display[#tao-math("A := \\left\\{ \\left(\\begin{smallmatrix} 1 & x & z \\\\ 0 & 1 & y \\\\ 0 & 0 & 1\\end{smallmatrix}\\right) \\in \\left(\\begin{smallmatrix} 1 & {}^* {\\bf Z} & {}^* {\\bf Z} \\\\ 0 & 1 & {}^* {\\bf Z} \\\\ 0 & 0 & 1\\end{smallmatrix}\\right): \\left|x\\right|, \\left|y\\right| \\leq N, \\left|z\\right| \\leq N^{10}\\right\\}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\langle A\\rangle := \\left(\\begin{smallmatrix} 1 & O(N) & O(N^{10}) \\\\ 0 & 1 & O(N) \\\\ 0 & 0 & 1\\end{smallmatrix}\\right),")]]

#text("where ")#mi("{N := \\lim_{n \\rightarrow \\alpha} n}")#text(". Now consider the map")

#align(center)[#tao-fit-display[#mitex("\\pi : \\langle A\\rangle ^8 \\rightarrow {\\bf R}^3")]]

#text("defined by")

#align(center)[#tao-fit-display[#mitex("\\pi\\left( \\left(\\begin{smallmatrix} 1 & x & z \\\\ 0 & 1 & y \\\\ 0 & 0 & 1\\end{smallmatrix}\\right) \\right)= \\left(\\text{st} \\frac{x}{N}, \\text{st} \\frac{y}{N}, \\text{st} \\frac{z}{N^{10}}\\right).")]]

#list(
[#text("(i) Show that ")#mi("{A \\cup A^{-1}}")#text(" is an ultra approximate group.")],
[#text("(ii) Show that ")#mi("{\\pi}")#text(" is a good model of ")#mi("{A \\cup A^{-1}}")#text(".")],
[#text("(iii) Show that ")#mi("{A \\cup A^{-1}}")#text(" cannot be modeled by ")#mi("{{\\bf R}^2}")#text(", or by the Heisenberg group.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 12")]#text(" Note in the above exercise that the homomorphism ")#mi("{\\pi: A^8 \\rightarrow {\\bf R}^3}")#text(" is not associated to any exact homomorphisms ")#mi("{\\pi_n}")#text(" from ")#mi("{A_n^8}")#text(" to ")#mi("{{\\bf R}^3}")#text(". Instead, it is only associated to ")#emph[#text("approximate")]#text(" homomorphisms")

#align(center)[#tao-fit-display[#mitex("\\pi_n\\left( \\left(\\begin{smallmatrix} 1 & x_n & z_n \\\\ 0 & 1 & y_n \\\\ 0 & 0 & 1\\end{smallmatrix}\\right) \\right) := \\left(\\frac{x_n}{n}, \\frac{y_n}{n}, \\frac{z_n}{n^{10}}\\right)")]]

#text("into ")#mi("{{\\bf R}^3}")#text(". Such approximate homomorphisms are somewhat less pleasant to work with than genuine homomorphisms; one of the main reasons why we work in the ultraproduct setting is so that we can use genuine group homomorphisms.")

#text("We also note the sets ")#mi("{A_n^m}")#text(" for small ")#mi("{m}")#text(" and large ")#mi("{n}")#text(" grow cubically in ")#mi("{m}")#text(" in Exercise ")#link(<tao-ce371d3c6bedcfcabbfe>)[#text("27")]#text(", and quartically in ")#mi("{m}")#text(" in Exercise ")#link(<tao-1d31823c188596b1859c>)[#text("28")]#text(". This reflects the corresponding growth rates in ")#mi("{{\\bf R}^3}")#text(" and in the Heisenberg group respectively.")

#text("Finally, we observe that the nonabelian structure of the ultra approximate group ")#mi("{A}")#text(" is lost in the model group ")#mi("{L}")#text(", because the nonabelianness is “infinitesimal” at the scale of ")#mi("{A}")#text(". More generally, good models can capture the “macroscopic” structure of ")#mi("{A}")#text(", but do not directly see the “microscopic” structure.")
]

#text("The following exercise demonstrates that model groups need not be simply connected.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29 (Models of Bohr sets)")]#text(" Let ")#mi("{\\alpha}")#text(" be a standard irrational, let ")#mi("{0 < \\epsilon < 0.1}")#text(" be a standard real number, and let ")#mi("{A_n \\subset {\\bf Z}}")#text(" be the sets")

#align(center)[#tao-fit-display[#tao-math("A_n := \\{ m \\in [-n,n]: \\left\\| \\alpha m \\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\epsilon \\}", block: true)]]

#text("where ")#tao-math("{\\left\\|x\\right\\|}", block: false)#text(" denotes the distance to the nearest integer. Set ")#mi("{A := \\prod_{n \\rightarrow \\alpha} A_n}")#text(".")

#list(
[#text("(i) Show that ")#mi("{A}")#text(" is an ultra approximate group.")],
[#text("(ii) Show that ")#mi("{{\\bf R}/{\\bf Z} \\times {\\bf R}}")#text(" is a good model for ")#mi("{A}")#text(".")],
[#text("(iii) Show that ")#mi("{{\\bf R}^2}")#text(" is not a good model for ")#mi("{A}")#text(". (")#emph[#text("Hint:")]#text(" consider the growth of ")#mi("{A^m}")#text(", as measured by the number of translates of ")#mi("{A}")#text(" needed to cover this set.)")],
[#text("(iv) Show that ")#mi("{{\\bf R}}")#text(" is not a good model for ")#mi("{A}")#text(". (")#emph[#text("Hint:")]#text(" consider the decay of the sets ")#mi("{\\{ g: g,g^2,\\ldots,g^m \\in A \\}}")#text(", as measured by the number of translates of this set needed to cover ")#mi("{A}")#text(".)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30 (Haar measure)")]#text(" ")#metadata(none) <tao-c33635072f01e4f83600>#text(" Let ")#mi("{\\pi: \\langle A \\rangle \\rightarrow L}")#text(" be a good model for an ultra approximate group ")#mi("{A = \\prod_{n \\rightarrow \\alpha} A_n}")#text(" by a locally compact group ")#mi("{L}")#text(". For any continuous compactly supported function ")#mi("{f: L \\rightarrow {\\bf R}}")#text(", we can define a functional ")#mi("{I(f)}")#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("I(f) = \\inf \\text{st} \\frac{\\sum_{a \\in A} F^+(a)}{\\left|A\\right|}", block: true)]]

#text("where ")#mi("{F^+ = \\lim_{n \\rightarrow \\alpha} F^+_n}")#text(" is the ultralimit of functions ")#mi("{F^+_n: A_n \\rightarrow {\\bf R}}")#text(", with the nonstandard real ")#mi("{\\sum_{a \\in A} F^+}")#text(" and nonstandard natural number ")#tao-math("{\\left|A\\right|}", block: false)#text(" defined in the usual fashion as")

#align(center)[#tao-fit-display[#mitex("\\sum_{a \\in A} F^+(a) := \\lim_{n \\rightarrow \\alpha} \\sum_{a_n \\in A_n} F^+_n(a_n)")]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|A\\right| := \\lim_{n \\rightarrow \\alpha} \\left|A_n\\right|,", block: true)]]

#text("and the infimum is over all ")#mi("{F^+}")#text(" for which ")#mi("{F^+(a) \\geq f(\\pi(a))}")#text(" for all ")#mi("{a \\in A}")#text(".")

#list(
[#text("(i) Establish the equivalent formula")

#align(center)[#tao-fit-display[#mitex("I(f) = \\sup \\text{st} \\frac{\\sum_{a \\in A} F^-(a)}{\\sum_{a \\in A} 1}")]]

#text("where the supremum is over all ")#mi("{F^-}")#text(" for which ")#mi("{F^-(a) \\leq f(\\pi(a))}")#text(" for all ")#mi("{a \\in A}")#text(".")],
[#text("(ii) Show that there exists a bi-invariant Haar measure ")#mi("{\\mu}")#text(" on ")#mi("{G}")#text(" such that ")#mi("{I(f) = \\int_G f\\ d\\mu}")#text(" for all continuous compactly supported ")#mi("{f: L \\rightarrow {\\bf R}}")#text(". (In particular, this shows that ")#mi("{L}")#text(" is necessarily unimodular.)")],
[#text("(iii) Show that")

#align(center)[#tao-fit-display[#tao-math("\\mu(F) \\left|A\\right| \\leq \\left|A^{\\prime}\\right| \\leq \\mu(U) \\left|A\\right|", block: true)]]

#text("whenever ")#mi("{F \\subseteq U \\subseteq U_1}")#text(", ")#mi("{F}")#text(" is compact, ")#mi("{U}")#text(" is open, and ")#mi("{A^{\\prime}}")#text(" is a nonstandard set with")

#align(center)[#tao-fit-display[#mitex("\\pi^{-1}(F) \\subset A^{\\prime} \\subseteq \\pi^{-1}(U).")]]]
)
]

#heading(level: 1)[#strong[#text(" — 4. Lie models of ultra approximate groups — ")]]

#text("In the examples of good models in the previous section, the model group ")#mi("{L}")#text(" was a Lie group. We give now give some examples to show that the model need not ")#emph[#text("initially")]#text(" be of Lie type, but can then be replaced with a Lie model after some modification.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4 (Nonstandard cyclic group, revisited)")]#text(" Consider the nonstandard cyclic group ")#mi("{A := {\\bf Z}/2^N{\\bf Z} = \\prod_{n \\rightarrow \\alpha} {\\bf Z}/2^n {\\bf Z}}")#text(". This is a nonstandard finite group and can thus be modeled by the trivial group ")#mi("{\\{1\\}}")#text(" as discussed in Example ")#link(<tao-d85db0a54febab6113cc>)[#text("2")]#text(". However, it can also be modeled by the compact abelian group ")#mi("{{\\bf Z}_2}")#text(" of ")#mi("{2}")#text("-adic integers using the model ")#mi("{\\pi: A \\rightarrow {\\bf Z}_2}")#text(" defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\pi(a) := \\lim_{n \\rightarrow \\infty} a \\text{ mod } {2^n}")]]

#text("where for each standard natural number ")#mi("{n}")#text(", ")#mi("{a \\text{ mod } 2^n \\in \\{0,\\ldots,2^{n-1}\\}}")#text(" is the remainder of ")#mi("{a}")#text(" modulo ")#mi("{2^n}")#text(" (this is well-defined in ")#mi("{A}")#text(") and the limit is in the ")#mi("{2}")#text("-adic metric. Note that the image ")#mi("{\\pi(A)}")#text(" of ")#mi("{A}")#text(" is the entire group ")#mi("{{\\bf Z}_2}")#text(", and conversely the preimage of ")#mi("{{\\bf Z}_2}")#text(" in ")#mi("{A^8 = A}")#text(" is trivially all of ")#mi("{{\\bf Z}/2^N{\\bf Z}}")#text("; as such, one can quotient out ")#mi("{{\\bf Z}_2}")#text(" in this model and recover the trivial model of ")#mi("{A}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 5 (Nonstandard abelian ")#mi("{2}")#text("-torsion group)")]#text(" ")#metadata(none) <tao-c6ff1ab20aafa4cb908b>#text(" In a similar spirit to the preceding example, the nonstandard ")#mi("{2}")#text("-torsion group ")#mi("{A := ({\\bf Z}/2{\\bf Z})^N = \\prod_{n \\rightarrow \\alpha} ({\\bf Z}/2{\\bf Z})^n}")#text(" can be modeled by the compact abelian group ")#mi("{({\\bf Z}/2{\\bf Z})^{\\bf N}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\pi(a) := \\lim_{n \\rightarrow \\infty} \\pi_n(a)")]]

#text("where ")#mi("{\\pi_n: A \\rightarrow ({\\bf Z}/2{\\bf Z})^n}")#text(" is the obvious projection, and the limit is in the product topology of ")#mi("{({\\bf Z}/2{\\bf Z})^{\\bf N}}")#text(". As before, we can quotient out ")#mi("{({\\bf Z}/2{\\bf Z})^{\\bf N}}")#text(" and model ")#mi("{A}")#text(" instead by the trivial group.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 13")]#text(" ")#metadata(none) <tao-89270a50341bb8e83734>#text(" The above two examples can be generalised to model any nonstandard finite group ")#mi("{G = \\prod_{n \\rightarrow \\alpha} G_n}")#text(" equipped with surjective homomorphisms from ")#mi("{G_{n+1}}")#text(" to ")#mi("{G_n}")#text(" by the inverse limit of the ")#mi("{G_n}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31 (Lamplighter group)")]#text(" Let ")#mi("{F_2}")#text(" be the field of two elements. ")#mi("{G}")#text(" be the ")#link("http://en.wikipedia.org/wiki/Lamplighter_group")[#text("lamplighter group")]#text(" ")#mi("{{\\bf Z} \\ltimes F_2^{\\bf Z}}")#text(", where ")#mi("{{\\bf Z}}")#text(" acts on ")#mi("{F_2^{\\bf Z}}")#text(" by the shift ")#mi("{T: F_2^{\\bf Z}}")#text(" defined by ")#mi("{T(a_k)_{k \\in {\\bf Z}} := (a_{k-1})_{k \\in {\\bf Z}}}")#text(". Thus the group law in ")#mi("{G}")#text(" is given by")

#align(center)[#tao-fit-display[#mitex("(i,x) (j,y) := (i+j, x+T^i y).")]]

#text("For each ")#mi("{n}")#text(", we then set ")#mi("{A_n \\subseteq G}")#text(" to be the set")

#align(center)[#tao-fit-display[#mitex("A_n := \\{ (i,x) \\in G: i \\in \\{-1,0,+1\\}; x \\in F_2^n \\},")]]

#text("where we identify ")#mi("{F_2^n}")#text(" with the space of elements ")#mi("{(a_k)_{k \\in {\\bf Z}}}")#text(" of ")#mi("{F_2^{\\bf Z}}")#text(" such that ")#mi("{a_k \\neq 0}")#text(" only for ")#mi("{k \\in \\{1,\\ldots,n\\}}")#text(". Let ")#mi("{F_2((t))}")#text(" be the ring of ")#link("http://en.wikipedia.org/wiki/Formal_Laurent_series#Formal_Laurent_series")[#text("formal Laurent series")]#text(" ")#mi("{\\sum_{k \\in {\\bf Z}} a_k t^k}")#text(" in which all but finitely many of the ")#mi("{a_k}")#text(" for negative ")#mi("{k}")#text(" are zero. We let ")#mi("{G_0}")#text(" be the modified lamplighter group ")#mi("{{\\bf Z} \\ltimes F_2((t))}")#text(", where ")#mi("{{\\bf Z}}")#text(" acts on ")#mi("{F_2^{\\bf Z}}")#text(" by the shift ")#mi("{T: f \\mapsto tf}")#text(". We give ")#mi("{F_2((t))}")#text(" a topology by assigning each non-zero Laurent series ")#mi("{\\sum_{k \\in {\\bf Z}} a_k t^k}")#text(" a norm of ")#mi("{2^{-k}}")#text(", where ")#mi("{k}")#text(" is the least integer for which ")#mi("{a_k \\neq 0}")#text("; this induces a topology on ")#mi("{G_0}")#text(" via the product topology construction.")

#text("We will model the ultraproduct ")#mi("{A := \\prod_{n \\rightarrow \\alpha} A_n \\subset {\\bf Z} \\ltimes {}^* ({\\bf Z}/2{\\bf Z})^{\\bf Z}}")#text(" (or more precisely, the set ")#mi("{A \\cup A^{-1}}")#text(", since ")#mi("{A}")#text(" is not quite symmetric) by the group")

#align(center)[#tao-fit-display[#mitex("G_0 \\times_{\\bf Z} G_0 := \\{ ((i,x),(j,y)) \\in G_0 \\times G_0: i = j \\}")]]

#text("using the map")

#align(center)[#tao-fit-display[#mitex("\\pi( (i, \\lim_{n \\rightarrow \\alpha} (a^{(n)}_k)_{k \\in {\\bf Z}} ) )")]]

#align(center)[#tao-fit-display[#mitex(":= ( (i, \\sum_{k \\in {\\bf Z}} \\lim_{n \\rightarrow \\alpha} a^{(n)}_k t^k ), (i, \\sum_{k \\in {\\bf Z}} \\lim_{n \\rightarrow \\alpha} a^{(n)}_{n-k} t^k ) ).")]]

#text("Roughly speaking, ")#mi("{\\pi(a)}")#text(" captures the behaviour of ")#mi("{a}")#text(" at the two “ends” of ")#mi("{F_2^N}")#text(", where ")#mi("{N := \\lim_{n \\rightarrow \\alpha} n}")#text(". We give ")#mi("{G_0 \\times_{\\bf Z} G_0}")#text(" the topology induced from the product topology on ")#mi("{G_0 \\times G_0}")#text(".")

#list(
[#text("(i) Show that ")#mi("{A \\cup A^{-1}}")#text(" is an ultra approximate group.")],
[#text("(ii) Show that ")#mi("{\\pi}")#text(" is a good model of ")#mi("{A \\cup A^{-1}}")#text(".")],
[#text("(iii) Show that ")#mi("{\\pi}")#text(" is no longer a good model if one projects ")#mi("{G_0 \\times_{\\bf Z} G_0}")#text(" to the first or second copy of ")#mi("{G_0}")#text(", or to the base group ")#mi("{{\\bf Z}}")#text(".")],
[#text("(iv) Show that ")#mi("{A \\cup A^{-1}}")#text(" does not have a good model by a Lie group ")#mi("{L}")#text(". (")#emph[#text("Hint:")]#text(" ")#mi("{L}")#text(" does not contain arbitrarily small elements of order two, other than the identity.)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 14")]#text(" In the above exercise, one needs a moderately complicated (though still locally compact) group ")#mi("{G \\times_{\\bf Z} G}")#text(" to properly model ")#mi("{A}")#text(" and its powers ")#mi("{A^m}")#text(". This can also be seen from volume growth considerations: ")#mi("{A_n^m}")#text(" grows like ")#mi("{4^m}")#text(" for fixed (large ")#mi("{n}")#text("), which is also the rate of volume growth of ")#mi("{\\pi(A)}")#text(" in ")#mi("{G \\times_{\\bf Z} G}")#text(", whereas the volume growth in a single factor ")#mi("{G}")#text(" would only grow like ")#mi("{2^m}")#text(", and the volume growth in ")#mi("{{\\bf Z}}")#text(" is only linear in ")#mi("{m}")#text(". However, if we pass to the large subset ")#mi("{A^{\\prime}}")#text(" of ")#mi("{A}")#text(" defined by ")#mi("{A^{\\prime} := \\prod_{n \\rightarrow\\alpha} A^{\\prime}_n}")#text(", where")

#align(center)[#tao-fit-display[#mitex("A^{\\prime}_n := \\{ (i,x) \\in G: i = 0; x \\in ({\\bf Z}/2{\\bf Z})^n \\}")]]

#text("then ")#mi("{A^{\\prime}}")#text(" is now a nonstandard finite group (isomorphic to the group ")#mi("{({\\bf Z}/2{\\bf Z})^N}")#text(" considered in Example ")#link(<tao-c6ff1ab20aafa4cb908b>)[#text("5")]#text(") and can be modeled simply by the trivial group ")#mi("{\\{1\\}}")#text(". Thus we see that we can sometimes greatly simplify the modeling of an ultra approximate group by passing to a large ultra approximate subgroup.")
]

#text("By using the Gleason-Yamabe theorem, one can formalise these examples. Given two ultra approximate groups ")#mi("{A^{\\prime}}")#text(", we say that ")#mi("{A^{\\prime}}")#text(" is an ")#emph[#text("large ultra approximate subgroup")]#text(" of ")#mi("{A}")#text(" if ")#mi("{(A^{\\prime})^4 \\subset A^4}")#text(" and ")#mi("{A}")#text(" can be covered by finitely many left-translates of ")#mi("{A^{\\prime}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 12 (Hrushovski’s Lie model theorem)")]#text(" ")#metadata(none) <tao-de35fa06661843844fde>#text(" Let ")#mi("{A}")#text(" be an ultra approximate group. Then there exists a large ultra approximate subgroup ")#mi("{A^{\\prime}}")#text(" of ")#mi("{A}")#text(" that can be modeled by a connected Lie group ")#mi("{L}")#text(".")
]

#emph[#text("Proof:")]#text(" By Exercise ")#link(<tao-eda6f634f26637a07eb0>)[#text("24")]#text(", we have a good model ")#mi("{\\pi_0: \\langle A \\rangle \\rightarrow L_0}")#text(" of ")#mi("{A^4}")#text(" by some locally compact group ")#mi("{L_0}")#text(". In particular, there is an open neighbourhood ")#mi("{U_0}")#text(" of the identity in ")#mi("{L_0}")#text(" such that ")#mi("{\\pi_0^{-1}(U_0) \\subset A^4}")#text(" and ")#mi("{U_0 \\subset \\pi_0(A^4)}")#text(".")

#text("Let ")#mi("{U_1}")#text(" be a symmetric precompact neighbourhood of the identity such that ")#mi("{U_1^{100} \\subset U_0}")#text(". By the Gleason-Yamabe theorem (Theorem 1 of ")#link("https://terrytao.wordpress.com/2011/10/08/254a-notes-5-the-structure-of-locally-compact-groups-and-hilberts-fifth-problem/")[#text("Notes 5")]#text("), there is an open subgroup ")#mi("{L^{\\prime}_0}")#text(" of ")#mi("{L_0}")#text(", and a compact normal subgroup ")#mi("{N}")#text(" of ")#mi("{L^{\\prime}_0}")#text(" contained in ")#mi("{U_1}")#text(", such that ")#mi("{L^{\\prime}_0/N}")#text(" is isomorphic to a connected Lie group ")#mi("{L}")#text(". Let ")#mi("{\\pi_1: L^{\\prime}_0 \\rightarrow L}")#text(" be the quotient map.")

#text("Write ")#mi("{U_2 := U_1 \\cap L^{\\prime}_0}")#text(". As ")#mi("{\\pi_0}")#text(" is a good model, we can find a nonstandard finite set ")#mi("{A^{\\prime}}")#text(" with")

#align(center)[#tao-fit-display[#mitex("\\pi^{-1}(U_2) \\subset A^{\\prime} \\subset \\pi^{-1}(U_2^2).")]]

#text("By replacing ")#mi("{A^{\\prime}}")#text(" with ")#mi("{A^{\\prime} \\cap (A^{\\prime})^{-1}}")#text(" if necessary, we may take ")#mi("{A^{\\prime}}")#text(" to be symmetric. As ")#mi("{U_2^4}")#text(" can be covered by finitely many left-translates of ")#mi("{U_2}")#text(", we see that ")#mi("{A^{\\prime}}")#text(" is an ultra approximate group. Since")

#align(center)[#tao-fit-display[#mitex("(A^{\\prime})^4 \\subset \\pi^{-1}(U_2^8) \\subset \\pi^{-1}(U_1^{100}) \\subset \\pi^{-1}(U_0) \\subset A^4")]]

#text("and ")#mi("{\\pi(A^4)}")#text(" can be covered by finitely many left-translates of ")#mi("{U_2}")#text(", we see that ")#mi("{A^{\\prime}}")#text(" is a large ultra approximate subgroup of ")#mi("{A}")#text(". It is then a routine matter to verify that ")#mi("{\\pi_1 \\circ \\pi_0: \\langle A^{\\prime} \\rangle \\rightarrow L}")#text(" is a good model for ")#mi("{A^{\\prime}}")#text(". ")#mi("\\Box")

#text("The Lie model ")#mi("{L}")#text(" need not be unique. For instance, the nonstandard cyclic group ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(" can be modeled both by the trivial group and by the unit circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(". However, as ")#link("http://arxiv.org/abs/0909.2190")[#text("observed by Hrushovski")]#text(", it can be shown that after quotienting out the (unique) maximal compact normal subgroup from the Lie model ")#mi("{L}")#text(", the resulting quotient group (which is also a Lie group, and in some sense describes the “large scale” structure of ")#mi("{L}")#text(") is unique up to isomorphism. The following exercise fleshes out the details of this observation.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32 (Large-scale uniqueness of the Lie model)")]#text(" Let ")#mi("{L, L^{\\prime}}")#text(" be connected Lie groups, and let ")#mi("{A}")#text(" be an ultra approximate group with good models ")#mi("{\\pi: \\langle A \\rangle \\rightarrow L}")#text(" and ")#mi("{\\pi^{\\prime}: \\langle A^{\\prime} \\rangle \\rightarrow L^{\\prime}}")#text(".")

#list(
[#text("(i) Show that the centre ")#mi("{Z(L) := \\{ g \\in L: gh=hg \\text{ for all } h \\in L \\}}")#text(" is an abelian Lie group.")],
[#text("(ii) Show that the connected component ")#mi("{Z(L)^0}")#text(" of the identity in ")#mi("{Z(L)}")#text(" is isomorphic to ")#mi("{{\\bf R}^d \\times ({\\bf R}/{\\bf Z})^{d^{\\prime}}}")#text(" for some ")#mi("{d,d^{\\prime} \\geq 0}")#text(".")],
[#text("(iii) Show that the quotient group ")#mi("{Z(L)/Z(L)^0}")#text(" is a finitely generated abelian group, and is isomorphic to ")#mi("{{\\bf Z}^{d^{\\prime\\prime}} \\times H}")#text(" for some finite group ")#mi("{H}")#text(".")],
[#text("(iv) Show that the torsion points of ")#mi("{Z(L)}")#text(" are contained in a compact subgroup of ")#mi("{Z(L)}")#text(" isomorphic to ")#mi("{({\\bf R}/{\\bf Z})^{d^{\\prime}} \\times H}")#text(".")],
[#text("(v) Show that any finite normal subgroup of ")#mi("{L}")#text(" is central, and thus lies in the compact subgroup indicated above. (")#emph[#text("Hint:")]#text(" ")#mi("{L}")#text(" will act continuously by conjugation on this finite normal subgroup.)")],
[#text("(vi) Show that given any increasing sequence ")#mi("{N_1 \\subset N_2 \\subset \\ldots}")#text(" of compact normal subgroups of ")#mi("{L}")#text(", the upper bound ")#mi("{\\overline{\\bigcup_n N_n}}")#text(" is also a compact normal subgroup of ")#mi("{L}")#text(". (")#emph[#text("Hint:")]#text(" The dimensions of ")#mi("{N_n}")#text(" (which are well-defined by Cartan’s theorem) are monotone increasing but bounded by the dimension of ")#mi("{L}")#text(". In particular, the connected components ")#mi("{N_n^0}")#text(" must eventually stabilise. Quotient them out and then use (v).)")],
[#text("(vii) Show that ")#mi("{L}")#text(" contains a unique maximal compact normal subgroup ")#mi("{N}")#text(". Similarly, ")#mi("{L^{\\prime}}")#text(" contains a unique maximal compact normal subgroup ")#mi("{N^{\\prime}}")#text(". Show that the quotient groups ")#mi("{L/N, L^{\\prime}/N^{\\prime}}")#text(" contain no non-trivial compact normal subgroups.")],
[#text("(viii) Show that ")#mi("{\\pi^{-1}(N) = (\\pi^{\\prime})^{-1}(N^{\\prime})}")#text(". (")#emph[#text("Hint:")]#text(" if ")#mi("{g \\in L}")#text(", then ")#mi("{g \\in N}")#text(" iff the group generated by ")#mi("{g}")#text(" and its conjugates is bounded.)")],
[#text("(ix) Show that ")#mi("{L/N}")#text(" is isomorphic to ")#mi("{L^{\\prime}/N^{\\prime}}")#text(".")],
[#text("(x) Show that for sufficiently large standard ")#mi("{m}")#text(", ")#mi("{A^m}")#text(" can be modeled by a Lie group with no non-trivial compact normal subgroups, which is unique up to isomorphism.")]
)
]

#text("To illustrate how this theorem is useful, let us apply it in the bounded torsion case.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" Let ")#mi("{A}")#text(" be an ultra approximate group in an ")#mi("{r}")#text("-torsion nonstandard group ")#mi("{G}")#text(" for some standard ")#mi("{r \\geq 1}")#text(". Show that ")#mi("{A^4}")#text(" contains a nonstandard finite group ")#mi("{H}")#text(" such that ")#mi("{A}")#text(" can be covered by finitely many left translates of ")#mi("{H}")#text(". (")#emph[#text("Hint:")]#text(" if a Lie group has positive dimension, then it contains elements arbitrarily close to the identity of arbitrarily large order.)")
]

#text("Combining this exercise with Proposition 11 from ")#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/")[#text("Notes 6")]#text(", we conclude a finitary consequence, first observed by Hrushovski:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 13 (Freiman theorem, bounded torsion case)")]#text(" Let ")#mi("{r, K \\geq 1}")#text(", and let ")#mi("{A}")#text(" be a finite ")#mi("{K}")#text("-approximate subgroup of an ")#mi("{r}")#text("-torsion group ")#mi("{G}")#text(". Then ")#mi("{A^4}")#text(" contains a finite subgroup ")#mi("{H}")#text(" such that ")#mi("{A}")#text(" can be covered by ")#mi("{O_{K,r}(1)}")#text(" left translates of ")#mi("{H}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34 (Commutator self-containment)")]#text(" ")#metadata(none) <tao-44438343c52ee70594e7>

#list(
[#text("Show that if ")#mi("{A}")#text(" is an ultra approximate group, then there exists a large approximate subgroup ")#mi("{B}")#text(" of ")#mi("{A}")#text(" such that ")#mi("{[B,B] \\subset B}")#text(", where we write ")#mi("{[A,B] := \\{ [a,b]: a \\in A, b \\in B \\}}")#text(", with ")#mi("{[a,b] := a^{-1} b^{-1} ab}")#text(". (Note that this is slightly different from the group-theoretic convention, when ")#mi("{H}")#text(" and ")#mi("{K}")#text(" are subgroups, to define ")#mi("{[H,K]}")#text(" to be the ")#emph[#text("group generated by")]#text(" the commutators ")#mi("{[h,k]}")#text(" with ")#mi("{h \\in H}")#text(" and ")#mi("{k \\in K}")#text(".)")],
[#text("Show that if ")#mi("{A}")#text(" is a finite ")#mi("{K}")#text("-approximate group, then there exists a symmetric set ")#mi("{B}")#text(" containing the origin with ")#mi("{B^4 \\subset A^4}")#text(", ")#tao-math("{\\left|B\\right| \\gg_K \\left|A\\right|}", block: false)#text(", and ")#mi("{[B,B] \\subset B}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 15")]#text(" I do not know of any proof of Exercise ")#link(<tao-44438343c52ee70594e7>)[#text("34")]#text(" that does not go through the Gleason-Yamabe theorem (or some other comparably deep fragment of the theory of Hilbert’s fifth problem).")
]

#text("The following result of Hrushovski is a significant strengthening of the preceding exercise:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35 (Hrushovski’s structure theorem)")]#text(" ")#metadata(none) <tao-e93c085e8bda6c3bd0cc>#text(" Let ")#mi("{A}")#text(" be a finite ")#mi("{K}")#text("-approximate group, and let ")#mi("{F: {\\bf N} \\times {\\bf N} \\rightarrow {\\bf N}}")#text(" be a function. Show that there exist natural numbers ")#mi("{L, M, N}")#text(" with ")#mi("{N \\geq F(L,M)}")#text(" and ")#mi("{L, M \\ll_{K,F} 1}")#text(", and nested sets")

#align(center)[#tao-fit-display[#mitex("\\{1\\} \\subset A_N \\subseteq \\ldots \\subseteq A_1 \\subseteq A^4")]]

#text("with the following properties:")

#list(
[#text("(i) For each ")#mi("{1 \\leq n \\leq N}")#text(", ")#mi("{A_n}")#text(" is symmetric;")],
[#text("(ii) For each ")#mi("{1 \\leq n < N}")#text(", ")#mi("{A_{n+1}^2 \\subseteq A_n}")#text(";")],
[#text("(iii) For each ")#mi("{1 \\leq n \\leq N}")#text(", ")#mi("{A_n}")#text(" is contained in ")#mi("{M}")#text(" left-translates of ")#mi("{A_{n+1}}")#text(";")],
[#text("(iv) For ")#mi("{1 \\leq n,m,k \\leq N}")#text(" with ")#mi("{k < n+m}")#text(", one has ")#mi("{[A_n,A_m] \\subset A_k}")#text(";")],
[#text("(v) ")#mi("{A}")#text(" can be covered by ")#mi("{L}")#text(" left-translates of ")#mi("{A_1}")#text(".")]
)

#text("(")#emph[#text("Hint:")]#text(" first find and prove an analogous statement for ultra approximate groups, in which the function ")#mi("{F}")#text(" is not present.)")
]

#text("There is a finitary formulation of Theorem ")#link(<tao-de35fa06661843844fde>)[#text("12")]#text(", but it takes some effort to state. Let ")#mi("{L}")#text(" be a connected Lie group, with Lie algebra ")#mi("{{\\mathfrak l}}")#text(" which we identify using some coordinate basis with ")#mi("{{\\bf R}^d}")#text(", thus giving a Euclidean norm ")#mi("{\\| \\|}")#text(" on ")#mi("{{\\mathfrak l}}")#text(". We say that ")#mi("{L}")#text(" with this basis has ")#emph[#text("complexity at most ")#mi("{M}")]#text(" for some ")#mi("{M \\geq 1}")#text(" if")

#list(
[#text("The dimension ")#mi("{d}")#text(" of ")#mi("{L}")#text(" is at most ")#mi("{M}")#text(";")],
[#text("The exponential map ")#mi("{\\exp: {\\mathfrak l} \\rightarrow L}")#text(" is injective on the ball ")#tao-math("{\\{ x \\in {\\mathfrak l}: \\left\\|x\\right\\| \\leq 1/M \\}}", block: false)#text(";")],
[#text("One has ")#tao-math("{\\left\\| [x,y] \\right\\| \\leq M \\left\\|x\\right\\| \\left\\|y\\right\\|}", block: false)#text(" for all ")#mi("{x,y \\in {\\mathfrak l}}")#text(".")]
)

#text("We then define “balls” ")#mi("{B_R}")#text(" on ")#mi("{L}")#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("B_R := \\{ \\exp(x): x \\in {\\mathfrak l}; \\left\\|x\\right\\| < R \\}.", block: true)]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36 (Hrushovski’s Lie model theorem, finitary version)")]#text(" ")#metadata(none) <tao-26e8aa1fc5bedf56f987>#text(" Let ")#mi("{F: {\\bf N} \\rightarrow {\\bf N}}")#text(" be a function, and let ")#mi("{A}")#text(" be a finite ")#mi("{K}")#text("-approximate group. Show that there exists a natural number ")#mi("{1 \\leq M \\ll_{K,F} 1}")#text(", a connected Lie group ")#mi("{L}")#text(" of complexity at most ")#mi("{M}")#text(", a symmetric set ")#mi("{A^{\\prime}}")#text(" containing the identity with ")#mi("{(A^{\\prime})^4 \\subset A^4}")#text(", and a map ")#mi("{\\pi: (A^{\\prime})^{F(M)} \\rightarrow L}")#text(" obeying the following properties:")

#list(
[#text("(i) (Large subgroup) ")#mi("{A}")#text(" can be covered by ")#mi("{M}")#text(" left-translates of ")#mi("{A^{\\prime}}")#text(".")],
[#text("(ii) (Approximate homomorphism) One has ")#mi("{\\pi(1)=1}")#text(", and for all ")#mi("{a, b \\in (A^{\\prime})^{F(M)}}")#text(" with ")#mi("{ab \\in (A^{\\prime})^{F(M)}}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\pi(ab) \\pi(b)^{-1} \\pi(a)^{-1} \\in B_{1/F(M)}.")]]],
[#text("(iii) (Thick image) If ")#mi("{a \\in (A^{\\prime})^{F(M)}}")#text(" and ")#mi("{\\pi(a) \\in B_{1/M}}")#text(", then ")#mi("{a \\in A^{\\prime}}")#text(". Conversely, if ")#mi("{g \\in B_{1/M}}")#text(", then ")#mi("{\\pi(A^{\\prime})}")#text(" intersects ")#mi("{g B_{1/F(M)}}")#text(".")],
[#text("(iv) (Compact image) One has ")#mi("{\\pi(A^{\\prime}) \\subset B_M^M}")#text(".")]
)

#text("(")#emph[#text("Hint:")]#text(" One needs to argue by compactness and contradiction, ")#emph[#text("carefully")]#text(" negating all the quantifiers in the above claim, and then use Theorem ")#link(<tao-de35fa06661843844fde>)[#text("12")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37")]#text(" In the converse direction, show that Theorem ")#link(<tao-de35fa06661843844fde>)[#text("12")]#text(" can be deduced from Exercise ")#link(<tao-26e8aa1fc5bedf56f987>)[#text("36")]#text(". (")#emph[#text("Hint:")]#text(" to get started, one needs a statement to the effect that if an ultra approximate group ")#mi("{A}")#text(" is unable to be modeled by some Lie group of complexity at most ")#mi("{M}")#text(", then there is also some ")#mi("{\\epsilon>0}")#text(" for which ")#mi("{A}")#text(" cannot be “approximately modeled up to error ")#mi("{\\epsilon}")#text("” in some sense by such a Lie group. Once one has such a statement (provable via a compactness or ultralimit argument), one can use this ")#mi("{\\epsilon}")#text(" to build a suitable function ")#mi("{F()}")#text(" which which to apply Exercise ")#link(<tao-26e8aa1fc5bedf56f987>)[#text("36")]#text(".")
]]
)

#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b0ff957cc3a07c7bcf007b031948591baa120075111033161781a507e9142ec-01884b2fd037b1ef9035ecf3ccbd17d1ace80fa06252dcb06df35f484605c646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/comment-page-1/#comment-97617")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2011")])]

#text("These are excellent notes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c1f39fda4802b07a12426a497a616a2925f6b74301f71b8be661e831a3db403-2059c209ec074d3a72be41d2e6ca3f4b820a344c32e1c151067d6bcddf93fd5a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/comment-page-1/#comment-98484")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2011")])]

#text("Third paragraph has broken link syntax:")

#link("http://en.wikipedia.org/wiki/Non-standard_analysis#.CE.BA-saturation")[#text("http://en.wikipedia.org/wiki/Non-standard_analysis#.CE.BA-saturation")]#text("{countable saturation}")

#text("Some bounding box errors, but not sure what you can do about them")#linebreak()#text(" Example 1 under remark 10")#linebreak()#text(" Exercise 27")#linebreak()#text(" Exercise 31")

#emph[#text("[(Mostly) corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d600bdb066c7343f948ad11009bb3ea87d327e036f152395ec729017399d19c8-e29f0023d02198bc3f84290d6a3592b5d65a4c2bae4f77342a81aa6c1cb3dc0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Olof Sisask")]], [#link("https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/comment-page-1/#comment-99654")[#strong[#text("Olof Sisask")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2011")])]

#text("Hi Terry,")

#text("About Remark 4, I believe the ")#mi("L^2")#text("-almost-periodicity lemma naturally gives a bound of the form ")#tao-math("\\left|S\\right| \\geq \\exp\\left( -O(m^2 K \\log 2K ) \\right) \\left|A\\right|", block: false)#text(" for the S with ")#mi("S^m \\subset A^4")#text(". (This is Theorem 1.6 in the paper with Ernie.) But as Tom very nicely pointed out in his Bogolyubov paper, if one applies the ")#mi("L^p")#text(" result (with ")#mi("p \\approx \\log K")#text(") to ")#mi("1_A*1_{A^2}")#text(" instead of the ")#mi("L^2")#text(" result to ")#mi("1_A*1_A")#text(", one naturally gets ")#tao-math("\\left|S\\right| \\geq \\exp\\left( -O(m^2 \\log^2 2K ) \\right) \\left|A\\right|", block: false)#text(" (even in the non-abelian setting).")

#text("Thanks for these very interesting posts.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/comment-page-1/#comment-99726")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2011")])]

#text("Thanks for the correction and reference! I did not realise that this portion of Tom’s paper worked in the nonabelian case also.")

#text("It makes me wonder if one can use this trick to similarly improve upon the “normal” version of Tom’s lemma (Lemma 8 in the above notes). The argument given above basically concedes one more exponential on top of what one has for the ordinary version, but perhaps with similar tricks to the above, that can be dealt with.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The microstructure of approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/comment-page-1/#comment-101198")[#strong[#text("254A, Notes 8: The microstructure of approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2011")])]

#text("[…] macroscopic structure of these objects is well described by the Hrushovski Lie model theorem from the previous set of notes, which informally asserts that the macroscopic structure of an (ultra) approximate group can be […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 9: Applications of the structural theory of approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/comment-page-1/#comment-104883")[#strong[#text("254A, Notes 9: Applications of the structural theory of approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2011")])]

#text("[…] but we will give here an alternate argument relying on a version of the Croot-Sisask lemma used in Notes 7 which is a little weaker with regards to quantitative bounds, but is slightly simpler technically […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf2a16ac892896b7a41e959a31e61f969336e91ef81c7e49ebe951465430ca53-b912387543b5839aa6538d6bb07a9d282b99e4e97a257910050b23850afb84aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Hayes")]], [#link("https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/comment-page-1/#comment-104988")[#strong[#text("Ben Hayes")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2011")])]

#text("Should the ")#mi("m")#text(" in the displayed equation on part (iv) of Exercise 23 be a displayed ")#mi("-m?")#text(" Otherwise this part doesn’t seem as helpful.")

#emph[#text("[Oops, corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf2a16ac892896b7a41e959a31e61f969336e91ef81c7e49ebe951465430ca53-b912387543b5839aa6538d6bb07a9d282b99e4e97a257910050b23850afb84aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Hayes")]], [#link("https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/comment-page-1/#comment-105360")[#strong[#text("Ben Hayes")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2011")])]

#text("In Exercise 31 should there be a ")#mi("-n")#text(" somewhere? I think, e.g. you may want ")#mi("A_{n}=\\{(i,x):i\\in \\{-1,0,1\\},x\\in ({\\bf Z}/2{\\bf Z})^{\\{-n,\\cdots,n\\}}")#text(" I’m having difficulty showing that ")#mi("A")#text(" contains the inverse image of an open neighborhood of the identity in ")#mi("G\\times_{\\mathbf{Z}}G.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/comment-page-1/#comment-105410")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2011")])]

#text("Oops, there were several things wrong with that exercise; I’ve had to rewrite it a bit to address the issues you found. Hopefully it is now ok…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f65524e6cc716d96154cbb99deb9f1833073b8e318d710c99e0604aba192739-83bf0cc80ccfbe12ab8fc91422586d7d3df4f576100d249d33e5a51e97dac6fa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/comment-page-1/#comment-110902")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2011")])]

#text("In the proof of the Normal Sanders Lemma, doesn’t application of the Rusza covering lemma give that ")#mi("A")#text(" is covered by ")#mi("O_{K,m}(1)")#text(" left translates of ")#mi("S^2")#text(", not ")#mi("S")#text("? Everything still works if we take ")#mi("S")#text(" such that ")#mi("S^{8m}")#text(" is contained in ")#mi("A^4")#text(" at the start – I just want to check my understanding that the Rusza covering lemma converts statements like ")#tao-math("\\left|S\\right|\\gg_{K,m}\\left|A\\right|", block: false)#text(" to statements about ")#mi("A")#text(" being covered by translates of ")#mi("S^2")#text(" rather than ")#mi("S")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f65524e6cc716d96154cbb99deb9f1833073b8e318d710c99e0604aba192739-83bf0cc80ccfbe12ab8fc91422586d7d3df4f576100d249d33e5a51e97dac6fa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/comment-page-1/#comment-110904")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2011")])]

#text("Some small typos: in Lemma 10 do you want ")#mi("\\delta_1, \\delta_2")#text(" as in the proof?")

#text("Exercise 29 – ")#mi("N")#text(" should be ")#mi("n")#text(" in the definition of ")#mi("A_n")#text(".")

#text("Exercise 31, part (iii) – I think should be project to one of the two factors ")#mi("G_0")#text(", rather than two factors of ")#mi("G_0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/comment-page-1/#comment-110917")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2011")])]

#text("Thanks for the corrections!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0495f8b8e748b3ed656cc09332e75388264b8051b5618821a84f698f129370d8-ad545e83c630e17edbfdf5495e97334a498f57c0478a1c4b2f8bb9de0acbbbdb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lou van den Dries")]], [#link("https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/comment-page-1/#comment-127275")[#strong[#text("Lou van den Dries")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2012")])]

#text("Some typos in the proof of Sanders’ Lemma:")#linebreak()#text(" . Two displays later, (1/m)|A^2| should be")#linebreak()#text(" (1/m)|A’A|, and the right hand sides in the next two displays should be")#linebreak()#text(" (1-(1/m)) |A’A| and (1-(1/m))f(t)|A|. In the subsequent two displays")#linebreak()#text(" the right hand side is missing a factor |A|.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0495f8b8e748b3ed656cc09332e75388264b8051b5618821a84f698f129370d8-ad545e83c630e17edbfdf5495e97334a498f57c0478a1c4b2f8bb9de0acbbbdb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lou van den Dries")]], [#link("https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/comment-page-1/#comment-127276")[#strong[#text("Lou van den Dries")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2012")])]

#text("The “less than” sign in (2) in the proof of Sanders’ lemma should be a")#linebreak()#text(" “greater than” sign, I think.")

#emph[#text("[Corrected, thanks – T.]")]
]
