// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/
// Converted to Typst by tao2typ: "2026-10-14T16:35:13.828088+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Lecture 13: Compact extensions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Lecture 13: Compact extensions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 February 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/")[#text("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("In ")#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/")[#text("Lecture 11")]#text(", we studied ")#emph[#text("compact")]#text(" measure-preserving systems – those systems ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" in which every function ")#mi("f \\in L^2(X, {\\mathcal X}, \\mu)")#text(" was almost periodic, which meant that their orbit ")#mi("\\{ T^n f: n \\in {\\Bbb Z}\\}")#text(" was ")#link("http://en.wikipedia.org/wiki/Precompact")[#text("precompact")]#text(" in the ")#mi("L^2(X, {\\mathcal X}, \\mu)")#text(" topology. Among other things, we were able to easily establish the Furstenberg recurrence theorem (Theorem 1 from ")#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/")[#text("Lecture 11")]#text(") for such systems.")

#text("In this lecture, we generalise these results to a “relative” or “conditional” setting, in which we study systems which are compact relative to some factor ")#mi("(Y, {\\mathcal Y}, \\nu, S)")#text(" of ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(". Such systems are to compact systems as isometric extensions are to isometric systems in topological dynamics. The main result we establish here is that the Furstenberg recurrence theorem holds for such compact extensions whenever the theorem holds for the base. The proof is essentially the same as in the compact case; the main new trick is to not to work in the Hilbert spaces ")#mi("L^2(X,{\\mathcal X},\\mu)")#text(" over the complex numbers, but rather in the ")#link("http://mathworld.wolfram.com/HilbertC-Star-Module.html")[#text("Hilbert module")]#text(" ")#mi("L^2(X,{\\mathcal X},\\mu|Y, {\\mathcal Y}, \\nu)")#text(" over the (commutative) ")#link("http://en.wikipedia.org/wiki/Von_Neumann_algebra")[#text("von Neumann algebra")]#text(" ")#mi("L^\\infty(Y,{\\mathcal Y},\\nu)")#text(". (")#link("http://en.wikipedia.org/wiki/Module_%28mathematics%29")[#text("Modules")]#text(" are to ")#link("http://en.wikipedia.org/wiki/Ring_%28mathematics%29")[#text("rings")]#text(" as ")#link("http://en.wikipedia.org/wiki/Vector_space")[#text("vector spaces")]#text(" are to ")#link("http://en.wikipedia.org/wiki/Field_%28mathematics%29")[#text("fields")]#text(".) Because of the compact nature of the extension, it turns out that results from topological dynamics (and in particular, van der Waerden’s theorem) can be exploited to good effect in this argument.")

#text("[Note: this operator-algebraic approach is not the only way to understand these extensions; one can also proceed by disintegrating ")#mi("\\mu")#text(" into fibre measures ")#mi("\\mu_y")#text(" for almost every ")#mi("y \\in Y")#text(" and working fibre by fibre. We will discuss the connection between the two approaches below.]")

#metadata(none) <tao-7121cd02cdb616913d3b>

#heading(level: 1)[#text("— Hilbert modules —")]

#text("Let ")#mi("X = (X,{\\mathcal X},\\mu,T)")#text(" be a measure-preserving system, and let ")#mi("\\pi: X \\to Y")#text(" be a factor map, i.e. a morphism from X to another system ")#mi("Y = (Y, {\\mathcal Y}, \\nu, S)")#text(". The algebra ")#mi("L^\\infty(Y)")#text(" can be viewed (using ")#mi("\\pi")#text(") as a subalgebra of ")#mi("L^\\infty(X)")#text("; indeed, it is isomorphic to ")#mi("L^\\infty(X, \\pi^{\\#}({\\mathcal Y}), \\mu)")#text(", where ")#mi("\\pi^{\\#}({\\mathcal Y}) := \\{ \\pi^{-1}(E): E \\in {\\mathcal Y} \\}")#text(" is the pullback of ")#mi("{\\mathcal Y}")#text(" by ")#mi("\\pi")#text(".")

#strong[#text("Example 1.")]#text(" Throughout these notes we shall use the ")#emph[#text("skew shift")]#text(" as our running example. Thus, in this example, ")#mi("X = ({\\Bbb R}/{\\Bbb Z})^2")#text(" with shift ")#mi("T: (y,z) \\mapsto (y+\\alpha,z+y)")#text(" for some fixed ")#mi("\\alpha")#text(" (which can be either rational or irrational), ")#mi("Y = {\\Bbb R}/{\\Bbb Z}")#text(" with shift ")#mi("S: y \\mapsto y+\\alpha")#text(", with factor map ")#mi("\\pi: (y,z) \\mapsto y")#text(". In this case, ")#mi("L^\\infty(Y)")#text(" can be thought of (modulo equivalence on null sets, of course) as the space of bounded functions on ")#mi("({\\Bbb R}/{\\Bbb Z})^2")#text(" which depend only on the first variable. ")#mi("\\diamond")

#strong[#text("Example 2. ")]#text("Another (rather trivial) example is when the factor system Y is simply a point. In this case, ")#mi("L^\\infty(Y)")#text(" is the space of constants and can be identified with ")#mi("{\\Bbb C}")#text(". At the opposite extreme, another example is when Y is equal to X. It is instructive to see how all of the concepts behave in each of these two extreme cases, as well as the typical intermediate case presented in Example 1. ")#mi("\\diamond")

#text("The idea here will be to try to “relativise” the machinery of Hilbert spaces over ")#mi("{\\Bbb C}")#text(" to that of Hilbert modules over ")#mi("L^\\infty(Y)")#text(". Roughly speaking, all concepts which used to be complex or real-valued (e.g. inner products, norms, coefficients, etc.) will now take values in the algebra ")#mi("L^\\infty(Y)")#text(". The following table depicts the various concepts that will be relativised:")

#table(columns: 2, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Absolute / unconditional")],
table.cell(colspan: 1, rowspan: 1)[#text("Relative / conditional")],
table.cell(colspan: 1, rowspan: 1)[#text("Constants ")#mi("{\\Bbb C}")],
table.cell(colspan: 1, rowspan: 1)[#text("Factor-measurable functions ")#mi("L^\\infty(Y)")],
table.cell(colspan: 1, rowspan: 1)[#text("Expectation ")#mi("{\\Bbb E} f = \\int_X f\\ d\\mu \\in {\\Bbb C}")],
table.cell(colspan: 1, rowspan: 1)[#text("Conditional expectation ")#mi("{\\Bbb E}(f|Y) \\in L^\\infty(Y)")],
table.cell(colspan: 1, rowspan: 1)[#text("Inner product ")#mi("\\langle f, g \\rangle_{L^2(X)} = {\\Bbb E} f \\overline{g}")],
table.cell(colspan: 1, rowspan: 1)[#text("Conditional inner product ")#mi("\\langle f, g \\rangle_{L^2(X|Y)} = {\\Bbb E}(f \\overline g|Y)")],
table.cell(colspan: 1, rowspan: 1)[#text("Hilbert space ")#mi("L^2(X)")],
table.cell(colspan: 1, rowspan: 1)[#text("Hilbert module ")#mi("L^2(X|Y)")],
table.cell(colspan: 1, rowspan: 1)[#text("Finite-dimensional subspace ")#mi("\\{\\sum_{j=1}^d c_j f_j: c_1,\\ldots,c_d \\in {\\Bbb C}\\}")],
table.cell(colspan: 1, rowspan: 1)[#text("Finitely generated module ")#mi("\\{ \\sum_{j=1}^d c_j f_j: c_1,\\ldots,c_d \\in L^\\infty(Y)\\}")],
table.cell(colspan: 1, rowspan: 1)[#text("Almost periodic function")],
table.cell(colspan: 1, rowspan: 1)[#text("Conditionally almost periodic function")],
table.cell(colspan: 1, rowspan: 1)[#text("Compact system")],
table.cell(colspan: 1, rowspan: 1)[#text("Compact extension")],
table.cell(colspan: 1, rowspan: 1)[#text("Hilbert-Schmidt operator")],
table.cell(colspan: 1, rowspan: 1)[#text("Conditionally Hilbert-Schmidt operator")],
table.cell(colspan: 1, rowspan: 1)[#text("Weakly mixing function")],
table.cell(colspan: 1, rowspan: 1)[#text("Conditionally weakly mixing function")],
table.cell(colspan: 1, rowspan: 1)[#text("Weakly mixing system")],
table.cell(colspan: 1, rowspan: 1)[#text("Weakly mixing extension")]
)

#text("(The last few notions in this table will be covered in the next lecture, rather than this one.)")

#strong[#text("Remark 1.")]#text(" In information-theoretic terms, one can view Y as representing all the observables in the system X that have already been “measured” in some sense, so that it is now permissible to allow one’s “constants” to depend on that data, and only study the remaining information present in X conditioning on the observed values in Y. Note though that once we activate the shift map T, the data in Y will similarly shift (by S), and so the various fibres of ")#mi("\\pi")#text(" can interact with each other in a non-trivial manner, so one should take some caution in applying information-theoretic intuition to this setting. ")#mi("\\diamond")

#text("We have already seen that the factor Y induces a sub-")#mi("\\sigma")#text("-algebra ")#mi("\\pi^{\\#}({\\mathcal Y})")#text(" of ")#mi("{\\mathcal X}")#text(". We therefore have a conditional expectation map ")#mi("f \\mapsto {\\Bbb E}(f|Y)")#text(" defined for all absolutely integrable f by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("{\\Bbb E}(f|Y) := {\\Bbb E}(f|\\pi^{\\#}({\\mathcal Y})).")]]

#text("In general, this expectation only lies in ")#mi("L^1(Y)")#text(", though for the functions we shall eventually study, the expectation will always lie in ")#mi("L^\\infty(Y)")#text(" when needed.")

#text("As stated in the table, conditional expectation will play the role in the conditional setting that the unconditional expectation ")#mi("{\\Bbb E} f = \\int_X f\\ d\\mu")#text(" plays in the unconditional setting. Note though that the conditional expectation takes values in the algebra ")#mi("L^\\infty(Y)")#text(" rather than in the complex numbers. We recall that conditional expectation is linear over this algebra, thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("{\\Bbb E}(cf + dg|Y) = c {\\Bbb E}(f|Y) + d {\\Bbb E}(g|Y)")]]

#text("for all absolutely integrable f, g and all ")#mi("c, d \\in L^\\infty(Y)")#text(".")

#strong[#text("Example 3.")]#text(" Continuing Example 1, we see that for any absolutely integrable f on ")#mi("({\\Bbb R}/{\\Bbb Z})^2")#text(", we have ")#mi("{\\Bbb E}(f|Y)(y) = \\int_{{\\Bbb R}/{\\Bbb Z}} f(y,z^{\\prime})\\ dz^{\\prime}")#text(" almost everywhere. ")#mi("\\diamond")#linebreak()#text(" Let ")#mi("L^2(X|Y)")#text(" be the space of all ")#mi("f \\in L^2(X,{\\mathcal X},\\mu)")#text(" such that the conditional norm")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\|f\\right\\|_{L^2(X|Y)} := {\\Bbb E}(\\left|f\\right|^2 | Y)^{1/2}", block: true)]]

#text("lies in ")#mi("L^\\infty(Y)")#text(" (rather than merely in ")#mi("L^2(Y)")#text(", which it does automatically). Thus for instance we have the inclusions")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("L^\\infty(X) \\subset L^2(X|Y) \\subset L^2(X).")]]

#text("The space ")#mi("L^2(X|Y)")#text(" is easily seen to be a vector space over ")#mi("{\\Bbb C}")#text(", and moreover (thanks to (2)) is a ")#link("http://en.wikipedia.org/wiki/Module_%28mathematics%29")[#text("module")]#text(" over ")#mi("L^\\infty(Y)")#text(".")

#strong[#text("Exercise 1.")]#text(" If we introduce the inner product")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\langle f, g \\rangle_{L^2(X|Y)} := {\\Bbb E}(f \\overline{g}|Y)")]]

#text("(which, initially, is only in ")#mi("L^1(Y)")#text("), establish the pointwise Cauchy-Schwarz inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left|\\langle f, g \\rangle_{L^2(X|Y)}\\right| \\leq \\left\\|f\\right\\|_{L^2(X|Y)} \\left\\|g\\right\\|_{L^2(X|Y)}", block: true)]]

#text("almost everywhere. In particular, the inner product lies in ")#mi("L^\\infty(Y)")#text(". (Hint: repeat the standard proof of the ")#link("http://en.wikipedia.org/wiki/Cauchy%E2%80%93Schwarz_inequality")[#text("Cauchy-Schwarz inequality")]#text(" verbatim, but with ")#mi("L^\\infty(Y)")#text(" playing the role of the constants ")#mi("{\\Bbb C}")#text(".) ")#mi("\\diamond")

#strong[#text("Example 4.")]#text(" Continuing Examples 1 and 3, ")#mi("L^2(X|Y)")#text(" consists (modulo null set equivalence) of all measurable functions ")#mi("f(y,z)")#text(" such that ")#tao-math("\\left\\|f\\right\\|_{L^2(X|Y)} = (\\int_{{\\Bbb R}/{\\Bbb Z}} \\left|f(y,z)\\right|^2\\ dz)^{1/2}", block: false)#text(" is bounded a.e. in y, with the relative inner product")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\langle f, g \\rangle_{L^2(X|Y)}(y) := \\int_{{\\Bbb R}/{\\Bbb Z}} f(y,z) \\overline{g(y,z)}\\ dz")]]

#text("defined a.e. in y. Observe in this case that the relative Cauchy-Schwarz inequality (6) follows easily from the standard Cauchy-Schwarz inequality. ")#mi("\\diamond")

#strong[#text("Exercise 2. ")]#text(" Show that the function ")#tao-math("f \\mapsto \\left\\| \\left\\|f\\right\\|_{L^2(X|Y)} \\right\\|_{L^\\infty(Y)}", block: false)#text(" is a norm on ")#mi("L^2(X|Y)")#text(", which turns that space into a Banach space. (")#emph[#text("Hint")]#text(": you may need to “relativise” one of the standard proofs that ")#mi("L^2(X)")#text(" is complete. You may also want to start with the skew shift example to build some intuition.) Because of this completeness, we refer to ")#mi("L^2(X|Y)")#text(" as a ")#emph[#text("Hilbert module")]#text(" over ")#mi("L^\\infty(Y)")#text(". ")#mi("\\diamond")

#text("As ")#mi("\\pi")#text(" is a morphism, one can easily check the intertwining relationship")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("{\\Bbb E}(T^n f|Y) = S^n {\\Bbb E}(f|Y)")]]

#text("for all ")#mi("f \\in L^1(X)")#text(" and integers n. As a consequence we see that the map T (and all of its powers) preserves the space ")#mi("L^2(X|Y)")#text(", and furthermore is conditionally unitary in the sense that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\langle T^n f, T^n g \\rangle_{L^2(X|Y)} = S^n \\langle f, g \\rangle_{L^2(X|Y)}")]]

#text("for all ")#mi("f, g \\in L^2(X|Y)")#text(" and integers n.")

#text("In the Hilbert space ")#mi("L^2(X)")#text(" one can create finite dimensional subspaces ")#mi("\\{ c_1 f_1 + \\ldots + c_d f_d: c_1,\\ldots,c_d \\in {\\Bbb C} \\}")#text(" for any ")#mi("f_1,\\ldots,f_d \\in L^2(X)")#text(". Inside such subspaces we can create the bounded finite-dimensional ")#link("http://en.wikipedia.org/wiki/Zonohedron")[#text("zonotopes")]#text(" ")#tao-math("\\{ c_1 f_1 + \\ldots + c_d f_d: c_1,\\ldots,c_d \\in {\\Bbb C}, \\left|c_1\\right|, \\ldots,\\left|c_d\\right| \\leq 1 \\}", block: false)#text(". Observe (from the ")#link("http://en.wikipedia.org/wiki/Heine-Borel_theorem")[#text("Heine-Borel theorem")]#text(") that a subset E of ")#mi("L^2(X)")#text(" is precompact if and only if it can be approximated by finite-dimensional zonotopes in the sense that for every ")#mi("\\varepsilon > 0")#text(", there exists a finite-dimensional zonotope Z of ")#mi("L^2(X)")#text(" such that E lies within the ")#mi("\\varepsilon")#text(" neighbourhood of Z.")

#strong[#text("Remark 2. ")]#text("There is nothing special about zonotopes here; just about any family of bounded finite-dimensional objects would suffice for this purpose. In fact, it seems to be slightly better (for the purposes of quantitative analysis, and in particular in controlling the dependence on dimension d) to work instead with ")#link("http://en.wikipedia.org/wiki/Cross_polytope")[#text("octahedra")]#text(", in which the constraint ")#tao-math("\\left|c_1\\right|,\\ldots,\\left|c_d\\right| \\leq 1", block: false)#text(" is replaced by ")#tao-math("\\left|c_1\\right| + \\ldots + \\left|c_d\\right| = 1", block: false)#text("; see ")#link("http://front.math.ucdavis.edu/math.CO/0405251")[#text("this paper of mine")]#text(" in which this perspective is used. ")#mi("\\diamond")

#text("Inspired by this, let us make some definitions. A ")#emph[#text("finitely generated module")]#text(" of ")#mi("L^2(X|Y)")#text(" is any ")#link("http://en.wikipedia.org/wiki/Module_%28mathematics%29")[#text("submodule")]#text(" of ")#mi("L^2(X|Y)")#text(" of the form ")#mi("\\{c_1 f_1 + \\ldots + c_d f_d: c_1,\\ldots,c_d \\in L^\\infty(Y)\\}")#text(", where ")#mi("f_1,\\ldots,f_d \\in L^2(X|Y)")#text(". Inside such a module we can define a ")#emph[#text("finitely generated module zonotope")]#text(" ")#tao-math("\\{c_1 f_1 + \\ldots + c_d f_d: c_1,\\ldots,c_d \\in L^\\infty(Y); \\left\\|c_1\\right\\|_{L^\\infty(Y)}, \\ldots, \\left\\|c_d\\right\\|_{L^\\infty(Y)} \\leq 1\\}", block: false)#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1. ")]#text("A subset E of ")#mi("L^2(X|Y)")#text(" is said to be ")#emph[#text("conditionally precompact")]#text(" if for every ")#mi("\\varepsilon > 0")#text(", there exists a finitely generated module zonotope Z of ")#mi("L^2(X|Y)")#text(" such that E lies within the ")#mi("\\varepsilon")#text("-neighbourhood of Z (using the norm from Exercise 2).")

#text("A function ")#mi("f \\in L^2(X|Y)")#text(" is said to be ")#emph[#text("conditionally almost periodic")]#text(" if its orbit ")#mi("\\{ T^n f: n \\in {\\Bbb Z} \\}")#text(" is conditionally precompact.")

#text("A function ")#mi("f \\in L^2(X|Y)")#text(" is said to be ")#emph[#text("conditionally almost periodic in measure ")]#text("if every ")#mi("\\varepsilon > 0")#text(" there exists a set E in Y of measure at most ")#mi("\\varepsilon")#text(" such that ")#mi("f1_{E^c}")#text(" is conditionally almost periodic.")

#text("The system X is said to be a compact extension of Y if every function in ")#mi("L^2(X|Y)")#text(" is conditionally almost periodic in measure.")
]

#strong[#text("Example 5.")]#text(" Any bounded subset of ")#mi("L^\\infty(Y)")#text(" is conditionally precompact (though note that it need not be precompact in the topological sense, using the topology from Exercise 2). In particular, every function in ")#mi("L^\\infty(Y)")#text(" is conditionally almost periodic. ")#mi("\\diamond")

#strong[#text("Example 6.")]#text(" Every system is a compact extension of itself. A system is a compact extension of a point if and only if it is a compact system. ")#mi("\\diamond")

#strong[#text("Example 7. ")]#text("Consider the skew shift (Examples 1, 3, 4), and consider the orbit of the function ")#mi("f(y,z) := e^{2\\pi i z}")#text(". A computation shows that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("T^n f(y,z) = e^{2\\pi i \\frac{-n(-n-1)}{2} \\alpha} e^{-2\\pi i n y} f")]]

#text("which reveals (for ")#mi("\\alpha")#text(" irrational) that f is not almost periodic in the unconditional sense. However, observe that all the shifts ")#mi("T^n f")#text(" lie in the zonotope ")#tao-math("\\{ c f: c \\in L^\\infty(Y), \\left\\|c\\right\\|_{L^\\infty(Y)} \\leq 1 \\}", block: false)#text(" generated by a single generator f, and so f is ")#emph[#text("conditionally")]#text(" almost periodic. ")#mi("\\diamond")

#strong[#text("Exercise 3.")]#text(" Consider the skew shift (Examples 1,3,4,7). Show that a sequence ")#mi("f_n \\in L^\\infty(X)")#text(" is conditionally precompact if and only if the sequences ")#mi("f_n(y,\\cdot) \\in L^\\infty({\\Bbb R}/{\\Bbb Z})")#text(" are precompact in ")#mi("L^2({\\Bbb R}/{\\Bbb Z})")#text(" (with the usual Lebesgue measure) for almost every y. ")#mi("\\diamond")

#strong[#text("Exercise 4. ")]#text("Show that the space of conditionally almost periodic functions in ")#mi("L^2(X|Y)")#text(" is a shift-invariant ")#mi("L^\\infty(Y)")#text(" module, i.e. it is closed under addition, under multiplication by elements of ")#mi("L^\\infty(Y)")#text(", and under powers ")#mi("T^n")#text(" of the shift operator. ")#mi("\\diamond")

#strong[#text("Exercise 5.")]#text(" Consider the skew shift (Examples 1,3,4,7 and Exercise 3) with ")#mi("\\alpha")#text(" irrational, and let ")#mi("f \\in L^2(X|Y)")#text(" be the function defined by setting ")#mi("f(y,z) := e^{2\\pi i n z}")#text(" whenever ")#mi("n \\geq 1")#text(" and ")#mi("y \\in (1/(n+1),1/n]")#text(". Show that f is conditionally almost periodic in measure, but not conditionally almost periodic. Thus the two notions can be distinct even for bounded functions (a subtlety that does not arise in the unconditional setting). ")#mi("\\diamond")

#strong[#text("Exercise 6. ")]#text("Let ")#mi("{\\mathcal Z}_{X|Y}")#text(" denote the collection of all measurable sets E in X such that ")#mi("1_E")#text(" is conditionally almost periodic in measure. Show that ")#mi("{\\mathcal Z}_{X|Y}")#text(" is a shift-invariant sub-")#mi("\\sigma")#text("-algebra of ")#mi("{\\mathcal X}")#text(" that contains ")#mi("\\pi^{\\#} {\\mathcal Y}")#text(", and that a function ")#mi("f \\in L^2(X|Y)")#text(" is conditionally almost periodic in measure if and only if it is ")#mi("{\\mathcal Z}")#text("-measurable. (In particular, ")#mi("(X, {\\mathcal Z}_{X|Y}, \\mu, T)")#text(" is the maximal compact extension of Y.) [")#emph[#text("Hint")]#text(": you may need to truncate the generators ")#mi("f_1,\\ldots,f_d")#text(" of various module zonotopes to be in ")#mi("L^\\infty(X)")#text(" rather than ")#mi("L^2(X|Y)")#text(".] ")#mi("\\diamond")

#strong[#text("Exercise 7. ")]#text(" Show that the skew shift (Examples 1, 3, 4, 7 and Exercises 3,5) is a compact extension of the circle shift. (Hint: Use Example 7 and Exercise 6. Alternatively, approximate a function on the skew torus by its vertical Fourier expansions. For each fixed horizontal coordinate y, the partial sums of these vertical Fourier series converge (in the vertical ")#mi("L^2")#text(" sense) to the original function, pointwise in y. Now apply ")#link("http://en.wikipedia.org/wiki/Egorov%27s_theorem")[#text("Egorov’s theorem")]#text(".) ")#mi("\\diamond")

#strong[#text("Exercise 8.")]#text(" Show that each of the iterated skew shifts (Exercise 8 from ")#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/")[#text("Lecture 9")]#text(") are compact extensions of the preceding skew shift. ")#mi("\\diamond")

#strong[#text("Exercise 9.")]#text(" Let ")#mi("(Y, {\\mathcal Y}, \\nu, S)")#text(" be a measure-preserving system, let G be a compact metrisable group with a closed subgroup H, let ")#mi("\\sigma: Y \\to G")#text(" be measurable, and let ")#mi("Y \\times_\\sigma G/H")#text(" be the extension of Y with underlying space ")#mi("Y \\times G/H")#text(" , with measure equal to the product of ")#mi("\\nu")#text(" and Haar measure, and shift map ")#mi("T: (y,\\zeta) \\mapsto (Sy, \\sigma(y) \\zeta)")#text(". Show that ")#mi("Y \\times_\\sigma G/H")#text(" is a compact extension of Y. ")#mi("\\diamond")

#heading(level: 1)[#text("— Multiple recurrence for compact extensions —")]

#text("Let us say that a measure-preserving system ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" obeys the ")#emph[#text("uniform multiple recurrence")]#text(" (UMR) property if the conclusion of the Furstenberg multiple recurrence theorem holds for this system, thus for all ")#mi("k \\geq 1")#text(" and all non-negative ")#mi("f \\in L^\\infty(X)")#text(" with ")#mi("\\int_X f\\ d\\mu > 0")#text(", we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\liminf_{N \\to \\infty} \\frac{1}{N} \\sum_{n=0}^{N-1} \\int_X f T^n f \\ldots T^{(k-1) n} f\\ d\\mu > 0.")]]

#text("Thus in Lecture 11 we showed that all compact systems obey UMR, and in Lecture 12 we showed that all weakly mixing systems obey UMR. The Furstenberg multiple recurrence theorem asserts, of course, that ")#emph[#text("all ")]#text("measure-preserving systems obey UMR.")

#text("We now establish an important further step (and, in many ways, the ")#emph[#text("key ")]#text("step) towards proving that theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" Suppose that ")#mi("X = (X, {\\mathcal X}, \\mu, T)")#text(" is a compact extension of ")#mi("Y = (Y, {\\mathcal Y}, \\nu, S)")#text(". If Y obeys UMR, then so does X.")
]

#text("Note that the converse implication is trivial: if a system obeys UMR, then all of its factors automatically do also.")

#strong[#text("Proof of Theorem 1. ")]#text("Fix ")#mi("k \\geq 1")#text(", and fix a non-negative function ")#mi("f \\in L^\\infty(X)")#text(" with ")#mi("\\int_X f\\ d\\mu > 0")#text(". Our objective is to show that (10) holds. As X is a compact extension, f is conditionally almost periodic in measure; by definition (and uniform integrability), this implies that f can be bounded from below by another conditionally almost periodic function which is non-negative with positive mean. Thus we may assume without loss of generality that f is conditionally almost periodic.")

#text("We may normalise ")#tao-math("\\left\\|f\\right\\|_{L^\\infty(X)} = 1", block: false)#text(" and ")#mi("\\int_X f\\ d\\mu = \\delta")#text(" for some ")#mi("0 < \\delta < 1")#text(". The reader may wish to follow this proof using the skew shift example as a guiding model.")

#text("Let ")#mi("\\varepsilon > 0")#text(" be a small number (depending on k and ")#mi("\\delta")#text(") to be chosen later. If we set ")#mi("E := \\{ y \\in Y: {\\Bbb E}(f|Y) > \\delta/2 \\}")#text(", then E must have measure at least ")#mi("\\delta/2")#text(".")

#text("Since f is almost periodic, we can find a finitely generated module zonotope ")#tao-math("\\{ c_1 f_1 + \\ldots + c_d f_d: \\left\\|c_1\\right\\|_{L^\\infty(Y)},\\ldots,\\left\\|c_d\\right\\|_{L^\\infty(Y)} \\leq 1 \\}", block: false)#text(" whose ")#mi("\\varepsilon")#text("-neighbourhood contains the orbit of f. In other words, we have an identity of the form")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("T^n f = c_{1,n} f_1 + \\ldots + c_{d,n} f_d + e_n")]]

#text("for all n, where ")#mi("c_{1,n},\\ldots,c_{d,n} \\in L^\\infty(Y)")#text(" with norm at most 1, and ")#mi("e_n \\in L^2(X,Y)")#text(" is an error with ")#tao-math("\\left\\|e_n\\right\\|_{L^2(X|Y)} = O(\\varepsilon)", block: false)#text(" almost everywhere.")

#text("By splitting into real and imaginary parts (and doubling d if necessary) we may assume that the ")#mi("c_{j,n}")#text(" are real-valued. By further duplication we can also assume that ")#tao-math("\\left\\|f_i\\right\\|_{L^2(X|Y)} \\leq 1", block: false)#text(" for each i. By rounding off ")#mi("c_{j,n}(y)")#text(" to the nearest multiple of ")#mi("\\varepsilon/d")#text(" for each y (and absorbing the error into the ")#mi("e_n")#text(" term) we may assume that ")#mi("c_{j,n}(y)")#text(" is always a multiple of ")#mi("\\varepsilon/d")#text(". Thus each ")#mi("c_{j,n}")#text(" only takes on ")#mi("O_{\\varepsilon,d}(1)")#text(" values.")

#text("Let K be a large integer (depending on k, d, ")#mi("\\delta")#text(", ")#mi("\\varepsilon")#text(") to be chosen later. Since the factor space Y obeys UMR, and E has positive measure in Y, we know that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\liminf_{N \\to \\infty} \\frac{1}{N} \\sum_{n=0}^{N-1} \\int_Y 1_{E} T^n 1_{E} \\ldots T^{(K-1) n}1_{E}\\ d\\nu > 0.")]]

#text("In other words, there exists a constant ")#mi("c > 0")#text(" such that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\nu( \\Omega_n ) > c")]]

#text("for a set of n of positive lower density, where ")#mi("\\Omega_n")#text(" is the set")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\Omega_n := E \\cap T^n E \\cap \\ldots \\cap T^{(K-1)n} E.")]]

#text("Let n be as above. By definition of ")#mi("\\Omega_n")#text(" and ")#mi("E")#text(" (and (8)), we see that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("{\\Bbb E}( T^{an} f | Y )(y) \\geq \\delta/2")]]

#text("for all ")#mi("y \\in \\Omega_n")#text(" and ")#mi("0 \\leq a < K")#text(". Meanwhile, from (11) we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\left\\| T^{an} f - c_{1,an} f_1 - \\ldots - c_{d,an} f_d \\right\\|_{L^2(X|Y)}(y) = O(\\varepsilon)", block: true)]]

#text("for all ")#mi("y \\in \\Omega_n")#text(" and ")#mi("0 \\leq a < K")#text(".")

#text("Fix y. For each ")#mi("0 \\leq a < K")#text(", the d-tuple ")#mi("\\vec c_{an}(y) := (c_{1,an}(y),\\ldots,c_{d,an}(y))")#text(" ranges over a set of cardinality ")#mi("O_{d,\\varepsilon}(1)")#text(". One can view this as a colouring of ")#mi("\\{0,\\ldots,K-1\\}")#text(" into ")#mi("O_{d,\\varepsilon}(1)")#text(" colours. Applying van der Waerden’s theorem (Exercise 3 from ")#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/")[#text("Lecture 4")]#text("), we can thus find (if K is sufficiently large depending on ")#mi("d, \\varepsilon, k")#text(") an arithmetic progression ")#mi("a(y), a(y)+r(y), \\ldots, a(y)+(k-1)r(y)")#text(" in ")#mi("\\{0,\\ldots,K-1\\}")#text(" for each y such that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\vec c_{a(y)n}(y) = \\vec c_{(a(y)+r(y)) n}(y) = \\ldots = \\vec c_{(a(y)+(k-1)r(y))n}(y).")]]

#text("The quantities a(y) and r(y) can of course be chosen to be measurable in y. By the pigeonhole principle, we can thus find a subset ")#mi("\\Omega^{\\prime}_n")#text(" of ")#mi("\\Omega_n")#text(" of measure at least ")#mi("\\sigma > 0")#text(" for some ")#mi("\\sigma")#text(" depending on c, K, d, ")#mi("\\varepsilon")#text(" but independent of n, and an arithmetic progression ")#mi("a, a+r, \\ldots, a+(k-1)r")#text(" in ")#mi("\\{0,\\ldots,K-1\\}")#text(" such that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\vec c_{an}(y) = \\vec c_{(a+r) n}(y) = \\ldots = \\vec c_{(a+(k-1)r)n}(y)")]]

#text("for all ")#mi("y \\in \\Omega^{\\prime}_n")#text(". (The quantities a and r can still depend on n, but this will not be of concern to us.)")

#text("Fix these values of a, r. From (16), (18) and the triangle inequality we see that")

#align(center)[#tao-math("\\left\\| T^{(a+jr)n} f - T^{an} f \\right\\|_{L^2(X|Y)}(y) = O(\\varepsilon)", block: false)#text(" (19)")#linebreak()#text(" for all ")#mi("1 \\leq j \\leq k")#text(" and ")#mi("y \\in \\Omega^{\\prime}_n")#text(". Recalling that f was normalised to have ")#mi("L^\\infty(X)")#text(" norm 1, it is then not hard to conclude (by induction on k and the relative Cauchy-Schwarz inequality) that")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("\\left\\| T^{an} f T^{(a+r)n} f \\ldots T^{(a+(k-1)r)n} f - (T^{an} f )^k \\right\\|_{L^2(X|Y)}(y) = O_k(\\varepsilon)", block: true)]]

#text("and thus (by another application of relative Cauchy-Schwarz)")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("{\\Bbb E}( T^{an} f T^{(a+r)n} f \\ldots T^{(a+(k-1)r)n} f )(y) \\geq {\\Bbb E}( (T^{an} f )^k | Y)(y) - O_k(\\varepsilon).")]]

#text("But from (15) we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("{\\Bbb E}( T^{an} f | Y)(y) \\geq \\delta/2")]]

#text("and so by several more applications of relative Cauchy-Schwarz we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("{\\Bbb E}( ( T^{an} f )^k|Y)(y) \\geq c(k,\\delta) > 0")]]

#text("for some positive quantity ")#mi("c(k,\\delta)")#text(". From (21), (23) we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("{\\Bbb E}( T^{an} f T^{(a+r)n} f \\ldots T^{(a+(k-1)r)n} f )(y) \\geq c(k,\\delta)/2")]]

#text("for ")#mi("y \\in \\Omega^{\\prime}_n")#text(", if ")#mi("\\varepsilon")#text(" is small enough. Integrating this in y and using the shift-invariance we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\int_X f T^{nr} f \\ldots T^{(k-1)nr} f\\ d\\mu \\geq c(k,\\delta) \\sigma/2.")]]

#text("The quantity r depends on n, but ranges between 1 and K-1, and so (by the non-negativity of f)")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\sum_{s=1}^{K-1} \\int_X f T^{ns} f \\ldots T^{(k-1)ns} f\\ d\\mu \\geq c(k,\\delta) \\sigma/2")]]

#text("for a set of n of positive lower density. Averaging this for n from 1 to N (say) one obtains (10) as desired. ")#mi("\\Box")

#text("Thus for instance we have now established UMR for the skew shift as well as higher iterates of that shift, thanks to Exercises 7 and 8.")

#strong[#text("Remark 3. ")]#text(" One can avoid the use of Hilbert modules, etc. by instead appealing to the theory of disintegration of measures (Theorem 4 from ")#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/")[#text("Lecture 9")]#text("). We sketch the details as follows. First, one has to restrict attention to those spaces X which are regular, though an inspection of the Furstenberg correspondence principle (")#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/")[#text("Lecture 10")]#text(") shows that this is in fact automatic for the purposes of such tasks as proving Szemerédi’s theorem. Once one disintegrates ")#mi("\\mu")#text(" with respect to ")#mi("\\nu")#text(", the situation now resembles the concrete example of the skew shift, with the fibre measures ")#mi("\\mu_y")#text(" playing the role of integration along vertical fibers ")#mi("\\{ (y,z): z \\in {\\Bbb R}/{\\Bbb Z} \\}")#text(". It is then not difficult (and somewhat instructive) to convert the above proof to one using norms such as ")#mi("L^2(X, {\\mathcal X}, mu_y)")#text(" rather than the module norm ")#mi("L^2(X|Y)")#text(". We leave the details to the reader (who can also get them from ")#link("http://www.ams.org/mathscinet-getitem?mr=603625")[#text("Furstenberg’s book")]#text("). ")#mi("\\diamond")

#strong[#text("Remark 4.")]#text(" It is an intriguing question as to whether there is any interesting non-commutative extension of the above theory, in which the underlying ")#link("http://en.wikipedia.org/wiki/Von_Neumann_algebra")[#text("von Neumann algebra")]#text(" ")#mi("L^\\infty(Y, {\\mathcal Y},\\nu)")#text(" is replaced by a non-commutative von Neumann algebra. While some of the theory seems to extend relatively easily, there does appear to be some genuine difficulties with other parts of the theory, particularly those involving multiple products such as ")#mi("f T^n f T^{2n} f")#text(". ")#mi("\\diamond")

#strong[#text("Remark 5.")]#text(" Just as ergodic compact systems can be described as group rotation systems (Kronecker systems), it turns out that ergodic compact extensions can be described as (inverse limits of) group quotient extensions, somewhat analogously to Lemma 2 from ")#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/")[#text("Lecture 6")]#text(". Roughly speaking, the idea is to first use some spectral theory to approximate conditionally almost periodic functions by conditionally ")#emph[#text("quasiperiodic")]#text(" functions – those functions whose orbit lies on a finitely generated module zonotope (as opposed to merely being close to one). One can then use the generators of that zonotope as a basis from which to build the group quotient extension, and then use some further trickery to make the group consistent across all fibres. The precise machinery for this is known as ")#emph[#text("Mackey theory")]#text("; it is of particular importance in the deeper structural theory of dynamical systems, but we will not describe it in detail here, instead referring the reader to the papers ")#link("http://www.ams.org/mathscinet-getitem?mr=498471")[#text("of Furstenberg")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=409770")[#text("of Zimmer")]#text(". ")#mi("\\diamond")

#text("[")#emph[#text("Update")]#text(", Mar 5: Exercise added.]")

#text("[")#emph[#text("Update")]#text(", Mar 12: Definition of conditionally almost periodic measure tweaked (to an equivalent definition) in order to simplify the proof of Theorem 1.]")

#heading(level: 1)[#text("Comments (31)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 14: Weakly mixing extensions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-26834")[#strong[#text("254A, Lecture 14: Weakly mixing extensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2008")])]

#text("[…] Hilbert-Schmidt operators, randomness, weak mixing Having studied compact extensions in the previous lecture, we now consider the opposite type of extension, namely that of a weakly mixing extension. Just as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-26993")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2008")])]

#text("All the formulas in this post seem to lack backlashases before TeX commands.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-26999")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2008")])]

#text("Anonymous, this is a problem on WordPress’ end, as ")#link("http://unapologetic.wordpress.com/2008/03/06/latex-screw-ups/")[#text("I noted earlier today")]#text(", or possibly all the way back to the new version of PHP, which ")#link("http://www.sunclipse.org/?p=550")[#text("Blake Stacey")]#text(" noticed recently.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-34442")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2008")])]

#text("Dear Professor Tao:")

#text("I got several small corrections and a question:")

#text("1, In Example 1, the shift should be ")#mi("T: (y,z) \\mapsto (y+\\alpha,z+y)")

#text("2, In (3), the right hand side should be ")#tao-math("{\\Bbb E}( \\left| f \\right|^2 | Y)^{1/2}", block: false)

#text("3,in Exercise 3, the tex cod “\\cdot”, with “\\”missing.")

#text("and")

#text("I don’t know how to compute (9).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-34453")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2008")])]

#text("Thanks for the corrections! There were some typos in (9); one can work things out by first computing what ")#mi("T^{-n}(y,z)")#text(" is by induction (it is ")#mi("(y-n\\alpha, z - ny + \\frac{-n(-n-1)}{2} \\alpha)")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 15: The Furstenberg-Zimmer structure theorem and the Furstenberg recurrence theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-34781")[#strong[#text("254A, Lecture 15: The Furstenberg-Zimmer structure theorem and the Furstenberg recurrence theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2009")])]

#text("[…] for a point, and we have already shown that UMR is preserved by compact extensions (Theorem 1 of Lecture 13) and by weakly mixing extensions (Theorem 1 of Lecture 14). The former result lets us climb the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-41996")[#strong[#text("Ergodic Ramsey Theory (by Yuri Lima) « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2009")]

#text("[…] Compact and weak-mixing […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6669b6dfdc08b6d8dcbdd96e50dd50bb963b4ca8c923d4a4b7a22de6d6634a4b-eaa6a0cd3a47692f656a02fecadcdc304d72c5ef5f1e744097e2ee351c3802fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-45532")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2010")])]

#text("Dear Professor Tao,")

#text("About Remark 4, do you have any reference in which this question have been studied?")

#text("thanks,")

#text("Alex")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-45536")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2010")])]

#text("I recently wrote a paper with Tim Austin and Tanja Eisner on this topic at")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2009/12/29/nonconventional-ergodic-averages-and-multiple-recurrence-for-von-neumann-dynamical-systems/")[#text("Nonconventional ergodic averages and multiple recurrence for von Neumann dynamical systems")]
]

#text("There is also previous work by Niculescu-Stroh-Zsido, Duvenhage, and Beyers-Duvenhage-Stroh, among others. Roughly speaking, it seems that triple averages are still more or less OK if one makes reasonable assumptions (such as ergodicity), but higher order averages can behave quite badly unless one makes very strong assumptions (e.g. asymptotic abelianness).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-52147")[#strong[#text("ERT16: Compact extensions « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2011")]

#text("[…] This post of Terence Tao has much in common with our discussion. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Furstenberg multiple recurrence theorem and finite extensions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-53439")[#strong[#text("The Furstenberg multiple recurrence theorem and finite extensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2011")])]

#text("[…] that the multiple recurrence property is preserved under compact extensions; see for instance these lecture notes, which is devoted entirely to this step. This step requires quite a bit of measure-theoretic and/or […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel zorin")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-95454")[#strong[#text("pavel zorin")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2011")])]

#text("Dear Prof. Tao,")

#text("could you please give some hints or references on how to approximate conditionally almost periodic functions by conditionally quasiperiodic functions?")

#text("For me this would be the last step in understanding why the factor in Exercise 6 coincides with that defined by Furstenberg in his ’77 paper.")

#text("best regards,")#linebreak()#text(" pavel")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-95464")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2011")])]

#text("I’m not sure how you are defining conditionally quasiperiodic functions in general, but in the case of compact extensions, it is possible to represent such extensions (under some mild topological assumptions on the underlying space) as extensions by compact abelian groups, at which point one can use Fourier analysis in that group to approximate arbitrary functions in the extension by functions which are “conditionally quasiperiodic” in the sense that they are finite linear combinations of functions that are eigenfunctions of the group action (or equivalently, are scalar multiples of characters in almost every fibre).")

#text("Furstenberg’s book contains a number of equivalent characterisations of compact extensions, and on the relationship between a number of slightly different versions of relative almost periodicity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-97080")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2011")])]

#text("I used the definition from Remark 5. The problem was that the construction of the representation as a group extension say by Furstenberg assumes that the extension is spanned by generalized eigenfunctions.")

#text("I have now adapted the argument from Lemma 2.14.17 in your book (using conditional Hilbert-Schmidt operators) to show that the generalized eigenfunctions are dense in conditionally almost periodic functions.")

#text("By the way, in the book (Proposition 2.14.11) you take a weak limit of operators on L²(X|Y). In that particular case a limit can be constructed explicitly using the mean ergodic theorem on ")#mi("X \\times_Y X")#text(" as in Furstenberg’s book. Is there also an abstract proof of existence? (the problem being that L²(X|Y) is not a Hilbert space and fiberwise constructions are not straightforward because there may be uncountably many fibers).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-97083")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2011")])]

#text("Ah, I see where you are coming from now. Yes, by taking a bunch of “conditional eigenspaces” of a conditional Hilbert-Schmidt operator, one can achieve the desired approximatino.")

#text("With regards to the weak limit, I guess one needs to use the weak topology of L^2(X) rather than L^2(X|Y) to get weak compactness. Note that the operators S_N involved are uniformly bounded in L^2(X). I’ll make a note of that in the errata.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8c2016a95d7871dcb511ae984e701ed78c8c69bcbea8aed09b3f13b3dbc827a-acbdc4f59b530120b45a1ec4380cb421d042b21bae300a1a2688683d5cfce060.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joel Moreira")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-200064")[#strong[#text("Joel Moreira")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2012")])]

#text("Dear Prof. Tao")

#text("In the proof of Theorem 1, right after equation (17) you claim that a(y) and r(y) can be made measurable in y. Maybe I’m missing something obvious but I don’t understand why this is true, could you give some additional explanation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-200074")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2012")])]

#text("Arrange the set of pairs ")#mi("(a,r)")#text(" in some well-ordered fashion (e.g. lexicographic) and then for each ")#mi("y")#text(", take ")#mi("(a(y),r(y))")#text(" to be the minimal ")#mi("(a,r)")#text(" that obeys the required property.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8c2016a95d7871dcb511ae984e701ed78c8c69bcbea8aed09b3f13b3dbc827a-acbdc4f59b530120b45a1ec4380cb421d042b21bae300a1a2688683d5cfce060.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joel Moreira")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-200077")[#strong[#text("Joel Moreira")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2012")])]

#text("Well, I was having trouble figuring out why the set of y’s for which some fixed (a,r) works is measurable, but after taking some time to write down the definitions I figured it out. Thank you for the quick answer.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ed4366c4acfdc577f31106b0d2504d33afb14aea32f847ce714bfb993b9550d-99b4a49893d437a8a2d40bd6d1e11fb0465f0dfaac37539a0136bac7bd85b261.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cuttheknot")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-211693")[#strong[#text("cuttheknot")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2013")])]

#text("Dear Prof. Tao, how can I deduce inequality (23) from (22)?")#linebreak()#text(" Also, where does the ")#mi("O(\\epsilon)")#text(" come from in (22)? (Shouldn’t it be identical to (15)?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-211707")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2013")])]

#text("Iterating relative Cauchy-Schwarz will give (23) from (22) when k is a power of two; the general case then follows since f is bounded by 1 (and every k is certainly bounded above by a power of two).")

#text("You’re right that (22) just follows from (15) without the epsilon loss; I’ll amend the text to reflect this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ed4366c4acfdc577f31106b0d2504d33afb14aea32f847ce714bfb993b9550d-99b4a49893d437a8a2d40bd6d1e11fb0465f0dfaac37539a0136bac7bd85b261.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cuttheknot")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-211731")[#strong[#text("cuttheknot")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2013")])]

#text("Ok, now I see. Thank you!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Multiple recurrence and convergence results associated to $F_{p}^{omega}$-actions | What's new")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-230673")[#strong[#text("Multiple recurrence and convergence results associated to $F_{p}^{omega}$-actions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2013")])]

#text("[…] is the Haar probability measure on ; see this previous blog post. The equation defining corresponds to the constraint (4) mentioned earlier. Among other things, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A nonstandard analysis proof of Szemeredi’s theorem | What's new")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-457538")[#strong[#text("A nonstandard analysis proof of Szemeredi’s theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2015")])]

#text("[…] This gives the structure of a (pre-)Hilbert module over , as discussed in this previous blog post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fd1243d1813d506891de7f7f6a3cd5c0c76ca07d3bf41804a212987abf7c5b5-548d6c3a5e084ac61ae89e77525846fd34b34ca006690132d9168167f40553c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike Schnurr")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-475179")[#strong[#text("Mike Schnurr")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2016")])]

#text("I’m still trying to grapple with the Hilbert module, so I have a question about conditional precompactness that might be pretty basic in light of a better understanding of the module.")

#text("First of all, am I correct in presuming that if ")#tao-math("\\left\\| \\left\\| f \\right\\|_{L^2(X|Y)} \\right\\|_{L^2(Y)}=1,", block: false)#text(" then for all ")#tao-math("n, \\left\\| \\left\\| T^n f \\right\\|_{L^2(X|Y)} \\right\\|_{L^2(X)}=1?", block: false)#text(" I will assume I am correct on this for my main question")

#text("Now, I’m working with a different formulation of conditional precompactness. Namely, ")#mi("E")#text(" is conditionally precompact if for all ")#mi("\\epsilon")#text(" there exists ")#mi("f_1, \\ldots, f_k")#text(" such that ")#tao-math("\\min_{1 \\le i \\le k} \\left\\| f - f_i \\right\\|_{L^2(X|Y)} < \\epsilon", block: false)#text(" a.e. So if I have ")#mi("f")#text(" conditionally almost periodic with ")#tao-math("\\left\\| \\left\\| f \\right\\|_{L^2(X|Y)} \\right\\|_{L^2(Y)}=1,", block: false)#text(" for a given ")#mi("\\epsilon,")#text(" can my ")#mi("f_i")#text(" be chosen such that ")#tao-math("\\left\\| \\left\\| f_i \\right\\|_{L^2(X|Y)} \\right\\|_{L^2(Y)}=1?", block: false)#text(" I would imagine it is possible, same as nearly all considerations with norms of functions. Still, I need to be sure, and I don't understand the Hilbert module well enough at this point to figure out how to grapple with answering it on my own.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-475186")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2016")])]

#text("The answer to the first question is “Yes”, assuming of course that ")#mi("T")#text(" is measure preserving. I’m afraid I don’t understand the second question – how is the set ")#mi("E")#text(" related to the function ")#mi("f")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fd1243d1813d506891de7f7f6a3cd5c0c76ca07d3bf41804a212987abf7c5b5-548d6c3a5e084ac61ae89e77525846fd34b34ca006690132d9168167f40553c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike Schnurr")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-475190")[#strong[#text("Mike Schnurr")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2016")])]

#text("Sorry for not making it clearer. Since ")#mi("f")#text(" is conditionally almost periodic, I mean for ")#mi("E")#text(" to be exactly the set ")#mi("\\{T^n f : n \\in \\mathbb{Z} \\},")#text(" where yes, ")#mi("T")#text(" is measure preserving. Additionally (if relevant), ")#mi("T")#text(" is an extension of some ")#mi("S: X \\to X,")#text(" and I’m even assuming both are invertible")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-475209")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2016")])]

#text("In which case you probably mean ")#tao-math("\\min_{1 \\leq i \\leq k} \\left\\|T^n f - f_i \\right\\|_{L^2(X|Y)}", block: false)#text(" rather than ")#tao-math("\\min_{1 \\leq i \\leq k} \\left\\| f - f_i \\right\\|_{L^2(X|Y)}", block: false)#text(". One can certainly achieve this normalisation, though it is somewhat unnatural to do so: one can partition ")#mi("Y")#text(" into small sets ")#mi("A_1,\\dots,A_r")#text(", and then replace each of the ")#mi("f_i")#text(" by functions ")#mi("f_{i,j}")#text(" for ")#mi("j=1,\\dots,r")#text(", where ")#mi("f_{i,j}")#text(" is defined to equal ")#mi("f_i")#text(" on ")#mi("A_j")#text(" and is chosen more or less arbitrarily on the remaining portion of ")#mi("Y")#text(" (or ")#mi("X")#text(") in order to achieve the required normalisation ")#tao-math("\\left\\| \\left\\|f_i\\right\\|_{L^2(X|Y)} \\right\\|_{L^2(Y)} = 1", block: false)#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c620300871938edc7f2479f0b0ba17f6903f20059bdfee397e078d5f2e3fd338-45a5bbb177a9bc377bcb72337273c93904f6fd03f53e7444ff36d00194d60ff8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abhishek Khetan")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-584982")[#strong[#text("Abhishek Khetan")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2020")])]

#text("Dear Prof. Tao,")

#text("I have a question regarding Exmaple 7.")

#text("We have ")#mi("f(y, z) = e^{2\\pi i z}")#text(". Fix ")#mi("\\alpha \\in \\mathbb Z/\\mathbb Z")#text(" and write ")#mi("\\lambda_n = e^{2\\pi i \\frac{n(n+1)}{2}\\alpha}")#text(". Then ")#mi("T^nf(y, z) = \\lambda_n e^{-2\\pi i n y} f(y, z)")#text(".")

#text("You have mentioned that ")#mi("f")#text(" is not (unconditionally) almost periodic if ")#mi("\\alpha")#text(" is irrational. I am trying to see what changes when ")#mi("\\alpha")#text(" is rational.")

#text("To check for almost periodicity, we need to look at the quantity ")#tao-math("\\left\\|T^nf -f\\right\\|_2", block: false)#text(" which by Fubini is equal to ")#tao-math("\\left|\\lambda_n e^{-2\\pi i n y} - 1\\right|^2\\ dy", block: false)#text(". By a change of variable this is same as ")#tao-math("\\left|e^{-\\pi i n y} - 1\\right|^2\\ dy", block: false)#text(" which does not depend on the choice of ")#mi("\\alpha")#text(".")

#text("So my conclusion is that ")#mi("f")#text(" is not almost peiodic regardless of the choice of ")#mi("\\alpha")#text(". Is this correct or have I made a mistake somwhere?")

#text("Also, there is a minor typo in Example 3. The expression ")#mi("E(f|Y)(y, z)")#text(" should be replaced by ")#mi("E(f|Y)(y)")#text(".")

#text("Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-586491")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2020")])]

#text("Thanks for the correction. It is true that even for rational ")#mi("\\alpha")#text(" the function here is not unconditionally almost periodic, though in this case the entire system is not ergodic and the dynamics are qualitatively rather different as a consequence.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a6ba709f9f4947c91dd60d61bd058aec89529bcb750b632689c4131ecf7d2543-3774efb36107cee096c1e5ed22760841b6832c5715cdd70cb13a44cc747e6e71.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matk")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-678444")[#strong[#text("Matk")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2023")])]

#text("A question related to the comment before the Example 1.")#linebreak()#text(" Let ")#mi("\\mathsf{Y} = (Y,\\mathcal{Y},\\nu,S)")#text(" is a factor of ")#mi("\\mathsf{X} = (X,\\mathcal{X},\\mu,T)")#text(" with the corresponding factor map ")#mi("\\pi\\colon X \\to Y")#text(", then ")#mi("\\mathsf{X}^{\\prime} = (X,\\pi^{\\#}(\\mathcal{Y}),\\mu,T)")#text(" is obviously another factor of ")#mi("\\mathsf{X}")#text(". I’ve seen being claimed (for example, in your paper with Bergelson and Ziegler, Remark 1.8 in ")#link("https://arxiv.org/pdf/0901.2602.pdf")[#text("https://arxiv.org/pdf/0901.2602.pdf")]#text(") that all factors are, up to isomorphism, are of this type, i.e. isomorphic to the original space but with a smaller ")#mi("\\sigma")#text("-algebra. Is this really true? What is the meaning of “isomorphic” here, i.e. is in the sense of ")#mi("L^\\infty")#text(" algebras? I don’t see how it can be isomorphic in the usual category of measure-preserving systems, given that ")#mi("Y")#text(" can be much smaller than ")#mi("X")#text(" and thus impossible to be the its extension (even with smaller ")#mi("\\sigma")#text("-algebra on ")#mi("X")#text(" and discarding null-sets).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/#comment-678448")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2023")])]

#text("Yes, isomorphism is in the sense of isomorphic ")#mi("L^\\infty")#text(" algebras (equipped with a trace and a shift), or equivalently as probability algebras. See for instance ")#text("this more recent paper")#text(" (particularly Appendix A) of Jamneshan, Shalom and myself for some discussion, and ")#link("https://arxiv.org/abs/2010.00681")[#text("this foundational paper of Jamneshan")]#text(" and myself for a much more detailed dive into this topic.")
]
]
