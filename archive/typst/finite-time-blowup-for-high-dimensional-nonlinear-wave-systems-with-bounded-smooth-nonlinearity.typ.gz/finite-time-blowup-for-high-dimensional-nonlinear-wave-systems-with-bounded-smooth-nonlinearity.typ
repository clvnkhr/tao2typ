// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/03/08/finite-time-blowup-for-high-dimensional-nonlinear-wave-systems-with-bounded-smooth-nonlinearity/
// Converted to Typst by tao2typ: "2026-10-14T07:13:21.535330+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Finite time blowup for high dimensional nonlinear wave systems with bounded smooth nonlinearity", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Finite time blowup for high dimensional nonlinear wave systems with bounded smooth nonlinearity")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 March 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/03/08/finite-time-blowup-for-high-dimensional-nonlinear-wave-systems-with-bounded-smooth-nonlinearity/")[#text("https://terrytao.wordpress.com/2016/03/08/finite-time-blowup-for-high-dimensional-nonlinear-wave-systems-with-bounded-smooth-nonlinearity/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper ")#link("http://arxiv.org/abs/1603.01908")[#text("Finite time blowup for high dimensional nonlinear wave systems with bounded smooth nonlinearity")]#text(", submitted to ")#link("http://www.tandfonline.com/action/journalInformation?journalCode=lpde20#.VtzcFZwrJWI")[#text("Comm. PDE")]#text(". This paper is in the same spirit as (though not directly related to) my previous paper on finite time blowup of supercritical NLW systems, and was inspired by a question posed to me some time ago by Jeffrey Rauch. Here, instead of looking at supercritical equations, we look at an extremely subcritical equation, namely a system of the form ")#metadata(none) <tao-3455e95ef2bc60a57df4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\Box u = f(u)")]]



#text(" where ")#mi("{u: {\\bf R}^{1+d} \\rightarrow {\\bf R}^m}")#text(" is the unknown field, and ")#mi("{f: {\\bf R}^m \\rightarrow {\\bf R}^m}")#text(" is the nonlinearity, which we assume to have all derivatives bounded. A typical example of such an equation is the higher-dimensional ")#link("https://en.wikipedia.org/wiki/Sine-Gordon_equation")[#text("sine-Gordon equation")]

#align(center)[#tao-fit-display[#mitex("\\Box u = \\sin u")]]

#text("for a scalar field ")#mi("{u: {\\bf R}^{1+d} \\rightarrow {\\bf R}}")#text(". Here ")#mi("{\\Box = -\\partial_t^2 + \\Delta}")#text(" is the d’Alembertian operator. We restrict attention here to classical (i.e. smooth) solutions to ")#link(<tao-3455e95ef2bc60a57df4>)[#text("(1)")]#text(".")

#text("We do not assume any Hamiltonian structure, so we do not require ")#mi("{f}")#text(" to be a gradient ")#mi("{f = \\nabla F}")#text(" of a potential ")#mi("{F: {\\bf R}^m \\rightarrow {\\bf R}}")#text(". But even without such Hamiltonian structure, the equation ")#link(<tao-3455e95ef2bc60a57df4>)[#text("(1)")]#text(" is very well behaved, with many ")#emph[#text("a priori")]#text(" bounds available. For instance, if the initial position ")#mi("{u_0(x) = u(0,x)}")#text(" and initial velocity ")#mi("{u_1(x) = \\partial_t u(0,x)}")#text(" are smooth and compactly supported, then from finite speed of propagation ")#mi("{u(t)}")#text(" has uniformly bounded compact support for all ")#mi("{t}")#text(" in a bounded interval. As the nonlinearity ")#mi("{f}")#text(" is bounded, this immediately places ")#mi("{f(u)}")#text(" in ")#mi("{L^\\infty_t L^2_x}")#text(" in any bounded time interval, which by the energy inequality gives an a priori ")#mi("{L^\\infty_t H^1_x}")#text(" bound on ")#mi("{u}")#text(" in this time interval. Next, from the chain rule we have")

#align(center)[#tao-fit-display[#mitex("\\nabla f(u) = (\\nabla_{{\\bf R}^m} f)(u) \\nabla u")]]

#text("which (from the assumption that ")#mi("{\\nabla_{{\\bf R}^m} f}")#text(" is bounded) shows that ")#mi("{f(u)}")#text(" is in ")#mi("{L^\\infty_t H^1_x}")#text(", which by the energy inequality again now gives an a priori ")#mi("{L^\\infty_t H^2_x}")#text(" bound on ")#mi("{u}")#text(".")

#text("One might expect that one could keep iterating this and obtain ")#emph[#text("a priori")]#text(" bounds on ")#mi("{u}")#text(" in arbitrarily smooth norms. In low dimensions such as ")#mi("{d \\leq 3}")#text(", this is a fairly easy task, since the above estimates and Sobolev embedding already place one in ")#mi("{L^\\infty_t L^\\infty_x}")#text(", and the nonlinear map ")#mi("{f}")#text(" is easily verified to preserve the space ")#mi("{L^\\infty_t H^k_x \\cap L^\\infty_t L^\\infty_x}")#text(" for any natural number ")#mi("{k}")#text(", from which one obtains a priori bounds in any Sobolev space; from this and standard energy methods, one can then establish global regularity for this equation (that is to say, any smooth choice of initial data generates a global smooth solution). However, one starts running into trouble in higher dimensions, in which no ")#mi("{L^\\infty_x}")#text(" bound is available. The main problem is that even a really nice nonlinearity such as ")#mi("{u \\mapsto \\sin u}")#text(" is unbounded in higher Sobolev norms. The estimates")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sin u\\right| \\leq \\left|u\\right|", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|\\nabla(\\sin u)\\right| \\leq \\left|\\nabla u\\right|", block: true)]]

#text("ensure that the map ")#mi("{u \\mapsto \\sin u}")#text(" is bounded in low regularity spaces like ")#mi("{L^2_x}")#text(" or ")#mi("{H^1_x}")#text(", but one already runs into trouble with the second derivative")

#align(center)[#tao-fit-display[#mitex("\\nabla^2(\\sin u) = (\\cos u) \\nabla^2 u - (\\sin u) \\nabla u \\nabla u")]]

#text("where there is a troublesome lower order term of size ")#tao-math("{O( \\left|\\nabla u\\right|^2 )}", block: false)#text(" which becomes difficult to control in higher dimensions, preventing the map ")#mi("{u \\mapsto \\sin u}")#text(" to be bounded in ")#mi("{H^2_x}")#text(". Ultimately, the issue here is that when ")#mi("{u}")#text(" is not controlled in ")#mi("{L^\\infty}")#text(", the function ")#mi("{\\sin u}")#text(" can oscillate at a much higher frequency than ")#mi("{u}")#text("; for instance, if ")#mi("{u}")#text(" is the one-dimensional wave ")#mi("{u = A \\sin(kx)}")#text("for some ")#mi("{k > 0}")#text(" and ")#mi("{A>1}")#text(", then ")#mi("{u}")#text(" oscillates at frequency ")#mi("{k}")#text(", but the function ")#mi("{\\sin(u)= \\sin(A \\sin(kx))}")#text(" more or less oscillates at the larger frequency ")#mi("{Ak}")#text(".")

#text("In medium dimensions, it is possible to use dispersive estimates for the wave equation (such as the famous Strichartz estimates) to overcome these problems. This line of inquiry was pursued (albeit for slightly different classes of nonlinearity ")#mi("{f}")#text(" than those considered here) by ")#link("http://www.ams.org/mathscinet-getitem?mr=365257")[#text("Heinz-von Wahl")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=435605")[#text("Pecher")]#text(" (in a ")#link("http://www.ams.org/mathscinet-getitem?mr=499812")[#text("series of papers")]#text("), ")#link("http://www.ams.org/mathscinet-getitem?mr=534820")[#text("Brenner")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=606174")[#text("Brenner-von Wahl")]#text("; to cut a long story short, one of the conclusions of these papers was that one had global regularity for equations such as ")#link(<tao-3455e95ef2bc60a57df4>)[#text("(1)")]#text(" in dimensions ")#mi("{d \\leq 9}")#text(". (I reprove this result using modern Strichartz estimate and Littlewood-Paley techniques in an appendix to my paper. The references given also allow for some growth in the nonlinearity ")#mi("{f}")#text(", but we will not detail the precise hypotheses used in these papers here.)")

#text("In my paper, I complement these positive results with an almost matching negative result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" If ")#mi("{d \\geq 11}")#text(" and ")#mi("{m \\geq 2}")#text(", then there exists a nonlinearity ")#mi("{f: {\\bf R}^m \\rightarrow {\\bf R}^m}")#text(" with all derivatives bounded, and a solution ")#mi("{u}")#text(" to ")#link(<tao-3455e95ef2bc60a57df4>)[#text("(1)")]#text(" that is smooth at time zero, but develops a singularity in finite time.")
]

#text("The construction crucially relies on the ability to choose the nonlinearity ")#mi("{f}")#text(", and also needs some injectivity properties on the solution ")#mi("{u: {\\bf R}^{1+d} \\rightarrow {\\bf R}^m}")#text(" (after making a symmetry reduction using an assumption of spherical symmetry to view ")#mi("{u}")#text(" as a function of ")#mi("{1+1}")#text(" variables rather than ")#mi("{1+d}")#text(") which restricts our counterexample to the ")#mi("{m \\geq 2}")#text(" case. Thus the model case of the higher-dimensional sine-Gordon equation ")#mi("{\\Box u =\\sin u}")#text(" is not covered by our arguments. Nevertheless (as with ")#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/")[#text("previous finite-time")]#text(" ")#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/")[#text("blowup results")]#text(" ")#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/")[#text("discussed on this blog")]#text("), one can view this result as a ")#emph[#text("barrier")]#text(" to trying to prove regularity for equations such as ")#mi("{\\Box u = \\sin u}")#text(" in eleven and higher dimensions, as any such argument must somehow use a property of that equation that is not applicable to the more general system ")#link(<tao-3455e95ef2bc60a57df4>)[#text("(1)")]#text(".")

#text("Let us first give some back-of-the-envelope calculations suggesting why there could be finite time blowup in eleven and higher dimensions. For sake of this discussion let us restrict attention to the sine-Gordon equation ")#mi("{\\Box u = \\sin u}")#text(". The blowup ansatz we will use is as follows: for each frequency ")#mi("{N_j}")#text(" in a sequence ")#mi("{1 < N_1 < N_2 < N_3 < \\dots}")#text(" of large quantities going to infinity, there will be a spacetime “cube” ")#mi("{Q_j = \\{ (t,x): t \\sim \\frac{1}{N_j}; x = O(\\frac{1}{N_j})\\}}")#text(" on which the solution ")#mi("{u}")#text(" oscillates with “amplitude” ")#mi("{N_j^\\alpha}")#text(" and “frequency” ")#mi("{N_j}")#text(", where ")#mi("{\\alpha>0}")#text(" is an exponent to be chosen later; this ansatz is of course compatible with the uncertainty principle. Since ")#mi("{N_j^\\alpha \\rightarrow \\infty}")#text(" as ")#mi("{j \\rightarrow \\infty}")#text(", this will create a singularity at the spacetime origin ")#mi("{(0,0)}")#text(". To make this ansatz plausible, we wish to make the oscillation of ")#mi("{u}")#text(" on ")#mi("{Q_j}")#text(" driven primarily by the forcing term ")#mi("{\\sin u}")#text(" at ")#mi("{Q_{j-1}}")#text(". Thus, by ")#link("https://en.wikipedia.org/wiki/Duhamel%27s_integral")[#text("Duhamel’s formula")]#text(", we expect a relation roughly of the form")

#align(center)[#tao-fit-display[#mitex("u(t,x) \\approx \\int \\frac{\\sin((s-t)\\sqrt{-\\Delta})}{\\sqrt{-\\Delta}} \\sin(1_{Q_{j-1}} u(s)) (x)\\ ds")]]

#text("on ")#mi("{Q_j}")#text(", where ")#mi("{\\frac{\\sin((s-t)\\sqrt{-\\Delta})}{\\sqrt{-\\Delta}}}")#text(" is the usual free wave propagator, and ")#mi("{1_{Q_{j-1}}}")#text(" is the indicator function of ")#mi("{Q_{j-1}}")#text(".")

#text("On ")#mi("{Q_{j-1}}")#text(", ")#mi("{u}")#text(" oscillates with amplitude ")#mi("{N_{j-1}^\\alpha}")#text(" and frequency ")#mi("{N_{j-1}}")#text(", we expect the derivative ")#mi("{\\nabla_{t,x} u}")#text(" to be of size about ")#mi("{N_{j-1}^{\\alpha+1}}")#text(", and so from the principle of stationary phase we expect ")#mi("{\\sin(u)}")#text(" to oscillate at frequency about ")#mi("{N_{j-1}^{\\alpha+1}}")#text(". Since the wave propagator ")#mi("{\\frac{\\sin((s-t)\\sqrt{-\\Delta})}{\\sqrt{-\\Delta}}}")#text(" preserves frequencies, and ")#mi("{u}")#text(" is supposed to be of frequency ")#mi("{N_j}")#text(" on ")#mi("{Q_j}")#text(" we are thus led to the requirement ")#metadata(none) <tao-a550708b48a6ed31c98b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("N_j \\approx N_{j-1}^{\\alpha+1}.")]]



#text(" Next, when restricted to frequencies of order ")#mi("{N_{j}}")#text(", the propagator ")#mi("{\\frac{\\sin((s-t)\\sqrt{-\\Delta})}{\\sqrt{-\\Delta}}}")#text(" “behaves like” ")#mi("{N_{j}^{\\frac{d-3}{2}} (s-t)^{\\frac{d-1}{2}} A_{s-t}}")#text(", where ")#mi("{A_{s-t}}")#text(" is the spherical averaging operator")

#align(center)[#tao-fit-display[#mitex("A_{s-t} f(x) := \\frac{1}{\\omega_{d-1}} \\int_{S^{d-1}} f(x + (s-t)\\theta)\\ d\\theta")]]

#text("where ")#mi("{d\\theta}")#text(" is surface measure on the unit sphere ")#mi("{S^{d-1}}")#text(", and ")#mi("{\\omega_{d-1}}")#text(" is the volume of that sphere. In our setting, ")#mi("{s-t}")#text(" is comparable to ")#mi("{1/N_{j-1}}")#text(", and so we have the informal approximation")

#align(center)[#tao-fit-display[#mitex("u(t,x) \\approx N_j^{\\frac{d-3}{2}} N_{j-1}^{-\\frac{d-1}{2}} \\int_{s \\sim 1/N_{j-1}} A_{s-t} \\sin(u(s))(x)\\ ds")]]

#text("on ")#mi("{Q_j}")#text(".")

#text("Since ")#mi("{\\sin(u(s))}")#text(" is bounded, ")#mi("{A_{s-t} \\sin(u(s))}")#text(" is bounded as well. This gives a (non-rigorous) upper bound")

#align(center)[#tao-fit-display[#mitex("u(t,x) \\lessapprox N_j^{\\frac{d-3}{2}} N_{j-1}^{-\\frac{d-1}{2}} \\frac{1}{N_{j-1}}")]]

#text("which when combined with our ansatz that ")#mi("{u}")#text(" has ampitude about ")#mi("{N_j^\\alpha}")#text(" on ")#mi("{Q_j}")#text(", gives the constraint")

#align(center)[#tao-fit-display[#mitex("N_j^\\alpha \\lessapprox N_j^{\\frac{d-3}{2}} N_{j-1}^{-\\frac{d-1}{2}} \\frac{1}{N_{j-1}}")]]

#text("which on applying ")#link(<tao-a550708b48a6ed31c98b>)[#text("(2)")]#text(" gives the further constraint")

#align(center)[#tao-fit-display[#mitex("\\alpha(\\alpha+1) \\leq \\frac{d-3}{2} (\\alpha+1) - \\frac{d-1}{2} - 1")]]

#text("which can be rearranged as")

#align(center)[#tao-fit-display[#mitex("\\left(\\alpha - \\frac{d-5}{4}\\right)^2 \\leq \\frac{d^2-10d-7}{16}.")]]

#text("It is now clear that the optimal choice of ")#mi("{\\alpha}")#text(" is")

#align(center)[#tao-fit-display[#mitex("\\alpha = \\frac{d-5}{4},")]]

#text("and this blowup ansatz is only self-consistent when")

#align(center)[#tao-fit-display[#mitex("\\frac{d^2-10d-7}{16} \\geq 0")]]

#text("or equivalently if ")#mi("{d \\geq 11}")#text(".")

#text("To turn this ansatz into an actual blowup example, we will construct ")#mi("{u}")#text(" as the sum of various functions ")#mi("{u_j}")#text(" that solve the wave equation with forcing term in ")#mi("{Q_{j+1}}")#text(", and which concentrate in ")#mi("{Q_j}")#text(" with the amplitude and frequency indicated by the above heuristic analysis. The remaining task is to show that ")#mi("{\\Box u}")#text(" can be written in the form ")#mi("{f(u)}")#text(" for some ")#mi("{f}")#text(" with all derivatives bounded. For this one needs some injectivity properties of ")#mi("{u}")#text(" (after imposing spherical symmetry to impose a dimensional reduction on the domain of ")#mi("{u}")#text(" from ")#mi("{d+1}")#text(" dimensions to ")#mi("{1+1}")#text("). This requires one to construct some solutions to the free wave equation that have some unusual restrictions on the range (for instance, we will need a solution taking values in the plane ")#mi("{{\\bf R}^2}")#text(" that avoid one quadrant of that plane). In order to do this we take advantage of the very explicit nature of the fundamental solution to the wave equation in odd dimensions (such as ")#mi("{d=11}")#text("), particularly under the assumption of spherical symmetry. Specifically, one can show that in odd dimension ")#mi("{d}")#text(", any spherically symmetric function ")#mi("{u(t,x) = u(t,r)}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("u(t,r) = \\left(\\frac{1}{r} \\partial_r\\right)^{\\frac{d-1}{2}} (g(t+r) + g(t-r))")]]

#text("for an arbitrary smooth function ")#mi("{g: {\\bf R} \\rightarrow {\\bf R}^m}")#text(", will solve the free wave equation; this is ultimately due to iterating the “")#link("https://en.wikipedia.org/wiki/Ladder_operator")[#text("ladder operator")]#text("” identity")

#align(center)[#tao-fit-display[#mitex("\\left( \\partial_{tt} + \\partial_{rr} + \\frac{d-1}{r} \\partial_r \\right) \\frac{1}{r} \\partial_r = \\frac{1}{r} \\partial_r \\left( \\partial_{tt} + \\partial_{rr} + \\frac{d-3}{r} \\partial_r \\right).")]]

#text("This precise and relatively simple formula for ")#mi("{u}")#text(" allows one to create “bespoke” solutions ")#mi("{u}")#text(" that obey various unusual properties, without too much difficulty.")

#text("It is not clear to me what to conjecture for ")#mi("{d=10}")#text(". The blowup ansatz given above is a little inefficient, in that the frequency ")#mi("{N_{j+1}}")#text(" component of the solution is only generated from a portion of the ")#mi("{N_j}")#text(" component, namely the portion close to a certain light cone. In particular, the solution does not saturate the Strichartz estimates that are used to establish the positive results for ")#mi("{d \\leq 9}")#text(", which helps explain the slight gap between the positive and negative results. It may be that a more complicated ansatz could work to give a negative result in ten dimensions; conversely, it is also possible that one could use more advanced estimates than the Strichartz estimate (that somehow capture the “thinness” of the fundamental solution, and not just its dispersive properties) to stretch the positive results to ten dimensions. Which side the ")#mi("{d=10}")#text(" case falls in all come down to some rather delicate numerology.")

#text("…")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cde49d386bd86f35f2745c247aa3023bbc0baa038fa002ba4280cf324a3d1bf-eeab2c366d01e45ea1d2a2b747f624c28864a3e91d2a9dbd18805bdd3422a0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mustaliblog")]], [#link("https://terrytao.wordpress.com/2016/03/08/finite-time-blowup-for-high-dimensional-nonlinear-wave-systems-with-bounded-smooth-nonlinearity/#comment-466736")[#strong[#text("mustaliblog")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2016")])]

#text("Impressive. this just tickles my mathematical imagination")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2016/03/08/finite-time-blowup-for-high-dimensional-nonlinear-wave-systems-with-bounded-smooth-nonlinearity/#comment-466761")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2016")])]

#text("I don’t understand why you are so careful. No physicist in his right mind knows or cares what a ")#mi("L^t_\\infty H_x^1")#text(" whos-a-whatsit space is.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/427dec019c6c02612758c0254b62bf919f69d7b58053e628a51571479408f198-7594e3e4723ff9d1d64d36c34b5203a382a6f14aa2a79e21e465d0528440af70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dcohen")]], [#link("https://terrytao.wordpress.com/2016/03/08/finite-time-blowup-for-high-dimensional-nonlinear-wave-systems-with-bounded-smooth-nonlinearity/#comment-466869")[#strong[#text("dcohen")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2016")])]

#text("line 11, it should be “d’Alembertian”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2016/03/08/finite-time-blowup-for-high-dimensional-nonlinear-wave-systems-with-bounded-smooth-nonlinearity/#comment-466929")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2016")])]

#text("Start of second paragraph before Theorem 1 should be “In” not “Im”; In paragraph after Theorem 1 should be “u as” not “u mas”")#linebreak()#text(" Paper Proposition 3.2 starts with (iii) not (i), but late on page 17 you refer to 3.2(i)")#linebreak()#text(" Paper page 12, definition of $\\hat\\omega$ should have dx, not d\\xi")

#emph[#text("[Corrected, thanks; the paper corrections will appear in the next revision of the ms. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Finite time blowup for Lagrangian modifications of the three-dimensional Euler equation | What's new")]], [#link("https://terrytao.wordpress.com/2016/03/08/finite-time-blowup-for-high-dimensional-nonlinear-wave-systems-with-bounded-smooth-nonlinearity/#comment-470145")[#strong[#text("Finite time blowup for Lagrangian modifications of the three-dimensional Euler equation | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2016")])]

#text("[…] of the three-dimensional Euler equation“. This paper is loosely in the spirit of other recent papers of mine in which I explore how close one can get to supercritical PDE of physical interest (such as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Finite time blowup for a supercritical defocusing nonlinear Schrodinger system | What's new")]], [#link("https://terrytao.wordpress.com/2016/03/08/finite-time-blowup-for-high-dimensional-nonlinear-wave-systems-with-bounded-smooth-nonlinearity/#comment-474870")[#strong[#text("Finite time blowup for a supercritical defocusing nonlinear Schrodinger system | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2016")])]

#text("[…] in higher dimensions one only knows global well-posedness instead of global regularity. See this previous post for some exploration of this issue in the context of nonlinear wave equations.) The main result of […]")
]
