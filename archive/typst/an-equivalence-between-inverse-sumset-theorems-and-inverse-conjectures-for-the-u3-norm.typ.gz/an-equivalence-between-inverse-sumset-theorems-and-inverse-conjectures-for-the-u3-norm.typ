// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/06/20/an-equivalence-between-inverse-sumset-theorems-and-inverse-conjectures-for-the-u3-norm/
// Converted to Typst by tao2typ: "2026-10-14T16:35:47.394684+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An equivalence between inverse sumset theorems and inverse conjectures for the U^3 norm", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An equivalence between inverse sumset theorems and inverse conjectures for the U^3 norm")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 June 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/06/20/an-equivalence-between-inverse-sumset-theorems-and-inverse-conjectures-for-the-u3-norm/")[#text("https://terrytao.wordpress.com/2009/06/20/an-equivalence-between-inverse-sumset-theorems-and-inverse-conjectures-for-the-u3-norm/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("For a number of reasons, including the start of the summer break for me and my coauthors, a number of papers that we have been working on are being released this week. For instance, ")#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(" and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/0906.3100")[#text("An equivalence between inverse sumset theorems and inverse conjectures for the ")#mi("U^3")#text(" norm")]#text("“, submitted to ")#link("http://journals.cambridge.org/action/displayJournal?jid=PSP")[#text("Math. Proc. Camb. Phil. Soc.")]#text(". The main result of this short paper (which was briefly announced in ")#link("https://terrytao.wordpress.com/2008/11/09/a-counterexample-to-a-strong-polynomial-freiman-ruzsa-conjecture/")[#text("this earlier post")]#text(") is a connection between two types of inverse theorems in additive combinatorics, namely the ")#emph[#text("inverse sumset theorems")]#text(" of Freiman type, and ")#emph[#text("inverse theorems for the Gowers uniformity norm")]#text(", and more specifically, for the ")#mi("U^3")#text(" norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^3(G)}^8 := {\\Bbb E}_{x,a,b,c \\in G} f(x) \\overline{f(x+a)} \\overline{f(x+b)} \\overline{f(x+c)} f(x+a+b) f(x+a+c) f(x+b+c) \\overline{f(x+a+b+c)}", block: true)]]

#text("on finite additive group G, where ")#mi("f: G \\to {\\Bbb C}")#text(" is a complex-valued function.")

#text("As usual, the connection is easiest to state in a finite field model such as ")#mi("G = {\\Bbb F}_2^n")#text(". In this case, we have the following inverse sumset theorem ")#link("http://www.ams.org/mathscinet-getitem?mr=1701207")[#text("of Ruzsa")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" If ")#mi("A \\subset {\\Bbb F}_2^n")#text(" is such that ")#tao-math("\\left|A+A\\right| \\leq K\\left|A\\right|", block: false)#text(", then A can be covered by a translate of a subspace of ")#mi("{\\Bbb F}_2^n")#text(" of cardinality at most ")#tao-math("K^2 2^{K^4} \\left|A\\right|", block: false)#text(".")
]

#text("The constant ")#mi("K^2 2^{K^4}")#text(" has been improved for large ")#mi("K")#text(" in a sequence of papers, from ")#mi("K 2^{\\lfloor K^3 \\rfloor-1}")#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2057683")[#text("by Ruzsa")]#text(", ")#mi("K^2 2^{K^2-2}")#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2201602")[#text("by Green-Ruzsa")]#text(", ")#mi("2^{O(K^{3/2} \\log(1+K)}")#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2396355")[#text("by Sanders")]#text(", ")#mi("2^{2K+O(\\sqrt{K} \\log K})")#text(" ")#link("http://arxiv.org/abs/math.CO/0703668")[#text("by Green and myself")]#text(", and finally ")#mi("2^{2K+O(\\log K)}")#text(" by Konyagin (private communication) which is sharp except for the precise value of the O() implied constant (as can be seen by considering the example when A consists of about 2K independent elements). However, it is conjectured that the polynomial loss can be removed entirely if one modifies the conclusion slightly:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1. (Polynomial Freiman-Ruzsa conjecture for ")#mi("{\\Bbb F}_2^n")#text(".) ")]#text("If ")#mi("A \\subset {\\Bbb F}_2^n")#text(" is such that ")#tao-math("\\left|A+A\\right| \\leq K\\left|A\\right|", block: false)#text(", then A can be covered by ")#mi("O(K^{O(1)})")#text(" translates of subspaces of ")#mi("{\\Bbb F}_2^n")#text(" of cardinality at most |A|.")
]

#text("This conjecture was verified for downsets ")#link("http://arxiv.org/abs/math.CO/0703668")[#text("by Green and myself")]#text(", but is open in general. This conjecture has a number of equivalent formulations; see ")#link("http://www.ams.org/mathscinet-getitem?mr=2187732")[#text("this paper of Green")]#text(" for more discussion. In ")#link("https://terrytao.wordpress.com/2008/11/09/a-counterexample-to-a-strong-polynomial-freiman-ruzsa-conjecture/")[#text("this previous post")]#text(" we show that a stronger version of this conjecture fails.")

#text("Meanwhile, for the Gowers norm, we have the following inverse theorem, ")#link("http://www.cs.huji.ac.il/~salex/papers/low_degree.ps")[#text("due to Samorodnitsky")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2. ")]#text(" Let ")#mi("f: {\\Bbb F}_2^n \\to [-1,1]")#text(" be a function whose ")#mi("U^3")#text(" norm is at least 1/K. Then there exists a quadratic polynomial ")#mi("Q: {\\Bbb F}_2^n \\to {\\Bbb F}_2")#text(" such that ")#tao-math("\\left|{\\Bbb E}_{x \\in {\\Bbb F}_2^n} f(x) (-1)^{Q(x)}\\right| \\geq \\exp( - O(K)^{O(1)} )", block: false)#text(".")
]

#text("Note that the quadratic phases ")#mi("(-1)^{Q(x)}")#text(" are the only functions taking values in [-1,1] whose ")#mi("U^3")#text(" norm attains its maximal value of 1.")

#text("It is conjectured that the exponentially weak correlation here can be strengthened to a polynomial one:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 2. (Polynomial inverse conjecture for the ")#mi("U^3({\\Bbb F}_2^n)")#text(" norm).")]#text(" Let ")#mi("f: {\\Bbb F}_2^n \\to [-1,1]")#text(" be a function whose ")#mi("U^3")#text(" norm is at least 1/K. Then there exists a quadratic polynomial ")#mi("Q: {\\Bbb F}_2^n \\to {\\Bbb F}_2")#text(" such that ")#tao-math("\\left|{\\Bbb E}_{x \\in {\\Bbb F}_2^n} f(x) (-1)^{Q(x)}\\right| \\geq K^{-O(1)}", block: false)#text(".")
]

#text("The first main result of this paper is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3.")]#text(" Conjecture 1 and Conjecture 2 are equivalent.")
]

#text("This result was also independently observed by Shachar Lovett (private communication). We also establish an analogous result for the cyclic group ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(", in which the notion of polynomial is replaced by that of a subexponential ")#mi("\\exp(K^{o(1)})")#text(", and in which the notion of a quadratic polynomial is replaced by a 2-step nilsequence; the precise statement is a bit technical and will not be given here. We also observe a partial partial analogue of the correpsondence between inverse sumset theorems and Gowers norms in the higher order case, in particular observing that ")#mi("U^4")#text(" inverse theorems imply a certain rigidity result for “Freiman-quadratic polynomials” (a quadratic version of Conjecture 3 below).")

#text("Below the fold, we sketch the proof of Theorem 3.")

#metadata(none) <tao-38562246f658df1e61c5>

#text("The deduction of Conjecture 2 from Conjecture 1 is already implicit in the ")#link("http://www.cs.huji.ac.il/~salex/papers/low_degree.ps")[#text("work of Samorodnitsky")]#text(", so we focus here on the converse implication. It is convenient to put Conjecture 1 in the following equivalent form:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 3. ")]#text(" (Polynomial rigidity of Freiman homomorphisms) Let ")#mi("S \\subset {\\Bbb F}_2^m")#text(" have density ")#mi("\\sigma")#text(", and let ")#mi("\\phi: S \\to {\\Bbb F}_2^N")#text(" be a ")#emph[#text("Freiman homomorphism")]#text(", thus ")#mi("\\phi(x)+\\phi(y) = \\phi(z)+\\phi(w)")#text(" whenever ")#mi("x,y,z,w \\in S")#text(" are such that ")#mi("x+y=z+w")#text(". Then there exists an affine-linear map ")#mi("\\psi: {\\Bbb F}_2^m \\to {\\Bbb F}_2^N")#text(" which agrees with ")#mi("\\phi")#text(" on at least ")#mi("\\gg \\sigma^{-O(1)} 2^m")#text(" elements of ")#mi("{\\Bbb F}_2^m")#text(".")
]

#text("The implication of Conjecture 1 from Conjecture 3 was observed by Ruzsa; basically, the idea is to use the random projection trick (cf. ")#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/")[#text("this post")]#text(") to view the set A in Conjecture 1 as a graph of a function ")#mi("\\phi")#text(" over a base ")#mi("{\\Bbb F}_2^m")#text(" of cardinality roughly comparable to |A|.")

#text("To deduce Conjecture 3 from Conjecture 2, we encode the Freiman homomorphism ")#mi("\\phi")#text(" as a function ")#mi("f: {\\Bbb F}_2^m \\times {\\Bbb F}_2^N \\to \\{-1,+1\\}")#text(", defined by the formula")

#align(center)[#tao-fit-display[#mitex("f(x,y) := 1_S(x) (-1)^{\\phi(x) \\cdot y},")]]

#text("thus f is the vertical Fourier transform of the graph of ")#mi("\\phi")#text(". A Fourier-analytic computation using the Freiman homomorphism property of ")#mi("\\phi")#text("and some standard applications of the Cauchy-Schwartz inequality shows that ")#mi("f")#text(" has a large ")#mi("U^3")#text(" norm (of size at least ")#mi("\\sigma")#text(", in fact). Applying Conjecture 2, we conclude that f must polynomially correlate with some quadratic function ")#mi("\\Psi: {\\Bbb F}_2^m \\times {\\Bbb F}_2^N")#text(". Separating the x and y coordinates, this implies that for a polynomially dense set of values of x, the linear phase ")#mi("(-1)^{\\phi(x) \\cdot y}")#text(" in y has polynomial correlation with a quadratic polynomial ")#mi("(-1)^{\\Psi(0,y) + \\psi(x) \\cdot y}")#text(", where ")#mi("\\psi: {\\Bbb F}_2^m \\to {\\Bbb F}_2^N")#text(" is affine-linear and ")#mi("\\Psi")#text(" is some quadratic polynomial on ")#mi("{\\Bbb F}_2^N")#text(" which is independent of x. To put it another way, ")#mi("(-1)^{\\Psi(0,y)}")#text(" has a polynomially large Fourier coefficient at ")#mi("\\phi(x)-\\psi(x)")#text(" for many x. But Plancherel’s theorem shows that there can only be polynomially many such large Fourier coefficients, so by the pigeonhole principle, ")#mi("\\phi(x)-\\psi(x)")#text(" is equal to a constant for a polynomially dense set of x, and the claim follows.")

#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2009/06/20/an-equivalence-between-inverse-sumset-theorems-and-inverse-conjectures-for-the-u3-norm/#comment-39653")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2009")])]

#text("Terry,")

#text("I think Sergei Konyagin has published his nice improvement of our result about Freiman in F_2^n. It’s in a recent edition of Mat. Zametki.")

#text("Best")#linebreak()#text(" Ben")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92f1228272953f345d03a05d0e93fd1965c0d42c46db72585086e5be929239f5-7321f0321a762d29957d00eaf87c956bcfb368c0b47e8ee9fb03ebe623a45f9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maxbaroi")]], [#link("https://terrytao.wordpress.com/2009/06/20/an-equivalence-between-inverse-sumset-theorems-and-inverse-conjectures-for-the-u3-norm/#comment-39655")[#strong[#text("maxbaroi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2009")])]

#text("Dear Professor Tao,")

#text("Out of curiosity, what is the intuition or motivation behind the Gower norms? The form of the product of the ")#mi("k")#text("-th Gower norm is reminiscent of the formula for the cardinality of the union of ")#mi("k")#text(" finite sets, but I don’t have a grasp of what the $2^k$th-root of the average value of that product measures about a function the way I understand, say, the sup-norm measures “height.”")

#text("Thanks for any reply.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/20/an-equivalence-between-inverse-sumset-theorems-and-inverse-conjectures-for-the-u3-norm/#comment-39692")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2009")])]

#text("Dear Max,")

#text("In the model case of a phase function ")#mi("f(x) = \\exp( 2\\pi i \\phi(x) )")#text(", the ")#mi("k^{th}")#text(" Gowers norm measures the oscillation of the ")#mi("k^{th}")#text(" derivative (or more precisely, ")#mi("k^{th}")#text(" difference) ")#mi("\\Delta_{h_1} \\ldots \\Delta_{h_k} \\phi(x)")#text(", where ")#mi("\\Delta_h \\phi(x) := \\phi(x+h)-\\phi(x)")#text(". So the Gowers norm is large when the ")#mi("k^{th}")#text(" derivative is small, in particular phases which are polynomial of degree at most k-1 have a large Gowers norm. In the original paper of Gowers where these norms are introduced, it is mentioned that these norms have some faint resemblance to Sobolev norms because of this connection with iterated derivatives, though the relationship is sort of inverted because the Gowers norms become _large_ rather than _small_ when the derivatives become small.")

#text("The inverse conjecture for the Gowers norm is essentially asserting that ")#mi("k^{th}")#text(" Gowers norm measures the extent to which the phase of a function behaves like a polynomial of degree <k (though in the integer case, one has to work with more technical generalisations of the concept of a polynomial, such as bracket polynomials or nilsequences).")

#text("Dear anonymous: I do not know of any serious proposal for a fractional Gowers norm. Given the discrete and combinatorial nature of these norms, the situation seems a bit different from the Sobolev norm setting, in which one can use the underlying real or complex structure to define fractional differentiation operators.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/20/an-equivalence-between-inverse-sumset-theorems-and-inverse-conjectures-for-the-u3-norm/#comment-39672")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2009")])]

#text("Can one meaningfully define U^p norms for p not an integer?")
]
