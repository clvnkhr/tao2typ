// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/06/06/285g-lecture-19-the-structure-of-ricci-flow-at-the-singular-time-surgery-and-the-poincare-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T07:00:30.587314+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "285G, Lecture 19: The structure of Ricci flow at the singular time, surgery, and the Poincaré conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("285G, Lecture 19: The structure of Ricci flow at the singular time, surgery, and the Poincaré conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 June 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/06/06/285g-lecture-19-the-structure-of-ricci-flow-at-the-singular-time-surgery-and-the-poincare-conjecture/")[#text("https://terrytao.wordpress.com/2008/06/06/285g-lecture-19-the-structure-of-ricci-flow-at-the-singular-time-surgery-and-the-poincare-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("In the previous lecture, we studied high curvature regions of Ricci flows ")#mi("t \\mapsto (M,g(t))")#text(" on some time interval ")#mi("{}[0,T)")#text(", and concluded that (as long as a mild topological condition was obeyed) they all had canonical neighbourhoods. This is enough control to now study the limits of such flows as one approaches the singularity time T. It turns out that one can subdivide the manifold M into a ")#emph[#text("continuing region")]#text(" C in which the geometry remains well behaved (for instance, the curvature does not blow up, and in fact converges smoothly to an (incomplete) limit), and a ")#emph[#text("disappearing region")]#text(" D, whose topology is well controlled. (For instance, the interface ")#mi("\\Sigma")#text(" between C and D will be a finite union of disjoint surfaces homeomorphic to ")#mi("S^2")#text(".) This allows one (at the topological level, at least) to perform surgery on the interface ")#mi("\\Sigma")#text(", removing the disappearing region D and replacing them with a finite number of “caps” homeomorphic to the 3-ball ")#mi("B^3")#text(". The relationship between the topology of the post-surgery manifold and pre-surgery manifold is as is described way back in ")#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/")[#text("Lecture 2")]#text(".")

#text("However, once surgery is completed, one needs to restart the Ricci flow process, at which point further singularities can occur. In order to apply surgery to these further singularities, we need to check that all the properties we have been exploiting about Ricci flows – notably the Hamilton-Ivey pinching property, the ")#mi("\\kappa")#text("-noncollapsing property, and the existence of canonical neighbourhoods for every point of high curvature – persist even in the presence of a large number of surgeries (indeed, with the way the constants are structured, all quantitative bounds on a fixed time interval [0,T] have to be uniform in the number of surgery times, although we will of course need the set of such times to be discrete). To ensure that surgeries do not disrupt any of these properties, it turns out that one has to perform these surgeries deep in certain ")#mi("\\varepsilon")#text("-horns of the Ricci flow at the singular time, in which the geometry is extremely close to being cylindrical (in particular, it should be a ")#mi("\\delta")#text("-neck and not just a ")#mi("\\varepsilon")#text("-neck, where the surgery control parameter ")#mi("\\delta")#text(" is much smaller than ")#mi("\\varepsilon")#text("; selection of this parameter can get a little tricky if one wants to evolve Ricci flow with surgery indefinitely, although for the purposes of the Poincaré conjecture the situation is simpler as there is a fixed upper bound on the time for which one needs to evolve the flow). Furthermore, the geometry of the manifolds one glues in to replace the disappearing regions has to be carefully chosen (in particular, it has to not disrupt the pinching condition, and the geometry of these glued in regions has to resemble a ")#mi("(C,\\varepsilon)")#text("-cap for a significant amount of (rescaled) time). The construction of the “standard solution” needed to achieve all these properties is somewhat delicate, although we will not discuss this issue much here.")

#text("In this, the final lecture, we shall present these issues from a high-level perspective; due to lack of time and space we will not cover the finer details of the surgery procedure. More detailed versions of the material here can be found in ")#link("http://arxiv.org/abs/math.DG/0303109")[#text("Perelman’s second paper")]#text(", the ")#link("http://arxiv.org/abs/math.DG/0605667")[#text("notes of Kleiner-Lott")]#text(", the ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("book of Morgan-Tian")]#text(", and the paper of ")#link("http://arxiv.org/abs/math/0612069")[#text("Cao-Zhu")]#text(". (See also a forthcoming paper of Bessières, Besson, Boileau, Maillot, and Porti.)")

#metadata(none) <tao-27a2e80268b3706c51f8>

#heading(level: 1)[#text("— Ricci flow at the singular time —")]

#text("Suppose we have a compact 3-dimensional Ricci flow ")#mi("t \\mapsto (M,g(t))")#text(" on the time interval ")#mi("{}[0,T)")#text(" without any embedded ")#mi("\\Bbb{RP}^2")#text(" with trivial normal bundle; for simplicity we can take M to be connected (otherwise we simply treat each of the finite number of connected components of M separately). We are interested in the extent to which we can define a limiting geometry g(T) on M (or on some subset of M) at the final time T, and to work out the topological structure of the portions of M for which such a limit cannot be defined.")

#text("From Theorem 1 of Lecture 18, we know that any point ")#mi("(t,x) \\in [0,T) \\times M")#text(" for which the curvature R(t,x) exceeds a certain threshold K, will lie in a canonical neighbourhood. (For sake of discussion we shall suppress the constants C and ")#mi("\\varepsilon")#text(", as they will not play a major role in what follows.) One consequence of this is that one has the pointwise bounds")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\nabla R = O( R^{3/2} ); \\quad R_t = O(R^2)")]]

#text("whenever ")#mi("R \\geq K")#text(". Also recall from the maximum principle that we have ")#mi("R \\geq -O(1)")#text(" throughout.")

#text("These simple regularity properties of the scalar curvature R are already enough to classify the limiting behaviour of ")#mi("R(t,x)")#text(" as ")#mi("t \\to T")#text(" for each fixed x:")

#strong[#text("Exercise 1.")]#text(" Using (1), show that for every ")#mi("x \\in M")#text(" there are either two possibilities: either ")#mi("R(t,x)")#text(" remains bounded as ")#mi("t \\to T")#text(" (with a bound that can depend on x), or that ")#mi("R(t,x)")#text(" goes to infinity as ")#mi("t \\to T")#text(", and in the latter case we even have the stronger statement ")#mi("\\lim_{t \\to T} (T-t) R(t,x) > c")#text(" for some c depending only on the implied constant in (1). If we let ")#mi("\\Omega \\subset M")#text(" be the set of x for which ")#mi("R(t,x)")#text(" remains bounded, show that ")#mi("\\Omega")#text(" is open, and ")#mi("R(t,\\cdot)")#text(" converges uniformly on compact subsets of ")#mi("\\Omega")#text(" to some limit ")#mi("R(T,\\cdot)")#text(" as ")#mi("t \\to T")#text(". ")#mi("\\diamond")

#text("The pinching property also lets us establish bounds of the form ")#tao-math("\\text{Riem} = O(1 + \\left|R\\right|)", block: false)#text(". Using this and Shi’s regularity estimates (and the non-collapsing property), one can show that ")#mi("(\\Omega, g(t))")#text(" converges in ")#mi("C^\\infty")#text(" on compact subsets of ")#mi("\\Omega")#text(" to an incomplete limit ")#mi("(\\Omega, g(T))")#text(".")

#text("Our main tasks here are to understand the geometry of the limit ")#mi("(\\Omega, g(T))")#text(", and the topology of the remaining region ")#mi("M \\backslash \\Omega")#text(" (and how the two regions connect to each other).")

#text("If ")#mi("\\Omega")#text(" is all of M, then the Ricci flow continues smoothly to time T, and we can continue onwards beyond T by the local existence theory for that flow. Now let us instead consider the other extreme case in which ")#mi("\\Omega")#text(" is empty. In this case, from Exercise 1 we see that we have ")#mi("R(t,x) \\geq K")#text(" for all ")#mi("x \\in M")#text(", if t is sufficiently close to T. In particular, this means that ")#emph[#text("every")]#text(" point in M lies in a canonical neighbourhood: an ")#mi("\\varepsilon")#text("-round component (topologically ")#mi("S^3/\\Gamma")#text("), a C-component (topologically ")#mi("S^3")#text(" or ")#mi("\\Bbb{RP}^3")#text("), a ")#mi("\\varepsilon")#text("-neck (topologically ")#mi("{}[-1,1] \\times S^2")#text("), or a ")#mi("(C,\\varepsilon)")#text("-cap (topologically a 3-ball or punctured ")#mi("\\Bbb{RP}^3")#text("). If any point lies in the first type of canonical neighbourhoods, then M is topologically a spherical space form ")#mi("S^3/\\Gamma")#text(". Similarly, if any point lies in the second type, M is either an ")#mi("S^3")#text(" or ")#mi("\\Bbb{RP}^3")#text(" this way. So the only remaining case left is when every point lies in a neck or a cap. Since each cap contains at least one neck in it, we have at least one neck; following this neck in both directions, we either must end up with a doubly capped tube, or the tube must eventually connect back to itself. In the former case we obtain an ")#mi("S^3")#text(", ")#mi("\\Bbb{RP}^3")#text(", or ")#mi("\\Bbb{RP}^3 \\# \\Bbb{RP}^3")#text(" (depending on whether zero, one, or two of the caps are punctured ")#mi("\\Bbb{RP}^3")#text("‘s rather than 3-balls); in the latter case, we get an ")#mi("S^2")#text(" bundle over ")#mi("S^1")#text(", which as discussed back in ")#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/")[#text("Lecture 2")]#text(" comes in only two topological types, oriented and unoriented.")

#text("To summarise, if ")#mi("\\Omega")#text(" is empty, then M is either a spherical space form,")#linebreak()#text(" ")#mi("\\Bbb{RP}^3 \\# \\Bbb{RP}^3")#text(", or an ")#mi("S^2")#text(" bundle over ")#mi("S^1")#text(". In this case, the surgery procedure is simply to delete the entire manifold; this respects the topological compatibility condition required for Theorem 2 of ")#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/")[#text("Lecture 2")]#text(". (The geometric compatibility condition is moot in this case.) In this case, the disappearing region is the whole manifold M, and the continuing region is empty.")

#text("Similar considerations occur if ")#mi("\\Omega")#text(" is non-empty, but that ")#mi("R(T,x) \\geq 2K")#text(" (say) for all ")#mi("x \\in \\Omega")#text(". So we may assume that there is at least one x for which ")#mi("R(T,x) < 2K")#text(", and thus ")#mi("R(t,x) < 2K")#text(" for all t sufficiently close to T. Thus we are guaranteed at least one point of bounded curvature in M, even at times close to the singular time. We can also assume that no canonical neighbourhood in M is an ")#mi("\\varepsilon")#text("-round or C-component, since again in this case we could delete the entire manifold by surgery. Thus every point of curvature greater than K lies in a neck or a cap.")

#text("Because of this, it is not hard to show that every boundary point of ")#mi("\\Omega")#text(" (where ")#mi("R(T,x)")#text(" becomes infinite) lies at the end of an ")#emph[#mi("\\varepsilon")#text("-horn")]#text(":a tube of ")#mi("\\varepsilon")#text("-necks of curvature at least 4K (say) throughout, with the curvature becoming infinite at one or both ends (thus the width of the necks go to zero as one approaches the boundary of ")#mi("\\Omega")#text("). (Note that if the tube is ever capped off by a ")#mi("(C,\\varepsilon)")#text("-cap, then the curvature does not go to infinity in this tube.) If the curvature goes to infinity at both ends, we have a ")#emph[#text("double ")#mi("\\varepsilon")#text("-horn")]#text("; otherwise, we have a ")#emph[#text("single ")#mi("\\varepsilon")#text("-horn")]#text(" will have one infinite curvature end and one end with bounded curvature.")

#text("The single ")#mi("\\varepsilon")#text("-horns are all disjoint from each other, and their volume is bounded from below, and so they are finite in number. So the geometric picture of ")#mi("(\\Omega,g(T))")#text(" is that of a (possibly infinite) number of double ")#mi("\\varepsilon")#text("-horns, together with a finite number of additional connected incomplete manifolds, with boundary consisting of a finite number of disjoint spheres ")#mi("S^2")#text(", with a single ")#mi("\\varepsilon")#text("-horn glued on to each one of these spheres.")

#text("Suppose one performs a topological surgery on each single ")#mi("\\varepsilon")#text("-horn, by taking a sphere ")#mi("S^2")#text(" somewhere in the middle of each horn, removing the portion between that ")#mi("S^2")#text(" and the boundary, and replacing it by a 3-ball. We also remove all the double ")#mi("\\varepsilon")#text("-horns; all the removed regions form the disappearing region of M, and the remainder is the continuing region. This creates a new compact (but possibly disconnected) manifold ")#mi("M(T)")#text(", formed by gluing finitely many 3-balls to the continuing region. To see the topological relationship between this new manifold and the previous manifold M, we move backwards in time a slight amount to an earlier time t, so that the horn is no longer singular at its boundary and instead connects to the remainder ")#mi("M\\backslash \\Omega")#text(" of the manifold. If t is close enough to T, then (by (1)), the portion of the horn between the ")#mi("S^2")#text(" and the boundary of the horn will still have curvature at least K, and thus every point here will lie in a neck or cap. Also, all the points in ")#mi("M \\backslash \\Omega")#text(", and in particular the portion of the manifold beyond the boundary of the horn, will also have curvature at least K and thus lie in a neck or cap if t is close enough to T. If we then follow this desingularised horn from the surgery sphere ")#mi("S^2")#text(" towards its boundary and beyond (possibly passing through any number of double ")#mi("\\varepsilon")#text("-horns in the process), we will either discover a capped tube (which is thus topologically either a 3-ball or a punctured ")#mi("\\Bbb{RP}^3")#text("), or else the tube will eventually connect to another surgery sphere, which may or may not lie in the same connected component of M(T). Topologically, the first case corresponds to taking a ")#link("http://en.wikipedia.org/wiki/Connected_sum")[#text("connected sum")]#text(" of (one component of) M(T) with either a sphere ")#mi("S^3")#text(" or a projective space ")#mi("\\Bbb{RP}^3")#text("; the second case corresponds to taking a connected sum of one component of M(T) with either another component of M(T), or with an ")#mi("S^2")#text("-bundle over ")#mi("S^1")#text(". Putting all this together we see that M is the connected sum of the components of M(T), together with finitely many ")#mi("S^3")#text("‘s, ")#mi("\\Bbb{RP}^3")#text("‘s, and ")#mi("S^2")#text("-bundles over ")#mi("S^1")#text(", which again gives the topological compatibility condition required for Theorem 2 of ")#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/")[#text("Lecture 2")]#text(".")

#text("We have thus successfully performed a single (topological) surgery. However, in doing so we have lost a lot of ")#emph[#text("quantitative")]#text(" properties of the geometry, such as Hamilton-Ivey pinching, ")#mi("\\kappa")#text("-noncollapsing, and the canonical neighbourhood property, which means that we cannot yet ensure that we can perform any further surgeries. To resolve this problem, we need to be more precise about the surgery process, in particular using our freedom to choose the surgery sphere as deep inside the ")#mi("\\varepsilon")#text("-horn as we please, and to prescribe the metric on the cap that we attach to that sphere.")

#heading(level: 1)[#text("— Surgery —")]

#text("To do surgery, a key observation of Perelman is that the geometry of the horn becomes increasingly cylindrical as one goes deeper into the horn:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" Let H be a single ")#mi("\\varepsilon")#text("-horn which has width scale comparable to r at the finite curvature end, and let ")#mi("\\delta > 0")#text(". Then there exists a ")#mi("\\delta")#text("-neck of width scale comparable to h inside the horn H, where ")#mi("h = h(r,\\delta) > 0")#text(" is a small quantity depending only on r and ")#mi("\\delta")#text(".")
]

#strong[#text("Proof.")]#text(" (Sketch) Suppose this was not the case; then one could find a sequence of horns ")#mi("H_n")#text(" of this type, and a sequence of points ")#mi("x_n")#text(" inside these horns inside ")#mi("\\varepsilon")#text("-necks of width scale comparable to ")#mi("h_n")#text(" which are not inside ")#mi("\\delta")#text("-necks of this scale, where ")#mi("h_n \\to 0")#text(". We can find a minimising geodesic from the finite curvature end to the infinite curvature end that goes through the neck near ")#mi("x_n")#text(". We then rescale ")#mi("(H_n, x_n)")#text(" to have width 1 at ")#mi("x_n")#text(", and then apply the machinery from ")#link("https://terrytao.wordpress.com/2008/06/04/285g-lecture-18-the-structure-of-high-curvature-regions-of-ricci-flow/")[#text("Lecture 18")]#text(" to obtain a limit ")#mi("(H_\\infty,x_\\infty)")#text("; the bounded curvature at bounded distance property (Proposition 3 from ")#link("https://terrytao.wordpress.com/2008/06/04/285g-lecture-18-the-structure-of-high-curvature-regions-of-ricci-flow/")[#text("Lecture 18")]#text(") shows that both the bounded curvature end and the infinite curvature end of the horn must recede to be infinitely far away from ")#mi("x_n")#text(" in the limit, and so ")#mi("H_\\infty")#text(" becomes complete; it also has non-negative curvature, by pinching. The minimising geodesic becomes a minimising line in ")#mi("H_\\infty")#text(", and so by the Cheeger-Gromoll theorem it splits ")#mi("H_\\infty")#text(" into the product of a line and a two-dimensional manifold (which is ")#mi("\\varepsilon")#text("-close to a sphere). It turns out that we can continue all these manifolds backwards in time and repeat these arguments (much as in ")#link("https://terrytao.wordpress.com/2008/06/04/285g-lecture-18-the-structure-of-high-curvature-regions-of-ricci-flow/")[#text("Lecture 18")]#text(") to eventually give ")#mi("H_\\infty")#text(" the structure of a ")#mi("\\kappa")#text("-solution; but then the vanishing curvature forces it to be a round cylinder, by Proposition 2 of ")#link("https://terrytao.wordpress.com/2008/06/02/285g-lecture-17-the-structure-of-%ce%ba-solutions/")[#text("Lecture 17")]#text(". This implies that the rescaled ")#mi("H_n")#text(" are eventually ")#mi("\\delta")#text("-necks, a contradiction. ")#mi("\\Box")

#text("In order to successfully perform Ricci flow with surgery up to some specified time T (starting from controlled initial conditions, and as always assuming that no embedded ")#mi("\\Bbb{RP}^2")#text(" with trivial normal bundle is present), we shall pick ")#mi("\\delta")#text(" to be a very small number depending on T and the initial condition parameters, and perform our surgery on the ")#mi("\\delta")#text("-necks the scale h provided by Lemma 1, where ")#mi("r^{-2}")#text(" is (essentially) the curvature threshold beyond which the canonical neighbourhood condition holds. (In order to avoid a circular dependence of constants, one needs to check that even after surgery, that the curvature threshold for the canonical neighbourhood condition remains bounded even after arbitrarily many surgeries, as long as ")#mi("\\delta")#text(" is chosen sufficiently small depending on this scale, on T, and on the initial conditions.)")

#strong[#text("Remark 1. ")]#text("Thanks to finite time extinction in the simply connected case, being able to perform Ricci flow with surgery up to a preassigned finite time T is sufficient for proving the Poincaré conjecture (cf. Remark 1.4 of ")#link("http://arxiv.org/abs/math.DG/0307245")[#text("Perelman’s third paper")]#text("). For the full geometrisation conjecture, however, one needs to perform Ricci flow with surgery for an infinite amount of time. For this, one cannot pick a single ")#mi("\\delta")#text("; instead, one has to divide the time interval into bounded intervals (e.g. dyadic intervals), and pick a different ")#mi("\\delta")#text(" for each one (which depends on a number of parameters, including the curvature threshold for the canonical neighbourhbood property on the previous dyadic interval). This selection of constants becomes a little subtle; see e.g. the ")#link("http://arxiv.org/abs/math.DG/0605667")[#text("notes of Kleiner-Lott")]#text(" for further discussion. ")#mi("\\diamond")

#text("Having located a ")#mi("\\delta")#text("-neck inside each single ")#mi("\\varepsilon")#text("-horn, we remove the half of the neck from the centre sphere to the infinite curvature region, and smoothly interpolate in its place a copy of an (appropriately rescaled) ")#emph[#text("standard solution")]#text(". There is some choice as to how to set up this solution (much as there is some freedom when selecting a cutoff function), but roughly speaking this solution should resemble the manifold formed by attaching a hemispherical cap to a round unit cylinder, except that one needs to smooth out the transition between the two portions of this solution; also, one needs to ensure that one has positive curvature throughout the standard solution in order not to disrupt the Hamilton-Ivey pinching property. It is also technically convenient to demand that this solution is spherically symmetric (at which point Ricci flow collapses to a system of two scalar equations in one spatial dimension). One can show that such standard solutions exist for unit time (just as the round unit cylinder does), and asymptotically matches the round shrinking solution at spatial infinity. As one consequence of this, one can check that all points in spacetime on the standard solution have canonical neighbourhoods; and, with some effort, one can also show that the same will be true in the spacetime vicinity of the region in which a standard solution has been inserted via surgery into a Ricci flow, as long as ")#mi("\\delta")#text(" is sufficiently small. This is an essential tool to ensure that the canonical neighbourhood solution persists after multiple surgeries.")

#strong[#text("Remark 2.")]#text(" Suppose that M is irreducible with respect to connected sum (one can easily reduce to this case for the purposes of the Poincaré conjecture, thanks to Kneser’s theorem on the existence of the ")#link("http://en.wikipedia.org/wiki/Prime_decomposition_%283-manifold%29")[#text("prime decomposition")]#text("). Then all surgeries must be topologically trivial, which means that every ")#mi("\\varepsilon")#text("-horn, when viewed just before the singular time, only connects to a tube capped off with a ball. Then one can show that the surgery procedure is ")#emph[#text("almost distance decreasing")]#text(" in the sense that for any ")#mi("\\eta > 0")#text(", there exists a ")#mi("1 +\\eta")#text("-Lipschitz diffeomorphism from the pre-surgery manifold to the post-surgery manifold. This property is useful for ensuring that various arguments for establishing finite time extinction for Ricci flows, also work for Ricci flows with surgery, as discussed for in ")#link("https://terrytao.wordpress.com/2008/04/15/285g-lecture-5-finite-time-extinction-of-the-third-homotopy-group-i/")[#text("Lecture 5")]#text(" and ")#link("https://terrytao.wordpress.com/2008/04/18/285g-lecture-6-finite-time-extinction-of-the-third-homotopy-group-ii/")[#text("Lecture 6")]#text(". Even if the manifold is not irreducible, one can show that there are only finitely many surgeries that change the topology of the manifold; this can be established either using the prime decomposition, or by constructing a topological invariant (namely, the maximal number of homotopically non-trivial and homotopiclly distinct embedded 2-spheres in M) which is finite, non-negative, decreases by at least one with non-trivial surgery; see Section 18.2 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian")]#text(" for details. ")#mi("\\diamond")

#strong[#text("Remark 3.")]#text(" The various properties listed above of the standard solution and its insertion into surgery regions are the “geometric compatibility conditions” alluded to in ")#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/")[#text("Theorem 2")]#text(" of Lecture 2. ")#mi("\\diamond")

#heading(level: 1)[#text("— Controlling the geometry after multiple surgeries —")]

#text("Suppose that we have already performed a large (but finite) number of surgeries. In order to be able to continue Ricci flow with surgery, it is necessary that we maintain quantitative control on the geometry of the manifold which is uniform in the number of surgeries. Specifically, we need to extend the following existing controls on Ricci flow, to Ricci flow with surgery:")

#enum(start: 1, 
[#text("Lower bounds on ")#mi("R_{\\text{min}}")#text(".")],
[#text("Hamilton-Ivey pinching type bounds that lower bound ")#mi("\\text{Riem}")#text(" in terms of R.")],
[#mi("\\kappa")#text("-noncollapsing of the manifold.")],
[#text("Canonical neighbourhoods for all high curvature points in the flow.")]
)

#text("The first two controls are quite easy to establish, because they are propagated by Ricci flow (thanks to the maximum principle), and are easily preserved by surgery (basically because 1. and 2. are primarily concerned with negative curvature, and surgery is only performed in regions of high positive curvature by construction). It is significantly trickier however to preserve 3., because the proof of ")#mi("\\kappa")#text("-noncollapsing is more global, requiring the use of ")#mi("{\\mathcal L}")#text("-geodesics through spacetime. The key new difficulty is that thanks to the presence of surgery, the manifold can become “parabolically disconnected”; not every point in the initial manifold ")#mi("(M,g(0))")#text(" can be reached from a future point in a later manifold ")#mi("(M(t),g(t))")#text(" by an ")#mi("{\\mathcal L}")#text("-geodesic, because an intervening surgery could have removed the region of spacetime that the geodesic ought to have passed through. This forces one to introduce the notion of an ")#emph[#text("admissible curve")]#text(" – curves that avoid the surgery regions completely – and ")#emph[#text("barely admissible curves")]#text(", which are admissible curves which touch the boundary of the surgery regions. Roughly speaking, the monotonicity of reduced volume now controls the ")#mi("\\kappa")#text("-noncollapsing at future times in terms of the non-collapsing of the portion of the initial manifold ")#mi("(M,g(0))")#text(" which can be reached by admissible curves; this region is bordered by points which can be reached by barely admissible curves.")

#text("Now suppose we knew that all barely admissible curves had large reduced length. Then the maximum principle argument that located points of small reduced length for Ricci flows (cf. equation (18) from ")#link("https://terrytao.wordpress.com/2008/05/14/285g-lecture-11-%ce%ba-noncollapsing-via-perelman-reduced-volume/")[#text("Lecture 11")]#text("), would continue to work for Ricci flows with surgery, with the points located being inside the admissible region. It turns out that the arguments of Lecture 11 could then be adapted to this setting without much difficulty to establish the desired ")#mi("\\kappa")#text("-noncollapsing.")

#text("It is not too difficult to show that if a path did pass through a ")#mi("\\delta")#text("-neck inside an ")#mi("\\varepsilon")#text("-horn in which surgery was taking place, then the portion of the path near to that surgery region would have a large contribution to the reduced length (unless the starting point of the path was very close to the surgery region, but then one could verify the non-collapsing property directly, essentially due to the non-collapsed nature of the standard solution). This almost settles the problem immediately, except for the technical issue that there might be regions of negative curvature elsewhere in spacetime which could drag the reduced length back down again (note that the reduced length is not guaranteed to be non-negative!). There is a technical fix for this, defining a modified reduced length in which the curvature term R is replaced by ")#mi("\\max(R,0)")#text(" (and using the lower bounds on ")#mi("R_{\\min}")#text(" to measure the discrepancy between the two notions), but we will not discuss the details here; see Lemma 5.2 of ")#link("http://arxiv.org/abs/math.DG/0303109")[#text("Perelman’s second paper")]#text(" (and Chapter 16 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian")]#text(" for a very detailed treatment).")

#strong[#text("Remark 4.")]#text(" A recent ")#link("http://arxiv.org/abs/0712.1329")[#text("paper of Zhang")]#text(" uses Perelman’s entropy (as in ")#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/")[#text("Lecture 8")]#text(") to establish ")#mi("\\kappa")#text("-noncollapsing for Ricci flow with surgery, using the distance-decreasing property to keep control of the entropy functional after each (topologically trivial) surgery. This should provide a way to simplify this part of the argument, at least in the case of irreducible manifolds M. ")#mi("\\diamond")

#text("Finally, one has to check that all high-curvature points of Ricci flows with surgery lie in canonical neighbourhoods, where the threshold for “high curvature” is uniform in the number of surgeries performed. Very roughly speaking, there are two cases, depending on whether there was a surgery performed near (in the spacetime sense) such a region or not. If there was no nearby surgery, then the arguments in Lecture 18 (which are local in nature) essentially go through, exploiting heavily the ")#mi("\\kappa")#text("-noncollapsing and pinching properties that we have just established. If instead there was a nearby surgery in the recent past, then one needs to approximate the geometry here by the geometry of the standard solution, for which all points have canonical neighbourhoods. See for instance Section 17.1 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian")]#text(" for details.")

#heading(level: 1)[#text("— Surgery times do not accumulate —")]

#text("The very last thing one needs to do to establish the Poincaré conjecture is to establish Theorem 3 from ")#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/")[#text("Lecture 2")]#text(", which asserts that the set of surgery times is discrete. It turns out that this is in fact rather easy to establish. One first observes that each surgery removes at least some constant amount of ")#mi("c(h) > 0")#text(" of")#linebreak()#text(" volume from the manifold (as can be seen by looking at what happens to a single ")#mi("\\delta")#text("-neck of width roughly h under surgery; all other removals under surgery of course only decrease the volume further). On the other hand, using the volume variation formula (equation (33) from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text(") we have an upper bound on the growth of volume during non-surgery times:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\frac{d}{dt} \\text{Vol}(M(t)) \\leq -R_{\\min}(t) \\text{Vol}(M(t)).")]]

#text("Since we have a uniform lower bound on ")#mi("R_{\\min}")#text(", this implies that volume can grow at most exponentially, and in particular can only grow by a bounded amount on any fixed time interval. Hence there can be at most finitely many surgeries on each such time interval, and we are done.")

#strong[#text("Remark 5. ")]#text("The number of surgeries performed in a given time interval, while finite, could be incredibly large; it depends on the length scale h of the surgery, which in turn depends on the parameter ")#mi("\\delta")#text(", which needs to be very small in order not to disrupt the ")#mi("\\kappa")#text("-noncollapsing or canonical neighbourhood properties of the flow. This is why it is essential that our control of such properties is uniform with respect to the number of surgeries. ")#mi("\\diamond")

#strong[#text("Remark 6. ")]#text("Note also that there is no lower bound as to how close two surgery times could be to each other; indeed, there is nothing preventing two completely unrelated surgeries from being instantaneous. However, if there are an infinite number of singularities occurring at (or very close to) a single time, what tends to happen is that the earliest surgeries will not only remove the immediate singularities being formed, but will also pre-emptively eradicate a large number of potential future singularities (in particular, due to the removal of all the double ")#mi("\\varepsilon")#text("-horns, which were not immediately singular but were threatening to become singular very shortly), thus keeping the surgery times discrete. ")#mi("\\diamond")

#text("This concludes the lecture notes on the Poincaré conjecture. Have a good summer!")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2008/06/06/285g-lecture-19-the-structure-of-ricci-flow-at-the-singular-time-surgery-and-the-poincare-conjecture/#comment-30286")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2008")])]

#text("Please accept the thanks of us in your audience (both in-person and on the web) for this outstanding series of lectures.")

#text("The theorems proved are of course historic and inspiring … and equally inspiring is the mathematical tool-set that is on-display in these lectures, and the creative style with which that tool-set is deployed.")

#text("The mathematics of these lectures surely is not the conclusion, but instead comprises a few very early chapters, of what will be an immensely long & hugely exciting adventure.")

#text("Thank you very much for introducing so many of us to this adventure.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2008/06/06/285g-lecture-19-the-structure-of-ricci-flow-at-the-singular-time-surgery-and-the-poincare-conjecture/#comment-30288")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2008")])]

#text("Hear, hear!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/06/06/285g-lecture-19-the-structure-of-ricci-flow-at-the-singular-time-surgery-and-the-poincare-conjecture/#comment-30316")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2008")])]

#text("Thank you! These are great even though I didn’t understand them. The amount of work needed to write the lectures must have been incredible!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/06/06/285g-lecture-19-the-structure-of-ricci-flow-at-the-singular-time-surgery-and-the-poincare-conjecture/#comment-30325")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2008")])]

#text("iam a student going to join college please do explain the riemann hypothesis and the poincare conjecture(only the problems and not the solutions) in a simple layman language. please treate me as a novice. these may be needed in my interview")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/06/06/285g-lecture-19-the-structure-of-ricci-flow-at-the-singular-time-surgery-and-the-poincare-conjecture/#comment-30327")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2008")])]

#text("There are two very nice books on the Poincare conjecture, written for general audience:")

#text("1) The Poincare Conjecture: In Search of the Shape of the Universe by Donal O’Shea")

#text("2) Poincare’s Prize: The Hundred-Year Quest to Solve One of Math’s Greatest Puzzles by George G. Szpiro")

#text("You don’t have to read the entire books to understand (or have an idea of) what the conjecture claims. If I remember correctly, I like O’Shea better since its first chapter gives a better explanation (in my opinion). It is somewhat lengthy and first may seem unrelated to mathematics (he recounts the early days of navigation), but he really gets to the point.")

#text("I am quite certain these books will be in your local public library, or else just go to Barnes and Noble, or Borders.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2008/06/06/285g-lecture-19-the-structure-of-ricci-flow-at-the-singular-time-surgery-and-the-poincare-conjecture/#comment-30345")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2008")])]

#text("Dear Anonymous")#linebreak()#text(" Regarding the Riemann Hypothesis, if you can read French you have ")#emph[#text("Giles Lachaud, Mathématiques, L’hypothèse de Riemann, Le Graal des mathématiciens, Les Dossiers de La Recherche, Nº 20, Aôut 2005, Nouveaux défits et vieux casse-tête, pp.26-35")]#text(". ")#link("http://www.larecherche.fr/store/window/ViewWindow?id=37")[#text("http://www.larecherche.fr/store/window/ViewWindow?id=37")]#link("http://www.larecherche.fr/store/window/ViewWindow?id=37")[#text("http://www.larecherche.fr/store/window/ViewWindow?id=37")]#text(".")

#text("The same issue ")#link("http://www.larecherche.fr/store/system/media/DLR20-Maths.gif")[#text("http://www.larecherche.fr/store/system/media/DLR20-Maths.gif")]#text(" also covers the Poincare Conjecture, ")#emph[#text("Emily Singer, La conjecture de Poincaré: le très discrete Grisha Perelman, pp. 14-18")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2008/06/06/285g-lecture-19-the-structure-of-ricci-flow-at-the-singular-time-surgery-and-the-poincare-conjecture/#comment-30399")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2008")])]

#text("Correction in LaTeX-code in Remark 4: ")#mi("R_{\\min}")#text(" instead of $latex R_{\\min}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/06/285g-lecture-19-the-structure-of-ricci-flow-at-the-singular-time-surgery-and-the-poincare-conjecture/#comment-30404")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2008")])]

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Serge")]], [#link("https://terrytao.wordpress.com/2008/06/06/285g-lecture-19-the-structure-of-ricci-flow-at-the-singular-time-surgery-and-the-poincare-conjecture/#comment-30551")[#strong[#text("Serge")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2008")])]

#text("Would be great to have it in the single file. I dropped off on the second lecture, but have vague intention to read it in some future “then I have more free time” :). Anyway I think there are many people who would like to see it as a file or e-book. Thanks for great blog.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2411afb8a61600612cdbfa3188169cf15c69373b05b7ddbc138d63eef22dfeea-f200a064c32dde3fa721e9afdf95a83f5544214632d4b8dfbd1159ca30252bb6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sajjad")]], [#link("https://terrytao.wordpress.com/2008/06/06/285g-lecture-19-the-structure-of-ricci-flow-at-the-singular-time-surgery-and-the-poincare-conjecture/#comment-93544")[#strong[#text("Sajjad")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2011")])]

#text("Dear Professor Tao, I think the following statement needs a correction:")

#text("“thus the width of the necks go to infinity as one approaches the boundary of \\Omega”")

#text("the width goes to zero I guess unless, by width you mean something different.")

#text("Best Regards,")#linebreak()#text(" Sajjad")

#emph[#text("[Corrected, thanks – T.]")]
]
