// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/
// Converted to Typst by tao2typ: "2026-10-14T07:22:57.012975+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Freiman’s theorem for solvable groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Freiman’s theorem for solvable groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 June 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/")[#text("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("I’m continuing the stream of uploaded papers this week with my paper “")#link("http://arxiv.org/abs/0906.3535")[#text("Freiman’s theorem for solvable groups")]#text("“, submitted to ")#link("http://cdm.ucalgary.ca/index.php/cdm")[#text("Contrib. Disc. Math.")]#text(". This paper concerns the problem (discussed in ")#link("https://terrytao.wordpress.com/2007/03/02/open-question-noncommutative-freiman-theorem/")[#text("this earlier blog post")]#text(") of determining the correct analogue of Freiman’s theorem in a general non-abelian group ")#mi("G = (G,\\cdot)")#text(". Specifically, if ")#mi("A \\subset G")#text(" is a finite set that obeys the doubling condition ")#tao-math("\\left|A \\cdot A\\right| \\leq K\\left|A\\right|", block: false)#text(" for some bounded K, what does this tell us about A? Heuristically, we expect A to behave like a finite subgroup of G (or perhaps a coset of such a subgroup).")

#text("When G is the integers (with the additive group operation), Freiman’s theorem then tells us that A is controlled by a generalised arithmetic progression P, where I say that one set A is controlled by another P if they have comparable size, and the former can be covered by a finite number of translates of the latter. (One can view generalised arithmetic progressions as an approximate version of a subgroup, in which one only uses the generators of the progression for a finite amount of time before stopping, as opposed to groups which allow words of unbounded length in the generators.) For more general abelian groups, the Freiman theorem ")#link("http://www.arxiv.org/abs/math.NT/0505198")[#text("of Green and Ruzsa")]#text(" tells us that a set of bounded doubling is controlled by a generalised coset progression ")#mi("P+H")#text(", i.e. the sum of a generalised arithmetic progression P and a finite subgroup H of G. (Of course, if G is torsion-free, the finite subgroup H must be trivial.)")

#text("In this paper we address the case when G is a ")#link("http://en.wikipedia.org/wiki/Solvable_group")[#text("solvable group")]#text(" of bounded derived length. The main result is that if a subset of G has small doubing, then it is controlled by an object which I call a “coset nilprogression”, which is a certain technical generalisation of a coset progression, in which the generators do not quite commute, but have commutator expressible in terms of “higher order” generators. This is essentially a sharp characterisation of such sets, except for the fact that one would like a more explicit description of these coset nilprogressions. In the torsion-free case, a more explicit description (analogous to the Mal’cev basis description of nilpotent groups) has appeared in a very recent ")#link("http://arxiv.org/abs/0906.3598")[#text("paper of Breulliard and Green")]#text("; in the case of monomial groups (a class of groups that overlaps to a large extent with solvable groups), and assuming a polynomial growth condition rather than a doubling condition, a related result controlling A by balls in a suitable type of metric has appeared in very recent work of Sanders. In the nilpotent case there is also a nice recent ")#link("http://arxiv.org/abs/0901.1409")[#text("argument of Fisher, Peng, and Katz")]#text(" which shows that sets of small doubling remain of small doubling with respect to the Lie algebra operations of addition and Lie bracket, and thus are amenable to the abelian Freiman theorems.")

#text("The conclusion of my paper is easiest to state (and easiest to prove) in the model case of the ")#link("http://en.wikipedia.org/wiki/Lamplighter_group")[#text("lamplighter group")]#text(" ")#mi("G = {\\Bbb Z} \\rtimes {\\Bbb F}_2^\\omega")#text(", where ")#mi("{\\Bbb F}_2^\\omega = \\lim_{n \\to \\infty} {\\Bbb F}_2^n")#text(" is the additive group of doubly infinite sequences in the finite field ")#mi("{\\Bbb F}_2")#text(" with only finitely many non-zero entries, and ")#mi("{\\Bbb Z}")#text(" acts on this space by translations. This is a solvable group of derived length two. The main result here is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" (Freiman’s theorem for the lamplighter group) If ")#mi("A \\subset {\\Bbb Z} \\ltimes {\\Bbb F}_2^\\omega")#text(" has bounded doubling, then A is controlled either by a finite subspace of the “vertical” group ")#mi("\\{0\\} \\times {\\Bbb F}_2^\\omega")#text(", or else by a set of the form ")#mi("\\{ (n,\\phi(n)): n \\in P \\}")#text(", where ")#mi("P \\subset {\\Bbb Z}")#text(" is a generalised arithmetic progression, and ")#mi("\\phi: P \\to {\\Bbb F}_2^{\\omega}")#text(" obeys the Freiman isomorphism property ")#mi("(n_1,\\phi(n_1)) \\cdot (n_2, \\phi(n_2)) = (n_3,\\phi(n_3)) \\cdot (n_4,\\phi(n_4))")#text(" whenever ")#mi("n_1,n_2,n_3,n_4 \\in P")#text(" and ")#mi("n_1+n_2=n_3+n_4")#text(".")
]

#text("This result, incidentally, recovers an earlier ")#link("http://www.ams.org/mathscinet-getitem?mr=1865397")[#text("result of Lindenstrauss")]#text(" that the lamplighter group does not contain a ")#link("http://en.wikipedia.org/wiki/F%C3%B8lner_sequence")[#text("Følner sequence")]#text(" of sets of uniformly bounded doubling. It is a good exercise to establish the “exact” version of this theorem, in which one classifies subgroups of the lamplighter group rather than sets of small doubling; indeed, the proof of this the above theorem follows fairly closely the natural proof of the exact version.")

#text("One application of the solvable Freiman theorem is the following quantitative version of a classical result ")#link("http://www.ams.org/mathscinet-getitem?mr=232311")[#text("of Milnor")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=248688")[#text("of Wolf")]#text(", which asserts that any solvable group of polynomial growth is virtually nilpotent:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2.")]#text(" (Quantitative Milnor-Wolf theorem) Let G be a solvable group of derived length O(1), let S be a set of generators for G, and suppose one has the polynomial growth condition ")#tao-math("\\left|B_S(R)\\right| \\leq R^d", block: false)#text(" for some d = O(1), where ")#mi("B_S(R)")#text(" is the set of all words generated by S of length at most R. If R is sufficiently large, then this implies that G is virtually nilpotent; more precisely, G contains a nilpotent subgroup of step O(1) and index ")#mi("O(R^{O(1)})")#text(".")
]

#text("The key points here are that one only needs polynomial growth at a single scale R, rather than on many scales, and that the index of the nilpotent subgroup has polynomial size.")

#text("The proofs are based on an induction on the derived length. After some standard manipulations (basically, splitting A by an approximate version of a short exact sequence), the problem boils down to that of understanding the action ")#mi("\\rho")#text(" of some finite set A on a set E in an additive group. If one assumes that E has small doubling and that the action of A leaves E approximately invariant, then one can show that E is a coset progression, and the action of A can be described efficiently using the generators of that progression (after refining the set A a bit).")

#text("In the course of the proof we need two new additive combinatorial results which may be of independent interest. The first is a variant of a well-known ")#link("http://www.ams.org/mathscinet-getitem?mr=1002119")[#text("theorem of Sárközy")]#text(", which asserts that if A is a large subset of an arithmetic progression P, then an iterated sumset kA of A for some ")#mi("k=O(1)")#text(" itself contains a long arithmetic progression. Here, we need the related fact that if A is a large subset of a coset progression, then an iterated subset kA for ")#mi("k=O(1)")#text(" contains a large coset progression Q, and furthermore this inclusion is “robust” in the sense that all elements the elements of Q have a large number of representations as sums of elements of A. We also need a new (non-commutative) variant of the Balog-Szemerédi(-Gowers) lemma, which asserts that if A has small doubling, then A (or more precisely ")#mi("A \\cdot A^{-1}")#text(") contains a large “core” subset D such that almost all of a large iterated subset kD of D still lies inside ")#mi("A \\cdot A^{-1}")#text("). (This may not look like the usual Balog-Szemerédi lemma, but the proof of the lemma is almost identical to the ")#link("http://www.ams.org/mathscinet-getitem?mr=1305895")[#text("original proof of Balog and Szemerédi")]#text(", in particular relying on the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (17)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/#comment-39662")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2009")])]

#text("Missing “paper” tag. ")#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f15187f7e44a1e4d467cafafbc13d0aa45c91292e4f729020bd9ba8362d49bce-9c7c7f41d44bf40e0cea7adfa6992c84d0842e868cb1cf8ddb374d63968fec3e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pierre")]], [#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/#comment-39663")[#strong[#text("pierre")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2009")])]

#text("Out of curiosity, how do you usually decide which journal to submit to?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/#comment-39765")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2009")])]

#text("Dear Pierre,")

#text("Please see")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/advice-on-writing-papers/submit-to-an-appropriate-journal/")[#text("Submit to an appropriate journal")]
]

#text("for my thoughts on these sorts of issues.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/#comment-39681")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2009")])]

#text("Typo: In the statement of Theorem 1, and in the paragraph before it, I think your semidirect product is backwards. The integers act on ")#mi("F_2^{\\omega}")#text(", right? ")#emph[#text("[Corrected, thanks]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/#comment-39705")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2009")])]

#text("I am very happy to see both this paper and the new paper by Green and Breuillard. I’d like to focus on your Corollary 1.21, and why you truly need the hypothesis that G be totally torsion-free in order to take H=N. I thought your readers might be interested in a few examples over finite fields. In these examples, G is not totally torsion-free (because it is finite!), one cannot take H=N (the conclusion would then be false), and the statement of Corollary 1.21 becomes unfortunately trivial.")

#text("These examples show that a subset A of a solvable group G can have small doubling constant and yet be far from being contained in a nilpotent group (or a few cosets thereof).")#linebreak()#text(" At the same time, as I will say thereafter, a different kind of reduction to the nilpotent case should still be possible.")

#text("Example 1.-")

#text("Let ")#mi("G = SL_3(K)")#text(", where ")#mi("K = Z/pZ")#text(".")

#text("Let")

#mi("A = \\left\\{\\left(\\begin{matrix} r^k & x & y\\\\ 0 & s^k & z \\\\ 0 & 0 & (r s)^{-k}\\end{matrix}\\right)               : x,y,z \\in K,  -N\\leq k\\leq N\\right\\}")#text(",")

#text("where r and s are arbitrary elements of ")#mi("K^*")#text(".")

#text("The doubling constant is ")#mi("<=4")#text(", but A is far from being contained in anything nilpotent.")

#text("Example 2.-")

#text("Let ")#mi("G = SL_3(K)")#text(", where ")#mi("K=Z/pZ")#text(".")

#text("Let")

#mi("A = \\left\\{\\left(\\begin{matrix} r^k & k^{\\prime} & y\\\\ 0 & r^k & z \\\\ 0 & 0 & (r)^{-2k}\\end{matrix}\\right)               : y,z \\in K,  -N\\leq k\\leq N, -M\\leq k^{\\prime}\\leq M\\right\\},")

#text("where r is an arbitrary element in ")#mi("K^*")#text(".")

#text("The doubling constant is ")#mi("\\leq 4")#text(", but, again, A is far from being nilpotent.")

#text("———-")

#text("It seems to me that one can make, nevertheless, make a general")#linebreak()#text(" reduction of the solvable case to the nilpotent case. Moreover, one")#linebreak()#text(" should be able to prove such a result with techniques available now.")

#text("—————")

#strong[#text("Very realistic conjecture.")]#text(" Let A be a subset of a solvable group G")#linebreak()#text(" of derived length at most l. Then, for any K, either")

#tao-math("\\left|A A A\\right| \\geq K \\left|A\\right|", block: false)

#text("or")

#text("there are subgroups ")#mi("H_1\\triangleleft H_2 \\triangleleft \\langle A\\rangle")#text(" such that")

#text("(a) ")#mi("H_1")#text(" is contained in ")#mi("(A \\cup \\{I\\} \\cup A^{-1})^k")#text(", where k depends only on l,")#linebreak()#text(" (b) A is contained in ")#mi("<= K^C")#text(" cosets of ")#mi("H_2")#text(", where C depends only on l, and")#linebreak()#text(" (c) ")#mi("H_2/H_1")#text(" is nilpotent.")#linebreak()#text(" —————–")

#text("I like to require these subgroups to be normal (which you haven't done); that makes the reduction more complete, and makes some of that business of K-approximate groups")#linebreak()#text(" automatically true. On the other hand, requiring ")#mi("H_2 \\triangleleft \\langle A\\rangle")#linebreak()#text(" as opposed to just ")#mi("H_2 < \\langle A \\rangle")#text(" will probably make the proof more complicated. (Or do you think that ")#mi("H_2\\triangleleft \\langle A\\rangle")#text(" is perhaps not even always true?)")

#text("The \"very realistic conjecture\" becomes a much harder conjecture (but is still probably true) if, instead of letting G be a solvable group of derived length <=l, we let G")#linebreak()#text(" be any subgroup of ")#mi("SL_l(K)")#text(" for any field K. I recently proved such a statement for")#linebreak()#text(" ")#mi("SL_3(Z/pZ)")#text(" (")#link("http://arxiv.org/abs/0807.2027")[#text("http://arxiv.org/abs/0807.2027")]#text(", Thm 1.1). I am now working on growth in ")#mi("SL_n(K)")#text(", but I'll probably restrict myself to sets generating ")#mi("SL_n(K)")#text(" in the near future: I am having difficulties with sets that generate ")#mi("SO_n")#text(", for example.")

#text("Returning to the solvable case: the very realistic conjecture should yield to techniques related to the sum-product theorem. As you know, I really think the sum-product theorem is a special case of a more general statement on groups acting on groups. I prove a statement of that nature in section 3 of my ")#mi("SL_3")#text(" paper – it may very well be strong enough to use as the main tool to prove the (very realistic) conjecture, but it's certainly not something that solves the problem immediately.")

#text("At any rate, you see how the conjecture would reduce the solvable problem more or less completely to what Ben [Green] and Emmanuel [Breuillard] are doing. (In fact, since it has polynomial dependence, it will still be enough if some day a polynomial Freiman-Ruzsa theorem is proven.) I say \"more or less\" simply because the few cosets of ")#mi("H_2")#text(" occupied by elements of A may act on ")#mi("H_2")#text(" in an interesting way by conjugation, and that may force some sets to grow that would not grow otherwise; that still needs to be looked into.")

#text("Tell me what you think.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/#comment-39706")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2009")])]

#text("My longer comments are not appearing; do you know what is the matter? Are you receiving them? ")#emph[#text("[Your comment was caught in the automatic spam filter, but I restored it manually. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/#comment-39722")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2009")])]

#text("Dear Harald,")

#text("Thanks for the examples!")

#text("I think the conjecture is quite plausible (except perhaps for the polynomial dependence on K in the gap between A and H_2, which is rather ambitious with current technology – note we don’t have polynomial Freiman-Ruzsa even in the abelian case right now). In my paper I manage to control A by a slightly weaker object that I call a “coset nilprogression”. Roughly speaking, you are controlling A by a finite extension ")#mi("H_2")#text(" of a nilpotent group ")#mi("N := H_2/H_1")#text(", thus ")#mi("0 \\to H_1 \\to H_2 \\to N \\to 0")#text(", (and nilpotent groups can be viewed as towers of central extensions of the trivial group); coset nilprogressions are a bit more complicated, being a tower in which each stage is either a central extension or a finite extension, but they can come jumbled up in a funny way, in particular the finite stuff doesn’t necessarily come at the very top of the tower, but is sort of scattered through the tower. But it may actually be possible to disentangle this tower and pull all the finite stuff out as a big normal subgroup, as you suggest. I’ll have to think about it.")

#text("[Actually, with my nilprogressions, I’m not so much extending things by central groups, but rather by central progressions. This is sort of a fuzzy concept – the language of “approximate group theory” is not yet well developed enough to cleanly deal with extending an approximate group by another approximate group (e.g. extending a nilprogression by an arithmetic progression, somewhat similar to how your examples are operating) – and so the precise formalisation of this concept in my paper (Definition 1.11) is quite yucky, analogous to what the concept of a group extension ")#mi("0 \\to K \\to G \\to H \\to 0")#text(" would look like if one insisted on writing everything in coordinates, thus creating a partial inverse ")#mi("\\phi: H \\to G")#text(" and expressing elements of G in the form ")#mi("k \\phi(h)")#text(" for ")#mi("k \\in K, h \\in H")#text(".]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/#comment-39732")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2009")])]

#text("Dear Terry,")

#text(">I think the conjecture is quite plausible (except perhaps for the polynomial dependence >on K in the gap between A and H_2, which is rather ambitious with current technology – >note we don’t have polynomial Freiman-Ruzsa even in the abelian case right now).")

#text("One doesn’t need polynomial Freiman-Ruzsa in any shape or form to get polynomial dependence here. In fact, I have already got polynomial dependence for A in a solvable subgroups of SL_3(Z/pZ) – well, actually, for any A in SL_3(Z/pZ). Otherwise I would not have been able to prove a result of the form |A A A| >> |A|^{1+epsilon} for subsets A of SL_3(Z/pZ) generating SL_3(Z/pZ).")

#text("In your paper, you are using ideas connected to Freiman-Ruzsa. I posit that these ideas belong to the study of nilpotent groups. The reduction of the solvable case to the nilpotent case can be managed entirely by what may call generalised sum-product technology (though the name is arguably outdated now), without any recourse to Freiman-Ruzsa. One great advantage of this is that we can get polynomial dependence right now.")

#text(">But it may actually be possible to disentangle this tower and pull all the finite stuff out >as a big normal subgroup, as you suggest. I’ll have to think about it.")

#text("I would be very curious to know what you get.")

#text("Best,")#linebreak()#text(" Harald")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/#comment-39743")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2009")])]

#text("Dear Harald,")

#text("I suppose that our current range of polynomially quantitative techniques may indeed be able to get a polynomial solvable-to-nilpotent reduction, but my guess is that it would have to use some rather explicit structure of the solvable group. It isn’t quite the same, but Fisher-Katz-Peng’s paper make a kind of polynomial nilpotent-to-abelian reduction based primarily on the Baker-Campbell-Hausdorff formula.")

#text("I did some calculations. It does indeed seem that the methods in my paper give your claim except for the polynomial bounds. The key new point is that if a matrix is both nilpotent and of finite order (with integer coefficients), then it is the identity. As a consequence, when one is extending some coset nilprogression by a proper abelian progression, with the conjugation action of the former on the latter being nilpotent, the action of any finite abelian subgroup of the base coset nilprogression on the proper progression is trivial and so that finite abelian subgroup can be absorbed into the extension group (and can eventually be quotiented out). Combining this with the stuff in my paper and using induction disentangles the tower and eventually gives the claim (I’ll send you more detailed computations at some point).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/#comment-39767")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2009")])]

#text("Dear Terry,")

#text(">I suppose that our current range of polynomially quantitative techniques may indeed be >able to get a polynomial solvable-to-nilpotent reduction, but my guess is that it would >have to use some rather explicit structure of the solvable group.")

#text("I cannot fully agree. There are already partial statements one can prove without any explicit work. This makes me think that it might be possible to settle the “very realistic conjecture” I stated above without much explicit work at all.")

#text("(I’ve sent you something – it’s very preliminary, though.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Non-commutative Freiman theorems, and model theory « What’s new")]], [#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/#comment-42726")[#strong[#text("Non-commutative Freiman theorems, and model theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2009")])]

#text("[…] weaker version of this lemma was also established by myself […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Linear approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/#comment-43382")[#strong[#text("Linear approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2010")])]

#text("[…] and proving this statement is the noncommutative Freiman theorem problem, discussed in these earlier blog […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A note on approximate subgroups of GL_n(C) and uniformly nonamenable groups « What’s new")]], [#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/#comment-49611")[#strong[#text("A note on approximate subgroups of GL_n(C) and uniformly nonamenable groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2011")])]

#text("[…] a “noncommutative Freiman” type theorem in linear groups . As discussed in earlier blog posts, a general question in additive (or multiplicative) combinatorics is to understand the structure of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The structure of approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/#comment-96265")[#strong[#text("The structure of approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2011")])]

#text("[…] groups, nilpotent groups, solvable groups, or simple groups of Lie type) are also known; see these previous blog posts for a summary of several of these […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 5: Product theorems, pivot arguments, and the Larsen-Pink non-concentration inequality « What’s new")]], [#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/#comment-126690")[#strong[#text("254B, Notes 5: Product theorems, pivot arguments, and the Larsen-Pink non-concentration inequality « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("[…] of . The Borel group is solvable, and by using tools from additive combinatorics, such as Freiman’s theorem in solvable groups (or the Helfgott-Lindenstrauss conjecture, discussed in the previous quarter’s notes), one […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c9d0afd7e80741d26c154be7fedf447a7cfac032e95209918c45d1ef5845352d-a7b7c0c3acee4e3027e89a8cb40753685810505c56a7ce9fbe7830ff1f3be127.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Coset progression")]], [#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/#comment-526469")[#strong[#text("Coset progression")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2019")])]

#text("Terry (or any other expert), I’m just beginning to read the Freiman/Green/Ruzsa papers and I have a question about your remark in this post that a generalized arithmetic progression is, approximately, a subgroup:")#linebreak()#text(" For a subset A (of finite abelian group G) with bounded doubling, does the dimension of the progression (that controls A) divide |G|? This would be the analogue of Lagrange’s theorem for subgroups.")

#text("Any references/counterexamples concerning this question would be appreciated.")

#text("Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/#comment-528566")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2019")])]

#text("No; for instance consider an arithmetic progression ")#mi("A = \\{1,\\dots,N\\}")#text(" in a cyclic group ")#mi("G = {\\bf Z}/p{\\bf Z}")#text(" of prime order ")#mi("p")#text(", where ")#mi("p")#text(" is much larger than ")#mi("N")#text(".")

#text("For an actual subgroup ")#mi("A")#text(" of a finite group ")#mi("G")#text(", one can cover ")#mi("G")#text(" by exactly ")#tao-math("\\left|G\\right|/\\left|A\\right|", block: false)#text(" disjoint translates of ")#mi("A")#text(", which is where Lagrange’s theorem comes from. For approximate groups ")#mi("A")#text(" one instead can cover ")#mi("G")#text(" by ")#tao-math("O(\\left|G\\right|/\\left|A\\right|)", block: false)#text(" translates of ")#mi("A-A")#text(" by the Ruzsa covering lemma, but now there is nothing preventing ")#tao-math("\\left|G\\right|/\\left|A\\right|", block: false)#text(" from being a non-integer.")
]
]
