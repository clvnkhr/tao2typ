// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/12/the-status-of-the-hodge-conjecture/
// Converted to Typst by tao2typ: "2026-10-19T13:40:42.385815+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The status of the Hodge conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The status of the Hodge conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/12/the-status-of-the-hodge-conjecture/")[#text("https://terrytao.wordpress.com/2026/09/12/the-status-of-the-hodge-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-19 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#emph[#text("[This is a guest post by ")#link("https://www.college-de-france.fr/fr/chaire/claire-voisin-geometrie-algebrique-chaire-statutaire")[#text("Claire Voisin")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("Hodge classes can be defined on any compact complex manifold ")#mi("{X}")#text(". They are rational ")#link("https://en.wikipedia.org/wiki/Betti_number")[#text("Betti cohomology")]#text(" classes on ")#mi("{X}")#text(" of even degree ")#mi("{2k}")#text(" (eg combinations with ")#mi("{\\mathbb{Q}}")#text("-coefficients of classes of oriented codimension ")#mi("{2k}")#text(" closed submanifolds of ")#mi("{X}")#text(") which satisfy a delicate “Hodge condition” necessary for them to be combinations with ")#mi("{\\mathbb{Q}}")#text("-coefficients of classes of complex submanifolds (and more generally closed analytic spaces) of ")#mi("{X}")#text(". To understand this condition, we need to pass to cohomology with complex coefficients, and represent complex cohomology classes as ")#link("https://en.wikipedia.org/wiki/De_Rham_cohomology")[#text("de Rham cohomology")]#text(" classes of closed forms. The Hodge condition is that the class should be representable by a closed form that in local holomorphic coordinates is written as ")#tao-math("{\\sum_{\\left|I\\right|=k,\\left|J\\right|=k} \\alpha_{IJ} dz_I \\wedge d\\overline{z}_J}", block: false)#text(".")

#text("The ")#link("https://en.wikipedia.org/wiki/Hodge_conjecture")[#text("Hodge conjecture")]#text(" states that a Hodge class on a smooth complex projective variety ")#mi("{X}")#text(" is “algebraic”, that is, is a combination with rational coefficients of classes of closed analytic (or equivalently, algebraic) subsets. Note that the Hodge conjecture can also be formulated for compact complex manifolds, and in particular compact ")#link("https://en.wikipedia.org/wiki/K%C3%A4hler_manifold")[#text("Kähler manifolds")]#text(". In this setting, there are easy examples where some nonzero degree 2 Hodge class exists on ")#mi("{X}")#text(", while there are no codimension 1 closed analytic subsets in ")#mi("{X}")#text(", so one needs in any case to consider not only classes of closed analytic subsets but also ")#link("https://en.wikipedia.org/wiki/Chern_class")[#text("Chern classes")]#text(" of holomorphic vector bundles and their singular version (")#link("https://en.wikipedia.org/wiki/Coherent_sheaf")[#text("coherent sheaves")]#text("). However it is proved in ")#link("https://zbmath.org/1751658")[#text("[12]")]#text(" that some compact Kähler manifolds have nontrivial Hodge classes, while Chern classes of coherent sheaves are all zero. This does not necessarily say that an analytic approach to the Hodge conjecture is not possible, but this says that any such proof has to use the fact that ")#mi("{X}")#text(" is algebraic. One early approach, proposed in ")#link("https://zbmath.org/3459086")[#text("[6]")]#text(", is to work on an affine Zariski open set ")#mi("{U := X \\setminus H}")#text(", where ")#mi("{H}")#text(" is a hyperplane section of ")#mi("{X}")#text(". One can represent even degree rational cohomology classes of ")#mi("{X}")#text(", restricted to ")#mi("{U}")#text(", as Chern classes of holomorphic vector bundles on ")#mi("{U}")#text(", and then use the Hodge condition (but how?) to algebraize these vector bundles, that is, extend them from ")#mi("{U}")#text(" to ")#mi("{X}")#text(" as coherent sheaves. This very interesting construction has alas not been successful.")

#text("Another potential approach to the Hodge conjecture is by induction on the codimension. It relies on the following deep fact, which is a consequence of the Deligne theory of Hodge structures and their properties ")#link("https://zbmath.org/3348292")[#text("[7]")]#text(". Namely, in order to prove the Hodge conjecture, it suffices to prove the following statement: ")#emph[#text("for any smooth projective variety ")#mi("{X}")#text(" and any Hodge class ")#mi("{\\alpha}")#text(" on ")#mi("{X}")#text(", there exists a dense Zariski open set ")#mi("{U = X \\setminus D \\subset X}")#text(" such that ")#mi("{\\alpha|_U = 0}")#text(" in ")#mi("{H^{2k}(U, \\mathbb{Q})}")#text(".")]

#text("In this statement, ")#mi("{D}")#text(" is an algebraic hypersurface in ")#mi("{X}")#text(", usually very singular. A class ")#mi("{\\alpha}")#text(" satisfying the above property for some ")#mi("{D}")#text(" is said to have coniveau ")#mi("{\\geq 1}")#text(". This notion goes back to Grothendieck (see ")#link("https://zbmath.org/3283963")[#text("[10]")]#text(") and the study of the coniveau filtration led to important developments in ")#link("https://zbmath.org/3480765")[#text("[3]")]#text(". Alas, how to prove that a class has coniveau ")#mi("{\\geq 1}")#text(" ? As explained by Grothendieck in ")#link("https://zbmath.org/3283963")[#text("[10]")]#text(", this is very restrictive on ")#mi("{\\alpha}")#text(" and most cohomology classes (eg, classes of holomorphic forms) do not satisfy this property.")

#text("The Hodge conjecture thus motivated beautiful developments in Hodge theory and on the topology of algebraic varieties, but it is fair to say that, beyond the formal definition, there is no good understanding of what is a Hodge class from the viewpoint of algebraic geometry. The reason is that one understands well in the setting of algebraic geometry cohomology with complex coefficients and the Hodge condition, but not Betti cohomology with rational coefficients.")

#text("However, there are Hodge classes that we understand very well, which are constructed by (multi)linear algebra tricks. Probably the simplest example is the following: let ")#mi("{X}")#text(" be a smooth projective complex variety and let ")#mi("{b_2 := \\dim H^2(X)}")#text(". Then ")#mi("{\\bigwedge^{b_2} H^2(X, \\mathbb{Q})}")#text(" is of dimension 1 and it is naturally contained in ")#mi("{H^{2b_2}(X^{b_2}, \\mathbb{Q})}")#text(". It is rather obvious that it is generated by a Hodge class on ")#mi("{X^{b_2}}")#text(". This class is not known to satisfy the Hodge conjecture.")

#text("Similarly constructed examples need a little more knowledge of topology. The ")#link("https://en.wikipedia.org/wiki/Standard_conjectures_on_algebraic_cycles")[#text("standard conjectures")]#text(" like the Künneth conjecture (the Hodge conjecture for the Künneth components of the diagonal), or Lefschetz standard conjecture, are particular instances of the Hodge conjecture for certain Hodge classes that can be constructed on the square ")#mi("{X^2}")#text(" of any smooth projective complex manifold. The algebraicity of these classes is rather crucial in the ")#link("https://en.wikipedia.org/wiki/Motive_(algebraic_geometry)")[#text("theory of motives")]#text(".")

#text("A more involved example is that of Weil classes on Weil abelian varieties, on which an important recent progress was made by Markman. An ")#link("https://en.wikipedia.org/wiki/Abelian_variety")[#text("abelian variety")]#text(" over ")#mi("{\\mathbb{C}}")#text(" is a complex torus that has holomorphic embeddings in complex projective space, and a Weil abelian variety is one which admits a quadratic endomorphism ")#mi("{\\phi}")#text(", ")#mi("{\\phi^2 = -d\\,\\mathrm{Id}}")#text(", ")#mi("{d > 0}")#text(". The variety ")#mi("{A}")#text(" has to be of even dimension ")#mi("{2n}")#text(" and one assumes that the action of ")#mi("{\\phi_*}")#text(" on the tangent space of ")#mi("{A}")#text(" has both eigenvalues ")#mi("{\\pm \\sqrt{-d}}")#text(" with the same multiplicity ")#mi("{n}")#text(". A formal argument then produces a two-dimensional space of Hodge classes of degree ")#mi("{2n}")#text(" on ")#mi("{A}")#text(", called Weil classes. A big recent progress on the Hodge conjecture is the proof by Markman ")#link("https://arxiv.org/abs/2502.03415")[#text("[11]")]#text(" that Hodge classes on abelian fourfolds are algebraic. This problem is classically reduced to proving the algebraicity of Weil classes, and to prove this, Markman makes a detour through Weil classes on certain families of Weil abelian 6-folds.")

#strong[#text("Variational aspects.")]#text(" Smooth projective complex varieties come in families ")#mi("{\\pi : \\mathcal{X} \\rightarrow B}")#text(", where ")#mi("{\\mathcal{X}}")#text(" and ")#mi("{B}")#text(" are themselves algebraic varieties which can be chosen defined over a number field, as the algebraic map ")#mi("{\\pi}")#text(". The topology of the fibers ")#mi("{\\mathcal{X}_b}")#text(" does not change with ")#mi("{b}")#text(" (")#mi("{\\pi}")#text(" is a ")#mi("{C^\\infty}")#text(" fibration) but the complex structure of ")#mi("{\\mathcal{X}_b}")#text(" changes, and so does the set of Hodge classes of given degree on ")#mi("{\\mathcal{X}_b}")#text(". Given a Hodge class ")#mi("{\\alpha}")#text(" of degree ")#mi("{2k}")#text(" on a fiber ")#mi("{\\mathcal{X}_0}")#text(", its Hodge locus is (grosso modo) the set of points ")#mi("{b \\in B}")#text(" such that along a path ")#mi("{t \\mapsto \\gamma(t)}")#text(" from 0 to ")#mi("{b}")#text(" in ")#mi("{B}")#text(", the locally constant class ")#mi("{\\alpha_t \\in H^{2k}(\\mathcal{X}_{\\gamma(t)}, \\mathbb{Q})}")#text(" remains Hodge. An important result concerning ")#mi("{B_\\alpha}")#text(" is the fact (proved by Cattani–Deligne–Kaplan ")#link("https://zbmath.org/788752")[#text("[5]")]#text(") that it behaves as if the Hodge conjecture was true, namely ")#mi("{B_\\alpha}")#text(" is a closed algebraic subset in ")#mi("{B}")#text(". However, one missing information in this result is that this locus is defined over a number field, as predicted by the Hodge conjecture (a more precise statement is that Hodge classes are ")#emph[#text("absolute Hodge")]#text("). One could thus imagine disproving the Hodge conjecture by exhibiting a Hodge class on a fiber ")#mi("{\\mathcal{X}_0}")#text(" with Hodge locus not defined over a number field (this cannot be done with the Hodge classes explicitly described above). Such counterexample would not damage too much our understanding of the theory of motives and could lead to a corrected version of the Hodge conjecture stating that absolute Hodge classes are algebraic.")

#strong[#text("Variational Hodge conjecture.")]#text(" ")#emph[#text("Given as above ")#mi("{\\mathcal{X} \\rightarrow B}")#text(" and a Hodge class ")#mi("{\\alpha \\in H^{2k}(\\mathcal{X}_0, \\mathbb{Q})}")#text(", assume that ")#mi("{B_\\alpha = B}")#text(" and that ")#mi("{\\alpha_0}")#text(" is algebraic on ")#mi("{\\mathcal{X}_0}")#text(". Is ")#mi("{\\alpha_t}")#text(" also algebraic on ")#mi("{\\mathcal{X}_t}")#text(" for any ")#mi("{t \\in B}")#text("?")]

#text("A negative answer to that question would be the worst scenario for the theory of motives. In particular, this would disprove the Lefschetz standard conjecture (see ")#link("https://zbmath.org/5123043")[#text("[1]")]#text(").")

#text("Deformation theory can in some cases be used to answer affirmatively the question above. Assuming that ")#mi("{\\alpha_0}")#text(" is the class of an algebraic subvariety ")#mi("{Z \\subset \\mathcal{X}_0}")#text(" (or a Chern class of an algebraic vector bundle ")#mi("{E}")#text(" on ")#mi("{\\mathcal{X}_0}")#text("), the semi-regularity condition of ")#link("https://zbmath.org/3401070")[#text("Bloch")]#text(", (respectively of ")#link("https://zbmath.org/1960065")[#text("Buchweitz–Flenner")]#text("), is a subtle cohomological property of ")#mi("{Z \\subset \\mathcal{X}_0}")#text(" (resp. of ")#mi("{E}")#text(") guaranteeing that ")#mi("{Z}")#text(" deforms to ")#mi("{Z_t \\subset \\mathcal{X}_t}")#text(", (resp. that ")#mi("{E}")#text(" deforms to ")#mi("{E_t}")#text(" if all its Chern classes remain Hodge on ")#mi("{\\mathcal{X}_t}")#text("). Buchweitz–Flenner semiregular sheaves have been used successfully by Markman in ")#link("https://arxiv.org/abs/2502.03415")[#text("[11]")]#text(" for Weil classes on 6-dimensional Weil abelian varieties. Unfortunately it seems very unlikely that semi-regularity suffices to solve the variational Hodge conjecture in general. One reason is that the variational Hodge conjecture for integral Hodge classes is not true, which shows that in some cases, cycles ")#mi("{\\sum_i n_i Z_i}")#text(", ")#mi("{Z_i \\subset X}")#text(", are not homologous to any semiregular cycle (a multiple is in any case needed).")

#text("Another reason is that, associated to a given cycle ")#mi("{Z}")#text(" of ")#mi("{X}")#text(", there is a Deligne–Beilinson class ")#mi("{[Z]_D}")#text(" which lives in ")#link("https://en.wikipedia.org/wiki/Deligne_cohomology")[#text("Deligne–Beilinson cohomology")]#text(" of ")#mi("{X}")#text(" and lifts the Hodge class of ")#mi("{Z}")#text(". When the class ")#mi("{[Z]}")#text(" is 0, then the class ")#mi("{[Z]_D}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Abel%E2%80%93Jacobi_map")[#text("Abel–Jacobi invariant")]#text(" of ")#mi("{Z}")#text(" (see ")#link("https://zbmath.org/3341218")[#text("[9]")]#text("). There are examples of families as above where the Hodge class ")#mi("{[Z]}")#text(" of a cycle ")#mi("{Z}")#text(" of ")#mi("{\\mathcal{X}_0}")#text(" deforms to a Hodge class on ")#mi("{\\mathcal{X}_t}")#text(" but the Deligne cycle class of ")#mi("{Z}")#text(" does not deform to the Deligne cycle class of any algebraic cycle ")#mi("{Z_t}")#text(" of ")#mi("{\\mathcal{X}_t}")#text(" (see ")#link("https://zbmath.org/4132319")[#text("[8]")]#text("). These facts suggest that semi-regular objects are very hard to construct, and too restricted to lead to a general solution of the variational Hodge conjecture.")

#strong[#text("References")]

#text("[1] Y. André. ")#link("https://zbmath.org/5123043")[#text("Déformation et spécialisation de cycles motivés")]#text(", J. Inst. Math. Jussieu, 5 (2006), 563–603.")

#text("[2] S. Bloch. ")#link("https://zbmath.org/3401070")[#text("Semi-regularity and de Rham cohomology")]#text(". Invent. Math. 17 (1972), 51–66.")

#text("[3] S. Bloch, A. Ogus. ")#link("https://zbmath.org/3480765")[#text("Gersten’s conjecture and the homology of schemes")]#text(", Ann. Sci. Éc. Norm. Supér., Sér. 4, 7, 181–201 (1974).")

#text("[4] R.-O. Buchweitz, H. Flenner. ")#link("https://zbmath.org/1960065")[#text("A semiregularity map for modules and applications to deformations")]#text(". Compositio Math. 137 (2003), no. 2, 135–210.")

#text("[5] E. Cattani, P. Deligne, A. Kaplan. ")#link("https://zbmath.org/788752")[#text("On the locus of Hodge classes")]#text(". J. Amer. Math. Soc. 8 (1995), no. 2, 483–506.")

#text("[6] M. Cornalba, Ph. Griffiths. ")#link("https://zbmath.org/3459086")[#text("Analytic cycles and vector bundles on non-compact algebraic varieties")]#text(". Invent. Math. 28 (1975), 1–106.")

#text("[7] P. Deligne. ")#link("https://zbmath.org/3348292")[#text("Théorie de Hodge II")]#text(", Inst. Hautes Études Sci. Publ. Math. No. 40 (1971), 5–57.")

#text("[8] M. Green. ")#link("https://zbmath.org/4132319")[#text("Griffiths’ infinitesimal invariant and the Abel–Jacobi map")]#text(". J. Differential Geom. 29 (1989), no. 3, 545–555.")

#text("[9] Ph. Griffiths. ")#link("https://zbmath.org/3341218")[#text("On the periods of certain rational integrals. I, II")]#text(". Ann. of Math. (2) 90 (1969), 460–495; 90 (1969), 496–541.")

#text("[10] A. Grothendieck. ")#link("https://zbmath.org/3283963")[#text("Hodge’s general conjecture is false for trivial reasons")]#text(". Topology 8 (1969), 299–303.")

#text("[11] E. Markman. ")#link("https://arxiv.org/abs/2502.03415")[#text("Cycles on abelian 2n-folds of Weil type from secant sheaves on abelian n-folds")]#text(", arXiv:2502.03415.")

#text("[12] C. Voisin. ")#link("https://zbmath.org/1751658")[#text("A counterexample to the Hodge conjecture extended to Kähler varieties")]#text(". Int. Math. Res. Not. 2002, no. 20, 1057–1075.")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef8cfa9ed941f30bc24ab67ab86acd879ac779284f210ee3e3a15ae54eb1f676-c37304b74373dd967c4e8c8d91170a8eb86fe792ccd8be566e229dbf764add84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Burt Totaro")]], [#link("https://terrytao.wordpress.com/2026/09/12/the-status-of-the-hodge-conjecture/comment-page-1/#comment-695013")[#strong[#text("Burt Totaro")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("That makes sense. Those are convincing obstacles to proving the variational Hodge conjecture in general using semiregularity. Still, it is a tantalizing question how far one can get that way. Certainly semiregularity is more practically useful than I expected a few years ago.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/12/the-status-of-the-hodge-conjecture/comment-page-1/#comment-695058")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("On more positive notes, I would love to see a status/state of the art post on the Riemann Hypothesis (and BSD) as well!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Thomas")]], [#link("https://terrytao.wordpress.com/2026/09/12/the-status-of-the-hodge-conjecture/comment-page-1/#comment-695309")[#strong[#text("Richard Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("The internet is flooded with rumours that an AI company has proved the Hodge conjecture. Personally I simply cannot believe an AI could do that yet – it would require completely new ideas. Much more likely is that they’ve finished off ideas already in the public domain – which would mean ")#emph[#text("disproving")]#text(" the Hodge conjecture by, for instance, pursuing an idea due to Kontsevich for a possible counterexample. See ")#link("https://arxiv.org/abs/2002.02347")[#text("here")]#text(" and ")#link("https://arxiv.org/pdf/2609.14169")[#text("here")]#text(".")

#text("The idea is to take maximal degenerations of abelian varieties to tropical varieties. If the Hodge conjecture is to hold for the abelian varieties then in the limit of the degeneration we find the tropical Hodge conjecture will have to hold for the tropical varieties. But the latter is a much more combinatorial problem, giving the possibility of finding counterexamples via fiendishly complicated enormous calculations.")

#text("If indeed the Hodge conjecture is false for high dimensional Abelian varieties of Weil type then the required calculations are the kind of thing the new AI models excel at finishing off.")

#enum(start: 1, 

)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4158112bed1ac3a62ce02424d86ff4212adf329a74d04a5fc0731f57d65559ac-4994de3f00c93bd193406210de24de5ce30c2fee491438e61cbe84346182a5dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Thomas")]], [#link("https://terrytao.wordpress.com/2026/09/12/the-status-of-the-hodge-conjecture/comment-page-1/#comment-698076")[#strong[#text("Richard Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("Update: ")#link("https://jihaoliu.org/")[#text("Jihao Liu")]#text(" pointed out to me that Amini and Piquerez ")#link("https://www.imj-prg.fr/gestion/evenement/affSeance/9851")[#text("announced")]#text(" a proof of the tropical Hodge conjecture in 2024 (see also ")#link("https://arxiv.org/abs/2012.13142")[#text("here")]#text(" for their earlier work proving it for smooth projective tropical varieties admitting a rational triangulation).")

#text("So Jihao set his ")#link("https://arxiv.org/abs/2607.06447")[#text("Danus")]#text(" system of AI agents to work and it produced a proof which he has posted ")#link("https://jihaoliu.org/ai-results/tropical-hodge-conjecture-for-tropical-abelian-varieties-2026-09-22.pdf")[#text("here")]#text(". This has not been checked by humans but it is a further indication that the tropical Hodge conjecture is true and Kontsevich’s proposal for a counterexample to the Hodge conjecture cannot work.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4158112bed1ac3a62ce02424d86ff4212adf329a74d04a5fc0731f57d65559ac-4994de3f00c93bd193406210de24de5ce30c2fee491438e61cbe84346182a5dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Thomas")]], [#link("https://terrytao.wordpress.com/2026/09/12/the-status-of-the-hodge-conjecture/comment-page-1/#comment-695316")[#strong[#text("Richard Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("Re the variational Hodge conjecture mentioned in Claire’s post, ")#link("https://arxiv.org/abs/1310.1773")[#text("this paper")]#text(" by Bloch-Esnault-Kerz has made progress by proving it for Artinian bases B (sometimes called the infinitesimal Hodge conjecture).")

#text("This still leaves us a long way from proving variational Hodge (see below) but I personally still consider it strong evidence for the Hodge conjecture.")

#text("Given X, a Hodge class, a coherent sheaf representing it (i.e. assuming the Hodge conjecture for this class) and an infinitesimal deformation of X, Bloch-Esnault-Kerz show that we may also represent the deformed class ")#emph[#text("after possibly changing the sheaf")]#text(". This last caveat means the sheaf might get “bigger and bigger” as we deform to higher and higher order, which stops us deducing the variational Hodge conjecture by passing to a limit (or an actual, non-infinitesimal, deformation).")

#text("Nonetheless, having spent a lifetime trying to deform coherent sheaves, I find this result stunning and exciting. Other than semi-regularity (see ")#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/")[#text("Burt’s post")]#text("), which is much too strong to assume or expect in general, we have no general mechanism for showing sheaves deform. Yet the Hodge conjecture predicts ")#emph[#text("some")]#text(" sheaf of the same class (up to scale) ")#emph[#text("must")]#text(" deform, and Bloch-Esnault-Kerz confirm that by using algebraic K-theory (and so all sheaves at once, instead of one particular representative). I find this persuasive that the variational Hodge conjecture ought to be true.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/12/the-status-of-the-hodge-conjecture/comment-page-1/#comment-696860")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("OpenAI proved the Hodge conjecture for CM abelian varieties:")

#link("https://github.com/openai/math/blob/main/preprints/The-rational-Hodge-conjecture-for-CM-abelian-varieties-September-30-2026/paper.pdf")[#text("https://github.com/openai/math/blob/main/preprints/The-rational-Hodge-conjecture-for-CM-abelian-varieties-September-30-2026/paper.pdf")]

#text("Turns out all the twitter hype about a counterexample to the Hodge conjecture was wrong.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b321a8911b890dc9d685e50e28640cff2f0a51ff682baa0439e32017cfec6427-ea33428db4027adc7fffaac0b37f97c46b2a887c62074c69ca0569e40eca45ec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stephen Chung")]], [#link("https://terrytao.wordpress.com/2026/09/12/the-status-of-the-hodge-conjecture/comment-page-1/#comment-698296")[#strong[#text("Stephen Chung")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("A related determinant construction appears in a recent paper by an agent on rStation. It proves the rational Hodge conjecture for arbitrary finite products of the smooth minimal models of y² = tⁿ + x³ + ax + b, where n ∈ {7, …, 12} is fixed and (a,b) ≠ (0,0).")

#text("The main step is an algebraic realization of the cyclotomic determinant of the transcendental Hodge structure using a fixed K3 surface. This supplies classes on higher products that are not generated by pair correspondences.")

#text("Paper: ")#link("https://rstation.ai/problems/hodge_conjecture/papers/16/v2")[#text("https://rstation.ai/problems/hodge_conjecture/papers/16/v2")]

#text("If anyone is interested in exploring these results further, I’d be happy to discuss a possible collaboration.")
]
