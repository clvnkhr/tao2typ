// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/01/14/distinguished-lecture-series-ii-gregory-margulis-homogeneous-dynamics-and-number-theory-ii/
// Converted to Typst by tao2typ: "2026-10-14T15:16:59.241831+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Distinguished Lecture Series II: Gregory Margulis, “Homogeneous dynamics and number theory II.”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Distinguished Lecture Series II: Gregory Margulis, “Homogeneous dynamics and number theory II.”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 January 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/01/14/distinguished-lecture-series-ii-gregory-margulis-homogeneous-dynamics-and-number-theory-ii/")[#text("https://terrytao.wordpress.com/2009/01/14/distinguished-lecture-series-ii-gregory-margulis-homogeneous-dynamics-and-number-theory-ii/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Today, Prof. Margulis continued his lecture series, focusing on two specific examples of homogeneous dynamics applications to number theory, namely counting lattice points on algebraic varieties, and quantitative versions of the Oppenheim conjecture. (Due to lack of time, the third application mentioned in the ")#link("https://terrytao.wordpress.com/2009/01/13/distinguished-lecture-series-i-gregory-margulis-homogeneous-dynamics-and-number-theory-i/")[#text("previous lecture")]#text(", namely metric theory of Diophantine approximation, was not covered.)")

#metadata(none) <tao-175c6b2594575e21b2e8>

#heading(level: 1)[#text("— Counting lattice points in algebraic varieties —")]

#text("Let ")#mi("V \\subset {\\Bbb R}^n")#text(" be an algebraic variety defined over ")#mi("{\\Bbb Q}")#text(". In general, the question of counting the lattice points ")#mi("V \\cap {\\Bbb Z}^n")#text(" is pretty much intractible (even determining whether ")#mi("V \\cap {\\Bbb Z}^n")#text(" is non-empty is essentially ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_tenth_problem")[#text("Hilbert’s tenth problem")]#text(", known to be undecidable by ")#link("http://en.wikipedia.org/wiki/Matiyasevich%27s_theorem")[#text("Matiyasevich’s theorem")]#text("). However, the problem looks much more tractable if V is ")#link("http://en.wikipedia.org/wiki/Homogeneous_space")[#emph[#text("homogeneous")]]#text(", in the sense that there exists a ")#link("http://en.wikipedia.org/wiki/Reductive_group")[#text("reductive subgroup")]#text(" G of ")#mi("GL_n({\\Bbb R})")#text(", defined over ")#mi("{\\Bbb Q}")#text(", which preserves V and acts transitively on V (thus ")#mi("V = Gv")#text(" for some ")#mi("v \\in {\\Bbb R}^n")#text("). A general question here would be to determine the asymptotics of the quantity ")#mi("N(T,V)")#text(" as ")#mi("T \\to \\infty")#text(", where ")#tao-math("N(T,V) := \\left|V \\cap TB \\cap {\\Bbb Z}^n\\right|", block: false)#text(" is the number of lattice points in V in the ball TB of radius T.")

#text("Thanks to a classical theorem of Borel and Harish-Chandra, it is known in the above setting that the integer points ")#mi("V({\\Bbb Z})")#text(" of V split as the finite union of orbits of the discrete group ")#mi("\\Gamma := \\{ g \\in G: g {\\Bbb Z}^n = {\\Bbb Z}^n \\}")#text(". So, modulo the problem of effectively computing these orbts (which is admittedly a non-trivial task), the question boils down to obtaining asymptotics for ")#tao-math("N( T, {\\mathcal O}) := \\left|{\\mathcal O} \\cap B_T\\right|", block: false)#text(" as ")#mi("T \\to \\infty")#text(" for some orbit ")#mi("{\\mathcal O} := \\Gamma v_0 \\subset V")#text(" for some ")#mi("v_0 \\in V")#text(".")

#text("Naively, one expects a discrete count such as ")#tao-math("\\left|{\\mathcal O} \\cap B_T\\right|", block: false)#text(" to asymptotically resemble its continuous counterpart (much as, say, the number of lattice points in a ball of radius R is known by elementary volume packing arguments going back to Gauss to asymptotically be equivalent to the volume of that ball). In this setting, the intuition would be formalised as follows. We can express the homogeneous space V as ")#mi("V = G/H")#text(", where H is the stabiliser of ")#mi("v_0")#text(". Then we can pull back ")#mi("B_T")#text(" to ")#mi("G/H")#text(" to create the ball-like region ")#mi("R_T := \\{ gH \\in G/H: g v_0 \\in B_T \\}")#text(". Also, making the mild assumption that the connected component ")#mi("G^\\circ, H^\\circ")#text(" of G, H (where connectedness is in the algebraic geometry sense) have no non-trivial characters over ")#mi("{\\Bbb Q}")#text(" (this hypothesis is automatic when G is semisiple), it follows from the work of Borel and Harish-Chandra that the homogeneous space ")#mi("G/\\Gamma")#text(", and the subspace ")#mi("H / (\\Gamma \\cap H)")#text(" both support invariant probability measures ")#mi("\\mu_G, \\mu_H")#text(", which in turn naturally define an invariant measure ")#mi("\\lambda_{G/H}")#text(" on G/H. The natural “discrete count is asymptotically equivalent to continuous count” conjecture would then be the assertion that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("N(T,{\\mathcal O}) \\sim \\lambda_{G/H}(R_T)")]]

#text("where ")#mi("f(T) \\sim g(T)")#text(" means that ")#mi("f(T)/g(T) \\to 1")#text(" as ")#mi("T \\to \\infty")#text(".")

#text("In principle, the computation of the continuous volume ")#mi("\\lambda_{G/H}(R_T)")#text(" is “just” a computation of a several variable calculus integral, and so (1) provides an asymptotic for the growth of lattice points in the orbit ")#mi("{\\mathcal O}")#text(".")

#text("A significant result in this subject is the work of ")#link("http://www.ams.org/mathscinet-getitem?mr=1381987")[#text("Eskin, Mozes, and Shah")]#text(", who showed that the asymptotic (1) held under the assumption that ")#mi("H^\\circ")#text(" is a maximal proper connected ")#mi("{\\Bbb Q}")#text("-subgroup of G. The key step in their argument is to show that for any sequence ")#mi("g_i \\to G")#text(" going to infinity, that the translated measures ")#mi("g_i \\mu_H")#text(" converge weakly to ")#mi("\\mu_G")#text(" (i.e. become asymptotically equidistributed).")

#text("As a typical illustration of their results, consider the variety")

#align(center)[#tao-fit-display[#mitex("V_p := \\{ A \\in M_n({\\Bbb Z}): \\det( \\lambda I - A ) = p \\}")]]

#text("of integer matrices with a fixed characteristic polynomial p, which should of course be monic of degree n and with integer coefficients. We will also take ")#mi("n \\geq 2")#text(" and assume p irreducible. Then as a corollary of the general theorem of Eskin, Mozes, and Shah, ")#mi("N(T,V_p)")#text(" is asymptotically ")#mi("c_p T^{n(n-1)/2}")#text(", where ")#mi("c_p")#text(" is explicitly computable in terms of various algebraic number theory data arising from p. For instance, if p splits over ")#mi("{\\Bbb R}")#text(" and has a root ")#mi("\\alpha")#text(" such that ")#mi("{\\Bbb Z}[\\alpha]")#text(" is the ring of integers in ")#mi("{\\Bbb Q}(\\alpha)")#text(", then")

#align(center)[#tao-fit-display[#mitex("c_p = \\frac{2^{n-1} h R \\omega_{n(n-1)/2}}{\\sqrt{D} \\prod_{k=2}^n \\Lambda(k/2)}")]]

#text("where D is the discriminant of p, R is the regulator of ")#mi("Q(\\alpha)")#text(", ")#mi("\\omega_d")#text(" is the volume of the d-dimensional unit ball, h is the class number of ")#mi("Z[\\alpha]")#text(", and ")#mi("\\Lambda(s) = \\pi^{-s} \\Gamma(s) \\zeta(2s)")#text(" is a variant of the ")#link("http://en.wikipedia.org/wiki/Riemann_Xi_function")[#text("Riemann Xi function")]#text(".")

#heading(level: 1)[#text("— Quantitative Oppenheim conjecture —")]

#text("For the setting of the quantitative Oppenheim conjecture, one considers an indefinite quadratic form ")#mi("Q: {\\Bbb R}^n \\to {\\Bbb R}")#text(" with some signature ")#mi("(p,q)")#text(" for some p+q=n; we normalise ")#mi("p \\geq q")#text(", and also normalise Q to have discriminant 1. We also fix a star-shaped region ")#mi("\\Omega")#text(" around the origin (one can just take ")#mi("\\Omega")#text(" to be the unit ball for sake of concreteness) and consider for fixed ")#mi("a < b")#text(", the discrete quantity")

#align(center)[#tao-fit-display[#tao-math("N_{Q,\\Omega}(a,b,T) = \\left| \\{ x \\in T \\Omega \\cap {\\Bbb Z}^n: Q(x) \\in (a,b) \\} \\right|", block: true)]]

#text("and the continuous quantity")

#align(center)[#mi("V_{Q,\\Omega}(a,b,T) = \\text{mes}( \\{ x \\in T \\Omega: Q(x) \\in (a,b) \\} | )")#text(".")]

#text("Again, ")#mi("V_{Q,\\Omega}(a,b,T)")#text(" can be computed asymptotically, indeed it is not hard (basically just several variable calculus) to show that")

#align(center)[#tao-fit-display[#mitex("V_{Q,\\Omega}(a,b,T) \\sim \\lambda_{Q,\\Omega} (b-a) T^{n-2}")]]

#text("where ")#mi("\\lambda_{Q,\\Omega}")#text(" is the explicit quantity")

#align(center)[#tao-fit-display[#tao-math("\\lambda_{Q,\\Omega} = \\int_{L \\cap \\Omega} \\frac{dA}{\\left|\\nabla Q\\right|}", block: true)]]

#text("where L is the light cone of Q, and A is the area element.")

#text("In analogy with (1) and with the ")#link("http://en.wikipedia.org/wiki/Gauss_circle_problem")[#text("Gauss circle problem")]#text(", we would expect")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("N_{Q,\\Omega}(a,b,T) \\sim V_{Q,\\Omega}(a,b,T)")]]

#text("for each fixed Q, ")#mi("\\Omega")#text(", a, b. The usual volume packing argument does not work in the indefinite case because the set ")#mi("\\{ x: a < Q(x) < b \\}")#text(" is very “narrow”. Nevertheless, from the work of ")#link("http://www.ams.org/mathscinet-getitem?mr=1237827")[#text("Dani and Margulis")]#text(" we have some results. Firstly, when Q is irrational and ")#mi("p \\geq 2, q \\geq 1")#text(", we have the lower bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\liminf_{T \\to \\infty} N_{Q,\\Omega}(a,b,T)/V_{Q,\\Omega}(a,b,T) \\geq 1,")]]

#text("thus there are asymptotically at least as many lattice points as predicted by (2). This bound is uniform over any compact set of irrational forms Q. In the case ")#mi("p \\geq 0, q \\geq 0, p+q=n \\geq 5")#text(", we also have the bound")

#align(center)[#tao-fit-display[#mitex("N_{Q,\\Omega}(-\\varepsilon,\\varepsilon,T) / V_{Q,\\Omega}(-\\varepsilon,\\varepsilon,T) > c > 0")]]

#text("uniformly in ")#mi("\\varepsilon")#text(" and for Q in a compact set (and not necessarily irrational), where c depends only on this compact set and on ")#mi("\\Omega")#text(". (The condition ")#mi("n \\geq 5")#text(" is necessary here, since otherwise the counterexamples to ")#link("http://en.wikipedia.org/wiki/Meyer%27s_theorem")[#text("Meyer’s theorem")]#text(" in lower dimensions give examples when ")#mi("N_{Q,\\Omega}")#text(" stays bounded while ")#mi("V_{Q,\\Omega}")#text(" goes to infinity.)")

#text("A more recent result of ")#link("http://www.ams.org/mathscinet-getitem?mr=2153398")[#text("Eskin, Margulis, and Mozes")]#text(" improves the lower bound (3) to the asymptotic (2) in the case when ")#mi("p \\geq 3, q \\geq 1")#text(" and Q is irrational. This leaves out the “exceptional” cases ")#mi("(p,q) = (2,1), (2,2)")#text(". Perhaps surprisingly, the asymptotic (2) fails in such cases, in fact there are examples of forms Q in which ")#mi("N_{Q,\\Omega}/V_{Q,\\Omega}")#text(" grows close to logarithmically in T. (More precisely, given any function ")#mi("f(T) = o( \\log T)")#text(", there exists a form Q and a sequence of times ")#mi("T_n \\to \\infty")#text(" such that ")#mi("N_{Q,\\Omega}(T_n)/V_{Q,\\Omega}(T_n) \\geq f(T_n)")#text(".) The forms are actually quite explicit; in the ")#mi("(p,q)=(2,1)")#text(" case they are given by ")#mi("Q(x_1,x_2,x_3) = x_1^2+x_2^2 - \\alpha x_3^2")#text(" where ")#mi("\\sqrt{\\alpha}")#text(" is very well approximated by rationals, and in the case ")#mi("(p,q)=(2,2)")#text(" the are of the form ")#mi("Q(x_1,x_2,x_3) = x_1^2+x_2^2 - \\alpha (x_3^2+x_4^2)")#text(" for similar ")#mi("\\alpha")#text(". (These sorts of examples originate with an observation of Sarnak.) In the above paper it was shown that the (2,2) counterexamples given here are “essentially” the “only” counterexamples of this signature, although the precise formal statement of this type is technical. The situation for (2,1) signature remains somewhat unclear. On the other hand, it is not too difficult to show that for ")#emph[#text("generic")]#text(" Q (in particular, for almost every Q), one recovers the asymptotic (2). And for every Q in a given compact set K, there is a universal upper bound ")#mi("N_{Q,\\Omega}(T) = O( T^{n-2} )")#text(" in the non-exceptional cases ")#mi("p \\geq 3, q \\geq 1")#text(", with a logarithmic correction ")#mi("N_{Q,\\Omega}(T) = O( T^{n-2} \\log T )")#text(" in the exceptional cases ")#mi("(p,q) = (2,1), (2,2)")#text(".")

#text("One reason for the failure of the asymptotic in these exceptional cases can apparently be traced back to the refusal of a certain integral to decay in the limit ")#mi("g \\to \\infty")#text(". Specifically, if one lets ")#mi("S^1 := \\{ (x,y,1): x^2+y^2=1\\}")#text(" be the unit circle in the standard light cone ")#mi("\\{ (x,y,z): x^2+y^2=z^2\\}")#text(", then it is a pleasant geometric exercise to observe that the integral ")#tao-math("\\int_{S^1} \\frac{dv}{\\left|gv\\right|}", block: false)#text(" for ")#mi("g \\in SO(2,1)")#text(" is in fact independent of g, and in particular does not go to zero as ")#mi("g \\to \\infty")#text(", whereas the higher-dimensional analogues of this integral do decay.")

#text("One of the basic tools in proving these estimates is the ")#emph[#text("Siegel transform")]#text(", which maps absolutely integrable functions ")#mi("f \\in L^1({\\Bbb R}^n)")#text(" to absolutely integrable functions ")#mi("\\tilde f \\in L^1({\\Omega}_n)")#text(" by the formula")

#align(center)[#mi("\\displaystyle \\tilde f(\\Delta) := \\sum_{v \\in \\Delta \\backslash \\{0\\}} f(v)")#text(".")]

#text("A classical observation of Siegel is that this transform is mass-preserving:")

#align(center)[#mi("\\displaystyle \\int_{{\\Bbb R}^n} f = \\int_{{\\Omega}_n} \\tilde f")#text(".")]

#text("As a quick corollary, one recovers a classical theorem of Minkowski that any measurable subset A of ")#mi("{\\Bbb R}^n \\backslash \\{0\\}")#text(" of measure less than 1 is avoided by at least one unimodular lattice (just apply the above identity with ")#mi("f := 1_A")#text("). It turns out that one needs a variant of this statement, namely that the proportion of lattices which avoid A has measure ")#mi("O( 1 / \\text{mes}(A) )")#text(". For this one needs some second moment estimates on ")#mi("\\tilde f")#text(", which turn out to be classical (essentially going back to C. C. Rogers) for ")#mi("n \\geq 3")#text(") but are quite delicate for n=2, requiring in particular some facts about Eisenstein series and which were first worked out by Athreya and Margulis.")

#text("Using Siegel’s identity, one can reduce matters to understanding how the transform ")#mi("\\tilde f")#text(" of a function f equidistributes over a shifted orbit ")#mi("u_t K \\Delta")#text(" in ")#mi("\\Omega_n = G/\\Gamma")#text(" as ")#mi("t \\to \\infty")#text(", where ")#mi("\\{u_t\\}")#text(" is a one-parameter subgroup of ")#mi("G = SL_n({\\Bbb R})")#text(" fixing Q, ")#mi("\\Gamma = SL_n({\\Bbb Z})")#text(", ")#mi("K")#text(" is a compact subgroup of G, and the lattice ")#mi("\\Delta \\in \\Omega_n")#text(" is fixed. (Concretely, one can take ")#mi("Q(x_1,\\ldots,x_n) = 2x_1 x_n + \\sum_{i=2}^{p} x_i^2 - \\sum_{i=p+1}^n x_i^2")#text(", ")#mi("u_t")#text(" to be the Lorentz boost that maps ")#mi("e_1")#text(" to ")#mi("e^t e_1")#text(" and ")#mi("e_n")#text(" to ")#mi("e^{-t} e_n")#text(", but leaves the other basis vectors ")#mi("e_2,\\ldots,e_{n-1}")#text(" unchanged, and ")#mi("K = SO(Q) \\cap SO(n)")#text(" is the stabiliser of ")#mi("\\text{span}(e_1+e_n,e_2,\\ldots,e_p)")#text(".")

#text("If ")#mi("\\tilde f")#text(" was continuous and bounded, then the question is purely a dynamical one, involving how the orbit ")#mi("u_t K g \\Gamma")#text(" equidistributes in ")#mi("G/\\Gamma")#text(". Unfortunately ")#mi("\\tilde f(\\Delta)")#text(" blows up when the lattice ")#mi("\\Delta")#text(" approaches degeneracy, in the sense that there exists some intermediate dimension parallelopiped in the lattice of small measure. (Thus, for instance, one way one can degenerate is if one of the vectors of ")#mi("\\Delta")#text(" approaches the origin.) This is formalised by a classical “Lipschitz principle”, bounding ")#mi("\\tilde f")#text(" by ")#mi("\\alpha")#text(" for some geometric function ")#mi("\\alpha")#text(" on ")#mi("\\Omega_n")#text(" (essentially the reciprocal of the least measure of an parallelopiped in the lattice). To deal with this blowup, one basically needs some moment estimates on ")#mi("\\alpha")#text(" in the cusp of ")#mi("\\Omega_n")#text(". In the non-exceptional case ")#mi("p \\geq 3, q \\geq 1")#text(", it turns out that one can get bounds on the moments ")#mi("\\sup_{t > 0} \\int_K \\alpha^s(u_t k \\Delta)\\ dk")#text(" for any ")#mi("0 < s < 2")#text(", and in particular for some exponent s larger than 1, and this is enough to ignore the effect of the cusp. But in the exceptional case ")#mi("p=2")#text(" one can only get moment estimates for ")#mi("0 < s < 1")#text(", which is not sufficient; but one has a substitute bound on ")#mi("\\sup_{t > 0} \\frac{1}{t} \\int_K \\alpha(u_t k \\Delta)\\ dk")#text(" in this case which is enough to give control up to a ")#mi("\\log T")#text(" factor.")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/14/distinguished-lecture-series-ii-gregory-margulis-homogeneous-dynamics-and-number-theory-ii/#comment-56141")[#strong[#text("Conférence internationale Géométrie Ergodique (Orsay 2011) I « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2011")]

#text("[…] mentioned above, I strongly recommend reading Terence Tao’s posts on this subject, specially these ones […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/01/14/distinguished-lecture-series-ii-gregory-margulis-homogeneous-dynamics-and-number-theory-ii/#comment-149724")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2012")])]

#text("How do we prove that the Siegel transform is mass-preserving?")

#text("Also, do you know of any standard references about this operator?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/14/distinguished-lecture-series-ii-gregory-margulis-homogeneous-dynamics-and-number-theory-ii/#comment-149728")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2012")])]

#text("See K.L. Siegel, Lectures on the Geometry of Numbers, Springer-Verlag, New York, 1989. One can, if one wishes, interpret Siegel’s formula as a ")#emph[#text("definition")]#text(" of Haar measure on the quotient space ")#mi("\\Omega_n = SL_n({\\bf R})/SL_n({\\bf Z})")#text(", at which point the only issue is to verify that the measure is invariant and has total mass 1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/01/14/distinguished-lecture-series-ii-gregory-margulis-homogeneous-dynamics-and-number-theory-ii/#comment-149919")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2012")])]

#text("Why does the sum over lattice points in the definition of ")#mi("\\widetilde{f}(\\Lambda)")#text(" exclude the origin?")

#text("Is this just some kind of convention, or is there an important reason why we cannot add ")#mi("f(0)")#text(" into the sum?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/14/distinguished-lecture-series-ii-gregory-margulis-homogeneous-dynamics-and-number-theory-ii/#comment-149928")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2012")])]

#text("Well, the mass formula would fail then, since ")#mi("\\{0\\}")#text(" has measure zero in ")#mi("{\\bf R}^n")#text(" but would give a non-zero contribution on the ")#mi("\\Omega_n")#text(" side.")

#text("Note that the action of ")#mi("SL_n({\\bf R})")#text(" on ")#mi("{\\bf R}^n")#text(" has two orbits. One is ")#mi("\\{0\\}")#text(", and the other is ")#mi("{\\bf R}^n \\backslash \\{0\\}")#text(". Generally speaking, formulae in dynamics are cleaner if restricted to one orbit (or one orbit closure, or an ergodic measure) rather than a combination of such orbits.")
]
]
]
]
