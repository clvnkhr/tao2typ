// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/
// Converted to Typst by tao2typ: "2026-10-27T12:30:10.124831+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "More additional blog posts and articles", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("More additional blog posts and articles")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/")[#text("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-27 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#list(
[#text("Pavel Etingof, Slava Gerovitch, “")#link("https://math.mit.edu/~etingof/futuremath.pdf")[#text("Mathematics of the Future")]#text("“")],
[#text("Timothy Gowers, “")#link("https://gowers.wordpress.com/2026/10/16/how-worried-should-we-be-about-extinction-risk-from-ai/")[#text("How worried should we be about extinction risk from AI?")]#text("“")],
[#text("Elchanan Mossel, “")#link("https://arxiv.org/abs/2601.02380")[#text("LLMs, Reasoning and Plagiarism")]#text("“. (See also ")#link("https://math.mit.edu/~elmos/petition.html")[#text("this related petition")]#text(".)")],
[#text("nihilunbounded, “")#link("https://nihilunbounded.substack.com/p/who-watches-the-watchmen")[#text("Who Watches the Watchmen")]#text("“")],
[#text("Sung-Jin Oh, “")#link("https://math.berkeley.edu/~sjoh/index.html#essay")[#text("What does it mean for a mathematician to understand? A case study in the age of AI")]#text("“")],
[#text("Ben Recht, “")#link("https://www.argmin.net/p/the-world-is-something-we-make")[#text("The World Is Something We Make")]#text("“")],
[#text("Manuel Luis Rivera, “")#link("https://vislumbres.github.io/#/post/raw-mathematics")[#text("Raw Mathematics")]#text("“")],
[#text("Grant Sanderson, “")#link("https://www.youtube.com/watch?v=LKrwhjOI8Nc")[#text("There’s never been a better time to go into math")]#text("“")]
)

#text("As before, readers are invited to contribute links to additional posts not already covered here (or at Proofs and Prompts) in the comments.")

#heading(level: 1)[#text("Comments (1)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81d3b09e12c1ffa40e14f72149df371575d986372b44584c682fdce06dd04724-e20bb59052a5b25f43f87bdf7347409769fe867005e0b68a7edf967b9b3673af.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Ryskamp")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698837")[#strong[#text("John Ryskamp")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Make sure you read Alejandro Garciadiego’s book, Bertrand Russell and the Origins of the Set-theoretic ‘Paradoxes.’ It began the process of what we call mathematics and logic.")
]
