// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/
// Converted to Typst by tao2typ: "2026-10-28T13:17:14.415232+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "More additional blog posts and articles", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("More additional blog posts and articles")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/")[#text("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-28 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#list(
[#text("Pavel Etingof, Slava Gerovitch, “")#link("https://math.mit.edu/~etingof/futuremath.pdf")[#text("Mathematics of the Future")]#text("“")],
[#text("Timothy Gowers, “")#link("https://gowers.wordpress.com/2026/10/16/how-worried-should-we-be-about-extinction-risk-from-ai/")[#text("How worried should we be about extinction risk from AI?")]#text("“")],
[#text("Elchanan Mossel, “")#link("https://arxiv.org/abs/2601.02380")[#text("LLMs, Reasoning and Plagiarism")]#text("“. (See also ")#link("https://math.mit.edu/~elmos/petition.html")[#text("this related petition")]#text(".)")],
[#text("nihilunbounded, “")#link("https://nihilunbounded.substack.com/p/who-watches-the-watchmen")[#text("Who Watches the Watchmen")]#text("“")],
[#text("Sung-Jin Oh, “")#link("https://math.berkeley.edu/~sjoh/index.html#essay")[#text("What does it mean for a mathematician to understand? A case study in the age of AI")]#text("“")],
[#text("Ben Recht, “")#link("https://www.argmin.net/p/the-world-is-something-we-make")[#text("The World Is Something We Make")]#text("“")],
[#text("Manuel Luis Rivera, “")#link("https://vislumbres.github.io/#/post/raw-mathematics")[#text("Raw Mathematics")]#text("“")],
[#text("Grant Sanderson, “")#link("https://www.youtube.com/watch?v=LKrwhjOI8Nc")[#text("There’s never been a better time to go into math")]#text("“")]
)

#text("As before, readers are invited to contribute links to additional posts not already covered here (or at Proofs and Prompts) in the comments.")

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81d3b09e12c1ffa40e14f72149df371575d986372b44584c682fdce06dd04724-e20bb59052a5b25f43f87bdf7347409769fe867005e0b68a7edf967b9b3673af.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Ryskamp")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698837")[#strong[#text("John Ryskamp")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Make sure you read Alejandro Garciadiego’s book, Bertrand Russell and the Origins of the Set-theoretic ‘Paradoxes.’ It began the process of what we call mathematics and logic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b52796f5953bd198c7a8f665c49d979b54adbb7be9b9502491f6ae6a1e29267-b798674221bbe8c8b7d6e6e7fbd9dfb3eaa8304bd696584e006950d38098d2e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698838")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Maybe it’s worth mentioning that Etingof consults for Anthropic")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9dbe4fe719bacb5077afdfe0dc0b12e61e51ed2f290dd6cd05c0eaf471694bd7-362bd281955d8e9bed1e39bb8725dee2db027049f2da95bcace54b5fe93ea817.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Florian Breuer")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698840")[#strong[#text("Florian Breuer")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("I’ve now seen many articles which look at what AI is capable of now and discusses how we can harness this ability, e.g. to build new theories while AI proves theorems for us. But what if AI keeps getting better at the same rate as the last two years?")

#text("I wrote my own take here: ")#link("https://florianbreuer.github.io/florianbreuer/FutureVision.html")[#text("https://florianbreuer.github.io/florianbreuer/FutureVision.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698848")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Elchanan Mossel’s “paper”, what a bunch garbage. A paper that starts with a premise, that it is then the conclusion. Really, some mathematicians are really embarrassing, in their reactions to the LLM phenomenon. “two incompatible narratives”, why? the paper postulates that, but the distinction between original research and imitation has a blurry boundary that is is anything but “incompatible”.")

#text("And Andrew Critch is part of MAISI? I have a lot less reassurance, that that institution will contribute to save us.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of R")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698857")[#strong[#text("R")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("The big boss of MAISI has no expertise in AI safety (writing an awkward scifi paper does not make one an expert), fundraised private money and use it unregulated, and saved himself basically all recruit process authority. What could you expect from this institute from the first place.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698849")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("I don’t understand the point of MAISI and Gowers’ article. Extinction risk is just the red cloth to distract people from real societal risks like unemployment, people getting less intelligent, concentration of wealth, IP theft and so on.")

#text("Even regarding the extinction risk itself Gowers does not make very good points and oscillates between treating the AI as a sentient being and a machine. It is an algorithm seeded by a random number generator that also depends on ordering of floating point point operations, which introduce more “randomness”. You could run it fully deterministically by using the same random seed, same context and same GPU scheduling.")

#text("Don’t connect the thing to the Internet and don’t allow agents that execute hallucinated commands.")

#text("Again, the real issues are SEO slop, influencing, mass propaganda, AI psychosis, unemployment etc.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6dd12d83808476959cf0f28e8cf5c1101ad2169efad7a66e1f911af8e8819014-7b9961f61d21cb1f240f40a6ff876022502c8f82ee04c4a04d235e567376d2bb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698860")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("The AI companies and the people in them have talked and cared about extinction risk for over 10 years, long before any current developments were foreseeable. It clearly isnt just a red cloth, but something that the AI companies (and many people in the field, like Hinton) earnestly believe. I think they are wrong about that, but that mean that they are dishonest in their concerns. It also doesn’t mean that you can not care about other issues. In fact, I suspect that caring about one will bolster the effort in caring about others.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698861")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Yes, I am wondering the same thing. Why have people become so fantastical. AI is after all an algorithm being run. Why are we handing it any kind of responsibility? Has everyone stopped analyzing things from first principles way in the age of hype and mindless data grabbing.")

#link("https://thebulletin.org/2026/09/rogue-ai-didnt-breach-hugging-face-human-decisions-did/")[#text("https://thebulletin.org/2026/09/rogue-ai-didnt-breach-hugging-face-human-decisions-did/")]#text(" ")#linebreak()#link("https://aiguide.substack.com/p/misleading-metaphors-and-real-risks")[#text("https://aiguide.substack.com/p/misleading-metaphors-and-real-risks")]#linebreak()#link("https://faculty.washington.edu/ebender/papers/Bender-AI-2026.pdf")[#text("https://faculty.washington.edu/ebender/papers/Bender-AI-2026.pdf")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698850")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Ben Recht:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Knowledge workers drive themselves insane in a flow state with their stochastic productivity software")
]

#text("Perhaps I am the exception, but I have the opposite problem. AI is so much fun I end up crowding out the rest of my life to spend time playing with it.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("If you haven’t found a way to run an open model in an open harness and see that it’s probably good enough for 99% of your work, you are very much missing out!")
]

#text("Really, it’s more like 10%, so not worth my time to try and figure out which 10% of my work it’s good for. Maxed-out frontier models are ")#strong[#text("so")]#text(" much better than anything else.")

#text("I do agree with the sentiment of trying to train a truly frontier-level open model. Problem is that it’s prohibitively expensive for the foreseeable future. I miss the days when you could do cutting-edge machine learning research at home.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e1b495630829824859f1c4ebbe6fbfb62d8d55a79046e735a30ef6fea04761a-db42d6d4b5cb007e950fc2fb2f86efb4e2621ae93f29570f780b99f22b55cb0e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aksenchuk Aleksandr")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698854")[#strong[#text("Aksenchuk Aleksandr")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Thank you for saying this. I am a math student, and I have such a huge anxiety about my future. I have always dreamed of being a math researcher, but now I don’t think that is feasible as the field became even more unstable, and I am neither particularly bright nor have many academic opportunities. I have hard time using social media because people everywhere on the Internet say that my degree will be useless in a few years. I can’t focus on doing math problems because I often think that my efforts is a complete waste of time; AI supposedly does everything better than me anyway. I honestly think switching to education to teach in high school, but what breaks my heart is that I will never be able to interact with high-level mathematics anymore. (besides, many AI bros already argue that public education is unnecessary).")

#text("I know that I am not the only one who feels the same. And instead of addressing the real worries of people who live in the age of AI, Gowers, MAISI, and tech bros write weak, pointless philosophical articles. They say that they care about people, and that is why they are doing what they are doing. But what about me, and many other people who go through this crisis? Why are they not doing anything to protect math students? At least, offer some words of encouragement or career guidance. Instead, they are already live in the astral space, compute P(doom) and think how they will fight against robot invasion. And we trust these people with AI safety. I am honestly so scared for the future.")
]
