// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/
// Converted to Typst by tao2typ: "2026-11-27T16:52:39.041111+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "More additional blog posts and articles", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("More additional blog posts and articles")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/")[#text("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-27 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#list(
[#text("Pavel Etingof, Slava Gerovitch, “")#link("https://math.mit.edu/~etingof/futuremath.pdf")[#text("Mathematics of the Future")]#text("“")],
[#text("Timothy Gowers, “")#link("https://gowers.wordpress.com/2026/10/16/how-worried-should-we-be-about-extinction-risk-from-ai/")[#text("How worried should we be about extinction risk from AI?")]#text("“")],
[#text("Elchanan Mossel, “")#link("https://arxiv.org/abs/2601.02380")[#text("LLMs, Reasoning and Plagiarism")]#text("“. (See also ")#link("https://math.mit.edu/~elmos/petition.html")[#text("this related petition")]#text(".)")],
[#text("nihilunbounded, “")#link("https://nihilunbounded.substack.com/p/who-watches-the-watchmen")[#text("Who Watches the Watchmen")]#text("“")],
[#text("Sung-Jin Oh, “")#link("https://math.berkeley.edu/~sjoh/index.html#essay")[#text("What does it mean for a mathematician to understand? A case study in the age of AI")]#text("“")],
[#text("Ben Recht, “")#link("https://www.argmin.net/p/the-world-is-something-we-make")[#text("The World Is Something We Make")]#text("“")],
[#text("Manuel Luis Rivera, “")#link("https://vislumbres.github.io/#/post/raw-mathematics")[#text("Raw Mathematics")]#text("“")],
[#text("Grant Sanderson, “")#link("https://www.youtube.com/watch?v=LKrwhjOI8Nc")[#text("There’s never been a better time to go into math")]#text("“")]
)

#text("As before, readers are invited to contribute links to additional posts not already covered here (or at Proofs and Prompts) in the comments.")

#heading(level: 1)[#text("Comments (23)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/713e26d4d6914c0a55b77499a8e1cd2bc5a6ec3d0f8fa25eaa5303f555fb621d-a1a21053f7ddb3a459d2892e57c177a7b113e1dbc1ffa24bd5f60b4ec2fe8846.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Ryskamp")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-698837")[#strong[#text("John Ryskamp")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Make sure you read Alejandro Garciadiego’s book, Bertrand Russell and the Origins of the Set-theoretic ‘Paradoxes.’ It began the process of what we call mathematics and logic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc87b7d7ea8b41f011d5f12d67370d9c42f45ae44e2223d249d7c6bf3ab8c887-e70337d799c323af9beed95cdc3de6965ea2b6eb38ae9528daac0bf69c812043.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-698838")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Maybe it’s worth mentioning that Etingof consults for Anthropic")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5677266fbfc2c564f8a1e7f8b291c46a3ff10f2f8c5365242e796cecacb204ea-09cb9bc1dfc24c4fc5078f68a852a2f63f454284724f199a0f2d0e059b2461ff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Florian Breuer")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-698840")[#strong[#text("Florian Breuer")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("I’ve now seen many articles which look at what AI is capable of now and discusses how we can harness this ability, e.g. to build new theories while AI proves theorems for us. But what if AI keeps getting better at the same rate as the last two years?")

#text("I wrote my own take here: ")#link("https://florianbreuer.github.io/florianbreuer/FutureVision.html")[#text("https://florianbreuer.github.io/florianbreuer/FutureVision.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-698848")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Elchanan Mossel’s “paper”, what a bunch garbage. A paper that starts with a premise, that it is then the conclusion. Really, some mathematicians are really embarrassing, in their reactions to the LLM phenomenon. “two incompatible narratives”, why? the paper postulates that, but the distinction between original research and imitation has a blurry boundary that is is anything but “incompatible”.")

#text("And Andrew Critch is part of MAISI? I have a lot less reassurance, that that institution will contribute to save us.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of R")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-698857")[#strong[#text("R")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("The big boss of MAISI has no expertise in AI safety (writing an awkward scifi paper does not make one an expert), fundraised private money and use it unregulated, and saved himself basically all recruit process authority. What could you expect from this institute from the first place.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-698871")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Tsimerman is a genuine brilliant problem solver, and mathematician. His talk at MSRI was, together with Gill Kallai’s and Tim Gowers’ first one, the only two that Tao has posted that I didn’t have a bone to pick.")

#text("Very far from the many others that the deeper they got was to say “but human understanding”, or the embarrasing Ludites at AHM.")

#text("On the other hand, Andrew Critch is not a good mathematician. He is on the charlatan spectrum. His version of problem solving is to muddle the problem enough that his explanation seems to fit his answer even though the answer is the opposite.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b2471604c8902ec9746d53afa441873dadc9012b5022d6ff0bc83852a9993e-b8d80f565218ccfbd08a65971f9e4d3de692f80225ef4b30178db5d2e2c01251.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-698849")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("I don’t understand the point of MAISI and Gowers’ article. Extinction risk is just the red cloth to distract people from real societal risks like unemployment, people getting less intelligent, concentration of wealth, IP theft and so on.")

#text("Even regarding the extinction risk itself Gowers does not make very good points and oscillates between treating the AI as a sentient being and a machine. It is an algorithm seeded by a random number generator that also depends on ordering of floating point point operations, which introduce more “randomness”. You could run it fully deterministically by using the same random seed, same context and same GPU scheduling.")

#text("Don’t connect the thing to the Internet and don’t allow agents that execute hallucinated commands.")

#text("Again, the real issues are SEO slop, influencing, mass propaganda, AI psychosis, unemployment etc.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4598a8e58294cba73ada68cd944a4b8994cace313ae395c55ffeb60027d6ef15-7748f91a730ed0e5e805e917ae6aeb91f2410b8b079b9fec86f50dae0a2d7df7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-698860")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("The AI companies and the people in them have talked and cared about extinction risk for over 10 years, long before any current developments were foreseeable. It clearly isnt just a red cloth, but something that the AI companies (and many people in the field, like Hinton) earnestly believe. I think they are wrong about that, but that mean that they are dishonest in their concerns. It also doesn’t mean that you can not care about other issues. In fact, I suspect that caring about one will bolster the effort in caring about others.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-698888")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("The obsession of silicon valley with singularity may be a cultural artifact (")#link("https://youtu.be/fgsmq8f3sWQ?is=u6O7_1fq2SJdWsmn")[#text("https://youtu.be/fgsmq8f3sWQ?is=u6O7_1fq2SJdWsmn")]#text("). Just because people are earnest in their befielfs does not mean that others should care (otherwise all of use would have the same religious faiths). What is lacking here is a scientific and verifiable discourse. The openness mentioned in Ben Recht’s post would help.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b2471604c8902ec9746d53afa441873dadc9012b5022d6ff0bc83852a9993e-b8d80f565218ccfbd08a65971f9e4d3de692f80225ef4b30178db5d2e2c01251.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-698926")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2026")])]

#text("There were people like the “Effective Altruists”, who have talked about the risk for a long time. One “Effective Altruist”, Sam Bankman Fried, defrauded the customers of his Bitcoin exchange and also invested in Anthropic!")

#text("Sam Altman stated tn 2023 the “AI will kill us all” but proceeded to push it forward and make money.")

#text("Amodei has proudly stated multiple times that AI will replace most while collar jobs, so he does not care in the least about unemployment and other issues. But was concerned about bioweapons, because those could affect himself, unlike unemployed people sleeping under a bridge.")

#text("Hinton was concerned after he got his Nobel Prize and the industry was “inevitable”.")

#text("I think many readers here are far too idealistic and mistakenly assume that Silicon Valley shares their values. The most cynical interpretation of Silicon Valley is usually the correct one, and the comedy series “Silicon Valley” is largely a documentary.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-698861")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Yes, I am wondering the same thing. Why have people become so fantastical. AI is after all an algorithm being run. Why are we handing it any kind of responsibility? Has everyone stopped analyzing things from first principles way in the age of hype and mindless data grabbing.")

#link("https://thebulletin.org/2026/09/rogue-ai-didnt-breach-hugging-face-human-decisions-did/")[#text("https://thebulletin.org/2026/09/rogue-ai-didnt-breach-hugging-face-human-decisions-did/")]#text(" ")#linebreak()#link("https://aiguide.substack.com/p/misleading-metaphors-and-real-risks")[#text("https://aiguide.substack.com/p/misleading-metaphors-and-real-risks")]#linebreak()#link("https://faculty.washington.edu/ebender/papers/Bender-AI-2026.pdf")[#text("https://faculty.washington.edu/ebender/papers/Bender-AI-2026.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-698886")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Don’t connect the thing to the Internet and don’t allow agents that execute hallucinated commands.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-698887")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Don’t connect the thing to the Internet and don’t allow agents that execute hallucinated commands.")
]

#text("I think this is completely unrealistic. Even if a large proportion of people end up following this advice (which I don’t even think is necessarily likely), there will still be a non-trivial enough proportion of people who feel the risk is acceptable because of the large upsides for the individual. My understanding is that this is already happening a lot, for example software engineers using cursor or other AI IDEs can get stuff done more quickly and easily by allowing the agents unconditional access to internet and command execution. I guess the downside is that occasionally the agent messes something up somewhat severely, but this is quite rare and it seems like most people are willing to take this risk given that coding ends up easier (or at least ends up feeling easier) when you are willing to accept these risks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e75c93c3d8c1ab12fefec30523788c6ce708722b1c40434134fb9c8668f628eb-b56f3a2b9d0079b38434d00161c96b15dc6e54671b3ca9cdf0e4a77131f69754.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.S.")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-698907")[#strong[#text("J.S.")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("The idea that AI-risk is a conspiracy cooked up by the AI companies to hype their product or distract from other AI-issues is such a baffling position I have trouble understanding how anyone can take it seriously.")

#text("It is like suggesting that someone claiming to be a serial killer is only doing so to distract from their previous bank robbery! The only answer to such a claim is to reply that, if this is true, they are the stupidest bank robber who ever lived.")

#text("Surely arguing that AI poses an existential risk will attract far more, not less, scrutiny to all AI-related problems?")

#text("In addition, concerns about existential risk from AI have existed long before modern AI. Alan Turing famously discussed the issue, writing “It seems probable that once the machine thinking method had started, it would not take long to outstrip our feeble powers. They would be able to converse with each other to sharpen their wits. At some stage therefore, we should have to expect the machines to take control.” To believe AI risk is some sort of “red cloth” invented by the AI companies for personal gain is completely ahistorical.")

#text("I think the real issue here is that those who dismiss AI risk either believe in souls, or else explicitly or implicitly believe some other theory of mind that rejects computationalism (the view that the brain is an information processing system and cognition and consciousness are forms of computation). They believe that human intelligence cannot, even in principle, be replicated in inorganic matter and think anyone who believes otherwise is gullible, mad, or stupid. Very well – if you can defend such a view – but you should at least be able to understand why people who are not so confident about the falsehood of computationalism are worried.")

#text("Personally, as a biologist, the current debate around whether AI is capable of “real thinking” reminds me worryingly of the slow retreat of vitalism in the face of powerful scientific evidence to the contrary. In that case too, there was a powerful instinctive intuition that living matter must differ from non-living matter in some fundamental, irreplicable way. Unfortunately, the vitalists were deeply mistaken. I sincerely hope that those who reject the idea of computational intelligence are not similarly mistaken.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-698908")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("It’s both. Some people in the AI companies are seriously concerned about existential risk. But there’s also a huge dose of protectionism motivating them. Amodei outright called for cartel status for OpenAI and Anthropic in his recent essay. Why do you need cartel status to prevent you from destroying humanity, Dario?")

#text("Check our the SNL skit on that. Sums it up perfectly.")

#text("These people are all “effective altruists”: the same philosophy that Bankman-Fried used to justify appropriating FTX customers’ funds for his personal trading. It’s a utilitarian philosophy, which means they believe that committing a truly heinous act is justified if it increases the welfare of enough people, no matter how marginally.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-698850")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Ben Recht:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Knowledge workers drive themselves insane in a flow state with their stochastic productivity software")
]

#text("Perhaps I am the exception, but I have the opposite problem. AI is so much fun I end up crowding out the rest of my life to spend time playing with it.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("If you haven’t found a way to run an open model in an open harness and see that it’s probably good enough for 99% of your work, you are very much missing out!")
]

#text("Really, it’s more like 10%, so not worth my time to try and figure out which 10% of my work it’s good for. Maxed-out frontier models are ")#strong[#text("so")]#text(" much better than anything else.")

#text("I do agree with the sentiment of trying to train a truly frontier-level open model. Problem is that it’s prohibitively expensive for the foreseeable future. I miss the days when you could do cutting-edge machine learning research at home.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28c875330269d0908899b83e1be49ecb669cdd528c5c712543d9902ada4983e4-30b8719cf7594ee7d23d2f911ee30d93cd416a24f8e148b3fcb22f68140a4a3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aksenchuk Aleksandr")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-698854")[#strong[#text("Aksenchuk Aleksandr")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Thank you for saying this. I am a math student, and I have such a huge anxiety about my future. I have always dreamed of being a math researcher, but now I don’t think that is feasible as the field became even more unstable, and I am neither particularly bright nor have many academic opportunities. I have hard time using social media because people everywhere on the Internet say that my degree will be useless in a few years. I can’t focus on doing math problems because I often think that my efforts is a complete waste of time; AI supposedly does everything better than me anyway. I honestly think switching to education to teach in high school, but what breaks my heart is that I will never be able to interact with high-level mathematics anymore. (besides, many AI bros already argue that public education is unnecessary).")

#text("I know that I am not the only one who feels the same. And instead of addressing the real worries of people who live in the age of AI, Gowers, MAISI, and tech bros write weak, pointless philosophical articles. They say that they care about people, and that is why they are doing what they are doing. But what about me, and many other people who go through this crisis? Why are they not doing anything to protect math students? At least, offer some words of encouragement or career guidance. Instead, they are already live in the astral space, compute P(doom) and think how they will fight against robot invasion. And we trust these people with AI safety. I am honestly so scared for the future.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Young postdoc")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-698884")[#strong[#text("Young postdoc")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("The P(doom) discussions of these “experts”, as well as Tskmerman’s pretentious to save humanity, will quickly become a worldwide joke.")

#text("Here is my advice: as long as you like mathematics, keep doing what you are doing as long as the world lets you do it. It is not like there is a safer alternative out there.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c978ae119cf264abfb14b750b424b42f3028b81c566ed2cfe784a4fb152dbcbb-93dc944583e279071c5ba85e6b16807d05f350aa9dca7f9189939d7f121289c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-698922")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2026")])]

#text("This is genuinely bad advice and can easily lead you to a life of poverty and misery. It is frequently the case that the world permits one to do something for quite a long time even though it is ultimately a career dead end.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-698891")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("It boggles my mind how your post could have gotten any down votes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b74a29775f9c4a913bf3feb37bfdee4540f4c5a9abeae5bf277744e882dd9416-4df5dec513a750ee773dec3b4c577d53479894846f6b7613bcae9d3b30963126.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Gannon")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-698906")[#strong[#text("Tom Gannon")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("I’d like to submit the very thought provoking essay “")#link("https://sites.google.com/ucr.edu/opwaite/personal-essays/on-the-present-state-of-mathematics?authuser=0&pli=1")[#text("On the Present State of Mathematics")]#text("” by Oliver P. Waite, a graduate student at UC Riverside, in case there are further “blog post and article” posts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01f9a0a7f697a942adbfaf1c5b60fdb12385302e1122a85b4c1e5891710a61bc-97ce473f22588a0b96025eb186c7f56479d8631f7649bf05f0e79a045114c03c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mraginsky")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-698934")[#strong[#text("mraginsky")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2026")])]

#text("I wrote this essay in December of 2025, but I think its key points still hold up: ")#link("https://realizable.substack.com/p/games-without-frontiers")[#text("https://realizable.substack.com/p/games-without-frontiers")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d62fb603f6cc2d205ca3294d2a5307d786b92ca5619e3d56bb153ce585528d2f-4a8a74ac9b16ec3a2a3bd14d99d2deabe51395ea98621a7db6ec64132e879e58.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Amir")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/#comment-699174")[#strong[#text("Amir")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("As I prepare for a talk on Understanding Understanding Mathematics in the Age of AI, I came across a 1998 interview with Yuri Manin, which I first read many years ago as a student.")

#text("Strangely, it feels more at home now than it did then. Even more strangely, it may be the most relevant thing I have read about the AI-ification of mathematics, although, of course, it says nothing directly about AI!")

#text("Manin questions the heroic culture of mathematics, the obsession with lists of problems to be solved, and the idea of mathematical progress as conquering one problem after another. His conception of a good proof is captured in the very title of the interview, Good Proofs are Proofs that Make us Wiser, and perhaps even more beautifully in his observation: “Wisdom lives in connections.”")

#text("He insists that proof cannot die without mathematics dying with it, but warns that mathematics itself might disappear as an accepted part of human culture. A deeply sad possibility.")

#text("Yet he is remarkably relaxed about computers. He imagines Euler spending much of his time writing software and Gauss sitting in front of a computer screen. And perhaps most strikingly, his remarks suggest to me that computers could open mathematics to people whose ways of thinking might not have found a natural home in its traditional culture. Could AI now extend that possibility even further?")

#text("Reading all this in 2026, I found his vision astonishingly refreshing.")

#text("If there are just two pieces I would encourage anyone concerned with the AI-ification of mathematics to read, they are:")

#text("William Thurston, On Proof and Progress in Mathematics (1994):")#link("https://arxiv.org/abs/math/9404236")[#text("https://arxiv.org/abs/math/9404236")]

#text("Yuri Manin, Good Proofs are Proofs that Make us Wiser (1998):")#link("https://mathshistory.st-andrews.ac.uk/Diagrams/Manin_interview.pdf")[#text("https://mathshistory.st-andrews.ac.uk/Diagrams/Manin_interview.pdf")]
]
