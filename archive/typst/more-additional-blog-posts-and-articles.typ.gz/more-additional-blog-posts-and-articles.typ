// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/
// Converted to Typst by tao2typ: "2026-10-31T12:52:17.390115+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "More additional blog posts and articles", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("More additional blog posts and articles")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/")[#text("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-31 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#list(
[#text("Pavel Etingof, Slava Gerovitch, “")#link("https://math.mit.edu/~etingof/futuremath.pdf")[#text("Mathematics of the Future")]#text("“")],
[#text("Timothy Gowers, “")#link("https://gowers.wordpress.com/2026/10/16/how-worried-should-we-be-about-extinction-risk-from-ai/")[#text("How worried should we be about extinction risk from AI?")]#text("“")],
[#text("Elchanan Mossel, “")#link("https://arxiv.org/abs/2601.02380")[#text("LLMs, Reasoning and Plagiarism")]#text("“. (See also ")#link("https://math.mit.edu/~elmos/petition.html")[#text("this related petition")]#text(".)")],
[#text("nihilunbounded, “")#link("https://nihilunbounded.substack.com/p/who-watches-the-watchmen")[#text("Who Watches the Watchmen")]#text("“")],
[#text("Sung-Jin Oh, “")#link("https://math.berkeley.edu/~sjoh/index.html#essay")[#text("What does it mean for a mathematician to understand? A case study in the age of AI")]#text("“")],
[#text("Ben Recht, “")#link("https://www.argmin.net/p/the-world-is-something-we-make")[#text("The World Is Something We Make")]#text("“")],
[#text("Manuel Luis Rivera, “")#link("https://vislumbres.github.io/#/post/raw-mathematics")[#text("Raw Mathematics")]#text("“")],
[#text("Grant Sanderson, “")#link("https://www.youtube.com/watch?v=LKrwhjOI8Nc")[#text("There’s never been a better time to go into math")]#text("“")]
)

#text("As before, readers are invited to contribute links to additional posts not already covered here (or at Proofs and Prompts) in the comments.")

#heading(level: 1)[#text("Comments (22)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81d3b09e12c1ffa40e14f72149df371575d986372b44584c682fdce06dd04724-e20bb59052a5b25f43f87bdf7347409769fe867005e0b68a7edf967b9b3673af.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Ryskamp")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698837")[#strong[#text("John Ryskamp")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Make sure you read Alejandro Garciadiego’s book, Bertrand Russell and the Origins of the Set-theoretic ‘Paradoxes.’ It began the process of what we call mathematics and logic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b52796f5953bd198c7a8f665c49d979b54adbb7be9b9502491f6ae6a1e29267-b798674221bbe8c8b7d6e6e7fbd9dfb3eaa8304bd696584e006950d38098d2e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698838")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Maybe it’s worth mentioning that Etingof consults for Anthropic")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9dbe4fe719bacb5077afdfe0dc0b12e61e51ed2f290dd6cd05c0eaf471694bd7-362bd281955d8e9bed1e39bb8725dee2db027049f2da95bcace54b5fe93ea817.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Florian Breuer")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698840")[#strong[#text("Florian Breuer")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("I’ve now seen many articles which look at what AI is capable of now and discusses how we can harness this ability, e.g. to build new theories while AI proves theorems for us. But what if AI keeps getting better at the same rate as the last two years?")

#text("I wrote my own take here: ")#link("https://florianbreuer.github.io/florianbreuer/FutureVision.html")[#text("https://florianbreuer.github.io/florianbreuer/FutureVision.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698848")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Elchanan Mossel’s “paper”, what a bunch garbage. A paper that starts with a premise, that it is then the conclusion. Really, some mathematicians are really embarrassing, in their reactions to the LLM phenomenon. “two incompatible narratives”, why? the paper postulates that, but the distinction between original research and imitation has a blurry boundary that is is anything but “incompatible”.")

#text("And Andrew Critch is part of MAISI? I have a lot less reassurance, that that institution will contribute to save us.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of R")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698857")[#strong[#text("R")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("The big boss of MAISI has no expertise in AI safety (writing an awkward scifi paper does not make one an expert), fundraised private money and use it unregulated, and saved himself basically all recruit process authority. What could you expect from this institute from the first place.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698871")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Tsimerman is a genuine brilliant problem solver, and mathematician. His talk at MSRI was, together with Gill Kallai’s and Tim Gowers’ first one, the only two that Tao has posted that I didn’t have a bone to pick.")

#text("Very far from the many others that the deeper they got was to say “but human understanding”, or the embarrasing Ludites at AHM.")

#text("On the other hand, Andrew Critch is not a good mathematician. He is on the charlatan spectrum. His version of problem solving is to muddle the problem enough that his explanation seems to fit his answer even though the answer is the opposite.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698849")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("I don’t understand the point of MAISI and Gowers’ article. Extinction risk is just the red cloth to distract people from real societal risks like unemployment, people getting less intelligent, concentration of wealth, IP theft and so on.")

#text("Even regarding the extinction risk itself Gowers does not make very good points and oscillates between treating the AI as a sentient being and a machine. It is an algorithm seeded by a random number generator that also depends on ordering of floating point point operations, which introduce more “randomness”. You could run it fully deterministically by using the same random seed, same context and same GPU scheduling.")

#text("Don’t connect the thing to the Internet and don’t allow agents that execute hallucinated commands.")

#text("Again, the real issues are SEO slop, influencing, mass propaganda, AI psychosis, unemployment etc.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6dd12d83808476959cf0f28e8cf5c1101ad2169efad7a66e1f911af8e8819014-7b9961f61d21cb1f240f40a6ff876022502c8f82ee04c4a04d235e567376d2bb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698860")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("The AI companies and the people in them have talked and cared about extinction risk for over 10 years, long before any current developments were foreseeable. It clearly isnt just a red cloth, but something that the AI companies (and many people in the field, like Hinton) earnestly believe. I think they are wrong about that, but that mean that they are dishonest in their concerns. It also doesn’t mean that you can not care about other issues. In fact, I suspect that caring about one will bolster the effort in caring about others.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698888")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("The obsession of silicon valley with singularity may be a cultural artifact (")#link("https://youtu.be/fgsmq8f3sWQ?is=u6O7_1fq2SJdWsmn")[#text("https://youtu.be/fgsmq8f3sWQ?is=u6O7_1fq2SJdWsmn")]#text("). Just because people are earnest in their befielfs does not mean that others should care (otherwise all of use would have the same religious faiths). What is lacking here is a scientific and verifiable discourse. The openness mentioned in Ben Recht’s post would help.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698926")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2026")])]

#text("There were people like the “Effective Altruists”, who have talked about the risk for a long time. One “Effective Altruist”, Sam Bankman Fried, defrauded the customers of his Bitcoin exchange and also invested in Anthropic!")

#text("Sam Altman stated tn 2023 the “AI will kill us all” but proceeded to push it forward and make money.")

#text("Amodei has proudly stated multiple times that AI will replace most while collar jobs, so he does not care in the least about unemployment and other issues. But was concerned about bioweapons, because those could affect himself, unlike unemployed people sleeping under a bridge.")

#text("Hinton was concerned after he got his Nobel Prize and the industry was “inevitable”.")

#text("I think many readers here are far too idealistic and mistakenly assume that Silicon Valley shares their values. The most cynical interpretation of Silicon Valley is usually the correct one, and the comedy series “Silicon Valley” is largely a documentary.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698861")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Yes, I am wondering the same thing. Why have people become so fantastical. AI is after all an algorithm being run. Why are we handing it any kind of responsibility? Has everyone stopped analyzing things from first principles way in the age of hype and mindless data grabbing.")

#link("https://thebulletin.org/2026/09/rogue-ai-didnt-breach-hugging-face-human-decisions-did/")[#text("https://thebulletin.org/2026/09/rogue-ai-didnt-breach-hugging-face-human-decisions-did/")]#text(" ")#linebreak()#link("https://aiguide.substack.com/p/misleading-metaphors-and-real-risks")[#text("https://aiguide.substack.com/p/misleading-metaphors-and-real-risks")]#linebreak()#link("https://faculty.washington.edu/ebender/papers/Bender-AI-2026.pdf")[#text("https://faculty.washington.edu/ebender/papers/Bender-AI-2026.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698886")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Don’t connect the thing to the Internet and don’t allow agents that execute hallucinated commands.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698887")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Don’t connect the thing to the Internet and don’t allow agents that execute hallucinated commands.")
]

#text("I think this is completely unrealistic. Even if a large proportion of people end up following this advice (which I don’t even think is necessarily likely), there will still be a non-trivial enough proportion of people who feel the risk is acceptable because of the large upsides for the individual. My understanding is that this is already happening a lot, for example software engineers using cursor or other AI IDEs can get stuff done more quickly and easily by allowing the agents unconditional access to internet and command execution. I guess the downside is that occasionally the agent messes something up somewhat severely, but this is quite rare and it seems like most people are willing to take this risk given that coding ends up easier (or at least ends up feeling easier) when you are willing to accept these risks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64b3aadae85ca35abb01c4ad399b4dd8260b793cc5c48531ee2f48f3c302b255-835a3d3f2bbcc99b52944da15801cebfb34e8249102ac67373d98424c1626044.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.S.")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698907")[#strong[#text("J.S.")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("The idea that AI-risk is a conspiracy cooked up by the AI companies to hype their product or distract from other AI-issues is such a baffling position I have trouble understanding how anyone can take it seriously.")

#text("It is like suggesting that someone claiming to be a serial killer is only doing so to distract from their previous bank robbery! The only answer to such a claim is to reply that, if this is true, they are the stupidest bank robber who ever lived.")

#text("Surely arguing that AI poses an existential risk will attract far more, not less, scrutiny to all AI-related problems?")

#text("In addition, concerns about existential risk from AI have existed long before modern AI. Alan Turing famously discussed the issue, writing “It seems probable that once the machine thinking method had started, it would not take long to outstrip our feeble powers. They would be able to converse with each other to sharpen their wits. At some stage therefore, we should have to expect the machines to take control.” To believe AI risk is some sort of “red cloth” invented by the AI companies for personal gain is completely ahistorical.")

#text("I think the real issue here is that those who dismiss AI risk either believe in souls, or else explicitly or implicitly believe some other theory of mind that rejects computationalism (the view that the brain is an information processing system and cognition and consciousness are forms of computation). They believe that human intelligence cannot, even in principle, be replicated in inorganic matter and think anyone who believes otherwise is gullible, mad, or stupid. Very well – if you can defend such a view – but you should at least be able to understand why people who are not so confident about the falsehood of computationalism are worried.")

#text("Personally, as a biologist, the current debate around whether AI is capable of “real thinking” reminds me worryingly of the slow retreat of vitalism in the face of powerful scientific evidence to the contrary. In that case too, there was a powerful instinctive intuition that living matter must differ from non-living matter in some fundamental, irreplicable way. Unfortunately, the vitalists were deeply mistaken. I sincerely hope that those who reject the idea of computational intelligence are not similarly mistaken.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698908")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("It’s both. Some people in the AI companies are seriously concerned about existential risk. But there’s also a huge dose of protectionism motivating them. Amodei outright called for cartel status for OpenAI and Anthropic in his recent essay. Why do you need cartel status to prevent you from destroying humanity, Dario?")

#text("Check our the SNL skit on that. Sums it up perfectly.")

#text("These people are all “effective altruists”: the same philosophy that Bankman-Fried used to justify appropriating FTX customers’ funds for his personal trading. It’s a utilitarian philosophy, which means they believe that committing a truly heinous act is justified if it increases the welfare of enough people, no matter how marginally.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698850")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Ben Recht:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Knowledge workers drive themselves insane in a flow state with their stochastic productivity software")
]

#text("Perhaps I am the exception, but I have the opposite problem. AI is so much fun I end up crowding out the rest of my life to spend time playing with it.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("If you haven’t found a way to run an open model in an open harness and see that it’s probably good enough for 99% of your work, you are very much missing out!")
]

#text("Really, it’s more like 10%, so not worth my time to try and figure out which 10% of my work it’s good for. Maxed-out frontier models are ")#strong[#text("so")]#text(" much better than anything else.")

#text("I do agree with the sentiment of trying to train a truly frontier-level open model. Problem is that it’s prohibitively expensive for the foreseeable future. I miss the days when you could do cutting-edge machine learning research at home.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e1b495630829824859f1c4ebbe6fbfb62d8d55a79046e735a30ef6fea04761a-db42d6d4b5cb007e950fc2fb2f86efb4e2621ae93f29570f780b99f22b55cb0e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aksenchuk Aleksandr")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698854")[#strong[#text("Aksenchuk Aleksandr")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Thank you for saying this. I am a math student, and I have such a huge anxiety about my future. I have always dreamed of being a math researcher, but now I don’t think that is feasible as the field became even more unstable, and I am neither particularly bright nor have many academic opportunities. I have hard time using social media because people everywhere on the Internet say that my degree will be useless in a few years. I can’t focus on doing math problems because I often think that my efforts is a complete waste of time; AI supposedly does everything better than me anyway. I honestly think switching to education to teach in high school, but what breaks my heart is that I will never be able to interact with high-level mathematics anymore. (besides, many AI bros already argue that public education is unnecessary).")

#text("I know that I am not the only one who feels the same. And instead of addressing the real worries of people who live in the age of AI, Gowers, MAISI, and tech bros write weak, pointless philosophical articles. They say that they care about people, and that is why they are doing what they are doing. But what about me, and many other people who go through this crisis? Why are they not doing anything to protect math students? At least, offer some words of encouragement or career guidance. Instead, they are already live in the astral space, compute P(doom) and think how they will fight against robot invasion. And we trust these people with AI safety. I am honestly so scared for the future.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Young postdoc")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698884")[#strong[#text("Young postdoc")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("The P(doom) discussions of these “experts”, as well as Tskmerman’s pretentious to save humanity, will quickly become a worldwide joke.")

#text("Here is my advice: as long as you like mathematics, keep doing what you are doing as long as the world lets you do it. It is not like there is a safer alternative out there.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16d08f0dc374b9c4079602b1f11addec54c6f3fee5da200a75bb176d0ba057ef-99cac407f108652afbd4239ea5865d2da78613a51ed1922d83d05e0475a3f7d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698922")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2026")])]

#text("This is genuinely bad advice and can easily lead you to a life of poverty and misery. It is frequently the case that the world permits one to do something for quite a long time even though it is ultimately a career dead end.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698891")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("It boggles my mind how your post could have gotten any down votes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5ce6dcbb42013ddeb413a6b9751b63c5c70d137327d7a4fc1321763e354c33e9-371a0c9d806991b9ba203e8bfb5a41165e9d939abfb1d6e3d09511ab6b959f3e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Gannon")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698906")[#strong[#text("Tom Gannon")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("I’d like to submit the very thought provoking essay “")#link("https://sites.google.com/ucr.edu/opwaite/personal-essays/on-the-present-state-of-mathematics?authuser=0&pli=1")[#text("On the Present State of Mathematics")]#text("” by Oliver P. Waite, a graduate student at UC Riverside, in case there are further “blog post and article” posts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3aefdd7ab7bc3b72df6da2c9865d8535ccf3153501803b275b9ab9c6bd2cefb8-eadd5c2589f198b1db5b991caf57ece9d9f4c9aee170bec7e793fd0574a6f934.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mraginsky")]], [#link("https://terrytao.wordpress.com/2026/10/26/more-additional-blog-posts-and-articles/comment-page-1/#comment-698934")[#strong[#text("mraginsky")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2026")])]

#text("I wrote this essay in December of 2025, but I think its key points still hold up: ")#link("https://realizable.substack.com/p/games-without-frontiers")[#text("https://realizable.substack.com/p/games-without-frontiers")]
]
