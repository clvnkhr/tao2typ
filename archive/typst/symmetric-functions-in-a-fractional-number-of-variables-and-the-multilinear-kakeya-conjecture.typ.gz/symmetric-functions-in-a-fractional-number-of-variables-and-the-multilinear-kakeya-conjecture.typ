// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T10:52:29.486902+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Symmetric functions in a fractional number of variables, and the multilinear Kakeya conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Symmetric functions in a fractional number of variables, and the multilinear Kakeya conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 June 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/")[#text("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{\\Omega}")#text(" be some domain (such as the real numbers). For any natural number ")#mi("{p}")#text(", let ")#mi("{L(\\Omega^p)_{sym}}")#text(" denote the space of symmetric real-valued functions ")#mi("{F^{(p)}: \\Omega^p \\rightarrow {\\bf R}}")#text(" on ")#mi("{p}")#text(" variables ")#mi("{x_1,\\dots,x_p \\in \\Omega}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("F^{(p)}(x_{\\sigma(1)},\\dots,x_{\\sigma(p)}) = F^{(p)}(x_1,\\dots,x_p)")]]

#text("for any permutation ")#mi("{\\sigma: \\{1,\\dots,p\\} \\rightarrow \\{1,\\dots,p\\}}")#text(". For instance, for any natural numbers ")#mi("{k,p}")#text(", the ")#link("https://en.wikipedia.org/wiki/Elementary_symmetric_polynomial")[#text("elementary symmetric polynomials")]

#align(center)[#tao-fit-display[#mitex("e_k^{(p)}(x_1,\\dots,x_p) = \\sum_{1 \\leq i_1 < i_2 < \\dots < i_k \\leq p} x_{i_1} \\dots x_{i_k}")]]

#text("will be an element of ")#mi("{L({\\bf R}^p)_{sym}}")#text(". With the pointwise product operation, ")#mi("{L(\\Omega^p)_{sym}}")#text(" becomes a commutative real algebra. We include the case ")#mi("{p=0}")#text(", in which case ")#mi("{L(\\Omega^0)_{sym}}")#text(" consists solely of the real constants.")

#text("Given two natural numbers ")#mi("{k,p}")#text(", one can “lift” a symmetric function ")#mi("{F^{(k)} \\in L(\\Omega^k)_{sym}}")#text(" of ")#mi("{k}")#text(" variables to a symmetric function ")#mi("{[F^{(k)}]_{k \\rightarrow p} \\in L(\\Omega^p)_{sym}}")#text(" of ")#mi("{p}")#text(" variables by the formula")

#tao-aligned(keep: true)[


#tao-math("[F^{(k)}]_{k \\rightarrow p}(x_1,\\dots,x_p)  & = \\sum_{1 \\leq i_1 < i_2 < \\dots < i_k \\leq p} F^{(k)}(x_{i_1}, \\dots, x_{i_k})", block: true)



#tao-math(" & = \\frac{1}{k!} \\sum_\\pi F^{(k)}( x_{\\pi(1)}, \\dots, x_{\\pi(k)} )", block: true)
]

#text("where ")#mi("{\\pi}")#text(" ranges over all injections from ")#mi("{\\{1,\\dots,k\\}}")#text(" to ")#mi("{\\{1,\\dots,p\\}}")#text(" (the latter formula making it clearer that ")#mi("{[F^{(k)}]_{k \\rightarrow p}}")#text(" is symmetric). Thus for instance")

#tao-aligned(keep: true)[


#tao-math("[F^{(1)}(x_1)]_{1 \\rightarrow p}  & = \\sum_{i=1}^p F^{(1)}(x_i)", block: true)



#tao-math("[F^{(2)}(x_1,x_2)]_{2 \\rightarrow p}  & = \\sum_{1 \\leq i < j \\leq p} F^{(2)}(x_i,x_j)", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#mitex("e_k^{(p)}(x_1,\\dots,x_p) = [x_1 \\dots x_k]_{k \\rightarrow p}.")]]

#text("Also we have")

#align(center)[#tao-fit-display[#mitex("[1]_{k \\rightarrow p} = \\binom{p}{k} = \\frac{p(p-1)\\dots(p-k+1)}{k!}.")]]

#text("With these conventions, we see that ")#mi("{[F^{(k)}]_{k \\rightarrow p}}")#text(" vanishes for ")#mi("{p=0,\\dots,k-1}")#text(", and is equal to ")#mi("{F}")#text(" if ")#mi("{k=p}")#text(". We also have the transitivity")

#align(center)[#tao-fit-display[#mitex("[F^{(k)}]_{k \\rightarrow p} = \\frac{1}{\\binom{p-k}{p-l}} [[F^{(k)}]_{k \\rightarrow l}]_{l \\rightarrow p}")]]

#text("if ")#mi("{k \\leq l \\leq p}")#text(".")

#text("The lifting map ")#mi("{[]_{k \\rightarrow p}}")#text(" is a linear map from ")#mi("{L(\\Omega^k)_{sym}}")#text(" to ")#mi("{L(\\Omega^p)_{sym}}")#text(", but it is not a ring homomorphism. For instance, when ")#mi("{\\Omega={\\bf R}}")#text(", one has ")#metadata(none) <tao-ce71df4dc560de1e3e3d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("[x_1]_{1 \\rightarrow p} [x_1]_{1 \\rightarrow p} = (\\sum_{i=1}^p x_i)^2")]]





#tao-aligned(keep: true)[


#tao-math(" & = \\sum_{i=1}^p x_i^2 + 2 \\sum_{1 \\leq i < j \\leq p} x_i x_j", block: true)



#tao-math(" & = [x_1^2]_{1 \\rightarrow p} + 2 [x_1 x_2]_{1 \\rightarrow p}", block: true)



#tao-math(" & \\neq [x_1^2]_{1 \\rightarrow p}.", block: true)
]

#text("In general, one has the identity ")#metadata(none) <tao-ad954419e17a945c068b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("[F^{(k)}(x_1,\\dots,x_k)]_{k \\rightarrow p} [G^{(l)}(x_1,\\dots,x_l)]_{l \\rightarrow p} = \\sum_{k,l \\leq m \\leq k+l} \\frac{1}{k! l!}")]]





#align(center)[#tao-fit-display[#mitex("[\\sum_{\\pi, \\rho} F^{(k)}(x_{\\pi(1)},\\dots,x_{\\pi(k)}) G^{(l)}(x_{\\rho(1)},\\dots,x_{\\rho(l)})]_{m \\rightarrow p}")]]

#text("for all natural numbers ")#mi("{k,l,p}")#text(" and ")#mi("{F^{(k)} \\in L(\\Omega^k)_{sym}}")#text(", ")#mi("{G^{(l)} \\in L(\\Omega^l)_{sym}}")#text(", where ")#mi("{\\pi, \\rho}")#text(" range over all injections ")#mi("{\\pi: \\{1,\\dots,k\\} \\rightarrow \\{1,\\dots,m\\}}")#text(", ")#mi("{\\rho: \\{1,\\dots,l\\} \\rightarrow \\{1,\\dots,m\\}}")#text(" with ")#mi("{\\pi(\\{1,\\dots,k\\}) \\cup \\rho(\\{1,\\dots,l\\}) = \\{1,\\dots,m\\}}")#text(". Combinatorially, the identity ")#link(<tao-ad954419e17a945c068b>)[#text("(2)")]#text(" follows from the fact that given any injections ")#mi("{\\tilde \\pi: \\{1,\\dots,k\\} \\rightarrow \\{1,\\dots,p\\}}")#text(" and ")#mi("{\\tilde \\rho: \\{1,\\dots,l\\} \\rightarrow \\{1,\\dots,p\\}}")#text(" with total image ")#mi("{\\tilde \\pi(\\{1,\\dots,k\\}) \\cup \\tilde \\rho(\\{1,\\dots,l\\})}")#text(" of cardinality ")#mi("{m}")#text(", one has ")#mi("{k,l \\leq m \\leq k+l}")#text(", and furthermore there exist precisely ")#mi("{m!}")#text(" triples ")#mi("{(\\pi, \\rho, \\sigma)}")#text(" of injections ")#mi("{\\pi: \\{1,\\dots,k\\} \\rightarrow \\{1,\\dots,m\\}}")#text(", ")#mi("{\\rho: \\{1,\\dots,l\\} \\rightarrow \\{1,\\dots,m\\}}")#text(", ")#mi("{\\sigma: \\{1,\\dots,m\\} \\rightarrow \\{1,\\dots,p\\}}")#text(" such that ")#mi("{\\tilde \\pi = \\sigma \\circ \\pi}")#text(" and ")#mi("{\\tilde \\rho = \\sigma \\circ \\rho}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" When ")#mi("{\\Omega = {\\bf R}}")#text(", one has")

#tao-aligned(keep: true)[


#tao-math("[x_1 x_2]_{2 \\rightarrow p} [x_1]_{1 \\rightarrow p}  & = [\\frac{1}{2! 1!}( 2 x_1^2 x_2 + 2 x_1 x_2^2 )]_{2 \\rightarrow p} + [\\frac{1}{2! 1!} 6 x_1 x_2 x_3]_{3 \\rightarrow p}", block: true)



#tao-math(" & = [x_1^2 x_2 + x_1 x_2^2]_{2 \\rightarrow p} + [3x_1 x_2 x_3]_{3 \\rightarrow p}", block: true)
]

#text("which is just a restatement of the identity")

#align(center)[#tao-fit-display[#mitex("(\\sum_{i < j} x_i x_j) (\\sum_k x_k) = \\sum_{i<j} x_i^2 x_j + x_i x_j^2 + \\sum_{i < j < k} 3 x_i x_j x_k.")]]
]

#text("Note that the coefficients appearing in ")#link(<tao-ad954419e17a945c068b>)[#text("(2)")]#text(" do not depend on the final number of variables ")#mi("{p}")#text(". We may therefore abstract the role of ")#mi("{p}")#text(" from the law ")#link(<tao-ad954419e17a945c068b>)[#text("(2)")]#text(" by introducing the real algebra ")#mi("{L(\\Omega^*)_{sym}}")#text(" of formal sums")

#align(center)[#tao-fit-display[#mitex("F^{(*)} = \\sum_{k=0}^\\infty [F^{(k)}]_{k \\rightarrow *}")]]

#text("where for each ")#mi("{k}")#text(", ")#mi("{F^{(k)}}")#text(" is an element of ")#mi("{L(\\Omega^k)_{sym}}")#text(" (with only finitely many of the ")#mi("{F^{(k)}}")#text(" being non-zero), and with the formal symbol ")#mi("{[]_{k \\rightarrow *}}")#text(" being formally linear, thus")

#align(center)[#tao-fit-display[#mitex("[F^{(k)}]_{k \\rightarrow *} + [G^{(k)}]_{k \\rightarrow *} := [F^{(k)} + G^{(k)}]_{k \\rightarrow *}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("c [F^{(k)}]_{k \\rightarrow *} := [cF^{(k)}]_{k \\rightarrow *}")]]

#text("for ")#mi("{F^{(k)}, G^{(k)} \\in L(\\Omega^k)_{sym}}")#text(" and scalars ")#mi("{c \\in {\\bf R}}")#text(", and with multiplication given by the analogue ")#metadata(none) <tao-b6dfa7c04ce31df432db>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("[F^{(k)}(x_1,\\dots,x_k)]_{k \\rightarrow *} [G^{(l)}(x_1,\\dots,x_l)]_{l \\rightarrow *} = \\sum_{k,l \\leq m \\leq k+l} \\frac{1}{k! l!}")]]





#align(center)[#tao-fit-display[#mitex("[\\sum_{\\pi, \\rho} F^{(k)}(x_{\\pi(1)},\\dots,x_{\\pi(k)}) G^{(l)}(x_{\\rho(1)},\\dots,x_{\\rho(l)})]_{m \\rightarrow *}")]]

#text("of ")#link(<tao-ad954419e17a945c068b>)[#text("(2)")]#text(". Thus for instance, in this algebra ")#mi("{L(\\Omega^*)_{sym}}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("[x_1]_{1 \\rightarrow *} [x_1]_{1 \\rightarrow *} = [x_1^2]_{1 \\rightarrow *} + 2 [x_1 x_2]_{2 \\rightarrow *}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("[x_1 x_2]_{2 \\rightarrow *} [x_1]_{1 \\rightarrow *} = [x_1^2 x_2 + x_1 x_2^2]_{2 \\rightarrow *} + [3 x_1 x_2 x_3]_{3 \\rightarrow *}.")]]

#text("Informally, ")#mi("{L(\\Omega^*)_{sym}}")#text(" is an abstraction (or “inverse limit”) of the concept of a symmetric function of an unspecified number of variables, which are formed by summing terms that each involve only a bounded number of these variables at a time. One can check (somewhat tediously) that ")#mi("{L(\\Omega^*)_{sym}}")#text(" is indeed a commutative real algebra, with a unit ")#mi("{[1]_{0 \\rightarrow *}}")#text(". (I do not know if this algebra has previously been studied in the literature; it is somewhat analogous to the abstract algebra of finite linear combinations of Schur polynomials, with multiplication given by a Littlewood-Richardson rule. )")

#text("For natural numbers ")#mi("{p}")#text(", there is an obvious specialisation map ")#mi("{[]_{* \\rightarrow p}}")#text(" from ")#mi("{L(\\Omega^*)_{sym}}")#text(" to ")#mi("{L(\\Omega^p)_{sym}}")#text(", defined by the formula")

#align(center)[#tao-fit-display[#mitex("[\\sum_{k=0}^\\infty [F^{(k)}]_{k \\rightarrow *}]_{* \\rightarrow p} := \\sum_{k=0}^\\infty [F^{(k)}]_{k \\rightarrow p}.")]]

#text("Thus, for instance, ")#mi("{[]_{* \\rightarrow p}}")#text(" maps ")#mi("{[x_1]_{1 \\rightarrow *}}")#text(" to ")#mi("{[x_1]_{1 \\rightarrow p}}")#text(" and ")#mi("{[x_1 x_2]_{2 \\rightarrow *}}")#text(" to ")#mi("{[x_1 x_2]_{2 \\rightarrow p}}")#text(". From ")#link(<tao-ad954419e17a945c068b>)[#text("(2)")]#text(" and ")#link(<tao-b6dfa7c04ce31df432db>)[#text("(3)")]#text(" we see that this map ")#mi("{[]_{* \\rightarrow p}: L(\\Omega^*)_{sym} \\rightarrow L(\\Omega^p)_{sym}}")#text(" is an algebra homomorphism, even though the maps ")#mi("{[]_{k \\rightarrow *}: L(\\Omega^k)_{sym} \\rightarrow L(\\Omega^*)_{sym}}")#text(" and ")#mi("{[]_{k \\rightarrow p}: L(\\Omega^k)_{sym} \\rightarrow L(\\Omega^p)_{sym}}")#text(" are not homomorphisms. By inspecting the ")#mi("{p^{th}}")#text(" component of ")#mi("{L(\\Omega^*)_{sym}}")#text(" we see that the homomorphism ")#mi("{[]_{* \\rightarrow p}}")#text(" is in fact surjective.")

#text("Now suppose that we have a measure ")#mi("{\\mu}")#text(" on the space ")#mi("{\\Omega}")#text(", which then induces a product measure ")#mi("{\\mu^p}")#text(" on every product space ")#mi("{\\Omega^p}")#text(". To avoid degeneracies we will assume that the integral ")#mi("{\\int_\\Omega \\mu}")#text(" is strictly positive. Assuming suitable measurability and integrability hypotheses, a function ")#mi("{F \\in L(\\Omega^p)_{sym}}")#text(" can then be integrated against this product measure to produce a number")

#align(center)[#tao-fit-display[#mitex("\\int_{\\Omega^p} F\\ d\\mu^p.")]]

#text("In the event that ")#mi("{F}")#text(" arises as a lift ")#mi("{[F^{(k)}]_{k \\rightarrow p}}")#text(" of another function ")#mi("{F^{(k)} \\in L(\\Omega^k)_{sym}}")#text(", then from Fubini’s theorem we obtain the formula")

#align(center)[#tao-fit-display[#mitex("\\int_{\\Omega^p} F\\ d\\mu^p = \\binom{p}{k} (\\int_{\\Omega^k} F^{(k)}\\ d\\mu^k) (\\int_\\Omega\\ d\\mu)^{p-k}.")]]

#text("Thus for instance, if ")#mi("{\\Omega={\\bf R}}")#text(", ")#metadata(none) <tao-f64551fcd6f07823cb87>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\int_{{\\bf R}^p} [x_1]_{1 \\rightarrow p}\\ d\\mu^p = p (\\int_{\\bf R} x\\ d\\mu(x)) (\\int_{\\bf R} \\mu)^{p-1}")]]



#text(" and ")#metadata(none) <tao-3946ca64ff78d93ca610>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\int_{{\\bf R}^p} [x_1 x_2]_{2 \\rightarrow p}\\ d\\mu^p = \\binom{p}{2} (\\int_{{\\bf R}^2} x_1 x_2\\ d\\mu(x_1) d\\mu(x_2)) (\\int_{\\bf R} \\mu)^{p-2}.")]]



#text(" On summing, we see that if")

#align(center)[#tao-fit-display[#mitex("F^{(*)} = \\sum_{k=0}^\\infty [F^{(k)}]_{k \\rightarrow *}")]]

#text("is an element of the formal algebra ")#mi("{L(\\Omega^*)_{sym}}")#text(", then ")#metadata(none) <tao-5b0435f03790e0fa682d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\int_{\\Omega^p} [F^{(*)}]_{* \\rightarrow p}\\ d\\mu^p = \\sum_{k=0}^\\infty \\binom{p}{k} (\\int_{\\Omega^k} F^{(k)}\\ d\\mu^k) (\\int_\\Omega\\ d\\mu)^{p-k}.")]]



#text(" Note that by hypothesis, only finitely many terms on the right-hand side are non-zero.")

#text("Now for a key observation: whereas the left-hand side of ")#link(<tao-5b0435f03790e0fa682d>)[#text("(6)")]#text(" only makes sense when ")#mi("{p}")#text(" is a natural number, the right-hand side is meaningful when ")#mi("{p}")#text(" takes a fractional value (or even when it takes negative or complex values!), interpreting the binomial coefficient ")#mi("{\\binom{p}{k}}")#text(" as a polynomial ")#mi("{\\frac{p(p-1) \\dots (p-k+1)}{k!}}")#text(" in ")#mi("{p}")#text(". As such, this suggests a way to introduce a “virtual” concept of a symmetric function on a fractional power space ")#mi("{\\Omega^p}")#text(" for such values of ")#mi("{p}")#text(", and even to integrate such functions against product measures ")#mi("{\\mu^p}")#text(", even if the fractional power ")#mi("{\\Omega^p}")#text(" does not exist in the usual set-theoretic sense (and ")#mi("{\\mu^p}")#text(" similarly does not exist in the usual measure-theoretic sense). More precisely, for arbitrary real or complex ")#mi("{p}")#text(", we now ")#emph[#text("define")]#text(" ")#mi("{L(\\Omega^p)_{sym}}")#text(" to be the space of abstract objects")

#align(center)[#tao-fit-display[#mitex("F^{(p)} = [F^{(*)}]_{* \\rightarrow p} = \\sum_{k=0}^\\infty [F^{(k)}]_{k \\rightarrow p}")]]

#text("with ")#mi("{F^{(*)} \\in L(\\Omega^*)_{sym}}")#text(" and ")#mi("{[]_{* \\rightarrow p}}")#text(" (and ")#mi("{[]_{k \\rightarrow p}}")#text(" now interpreted as formal symbols, with the structure of a commutative real algebra inherited from ")#mi("{L(\\Omega^*)_{sym}}")#text(", thus")

#tao-aligned(keep: true)[


#tao-math("[F^{(*)}]_{* \\rightarrow p} + [G^{(*)}]_{* \\rightarrow p}  & := [F^{(*)} + G^{(*)}]_{* \\rightarrow p}", block: true)



#tao-math("c [F^{(*)}]_{* \\rightarrow p}  & := [c F^{(*)}]_{* \\rightarrow p}", block: true)



#tao-math("[F^{(*)}]_{* \\rightarrow p} [G^{(*)}]_{* \\rightarrow p}  & := [F^{(*)} G^{(*)}]_{* \\rightarrow p}.", block: true)
]

#text("In particular, the multiplication law ")#link(<tao-ad954419e17a945c068b>)[#text("(2)")]#text(" continues to hold for such values of ")#mi("{p}")#text(", thanks to ")#link(<tao-b6dfa7c04ce31df432db>)[#text("(3)")]#text(". Given any measure ")#mi("{\\mu}")#text(" on ")#mi("{\\Omega}")#text(", we formally define a measure ")#mi("{\\mu^p}")#text(" on ")#mi("{\\Omega^p}")#text(" with regards to which we can integrate elements ")#mi("{F^{(p)}}")#text(" of ")#mi("{L(\\Omega^p)_{sym}}")#text(" by the formula ")#link(<tao-5b0435f03790e0fa682d>)[#text("(6)")]#text(" (providing one has sufficient measurability and integrability to make sense of this formula), thus providing a sort of “fractional dimensional integral” for symmetric functions. Thus, for instance, with this formalism the identities ")#link(<tao-f64551fcd6f07823cb87>)[#text("(4)")]#text(", ")#link(<tao-3946ca64ff78d93ca610>)[#text("(5)")]#text(" now hold for fractional values of ")#mi("{p}")#text(", even though the formal space ")#mi("{{\\bf R}^p}")#text(" no longer makes sense as a set, and the formal measure ")#mi("{\\mu^p}")#text(" no longer makes sense as a measure. (The formalism here is somewhat reminiscent of the technique of ")#link("https://en.wikipedia.org/wiki/Dimensional_regularization")[#text("dimensional regularisation")]#text(" employed in the physical literature in order to assign values to otherwise divergent integrals. See also ")#link("https://terrytao.wordpress.com/2013/02/19/supercommutative-gaussian-integration-and-the-gaussian-unitary-ensemble/")[#text("this post")]#text(" for an unrelated abstraction of the integration concept involving integration over supercommutative variables (and in particular over fermionic variables).)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" Suppose ")#mi("{\\mu}")#text(" is a probability measure on ")#mi("{\\Omega}")#text(", and ")#mi("{X: \\Omega \\rightarrow {\\bf R}}")#text(" is a random variable; on any power ")#mi("{\\Omega^k}")#text(", we let ")#mi("{X_1,\\dots,X_k: \\Omega^k \\rightarrow {\\bf R}}")#text(" be the usual independent copies of ")#mi("{X}")#text(" on ")#mi("{\\Omega^k}")#text(", thus ")#mi("{X_j(\\omega_1,\\dots,\\omega_k) := X(\\omega_j)}")#text(" for ")#mi("{(\\omega_1,\\dots,\\omega_k) \\in \\Omega^k}")#text(". Then for any real or complex ")#mi("{p}")#text(", the formal integral")

#align(center)[#tao-fit-display[#mitex("\\int_{\\Omega^p} [X_1]_{1 \\rightarrow p}^2\\ d\\mu^p")]]

#text("can be evaluated by first using the identity")

#align(center)[#tao-fit-display[#mitex("[X_1]_{1 \\rightarrow p}^2 = [X_1^2]_{1 \\rightarrow p} + 2[X_1 X_2]_{2 \\rightarrow p}")]]

#text("(cf. ")#link(<tao-ce71df4dc560de1e3e3d>)[#text("(1)")]#text(") and then using ")#link(<tao-5b0435f03790e0fa682d>)[#text("(6)")]#text(" and the probability measure hypothesis ")#mi("{\\int_\\Omega\\ d\\mu = 1}")#text(" to conclude that")

#tao-aligned(keep: true)[


#tao-math("\\int_{\\Omega^p} [X_1]_{1 \\rightarrow p}^2\\ d\\mu^p  & = \\binom{p}{1} \\int_{\\Omega} X^2\\ d\\mu + 2 \\binom{p}{2} \\int_{\\Omega^2} X_1 X_2\\ d\\mu^2", block: true)



#tao-math(" & = p (\\int_\\Omega X^2\\ d\\mu - (\\int_\\Omega X\\ d\\mu)^2) + p^2 (\\int_\\Omega X\\ d\\mu)^2", block: true)
]

#text("or in probabilistic notation ")#metadata(none) <tao-e1b771ff6831269c53a6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\int_{\\Omega^p} [X_1]_{1 \\rightarrow p}^2\\ d\\mu^p = p \\mathbf{Var}(X) + p^2 \\mathbf{E}(X)^2.")]]



#text(" For ")#mi("{p}")#text(" a natural number, this identity has the probabilistic interpretation ")#metadata(none) <tao-43ea9161e5649e6cb6fd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\mathbf{E}( X_1 + \\dots + X_p)^2 = p \\mathbf{Var}(X) + p^2 \\mathbf{E}(X)^2")]]



#text(" whenever ")#mi("{X_1,\\dots,X_p}")#text(" are jointly independent copies of ")#mi("{X}")#text(", which reflects the well known fact that the sum ")#mi("{X_1 + \\dots + X_p}")#text(" has expectation ")#mi("{p \\mathbf{E} X}")#text(" and variance ")#mi("{p \\mathbf{Var}(X)}")#text(". One can thus view ")#link(<tao-e1b771ff6831269c53a6>)[#text("(7)")]#text(" as an abstract generalisation of ")#link(<tao-43ea9161e5649e6cb6fd>)[#text("(8)")]#text(" to the case when ")#mi("{p}")#text(" is fractional, negative, or even complex, despite the fact that there is no sensible way in this case to talk about ")#mi("{p}")#text(" independent copies ")#mi("{X_1,\\dots,X_p}")#text(" of ")#mi("{X}")#text(" in the standard framework of probability theory.")

#text("In this particular case, the quantity ")#link(<tao-e1b771ff6831269c53a6>)[#text("(7)")]#text(" is non-negative for every nonnegative ")#mi("{p}")#text(", which looks plausible given the form of the left-hand side. Unfortunately, this sort of non-negativity does not always hold; for instance, if ")#mi("{X}")#text(" has mean zero, one can check that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\Omega^p} [X_1]_{1 \\rightarrow p}^4\\ d\\mu^p = p \\mathbf{Var}(X^2) + p(3p-2) (\\mathbf{E}(X^2))^2")]]

#text("and the right-hand side can become negative for ")#mi("{p < 2/3}")#text(". This is a shame, because otherwise one could hope to start endowing ")#mi("{L(X^p)_{sym}}")#text(" with some sort of commutative von Neumann algebra type structure (or the abstract probability structure discussed in ")#link("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/")[#text("this previous post")]#text(") and then interpret it as a genuine measure space rather than as a virtual one. (This failure of positivity is related to the fact that the ")#link("https://en.wikipedia.org/wiki/Characteristic_function_(probability_theory)")[#text("characteristic function")]#text(" of a random variable, when raised to the ")#mi("{p^{th}}")#text(" power, need not be a characteristic function of any random variable once ")#mi("{p}")#text(" is no longer a natural number: “fractional convolution” does not preserve positivity!) However, one vestige of positivity remains: if ")#mi("{F: \\Omega \\rightarrow {\\bf R}}")#text(" is non-negative, then so is")

#align(center)[#tao-fit-display[#mitex("\\int_{\\Omega^p} [F]_{1 \\rightarrow p}\\ d\\mu^p = p (\\int_\\Omega F\\ d\\mu) (\\int_\\Omega\\ d\\mu)^{p-1}.")]]
]

#text("One can wonder what the point is to all of this abstract formalism and how it relates to the rest of mathematics. For me, this formalism originated implicitly in an old paper I ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2275834")[#text("wrote with Jon Bennett and Tony Carbery")]#text(" on the multilinear restriction and Kakeya conjectures, though we did not have a good language for working with it at the time, instead working first with the case of natural number exponents ")#mi("{p}")#text(" and appealing to a general extrapolation theorem to then obtain various identities in the fractional ")#mi("{p}")#text(" case. The connection between these fractional dimensional integrals and more traditional integrals ultimately arises from the simple identity")

#align(center)[#tao-fit-display[#mitex("(\\int_\\Omega\\ d\\mu)^p = \\int_{\\Omega^p}\\ d\\mu^p")]]

#text("(where the right-hand side should be viewed as the fractional dimensional integral of the unit ")#mi("{[1]_{0 \\rightarrow p}}")#text(" against ")#mi("{\\mu^p}")#text("). As such, one can manipulate ")#mi("{p^{th}}")#text(" powers of ordinary integrals using the machinery of fractional dimensional integrals. A key lemma in this regard is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Differentiation formula)")]#text(" ")#metadata(none) <tao-311f38b7836c4228463d>#text(" Suppose that a positive measure ")#mi("{\\mu = \\mu(t)}")#text(" on ")#mi("{\\Omega}")#text(" depends on some parameter ")#mi("{t}")#text(" and varies by the formula ")#metadata(none) <tao-310452bca2c33f824da0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\frac{d}{dt} \\mu(t) = a(t) \\mu(t)")]]



#text(" for some function ")#mi("{a(t): \\Omega \\rightarrow {\\bf R}}")#text(". Let ")#mi("{p}")#text(" be any real or complex number. Then, assuming sufficient smoothness and integrability of all quantities involved, we have ")#metadata(none) <tao-3abd807250d1b53741c3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\frac{d}{dt} \\int_{\\Omega^p} F^{(p)}\\ d\\mu(t)^p = \\int_{\\Omega^p} F^{(p)} [a(t)]_{1 \\rightarrow p}\\ d\\mu(t)^p")]]



#text(" for all ")#mi("{F^{(p)} \\in L(\\Omega^p)_{sym}}")#text(" that are independent of ")#mi("{t}")#text(". If we allow ")#mi("{F^{(p)}(t)}")#text(" to now depend on ")#mi("{t}")#text(" also, then we have the more general total derivative formula ")#metadata(none) <tao-4ff1306aef01cc958725>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\frac{d}{dt} \\int_{\\Omega^p} F^{(p)}(t)\\ d\\mu(t)^p")]]





#align(center)[#tao-fit-display[#mitex("= \\int_{\\Omega^p} \\frac{d}{dt} F^{(p)}(t) + F^{(p)}(t) [a(t)]_{1 \\rightarrow p}\\ d\\mu(t)^p,")]]

#text("again assuming sufficient amounts of smoothness and regularity.")
]

#emph[#text("Proof:")]#text(" We just prove ")#link(<tao-3abd807250d1b53741c3>)[#text("(10)")]#text(", as ")#link(<tao-4ff1306aef01cc958725>)[#text("(11)")]#text(" then follows by same argument used to prove the usual product rule. By linearity it suffices to verify this identity in the case ")#mi("{F^{(p)} = [F^{(k)}]_{k \\rightarrow p}}")#text(" for some symmetric function ")#mi("{F^{(k)} \\in L(\\Omega^k)_{sym}}")#text(" for a natural number ")#mi("{k}")#text(". By ")#link(<tao-5b0435f03790e0fa682d>)[#text("(6)")]#text(", the left-hand side of ")#link(<tao-3abd807250d1b53741c3>)[#text("(10)")]#text(" is then ")#metadata(none) <tao-b0e432baa878a4511b98>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\frac{d}{dt} [\\binom{p}{k} (\\int_{\\Omega^k} F^{(k)}\\ d\\mu(t)^k) (\\int_\\Omega\\ d\\mu(t))^{p-k}].")]]



#text(" Differentiating under the integral sign using ")#link(<tao-310452bca2c33f824da0>)[#text("(9)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} \\int_\\Omega\\ d\\mu(t) = \\int_\\Omega\\ a(t)\\ d\\mu(t)")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} \\int_{\\Omega^k} F^{(k)}\\ d\\mu(t)^k = \\int_{\\Omega^k} F^{(k)}(a_1+\\dots+a_k)\\ d\\mu(t)^k")]]

#text("where ")#mi("{a_1,\\dots,a_k}")#text(" are the standard ")#mi("{k}")#text(" copies of ")#mi("{a = a(t)}")#text(" on ")#mi("{\\Omega^k}")#text(":")

#align(center)[#tao-fit-display[#mitex("a_j(\\omega_1,\\dots,\\omega_k) := a(\\omega_j).")]]

#text("By the product rule, we can thus expand ")#link(<tao-b0e432baa878a4511b98>)[#text("(12)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\binom{p}{k} (\\int_{\\Omega^k} F^{(k)}(a_1+\\dots+a_k)\\ d\\mu^k ) (\\int_\\Omega\\ d\\mu)^{p-k}")]]

#align(center)[#tao-fit-display[#mitex("+ \\binom{p}{k} (p-k) (\\int_{\\Omega^k} F^{(k)}\\ d\\mu^k) (\\int_\\Omega\\ a\\ d\\mu) (\\int_\\Omega\\ d\\mu)^{p-k-1}")]]

#text("where we have suppressed the dependence on ")#mi("{t}")#text(" for brevity. Since ")#mi("{\\binom{p}{k} (p-k) = \\binom{p}{k+1} (k+1)}")#text(", we can write this expression using ")#link(<tao-5b0435f03790e0fa682d>)[#text("(6)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\int_{\\Omega^p} [F^{(k)} (a_1 + \\dots + a_k)]_{k \\rightarrow p} + [ F^{(k)} \\ast a ]_{k+1 \\rightarrow p}\\ d\\mu^p")]]

#text("where ")#mi("{F^{(k)} \\ast a \\in L(\\Omega^{k+1})_{sym}}")#text(" is the symmetric function")

#align(center)[#tao-fit-display[#mitex("F^{(k)} \\ast a(\\omega_1,\\dots,\\omega_{k+1}) := \\sum_{j=1}^{k+1} F^{(k)}(\\omega_1,\\dots,\\omega_{j-1},\\omega_{j+1} \\dots \\omega_{k+1}) a(\\omega_j).")]]

#text("But from ")#link(<tao-ad954419e17a945c068b>)[#text("(2)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("[F^{(k)} (a_1 + \\dots + a_k)]_{k \\rightarrow p} + [ F^{(k)} \\ast a ]_{k+1 \\rightarrow p} = [F^{(k)}]_{k \\rightarrow p} [a]_{1 \\rightarrow p}")]]

#text("and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" ")#metadata(none) <tao-931ec906ad92720c7c91>#text(" It is also instructive to prove this lemma in the special case when ")#mi("{p}")#text(" is a natural number, in which case the fractional dimensional integral ")#mi("{\\int_{\\Omega^p} F^{(p)}\\ d\\mu(t)^p}")#text(" can be interpreted as a classical integral. In this case, the identity ")#link(<tao-3abd807250d1b53741c3>)[#text("(10)")]#text(" is immediate from applying the product rule to ")#link(<tao-310452bca2c33f824da0>)[#text("(9)")]#text(" to conclude that")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} d\\mu(t)^p = [a(t)]_{1 \\rightarrow p} d\\mu(t)^p.")]]

#text("One could in fact derive ")#link(<tao-3abd807250d1b53741c3>)[#text("(10)")]#text(" for arbitrary real or complex ")#mi("{p}")#text(" from the case when ")#mi("{p}")#text(" is a natural number by an extrapolation argument; see the appendix of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2275834")[#text("my paper with Bennett and Carbery")]#text(" for details.")
]

#text("Let us give a simple PDE application of this lemma as illustration:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5 (Heat flow monotonicity)")]#text(" ")#metadata(none) <tao-103b5c9495beee0f2be9>#text(" Let ")#mi("{u: [0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}}")#text(" be a solution to the heat equation ")#mi("{u_t = \\Delta u}")#text(" with initial data ")#mi("{\\mu_0}")#text(" a rapidly decreasing finite non-negative Radon measure, or more explicitly")

#align(center)[#tao-fit-display[#tao-math("u(t,x) = \\frac{1}{(4\\pi t)^{d/2}} \\int_{{\\bf R}^d} e^{-\\left|x-y\\right|^2/4t}\\ d\\mu_0(y)", block: true)]]

#text("for al ")#mi("{t>0}")#text(". Then for any ")#mi("{p>0}")#text(", the quantity")

#align(center)[#tao-fit-display[#mitex("Q_p(t) := t^{\\frac{d}{2} (p-1)} \\int_{{\\bf R}^d} u(t,x)^p\\ dx")]]

#text("is monotone non-decreasing in ")#mi("{t \\in (0,+\\infty)}")#text(" for ")#mi("{1 < p < \\infty}")#text(", constant for ")#mi("{p=1}")#text(", and monotone non-increasing for ")#mi("{0 < p < 1}")#text(".")
]

#emph[#text("Proof:")]#text(" By a limiting argument we may assume that ")#mi("{d\\mu_0}")#text(" is absolutely continuous, with Radon-Nikodym derivative a test function; this is more than enough regularity to justify the arguments below.")

#text("For any ")#mi("{(t,x) \\in (0,+\\infty) \\times {\\bf R}^d}")#text(", let ")#mi("{\\mu(t,x)}")#text(" denote the Radon measure")

#align(center)[#tao-fit-display[#tao-math("d\\mu(t,x)(y) := \\frac{1}{(4\\pi)^{d/2}} e^{-\\left|x-y\\right|^2/4t}\\ d\\mu_0(y).", block: true)]]

#text("Then the quantity ")#mi("{Q_p(t)}")#text(" can be written as a fractional dimensional integral")

#align(center)[#tao-fit-display[#mitex("Q_p(t) = t^{-d/2} \\int_{{\\bf R}^d} \\int_{({\\bf R}^d)^p}\\ d\\mu(t,x)^p\\ dx.")]]

#text("Observe that")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\partial}{\\partial t} d\\mu(t,x) = \\frac{\\left|x-y\\right|^2}{4t^2} d\\mu(t,x)", block: true)]]

#text("and thus by Lemma ")#link(<tao-311f38b7836c4228463d>)[#text("3")]#text(" and the product rule ")#metadata(none) <tao-6754af9632a2745e85c2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\frac{d}{dt} Q_p(t) = -\\frac{d}{2t} Q_p(t) + t^{-d/2} \\int_{{\\bf R}^d} \\int_{({\\bf R}^d)^p} [\\frac{\\left|x-y\\right|^2}{4t^2}]_{1 \\rightarrow p} d\\mu(t,x)^p\\ dx", block: true)]]



#text(" where we use ")#mi("{y}")#text(" for the variable of integration in the factor space ")#mi("{{\\bf R}^d}")#text(" of ")#mi("{({\\bf R}^d)^p}")#text(".")

#text("To simplify this expression we will take advantage of integration by parts in the ")#mi("{x}")#text(" variable. Specifically, in any direction ")#mi("{x_j}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial}{\\partial x_j} d\\mu(t,x) = -\\frac{x_j-y_j}{2t} d\\mu(t,x)")]]

#text("and hence by Lemma ")#link(<tao-311f38b7836c4228463d>)[#text("3")]

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial}{\\partial x_j} \\int_{({\\bf R}^d)^p}\\ d\\mu(t,x)^p\\ dx = - \\int_{({\\bf R}^d)^p} [\\frac{x_j-y_j}{2t}]_{1 \\rightarrow p}\\ d\\mu(t,x)^p\\ dx.")]]

#text("Multiplying by ")#mi("{x_j}")#text(" and integrating by parts, we see that")

#tao-aligned(keep: true)[


#tao-math("d Q_p(t)  & = \\int_{{\\bf R}^d} \\int_{({\\bf R}^d)^p} x_j [\\frac{x_j-y_j}{2t}]_{1 \\rightarrow p}\\ d\\mu(t,x)^p\\ dx", block: true)



#tao-math(" & = \\int_{{\\bf R}^d} \\int_{({\\bf R}^d)^p} x_j [\\frac{x_j-y_j}{2t}]_{1 \\rightarrow p}\\ d\\mu(t,x)^p\\ dx", block: true)
]

#text("where we use the Einstein summation convention in ")#mi("{j}")#text(". Similarly, if ")#mi("{F_j(y)}")#text(" is any reasonable function depending only on ")#mi("{y}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial}{\\partial x_j} \\int_{({\\bf R}^d)^p}[F_j(y)]_{1 \\rightarrow p}\\ d\\mu(t,x)^p\\ dx")]]

#align(center)[#tao-fit-display[#mitex("= - \\int_{({\\bf R}^d)^p} [F_j(y)]_{1 \\rightarrow p} [\\frac{x_j-y_j}{2t}]_{1 \\rightarrow p}\\ d\\mu(t,x)^p\\ dx")]]

#text("and hence on integration by parts")

#align(center)[#tao-fit-display[#mitex("0 = \\int_{{\\bf R}^d} \\int_{({\\bf R}^d)^p} [F_j(y) \\frac{x_j-y_j}{2t}]_{1 \\rightarrow p}\\ d\\mu(t,x)^p\\ dx.")]]

#text("We conclude that")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{2t} Q_p(t) = t^{-d/2} \\int_{{\\bf R}^d} \\int_{({\\bf R}^d)^p} (x_j - [F_j(y)]_{1 \\rightarrow p}) [\\frac{(x_j-y_j)}{4t}]_{1 \\rightarrow p} d\\mu(t,x)^p\\ dx")]]

#text("and thus by ")#link(<tao-6754af9632a2745e85c2>)[#text("(13)")]

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} Q_p(t) = \\frac{1}{4t^{\\frac{d}{2}+2}} \\int_{{\\bf R}^d} \\int_{({\\bf R}^d)^p}")]]

#align(center)[#tao-fit-display[#mitex("[(x_j-y_j)(x_j-y_j)]_{1 \\rightarrow p} - (x_j - [F_j(y)]_{1 \\rightarrow p}) [x_j - y_j]_{1 \\rightarrow p}\\ d\\mu(t,x)^p\\ dx.")]]

#text("The choice of ")#mi("{F_j}")#text(" that then achieves the most cancellation turns out to be ")#mi("{F_j(y) = \\frac{1}{p} y_j}")#text(" (this cancels the terms that are linear or quadratic in the ")#mi("{x_j}")#text("), so that ")#mi("{x_j - [F_j(y)]_{1 \\rightarrow p} = \\frac{1}{p} [x_j - y_j]_{1 \\rightarrow p}}")#text(". Repeating the calculations establishing ")#link(<tao-e1b771ff6831269c53a6>)[#text("(7)")]#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\int_{({\\bf R}^d)^p} [(x_j-y_j)(x_j-y_j)]_{1 \\rightarrow p}\\ d\\mu^p = p \\mathop{\\bf E} \\left|x-Y\\right|^2 (\\int_{{\\bf R}^d}\\ d\\mu)^{p}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\int_{({\\bf R}^d)^p} [x_j-y_j]_{1 \\rightarrow p} [x_j-y_j]_{1 \\rightarrow p}\\ d\\mu^p")]]

#align(center)[#tao-fit-display[#tao-math("= (p \\mathbf{Var}(x-Y) + p^2 \\left|\\mathop{\\bf E} x-Y\\right|^2) (\\int_{{\\bf R}^d}\\ d\\mu)^{p}", block: true)]]

#text("where ")#mi("{Y}")#text(" is the random variable drawn from ")#mi("{{\\bf R}^d}")#text(" with the normalised probability measure ")#mi("{\\mu / \\int_{{\\bf R}^d}\\ d\\mu}")#text(". Since ")#tao-math("{\\mathop{\\bf E} \\left|x-Y\\right|^2 = \\mathbf{Var}(x-Y) + \\left|\\mathop{\\bf E} x-Y\\right|^2}", block: false)#text(", one thus has ")#metadata(none) <tao-e77c4b3f81059b97c4d2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\frac{d}{dt} Q_p(t) = (p-1) \\frac{1}{4t^{\\frac{d}{2}+2}} \\int_{{\\bf R}^d} \\mathbf{Var}(x-Y) (\\int_{{\\bf R}^d}\\ d\\mu)^{p}\\ dx.")]]



#text(" This expression is clearly non-negative for ")#mi("{p>1}")#text(", equal to zero for ")#mi("{p=1}")#text(", and positive for ")#mi("{0 < p < 1}")#text(", giving the claim. (One could simplify ")#mi("{\\mathbf{Var}(x-Y)}")#text(" here as ")#mi("{\\mathbf{Var}(Y)}")#text(" if desired, though it is not strictly necessary to do so for the proof.) ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" As with Remark ")#link(<tao-931ec906ad92720c7c91>)[#text("4")]#text(", one can also establish the identity ")#link(<tao-e77c4b3f81059b97c4d2>)[#text("(14)")]#text(" first for natural numbers ")#mi("{p}")#text(" by direct computation avoiding the theory of fractional dimensional integrals, and then extrapolate to the case of more general values of ")#mi("{p}")#text(". This particular identity is also simple enough that it can be directly established by integration by parts without much difficulty, even for fractional values of ")#mi("{p}")#text(".")
]

#text("A more complicated version of this argument establishes the non-endpoint multilinear Kakeya inequality (without any logarithmic loss in a scale parameter ")#mi("{R}")#text("); this was established in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2275834")[#text("my previous paper with Jon Bennett and Tony Carbery")]#text(", but using the “natural number ")#mi("{p}")#text(" first” approach rather than using the current formalism of fractional dimensional integration. However, the arguments can be translated into this formalism without much difficulty; we do so below the fold. (To simplify the exposition slightly we will not address issues of establishing enough regularity and integrability to justify all the manipulations, though in practice this can be done by standard limiting arguments.)")

#metadata(none) <tao-dcc0b5abeba373d34e6d>

#heading(level: 1)[#strong[#text(" — 1. Multilinear heat flow monotonicity — ")]]

#text("Before we give a multilinear variant of Proposition ")#link(<tao-103b5c9495beee0f2be9>)[#text("5")]#text(" of relevance to the multilinear Kakeya inequality, we first need to briefly set up the theory of finite products")

#align(center)[#tao-fit-display[#mitex("\\Omega_1^{p_1} \\times \\dots \\times \\Omega_k^{p_k}")]]

#text("of fractional powers of spaces ")#mi("{\\Omega_1,\\dots,\\Omega_k}")#text(", where ")#mi("{p_1,\\dots,p_k}")#text(" are real or complex numbers. The functions ")#mi("{F^{(p_1,\\dots,p_k)}}")#text(" to integrate here lie in the tensor product space ")#metadata(none) <tao-cf4051ef5db4ce6e38aa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("L(\\Omega_1^{p_1})_{sym} \\otimes \\dots \\otimes L(\\Omega_k^{p_k})_{sym},")]]



#text(" which is generated by tensor powers")

#align(center)[#tao-fit-display[#mitex("F^{(p_1,\\dots,p_k)} = F_1^{(p_1)} \\otimes \\dots \\otimes F_k^{(p_k)}")]]

#text("with ")#mi("{F_j^{(p_j)} \\in L(\\Omega_j^{p_j})_{sym}}")#text(", with the usual tensor product identifications and algebra operations. One can evaluate fractional dimensional integrals of such functions against “virtual product measures” ")#mi("{d\\mu_1^{p_1} \\dots d\\mu_k^{p_k}}")#text(", with ")#mi("{\\mu_j}")#text(" a measure on ")#mi("{\\Omega_j}")#text(", by the natural formula")

#align(center)[#tao-fit-display[#mitex("\\int_{\\Omega_1^{p_1} \\times \\dots \\times \\Omega_k^{p_k}} F_1^{(p_1)} \\otimes \\dots \\otimes F_k^{(p_k)} d\\mu_1^{p_1} \\dots d\\mu_k^{p_k} := \\prod_{j=1}^k ( \\int_{\\Omega_j^{p_j}} F_j^{(p_j)}\\ d\\mu_j^{p_j} )")]]

#text("assuming sufficient measurability and integrability hypotheses. We can lift functions ")#mi("{F_j^{(m)} \\in L(\\Omega_j^m)_{sym}}")#text(" to an element ")#mi("{[F_j^{(m)}]_{m \\rightarrow p; j}}")#text(" of the space ")#link(<tao-cf4051ef5db4ce6e38aa>)[#text("(15)")]#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("[F_j^{(m)}]_{m \\rightarrow p; j} := 1^{\\otimes j-1} \\otimes [F_j^{(m)}]_{m \\rightarrow p} \\otimes 1^{\\otimes k-j}.")]]

#text("This is easily seen to be an algebra homomorphism.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 7")]#text(" If ")#mi("{F_1: \\Omega_1 \\rightarrow {\\bf R}}")#text(" and ")#mi("{F_2: \\Omega_2 \\rightarrow {\\bf R}}")#text(" are functions and ")#mi("{\\mu_1, \\mu_2}")#text(" are measures on ")#mi("{\\Omega_1, \\Omega_2}")#text(" respectively, then (assuming sufficient measurability and integrability) then the multiple fractional dimensional integral")

#align(center)[#tao-fit-display[#mitex("\\int_{\\Omega_1^{p_1} \\times \\Omega_2^{p_2}} [F_1]_{1 \\rightarrow p_1; 1} [F_2]_{1 \\rightarrow p_2;2}\\ d\\mu_1^{p_1} d\\mu^{p_2}")]]

#text("is equal to")

#align(center)[#tao-fit-display[#mitex("p_1 (\\int_{\\Omega_1} F_1\\ d\\mu_1) (\\int_{\\Omega_1}\\ d\\mu_1)^{p_1-1} p_2 (\\int_{\\Omega_2} F_2\\ d\\mu_2) (\\int_{\\Omega_2}\\ d\\mu_2)^{p_2-2}.")]]

#text("In the case that ")#mi("{p_1,p_2}")#text(" are natural numbers, one can view the “virtual” integrand ")#mi("{[F_1]_{1 \\rightarrow p_1; 1} [F_2]_{1 \\rightarrow p_2;2}}")#text(" here as an actual function on ")#mi("{\\Omega_1^{p_1} \\times \\Omega_2^{p_2}}")#text(", namely")

#align(center)[#tao-fit-display[#mitex("(\\omega_{1;1},\\dots,\\omega_{p_1;1}), (\\omega_{1;2},\\dots,\\omega_{p_2;2}) \\mapsto \\sum_{i_1=1}^{p_1} F_1(\\omega_{i_1;1}) \\sum_{i_2=1}^{p_2} F_2(\\omega_{i_2;2})")]]

#text("in which case the above evaluation of the integral can be achieved classically.")
]

#text("From a routine application of Lemma ")#link(<tao-311f38b7836c4228463d>)[#text("3")]#text(" and various forms of the product rule, we see that if each ")#mi("{\\mu_j(t)}")#text(" varies with respect to a time parameter ")#mi("{t}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} \\mu_j(t) = a_j(t) \\mu_j(t)")]]

#text("and ")#mi("{F^{(p_1,\\dots,p_k)}(t)}")#text(" is a time-varying function in ")#link(<tao-cf4051ef5db4ce6e38aa>)[#text("(15)")]#text(", then (assuming sufficient regularity and integrability), the time derivative")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} \\int_{\\Omega_1^{p_1} \\times \\dots \\times \\Omega_k^{p_k}} F^{(p_1,\\dots,p_k)}(t)\\ d\\mu_1(t)^{p_1} \\dots d\\mu_k(t)^{p_k}")]]

#text("is equal to ")#metadata(none) <tao-5002b25126af090487c8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\int_{\\Omega_1^{p_1} \\times \\dots \\times \\Omega_k^{p_k}} \\frac{d}{dt} F^{(p_1,\\dots,p_k)}(t)")]]





#text("Now suppose that for each space ")#mi("{\\Omega_j}")#text(" one has a non-negative measure ")#mi("{\\mu_j^0}")#text(", a vector-valued function ")#mi("{y_j: \\Omega_j \\rightarrow {\\bf R}^d}")#text(", and a matrix-valued function ")#mi("{A_j: \\Omega_j \\rightarrow {\\bf R}^{d \\times d}}")#text(" taking values in real symmetric positive semi-definite ")#mi("{d \\times d}")#text(" matrices. Let ")#mi("{p_1,\\dots,p_k}")#text(" be positive real numbers; we make the abbreviations")

#tao-aligned(keep: true)[


#tao-math("\\vec p  & := (p_1,\\dots,p_k)", block: true)



#tao-math("\\Omega^{\\vec p}  & := \\Omega_1^{p_1} \\times \\dots \\times \\Omega_k^{p_k}.", block: true)
]

#text("For any ")#mi("{t > 0}")#text(" and ")#mi("{x \\in {\\bf R}^d}")#text(", we define the modified measures")

#align(center)[#tao-fit-display[#mitex("d\\mu_j(t,x) := e^{-\\pi \\langle A_j(x-y_j), (x-y_j) \\rangle/t}\\ d\\mu_j^0")]]

#text("and then the product fractional power measure")

#align(center)[#tao-fit-display[#mitex("d\\mu(t,x)^{\\vec p} := d\\mu(t,x)_1^{p_1} \\dots d\\mu(t,x)_k^{p_k}.")]]

#text("If we then define the heat-type functions")

#align(center)[#tao-fit-display[#mitex("u_j(t,x) := \\int_{{\\bf R}^d}\\ d\\mu_j(t,x) = \\int_{{\\bf R}^d} e^{-\\pi \\langle A_j(x-y_j), (x-y_j) \\rangle/t}\\ d\\mu_j^0")]]

#text("(where we drop the normalising power of ")#mi("{t}")#text(" for simplicity) we see in particular that ")#metadata(none) <tao-e08d706b3e4ce964b632>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\int_{{\\bf R}^d} \\prod_{j=1}^k u_j(t,x)^{p_j}\\ dx = \\int_{\\Omega^{\\vec p}}\\ d\\mu(t,x)^{\\vec p}")]]



#text(" hence we can interpret the multilinear integral in the left-hand side of ")#link(<tao-e08d706b3e4ce964b632>)[#text("(17)")]#text(" as a product fractional dimensional integral. (We remark that in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2275834")[#text("my paper with Bennett and Carbery")]#text(", a slightly different parameterisation is used, replacing ")#mi("{x}")#text(" with ")#mi("{t x}")#text(", and also replacing ")#mi("{t}")#text(" with ")#mi("{1/t}")#text(".)")

#text("If the functions ")#mi("{A_j: \\Omega_j \\rightarrow {\\bf R}^{d \\times d}}")#text(" were constant in ")#mi("{\\Omega_j}")#text(", then the functions ")#mi("{u_j(t,x)}")#text(" would obey some heat-type partial differential equation, and the situation is now very analogous to Proposition ")#link(<tao-103b5c9495beee0f2be9>)[#text("5")]#text(" (and is also closely related to Brascamp-Lieb inequalities, as discussed for instance in ")#link("https://arxiv.org/abs/math/0408030")[#text("this paper of Carlen, Lieb, and Loss")]#text(", or ")#link("https://arxiv.org/abs/math/0505065")[#text("this paper of mine with Bennett, Carbery, and Christ")]#text("). However, for applications to the multilinear Kakeya inequality, we permit ")#mi("{A_j}")#text(" to vary slightly in the ")#mi("{\\Omega_j}")#text(" variable, and now the ")#mi("{u_j}")#text(" do not directly obey any PDE.")

#text("A naive extension of Proposition ")#link(<tao-103b5c9495beee0f2be9>)[#text("5")]#text(" would then seek to establish monotonicity of the quantity ")#link(<tao-e08d706b3e4ce964b632>)[#text("(17)")]#text(". While such monotonicity is available in the “Brascamp-Lieb case” of constant ")#mi("{A_j}")#text(", as discussed in the above papers, this does not quite seem to be to be true for variable ")#mi("{A_j}")#text(". To fix this problem, a weight is introduced in order to avoid having to take matrix inverses (which are not always available in this algebra). On the product fractional dimensional space ")#mi("{\\Omega^{\\vec p}}")#text(", we have a matrix-valued function ")#mi("{A_*}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("A_* := \\sum_{j=1}^k [A_j]_{1 \\rightarrow p_j; j}.")]]

#text("The determinant ")#mi("{\\mathrm{det}(A_*)}")#text(" is then a scalar element of the algebra ")#link(<tao-cf4051ef5db4ce6e38aa>)[#text("(15)")]#text(". We then define the quantity ")#metadata(none) <tao-b6b54201f23d00f5b719>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("Q_{\\vec p}(t) := t^{-d/2} \\int_{\\Omega^{\\vec p}}\\mathrm{det}(A_*)\\ d\\mu(t,x)^{\\vec p}.")]]





#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 8")]#text(" Suppose we take ")#mi("{k=2}")#text(" and let ")#mi("{p_1,p_2}")#text(" be natural numbers. Then ")#mi("{A_*}")#text(" can be viewed as the ")#mi("{2 \\times 2}")#text("-matrix valued function")

#align(center)[#tao-fit-display[#mitex("A_*(\\omega_{1;1},\\dots,\\omega_{p_1;1},\\omega_{1;2},\\dots,\\omega_{p_2;2}) = \\sum_{i=1}^{p_1} A_1(\\omega_{i;1}) + \\sum_{i=1}^{p_2} A_2(\\omega_{i;2}).")]]

#text("By slight abuse of notation, we write the determinant ")#mi("{\\mathrm{det}(A)}")#text(" of a ")#mi("{2 \\times 2}")#text(" matrix as ")#mi("{X \\wedge Y}")#text(", where ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are the first and second rows of ")#mi("{A}")#text(". Then")

#tao-aligned(keep: true)[


#tao-math("\\mathrm{det}(A_*)  & = \\sum_{1 \\leq i,i^{\\prime} \\leq p_1} X_1(\\omega_{i;1}) \\wedge Y_1(\\omega_{i^{\\prime};1})", block: true)



#tao-math(" & + \\sum_{i=1}^{p_1} \\sum_{i^{\\prime}=1}^{p_2} X_1(\\omega_{i;1}) \\wedge Y_2(\\omega_{i^{\\prime};2}) + X_2(\\omega_{i^{\\prime};2}) \\wedge Y_1(\\omega_{i;1})", block: true)



#tao-math(" & + \\sum_{1 \\leq i,i^{\\prime} \\leq p_2} X_2(\\omega_{i;2}) \\wedge Y_2(\\omega_{i^{\\prime};2})", block: true)
]

#text("and after some calculation, one can then write ")#mi("{Q_{\\vec p}(t)}")#text(" as")

#align(center)[#tao-fit-display[#mitex("p t^{-d/2} \\int_{{\\bf R}^d} (\\int_{\\Omega_1} X_1 \\wedge Y_1\\ d\\mu_1(t,x)) u_1(t,x)^{p_1-1} u_2(t,x)^{p_2}\\ dx")]]

#align(center)[#tao-fit-display[#mitex("+ p(p-1)t^{-d/2} \\int_{{\\bf R}^d} (\\int_{\\Omega_1^2} X_1(\\omega_1) \\wedge Y_1(\\omega_2)\\ d\\mu^2_1(t,x)(\\omega_1,\\omega_2))")]]

#align(center)[#tao-fit-display[#mitex("u_1(t,x)^{p_1-2} u_2(t,x)^{p_2}\\ dx")]]

#align(center)[#tao-fit-display[#mitex("+ p^2t^{-d/2} \\int_{{\\bf R}^d} (\\int_{\\Omega_1} X_1\\ d\\mu_1(t,x) \\wedge \\int_{\\Omega_2} Y_2\\ d\\mu_2(t,x)")]]

#align(center)[#tao-fit-display[#mitex("+ \\int_{\\Omega_2} X_2\\ d\\mu_2(t,x) \\wedge \\int_{\\Omega_1} Y_1\\ d\\mu_1(t,x)) u_1(t,x)^{p_1-1} u_2(t,x)^{p_2-1}\\ dx")]]

#align(center)[#tao-fit-display[#mitex("p t^{-d/2}\\int_{{\\bf R}^d} (\\int_{\\Omega_2} X_2 \\wedge Y_2\\ d\\mu_2(t,x)) u_1(t,x)^{p_1} u_2(t,x)^{p_2-1}\\ dx")]]

#align(center)[#tao-fit-display[#mitex("+ p(p-1)t^{-d/2} \\int_{{\\bf R}^d} (\\int_{\\Omega_2^2} X_2(\\omega_1) \\wedge Y_2(\\omega_2)\\ d\\mu^2_2(t,x)(\\omega_1,\\omega_2))")]]

#align(center)[#tao-fit-display[#mitex("u_1(t,x)^{p_1} u_2(t,x)^{p_2-2}\\ dx.")]]

#text("By a polynomial extrapolation argument, this formula is then also valid for fractional values of ")#mi("{p}")#text("; this can also be checked directly from the definitions after some tedious computation. Thus we see that while the compact-looking fractional dimensional integral ")#link(<tao-b6b54201f23d00f5b719>)[#text("(18)")]#text(" can be expressed in terms of more traditional integrals, the formulae get rather messy, even in the ")#mi("{d=2}")#text(" case. As such, the fractional dimensional calculus (based heavily on derivative identities such as ")#link(<tao-5002b25126af090487c8>)[#text("(16)")]#text(") gives a more convenient framework to manipulate these otherwise quite complicated expressions.")
]

#text("Suppose the functions ")#mi("{A_j: \\Omega_j \\rightarrow {\\bf R}^{d \\times d}}")#text(" are close to constant ")#mi("{d \\times d}")#text(" matrices ")#mi("{A_j^0 \\in {\\bf R}^{d \\times d}}")#text(", in the sense that ")#metadata(none) <tao-4a4c489e75c9297e38b4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("A_j = A_j^0 + O(\\varepsilon)")]]



#text(" uniformly on ")#mi("{\\Omega_j}")#text(" for some small ")#mi("{\\varepsilon>0}")#text(" (where we use for instance the operator norm to measure the size of matrices, and we allow implied constants in the ")#mi("{O()}")#text(" notation to depend on ")#mi("{d, \\vec p}")#text(", and the ")#mi("{A_j^0}")#text("). Then we can write ")#mi("{A_j = A_j^0 + \\varepsilon C_j}")#text(" for some bounded matrix ")#mi("{C_j}")#text(", and then we can write")

#align(center)[#tao-fit-display[#mitex("A_* = \\sum_{j=1}^k [A_j^0]_{1 \\rightarrow p_j;j} + \\varepsilon [B_j]_{1 \\rightarrow p_j;j} = \\sum_{j=1}^k p_j A_j^0 + \\varepsilon \\sum_{j=1}^k [B_j^0]_{1 \\rightarrow p_j;j}.")]]

#text("We can therefore write")

#align(center)[#tao-fit-display[#mitex("\\mathrm{det}(A_*) = \\mathrm{det}(A_*^0) + \\varepsilon B_*")]]

#text("where ")#mi("{A_*^0 := \\sum_{j=1}^k p_j A_j^0}")#text(" and the coefficients of the matrix ")#mi("{C_*}")#text(" are some polynomial combination of the coefficients of ")#mi("{[C_j^0]_{1 \\rightarrow p_j;j}}")#text(", with all coefficients in this polynomial of bounded size. As a consequence, and on expanding out all the fractional dimensional integrals, one obtains a formula of the form")

#tao-aligned(keep: true)[


#tao-math("Q_{\\vec p}(t)  & = t^{-d/2} (\\mathrm{det}(A_*^0) + O(\\varepsilon)) \\int_{\\Omega^{\\vec p}} \\ d\\mu(t,x)^{\\vec p}", block: true)



#tao-math(" & = t^{-d/2} (\\mathrm{det}(A_*^0) + O(\\varepsilon)) \\int_{{\\bf R}^d} \\prod_{j=1}^k u_j(t,x)^{p_j}\\ dx .", block: true)
]

#text("Thus, as long as ")#mi("{A_*^0}")#text(" is strictly positive definite and ")#mi("{\\varepsilon}")#text(" is small enough, this quantity ")#mi("{Q_{\\vec p}(t)}")#text(" is comparable to the classical integral")

#align(center)[#tao-fit-display[#mitex("t^{-d/2} \\int_{{\\bf R}^d} \\prod_{j=1}^k u_j(t,x)^{p_j}\\ dx.")]]

#text("Now we compute the time derivative of ")#mi("{Q_{\\vec p}(t)}")#text(". We have")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial}{\\partial t} \\mu_j(t,x) = \\frac{\\pi}{t^2} \\langle A_j(x-y_j),(x-y_j) \\rangle \\mu_j(t,x)")]]

#text("so by ")#link(<tao-5002b25126af090487c8>)[#text("(16)")]#text(", one can write ")#mi("{\\frac{d}{dt} Q_{\\vec p}(t)}")#text(" as ")#metadata(none) <tao-6da0633528deaa0144e7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("-\\frac{d}{2} Q_{\\vec p}(t) + \\frac{\\pi}{t^{\\frac{d}{2}+2}} \\int_{{\\bf R}^d} \\int_{\\Omega^{\\vec p}}")]]





#align(center)[#tao-fit-display[#mitex("\\mathrm{det}(A_*) \\sum_{j=1}^k [\\langle A_j(x-y_j),(x-y_j) \\rangle]_{1 \\rightarrow p_j;j}\\ d\\mu(t,x)^{\\vec p}\\ dx")]]

#text("where we use ")#mi("{y_j}")#text(" as the coordinate for the copy of ")#mi("{{\\bf R}^d}")#text(" that is being lifted to ")#mi("{({\\bf R}^d)^{p_j}}")#text(".")

#text("As before, we can take advantage of some cancellation in this expression using integration by parts. Since")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial}{\\partial x_i} \\mu_j(t,x) = -\\frac{2\\pi}{t} \\langle A_j(x-y_j), e_i\\rangle \\mu_j(t,x)")]]

#text("where ")#mi("{e_1,\\dots,e_d}")#text(" are the standard basis for ")#mi("{{\\bf R}^d}")#text(", we see from ")#link(<tao-5002b25126af090487c8>)[#text("(16)")]#text(" and integration by parts that")

#align(center)[#tao-fit-display[#mitex("d Q_{\\vec p}(t) = \\frac{2\\pi}{t^{\\frac{d}{2}+1}} \\int_{{\\bf R}^d} \\int_{\\Omega^{\\vec p}}\\mathrm{det}(A_*) \\sum_{j=1}^k x_i [\\langle A_j(x-y_j), e_i\\rangle]_{1 \\rightarrow p_j;j}\\ d\\mu(t,x)^{\\vec p}")]]

#text("with the usual summation conventions on the index ")#mi("{i}")#text(". Also, similarly to before, we suppose we have an element ")#mi("{F_i}")#text(" of ")#link(<tao-cf4051ef5db4ce6e38aa>)[#text("(15)")]#text(" for each ")#mi("{i}")#text(" that does not depend on ")#mi("{x}")#text(", then by ")#link(<tao-5002b25126af090487c8>)[#text("(16)")]#text(" and integration by parts")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} \\int_{\\Omega^{\\vec p}} \\sum_{j=1}^k F_i [\\langle A_j(x-y_j), e_i\\rangle]_{1 \\rightarrow p_j;j}\\ d\\mu(t,x)^{\\vec p} = 0")]]

#text("or, writing ")#mi("{F = (F_1,\\dots,F_d)}")#text(",")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} \\int_{\\Omega^{\\vec p}} \\sum_{j=1}^k \\langle [A_j(x-y_j)]_{1 \\rightarrow p_j;j}, F \\rangle\\ d\\mu(t,x)^{\\vec p} = 0.")]]

#text("We can thus write ")#link(<tao-6da0633528deaa0144e7>)[#text("(20)")]#text(" as ")#metadata(none) <tao-a41ad70599b509c1953a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\frac{d}{dt} Q_{\\vec p}(t) = \\frac{\\pi}{t^{\\frac{d}{2}+2}} \\int_{{\\bf R}^d} \\int_{\\Omega^{\\vec p}} G\\ d\\mu(t,x)^{\\vec p}\\ dx")]]



#text(" where ")#mi("{G = G(x)}")#text(" is the element of ")#link(<tao-cf4051ef5db4ce6e38aa>)[#text("(15)")]#text(" given by ")#metadata(none) <tao-868516e307d91e7f8266>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("G := \\mathrm{det}(A_*) \\sum_{j=1}^k [\\langle A_j(x-y_j),(x-y_j) \\rangle]_{1 \\rightarrow p_j;j}")]]





#align(center)[#tao-fit-display[#mitex("- \\langle \\sum_{j=1}^k [A_j(x-y_j)]_{1 \\rightarrow p_j;j}, \\mathrm{det}(A_*) x - F \\rangle.")]]

#text("The terms in ")#mi("{G}")#text(" that are quadratic in ")#mi("{x}")#text(" cancel. The linear term can be rearranged as")

#align(center)[#tao-fit-display[#mitex("\\langle x, A_* F - \\mathrm{det}(A_*) \\sum_{j=1}^k [A_j y_j]_{1 \\rightarrow p_j; j} \\rangle.")]]

#text("To cancel this, one would like to set ")#mi("{F}")#text(" equal to")

#align(center)[#tao-fit-display[#mitex("F = A_*^{-1}\\mathrm{det}(A_*) \\sum_{j=1}^k [A_j y_j]_{1 \\rightarrow p_j; j} .")]]

#text("Now in the commutative algebra ")#link(<tao-cf4051ef5db4ce6e38aa>)[#text("(15)")]#text(", the inverse ")#mi("{A_*^{-1}}")#text(" does not necessarily exist. However, because of the weight factor ")#mi("{\\mathrm{det}(A_*)}")#text(", one can work instead with the adjugate matrix ")#mi("{\\mathrm{adj}(A_*)}")#text(", which is such that ")#mi("{\\mathrm{adj}(A_*) A_* = A_* \\mathrm{adj}(A_*) \\mathrm{det}(A_*) I}")#text(" where ")#mi("{I}")#text(" is the identity matrix. We therefore set ")#mi("{F}")#text(" equal to the expression")

#align(center)[#tao-fit-display[#mitex("F := \\mathrm{adj}(A_*) \\sum_{j=1}^k [A_j y_j]_{1 \\rightarrow p_j; j}")]]

#text("and now the expression in ")#link(<tao-868516e307d91e7f8266>)[#text("(22)")]#text(" does not contain any linear or quadratic terms in ")#mi("{x}")#text(". In particular it is completely independent of ")#mi("{x}")#text(", and thus we can write")

#tao-aligned(keep: true)[


#tao-math("G  & = \\mathrm{det}(A_*) \\sum_{j=1}^k [\\langle A_j(\\overline{y}-y_j),(\\overline{y}-y_j) \\rangle]_{1 \\rightarrow p_j;j}", block: true)



#tao-math(" & - \\langle \\sum_{j=1}^k [A_j(\\overline{y}-y_j)]_{1 \\rightarrow p_j;j}, \\mathrm{det}(A_*) \\overline{y} - F \\rangle", block: true)
]

#text("where ")#mi("{\\overline{y} = \\overline{y}(t,x)}")#text(" is an arbitrary element of ")#mi("{{\\bf R}^d}")#text(" that we will select later to obtain a useful cancellation. We can rewrite this a little as")

#tao-aligned(keep: true)[


#tao-math("G  & = \\mathrm{det}(A_*) \\sum_{j=1}^k [\\langle A_j(\\overline{y}-y_j),(\\overline{y}-y_j) \\rangle]_{1 \\rightarrow p_j;j}", block: true)



#tao-math(" & - \\langle \\sum_{j=1}^k [A_j(\\overline{y}-y_j)]_{1 \\rightarrow p_j;j}, \\mathrm{adj}(A_*) \\sum_{j^{\\prime}=1}^k [A_j(\\overline{y} - y_j)]_{1 \\rightarrow p_j; j} \\rangle.", block: true)
]

#text("If we now introduce the matrix functions")

#align(center)[#tao-fit-display[#mitex("B_j := A_j^{1/2}")]]

#text("and the vector functions")

#align(center)[#tao-fit-display[#mitex("w_j := B_j( \\overline{y} - y_j)")]]

#text("then this can be rewritten as")

#tao-aligned(keep: true)[


#tao-math("G  & = \\mathrm{det}(A_*) \\sum_{j=1}^k [\\left\\|w_j\\right\\|^2]_{1 \\rightarrow p_j;j}", block: true)



#tao-math(" & - \\langle \\sum_{j=1}^k [B_j w_j]_{1 \\rightarrow p_j;j}, \\mathrm{adj}(A_*) \\sum_{j^{\\prime}=1}^k [B_j w_j]_{1 \\rightarrow p_j; j} \\rangle.", block: true)
]

#text("Similarly to ")#link(<tao-4a4c489e75c9297e38b4>)[#text("(19)")]#text(", suppose that we have")

#align(center)[#tao-fit-display[#mitex("B_j = B_j^0 + O(\\varepsilon)")]]

#text("uniformly on ")#mi("{\\Omega_j}")#text(", where ")#mi("{B_j^0 := (A_j^0)^{1/2}}")#text(", thus we can write ")#metadata(none) <tao-2f05d4b689d270cafb02>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("B_j = B_j^0 + \\varepsilon D_j")]]



#text(" for some bounded matrix-valued functions ")#mi("{D_j}")#text(". Inserting this into the previous expression (and expanding out ")#mi("{A_*}")#text(" appropriately) one can eventually write")

#align(center)[#tao-fit-display[#mitex("G = G^0 + \\varepsilon H")]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("G^0  & = \\mathrm{det}(A^0_*) (\\sum_{j=1}^k [\\left\\|w_j\\right\\|^2]_{1 \\rightarrow p_j;j}", block: true)



#tao-math(" & - \\langle \\sum_{j=1}^k B^0_j [w_j]_{1 \\rightarrow p_j;j}, (A^0_*)^{-1} \\sum_{j^{\\prime}=1}^k B^0_j [w_j]_{1 \\rightarrow p_j; j} \\rangle )", block: true)
]

#text("and ")#mi("{H}")#text(" is some polynomial combination of the ")#mi("{D_j}")#text(" and ")#mi("{w_j}")#text(" (or more precisely, of the quantities ")#mi("{[D_j]_{1 \\rightarrow p_j;j}}")#text(", ")#mi("{[w_j]_{1 \\rightarrow p_j;j}}")#text(", ")#mi("{[D_j w_j]_{1 \\rightarrow p_j;j}}")#text(", ")#tao-math("{[\\left\\|w_j\\right\\|^2]_{1 \\rightarrow p_j;j}}", block: false)#text(") that is quadratic in the ")#mi("{w_j}")#text(" variables, with bounded coefficients. As a consequence, after expanding out the product fractional dimensional integrals and applying some Cauchy-Schwarz to control cross-terms, we have")

#tao-aligned(keep: true)[


#tao-math("\\frac{d}{dt} Q_{\\vec p}(t)  & = \\frac{\\pi}{t^{\\frac{d}{2}+2}} \\int_{{\\bf R}^d} \\int_{\\Omega^{\\vec p}} G^0\\ d\\mu(t,x)^{\\vec p}\\ dx", block: true)



#tao-math(" & + O( \\varepsilon t^{-\\frac{d}{2}+2} \\int_{{\\bf R}^d} \\int_{\\Omega^{\\vec p}} \\sum_{j=1}^k [\\left\\| w_j \\right\\|^2]_{1 \\rightarrow p_j;j}d\\mu(t,x)^{\\vec p}\\ dx).", block: true)
]

#text("Now we simplify ")#mi("{G^0}")#text(". We let")

#align(center)[#tao-fit-display[#mitex("\\overline{w_j} := \\frac{\\int_{\\Omega_j} w_j\\ d\\mu_j}{\\int_{\\Omega_j}\\ d\\mu_j}")]]

#text("be the average value of ")#mi("{\\overline{w_j}}")#text("; for each ")#mi("{t,x}")#text(" this is just a vector in ")#mi("{{\\bf R}^d}")#text(". We then split ")#mi("{w_j = \\overline{w_j} + (w_j - \\overline{w_j})}")#text(", leading to the identities")

#tao-aligned(keep: true)[


#tao-math("[\\left\\|w_j\\right\\|^2]_{1 \\rightarrow p_j;j}  & = p_j \\left\\|\\overline{w_j}\\right\\|^2 + 2 \\langle \\overline{w_j}, [w_j - \\overline{w_j}]_{1 \\rightarrow p_j;j}\\rangle", block: true)



#tao-math(" & + [\\left\\| w_j - \\overline{w_j} \\right\\|^2]_{1 \\rightarrow p_j;j}", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^k B^0_j [w_j]_{1 \\rightarrow p_j;j} = \\sum_{j=1}^k p_j B^0_j \\overline{w_j} + \\sum_{j=1}^k B^0_j [(w_j - \\overline{w_j})]_{1 \\rightarrow p_j;j}.")]]

#text("The term ")#mi("{\\sum_{j=1}^k p_j B^0_j \\overline{w_j}}")#text(" is problematic, but we can eliminate it as follows. By construction one has (supressing the dependence on ")#mi("{t,x}")#text(")")

#tao-aligned(keep: true)[


#tao-math("\\sum_{j=1}^k p_j B^0_j \\overline{w_j} \\int_{\\Omega^p} \\ d\\mu^{\\vec p}  & = \\int_{\\Omega^p} \\sum_{j=1}^k B^0_j [w_j]_{1 \\rightarrow p_j; j} \\ d\\mu^{\\vec p}", block: true)



#tao-math(" & = \\int_{\\Omega^p}\\sum_{j=1}^k B^0_j [B_j(\\overline{y} - y_j)]_{1 \\rightarrow p_j; j} \\ d\\mu^{\\vec p}", block: true)



#tao-math(" & = \\int_{\\Omega^p}\\sum_{j=1}^k B^0_j [B_j]_{1 \\rightarrow p_j;j} \\overline{y} - \\int_{\\Omega^p}\\sum_{j=1}^k B^0_j [B_j y_j]_{1 \\rightarrow p_j; j} \\ d\\mu^{\\vec p}.", block: true)
]

#text("By construction, one has")

#tao-aligned(keep: true)[


#tao-math("\\int_{\\Omega^p}\\sum_{j=1}^k B^0_j [B_j]_{1 \\rightarrow p_j;j}\\ d\\mu^{\\vec p}  & = (\\sum_{j=1}^k p B_0^j B_0^j + O(\\varepsilon)) \\int_{\\Omega^p}\\ d\\mu^{\\vec p}", block: true)



#tao-math(" & = (A^0_* + O(\\varepsilon)) \\int_{\\Omega^p}\\ d\\mu^{\\vec p}.", block: true)
]

#text("Thus if ")#mi("{A^0_*}")#text(" is positive definite and ")#mi("{\\varepsilon}")#text(" is small enough, this matrix is invertible, and we can choose ")#mi("{\\overline{y}}")#text(" so that the expression ")#mi("{\\sum_{j=1}^k p_j B^0_j \\overline{w_j} }")#text(" vanishes. Making this choice, we then have")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^k [B^0_j w_j]_{1 \\rightarrow p_j;j} = \\sum_{j=1}^k [B^0_j (w_j - \\overline{w_j})]_{1 \\rightarrow p_j;j}.")]]

#text("Observe that the fractional dimensional integral of")

#align(center)[#tao-fit-display[#mitex("\\langle \\overline{w_j}, [w_j - \\overline{w_j}]_{1 \\rightarrow p_j;j} \\rangle")]]

#text("or")

#align(center)[#tao-fit-display[#mitex("\\langle [w_j - \\overline{w_j}]_{1 \\rightarrow p_j;j}, M [w_{j^{\\prime}} - \\overline{w_{j^{\\prime}}}]_{1 \\rightarrow p_{j^{\\prime}};j^{\\prime}}")]]

#text("for ")#mi("{j \\neq j^{\\prime}}")#text(" and arbitrary constant matrices ")#mi("{M}")#text(" against ")#mi("{d\\mu^{\\vec p}}")#text(" vanishes. As a consequence, we can now simplify the integral ")#metadata(none) <tao-d7b19de7aed5e4ca5d0a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\int_{\\Omega^p} G_0\\ d\\mu^{\\vec p}")]]



#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{det}(A^0_*) \\int_{\\Omega^p} \\sum_{j=1}^k p_j \\left\\| \\overline{w_j}\\right\\|^2", block: true)]]

#align(center)[#tao-fit-display[#mitex("+ \\langle [w_j - \\overline{w_j}]_{1 \\rightarrow p_j;j}, (1 - B_0^j (A^0_*)^{-1} B_0^{j}) [w_j - \\overline{w_j}]_{1 \\rightarrow p_j; j} \\rangle\\ d\\mu^{\\vec p}.")]]

#text("Using ")#link(<tao-ad954419e17a945c068b>)[#text("(2)")]#text(", we can split")

#align(center)[#tao-fit-display[#mitex("\\langle [w_j - \\overline{w_j}]_{1 \\rightarrow p_j;j}, (1 - B_0^j (A^0_*)^{-1} B_0^{j}) [w_j - \\overline{w_j}]_{1 \\rightarrow p_j; j} \\rangle")]]

#text("as the sum of")

#align(center)[#tao-fit-display[#mitex("[\\langle w_j - \\overline{w_j}, (1 - B_0^j (A^0_*)^{-1} B_0^{j}) (w_j - \\overline{w_j}) \\rangle ]_{1 \\rightarrow p_j; j}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("2[\\langle w_j(\\omega_1) - \\overline{w_j}, (1 - B_0^j (A^0_*)^{-1} B_0^{j}) (w_j(\\omega_2) - \\overline{w_j}) \\rangle ]_{2 \\rightarrow p_j; j}.")]]

#text("The latter also integrates to zero by the mean zero nature of ")#mi("{w_j - \\overline{w_j}}")#text(". Thus we have simplified ")#link(<tao-d7b19de7aed5e4ca5d0a>)[#text("(24)")]#text(" to")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{det}(A^0_*) \\int_{\\Omega^p} \\sum_{j=1}^k p_j \\left\\| \\overline{w_j}\\right\\|^2", block: true)]]

#align(center)[#tao-fit-display[#mitex("+ [\\langle w_j - \\overline{w_j}, (1 - B_0^j (A^0_*)^{-1} B_0^{j}) (w_j - \\overline{w_j}) \\rangle ]_{1 \\rightarrow p_j; j} \\ d\\mu^{\\vec p}.")]]

#text("Now let us make the key hypothesis that the matrix")

#align(center)[#tao-fit-display[#mitex("1 - B_0^j (A^0_*)^{-1} B_0^{j}")]]

#text("is strictly positive definite, or equivalently that")

#align(center)[#tao-fit-display[#mitex("\\sum_{j^{\\prime}=1}^k p_{j^{\\prime}} A_{j^{\\prime}}^0 > A_j")]]

#text("for all ")#mi("{j=1,\\dots,k}")#text(", where the ordering is in the sense of positive definite matrices. Then we have the pointwise bound")

#align(center)[#tao-fit-display[#tao-math("\\langle w_j - \\overline{w_j}, (1 - B_0^j (A^0_*)^{-1} B_0^{j}) (w_j - \\overline{w_j}) \\rangle \\gtrsim \\left\\| w_j - \\overline{w_j} \\right\\|^2", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} Q_{\\vec p}(t) \\gtrsim t^{-\\frac{d}{2}+2} \\int_{{\\bf R}^d} \\int_{\\Omega^p}")]]

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^k [\\left\\|\\overline{w_j}\\right\\|^2 + \\left\\| w_j - \\overline{w_j} \\right\\|^2 - O(\\varepsilon) \\left\\|w_j\\right\\|^2 ]_{1 \\rightarrow p_j;j}\\ d\\mu^{\\vec p}\\ dx.", block: true)]]

#text("For ")#mi("{\\varepsilon}")#text(" small enough, the expression inside the ")#mi("{[]_{1 \\rightarrow p_j;j}}")#text(" is non-negative, and we conclude the monotonicity")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} Q_{\\vec p}(t) \\geq 0.")]]

#text("We have thus proven the following statement, which is essentially Proposition 4.1 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2275834")[#text("my paper with Bennett and Carbery")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 9")]#text(" Let ")#mi("{d,k \\geq 1}")#text(", let ")#mi("{A_1^0,\\dots,A_k^0}")#text(" be positive semi-definite real symmetric ")#mi("{d \\times d}")#text(" matrices, and let ")#mi("{p_1,\\dots,p_k>0}")#text(" be such that ")#metadata(none) <tao-b1d6b91b67c2afa5e322>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("p_1 A_1^0 + \\dots + p_k A_k^0 > A_j^0")]]



#text(" for ")#mi("{j=1,\\dots,d}")#text(". Then for any positive measure spaces ")#mi("{\\Omega_1,\\dots,\\Omega_k}")#text(" with measures ")#mi("{\\mu_1^0,\\dots,\\mu_k^0}")#text(" and any functions ")#mi("{A_j, y_j}")#text(" on ")#mi("{\\Omega_j}")#text(" with ")#mi("{A_j = A_j^0 + O(\\varepsilon)}")#text(" for a sufficiently small ")#mi("{\\varepsilon>0}")#text(", the quantity ")#mi("{Q_{\\vec p}(t)}")#text(" is non-decreasing in ")#mi("{t \\in (0,+\\infty)}")#text(", and is also equal to")

#align(center)[#tao-fit-display[#mitex("t^{-d/2} (\\mathrm{det}(A_*^0) + O(\\varepsilon)) \\int_{{\\bf R}^d} \\prod_{j=1}^k u_j(t,x)^{p_j}\\ dx.")]]

#text("In particular, we have")

#align(center)[#tao-fit-display[#mitex("t^{-d/2} \\int_{{\\bf R}^d} \\prod_{j=1}^k u_j(t,x)^{p_j}\\ dx \\lesssim \\limsup_{T \\rightarrow \\infty} T^{-d/2} \\int_{{\\bf R}^d} \\prod_{j=1}^k u_j(T,x)^{p_j}\\ dx")]]

#text("for any ")#mi("{t>0}")#text(".")
]

#text("A routine calculation shows that for reasonable choices of ")#mi("{\\mu_j^0}")#text(" (e.g. discrete measures of finite support), one has")

#align(center)[#tao-fit-display[#mitex("\\limsup_{T \\rightarrow \\infty} T^{-d/2} \\int_{{\\bf R}^d} \\prod_{j=1}^k u_j(T,x)^{p_j}\\ dx \\lesssim \\prod_{j=1}^k \\mu_j^0({\\bf R}^d)^{p_j}")]]

#text("and hence (setting ")#mi("{t=1}")#text(") we have")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} \\prod_{j=1}^k u_j(t,x)^{p_j}\\ dx \\lesssim \\prod_{j=1}^k \\mu_j^0({\\bf R}^d).")]]

#text("If we choose the ")#mi("{\\mu_j^0}")#text(" to be the sum of ")#mi("{N_j}")#text(" Dirac masses, and each ")#mi("{A_j^0}")#text(" to be the diagonal matrix ")#mi("{A_j^0 = I - e_j e_j^T}")#text(", then the key condition ")#link(<tao-b1d6b91b67c2afa5e322>)[#text("(25)")]#text(" is obeyed for ")#mi("{p_1=\\dots=p_k = p > \\frac{1}{d-1}}")#text(", and one arrives at the multilinear Kakeya inequality")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} \\prod_{j=1}^k (\\sum_{i=1}^{N_j} 1_{T_{j,i}})^p \\lesssim \\prod_{j=1}^k N_j^{p_j}")]]

#text("whenever ")#mi("{T_{j,i}}")#text(" are infinite tubes in ")#mi("{{\\bf R}^d}")#text(" of width ")#mi("{1}")#text(" and oriented within ")#mi("{\\varepsilon}")#text(" of the basis vector ")#mi("{e_j}")#text(", for a sufficiently small absolute constant ")#mi("{\\varepsilon}")#text(". (The hypothesis on the directions can then be relaxed to a transversality hypothesis by applying some linear transformations and the triangle inequality.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (21)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/#comment-517972")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2019")])]

#text("What are the main ideas? And what are you trying to achieve with the complex mathematics?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/#comment-517994")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2019")])]

#text("“One can wonder what the point is to all of this abstract formalism and how it relates to the rest of mathematics…” — Prof. Tao.")

#text("Some of us, I think, do not understand what you are doing here. Please explain to us in plain English, your goals and main ideas here. And maybe then, we can better appreciate the high-level mathematics associated with your ideas.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/#comment-517998")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2019")])]

#text("FYI: Please gather some information at the link below:")

#link("https://en.wikipedia.org/wiki/Kakeya_set")[#text("https://en.wikipedia.org/wiki/Kakeya_set")]

#text("I hope it helps you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/#comment-518025")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2019")])]

#text("Thanks! It helps a bit. That link is quite interesting! And I understand some of its content.")

#text("But ‘Symmetric functions in a fractional number of variables, and the multilinear Kakeya conjecture’ is generally beyond me, and it is probably meant for the elite few or insiders (highly specialized audience)…")

#text("C’est la vie.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/#comment-518949")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2019")])]

#text("The ability to learn and the ability to absorb/understand complex or advanced mathematical ideas are a big part of any mathematician’s toolbox to solve problems or to do advanced research…")

#text("Please try solving some Diophantine equations (DEs) using two or more distinct variables (you may use parts of example 1 above as a starting point) to get some feel for the theory posted here.")

#text("And rethink (construct a counterexample or develop a different or simpler disproof or develop a general algorithm that solves DEs efficiently, etc.) the solution/disproof of David Hilbert’s Tenth Problem for inspiration and for purpose of learning/research. And good luck!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/85fec62161e04c2ae3b028b5eccf6ff083ede62b26d23968a23e4789869f23bf-0ca208eb6faafa70367604d809ad364a6359d20b904df7c950b7bf3d3c2fa5b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tony Carbery")]], [#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/#comment-517977")[#strong[#text("Tony Carbery")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2019")])]

#text("Ron Blei did a lot of work on fractional cartesian products in the mid-1970’s to the mid 1980’s. Is there a connection with his work?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/#comment-518004")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2019")])]

#text("Interesting (and I now remember that you actually had put this reference into our original paper and I had forgotten about it!). Looking at Blei’s work, it seems that he is focused on constructing fractal subsets of ambient Cartesian product spaces (such as ")#mi("{\\bf R}^d")#text(") which exhibit dimensional properties similar to that which one would expect a fractional Cartesian power to obey. The constructions here are more focused on the integration theory than the dimensional theory, but it could well be that when the exponent ")#mi("p")#text(" is a fraction ")#mi("p = n/m")#text(" then it is possible to find some more classical interpretation of these products, and of the fractional dimensional integral of symmetric functions, in a manner similar to what Blei does, and")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/#comment-517978")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2019")])]

#text("I haven’t done any calculations, but this is reminding me of Deligne’s tensor category of type A_n, n fractional. I’ll report back if it pans out.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of reader")]], [#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/#comment-517979")[#strong[#text("reader")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2019")])]

#text("What would we obtain if we were out for anti-symmetric functions in the first instance?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/#comment-518005")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2019")])]

#text("Hmm, interesting question. From a representation theory perspective, symmetric functions correspond to Young diagrams consisting of one row, whereas antisymmetric functions correspond to Young diagrams consisting of one column. In this post we are focusing on trying to extend to situations where the horizontal dimensions of the Young diagram are fractional (perhaps related to this previous post: ")#link("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/")[#text("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/")]#text(" , now that I think about it) but if one were to try to do the same for antisymmetric functions then one would now also want to consider Young diagrams whose vertical dimensions are fractional. Perhaps this could be done, but it may require a somewhat different formalism than what is done here.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68605af64a1e6fdd351a77f2433b7adf2f9cd04727474b417cc1c845066a5e94-d8bc53556dd92c4d890688ebd3b5209234ccd686c220700ce921962010131f65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sylvainjulien")]], [#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/#comment-517981")[#strong[#text("sylvainjulien")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2019")])]

#text("There must be a typo under your example 1, cause you define a quantity by setting it equal to itself.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f7f245429786040bab910d040af71dcd754ff66c0c1e02810caa2f67291c05b-60777bb901483cddaae165fe8145af6a6b1b99174a69ed17e7bedad40be7b46f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L")]], [#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/#comment-517995")[#strong[#text("L")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2019")])]

#text("@Allen_knutson Exactly what I was thinking. Etingoff’s work as well Representation theory in Complex dimension.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/#comment-517997")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2019")])]

#text("typo: The connection to ONE of these fractional dimensional integrals with more traditional integrals ultimately arises from the simple identity")

#emph[#text("[Reworded, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/#comment-518010")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2019")])]

#text("Is there a “natural” generalization of these concepts to the case of complex variables and complex valued functions?")#linebreak()#text(" Perhaps the concept of “symmetric function” should be replaced by a properly defined concept of “Hermitian complex valued function” ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24e4f0acbdcc91b2c7ba7aa365b93230645de6434c5bb00b576cb2e5b7b4b5d4-c613a49f867fec7449a638a997a449750baa68478c75c7b8283270fc50513284.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gpecc")]], [#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/#comment-518052")[#strong[#text("gpecc")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2019")])]

#text("The definition of ")#mi("[F^{(k)}]_{k\\rightarrow p}")#text(" is what in Probability/Statistics is called a “symmetric U-statistic” with kernel ")#mi("F^{(k)}")#text(", based on a sample of dimension ")#mi("p")#text(". U-statistics appear e.g. in parametric estimation, stochastic geometry, analysis of boolean functions, multiple stochastic integration, … It is intriguing to know that one can formally define symmetric U-statistics based on samples with fractional dimension…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/#comment-518067")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2019")])]

#text("Thanks for this link to existing terminology! (Though it seems that the symmetric U-statistic actually corresponds to a normalised average that in my notation would be ")#mi("\\binom{p}{k}^{-1} [F^{(k)}]_{k \\to p}")#text(".)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/14c1ac32236ec91f5540dbf15fb607359c459c37e85ab62e3889b14ea9932cf5-f307140c5efdb7307dae03aa821f2e195b3204bd9850191d76106afd0df8d0d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of p kothari")]], [#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/#comment-518253")[#strong[#text("p kothari")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2019")])]

#text("On random topic, what are your thoughts about What are your thoughts on analyzing Pauli–Lubanski pseudovector and spin number(information geometry) in NLP vectorized framework – doc2vec etc. to detect fake news?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/571589aae0f3286f5b3b319c54c4a52988eea7683328b3e632c8c8b2abff2da0-f765556fcce679c8f7603df2b917cb1ae08f65b5ae88a6a337aa437da0316d1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YY")]], [#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/#comment-518260")[#strong[#text("YY")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2019")])]

#text("How would he know?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sharp bounds for multilinear curved Kakeya, restriction and oscillatory integral estimates away from the endpoint | What's new")]], [#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/#comment-519030")[#strong[#text("Sharp bounds for multilinear curved Kakeya, restriction and oscillatory integral estimates away from the endpoint | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("[…] original proof of this proceeded using a heat flow monotonicity method, which in my previous post I reinterpreted using a “virtual integration” concept on a fractional Cartesian product […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ceece33fc0d7564904fa6a9fa6a9fc0d78f975f0eaaedfe652c8ecaf8fb4766a-78c02a557917a6b3221ab49ebbe56babbc5bf43af4fd38473688929c31c78919.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tt")]], [#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/#comment-520059")[#strong[#text("tt")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2019")])]

#text("typo: The integrand on the left-hand side of (5) is ")#mi("[x_1 x_2]_{2 \\to p}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/#comment-552881")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2020")])]

#text("This is highly reminiscent of Razborov’s theory of flag algebras for extremal combinatorics.")
]
