// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/
// Converted to Typst by tao2typ: "2026-10-14T10:26:27.624676+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 September 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/")[#text("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded two related papers to the arXiv:")

#list(
[#link("http://arxiv.org/abs/1509.05422")[#text("The logarithmically averaged Chowla and Elliott conjectures for two-point correlations")]#text(", submitted to ")#link("http://journals.cambridge.org/pi")[#text("Forum of Mathematics, Pi")]#text("; and")],
[#link("http://arxiv.org/abs/1509.05363")[#text("The Erdos discrepancy problem")]#text(", submitted to the new arXiv overlay journal, ")#link("https://submissions.scholasticahq.com/sites/discrete-analysis")[#text("Discrete Analysis")]#text(" (see this ")#link("https://gowers.wordpress.com/2015/09/10/discrete-analysis-an-arxiv-overlay-journal/")[#text("recent announcement")]#text(" on Tim Gowers’ blog).")]
)

#text("This pair of papers is an outgrowth of ")#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/")[#text("these two")]#text(" ")#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/")[#text("recent blog posts")]#text(" and the ensuing discussion. In the first paper, we establish the following logarithmically averaged version of the Chowla conjecture (in the case ")#mi("{k=2}")#text(" of two-point correlations (or “pair correlations”)):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Logarithmically averaged Chowla conjecture)")]#text(" ")#metadata(none) <tao-669cd16498cb442216f0>#text(" Let ")#mi("{a_1,a_2}")#text(" be natural numbers, and let ")#mi("{b_1,b_2}")#text(" be integers such that ")#mi("{a_1 b_2 - a_2 b_1 \\neq 0}")#text(". Let ")#mi("{1 \\leq \\omega(x) \\leq x}")#text(" be a quantity depending on ")#mi("{x}")#text(" that goes to infinity as ")#mi("{x \\rightarrow \\infty}")#text(". Let ")#mi("{\\lambda}")#text(" denote the Liouville function. Then one has ")#metadata(none) <tao-ed951f6e58c9ceff20ce>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{x/\\omega(x) < n \\leq x} \\frac{\\lambda(a_1 n + b_1) \\lambda(a_2 n+b_2)}{n} = o( \\log \\omega(x) )")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(".")
]

#text("Thus for instance one has ")#metadata(none) <tao-6dc7cb17a3f38ab8b715>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{n \\leq x} \\frac{\\lambda(n) \\lambda(n+1)}{n} = o(\\log x).")]]

#text("For comparison, the non-averaged Chowla conjecture would imply that ")#metadata(none) <tao-e5b564a7a4059dccb9c2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_{n \\leq x} \\lambda(n) \\lambda(n+1) = o(x)")]]

#text("which is a strictly stronger estimate than ")#link(<tao-6dc7cb17a3f38ab8b715>)[#text("(2)")]#text(", and remains open.")

#text("The arguments also extend to other completely multiplicative functions than the Liouville function. In particular, one obtains a slightly averaged version of the non-asymptotic Elliott conjecture that was shown in ")#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/")[#text("the previous blog post")]#text(" to imply a positive solution to the Erdos discrepancy problem. The averaged version of the conjecture established in this paper is slightly weaker than the one assumed in the previous blog post, but it turns out that the arguments there can be modified without much difficulty to accept this averaged Elliott conjecture as input. In particular, we obtain an unconditional solution to the Erdos discrepancy problem as a consequence; this is detailed in the second paper listed above. In fact we can also handle the vector-valued version of the Erdos discrepancy problem, in which the sequence ")#mi("{f(1), f(2), \\dots}")#text(" takes values in the unit sphere of an arbitrary Hilbert space, rather than in ")#mi("{\\{-1,+1\\}}")#text(".")

#text("Estimates such as ")#link(<tao-6dc7cb17a3f38ab8b715>)[#text("(2)")]#text(" or ")#link(<tao-e5b564a7a4059dccb9c2>)[#text("(3)")]#text(" are known to be subject to the “")#link("https://en.wikipedia.org/wiki/Parity_problem_(sieve_theory)")[#text("parity problem")]#text("” (discussed ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("numerous")]#text(" ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("times")]#text(" ")#link("https://terrytao.wordpress.com/2014/11/21/a-general-parity-problem-obstruction/")[#text("previously")]#text(" ")#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/")[#text("on")]#text(" ")#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/")[#text("this blog")]#text("), which roughly speaking means that they cannot be proven solely using “linear” estimates on functions such as the von Mangoldt function. However, it is known that the parity problem can be circumvented using “bilinear” estimates, and this is basically what is done here.")

#text("We now describe in informal terms the proof of Theorem ")#link(<tao-669cd16498cb442216f0>)[#text("1")]#text(", focusing on the model case ")#link(<tao-6dc7cb17a3f38ab8b715>)[#text("(2)")]#text(" for simplicity. Suppose for contradiction that the left-hand side of ")#link(<tao-6dc7cb17a3f38ab8b715>)[#text("(2)")]#text(" was large and (say) positive. Using the multiplicativity ")#mi("{\\lambda(pn) = -\\lambda(n)}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{\\lambda(n) \\lambda(n+p) 1_{p|n}}{n}")]]

#text("is also large and positive for all primes ")#mi("{p}")#text(" that are not too large; note here how the logarithmic averaging allows us to leave the constraint ")#mi("{n \\leq x}")#text(" unchanged. Summing in ")#mi("{p}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{ \\sum_{p \\in {\\mathcal P}} \\lambda(n) \\lambda(n+p) 1_{p|n}}{n}")]]

#text("is large and positive for any given set ")#mi("{{\\mathcal P}}")#text(" of medium-sized primes. By a standard averaging argument, this implies that ")#metadata(none) <tao-30cf5e953b01e70efce9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\frac{1}{H} \\sum_{j=1}^H \\sum_{p \\in {\\mathcal P}} \\lambda(n+j) \\lambda(n+p+j) 1_{p|n+j}")]]

#text("is large for many choices of ")#mi("{n}")#text(", where ")#mi("{H}")#text(" is a medium-sized parameter at our disposal to choose, and we take ")#mi("{{\\mathcal P}}")#text(" to be some set of primes that are somewhat smaller than ")#mi("{H}")#text(". (A similar approach was taken in ")#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/")[#text("this recent paper of Matomaki, Radziwill, and myself")]#text(" to study sign patterns of the Möbius function.) To obtain the required contradiction, one thus wants to demonstrate significant cancellation in the expression ")#link(<tao-30cf5e953b01e70efce9>)[#text("(4)")]#text(". As in that paper, we view ")#mi("{n}")#text(" as a random variable, in which case ")#link(<tao-30cf5e953b01e70efce9>)[#text("(4)")]#text(" is essentially a bilinear sum of the random sequence ")#mi("{(\\lambda(n+1),\\dots,\\lambda(n+H))}")#text(" along a random graph ")#mi("{G_{n,H}}")#text(" on ")#mi("{\\{1,\\dots,H\\}}")#text(", in which two vertices ")#mi("{j, j+p}")#text(" are connected if they differ by a prime ")#mi("{p}")#text(" in ")#mi("{{\\mathcal P}}")#text(" that divides ")#mi("{n+j}")#text(". A key difficulty in controlling this sum is that for randomly chosen ")#mi("{n}")#text(", the sequence ")#mi("{(\\lambda(n+1),\\dots,\\lambda(n+H))}")#text(" and the graph ")#mi("{G_{n,H}}")#text(" need not be independent. To get around this obstacle we introduce a new argument which we call the “entropy decrement argument” (in analogy with the “density increment argument” and “energy increment argument” that appear in the literature surrounding Szemerédi’s theorem on arithmetic progressions, and also reminiscent of the “entropy compression argument” of Moser and Tardos, discussed in ")#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/")[#text("this previous post")]#text("). This argument, which is a simple consequence of the ")#link("https://en.wikipedia.org/wiki/Inequalities_in_information_theory#Shannon-type_inequalities")[#text("Shannon entropy inequalities")]#text(", can be viewed as a quantitative version of the standard subadditivity argument that establishes the existence of ")#link("https://en.wikipedia.org/wiki/Measure-preserving_dynamical_system#Measure-theoretic_entropy")[#text("Kolmogorov-Sinai entropy")]#text(" in topological dynamical systems; it allows one to select a scale parameter ")#mi("{H}")#text(" (in some suitable range ")#mi("{[H_-,H_+]}")#text(") for which the sequence ")#mi("{(\\lambda(n+1),\\dots,\\lambda(n+H))}")#text(" and the graph ")#mi("{G_{n,H}}")#text(" exhibit some weak independence properties (or more precisely, the ")#link("https://en.wikipedia.org/wiki/Mutual_information")[#text("mutual information")]#text(" between the two random variables is small).")

#text("Informally, the entropy decrement argument goes like this: if the sequence ")#mi("{(\\lambda(n+1),\\dots,\\lambda(n+H))}")#text(" has significant mutual information with ")#mi("{G_{n,H}}")#text(", then the entropy of the sequence ")#mi("{(\\lambda(n+1),\\dots,\\lambda(n+H^{\\prime}))}")#text(" for ")#mi("{H^{\\prime} > H}")#text(" will grow a little slower than linearly, due to the fact that the graph ")#mi("{G_{n,H}}")#text(" has zero entropy (knowledge of ")#mi("{G_{n,H}}")#text(" more or less completely determines the shifts ")#mi("{G_{n+kH,H}}")#text(" of the graph); this can be formalised using the classical ")#link("https://en.wikipedia.org/wiki/Inequalities_in_information_theory#Shannon-type_inequalities")[#text("Shannon inequalities for entropy")]#text(" (and specifically, the non-negativity of ")#link("https://en.wikipedia.org/wiki/Conditional_mutual_information")[#text("conditional mutual information")]#text("). But the entropy cannot drop below zero, so by increasing ")#mi("{H}")#text(" as necessary, at some point one must reach a metastable region (cf. the finite convergence principle discussed in ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("this previous blog post")]#text("), within which very little mutual information can be shared between the sequence ")#mi("{(\\lambda(n+1),\\dots,\\lambda(n+H))}")#text(" and the graph ")#mi("{G_{n,H}}")#text(". Curiously, for the application it is not enough to have a purely quantitative version of this argument; one needs a quantitative bound (which gains a factor of a bit more than ")#mi("{\\log H}")#text(" on the trivial bound for mutual information), and this is surprisingly delicate (it ultimately comes down to the fact that the series ")#mi("{\\sum_{j \\geq 2} \\frac{1}{j \\log j \\log\\log j}}")#text(" diverges, which is only barely true).")

#text("Once one locates a scale ")#mi("{H}")#text(" with the low mutual information property, one can use standard concentration of measure results such as the ")#link("https://en.wikipedia.org/wiki/Hoeffding%27s_inequality")[#text("Hoeffding inequality")]#text(" to approximate ")#link(<tao-30cf5e953b01e70efce9>)[#text("(4)")]#text(" by the significantly simpler expression ")#metadata(none) <tao-639097e715e88be050d0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\frac{1}{H} \\sum_{j=1}^H \\sum_{p \\in {\\mathcal P}} \\frac{\\lambda(n+j) \\lambda(n+p+j)}{p}.")]]

#text("The important thing here is that Hoeffding’s inequality gives exponentially strong bounds on the failure probability, which is needed to counteract the logarithms that are inevitably present whenever trying to use entropy inequalities. The expression ")#link(<tao-639097e715e88be050d0>)[#text("(5)")]#text(" can then be controlled in turn by an application of the ")#link("https://en.wikipedia.org/wiki/Hardy%E2%80%93Littlewood_circle_method")[#text("Hardy-Littlewood circle method")]#text(" and a non-trivial estimate ")#metadata(none) <tao-8e461a3a3256d308d9ba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sup_\\alpha \\frac{1}{X} \\int_X^{2X} |\\frac{1}{H} \\sum_{x \\leq n \\leq x+H} \\lambda(n) e(\\alpha n)|\\ dx = o(1)")]]

#text("for averaged short sums of a modulated Liouville function established in ")#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/")[#text("another recent paper by Matomäki, Radziwill and myself")]#text(".")

#text("When one uses this method to study more general sums such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{g_1(n) g_2(n+1)}{n},")]]

#text("one ends up having to consider expressions such as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{H} \\sum_{j=1}^H \\sum_{p \\in {\\mathcal P}} c_p \\frac{g_1(n+j) g_2(n+p+j)}{p}.")]]

#text("where ")#mi("{c_p}")#text(" is the coefficient ")#mi("{c_p := \\overline{g_1}(p) \\overline{g_2}(p)}")#text(". When attacking this sum with the circle method, one soon finds oneself in the situation of wanting to locate the large Fourier coefficients of the exponential sum")

#align(center)[#tao-fit-display[#mitex("S(\\alpha) := \\sum_{p \\in {\\mathcal P}} \\frac{c_p}{p} e^{2\\pi i \\alpha p}.")]]

#text("In many cases (such as in the application to the Erdös discrepancy problem), the coefficient ")#mi("{c_p}")#text(" is identically ")#mi("{1}")#text(", and one can understand this sum satisfactorily using the classical results of Vinogradov: basically, ")#mi("{S(\\alpha)}")#text(" is large when ")#mi("{\\alpha}")#text(" lies in a “major arc” and is small when it lies in a “minor arc”. For more general functions ")#mi("{g_1,g_2}")#text(", the coefficients ")#mi("{c_p}")#text(" are more or less arbitrary; the large values of ")#mi("{S(\\alpha)}")#text(" are no longer confined to the major arc case. Fortunately, even in this general situation one can use a restriction theorem for the primes established some time ago ")#link("http://www.ams.org/mathscinet-getitem?mr=2245880")[#text("by Ben Green and myself")]#text(" to show that there are still only a bounded number of possible locations ")#mi("{\\alpha}")#text(" (up to the uncertainty mandated by the Heisenberg uncertainty principle) where ")#mi("{S(\\alpha)}")#text(" is large, and we can still conclude by using ")#link(<tao-8e461a3a3256d308d9ba>)[#text("(6)")]#text(". (Actually, as recently pointed out to me by Ben, one does not need the full strength of our result; one only needs the ")#mi("{L^4}")#text(" restriction theorem for the primes, which can be proven fairly directly using Plancherel’s theorem and some sieve theory.)")

#text("It is tempting to also use the method to attack higher order cases of the (logarithmically) averaged Chowla conjecture, for instance one could try to prove the estimate")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{\\lambda(n) \\lambda(n+1) \\lambda(n+2)}{n} = o(\\log x).")]]

#text("The above arguments reduce matters to obtaining some non-trivial cancellation for sums of the form")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{H} \\sum_{j=1}^H \\sum_{p \\in {\\mathcal P}} \\frac{\\lambda(n+j) \\lambda(n+p+j) \\lambda(n+2p+j)}{p}.")]]

#text("A little bit of “higher order Fourier analysis” (as was done for very similar sums in the ergodic theory context by ")#link("http://www.ams.org/mathscinet-getitem?mr=2361086")[#text("Frantzikinakis-Host-Kra")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2999293")[#text("Wooley-Ziegler")]#text(") lets one control this sort of sum if one can establish a bound of the form ")#metadata(none) <tao-bcb9dae6ea88dbf28c26>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\frac{1}{X} \\int_X^{2X} \\sup_\\alpha \\left|\\frac{1}{H} \\sum_{x \\leq n \\leq x+H} \\lambda(n) e(\\alpha n)\\right|\\ dx = o(1)", block: true)]]

#text("where ")#mi("{X}")#text(" goes to infinity and ")#mi("{H}")#text(" is a very slowly growing function of ")#mi("{X}")#text(". This looks very similar to ")#link(<tao-8e461a3a3256d308d9ba>)[#text("(6)")]#text(", but the fact that the supremum is now inside the integral makes the problem much more difficult. However it looks worth attacking ")#link(<tao-bcb9dae6ea88dbf28c26>)[#text("(7)")]#text(" further, as this estimate looks like it should have many nice applications (beyond just the ")#mi("{k=3}")#text(" case of the logarithmically averaged Chowla or Elliott conjectures, which is already interesting).")

#text("For higher ")#mi("{k}")#text(" than ")#mi("{k=3}")#text(", the same line of analysis requires one to replace the linear phase ")#mi("{e(\\alpha n)}")#text(" by more complicated phases, such as quadratic phases ")#mi("{e(\\alpha n^2 + \\beta n)}")#text(" or even ")#mi("{k-2}")#text("-step nilsequences. Given that ")#link(<tao-bcb9dae6ea88dbf28c26>)[#text("(7)")]#text(" is already beyond the reach of current literature, these even more complicated expressions are also unavailable at present, but one can imagine that they will eventually become tractable, in which case we would obtain an averaged form of the Chowla conjecture for all ")#mi("{k}")#text(", which would have a number of consequences (such as a logarithmically averaged version of ")#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/")[#text("Sarnak’s conjecture")]#text(", as per this blog post).")

#text("It would of course be very nice to remove the logarithmic averaging, and be able to establish bounds such as ")#link(<tao-e5b564a7a4059dccb9c2>)[#text("(3)")]#text(". I did attempt to do so, but I do not see a way to use the entropy decrement argument in a manner that does not require some sort of averaging of logarithmic type, as it requires one to pick a scale ")#mi("{H}")#text(" that one cannot specify in advance, which is not a problem for logarithmic averages (which are quite stable with respect to dilations) but is problematic for ordinary averages. But perhaps the problem can be circumvented by some clever modification of the argument. One possible approach would be to start exploiting multiplicativity at products of primes, and not just individual primes, to try to keep the scale fixed, but this makes the concentration of measure part of the argument much more complicated as one loses some independence properties (coming from the Chinese remainder theorem) which allowed one to conclude just from the Hoeffding inequality.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (77)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459443")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2015")])]

#text("In the first paper (page 26) it seems that the integrand in (4.1) is different from the integrand in (7) above (perhaps the arguments of both ")#mi("\\lambda(.)")#text(" and ")#mi("e(.)")#text(" in (4.1) should be corrected according to the shift ")#mi("n=x+j")#text(" in the summation variables.)")

#emph[#text("[There is a typo in (4.1) which will be corrected in the next revision – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459454")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2015")])]

#text("Is ")#mi("\\sup_{\\alpha}")#text(" in (6), (7) over all real ")#mi("\\alpha")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77e88642182093deb6a5b1c88efb8b23287678d9cee8dcf598e62bf1efbc2ae4-d171b5204377dd1866efcec977afdeb8a3f959201d82a56ff5fb504206643d4a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459460")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2015")])]

#text("Yes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d9e338e0cd3c5854d68f121b5bf4dd9161377bdb81e3cdc27ffbef30ef3227b-78ebb2d5d5bd8641134d35ec8cda100165b35ec3350266a25bb780abe9cd2e13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459455")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2015")])]

#text("@TerryTao It was very hard to program the Möbius function for a large range of N. I could find the primes up to a billion within a reasonable time of 1 minute. Writing the algorithm took several attempts. Indeed, I was able to compute the Mertens function after catching a serious error.")

#text("I do not have any specific interest in prime number theory. However, Möbius pseudorandomness is a bottleneck to any asymptotic discussion of integers. Sometimes, when I least expect it.")

#text("I am weary of Hardy’s layering of notation and am not sure how to interpret symbols like ")#mi("\\log \\log \\log x")#text(" and ")#mi("\\ll")#text(". The computer has been a helpful tool in following along.")

#text("These subtleties I attribute to the complexity class of the set of primes, which share aspects of random sets. Yet primes are not totally random, e.g. quadratic reciprocity, Fermat’s little Theorem, etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4e5b01b0b7059dae1bd459fad4308185c02c0a62ae1b6208aa380e21578a7e6-fb63ef724dcdc531a24e4646f2d9f657a00ee485b6bcd21899fd2b3a6ff79306.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antonio")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459457")[#strong[#text("Antonio")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2015")])]

#text("offtopic: I love the image of the tree in your blog, Dr Terrence Tao, where can i get it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a830450fdc42640734c399aefa8d8f69203b5cf003a6fb3d85c05a81a6dcced-6aa92d6fbc6161814fa75065d6b8ebec555852a948f8c3d0155ac32fac6aeb95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459459")[#strong[#text("Joseph")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2015")])]

#text("I was confused by a little point of the proof in the paper “The Erdös discrepency problem”, where the first inequality p. 11 is used to apply the contrapositive of Theorem 1.8. Indeed, the lower bound given is 1 and the bound needed to apply Theorem 1.8 seems to be ")#mi("\\epsilon log \\sqrt{X}")#text(". I think one can instead replace the bound ")#mi("1")#text(" by ")#mi("\\log X/H")#text(" which then allows to apply Theorem 1.8 (with a different value of ")#mi("\\epsilon")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/584cd02f839ef6f42551e80d351f9a4a15cb388eea2c96194a9925dcd6248b8b-d4a31d6f5ab8c8b59637f67c32594b522a6199cfd232e67ffe727dace4462076.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459464")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2015")])]

#text("I agree. I just made a similar comment in the previous blog post, I should have made it here. See ")#link("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459463")[#text("https://terrytao.wordpress.com/2015/09/11/the-erdos-discrepancy-problem-via-the-elliott-conjecture/#comment-459463")]

#emph[#text("[Yes, this correction works, and will be implemented in the next revision of the ms, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459467")[#strong[#text("Updates and plans III. | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2015")]

#text("[…] The number theory works by Tao with Matomaki and Radzwill play important role in the proof. See this blog post with links to two new relevant […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459468")[#strong[#text("Polymath5 – Is 2 logarithmic in 1124? | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2015")]

#text("[…] Erdos discrepancy problem and proved that indeed the discrepancy tends to infinity. See also this blog post on Tao’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459479")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2015")])]

#text("In the paper on Chowla’s conjecture reference [16] is never referenced to in the body of the paper, but listed in the bibliography!")

#emph[#text("[The estimates we use in [17] are heavily based on those in [16]; I’ll add a mention of this in the next revision of the ms. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459483")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2015")])]

#text("Is it possible (with the current methods) to “interpolate” between (2) and (3) by using the multiplicative weight function ")#mi("n^c")#text(" for some exponent ")#mi("c>-1")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459484")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2015")])]

#text("If one uses a quantitative version of the arguments in the paper, one might be able to shave some iterated logarithms off of the ")#mi("\\frac{1}{n}")#text(" weight (e.g. to something like ")#mi("\\frac{\\log\\log\\log\\log n}{n}")#text(") but it is unlikely that one can get as far as ")#mi("\\frac{1}{n^c}")#text(" without some dramatic quantitative improvements in the bounds.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459485")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2015")])]

#text("Congratulations Terry. (Even I can appreciate that any solution to an unsolved conjecture whose statement can be easily explained to a layperson, is pretty significant).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459488")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2015")])]

#text("What is the probabilistic prediction for the true size of the RHS of (7)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459489")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2015")])]

#text("I would expect this expression to be of size ")#mi("O(H^{-1/2+o(1)})")#text(" (the usual square root cancellation, with some logarithmic correction to handle the supremum), if X is large enough depending on H.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459498")[#strong[#text("EDP28 — problem solved by Terence Tao! | Gowers's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2015")]

#text("[…] posts, a first that shows how to reduce the problem to the Elliott conjecture in number theory, and a second that shows (i) that an averaged form of the conjecture is sufficient and (ii) that he can prove the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Entropy and rare events | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459503")[#strong[#text("Entropy and rare events | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2015")])]

#text("[…] is close to in the sense that , otherwise the bound is worse than the trivial bound of . In my recent paper on the Chowla and Elliott conjectures, I ended up using a variant of (2) which was still non-trivial when the entropy was allowed to be […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459524")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2015")])]

#text("If I remember correctly, one difficulty in EDP was that it does not generally hold “on average,” namely that for a multiplicative function (say) the average absolute value of partial sums can be bounded. Is it the case that unless g “pretends” to be a modulated Dirichlet character EDP actually does hold on average?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459544")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2015")])]

#text("Dear Gil,")

#text("Offhand I can’t think of an example (pretentious or not) in which the average absolute value of the partial sums are bounded. If ")#mi("g")#text(" does not pretend to be a modulated Dirichlet character then the results in my Elliott conjecture basically say that ")#mi("g(n)")#text(" and ")#mi("g(n+h)")#text(" are uncorrelated for random large n and medium-sized h, which by the second moment method implies that ")#tao-math("\\left|\\sum_{n < j \\leq n+H} g(j)\\right|", block: false)#text(" is large on average, which by the triangle inequality in the contrapositive implies that ")#tao-math("\\left|\\sum_{j \\leq n} g(j)\\right|", block: false)#text(" is large on average. In fact it is quite possible that one has a uniform lower bound on ")#tao-math("\\frac{1}{N} \\sum_{n \\leq N} \\left|\\sum_{j \\leq n} g(j)\\right|^2", block: false)#text(" that goes to infinity as ")#mi("N \\to \\infty")#text(" for all completely multiplicative ")#mi("g: {\\bf N} \\to S^1")#text(" by some refinement of the argument in the paper (this was in fact the original formulation of the \"Fourier reduction\" of Polymath5).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459573")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2015")])]

#text("(I am not sure either now about the average statement. Quite possibly I was already confused about it at the polymath5 time.)")

#text("One idea from early polymath5 was this. Once it was proved that EDP is correct for multiplicative functions that have positive correlation with a Direchlet character, perhaps for functions with vanishing correlation with every Direchlet character something even stronger is correct. (I think the term “pretentious” was not used back then.)")

#text("One such potential statement is this:")

#text("(*) let f be a multiplicative function from 1,2,…,n with values in [-1,1] or the entire unit disc. Then the discrepancy of f is lower bounded by a function tending to infinity times the ell-2 norm of f. (normalized so that if all values are unir vectors then the l-2 norm is 1.)")

#text("(*) is not true in general (which is perhaps one reason why EDP is hard) but maybe it is true (and perhaps follows from the new developments) whenever f has vanishing correlation with every Direchlet character.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459586")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2015")])]

#text("Nice question! It looks like the van der Corput argument in the Erdos paper does indeed show that for any multiplicative function f taking values in the unit disk, and not pretending to be a modulated Dirichlet character, the discrepancy will be large if the l^2 norm is large (in that one has ")#tao-math("\\left|f(n)\\right| \\gg 1", block: false)#text(" for a positive proportion of the n). I’m not sure if one can hope for a linear relationship between the discrepancy and the l^2 norm, though.")

#text("Related to this, it turns out that the Fourier reduction step also works if one assumes ")#tao-math("\\left|f(n)\\right| \\geq 1", block: false)#text(" rather than ")#tao-math("\\left|f(n)\\right|=1", block: false)#text(". Thus the EDP can be solved for any sequence avoiding the unit interval (or unit disk), not just +1/-1 sequences (or sequences on the unit circle). This is perhaps not too surprising – larger sequences should intuitively have larger discrepancy. I’ll add these remarks to the next revision of the manuscript.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459643")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2015")])]

#text("That’s interesting! Lets consider finite n’s. It also seems that the weaker version (**) that you indicate (discrepancy bounded by a function of the ell-2 norm of f) holds when f does not correlate just with Direchlet characters that correspond to primes q which are bounded (and not tend to infinity with n).")

#text("I.e. if f does not correlate with Direchlet characters corresponding to primes <= q then the discrepancy is bounded below by a function depending on (n,q) of the ell-2 norm of f (perhaps even a function of n and q times the ell-2 norm of f), and this function tends to infinity whenever n and q tends to infinity.")

#text("(Maybe its obviously equivalent to what you say though.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459546")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2015")])]

#text("Since the inner sum in the integrand of (7) (as a trigonometric polynomial) has unit period in ")#mi("\\alpha")#text(" (for fixed ")#mi("x , H")#text("), ")#mi("\\alpha")#text(" (as well as the supremum) may be restricted to ")#mi("[0, 1)")#text(".")#linebreak()#text(" Moreover, if H is a fixed integer, the set of integers ")#mi("n")#text(" in ")#mi("[x, x+H]")#text(" (as a function of x) is fixed as long as the variable x does not cross an integer. Therefore the inner sum (as well as the supremum) is fixed(!) as long as ")#mi("x")#text(" is not crossing an integer. So the supremum (as a function of ")#mi("x")#text(") is in fact constant between integer values of ")#mi("x")#text(".")#linebreak()#text(" Hence for integer ")#mi("X")#text(", the integral in (7) is in fact a finite sum!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459805")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2015")])]

#text("In fact, ")#mi("\\alpha")#text(" in (7) can be further restricted to ")#mi("[0, 1/2]")#text(" by")#linebreak()#text(" (i) restricting it to ")#mi("[-1/2, 1/2]")#text(" (using the unit periodicity in ")#mi("\\alpha")#text(") and than (ii) using the fact that changing ")#mi("\\alpha")#text(" to ")#mi("-\\alpha")#text(" is merely equivalent to taking the conjugate value of the sum inside the integrand – without changing its absolute value! (so ")#mi("\\alpha")#text(" can be further restricted to ")#mi("[0, 1/2]")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4ad6c18186ffa1aab4aadbb6437ddfdfd03ffdb28fa7b75fb5a4b74dadd060d-b17876bb6ed44b4eb4e6f409d6e9c2e04bf2fd6789fad7fda897a642de72445e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Erdős discrepancy problem has been solved by Tao | The polymath blog")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459582")[#strong[#text("The Erdős discrepancy problem has been solved by Tao | The polymath blog")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2015")])]

#text("[…] has now been solved by Terry Tao using important recent developments in analytic number theory. See this blog post from Tao’s blog and this concluding blog post from Gowers’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459620")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2015")])]

#text("In the sum below (6), it seems that the denominator should be ")#mi("n")#text(" (instead of ")#mi("x")#text(").")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cefc075ba8b78b94f7172ed8253ecb81510fa34f735b72ca65d084415d58698-59e1053277d9329365e3b62fbf44714901655e504d808b003efd60f90cab2e27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KWRegan")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459635")[#strong[#text("KWRegan")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2015")])]

#text("There is a more immediate typo in the first box in the post, Theorem (1): at the bottom “as n \\to \\infty” should be “as x \\to \\infty”. It is correctly “x” in the opening lines of the first paper. [Dick Lipton and I are finishing a post on this, our congratulations!]")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459652")[#strong[#text("Frogs and Lily Pads and Discrepancy | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2015")]

#text("[…] from discussion of his two earlier posts this month on his blog. They and his 9/18 announcement post re-create much of the content of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459672")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2015")])]

#text("Can theorem 1 be extended to include the case of bounded ")#mi("\\omega(x)")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459695")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2015")])]

#text("I would very much like to extend the theorem in this fashion, as this should recover the original Chowla conjecture in the k=2 case; unfortunately, the arguments I have rely on having a sufficient amount of logarithmic averaging, which forces the assumption that ")#mi("\\omega(x)")#text(" goes to infinity. As discussed in previous posts, it is not completely hopeless to try to remove the log averaging (broadly speaking, it requires one to prove expansion properties of a certain random graph, as opposed to using the entropy decrement argument to finesse the need to establish expansion) but I don’t see how to achieve it right now.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459747")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2015")])]

#text("Is it possible to prove (7) for a sufficiently restricted class of functions ")#mi("H = H(X)")#text(" under the restriction ")#mi("H_1(X) \\leq H(X) \\leq H_2(X)")#text(" for some (appropriately chosen) functions ")#mi("H_1(X), H_2(X)")#text(" which still enable some applications of (7)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459766")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2015")])]

#text("Using an estimate of Davenport, one can prove (7) in the range ")#mi("X \\log^{-A} X \\leq H \\leq X")#text(" for any fixed ")#mi("A")#text(". There ought to be a decent chance of extending this range to ")#mi("X^{1-c} \\leq H \\leq X")#text(" for some absolute constant ")#mi("c>0")#text(", and this would be a good warmup problem for proving (7) in full generality, though it seems like there is a significant jump in difficulty past the square root barrier ")#mi("c= 1/2")#text(". This may lead to some other applications than Chowla (e.g. asymptotics for counting narrow 3-term progressions or similar patterns in the primes), and indeed I believe some people were already looking at (7) in ranges like this for this sort of applications.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37fb63c95b2e31cb179dce5756224f00122390e333dd234b3cdd32f65b469f33-5d81ad6fa0d97b32905b66432b52bb9401db9e4a0b584031e53ad73fdf357ca8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cristóbal Camarero")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459794")[#strong[#text("Cristóbal Camarero")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2015")])]

#text("About the sequence in the paper in Remark 1.13 defined by f(jD!+k)=(-1)^jf(k). I think the elements 15 to 18 are wrong and they are -1,1,1,-1 instead. Also, you might add it to the OEIS; it seems pretty and useful.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms, and I’ll add the sequence to the OEIS. -T]")]#emph[]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459847")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2015")])]

#text("This sequence is now at ")#link("https://oeis.org/A262725")[#text("https://oeis.org/A262725")]#text(" . (Unfortunately I made a data entry for the a(25)-a(48) block, but I have submitted a correction.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459839")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2015")])]

#text("Straight from “The Book”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 0: Foundations of probability theory | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459860")[#strong[#text("275A, Notes 0: Foundations of probability theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2015")])]

#text("[…] my research (for instance, the probabilistic concept of Shannon entropy played a crucial role in my recent paper on the Chowla and Elliott conjectures, and random multiplicative functions similarly played a central role in the paper on the Erdos […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459874")[#strong[#text("Epsilon - Ocasapiens - Blog - Repubblica.it")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2015")]

#text("[…] superare la peer-review, ma ha pubblicato tutto sul suo blog (c'è una seconda parte), quindi la peer-review è stata collettiva e […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459923")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2015")])]

#text("Is there some known generalization of the recent results on short averages of ")#mi("\\lambda(n)")#text(" for consecutive integers ")#mi("n")#text(" in ")#mi("[x, x+H]")#text(" to the case of arithmetical progressions of ")#mi("n")#text(" in ")#mi("[x, x+H]")#text(" ?")#linebreak()#text(" Also, is there any restriction (in terms of ")#mi("x, H")#text(") on the size of the gaps ")#mi("D")#text(" of the arithmetical progressions ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459927")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2015")])]

#text("This is a good question! For bounded values of D (and for H large compared to D) one can derive such results from the existing Matomaki-Radziwill theory by expanding into Dirichlet characters and applying MR to the twisted Liouville functions ")#mi("\\lambda \\chi")#text(" separately (we did this to handle major arcs in our averaged Chowla paper). But this gets inefficient when D is moderately large. Presumably there should be some “q-aspect” version of MR’s work in which one averages both over Archimedean intervals ")#mi("[x,x+H]")#text(" and over characters of a given conductor (or up to a given conductor) that gives better results (particularly if one avoids Siegel zeroes somehow). In principle, many of the ingredients in MR (e.g. mean value theorems) have q-aspect generalisations, but as far as I know nobody has pushed the whole argument through to this setting. (It’s a worthwhile thing to think about though. One could perhaps start with the ")#mi("H = x^\\varepsilon")#text(" case which is easier, see ")#link("http://arxiv.org/abs/1502.02374")[#text("http://arxiv.org/abs/1502.02374")]#text(" .)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459936")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2015")])]

#text("Thanks for the detailed answer!")#linebreak()#text(" My motivation for this question was to check the possibility of proving a slightly stronger version (7′) of (7), namely that the integrand of (7) itself is ")#mi("o(1)")#text(" (i.e. without the outer averaging!) via the following simple approach:")

#text("1. Denote by ")#mi("S(\\alpha)")#text(" the integrand of (6). Clearly")

#mi("S(\\alpha) = S(\\alpha^{\\prime})  + o(1)")

#text("whenever ")#mi("\\alpha = \\alpha^{\\prime} + o(1/(x+H))")#text(" for any real ")#mi("\\alpha, \\alpha^{\\prime}")#text(".")

#text("Therefore, if ")#mi("\\alpha")#text(" is approximated by rational ")#mi("\\alpha^{\\prime}")#text(" with approximation error ")#mi("o(1/X)")#text(", (which is always possible if ")#mi("\\alpha^{\\prime}")#text(" has denominator ")#mi("D=O(X^c)")#text(" for any fixed ")#mi("c > 1/2")#text("), one needs only to verify (7′) for a finite(!) set of rational ")#mi("\\alpha^{\\prime}")#text(" with denominators ")#mi("D = O(X^c)")#text(" with fixed ")#mi("c > 1/2")#text(".")

#text("2. For such rational approximation ")#mi("\\alpha^{\\prime}")#text(" with denominator ")#mi("D")#text(", let ")#mi("\\xi := e(\\alpha^{\\prime})")#text(" be the corresponding primitive D-th root of unity. The inner sum in (7) is")

#mi("\\sum_{n \\in [x, x+H]} \\lambda(n) \\xi^n")

#text("Using the fact that the absolute value of the above sum is equal to the absolute value of a polynomial in ")#mi("\\xi")#text(" of degree ")#mi("D-1")#text(" (since ")#mi("\\xi")#text(" is a primitive root of unity of order ")#mi("D")#text(") whose ")#mi("D")#text(" coefficients are the sums of ")#mi("\\lambda(n)")#text(" over the ")#mi("D")#text(" classes mod ")#mi("D")#text(" (i.e. ")#mi("D")#text(" arithmetic progressions with gap ")#mi("D")#text(") of integers ")#mi("n")#text(" in ")#mi("[x, x+H]")#text(", it follows that if ")#mi("D = o(H)")#text(" then under the generalization of the short averages of ")#mi("\\lambda(n)")#text(" over arithmetic progressions in ")#mi("[x,x+H]")#text(", the ")#mi("D")#text(" coefficients of the above polynomial should be ")#mi("o(H/D)")#text(" (as being sums of ")#mi("\\lambda(n)")#text(" over arithmetic progressions of lengths ")#mi("H/D +O(1)")#text(") – therefore the integrand of (7) (after dividing the absolute value of the above polynomial in ")#mi("\\xi")#text(" by H) should be ")#mi("o(1)")#text(" – i.e. (7′).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459971")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2015")])]

#text("I just realized that in the approximation step (first step in my above comment) the condition")

#mi("\\alpha = \\alpha^{\\prime} + o(1/(x+H))")#text(" (for ")#mi("S(\\alpha) = S(\\alpha^{\\prime}) + o(1)")#text(") can be relaxed to")

#mi("\\alpha = \\alpha^{\\prime} + o(1/H)")

#text("(i.e. it is dependent only on the length ")#mi("H")#text(" of the interval ")#mi("[x, x+H]")#text(").")

#text("This follows from")

#tao-math("S(\\alpha)  := H^{-1}\\left|\\sum_{n \\in [x, x+H]} \\lambda(n) e(\\alpha n)\\right|", block: false)

#mi("= H^{-1}|\\sum_{n \\in [x, x+H]} \\lambda(n) e(\\alpha (n-x))!")

#text("Which implies that ")#mi("S(\\alpha^{\\prime}) = S(\\alpha) + o(1)")#text(" whenever")#linebreak()#text(" ")#mi("\\alpha (n-x) = \\alpha^{\\prime} (n-x) + o(1)")#text(" for all ")#mi("n \\in [x, x+H]")#text(" – which clearly follows from ")#mi("\\alpha = \\alpha^{\\prime} +o(1/H)")

#text("(note that this relaxed condition follows from the need to approximate only(!) the absolute value of the inner sum in (7) – which enable to rotate the sum by multiplying it by ")#mi("e(- \\alpha x)")#text(" before comparing it to the rotated version of the sum corresponding to ")#mi("\\alpha^{\\prime}")#text(").")

#text("Therefore, this relaxed approximation for any real ")#mi("\\alpha")#text(" by a rational ")#mi("\\alpha^{\\prime}")#text(" with denominator ")#mi("D")#text(" is possible under the condition ")#mi("D^-2 = o(1/H)")#text(" (i.e. ")#mi("H = o(D^2)")#text(").")#linebreak()#text(" This shows that the approximation step of ")#mi("\\alpha")#text(" by rational ")#mi("\\alpha^{\\prime}")#text(" with denominator ")#mi("D = O(X^c)")#text(" and ")#mi("H = X^{\\delta}")#text(" is possible whenever ")#mi("c > \\delta /2 > 0")#text(" (relaxing the former condition ")#mi("c > 1/2")#text("). One should also add the condition ")#mi("D = o(H)")#text(" (needed in the second step of estimating ")#mi("S(\\alpha^{\\prime})")#text(" in the above comment) which gives the relaxed constraints")

#mi("0 < \\delta /2 < c < \\delta \\leq 1")

#text("where ")#mi("H = X^{\\delta}")#text(" and ")#mi("D = O(X^c)")#text(" for this approach to prove (7').")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-460061")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("In MR paper “Multiplicative functions in short intervals”, the exceptional set of ")#mi("x")#text(" values in ")#mi("[X, 2X]")#text(" in theorem 1 seems (by construction) to be independent (!) of the multiplicative function ")#mi("f")#text(" (but still may depend on ")#mi("X, h")#text(") – is this true?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-460063")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("Not quite. They do identify a universal set S of “typical” numbers, independent of f, on which they obtain better estimates (Theorem 3), but within that typical set there can still be an f-dependent set of “bad” x.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/05ee76f48e9fa8e8b603d5e9a4f66cd75a718b8c8f47f220c48e0d2786526678-be627ce02e89d39b6f8c62c8efb97754edca2b070170dd0f31f5afa700803bc6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miles")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459937")[#strong[#text("Miles")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2015")])]

#text("I’m curious where one would look to prove this in the specific case of f(x) = sgn(sin(1/x))? (that the discrepancy of this function is infinite)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459946")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2015")])]

#text("If ")#tao-math("\\left|x\\right| > 1/ \\pi", block: false)#text(" then ")#mi("1/x \\in (-\\pi, \\pi)")#text(" and therefore ")#mi("f(x) = sgn(x)")#text(". In particular, ")#mi("f(x) = 1")#text(" for each positive integer ")#mi("x")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/05ee76f48e9fa8e8b603d5e9a4f66cd75a718b8c8f47f220c48e0d2786526678-be627ce02e89d39b6f8c62c8efb97754edca2b070170dd0f31f5afa700803bc6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miles")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-459955")[#strong[#text("Miles")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2015")])]

#text("Thanks! Although I must apologize – I meant to define a function with increasingly large, but not infinite, sections of constant sign. I was instead maybe thinking of a function like ")#mi("f(x) = \\text{sgn}(\\sin(\\frac{1}{\\sqrt{x+1}-\\sqrt{x}}))")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MatjazG")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-460288")[#strong[#text("MatjazG")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2015")])]

#text("This case of sections of constant sign with unbounded lengths is quite easy. It suffices to take ")#mi("d = 1")#text(" in the discrepancy sum, i.e. to only look at partial sums: ")#mi("S_m = \\sum_{n=1}^m f(n)")#text(", to show infinite discrepancy.")

#text("Let ")#mi("m_j")#text(" denote the index of the last element in the section of constant sign ")#mi("(-1)^j")#text(", whose length is ")#mi("w_j = m_j - m_{j-1} \\geq 1")#text(". Then: ")#mi("S_{m_j} - S_{m_{j-1}} = (-1)^j w_j")#text(". Thus we have:")

#text("If the lengths ")#mi("w_j")#text(" are unbounded (finite or infinite), the ")#mi("S_{m_j}")#text(" are unbounded as well and the discrepancy is infinite, even with just ")#mi("d = 1")#text(".")

#text("(Explicitly, for unbounded ")#mi("w_j")#text(": suppose ")#mi("S_m")#text(" are bounded, so ")#tao-math("\\left|S_m\\right| \\leq S", block: false)#text(" for all ")#mi("m \\in {\\bf N}")#text(". Choose a ")#mi("w_j \\geq 2S+1")#text(". Then ")#tao-math("\\left|S_{m_j}\\right| = \\left|S_{m_{j-1}} + (-1)^j w_j\\right| \\geq S+1", block: false)#text(", a contradiction. Hence ")#mi("S_m")#text(" are unbounded.)")

#text("If we write ")#mi("f(n) = (-1)^{\\lfloor g(n) \\rfloor}")#text(" for some differentiable function ")#mi("g(x)")#text(", then ")#mi("w_j")#text(" are unbounded (and hence the discrepancy infinite for ")#mi("d = 1")#text(") for example if the derivative ")#mi("g^{\\prime}(x) \\to k")#text(" as ")#mi("x \\to +\\infty")#text(", where ")#mi("k \\in 2{\\bf Z}")#text(" is an even integer.")

#text("(Since then the change in ")#mi("g(n) \\text{mod} 2")#text(" becomes arbitrarily small when ")#mi("n")#text(" increases by one and the sign of ")#mi("f(n)")#text(" stays constant for an arbitrarily long sequence of consecutive ")#mi("n \\in {\\bf N}")#text(".)")

#text("In your example: ")#mi("f(x) = \\text{sgn}(\\sin(\\frac{1}{\\sqrt{x+1}-\\sqrt{x}})) = (-1)^{\\lfloor g(x) \\rfloor}")#text(" where ")#mi("g(x) = \\frac{1}{\\pi(\\sqrt{x+1}-\\sqrt{x})}")#text(" (at least when ")#mi("\\frac{1}{\\sqrt{x+1}-\\sqrt{x}}")#text(" is not a multiple of ")#mi("\\pi")#text("). As ")#mi("x \\to +\\infty")#text(" the derivative ")#mi("g^{\\prime}(x) \\to 0")#text(", an even integer, and hence the discrepancy of ")#mi("f(x)")#text(" is infinite even with ")#mi("d = 1")#text(". QED")

#text("More generally, if ")#mi("f(n) = (-1)^{\\lfloor g(n) \\rfloor}")#text(" for some differentiable ")#mi("g(x)")#text(", and ")#mi("\\lim_{x \\to \\infty} g^{\\prime}(x) = \\frac{p}{q} \\in {\\bf Q}")#text(" is rational (with ")#mi("p \\in {bf Z}")#text(", ")#mi("q \\in {bf N}")#text("), then the discrepancy of ")#mi("f(n)")#text(" is infinite, where ")#mi("d = 2q")#text(" suffices.")

#text("Proof: define ")#mi("f_{(2q)}(n) = f(2q n) = (-1)^{\\lfloor g_{(2q)}(n)) \\rfloor}")#text(", where ")#mi("g_{(2q)}(x) = g(2q x)")#text(". As the derivative ")#mi("g_{(2q)}^{\\prime}(x) = 2q g^{\\prime}(x) = 2p \\in 2{\\bf Z}")#text(" is an even integer, the discrepancy of ")#mi("f_{(2q)}(n) = f(2q n)")#text(" is infinite with ")#mi("d = 1")#text(", and hence the discrepancy of the original ")#mi("f(n)")#text(" is infinite with ")#mi("d = 2q")#text(". QED")

#text("Would be nice to complete this discussion with the case of ")#mi("\\lim_{x \\to \\infty} g^{\\prime}(x)")#text(" an arbitrary real number, but I’d have to think about that case a bit more (Liouville’s Approximation Theorem comes to mind) …f")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MatjazG")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-460290")[#strong[#text("MatjazG")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2015")])]

#text("P.S. The equidistribution theorem/ergodicity of irrational shifts on a circle come to mind as well … :p")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MatjazG")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-460301")[#strong[#text("MatjazG")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2015")])]

#text("Correction: what is stated above about the limits of the derivative ")#mi("g^{\\prime}(x)")#text(" as ")#mi("x \\to \\infty")#text(" is not entirely true. For example, if ")#mi("g(x) = \\frac{\\sin \\nu x}{x}")#text(" then ")#mi("g^{\\prime}(x) \\to 0")#text(" as ")#mi("x \\to \\infty")#text(", but the lengths of the intervals ")#mi("w_j")#text(" do not diverge. This happens, because the floor function ")#mi("\\lfloor \\dots \\rfloor")#text(" is not continuous.")

#text("All of the analysis where limits of the derivative ")#mi("g^{\\prime}(x)")#text(" are needed from the previous post is still valid though, if we additionally suppose that: ")#mi("g^{\\prime}(n) - \\lim_{x \\to \\infty} g^{\\prime}(x)")#text(" has constant sign or is zero for all natural numbers ")#mi("n \\geq N")#text(" greater than some $N \\in {\\bf N}$. This is satisfied for example when ")#mi("g(x)")#text(" is increasing concave or decreasing convex for large enough ")#mi("x")#text(".")

#text("It is also satisfied in the example: ")#mi("g(x) = \\frac{1}{\\pi(\\sqrt{x+1}-\\sqrt{x})}")#text(".")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-460201")[#strong[#text("Terence Tao magic breakthrough again with EDP, Erdos Discrepancy Problem | Turing Machine")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2015")]

#text("[…] 8. The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos di… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81c7ee47219767de6af71eb6b5313e9894d7c3914be6d57431ae7e1b00c157a1-a1e079dc8e5844fbe1b13fa79adf07f02d1892bfbe1b6c1e95a39cc933de0cdd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vznvzn")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-460209")[#strong[#text("vznvzn")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2015")])]

#text(":star: :!: :D :cool: congratulations on this amazing breakthrough from, er (as is said in other fields eg hollywood celebrity) “one of your biggest fans”! hope that stanford or someone else does a press release soon, that seems the only reason there is not even more widespread notice so far, suspect it will be a slow-building wave in this case (ie among the public, insiders are now all well aware). some sketch of other possible diverse connections to other math/ CS areas ")#link("https://vzn1.wordpress.com/2015/10/06/terence-tao-magic-breakthrough-again-with-edp-erdos-discrepancy-problem/")[#text("here")]#text(". am wondering if some more general “theory of pseudorandomness” is lurking and/ or can be devised to attack apparently similar problems and even others now thought apparently dissimilar. also, it would be great if more comment could be made on the efforts underway to independently verify the proof, which is obviously quite/ extremely tricky/ technical. it would also be neat if you remarked somewhere more at length on the Konev/ Lisitsa empirical/ TCS-angle results.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-460638")[#strong[#text("Il problema della discrepanza: provata una congettura di Erdős? | OggiScienza")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2015")]

#text("[…] dei suggerimenti più utili sia sul blog di Tim Gowers che sul proprio (ha scritto anche una seconda parte) dove la peer-review ha preceduto quella della rivista, tuttora priva di un sito web […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-460754")[#strong[#text("EDP Reflections and Celebrations | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2015")]

#text("[…] posts:) The proof is described in this blog post by Tao. A similar (somewhat simpler) argument proving EDC based on a number-theoretic conjecture (The […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A small remark on the Elliott conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-461150")[#strong[#text("A small remark on the Elliott conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2015")])]

#text("[…] as for any distinct integers , where is the Liouville function. (The usual formulation of the conjecture also allows one to consider more general linear forms than the shifts , but for sake of discussion let us focus on the shift case.) This conjecture remains open for , though there are now some partial results when one averages either in or in the , as discussed in this recent post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klaus Roth | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-461808")[#strong[#text("Klaus Roth | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2015")])]

#text("[…] that generalised Roth’s theorem to progressions of arbitrary length. More recently, my recent work on the Chowla and Elliott conjectures that was a crucial component of the solution of the ErdH{o}s discrepancy problem, relies on an […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A conjectural local Fourier-uniformity of the Liouville function | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-462894")[#strong[#text("A conjectural local Fourier-uniformity of the Liouville function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2015")])]

#text("[…] to other “non-pretentious” bounded multiplicative functions, was a key ingredient in my recent solution of the Erdös discrepancy problem, as well as in obtaining logarithmically averaged cases of Chowla’s conjecture, such […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-463416")[#strong[#text("White label: the growth of bioRxiv | quantixed")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2015")]

#text("[…] a solution to the Erdos discrepency problem on arXiv (he actually put them on his blog first). This was then “published” in Discrete Analysis, an overlay journal. Read about […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-463433")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2015")])]

#text("In the second arXiv paper (the Erdos discrepancy problem), page 9, line 5, it should be “depending on ")#mi("\\epsilon")#text("” (instead of “depending on ")#mi("Y")#text("“).")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa1324c1c994de839ea47c1d3fc090678b0f30678ef9322eb0fb7c21d28a5761-0bc6d52660a40354927956fb97c9f4ccdb5632a4a81997c2618c656e6462fd96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zak")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-463916")[#strong[#text("Zak")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2015")])]

#text("In equation 3.11 (subadditivity of entropy of concatenation of intervals) on the Chowla and Elliot conjectures, it is claimed that this follows from Lemma 2.5, the affine invariance. I don’t think this is the case, since the random variable in consideration is not O(1), and actually can be as large as log(x). Nevertheless, it still should be true, basically because the random variable is as big as log(x) very infrequently.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-463922")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2015")])]

#text("One never has to directly work with random variables of size as large as log x, as one only needs to work with the entropy function ")#mi("p \\mapsto p \\log \\frac{1}{p}")#text(" (which is uniformly continuous on [0,1]) rather than with ")#mi("\\log \\frac{1}{p}")#text(" in isolation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa1324c1c994de839ea47c1d3fc090678b0f30678ef9322eb0fb7c21d28a5761-0bc6d52660a40354927956fb97c9f4ccdb5632a4a81997c2618c656e6462fd96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zak")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-463970")[#strong[#text("Zak")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2015")])]

#text("Oh, thanks, probably you are applying Lemma 2.5 ")#mi("2^{H_2}")#text(" times, which I missed.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa1324c1c994de839ea47c1d3fc090678b0f30678ef9322eb0fb7c21d28a5761-0bc6d52660a40354927956fb97c9f4ccdb5632a4a81997c2618c656e6462fd96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zak")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-463971")[#strong[#text("Zak")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2015")])]

#text("In between equations 3.13 and 3.14, it’s stated that ")#mi("H(Y_H) - H(Y_H | X_H =x ) \\geq 0")#text(". I don’t follow this, since it seems to me that ")#mi("Y_H")#text(" might not be uniformly distributed whilst after conditioning on ")#mi("X = x")#text(", it could be.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-464105")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2015")])]

#text("Sorry, the lower bound here should be ")#mi("-o_{A \\to \\infty}(1)")#text(" (from (3.7) and (3.9)). This will be corrected in the next revision of the ms.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa1324c1c994de839ea47c1d3fc090678b0f30678ef9322eb0fb7c21d28a5761-0bc6d52660a40354927956fb97c9f4ccdb5632a4a81997c2618c656e6462fd96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zak")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-464201")[#strong[#text("Zak")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2015")])]

#text("Ah..thanks! ")#mi("Y_H")#text(" is basically uniformly distributed")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa1324c1c994de839ea47c1d3fc090678b0f30678ef9322eb0fb7c21d28a5761-0bc6d52660a40354927956fb97c9f4ccdb5632a4a81997c2618c656e6462fd96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zak")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-465039")[#strong[#text("Zak")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2016")])]

#text("In the blog post, the equation just before equation 7, probably the 2 should be in front of the p instead of the j. Also, would you be able to elaborate a bit on how a bound on correlations of Louisville with nilsequences helps here? I am somewhat familiar with the case when studying k term arithmetic progressions, but here the common differences are restricted to a small subset of primes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-465040")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2016")])]

#text("Thanks for the correction. Arithmetic progressions with spacings in the primes (or some affine shift of the primes) can be controlled by Gowers uniformity norms of (say) the von Mangoldt function, which can in turn be controlled (in principle at least) by correlations of the Mobius or Liouville functions with nilsequences. See the papers of ")#link("http://www.ams.org/mathscinet-getitem?mr=2361086")[#text("Frantzikinakis-Kra")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2999293")[#text("Wooley-Ziegler")]#text(" for some calculations in this direction.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-467572")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2016")])]

#text("There is a ")#link("http://arxiv.org/abs/1603.08453")[#text("recent paper of Oleksiy Klurman")]#text(" that extends the methods in the above papers to finish off a second question of Erdos closely related to the discrepancy problem. Namely, Klurman completely classifies the functions ")#mi("f: {\\bf N} \\to \\{-1,+1\\}")#text(" that are multiplicative (but not necessarily completely multiplicative) and has bounded partial sums. There is an obvious such example, namely the parity function ")#mi("\\chi_2")#text(" that equals ")#mi("-1")#text(" on the even numbers and ")#mi("+1")#text(" on the odd numbers, and more generally one can multiply ")#mi("\\chi_2")#text(" by periodic multiplicative ")#mi("\\{-1,+1\\}")#text("-valued functions of odd period. These turn out to be the only examples; in my paper I was able to eliminate the “non-pretentious” multiplicative functions from consideration, and Klurman performed the complementary analysis of the “pretentious” case to resolve the question completely.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-467581")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2016")])]

#text("Is it possible to combine both methods?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Equivalence of the logarithmically averaged Chowla and Sarnak conjectures | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-468686")[#strong[#text("Equivalence of the logarithmically averaged Chowla and Sarnak conjectures | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2016")])]

#text("[…] distribution and applications” in honour of Robert F. Tichy. This paper is a spinoff of my previous paper establishing a logarithmically averaged version of the Chowla (and Elliott) conjectures in the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on the Bombieri asymptotic sieve | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-470705")[#strong[#text("Notes on the Bombieri asymptotic sieve | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2016")])]

#text("[…] the Chowla conjecture, for which there has been some recent progress (discussed for instance in these recent posts). Informally, the Bombieri asymptotic sieve lets us (on GEH) view the twin prime […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Special cases of Shannon entropy | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-478566")[#strong[#text("Special cases of Shannon entropy | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2017")])]

#text("[…] able to guess arguments that would work for general random variables. An example of this comes from my paper on the logarithmically averaged Chowla conjecture, in which I showed among other things […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Furstenberg limits of the Liouville function | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-478887")[#strong[#text("Furstenberg limits of the Liouville function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2017")])]

#text("[…] of Liouville with logarithmic averaging are equivalent to the Bernoulli system. Recently, I was able to prove the two-point […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The structure of logarithmically averaged correlations of multiplicative functions, with applications to the Chowla and Elliott conjectures | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-484808")[#strong[#text("The structure of logarithmically averaged correlations of multiplicative functions, with applications to the Chowla and Elliott conjectures | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2017")])]

#text("[…] and Elliott conjectures“, submitted to Duke Mathematical Journal. This paper builds upon my previous paper in which I introduced an “entropy decrement method” to prove the two-point […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The logarithmically averaged and non-logarithmically averaged Chowla conjectures | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-487852")[#strong[#text("The logarithmically averaged and non-logarithmically averaged Chowla conjectures | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2017")])]

#text("[…] And indeed, significantly more is now known for the logarithmically averaged Chowla conjecture; in this paper of mine I had proven (2) for , and in this recent paper with Joni Teravainen, we proved the conjecture for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fourier uniformity of bounded multiplicative functions in short intervals on average | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-508355")[#strong[#text("Fourier uniformity of bounded multiplicative functions in short intervals on average | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2018")])]

#text("[…] of this result to arbitrary non-pretentious bounded multiplicative functions) a few years ago to solve the Erdös discrepancy problem, as well as a logarithmically averaged two-point Chowla con…, for instance it implies […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 10 – mean values of nonpretentious multiplicative functions | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-532955")[#strong[#text("254A, Notes 10 – mean values of nonpretentious multiplicative functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2019")])]

#text("[…] as if is such that for some fixed . However it is significantly more difficult to understand what happens when grows much slower than this. By using the techniques based on zero density estimates discussed in Notes 6, it was shown by Motohashi that one can also establish (4) as long as (strictly speaking Motohashi discusses the Möbius function only, but one can use a variant of Exercise 1 to then recover the Liouville case). This threshold is still essentially the best one known unconditionally; on the Riemann Hypothesis Maier and Montgomery lowered it to for an absolute constant (the bound is more classical, following from Exercise 33 of Notes 2). On the other hand, the randomness heuristics from Supplement 4 suggest that should be able to be taken as small as , and perhaps even if one is particularly optimistic about the accuracy of these probabilistic models. On the other hand, the Chowla conjecture (mentioned for instance in Supplement 4) predicts that cannot be taken arbitrarily slowly growing in , due to the conjectured existence of arbitrarily long strings of consecutive numbers where the Liouville function does not change sign (and in fact one can already show from the known partial results towards the Chowla conjecture that (4) fails for some sequence and some sufficiently slowly growing , by modifying the arguments in these papers of mine). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Some recent papers | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/#comment-535671")[#strong[#text("Some recent papers | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2020")])]

#text("[…] to those used in recent progress towards the Chowla conjecture over the integers (e.g., in this previous paper of mine); the starting point is an algebraic observation that in certain function fields, the Mobius […]")
]
