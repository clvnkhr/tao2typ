// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/
// Converted to Typst by tao2typ: "2026-10-14T09:22:23.268496+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The cost of knowledge", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The cost of knowledge")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 January 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/")[#text("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("A few days ago, inspired by ")#link("http://gowers.wordpress.com/2012/01/21/elsevier-my-part-in-its-downfall/")[#text("this recent post of Tim Gowers")]#text(", a ")#link("http://thecostofknowledge.com/")[#text("web page entitled “the cost of knowledge”")]#text(" has been set up as a location for mathematicians and other academics to declare a protest against the academic publishing practices of ")#link("http://www.reedelsevier.com/Pages/Home.aspx")[#text("Reed Elsevier")]#text(", in particular with regard to their ")#link("http://math.berkeley.edu/~kirby/journals.html")[#text("exceptionally high journal prices")]#text(", their")#link("http://www.ncbi.nlm.nih.gov/pmc/articles/PMC1150298/")[#text(" policy of “bundling” journals together")]#text(" so that libraries are forced to purchase subscriptions to large numbers of low-quality journals in order to gain access to a handful of high-quality journals, and their opposition to the open access movement (as manifested, for instance, in their ")#link("http://gizmodo.com/5870241")[#text("lobbying")]#text(" ")#link("http://www.michaeleisen.org/blog/?p=846")[#text("in support of")]#text(" legislation such as the Stop Online Piracy Act (SOPA) and the Research Works Act (RWA)). [These practices have been documented in a number of places; ")#link("http://michaelnielsen.org/polymath1/index.php?title=Journal_publishing_reform")[#text("this wiki page")]#text(", which was set up in response to Tim’s post, collects several relevant links for this purpose. Some of the other commercial publishers have exhibited similar behaviour, though usually not to the extent that Elsevier has, which is why this particular publisher is the focus of ")#link("http://thecostofknowledge.com/")[#text("this protest")]#text(".] At ")#link("http://thecostofknowledge.com/")[#text("the protest site")]#text(", one can publicly declare a refusal to either publish at an Elsevier journal, referee for an Elsevier journal, or join the board of an Elsevier journal.")

#text("(In the past, the editorial boards of several Elsevier journals have resigned over the pricing policies of the journal, most famously ")#link("http://math.ucr.edu/home/baez/topology-letter.pdf")[#text("the board of Topology in 2006")]#text(", but also ")#link("http://www.cs.colorado.edu/~hal/jalg.html")[#text("the Journal of Algorithms in 2003")]#text(", and ")#link("http://en.wikipedia.org/wiki/Elsevier#Resignation_of_editorial_boards")[#text("a number of journals in other sciences")]#text(" as well. Several libraries, ")#link("http://www.ncbi.nlm.nih.gov/pmc/articles/PMC1150298/")[#text("such as those of Harvard and Cornell")]#text(", have also managed to negotiate an unbundling of Elsevier journals, but most libraries are still unable to subscribe to such journals individually.)")

#text("For a more thorough discussion as to why such a protest is warranted, please see ")#link("http://gowers.wordpress.com/2012/01/21/elsevier-my-part-in-its-downfall/")[#text("Tim’s post on the matter")]#text(" (and the 100+ comments to that post). Many of the issues regarding Elsevier were already known to some extent to many mathematicians (particularly those who have served on departmental library committees), several of whom had already privately made the decision to boycott Elsevier; but nevertheless it is important to bring these issues out into the open, to make them ")#link("http://en.wikipedia.org/wiki/Common_knowledge")[#text("commonly known")]#text(" as opposed to merely mutually known. (Amusingly, this distinction is also of crucial importance in my ")#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/")[#text("favorite logic puzzle")]#text(", but that’s another story.) One can also see Elsevier’s side of the story in ")#link("http://gowers.wordpress.com/2012/01/21/elsevier-my-part-in-its-downfall/#comment-14679")[#text("this response to Tim’s post by David Clark")]#text(" (the Senior Vice President for Physical Sciences at Elsevier).")

#text("For my own part, though I have sent about 9% of my papers in the past to Elsevier journals (with one or two still in press), I have now elected not to submit any further papers to these journals, nor to serve on their editorial boards, though I will continue refereeing some papers from these journals. As of this time of writing, over five hundred mathematicians and other academics ")#link("http://thecostofknowledge.com/")[#text("have also signed on to the protest")]#text(" in the four days that the site has been active.")

#text("Admittedly, I am fortunate enough to be at a stage of career in which I am not pressured to publish in a very specific set of journals, and as such, I am not making a recommendation as to what anyone else should do or not do regarding ")#link("http://thecostofknowledge.com/")[#text("this protest")]#text(". However, I do feel that it is worth spreading awareness, at least, of the fact that such protests exist (and some additional petitions on related issues can be found at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Journal_publishing_reform")[#text("the previously mentioned wiki page")]#text(").")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (47)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bc3ca449c2ebc83a53332b20e9736b24e10e2a0cfbf189423336e5e695473b5-8df4d657c1dba3ec50191b7c242866c5f037feb2f5bb0fa2baf2846042f64873.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ccarminat")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-124820")[#strong[#text("ccarminat")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2012")])]

#text("I just would like to recall that there was a similar (but less specific) action regarding “exceptionally high journal prices” called the Banff Protocol.")#linebreak()#text(" ")#link("http://members.cox.net/banffprotocol/")[#text("http://members.cox.net/banffprotocol/")]

#text("I think that getting some concrete result with this specific target (Elsevier) could be of great help for the general campaign aiming to reasonable journal prices.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-124873")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2012")])]

#text("The link you provided for the Banff Protocol seems to be down. If anyone knows of an active link for this, I would be happy to add it to the wiki page.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee89f7be5db84c69427e542c843fce8ef950081c46c1d97f90c35d66fd32a12f-aebd9da958af9f6d8842f374a0daafcf96130da3c271896c6306f8689019624d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Barry Cipra")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-124908")[#strong[#text("Barry Cipra")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2012")])]

#text("Here’s a link that might explain what happened to the banffprotocol link: ")#link("http://consumerist.com/2011/11/cox-ends-free-web-pages-for-internet-service-customers.html")[#text("http://consumerist.com/2011/11/cox-ends-free-web-pages-for-internet-service-customers.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26f15258f2b5502af22d190d1d224fcfa1e4eeddc42feef0dbb10cd83ce381f3-c040b178f55636f6a721cf117ebd76c776b1d0ab1b023170add3265ef853f715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hasler (@hasler)")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-143089")[#strong[#text("hasler (@hasler)")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2012")])]

#link("http://www.google.com/search?q=bannf+protocol")[#text("http://www.google.com/search?q=bannf+protocol")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-124848")[#strong[#text("The cost of knowledge « Mathematical Biology")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2012")]

#text("[…] Terry Tao blog post […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44ed8a2db4d1cda859a959cad9af94bcda5ee56436fe69b3a6ed9d47787efa66-e3deb08ce24c18d49d3200ca6d35dbb560aa203c10b42552fd5d84cccc9c886e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elsevier’s economic case is lacking | Digitopoly")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-124856")[#strong[#text("Elsevier’s economic case is lacking | Digitopoly")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2012")])]

#text("[…] here is Terry Tao] Share […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/704b81e58ca29743b47850bb62f82d988587af8aa950d2d86ccec5d2d2505f3a-ae78c7c51eb8b92e65e74b0790dfb510525c2923707a533c2fcc07a150e39602.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of plm")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-124862")[#strong[#text("plm")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2012")])]

#text("“Admittedly, I am fortunate enough to be at a stage of career in which I am not pressured to publish…”")

#text("Indeed when 9% of your papers is a nontrivial number. :)")

#text("The MSRI has finally updated its video website, with among others, videos of their workshop on mathematics journals:")#linebreak()#text(" ")#link("http://www.msri.org/web/msri/scientific/show/-/event/Wm549")[#text("http://www.msri.org/web/msri/scientific/show/-/event/Wm549")]

#text("Elsevier’s David Clark gave a presentation there, though I did not find anything really noteworthy in it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Acta treaty, “the cost of knowledge”, Google privacy policy | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-124864")[#strong[#text("Acta treaty, “the cost of knowledge”, Google privacy policy | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2012")])]

#text("[…] read the post “The cost of knowledge” by Terence Tao and also visit the relevant links, if you are concerned with the matter of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Crust")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-124872")[#strong[#text("Crust")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2012")])]

#text("Terry, can you comment on why you will continue refereeing in some cases for Elsevier journals? (I assume you mean beyond commitments you have already made to review specific papers, which is of course expected.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-124874")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2012")])]

#text("As I said in the post, I am fortunate that I can exercise discretion where to publish, but I recognise that some mathematicians, for reasons beyond their control, are unable to, and I do not wish to penalise them for being in such a situation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Crust")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-124884")[#strong[#text("Crust")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2012")])]

#text("Thanks for the reply. So I think you’re saying roughly that your policy is that you will only referee papers for Elsevier journals when the authors are not particularly prominent and thus might not have had the opportunity to publish in a non-Elsevier journal.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31c37b7cec586dc4166ab6dd70044da1750aa341935647e94e929cbb5e674764-6fdfc7e729cce89fb717f3a8306407c87042f4b1e773cd4610a9db61e5b786c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pete")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-125637")[#strong[#text("Pete")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2012")])]

#text("There is a point missing from the discussion here (and elsewhere). The commercial publishers are obviously interested in keeping the current system, and are helped by the various fundings agencies which tend to give money in proportion to the (perceived) journal quality, making it hard to get a new free or cheap journal running. But the publishers don’t just make use of our services as referees and editors – they are forced to. They do not have on their staff enough mathematically competent people to take on even a tiny fraction of the refereeing work, and they don’t have anyone who commands enough respect to get that work out of the community: that job is done by the unpaid editor.")

#text("The question is how one can convince an editor (or preferably the entire board of a journal) that they should resign (and perhaps start a new journal with a decent publisher such as a learned society). The simplest way (and perhaps it will happen now with some of the Elsevier combinatorics journals) is that the editor suddenly finds that getting referees for papers (which already takes up more time than they like) becomes much harder (and they no longer have time to get their own work done), and the refusals tend to come with notes stating that the reason is the journal publisher. So – whether or not you want to sign a public boycott of Elsevier, and thereby remove any chance of publishing with them (which could be a bad career move for many people) you should refuse to referee for them")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae8461e0132a14b601b9e759b29e8bf55ab18c2e8319bea84c92705f045afceb-2355733f005069d29ef94b3b79978270f4125505ecbb25a228ec7a4084166b3e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sgadgil")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-124875")[#strong[#text("sgadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2012")])]

#text("This should really be called the `cost of certification’ (or evaluation) – this has become the main role of the journals.This does not justify high costs, but there should be more introspection on the whole process (for the most part, we have cheerfully gone along with the idea that papers are our products), and what has made us vulnerable to the Elseviers (besides the agency problem).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-124903")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2012")])]

#text("My impression is that the set of Elsevier journals is still small enough that mathematicians in most areas can avoid them at any stage in their careers, if they make the effort.")

#text("(Full disclosure: I did publish once in an Elsevier journal in the past, due to a decision on the part of coauthors; I do not intend to do so ever again.)")

#text("Needless to say, avoiding all high-price journals is harder. It’s good that mass support for a specific measure seems to be so strong.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AKB")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-124933")[#strong[#text("AKB")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2012")])]

#text("The New York Times recently had an article related to this discussion. The link is below.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d7d86ad093ebf137a44f6706457ec5be9ed7d1f0d08bfec3e5ec44b4943aa9e-0544df05390b65666ffa232085525d09bc1f518b078677cf417cf6549848afc4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andres")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-124948")[#strong[#text("Andres")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2012")])]

#text("Why cannot current editors of Elsevier (or Springer) agree on creating an online journal that will replace each existing one, so as not to penalize anyone? For instance people could spread the word about keeping the same standards and submission guidelines for the newly founded “Journal of Functorial Analysis” the “Journal of Mathematical Analysis and its applications” and so on. No CV would be affected if this were to happen, everyone would understand the quality of each paper as coming from the preexisting journal.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/58a78745d0cae95122cacbb589de3f66f67af2ada558fcec8c709c0a8bbde016-1fd06a6a3ef4fb4a7dc0b89ecdf2c1e1f6c212b0efc09f5e6dc9df4e4b502675.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ogerard")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-125308")[#strong[#text("ogerard")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2012")])]

#text("@Andres: You must consider, that at least in certain cases, Elsevier or another publishing house can be the owner of the journal’s title, as a registered trade mark, ISSN designation or equivalent. Passing without permission for such a journal would expose to a legal action for infringement. On the same topic, editors may be bound by more precise agreements with the publishing house (non disclosure of privileged information, non competition, etc.) putting them in a delicate position.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-124970")[#strong[#text("Peneliti Dunia Melawan Elsevier « Blog cak alief")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2012")]

#text("[…] nyasar ke video Bilangan Prima oleh Terence Tao, kemudian liat blognya, sampai akhirnya baca postingan bahwa para peneliti dunia sedang membuat perlawanan terhadap Elsevier di sini. Di saat aku […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Séguin")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-124971")[#strong[#text("Richard Séguin")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2012")])]

#text("There are now more than 1000 names on the list, and I think the number has more than doubled within the last 24 hours. Impressive! If I were only affiliated …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-124995")[#strong[#text("Dois artigos interessantes sobre o atual sistema de periódicos científicos « Teoria de Lie e Aplicações")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2012")]

#text("[…] Post do blog do Terence Tao: The cost of knowledge […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-125211")[#strong[#text("PUblishers’ wars « Peter Cameron's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2012")]

#text("[…] seems to have taken the lead in a campaign targeted specifically against Elsevier, supported by Terry Tao and others. There is a website thecostofknowledge.com where you can choose to support the campaign […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-125213")[#strong[#text("ぎろんとか． « Memorandum")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2012")]

#text("[…] * 数学のジャーナル The Cost of Knowledge Gowersのブログから Taoのブログから […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-125351")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2012")])]

#text("I was thinking for some time to write one or more arxiv papers with full proofs of partial results, all the technicalities, etc. Then submit to a journal a 2 pages paper which contains a new result which is proved by concatenating the technical results from the arxiv papers. The proof of the new result would be something like “in order to prove this use theorem A from arxiv…, then theorem B from arxiv … and conclude by using theorem C from arxiv …”")

#text("With enough imagination ANY paper from ANY journal (which asks for money to “disseminate” one’s work) could be just reduced to one or two pages, like a sort of extended abstract.")

#text("Peer review? Easy! Would they publish it? I doubt!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae5153cb5eb5186bb605f30d097b7da87b5629bbf1937bf7f4fc2446b7f3a8ee-aa697eee4fded48993576d603e6d2f9257e3ae047c216575b897f06d86f024bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shane O Rourke")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-125437")[#strong[#text("Shane O Rourke")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2012")])]

#text("Interesting discussion. What I’d like to know is: which publishers do deserve our support? Is there an on-line list of publishing houses (or better still, of maths journals) that don’t charge extortionate prices, don’t bundle etc? So far I’ve found ")#link("http://www.doaj.org/doaj?func=subject&cpid=58")[#text("http://www.doaj.org/doaj?func=subject&cpid=58")]#text(", the directory of open access journals, and ")#link("http://www.mathematik.uni-bielefeld.de/~rehmann/BIB/AMS/Publisher.html")[#text("http://www.mathematik.uni-bielefeld.de/~rehmann/BIB/AMS/Publisher.html")]#text(" which gives information on (2008) maths journal prices. I’d be interested to find out more.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73fd7d645a2c8704f3385a2d4068cf2e4dfe9ea2a8ff5a0b5409317cfedb833e-a4f0a9e34a41cb156a72a55b58c7903053d481bf6750e520a45b3c864254f1a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Joshi")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-125485")[#strong[#text("Mark Joshi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2012")])]

#text("Such campaigns have been around for a while in various forms. I do not feel that they will work until there’s an additional part of the pledge.")

#text("“I promise not to be impressed nor to take into account any publication in an overpriced journal when assessing an academic’s research.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef3ae79bd944137a0ccf68ddfb4ed9dfeeb13f961a9a3b4d2ab56fa684b5a23a-2affba240ffd94ccd755a866d2425adef2dc8d0dcaadef7222e988fcfcbf79a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Norman")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-125683")[#strong[#text("Norman")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2012")])]

#text("This is effectively discriminating against people who choose not to participate in the boycott. I do think there is more than one valid view on how to deal with Elsevier, and alternative viewpoints shouldn’t be punished.")#linebreak()#text(" Also, in my opinion you are advocating academic dishonesty… you are saying a given result should be judged not solely on its content, but also on whether or not the author is participating in the boycott.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73fd7d645a2c8704f3385a2d4068cf2e4dfe9ea2a8ff5a0b5409317cfedb833e-a4f0a9e34a41cb156a72a55b58c7903053d481bf6750e520a45b3c864254f1a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Joshi")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-126111")[#strong[#text("Mark Joshi")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2012")])]

#text("I am advocating that the paper be judged on its merits rather than on what journal it’s published in. The expensive journals continue to exist because authors have to publish in them to get tenure and promotion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef3ae79bd944137a0ccf68ddfb4ed9dfeeb13f961a9a3b4d2ab56fa684b5a23a-2affba240ffd94ccd755a866d2425adef2dc8d0dcaadef7222e988fcfcbf79a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Norman")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-126570")[#strong[#text("Norman")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2012")])]

#text("You did say you promise not to take into account any publication in an overpriced journal, which means something else from what you just said.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-125677")[#strong[#text("Koszt wiedzy « Rozmaitości")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2012")]

#text("[…] Medalu Fieldsa Timothy Gowers wezwał na swoim blogu do bojkotu Elseviera. Kilka dni później poparł go Terence Tao. Na stronie thecostofknowledge.com można zadeklarować wstrzymanie się od […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d841279bde782b1cb2e7ccda53cc7961fc14ed2c90a8bc7731bb0c74350c951-eee14fee51eb44b15d62bce8c494cea0959e98139d76d125f021dd3452b6c425.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Links 31 Jan + Maxeler JP Morgan References « Front to Back Books")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-125693")[#strong[#text("Links 31 Jan + Maxeler JP Morgan References « Front to Back Books")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2012")])]

#text("[…] Tao and Gowers re: Reed Elsevier journals, here […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-125730")[#strong[#text("Libres pensées d'un mathématicien ordinaire » Publications: science, money, and human comedy")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2012")]

#text("[…] The Cost of Knowledge by Terry Tao […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c514ac24f83e4b5cff3f5a8f7e69c7739d466a090d3ebc0000c588118688049e-fe4a375bd51d7782ba3def1fd9da15f0083a08a89282e2849f5d6a48a1048243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petequinn")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-125731")[#strong[#text("petequinn")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2012")])]

#text("I’ve read Tim Gowers’ post and had a look at the wiki page and a number of the (mostly supportive) comments, but I’ll admit it’s not clear to me what this movement is trying to achieve, specifically. There’s a strong element of supply and demand at work here. Elsevier and the other publishing houses (Elsevier is the target du jour, but it seems Springer is also quite expensive from what I can gather) are businesses, and they have a product to sell, that has a market value established not by them alone but by them and their customers (including all of us). Quality and exclusivity have real value. Researchers want to publish in prestigious journals because they carry more weight; prestigious journals are thus in greater demand, both from authors and from the academic audience that buys the product (either directly, or, in most cases, indirectly through university libraries for example), and thus more valuable. In a free market society, a more valuable commodity sells for a higher price.")

#text("I realize part of the argument is about the policy of bundling, and associated high cost. I can see that point of view, but the down side of eliminating such bundling is that it will likely lead to the rapid death of a large number of smaller journals. Is that a good thing? Judging from the comments in Gowers’ blog about “Chaos, Solitons and Fractals” (is it really a shoddy journal? I have no opinion, although it’s been around > 20 years), maybe it’s a good thing if a large number of fringe journals die a sudden death, I don’t know.")

#text("With the advent of the internet, it’s certainly easy to share ideas freely, and it’s a noble thing to want to give one’s work away. But if a thing (in this case intellectual property) has value, people will be willing to pay for it, and the market will collectively set a “fair” price.")

#text("Are Elsevier’s prices “fair?” Doesn’t sound like it from the groundswell of opposition. So in that vein, hopefully this protest will bear some meaningful fruit in price adjustments.")

#text("I realize I’m going against the flow a bit here, hopefully not in an offensive way. Cheers… :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-126258")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2012")])]

#text("I wish the journals were more exclusive and expensive. Then it would be easier to justify funding as an academic research mathematician, because your work is clearly valuable if universities pay for expensive subscriptions to the journals where you publish.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5cd4d6f7c957fadda199dc126443e196e4eda2db3001bdea48132a5f43607760-fb213bab809261697e135d8664d4102f6329e5923004adbd3b7e525268462344.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Deane")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-126842")[#strong[#text("Deane")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2012")])]

#text("It seems to me what would be more effective than a boycott is for the editorial board of journals as Advances to switch to a new publisher, preferably either the AMS or a university press. Or some of us should try to start new journals with high standards. Otherwise, the boycott *does* unfairly hurt those who for one reason or another are dependent on publishing in Elsevier journals.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-127076")[#strong[#text("Fourteenth Linkfest")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2012")]

#text("[…] Terence Tao: The cost of knowledge […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5ff347feabfce275c82e677ffc99133503a9f0c1e1ba5a0c1d09f76b4dd2b5d7-d9fb9b1bd0efa565f292b230669a57e76db93321a730af4e4751a5048606c9c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gowers on Elsevier | CUNYMath Blog")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-127687")[#strong[#text("Gowers on Elsevier | CUNYMath Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2012")])]

#text("[…] Field’s medalist Terence Tao has seconded some of Gowers’s opinions. While Gowers has resolved neither to publish nor to referee for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c514ac24f83e4b5cff3f5a8f7e69c7739d466a090d3ebc0000c588118688049e-fe4a375bd51d7782ba3def1fd9da15f0083a08a89282e2849f5d6a48a1048243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petequinn")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-127734")[#strong[#text("petequinn")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2012")])]

#text("I think it’s likely that some of the arguments in support of this boycott/protest are a little misguided, namely that the publishers are making “exorbitant” profits or that the actual production costs (beyond the contributions of the volunteer editors, referees etc) are “negligible.” If the profits were unreasonable (in comparison with industry norms, say), you could be sure a competitor would materialize to claw away some of the excess profit. That’s the way a free market works (and, ironically, perhaps the best mathematical explanations of the chaotic dynamics of a free market would appear in a journal like “Chaos, Solitons and Fractals”).")

#text("I think if this group is really serious about this protest, the thing to do would be to organize to create a low cost, world class competitive journal or set of journals as an alternative. I suggest you would find in developing a business case for such a venture that without a strong backbone of volunteer effort, the costs to produce a top notch journal (or set of journals) would price you way out of the market. Of course I could be wrong, but this is my suspicion. I continue to wish you all the best with your efforts, I would also enjoy lower cost access to academic journals, and would certainly prefer to retain copyright of my own work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-127761")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2012")])]

#text("There are already a significant number of low cost, high quality journals in mathematics; see for instance the journals of ")#link("http://msp.org/")[#text("Mathematical Sciences Publishers")]#text(", whose journal costs are about a tenth of that of the major commercial publishers. This is certainly part of the solution, but it is not enough that low cost publishing exists, because of several unique features of the academic journal market that distinguish it from textbook “free markets”.")

#text("First of all, access to research is not a fungible good. It is not as if each library has a given target of, say, 100,000 high quality research pages a year, which it can then choose to buy from a variety of sellers. Instead, a library is trying to ensure access to as much of the important literature as it can. If half of the most important papers in a field are in expensive journals, and half are in cheap journals, one cannot just subscribe to the cheap journals, as one is then missing out on half of the key literature. It is only if there is a concerted effort among researchers to submit their best papers to cheaper journals (and/or an expansion of the practice of making preprints of these papers freely available) that libraries can finally refuse to pay for the most expensive journals. (In part, the difficulty here is an agency problem; the researcher at a university submitting the paper to a journal is not usually the person in charge of purchasing that journal later for the university library, and so the journal pricing is often not an immediate factor in submission. One appealing feature of open access models is that they reduce the agency problem by making the cost of the paper more explicit to the submitter, bringing it closer to the free market you have in mind.)")

#text("Another issue is that the commercial journals set the individual prices of journals and articles are so high that the only realistic option of most libraries is to subscribe to enormous bundling deals involving large numbers of journals (and in some cases, many universities or even, in extreme cases, an entire country). In many of these contracts, one cannot actually save any money by cancelling an unwanted journal; at best, one can substitute it with another journal from the bundle. As long as the publisher commands a significant enough fraction of the important research in the area that subscription to their bundle becomes a necessity for any good research library, this considerably reduces the ability of libraries to exercise their market power.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c514ac24f83e4b5cff3f5a8f7e69c7739d466a090d3ebc0000c588118688049e-fe4a375bd51d7782ba3def1fd9da15f0083a08a89282e2849f5d6a48a1048243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petequinn")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-127770")[#strong[#text("petequinn")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2012")])]

#text("I love reading this blog because every time I come here I learn something new. I usually struggle to follow maybe 5 % of the mathematics, but now I know what “fungible” means, thanks to Professor Tao and wikipedia. :-)")

#text("And speaking of wikipedia, there is an excellent example of newly free knowledge, widely available. You say the text book market is different than the academic research market, and this i probably true (although I would suggest they are different for reasons that are too complex to state clearly and concisely). Similarly, I’d suggest the academic research market is similarly different than the wiki-model free knowledge market.")

#text("But perhaps these different strands will be woven together into a free or nearly free model sometime in the near future. I don’t think when I was filling out Fortran bubble cards in the 70s me or any of my peers anticipated the magnitude of change in the knowledge economy over the next 3-4 decades. I’m sure nobody can predict what the next 10-30 years will hold for us. But here’s wishing for free academic journals for all! :-)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd4bfb06bd050a989093ed573685723febc2f7fbc97be93869ddd8bab3257fc9-7fe956b9f8b7dae1686b686a0691c02b9667dd8802e8de59c9cf328efac02d71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boicote a Elsevier, Higgs e Moriond « Ars Physica")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-128175")[#strong[#text("Boicote a Elsevier, Higgs e Moriond « Ars Physica")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2012")])]

#text("[…] com 34 iminentes matemáticos como signatários, entre eles alguns famosos na internet como o Terence Tao (mais aqui) e o John Baez. O único brasileiro signatário dessa lista é o matemático do IMPA […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/06ca176c2a5464f2186dfa94ec79a02e112985047ae33dcd4b5eddcacc0ee95f-991fd68827cc5cd7d3eb4023228d7b9aecaf280c489240cc464f2ab79f1b253f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KY")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-141683")[#strong[#text("KY")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2012")])]

#text("Dear Prof. Tao:")

#text("I forgot if it was this blog or in another blog, but I think you said something like we should all post pre-prints on ArXiV (or published version on our own homepages).")

#text("Well, some have already published and do not even have their homepages (for some reason). What do you think about the idea of posting papers on ArXiV after publication? ArXiV is supposed to be pre-print. Does it make sense to use ArXiV just to share published works? I sometimes see a paper on ArXiV that just appeared on ArXiV and it was actually published by some journal a few years ago. Any thought on that kind of activity?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-141687")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2012")])]

#text("I see no reason why the arXiv could not be used for this purpose (there is even a specific “Journal” field in the arXiv metadata for recording where a preprint has appeared in print); most journals nowadays permit electronic posting of papers (though some only permit the posting of unofficial drafts rather than the final published copy). An extreme case of this are the arXiv translations of some papers of Euler: ")#link("http://arxiv.org/find/math/1/au:+Euler_L/0/1/0/all/0/1")[#text("http://arxiv.org/find/math/1/au:+Euler_L/0/1/0/all/0/1")]#text(" . On the other hand, if the paper is already in print in a journal for which one already has reasonably good online access, the need to have an independent online copy of the paper is not all that pressing.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/06ca176c2a5464f2186dfa94ec79a02e112985047ae33dcd4b5eddcacc0ee95f-991fd68827cc5cd7d3eb4023228d7b9aecaf280c489240cc464f2ab79f1b253f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KY")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-141694")[#strong[#text("KY")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2012")])]

#text("Dear Prof. Tao:")

#text("I understood.")

#text("Thank you very much for your reply!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26f15258f2b5502af22d190d1d224fcfa1e4eeddc42feef0dbb10cd83ce381f3-c040b178f55636f6a721cf117ebd76c776b1d0ab1b023170add3265ef853f715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hasler (@hasler)")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-143090")[#strong[#text("hasler (@hasler)")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2012")])]

#text("I am confident that sooner or later, with the disappearing of the last generation of distinguished researchers reluctant to use internet to publish their knowledge, the community of scientists will be able to estabish their own rating system.")#linebreak()#text(" There will be small deviations and aberrations, but globally, a consensus (at least qualitatively) will be reached on the scientific value / qualification of most members of the community, i.e., of their judgement about publications of others.")#linebreak()#text(" Then their rating of publications will be a good substitute for the current (“ancient”) peer review system. It will not be perfect, but at least as good as the ancient system. There will be many more referees for each publication, since refereeing could be as simple as clicking on “like” or “dislike”, with a value attributed to the vote depending on the evaluation of this person by others and on how many clicks the person distributes during a time interval.")#linebreak()#text(" Even if the absolute value of such ratings will not necessarily be meaningful, it will allow comparision among publications in a given area.")#linebreak()#text(" After all, “to publish” should mean that the findings become public, i.e. available to as many readers as possible!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-148190")[#strong[#text("Je boycotte désormais Elsevier « Blog de Cyril Imbert")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2012")]

#text("[…] de la Société mathématique de France. Après la lecture du post sur le blog de T. Gowers, celui de T. Tao, du post du blog de D. Chafaï et de l’article de D. N. Arnold et H. Cohn, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leaders and followers « chorasimilarity")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-180038")[#strong[#text("Leaders and followers « chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2012")])]

#text("[…] and funny video is dedicated to “The cost of knowledge” movement, to its leader, its first follower and to all others who […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fee8888affee69ddeca79de73d03e1ed0525687ab5818022981e74528321f07-7693dc0db1ee9b226226ae377722305f65a4f31e17cacdd789a263a07fa637bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Umar")]], [#link("https://terrytao.wordpress.com/2012/01/26/the-cost-of-knowledge/#comment-215233")[#strong[#text("Umar")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2013")])]

#text("Let’s crowdfund peer-review!")

#text("Sites which crowdfund research: ")#link("http://scifundchallenge.org/")[#text("http://scifundchallenge.org/")]#text(" ")#link("http://www.petridish.org")[#text("http://www.petridish.org")]
]
