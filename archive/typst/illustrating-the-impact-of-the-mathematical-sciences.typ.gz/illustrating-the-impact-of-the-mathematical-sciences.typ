// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/03/04/illustrating-the-impact-of-the-mathematical-sciences/
// Converted to Typst by tao2typ: "2026-10-14T15:20:25.458436+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Illustrating the impact of the mathematical sciences", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Illustrating the impact of the mathematical sciences")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 March 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/03/04/illustrating-the-impact-of-the-mathematical-sciences/")[#text("https://terrytao.wordpress.com/2020/03/04/illustrating-the-impact-of-the-mathematical-sciences/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The National Academies of Sciences, Engineering, and Medicine have initiated a project on “")#link("https://www8.nationalacademies.org/pa/projectview.aspx?key=51712")[#text("Illustrating the Impact of the Mathematical Sciences")]#text("“, in which various media will be produced to showcase how mathematics impacts the modern world. (I am serving on the committee for creating this media, which has been an interesting experience; the first time for instance that I have had to seriously interact with graphic designers.) One of the first products is a ")#link("https://www.eventbrite.com/e/webinar-series-illustrating-the-impact-of-the-mathematical-sciences-registration-93576500833")[#text("“webinar” series")]#text(" on the ten topics our committee have chosen to focus on, that is currently running weekly on Tuesdays. Last week I moderated the ")#link("https://vimeo.com/showcase/6834078/video/395030757")[#text("first such webinar")]#text(", titled “From Solving to Seeing”, in which Profs. Gunther Uhlmann and Anna Gilbert presented ways in which inverse problems, compressed sensing, and other modern mathematical techniques have been used to obtain images (such as MRI images) that would not otherwise be accessible. Next week I will moderate another webinar, titled “Abstract Geometry, Concrete Impact”, in which Profs. Katherine Stange and Jordan Ellenberg will discuss how modern abstract geometries are used in modern applications such as cryptography. The full list of webinars and the latest information on the speakers can be found at ")#link("https://www8.nationalacademies.org/pa/projectview.aspx?key=51712")[#text("this website")]#text(". (Past webinars can be viewed directly from the web site; live webinars require a (free) registration, and offer the ability to submit text questions to the speakers via the moderator.)")

#text("We are currently in the process of designing posters (and possibly even a more interactive online resource) for each of the ten topics listed in the webinars; hopefully these will be available in a few months.")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcc8946f803e2fd7a6157d43b3a347a85dfdccc1a772a4fe526012aa745e91ff-b32507acb466766f9be1685d880c057ea5d929c88b1bbb6a4e287c2627f485ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Fry")]], [#link("https://terrytao.wordpress.com/2020/03/04/illustrating-the-impact-of-the-mathematical-sciences/#comment-543232")[#strong[#text("David Fry")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2020")])]

#text("Congratulations Terry. I consider you to be a big star now, but when you become a Super Nova, please don’t forget about the small Red Dwarfs, like me. Thanks for the heads up, and please keep it up!")

#text("Very Sincerely,")

#text("David")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/945738ce6873f83b0c01c9b2178ecc0efa149c758b8162b560856ba58bf87b2d-7ac4eb5c4f31ec301cb628fa1576b6995b4764126ac8696b1aa02402ee7168da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of BritishBloke")]], [#link("https://terrytao.wordpress.com/2020/03/04/illustrating-the-impact-of-the-mathematical-sciences/#comment-544147")[#strong[#text("BritishBloke")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2020")])]

#text("Small Fry?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Braight")]], [#link("https://terrytao.wordpress.com/2020/03/04/illustrating-the-impact-of-the-mathematical-sciences/#comment-543255")[#strong[#text("Richard Braight")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2020")])]

#text("I am a bit concerned about such activities. It seems there could be post-hoc justifications generated which might lead long term to the expectation that science has the direct primary goal of saving the world or of solving problems. Such an expectation would have a significant bad influence on the development of sciences. Correct me if I’m wrong but I see it that we engage in science because of our interest and curiosity about the nature of the world we live in. That is the major drivong force for the most important discoveries we know of.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4621ee227888d6120e7ee3b02d6656f1d378143d2fa6d4618186b499962a5b44-52d6b312f6abbe4d19dccde31339da2d96cd53bd446b34006f543ca49b0caac3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2020/03/04/illustrating-the-impact-of-the-mathematical-sciences/#comment-543267")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2020")])]

#text("Think of this as a mathematicians’ PR campaign to convince the people who control the money spigot that math does have some real world usefulness.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16a8967c1e9c778177283e862347313e359f4ec8a94432259f164768abbe4d66-add38f023258e8054c5dd91237a856b3ea53bc730e87d5fe9e3a7ed09b8314e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bhupinder Singh Anand")]], [#link("https://terrytao.wordpress.com/2020/03/04/illustrating-the-impact-of-the-mathematical-sciences/#comment-543304")[#strong[#text("Bhupinder Singh Anand")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2020")])]

#text("Dear Terry,")

#text("Permit me to interject a cautionary observation—from the perspective of the paper (link [1] below) which appeared in the December 2016 issue of ‘Cognitive Systems Research’, and the forthcoming book (link [2] below)—that the more pressing/appropriate project for the immediate future should be:")

#text("‘Why the mathematical sciences are no longer impacting as they did/should, why the situation is critical, and what needs to be done urgently’")

#text("The paper [1] answers the first by illustrating that, as in the case of the Emperor’s illusory clothing, the mathematical sciences today venerate a similar Goedelian illusion of ‘meaningfulness’ for cloaking formal proofs that cannot interpret as truths under any evidence-based interpretation.")

#text("It is an illusion that fosters teaching, study, and research, of theses that are essentially not falsifiable; hence incapable of impacting upon, and with expectedly diminishing intellectual and economic returns to, the society that such activities seek to serve.")

#text("The book [2] seeks to highlight the critical consequences of reviewing the mathematical sciences through the lens of evidence-based reasoning; and what might conceivably be at stake.")

#text("Sincerely,")

#text("Bhupinder Singh Anand")

#text("References")#linebreak()#text(" ==========")#linebreak()#text(" [1] CSR paper: ‘The truth assignments that differentiate human reasoning from mechanistic reasoning: The evidence-based argument for Lucas’ G\\”{o}delian thesis’")#linebreak()#text(" ")#link("https://www.sciencedirect.com/science/article/pii/S1389041716300250?via%3Dihub")[#text("https://www.sciencedirect.com/science/article/pii/S1389041716300250?via%3Dihub")]

#text("[2] Book (under final revision/indexing): ‘The Significance of Evidence-based Reasoning for Mathematics, Mathematics Education, Philosophy and the Natural Sciences’")#linebreak()#text(" ")#link("https://www.dropbox.com/s/gd6ffwf9wssak86/16_Anand_Dogmas_Submission_Update_3.pdf?dl=0")[#text("https://www.dropbox.com/s/gd6ffwf9wssak86/16_Anand_Dogmas_Submission_Update_3.pdf?dl=0")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c1884fc446f7aa2bcbdf6379cf0d6dad4a39952c8fb881e7743661e315f279c-78721a91ae9eb3829ec12993708a8dd55452c8d82d5c1f3e94733d82d6bccd60.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Bond Singh")]], [#link("https://terrytao.wordpress.com/2020/03/04/illustrating-the-impact-of-the-mathematical-sciences/#comment-545766")[#strong[#text("James Bond Singh")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2020")])]

#text("It is taught in high school that mathematical truths are a priori knowledge so how do people still get paid to spend their life doing ”research” on whether it is evidence based lol, oh wait, maybe they don’t 😂")#linebreak()#text(" Maybe no one cares about your research because it asks completely wrong questions while being blind to overwhelming evidence towards the right questions such as")#linebreak()#text(" “How is it that mathematicians have a ﬁrm grip on concepts such as `inﬁnity` and `continuous function`, while speculative philosophers continue talking in circles after millennia?” or")#linebreak()#text(" “why is mathematics so effective in sciences?”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9566005ebf7f21b2b7561c38b5da4cc0cad024fbfee83322a1315850dfc0e7eb-ec9e4d458a1dec2cc6656df29423635c406ce277483f4c5c7bb72fcb3bfa0364.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leandro Recova")]], [#link("https://terrytao.wordpress.com/2020/03/04/illustrating-the-impact-of-the-mathematical-sciences/#comment-544137")[#strong[#text("Leandro Recova")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2020")])]

#text("This is a great initiative.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb5ce4a153a3093c8fb489ea32231f03404b265cbcdf61d1d87b8a8d075f3229-8d909e578e27d85ffb4ab188360385187dd42b30cc0e1c1936c15af4c83ac1b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dat")]], [#link("https://terrytao.wordpress.com/2020/03/04/illustrating-the-impact-of-the-mathematical-sciences/#comment-546588")[#strong[#text("Dat")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2020")])]

#text("Y’ + xy/x^2 + 1 = xy^2/x^2 + 1")#linebreak()#text(" Help me !!")
]
