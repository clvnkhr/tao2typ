// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/08/20/quantitative-bounds-for-sets-lacking-polynomial-progressions-with-shifted-prime-difference/
// Converted to Typst by tao2typ: "2026-10-14T16:39:26.459766+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Quantitative bounds for sets lacking polynomial progressions with shifted prime difference", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Quantitative bounds for sets lacking polynomial progressions with shifted prime difference")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 August 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/08/20/quantitative-bounds-for-sets-lacking-polynomial-progressions-with-shifted-prime-difference/")[#text("https://terrytao.wordpress.com/2026/08/20/quantitative-bounds-for-sets-lacking-polynomial-progressions-with-shifted-prime-difference/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Ben Krause, Hamed Mousavi, Joni Teräiväinen, and I have just uploaded to the arXiv our paper ")#link("http://arxiv.org/abs/2608.19525")[#text("Quantitative bounds for sets lacking polynomial progressions with shifted prime difference")]#text(". The purpose of this paper is to obtain quantitative versions of this ")#link("https://zbmath.org/1355.11005")[#text("theorem of Wooley and Ziegler")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" Let ")#mi("{P_1,\\dots,P_{k-1} \\in {\\bf Z}[y]}")#text(" be polynomials of one variable ")#mi("{y}")#text(" with integer coefficients with zero constant term, and let ")#mi("{A}")#text(" be a set of integers of positive density. Then there exist infinitely many primes ")#mi("{p}")#text(" such that ")#mi("{A}")#text(" contains a progression of the form")

#align(center)[#tao-fit-display[#mitex("a, a+P_1(p-1), \\dots, a+P_{k-1}(p-1)")]]

#text("for some integer ")#mi("{a}")#text(".")
]

#text("This generalizes the famous ")#link("https://en.wikipedia.org/wiki/Szemer%C3%A9di%27s_theorem")[#text("theorem of Szemerédi")]#text(" in two ways: firstly, by considering “polynomial progressions” instead of arithmetic progressions, and secondly by requiring the shift parameter to be one less than a prime ")#mi("{p}")#text(". The first extension of Szemerédi’s theorem is a ")#link("https://zbmath.org/0870.11015")[#text("theorem of Bergelson and Leibman")]#text("; and the second extension is also obtainable by combining the ")#link("https://zbmath.org/1126.37005")[#text("arguments of Frantzikinakis, Host and Kra")]#text(" with the results ")#link("https://zbmath.org/1242.11071")[#text("of Green")]#text(", ")#link("https://zbmath.org/1247.11017")[#text("Ziegler")]#text(", ")#link("https://zbmath.org/1347.37019")[#text("and myself")]#text(".")

#text("The proof of the above theorem uses ergodic theory, which makes it difficult to extract quantitative bounds from it; and standard methods of “finitizing” ergodic theory results, for instance by replacing Host–Kra seminorms by their Gowers uniformity norm counterparts, run into a number of technical difficulties here due to the need to work with multiple scales due to the presence of polynomials, as well as the fact that many of the conjectural uniformity properties of the prime numbers at small scales remain unproven.")

#text("Nevertheless, we are able to get reasonable quantitative results (with density bounds that are roughly single or doubly logarithmic in scale) in the following special cases:")

#list(
[#text("linear polynomials;")],
[#text("polynomials of distinct degree; and")],
[#text("multiples of a fixed polynomial.")]
)

#text("The precise statements are slightly technical and not reproduced here.")

#text("Previous quantitative bounds in the linear case were obtained ")#link("https://arxiv.org/abs/2212.09635")[#text("by Leng")]#text(" and ")#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/")[#text("by Teräväinen and myself")]#text(", but our new method improves upon these bounds by roughly one iterated logarithm. On the other hand, in the case of two term progressions of spacing ")#mi("{p-1}")#text(", there is a much stronger quantitative result (with polynomial dependence of constants) ")#link("https://arxiv.org/abs/2206.08001")[#text("due to Green")]#text("; our method do not recover that result.")

#text("Our methods use a variety of old and new methods in the subject. For instance, we use the (now quite standard) “")#mi("{W}")#text("-trick” to restrict the primes to a single congruence class to improve their uniformity properties (which, thanks to the recent work ")#link("https://arxiv.org/abs/2312.10772")[#text("of Leng")]#text(" and ")#link("https://zbmath.org/8205248")[#text("Matthiesen–Teräväinen–Wang")]#text(", are now quite strong quantitatively); and for good configurations of polynomials, one can also use a ")#link("https://arxiv.org/abs/2506.13010")[#text("recent transference theorem of Altman and Sawhney")]#text(" to compare the polynomial averages with simpler linear ones, without having to pass to short scales. In order to get relatively strong bounds unconditionally, a “Siegel approximation” for the primes is used taking into account the potential influence of a Siegel zero. It will not be surprising to the experts that quantitative inverse Gowers theorems and nilsequence equidistribution theorems also play a major role.")

#text("A key technical difficulty is the presence of the ")#mi("{W}")#text(" modulus in the coefficients of the polynomial progressions after changes of variable, which forced us to make several of the existing estimates uniform over such coefficients (assuming they are not unreasonably large).This caused several complications that made a correct argument to more time-consuming to locate than initially planned.")

#text("AI usage in this work was fairly light, being restricted to proofreading and literature search only.")

#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62f5e75dd5d1b84462a93fda2757d25279ed40d7abfe639eb97c2d3c4360bac0-20128771c050417854a2a39358afc5479821fc71248c3788ac63054a269a920d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim Ktitarev")]], [#link("https://terrytao.wordpress.com/2026/08/20/quantitative-bounds-for-sets-lacking-polynomial-progressions-with-shifted-prime-difference/#comment-694045")[#strong[#text("Tim Ktitarev")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2026")])]

#text("Typo:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The purpose of this paper is to obtain ")#emph[#text("quantative")]#text(" versions […]")
]

#text("And:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("[…] for good configurations of configurations […]")
]

#text("Perhaps you mean good configurations of polynomials?")

#text("You write that AI usage was only light. Was it not effective in this problem, or just not needed because it was relatively clear on how to proceed? Or maybe it was simply fun to work out the details without AI?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/20/quantitative-bounds-for-sets-lacking-polynomial-progressions-with-shifted-prime-difference/#comment-694047")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2026")])]

#text("Thanks for the corrections.")

#text("This project was started as a traditional (non-AI assisted) collaboration. While it did take several months to complete due to a number of technical challenges as noted in the blog post, we did learn a lot from resolving them by hand. Increased AI use may have allowed us to reach our goals faster, at the cost of reduced understanding of the material, but nobody on our collaboration proposed taking this tradeoff.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0f7c7ad06e697fbe5ee8824464a13ca9e0351b393ef4b2a9ebe6a8c8900dba5-d55c28a7783f11fd299245299491e38d844c474a48cc2b9d89acc6089567d5e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2026/08/20/quantitative-bounds-for-sets-lacking-polynomial-progressions-with-shifted-prime-difference/#comment-694050")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2026")])]

#text("Prompted by this work, I have been doing a small computational experiment today on the construction side, particularly the two-term quadratic case")

#mi("x, \\quad x+(p-1)^2")#text(".")

#text("The question is: for a given ")#mi("X")#text(", how dense can a periodic set be while avoiding ")#mi("(p-1)^2")#text(" as a difference for every prime ")#mi("p \\leq X")#text("? I wrote a search/certification tool here:")

#link("https://github.com/michaelmross/shifted-prime-patterns")[#text("https://github.com/michaelmross/shifted-prime-patterns")]

#text("Some initial examples are a density 2/5 construction for ")#mi("X=10")#text(" (optimal among periods at most 80), 16/69 for ")#mi("X=30")#text(", and 1/74 for ")#mi("X=10^4")#text(". The latter is a period-3848 set whose avoidance of every prime up to ")#mi("10^4")#text(" is checked exactly.")

#text("This is of course only finite computational evidence, but I thought these constructions might be useful lower-bound benchmarks for the quantitative question. Are substantially better constructions of this type already known?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0f7c7ad06e697fbe5ee8824464a13ca9e0351b393ef4b2a9ebe6a8c8900dba5-d55c28a7783f11fd299245299491e38d844c474a48cc2b9d89acc6089567d5e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2026/08/20/quantitative-bounds-for-sets-lacking-polynomial-progressions-with-shifted-prime-difference/#comment-694152")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2026")])]

#text("I continued my experiment, and the search has been extended considerably with computational certificates.")

#text("For ")#mi("x,x+(p-1)^2")#text(", the best certified densities track ")#mi("X^{-1/2}")#text(" remarkably well through ")#mi("X=10^5")#text(" (equivalently ")#mi("N^{-1/4}")#text(" under ")#mi("N=X^2")#text("), then bend downward. ")#mi("\\delta(X)\\sqrt {X}")#text(" falls from the earlier range ")#mi("1.26")#text("–")#mi("2.18")#text(" to ")#mi("0.94")#text(" at ")#mi("3\\cdot10^5")#text(" and ")#mi("0.84")#text(" at ")#mi("10^6")#text(". The latter survives a blind sweep of all periods to ")#mi("400000")#text(".")

#text("For the model three-term configuration ")#mi("x,x+(p-1),x+(p-1)^2")#text(", the corresponding lower-bound profile initially follows roughly ")#mi("1.1X^{-0.267}")#text(", and then bends similarly. Interestingly, the arithmetic behind the two families appears quite different, so it is not yet clear whether the common bend reflects finite-scale depletion or a genuine change of exponent.")

#text("Summary with figures and link to repo data and certificates: ")#link("https://michaelmross.github.io/shifted-prime-patterns.html")[#text("https://michaelmross.github.io/shifted-prime-patterns.html")]
]
]
