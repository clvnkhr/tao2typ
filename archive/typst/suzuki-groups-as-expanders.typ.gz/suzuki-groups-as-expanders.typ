// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/05/06/suzuki-groups-as-expanders/
// Converted to Typst by tao2typ: "2026-10-14T08:58:53.617895+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Suzuki groups as expanders", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Suzuki groups as expanders")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 May 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/05/06/suzuki-groups-as-expanders/")[#text("https://terrytao.wordpress.com/2010/05/06/suzuki-groups-as-expanders/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#link("http://www.math.u-psud.fr/~breuilla/indexgb.html")[#text("Emmanuel Breuillard")]#text(", ")#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(", and I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" the paper “")#link("http://arxiv.org/abs/1005.0782")[#text("Suzuki groups as expanders")]#text("“, to be submitted. The purpose of this paper is to finish off the last case of the following theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (All finite simple groups have expanders)")]#text(" For every finite simple non-abelian group ")#mi("{G}")#text(", there exists a set of generators ")#mi("{S}")#text(" of cardinality bounded uniformly in ")#mi("{G}")#text(", such that the Cayley graph ")#mi("{\\text{Cay}(G,S)}")#text(" on ")#mi("{G}")#text(" generated by ")#mi("{S}")#text(" (i.e. the graph that connects ")#mi("{g}")#text(" with ")#mi("{sg}")#text(" for all ")#mi("{g \\in G}")#text(" and ")#mi("{s \\in S}")#text(") has expansion constant bounded away from zero uniformly in ")#mi("{G}")#text(", or equivalently that ")#tao-math("{\\left|A \\cdot S\\right| \\geq (1+\\epsilon) \\left|A\\right|}", block: false)#text(" for all ")#mi("{A \\subset G}")#text(" with ")#tao-math("{\\left|A\\right| < \\left|G\\right|/2}", block: false)#text(" and some ")#mi("{\\epsilon>0}")#text(" independent of ")#mi("{G}")#text(".")
]

#text("To put in an essentially equivalent way, one can quickly generate a random element of a finite simple group with a near-uniform distribution by multiplying together a few (")#tao-math("{O(\\log \\left|G\\right|)}", block: false)#text(", to be more precise) randomly chosen elements of a fixed set ")#mi("{S}")#text(". (The most well-known instance of this phenomenon is the ")#link("http://www.jstor.org/pss/2959752")[#text("famous result of Bayer and Diaconis")]#text(" that one can shuffle a 52-card deck reasonably well after seven riffle shuffles, and almost perfectly after ten.) Note that the abelian simple groups ")#mi("{{\\bf Z}/p{\\bf Z}}")#text(" do not support expanders due to the slow mixing time of random walks in the abelian setting.")

#text("The first step in proving this theorem is, naturally enough, the ")#link("http://en.wikipedia.org/wiki/Classification_of_finite_simple_groups")[#text("classification of finite simple groups")]#text(". The sporadic groups have bounded cardinality and are a trivial case of this theorem, so one only has to deal with the seventeen infinite families of finite non-abelian simple groups. With one exception, the groups ")#mi("{G}")#text(" in all of these families contain a copy of ")#mi("{SL_2({\\bf F}_q)}")#text(" for some ")#mi("{q}")#text(" that goes to infinity as ")#tao-math("{\\left|G\\right| \\rightarrow \\infty}", block: false)#text(". Using this and several other non-trivial tools (such as ")#link("http://en.wikipedia.org/wiki/Kazhdan's_property_(T)")[#text("Kazhdan’s property (T)")]#text(" and a deep ")#link("http://www.ams.org/mathscinet-getitem?mr=1329903")[#text("model-theoretic result of Hrushovski and Pillay")]#text("), the above theorem was proven for all groups outside of this exceptional family by a series of works culminating in the ")#link("http://www.ams.org/mathscinet-getitem?mr=2221038")[#text("paper of Kassabov, Lubotzky, and Nikolov")]#text(".")

#text("The exceptional family is the family of ")#link("http://en.wikipedia.org/wiki/Suzuki-Ree_groups#Suzuki.E2.80.93Ree_groups")[#text("Suzuki groups")]#text(" ")#mi("{Sz(q)}")#text(", where ")#mi("{q = 2^{2n+1}}")#text(" is an odd power of ")#mi("{2}")#text(". The Suzuki group ")#mi("{Sz(q)}")#text(" can be viewed explicitly as a subgroup of the symplectic group ")#mi("{Sp_4(q)}")#text(" and has cardinality ")#mi("{q^2 (q^2+1)(q-1) \\approx q^5}")#text(". This cardinality is not divisible by ")#mi("{3}")#text(", whereas all groups of the form ")#mi("{SL_2(k)}")#text(" have cardinality divisible by ")#mi("{3}")#text("; thus Suzuki groups do not contain copies of ")#mi("{SL_2}")#text(" and the Kassabov-Lubotsky-Nikolov argument does not apply.")

#text("Our main result is that the Suzuki groups also support expanders, thus completing the last case of the above theorem. In fact we can pick just two random elements ")#mi("{a, b}")#text(" of the Suzuki group, and with probability ")#mi("{1-o_{q \\rightarrow \\infty}(1)}")#text(", the Cayley graph generated by ")#mi("{S = \\{a,b,a^{-1},b^{-1}\\}}")#text(" will be an expander uniformly in ")#mi("{q}")#text(". (As stated in the paper of Kassabov-Lubotsky-Nikolov, the methods in that paper should give an upper bound on ")#mi("{S}")#text(" which they conservatively estimate to be ")#mi("{1000}")#text(".)")

#text("Our methods are different, instead following closely the ")#link("http://www.ams.org/mathscinet-getitem?mr=2415383")[#text("arguments of Bourgain and Gamburd")]#text(", which established the analogue of our result (i.e. that two random elements generate an expander graph) for the family of groups ")#mi("{SL_2({\\bf F}_p)}")#text(" (")#mi("{p}")#text(" a large prime); the arguments there have since been generalised to several other major families of groups, and our result here can thus be viewed as one further such generalisation. Roughly speaking, the strategy is as follows. Let ")#mi("{\\mu}")#text(" be the uniform probability measure on the randomly chosen set of generators ")#mi("{S}")#text(", and let ")#mi("{\\mu^{(n)}}")#text(" be the ")#mi("{n}")#text("-fold convolution. We need ")#mi("{\\mu^{(n)}}")#text(" to converge rapidly to the uniform measure on ")#mi("{G}")#text(" (with a mixing time of ")#tao-math("{O(\\log \\left|G\\right|)}", block: false)#text("). There are three steps to obtain this mixing:")

#list(
[#text("(Early period) When ")#tao-math("{n \\sim c \\log \\left|G\\right|}", block: false)#text(" for some small ")#mi("{c > 0}")#text(", one wants ")#mi("{\\mu^{(n)}}")#text(" to spread out a little bit in the sense that no individual element of ")#mi("{G}")#text(" is assigned a mass of any more than ")#tao-math("{\\left|G\\right|^{-\\epsilon}}", block: false)#text(" for some fixed ")#mi("{\\epsilon > 0}")#text(". More generally, no proper subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(" should be assigned a mass of more than ")#tao-math("{\\left|G\\right|^{-\\epsilon}}", block: false)#text(".")],
[#text("(Middle period) Once ")#mi("{\\mu^{(n)}}")#text(" is somewhat spread out, one should be able to convolve this measure with itself a bounded number of times and conclude that the measure ")#mi("{\\mu^{(Cn)}}")#text(" for some suitable ")#mi("{C}")#text(" is reasonably spread out in the sense that its ")#mi("{L^2}")#text(" norm is comparable (up to powers of ")#tao-math("{\\left|G\\right|^{\\epsilon}}", block: false)#text(" for some small ")#mi("{\\epsilon > 0}")#text(") to the ")#mi("{L^2}")#text(" norm of the uniform distribution.")],
[#text("(Late period) Once ")#mi("{\\mu^{(n)}}")#text(" is reasonably spread out, a few more convolutions should make it extremely close to uniform (e.g. within ")#tao-math("{\\left|G\\right|^{-10}}", block: false)#text(" in the ")#mi("{L^\\infty}")#text(" norm).")]
)

#text("The late period claim is easy to establish from ")#link("http://www.ams.org/mathscinet-getitem?mr=2410393")[#text("Gowers’ theory of quasirandom groups")]#text(", the key point being that (like all other finite simple nonabelian groups), the Suzuki groups do not admit any non-trivial low-dimensional irreducible representations (we can for instance use a precise lower bound of ")#mi("{\\gg q^{3/2}}")#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=360852")[#text("due to Landazuri and Seitz")]#text("). (One can also proceed here using a trace formula argument ")#link("http://www.ams.org/mathscinet-getitem?mr=1131400")[#text("of Sarnak and Xue")]#text("; the two approaches are basically equivalent.) The middle period reduces, by a variant of the ")#emph[#text("Balog-Szemerédi-Gowers lemma")]#text(", to a product estimate in ")#mi("{Sz(q)}")#text(" which was recently established ")#link("http://arxiv.org/abs/1001.4556")[#text("by Pyber-Szábo")]#text(" and can also be obtained by the methods of proof of the results announced ")#link("https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/")[#text("by ourselves")]#text(". (These arguments are in turn based on an earlier ")#link("http://www.ams.org/mathscinet-getitem?mr=2415382")[#text("result of Helfgott")]#text(" establishing the analogous claim for ")#mi("{SL_2({\\bf F}_p)}")#text(".) This requires checking that ")#mi("{Sz(q)}")#text(" is a “sufficiently Zariski dense” subgroup of the finite Lie group ")#mi("{Sp_4(q)}")#text(", but this can be done using an explicit description of the Suzuki group and the ")#link("http://en.wikipedia.org/wiki/Schwartz%E2%80%93Zippel_lemma")[#text("Schwartz-Zippel lemma")]#text(".")

#text("The main difficulty is then to deal with the early period, obtaining some initial non-concentration in the random walk associated to ")#mi("{S}")#text(" away from subgroups ")#mi("{H}")#text(" of ")#mi("{Sz(q)}")#text(". These subgroups have been classified for some time (see e.g. the ")#link("http://www.ams.org/mathscinet-getitem?mr=2562037")[#text("book of Wilson")]#text("); they split into two families, the ")#emph[#text("algebraic subgroups")]#text(", which in the Suzuki case turn out to be solvable of derived length at most three, and the ")#emph[#text("arithmetic subgroups")]#text(", which are conjugate to ")#mi("{Sz(q_0)}")#text(", where ")#mi("{{\\bf F}_{q_0}}")#text(" is a subfield of ")#mi("{{\\bf F}_q}")#text(".")

#text("In the algebraic case, one can prevent concentration using a lower bound on the girth of random Cayley graphs ")#link("http://www.ams.org/mathscinet-getitem?mr=2532876")[#text("due to Gamburd, Hoory, Shahshahani, Shalev, and Virág")]#text(" (and we also provide an independent proof of this fact for completeness, which fortunately is able to avoid any really deep technology, such as Lang-Weil estimates); this follows an analogous argument of Bourgain-Gamburd in the ")#mi("{SL_2}")#text(" case fairly closely, and is ultimately based on the fact that all the algebraic subgroups obey a fixed law (in this case, the law arises from the solvability). In the arithmetic case, the main task is to show that the coefficients of the characteristic polynomial of a typical word in ")#mi("{S}")#text(" does not fall into a proper subfield of ")#mi("{{\\bf F}_q}")#text(", but this can be accomplished by a variant of the Schwartz-Zippel lemma.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2010/05/06/suzuki-groups-as-expanders/#comment-44689")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2010")])]

#text("The famous result about card shuffling you refer to is actually in ")#link("http://www.jstor.org/stable/2959752")[#text("this paper of Bayer and Diaconis")]#text(". It’s also an overstatement to say you can shuffle “almost perfectly” in seven riffles. See the table on p. 296, which shows that up to 5 shuffles are essentially worthless, and 10 or so are almost perfect. The famous 7 is a somewhat arbitrary choice in that range.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/05/06/suzuki-groups-as-expanders/#comment-44690")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2010")])]

#text("Missing “paper” tag")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/05/06/suzuki-groups-as-expanders/#comment-44692")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2010")])]

#text("Thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Approximate subgroups of linear subgroups « What’s new")]], [#link("https://terrytao.wordpress.com/2010/05/06/suzuki-groups-as-expanders/#comment-44810")[#strong[#text("Approximate subgroups of linear subgroups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2010")])]

#text("[…] diameter at most. Applications to expanders include the result on Suzuki groups mentioned in a previous post; further applications will appear in a forthcoming […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Expansion in finite simple groups of Lie type | What's new")]], [#link("https://terrytao.wordpress.com/2010/05/06/suzuki-groups-as-expanders/#comment-244505")[#strong[#text("Expansion in finite simple groups of Lie type | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2013")])]

#text("[…] random Cayley graphs. This result had previously been established for by Bourgain and Gamburd, and Ben, Emmanuel and I had used the Bourgain-Gamburd method to achieve the same result for Suzuki groups. For the other finite […]")
]
