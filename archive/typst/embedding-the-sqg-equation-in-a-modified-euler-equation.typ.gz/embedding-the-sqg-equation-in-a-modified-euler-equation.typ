// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/04/19/embedding-the-sqg-equation-in-a-modified-euler-equation/
// Converted to Typst by tao2typ: "2026-10-14T10:24:26.988040+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Embedding the SQG equation in a modified Euler equation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Embedding the SQG equation in a modified Euler equation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 April 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/04/19/embedding-the-sqg-equation-in-a-modified-euler-equation/")[#text("https://terrytao.wordpress.com/2015/04/19/embedding-the-sqg-equation-in-a-modified-euler-equation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("http://en.wikipedia.org/wiki/Euler_equations_(fluid_dynamics)")[#text("Euler equations")]#text(" for three-dimensional incompressible inviscid fluid flow are ")#metadata(none) <tao-c23c23a7c71feb7e0bd8>

#tao-aligned(keep: true)[


#tao-math("\\partial_t u + (u \\cdot \\nabla) u  & = - \\nabla p", block: true, numbering: n => [#text("(1)")])



#tao-math("\\nabla \\cdot u  & = 0", block: true)
]

#text("where ")#mi("{u: {\\bf R} \\times {\\bf R}^3 \\rightarrow {\\bf R}^3}")#text(" is the velocity field, and ")#mi("{p: {\\bf R} \\times {\\bf R}^3 \\rightarrow {\\bf R}}")#text(" is the pressure field. For the purposes of this post, we will ignore all issues of decay or regularity of the fields in question, assuming that they are as smooth and rapidly decreasing as needed to justify all the formal calculations here; in particular, we will apply inverse operators such as ")#mi("{(-\\Delta)^{-1}}")#text(" or ")#tao-math("{\\left|\\nabla\\right|^{-1} := (-\\Delta)^{-1/2}}", block: false)#text(" formally, assuming that these inverses are well defined on the functions they are applied to.")

#text("Meanwhile, the ")#link("https://www.ma.utexas.edu/mediawiki/index.php/Surface_quasi-geostrophic_equation")[#text("surface quasi-geostrophic")]#text(" (SQG) equation is given by ")#metadata(none) <tao-80ce03380a8bc51b81a9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\partial_t \\theta + (u \\cdot \\nabla) \\theta = 0")]]

#metadata(none) <tao-c1b3d84d9366c67e74fb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("u = ( -\\partial_y \\left|\\nabla\\right|^{-1}, \\partial_x \\left|\\nabla\\right|^{-1} ) \\theta", block: true)]]

#text("where ")#mi("{\\theta: {\\bf R} \\times {\\bf R}^2 \\rightarrow {\\bf R}}")#text(" is the active scalar, and ")#mi("{u: {\\bf R} \\times {\\bf R}^2 \\rightarrow {\\bf R}^2}")#text(" is the velocity field. The SQG equations are often used as a toy model for the 3D Euler equations, as they share many of the same features (e.g. vortex stretching); see ")#link("http://www.ams.org/mathscinet-getitem?mr=1252829")[#text("this paper of Constantin, Majda, and Tabak")]#text(" for more discussion (or ")#link("https://terrytao.wordpress.com/2014/03/06/conserved-quantities-for-the-surface-quasi-geostrophic-equation/")[#text("this previous blog post")]#text(").")

#text("I recently found a more direct way to connect the two equations. We first recall that the Euler equations can be placed in ")#emph[#text("vorticity-stream")]#text(" form by focusing on the vorticity ")#mi("{\\omega := \\nabla \\times u}")#text(". Indeed, taking the curl of ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(1)")]#text(", we obtain the ")#link("http://en.wikipedia.org/wiki/Vorticity_equation")[#text("vorticity equation")]#text(" ")#metadata(none) <tao-9b65d81e40811c75a092>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\partial_t \\omega + (u \\cdot \\nabla) \\omega = (\\omega \\cdot \\nabla) u")]]

#text("while the velocity ")#mi("{u}")#text(" can be recovered from the vorticity via the ")#link("http://en.wikipedia.org/wiki/Biot%E2%80%93Savart_law")[#text("Biot-Savart law")]#text(" ")#metadata(none) <tao-5975baa1903491a53c35>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("u = (-\\Delta)^{-1} \\nabla \\times \\omega.")]]

#text("The system ")#link(<tao-9b65d81e40811c75a092>)[#text("(4)")]#text(", ")#link(<tao-5975baa1903491a53c35>)[#text("(5)")]#text(" has some features in common with the system ")#link(<tao-80ce03380a8bc51b81a9>)[#text("(2)")]#text(", ")#link(<tao-c1b3d84d9366c67e74fb>)[#text("(3)")]#text("; in ")#link(<tao-80ce03380a8bc51b81a9>)[#text("(2)")]#text(" it is a scalar field ")#mi("{\\theta}")#text(" that is being transported by a divergence-free vector field ")#mi("{u}")#text(", which is a linear function of the scalar field as per ")#link(<tao-c1b3d84d9366c67e74fb>)[#text("(3)")]#text(", whereas in ")#link(<tao-9b65d81e40811c75a092>)[#text("(4)")]#text(" it is a vector field ")#mi("{\\omega}")#text(" that is being transported (in the ")#link("http://en.wikipedia.org/wiki/Lie_derivative")[#text("Lie derivative")]#text(" sense) by a divergence-free vector field ")#mi("{u}")#text(", which is a linear function of the vector field as per ")#link(<tao-5975baa1903491a53c35>)[#text("(5)")]#text(". However, the system ")#link(<tao-9b65d81e40811c75a092>)[#text("(4)")]#text(", ")#link(<tao-5975baa1903491a53c35>)[#text("(5)")]#text(" is in three dimensions whilst ")#link(<tao-80ce03380a8bc51b81a9>)[#text("(2)")]#text(", ")#link(<tao-c1b3d84d9366c67e74fb>)[#text("(3)")]#text(" is in two spatial dimensions, the dynamical field is a scalar field ")#mi("{\\theta}")#text(" for SQG and a vector field ")#mi("{\\omega}")#text(" for Euler, and the relationship between the velocity field and the dynamical field is given by a zeroth order Fourier multiplier in ")#link(<tao-c1b3d84d9366c67e74fb>)[#text("(3)")]#text(" and a ")#mi("{-1^{th}}")#text(" order operator in ")#link(<tao-5975baa1903491a53c35>)[#text("(5)")]#text(".")

#text("However, we can make the two equations more closely resemble each other as follows. We first consider the generalisation ")#metadata(none) <tao-901e70671554de90a082>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\partial_t \\omega + (u \\cdot \\nabla) \\omega = (\\omega \\cdot \\nabla) u")]]

#metadata(none) <tao-feec84fd3f6b5522763d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("u = T (-\\Delta)^{-1} \\nabla \\times \\omega")]]

#text("where ")#mi("{T}")#text(" is an invertible, self-adjoint, positive-definite zeroth order Fourier multiplier that maps divergence-free vector fields to divergence-free vector fields. The Euler equations then correspond to the case when ")#mi("{T}")#text(" is the identity operator. As discussed in ")#link("https://terrytao.wordpress.com/2014/03/06/conserved-quantities-for-the-surface-quasi-geostrophic-equation/")[#text("this previous blog post")]#text(" (which used ")#mi("{A}")#text(" to denote the inverse of the operator denoted here as ")#mi("{T}")#text("), this generalised Euler system has many of the same features as the original Euler equation, such as a conserved Hamiltonian")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} \\int_{{\\bf R}^3} u \\cdot T^{-1} u,")]]

#text("the ")#link("http://en.wikipedia.org/wiki/Kelvin%27s_circulation_theorem")[#text("Kelvin circulation theorem")]#text(", and conservation of ")#link("http://en.wikipedia.org/wiki/Hydrodynamical_helicity")[#text("helicity")]

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^3} \\omega \\cdot T^{-1} u.")]]

#text("Also, if we require ")#mi("{\\omega}")#text(" to be divergence-free at time zero, it remains divergence-free at all later times.")

#text("Let us consider “two-and-a-half-dimensional” solutions to the system ")#link(<tao-901e70671554de90a082>)[#text("(6)")]#text(", ")#link(<tao-feec84fd3f6b5522763d>)[#text("(7)")]#text(", in which ")#mi("{u,\\omega}")#text(" do not depend on the vertical coordinate ")#mi("{z}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\omega(t,x,y,z) = \\omega(t,x,y)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("u(t,x,y,z) = u(t,x,y)")]]

#text("but we allow the vertical components ")#mi("{u_z, \\omega_z}")#text(" to be non-zero. For this to be consistent, we also require ")#mi("{T}")#text(" to commute with translations in the ")#mi("{z}")#text(" direction. As all derivatives in the ")#mi("{z}")#text(" direction now vanish, we can simplify ")#link(<tao-901e70671554de90a082>)[#text("(6)")]#text(" to ")#metadata(none) <tao-f3cf3f52140e146702cb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("D_t \\omega = (\\omega_x \\partial_x + \\omega_y \\partial_y) u")]]

#text("where ")#mi("{D_t}")#text(" is the two-dimensional material derivative")

#align(center)[#tao-fit-display[#mitex("D_t := \\partial_t + u_x \\partial_x + u_y \\partial_y.")]]

#text("Also, divergence-free nature of ")#mi("{\\omega,u}")#text(" then becomes")

#align(center)[#tao-fit-display[#mitex("\\partial_x \\omega_x + \\partial_y \\omega_y = 0")]]

#text("and ")#metadata(none) <tao-ce3659cc128ebd782745>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\partial_x u_x + \\partial_y u_y = 0.")]]

#text("In particular, we may (formally, at least) write")

#align(center)[#tao-fit-display[#mitex("(\\omega_x, \\omega_y) = (\\partial_y \\theta, -\\partial_x \\theta)")]]

#text("for some scalar field ")#mi("{\\theta(t,x,y,z) = \\theta(t,x,y)}")#text(", so that ")#link(<tao-feec84fd3f6b5522763d>)[#text("(7)")]#text(" becomes ")#metadata(none) <tao-3452df462642811f533a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("u = T ( (- \\Delta)^{-1} \\partial_y \\omega_z, - (-\\Delta^{-1}) \\partial_x \\omega_z, \\theta ).")]]

#text("The first two components of ")#link(<tao-f3cf3f52140e146702cb>)[#text("(8)")]#text(" become")

#tao-aligned(keep: true)[


#tao-math("D_t \\partial_y \\theta  & = \\partial_y \\theta \\partial_x u_x - \\partial_x \\theta \\partial_y u_x", block: true)



#tao-math("- D_t \\partial_x \\theta  & = \\partial_y \\theta \\partial_x u_y - \\partial_x \\theta \\partial_y u_y", block: true)
]

#text("which rearranges using ")#link(<tao-ce3659cc128ebd782745>)[#text("(9)")]#text(" to")

#align(center)[#tao-fit-display[#mitex("\\partial_y D_t \\theta = \\partial_x D_t \\theta = 0.")]]

#text("Formally, we may integrate this system to obtain the transport equation ")#metadata(none) <tao-947d5a35ff2fe522fda5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("D_t \\theta = 0,")]]

#text("Finally, the last component of ")#link(<tao-f3cf3f52140e146702cb>)[#text("(8)")]#text(" is ")#metadata(none) <tao-e94663a4cf48108e082a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("D_t \\omega_z = \\partial_y \\theta \\partial_x u_z - \\partial_x \\theta \\partial_y u_z.")]]

#text("At this point, we make the following choice for ")#mi("{T}")#text(": ")#metadata(none) <tao-a12fc80c9c13552be405>

#tao-aligned(keep: true)[


#tao-math("T ( U_x, U_y, \\theta )  & = \\alpha (U_x, U_y, \\theta) + (-\\partial_y \\left|\\nabla\\right|^{-1} \\theta, \\partial_x \\left|\\nabla\\right|^{-1} \\theta, 0)", block: true, numbering: n => [#text("(13)")])



#tao-math(" & + P( 0, 0, \\left|\\nabla\\right|^{-1} (\\partial_y U_x - \\partial_x U_y) )", block: true)
]

#text("where ")#mi("{\\alpha > 0}")#text(" is a real constant and ")#mi("{Pu := (-\\Delta)^{-1} (\\nabla \\times (\\nabla \\times u))}")#text(" is the Leray projection onto divergence-free vector fields. One can verify that for large enough ")#mi("{\\alpha}")#text(", ")#mi("{T}")#text(" is a self-adjoint positive definite zeroth order Fourier multiplier from divergence free vector fields to divergence-free vector fields. With this choice, we see from ")#link(<tao-3452df462642811f533a>)[#text("(10)")]#text(" that")

#align(center)[#tao-fit-display[#tao-math("u_z = \\alpha \\theta - \\left|\\nabla\\right|^{-1} \\omega_z", block: true)]]

#text("so that ")#link(<tao-e94663a4cf48108e082a>)[#text("(12)")]#text(" simplifies to")

#align(center)[#tao-fit-display[#tao-math("D_t \\omega_z = - \\partial_y \\theta \\partial_x \\left|\\nabla\\right|^{-1} \\omega_z + \\partial_x \\theta \\partial_y \\left|\\nabla\\right|^{-1} \\omega_z.", block: true)]]

#text("This implies (formally at least) that if ")#mi("{\\omega_z}")#text(" vanishes at time zero, then it vanishes for all time. Setting ")#mi("{\\omega_z=0}")#text(", we then have from ")#link(<tao-3452df462642811f533a>)[#text("(10)")]#text(" that")

#align(center)[#tao-fit-display[#tao-math("(u_x,u_y,u_z) = (-\\partial_y \\left|\\nabla\\right|^{-1} \\theta, \\partial_x \\left|\\nabla\\right|^{-1} \\theta, \\alpha \\theta )", block: true)]]

#text("and from ")#link(<tao-947d5a35ff2fe522fda5>)[#text("(11)")]#text(" we then recover the SQG system ")#link(<tao-80ce03380a8bc51b81a9>)[#text("(2)")]#text(", ")#link(<tao-c1b3d84d9366c67e74fb>)[#text("(3)")]#text(". To put it another way, if ")#mi("{\\theta(t,x,y)}")#text(" and ")#mi("{u(t,x,y)}")#text(" solve the SQG system, then by setting")

#tao-aligned(keep: true)[


#tao-math("\\omega(t,x,y,z)  & := ( \\partial_y \\theta(t,x,y), -\\partial_x \\theta(t,x,y), 0 )", block: true)



#tao-math("\\tilde u(t,x,y,z)  & := ( u_x(t,x,y), u_y(t,x,y), \\alpha \\theta(t,x,y) )", block: true)
]

#text("then ")#mi("{\\omega,\\tilde u}")#text(" solve the modified Euler system ")#link(<tao-901e70671554de90a082>)[#text("(6)")]#text(", ")#link(<tao-feec84fd3f6b5522763d>)[#text("(7)")]#text(" with ")#mi("{T}")#text(" given by ")#link(<tao-a12fc80c9c13552be405>)[#text("(13)")]#text(".")

#text("We have ")#mi("{T^{-1} \\tilde u = (0, 0, \\theta)}")#text(", so the Hamiltonian ")#mi("{\\frac{1}{2} \\int_{{\\bf R}^3} \\tilde u \\cdot T^{-1} \\tilde u}")#text(" for the modified Euler system in this case is formally a scalar multiple of the conserved quantity ")#mi("{\\int_{{\\bf R}^2} \\theta^2}")#text(". The momentum ")#mi("{\\int_{{\\bf R}^3} x \\cdot \\tilde u}")#text(" for the modified Euler system is formally a scalar multiple of the conserved quantity ")#mi("{\\int_{{\\bf R}^2} \\theta}")#text(", while the vortex stream lines that are preserved by the modified Euler flow become the level sets of the active scalar that are preserved by the SQG flow. On the other hand, the helicity ")#mi("{\\int_{{\\bf R}^3} \\omega \\cdot T^{-1} \\tilde u}")#text(" vanishes, and other conserved quantities for SQG (such as the Hamiltonian ")#tao-math("{\\int_{{\\bf R}^2} \\theta \\left|\\nabla\\right|^{-1} \\theta}", block: false)#text(") do not seem to correspond to conserved quantities of the modified Euler system. This is not terribly surprising; a low-dimensional flow may well have a richer family of conservation laws than the higher-dimensional system that it is embedded in.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d20c2faf00b92e29e07961c027448d5fb3592bc4eb027a7e9f55243a7db9cd-f7f871630eb512b4f840bb9c8b184ed30c5c8883bfb9ab9ca332914b9ddebed1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Pizzo")]], [#link("https://terrytao.wordpress.com/2015/04/19/embedding-the-sqg-equation-in-a-modified-euler-equation/#comment-454242")[#strong[#text("Nick Pizzo")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2015")])]

#text("Very interesting post. Your last sentence made me think of the KdV equation, or the Nonlinear Schrodinger equation, both of which have an infinite number of conservation laws, and both of which are derived from the water wave equations, which only have a handful of conserved quantities (Benjamin and Olver 1980). This is likely a naive question, but is the reason why this happens simply that these asymptotic equations describe less phenomenon, and hence have more restrictions (ie conservation laws) on the behavior of their solutions?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35ed59a91a9f5eee989e3030b8ae1d6839b87701f933b21b72429f24b4da5e2e-13be6fe74d0789a99fc71f8fd902b3bd2f250bcdc46415ad440041a28288fc0f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ...🐺...")]], [#link("https://terrytao.wordpress.com/2015/04/19/embedding-the-sqg-equation-in-a-modified-euler-equation/#comment-454268")[#strong[#text("...🐺...")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2015")])]

#text("Reblogged this on ")#link("https://hongnhungnguyen520.wordpress.com/2015/04/22/embedding-the-sqg-equation-in-a-modified-euler-equation/")[#text("Sống trong đời sống cần có một con mèo")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6aa40aca75f3f0845049140f5d179ade797062831ea25ebbaa1f9022ea33cf1a-66ad53dd93ca1c0fc8f8191edbe97fd12c7d22993bcc08005f57eed6a18e2d2f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hicsuntdracones")]], [#link("https://terrytao.wordpress.com/2015/04/19/embedding-the-sqg-equation-in-a-modified-euler-equation/#comment-454733")[#strong[#text("hicsuntdracones")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2015")])]

#text("just to verify if LaTeX code is accepted in comments: ")#mi("\\frac{1}{2}")#text(" Sorry for the inconveniences.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Finite time blowup for an Euler-type equation in vorticity stream form | What's new")]], [#link("https://terrytao.wordpress.com/2015/04/19/embedding-the-sqg-equation-in-a-modified-euler-equation/#comment-465905")[#strong[#text("Finite time blowup for an Euler-type equation in vorticity stream form | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2016")])]

#text("[…] discussed in this previous blog post, a natural generalisation of this system of equations is the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Finite time blowup for Lagrangian modifications of the three-dimensional Euler equation | What's new")]], [#link("https://terrytao.wordpress.com/2015/04/19/embedding-the-sqg-equation-in-a-modified-euler-equation/#comment-470146")[#strong[#text("Finite time blowup for Lagrangian modifications of the three-dimensional Euler equation | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2016")])]

#text("[…] example, the surface quasi-geostrophic (SQG) equations can be written in this form, as discussed in this previous post. One can view (up to Hodge duality) as a vector potential for the velocity , so it is natural to […]")
]
