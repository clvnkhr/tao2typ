// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/07/24/deducing-the-inverse-theorem-for-the-multidimensional-gowers-norms-from-the-one-dimensional-version/
// Converted to Typst by tao2typ: "2026-10-14T16:37:44.231251+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Deducing the inverse theorem for the multidimensional Gowers norms from the one-dimensional version", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Deducing the inverse theorem for the multidimensional Gowers norms from the one-dimensional version")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 July 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/07/24/deducing-the-inverse-theorem-for-the-multidimensional-gowers-norms-from-the-one-dimensional-version/")[#text("https://terrytao.wordpress.com/2015/07/24/deducing-the-inverse-theorem-for-the-multidimensional-gowers-norms-from-the-one-dimensional-version/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This week I have been at a Banff workshop “")#link("http://www.birs.ca/events/2015/5-day-workshops/15w5013")[#text("Combinatorics meets Ergodic theory")]#text("“, focused on the combinatorics surrounding Szemerédi’s theorem and the Gowers uniformity norms on one hand, and the ergodic theory surrounding Furstenberg’s multiple recurrence theorem and the Host-Kra structure theory on the other. This was quite a fruitful workshop, and directly inspired the various posts this week on this blog. Incidentally, BIRS being as efficient as it is, videos for this week’s talks are ")#link("http://www.birs.ca/events/2015/5-day-workshops/15w5013/videos")[#text("already online")]#text(".")

#text("As mentioned in ")#link("https://terrytao.wordpress.com/2015/07/22/an-inverse-theorem-for-the-continuous-gowers-uniformity-norm/")[#text("the previous")]#text(" ")#link("https://terrytao.wordpress.com/2015/07/23/deducing-a-weak-ergodic-inverse-theorem-from-a-combinatorial-inverse-theorem/")[#text("two posts")]#text(", Ben Green, Tamar Ziegler, and myself ")#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/")[#text("proved the following")]#text(" inverse theorem for the Gowers norms:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Inverse theorem for Gowers norms)")]#text(" ")#metadata(none) <tao-6bf99799d0ef91be6c25>#text(" Let ")#mi("{N \\geq 1}")#text(" and ")#mi("{s \\geq 1}")#text(" be integers, and let ")#mi("{\\delta > 0}")#text(". Suppose that ")#mi("{f: {\\bf Z} \\rightarrow [-1,1]}")#text(" is a function supported on ")#mi("{[N] := \\{1,\\dots,N\\}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N^{s+2}} \\sum_{n,h_1,\\dots,h_{s+1} \\in {\\bf Z}} \\prod_{\\omega \\in \\{0,1\\}^{s+1}} f(n+\\omega_1 h_1 + \\dots + \\omega_{s+1} h_{s+1}) \\geq \\delta.")]]

#text("Then there exists a filtered nilmanifold ")#mi("{G/\\Gamma}")#text(" of degree ")#mi("{\\leq s}")#text(" and complexity ")#mi("{O_{s,\\delta}(1)}")#text(", a polynomial sequence ")#mi("{g: {\\bf Z} \\rightarrow G}")#text(", and a Lipschitz function ")#mi("{F: G/\\Gamma \\rightarrow {\\bf R}}")#text(" of Lipschitz constant ")#mi("{O_{s,\\delta}(1)}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_n f(n) F(g(n) \\Gamma) \\gg_{s,\\delta} 1.")]]
]

#text("There is a higher dimensional generalisation, which first appeared explicitly (in a more general form) in this ")#link("http://arxiv.org/abs/1203.2260")[#text("preprint of Szegedy")]#text(" (which used a slightly different argument than the one of Ben, Tammy, and myself; see also this previous ")#link("http://arxiv.org/abs/1010.6211")[#text("preprint of Szegedy")]#text(" with related results):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Inverse theorem for multidimensional Gowers norms)")]#text(" ")#metadata(none) <tao-79240123f42579c2c41f>#text(" Let ")#mi("{N \\geq 1}")#text(" and ")#mi("{s,d \\geq 1}")#text(" be integers, and let ")#mi("{\\delta > 0}")#text(". Suppose that ")#mi("{f: {\\bf Z}^d \\rightarrow [-1,1]}")#text(" is a function supported on ")#mi("{[N]^d}")#text(" such that ")#metadata(none) <tao-b6a0005c7e9085a729bb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{1}{N^{d(s+2)}} \\sum_{n,h_1,\\dots,h_{s+1} \\in {\\bf Z}^d} \\prod_{\\omega \\in \\{0,1\\}^{s+1}} f(n+\\omega_1 h_1 + \\dots + \\omega_{s+1} h_{s+1}) \\geq \\delta.")]]



#text(" Then there exists a filtered nilmanifold ")#mi("{G/\\Gamma}")#text(" of degree ")#mi("{\\leq s}")#text(" and complexity ")#mi("{O_{s,\\delta,d}(1)}")#text(", a polynomial sequence ")#mi("{g: {\\bf Z}^d \\rightarrow G}")#text(", and a Lipschitz function ")#mi("{F: G/\\Gamma \\rightarrow {\\bf R}}")#text(" of Lipschitz constant ")#mi("{O_{s,\\delta,d}(1)}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N^d} \\sum_{n \\in {\\bf Z}^d} f(n) F(g(n) \\Gamma) \\gg_{s,\\delta,d} 1.")]]
]

#text("The ")#mi("{d=2}")#text(" case of this theorem was recently used ")#link("http://arxiv.org/abs/1405.0241")[#text("by Wenbo Sun")]#text(". One can replace the polynomial sequence with a linear sequence if desired by using a lifting trick (essentially due to Furstenberg, but which appears explicitly in Appendix C of ")#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/")[#text("my paper with Ben and Tammy")]#text(").")

#text("In this post I would like to record a very neat and simple observation of Ben Green and Nikos Frantzikinakis, that uses the tool of Freiman isomorphisms to derive Theorem ")#link(<tao-79240123f42579c2c41f>)[#text("2")]#text(" as a corollary of the one-dimensional theorem. Namely, consider the linear map ")#mi("{\\phi: {\\bf Z}^d \\rightarrow {\\bf Z}}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("\\phi( n_1,\\dots,n_d ) := \\sum_{i=1}^d (10 N)^{i-1} n_i,")]]

#text("that is to say ")#mi("{\\phi}")#text(" is the digit string base ")#mi("{10N}")#text(" that has digits ")#mi("{n_d \\dots n_1}")#text(". This map is a linear map from ")#mi("{[N]^d}")#text(" to a subset of ")#mi("{[d 10^d N^d]}")#text(" of density ")#mi("{1/(d10^d)}")#text(". Furthermore it has the following “Freiman isomorphism” property: if ")#mi("{n, h_1,\\dots,h_{s+1}}")#text(" lie in ")#mi("{{\\bf Z}}")#text(" with ")#mi("{n + \\omega_1 h_1 + \\dots + \\omega_{s+1} h_{s+1}}")#text(" in the image set ")#mi("{\\phi( [N]^d )}")#text(" of ")#mi("{[N]^d}")#text(" for all ")#mi("{\\omega}")#text(", then there exist (unique) lifts ")#mi("{\\tilde n \\in {\\bf Z}^d, \\tilde h_1,\\dots,\\tilde h_{s+1} \\in {\\bf Z}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\tilde n + \\omega_1 \\tilde h_1 + \\dots + \\omega_{s+1} \\tilde h_{s+1} \\in [N]^d")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\phi( \\tilde n + \\omega_1 \\tilde h_1 + \\dots + \\omega_{s+1} \\tilde h_{s+1} ) = n + \\omega_1 h_1 + \\dots + \\omega_{s+1} h_{s+1}")]]

#text("for all ")#mi("{\\omega}")#text(". Indeed, the injectivity of ")#mi("{\\phi}")#text(" on ")#mi("{[N]^d}")#text(" uniquely determines the sum ")#mi("{\\tilde n + \\omega_1 \\tilde h_1 + \\dots + \\omega_{s+1} \\tilde h_{s+1}}")#text(" for each ")#mi("{\\omega}")#text(", and one can use base ")#mi("{10N}")#text(" arithmetic to verify that the alternating sum of these sums on any ")#mi("{2}")#text("-facet of the cube ")#mi("{\\{0,1\\}^{s+1}}")#text(" vanishes, which gives the claim. (In the language of additive combinatorics, the point is that ")#mi("{\\phi}")#text(" is a Freiman isomorphism of order (say) ")#mi("{8}")#text(" on ")#mi("{[N]^d}")#text(".)")

#text("Now let ")#mi("{\\tilde f: {\\bf Z} \\rightarrow [-1,1]}")#text(" be the function defined by setting ")#mi("{\\tilde f( \\phi(n) ) := f(n)}")#text(" whenever ")#mi("{n \\in [N]^d}")#text(", with ")#mi("{\\tilde f}")#text(" vanishing outside of ")#mi("{\\phi([N]^d)}")#text(". If ")#mi("{f}")#text(" obeys ")#link(<tao-b6a0005c7e9085a729bb>)[#text("(1)")]#text(", then from the above Freiman isomorphism property we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N^{d(s+2)}} \\sum_{n, h_1,\\dots,h_{s+1} \\in {\\bf Z}} \\prod_{\\omega \\in \\{0,1\\}^{s+1}} \\tilde f(n+\\omega_1 h_1 + \\dots + \\omega_{s+1} h_{s+1}) \\geq \\delta.")]]

#text("Applying the one-dimensional inverse theorem (Theorem ")#link(<tao-6bf99799d0ef91be6c25>)[#text("1")]#text("), with ")#mi("{\\delta}")#text(" reduced by a factor of ")#mi("{d 10^d}")#text(" and ")#mi("{N}")#text(" replaced by ")#mi("{d 10^d N^d}")#text(", this implies the existence of a filtered nilmanifold ")#mi("{G/\\Gamma}")#text(" of degree ")#mi("{\\leq s}")#text(" and complexity ")#mi("{O_{s,\\delta,d}(1)}")#text(", a polynomial sequence ")#mi("{g: {\\bf Z} \\rightarrow G}")#text(", and a Lipschitz function ")#mi("{F: G/\\Gamma \\rightarrow {\\bf R}}")#text(" of Lipschitz constant ")#mi("{O_{s,\\delta,d}(1)}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N^{d(s+2)}} \\sum_{n \\in {\\bf Z}} \\tilde f(n) F(g(n) \\Gamma) \\gg_{s,\\delta,d} 1")]]

#text("which by the Freiman isomorphism property again implies that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N^{d(s+2)}} \\sum_{n \\in {\\bf Z}^d} f(n) F(g(\\phi(n)) \\Gamma) \\gg_{s,\\delta,d} 1.")]]

#text("But the map ")#mi("{n \\mapsto g(\\phi(n))}")#text(" is clearly a polynomial map from ")#mi("{{\\bf Z}^d}")#text(" to ")#mi("{G}")#text(" (the composition of two polynomial maps is polynomial, see e.g. Appendix B of ")#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/")[#text("my paper with Ben and Tammy")]#text("), and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" This trick appears to be largely restricted to the case of boundedly generated groups such as ")#mi("{{\\bf Z}^d}")#text("; I do not see any easy way to deduce an inverse theorem for, say, ")#mi("{\\bigcup_{n=1}^\\infty {\\mathbb F}_p^n}")#text(" from the ")#mi("{{\\bf Z}}")#text("-inverse theorem by this method.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" By combining this argument with the one in the previous post, one can obtain a weak ergodic inverse theorem for ")#mi("{{\\bf Z}^d}")#text("-actions. Interestingly, the Freiman isomorphism argument appears to be difficult to implement directly in the ergodic category; in particular, there does not appear to be an obvious direct way to derive the Host-Kra inverse theorem for ")#mi("{{\\bf Z}^d}")#text(" actions (a result first obtained in the ")#link("https://etd.ohiolink.edu/ap/10?0::NO:10:P10_ACCESSION_NUM:osu1243973834")[#text("PhD thesis of Griesmer")]#text(") from the counterpart for ")#mi("{{\\bf Z}}")#text(" actions.")
]

#heading(level: 1)[#text("Comments (1)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/07/24/deducing-the-inverse-theorem-for-the-multidimensional-gowers-norms-from-the-one-dimensional-version/#comment-457950")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2015")])]

#text("Great!")
]
