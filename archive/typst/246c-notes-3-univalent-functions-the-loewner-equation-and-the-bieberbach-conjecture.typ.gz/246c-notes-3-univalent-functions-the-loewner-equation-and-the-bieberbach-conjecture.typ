// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T16:38:21.119077+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "246C notes 3: Univalent functions, the Loewner equation, and the Bieberbach conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("246C notes 3: Univalent functions, the Loewner equation, and the Bieberbach conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 May 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/")[#text("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Previous set of notes: ")#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/")[#text("Notes 2")]#text(". Next set of notes: ")#link("https://terrytao.wordpress.com/2018/05/29/246c-notes-4-brownian-motion-conformal-invariance-and-sle/")[#text("Notes 4")]#text(".")

#text("We now approach conformal maps from yet another perspective. Given an open subset ")#mi("{U}")#text(" of the complex numbers ")#mi("{{\\bf C}}")#text(", define a ")#link("https://en.wikipedia.org/wiki/Univalent_function")[#text("univalent function")]#text(" on ")#mi("{U}")#text(" to be a holomorphic function ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" that is also injective. We will primarily be studying this concept in the case when ")#mi("{U}")#text(" is the unit disk ")#tao-math("{D(0,1) := \\{ z \\in {\\bf C}: \\left|z\\right| < 1 \\}}", block: false)#text(".")

#text("Clearly, a univalent function ")#mi("{f: D(0,1) \\rightarrow {\\bf C}}")#text(" on the unit disk is a conformal map from ")#mi("{D(0,1)}")#text(" to the image ")#mi("{f(D(0,1))}")#text("; in particular, ")#mi("{f(D(0,1))}")#text(" is simply connected, and not all of ")#mi("{{\\bf C}}")#text(" (since otherwise the inverse map ")#mi("{f^{-1}: {\\bf C} \\rightarrow D(0,1)}")#text(" would violate Liouville’s theorem). In the converse direction, the Riemann mapping theorem tells us that every open simply connected proper subset ")#mi("{V \\subsetneq {\\bf C}}")#text(" of the complex numbers is the image of a univalent function on ")#mi("{D(0,1)}")#text(". Furthermore, if ")#mi("{V}")#text(" contains the origin, then the univalent function ")#mi("{f: D(0,1) \\rightarrow {\\bf C}}")#text(" with this image becomes unique once we normalise ")#mi("{f(0) = 0}")#text(" and ")#mi("{f^{\\prime}(0) > 0}")#text(". Thus the Riemann mapping theorem provides a one-to-one correspondence between open simply connected proper subsets of the complex plane containing the origin, and univalent functions ")#mi("{f: D(0,1) \\rightarrow {\\bf C}}")#text(" with ")#mi("{f(0)=0}")#text(" and ")#mi("{f^{\\prime}(0)>0}")#text(". We will focus particular attention on the univalent functions ")#mi("{f: D(0,1) \\rightarrow {\\bf C}}")#text(" with the normalisation ")#mi("{f(0)=0}")#text(" and ")#mi("{f^{\\prime}(0)=1}")#text("; such functions will be called ")#link("https://en.wikipedia.org/wiki/De_Branges%27s_theorem#Schlicht_functions")[#text("schlicht functions")]#text(".")

#text("One basic example of a univalent function on ")#mi("{D(0,1)}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Cayley_transform")[#text("Cayley transform")]#text(" ")#mi("{z \\mapsto \\frac{1+z}{1-z}}")#text(", which is a Möbius transformation from ")#mi("{D(0,1)}")#text(" to the right half-plane ")#mi("{\\{ \\mathrm{Re}(z) > 0 \\}}")#text(". (The slight variant ")#mi("{z \\mapsto \\frac{1-z}{1+z}}")#text(" is also referred to as the Cayley transform, as is the closely related map ")#mi("{z \\mapsto \\frac{z-i}{z+i}}")#text(", which maps ")#mi("{D(0,1)}")#text(" to the upper half-plane.) One can square this map to obtain a further univalent function ")#mi("{z \\mapsto \\left( \\frac{1+z}{1-z} \\right)^2}")#text(", which now maps ")#mi("{D(0,1)}")#text(" to the complex numbers with the negative real axis ")#mi("{(-\\infty,0]}")#text(" removed. One can normalise this function to be schlicht to obtain the ")#link("https://www.encyclopediaofmath.org/index.php/Koebe_function")[#text("Koebe function")]#text(" ")#metadata(none) <tao-4f13c5c39e34d3f8af83>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("f(z) := \\frac{1}{4}\\left( \\left( \\frac{1+z}{1-z} \\right)^2 - 1\\right) = \\frac{z}{(1-z)^2},")]]

#linebreak()#text(" ")#text(" which now maps ")#mi("{D(0,1)}")#text(" to the complex numbers with the half-line ")#mi("{(-\\infty,-1/4]}")#text(" removed. A little more generally, for any ")#mi("{\\theta \\in {\\bf R}}")#text(" we have the ")#emph[#text("rotated Koebe function")]#text(" ")#metadata(none) <tao-f42546d5ecdd45250980>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("f(z) := \\frac{z}{(1 - e^{i\\theta} z)^2}")]]

#text("that is a schlicht function that maps ")#mi("{D(0,1)}")#text(" to the complex numbers with the half-line ")#mi("{\\{ -re^{-i\\theta}: r \\geq 1/4\\}}")#text(" removed.")#linebreak()#text(" Every schlicht function ")#mi("{f: D(0,1) \\rightarrow {\\bf C}}")#text(" has a convergent Taylor expansion")

#align(center)[#tao-fit-display[#mitex("f(z) = a_1 z + a_2 z^2 + a_3 z^3 + \\dots")]]

#text("for some complex coefficients ")#mi("{a_1,a_2,\\dots}")#text(" with ")#mi("{a_1=1}")#text(". For instance, the Koebe function has the expansion")

#align(center)[#tao-fit-display[#mitex("f(z) = z + 2 z^2 + 3 z^3 + \\dots = \\sum_{n=1}^\\infty n z^n")]]

#text("and similarly the rotated Koebe function has the expansion")

#align(center)[#tao-fit-display[#mitex("f(z) = z + 2 e^{i\\theta} z^2 + 3 e^{2i\\theta} z^3 + \\dots = \\sum_{n=1}^\\infty n e^{(n-1)\\theta} z^n.")]]

#text("Intuitively, the Koebe function and its rotations should be the “largest” schlicht functions available. This is formalised by the famous ")#link("https://en.wikipedia.org/wiki/De_Branges%27s_theorem")[#text("Bieberbach conjecture")]#text(", which asserts that for any schlicht function, the coefficients ")#mi("{a_n}")#text(" should obey the bound ")#tao-math("{\\left|a_n\\right| \\leq n}", block: false)#text(" for all ")#mi("{n}")#text(". After a large number of partial results, this conjecture was eventually ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=772434")[#text("solved by de Branges")]#text("; see for instance ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=856290")[#text("this survey of Korevaar")]#text(" or ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2281158")[#text("this survey of Koepf")]#text(" for a history.")#linebreak()#text(" It turns out that to resolve these sorts of questions, it is convenient to restrict attention to schlicht functions ")#mi("{g: D(0,1) \\rightarrow {\\bf C}}")#text(" that are ")#emph[#text("odd")]#text(", thus ")#mi("{g(-z)=-g(z)}")#text(" for all ")#mi("{z}")#text(", and the Taylor expansion now reads")

#align(center)[#tao-fit-display[#mitex("g(z) = b_1 z + b_3 z^3 + b_5 z^5 + \\dots")]]

#text("for some complex coefficients ")#mi("{b_1,b_3,\\dots}")#text(" with ")#mi("{b_1=1}")#text(". One can transform a general schlicht function ")#mi("{f: D(0,1) \\rightarrow {\\bf C}}")#text(" to an odd schlicht function ")#mi("{g: D(0,1) \\rightarrow {\\bf C}}")#text(" by observing that the function ")#mi("{f(z^2)/z^2: D(0,1) \\rightarrow {\\bf C}}")#text(", after removing the singularity at zero, is a non-zero function that equals ")#mi("{1}")#text(" at the origin, and thus (as ")#mi("{D(0,1)}")#text(" is simply connected) has a unique holomorphic square root ")#mi("{(f(z^2)/z^2)^{1/2}}")#text(" that also equals ")#mi("{1}")#text(" at the origin. If one then sets ")#metadata(none) <tao-88cd2bb6b24c8ba05bac>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("g(z) := z (f(z^2)/z^2)^{1/2}")]]

#text("it is not difficult to verify that ")#mi("{g}")#text(" is an odd schlicht function which additionally obeys the equation ")#metadata(none) <tao-31327e782a9f8d09a978>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("f(z^2) = g(z)^2.")]]

#text("Conversely, given an odd schlicht function ")#mi("{g}")#text(", the formula ")#link(<tao-31327e782a9f8d09a978>)[#text("(4)")]#text(" uniquely determines a schlicht function ")#mi("{f}")#text(".")#linebreak()#text(" For instance, if ")#mi("{f}")#text(" is the Koebe function ")#link(<tao-4f13c5c39e34d3f8af83>)[#text("(1)")]#text(", ")#mi("{g}")#text(" becomes ")#metadata(none) <tao-3a38fa4f38d60f07014c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("g(z) = \\frac{z}{1-z^2} = z + z^3 + z^5 + \\dots,")]]

#linebreak()#text(" ")#text(" which maps ")#mi("{D(0,1)}")#text(" to the complex numbers with two slits ")#mi("{\\{ \\pm iy: y > 1/2 \\}}")#text(" removed, and if ")#mi("{f}")#text(" is the rotated Koebe function ")#link(<tao-f42546d5ecdd45250980>)[#text("(2)")]#text(", ")#mi("{g}")#text(" becomes ")#metadata(none) <tao-710cf1ace7c6da1107df>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("g(z) = \\frac{z}{1- e^{i\\theta} z^2} = z + e^{i\\theta} z^3 + e^{2i\\theta} z^5 + \\dots.")]]

#linebreak()#text(" De Branges established the Bieberbach conjecture by first proving an analogous conjecture for odd schlicht functions known as ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1503286")[#text("Robertson’s conjecture")]#text(". More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (de Branges’ theorem)")]#text(" Let ")#mi("{n \\geq 1}")#text(" be a natural number.")

#list(
[#text("(i) (Robertson conjecture) If ")#mi("{g(z) = b_1 z + b_3 z^3 + b_5 z^5 + \\dots}")#text(" is an odd schlicht function, then")

#align(center)[#tao-fit-display[#tao-math("\\sum_{k=1}^n \\left|b_{2k-1}\\right|^2 \\leq n.", block: true)]]],
[#text("(ii) (Bieberbach conjecture) If ")#mi("{f(z) = a_1 z + a_2 z^2 + a_3 z^3 + \\dots}")#text(" is a schlicht function, then")

#align(center)[#tao-fit-display[#tao-math("\\left|a_n\\right| \\leq n.", block: true)]]]
)
]

#text("It is easy to see that the Robertson conjecture for a given value of ")#mi("{n}")#text(" implies the Bieberbach conjecture for the same value of ")#mi("{n}")#text(". Indeed, if ")#mi("{f(z) = a_1 z + a_2 z^2 + a_3 z^3 + \\dots}")#text(" is schlicht, and ")#mi("{g(z) = b_1 z + b_3 z^3 + b_5 z^5 + \\dots}")#text(" is the odd schlicht function given by ")#link(<tao-88cd2bb6b24c8ba05bac>)[#text("(3)")]#text(", then from extracting the ")#mi("{z^{2n}}")#text(" coefficient of ")#link(<tao-31327e782a9f8d09a978>)[#text("(4)")]#text(" we obtain a formula")

#align(center)[#tao-fit-display[#mitex("a_n = \\sum_{j=1}^n b_{2j-1} b_{2(n+1-j)-1}")]]

#text("for the coefficients of ")#mi("{f}")#text(" in terms of the coefficients of ")#mi("{g}")#text(". Applying the Cauchy-Schwarz inequality, we derive the Bieberbach conjecture for this value of ")#mi("{n}")#text(" from the Robertson conjecture for the same value of ")#mi("{n}")#text(". We remark that ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1574687")[#text("Littlewood and Paley had conjectured")]#text(" a stronger form ")#tao-math("{\\left|b_{2k-1}\\right| \\leq 1}", block: false)#text(" of Robertson’s conjecture, but this was disproved for ")#mi("{k=3}")#text(" ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1574865")[#text("by Fekete and Szegö")]#text(".")#linebreak()#text(" To prove the Robertson and Bieberbach conjectures, one first takes a logarithm and deduces both conjectures from a similar conjecture about the Taylor coefficients of ")#mi("{\\log \\frac{f(z)}{z}}")#text(", known as the ")#emph[#text("Milin conjecture")]#text(". Next, one continuously enlarges the image ")#mi("{f(D(0,1))}")#text(" of the schlicht function to cover all of ")#mi("{{\\bf C}}")#text("; done properly, this places the schlicht function ")#mi("{f}")#text(" as the initial function ")#mi("{f = f_0}")#text(" in a sequence ")#mi("{(f_t)_{t \\geq 0}}")#text(" of univalent maps ")#mi("{f_t: D(0,1) \\rightarrow {\\bf C}}")#text(" known as a ")#link("https://en.wikipedia.org/wiki/Loewner_differential_equation#Loewner_chain")[#text("Loewner chain")]#text(". The functions ")#mi("{f_t}")#text(" obey a useful differential equation known as the ")#link("https://en.wikipedia.org/wiki/Loewner_differential_equation")[#text("Loewner equation")]#text(", that involves an unspecified forcing term ")#mi("{\\mu_t}")#text(" (or ")#mi("{\\theta(t)}")#text(", in the case that the image is a slit domain) coming from the boundary; this in turn gives useful differential equations for the Taylor coefficients of ")#mi("{f(z)}")#text(", ")#mi("{g(z)}")#text(", or ")#mi("{\\log \\frac{f(z)}{z}}")#text(". After some elementary calculus manipulations to “integrate” this equations, the Bieberbach, Robertson, and Milin conjectures are then reduced to establishing the non-negativity of a certain explicit hypergeometric function, which is non-trivial to prove (and will not be done here, except for small values of ")#mi("{n}")#text(") but for which several proofs exist in the literature.")

#text("The theory of Loewner chains subsequently became fundamental to a more recent topic in complex analysis, that of the ")#link("https://en.wikipedia.org/wiki/Schramm%E2%80%93Loewner_evolution")[#text("Schramm-Loewner equation")]#text(" (SLE), which is the focus of the next and final set of notes.")

#metadata(none) <tao-93b09da2284dea88e4e1>

#heading(level: 1)[#strong[#text(" — 1. The area theorem and its consequences — ")]]

#text("We begin with the area theorem of Grönwall.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Grönwall area theorem)")]#text(" ")#metadata(none) <tao-d137d43ec26cc59943b3>#text(" Let ")#tao-math("{F: \\{ z: \\left|z\\right| > 1 \\} \\rightarrow {\\bf C}}", block: false)#text(" be a univalent function with a convergent Laurent expansion")

#align(center)[#tao-fit-display[#mitex("f(z) = z + d_0 + \\frac{d_1}{z} + \\frac{d_2}{z^2} + \\dots.")]]

#text("Then")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n=0}^\\infty n \\left|d_n\\right|^2 \\leq 1.", block: true)]]
]

#emph[#text("Proof:")]#text(" By shifting ")#mi("{f}")#text(" we may normalise ")#mi("{d_0=0}")#text(". By hypothesis we have ")#mi("{d_n = O_\\varepsilon((1+\\varepsilon)^n)}")#text(" for any ")#mi("{\\varepsilon>0}")#text("; by replacing ")#mi("{F}")#text(" with ")#mi("{(1+\\varepsilon)^{-1} F((1+\\varepsilon) z)}")#text(" and using a limiting argument, we may assume without loss of generality that the ")#mi("{d_n}")#text(" have some exponential decay as ")#mi("{n \\rightarrow \\infty}")#text(" (in order to justify some of the manipulations below).")

#text("Let ")#mi("{R>1}")#text(" be a large parameter. If ")#mi("{z = R e^{i\\theta}}")#text(", then ")#mi("{F(Re^{i\\theta}) = R e^{i\\theta} + d_1 R^{-1} e^{-i\\theta} + O(R^{-2})}")#text(" and ")#mi("{\\frac{d}{d\\theta} F(Re^{i\\theta}) = i R e^{i\\theta} - i d_1 R^{-1} e^{-i\\theta} + O(R^{-2})}")#text(". The area enclosed by the simple curve ")#mi("{\\{ F(Re^{i\\theta}):0 \\leq \\theta \\leq 2\\pi \\}}")#text(" is equal to")

#align(center)[#tao-fit-display[#mitex("\\int_0^{2\\pi} \\frac{1}{2} \\mathrm{Im}( \\overline{F(Re^{i\\theta})} \\frac{d}{d\\theta} F(Re^{i\\theta}) )\\ d\\theta")]]

#tao-aligned(keep: true)[


#tao-math(" & = \\frac{1}{2} \\int_0^{2\\pi} \\mathrm{Im}( i R^2 + i \\overline{d_1} e^{2i\\theta} - i d_1 e^{-2i\\theta} + O( R^{-1} )\\ d\\theta", block: true)



#tao-math(" & = \\pi R^2 + O(1/R);", block: true)
]

#text("crucially, the error term here goes to zero as ")#mi("{R \\rightarrow \\infty}")#text(". Meanwhile, by the change of variables formula (using monotone convergence if desired to work in compact subsets of the annulus ")#tao-math("{\\{z: 1 < \\left|z\\right| < R \\}}", block: false)#text(" initially) and Plancherel’s theorem, the area of the region ")#tao-math("{\\{ F(z): 1 < \\left|z\\right| < R \\}}", block: false)#text(" is")

#align(center)[#tao-fit-display[#tao-math("\\int_{1 < \\left|z\\right| < R} \\left|F^{\\prime}(z)\\right|^2\\ dz d\\overline{z}", block: true)]]

#tao-aligned(keep: true)[


#tao-math(" & = \\int_1^R \\int_0^{2\\pi} \\left|1 + \\frac{d_1}{r^2} e^{-2i\\theta} + \\frac{2d_2}{r^3} e^{-3i\\theta} + \\dots\\right|^2\\ d\\theta\\ r dr", block: true)



#tao-math(" & = 2\\pi \\int_1^R (1 + \\frac{\\left|d_1\\right|^2}{r^4} + \\frac{\\left|2d_2\\right|^2}{r^6} + \\dots)\\ r dr", block: true)



#tao-math(" & = \\pi R^2 - \\pi + \\pi \\left|d_1\\right|^2 + 2 \\pi \\left|d_2\\right|^2 + \\dots - O(R^{-1}).", block: true)
]

#text("Comparing these bounds we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n=0}^\\infty n \\left|d_n\\right|^2 \\leq 1 + O(R^{-1});", block: true)]]

#text("sending ")#mi("{R}")#text(" to infinity, we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Let ")#mi("{f: D(0,1) \\rightarrow {\\bf C}}")#text(" be a univalent function with Taylor expansion")

#align(center)[#tao-fit-display[#mitex("f(z) = a_0 + a_1 z + a_2 z^2 + \\dots")]]

#text("Show that the area of ")#mi("{f(D(0,1))}")#text(" is equal to ")#tao-math("{\\pi \\sum_n n \\left|a_n\\right|^2}", block: false)#text(". (In particular, ")#mi("{f(D(0,1))}")#text(" has finite area if and only if ")#tao-math("{\\sum_n n \\left|a_n\\right|^2 < \\infty}", block: false)#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 4 (Bieberbach inequality)")]#text(" ")#metadata(none) <tao-7c454b89bda1d1db2da0>

#list(
[#text("(i) If ")#mi("{g(z) = z + b_3 z^3 + b_5 z^5 + \\dots}")#text(" is an odd schlicht function, then ")#tao-math("{\\left|b_3\\right| \\leq 1}", block: false)#text(".")],
[#text("(ii) If ")#mi("{f(z) = z + a_2 z^2 + a_3 z^3 + \\dots}")#text(" is a schlicht function, then ")#tao-math("{\\left|a_2\\right| \\leq 2}", block: false)#text(".")]
)
]

#emph[#text("Proof:")]#text(" For (i), we apply Theorem ")#link(<tao-d137d43ec26cc59943b3>)[#text("2")]#text(" to the univalent function ")#tao-math("{F: \\{ \\left|z\\right| > 1 \\} \\rightarrow {\\bf C}}", block: false)#text(" defined by ")#mi("{F(z) := 1/g(\\frac{1}{z})}")#text(", which has a Laurent expansion ")#mi("{F(z) = z - \\frac{b_3}{z} + \\dots}")#text(", to give the claim. For (ii), apply part (i) to the square root of ")#mi("{z \\mapsto f(z^2)}")#text(" with first term ")#mi("{z}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Show that equality occurs in Corollary ")#link(<tao-7c454b89bda1d1db2da0>)[#text("4")]#text("(i) if and only if ")#mi("{g}")#text(" takes the form ")#mi("{g(z) = \\frac{z}{1-e^{i\\theta} z^2}}")#text(" for some ")#mi("{\\theta \\in {\\bf R}}")#text(", and in Corollary ")#link(<tao-7c454b89bda1d1db2da0>)[#text("4")]#text("(ii) if and only if ")#mi("{f}")#text(" takes the form of a rotated Koebe function ")#mi("{f(z) = \\frac{z}{(1-e^{i\\theta} z)^2}}")#text(" for some ")#mi("{\\theta \\in {\\bf R}}")#text(".")
]

#text("The Bieberbach inequality can be rescaled to bound the second coefficient of univalent functions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6 (Rescaled Bieberbach inequality)")]#text(" ")#metadata(none) <tao-34cfdbc7d75aa3a3effd>#text(" If ")#mi("{f: D(0,1) \\rightarrow {\\bf C}}")#text(" is a univalent function, show that")

#align(center)[#tao-fit-display[#tao-math("\\left|f^{\\prime\\prime}(0)\\right| \\leq 4|f^{\\prime}(0)|.", block: true)]]

#text("When does equality hold?")
]

#text("The Bieberbach inequality gives a useful lower bound for the image of a univalent function, known as the ")#link("https://en.wikipedia.org/wiki/Koebe_quarter_theorem")[#text("Koebe quarter theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 7 (Koebe quarter theorem)")]#text(" ")#metadata(none) <tao-cadf48f10c0e0dd8a293>#text(" Let ")#mi("{f: D(0,1) \\rightarrow {\\bf C}}")#text(" be a univalent function. Then ")#mi("{f(D(0,1))}")#text(" contains the disk ")#tao-math("{D(f(0), \\left|f^{\\prime}(0)\\right|/4)}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" By applying a translation and rescaling, we may assume without loss of generality that ")#mi("{f}")#text(" is a schlicht function, with Taylor expansion")

#align(center)[#tao-fit-display[#mitex("f(z) = z + a_2 z^2 + a_3 z^3 + \\dots")]]

#text("Our task is now to show that for every ")#mi("{w \\in D(0,1/4)}")#text(", the equation ")#mi("{f(z)=w}")#text(" has a solution in ")#mi("{D(0,1)}")#text(". If this were not the case, then the function ")#mi("{w-f(z)}")#text(" is invertible on ")#mi("{D(0,1)}")#text(", with inverse being univalent and having the Taylor expansion")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{w-f(z)} = \\frac{1}{w} + \\frac{f(z)}{w^2} + \\frac{f(z)^2}{w^3} + \\dots = \\frac{1}{w} + \\frac{z}{w^2} + (\\frac{a_2}{w^2} + \\frac{1}{w^3}) z^2 + \\dots.")]]

#text("Applying Exercise ")#link(<tao-34cfdbc7d75aa3a3effd>)[#text("6")]#text(" we then have")

#align(center)[#tao-fit-display[#tao-math("2\\left|\\frac{a_2}{w^2} + \\frac{1}{w^3}\\right| \\leq \\frac{4}{\\left|w\\right|^2}", block: true)]]

#text("while from the Bieberbach inequality one also has ")#tao-math("{\\left|a_2\\right| \\leq 2}", block: false)#text(". Hence by the triangle inequality ")#tao-math("{\\left|1/w\\right| \\leq 4}", block: false)#text(", which is incompatible with the hypothesis ")#mi("{w \\in D(0,1/4)}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Show that the radius ")#tao-math("{\\left|f^{\\prime}(0)\\right|/4}", block: false)#text(" is best possible in Corollary ")#link(<tao-cadf48f10c0e0dd8a293>)[#text("7")]#text(" (thus, ")#mi("{f(D(0,1))}")#text(" does not contain any disk ")#tao-math("{D(f(0), \\left|f^{\\prime}(0)\\right|/4+\\varepsilon)}", block: false)#text(" with ")#mi("{\\varepsilon>0}")#text(") if and only if ")#mi("{f}")#text(" takes the form ")#mi("{f(z) = a + \\frac{bz}{(1-e^{i\\theta}z)^2}}")#text(" for some complex numbers ")#mi("{a,b \\in {\\bf C}}")#text(" and real ")#mi("{\\theta}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" The univalence hypothesis is crucial in the Koebe quarter theorem. Consider for instance the functions ")#mi("{f_n: D(0,1) \\rightarrow {\\bf C}}")#text(" defined by ")#mi("{f_n(z) := \\frac{e^{nz}-1}{n}}")#text(". These are locally univalent functions (since ")#mi("{f_n}")#text(" is holomorphic with non-zero derivative) and ")#mi("{f_n(0)=0}")#text(", ")#mi("{f^{\\prime}_n(z)=1}")#text(", but ")#mi("{f_n(D(0,1))}")#text(" avoids the point ")#mi("{-\\frac{1}{n}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Koebe distortion theorem)")]#text(" ")#metadata(none) <tao-3ab2490818a68cc7a24c>#text(" Let ")#mi("{f: D(0,1) \\rightarrow {\\bf C}}")#text(" be a schlicht function, and let ")#mi("{z \\in D(0,1)}")#text(" have magnitude ")#tao-math("{\\left|z\\right|=r}", block: false)#text(".")

#list(
[#text("(i) Show that")

#align(center)[#tao-fit-display[#tao-math("\\left| \\frac{z f^{\\prime\\prime}(z)}{f^{\\prime}(z)} - \\frac{2r^2}{1-r^2}\\right| \\leq \\frac{4r}{1-r^2}.", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" compose ")#mi("{f}")#text(" on the right with a Möbius automorphism of ")#mi("{D(0,1)}")#text(" that sends ")#mi("{0}")#text(" to ")#mi("{z}")#text(" and then apply the rescaled Bieberbach inequality.)")],
[#text("(ii) Show that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1-r}{(1+r)^3} \\leq \\left|f^{\\prime}(z)\\right| \\leq \\frac{1+r}{(1-r)^3}.", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" use (i) to control the radial derivative of ")#tao-math("{\\log \\left|f^{\\prime}(z)\\right|}", block: false)#text(".)")],
[#text("(iii) Show that")

#align(center)[#tao-fit-display[#tao-math("\\frac{r}{(1+r)^2} \\leq \\left|f(z)\\right| \\leq \\frac{r}{(1-r)^2}.", block: true)]]],
[#text("(iv) Show that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1-r}{1+r} \\leq \\left|\\frac{z f^{\\prime}(z)}{f(z)}\\right| \\leq \\frac{1+r}{1-r)}.", block: true)]]

#text("(This cannot be directly derived from (ii) and (iii). Instead, compose ")#mi("{f}")#text(" on the right with a Mobius automorphism that sends ")#mi("{0}")#text(" to ")#mi("{z}")#text(" and ")#mi("{-z}")#text(" to ")#mi("{0}")#text(", rescale it to be schlicht, and apply (iii) to this function at ")#mi("{-z}")#text(".)")],
[#text("(v) Show that the space of schlicht functions is a ")#link("https://en.wikipedia.org/wiki/Normal_family")[#text("normal family")]#text(". In other words, if ")#mi("{f_n: D(0,1) \\rightarrow {\\bf C}}")#text(" is any sequence of schlicht functions, then there is a subsequence ")#mi("{f_{n_j}}")#text(" that converges locally uniformly on compact sets.")],
[#text("(vi) (Qualitative Bieberbach conjecture) Show that for each natural number ")#mi("{n}")#text(" there is a constant ")#mi("{C_n}")#text(" such that ")#tao-math("{\\left|a_n\\right| \\leq C_n}", block: false)#text(" whenever ")#mi("{f: D(0,1) \\rightarrow {\\bf C}}")#text(" is a schlicht function with Taylor expansion")

#align(center)[#tao-fit-display[#mitex("f(z) = a_1 z + a_2 z^2 + a_3 z^3 + \\dots.")]]]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11 (Conformal radius)")]#text(" ")#metadata(none) <tao-0c326c4f02797b088fc5>#text(" If ")#mi("{U}")#text(" is a non-empty simply connected open subset of ")#mi("{{\\bf C}}")#text(" that is not all of ")#mi("{{\\bf C}}")#text(", and ")#mi("{z_0}")#text(" is a point in ")#mi("{U}")#text(", define the ")#emph[#text("conformal radius")]#text(" of ")#mi("{U}")#text(" at ")#mi("{z_0}")#text(" to be the quantity ")#tao-math("{\\left|\\phi^{\\prime}(0)\\right|}", block: false)#text(", where ")#mi("{\\phi}")#text(" is any conformal map from ")#mi("{D(0,1)}")#text(" to ")#mi("{U}")#text(" that maps ")#mi("{0}")#text(" to ")#mi("{z_0}")#text(" (the existence and uniqueness of this radius follows from the Riemann mapping theorem). Thus for instance the disk ")#mi("{D(z_0,r)}")#text(" has conformal radius ")#mi("{r}")#text(" around ")#mi("{z_0}")#text(".")

#list(
[#text("(i) Show that the conformal radius is strictly monotone in ")#mi("{U}")#text(": if ")#mi("{U_1 \\subsetneq U_2 \\subsetneq {\\bf C}}")#text(" are non-empty simply connected open subsets of ")#mi("{{\\bf C}}")#text(", and ")#mi("{z_0 \\in U_1}")#text(", then the conformal radius of ")#mi("{U_2}")#text(" around ")#mi("{z_0}")#text(" is strictly greater than that of ")#mi("{U_1}")#text(".")],
[#text("(ii) Show that the conformal radius of a disk ")#mi("{D(z_0,r)}")#text(" around an element ")#mi("{z_1}")#text(" of the disk is given by the formula ")#tao-math("{r - \\frac{\\left|z_1-z_0\\right|^2}{r}}", block: false)#text(".")],
[#text("(iii) Show that the conformal radius of ")#mi("{U}")#text(" around ")#mi("{z_0}")#text(" lies between ")#mi("{r}")#text(" and ")#mi("{4r}")#text(", where ")#mi("{r}")#text(" is the radius of the maximal disk ")#mi("{D(z_0,r)}")#text(" that is contained in ")#mi("{U}")#text(".")],
[#text("(iv) If the conformal radius of ")#mi("{U}")#text(" around ")#mi("{z_0}")#text(" is equal to ")#mi("{R}")#text(", show that for all sufficiently small ")#mi("{\\varepsilon>0}")#text(", the ring domain ")#mi("{U \\backslash D(z_0,\\varepsilon)}")#text(" has modulus ")#mi("{\\log \\frac{R}{\\varepsilon} + o(1)}")#text(", where ")#mi("{o(1)}")#text(" denotes a quantity that goes to zero as ")#mi("{\\varepsilon \\rightarrow 0}")#text(", and the modulus of a ring domain was defined in ")#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/")[#text("Notes 2")]#text(".")]
)
]

#text("We can use the distortion theorem to obtain a nice criterion for when univalent maps converge to a given limit, known as the ")#link("https://en.wikipedia.org/wiki/Carath%C3%A9odory_kernel_theorem")[#text("Carathéodory kernel theorem")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 12 (Carathéodory kernel theorem)")]#text(" ")#metadata(none) <tao-7d94d2a81920e50826c1>#text(" Let ")#mi("{U_1,U_2,\\dots}")#text(" be a sequence of simply connected open proper subsets of ")#mi("{{\\bf C}}")#text(" containing the origin, and let ")#mi("{U}")#text(" be a further simply connected open proper subset of ")#mi("{{\\bf C}}")#text(" containing ")#mi("{0}")#text(". Let ")#mi("{f_n: D(0,1) \\rightarrow U_n}")#text(" and ")#mi("{f: D(0,1) \\rightarrow U}")#text(" be the conformal maps with ")#mi("{f_n(0)=0}")#text(" and ")#mi("{f^{\\prime}_n(0) > 0}")#text(" (the existence and uniqueness of these maps are given by the Riemann mapping theorem). Then the following are equivalent:")

#list(
[#text("(i) ")#mi("{f_n}")#text(" converges locally uniformly on compact sets to ")#mi("{f}")#text(".")],
[#text("(ii) For every subsequence ")#mi("{U_{n_j}}")#text(" of the ")#mi("{U_n}")#text(", ")#mi("{U}")#text(" is the set of all ")#mi("{w \\in {\\bf C}}")#text(" such that there is an open connected set containing ")#mi("{0}")#text(" and ")#mi("{w}")#text(" that is contained in ")#mi("{U_{n_j}}")#text(" for all sufficiently large ")#mi("{j}")#text(".")]
)
]

#text("If conclusion (ii) holds, ")#mi("{U}")#text(" is known as the ")#emph[#text("kernel")]#text(" of the domains ")#mi("{U_n}")#text(".")

#emph[#text("Proof:")]#text(" Suppose first that ")#mi("{f_n}")#text(" converges locally uniformly on compact sets to ")#mi("{f}")#text(". If ")#mi("{w \\in U}")#text(", then ")#mi("{w \\in f(B(0,r^{\\prime})) \\subset f(B(0,r))}")#text(" for some ")#mi("{0 < r^{\\prime} < r < 1}")#text(". If ")#mi("{w^{\\prime} \\in f(B(0,r))}")#text(", then the holomorphic functions ")#mi("{f_n-w^{\\prime}}")#text(" converge uniformly on ")#mi("{\\overline{B(0,r)}}")#text(" to the function ")#mi("{f-w^{\\prime}}")#text(", which is not identically zero but has a zero in ")#mi("{B(0,r)}")#text(". By ")#link("https://en.wikipedia.org/wiki/Hurwitz%27s_theorem_(complex_analysis)")[#text("Hurwitz’s theorem")]#text(" we conclude that ")#mi("{f_n-w^{\\prime}}")#text(" also has a zero in ")#mi("{B(0,r)}")#text(" for all sufficiently large ")#mi("{n}")#text("; indeed the same argument shows that one can replace ")#mi("{w^{\\prime}}")#text(" by any element of a small neighbourhood of ")#mi("{w^{\\prime}}")#text(" to obtain the same conclusion, uniformly in ")#mi("{n}")#text(". From compactness we conclude that for sufficiently large ")#mi("{n}")#text(", ")#mi("{f_n-w^{\\prime}}")#text(" has a zero in ")#mi("{B(0,r)}")#text(" for all ")#mi("{w^{\\prime} \\in \\overline{f(B(0,r^{\\prime}))}}")#text(", thus ")#mi("{f(B(0,r^{\\prime})) \\subset U_n}")#text(" for sufficiently large ")#mi("{n}")#text(". Since ")#mi("{f(B(0,r^{\\prime}))}")#text(" is open connected and contains ")#mi("{0}")#text(" and ")#mi("{w}")#text(", we see that ")#mi("{U}")#text(" is contained in the set described in (ii).")

#text("Conversely, suppose that ")#mi("{U_{n_j}}")#text(" is a subsequence of the ")#mi("{U_n}")#text(" and ")#mi("{w \\in {\\bf C}}")#text(" is such that there is an open connected set ")#mi("{V}")#text(" containing ")#mi("{0}")#text(" and ")#mi("{w}")#text(" that is contained in ")#mi("{U_{n_j}}")#text(" for sufficiently large ")#mi("{j}")#text(". The inverse maps ")#mi("{f_{n_j}^{-1}: V \\rightarrow D(0,1)}")#text(" are holomorphic and bounded, hence form a normal family by Montel’s theorem. By refining the subsequence we may thus assume that the ")#mi("{f_{n_j}^{-1}}")#text(" converge locally uniformly to a holomorphic limit ")#mi("{g}")#text(". The function ")#mi("{g}")#text(" takes values in ")#mi("{\\overline{D(0,1)}}")#text(", but by the open mapping theorem it must in fact map to ")#mi("{D(0,1)}")#text(". In particular, ")#mi("{g(w) \\in D(0,1)}")#text(". Since ")#mi("{f_{n_j}^{-1}(w)}")#text(" converges to ")#mi("{g(w)}")#text(", and ")#mi("{f_{n_j}}")#text(" converges locally uniformly to ")#mi("{f}")#text(", we conclude that ")#mi("{f_{n_j}( f_{n_j}^{-1}(w) )}")#text(" converges to ")#mi("{f(g(w))}")#text(", thus ")#mi("{f(g(w)) = w}")#text(" and hence ")#mi("{w \\in U}")#text(". This establishes the derivation of (ii) from (i).")

#text("Now suppose that (ii) holds. It suffices to show that every subsequence of ")#mi("{f_n}")#text(" has a further subsequence that converges locally uniformly on compact sets to ")#mi("{f}")#text(" (this is an instance of the ")#emph[#text("Urysohn subsequence principle")]#text("). Then (as ")#mi("{U}")#text(" contains ")#mi("{0}")#text(") in particular there is a disk ")#mi("{D(0,\\varepsilon)}")#text(" that is contained in the ")#mi("{U_n}")#text(" for all sufficiently large ")#mi("{n}")#text("; on the other hand, as ")#mi("{U}")#text(" is not all of ")#mi("{{\\bf C}}")#text(", there is also a disk ")#mi("{D(0,R)}")#text(" which is ")#emph[#text("not")]#text(" contained in the ")#mi("{U_n}")#text(" for all sufficiently large ")#mi("{n}")#text(". By Exercise ")#link(<tao-0c326c4f02797b088fc5>)[#text("11")]#text(", this implies that the conformal radii of the ")#mi("{U_n}")#text(" around zero is bounded above and below, thus ")#mi("{f^{\\prime}_n(0)}")#text(" is bounded above and below.")

#text("By Exercise ")#link(<tao-3ab2490818a68cc7a24c>)[#text("10")]#text("(v), and rescaling, the functions ")#mi("{f_{n_j}}")#text(" then form a normal family, thus there is a subsequence ")#mi("{f_{n^{\\prime}_j}}")#text(" of the ")#mi("{f_{n_j}}")#text(" that converges locally uniformly on compact sets to some limit ")#mi("{g}")#text(". Since ")#mi("{f^{\\prime}_{n^{\\prime}_j}(0)}")#text(" is positive and bounded away from zero, ")#mi("{g^{\\prime}(0)}")#text(" is also positive, so ")#mi("{g}")#text(" is non-constant. By Hurwitz’s theorem, ")#mi("{g}")#text(" is therefore also univalent, and thus maps ")#mi("{D(0,1)}")#text(" to some region ")#mi("{V}")#text(". By the implication of (ii) from (i) (with ")#mi("{f,U}")#text(" replaced by ")#mi("{g,V}")#text(") we conclude that ")#mi("{V}")#text(" is the set of all ")#mi("{w \\in {\\bf C}}")#text(" such that there is an open connected set containing ")#mi("{0}")#text(" and ")#mi("{w}")#text(" that is contained in ")#mi("{U_{n^{\\prime}_j}}")#text(" for all sufficiently large ")#mi("{j}")#text("; but by hypothesis, this set is also ")#mi("{U}")#text(". Thus ")#mi("{U=V}")#text(", and then by the uniqueness part of the Riemann mapping theorem, ")#mi("{f=g}")#text(" as desired. ")#mi("\\Box")

#text("The condition in Theorem ")#link(<tao-7d94d2a81920e50826c1>)[#text("12")]#text("(ii) indicates that ")#mi("{U_n}")#text(" “converges” to ")#mi("{U}")#text(" in a rather complicated sense, in which large parts of ")#mi("{U_n}")#text(" are allowed to be “pinched off” from ")#mi("{0}")#text(" and disappear in the limit. This is illustrated in the following explicit example:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Explicit example of kernel convergence)")]#text(" Let ")#mi("{g}")#text(" be the function from ")#link(<tao-3a38fa4f38d60f07014c>)[#text("(5)")]#text(", thus ")#mi("{g}")#text(" is a univalent function from ")#mi("{D(0,1)}")#text(" to ")#mi("{{\\bf C}}")#text(" with the two vertical rays from ")#mi("{i/2}")#text(" to ")#mi("{+i\\infty}")#text(", and from ")#mi("{-i/2}")#text(" to ")#mi("{-i\\infty}")#text(", removed. For any natural number ")#mi("{n}")#text(", let ")#mi("{z_n := 1-\\frac{1}{n}}")#text(" and let ")#mi("{w_n := g(z_n) = \\frac{n(n-1)}{2n-1}}")#text(", and define the transformed functions ")#mi("{f_n(z) := \\frac{1}{w_n} g(\\frac{z+z_n}{1+\\overline{z_n} z}) - 1}")#text(".")

#list(
[#text("(i) Show that ")#mi("{f_n}")#text(" is a univalent function from ")#mi("{D(0,1)}")#text(" to ")#mi("{{\\bf C}}")#text(" with the two vertical rays from ")#mi("{-1 + \\frac{i}{2w_n}}")#text(" to ")#mi("{-1+i\\infty}")#text(", and from ")#mi("{-1 - \\frac{i}{2w_n}}")#text(" to ")#mi("{-1 -i\\infty}")#text(", removed, and that ")#mi("{f_n(0)=0}")#text(" and ")#mi("{f^{\\prime}_n(0)>0}")#text(".")],
[#text("(ii) Show that ")#mi("{f_n}")#text(" converges locally uniformly to the function ")#mi("{f(z) := \\frac{2z}{1-z}}")#text(", and that this latter map is a univalent map from ")#mi("{D(0,1)}")#text(" to the half-plane ")#mi("{\\{ x+iy: x > -1\\}}")#text(". (")#emph[#text("Hint:")]#text(" one does not need to compute everything exactly; for instance, any terms of the form ")#mi("{O( \\frac{1}{n^2})}")#text(" can be written using the ")#mi("{O()}")#text(" notation instead of expanded explicitly.)")],
[#text("(iii) Explain why these facts are consistent with the Carathéodory kernel theorem.")]
)
]

#text("As another illustration of the theorem, let ")#mi("{U,V}")#text(" be two distinct convex open proper subsets of ")#mi("{{\\bf C}}")#text(" containing the origin, and let ")#mi("{f_U, f_V}")#text(" be the associated conformal maps from ")#mi("{D(0,1)}")#text(" to ")#mi("{U,V}")#text(" respectively with ")#mi("{f_U(0)=f_V(0)=0}")#text(" and ")#mi("{f^{\\prime}_U(0), f^{\\prime}_V(0)>0}")#text(". Then the alternating sequence ")#mi("{f_U, f_V, f_U, f_V, \\dots}")#text(" does not converge locally uniformly to any limit. The set ")#mi("{U \\cap V}")#text(" is the set of all points that lie in a connected open set containing the origin that eventually is contained in the sequence ")#mi("{U,V,U,V,\\dots}")#text("; but if one passes to the subsequence ")#mi("{U,U,U,\\dots}")#text(", this set of points enlarges to ")#mi("{U}")#text(", and so the sequence ")#mi("{U,V,U,V,\\dots}")#text(" does not in fact have a kernel.")

#text("However, the kernel theorem simplifies significantly when the ")#mi("{U_n}")#text(" are monotone increasing, which is already an important special case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 14 (Monotone increasing case of kernel theorem)")]#text(" ")#metadata(none) <tao-aceea3feef0902bbab40>#text(" Let the notation and assumptions be as in Theorem ")#link(<tao-7d94d2a81920e50826c1>)[#text("12")]#text(". Assume furthermore that")

#align(center)[#tao-fit-display[#mitex("U_1 \\subset U_2 \\subset U_3 \\subset \\dots")]]

#text("and that ")#mi("{U = \\bigcup_{n=1}^\\infty U_n}")#text(". Then ")#mi("{f_n}")#text(" converges locally uniformly on compact sets to ")#mi("{f}")#text(".")
]

#text("Loewner observed that the kernel theorem can be used to approximate univalent functions by functions mapping into slit domains. More precisely, define a ")#emph[#text("slit domain")]#text(" to be an open simply connected subset of ")#mi("{{\\bf C}}")#text(" formed by deleting a half-infinite Jordan curve ")#mi("{\\{ \\gamma(t): t \\geq 0 \\}}")#text(" connecting some finite point ")#mi("{\\gamma(0)}")#text(" to infinity; for instance, the image ")#mi("{{\\bf C} \\backslash (-\\infty,-1/4]}")#text(" of the Koebe function is a slit domain.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 15 (Loewner approximation theorem)")]#text(" ")#metadata(none) <tao-473c3cba6f0b66454d76>#text(" Let ")#mi("{f: D(0,1) \\rightarrow {\\bf C}}")#text(" be a univalent function. Then there exists a sequence ")#mi("{f_n: D(0,1) \\rightarrow {\\bf C}}")#text(" of univalent functions whose images ")#mi("{f_n(D(0,1))}")#text(" are slit domains, and which converge locally uniformly on compact subsets to ")#mi("{f}")#text(".")
]

#emph[#text("Proof:")]#text(" First suppose that ")#mi("{f}")#text(" extends to a univalent function on a slightly larger disk ")#mi("{D(0,1+\\varepsilon)}")#text(" for some ")#mi("{\\varepsilon>0}")#text(". Then the image ")#mi("{f( \\partial D(0,1)) = \\{ f(e^{i\\theta}): 0 \\leq \\theta \\leq 2\\pi \\}}")#text(" of the unit circle is a Jordan curve enclosing the region ")#mi("{f(D(0,1))}")#text(" in the interior. Applying the Jordan curve theorem (and the Möbius inversion ")#mi("{z \\mapsto 1/z}")#text("), one can find a half-infinite Jordan curve ")#mi("{\\gamma}")#text(" from ")#mi("{f(1)}")#text(" to infinity that stays outside of ")#mi("{f(\\overline{D(0,1)})}")#text(". For any ")#mi("{n}")#text(", one can concatenate this curve with the arc ")#mi("{\\{f(e^{i\\theta}): 0 \\leq \\theta \\leq 2\\pi - \\frac{1}{n} \\}}")#text(" to obtain another half-infinite Jordan curve ")#mi("{\\gamma_n}")#text(", whose complement ")#mi("{U_n := {\\bf C} \\backslash \\gamma_n}")#text(" is a slit domain which has ")#mi("{f(D(0,1))}")#text(" as kernel (why?). If we let ")#mi("{f_n}")#text(" be the conformal maps from ")#mi("{D(0,1)}")#text(" to ")#mi("{U_n}")#text(" with ")#mi("{f_n(0)=0}")#text(" and ")#mi("{f^{\\prime}_n(0)>0}")#text(", we conclude from the Carathéodory kernel theorem that ")#mi("{f_n}")#text(" converges locally uniformly on compact sets to ")#mi("{f}")#text(".")

#text("If ")#mi("{f}")#text(" is just univalent on ")#mi("{D(0,1)}")#text(", then it is the locally uniform limit of the dilations ")#mi("{f_n(z) := f( \\frac{n-1}{n} z )}")#text(", which are univalent on the slightly larger disks ")#mi("{D(0,\\frac{n}{n-1})}")#text(". By the previous arguments, each ")#mi("{f_n}")#text(" is in turn the locally uniform limit of univalent functions whose images are slit domains, and the claim now follows from a diagonalisation argument. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 2. Loewner chains — ")]]

#text("The material in this section is based on ")#link("https://web.archive.org/web/20171103012553/https://math.hawaii.edu/~myounsi/teaching/mat627/NotesClassical.pdf")[#text("lecture notes of Contreras")]#text(".")

#text("An important tool in analysing univalent functions is to study one-parameter families ")#mi("{f_t: D(0,1) \\rightarrow {\\bf C}}")#text(" of univalent functions, parameterised by a time parameter ")#mi("{t \\geq 0}")#text(", in which the images ")#mi("{f_t(D(0,1))}")#text(" are increasing in ")#mi("{t}")#text("; roughly speaking, these families allow one to study an arbitrary univalent function ")#mi("{f_1}")#text(" by “integrating” along such a family from ")#mi("{t=\\infty}")#text(" back to ")#mi("{t=1}")#text(". Traditionally, we normalise these families into (radial) ")#link("https://en.wikipedia.org/wiki/Loewner_differential_equation#Loewner_chain")[#text("Loewner chains")]#text(", which we now define:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 16 (Loewner chain)")]#text(" A (radial) Loewner chain is a family ")#mi("{(f_t)_{t \\geq 0}}")#text(" of univalent maps ")#mi("{f_t: D(0,1) \\rightarrow {\\bf C}}")#text(" with ")#mi("{f(0)=0}")#text(" and ")#mi("{f^{\\prime}_t(0) = e^t}")#text(" (so in particular ")#mi("{f_0}")#text(" is schlicht), such that ")#mi("{f_s(D(0,1)) \\subsetneq f_t(D(0,1))}")#text(" for all ")#mi("{0 \\leq s < t < \\infty}")#text(". (In these notes we use the prime notation exclusively for differentiation in the ")#mi("{z}")#text(" variable; we will use ")#mi("{\\partial_t}")#text(" later for differentiation in the ")#mi("{t}")#text(" variable.)")
]

#text("A key example of a Loewner chain is the family ")#metadata(none) <tao-2cecb41e40144e186719>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("f_t(z) := e^t \\frac{z}{(1-z)^2}")]]

#linebreak()#text(" ")#text(" of dilated Koebe functions; note that the image ")#mi("{f_t(D(0,1))}")#text(" of each ")#mi("{f_t}")#text(" is the slit domain ")#mi("{{\\bf C} \\backslash (-\\infty, -e^t/4]}")#text(", which is clearly monotone increasing in ")#mi("{t}")#text(". More generally, we have the rotated Koebe chains ")#metadata(none) <tao-de7ee32ce67a8a2c340d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("f_t(z) := e^t \\frac{z}{(1- e^{i\\theta} z)^2}")]]

#text("for any real ")#mi("{\\theta}")#text(".")#linebreak()#text(" Whenever one has a family ")#mi("{(U_t)_{t>0}}")#text(" of simply connected proper open subsets of ")#mi("{{\\bf C}}")#text(" containing ")#mi("{0}")#text(" with ")#mi("{U_s \\subsetneq U_t}")#text(" for ")#mi("{0 \\leq s<t<\\infty}")#text(", we can use the Riemann mapping theorem to uniquely define univalent functions ")#mi("{f_t: D(0,1) \\rightarrow {\\bf C}}")#text(" with ")#mi("{f_t(0)=0}")#text(", ")#mi("{f^{\\prime}_t(0)>0}")#text(", and ")#mi("{f_t(D(0,1)) = U_t}")#text(". By definition, ")#mi("{f^{\\prime}_t(0)}")#text(" is then the conformal radius of ")#mi("{U_t}")#text(" around ")#mi("{0}")#text(", which is a strictly increasing function of ")#mi("{t}")#text(" by Exercise ")#link(<tao-0c326c4f02797b088fc5>)[#text("11")]#text(". If this conformal radius ")#mi("{f^{\\prime}_t(0)}")#text(" is equal to ")#mi("{1}")#text(" at ")#mi("{t=0}")#text(" and increases continuously to infinity as ")#mi("{t \\rightarrow \\infty}")#text(", then one can reparameterise the ")#mi("{t}")#text(" variable so that ")#mi("{f^{\\prime}_t(0)=e^t}")#text(", at which point one obtains a Loewner chain.")

#text("From the Koebe quarter theorem we see that each image ")#mi("{U_t = f_t(D(0,1))}")#text(" in a Loewner chain contains the disk ")#mi("{D(0,e^t/4)}")#text(". In particular the ")#mi("{U_t}")#text(" increase to fill out all of ")#mi("{{\\bf C}}")#text(": ")#mi("{{\\bf C} = \\bigcup_{t>0} U_t}")#text(".")

#text("Let ")#mi("{(f_t)_{t \\geq 0}}")#text(" be a Loewner chain, Let ")#mi("{0 \\leq s \\leq t < \\infty}")#text(". The relation ")#mi("{f_s(D(0,1)) \\subsetneq f_t(D(0,1))}")#text(" is sometimes expressed as the assertion that ")#mi("{f_s}")#text(" is ")#emph[#text("subordinate")]#text(" to ")#mi("{f_t}")#text(". It has the consequence that one has a composition law of the form ")#metadata(none) <tao-07026a4df5486d62e512>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("f_s = f_t \\circ \\phi_{t \\leftarrow s}")]]

#linebreak()#text(" ")#text(" for a univalent function ")#mi("{\\phi_{t \\leftarrow s}: D(0,1) \\rightarrow D(0,1)}")#text(", uniquely defined as ")#mi("{\\phi_{t \\leftarrow s} = f_t^{-1} \\circ f_s}")#text(", noting that ")#mi("{f_t^{-1}: U_t \\rightarrow D(0,1)}")#text(" is well-defined on ")#mi("{U_s \\subset U_t}")#text(". By construction, we have ")#mi("{\\phi_{t \\leftarrow s}(0)=0}")#text(" and ")#metadata(none) <tao-5ee424ce8c978203e952>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\phi_{t \\leftarrow s}^{\\prime}(0) = e^{s-t},")]]

#text("as well as the composition laws ")#metadata(none) <tao-db669af634b75c7f2984>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\phi_{t \\leftarrow t} = \\mathrm{id}; \\quad \\phi_{t \\leftarrow r} = \\phi_{t \\leftarrow s} \\circ \\phi_{s \\leftarrow r}")]]

#text("for ")#mi("{0 \\leq r \\leq s \\leq t < \\infty}")#text(". We will refer to the ")#mi("{\\phi_{t \\leftarrow s}}")#text(" as ")#emph[#text("transition functions")]#text(".")#linebreak()#text(" From the ")#link("https://en.wikipedia.org/wiki/Schwarz_lemma")[#text("Schwarz lemma")]#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\phi_{t \\leftarrow s}(z)\\right| \\leq \\left|z\\right|", block: true)]]

#text("for ")#mi("{0 \\leq s \\leq t < \\infty}")#text(", with strict inequality when ")#mi("{s<t}")#text(". In particular, if we introduce the function ")#metadata(none) <tao-48d4a7bd3a31b5c7366c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("p_{t \\leftarrow s}(z) := \\frac{1 + e^{s-t}}{1-e^{s-t}} \\frac{z - \\phi_{t \\leftarrow s}(z)}{z + \\phi_{t \\leftarrow s}(z)}")]]

#text("for ")#mi("{0 \\leq s<t< \\infty}")#text(" and ")#mi("{z \\in D(0,1)}")#text(", then (after removing the singularity at infinity and using ")#link(<tao-5ee424ce8c978203e952>)[#text("(10)")]#text(") we see that ")#mi("{p_{t \\leftarrow s}: D(0,1) \\rightarrow \\mathbf{H}}")#text(" is a holomorphic map to the right half-plane ")#mi("{\\mathbf{H} := \\{ x+iy: x>0 \\}}")#text(", normalised so that")

#align(center)[#tao-fit-display[#mitex("p_{t \\leftarrow s}(0) = 1.")]]

#text("Define a ")#link("https://en.wikipedia.org/wiki/Nevanlinna_function")[#text("Herglotz function")]#text(" to be a holomorphic function ")#mi("{p: D(0,1) \\rightarrow \\mathbf{H}}")#text(", thus ")#mi("{p_{t \\leftarrow s}}")#text(" is a Herglotz function for all ")#mi("{0 \\leq s < t < \\infty}")#text(". A key family of examples of a Herglotz function are the Möbius transforms ")#mi("{z \\mapsto \\frac{e^{i\\theta}+z}{e^{i\\theta}-z}}")#text(" for ")#mi("{\\theta \\in {\\bf R}}")#text(". In fact, all other Herglotz functions are basically just averages of this one:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17 (Herglotz representation theorem)")]#text(" Let ")#mi("{p: D(0,1) \\rightarrow \\mathbf{H}}")#text(" be a Herglotz function, normalised so that ")#mi("{p(0)=1}")#text(".")

#list(
[#text("(i) For any ")#mi("{0 < r < 1}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("p(z) = \\frac{1}{2\\pi} \\int_0^{2\\pi} \\frac{re^{i\\theta}+z}{re^{i\\theta}-z} \\mathrm{Re} p(re^{i\\theta})\\ d\\theta.")]]

#text("for ")#mi("{z \\in D(0,r)}")#text(". (")#emph[#text("Hint:")]#text(" The real part of ")#mi("{p}")#text(" is harmonic, and so has a ")#link("https://en.wikipedia.org/wiki/Poisson_kernel")[#text("Poisson kernel")]#text(" representation. Alternatively, one can use a Taylor expansion of ")#mi("{p}")#text(".)")],
[#text("(ii) Show that there exists a (Radon) probability measure ")#mi("{\\mu}")#text(" on ")#mi("{[0,2\\pi)}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("p(z) = \\int_0^{2\\pi} \\frac{e^{i\\theta}+z}{e^{i\\theta}-z}\\ d\\mu(\\theta)")]]

#text("for all ")#mi("{z \\in D(0,1)}")#text(". (One will need a measure-theoretic tool such as ")#link("https://en.wikipedia.org/wiki/Prokhorov%27s_theorem")[#text("Prokhorov’s theorem")]#text(", the ")#link("https://en.wikipedia.org/wiki/Riesz_representation_theorem")[#text("Riesz representation theorem")]#text(", or the ")#link("https://en.wikipedia.org/wiki/Helly%27s_selection_theorem")[#text("Helly selection principle")]#text(".) Conversely, show that every probability measure ")#mi("{\\mu}")#text(" on ")#mi("{[0,2\\pi]}")#text(" generates a Herglotz function ")#mi("{p}")#text(" with ")#mi("{p(0)=1}")#text(" by the above formula.")],
[#text("(iii) Show that the measure ")#mi("{\\mu}")#text(" constructed on (ii) is unique.")]
)
]

#text("This has a useful corollary, namely a version of the ")#link("https://en.wikipedia.org/wiki/Harnack%27s_inequality")[#text("Harnack inequality")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18 (Harnack inequality)")]#text(" Let ")#mi("{p: D(0,1) \\rightarrow \\mathbf{H}}")#text(" be a Herglotz function, normalised so that ")#mi("{p(0)=1}")#text(". Show that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1-\\left|z\\right|}{1+\\left|z\\right|} \\leq \\mathrm{Re} p(z) \\leq \\left|p(z)\\right| \\leq \\frac{1+\\left|z\\right|}{1-\\left|z\\right|}", block: true)]]

#text("for all ")#mi("{z \\in D(0,1)}")#text(".")
]

#text("This gives some useful Lipschitz regularity properties of the transition functions ")#mi("{p_{t \\leftarrow s}}")#text(" and univalent functions ")#mi("{f_t}")#text(" in the ")#mi("{t}")#text(" variable:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 19 (Lipschitz regularity)")]#text(" ")#metadata(none) <tao-adb23c499622d93615d0>#text(" Let ")#mi("{K}")#text(" be a compact subset of ")#mi("{D(0,1)}")#text(", and let ")#mi("{0 < T < \\infty}")#text(". Use ")#mi("{O_{K,T}(X)}")#text(" to denote a quantity bounded in magnitude by ")#mi("{C_{K,T} X}")#text(", where ")#mi("{C_{K,T}}")#text(" depends only on ")#mi("{K,T}")#text(".")

#list(
[#text("(i) For any ")#mi("{0 \\leq s \\leq t \\leq u \\leq T}")#text(" and ")#mi("{z \\in K}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\phi_{u \\leftarrow t}(z) - \\phi_{u \\leftarrow s}(z) = O_{K,T}(\\left|s-t\\right|).", block: true)]]],
[#text("(ii) For any ")#mi("{0 \\leq s \\leq t \\leq T}")#text(" and ")#mi("{z \\in K}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("f_t(z) - f_s(z) = O_{K,T}(\\left|s-t\\right|).", block: true)]]]
)
]

#text("One can make the bounds ")#tao-math("{O_{K,T}(\\left|s-t\\right|)}", block: false)#text(" much more explicit if desired (see e.g. Lemma 2.3 of ")#link("https://math.hawaii.edu/~myounsi/teaching/mat627/NotesClassical.pdf")[#text("these notes of Contreras")]#text("), but for our purposes any Lipschitz bound will suffice.")

#emph[#text("Proof:")]#text(" To prove (i), it suffices from ")#link(<tao-db669af634b75c7f2984>)[#text("(11)")]#text(" and the Schwarz-Pick lemma (Exercise 13 from ")#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/")[#text("Notes 2")]#text(") to establish this claim when ")#mi("{u=t}")#text(". We can also assume that ")#mi("{s<t}")#text(" since the claim is trivial when ")#mi("{s=t}")#text(". From the Harnack inequality one has")

#align(center)[#tao-fit-display[#mitex("p_{t \\leftarrow s}(z) = O_{K,T}(1)")]]

#text("for ")#mi("{z \\in K}")#text(", which by ")#link(<tao-48d4a7bd3a31b5c7366c>)[#text("(12)")]#text(" and some computation gives ")#metadata(none) <tao-b495942f14d7ebc0cc2f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\phi_{t \\leftarrow s}(z) = z + O_{K,T}(\\left|s-t\\right|),", block: true)]]

#text("giving the claim.")#linebreak()#text(" Now we prove (ii). We may assume without loss of generality that ")#mi("{K}")#text(" is convex. From Exercise ")#link(<tao-3ab2490818a68cc7a24c>)[#text("10")]#text(" (normalising ")#mi("{f_t}")#text(" to be schlicht) we see that ")#mi("{f^{\\prime}_t(z) = O_{K,T}(1)}")#text(" for ")#mi("{z \\in K}")#text(", and hence ")#mi("{f_t}")#text(" has a Lipschitz constant of ")#mi("{O_{K,T}(1)}")#text(" on ")#mi("{K}")#text(". Since ")#mi("{f_t(z) - f_s(z) = f_t(z) - f_t( \\phi_{t \\leftarrow s}(z) )}")#text(", the claim now follows from ")#link(<tao-b495942f14d7ebc0cc2f>)[#text("(13)")]#text(". ")#mi("\\Box")

#text("As a first application of this we show that every schlicht function starts a Loewner chain.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 20")]#text(" ")#metadata(none) <tao-1154fd7ea50413bfda4b>#text(" Let ")#mi("{f: D(0,1) \\rightarrow {\\bf C}}")#text(" be schlicht. Then there exists a Loewner chain ")#mi("{(f_t)_{t \\geq 0}}")#text(" with ")#mi("{f_0 = 0}")#text(".")
]

#emph[#text("Proof:")]#text(" This will be similar to the proof of Theorem ")#link(<tao-473c3cba6f0b66454d76>)[#text("15")]#text(". First suppose that ")#mi("{f}")#text(" extends to be univalent on ")#mi("{D(0,1+\\varepsilon)}")#text(" for some ")#mi("{\\varepsilon>0}")#text(", then ")#mi("{f(\\partial D(0,1))}")#text(" is a Jordan curve. Then by Carathéodory’s theorem (Theorem 20 of ")#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/")[#text("Notes 2")]#text(") (and the Möbius inversion ")#mi("{z \\mapsto \\frac{1}{z}}")#text(") one can find a conformal map ")#mi("{\\phi}")#text(" from the exterior of ")#mi("{f(\\partial D(0,1))}")#text(" to the exterior of ")#mi("{D(0,1)}")#text(" that sends infinity to infinity. If we define ")#mi("{U_t}")#text(" for ")#mi("{t>0}")#text(" to be the region enclosed by the Jordan curve ")#mi("{\\phi^{-1}( \\partial D( 0, e^t) ))}")#text(", then the ")#mi("{U_t}")#text(" are increasing in ")#mi("{t}")#text(" with conformal radius going to infinity as ")#mi("{t \\rightarrow \\infty}")#text(". If one sets ")#mi("{f_t: D(0,1) \\rightarrow U_t}")#text(" to be the conformal maps with ")#mi("{f_t(0)=0}")#text(" and ")#mi("{f^{\\prime}_t(0)>0}")#text(", then ")#mi("{f_0 = f}")#text(" (by the uniqueness of Riemann mapping) and by the Carathéodory kernel theorem, ")#mi("{f_s}")#text(" converges locally uniformly to ")#mi("{f_t}")#text(" as ")#mi("{s \\rightarrow t}")#text(". In particular, the conformal radii ")#mi("{f^{\\prime}_t(0)}")#text(" are continuous in ")#mi("{t}")#text(". Reparameterising in ")#mi("{t}")#text(" one can then obtain the required Loewner chain.")

#text("Now suppose ")#mi("{f}")#text(" is only univalent on ")#mi("{D(0,1)}")#text(". As in the proof of Theorem ")#link(<tao-473c3cba6f0b66454d76>)[#text("15")]#text(", one can express ")#mi("{f}")#text(" as the locally uniform limit of schlicht functions ")#mi("{f_n}")#text(", each of which extends univalently to some larger disk ")#mi("{D(0,1+\\varepsilon_n)}")#text(". By the preceding discussion, each of the ")#mi("{f_n}")#text(" extends to a Loewner chain ")#mi("{(f_{n,t})_{t>0}}")#text(". From the Lipschitz bounds (and the Koebe distortion theorem) one sees that these chains are locally uniformly equicontinuous in ")#mi("{t}")#text(" and ")#mi("{z}")#text(", uniformly in ")#mi("{n}")#text(", and hence by Arzela-Ascoli we can pass to a subsequence that converges locally uniformly in ")#mi("{t,z}")#text(" to a limit ")#mi("{(f_t)_{t>0}}")#text("; one can also assume that the transition functions ")#mi("{\\phi_{n,t \\leftarrow s}}")#text(" converge locally uniformly to limits ")#mi("{\\phi_{t \\leftarrow s}}")#text(". It is then not difficult by Hurwitz theorem to verify the limiting relations ")#link(<tao-07026a4df5486d62e512>)[#text("(9)")]#text(", ")#link(<tao-db669af634b75c7f2984>)[#text("(11)")]#text(", and that ")#mi("{(f_t)_{t>0}}")#text(" is a Loewner chain with ")#mi("{f_0=f}")#text(" as desired. ")#mi("\\Box")

#text("Suppose that ")#mi("{0 \\leq s < t < \\infty}")#text(" are close to each other: ")#mi("{s \\approx t}")#text(". Then one heuristically has the approximations")

#align(center)[#tao-fit-display[#mitex("\\frac{1 + e^{s-t}}{1-e^{s-t}} \\approx \\frac{2}{t-s}; \\quad \\frac{z - \\phi_{t \\leftarrow s}(z)}{z + \\phi_{t \\leftarrow s}(z)} \\approx \\frac{1}{2z} (z - \\phi_{t \\leftarrow s}(z))")]]

#text("and hence by ")#link(<tao-48d4a7bd3a31b5c7366c>)[#text("(12)")]#text(" and some rearranging")

#align(center)[#tao-fit-display[#mitex("\\phi_{t \\leftarrow s}(z) \\approx z + (s-t) z p_{t \\leftarrow s}(z)")]]

#text("and hence on applying ")#mi("{f_t}")#text(", ")#link(<tao-07026a4df5486d62e512>)[#text("(9)")]#text(", and the Newton approximation")

#align(center)[#tao-fit-display[#mitex("f_s(z) \\approx f_t(z) + (s-t) z f^{\\prime}_t(z) p_{t \\leftarrow s}(z).")]]

#text("This suggests that the ")#mi("{f_t}")#text(" should obey the ")#emph[#text("Loewner equation")]#text(" ")#metadata(none) <tao-61098a4bf2a5e216533e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\partial_t f_t(z) = z f^{\\prime}_t(z) p_t(z)")]]

#text("for some Herglotz function ")#mi("{p_t}")#text(". This is essentially the case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 21 (Loewner equation)")]#text(" ")#metadata(none) <tao-6c1ff09db3a73dc4a854>#text(" Let ")#mi("{(f_t)_{t \\geq 0}}")#text(" be a Loewner chain. Then, for ")#mi("{t}")#text(" outside of an exceptional set ")#mi("{E \\subset [0,+\\infty)}")#text(" of Lebesgue measure zero, the functions ")#mi("{f_t(z)}")#text(" are differentiable in time for each ")#mi("{z \\in D(0,1)}")#text(", and obey the equation ")#link(<tao-61098a4bf2a5e216533e>)[#text("(14)")]#text(" for all ")#mi("{t \\in [0,+\\infty) \\backslash E}")#text(" and ")#mi("{z \\in D(0,1)}")#text(", and some Herglotz function ")#mi("{p_t}")#text(" for each ")#mi("{t \\in E}")#text(" with ")#mi("{p_t(0)=1}")#text(". Furthermore, the maps ")#mi("{t \\mapsto p_t(z)}")#text(" are measurable for every ")#mi("{z \\in D(0,1)}")#text(".")
]

#emph[#text("Proof:")]#text(" From Lemma ")#link(<tao-adb23c499622d93615d0>)[#text("19")]#text(", the function ")#mi("{t \\mapsto f_t(z)}")#text(" is Lipschitz continuous, and thus differentiable almost everywhere, for each ")#mi("{z \\in D(0,1)}")#text(". Here we run into a technical issue in that the exceptional set of times ")#mi("{t}")#text(" in which differentiability fails can depend on ")#mi("{z}")#text(", and there are uncountably many such ")#mi("{z}")#text("‘s. However one can avoid this issue using the Cauchy integral formula as follows. For any fixed ")#mi("{0 < r < 1}")#text(" and ")#mi("{t}")#text(" in a compact range ")#mi("{0 \\leq t \\leq T}")#text(", the functions ")#mi("{f_t}")#text(" are uniformly bounded on ")#mi("{\\overline{D(0,r)}}")#text(" by the Koebe distortion theorem, and by Fubini’s theorem we have for almost all ")#mi("{t}")#text(" in this range that the ")#mi("{f_t(z)}")#text(" are differentiable at ")#mi("{t}")#text(" for almost all ")#mi("{z \\in \\partial D(0,r)}")#text(". By the Cauchy integral formula and dominated convergence we then conclude that for all such times ")#mi("{t}")#text(", we in fact have ")#mi("{f_t(z)}")#text(" differentiable at ")#mi("{t}")#text(" for ")#emph[#text("every")]#text(" ")#mi("{t \\in D(0,r)}")#text(". Sending ")#mi("{r}")#text(" to ")#mi("{1}")#text(", we can thus find a universal measure zero set ")#mi("{E}")#text(" of times ")#mi("{t}")#text(", outside of which ")#mi("{t \\mapsto f_t(z)}")#text(" is differentiable for all ")#mi("{z \\in D(0,1)}")#text(". The argument in fact shows that this differentiability is locally uniform in ")#mi("{z}")#text(".")

#text("Let ")#mi("{t \\in [0,+\\infty) \\backslash E}")#text(", and let ")#mi("{z \\in D(0,1)}")#text(". Then as ")#mi("{s}")#text(" approaches ")#mi("{t}")#text(" from below, we have")

#align(center)[#tao-fit-display[#tao-math("f_s(z) = f_t(z) + (s-t) \\partial_t f_t(z) + o(\\left|s-t\\right|)", block: true)]]

#text("locally uniformly in ")#mi("{z}")#text("; from ")#link(<tao-07026a4df5486d62e512>)[#text("(9)")]#text(" and Newton approximation we thus have")

#align(center)[#tao-fit-display[#tao-math("\\phi_{t \\leftarrow s}(t) = z + (s-t) \\partial_t f_t(z) / f^{\\prime}_t(z) + o(\\left|s-t\\right|)", block: true)]]

#text("which implies that")

#align(center)[#tao-fit-display[#mitex("\\frac{z - \\phi_{t \\leftarrow s}(z)}{z + \\phi_{t \\leftarrow s}(z)} = (1+o(1)) \\frac{t-s}{2z} \\frac{\\partial_t f_t(z)}{f^{\\prime}_t(z)}.")]]

#text("Also we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1 + e^{s-t}}{1-e^{s-t}} = (1 + o(1)) \\frac{2}{t-s}")]]

#text("and hence by ")#link(<tao-48d4a7bd3a31b5c7366c>)[#text("(12)")]

#align(center)[#tao-fit-display[#mitex("p_{t \\leftarrow s}(z) = (1+o(1)) \\frac{\\partial_t f_t(z)}{z f^{\\prime}_t(z)}.")]]

#text("Taking limits, we see that the function ")#mi("{p_t(z) := \\frac{\\partial_t f_t(z)}{z f^{\\prime}_t(z)}}")#text(" is Herglotz with ")#mi("{p_t(0)=1}")#text(", giving the claim. It is also easy to verify the measurability (because derivatives of Lipschitz functions are measurable). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 22")]#text(" The Loewner chain ")#link(<tao-2cecb41e40144e186719>)[#text("(7)")]#text(" solves the Loewner equation with the Herglotz function ")#mi("{p_t(z) = \\frac{1-z}{1+z}}")#text(". With the rotated Koebe chains ")#link(<tao-de7ee32ce67a8a2c340d>)[#text("(8)")]#text(", we instead have ")#mi("{p_t(z) = \\frac{1-e^{i\\theta} z}{1+e^{i\\theta} z}}")#text(".")
]

#text("Although we will not need it in this set of notes, there is also a converse implication that for every family ")#mi("{p_t}")#text(" of Herglotz functions depending measurably on ")#mi("{t}")#text(", one can associate a Loewner chain.")

#text("Let us now Taylor expand a Loewner chain ")#mi("{f_t(z)}")#text(" at each time ")#mi("{t}")#text(" as")

#align(center)[#tao-fit-display[#mitex("f_t(z) = a_1(t) z + a_2(t) z^2 + a_3(t) z^3 + \\dots;")]]

#text("as ")#mi("{f^{\\prime}_t(0)=e^t}")#text(", we have ")#mi("{a_1(t) = e^t}")#text(". As ")#mi("{f_t(z)}")#text(" is differentiable in almost every ")#mi("{t}")#text(" for each ")#mi("{z}")#text(", and is locally uniformly continuous in ")#mi("{z}")#text(", we see from the Cauchy integral formulae that the ")#mi("{a_n(t)}")#text(" are also differentiable almost everywhere in ")#mi("{t}")#text(". If we similarly write")

#align(center)[#tao-fit-display[#mitex("p_t(z) = c_0(t) + c_1(t) z + c_2(t) z^2 + \\dots")]]

#text("for all ")#mi("{t}")#text(" outside of ")#mi("{E}")#text(", then ")#mi("{c_0(t)=1}")#text(", and we obtain the equations")

#align(center)[#tao-fit-display[#mitex("\\partial_t a_n(t) = \\sum_{j=1}^n j a_j(t) c_{n-j}(t)")]]

#text("for every ")#mi("{n}")#text(", thus ")#metadata(none) <tao-43d3a87fd00dae75563b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\partial_t a_2(t) = 2 a_2(t) + c_1(t) e^t")]]

#metadata(none) <tao-14188f96605bd882a5e2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\partial_t a_3(t) = 3 a_3(t) + 2 c_1(t) a_2(t) + e^t c_2(t)")]]

#text("and so forth. For instance, for the Loewner chain ")#link(<tao-2cecb41e40144e186719>)[#text("(7)")]#text(" one can verify that ")#mi("{a_n(t) = ne^t}")#text(" and ")#mi("{c_n(t) = 2 (-1)^n}")#text(" for ")#mi("{n \\geq 1}")#text(" solve these equations. For ")#link(<tao-de7ee32ce67a8a2c340d>)[#text("(8)")]#text(" one instead has ")#mi("{a_n(t) = e^{i(n-1) \\theta} n e^t}")#text(" and ")#mi("{c_n(t) = 2 (-1)^n e^{in\\theta}}")#text(".")#linebreak()#text(" We have the following bounds on the first few coefficients of ")#mi("{p}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" ")#metadata(none) <tao-a7e7e2f59b128bdb0aa6>#text(" Let ")#mi("{p(z) = 1 + c_1 z + c_2 z^2 + \\dots}")#text(" be a Herglotz function with ")#mi("{p(0)=1}")#text(". Let ")#mi("{\\mu}")#text(" be the measure coming from the Herglotz representation theorem.")

#list(
[#text("(i) Show that ")#mi("{c_n = 2 \\int_0^{2\\pi} e^{-int}\\ d\\mu(t)}")#text(" for all ")#mi("{n \\geq 1}")#text(". In particular, ")#tao-math("{\\left|c_n\\right| \\leq 2}", block: false)#text(" for all ")#mi("{n \\geq 1}")#text(". Use this to give an alternate proof of the upper bound in the Harnack inequality.")],
[#text("(ii) Show that ")#mi("{(\\mathrm{Re}(c_1))^2 \\leq 2 + \\mathrm{Re} c_2}")#text(".")]
)
]

#text("We can use this to establish the first two cases of the Bieberbach conjecture:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 24 (")#mi("{n=2,3}")#text(" cases of Bieberbach)")]#text(" ")#metadata(none) <tao-a212f07276961212b0ec>#text(" If ")#mi("{f(z) = z + a_2 z^2 + a_3 z^3 + \\dots}")#text(" is schlicht, then ")#tao-math("{\\left|a_2\\right| \\leq 2}", block: false)#text(" and ")#tao-math("{\\left|a_3\\right| \\leq 3}", block: false)#text(".")
]

#text("The bound ")#tao-math("{\\left|a_2\\right| \\leq 2}", block: false)#text(" is not new, and indeed was implicitly used many times in the above arguments, but we include it to illustrate the use of the equations ")#link(<tao-43d3a87fd00dae75563b>)[#text("(15)")]#text(", ")#link(<tao-14188f96605bd882a5e2>)[#text("(16)")]#text(".")

#emph[#text("Proof:")]#text(" By Lemma ")#link(<tao-1154fd7ea50413bfda4b>)[#text("20")]#text(", we can write ")#mi("{f = f_0}")#text(" (and ")#mi("{a_n = a_n(0)}")#text(") for some Loewner chain ")#mi("{(f_t)_{t \\geq 0}}")#text(".")

#text("We can write ")#link(<tao-43d3a87fd00dae75563b>)[#text("(15)")]#text(" as ")#mi("{\\partial_t (e^{-2t} a_2(t)) = c_1(t) e^{-t}}")#text(". On the other hand, from the Koebe distortion theorem applied to the schlicht functions ")#mi("{e^{-t} f_t}")#text(", we have ")#mi("{a_2(t) = O( e^{t})}")#text(", so in particular ")#mi("{e^{-2t} a_2(t)}")#text(" goes to zero at infinity. We can integrate from ")#mi("{0}")#text(" to infinity to obtain ")#metadata(none) <tao-397824af343ea98c7faf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("a_2 = - \\int_0^\\infty c_1(t) e^{-t}\\ dt.")]]

#linebreak()#text(" ")#text(" From Harnack’s inequality we have ")#tao-math("{\\left|c_1(t)\\right| \\leq 2}", block: false)#text(", giving the required bound ")#tao-math("{\\left|a_2\\right| \\leq 2}", block: false)#text(".")#linebreak()#text(" In a similar vein, writing ")#link(<tao-14188f96605bd882a5e2>)[#text("(16)")]#text(" as")

#tao-aligned(keep: true)[


#tao-math("\\partial_t (e^{-3t} a_3(t))  & = 2 e^{-3t} c_1(t) a_2(t) + e^{-2t} c_2(t)", block: true)



#tao-math(" & = 2 (e^{-2t} a_2(t)) \\partial_t (e^{-2t} a_2(t)) + e^{-2t} c_2(t)", block: true)
]

#text("we obtain")

#align(center)[#tao-fit-display[#mitex("\\partial_t (e^{-3t} a_3(t) - e^{-4t} a_2(t)^2) = e^{-2t} c_2(t).")]]

#text("As ")#mi("{a_2(t), a_3(t) = O(e^t)}")#text(", we may integrate from ")#mi("{0}")#text(" to infinity to obtain the identity")

#align(center)[#tao-fit-display[#mitex("a_3 - a_2^2 = - \\int_0^\\infty e^{-2t} c_2(t)\\ dt.")]]

#text("Taking real parts using Exercise ")#link(<tao-a7e7e2f59b128bdb0aa6>)[#text("23")]#text("(ii) and ")#link(<tao-397824af343ea98c7faf>)[#text("(17)")]#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Re} a_3 - \\mathrm{Re}((\\int_0^\\infty c_1(t) e^{-t}\\ dt)^2) \\leq 1 - \\int_0^\\infty e^{-2t} (\\mathrm{Re}(c_1(t)))^2\\ dt.")]]

#text("Since ")#mi("{\\mathrm{Re}(z^2) \\leq (\\mathrm{Re}(z))^2}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Re} a_3 \\leq 1 + (\\int_0^\\infty f(t) e^{-t}\\ dt)^2 - \\int_0^\\infty e^{-2t} f(t)^2\\ dt")]]

#text("where ")#mi("{f(t) := \\mathrm{Re} c_1(t)}")#text(". By Cauchy-Schwarz, we have ")#mi("{(\\int_0^\\infty f(t) e^{-t}\\ dt)^2 \\leq \\int_0^\\infty f(t)^2 e^{-t}\\ dt}")#text(", and from the bound ")#tao-math("{f(t)^2 \\leq \\left|c_1(t)\\right|^2 \\leq 4}", block: false)#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Re} a_3 \\leq 1 + 4 \\int_0^\\infty (e^{-t} - e^{-2t})\\ dt = 3.")]]

#text("Replacing ")#mi("{f(z)}")#text(" by the schlicht function ")#mi("{z \\mapsto e^{-i\\theta} f(e^{i\\theta} z)}")#text(" (which rotates ")#mi("{a_3}")#text(" by ")#mi("{e^{2i\\theta}}")#text(") and optimising in ")#mi("{\\theta}")#text(", we obtain the claim ")#tao-math("{\\left|a_3\\right| \\leq 3}", block: false)#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" Show that equality in the above bound ")#tao-math("{\\left|a_3\\right| \\leq 3}", block: false)#text(" is only attained when ")#mi("{f}")#text(" is a rotated Koebe function.")
]

#text("The Loewner equation ")#link(<tao-61098a4bf2a5e216533e>)[#text("(14)")]#text(" takes a special form in the case of slit domains. Indeed, let ")#mi("{U = {\\bf C} \\backslash \\{ \\gamma(t): t \\geq 0 \\}}")#text(" be a slit domain not containing the origin, with conformal radius ")#mi("{1}")#text(" around ")#mi("{0}")#text(", and let ")#mi("{(f_t)_{t \\geq 0}}")#text(" be the Loewner chain with ")#mi("{f_0(D(0,1)) = U}")#text(". We can parameterise ")#mi("{\\gamma}")#text(" so that the sets ")#mi("{U_{t_0} := {\\bf C} \\backslash \\{ \\gamma(t): t \\geq t_0\\}}")#text(" have conformal radius ")#mi("{e^{t_0}}")#text(" around ")#mi("{0}")#text(" for every ")#mi("{t_0 \\geq 0}")#text(", in which case we see that ")#mi("{f_{t_0}}")#text(" must be the unique conformal map from ")#mi("{D(0,1)}")#text(" to ")#mi("{U_{t_0}}")#text(" with ")#mi("{f_{t_0}(0)=0}")#text(" and ")#mi("{f^{\\prime}_{t_0}>0}")#text(". For instance, for the chain ")#link(<tao-2cecb41e40144e186719>)[#text("(7)")]#text(" we would have ")#mi("{\\gamma(t) = -e^t/4}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 26 (Loewner equation for slit domains)")]#text(" ")#metadata(none) <tao-dfdee5e362199cb341b4>#text(" In the above situation, we have the Loewner equation holding with ")#metadata(none) <tao-75a1b65144b46b8739e3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("p_t(z) = \\frac{1+e^{i\\theta(t)} z}{1-e^{i\\theta(t)} z}")]]

#text("for almost all ")#mi("{t}")#text(" and some measurable ")#mi("{\\theta: [0,+\\infty) \\rightarrow {\\bf R}}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{t>0}")#text(" be a time where the Loewner equation holds. For ")#mi("{0 < s < t}")#text(", the function ")#mi("{f_t: D(0,1) \\rightarrow {\\bf C} \\backslash \\gamma([t,+\\infty))}")#text(" extends continuously to the boundary, and is two-to-one on the split ")#mi("{\\gamma([t,+\\infty))}")#text(", except at the tip ")#mi("{\\gamma(t)}")#text(" where there is a single preimage ")#mi("{e^{i\\theta(t)}}")#text(" on the unit circle; this can be seen by taking a holomorphic square root of ")#mi("{f(t) - \\gamma(t)}")#text(", using a Möbius transformation to map the resulting image to a set bounded by a Jordan curve, and applying Carathéodory’s theorem (Theorem 20 from ")#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/")[#text("Notes 2")]#text(") to the resulting conformal map. The image ")#mi("{\\phi_{t \\leftarrow s}(D(0,1)) = f_t^{-1}( f_s(D(0,1)))}")#text(" is then ")#mi("{D(0,1)}")#text(" with a Jordan arc ")#mi("{\\{ \\eta_t(t^{\\prime}): s \\leq t \\leq t^{\\prime} \\}}")#text(" removed, where ")#mi("{\\eta_t(t) =: e^{i\\theta(t)}}")#text(" is a point on the boundary of the sphere. Applying Carathéodory’s theorem to a holomorphic square root of ")#mi("{\\phi_{t \\leftarrow s} - \\eta_t(s)}")#text(", we see that ")#mi("{\\phi_{t \\leftarrow s}}")#text(" extends continuously to be a map from ")#mi("{\\overline{D(0,1)}}")#text(" to ")#mi("{\\overline{D(0,1)}}")#text(", with an arc ")#mi("{\\{ e^{i\\theta}: \\theta \\in I_{t,s} \\}}")#text(" on the boundary mapping (in two-to-one fashion) to the arc ")#mi("{\\{ \\eta_t(t^{\\prime}): s \\leq t \\leq t^{\\prime} \\}}")#text(", and the endpoints of this arc mapping to ")#mi("{e^{i\\theta(t)}}")#text(". From this and ")#link(<tao-48d4a7bd3a31b5c7366c>)[#text("(12)")]#text(", we see that ")#mi("{\\lim_{r \\rightarrow 1^-} \\mathrm{Re}(p_{t \\leftarrow s})(re^{i\\theta})}")#text(" converges to zero outside of the arc ")#mi("{I_{t,s}}")#text(", which by the Herglotz representation theorem implies that the measure ")#mi("{\\mu_{t \\leftarrow s}}")#text(" associated to ")#mi("{p_{t \\leftarrow s}}")#text(" is supported on the arc ")#mi("{I_{t,s}}")#text(". An inspection of the proof of Carathéodory’s theorem also reveals that the ")#mi("{\\phi_{t \\leftarrow s}}")#text(" are equicontinuous on ")#mi("{\\overline{D(0,1)}}")#text(" as ")#mi("{s \\rightarrow t^-}")#text(", and thus converge uniformly to ")#mi("{\\phi_{t \\leftarrow t}}")#text(" (which is the identity function) as ")#mi("{s \\rightarrow t^-}")#text(". This implies that ")#mi("{I_{t,s}}")#text(" must converge to the point ")#mi("{\\theta(t)}")#text(" as ")#mi("{s}")#text(" approaches ")#mi("{t}")#text(", and so ")#mi("{\\mu_{t \\leftarrow s}}")#text(" converges vaguely to the Dirac mass at ")#mi("{\\theta(t)}")#text(". Since ")#mi("{p_{t \\leftarrow s}}")#text(" converges locally uniformly to ")#mi("{p_t}")#text(", we conclude the formula ")#link(<tao-75a1b65144b46b8739e3>)[#text("(18)")]#text(". As ")#mi("{p_t}")#text(" depends measurably in ")#mi("{t}")#text(", we conclude that ")#mi("{\\theta}")#text(" does also. ")#mi("\\Box")

#text("In fact one can show that ")#mi("{\\theta}")#text(" extends to a continuous function ")#mi("{\\theta: [0,+\\infty) \\rightarrow {\\bf R}}")#text(", and that the Loewner equation holds for all ")#mi("{t}")#text(", but this is a bit trickier to show (it requires some further distortion estimates on conformal maps, related to the arguments used to prove Carathéodory’s theorem in the previous notes) and will not be done here. One can think of the function ")#mi("{\\theta}")#text(" as “driving force” that incrementally enlarges the slit via the Loewner equation; this perspective is often used when studying the ")#link("https://en.wikipedia.org/wiki/Schramm%E2%80%93Loewner_evolution")[#text("Schramm-Loewner evolution")]#text(", which is the topic of the next (and final) set of notes.")

#heading(level: 1)[#strong[#text(" — 3. The Bieberbach conjecture — ")]]

#text("We now turn to the resolution of the Bieberbach (and Robertson) conjectures. We follow the simplified treatment of ")#link("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/???")[#text("de Branges’ original proof")]#text(", ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=792819")[#text("due to FitzGerald and Pommerenke")]#text(", though we omit the proof of one key ingredient, namely the non-negativity of a certain hypergeometric function.")

#text("The first step is to work not with the Taylor coefficients of a schlicht function ")#mi("{f(z)}")#text(" or with an odd schlicht function ")#mi("{g(z)}")#text(", but rather with the (normalised) logarithm ")#mi("{\\log \\frac{f(z)}{z}}")#text(" of a schlicht function ")#mi("{f}")#text(", as the coefficients end up obeying more tractable equations. To transfer to this setting we need the following elementary inequalities relating the coefficients of a power series with the coefficients of its exponential.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 27 (Second Lebedev-Milin inequality)")]#text(" ")#metadata(none) <tao-99a2c2fe1fbfc92b3d69>#text(" Let ")#mi("{\\sum_{n=1}^\\infty c_n z^n}")#text(" be a formal power series with complex coefficients and no constant term, and let ")#mi("{\\sum_{n=0}^\\infty b_n z^n}")#text(" be its formal exponential, thus ")#metadata(none) <tao-1351d0d173e9bc9363f3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\sum_{n=0}^\\infty b_n z^n = \\exp( \\sum_{n=1}^\\infty c_n z^n )")]]

#text("where ")#mi("{\\exp(w)}")#text(" is the formal series ")#mi("{1 + w + \\frac{w^2}{2!} + \\frac{w^3}{3!} + \\dots}")#text(". Then for any ")#mi("{n \\geq 0}")#text(", one has ")#metadata(none) <tao-ad380cbfc34cc3995c53>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("\\frac{1}{n+1} \\sum_{k=0}^n \\left|b_k\\right|^2 \\leq \\exp( \\frac{1}{n+1} \\sum_{k=1}^n (n+1-k) (k \\left|c_k\\right|^2 - \\frac{1}{k}) ).", block: true)]]
]

#emph[#text("Proof:")]#text(" If we formally differentiate ")#link(<tao-1351d0d173e9bc9363f3>)[#text("(19)")]#text(" in ")#mi("{z}")#text(", we obtain the identity")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty b_n n z^{n-1} = (\\sum_{n=1}^\\infty c_n n z^{n-1}) (\\sum_{n=0}^\\infty b_n z^n);")]]

#text("extracting the ")#mi("{z^m}")#text(" coefficient for any ")#mi("{m \\geq 1}")#text(", we obtain the formula")

#align(center)[#tao-fit-display[#mitex("b_{m} = \\frac{1}{m} \\sum_{k=1}^{m} k c_k b_{m-k}.")]]

#text("By Cauchy-Schwarz, we thus have ")#metadata(none) <tao-7292b55d8cfc45bafdf2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\left|b_{m}\\right|^2 \\leq \\frac{1}{m^2} (\\sum_{k=1}^{m} k^2 \\left|c_k\\right|^2) (\\sum_{k=0}^{m-1} \\left|b_n\\right|^2)", block: true)]]

#text("which we can rearrange as")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{m+1} \\sum_{k=0}^{m} \\left|b_{k}\\right|^2 \\leq \\frac{1}{m} \\sum_{k=0}^{m-1} \\left|b_{k}\\right|^2 ( 1 - \\frac{1}{m+1} + \\frac{1}{m(m+1)} (\\sum_{k=1}^{m} k^2 \\left|c_k\\right|^2)).", block: true)]]

#text("Using ")#mi("{1+x \\leq \\exp(x)}")#text(" and telescoping series, it thus suffices to prove the identity")

#align(center)[#tao-fit-display[#tao-math("\\sum_{m=1}^n (-\\frac{1}{m+1} + \\frac{1}{m(m+1)} \\sum_{k=1}^m k^2 \\left|c_k\\right|^2) = \\frac{1}{n+1} \\sum_{k=1}^n (n+1-k) (k \\left|c_k\\right|^2 - \\frac{1}{k}).", block: true)]]

#text("But this follows from observing that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{n+1} \\sum_{k=1}^n (n+1-k) \\frac{1}{k} = \\sum_{k=1}^n \\frac{1}{k} - \\frac{n}{n+1} = \\sum_{m=1}^n \\frac{1}{m+1}")]]

#text("and that")

#align(center)[#tao-fit-display[#mitex("k^2 \\sum_{m=k}^n \\frac{1}{m(m+1)} = k^2 (\\frac{1}{k} - \\frac{1}{n+1}) = \\frac{1}{n+1} (n+1-k) k")]]

#text("for all ")#mi("{1 \\leq k \\leq n}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" Show that equality holds in ")#link(<tao-ad380cbfc34cc3995c53>)[#text("(20)")]#text(" for a given ")#mi("{n}")#text(" if and only if there is ")#mi("{\\theta \\in {\\bf R}}")#text(" such that ")#mi("{c_k = e^{ik\\theta}/k}")#text(" for all ")#mi("{k=1,\\dots,n}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29 (First Lebedev-Milin inequality)")]#text(" With the notation as in the above lemma, and under the additional assumption ")#tao-math("{\\sum_{k=1}^\\infty k \\left|c_k\\right|^2 < \\infty}", block: false)#text(", prove that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{k=0}^\\infty \\left|b_k\\right|^2 \\leq \\exp( \\sum_{k=1}^\\infty k \\left|c_k\\right|^2 ).", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" using the Cauchy-Schwarz inequality as above, first show that the power series ")#tao-math("{\\sum_{k=0}^\\infty \\left|b_k\\right|^2 z^k}", block: false)#text(" is bounded term-by-term by the power series of ")#tao-math("{\\exp( \\sum_{k=1}^\\infty k \\left|c_k\\right|^2 z^k)}", block: false)#text(".) When does equality occur?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30 (Third Lebedev-Milin inequality)")]#text(" With the notation as in the above lemma, show that")

#align(center)[#tao-fit-display[#tao-math("\\left|b_n\\right|^2 \\leq \\exp( \\sum_{k=1}^n (k \\left|c_k\\right|^2 - \\frac{1}{k}) ).", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" use the second Lebedev-Milin inequality and ")#link(<tao-7292b55d8cfc45bafdf2>)[#text("(21)")]#text(", together with the calculus inequality ")#mi("{x e^{-x} \\leq e}")#text(" for all ")#mi("{x}")#text(".) When does equality occur?")
]

#text("Using these inequalities, one can reduce the Robertson and Bieberbach conjectures to the following conjecture of Milin, also proven by de Branges:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 31 (Milin conjecture)")]#text(" Let ")#mi("{f: D(0,1) \\rightarrow {\\bf C}}")#text(" be a schlicht function. Let ")#mi("{\\log \\frac{f(z)}{z}}")#text(" be the branch of the logarithm of ")#mi("{f(z)/z}")#text(" that equals ")#mi("{0}")#text(" at the origin, thus one has")

#align(center)[#tao-fit-display[#mitex("\\log \\frac{f(z)}{z} = d_1 z + d_2 z^2 + \\dots")]]

#text("for some complex coefficients ")#mi("{d_1,d_2,\\dots}")#text(". Then one has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{k=1}^n (n+1-k) (k \\left|d_k\\right|^2 - \\frac{4}{k}) \\leq 0", block: true)]]

#text("for all ")#mi("{n \\geq 1}")#text(".")
]

#text("Indeed, if")

#align(center)[#tao-fit-display[#mitex("g(z) = b_1 z + b_3 z^3 + b_5 z^5 + \\dots")]]

#text("is an odd schlicht function, let ")#mi("{f}")#text(" be the schlicht function given by ")#link(<tao-31327e782a9f8d09a978>)[#text("(4)")]#text(", then")

#align(center)[#tao-fit-display[#mitex("\\exp( \\frac{1}{2} \\log \\frac{f(z)}{z} ) = \\frac{g(z^{1/2})}{z^{1/2}} = b_1 + b_3 z + b_5 z^2 + \\dots.")]]

#text("Applying Lemma ")#link(<tao-99a2c2fe1fbfc92b3d69>)[#text("27")]#text(" with ")#mi("{c_n := d_n/2}")#text(", we obtain the Robertson conjecture, and the Bieberbach conjecture follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 32")]#text(" If ")#mi("{f}")#text(" is the Koebe function ")#link(<tao-4f13c5c39e34d3f8af83>)[#text("(1)")]#text(", then")

#align(center)[#tao-fit-display[#mitex("\\log \\frac{f(z)}{z} = - 2\\log (1-z) = 2z + \\frac{2}{2} z^2 + \\frac{2}{3} z^3 + \\dots")]]

#text("so in this case ")#mi("{d_k = \\frac{2}{k}}")#text(" and ")#tao-math("{k \\left|d_k\\right|^2 - \\frac{4}{k} = 0}", block: false)#text(". Similarly, for the rotated Koebe function ")#link(<tao-f42546d5ecdd45250980>)[#text("(2)")]#text(" one has ")#mi("{d_k = \\frac{2}{k} e^{ik\\theta}}")#text(" and again ")#tao-math("{k \\left|d_k\\right|^2 - \\frac{4}{k} = 0}", block: false)#text(". If one works instead with the dilated Koebe function ")#mi("{e^t f}")#text(", we have ")#mi("{\\log \\frac{f(z)}{z} = t + d_1 z + d_2 z^2 + \\dots}")#text(", thus the time parameter only affects the constant term in ")#mi("{\\log \\frac{f(z)}{z}}")#text(". This is already a hint that the coefficients of ")#mi("{\\log \\frac{f(z)}{z}}")#text(" could be worth studying further in this problem.")
]

#text("To prove the Milin conjecture, we use the Loewner chain method. It suffices by Theorem ")#link(<tao-473c3cba6f0b66454d76>)[#text("15")]#text(" and a limiting argument to do so in the case that ")#mi("{f(D(0,1))}")#text(" is a slit domain. Then, by Theorem ")#link(<tao-dfdee5e362199cb341b4>)[#text("26")]#text(", ")#mi("{f}")#text(" is the initial function ")#mi("{f_0}")#text(" of a Loewner chain ")#mi("{(f_t)_{t \\geq 0}}")#text(" that solves the Loewner equation")

#align(center)[#tao-fit-display[#mitex("\\partial_t f_t(z) = z f^{\\prime}_t(z) \\frac{1-e^{i\\theta(t)} z}{1+e^{i\\theta(t)} z}")]]

#text("for all ")#mi("{z}")#text(" and almost every ")#mi("{t}")#text(", and some function ")#mi("{\\theta: [0,+\\infty) \\rightarrow {\\bf R}}")#text(".")#linebreak()#text(" We can transform this into an equation for ")#mi("{\\log \\frac{f(z)}{z}}")#text(". Indeed, for non-zero ")#mi("{z}")#text(" we may divide by ")#mi("{f}")#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\log f_t(z) = z (\\frac{d}{dz} \\log f_t(z)) \\frac{1-e^{i\\theta(t)} z}{1+e^{i\\theta(t)} z}")]]

#text("(for any local branch of the logarithm) and hence")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\log \\frac{f_t(z)}{z} = (z \\frac{d}{dz} \\log \\frac{f_t(z)}{z} + 1) \\frac{1-e^{i\\theta(t)} z}{1+e^{i\\theta(t)} z}.")]]

#text("Since ")#mi("{f^{\\prime}_t(0)=e^t}")#text(", ")#mi("{\\log \\frac{f_t(z)}{z}}")#text(" is equal to ")#mi("{t}")#text(" at the origin (for an appropriate branch of the logarithm). Thus we can write")

#align(center)[#tao-fit-display[#mitex("\\log \\frac{f_t(z)}{z} = t + d_1(t) z + d_2(t) z^2 + \\dots.")]]

#text("The ")#mi("{d_n(t)}")#text(" are locally Lipschitz in ")#mi("{t}")#text(" (basically thanks to Lemma ")#link(<tao-adb23c499622d93615d0>)[#text("19")]#text(") and for almost every ")#mi("{t}")#text(" we have the Taylor expansions")

#tao-aligned(keep: true)[


#tao-math("\\partial_t \\log \\frac{f_t(z)}{z}  & = 1 +\\partial_t d_1(t) z + \\partial_t d_2(t) z^2 + \\dots", block: true)



#tao-math("z \\frac{d}{dz} \\log \\frac{f_t(z)}{z} + 1  & = 1 + d_1(t) z + 2 d_2(t) z^2 + \\dots", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\frac{1-e^{i\\theta(t)} z}{1+e^{i\\theta(t)} z} = 1 - 2e^{i\\theta(t)} z + 2 e^{2i\\theta(t)} z^2 - \\dots.")]]

#text("Comparing coefficients, we arrive at the system of ordinary differential equations ")#metadata(none) <tao-baf0e4c09449fe8b3e74>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\partial_t d_k(t) = k d_k(t) + 2 \\sum_{j=1}^{k-1} j d_j(t) (-e^{i\\theta(t)})^{k-j} + 2(-e^{i\\theta(t)})^{k}")]]

#text("for every ")#mi("{k \\geq 1}")#text(".")#linebreak()#text(" Fix ")#mi("{n \\geq 1}")#text(" (we will not need to use any induction on ")#mi("{n}")#text(" here). We would like to use the system ")#link(<tao-baf0e4c09449fe8b3e74>)[#text("(22)")]#text(" to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{k=1}^n (n+1-k) (k \\left|d_k(0)\\right|^2 - \\frac{4}{k}) \\leq 0.", block: true)]]

#text("The most naive attempt to do this would be to show that one has a monotonicity formula")

#align(center)[#tao-fit-display[#tao-math("\\partial_t \\sum_{k=1}^n (n+1-k) (k \\left|d_k(t)\\right|^2 - \\frac{4}{k}) \\geq 0", block: true)]]

#text("for all ")#mi("{t \\geq 0}")#text(", and that the expression ")#tao-math("{\\sum_{k=1}^n (n+1-k) (k \\left|d_k(0)\\right|^2 - \\frac{4}{k})}", block: false)#text(" goes to zero as ")#mi("{ \\rightarrow\\infty}")#text(", as the claim would then follow from the fundamental theorem of calculus. This turns out to not quite work; however it turns out that a slight modification of this idea does work. Namely, we introduce the quantities")

#align(center)[#tao-fit-display[#tao-math("\\Omega(t) := \\sum_{k=1}^n \\sigma_{k,n}(t) (k \\left|d_k(t)\\right|^2 - \\frac{4}{k})", block: true)]]

#text("where for each ")#mi("{k=1,\\dots,n}")#text(", ")#mi("{\\sigma_{k}: [0,+\\infty) \\rightarrow {\\bf R}}")#text(" is a continuously differentiable function to be chosen later. If we have the initial condition ")#metadata(none) <tao-ac1b5c0961a7269b6a05>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\sigma_{k}(0) = n+1-k")]]

#text("for all ")#mi("{k=1,\\dots,n}")#text(", then the Milin conjecture is equivalent to asking that ")#mi("{\\Omega(0) \\leq 0}")#text(". On the other hand, if we impose a boundary condition ")#metadata(none) <tao-931534c0c145d0a99631>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\lim_{t \\rightarrow \\infty} \\sigma_{k}(t) = 0")]]

#text("for ")#mi("{k=1,\\dots,n}")#text(", then we also have ")#mi("{\\Omega(t) \\rightarrow 0}")#text(" as ")#mi("{t \\rightarrow \\infty}")#text(", since ")#mi("{e^{-t} f_t}")#text(" is schlicht and hence ")#mi("{\\log \\frac{e^{-t} f(z)}{z} = \\log \\frac{f(z)}{z} - t}")#text(" is a normal family, implying that the ")#mi("{d_k(t)}")#text(" are bounded in ")#mi("{t}")#text(" for each ")#mi("{k}")#text(". Thus, to solve the Milin, Robertson, and Bieberbach conjectures, it suffices to find a choice of weights ")#mi("{\\sigma_k(t)}")#text(" obeying the initial and boundary conditions ")#link(<tao-ac1b5c0961a7269b6a05>)[#text("(23)")]#text(", ")#link(<tao-931534c0c145d0a99631>)[#text("(24)")]#text(", and such that ")#metadata(none) <tao-3684878e765f8117fbb6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\partial_t \\Omega(t) \\geq 0")]]

#text("for almost every ")#mi("{t}")#text(" (note that ")#mi("{\\Omega}")#text(" will be Lipschitz, so the fundamental theorem of calculus applies).")#linebreak()#text(" Let us now try to establish ")#link(<tao-3684878e765f8117fbb6>)[#text("(25)")]#text(" using ")#link(<tao-baf0e4c09449fe8b3e74>)[#text("(22)")]#text(". We first write ")#mi("{\\kappa(t) := -e^{i\\theta(t)}}")#text(", and drop the explicit dependence on ")#mi("{t}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\partial_t d_k = k d_k + 2 \\sum_{j=1}^{k-1} j d_j \\kappa^{k-j} + 2 \\kappa^k")]]

#text("for ")#mi("{k \\geq 1}")#text(". To simplify this equation, we make a further transformation, introducing the functions")

#align(center)[#tao-fit-display[#mitex("f_k := \\sum_{j=1}^k j d_j \\kappa^{-j}")]]

#text("(with the convention ")#mi("{f_0=0}")#text("); then we can write the above equation as")

#align(center)[#tao-fit-display[#mitex("\\partial_t d_k = \\kappa^n ( f_k + f_{k-1} + 2 ).")]]

#text("We can recover the ")#mi("{d_k}")#text(" from the ")#mi("{f_k}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("d_k = \\frac{1}{k} \\kappa^k (f_k - f_{k-1}).")]]

#text("It may be worth recalling at this point that in the example of the rotated Koebe Loewner chain ")#link(<tao-f42546d5ecdd45250980>)[#text("(2)")]#text(" one has ")#mi("{d_k = \\frac{2}{k} e^{ik\\theta}}")#text(", ")#mi("{\\kappa = -e^{i\\theta}}")#text(", and ")#mi("{f_k = -1 + (-1)^k}")#text(", for some real constant ")#mi("{\\theta}")#text(". Observe that ")#mi("{f_k}")#text(" has a simpler form than ")#mi("{d_k}")#text(" in this example, suggesting again that the decision to transform the problem to one about the ")#mi("{f_k}")#text(" rather than the ")#mi("{d_k}")#text(" is on the right track.")#linebreak()#text(" We now calculate")

#tao-aligned(keep: true)[


#tao-math("\\partial_t \\Omega(t)  & = \\sum_{k=1}^n 2 k \\sigma_k \\mathrm{Re} \\overline{d_k} \\partial_t d_k + (\\partial_t \\sigma_k) (k \\left|d_k\\right|^2 - \\frac{4}{k})", block: true)



#tao-math(" & = \\sum_{k=1}^n 2 k \\sigma_k \\mathrm{Re} \\overline{d_k} \\kappa^k (f_k + f_{k-1}+2) + \\frac{\\partial_t \\sigma_k}{k} (\\left|f_k - f_{k-1}\\right|^2 - 4)", block: true)



#tao-math(" & = \\sum_{k=1}^n 2 \\sigma_k \\mathrm{Re} ((\\overline{f_k} - \\overline{f_{k-1}}) (f_k + f_{k-1}+2)) + \\frac{\\partial_t \\sigma_k}{k} (\\left|f_k - f_{k-1}\\right|^2 - 4).", block: true)
]

#text("Conveniently, the unknown function ")#mi("{\\kappa}")#text(" no longer appears explicitly! Some simple algebra shows that")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{Re} (\\overline{f_k} - \\overline{f_{k-1}}) (f_k + f_{k-1}+2) = (\\left|f_k\\right|^2 + 2 \\mathrm{Re} f_k) - (\\left|f_{k-1}\\right|^2 + 2 \\mathrm{Re} f_{k-1})", block: true)]]

#text("and hence by summation by parts")

#align(center)[#tao-fit-display[#tao-math("\\partial_t \\Omega(t) = \\sum_{k=1}^n 2 (\\sigma_k - \\sigma_{k+1}) (\\left|f_k\\right|^2 + 2 \\mathrm{Re} f_k) + \\frac{\\partial_t \\sigma_k}{k} (\\left|f_k - f_{k-1}\\right|^2 - 4)", block: true)]]

#text("with the convention ")#mi("{\\sigma_{n+1}=0}")#text(".")#linebreak()#text(" In the example of the rotated Koebe function, with ")#mi("{f_k = -1 + (-1)^k}")#text(", the factors ")#tao-math("{\\left|f_k\\right|^2 + 2 \\mathrm{Re} f_k}", block: false)#text(" and ")#tao-math("{\\left|f_k - f_{k-1}\\right|^2 - 4}", block: false)#text(" both vanish, which is consistent with the fact that ")#mi("{\\Omega}")#text(" vanishes in this case regardless of the choice of weights ")#mi("{\\sigma_k}")#text(". So these two factors look to be related to each other. On the other hand, for more general choices of ")#mi("{f_k}")#text(", these two expressions do not have any definite sign. For comparison, the quantity ")#tao-math("{\\left|f_k + f_{k-1} + 2\\right|^2}", block: false)#text(" also vanishes when ")#mi("{f_k = -1 + (-1)^k}")#text(", and has a definite sign. So it is natural to see of these three factors are related to each other. After a little bit of experimentation, one eventually discovers the following elementary identity giving such a connection:")

#tao-aligned(keep: true)[


#tao-math("\\left|f_k - f_{k-1}\\right|^2 - 4  & = 2 (\\left|f_k\\right|^2 + 2 \\mathrm{Re} f_k) + 2 (\\left|f_{k-1}\\right|^2 + 2 \\mathrm{Re} f_{k-1})", block: true)



#tao-math(" & - \\left|f_k + f_{k-1} + 2\\right|^2.", block: true)
]

#text("Inserting this identity into the above equation, we obtain")

#tao-aligned(keep: true)[


#tao-math("\\partial_t \\Omega(t)  & = \\sum_{k=1}^n 2 (\\sigma_k - \\sigma_{k+1}) (\\left|f_k\\right|^2 + 2 \\mathrm{Re} f_k) + 2 \\frac{\\partial_t \\sigma_k}{k} (\\left|f_k\\right|^2 + 2 \\mathrm{Re} f_k)", block: true)



#tao-math(" & + 2 \\frac{\\partial_t \\sigma_k}{k} (\\left|f_{k-1}\\right|^2 + 2 \\mathrm{Re} f_{k-1}) - \\frac{\\partial_t \\sigma_k}{k} \\left|f_k + f_{k-1} + 2\\right|^2", block: true)
]

#text("which can be rearranged as")

#tao-aligned(keep: true)[


#tao-math("\\partial_t \\Omega(t)  & = 2 \\sum_{k=1}^n (\\sigma_k - \\sigma_{k+1} + \\frac{\\partial_t \\sigma_k}{k} + \\frac{\\partial_t \\sigma_{k+1}}{k+1}) (\\left|f_k\\right|^2 + 2 \\mathrm{Re} f_k)", block: true)



#tao-math(" & - \\sum_{k=1}^n \\frac{\\partial_t \\sigma_k}{k} \\left|f_k + f_{k_1} + 2\\right|^2.", block: true)
]

#text("We can kill the first summation by fiat, by imposing the requirement that the ")#mi("{\\sigma_k}")#text(" obey the system of differential equations ")#metadata(none) <tao-c4264b5b2189f12a5012>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\sigma_k - \\sigma_{k+1} = - \\frac{\\partial_t \\sigma_k}{k} - \\frac{\\partial_t \\sigma_{k+1}}{k+1},")]]

#text("for ")#mi("{k=1,\\dots,n}")#text("; then we just have")

#align(center)[#tao-fit-display[#tao-math("\\partial_t \\Omega(t) = - \\sum_{k=1}^n \\frac{\\partial_t \\sigma_k}{k} \\left|f_k + f_{k_1} + 2\\right|^2.", block: true)]]

#text("Hence if we also have the non-negativity condition ")#metadata(none) <tao-98a0c062075a36ed3ecd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("-\\partial_t \\sigma_k(t) \\geq 0")]]

#text("for all ")#mi("{k=1,\\dots,n}")#text(" and ")#mi("{t \\geq 0}")#text(", we will have obtained the desired monotonicity ")#link(<tao-3684878e765f8117fbb6>)[#text("(25)")]#text(".")#linebreak()#text(" To summarise, in order to prove the Milin conjecture for a fixed value of ")#mi("{n}")#text(", we need to find functions ")#mi("{\\sigma_1,\\dots,\\sigma_n}")#text(" obeying the initial condition ")#link(<tao-ac1b5c0961a7269b6a05>)[#text("(23)")]#text(", the boundary condition ")#link(<tao-931534c0c145d0a99631>)[#text("(24)")]#text(", the differential equation ")#link(<tao-c4264b5b2189f12a5012>)[#text("(26)")]#text(", and the nonnegativity condition ")#link(<tao-98a0c062075a36ed3ecd>)[#text("(27)")]#text(", with the convention ")#mi("{\\sigma_{n+1}=0}")#text(". This is a significant reduction to the problem, as one just has to write down an explicit formula for such functions and verify all the properties.")

#text("Let us work out some simple cases. First consider the case ")#mi("{n=1}")#text(". Now our task is to solve the system")

#tao-aligned(keep: true)[


#tao-math("\\sigma_1(0)  & = 1", block: true)



#tao-math("\\lim_{t \\rightarrow \\infty} \\sigma_1(t)  & = 0", block: true)



#tao-math("\\sigma_1(t)  & = - \\partial_t \\sigma_1(t)", block: true)



#tao-math("-\\partial_t \\sigma_1(t)  & \\geq 0", block: true)
]

#text("for all ")#mi("{0 \\leq t \\leq \\infty}")#text(". This is easy: we just take ")#mi("{\\sigma_1(t) = e^{-t}}")#text(" (indeed this is the unique choice). This gives the ")#mi("{n=1}")#text(" case of the Milin conjecture (which corresponds to the ")#mi("{n=2}")#text(" case of Bieberbach).")#linebreak()#text(" Next consider the case ")#mi("{n=2}")#text(". The system is now")

#tao-aligned(keep: true)[


#tao-math("\\sigma_1(0)  & = 2; \\quad \\sigma_2(0) = 1", block: true)



#tao-math("\\lim_{t \\rightarrow \\infty} \\sigma_1(t)  & = \\lim_{t \\rightarrow \\infty} \\sigma_2(t) = 0", block: true)



#tao-math("\\sigma_1(t) - \\sigma_2(t)  & = - \\partial_t \\sigma_1(t) - \\frac{1}{2} \\partial_t \\sigma_2(t)", block: true)



#tao-math("\\sigma_2(t)  & = - \\frac{1}{2} \\partial_t \\sigma_2(t)", block: true)



#tao-math("- \\partial_t \\sigma_1(t), - \\partial_t \\sigma_2(t)  & \\geq 0.", block: true)
]

#text("Again, a routine computation shows that there is a unique solution here, namely ")#mi("{\\sigma_1(t) = 4e^{-t} - 2e^{-2t}}")#text(" and ")#mi("{\\sigma_2(t) = e^{-2t}}")#text(". This gives the ")#mi("{n=2}")#text(" case of the Milin conjecture (which corresponds to the ")#mi("{n=3}")#text(" case of Bieberbach). One should compare this argument to that in Theorem ")#link(<tao-a212f07276961212b0ec>)[#text("24")]#text(", in particular one should see very similar weight functions emerging.")#linebreak()#text(" Let us now move on to ")#mi("{n=3}")#text(". The system is now")

#tao-aligned(keep: true)[


#tao-math("\\sigma_1(0)  & = 3; \\quad \\sigma_2(0) = 2; \\quad \\sigma_1(0) = 1", block: true)



#tao-math("\\lim_{t \\rightarrow \\infty} \\sigma_1(t)  & = \\lim_{t \\rightarrow \\infty} \\sigma_2(t) = \\lim_{t \\rightarrow \\infty} \\sigma_3(t) = 0", block: true)



#tao-math("\\sigma_1(t) - \\sigma_2(t)  & = - \\partial_t \\sigma_1(t) - \\frac{1}{2} \\partial_t \\sigma_2(t)", block: true)



#tao-math("\\sigma_2(t) - \\sigma_3(t)  & = - \\frac{1}{2} \\partial_t \\sigma_2(t) - \\frac{1}{3} \\partial_t \\sigma_3(t)", block: true)



#tao-math("\\sigma_3(t)  & = - \\frac{1}{3} \\partial_t \\sigma_3(t)", block: true)



#tao-math("- \\partial_t \\sigma_1(t), - \\partial_t \\sigma_2(t), - \\partial_t \\sigma_3(t)  & \\geq 0.", block: true)
]

#text("A slightly lengthier calculation gives the unique explicit solution")

#tao-aligned(keep: true)[


#tao-math("\\sigma_1(t)  & = 10 e^{-t} - 12 e^{-2t} + 5 e^{-3t}", block: true)



#tao-math("\\sigma_2(t)  & = 6 e^{-2t} - 4 e^{-3t}", block: true)



#tao-math("\\sigma_3(t)  & = e^{-3t}", block: true)
]

#text("to the above conditions.")#linebreak()#text(" These simple cases already indicate that there is basically only one candidate for the weights ")#mi("{\\sigma_k}")#text(" that will work. A calculation can give the explicit formula:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" Let ")#mi("{n \\geq 1}")#text(".")

#list(
[#text("(i) Show there is a unique choice of continuously differentiable functions ")#mi("{\\sigma_1,\\dots,\\sigma_n: [0,+\\infty) \\rightarrow {\\bf R}}")#text(" that solve the differential equations ")#link(<tao-c4264b5b2189f12a5012>)[#text("(26)")]#text(" with initial condition ")#link(<tao-ac1b5c0961a7269b6a05>)[#text("(23)")]#text(", with the convention ")#mi("{\\sigma_{n+1}=0}")#text(". (Use the ")#link("https://en.wikipedia.org/wiki/Picard%E2%80%93Lindel%C3%B6f_theorem")[#text("Picard existence theorem")]#text(".)")],
[#text("(ii) For any ")#mi("{0 \\leq k \\leq n}")#text(", show that the expression")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=0}^{n-k} (-1)^j \\binom{2k+2j}{j} \\binom{n+j+k+1}{n-k-j}")]]

#text("is equal to ")#mi("{1}")#text(" when ")#mi("{n-k}")#text(" is even and ")#mi("{0}")#text(" when ")#mi("{n-k}")#text(" is odd.")],
[#text("(iii) Show that the functions")

#align(center)[#tao-fit-display[#mitex("\\sigma_k(t) = k \\sum_{j=0}^{n-k} (-1)^j \\binom{2k+2j}{j} \\binom{n+k+j+1}{n-k-j} \\frac{1}{k+j} e^{-(k+j)t}")]]

#text("for ")#mi("{k=1,\\dots,n}")#text(" obey the properties ")#link(<tao-ac1b5c0961a7269b6a05>)[#text("(23)")]#text(", ")#link(<tao-c4264b5b2189f12a5012>)[#text("(26)")]#text(", ")#link(<tao-931534c0c145d0a99631>)[#text("(24)")]#text(". (")#emph[#text("Hint:")]#text(" for ")#link(<tao-ac1b5c0961a7269b6a05>)[#text("(23)")]#text(", first use (ii) to show that ")#mi("{\\partial_t \\sigma_k(t)}")#text(" is equal to ")#mi("{-k}")#text(" when ")#mi("{n-k}")#text(" is even and ")#mi("{0}")#text(" when ")#mi("{n-k}")#text(" is odd, then use ")#link(<tao-c4264b5b2189f12a5012>)[#text("(26)")]#text(".)")]
)
]

#text("The Bieberbach conjecture is then reduced to the claim that ")#metadata(none) <tao-3df0be97c272547289a4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("k \\sum_{j=0}^{n-k} (-1)^j \\binom{2k+2j}{j} \\binom{n+k+j+1}{n-k-j} e^{-(k+j)t} \\geq 0")]]

#linebreak()#text(" ")#text(" for any ")#mi("{1 \\leq k \\leq n}")#text(" and ")#mi("{t \\geq 0}")#text(". This inequality can be directly verified for any fixed ")#mi("{n}")#text("; for general ")#mi("{n}")#text(" it follows from general inequalities on Jacobi polynomials ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=430358")[#text("by Askey and Gasper")]#text(", with an alternate proof given ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=877650")[#text("subsequently by Gasper")]#text(". A further proof of ")#link(<tao-3df0be97c272547289a4>)[#text("(28)")]#text(", based on a variant of the above argument ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1131432")[#text("due to Weinstein")]#text(" that avoids explicit use of ")#link(<tao-3df0be97c272547289a4>)[#text("(28)")]#text(", appears in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2281158")[#text("this article of Koepf")]#text(". We will not detail these arguments here.")

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/#comment-497648")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2018")])]

#text("It seems clearer to add that the simply connected proper subset ")#mi("V")#text(" (in line 11) should be also open and nonempty. Also “simply connected” here (with respect to complex plane topology) can be extended to be with respect to the Riemann sphere topology.")

#emph[#text("[Openness hypothesis added. For this set of notes, only univalent functions taking values in the complex numbers (rather than the Riemann sphere) are considered. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/#comment-497726")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2018")])]

#text("It is interesting to observe that the method of proof was used to prove the stronger Milin’s conjecture and apparently is not adapted for a direct proof of the weaker Bieberbach conjecture. Is it possible to modify the method for a direct proof of the Bieberbach conjecture?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/#comment-497736")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2018")])]

#text("I am not aware of any confirmed proof of the Bieberbach conjecture that does not go through the Milin conjecture.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aula")]], [#link("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/#comment-497762")[#strong[#text("Aula")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2018")])]

#text("In the proof of Lemma 27, “it thus suffices the identity” should be “…suffices to prove the identity” or something similar.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa64c9c253f65a7d9cc17341c4b22ebef482e1440374dcc9f37da48992a6c01-adae0e3099b1eca8bd0752161d24380b97aab9790b1fa32b2687d7d9e5d3dd74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Asimov")]], [#link("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/#comment-497773")[#strong[#text("Dan Asimov")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2018")])]

#text("I always wanted to understand the Bieberbach conjecture. With a 1-page proof this may be possible.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/966e7929baf7793ef93adf468e7c8c34ef8ed5a9c3215693667030eabe435a8a-443b317c6e43961b4c2578b0e7d8be110162b3f07fda49b8b8ffd12a8d535094.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Conrad")]], [#link("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/#comment-497825")[#strong[#text("Conrad")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2018")])]

#text("For “simple” univalent functions (eg those with real coefficients and more generally the typically real functions on the unit disk which may not be univalent – since they have a simple integral representation with respect to a positive unit measure on the circle, or for that matter close to convex and related univalent functions which also have nice integral representations) Bieberbach’s conjecture is fairly easy to deduce; also Littlewood proved fairly easily in the 20’s the inequality a(n)<en so the right order of the magnitude for the coefficients is not that deep a problem either.")

#text("However there are some functionals (related to the Milin one(s) that is used in de Branges' proof) on the S class that have different asymptotic behaviors on odd versus even coefficients (see Grinshpan' survey article in Kuhnau's handbook of Geometric Function Theory I, p 313) that hint to the reasons no one so far managed to prove Bieberbach without going through the 2-symmetrization of the S-class that leads to an odd univalent function and the Robertson conjecture which then follows from the negativity of the Milin functional")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf39df540f0dfc4ec83435cd675f78dd722185c2db39244e6a73c189a89172ed-1b2b9f57ff0a3026d70a2ba214a09fbff6e4585625f635a11a9441c7b3d9b77d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jasper Liang")]], [#link("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/#comment-497887")[#strong[#text("Jasper Liang")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2018")])]

#text("Reblogged this on ")#link("https://zhengjunliang.wordpress.com/2018/05/08/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/")[#text("Countable Infinity")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ebe6de4cb9de9ac0c3a5d1059f9aa668ff783d49acdacd8b4ac3c00df70150c-07a9edce3bd51963008db0afe7af1327ba78ef0a7086c351daaa344225aa3dfc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/#comment-498097")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2018")])]

#text("I was never sure why Bierbach conjecture was so important but I always liked Gronwall area formula since it linked complex analysis and fourier series.")

#text("Maybe the floor plan of a room — all floor plans of houses — are conformally equivalent. We can partition a rectangle into various rooms connected by doors. And then we randomly walk around. And these are all related.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ebe6de4cb9de9ac0c3a5d1059f9aa668ff783d49acdacd8b4ac3c00df70150c-07a9edce3bd51963008db0afe7af1327ba78ef0a7086c351daaa344225aa3dfc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/#comment-498453")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2018")])]

#text("This the first time I read that the function you obtain from the Riemann Mapping Theorem is univalent. Can we tell just looking at the series expansion that a holomorphic function is injective? Let alone if it maps to a specific shape…")

#text("Here is something nice. Let ")#tao-math("\\Omega = \\{ z + z^2/2 : \\left|z\\right| < 1 \\}", block: false)#text(". Then we have ")#mi("\\int_\\Omega f \\, dA = \\frac{3\\pi}{2} f(0) + \\frac{\\pi}{2} f^{\\prime}(0)")#text(" it's like we pinch off a tiny bit of the value at the origin with the derivative. And the shape is a Cardioid. This taken from a paper \"Topology of Quadrature Domains\" ")#link("https://arxiv.org/abs/1307.0487")[#text("https://arxiv.org/abs/1307.0487")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f35a2c2e04b812c27d901e9773072d861a2f880bdca36c84cccda50d87f558e-61bfb6dcf8dce9387d2ac9a844e7f71ad10265b48583e11a70216cfae158cedd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vivek Sharma")]], [#link("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/#comment-498987")[#strong[#text("Vivek Sharma")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2018")])]

#text("I know that You are very busy and occupied Sir, but only One question: When are Notes 4 coming?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246C notes 4: Brownian motion, conformal invariance, and SLE | What's new")]], [#link("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/#comment-500283")[#strong[#text("246C notes 4: Brownian motion, conformal invariance, and SLE | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2018")])]

#text("[…] can help gain an intuitive understanding of the Carathéodory kernel theorem (Theorem 12 from Notes 3). Consider for instance the example in Exercise 13 from those notes. It is intuitively clear that a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80ccb94c50c8e6d0a52921d2fefac582aa1d3ebac54448350302574ce8356ca8-24efd013ca99410abff9c9208b75ce99123eaf724ac054de73c9e60339a01b2b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/#comment-500697")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2018")])]

#text("For Exercise 18, is the presence of an ‘s’ a typo? If not, what does it refer to?")

#emph[#text("[This is a typo, now removed. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/#comment-501875")[#strong[#text("U.V. S.")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2018")]

#text("Does anybody else remember the discussion of Herglotz vs. Airy by the wonderful Prof. Bender? I confess I cannot read a publication mentioning Herglotz functions seriously since that day!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246C notes 2: Circle packings, conformal maps, and quasiconformal maps | What's new")]], [#link("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/#comment-622837")[#strong[#text("246C notes 2: Circle packings, conformal maps, and quasiconformal maps | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("[…] set of notes: Notes 1. Next set of notes: Notes 3. We now leave the topic of Riemann surfaces, and turn now to the (loosely related) topic of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/#comment-643957")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2022")])]

#text("Link to “lecture note of Contreras” doesn’t work.")

#emph[#text("[Link revised – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/#comment-644011")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2022")])]

#text("Dr. Tao:")#linebreak()#text(" Since the coefficients ")#mi("a_{n}")#text(" are only functions of time, shouldn’t (15) (16) using regular derivatives ")#mi("a_n^{\\prime}")#text(" instead of")#linebreak()#text(" ")#mi("\\partial_{t}a_n")#text("?")

#emph[#text("[I am reserving primes in this post for the complex derivative in the ")#mi("z")#text(" variable, and am avoiding it for the ")#mi("t")#text(" variable to reduce confusion – T.]")]
]
