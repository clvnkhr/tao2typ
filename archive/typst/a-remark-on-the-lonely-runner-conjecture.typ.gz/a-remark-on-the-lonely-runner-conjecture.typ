// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T15:19:29.200196+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A remark on the lonely runner conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A remark on the lonely runner conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 May 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/")[#text("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("http://en.wikipedia.org/wiki/Lonely_runner_conjecture")[#text("lonely runner conjecture")]#text(" is the following open problem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1")]#text(" Suppose one has ")#mi("{n \\geq 1}")#text(" runners on the unit circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(", all starting at the origin and moving at different speeds. Then for each runner, there is at least one time ")#mi("{t}")#text(" for which that runner is “lonely” in the sense that it is separated by a distance at least ")#mi("{1/n}")#text(" from all other runners.")
]

#text("One can normalise the speed of the lonely runner to be zero, at which point the conjecture can be reformulated (after replacing ")#mi("{n}")#text(" by ")#mi("{n+1}")#text(") as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 2")]#text(" Let ")#mi("{v_1,\\dots,v_n}")#text(" be non-zero real numbers for some ")#mi("{n \\geq 1}")#text(". Then there exists a real number ")#mi("{t}")#text(" such that the numbers ")#mi("{tv_1,\\dots,tv_n}")#text(" are all a distance at least ")#mi("{\\frac{1}{n+1}}")#text(" from the integers, thus ")#tao-math("{\\left\\|tv_1\\right\\|_{{\\bf R}/{\\bf Z}},\\dots,\\left\\|tv_n\\right\\|_{{\\bf R}/{\\bf Z}} \\geq \\frac{1}{n+1}}", block: false)#text(" where ")#tao-math("{\\left\\|x\\right\\|_{{\\bf R}/{\\bf Z}}}", block: false)#text(" denotes the distance of ")#mi("{x}")#text(" to the nearest integer.")
]

#text("This conjecture has been proven for ")#mi("{n \\leq 7}")#text(", but remains open for larger ")#mi("{n}")#text(". The bound ")#mi("{\\frac{1}{n+1}}")#text(" is optimal, as can be seen by looking at the case ")#mi("{v_i=i}")#text(" and applying the ")#link("http://en.wikipedia.org/wiki/Dirichlet%27s_approximation_theorem")[#text("Dirichlet approximation theorem")]#text(". Note that for each non-zero ")#mi("{v}")#text(", the set ")#tao-math("{\\{ t \\in {\\bf R}: \\left\\|vt\\right\\|_{{\\bf R}/{\\bf Z}} \\leq r \\}}", block: false)#text(" has (Banach) density ")#mi("{2r}")#text(" for any ")#mi("{0 < r < 1/2}")#text(", and from this and the union bound we can easily find ")#mi("{t \\in {\\bf R}}")#text(" for which")

#align(center)[#tao-fit-display[#tao-math("\\left\\|tv_1\\right\\|_{{\\bf R}/{\\bf Z}},\\dots,\\left\\|tv_n\\right\\|_{{\\bf R}/{\\bf Z}} \\geq \\frac{1}{2n}-\\varepsilon", block: true)]]

#text("for any ")#mi("{\\varepsilon>0}")#text(", but it has proven to be quite challenging to remove the factor of ")#mi("{2}")#text(" to increase ")#mi("{\\frac{1}{2n}}")#text(" to ")#mi("{\\frac{1}{n+1}}")#text(". (As far as I know, even improving ")#mi("{\\frac{1}{2n}}")#text(" to ")#mi("{\\frac{1+c}{2n}}")#text(" for some absolute constant ")#mi("{c>0}")#text(" and sufficiently large ")#mi("{n}")#text(" remains open.)")

#text("The speeds ")#mi("{v_1,\\dots,v_n}")#text(" in the above conjecture are arbitrary non-zero reals, but it has been known for some time that one can reduce without loss of generality to the case when the ")#mi("{v_1,\\dots,v_n}")#text(" are rationals, or equivalently (by scaling) to the case where they are integers; see e.g. Section 4 of ")#link("http://www.ams.org/mathscinet-getitem?mr=1853254")[#text("this paper of Bohman, Holzman, and Kleitman")]#text(".")

#text("In this post I would like to remark on a slight refinement of this reduction, in which the speeds ")#mi("{v_1,\\dots,v_n}")#text(" are integers of ")#emph[#text("bounded size")]#text(", where the bound depends on ")#mi("{n}")#text(". More precisely:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3")]#text(" In order to prove the lonely runner conjecture, it suffices to do so under the additional assumption that the ")#mi("{v_1,\\dots,v_n}")#text(" are integers of size at most ")#mi("{n^{Cn^2}}")#text(", where ")#mi("{C}")#text(" is an (explicitly computable) absolute constant. (More precisely: if this restricted version of the lonely runner conjecture is true for all ")#mi("{n \\leq n_0}")#text(", then the original version of the conjecture is also true for all ")#mi("{n \\leq n_0}")#text(".)")
]

#text("In principle, this proposition allows one to verify the lonely runner conjecture for a given ")#mi("{n}")#text(" in finite time; however the number of cases to check with this proposition grows faster than exponentially in ")#mi("{n}")#text(", and so this is unfortunately not a feasible approach to verifying the lonely runner conjecture for more values of ")#mi("{n}")#text(" than currently known.")

#text("One of the key tools needed to prove this proposition is the following additive combinatorics result. Recall that a ")#emph[#text("generalised arithmetic progression")]#text(" (or ")#mi("{GAP}")#text(") in the reals ")#mi("{{\\bf R}}")#text(" is a set of the form")

#align(center)[#tao-fit-display[#tao-math("P = \\{ n_1 v_1 + \\dots + n_d v_d: n_1,\\dots,n_d \\in {\\bf Z}; \\left|n_1\\right| \\leq N_1, \\dots, \\left|n_d\\right| \\leq N_d \\}", block: true)]]

#text("for some ")#mi("{v_1,\\dots,v_d \\in {\\bf R}}")#text(" and ")#mi("{N_1,\\dots,N_d > 0}")#text("; the quantity ")#mi("{d}")#text(" is called the ")#emph[#text("rank")]#text(" of the progression. If ")#mi("{t>0}")#text(", the progression ")#mi("{P}")#text(" is said to be ")#emph[#mi("{t}")#text("-proper")]#text(" if the sums ")#mi("{n_1 v_1 + \\dots + n_d v_d}")#text(" with ")#tao-math("{\\left|n_i\\right| \\leq t N_i}", block: false)#text(" for ")#mi("{i=1,\\dots,d}")#text(" are all distinct. We have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (Progressions lie inside proper progressions)")]#text(" Let ")#mi("{P}")#text(" be a GAP of rank ")#mi("{d}")#text(" in the reals, and let ")#mi("{t \\geq 1}")#text(". Then ")#mi("{P}")#text(" is contained in a ")#mi("{t}")#text("-proper GAP ")#mi("{Q}")#text(" of rank at most ")#mi("{d}")#text(", with")

#align(center)[#tao-fit-display[#tao-math("\\left|Q\\right| \\leq (2t)^d d^{6d^2} \\prod_{i=1}^d (2N_i+1).", block: true)]]
]

#emph[#text("Proof:")]#text(" See Theorem 2.1 of ")#link("http://www.ams.org/mathscinet-getitem?mr=1701189")[#text("this paper of Bilu")]#text(". (Very similar results can also be found in Theorem 3.40 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2289012")[#text("my book with Van Vu")]#text(", or Theorem 1.10 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2435645")[#text("this paper of mine with Van Vu")]#text(".) ")#mi("\\Box")

#text("Now let ")#mi("{n \\geq 1}")#text(", and assume inductively that the lonely runner conjecture has been proven for all smaller values of ")#mi("{n}")#text(", as well as for the current value of ")#mi("{n}")#text(" in the case that ")#mi("{v_1,\\dots,v_n}")#text(" are integers of size at most ")#mi("{n^{Cn^2}}")#text(" for some sufficiently large ")#mi("{C}")#text(". We will show that the lonely runner conjecture holds in general for this choice of ")#mi("{n}")#text(".")

#text("let ")#mi("{v_1,\\dots,v_n}")#text(" be non-zero real numbers. Let ")#mi("{C_0}")#text(" be a large absolute constant to be chosen later. From the above lemma applied to the GAP ")#mi("{\\{ n_1 v_1 + \\dots + n_d v_d: n_1,\\dots,n_d \\in \\{-1,0,1\\}\\}}")#text(", one can find a ")#mi("{n^{C_0n}}")#text("-proper GAP ")#mi("{Q}")#text(" of rank at most ")#mi("{n}")#text(" containing ")#mi("{\\{v_1,\\dots,v_n\\}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|Q\\right| \\leq (6n^{C_0 n})^n n^{6n^2};", block: true)]]

#text("in particular ")#tao-math("{\\left|Q\\right| \\leq n^{Cn^2}}", block: false)#text(" if ")#mi("{C}")#text(" is large enough depending on ")#mi("{C_0}")#text(".")

#text("We write")

#align(center)[#tao-fit-display[#tao-math("Q = \\{ n_1 w_1 + \\dots + n_d w_d: n_1,\\dots,n_d \\in {\\bf Z}; \\left|n_1\\right| \\leq N_1,\\dots,\\left|n_d\\right| \\leq N_d \\}", block: true)]]

#text("for some ")#mi("{d \\leq n}")#text(", ")#mi("{w_1,\\dots,w_d}")#text(", and ")#mi("{N_1,\\dots,N_d \\geq 0}")#text(". We thus have ")#mi("{v_i = \\phi(a_i)}")#text(" for ")#mi("{i=1,\\dots,n}")#text(", where ")#mi("{\\phi: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" is the linear map ")#mi("{\\phi(n_1,\\dots,n_d) := n_1 w_1 + \\dots + n_d w_d}")#text(" and ")#mi("{a_1,\\dots,a_n \\in {\\bf Z}^d}")#text(" are non-zero and lie in the box ")#tao-math("{\\{ (n_1,\\dots,n_d) \\in {\\bf R}^d: \\left|n_1\\right| \\leq N_1,\\dots,\\left|n_d\\right| \\leq N_d \\}}", block: false)#text(".")

#text("We now need an elementary lemma that allows us to create a “collision” between two of the ")#mi("{a_1,\\dots,a_n}")#text(" via a linear projection, without making any of the ")#mi("{a_i}")#text(" collide with the origin:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5")]#text(" Let ")#mi("{a_1,\\dots,a_n \\in {\\bf R}^d}")#text(" be non-zero vectors that are not all collinear with the origin. Then, after replacing one or more of the ")#mi("{a_i}")#text(" with their negatives ")#mi("{-a_i}")#text(" if necessary, there exists a pair ")#mi("{a_i,a_j}")#text(" such that ")#mi("{a_i-a_j \\neq 0}")#text(", and such that none of the ")#mi("{a_1,\\dots,a_n}")#text(" is a scalar multiple of ")#mi("{a_i-a_j}")#text(".")
]

#emph[#text("Proof:")]#text(" We may assume that ")#mi("{d \\geq 2}")#text(", since the ")#mi("{d \\leq 1}")#text(" case is vacuous. Applying a generic linear projection to ")#mi("{{\\bf R}^2}")#text(" (which does not affect collinearity, or the property that a given ")#mi("{a_k}")#text(" is a scalar multiple of ")#mi("{a_i-a_j}")#text("), we may then reduce to the case ")#mi("{d=2}")#text(".")

#text("By a rotation and relabeling, we may assume that ")#mi("{a_1}")#text(" lies on the negative ")#mi("{x}")#text("-axis; by flipping signs as necessary we may then assume that all of the ")#mi("{a_2,\\dots,a_n}")#text(" lie in the closed right half-plane. As the ")#mi("{a_i}")#text(" are not all collinear with the origin, one of the ")#mi("{a_i}")#text(" lies off of the ")#mi("{x}")#text("-axis, by relabeling, we may assume that ")#mi("{a_2}")#text(" lies off of the ")#mi("{x}")#text(" axis and makes a minimal angle with the ")#mi("{x}")#text("-axis. Then the angle of ")#mi("{a_2-a_1}")#text(" with the ")#mi("{x}")#text("-axis is non-zero but smaller than any non-zero angle that any of the ")#mi("{a_i}")#text(" make with this axis, and so none of the ")#mi("{a_i}")#text(" are a scalar multiple of ")#mi("{a_2-a_1}")#text(", and the claim follows. ")#mi("\\Box")

#text("We now return to the proof of the proposition. If the ")#mi("{a_1,\\dots,a_n}")#text(" are all collinear with the origin, then ")#mi("{\\phi(a_1),\\dots,\\phi(a_n)}")#text(" lie in a one-dimensional arithmetic progression ")#tao-math("{\\{ mv: \\left|m\\right| \\leq \\left|Q\\right| \\}}", block: false)#text(", and then by rescaling we may take the ")#mi("{v_1,\\dots,v_n}")#text(" to be integers of magnitude at most ")#tao-math("{\\left|Q\\right| \\leq n^{Cn}}", block: false)#text(", at which point we are done by hypothesis. Thus, we may assume that the ")#mi("{a_1,\\dots,a_n}")#text(" are not all collinear with the origin, and so by the above lemma and relabeling we may assume that ")#mi("{a_n-a_1}")#text(" is non-zero, and that none of the ")#mi("{a_i}")#text(" are scalar multiples of ")#mi("{a_n-a_1}")#text(".")

#text("We write ")#metadata(none) <tao-961b6dd3ede3cb8ecbaa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("a_n-a_1 = (c_1,\\dots,c_d)")]]

#text("with ")#tao-math("{\\left|c_i\\right| \\leq 2 N_i}", block: false)#text(" for ")#mi("{i=1,\\dots,d}")#text("; by relabeling we may assume without loss of generality that ")#mi("{c_d}")#text(" is non-zero, and furthermore that")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\left|c_i\\right|}{N_i} \\leq \\frac{\\left|c_d\\right|}{N_d}", block: true)]]

#text("for ")#mi("{i=1,\\dots,d}")#text(". We can also factor ")#metadata(none) <tao-355b1bbfc96725cdce8f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("(c_1,\\dots,c_d) = q (c^{\\prime}_1,\\dots,c^{\\prime}_d)")]]

#text("where ")#mi("{q}")#text(" is a natural number and ")#mi("{c^{\\prime}_1,\\dots,c^{\\prime}_d}")#text(" have no common factor.")

#text("We now define a variant ")#mi("{\\tilde \\phi: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" of ")#mi("{\\phi: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" by the map")

#align(center)[#tao-fit-display[#mitex("\\tilde \\phi(n_1,\\dots,n_d) := n_1 \\tilde w_1 + \\dots + n_{d-1} \\tilde w_{d-1} - \\frac{n_d}{c_d} (c_1 \\tilde w_1 + \\dots + c_{d-1} \\tilde w_{d-1}),")]]

#text("where the ")#mi("{\\tilde w_1,\\dots,\\tilde w_{d-1}}")#text(" are real numbers that are linearly independent over ")#mi("{{\\bf Q}}")#text(", whose precise value will not be of importance in our argument. This is a linear map with the property that ")#mi("{\\tilde \\phi(a_n-a_1)=0}")#text(", so that ")#mi("{\\tilde \\phi(a_1),\\dots,\\tilde \\phi(a_n)}")#text(" consists of at most ")#mi("{n-1}")#text(" distinct real numbers, which are non-zero since none of the ")#mi("{a_i}")#text(" are scalar multiples of ")#mi("{a_n-a_1}")#text(", and the ")#mi("{\\tilde w_i}")#text(" are linearly independent over ")#mi("{{\\bf Q}}")#text(". As we are assuming inductively that the lonely runner conjecture holds for ")#mi("{n-1}")#text(", we conclude (after deleting duplicates) that there exists at least one real number ")#mi("{\\tilde t}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\tilde t \\tilde \\phi(a_1) \\right\\|_{{\\bf R}/{\\bf Z}}, \\dots, \\left\\| \\tilde t \\tilde \\phi(a_n) \\right\\|_{{\\bf R}/{\\bf Z}} \\geq \\frac{1}{n}.", block: true)]]

#text("We would like to “approximate” ")#mi("{\\phi}")#text(" by ")#mi("{\\tilde \\phi}")#text(" to then conclude that there is at least one real number ")#mi("{t}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| t \\phi(a_1) \\right\\|_{{\\bf R}/{\\bf Z}}, \\dots, \\left\\| t \\phi(a_n) \\right\\|_{{\\bf R}/{\\bf Z}} \\geq \\frac{1}{n+1}.", block: true)]]

#text("It turns out that we can do this by a Fourier-analytic argument taking advantage of the ")#mi("{n^{C_0 n}}")#text("-proper nature of ")#mi("{Q}")#text(". Firstly, we see from the Dirichlet approximation theorem that one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\tilde t \\tilde \\phi(a_1) \\right\\|_{{\\bf R}/{\\bf Z}}, \\dots, \\left\\| \\tilde t \\tilde \\phi(a_n) \\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\frac{1}{10 n^2}", block: true)]]

#text("for a set ")#mi("{\\tilde t}")#text(" of reals of (Banach) density ")#mi("{\\gg n^{-O(n)}}")#text(". Thus, by the triangle inequality, we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\tilde t \\tilde \\phi(a_1) \\right\\|_{{\\bf R}/{\\bf Z}}, \\dots, \\left\\| \\tilde t \\tilde \\phi(a_n) \\right\\|_{{\\bf R}/{\\bf Z}} \\geq \\frac{1}{n} - \\frac{1}{10n^2}", block: true)]]

#text("for a set ")#mi("{\\tilde t}")#text(" of reals of density ")#mi("{\\gg n^{-O(n)}}")#text(".")

#text("Applying a smooth Fourier multiplier of Littlewood-Paley type, one can find a trigonometric polynomial")

#align(center)[#tao-fit-display[#tao-math("\\eta(x) = \\sum_{m: \\left|m\\right| \\leq n^{C_0 n/10}} b_m e^{2\\pi i mx}", block: true)]]

#text("which takes values in ")#mi("{[0,1]}")#text(", is ")#mi("{\\gg 1}")#text(" for ")#tao-math("{\\left\\|x\\right\\|_{{\\bf R}/{\\bf Z}} \\geq \\frac{1}{n} - \\frac{1}{10n^2}}", block: false)#text(", and is no larger than ")#mi("{O( n^{-100 C_0n} )}")#text(" for ")#tao-math("{\\left\\|x\\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\frac{1}{n+1}}", block: false)#text(". We then have")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_t \\prod_{j=1}^n \\eta( t \\tilde \\phi(a_j) ) \\gg n^{-O(n)}")]]

#text("where ")#mi("{\\mathop{\\bf E}_t f(t)}")#text(" denotes the mean value of a quasiperiodic function ")#mi("{f}")#text(" on the reals ")#mi("{{\\bf R}}")#text(". We expand the left-hand side out as")

#align(center)[#tao-fit-display[#mitex("\\sum_{m_1,\\dots,m_n: m_1 \\tilde \\phi(a_1) + \\dots + m_n \\tilde \\phi(a_n) = 0} b_{m_1} \\dots b_{m_n}.")]]

#text("From the genericity of ")#mi("{\\tilde w_1,\\dots,\\tilde w_n}")#text(", we see that the constraint")

#align(center)[#tao-fit-display[#mitex("m_1 \\tilde \\phi(a_1) + \\dots + m_n \\tilde \\phi(a_n) = 0")]]

#text("occurs if and only if ")#mi("{m_1 a_1 + \\dots + m_n a_n}")#text(" is a scalar multiple of ")#mi("{a_n-a_1}")#text(", or equivalently (by ")#link(<tao-961b6dd3ede3cb8ecbaa>)[#text("(1)")]#text(", ")#link(<tao-355b1bbfc96725cdce8f>)[#text("(2)")]#text(") an integer multiple of ")#mi("{(c^{\\prime}_1,\\dots,c^{\\prime}_d)}")#text(". Thus ")#metadata(none) <tao-2a21fe6d592a19b7de89>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_{m_1,\\dots,m_n: m_1 a_1 + \\dots + m_n a_n \\in {\\bf Z} (c^{\\prime}_1,\\dots,c^{\\prime}_d)} b_{m_1} \\dots b_{m_n} \\gg n^{-O(n)}.")]]

#text("Next, we consider the average ")#metadata(none) <tao-a5f02630dd666a73979b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\mathop{\\bf E}_t \\varphi( t \\xi ) \\prod_{j=1}^n \\eta( t v_j )")]]

#text("where ")#metadata(none) <tao-6e6450b16543e5f20de8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\xi := c^{\\prime}_1 w_1 + \\dots + c^{\\prime}_d w_d.")]]

#text("and ")#mi("{\\varphi}")#text(" is the Dirichlet series")

#align(center)[#tao-fit-display[#tao-math("\\varphi(x) := \\sum_{m: \\left|m\\right| \\leq n^{C_0 n/2}} e^{2\\pi i mx}.", block: true)]]

#text("By Fourier expansion and writing ")#mi("{v_j = \\phi(a_j)}")#text(", we may write ")#link(<tao-a5f02630dd666a73979b>)[#text("(4)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\sum_{m,m_1,\\dots,m_n: \\left|m\\right| \\leq n^{C_0n/2}; m_1 \\phi(a_1) + \\dots + m_n \\phi(a_n) = m \\xi} b_{m_1} \\dots b_{m_n}.", block: true)]]

#text("The support of the ")#mi("{b_{m_i}}")#text(" implies that ")#tao-math("{\\left|m_i\\right| \\leq n^{C_0n/10}}", block: false)#text(". Because of the ")#mi("{n^{C_0 n}}")#text("-properness of ")#mi("{Q}")#text(", we see (for ")#mi("{n}")#text(" large enough) that the equation ")#metadata(none) <tao-ee58dc2ac168ba351fec>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("m_1 \\phi(a_1) + \\dots + m_n \\phi(a_n) = m \\xi")]]

#text("implies that ")#metadata(none) <tao-37bfd2508fbbac943f3b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("m_1 a_1 + \\dots + m_n a_n \\in {\\bf Z} (c^{\\prime}_1,\\dots,c^{\\prime}_d)")]]

#text("and conversely that ")#link(<tao-37bfd2508fbbac943f3b>)[#text("(7)")]#text(" implies that ")#link(<tao-ee58dc2ac168ba351fec>)[#text("(6)")]#text(" holds for some ")#mi("{m}")#text(" with ")#tao-math("{\\left|m\\right| \\leq n^{C_0 n/2}}", block: false)#text(". From ")#link(<tao-2a21fe6d592a19b7de89>)[#text("(3)")]#text(" we thus have")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_t \\varphi( t \\xi ) \\prod_{j=1}^n \\eta( t v_j ) \\gg n^{-O(1)}.")]]

#text("In particular, there exists a ")#mi("{t}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\varphi( t \\xi ) \\prod_{j=1}^n \\eta( t v_j ) \\gg n^{-O(1)}.")]]

#text("Since ")#mi("{\\varphi}")#text(" is bounded in magnitude by ")#mi("{n^{C_0n/2}}")#text(", and ")#mi("{\\eta}")#text(" is bounded by ")#mi("{1}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("\\eta(t v_j) \\gg n^{-C_0 n/2 - O(1)}")]]

#text("for each ")#mi("{1 \\leq j \\leq n}")#text(", which by the size properties of ")#mi("{\\eta}")#text(" implies that ")#tao-math("{\\left\\|tv_j\\right\\|_{{\\bf R}/{\\bf Z}} \\geq \\frac{1}{n+1}}", block: false)#text(" for all ")#mi("{1 \\leq j \\leq n}")#text(", giving the lonely runner conjecture for ")#mi("{n}")#text(".")

#heading(level: 1)[#text("Comments (59)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-455707")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2015")])]

#text("I’m in a hurry, but we have also investigated results similar to Lemma 4: ")#link("http://arxiv.org/abs/0912.0424")[#text("http://arxiv.org/abs/0912.0424")]#text(". One can show that a single exponential bound in d is not sufficient using this result of Alon and Vu: ")#link("http://www.math.tau.ac.il/~nogaa/PDFS/av1.pdf")[#text("http://www.math.tau.ac.il/~nogaa/PDFS/av1.pdf")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-455804")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2015")])]

#text("I’m sorry, now after taking a proper look, our results seem unrelated, they just contain similar words and bounds.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-455724")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2015")])]

#text("In conjecture 2, it seems that “the origin” should be “the integers”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39d042cd343763a0074f825ecdf61ade3a1f833c09d7322d7ed33b69d91748e0-004ee65ff1042e640b0bfa8bf9563704de056663a81b46994f471f2da9bfde76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bogdan")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-455748")[#strong[#text("Bogdan")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2015")])]

#text("You proved that if the conjecture is false for a given n, then it false for SOME v_1, …, v_n of size n^(Cn^2). Can similar methods to be extended to prove a stronger result, that if the conjecture is false for a given n, then it false for MANY v_1, …, v_n of size n^(Cn^2), say, for a positive proportion (independent of n) of all tuples v_1, …, v_n of this size. Then, for the first unproved case n=8, we could check the conjecture for some RANDOM tuples bouded by 8^64C (if C is not too lagre), and, if true, confirm the original conjecture for n=8, with probability, arbitrary closed to 1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-455758")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2015")])]

#text("One can certainly establish the conjecture for “most” choices of ")#mi("v_1,\\dots,v_n")#text("; for instance, if the ")#mi("v_1,\\dots,v_n")#text(" are linearly independent over ")#mi("{\\bf Q}")#text(" (which occurs for almost every choice of reals ")#mi("v_1,\\dots,v_n")#text("), then the ")#tao-math("\\left\\|tv_i\\right\\|_{{\\bf R}/{\\bf Z}}", block: false)#text(" behave as independent random variables and the claim is quite easy to show in this case. However, all of the difficulty of the problem is concentrated in “special” choices of ")#mi("v_1,\\dots,v_n")#text(", and knowing that the conjecture is true for “most” choices doesn’t make much impact on this most difficult case. (An analogy is with Fermat’s last theorem: it is easy to show that the equation ")#mi("a^n+b^n=c^n")#text(" is false for “most” choices of $a,b,c,n$, for just about any notion of “most”, but this does not really make a dent in solving the problem.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39d042cd343763a0074f825ecdf61ade3a1f833c09d7322d7ed33b69d91748e0-004ee65ff1042e640b0bfa8bf9563704de056663a81b46994f471f2da9bfde76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bogdan")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-455845")[#strong[#text("Bogdan")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2015")])]

#text("You completely misundersood my comment :) I wil try again.")#linebreak()#text(" Your theorem is: If there is at least one counterexample for ANY v_1, …, v_n, then there is at least ONE counterexample for bounded v_1, …, v_n.")#linebreak()#text(" Now, assume we have a stronger result, namely:")#linebreak()#text(" Statement A: If there is at least one counterexample for any v_1, …, v_n, then positive proportion of ALL bounded v_1, …, v_n are all counterexamples.")#linebreak()#text(" Then, trying at random, we could rule out a possibility that positive proportion of ALL bounded v_1, …, v_n are all counterexamples, and")#linebreak()#text(" use statement A to prove the result in full.")

#text("Example how this may work.")

#text("Statement B: If there is at least one counterexample N to odd Goldbach’s conjecture, then at least N/log N even numbers in the region from 2 to N are ALL counterexamples to even Goldbach’s conjecture.")

#text("Proof is trivial. If N is a counterexample to odd Goldbach’s conjecture, then N-p is a counterexample to the even Goldbach’s conjecture for any odd p less than N.")

#text("Now, we can check even Goldbach’s conjecture for sufficiently many random numbers below exp(3100), and the odd Goldbach’s conjecture for numbers below exp(3100) follows from statement B. See ")#link("https://rjlipton.wordpress.com/2014/06/06/is-this-a-proof-2/")[#text("https://rjlipton.wordpress.com/2014/06/06/is-this-a-proof-2/")]#text(" for a variant of this argument.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-455884")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2015")])]

#text("Ah, I see what you are saying now. I doubt that this sort of “counterexample dispersion” effect is present in this problem; roughly speaking, the only symmetry we have available in this problem to convert one counterexample into many counterexamples are Freiman homomorphisms. (There is a technicality here in that there is some loss in the lower bound on runner separation every time one applies such a homomorphism, based on the quality of that homomorphism, but let me ignore this technicality for sake of current discussions.) There are enough homomorphisms present to “rectify” any finite set of speeds into a set of bounded integers, but not enough to obtain a positive proportion of such sets. As mentioned in my previous comment, for randomly selected sets of speeds (which all lie, more or less, in a single Freiman isomorphism class) the claim is trivial to prove, but this does not have much bearing on all the other Freiman isomorphism classes (and if the conjecture is to fail, it is likely to come from a very special, carefully constructed, Freiman isomorphism class, which will not be detectable by random search).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-455752")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2015")])]

#text("It seems that the (closely related) Littlewood conjecture complements this conjecture for ")#mi("n=2")#text(" (where ")#mi("t")#text(" is constrained to be an integer.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-455822")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2015")])]

#text("Correction: In conjecture 1 (to be exactly equivalent to conjecture 2), it seems that “different speeds” should be interpreted as “there is at least one runner whose speed is different from the speeds of the other runners”.")

#emph[#text("[The formulations are equivalent, as can be seen by replacing multiple runners with the same speed with a single runner of that speed. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-455887")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2015")])]

#text("The simple identity ")#tao-math("\\sin (\\pi \\left|\\left| x \\right|\\right|) = \\left| \\sin (\\pi x)\\right|", block: false)#text(" implies that conjecture 2 has the following analytic formulation")

#tao-math("\\max_{t \\in \\mathbb R} \\min_{1\\leq  j \\leq n} \\left|sin(\\pi t v_j)\\right| \\geq \\sin \\frac {\\pi}{n+1}", block: false)

#text("It is easy to verify that the (outer) maximum is attained at an intersection point of two sine curves (with corresponding velocities ")#mi("v_i, v_j")#text("), i.e.")

#tao-math("\\left|\\sin (\\pi t v_i)\\right| = \\left|\\sin(\\pi t v_j)\\right|", block: false)#text(" for some ")#mi("v_i, v_j")

#text("Implying that ")#mi("t")#text(" is rational (a multiple of ")#mi("1/(v_i - v_j)")#text(" or ")#mi("1/(v_i + v_j)")#text(").")

#text("Therefore (without loss of generality) ")#mi("t")#text(" may be assumed to be rational (with denominator being the sum or difference of two integer velocities).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-455903")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2015")])]

#text("Is Conjecture 2 equivalent to asking whether one can see infinitely far from the origin in an n-space occupied by opaque n-cubes of side length (n-1)/(n+1) centered at half-integer coordinates?")

#text("..and no fair peeking down a coordinate axis:-)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-455920")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2015")])]

#text("Yes; indeed, the original literature on the lonely runner conjecture was motivated by such “view-obstruction” formulations of the problem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-455926")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2015")])]

#text("Thanks. As a layperson this motivates me to try understand more of this posting. At first blush, it’s very surprising to me that such a basic view obstruction question, in such an apparently simple, symmetrical, static setting, is so hard.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Drive by shooting")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-455911")[#strong[#text("Drive by shooting")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2015")])]

#text("Would you buy this argument?")

#text("We can generalize the ")#mi("n")#text(" velocities to be arbitrary real numbers, for example by choosing a frame of reference traveling with an arbitrary runner. The system then satisfies the constraints of the Poincare recurrence theorem, for the ")#mi("n")#text(" positions, and the ")#mi("n")#text(" velocities. But any group of $n-1$ runners must then also fulfill the constraints of the Poincare recurrence theorem. Thus, fix a reference frame to an arbitrary runner, and consider a volume of the position space of the remaining ")#mi("n-1")#text(" runners, of length ")#mi("\\epsilon \\in (0, \\frac{1}{2})")#text(" for each of the ")#mi("n-1")#text(" runners, and exactly opposite to the origin of the chosen runner. By the Poincare recurrence theorem the ")#mi("n-1")#text(" runners must revisit this volume infinitely often. We then have for any ")#mi("\\epsilon \\in (0, \\frac{1}{2})")#text(" each runner is separated from all the other runners by that amount infinitely often.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-455919")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2015")])]

#text("In order to apply the Poincare recurrence theorem, the region of space considered must be visited ")#emph[#text("at least once")]#text(" before one can conclude that it is visited infinitely often. (With stronger hypotheses on the dynamical system, such as minimality, one does not need this additional hypothesis, however the system will only be minimal in the easy case when the relative velocities are linearly independent over the rationals.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c988dc5aeac7cbcfa8f4f366d2ed8af4074aa7131b2cc6401846be58b5af5441-74ff5027811a3fbcd41bd7a43cfc64952d56b368f1f39d51ae9b390c924a930e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Smith")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-455921")[#strong[#text("James Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2015")])]

#text("A small thing that confused me: you say in your definition of the problem that all the runners start at the origin. To say they start at the same place might be a little clearer. And I wonder now I come to think of it if the circle were indeed replaced with a disc how the problem would unfold.")

#emph[#text("[")#mi("{\\mathbf R}/{\\mathbf Z}")#text(" denotes the additive unit circle, rather than the multiplicative (or geometric) unit circle ")#mi("S^1")#text(" – one can think of it as the geometric unit circle transformed by a logarithmic change of variables. In particular, the identity element 1 of the multiplicative unit circle becomes the identity element 0 of the additive unit circle. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c988dc5aeac7cbcfa8f4f366d2ed8af4074aa7131b2cc6401846be58b5af5441-74ff5027811a3fbcd41bd7a43cfc64952d56b368f1f39d51ae9b390c924a930e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Smith")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-455929")[#strong[#text("James Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2015")])]

#text("I never made the distinction before. Thanks for clearing it up!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/070548c5f283d5da8bc06d5ee4ecf9174139faa45d02e3c408c967e6ec3771b0-96317c989091e8e46020f553fc3a6f996a51998c5bca5c719f77f5ef4cb0a09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of victor")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-455932")[#strong[#text("victor")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2015")])]

#text("What if the velocities are random, ie, the velocity of the $i$th runner is $v_0 \\exp( \\mu t + \\sigma B^i_t)$ where $B^i_t$ is standard Brownian Motion and is independent across the runners? The deterministic problem is the limiting case where $\\mu = 0$ and $\\sigma= \\infty$. Would it make sense to solve the stochastic problem first?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-455941")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2015")])]

#text("This is an irreducible Markov process (where the state space tracks both position and velocity) and so the stochastic runners will almost surely traverse a dense set of states, which amongst other things establishes the lonely runner property for such a set of runners. The difficulty in this conjecture lies not with such “generic” situations, but rather with very special “arithmetically structured” situations in which the runner velocities all have a rigid relationship with each other (e.g. they are all rational multiples of each other with small height).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/070548c5f283d5da8bc06d5ee4ecf9174139faa45d02e3c408c967e6ec3771b0-96317c989091e8e46020f553fc3a6f996a51998c5bca5c719f77f5ef4cb0a09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of victor")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-455942")[#strong[#text("victor")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2015")])]

#text("Thanks for clarifying Prof Tao.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d2e84774408db9d26f32102122ef58e5deb8a5f65ac229cf6b7d48db4b95123-16c1c987934d5f038cf1e52f2b8dbe9f2e82914452888a640df0cc091d68cf82.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-461022")[#strong[#text("Antoine")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2015")])]

#text("Hello, with all my respect, Dr. Tao, your point of the optimal ")#mi("\\dfrac{1}{n+1}")#text(" and relation to the Dirichlet approximation theorem. well i haven’t seen that, from the stated theorem at wiki, ")#mi("v_i")#text(" is what precisely in the theorem? thanks.")

#emph[#text("[The ")#mi("v_i")#text(" would correspond to the “")#mi("q")#text("” in the Wikipedia formulation of the theorem (and the time ")#mi("t")#text(" would correspond to ")#mi("\\alpha")#text(", and ")#mi("n")#text(" to ")#mi("N")#text("). -T]</I<")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d2e84774408db9d26f32102122ef58e5deb8a5f65ac229cf6b7d48db4b95123-16c1c987934d5f038cf1e52f2b8dbe9f2e82914452888a640df0cc091d68cf82.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-462122")[#strong[#text("Antoine")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2015")])]

#text("Thanks sorry i didn’t expect a reply!, anyway the $q$ depends on $\\alpha $ in the theorem no, so for a fixed $q$ maybe there exist $\\alpha$ such that the less or equal is bigger or equal, did i miss something? t.y.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d2e84774408db9d26f32102122ef58e5deb8a5f65ac229cf6b7d48db4b95123-16c1c987934d5f038cf1e52f2b8dbe9f2e82914452888a640df0cc091d68cf82.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-462123")[#strong[#text("Antoine")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2015")])]

#text("No Tex sorry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-462139")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2015")])]

#text("The Dirichlet approximation theorem (with the substitutions indicated) tells us that for any real ")#mi("t")#text(", there exists a ")#mi("q")#text(" between ")#mi("1")#text(" and ")#mi("n")#text(" (depending on ")#mi("t")#text(") such that ")#tao-math("\\left\\| qt\\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\frac{1}{n+1}", block: false)#text(". Setting ")#mi("v_q := q")#text(" for ")#mi("q = 1,\\dots, n")#text(", we conclude that Conjecture 2 fails if the quantity ")#mi("1/(n+1)")#text(" is replaced by any smaller quantity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-462141")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2015")])]

#text("Thank you.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d2e84774408db9d26f32102122ef58e5deb8a5f65ac229cf6b7d48db4b95123-16c1c987934d5f038cf1e52f2b8dbe9f2e82914452888a640df0cc091d68cf82.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-463959")[#strong[#text("Antoine")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2015")])]

#text("Thanks")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elliott")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-465156")[#strong[#text("Elliott")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2016")])]

#text("Prof. Tao, can’t the bound 1/(n+1) be seen to be optimal without referring to the Dirichlet approximation theorem? For speeds 1,…,n let t = 1/(n+1). Then ||1/(n+1)|| and ||n/(n+1)|| both equal 1/(n+1).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-465166")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2016")])]

#text("This doesn’t immediately preclude Conjecture 2 holding with 1/(n+1) replaced by a larger bound, because there could be a different value of t (other than t = 1/(n+1)) in which the numbers t, 2t, …, nt are further away from the origin than in your example. (But this scenario is ruled out by the Dirichlet approximation theorem.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29e9b2347360e6df3200750dc17da5b45881d31bcbb983c671541d7cd525ba2e-e30ec49ea325d5aaf2b58aba222081bbe685b1effd4140f410a9940082bff026.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stephen Mc Guire")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-515516")[#strong[#text("Stephen Mc Guire")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2019")])]

#text("Dirichlet’s theorem tells us that ")#tao-math("\\left|\\left| qt\\right|\\right|_{\\mathbf{R}/\\mathbf{Z}} \\leq \\frac{1}{n}", block: false)#text(" not that ")#tao-math("\\left|\\left| qt\\right|\\right|_{\\mathbf{R}/\\mathbf{Z}} \\leq \\frac{1}{n+1}", block: false)#text(". So we can, at best, conclude that all runners are within ")#mi("\\frac{1}{n}")#text(" of the lonely runner i.e. the runner stationary at 0. Perhaps I’m misunderstanding something?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-515578")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2019")])]

#text("The Dirichlet approximation theorem does indeed show that ")#tao-math("\\inf_{1 \\leq q \\leq n} \\left\\|qt\\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\frac{1}{n+1}", block: false)#text(" for all ")#mi("t")#text(" and all natural numbers ")#mi("n \\geq 1")#text(". (For some reason the Wikipedia entry only gives the weaker estimate ")#tao-math("\\inf_{1 \\leq q \\leq n} \\left\\|qt\\right\\|_{{\\bf R}/{\\bf Z}} < \\frac{1}{n}", block: false)#text(", but the stronger bound is what actually comes out of carefully optimising the proof, and in particular observing that some pair amongst ")#mi("0, t, 2t, \\dots, n t")#text(" must be at a distance at most ")#mi("\\frac{1}{n+1}")#text(" from each other.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of koza3301")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-462118")[#strong[#text("koza3301")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2015")])]

#text("Could you explain how to prove that “")#tao-math("\\displaystyle  \\left\\| \\tilde t \\tilde \\phi(a_1) \\right\\|_{{\\bf R}/{\\bf Z}}, \\dots, \\left\\| \\tilde t \\tilde \\phi(a_n) \\right\\|_{{\\bf R}/{\\bf Z}} \\geq \\frac{1}{n} - \\frac{1}{10n^2}", block: false)#text(" for a set ")#mi("{\\tilde t}")#text(" of reals of (Banach) density ")#mi("{\\gg n^{-O(n)}}")#text("” from the Dirichlet approximation theorem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-462138")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2015")])]

#text("Cover the n-torus by ")#mi("O(n^{O(n)})")#text(" boxes of sidelength ")#mi("1/20n^2")#text(". By the Dirichlet box principle (pigeonhole principle), one of these boxes will contain ")#mi("(\\tilde t \\tilde \\phi(a_1), \\dots, \\tilde t \\phi(a_n))")#text(" for a set of ")#mi("\\tilde t")#text(" of positive density. Now subtract to get the claim. (This argument is identical to the one used to prove the usual Dirichlet approximation theorem. There are some technical issues regarding the nature of density used here, but by using some equidistribution theory one can show that all the usual notions of density (lower Banach, upper Banach, etc.) agree for the sets in question.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of koza3301")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-462140")[#strong[#text("koza3301")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2015")])]

#text("Thanks :)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d2e84774408db9d26f32102122ef58e5deb8a5f65ac229cf6b7d48db4b95123-16c1c987934d5f038cf1e52f2b8dbe9f2e82914452888a640df0cc091d68cf82.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-463960")[#strong[#text("Antoine")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2015")])]

#text("Hi, I’ve got another question Prof. Tao if no bother; a result such as: their exist infinite times when say the $k$ runners are all distant from each other by at least $a\\dfrac{1}{k}$ with $a$ less than $1,$ can be bigger than $\\dfrac{1}{2}$ and it depends on the speed of the $k$ runners, Where it stands on a crowded scale for this problem, thanks all respect.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/026331ea6d47f2bddf9f44e26b7ebcea1973298cc5865f9e88cfe0c42b2ab6f4-738c639f300bf0a2f73c3ce790959ac7c4abebba408fe979906c1646aacff23d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David R")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-467203")[#strong[#text("David R")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2016")])]

#text("What do you think of this argument Prof. Tao? Suppose we use the following three lemmas to prove the slowest runner ")#mi("j")#text(" becomes lonely:")

#text("Lemma 1: Let ")#mi("s_j < s_1 < \\ldots < s_{k - 1}")#text(" for ")#mi("k \\geq 3")#text(". Then ")#mi("j")#text(" becomes lonely if and only if there exists ")#mi("n_1, n_2, \\ldots n_{k - 1} \\in \\mathbb{N}")#text(" such that ")#mi("\\bigcap_{i = 1}^{k - 1} \\bigg{\\left[\\frac{n_i + \\frac{1}{k}}{s_i - s_j},  \\frac{n_i + \\frac{k - 1}{k}}{s_i - s_j}\\right]} \\neq \\emptyset")

#text("Proof:: Straightforward in both directions.")

#text("Lemma 2: Let ")#mi("a_i, b_i \\in \\mathbb{R}")#text(" and ")#mi("a_i < b_i")#text(". Then ")#mi("\\bigcap_{i = 1}^{k} [a_i, b_i] \\neq \\emptyset")#text(" if and only if ")#mi("b_i \\geq a_i")#text(" for all ")#mi("1 \\leq i,j \\leq k, j \\neq i")#text("..")

#text("Proof: (")#mi("\\Rightarrow")#text("). Proof by contradiction.")#linebreak()#text(" (")#mi("\\Leftarrow")#text("). Proof by contrapositive.")

#text("Lemma 3: Let ")#mi("s_j < s_1 < \\ldots < s_{k - 1}")#text(" for ")#mi("k \\geq 3")#text(".Then there exists ")#mi("n_1, n_2, \\ldots n_{k - 1} \\in \\mathbb{N}")#text(" such that")

#mi("\\frac{s_m - s_j}{s_i - s_j} \\ge \\frac{kn_m + 1}{kn_i + k - 1}")

#text("for ")#mi("1 \\le i, m \\le k - 1")#text(", ")#mi("m \\ne i")#text(".")

#text("Proof: Try a proof by induction. Proving the base case ")#mi("P(3)")#text(" follows easily from the fact that the LRC has been proven for ")#mi("k =3")#text(". Proving that ")#mi("P(k) \\Rightarrow P(k + 1)")#text(" looks to be quite difficult though.")

#text("We can then make the following argument:")

#text("Theorem 1: Let ")#mi("s_j < s_1 < s_2 < \\ldots < s_{k - 1}, k\\ge 3")#text(". Then ")#mi("j")#text(" becomes lonely.")

#text("Proof: By Lemma 3, there exists ")#mi("n_1, n_2, \\ldots n_{k - 1} \\in \\mathbb{N}")#text(" such that")

#mi("\\frac{s_m - s_j}{s_i - s_j} \\ge \\frac{kn_m + 1}{kn_i + k - 1}")

#text("for all ")#mi("1 \\le i, m \\le k - 1")#text(", ")#mi("m \\ne i")#text(". Hence, there exists ")#mi("n_1, n_2, \\ldots n_{k - 1} \\in \\mathbb{N}")#text(" such that")

#mi("\\frac{n_i + \\frac{k - 1}{k}}{s_i - s_j} \\geq \\frac{n_m + \\frac{1}{k}}{s_m - s_j}")

#text("for all ")#mi("1 \\le i, m \\le k - 1")#text(", ")#mi("m \\ne i")#text(". By setting")

#mi("a_i = \\frac{n_i + \\frac{1}{k}}{s_i - s_j}, b_i = \\frac{n_i + \\frac{k - 1}{k}}{s_i - s_j}")

#text("and because ")#mi("b_i \\geq a_m")#text(" for ")#mi("1 \\leq i, m \\leq k - 1, i \\ne m")#text(" we have from Lemma 2,")

#mi("\\bigcap_{i = 1}^{k - 1} \\bigg{\\left[\\frac{n_i + \\frac{1}{k}}{s_i - s_j},  \\frac{n_i + \\frac{k - 1}{k}}{s_i - s_j}\\right]} \\neq \\emptyset")#text(".")

#text("By Lemma 1, ")#mi("j")#text(" becomes lonely for all T in the intersection.")

#text("The thing that’s interesting about this argument is that if we can prove Lemma 3, then we can repeat essentially the same argument to prove that runners with some intermediate speed as well as runners with the fastest speed become lonely. The argument for proving that the fastest runner becomes lonely would be almost identical to the argument for the slowest runner.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5532625b5077728d3b36ee69ade51a3091f374b35f8cc6e36a974cda3cca0d11-051c4e4b8691f0d7e520b97aa39a976bf545595ab27c2e734bec837b4024af09.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klaus85")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-469564")[#strong[#text("Klaus85")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("Dear Terry, I have just found this arxiv-paper (")#link("http://arxiv.org/abs/1606.01783")[#text("http://arxiv.org/abs/1606.01783")]#text(") claiming to proof the lonely-runner conjecture. It is the highest-rated paper of today on scirate, thus i thought it might be serios; but i would love to hear more details by an expert. Does it investigate the same question as mentioned here, or is it a weaker variation? Thanks so much!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-469580")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("The paper has been withdrawn due to an error on the last line.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-469581")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("Can you say in more detail where the error was?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-469582")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("The final inequality is not true in the ")#mi("n=0")#text(" case.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/abe3a52c0719e487144c871e2e73384810293c8d318afbcb9952459471bc031b-f592d8b68fbe22e38c1a6a510cb1155ef95cc46ad81798717c8aec536c49e1bd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Lui")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-469593")[#strong[#text("David Lui")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("do you think this is an easily fixable problem, or would it require significant effort to fix, or is the proof outright wrong?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-469607")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("Probably the author is the best person to answer this. But one test can come from the observation that the lonely runner conjecture is only barely true in the case ")#mi("v_i=i")#text(" (as pointed out in above in the blog post) or permutations or affine transformations thereof. As such, any proof of the lonely runner conjecture should also only barely work in this case (in particular, any key inequality in the proof should hold with equality in this case). This did not seem to be the case in this most recent attempt to prove the conjecture, which suggests at minimum that a significant modification of the argument would be required.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-469579")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("I have read through the Beck paper once without finding any problems in it. It does indeed address the full Lonely Runner Conjecture as described in this blog post. I am about to re-read.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/25b34bd07c7a4afa118d7a6906e6f9f796934059cb199f5442f43a2c2aab7505-683f81b42fb64d8a93f42cdf10fef09068d5bb0ed24c6a06523c3e1248212d0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious Party")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-469590")[#strong[#text("Curious Party")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("What time was the mistake found? A wager was placed on this result being false.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike Miller")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-469595")[#strong[#text("Mike Miller")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("I find this to be in extremely poor taste.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d43140c71728970a8174ce3753cecacbc58b126383263e0d6d67a0e8d827bb9a-f592d8b68fbe22e38c1a6a510cb1155ef95cc46ad81798717c8aec536c49e1bd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Lui")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-469606")[#strong[#text("David Lui")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("is it asking when it was found, or the wager part that you find to be in poor taste?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68770994525ea216df1fbbcfb68466bbb12efd5ae6d316f5a75fe2b05017e9b4-da253ccfa65d565708fcfb387476a76f9dadc2a3569069c710958eecc4d18a64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Classy Mofo")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-469622")[#strong[#text("Classy Mofo")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("Perhaps it is your own taste that is poor?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d128ddd34f034c93f31ff0f012ab1184a973e263701f80725c8685d8e4e8e8c-109eb1d701335d192235ec8808234979ce935ef9c015217510bc11bed06b7533.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of giorgi")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-471968")[#strong[#text("giorgi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2016")])]

#text("Hello terence tao. (1,2…m-1 and i are indexes ) i just proof what conjecture is equivalent to this conjecture (i mean if we proof “”this” then lonely runner conjecture is true too): q1, q2, …qm-1 is any positive numbers , if q1, q2, …qm-1")#linebreak()#text(" we can Multiplicate some number k (k>0) and get this type of similar proportion numbers: C1+N1, C2+N2 , …. Cm-1+Nm-1 , were Ci are numbers between 1/m<=Ci<=(m-1)/m and Ni are natural numbers then \"lonely runner\" is true too. what you think about it?")

#text("p.s. im just lover of mathematics and sorry for my english and \"latex\"")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-472200")[#strong[#text("একেলা দৌড়বিদের কনজেকচার (The Lonely Runner Conjecture) - বিজ্ঞান স্কুল")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2016")]

#text("[…] আরও পড়ার জন্য দেখতে পারেন এখানে ")#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/")[#text("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Some remarks on the lonely runner conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-476409")[#strong[#text("Some remarks on the lonely runner conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2017")])]

#text("[…] to Contributions to discrete mathematics. I had blogged about the lonely runner conjecture in this previous blog post, and I returned to the problem recently to see if I could obtain anything further. The results […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3dd2001b73977d8ee185825d4fd78fe822f1866768bf2ec863859469c19723b-b9c1253ee80a46dfda80e08ff33eeea5d21c1826976a5c74c9deac242a2938fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dsp")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-506363")[#strong[#text("dsp")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2018")])]

#text("This will probably turn out to be a very stupid question, but anyway: I have been thinking about what happens when you replace the Euclidean distance in the lonely runner conjecture with the p-adic one, i. e., what can one say about the set of vectors of distances ")#tao-math("(\\left|(e^{\\pi i v_1})^t - 1\\right|_p, \\dots, \\left|(e^{\\pi i v_n})^t - 1\\right|_p)", block: false)#text(", where ")#mi("v_1,\\dots,v_n")#text(" are fixed rational numbers, ")#mi("t")#text(" ranges over ")#mi("\\mathbb{R}")#text(" and ")#tao-math("\\left|x\\right|_p", block: false)#text(" denotes the p-adic absolute value of ")#mi("x")#text("? I’ve come up with something I can’t understand. I guess my (as I said, probably stupid) question boils down to this:")

#text("1) For an algebraic number ")#mi("x")#text(", the product of all the p-adic absolute values of ")#mi("x")#text(" equals ")#tao-math("\\frac{1}{\\left|x\\right|}", block: false)#text(".")

#text("2) For any ")#mi("p,x,y")#text(", ")#tao-math("\\left|x+y\\right|_p \\leq \\max (\\left|x\\right|_p,\\left|y\\right|_p)", block: false)

#text("So if ")#mi("n")#text(" is a sufficiently large positive integer, since the Euclidean distance between, say, 1 and ")#mi("e^{\\frac{\\pi i}{n}}")#text(" is smaller than 1, for at least one ")#mi("p")#text(", we must have that the p-adic distance between the two numbers is ")#mi("> 1")#text(" by 1). But by 2), this distance is at most ")#tao-math("\\max (\\left|1\\right|_p,\\left|e^{\\frac{\\pi i}{n}}\\right|_p)", block: false)#text(", and ")#tao-math("\\left|e^{\\frac{\\pi i}{n}}\\right|_p = 1", block: false)#text(" since it is a root of unity.")

#text("I hope this isn’t too far off topic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-506469")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2018")])]

#text("I’m not sure one can make sense p-adically of ")#mi("(e^{\\pi i v_n})^t")#text(" if ")#mi("t")#text(" is real, since ")#mi("(e^{\\pi i v_n})^t")#text(" will then in general just be a transcendental complex number. However, there is some work on studying function field analogues of the lonely runner conjecture which you may be interested in: ")#link("https://arxiv.org/abs/1711.01207")[#text("https://arxiv.org/abs/1711.01207")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86d49f80fc3ebcf3a5c2a5aadba36785a0b54fc2824432dfc8ee055320a5718c-8041807490b9ecdf8c2c24ee6ff3d5f3870b1770b15ba565aadaa7393d31993f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Florent L. B. Périat")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-530675")[#strong[#text("Florent L. B. Périat")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2019")])]

#text("Hi, Prof. Tao, I found one iterative algorithm which seems to make the times for the different runners to be lonely converge. So proving its completeness, would also proves the conjecture ? But, the program does not always converge to a solution, especially when the speeds are only integers. Would a kind of ghost decimal speed value that does not increment k help ?")

#text("PS : Sorry for my English")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-638819")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2021")])]

#text("Prof. Tao are you aware of any literature where the authors have tried to approach this problem probabilistically.")#linebreak()#text(" (This problem seems to scream “use probability” in my ears, but that might be due to my lack of experience in mathematics or my obsession with probability.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-638820")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2021")])]

#text("Reblogged this on ")#link("https://scoutmathematics.wordpress.com/2021/12/30/a-remark-on-the-lonely-runner-conjecture/")[#text("Aditya Guha Roy's weblog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e60a1f0a6f4771457037652488b48120b9f6d933912b293d998629c6a08c07f-7702d5ceb0ab9c6e1a209b4e8b670248aec252372835905f8162864fe97d4dbb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of martin")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-659896")[#strong[#text("martin")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2022")])]

#text("Has the opposite problem been considered in the literature (or elsewhere)? I would be interested whether ALL runners need to be close (how close?) to the integers at some point in time. Obviously we would need to remove the condition of start at the origin at t=0.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e60a1f0a6f4771457037652488b48120b9f6d933912b293d998629c6a08c07f-7702d5ceb0ab9c6e1a209b4e8b670248aec252372835905f8162864fe97d4dbb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of martin")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-659959")[#strong[#text("martin")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2022")])]

#text("Oh I see this is in a sense equivalent to the original problem because close to the integers means far away from the half-integers.")#linebreak()#text(" However for the removal of the start condition I did not find anything except a comment by Wills to a 2012 talk in Siegen by Goddyn that maybe Hans-Gill or Dumir did work on this. So the question still stands: what about removing the start condition – is there some literature?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e60a1f0a6f4771457037652488b48120b9f6d933912b293d998629c6a08c07f-7702d5ceb0ab9c6e1a209b4e8b670248aec252372835905f8162864fe97d4dbb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of martin")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-660020")[#strong[#text("martin")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2022")])]

#text("After more search, there is ")#link("https://arxiv.org/abs/2009.12080")[#text("https://arxiv.org/abs/2009.12080")]#text(" which calls the generalization the “shifted lonely runner conjecture” and proves it for 4 runners (i.e one stationary and n=3 non-stationary ones).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-659934")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2022")])]

#text("Is it possible to show that that the conjecture is true for “almost every runners velocities” (in some sense) the conjecture is true?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/13/a-remark-on-the-lonely-runner-conjecture/#comment-693418")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2026")])]

#text("Why are we stuck at 14 runners? I think the problem becomes very difficult when n is a general number, as it might violate the uncertainty principle.")
]
