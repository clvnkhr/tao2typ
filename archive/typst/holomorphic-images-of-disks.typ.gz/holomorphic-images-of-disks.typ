// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/11/28/holomorphic-images-of-disks/
// Converted to Typst by tao2typ: "2026-10-14T16:38:52.647076+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Holomorphic images of disks", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Holomorphic images of disks")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 November 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/11/28/holomorphic-images-of-disks/")[#text("https://terrytao.wordpress.com/2020/11/28/holomorphic-images-of-disks/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Consider a disk ")#tao-math("{D(z_0,r) := \\{ z: \\left|z-z_0\\right| < r \\}}", block: false)#text(" in the complex plane. If one applies an affine-linear map ")#mi("{f(z) = az+b}")#text(" to this disk, one obtains")

#align(center)[#tao-fit-display[#tao-math("f(D(z_0,r)) = D(f(z_0), \\left|f^{\\prime}(z_0)\\right| r).", block: true)]]

#text("For maps that are merely holomorphic instead of affine-linear, one has some variants of this assertion, which I am recording here mostly for my own reference:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Holomorphic images of disks)")]#text(" Let ")#mi("{D(z_0,r)}")#text(" be a disk in the complex plane, and ")#mi("{f: D(z_0,r) \\rightarrow {\\bf C}}")#text(" be a holomorphic function with ")#mi("{f^{\\prime}(z_0) \\neq 0}")#text(".")

#list(
[#text("(i) (")#link("https://en.wikipedia.org/wiki/Open_mapping_theorem_(complex_analysis)")[#text("Open mapping theorem")]#text(" or ")#link("https://en.wikipedia.org/wiki/Inverse_function_theorem")[#text("inverse function theorem")]#text(") ")#mi("{f(D(z_0,r))}")#text(" contains a disk ")#mi("{D(f(z_0),\\varepsilon)}")#text(" for some ")#mi("{\\varepsilon>0}")#text(". (In fact there is even a holomorphic right inverse of ")#mi("{f}")#text(" from ")#mi("{D(f(z_0), \\varepsilon)}")#text(" to ")#mi("{D(z_0,r)}")#text(".)")],
[#text("(ii) (")#link("https://en.wikipedia.org/wiki/Bloch%27s_theorem_(complex_variables)")[#text("Bloch theorem")]#text(") ")#mi("{f(D(z_0,r))}")#text(" contains a disk ")#mi("{D(w, c |f^{\\prime}(z_0)| r)}")#text(" for some absolute constant ")#mi("{c>0}")#text(" and some ")#mi("{w \\in {\\bf C}}")#text(". (In fact there is even a holomorphic right inverse of ")#mi("{f}")#text(" from ")#mi("{D(w, c |f^{\\prime}(z_0)| r)}")#text(" to ")#mi("{D(z_0,r)}")#text(".)")],
[#text("(iii) (")#link("https://en.wikipedia.org/wiki/Koebe_quarter_theorem")[#text("Koebe quarter theorem")]#text(") If ")#mi("{f}")#text(" is injective, then ")#mi("{f(D(z_0,r))}")#text(" contains the disk ")#mi("{D(f(z_0), \\frac{1}{4} |f^{\\prime}(z_0)| r)}")#text(".")],
[#text("(iv) If ")#mi("{f}")#text(" is a polynomial of degree ")#mi("{n}")#text(", then ")#mi("{f(D(z_0,r))}")#text(" contains the disk ")#mi("{D(f(z_0), \\frac{1}{n} |f^{\\prime}(z_0)| r)}")#text(".")],
[#text("(v) If one has a bound of the form ")#tao-math("{\\left|f^{\\prime}(z)\\right| \\leq A \\left|f^{\\prime}(z_0)\\right|}", block: false)#text(" for all ")#mi("{z \\in D(z_0,r)}")#text(" and some ")#mi("{A>1}")#text(", then ")#mi("{f(D(z_0,r))}")#text(" contains the disk ")#mi("{D(f(z_0), \\frac{c}{A} |f^{\\prime}(z_0)| r)}")#text(" for some absolute constant ")#mi("{c>0}")#text(". (In fact there is holomorphic right inverse of ")#mi("{f}")#text(" from ")#mi("{D(f(z_0), \\frac{c}{A} |f^{\\prime}(z_0)| r)}")#text(" to ")#mi("{D(z_0,r)}")#text(".)")]
)
]

#text("Parts (i), (ii), (iii) of this theorem are standard, as indicated by the given links. I found part (iv) as (a consequence of) Theorem 2 of ")#link("https://arxiv.org/abs/1106.4126")[#text("this paper of Degot")]#text(", who remarks that it “seems not already known in spite of its simplicity”; an equivalent form of this result also appears in Lemma 4 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1219199")[#text("this paper of Miller")]#text(". The proof is simple:")

#emph[#text("Proof:")]#text(" (Proof of (iv)) Let ")#mi("{w \\in D(f(z_0), \\frac{1}{n} |f^{\\prime}(z_0)| r)}")#text(", then we have a lower bound for the log-derivative of ")#mi("{f(z)-w}")#text(" at ")#mi("{z_0}")#text(":")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\left|f^{\\prime}(z_0)\\right|}{\\left|f(z_0)-w\\right|} > \\frac{n}{r}", block: true)]]

#text("(with the convention that the left-hand side is infinite when ")#mi("{f(z_0)=w}")#text("). But by the fundamental theorem of algebra we have")

#align(center)[#tao-fit-display[#mitex("\\frac{f^{\\prime}(z_0)}{f(z_0)-w} = \\sum_{j=1}^n \\frac{1}{z_0-\\zeta_j}")]]

#text("where ")#mi("{\\zeta_1,\\dots,\\zeta_n}")#text(" are the roots of the polynomial ")#mi("{f(z)-w}")#text(" (counting multiplicity). By the pigeonhole principle, there must therefore exist a root ")#mi("{\\zeta_j}")#text(" of ")#mi("{f(z) - w}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|z_0-\\zeta_j\\right|} > \\frac{1}{r}", block: true)]]

#text("and hence ")#mi("{\\zeta_j \\in D(z_0,r)}")#text(". Thus ")#mi("{f(D(z_0,r))}")#text(" contains ")#mi("{w}")#text(", and the claim follows. ")#mi("\\Box")

#text("The constant ")#mi("{\\frac{1}{n}}")#text(" in (iv) is completely sharp: if ")#mi("{f(z) = z^n}")#text(" and ")#mi("{z_0}")#text(" is non-zero then ")#tao-math("{f(D(z_0,\\left|z_0\\right|))}", block: false)#text(" contains the disk")

#align(center)[#tao-fit-display[#tao-math("D(f(z_0), \\frac{1}{n} |f^{\\prime}(z_0)| r) = D( z_0^n, \\left|z_0\\right|^n)", block: true)]]

#text("but avoids the origin, thus does not contain any disk of the form ")#tao-math("{D( z_0^n, \\left|z_0\\right|^n+\\varepsilon)}", block: false)#text(". This example also shows that despite parts (ii), (iii) of the theorem, one cannot hope for a general inclusion of the form")

#align(center)[#tao-fit-display[#mitex("f(D(z_0,r)) \\supset D(f(z_0), c |f^{\\prime}(z_0)| r )")]]

#text("for an absolute constant ")#mi("{c>0}")#text(".")

#text("Part (v) is implicit in the standard proof of Bloch’s theorem (part (ii)), and is easy to establish:")

#emph[#text("Proof:")]#text(" (Proof of (v)) From the Cauchy inequalities one has ")#tao-math("{f^{\\prime\\prime}(z) = O(\\frac{A}{r} \\left|f^{\\prime}(z_0)\\right|)}", block: false)#text(" for ")#mi("{z \\in D(z_0,r/2)}")#text(", hence by Taylor’s theorem with remainder ")#tao-math("{f(z) = f(z_0) + f^{\\prime}(z_0) (z-z_0) (1 + O( A \\frac{\\left|z-z_0\\right|}{r} ) )}", block: false)#text(" for ")#mi("{z \\in D(z_0, r/2)}")#text(". By Rouche’s theorem, this implies that the function ")#mi("{f(z)-w}")#text(" has a unique zero in ")#mi("{D(z_0, 2cr/A)}")#text(" for any ")#tao-math("{w \\in D(f(z_0), cr\\left|f^{\\prime}(z_0)\\right|/A)}", block: false)#text(", if ")#mi("{c>0}")#text(" is a sufficiently small absolute constant. The claim follows. ")#mi("\\Box")

#text("Note that part (v) implies part (i). A standard point picking argument also lets one deduce part (ii) from part (v):")

#emph[#text("Proof:")]#text(" (Proof of (ii)) By shrinking ")#mi("{r}")#text(" slightly if necessary we may assume that ")#mi("{f}")#text(" extends analytically to the closure of the disk ")#mi("{D(z_0,r)}")#text(". Let ")#mi("{c}")#text(" be the constant in (v) with ")#mi("{A=2}")#text("; we will prove (iii) with ")#mi("{c}")#text(" replaced by ")#mi("{c/2}")#text(". If we have ")#tao-math("{\\left|f^{\\prime}(z)\\right| \\leq 2 \\left|f^{\\prime}(z_0)\\right|}", block: false)#text(" for all ")#mi("{z \\in D(z_0,r/2)}")#text(" then we are done by (v), so we may assume without loss of generality that there is ")#mi("{z_1 \\in D(z_0,r/2)}")#text(" such that ")#tao-math("{\\left|f^{\\prime}(z_1)\\right| > 2 \\left|f^{\\prime}(z_0)\\right|}", block: false)#text(". If ")#tao-math("{\\left|f^{\\prime}(z)\\right| \\leq 2 \\left|f^{\\prime}(z_1)\\right|}", block: false)#text(" for all ")#mi("{z \\in D(z_1,r/4)}")#text(" then by (v) we have")

#tao-aligned(keep: true)[


#tao-math("f( D(z_0, r) )  & \\supset f( D(z_1,r/2) ) \\supset D( f(z_1), \\frac{c}{2} |f^{\\prime}(z_1)| \\frac{r}{2} )", block: true)



#tao-math(" & \\supset D( f(z_1), \\frac{c}{2} |f^{\\prime}(z_0)| r )", block: true)
]

#text("and we are again done. Hence we may assume without loss of generality that there is ")#mi("{z_2 \\in D(z_1,r/4)}")#text(" such that ")#tao-math("{\\left|f^{\\prime}(z_2)\\right| > 2 \\left|f^{\\prime}(z_1)\\right|}", block: false)#text(". Iterating this procedure in the obvious fashion we either are done, or obtain a Cauchy sequence ")#mi("{z_0, z_1, \\dots}")#text(" in ")#mi("{D(z_0,r)}")#text(" such that ")#mi("{f^{\\prime}(z_j)}")#text(" goes to infinity as ")#mi("{j \\rightarrow \\infty}")#text(", which contradicts the analytic nature of ")#mi("{f}")#text(" (and hence continuous nature of ")#mi("{f^{\\prime}}")#text(") on the closure of ")#mi("{D(z_0,r)}")#text(". This gives the claim. ")#mi("\\Box")

#text("Here is another classical result ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1503516")[#text("stated by Alexander")]#text(" (and then proven by Kakeya and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1544526")[#text("by Szego")]#text(", but also implied to a classical theorem of Grace and Heawood) that is broadly compatible with parts (iii), (iv) of the above theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2")]#text(" Let ")#mi("{D(z_0,r)}")#text(" be a disk in the complex plane, and ")#mi("{f: D(z_0,r) \\rightarrow {\\bf C}}")#text(" be a polynomial of degree ")#mi("{n \\geq 1}")#text(" with ")#mi("{f^{\\prime}(z) \\neq 0}")#text(" for all ")#mi("{z \\in D(z_0,r)}")#text(". Then ")#mi("{f}")#text(" is injective on ")#mi("{D(z_0, \\sin\\frac{\\pi}{n})}")#text(".")
]

#text("The radius ")#mi("{\\sin \\frac{\\pi}{n}}")#text(" is best possible, for the polynomial ")#mi("{f(z) = z^n}")#text(" has ")#mi("{f^{\\prime}}")#text(" non-vanishing on ")#mi("{D(1,1)}")#text(", but one has ")#mi("{f(\\cos(\\pi/n) e^{i \\pi/n}) = f(\\cos(\\pi/n) e^{-i\\pi/n})}")#text(", and ")#mi("{\\cos(\\pi/n) e^{i \\pi/n}, \\cos(\\pi/n) e^{-i\\pi/n}}")#text(" lie on the boundary of ")#mi("{D(1,\\sin \\frac{\\pi}{n})}")#text(".")

#text("If one narrows ")#mi("{\\sin \\frac{\\pi}{n}}")#text(" slightly to ")#mi("{\\sin \\frac{\\pi}{2n}}")#text(" then one can quickly prove this proposition as follows. Suppose for contradiction that there exist distinct ")#mi("{z_1, z_2 \\in D(z_0, \\sin\\frac{\\pi}{n})}")#text(" with ")#mi("{f(z_1)=f(z_2)}")#text(", thus if we let ")#mi("{\\gamma}")#text(" be the line segment contour from ")#mi("{z_1}")#text(" to ")#mi("{z_2}")#text(" then ")#mi("{\\int_\\gamma f^{\\prime}(z)\\ dz}")#text(". However, by assumption we may factor ")#mi("{f^{\\prime}(z) = c (z-\\zeta_1) \\dots (z-\\zeta_{n-1})}")#text(" where all the ")#mi("{\\zeta_j}")#text(" lie outside of ")#mi("{D(z_0,r)}")#text(". Elementary trigonometry then tells us that the argument of ")#mi("{z-\\zeta_j}")#text(" only varies by less than ")#mi("{\\frac{\\pi}{n}}")#text(" as ")#mi("{z}")#text(" traverses ")#mi("{\\gamma}")#text(", hence the argument of ")#mi("{f^{\\prime}(z)}")#text(" only varies by less than ")#mi("{\\pi}")#text(". Thus ")#mi("{f^{\\prime}(z)}")#text(" takes values in an open half-plane avoiding the origin and so it is not possible for ")#mi("{\\int_\\gamma f^{\\prime}(z)\\ dz}")#text(" to vanish.")

#text("To recover the best constant of ")#mi("{\\sin \\frac{\\pi}{n}}")#text(" requires some effort. By taking contrapositives and applying an affine rescaling and some trigonometry, the proposition can be deduced from the following result, known variously as the Grace-Heawood theorem or the complex Rolle theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Grace-Heawood theorem)")]#text(" Let ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" be a polynomial of degree ")#mi("{n \\geq 1}")#text(" such that ")#mi("{f(1)=f(-1)}")#text(". Then ")#mi("{f^{\\prime}}")#text(" contains a zero in the closure of ")#mi("{D( 0, \\cot \\frac{\\pi}{n} )}")#text(".")
]

#text("This is in turn implied by a remarkable and powerful theorem of Grace (which we shall prove shortly). Given two polynomials ")#mi("{f,g}")#text(" of degree at most ")#mi("{n}")#text(", define the ")#emph[#text("apolar")]#text(" form ")#mi("{(f,g)_n}")#text(" by ")#metadata(none) <tao-20ddf8eaafbb891d175a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("(f,g)_n := \\sum_{k=0}^n (-1)^k f^{(k)}(0) g^{(n-k)}(0).")]]



#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Grace’s theorem)")]#text(" Let ")#mi("{C}")#text(" be a circle or line in ")#mi("{{\\bf C}}")#text(", dividing ")#mi("{{\\bf C} \\backslash C}")#text(" into two open connected regions ")#mi("{\\Omega_1, \\Omega_2}")#text(". Let ")#mi("{f,g}")#text(" be two polynomials of degree at most ")#mi("{n \\geq 1}")#text(", with all the zeroes of ")#mi("{f}")#text(" lying in ")#mi("{\\Omega_1}")#text(" and all the zeroes of ")#mi("{g}")#text(" lying in ")#mi("{\\Omega_2}")#text(". Then ")#mi("{(f,g)_n \\neq 0}")#text(".")
]

#text("(Contrapositively: if ")#mi("{(f,g)_n=0}")#text(", then the zeroes of ")#mi("{f}")#text(" cannot be separated from the zeroes of ")#mi("{g}")#text(" by a circle or line.)")

#text("Indeed, a brief calculation reveals the identity")

#align(center)[#tao-fit-display[#mitex("f(1) - f(-1) = (f^{\\prime}, g)_{n-1}")]]

#text("where ")#mi("{g}")#text(" is the degree ")#mi("{n-1}")#text(" polynomial")

#align(center)[#tao-fit-display[#mitex("g(z) := \\frac{1}{n!} ((z+1)^n - (z-1)^n).")]]

#text("The zeroes of ")#mi("{g}")#text(" are ")#mi("{i \\cot \\frac{\\pi j}{n}}")#text(" for ")#mi("{j=1,\\dots,n-1}")#text(", so the Grace-Heawood theorem follows by applying Grace’s theorem with ")#mi("{C}")#text(" equal to the boundary of ")#mi("{D(0, \\cot \\frac{\\pi}{n})}")#text(".")

#text("The same method of proof gives the following nice consequence:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Perpendicular bisector theorem)")]#text(" Let ")#mi("{f: {\\bf C} \\rightarrow C}")#text(" be a polynomial such that ")#mi("{f(z_1)=f(z_2)}")#text(" for some distinct ")#mi("{z_1,z_2}")#text(". Then the zeroes of ")#mi("{f^{\\prime}}")#text(" cannot all lie on one side of the perpendicular bisector of ")#mi("{z_1,z_2}")#text(". For instance, if ")#mi("{f(1)=f(-1)}")#text(", then the zeroes of ")#mi("{f^{\\prime}}")#text(" cannot all lie in the halfplane ")#mi("{\\{ z: \\mathrm{Re} z > 0 \\}}")#text(" or the halfplane ")#mi("{\\{ z: \\mathrm{Re} z < 0 \\}}")#text(".")
]

#text("I’d be interested in seeing a proof of this latter theorem that did not proceed via Grace’s theorem.")

#text("Now we give a proof of Grace’s theorem. The case ")#mi("{n=1}")#text(" can be established by direct computation, so suppose inductively that ")#mi("{n>1}")#text(" and that the claim has already been established for ")#mi("{n-1}")#text(". Given the involvement of circles and lines it is natural to suspect that a Möbius transformation symmetry is involved. This is indeed the case and can be made precise as follows. Let ")#mi("{V_n}")#text(" denote the vector space of polynomials ")#mi("{f}")#text(" of degree at most ")#mi("{n}")#text(", then the apolar form is a bilinear form ")#mi("{(,)_n: V_n \\times V_n \\rightarrow {\\bf C}}")#text(". Each translation ")#mi("{z \\mapsto z+a}")#text(" on the complex plane induces a corresponding map on ")#mi("{V_n}")#text(", mapping each polynomial ")#mi("{f}")#text(" to its shift ")#mi("{\\tau_a f(z) := f(z-a)}")#text(". We claim that the apolar form is invariant with respect to these translations:")

#align(center)[#tao-fit-display[#mitex("( \\tau_a f, \\tau_a g )_n = (f,g)_n.")]]

#text("Taking derivatives in ")#mi("{a}")#text(", it suffices to establish the skew-adjointness relation")

#align(center)[#tao-fit-display[#mitex("(f^{\\prime}, g)_n + (f,g^{\\prime})_n = 0")]]

#text("but this is clear from the alternating form of ")#link(<tao-20ddf8eaafbb891d175a>)[#text("(1)")]#text(".")

#text("Next, we see that the inversion map ")#mi("{z \\mapsto 1/z}")#text(" also induces a corresponding map on ")#mi("{V_n}")#text(", mapping each polynomial ")#mi("{f \\in V_n}")#text(" to its inversion ")#mi("{\\iota f(z) := z^n f(1/z)}")#text(". From ")#link(<tao-20ddf8eaafbb891d175a>)[#text("(1)")]#text(" we see that this map also (projectively) preserves the apolar form:")

#align(center)[#tao-fit-display[#mitex("(\\iota f, \\iota g)_n = (-1)^n (f,g)_n.")]]

#text("More generally, the group of Möbius transformations on the Riemann sphere acts projectively on ")#mi("{V_n}")#text(", with each Möbius transformation ")#mi("{T: {\\bf C} \\rightarrow {\\bf C}}")#text(" mapping each ")#mi("{f \\in V_n}")#text(" to ")#mi("{Tf(z) := g_T(z) f(T^{-1} z)}")#text(", where ")#mi("{g_T}")#text(" is the unique (up to constants) rational function that maps this a map from ")#mi("{V_n}")#text(" to ")#mi("{V_n}")#text(" (its divisor is ")#mi("{n(T \\infty) - n(\\infty)}")#text("). Since the Möbius transformations are generated by translations and inversion, we see that the action of Möbius transformations projectively preserves the apolar form; also, we see this action of ")#mi("{T}")#text(" on ")#mi("{V_n}")#text(" also moves the zeroes of each ")#mi("{f \\in V_n}")#text(" by ")#mi("{T}")#text(" (viewing polynomials of degree less than ")#mi("{n}")#text(" in ")#mi("{V_n}")#text(" as having zeroes at infinity). In particular, the hypotheses and conclusions of Grace’s theorem are preserved by this Möbius action. We can then apply such a transformation to move one of the zeroes of ")#mi("{f}")#text(" to infinity (thus making ")#mi("{f}")#text(" a polynomial of degree ")#mi("{n-1}")#text("), so that ")#mi("{C}")#text(" must now be a circle, with the zeroes of ")#mi("{g}")#text(" inside the circle and the remaining zeroes of ")#mi("{f}")#text(" outside the circle. But then")

#align(center)[#tao-fit-display[#mitex("(f,g)_n = (f, g^{\\prime})_{n-1}.")]]

#text("By the ")#link("https://en.wikipedia.org/wiki/Gauss%E2%80%93Lucas_theorem")[#text("Gauss-Lucas theorem")]#text(", the zeroes of ")#mi("{g^{\\prime}}")#text(" are also inside ")#mi("{C}")#text(". The claim now follows from the induction hypothesis.")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/11/28/holomorphic-images-of-disks/#comment-606777")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2020")])]

#text("What are the best possible values of the absolute constants in (ii) and (v)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/11/28/holomorphic-images-of-disks/#comment-606810")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2020")])]

#text("For (ii) the best constant is known as ")#link("https://encyclopediaofmath.org/wiki/Bloch_constant#:~:text=An%20absolute%20constant%2C%20the%20existence,of%20radius%20Bf%3E0.")[#text("Bloch’s constant")]#text("; it is somewhere between 0.433 and 0.4719 but the precise value is not known. The best constant in (v) is of roughly a similar order of magnitude but I don’t think it’s value has been intensively studied.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonym")]], [#link("https://terrytao.wordpress.com/2020/11/28/holomorphic-images-of-disks/#comment-606842")[#strong[#text("Anonym")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2020")])]

#text("Dear Professor,")

#text("Except the contribution of Dégot, I suggest to you the recent Ph.D Thesis of Taboka Prince Chalebgwa on the geometry of complex polynomials, and his paper entitled “Sendov conjecture: On a paper of Dégot” which has been published in Analysis Mathematica in 2018")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/11/28/holomorphic-images-of-disks/#comment-606847")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2020")])]

#text("Your present post seems in fact related to the famous Ilief-Sendov conjecture.")#linebreak()#text(" Here is an interesting reference on this topic.")#linebreak()#text(" Zhaizhao Meng. “Proof of the Sendov conjecture for polynomials of degre ni ne.” Preprint uploaded to the ArXiv in 2017. Last revised on April 17, 2018.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan")]], [#link("https://terrytao.wordpress.com/2020/11/28/holomorphic-images-of-disks/#comment-606920")[#strong[#text("Alan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2020")])]

#text("Following the previous messages, could you precise if your very interesting contribution in the present post has an eventual strong or weak connection with the well-known Iliev-Sendov conjecture?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/11/28/holomorphic-images-of-disks/#comment-607220")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2020")])]

#emph[#text("…by (v) we have")]

#mi("\\displaystyle  f( D(z_0, r) ) \\supset f( D(z_1,r/2) ) \\supset D( f(z_1), \\frac{c}{2} |f^{\\prime}(z_1)| \\frac{r}{2} ) \\supset D( f(z_1), \\frac{c}{2} |f^{\\prime}(z_0)| r )")#linebreak()

#text("Part of this long line is missing in the display:")

#mi("\\displaystyle  f( D(z_0, r) )  \\supset f( D(z_1,r/2) )  \\supset D( f(z_1), \\frac{c}{2} |f^{\\prime}(z_1)| \\frac{r}{2} )")#linebreak()#text(" ")#mi("\\displaystyle \\supset D( f(z_1), \\frac{c}{2} |f^{\\prime}(z_0)| r )")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/11/28/holomorphic-images-of-disks/#comment-607255")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2020")])]

#text("Are there similar theorems for meromorphic images of disks?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/405969d14a225183ed3e020ed3d4f7ba4b701f0d7a2a8b13b4e70204b5cb335f-05ec8b80fac8a970e9b75fb37efdd09e4fa61475b586004b819f604ec434a366.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacob Manaker")]], [#link("https://terrytao.wordpress.com/2020/11/28/holomorphic-images-of-disks/#comment-607431")[#strong[#text("Jacob Manaker")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2020")])]

#text("What is the intuition for the apolar form?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/405969d14a225183ed3e020ed3d4f7ba4b701f0d7a2a8b13b4e70204b5cb335f-05ec8b80fac8a970e9b75fb37efdd09e4fa61475b586004b819f604ec434a366.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacob Manaker")]], [#link("https://terrytao.wordpress.com/2020/11/28/holomorphic-images-of-disks/#comment-607795")[#strong[#text("Jacob Manaker")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2020")])]

#text("Plaumann (1410.5935) notes that the apolar form coincides, “up to a conjugation in the second argument…with Fischer’s inner product…well known for identifying the adjoint of complex differentiation with the multipli-cation by the variable”; and has “geometric implications…surprising and multifold [8].” Following up on note 8 (Algebra of Invariants, Grace & Young, 1903), it appears that the apolar form is sensitive to multiple zeros, so that it can be used to detect tangency and (dually) collinearity.")

#text("For the purposes of this theorem, I think it’s probably best to black-box the form: it is (Plaumann again) “the only joint invariant under affine substitutions which is linear in the coefficients” and the “zero location property [of the Grace-Heawood theorem] is equivalent to apolarity.” So if we seek a tool to detect zeros separated by clines, and want a proof by Möbius transforms, the apolar form is the only game in town.")

#text("(Yes, I’m answering a question I posed. I don’t care.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of HuaFoFeng")]], [#link("https://terrytao.wordpress.com/2020/11/28/holomorphic-images-of-disks/#comment-607548")[#strong[#text("HuaFoFeng")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2020")])]

#text("In order to answer to the question of Alan, the current post of Pr. Tao has a fortiori nothing to do with Iliev -Sendov conjecture, even if the same research subfield of geometrical aspects of complex polynomials is here considered. To the best of my knowledge, this conjecture remains an open problem today. It was only proven in particular cases and up to n = 9 nowadays by Meng (see the corresponding aforementioned reference in a previous commentary).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/11/28/holomorphic-images-of-disks/#comment-607767")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2020")])]

#text("is it true that the Stein Shakarchi Complex analysis book doesn’t have the standard definition of holomorphic functions?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/15d0e16496de322c7505bd61aa49ab57d53933c345d2ff8157c6dd85bb126464-787e72d05167f3478c8320ca742621f94f34edda6e69104fb891299d76c74d8c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rob")]], [#link("https://terrytao.wordpress.com/2020/11/28/holomorphic-images-of-disks/#comment-607780")[#strong[#text("Rob")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2020")])]

#text("Should it be “Let V_n denote the vector.space” instead of “V_n denote the vector space”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonym 2")]], [#link("https://terrytao.wordpress.com/2020/11/28/holomorphic-images-of-disks/#comment-607796")[#strong[#text("Anonym 2")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2020")])]

#text("In my opinion, I see rather “If the V_n denote (…)”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sendov’s conjecture for sufficiently high degree polynomials | What's new")]], [#link("https://terrytao.wordpress.com/2020/11/28/holomorphic-images-of-disks/#comment-608989")[#strong[#text("Sendov’s conjecture for sufficiently high degree polynomials | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2020")])]

#text("[…] the unique continuation property for harmonic functions and Grace’s theorem (discussed in this previous post), with the latter drawn from the prior work of Dégot, we can get very good control on these […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47373d5dde599011b5626a355281c6ca40415567d0e12920043267cfcc54e888-831cf9c3d95e385d8cea6f94baeca1c7d5e9deba0d151e80ee8bfe81938d33a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of profoundlyengineer435c9e043f")]], [#link("https://terrytao.wordpress.com/2020/11/28/holomorphic-images-of-disks/#comment-691957")[#strong[#text("profoundlyengineer435c9e043f")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2026")])]

#text("One more proof of iv) by Alexey Solyanik “Note on the Covering Theorem for Complex Polynomials”, 2016 ")#link("https://arxiv.org/pdf/1410.6772")[#text("https://arxiv.org/pdf/1410.6772")]
]
