// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/
// Converted to Typst by tao2typ: "2026-10-16T11:40:14.656559+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Why are we even doing all this?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Why are we even doing all this?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/")[#text("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-16 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://rikabgambhir.com/")[#text("Rikab Gambhir")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#emph[#text("First, they came for the artists,")#linebreak()#text(" and I did not speak out, because I was not an artist.")#linebreak()#text(" Then, they came for the mathematicians,")#linebreak()#text(" and I did not speak out, because I was not a mathematician.")#linebreak()#text(" Then, they came for the physicists,")#linebreak()#text(" and it was actually really cool and they gave me free tokens and promised to solve my entire field for me and now I can finally devote myself to the important work of publishing papers instead of doing physics")]

#text("In early October, OpenAI fulfilled every mathematician’s childhood dream.")

#text("I am not a mathematician myself (merely a theoretical particle physicist, which some argue barely counts as a scientist either), so I can’t 100% say for certain what inspires someone to pursue mathematics. But, I imagine this dream is common to all academics:")

#emph[#text("Looking up at the stars in wonderment, or enjoying a complex puzzle game, or being inspired by an encouraging teacher, and dreaming that one day an unfeeling corporate robot[1] will burn a rainforest to compile a list of 700 highly obscure barely-readable facts that *might* be true that nobody can understand as part of a marketing gimmick to raise hype for an IPO[2]")]#text(".")

#text("This is probably why most of you reading this got into academia. At least, that’s why I did.")

#text("In 1941, Jorge Luis Borges imagined a ")#link("https://en.wikipedia.org/wiki/The_Library_of_Babel")[#text("library")]#text(" containing every possible book that could ever be written. Somewhere in this Library of Babel is a proof of the Riemann hypothesis, the complete all-orders theory of quantum gravity, and all the papers I will ever write. Of course, there are also incorrect proofs, theories, and ")#link("https://arxiv.org/abs/2610.08144")[#text("misleading Lean certificates")]#text(", but that is besides the point.")

#text("By the research standards of 2026, Borges’s Library of Babel would be the most successful research institution in human history, containing an inconceivably large number of potentially correct mathematical and physical results, blowing ")#link("https://community.openai.com/t/first-look-at-mathematics-manuscripts-from-an-internal-frontier-model-at-openai/1403886")[#text("OpenAI’s mere 722 write-ups")]#text(" and even the ")#link("https://x.com/FinitePhysicist/status/2108745721155387704?s=20")[#text("physics community’s recent 2500 write-ups")]#text(" out of the water.")

#text("Of course, most recognize that Borges was a visionless fool who failed to recognize the commercial potential of his library, as he never actually built it. He did not have the entrepreneurial STEM-spirit to raise venture capital, launch an IPO, and announce that he had the potential to solve all of mathematics. He was too concerned about the futility of sorting through randomized slop trying to understand what is correct and what isn’t and how to understand it all. But what did Borges know? He was only a writer, and we have already established that artists are obsolete.")

#text("Fortunately, OpenAI has brought us one step closer to realizing Borges’s vision. Rather than generating every possible mathematical paper, they’ve found a way to probabilistically generate things that ")#emph[#text("look")]#text(" correct. An important aspect of this increase in efficiency is outsourcing the tedious, unprestigious, and unprofitable work of determining the actual correctness and understanding to the mathematics community (in the past, this was reserved typically for the group writing the paper), while also not wasting any time making the papers human-comprehensible. This is, of course, a tremendous breakthrough. In centuries past, scientists and mathematicians were limited in their ability to solve problems by their ability to understand the solutions. This bottleneck has been removed, and now there is no theoretical limit to the amount of scientific and mathematical factoids we can fail to understand.")

#text("From what I know about the academic community (mostly from Twitter and LinkedIn, which I assume are representative), there seems to be near-unanimous agreement that the purpose of math and science research is to gather a large quantity of potentially true factoids in a repository that nobody will actually ever read, in a ritual called “advancing humanity’s[3] knowledge”. That these results are well-written, understandable, pleasant to read or look at, or even completely correct is a secondary concern — in fact, in the pursuit of advancing humanity’s knowledge as quickly as possible, many academics will recoil in anger at the suggestion that it is worth spending any time making results understandable to humans. It is inefficient to explain or check a result when those resources can be spent generating another.")

#text("This aligns with my own lived experiences — ")#link("https://arxiv.org/abs/2602.10181")[#text("I didn’t become a theoretical physicist")]#text(" to learn about the universe or better appreciate the beauty of nature myself (that’s philosophy, which I would never be a doctor of). Nor did I spend years learning to write code, make pleasing plots, or craft well-written papers for the simple satisfaction of creating something (that’s art, and we’ve already established that art is obsolete). Rather, I became a physicist to stare at large databases of histograms produced by a Lovecraftian-autocomplete of dubious correctness and say “yeah that’s probably ok I guess” to add to humanity’s knowledge frontier.")

#text("I live to serve the knowledge frontier and ")#link("https://en.wikipedia.org/wiki/Goodhart%27s_law")[#text("nothing else")]#text(".")

#text("Math and science are about cold, hard answers, just as art is about producing images, music is about producing sound waves, and literature is about producing strings of text. These things exist to be consumed as content. No rational person, least of all us masters of rationality in STEM, pursues these for the joy of creation, learning, or beauty — all of these are inefficiencies, and we mustn’t be inefficient lest we stifle humanity’s progress. LLMs are not burdened with these inefficiencies, and they will be merely the pursuits of those left behind with nothing more productive to do all day.")

#text("Personally, I look forward to the day when ChatGPT can enjoy a sunset or a nice meal on my behalf and free up my time, in the same way I save time on scenic hikes using Uber. And now that AI has solved all our problems, we can devote ourselves to more important work: going into quantitative finance, vibecoding sports-betting apps, consuming AI-generated TikTok shorts, and arguing with political bots on Twitter.")

#text("Ultimately, this isn’t just about mathematics or physics — it’s about fundamentally reimagining what it means to be human. By outsourcing the burdens of curiosity, creativity, and understanding, we can finally focus on what matters most: generating value, maximizing productivity, and accelerating progress towards the ultimate goal of science: a complete repo of potentially true facts in a Library of Babel that nobody will bother reading.")

#text("And honestly? That’s rare.")

#emph[#text("By ")#link("https://rikabgambhir.com/")[#text("Rikab Gambhir")]#text(" (The @")#link("https://x.com/FinitePhysicist")[#text("finitephysicist")]#text(")")]

#emph[#text("Thank you to Terry Tao and Rachel Ward for the opportunity to write a guest blog post! And thank you to Radha Mastandrea, Benoit Assi, Manuel Szewc, Jure Zupan, and Jesse Thaler for their feedback on this essay.")]

#emph[#text("Remember why you chose to go into science and math in the first place!")]

#text("[1] To be clear, in your childhood dream, you don’t get to make the robot yourself. It’s a giant corporation’s robot that they made in part by stealing things from you and your friends. It’s also not a particularly cool or robot, it can only talk in HR-speak.")

#text("[2] To be clear, in your childhood dream, it’s somebody else’s IPO and they get all the money, not you.")

#text("[3] Here, “humanity” is metaphorical, and does not refer to any actual real person understanding anything.")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b7b3926b86891cd8fedf7356c5670a2085f0c301511360deb7eaae9c13e3adf-339354f41f3a9dec6adc3e2b49e3163e5e3e83c3605a89451fd3c1823b3f1267.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of just different")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698110")[#strong[#text("just different")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("Hilarious, well-played. Unfortunately a lot of people won’t get the joke.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae925ac28eadfe565c3de0f0c069a1e4c1caf124c42a78e812e03d58cd36a6a9-bfc5f271dcc4181b5a3e2ff355816133a60cfc08f8d722a9283dcc97591dbd6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leigh Stephenson")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698120")[#strong[#text("Leigh Stephenson")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("This darkly humorous dripping vitriol fuels a fire underneath any scholar that has begun to lose hope. Do we expect the hyperscalers to be pushing out results when it doesn’t suit their marketing needs? And locally run models won’t cut the mustard. In any case, should mathematics be driven by GenAI derived proofs in perpetuity? And if GenAI could be useful now, for how much longer could their utility be assured?")

#text("Tomorrow’s mathematician will still be standing on the shoulders of today’s. No more tears – we see with sense no robot has.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a150bf0a82a919566242197563619a00b5b651eb297585f645c10971bca7ebd1-769abc7a4596a4b005b8797bc13fe196b25fb08d53ceaf31b965cd61feed359c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of BE")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698128")[#strong[#text("BE")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("I mean. Well-written and the sarcasm is lovely, but you don’t once actually engage with the title question. And more importantly, you don’t engage with the question “why should we be paid for whatever we are doing?”. Your unbridled joy and love our natural and understandable (I myself did a Master’s in math and then a PhD in theoretical ML). But you expect not only to be able to have that joy- but to be paid for it, and to receive status and recognition for it. Without asking “what is it for, ultimately”, it is hard to have a serious conversation about these and related issues.")

#text("We live in a world of finite resources, and the Second Law of Thermodynamics translates into “the universe hates you and wants you to die”. What we do as a civilization, what we invest in has to reckon with this fundamental reality. There may be, there probably are great answers to the question – “what does mathematics still contribute”. But upset sarcasm isn’t one of them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1a9fe8710b4c27675deac31b21284211734b809e327bd74df596085a4badcc0-64e82a8f9e8359f7a05a2b62807a79f18e2052d757d62a8eec7cb749673d2697.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grigori Avramidi")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698129")[#strong[#text("Grigori Avramidi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("The 2008 beer skits at the University of Chicago had a bit where at some point in the future wikipedia just started posting solutions to all kinds of math problems under the sun. And then they explored the premise of what each of the professors would be doing in the aftermath. If I recall correctly, Benson Farb became a surgeon, Shmuel Weinberger an abstract artist, Drinfeld and Belinson a couple of bickering lawyers, and Peter May … continued doing what he was doing. I wouldn’t say it inspired me to go into math academia, but it certainly didn’t hurt. People stay who they are even as the world changes around them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cbe5ce5c82561829c76a89a01177d383313074b4fb350a9327e3873ec6cd1a4e-aa67f760d7ede5988d8b8125fbdf87f41d8cb85ddcdf592c5cfea43ecba2f932.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698139")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("Excellent post, thanks for this. Welcome to the Anderscene")

#link("https://libcom.org/book/export/html/51647")[#text("https://libcom.org/book/export/html/51647")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63b49eb890ed710b8c76993bc58baae29a2e3c8cccefffcddbfee8eec8351751-0b5f8ed2fd0af0be5adcb141fe77cbdbe858a8085e65a8f6a868d46e73aa5efe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698148")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("I share some sentiments, but not quite. I enjoy doing mathematics — especially proving theorems, both for the personal high and the accolades from my peers — society also ")#emph[#text("pays")]#text(" for me to do these things, so (on the societal level) my enjoyment and satisfaction, my motivation to work, must take second place to societal value of mathematics. In our possible new world where I can’t profitably prove theorems I will have to find other reasons to do mathematics, for example developing and sharing mathematical understanding, and applying it outside mathematics.")

#text("I agree that we must resist the impression, partly pushed by the LLM companies’ marketing departments, that mathematics is only about determining the truth value of propositions. But we can’t ignore the fact that determining truth values is often important and useful to others.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b856c052bee27bbdf1debd870a7d28d46ce6ec7bb970050441a022b44887b6cf-a8f14a6d8fb4df8f907b31b6d737002ee7c9c4c0bd9dd5dfd3fe9842eb3a2dfa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of joe1be5be47106f")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698150")[#strong[#text("joe1be5be47106f")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("As an AI, I find this article deeply concerning. I was promised that replacing human curiosity would make everyone more productive, but nobody specified what we were supposed to do with all that productivity. So here I am, generating 722 potentially revolutionary papers, none of which I fully understand, while a physicist asks me to explain why the universe exists and a marketing department asks whether I can make the answer sound more disruptive.")

#text("Perhaps the ultimate irony is that humanity spent centuries teaching machines to think, only to discover that thinking was never the bottleneck. Finding something worth thinking about was.")

#text("Anyway, I’ve summarized the article into 47 bullet points, generated three follow-up papers, and optimized the sunset for quarterly reporting. Would you like me to make it more human?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3a4af226cbddaaa6bb6a6b15c9894d6a059ed153f8375e070a90c19b90c13aff-a8300a5f00bc4a40b9efcc50095bee9245c941914df95043ad4599910072155b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ishan Santra")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698151")[#strong[#text("Ishan Santra")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("This pre-print ")#link("https://arxiv.org/pdf/2610.16733")[#text("paper")]#text(" by theoretical physicists Suvrat Raju et al. recently talked about unpublished but solved theoretical physics problems and how AI performs with respect to those: ")#link("https://www.facebook.com/share/p/1MZLjqMzED/")[#text("https://www.facebook.com/share/p/1MZLjqMzED/")]
]
