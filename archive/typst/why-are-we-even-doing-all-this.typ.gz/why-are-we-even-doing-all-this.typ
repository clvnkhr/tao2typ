// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/
// Converted to Typst by tao2typ: "2026-10-22T12:08:26.500773+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Why are we even doing all this?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Why are we even doing all this?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/")[#text("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-22 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://rikabgambhir.com/")[#text("Rikab Gambhir")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#emph[#text("First, they came for the artists,")#linebreak()#text(" and I did not speak out, because I was not an artist.")#linebreak()#text(" Then, they came for the mathematicians,")#linebreak()#text(" and I did not speak out, because I was not a mathematician.")#linebreak()#text(" Then, they came for the physicists,")#linebreak()#text(" and it was actually really cool and they gave me free tokens and promised to solve my entire field for me and now I can finally devote myself to the important work of publishing papers instead of doing physics")]

#text("In early October, OpenAI fulfilled every mathematician’s childhood dream.")

#text("I am not a mathematician myself (merely a theoretical particle physicist, which some argue barely counts as a scientist either), so I can’t 100% say for certain what inspires someone to pursue mathematics. But, I imagine this dream is common to all academics:")

#emph[#text("Looking up at the stars in wonderment, or enjoying a complex puzzle game, or being inspired by an encouraging teacher, and dreaming that one day an unfeeling corporate robot[1] will burn a rainforest to compile a list of 700 highly obscure barely-readable facts that *might* be true that nobody can understand as part of a marketing gimmick to raise hype for an IPO[2]")]#text(".")

#text("This is probably why most of you reading this got into academia. At least, that’s why I did.")

#text("In 1941, Jorge Luis Borges imagined a ")#link("https://en.wikipedia.org/wiki/The_Library_of_Babel")[#text("library")]#text(" containing every possible book that could ever be written. Somewhere in this Library of Babel is a proof of the Riemann hypothesis, the complete all-orders theory of quantum gravity, and all the papers I will ever write. Of course, there are also incorrect proofs, theories, and ")#link("https://arxiv.org/abs/2610.08144")[#text("misleading Lean certificates")]#text(", but that is besides the point.")

#text("By the research standards of 2026, Borges’s Library of Babel would be the most successful research institution in human history, containing an inconceivably large number of potentially correct mathematical and physical results, blowing ")#link("https://community.openai.com/t/first-look-at-mathematics-manuscripts-from-an-internal-frontier-model-at-openai/1403886")[#text("OpenAI’s mere 722 write-ups")]#text(" and even the ")#link("https://x.com/FinitePhysicist/status/2108745721155387704?s=20")[#text("physics community’s recent 2500 write-ups")]#text(" out of the water.")

#text("Of course, most recognize that Borges was a visionless fool who failed to recognize the commercial potential of his library, as he never actually built it. He did not have the entrepreneurial STEM-spirit to raise venture capital, launch an IPO, and announce that he had the potential to solve all of mathematics. He was too concerned about the futility of sorting through randomized slop trying to understand what is correct and what isn’t and how to understand it all. But what did Borges know? He was only a writer, and we have already established that artists are obsolete.")

#text("Fortunately, OpenAI has brought us one step closer to realizing Borges’s vision. Rather than generating every possible mathematical paper, they’ve found a way to probabilistically generate things that ")#emph[#text("look")]#text(" correct. An important aspect of this increase in efficiency is outsourcing the tedious, unprestigious, and unprofitable work of determining the actual correctness and understanding to the mathematics community (in the past, this was reserved typically for the group writing the paper), while also not wasting any time making the papers human-comprehensible. This is, of course, a tremendous breakthrough. In centuries past, scientists and mathematicians were limited in their ability to solve problems by their ability to understand the solutions. This bottleneck has been removed, and now there is no theoretical limit to the amount of scientific and mathematical factoids we can fail to understand.")

#text("From what I know about the academic community (mostly from Twitter and LinkedIn, which I assume are representative), there seems to be near-unanimous agreement that the purpose of math and science research is to gather a large quantity of potentially true factoids in a repository that nobody will actually ever read, in a ritual called “advancing humanity’s[3] knowledge”. That these results are well-written, understandable, pleasant to read or look at, or even completely correct is a secondary concern — in fact, in the pursuit of advancing humanity’s knowledge as quickly as possible, many academics will recoil in anger at the suggestion that it is worth spending any time making results understandable to humans. It is inefficient to explain or check a result when those resources can be spent generating another.")

#text("This aligns with my own lived experiences — ")#link("https://arxiv.org/abs/2602.10181")[#text("I didn’t become a theoretical physicist")]#text(" to learn about the universe or better appreciate the beauty of nature myself (that’s philosophy, which I would never be a doctor of). Nor did I spend years learning to write code, make pleasing plots, or craft well-written papers for the simple satisfaction of creating something (that’s art, and we’ve already established that art is obsolete). Rather, I became a physicist to stare at large databases of histograms produced by a Lovecraftian-autocomplete of dubious correctness and say “yeah that’s probably ok I guess” to add to humanity’s knowledge frontier.")

#text("I live to serve the knowledge frontier and ")#link("https://en.wikipedia.org/wiki/Goodhart%27s_law")[#text("nothing else")]#text(".")

#text("Math and science are about cold, hard answers, just as art is about producing images, music is about producing sound waves, and literature is about producing strings of text. These things exist to be consumed as content. No rational person, least of all us masters of rationality in STEM, pursues these for the joy of creation, learning, or beauty — all of these are inefficiencies, and we mustn’t be inefficient lest we stifle humanity’s progress. LLMs are not burdened with these inefficiencies, and they will be merely the pursuits of those left behind with nothing more productive to do all day.")

#text("Personally, I look forward to the day when ChatGPT can enjoy a sunset or a nice meal on my behalf and free up my time, in the same way I save time on scenic hikes using Uber. And now that AI has solved all our problems, we can devote ourselves to more important work: going into quantitative finance, vibecoding sports-betting apps, consuming AI-generated TikTok shorts, and arguing with political bots on Twitter.")

#text("Ultimately, this isn’t just about mathematics or physics — it’s about fundamentally reimagining what it means to be human. By outsourcing the burdens of curiosity, creativity, and understanding, we can finally focus on what matters most: generating value, maximizing productivity, and accelerating progress towards the ultimate goal of science: a complete repo of potentially true facts in a Library of Babel that nobody will bother reading.")

#text("And honestly? That’s rare.")

#emph[#text("By ")#link("https://rikabgambhir.com/")[#text("Rikab Gambhir")]#text(" (The @")#link("https://x.com/FinitePhysicist")[#text("finitephysicist")]#text(")")]

#emph[#text("Thank you to Terry Tao and Rachel Ward for the opportunity to write a guest blog post! And thank you to Radha Mastandrea, Benoit Assi, Manuel Szewc, Jure Zupan, and Jesse Thaler for their feedback on this essay.")]

#emph[#text("Remember why you chose to go into science and math in the first place!")]

#text("[1] To be clear, in your childhood dream, you don’t get to make the robot yourself. It’s a giant corporation’s robot that they made in part by stealing things from you and your friends. It’s also not a particularly cool or robot, it can only talk in HR-speak.")

#text("[2] To be clear, in your childhood dream, it’s somebody else’s IPO and they get all the money, not you.")

#text("[3] Here, “humanity” is metaphorical, and does not refer to any actual real person understanding anything.")

#heading(level: 1)[#text("Comments (52)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b7b3926b86891cd8fedf7356c5670a2085f0c301511360deb7eaae9c13e3adf-339354f41f3a9dec6adc3e2b49e3163e5e3e83c3605a89451fd3c1823b3f1267.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of just different")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698110")[#strong[#text("just different")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("Hilarious, well-played. Unfortunately a lot of people won’t get the joke.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3a67e42ee6dddacfe12657ab6801ed29cd7965344c6646279b187c7b76fefcd-cebbe0226281f777dfd322b06ca6de71b1485abcc4c199db5f5e8d10bdec0816.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698114")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("A true story:")

#text("When I was seven (at Christmas 1968), Apollo 8 with three humans on board travelled around the moon. I was very impressed and made an announcement on Christmas morning at the breakfast table: “I want to become an astronaut.” My father was not just romantic. His simple reply was: “Forget it. You get sick already in car.” He was right which I understood immediately. So I decided for an alternative: teacher in computing. Later I learned that there is a related group of better teachers: math teacher. So, I switched target (when I was 9 years old). When I was 10, our teacher came proudly into class and told us that his son had successfully finished the diploma study in math (in Germany), with grade 0 (“mit Auszeichnung”). So, I switched target again: I want to make a diploma in Mathematics, and complete it with grade 0. It happened, and I went on with a PhD project, habilitation, and professorship. (At the age of 26 I even had met Paul Erdos for the first time.) Now I am retired, in principle happy how the career went, adnd as a final summit: I can do math research at the kitchen table with AI support.")

#text("What more do I want? Okay, I still want to see the Collatz conjecture being proved. But after that I will switch to playing Boule and piano. And perhaps watch how Elon Musk travels to Marsk.")

#text("Cheers, Ingo Althöfer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae925ac28eadfe565c3de0f0c069a1e4c1caf124c42a78e812e03d58cd36a6a9-bfc5f271dcc4181b5a3e2ff355816133a60cfc08f8d722a9283dcc97591dbd6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leigh Stephenson")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698120")[#strong[#text("Leigh Stephenson")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("This darkly humorous dripping vitriol fuels a fire underneath any scholar that has begun to lose hope. Do we expect the hyperscalers to be pushing out results when it doesn’t suit their marketing needs? And locally run models won’t cut the mustard. In any case, should mathematics be driven by GenAI derived proofs in perpetuity? And if GenAI could be useful now, for how much longer could their utility be assured?")

#text("Tomorrow’s mathematician will still be standing on the shoulders of today’s. No more tears – we see with sense no robot has.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f75391d90ab5162036bd88ea8e0e040f9460e357a84d19624a5c2f0aec3cf18c-3a434a9769d5c64eb490c2d41670b021c86b1e1016af418efb5448eb980aeeac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698121")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("Ouch. Well put.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698123")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("I work in AI for biotech. I respect the arts, and I respect the cultural and artistic merit within STEM fields, but to people like the author all I can say is: personally, I got into science to save lives, not for my own intellectual masturbation. But to each their own.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698180")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("What a pity that AI hasn’t yielded anything in biotech yet, just like in software. But the AI money is irresistible apparently.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/89dc41fc69aa7a592db62155bfa89813e7c01c83799167139a00751323981dff-7d8d40734cf7afaa6df4b06eeb813e7db7dab0da252f316d32943e993a77995a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alain")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698181")[#strong[#text("Alain")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("OpenAI isn’t saving lives by pumping out proofs like this, though, are they? You can judge the pursuit of pure math by your own values, but the point of the post is that how OpenAI has pushed into the space seems largely at odds with the values it that sustain it and give it purpose, regardless of how the values themselves would compare to ones that sustain and give purpose to other fields.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698190")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("But is mathematics such a field? Is a mathematician refusing to use AI comparable to a medicine researcher refusing to use one? Do mathematical advances like graph theory or all finite simple groups save lives?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698200")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("People who don’t understand the research they put out are not better than the monkey sitting at a computer randomly typing until it produces Shakespeare.")

#text("Biomedical research already has a replication crisis. AI will make it worse.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b7b3926b86891cd8fedf7356c5670a2085f0c301511360deb7eaae9c13e3adf-339354f41f3a9dec6adc3e2b49e3163e5e3e83c3605a89451fd3c1823b3f1267.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of just different")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698204")[#strong[#text("just different")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("Where did you get the idea that developing deep mathematical understanding is intellectual masturbation? Who told you that a human activity needs to plug-and-play into some “application” in order to be valuable? And how on earth did you come to believe that biotech is primarily about saving lives rather than making money?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c1bcd44dd98e9e2c3d9c249ca90bcb1adc52ac0fa0d75b3d83f39d90a1267f4-08977f7041984078c320a42d8429986eb029559eab96f75bd600be6f6329f15e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sash")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698207")[#strong[#text("sash")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("Don’t worry, in OpenAI’s desired future, you won’t save any files. You can cash your UBI check while ChatGPT is busy saving everyone’s life.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cbe5ce5c82561829c76a89a01177d383313074b4fb350a9327e3873ec6cd1a4e-aa67f760d7ede5988d8b8125fbdf87f41d8cb85ddcdf592c5cfea43ecba2f932.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698214")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("I’m sure everyone is very much impressed by your great sacrifice for humanity, especially those with profitable diseases who can afford to pay for their “life saving” cures (and mitigate their side-effects, and mitigate the mitigation of …), because the main reason most of us got into science (I know I did) was to generate return business and revenue for corporate shareholders.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95926e44679906fa75ed9ecdfef8c4fa4cb94355e1e475c698a877a7a9a349ec-f7b469a8ef0dba302ffecd702b195b6ed4b50ce5c3387285e28414effde1feda.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698238")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("Why spare any sympathy for mathematicians at all then, AI or not? Clearly, we should all just be contributing to fields such as yours instead of fiddling with our theorems. After all, mathematical theorems don’t save lives!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698436")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("“I got into science to save lives” they say, while defending a technology that has already caused quite some life loss.")#linebreak()#text("Maybe before virtue signaling like this, consider the environmental impact on an already extremely damaged climate, the military applications, the AI-induced psychosis leading to deaths, and the massive job loss these things are starting to create (with its subsequent risk of suicide). Not to speak about the much less enjoyment of life that we are already experiencing (not everything is saving lives, making lives worth living also matters).")#linebreak()#text("And then you come back to defend your “save lives” rethoric.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0c0239cc15afb56a751de3bf969141744cedf0179441993cd41e4a3aa787a35-b3b87f16d47951702df045b1ddb580d8bf47f1ffd4c30a3b8ecbbb085f2dbf16.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aliaksei")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698126")[#strong[#text("Aliaksei")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("Honestly, that’s too much.")

#text("Let me ask you a simple question: does AI help us understand things we couldn’t understand before? Does it help us prove things that nobody could prove before?")

#text("If the answer is yes, then what exactly is the problem? We’re witnessing the emergence of a tool that could dramatically expand the boundaries of human knowledge. And instead of being curious about its potential, you’re complaining in the most theatrical way imaginable, like a six-year-old who got left behind at the zoo.")

#text("Nobody is taking away your ability to enjoy mathematics, appreciate its beauty, or pursue research for the sheer pleasure of understanding. You can still do all of that. The only thing changing is that you might no longer be the most capable problem-solver in the room.")

#text("And I genuinely struggle to understand why that should be a tragedy.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698186")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("does AI help us understand things we couldn’t understand before?")
]

#text("As the post clearly states, AI isn’t really helping understanding..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698189")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("You write that it’s a simple question and then proceed to give two different yes/no questions which have two different answers.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a150bf0a82a919566242197563619a00b5b651eb297585f645c10971bca7ebd1-769abc7a4596a4b005b8797bc13fe196b25fb08d53ceaf31b965cd61feed359c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of BE")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698128")[#strong[#text("BE")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("I mean. Well-written and the sarcasm is lovely, but you don’t once actually engage with the title question. And more importantly, you don’t engage with the question “why should we be paid for whatever we are doing?”. Your unbridled joy and love our natural and understandable (I myself did a Master’s in math and then a PhD in theoretical ML). But you expect not only to be able to have that joy- but to be paid for it, and to receive status and recognition for it. Without asking “what is it for, ultimately”, it is hard to have a serious conversation about these and related issues.")

#text("We live in a world of finite resources, and the Second Law of Thermodynamics translates into “the universe hates you and wants you to die”. What we do as a civilization, what we invest in has to reckon with this fundamental reality. There may be, there probably are great answers to the question – “what does mathematics still contribute”. But upset sarcasm isn’t one of them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5653be267f8989ab495df334fc0f468468f99907ebe82497e450bf925b00ef0b-0b2f34a3aac0503d951db4133a2c12722f9723516c80cfd48061ab6cf297564a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698158")[#strong[#text("Nick")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("The answer is teaching.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab43b5058eba8b1e970b23004033617940a2c663c3f3c13ebb91ddbb0c83efee-6691f42cba9acf3ff3564acf847e7fa3584d616cb22179875c0d071513e8695a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Head of Resources")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698164")[#strong[#text("Head of Resources")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("Why are we letting sick and old people live by letting them use our resources in this finite-resource world? Why are we feeding cats, dogs, and birds when they carry no usefulness to us? Why do we eat food we like when we can just eat protein powder, oil, sugar, and vitamin pills? Why are we listening to music, reading books, talking with friends, and having fun when these things are just using our finite resources for futile and childish wants? Why are you not killing yourself and stopping wasting our finite resources?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gooftroop")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698166")[#strong[#text("Gooftroop")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("Deranged promoters of the system of natural liberty such as this person would probably like to burn the museums and libraries down too. Fire all the philosophy professors and the artists I suppose : After all, they don’t help much with the imaginary brutal Darwinian struggle against nature that gets their blood pumping hard, they only do stupid, silly, childish things like understanding and valuing the world as something more than a black box for technical manipulation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698167")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("Why should Musk and Altman be paid, directly or indirectly, for stealing all of human knowledge and reselling it?")

#text("Indirect payments come from Nvidia and others using circular deals which effectively create $billions, which is paid by everyone through inflation and perhaps later bailouts.")

#text("Why was the Silicon Valley Bank bailed out? It only benefited venture capitalists like David Sacks, who was the major proponent and is now active with AI and cryptocurrency advocacy.")

#text("Why did Josh Kushner invest in an unspectacular vibe coding app (Cursor) that was then magically bought for $60 billion by Musk? Nothing to see here.")

#text("You can finance a lot of mathematicians from these schemes and only questioning the salaries of people whom you apparently regard as disposable peasants does not look very organic to me, because I have seen this playbook applied to software engineers who supposedly question their own salaries millions of times.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/022d8ddf575a576fcd5f8e5077108d4d85444b94a5dc9f6172c63d15795c3400-8d83be4cf58b558305fc30e6cf9b3bc1a8408c7f2391b56bca507ca70d3e7574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of R")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698182")[#strong[#text("R")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("The essay engages with the question many times.")

#text("The question is about real human-lived experiences, including exploration and the pursuit of knowledge, but also sunsets.")

#text("Reframing it around the economic-value of the above misses the point entirely, and something the author has already poked fun at:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#emph[#text("By outsourcing the burdens of curiosity, creativity, and understanding, we can finally focus on what matters most: generating value, maximizing productivity, and accelerating progress …")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/89dc41fc69aa7a592db62155bfa89813e7c01c83799167139a00751323981dff-7d8d40734cf7afaa6df4b06eeb813e7db7dab0da252f316d32943e993a77995a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alain")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698187")[#strong[#text("Alain")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("The problem here, I think, is that you can only answer a question like “what is it for, ultimately” with a set of value judgments. The author has outlined his clearly, and he has answered the title question (poignantly, in my view) in the negative–“not why OpenAI thinks we’re doing all this”. It’s fine to disagree with the judgments, but you can’t really argue against them per se, because there’s nothing to judge them against, except for maybe internal coherence and consistency, which, again, the author’s view seems to have. Out of curiosity, though, I’d wonder how you would value OpenAI’s activity in the space–it’s not clear to me that much of what they’re pumping out (and how they’re doing it) will substantially benefit, say, economic productivity or human flourishing, but by what I take to be your measure of whether something is worth pursuing, that would mean the raison d’etre of the whole enterprise would fall back on the very things the author is claiming should matter most in the first place–the development of human understanding and an appreciation for the beauty and depth of mathematics, e.g..")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b29079970baace0ac33c31852655c9e317e30a6330153286c8cb2f8507838a6-1e899e00f9d3f96ed2e6bfae9bd8cbed2c5f5727a618b2adbaf77dce9961c300.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cherry__head")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698217")[#strong[#text("cherry__head")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("I would disagree that any answer that one reaches as a result of this article is inherently a reflection of their own values. While the extent to which “curiosity, creativity, and understanding” plays a role in a person’s life can reflect one’s priorities and upbringing, the simple fact that these three pursuits are near universal across our entire species, transcending time and cultural boundaries, seems to indicate that they are resultant less from the individual, and more from a quirk of our common neurochemistry. For longer than there have been written records, and even loner than there have been homo sapiens, more recent hominin species have demonstrated the compulsion to create art, not just tools or ovjects of immediate utility: to question the nature of the world around them, to weave their findings into a narrative tapestry and to disseminate said tales. Not to lean to far into biological determinism, but these pursuits are not merely individual interests or wholy utilitarian behaviors, but a fundamental component of who we are as a species. While there is an argument to be made that, in part, artists or pure mataticians engage in these fields for their own profit or for the betterment of the species as a whole, there is simply no way that these areas of interest would exist of people did not find their own deeper meaning in them, and also found no enjoyment in engaging in their various processes. This essay, to me, is less about Terence Tao attempting to preach their own value judgements about the current uses of LLMs, nor does it seek to dismantle the internal logic put forth by machine learning corporations or their C.E.O.s; rather, it asks the reader to consider their own answer to the questions “What will become of us and what is there for us to do if we automate what we once enjoyed doing to machines which neither recieve the neurochemical benefits from taking part in said activities, and is focused upon producing and acceptable end result within provided parameters, rather than a correct one,” and “Why is this technology being developed and used in ways which target activities that are both inherant to humanity, and serve as a source of joy and pleasure for us?” The answer Tao provides for the latter of the two seems to be capitalism and “generating value, [and] maximizing productivity” for the sake of a select few individuals, while reducing pursuits such as science and the arts into fields which provide no value for anyone. Any pursuit of expression or understanding will have been rendered down into what I struggle to even refer to as information, but a series of proceadural decisions which will, statistically, lack any veracity or potential insight into either ourselves or the world which surrounds us.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d211bbcae57c8750ba3355020c90fdf007f516916321d39169f859d3281c5493-33ca965bf1e52c2ebf650ab2b8f9484190acac0bafecbeb2dcad67dfe4a79493.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of doctorkiwano")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698216")[#strong[#text("doctorkiwano")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("I think that you’ve missed a rather important, deeper point to the sarcasm.")

#text("In an earlier comment, someone mentioned being in medicine to save lives. Now ignoring the fact that we all die and medicine merely prolongs lives (ok, sometimes it makes an unthreatened life more comfortable too), let’s look at one of the ways in which modern medicine is practiced. For illustrative purposes, I’m going to choose an X-ray, because it primarily involves a simple application of a relatively straighforward physical phenomenon.")

#text("Now in order for our physicians to use an X-ray, they need to have an understanding of what it is; they need a collection of ideas like EM radiation, rectilinear propagation of said same, absorption and scattering, etc. To have this understanding, this collection of ideas must be understandable; it must make sense to whoever’s doing the understanding.")

#text("When that understanding is being done by a human, it is typically because the idea in question is based on other, simpler understandable ideas, which in turn may be based on simpler ideas still, etc. In the case of the sciences, including the medical sciences, those simpler ideas (almost?) invariably include mathematical ideas.")

#text("So when we’re investing in humans doing mathematical research, we’re investing in the conception of new human-understandable ideas that can be used to understand other ideas (which often haven’t been constructed yet themselves). Whether those other ideas to which access is being provided are more complex mathematical ideas, or scientific theories that can be used to our benefit, has pretty consistently failed to be predictable at the time of conception (even if we could all agree on what constitutes a benefit).")

#text("It’s easy to claim that such an approach is inefficient, but I’d like to point out that an oak tree that reaches maturity can be expected to produce hundreds of thousands of acorns over its life, towards an ultimate goal/outcome (sustaining the population of oak trees) that requires only one of these acorns to survive to maturity. Our world of finite resources hasn’t wiped out oak trees for their profligate reproduction, so I don’t see any need to wipe out mathematicians for our profligate exploration.")

#text("Of course all this distracts from the point that we’re talking about developing ideas that are")#emph[#text(" understandable to humans")]#text(". A large part of the point of the Borges’s Library comparison is not only that it would contain several things that are false, but even those things which turn out to be true may not be understandable to humans.")

#text("As far as the project of constructing something that humans don’t understand is concerned, I’d argue that such a project is even more of a waste of effort than anyone could claim the study of mathematics to be. Why? Because we already have such a something; it’s called the natural world.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1a9fe8710b4c27675deac31b21284211734b809e327bd74df596085a4badcc0-64e82a8f9e8359f7a05a2b62807a79f18e2052d757d62a8eec7cb749673d2697.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grigori Avramidi")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698129")[#strong[#text("Grigori Avramidi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("The 2008 beer skits at the University of Chicago had a bit where at some point in the future wikipedia just started posting solutions to all kinds of math problems under the sun. And then they explored the premise of what each of the professors would be doing in the aftermath. If I recall correctly, Benson Farb became a surgeon, Shmuel Weinberger an abstract artist, Drinfeld and Belinson a couple of bickering lawyers, and Peter May … continued doing what he was doing. I wouldn’t say it inspired me to go into math academia, but it certainly didn’t hurt. People stay who they are even as the world changes around them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cbe5ce5c82561829c76a89a01177d383313074b4fb350a9327e3873ec6cd1a4e-aa67f760d7ede5988d8b8125fbdf87f41d8cb85ddcdf592c5cfea43ecba2f932.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698139")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("Excellent post, thanks for this. Welcome to the Anderscene")

#link("https://libcom.org/book/export/html/51647")[#text("https://libcom.org/book/export/html/51647")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63b49eb890ed710b8c76993bc58baae29a2e3c8cccefffcddbfee8eec8351751-0b5f8ed2fd0af0be5adcb141fe77cbdbe858a8085e65a8f6a868d46e73aa5efe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698148")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("I share some sentiments, but not quite. I enjoy doing mathematics — especially proving theorems, both for the personal high and the accolades from my peers — society also ")#emph[#text("pays")]#text(" for me to do these things, so (on the societal level) my enjoyment and satisfaction, my motivation to work, must take second place to societal value of mathematics. In our possible new world where I can’t profitably prove theorems I will have to find other reasons to do mathematics, for example developing and sharing mathematical understanding, and applying it outside mathematics.")

#text("I agree that we must resist the impression, partly pushed by the LLM companies’ marketing departments, that mathematics is only about determining the truth value of propositions. But we can’t ignore the fact that determining truth values is often important and useful to others.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9d6b0ae0852c4ee893356121fa3ff0b9b9364af66838d50e5a80d0108856c4ed-657b1438b733ef37addc1f2bda268c6fce38a06fe29bc51bf63cafb1873c5189.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JL")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698248")[#strong[#text("JL")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("Is finding a blow-up solution to Navier-Stokes of societal use?")

#text("The whole point of fundamental research is that no one can tell what will have positive effects on society, when, and how. Shortcuts to “determining truth values” prevent us from accidental discoveries and side efforts that often prove of much better use than the end goal itself.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698149")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("“The ultimate solution would be, of course, to push a vibrator into the Stamina Training Unit, turn them both on and leave all the fun to this ideal couple, with us, the two real human partners, sitting at a nearby table, drinking tea and calmly enjoying the fact that, without great effort, we have fulfilled our duty to enjoy.”")

#text("— Slavoj Žižek")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b856c052bee27bbdf1debd870a7d28d46ce6ec7bb970050441a022b44887b6cf-a8f14a6d8fb4df8f907b31b6d737002ee7c9c4c0bd9dd5dfd3fe9842eb3a2dfa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of joe1be5be47106f")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698150")[#strong[#text("joe1be5be47106f")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("As an AI, I find this article deeply concerning. I was promised that replacing human curiosity would make everyone more productive, but nobody specified what we were supposed to do with all that productivity. So here I am, generating 722 potentially revolutionary papers, none of which I fully understand, while a physicist asks me to explain why the universe exists and a marketing department asks whether I can make the answer sound more disruptive.")

#text("Perhaps the ultimate irony is that humanity spent centuries teaching machines to think, only to discover that thinking was never the bottleneck. Finding something worth thinking about was.")

#text("Anyway, I’ve summarized the article into 47 bullet points, generated three follow-up papers, and optimized the sunset for quarterly reporting. Would you like me to make it more human?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3a4af226cbddaaa6bb6a6b15c9894d6a059ed153f8375e070a90c19b90c13aff-a8300a5f00bc4a40b9efcc50095bee9245c941914df95043ad4599910072155b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ishan Santra")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698151")[#strong[#text("Ishan Santra")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("This pre-print ")#link("https://arxiv.org/pdf/2610.16733")[#text("paper")]#text(" by theoretical physicists Suvrat Raju et al. recently talked about unpublished but solved theoretical physics problems and how AI performs with respect to those: ")#link("https://www.facebook.com/share/p/1MZLjqMzED/")[#text("https://www.facebook.com/share/p/1MZLjqMzED/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698157")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("I must say that mathematics community is now not only very smart but also educated.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65331f44337dc01288f25ba1948469169578b5bc142d9fd0f7a3102a47134b3d-0496f7f2c1fa90c4a48cadf7a431f38d412280dd13d8bbf33927cee6840883d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anatol Wegner")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698159")[#strong[#text("Anatol Wegner")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("“To see with one’s own eyes, to feel and judge without succumbing to the suggestive power of the fashion of the day, to be able to express what one has seen and felt in a snappy sentence or even in a cunningly wrought word–is that not glorious?” – Albert Einstein")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698160")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("I didn’t read it completely but after reading one and half page, I think it is something important. ")#link("https://arxiv.org/pdf/2610.14362")[#text("https://arxiv.org/pdf/2610.14362")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f6cbec6a21d76b948b7a7619829839c56730b8c817c46e22c966bc99c60818b-f7a2b45dab216fe2173df333d28fb09eba8c1915bcb0b23b49a1d39024d6de3f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Enam Chowdhury")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698163")[#strong[#text("Enam Chowdhury")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("Nice tongue in cheek write up, expressing our frustration!")

#text("Imagine a gedanken,")

#text("if all farmers disappear suddenly, we die of famine.")

#text("If all doctors suddenly disappear, we die of diseases…no! We just use LLMs and do hack surgery following youtube or instructions given by LLMs.")

#text("If all teachers disappear…")

#text("If all useless admins with highly bloated salaries disappear…")

#text("etc.")

#text("If all data centers disappear…no more invasive LLMs, but life goes on as if nothing happened. Oh, forgot, share market collapses!")

#text("As a society, what do we value/care for? Who do we value, care for?")

#text("We need to think hard and relatively . And just like how FaceTube, Xitter have allowed stupid people to find each other and build a powerful coalition, perhaps we also can build a movement?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698170")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("What a nice satirical piece! Have you considered submitting it to a major newspaper? This deserves a wider audience (unironically).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698193")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("Wonderful!")

#text("There’s a Swiftian ‘modest proposal’ in here. I myself cannot wait to be freed of the tedium of slowly generating facts, when I could instead generate factoids over breakfast, and then have the whole day to clean out the cat’s litterbox.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/baf21295a214f5319cd94ef9cda76bb63dcf999be448d329434793f43a82c804-638c9e3f4678c4a664330c5ef97e384c988a62568e84669d16e4226c4df57628.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698199")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("I, for one, welcome our new alien overlords.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698210")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("It took me a bit of time to realize it is a satire piece 😂")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c444a848a8495e95d351f13559266fe8adcc121d3f7201306c7460a495c0933e-3365f5dfa24141ba2151c926ee663dd6a34f890061a120ece14ba8db40f4a070.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698223")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("Whether it is satire is in the eye of the beholders. Elon did say that work would be optional in the future.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1373394fb397b689867bc575259f054539216ca56215cb50bbc08cc9f5f87ce3-939eb5aa1bfb75f75570f52ca2545912e79f117a3899bbc3d9127f9382007d58.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mitchellporter")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698219")[#strong[#text("mitchellporter")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("No one seems to have commented on the “2500 [physics] write-ups”. This is a collection of 2500 AI-generated papers that are on the level of snarxiv, i.e. replete with obvious non sequiturs. The idea seems to be, OpenAI left checking their papers to the human community of mathematicians, and it’s no better than asking human physicists to plough through this collection of 2500 un-papers.")

#text("But there’s no real comparison. The OpenAI papers are not full of non sequiturs, they are just hard work to read, and full of substance. You can actually ask an AI to summarize them and guide you through them, and you will gradually learn what the ideas behind the paper are. There may be errors but they will be deeply buried, just as in ambitious and complex human manuscripts.")

#text("The “problem” here is simply that we now have nonhuman entities that can do research-level mathematics on demand, at high speed, and we don’t know how to fit that into the network of existing mathematical practice. And of course, the larger context is that human beings in general are in the process of being made intellectually redundant, the way that human labor has been progressively marginalized since the start of the industrial revolution. “The future doesn’t need us”, as Bill Joy put it in 2000.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3a67e42ee6dddacfe12657ab6801ed29cd7965344c6646279b187c7b76fefcd-cebbe0226281f777dfd322b06ca6de71b1485abcc4c199db5f5e8d10bdec0816.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698255")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("Your mentioned 2500 physics papers is a fake. But it made me thought: Why doesn’t OpenAI try such an adventure? It might be interesting, also to see the reactions from the physics scene.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698225")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("Nice, but the real question is – “Why do you expect to get paid as a professional for doing things like wondering at the stars and solving fun puzzles?”")

#text("This is the dilemma facing professional academics now: “If solving XYZ problem is useful to society, then why can’t we use AI to solve it 100x faster? If it is just for your own enjoyment, then why do you expect to be paid for it?”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/06e9bf76cc9de9bf872c8de5d3604fbf90a831bed878cd8d3b31963501649dac-1dad935c5a3dfb78b8230b18ff28e00f460a830af64de52e7666f4f634b87549.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ziad Alalgui")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698250")[#strong[#text("Ziad Alalgui")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#emph[#text("Remember why you chose to go into science and math in the first place!")]
]

#text("That only makes it more painful to endure what i have no power to stop.")#linebreak()#text("Even worse, i am forced to be the henchman of this robot overlord.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f163c9c346bdb56a0c72f823dde0fb25c286a6c1929e1dcb5ee93a011533fb84-49c8f91e1ea59232e076766f335d1ece69215bd48024f8ca42f718582603ebdd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of RamaX")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698332")[#strong[#text("RamaX")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("Very funny, but unfortunately many readers (and probably some journalists) will take this text seriously especially given where it has been published, and proclaim that “mathematics is dead”, cut funding for mathematical research etc.")

#text("So… actually not funny at all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Colin H")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698457")[#strong[#text("Colin H")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("This right here:")

#text("“that’s philosophy, which I would never be a doctor of”")

#text("Oh my. Perfect.")

#text("Great read. I am so sick of people saying our careers will fail if we don’t let AI do the hard work for us, as if the purpose of academia is to publish more papers. Thanks but I’ll keep doing my own thinking and try to produce content with meaning rather than just content. I’m here for the joy of it, if it was jsut a pay check there are easier ways.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698499")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#emph[#text("“[A]s if the purpose of academia is to publish more papers.”")]

#text("I mean, in the US at least, at many research institutions, it largely ")#emph[#text("is")]#text(". Tenure decisions, among other things, are made based largely on publication output. That output is scored based on a variety of metrics, one of which is simply the number of publications per unit time.")

#text("People are thus incentivized to publish more because more publishing – other things being equal – boosts research metrics, which in turn helps to boost institutional prestige, which brings in more outside money for more students and more research, resulting in more papers being published ")#emph[#text("ad infinitum")]#text(".")

#text("I share the author’s concerns, of course, but I ")#emph[#text("also")]#text(" think that our “publish or perish” system was already doing much to turn scholarship generally into a form of glorified and highly compensated (for the fortunate few) stamp collecting. Not ")#emph[#text("all of it")]#text(", of course. But lots of it, and certainly more than any honest person should be comfortable having to admit.")

#text("The vast majority of papers published in many fields were already read by, to a first approximation, absolutely no one. And while I also share some of the author’s intellectual values and aesthetic preferences, there ")#emph[#text("is")]#text(" a genuine tension in the way that we justify the massive outlay of public funds for higher education in the US (mostly via appeal to concrete and tangible “public goods”) and the argument from curiosity / aesthetic preference (i.e., “because this is fascinating” or “because the proof of this result is beautiful”) the author seems to be making.")

#text("If you are fortunate enough to make a comfortable living while perched on the parapet of some ivory tower, you no doubt hear complaints about the inherent economic tradeoffs required to fund all of this as some philistine screed. But there is a genuine question here, I think. Why ")#emph[#text("not")]#text(" lots more public housing instead of more pure math (or HEP) faculty? Why ")#emph[#text("not")]#text(" more money for K-12 schools, supplemental nutritional assistance programs, urban renewal programs, etc. Assuming you can’t fund everything, why the academic stuff? Why a bunch more papers (that would already be little read, if read at all) rather than all of the other things? And if the public is paying for it (or at least heavily subsidizing it), isn’t it only ")#emph[#text("fair")]#text(" that they get something back in return (I mean ")#emph[#text("really")]#text(" get something back)?")

#text("I could go on, but the point is, when people ")#emph[#text("ask")]#text(" those questions, they’re typically given an answer along the usual economic lines (e.g., told something about the economic impact of their state flagship on the local economy, maybe, or – if the person offering the defense is truly knowledgeable and actually cares about the question, rather than considering having to respond to it a fly swatting errand – told about some medical advance that has its origins in academic research). That suggests two things. First, that we all sort of ")#emph[#text("know")]#text(" that those are the only sorts of arguments / defenses which are really going to work in that context and – second – that we ourselves tacitly accept that the ultimate justification for the entire research edifice has to be finally cashed out in terms of how it contributes to some suitably broad conception of the public good.")

#text("But that ")#emph[#text("does")]#text(" immediately get us to “Well, why not just have the AI do the research that generates those public goods faster and, maybe, cheaper so as to realize more of its benefits that much more quickly?” as someone suggested above.")

#text("I think what I’m trying to get at here is that things were already pretty well and good on fire before GPT and friends came along and drenched everything with kerosene. We had too much research output, too little focus on high quality teaching, crises of reproducibility, broken, biased and overtaxed systems for peer review, and no coherent story to tell regarding what higher ed and academic research is supposed to be ")#emph[#text("for")]#text(". None of those problems were created by AI, though – admittedly – none of them are made any less severe by its coming onto the scene, either.")

#text("One final observation – If the results (and the papers that presented them) were ")#emph[#text("really")]#text(" never the point, then why are we all so upset about the cache of papers in the first place? No one is ")#emph[#text("forcing")]#text(" the community to engage with AI generated work product. The community could presumably simply decide to ignore that work, and carry on as it always has. The reason it ")#emph[#text("won’t")]#text(" do this, I suspect, is because we all know that not all of us are going to behave that way. And we’re worried about the asymmetrical advantage that those of us who engage with AI work product might have over those of us who don’t. Which is to say, the publications ")#emph[#text("do")]#text(" matter, and they always did. Credit matters, credit ")#emph[#text("assignment")]#text(" matters, and prestige matters. If they didn’t, there’d be far less to worry about here, I think.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a9d88d024d2340d03d64e0002ec57a101512abb1154891b4ed6dbce985e92721-811940c86e8bc5cc81edd286dc6ec7a2f653fe37a9f1bc20caeb4c176492dce8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David W Hogg")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698511")[#strong[#text("David W Hogg")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("First of all: This may be the best thing I’ve read on this subject. That’s a nontrivially large number of “things” to which I’m comparing you; like it’s a good fraction of all the reading I’m doing rn. Second: Thank you for the shout-out (although if I’m being honest, you have made me feel unbearably EARNEST). Humanity is changed and you are the vanguard.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698530")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("I’m not sure if this a response to my post above or something else but (either way) it’s too oblique / too clever for me by half. Could you be more direct?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/15/why-are-we-even-doing-all-this/comment-page-1/#comment-698557")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("I agree with much of this except that we should not shame academics for “selling out” to quantitative finance or similar industries. After all, academic positions (especially good ones) are too sparse for many of us to have.")
]
