// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/
// Converted to Typst by tao2typ: "2026-10-14T07:10:53.159647+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245B, Notes 8: A quick review of point set topology", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245B, Notes 8: A quick review of point set topology")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 January 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/")[#text("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("To progress further in our study of function spaces, we will need to develop the standard theory of ")#link("http://en.wikipedia.org/wiki/Metric_space")[#text("metric spaces")]#text(", and of the closely related theory of ")#link("http://en.wikipedia.org/wiki/Topological_space")[#text("topological spaces")]#text(" (i.e. ")#link("http://en.wikipedia.org/wiki/Point-set_topology")[#text("point-set topology")]#text("). I will be assuming that students in my class will already have encountered these concepts in an undergraduate topology or real analysis course, but for sake of completeness I will briefly review the basics of both spaces here.")

#heading(level: 1)[#metadata(none) <tao-9c93aff64c6aef37348a>#text("— Metric spaces —")]

#text("In many spaces, one wants a notion of when two points in the space are “near” or “far”. A particularly quantitative and intuitive way to formalise this notion is via the concept of a metric space.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1.")]#text(" (Metric spaces) A ")#link("http://en.wikipedia.org/wiki/Metric_space")[#emph[#text("metric space")]]#text(" ")#mi("X = (X,d)")#text(" is a set X, together with a distance function ")#mi("d: X \\times X \\to {\\Bbb R}^+")#text(" which obeys the following properties:")

#enum(start: 1, 
[#text("(Non-degeneracy) For any ")#mi("x, y \\in X")#text(", we have ")#mi("d(x,y) \\geq 0")#text(", with equality if and only if x=y.")],
[#text("(Symmetry) For any ")#mi("x,y \\in X")#text(", we have ")#mi("d(x,y) = d(y,x)")#text(".")],
[#text("(Triangle inequality) For any ")#mi("x,y,z \\in X")#text(", we have ")#mi("d(x,z) \\leq d(x,y) + d(y,z)")#text(".")]
)
]

#strong[#text("Example 1. ")]#text("Every normed vector space ")#mi("(X, \\| \\|)")#text(" is a metric space, with distance function ")#tao-math("d(x,y) := \\left\\|x-y\\right\\|", block: false)#text(". ")#mi("\\diamond")

#strong[#text("Example 2.")]#text(" Any subset Y of a metric space ")#mi("X = (X,d)")#text(" is also a metric space ")#mi("Y = (Y, d\\downharpoonright_{Y \\times Y})")#text(", where ")#mi("d\\downharpoonright_{Y \\times Y}: Y \\times Y \\to {\\Bbb R}^+")#text(" is the restriction of d to ")#mi("Y \\times Y")#text(". We call the metric space ")#mi("Y = (Y, d\\downharpoonright_{Y \\times Y})")#text(" a ")#emph[#text("subspace")]#text(" of the metric space ")#mi("X = (X,d)")#text(". ")#mi("\\diamond")

#strong[#text("Example 3. ")]#text(" Given two metric spaces ")#mi("X = (X,d_X)")#text(" and ")#mi("Y = (Y,d_Y)")#text(", we can define the ")#emph[#link("http://en.wikipedia.org/wiki/Product_space")[#text("product space ")]]#mi("X \\times Y = (X \\times Y, d_X \\times d_Y)")#text(" to be the Cartesian product ")#mi("X \\times Y")#text(" with the product metric")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("d_X \\times d_Y( (x,y), (x^{\\prime},y^{\\prime}) ) := \\max( d_X( x,x^{\\prime}), d_Y(y,y^{\\prime} )).")]]

#text("(One can also pick slightly different metrics here, such as ")#mi("d_X(x,x^{\\prime}) + d_Y(y,y^{\\prime})")#text(", but this metric only differs from (1) by a factor of two, and so they are equivalent (see Example 5 below). ")#mi("\\diamond")

#strong[#text("Example 4.")]#text(" Any set X can be turned into a metric space by using the ")#emph[#link("http://en.wikipedia.org/wiki/Discrete_metric")[#text("discrete metric")]]#text(" ")#mi("d: X \\times X \\to {\\Bbb R}^+")#text(", defined by setting ")#mi("d(x,y) = 0")#text(" when ")#mi("x=y")#text(" and ")#mi("d(x,y)=1")#text(" otherwise. ")#mi("\\diamond")

#text("Given a metric space, one can then define various useful topological structures. There are two ways to do so. One is via the machinery of convergent sequences:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2.")]#text(" (Topology of a metric space) Let ")#mi("(X,d)")#text(" be a metric space.")

#enum(start: 1, 
[#text("A sequence ")#mi("x_n")#text(" of points in X is said to ")#link("http://en.wikipedia.org/wiki/Limit_of_a_sequence")[#emph[#text("converge")]]#text(" to a limit ")#mi("x \\in X")#text(" if one has ")#mi("d(x_n,x) \\to 0")#text(" as ")#mi("n \\to \\infty")#text(". In this case, we say that ")#mi("x_n \\to x")#text(" in the metric d as ")#mi("n \\to \\infty")#text(", and that ")#mi("\\lim_{n \\to \\infty} x_n = x")#text(" in the metric space X. (It is easy to see that any sequence of points in a metric space has at most one limit.)")],
[#text("A point x is an ")#emph[#link("http://en.wikipedia.org/wiki/Adherent_point")[#text("adherent point")]]#text(" of a set ")#mi("E \\subset X")#text(" if it is the limit of some sequence in E. (This is slightly different from being a ")#emph[#link("http://en.wikipedia.org/wiki/Limit_point")[#text("limit point")]]#text(" of E, which is equivalent to being an adherent point of ")#mi("E \\backslash \\{x\\}")#text("; every adherent point is either a limit point or an ")#emph[#link("http://en.wikipedia.org/wiki/Isolated_point")[#text("isolated point")]]#text(" of E.) The set of all adherent points of E is called the ")#emph[#link("http://en.wikipedia.org/wiki/Closure_(topology)")[#text("closure")]]#text(" ")#mi("\\overline{E}")#text(" of E. A set E is ")#emph[#link("http://en.wikipedia.org/wiki/Closure_(topology)")[#text("closed")]]#text(" if it contains all its adherent points, i.e. if ")#mi("E = \\overline{E}")#text(". A set E is ")#emph[#link("http://en.wikipedia.org/wiki/Dense_set")[#text("dense")]]#text(" if every point in X is adherent to E, or equivalently if ")#mi("\\overline{E} = X")#text(".")],
[#text("Given any x in X and ")#mi("r > 0")#text(", define the ")#emph[#link("http://en.wikipedia.org/wiki/Metric_ball#Balls_in_general_metric_spaces")[#text("open ball")]]#text(" ")#mi("B(x,r)")#text(" centred at x with radius r to be the set of all y in X such that ")#mi("d(x,y) < r")#text(". Given a set E, we say that x is an ")#emph[#link("http://en.wikipedia.org/wiki/Interior_point")[#text("interior point")]]#text(" of E if there is some open ball centred at x which is contained in E. The set of all interior points is called the ")#emph[#link("http://en.wikipedia.org/wiki/Interior_point")[#text("interior")]#text(" ")]#mi("E^\\circ")#text(" of E. A set is ")#emph[#link("http://en.wikipedia.org/wiki/Open_set")[#text("open")]]#text(" if every point is an interior point, i.e. if ")#mi("E = E^\\circ")#text(".")]
)
]

#text("There is however an alternate approach to defining these concepts, which takes the concept of an open set as a primitive, rather than the distance function, and defines other terms in terms of open sets. For instance:")

#strong[#text("Exercise 1.")]#text(" Let ")#mi("(X,d)")#text(" be a metric space.")

#enum(start: 1, 
[#text("Show that a sequence ")#mi("x_n")#text(" of points in X converges to a limit ")#mi("x \\in X")#text(" if and only if every ")#emph[#link("http://en.wikipedia.org/wiki/Open_neighborhood")[#text("open neighbourhood")]]#text(" of x (i.e. an open set containing x) contains ")#mi("x_n")#text(" for all sufficiently large n.")],
[#text("Show that a point x is an adherent point of a set E if and only if every open neighbourhood of x intersects E.")],
[#text("Show that a set E is closed if and only if its complement is open.")],
[#text("Show that the closure of a set E is the intersection of all the closed sets containing E.")],
[#text("Show that a set E is dense if and only if every non-empty open set intersects E.")],
[#text("Show that the interior of a set E is the union of all the open sets contained in E, and that x is an interior point of E if and only if some neighbourhood of x is contained in E. ")#mi("\\diamond")]
)

#text("In the next section we will adopt this “open sets first” perspective when defining topological spaces.")

#text("On the other hand, there are some other properties of subsets of a metric space which require the metric structure more fully, and cannot be defined purely in terms of open sets (see Example 14) below (although some of these concepts can still be defined using a structure intermediate to metric spaces and topological spaces, namely ")#link("http://en.wikipedia.org/wiki/Uniform_spaces")[#text("a uniform space")]#text("). For instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3.")]#text(" Let (X,d) be a metric space.")

#enum(start: 1, 
[#text("A sequence ")#mi("(x_n)_{n=1}^\\infty")#text(" of points in X is a ")#emph[#link("http://en.wikipedia.org/wiki/Cauchy_sequence")[#text("Cauchy sequence")]]#text(" if ")#mi("d(x_n,x_m) \\to 0")#text(" as ")#mi("n,m \\to \\infty")#text(" (i.e. for every ")#mi("\\varepsilon > 0")#text(" there exists ")#mi("N > 0")#text(" such that ")#mi("d(x_n,x_m) \\leq \\varepsilon")#text(" for all ")#mi("n,m \\geq N")#text(").")],
[#text("A space X is ")#emph[#link("http://en.wikipedia.org/wiki/Complete_metric_space")[#text("complete")]]#text(" if every Cauchy sequence is convergent.")],
[#text("A set E in X is ")#emph[#link("http://en.wikipedia.org/wiki/Bounded_set")[#text("bounded")]]#text(" if it is contained inside a ball.")],
[#text("A set E is ")#emph[#link("http://en.wikipedia.org/wiki/Total_boundedness")[#text("totally bounded")]]#text(" in X if for every ")#mi("\\varepsilon > 0")#text(", E can be covered by finitely many balls of radius ")#mi("\\varepsilon")#text(".")]
)
]

#strong[#text("Exercise 2.")]#text(" Show that any metric space ")#mi("X")#text(" can be identified with a dense subspace of a complete metric space ")#mi("\\overline{X}")#text(", known as a ")#emph[#link("http://en.wikipedia.org/wiki/Complete_metric_space#Completion")[#text("metric completion")]]#text(" or ")#emph[#text("Cauchy completion")]#text(" of X. (For instance, ")#mi("{\\Bbb R}")#text(" is a metric completion of ")#mi("{\\Bbb Q}")#text(".) (")#emph[#text("Hint")]#text(": one can define a real number to be an equivalence class of Cauchy sequences of rationals. Once the reals are defined, essentially the same construction works in arbitrary metric spaces.) Furthermore, if ")#mi("\\overline{X}^{\\prime}")#text(" is another metric completion of ")#mi("X")#text(", show that there exists an ")#link("http://en.wikipedia.org/wiki/Isometry")[#text("isometry")]#text(" between ")#mi("\\overline{X}")#text(" and ")#mi("\\overline{X}^{\\prime}")#text(" which is the identity on X. Thus, up to isometry, there is a unique metric completion to any metric space. ")#mi("\\diamond")

#strong[#text("Exercise 3.")]#text(" Show that a metric space X is complete if and only if it is closed in every superspace Y of X (i.e. in every metric space Y for which X is a subspace). Thus one can think of completeness as being the property of being “absolutely closed”. ")#mi("\\diamond")

#strong[#text("Exercise 4.")]#text(" Show that every totally bounded set is also bounded. Conversely, in a Euclidean space ")#mi("{\\Bbb R}^n")#text(" with the usual metric, show that every bounded set is totally bounded. But give an example of a set in a metric space which is bounded but not totally bounded. (Hint: use Example 4.) ")#mi("\\diamond")

#text("Now we come to an important concept.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" (")#link("http://en.wikipedia.org/wiki/Heine-Borel_theorem")[#text("Heine-Borel theorem")]#text(" for metric spaces) Let ")#mi("(X,d)")#text(" be a metric space. Then the following are equivalent:")

#enum(start: 1, 
[#text("(")#link("http://en.wikipedia.org/wiki/Sequentially_compact")[#text("Sequential compactness")]#text(") Every sequence in X has a convergent subsequence.")],
[#text("(")#link("http://en.wikipedia.org/wiki/Compact_space")[#text("Compactness")]#text(") Every open cover ")#mi("(V_\\alpha)_{\\alpha \\in A}")#text(" of X (i.e. a collection of open sets ")#mi("V_\\alpha")#text(" whose union contains X) has a finite subcover.")],
[#text("(")#link("http://en.wikipedia.org/wiki/Finite_intersection_property")[#text("Finite intersection property")]#text(") If ")#mi("(F_\\alpha)_{\\alpha \\in A}")#text(" is a collection of closed subsets of X such that any finite subcollection of sets has non-empty intersection, then the entire collection has non-empty intersection.")],
[#text("X is complete and totally bounded.")]
)
]

#strong[#text("Proof. ")]#text(" (2 ")#mi("\\implies")#text(" 1) If there was an infinite sequence ")#mi("x_n")#text(" with no convergent subsequence, then given any point x in X there must exist an open ball centred at x which contains ")#mi("x_n")#text(" for only finitely many n (since otherwise one could easily construct a subsequence of ")#mi("x_n")#text(" converging to x). By property 2, one can cover X with a finite number of such balls. But then the sequence ")#mi("x_n")#text(" would be finite, a contradiction.")

#text("(1 ")#mi("\\implies")#text(" 4) If X was not complete, then there would exist a Cauchy sequence which is not convergent; one easily shows that this sequence cannot have any convergent subsequences either, contradicting 1. If X was not totally bounded, then there exists ")#mi("\\varepsilon > 0")#text(" such that X cannot be covered by any finite collection of balls of radius ")#mi("\\varepsilon")#text("; a standard greedy algorithm argument then gives a sequence ")#mi("x_n")#text(" such that ")#mi("d(x_n,x_m) \\geq \\varepsilon")#text(" for all distinct n, m. This sequence clearly has no convergent subsequence, again a contradiction.")

#text("(2 ")#mi("\\iff")#text(" 3) This follows from ")#link("http://en.wikipedia.org/wiki/De_Morgan%27s_law")[#text("de Morgan’s laws")]#text(" and Exercise 1.3.")

#text("(4 ")#mi("\\implies")#text(" 3) Let ")#mi("(F_\\alpha)_{\\alpha \\in A}")#text(" be as in 3. Call a set E in X ")#emph[#text("rich")]#text(" if it intersects all of the ")#mi("F_\\alpha")#text(". Observe that if one could cover X by a finite number of non-rich sets, then (as each non-rich set is disjoint from at least one of the ")#mi("F_\\alpha")#text("), there would be a finite number of ")#mi("F_\\alpha")#text(" whose intersection is empty, a contradiction. Thus, whenever we cover X by finitely many sets, at least one of them must be rich.")

#text("As X is totally bounded, for each ")#mi("n \\geq 1")#text(" we can find a finite set ")#mi("x_{n,1},\\ldots,x_{n,m_n}")#text(" such that the balls ")#mi("B(x_{n,1},2^{-n}), \\ldots, B(x_{n,m_n},2^{-n})")#text(" cover X. By the previous discussion, we can then find ")#mi("1 \\leq i_n \\leq m_n")#text(" such that ")#mi("B(x_{n,i_n}, 2^{-n})")#text(" is rich.")

#text("Call a ball ")#mi("B(x_{n,i},2^{-n})")#text(" ")#emph[#text("asymptotically rich")]#text(" if it contains infinitely many of the ")#mi("x_{j,i_j}")#text(". As these balls cover X, we see that for each n, ")#mi("B(x_{n,i},2^{-n})")#text(" is asymptotically rich for at least one i. Furthermore, since each ball of radius ")#mi("2^{-n}")#text(" can be covered by balls of radius ")#mi("2^{-n-1}")#text(", we see that if ")#mi("B(x_{n,j},2^{-n})")#text(" is asymptotically rich, then it must intersect an asymptotically rich ball ")#mi("B(x_{n+1,j^{\\prime}},2^{-n-1})")#text(". Iterating this, we can find a sequence ")#mi("B(x_{n,j_n},2^{-n})")#text(" of asymptotically rich balls, each one of which intersects the next one. This implies that ")#mi("x_{n,j_n}")#text(" is a Cauchy sequence and hence (as X is assumed complete) converges to a limit x. Observe that there exist arbitrarily small rich balls that are arbitrarily close to x, and thus x is adherent to every ")#mi("F_\\alpha")#text("; since the ")#mi("F_\\alpha")#text(" are closed, we see that x lies in every ")#mi("F_\\alpha")#text(", and we are done. ")#mi("\\Box")

#strong[#text("Remark 1. ")]#text(" The hard implication ")#mi("4 \\implies 3")#text(" of the Heine-Borel theorem is noticeably more complicated than any of the others. This turns out to be unavoidable; the Heine-Borel theorem turns out to be logically equivalent to ")#link("http://en.wikipedia.org/wiki/K%C3%B6nig%27s_lemma")[#text("König’s lemma")]#text(" in the sense of ")#link("http://en.wikipedia.org/wiki/Reverse_mathematics")[#text("reverse mathematics")]#text(", and thus cannot be proven in sufficiently weak systems of logical reasoning. ")#mi("\\diamond")

#text("Any space that obeys one of the four equivalent properties in Lemma 1 is called a ")#emph[#text("compact space")]#text("; a subset E of a metric space X is said to be compact if it is a compact space when viewed as a subspace of X. There are some variants of the notion of compactness which are also of importance for us:")

#enum(start: 1, 
[#text("A space is ")#emph[#link("http://en.wikipedia.org/wiki/%CE%A3-compact_space")[#mi("\\sigma")#text("-compact")]]#text(" if it can be expressed as the countable union of compact sets. (For instance, the real line ")#mi("{\\Bbb R}")#text(" with the usual metric is ")#mi("\\sigma")#text("-compact.)")],
[#text("A space is ")#emph[#link("http://en.wikipedia.org/wiki/Locally_compact")[#text("locally compact")]]#text(" if every point is contained in the interior of a compact set. (For instance, ")#mi("{\\Bbb R}")#text(" is locally compact.)")],
[#text("A subset of a space is ")#emph[#text("precompact")]#text(" or ")#emph[#link("http://en.wikipedia.org/wiki/Relatively_compact")[#text("relatively compact")]]#text(" if it is contained inside a compact set (or equivalently, if its closure is compact).")]
)

#text("Another fundamental notion in the subject is that of a ")#emph[#text("continuous map")]#text(".")

#strong[#text("Exercise 5.")]#text(" Let ")#mi("f: X \\to Y")#text(" be a map from one metric space ")#mi("(X, d_X)")#text(" to another ")#mi("(Y,d_Y)")#text(". Then the following are equivalent:")

#enum(start: 1, 
[#text("(Metric continuity) For every ")#mi("x \\in X")#text(" and ")#mi("\\varepsilon > 0")#text(" there exists ")#mi("\\delta > 0")#text(" such that ")#mi("d_Y( f(x), f(x^{\\prime}) ) \\leq \\varepsilon")#text(" whenever ")#mi("d_X(x,x^{\\prime}) \\leq \\delta")#text(".")],
[#text("(Sequential continuity) For every sequence ")#mi("x_n \\in X")#text(" that converges to a limit ")#mi("x \\in X")#text(", ")#mi("f(x_n)")#text(" converges to f(x).")],
[#text("(Topological continuity) The inverse image ")#mi("f^{-1}(V)")#text(" of every open set V in Y, is an open set in X.")],
[#text("The inverse image ")#mi("f^{-1}(F)")#text(" of every closed set F in Y, is a closed set in X. ")#mi("\\diamond")]
)

#text("A function f obeying any one of the properties in Exercise 5 is known as a ")#emph[#text("continuous map")]#text(".")

#strong[#text("Exercise 6.")]#text(" Let ")#mi("X, Y, Z")#text(" be metric spaces, and let ")#mi("f: X \\to Y")#text(" and ")#mi("g: X \\to Z")#text(" be continuous maps. Show that the combined map ")#mi("f \\oplus g: X \\to Y \\times Z")#text(" defined by ")#mi("f\\oplus g(x) := (f(x), g(x))")#text(" is continuous if and only if f and g are continuous. Show also that the projection maps ")#mi("\\pi_Y: Y \\times Z \\to Y")#text(", ")#mi("\\pi_Z: Y \\times Z \\to Z")#text(" defined by ")#mi("\\pi_Y(y,z) := y")#text(", ")#mi("\\pi_Z(y,z) := z")#text(" are continuous. ")#mi("\\diamond")

#strong[#text("Exercise 7.")]#text(" Show that the image of a compact set under a continuous map is again compact. ")#mi("\\diamond")

#heading(level: 1)[#text("— Topological spaces —")]

#text("Metric spaces capture many of the notions of convergence and continuity that one commonly uses in real analysis, but there are several such notions (e.g. ")#link("http://en.wikipedia.org/wiki/Pointwise_convergence")[#text("pointwise convergence")]#text(", ")#link("http://en.wikipedia.org/wiki/Semi-continuity")[#text("semi-continuity")]#text(", or ")#link("http://en.wikipedia.org/wiki/Weak_convergence_(Hilbert_space)")[#text("weak convergence")]#text(") in the subject that turn out to not be modeled by metric spaces. A very useful framework to handle these more general modes of convergence and continuity is that of a ")#link("http://en.wikipedia.org/wiki/Topological_space")[#emph[#text("topological space")]]#text(", which one can think of as an abstract generalisation of a metric space in which the metric and balls are forgotten, and the open sets become the central object. [There are even more abstract notions, such as ")#emph[#link("http://en.wikipedia.org/wiki/Pointless_topology")[#text("pointless topological spaces")]]#text(", in which the collection of open sets has become an abstract ")#link("http://en.wikipedia.org/wiki/Lattice_(order)")[#text("lattice")]#text(", in the spirit of ")#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/")[#text("Notes 4")]#text(", but we will not need such notions in this course.]")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 4. ")]#text(" (Topological space) A topological space ")#mi("X = (X, {\\mathcal F})")#text(" is a set X, together with a collection ")#mi("{\\mathcal F}")#text(" of subsets of X, known as ")#emph[#text("open sets")]#text(", which obey the following axioms:")

#enum(start: 1, 
[#mi("\\emptyset")#text(" and X are open.")],
[#text("The intersection of any finite number of open sets is open.")],
[#text("The union of any arbitrary number of open sets is open.")]
)

#text("The collection ")#mi("{\\mathcal F}")#text(" is called a ")#emph[#text("topology")]#text(" on X.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Given two topologies ")#mi("{\\mathcal F}, {\\mathcal F}^{\\prime}")#text(" on a space X, we say that ")#mi("{\\mathcal F}")#text(" is a ")#emph[#text("coarser (or weaker) topology")]#text(" than ")#mi("{\\mathcal F}^{\\prime}")#text(" (or equivalently, that ")#mi("{\\mathcal F}^{\\prime}")#text(" is a ")#emph[#text("finer (or stronger) topology")]#text(" than ")#mi("{\\mathcal F}")#text("), if ")#mi("{\\mathcal F} \\subset {\\mathcal F}^{\\prime}")#text(" (informally, ")#mi("{\\mathcal F}^{\\prime}")#text(" has more open sets than ")#mi("{\\mathcal F}")#text(").")
]

#strong[#text("Example 5.")]#text(" Every metric space ")#mi("(X,d)")#text(" generates a topology ")#mi("{\\mathcal F}_d")#text(", namely the space of sets which are open with respect to the metric d. Observe that if two metrics d, d’ on X are ")#link("http://mathworld.wolfram.com/EquivalentMetrics.html")[#emph[#text("equivalent")]]#text(" in the sense that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("c d(x,y) \\leq d^{\\prime}(x,y) \\leq C d(x,y)")]]

#text("for all x, y in X and some constants ")#mi("c, C > 0")#text(", then they generate an identical topology. ")#mi("\\diamond")

#strong[#text("Example 6.")]#text(" The finest (or strongest) topology on any set X is the ")#emph[#link("http://en.wikipedia.org/wiki/Discrete_topology")[#text("discrete topology")]]#text(" ")#mi("2^X = \\{ E: E \\subset X\\}")#text(", in which every set is open; this is the topology generated by the discrete metric (Example 4). The coarsest (or weakest) topology is the ")#emph[#link("http://en.wikipedia.org/wiki/Trivial_topology")[#text("trivial topology")]]#text(" ")#mi("\\{ \\emptyset, X\\}")#text(", in which only the empty set and the full set are open. ")#mi("\\diamond")

#strong[#text("Example 7.")]#text(" Given any collection ")#mi("{\\mathcal A}")#text(" of sets of X, we can define the topology ")#mi("{\\mathcal F}[{\\mathcal A}]")#text(" generated by ")#mi("{\\mathcal A}")#text(" to be the intersection of all the topologies that contain ")#mi("{\\mathcal A}")#text("; this is easily seen to be the coarsest topology that makes all the sets in ")#mi("{\\mathcal A}")#text(" open. For instance, the topology generated by a metric space is the same as the topology generated by its open balls. ")#mi("\\diamond")

#strong[#text("Example 8.")]#text(" If ")#mi("(X,{\\mathcal F})")#text(" is a topological space, and Y is a subset of X, then we can define the ")#link("http://en.wikipedia.org/wiki/Subspace_topology")[#emph[#text("relative topology")]]#text(" ")#mi("{\\mathcal F}\\downharpoonright_Y := \\{ E \\cap Y: E \\in {\\mathcal F} \\}")#text(" to be the collection of all open sets in X, restricted to Y, this makes ")#mi("(Y, {\\mathcal F}\\downharpoonright_Y)")#text(" a topological space, known as a subspace of ")#mi("(X,{\\mathcal F})")#text(". ")#mi("\\diamond")

#text("Any notion in metric space theory which can be defined purely in terms of open sets, can now be defined for topological spaces. Thus for instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 5.")]#text(" Let ")#mi("(X,{\\mathcal F})")#text(" be a topological space.")

#enum(start: 1, 
[#text("A sequence ")#mi("x_n")#text(" of points in X ")#emph[#text("converges to a limit")]#text(" ")#mi("x \\in X")#text(" if and only if every ")#emph[#link("http://en.wikipedia.org/wiki/Open_neighborhood")[#text("open neighbourhood")]]#text(" of x (i.e. an open set containing x) contains ")#mi("x_n")#text(" for all sufficiently large n. In this case we write ")#mi("x_n \\to x")#text(" in the topological space ")#mi("(X,{\\mathcal F})")#text(", and (if x is unique) we write ")#mi("x = \\lim_{n \\to \\infty} x_n")#text(".")],
[#text("A point is a ")#emph[#text("sequentially adherent point")]#text(" of a set E if it is the limit of some sequence in E.")],
[#text("A point x is an ")#link("http://en.wikipedia.org/wiki/Adherent_point")[#emph[#text("adherent point")]]#text(" of a set E if and only if every open neighbourhood of x intersects E. The set of all adherent points of E is called the ")#link("http://en.wikipedia.org/wiki/Closure_(topology)")[#emph[#text("closure")]]#text(" of E and is denoted ")#mi("\\overline{E}")#text(".")],
[#text("A set E is ")#link("http://en.wikipedia.org/wiki/Closed_set")[#emph[#text("closed")]]#text(" if and only if its complement is open, or equivalently if it contains all its adherent points.")],
[#text("A set E is ")#link("http://en.wikipedia.org/wiki/Dense_set")[#emph[#text("dense")]]#text(" if and only if every non-empty open set intersects E, or equivalently if its closure is X.")],
[#text("The ")#link("http://en.wikipedia.org/wiki/Interior_(topology)")[#emph[#text("interior")]]#text(" of a set E is the union of all the open sets contained in E, and x is called an ")#link("http://en.wikipedia.org/wiki/Interior_point")[#emph[#text("interior point")]]#text(" of E if and only if some neighbourhood of x is contained in E.")],
[#text("A space X is ")#emph[#link("http://en.wikipedia.org/wiki/Sequentially_compact")[#text("sequentially compact")]]#text(" if every sequence has a convergent subsequence.")],
[#text("A space X is ")#link("http://en.wikipedia.org/wiki/Compact_space")[#emph[#text("compact")]]#text(" if every open cover has a finite subcover.")],
[#text("The concepts of being ")#link("http://en.wikipedia.org/wiki/%CE%A3-compact_space")[#emph[#mi("\\sigma")#text("-compact")]]#text(", ")#link("http://en.wikipedia.org/wiki/Locally_compact")[#emph[#text("locally compact")]]#text(", and ")#link("http://en.wikipedia.org/wiki/Relatively_compact")[#emph[#text("precompact")]]#text(" can be defined as before. (One could also define sequential ")#mi("\\sigma")#text("-compactness, etc., but these notions are rarely used.)")],
[#text("A map ")#mi("f: X \\to Y")#text(" between topological spaces is ")#emph[#link("http://en.wikipedia.org/wiki/Sequential_continuity")[#text("sequentially continuous")]]#text(" if whenever ")#mi("x_n")#text(" converges to a limit x in X, ")#mi("f(x_n)")#text(" converges to a limit f(x) in Y.")],
[#text("A map ")#mi("f: X \\to Y")#text(" between topological spaces is ")#emph[#link("http://en.wikipedia.org/wiki/Continuous_function_(topology)")[#text("continuous")]]#text(" if the inverse image of every open set is open. ")#mi("\\diamond")]
)
]

#strong[#text("Remark 2. ")]#text(" The stronger a topology becomes, the more open and closed sets it will have, but fewer sequences will converge, there are fewer (sequentially) adherent points and (sequentially) compact sets, closures become smaller, and interiors become larger. There will be more (sequentially) continuous functions on this space, but fewer (sequentially) continuous functions ")#emph[#text("into")]#text(" the space. Note also that the identity map from a space X with one topology ")#mi("{\\mathcal F}")#text(" to the same space X with a different topology ")#mi("{\\mathcal F}^{\\prime}")#text(" is continuous precisely when ")#mi("{\\mathcal F}")#text(" is stronger than ")#mi("{\\mathcal F}^{\\prime}")#text(". ")#mi("\\diamond")

#strong[#text("Example 9.")]#text(" In a metric space, these topological notions coincide with their metric counterparts, and sequential compactness and compactness are equivalent, as are sequential continuity and continuity. ")#mi("\\diamond")

#strong[#text("Exercise 7′.")]#text(" (Urysohn’s subsequence principle) Let ")#mi("x_n")#text(" be a sequence in a topological space X, and let x be another point in X. Show that the following are equivalent:")

#enum(start: 1, 
[#mi("x_n")#text(" converges to x.")],
[#text("Every subsequence of ")#mi("x_n")#text(" converges to x.")],
[#text("Every subsequence of ")#mi("x_n")#text(" has a further subsequence that converges to x. ")#mi("\\diamond")]
)

#strong[#text("Exercise 8.")]#text(" Show that every sequentially adherent point is an adherent point, every continuous function is sequentially continuous. ")#mi("\\diamond")

#strong[#text("Remark 3.")]#text(" The converses to Exercise 8 are unfortunately not always true in general topological spaces. For instance, if we endow an uncountable set X with the ")#link("http://en.wikipedia.org/wiki/Cocountable_topology")[#text("cocountable topology")]#text(" (so that a set is open if it is either empty, or its complement is at most countable) then we see that the only convergent sequences are those which are eventually constant. Thus, every subset of X contains its sequentially adherent points, and every function from X to another topological space is sequentially continuous, even though not every set in X is closed and not every function on X is continuous. An example of a set which is sequentially compact but not compact is the ")#link("http://en.wikipedia.org/wiki/First_uncountable_ordinal")[#text("first uncountable ordinal")]#text(" with the order topology (Exercise 9). It is more tricky to give an example of a compact space which is not sequentially compact; this will have to wait for future notes, when we establish ")#link("http://en.wikipedia.org/wiki/Tychonoff%27s_theorem")[#text("Tychonoff’s theorem")]#text(". However one can “fix” this discrepancy between the sequential and non-sequential concepts by replacing sequences with the more general notion of ")#link("http://en.wikipedia.org/wiki/Net_(topology)")[#text("nets")]#text(", see the appendix below. ")#mi("\\diamond")

#strong[#text("Remark 4.")]#text(" Metric space concepts such as boundedness, completeness, Cauchy sequences, and uniform continuity do not have counterparts for general topological spaces, because they cannot be defined purely in terms of open sets. (They can however be extended to some other types of spaces, such as ")#link("http://en.wikipedia.org/wiki/Uniform_space")[#text("uniform spaces")]#text(" or ")#link("http://en.wikipedia.org/wiki/Coarse_structure")[#text("coarse spaces")]#text(".) ")#mi("\\diamond")

#text("Now we give some important topologies that capture certain modes of convergence or continuity that are difficult or impossible to capture using metric spaces alone.")

#strong[#text("Example 10.")]#text(" (")#link("http://en.wikipedia.org/wiki/Zariski_topology")[#text("Zariski topology")]#text(") This topology is important in ")#link("http://en.wikipedia.org/wiki/Algebraic_geometry")[#text("algebraic geometry")]#text(", though it will not be used in this course. If F is an ")#link("http://en.wikipedia.org/wiki/Algebraically_closed_field")[#text("algebraically closed field")]#text(", we define the ")#emph[#text("Zariski topology")]#text(" on the vector space ")#mi("F^n")#text(" to be the topology generated by the complements of proper ")#link("http://en.wikipedia.org/wiki/Algebraic_variety")[#text("algebraic varieties")]#text(" in ")#mi("F^n")#text("; thus a set is ")#emph[#text("Zariski open")]#text(" if it is either empty, or is the complement of a finite union of proper algebraic varieties. A set in ")#mi("F^n")#text(" is then ")#emph[#text("Zariski dense")]#text(" if it is not contained in any proper subvariety, and the ")#emph[#text("Zariski closure")]#text(" of a set is the smallest algebraic variety that contains that set. ")#mi("\\diamond")

#strong[#text("Example 11. ")]#text(" (")#link("http://en.wikipedia.org/wiki/Order_topology")[#text("Order topology")]#text(") Any totally ordered set ")#mi("(X,<)")#text(" generates the ")#emph[#text("order topology")]#text(", defined as the topology generated by the sets ")#mi("\\{ x \\in X: x > a \\}")#text(" and ")#mi("\\{ x \\in X: x < a \\}")#text(" for all ")#mi("a \\in X")#text(". In particular, the ")#link("http://en.wikipedia.org/wiki/Extended_real_number_line")[#text("extended real line")]#text(" ")#mi("{}[-\\infty,+\\infty]")#text(" can be given the order topology, and the notion of convergence of sequences in this topology to either finite or infinite limits is identical to the notion one is accustomed to in undergraduate real analysis. (On the real line, of course, the order topology corresponds to the usual topology.) Also observe that a function ")#mi("n \\mapsto x_n")#text(" from the extended natural numbers ")#mi("{\\Bbb N} \\cup \\{+\\infty\\}")#text(" (with the order topology) into a topological space X is continuous if and only if ")#mi("x_n \\to x_{+\\infty}")#text(" as ")#mi("n \\to +\\infty")#text(", so one can interpret convergence of sequences as a special case of continuity. ")#mi("\\diamond")

#strong[#text("Exercise 9.")]#text(" Let ")#mi("\\omega")#text(" be the first uncountable ordinal, endowed with the order topology. Show that ")#mi("\\omega")#text(" is sequentially compact (")#emph[#text("Hint")]#text(": every sequence has a lim sup), but not compact (")#emph[#text("Hint: ")]#text("every point has a countable neighbourhood). ")#mi("\\diamond")

#strong[#text("Example 12.")]#text(" (")#link("http://en.wikipedia.org/wiki/Lower_limit_topology")[#text("Half-open topology")]#text(") The ")#emph[#text("right half-open topology")]#text(" ")#mi("{\\mathcal F}_r")#text(" on the real line ")#mi("{\\Bbb R}")#text(" is the topology generated by the right half-open intervals ")#mi("{}[a,b)")#text(" for ")#mi("-\\infty < a < b < \\infty")#text("; this is a bit finer than the usual topology on ")#mi("{\\Bbb R}")#text(". Observe that a sequence ")#mi("x_n")#text(" converges to a limit x in the right half-open topology if and only if it converges in the ordinary topology ")#mi("{\\mathcal F}")#text(", and also if ")#mi("x_n \\geq x")#text(" for all sufficiently large n. Observe that a map ")#mi("f: {\\Bbb R} \\to {\\Bbb R}")#text(" is")#link("http://en.wikipedia.org/wiki/Continuous_function#Directional_continuity")[#text(" right-continuous")]#text(" iff it is a continuous map from ")#mi("({\\Bbb R}, {\\mathcal F}_r)")#text(" to ")#mi("({\\Bbb R}, {\\mathcal F})")#text(". One can of course model left-continuity via a suitable left half-open topology in a similar fashion. ")#mi("\\diamond")

#strong[#text("Example 13.")]#text(" (")#link("http://en.wikipedia.org/wiki/Upper_topology")[#text("Upper topology")]#text(") The ")#emph[#text("upper topology")]#text(" ")#mi("{\\mathcal F}_u")#text(" on the real line is defined as the topology generated by the sets ")#mi("(a,+\\infty)")#text(" for all ")#mi("a \\in {\\Bbb R}")#text(". Observe that (somewhat confusingly), a function ")#mi("f: {\\Bbb R} \\to {\\Bbb R}")#text(" is ")#link("http://en.wikipedia.org/wiki/Lower_semi-continuous")[#text("lower semi-continuous")]#text(" iff it is continuous from ")#mi("({\\Bbb R}, {\\mathcal F})")#text(" to ")#mi("({\\Bbb R}, {\\mathcal F}_u)")#text(". One can of course model upper semi-continuity via a suitable lower topology in a similar fashion. ")#mi("\\diamond")

#strong[#text("Example 14.")]#text(" (")#link("http://en.wikipedia.org/wiki/Product_topology")[#text("Product topology")]#text(") Let ")#mi("Y^X")#text(" be the space of all functions ")#mi("f: X \\to Y")#text(" from a set X to a topological space Y. We define the ")#emph[#text("product topology")]#text(" on ")#mi("Y^X")#text(" to be the topology generated by the sets ")#mi("\\{ f \\in Y^X: f(x) \\in V \\}")#text(" for all ")#mi("x \\in X")#text(" and all open ")#mi("V \\subset Y")#text(". Observe that a sequence of functions ")#mi("f_n: X \\to Y")#text(" ")#link("http://en.wikipedia.org/wiki/Pointwise_convergence")[#text("converges pointwise")]#text(" to a limit ")#mi("f: X \\to Y")#text(" iff it converges in the product topology. We will study the product topology in more depth in future notes. ")#mi("\\diamond")

#strong[#text("Example 15.")]#text(" (Product topology, again) If ")#mi("(X,{\\mathcal F}_X)")#text(" and ")#mi("(Y, {\\mathcal F}_Y)")#text(" are two topological spaces, we can define the product space ")#mi("(X \\times Y, {\\mathcal F}_X \\times {\\mathcal F}_Y )")#text(" to be the Cartesian product ")#mi("X \\times Y")#text(" with the topology generated by the product sets ")#mi("U \\times V")#text(", where U and V are open in X and Y respectively. Observe that two functions ")#mi("f: Z \\to X")#text(", ")#mi("g: Z \\to Y")#text(" from a topological space Z are continuous if and only if the pairing ")#mi("(f,g): Z \\to X \\times Y")#text(" defined by $(f,g)(z) := (f(z),g(z))$ is continuous in the product topology, and also that the projection maps ")#mi("\\pi_X: X \\times Y \\to X")#text(" and ")#mi("\\pi_Y: X \\times Y \\to Y")#text(" are continuous (cf. Exercise 6). ")#mi("\\diamond")

#text("We mention that not every topological space can be generated from a metric (such topological spaces are called ")#link("http://en.wikipedia.org/wiki/Metrizable_space")[#text("metrisable")]#text("). One important obstruction to this arises from the Hausdorff property:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 6.")]#text(" A topological space X is said to be a ")#link("http://en.wikipedia.org/wiki/Hausdorff_space")[#text("Hausdorff space")]#text(" if for any two distinct points x, y in X, there exist disjoint neighbourhoods ")#mi("V_x, V_y")#text(" of x and y respectively.")
]

#strong[#text("Example 16. ")]#text("Every metric space is Hausdorff (one can use the open balls ")#mi("B( x, d(x,y)/2 )")#text(" and ")#mi("B( y, d(x,y)/2 )")#text(" as the separating neighbourhoods. On the other hand, the trivial topology (Example 7) on two or more points is not Hausdorff, and neither is the cocountable topology (Remark 3) on an uncountable set, or the upper topology (Example 13) on the real line. Thus, these topologies do not arise from a metric. ")#mi("\\diamond")

#strong[#text("Exercise 10.")]#text(" Show that the half-open topology (Example 12) is Hausdorff, but does not arise from a metric. [")#emph[#text("Hint")]#text(": assume for contradiction that the half-open topology did arise from a metric; then show that for every real number x there exists a rational number q and a positive integer n such that the ball of radius 1/n centred at q has infimum x.] Thus there are more obstructions to metrisability than just the Hausdorff property; a more complete answer is provided by ")#link("http://en.wikipedia.org/wiki/Metrizable")[#text("Urysohn’s metrisation theorem")]#text(", which we will cover in later notes. ")#mi("\\diamond")

#strong[#text("Exercise 11. ")]#text(" Show that in a Hausdorff space, any sequence can have at most one limit. (For a more precise statement, see Exercise 15 below.) ")#mi("\\diamond")

#text("A ")#emph[#link("http://en.wikipedia.org/wiki/Homeomorphism")[#text("homeomorphism")]]#text(" (or ")#emph[#text("topological ")#link("http://en.wikipedia.org/wiki/Isomorphism")[#text("isomorphism")]]#text(") between two topological spaces is a continuous invertible map ")#mi("f: X \\to Y")#text(" whose inverse ")#mi("f^{-1}: Y \\to X")#text(" is also continuous. Such a map identifies the topology on X with the topology on Y, and so any topological concept of X will be preserved by f to the corresponding topological concept of Y. For instance, X is compact if and only if Y is compact, X is Hausdorff if and only if Y is Hausdorff, x is adherent to E if and only if f(x) is adherent to f(E), and so forth. When there is a homeomorphism between two topological spaces, we say that X and Y are ")#emph[#text("homeomorphic")]#text(" (or ")#emph[#text("topologically isomorphic")]#text(").")

#strong[#text("Example 14.")]#text(" The tangent function is a homeomorphism between ")#mi("(-\\pi/2,\\pi/2)")#text(" and ")#mi("{\\Bbb R}")#text(" (with the usual topologies), and thus preserves all topological structures on these two spaces. Note however that the former space is bounded as a metric space while the latter is not, and the latter is complete while the former is not. Thus metric properties such as boundedness or completeness are not purely topological properties, since they are not preserved by homeomorphisms. ")#mi("\\diamond")

#heading(level: 1)[#text("— Nets (optional) —")]

#text("A sequence ")#mi("(x_n)_{n=1}^\\infty")#text(" in a space X can be viewed as a function from the natural numbers ")#mi("{\\Bbb N}")#text(" to X. We can generalise this concept as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 7.")]#text(" A ")#link("http://en.wikipedia.org/wiki/Net_(topology)")[#text("net")]#text(" in a space X is a tuple ")#mi("(x_\\alpha)_{\\alpha \\in A}")#text(", where ")#mi("A = (A,<)")#text(" is a ")#link("http://en.wikipedia.org/wiki/Net_(topology)")[#text("directed set")]#text(" (i.e. a pre-ordered set such that any two elements have at least one upper bound), and ")#mi("x_\\alpha \\in X")#text(" for each ")#mi("\\alpha \\in A")#text(". We say that a statement ")#mi("P(\\alpha)")#text(" ")#emph[#text("holds for sufficiently large")]#text(" ")#mi("\\alpha")#text(" in a directed set A if there exists ")#mi("\\beta \\in A")#text(" such that ")#mi("P(\\alpha)")#text(" holds for all ")#mi("\\alpha \\geq \\beta")#text(". [Note in particular that if ")#mi("P(\\alpha)")#text(" and ")#mi("Q(\\alpha)")#text(" separately hold for sufficiently large ")#mi("\\alpha")#text(", then their conjunction ")#mi("P(\\alpha) \\wedge Q(\\alpha)")#text(" also holds for sufficiently large ")#mi("\\alpha")#text(".]")

#text("A net ")#mi("(x_\\alpha)_{\\alpha \\in A}")#text(" in a topological space X is said to ")#emph[#text("converge")]#text(" to a limit ")#mi("x \\in X")#text(" if for every neighbourhood V of x, we have ")#mi("x_\\alpha \\in V")#text(" for all sufficiently large ")#mi("\\alpha")#text(".")

#text("A ")#emph[#text("subnet")]#text(" of a net ")#mi("(x_\\alpha)_{\\alpha \\in A}")#text(" is a tuple of the form ")#mi("(x_{\\phi(\\beta)})_{\\beta \\in B}")#text(", where ")#mi("(B, <)")#text(" is another directed set, and ")#mi("\\phi: B \\to A")#text(" is a monotone map (thus ")#mi("\\phi(\\beta^{\\prime}) \\geq \\phi(\\beta)")#text(" whenever ")#mi("\\beta^{\\prime} \\geq \\beta")#text(") which is also has ")#link("http://en.wikipedia.org/wiki/Cofinal_subset")[#text("cofinal")]#text(" image, which means that for any ")#mi("\\alpha \\in A")#text(" there exists ")#mi("\\beta \\in B")#text(" with ")#mi("\\phi(\\beta) \\geq \\alpha")#text(" (in particular, if ")#mi("P(\\alpha)")#text(" is true for sufficiently large ")#mi("\\alpha")#text(", then ")#mi("P(\\phi(\\beta))")#text(" is true for sufficiently large ")#mi("\\beta")#text(").")
]

#strong[#text("Remark 5.")]#text(" Every sequence is a net, but one can create nets that do not arise from sequences (in particular, one can take A to be uncountable). Note a subtlety in the definition of a subnet – we do not require ")#mi("\\phi")#text(" to be injective, so B can in fact be larger than A! Thus subnets differ a little bit from subsequences in that they “allow repetitions”. ")#mi("\\diamond")

#strong[#text("Remark 6.")]#text(" Given a directed set A, one can endow ")#mi("A \\cup \\{+\\infty\\}")#text(" with the topology generated by the singleton sets ")#mi("\\{\\alpha\\}")#text(" with ")#mi("\\alpha \\in A")#text(", together with the sets ")#mi("{}[\\alpha,+\\infty] := \\{ \\beta \\in A \\cup \\{+\\infty\\}: \\beta \\geq \\alpha \\}")#text(" for ")#mi("\\alpha \\in A")#text(", with the convention that ")#mi("+\\infty > \\alpha")#text(" for all ")#mi("\\alpha \\in A")#text(". The property of being directed is precisely saying that these sets form a ")#link("http://en.wikipedia.org/wiki/Base_(topology)")[#text("base")]#text(". A net ")#mi("(x_{\\alpha})_{\\alpha \\in A}")#text(" converges to a limit ")#mi("x_{+\\infty}")#text(" if and only if the function ")#mi("\\alpha \\mapsto x_{\\alpha}")#text(" is continuous on ")#mi("A \\cup \\{+\\infty\\}")#text(" (cf. Example 11). Also, if ")#mi("(x_{\\phi(\\beta)})_{\\beta \\in B}")#text(" is a subnet of ")#mi("(x_{\\alpha})_{\\alpha \\in A}")#text(", then ")#mi("\\phi")#text(" is a continuous map from ")#mi("B \\cup \\{+\\infty\\}")#text(" to ")#mi("A \\cup \\{+\\infty\\}")#text(", if we adopt the convention that ")#mi("\\phi(+\\infty) = +\\infty")#text(". In particular, a subnet of a convergent net remains convergent to the same limit. ")#mi("\\diamond")

#text("The point of working with nets instead of sequences is that one no longer needs to worry about the distinction between sequential and non-sequential concepts in topology, as the following exercises show:")

#strong[#text("Exercise 12.")]#text(" Let X be a topological space, let E be a subset of X, and let x be an element of X. Show that x is an adherent point of E if and only if there exists a net ")#mi("(x_\\alpha)_{\\alpha \\in A}")#text(" in E that converges to x. (")#emph[#text("Hint")]#text(": take A to be the directed set of neighbourhoods of x, ordered by reverse set inclusion.) ")#mi("\\diamond")

#strong[#text("Exercise 13.")]#text(" Let ")#mi("f: X \\to Y")#text(" be a map between two topological spaces. Show that f is continuous if and only if for every net ")#mi("(x_\\alpha)_{\\alpha \\in A}")#text(" in X that converges to a limit x, the net ")#mi("(f(x_\\alpha))_{\\alpha \\in A}")#text(" converges in Y to f(x). ")#mi("\\diamond")

#strong[#text("Exercise 14.")]#text(" Let X be a topological space. Show that X is compact if and only if every net has a convergent subnet. (")#emph[#text("Hint")]#text(": equate both properties of X with the ")#link("http://en.wikipedia.org/wiki/Finite_intersection_property")[#text("finite intersection property")]#text(", and review the proof of Theorem 1. Similarly, show that a subset E of X is relatively compact if and only if every net in E has a subnet that converges in X. (Note that as not every compact space is sequentially compact, this exercise shows that we cannot enforce injectivity of ")#mi("\\phi")#text(" in the definition of a subnet.) ")#mi("\\diamond")

#strong[#text("Exercise 15.")]#text(" Show that a space is Hausdorff if and only if every net has at most one limit. ")#mi("\\diamond")

#strong[#text("Exercise 16.")]#text(" In the product space ")#mi("Y^X")#text(" in Example 14, show that a net ")#mi("(f_\\alpha)_{\\alpha \\in A}")#text(" converges in ")#mi("Y^X")#text(" to ")#mi("f \\in Y^X")#text(" if and only if for every ")#mi("x \\in X")#text(", the net ")#mi("(f_\\alpha(x))_{\\alpha \\in A}")#text(" converges in Y to ")#mi("f(x)")#text(". ")#mi("\\diamond")

#text("[")#emph[#text("Update")]#text(", Jan 31: Definition of subnet corrected; Exercise 8 corrected; Exercise 9 added, subsequent exercises renumbered; hint for Exercise 2 altered; some remarks added.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (60)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04c4d58f9dbddf3307ef8d2df2e18a5d5fc0c0319b87bab57d68dc7e63d41112-68f771755b88688f32ccfd7789c1af26b64d1fd1a39007f71485f9fedb92b9d4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Franciscus Rebro")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-35352")[#strong[#text("Franciscus Rebro")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2009")])]

#text("Hi Terry,")

#text("In Definition 1 did you mean to write the Cartesian product X x X rather than that first right arrow?")

#text("Thanks for the notes!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/faaea4b7c5b04ead9c268663613ffcafa523cef7b85d370aaa07e69b3b4f55a2-b45439409ba81279ca30a7ebe5943c45a989379226691336f70e59356093ae5a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of johan")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-35357")[#strong[#text("johan")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2009")])]

#text("The definition of homeomorphism seems to have been cut short, not mentioning the continuity of the inverse.")

#text("There is a latex error in point 10 of definition 5. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jzahl")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-35369")[#strong[#text("jzahl")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2009")])]

#text("I believe exercise 8 is not correct; compact -> limit point compact, but not sequentially compact: there exist (non-metrizable, non-second-countable) compact spaces that are not sequentially compact. I don’t have an example, but my claim is backed up by Wikipedia: ")#link("http://en.wikipedia.org/wiki/Sequentially_compact_space")[#text("http://en.wikipedia.org/wiki/Sequentially_compact_space")]#text(" .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-35372")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2009")])]

#text("Dear jzahl: Ack, you’re right, of course; I had confused limit point compact with sequentially compact as you had guessed. (I also was misled by incorrectly thinking that a subnet of a sequence was the same thing as a subsequence.) I think I fixed these issues now.")

#text("Dear anonymous: Huh, that is an annoying technicality. Fortunately, I think I can resolve it by rewording the hint slightly. (Note that the way I have defined metric completion, it is not necessary for the completed space to be formed by equivalence classes of Cauchy sequences of the original space, even though this is the canonical way to construct such a completion.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-35371")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2009")])]

#text("This is admittedly pedantic, but your comments about ")#mi("{\\Bbb R}")#text(" arising as the metric completion of ")#mi("{\\Bbb Q}")#text(" are pedagogically correct but technically problematic. The definition of metric completion rests ultimately on the definition of that of the metric space itself, and the definition of metric space requires a function ")#mi("d: X \\times X \\to {\\Bbb R}^+")#text(". So since the definition of a metric space already presupposes that we have the (nonnegative) reals, you can’t use metric completion to “construct” ")#mi("{\\Bbb R}")#text(" from ")#mi("{\\Bbb Q}")#text(".")

#text("Of course, this is indeed the right way to think about what’s really going on with metric completion. How counterintuitive that the best way to explain this concept isn’t a proper example of metric completion, though…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c6547c98ff2a1c021e41f067b4863ea434c119a41e18c5af2ebd459c8121c27-1ee9894230e785e0398c1103dd321df8d107a69c98cf6336c5d7293bbaa65a64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K. P. Hart")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-35413")[#strong[#text("K. P. Hart")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2009")])]

#text("Re completions: one can always go the Bourbaki way and define R to be the completion of the uniform(!) space Q (See Chapter IV in the first book of Topologie Generale).")#linebreak()#text(" For jzahl: the Cech-Stone compactification of N is compact (hence limit-point compact, aka countably compact) by not sequentially compact.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3ad04e1ced21016b87f666e7ec164e56c2708dad17af723dc25b10a436a26d4-f0dc59139b53639bb39975118265aa1fa073a175964f544a2ff9618f3b8c1f65.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tusarepides")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-35435")[#strong[#text("Tusarepides")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2009")])]

#text("Some further exposition (mathematical/philosophical/pedagogical) about uniform spaces and structures would be greatly appreciated (i.e. beyond the wiki entry). Please give me a clue as to where you might have written about this before (something tells me that you have).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-35438")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2009")])]

#text("It’s 245B. ")#emph[#text("[Ack, not again – at any rate, corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-479128")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2017")])]

#text("The url still shows 254a-notes-8-a-quick-review-of-point-set-topology/")

#emph[#text("[The URL is unfortunately not editable – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-35509")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")])]

#text("There’s an error in the definition of interior point:")

#text("” Given a set E, we say that x is an interior pointinterior of E if … ” ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-35511")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")])]

#text("Another small point: for the proof of (1 \\Rightarrow 4) in Thm. 1 I dont think you need/have that d(x_{1},x_{n}) \\to \\infty. For example with the discrete metric on the integers. ")#emph[#text("[Ack, yes, I was only proving the weaker statement here that unbounded sets are not compact. This has been corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c6547c98ff2a1c021e41f067b4863ea434c119a41e18c5af2ebd459c8121c27-1ee9894230e785e0398c1103dd321df8d107a69c98cf6336c5d7293bbaa65a64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K. P. Hart")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-35517")[#strong[#text("K. P. Hart")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")])]

#text("For Tusarepides: yes, indeed, I wrote a short introduction to Uniform Spaces; you can find it ")#link("http://dutiaw37.twi.tudelft.nl/~kp/publications/the_papers/ency/e07-uniform-spaces-I.pdf")[#text(" here")]#text("; it appeared in the ")#link("http://www.elsevier.com/inca/publications/store/6/7/2/8/5/9/index.htt")[#text("Encyclopedia of General Topology")]#text(", which I co-edited. Hope it helps.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 10: Compactness in topological spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-35692")[#strong[#text("245B, Notes 10: Compactness in topological spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#text("[…] from Notes 8 that a topological space is Hausdorff if every distinct pair of points can be separated by two […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Announcement « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-35704")[#strong[#text("Announcement « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#text("[…] 14 of the Notes 8 of the course: Real Analysis:Let X be a topological space. Show that X is compact if and only if every net has a convergent […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 实分析0-10 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-35901")[#strong[#text("实分析0-10 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("[…] 第八节复习点集拓扑。我还算熟悉，基本上把精力都放在了ultrafilter出现的地方。，ultrafilter是我学到的一个很有趣的工具，以前写过一个介绍性的帖子。还应该提到的是“网”的概念。它是数列的一个加强版。以前常常会遇到，这回算是有了一个全面的了解了。值得注意的是，一个空间是紧致的等价于任意一个网都有收敛子网。这是区别于列紧性质的。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 11: The strong and weak topologies « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-36553")[#strong[#text("245B, Notes 11: The strong and weak topologies « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2009")])]

#text("[…] subsequence has a further subsequence that converges a.e. to zero, and use Exercise 7′ from Notes 8.) Thus almost everywhere convergence is not “topologisable” in general. Exercise 9 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 倡议 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-37501")[#strong[#text("倡议 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("[…] 14 of the Notes 8 of the course: Real Analysis:Let X be a topological space. Show that X is compact if and only if every net has a convergent […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aaed0abc7e358133c38f6cdbe201713e4f795ade6b5a9b50d90dc79fc437b7e6-169ed54092edba23e1076ef1642a3d9e616d91a4ba40bded81b3c34d5d4c29e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anush Tserunyan")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-41167")[#strong[#text("Anush Tserunyan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2009")])]

#text("Dear Prof. Tao,")

#text("Maybe I’m confusing something, but I think the requirement of monotonicity in the definition of subnet is too strong. With this definition I fail to show that compact implies every net has a convergent subnet. I show that in a compact space every net has a cluster point but I cannot imply that then there is a subnet converging to that cluster point. However, if we require only that for every \\alpha in A there is a \\beta_0 in B such that for all \\beta in B with \\beta \\geq \\beta_0, \\phi(\\beta) \\geq \\alpha, then everything is fine.")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-41172")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2009")])]

#text("I think one can recover monotonicity by taking B not to be the set of neighbourhoods of the cluster point, but instead to be the set of all finite collections of neighbourhoods of the cluster point, ordered by set inclusion. One can build ")#mi("\\phi")#text(" inductively to gain the monotonicity.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aaed0abc7e358133c38f6cdbe201713e4f795ade6b5a9b50d90dc79fc437b7e6-169ed54092edba23e1076ef1642a3d9e616d91a4ba40bded81b3c34d5d4c29e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anush Tserunyan")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-41174")[#strong[#text("Anush Tserunyan")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2009")])]

#text("Oh right! Thank you so much!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-42783")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2009")])]

#text("Dear Prof. Tao,")

#text("if we have a complete, seperable metric space, what can we say about its cardinality?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82e1b386e902885d97ea288c91542f3c6923379c3d093e709ff15775063b000b-94f7b243bec7ad017d8d84cf49ddd297bfe5b5f6046280fe8361a2385758bd0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kestutis Cesnavicius")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-45873")[#strong[#text("Kestutis Cesnavicius")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2010")])]

#text("Few typos:")

#text("1. In the first sentence of the proof of Theorem 1 “converging to n” should be “converging to x”.")#linebreak()#text(" 2. In definition 5.10 the last “in X” should be “in Y”.")#linebreak()#text(" 3. In the Remark 6 on the upper topology I think the equivalence between continuity in the upper topology and the convergence of the net does not hold in general. E.g., in Example 11 we had the order topology which is finer than the upper topology; I guess for the equivalence the order topology is needed here as well.")#linebreak()#text(" 4. In Exercise 16 ")#mi("f(\\alpha)")#text(" should be ")#mi("f(x)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-45881")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2010")])]

#text("Thanks for the corrections! Regarding point 3, I think the upper topology is the correct one to use here (note that there is no reason why a net ")#mi("\\alpha \\to x_\\alpha")#text(", convergent or otherwise, needs to be continuous with respect to the order topology).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82e1b386e902885d97ea288c91542f3c6923379c3d093e709ff15775063b000b-94f7b243bec7ad017d8d84cf49ddd297bfe5b5f6046280fe8361a2385758bd0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kestutis Cesnavicius")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-45882")[#strong[#text("Kestutis Cesnavicius")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2010")])]

#text("Maybe then for the equivalence one requires the continuity of ")#mi("\\alpha \\rightarrow x_{\\alpha}")#text(" at $\\infty$. I don’t see how one gets that the preimage of an open $U$ is open, if that $U$ happens to contain just one $x_{\\alpha}$ (and in particular, does not contain $x_{\\infty}$).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-45943")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2010")])]

#text("Ah, right. I intended the topology to be discrete away from infinity; I’ve modified the remark accordingly.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b219fc2824bda66eb306a3cea966ec4cdda1f2ebbd5a1d636e9b8deb14b92211-6b4cc5abca9dbf4dca4383ea131ac6f1dc5010e50e41f350be751a90348d070a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shawn")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-46119")[#strong[#text("Shawn")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2010")])]

#text("Hi!")

#text("I’m actually a bit confused about two things regarding subnets. Let’s take the example of \\delta_n(g) = g(n) (the linear operator on l_infty which evaluates g at the point n on N, the natural numbers). Now clearly ||\\delta_n||_* = 1 for all n and so there is a weak-* cluster point.")

#text("One can quickly see that there is no weakly convergent subsequence since if there were, we’d have g(n_k) -> F(g) and we can modify g as we wish on the points n_k.")

#text("By Banach Alaoglu, there is a weak-* convergent subnet. How do we construct such a subnet in this case? Why is it the case that if we have a convergent subnet that we can’t extract a convergent subsequence from that subnet? (ie. aren’t subnets ‘larger’ than subsequences in that they can be uncountable?)")

#text("Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-46120")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2010")])]

#text("To construct such a subnet requires the axiom of choice. For instance, one can select a non-principal ultrafilter p on the natural numbers, and then define ")#mi("\\lambda")#text(" to be the element of ")#mi("(\\ell^\\infty)^*")#text(" given by ")#mi("\\lambda(f) := \\lim_{n \\to p} f(n)")#text(" (or, if one wishes, ")#mi("\\lambda(f)")#text(" is the evaluation of the Stone-Cech extension of f at p). One can then obtain a subnet of the ")#mi("\\delta_n")#text(" converging to ")#mi("\\lambda")#text(" by taking the index set of the net to be the space of finite collections of constraints of the form ")#mi("n \\geq n_0")#text(" or ")#tao-math("\\left|f(n) - \\lambda(f)\\right| \\leq \\varepsilon", block: false)#text(" for various choices of natural number ")#mi("n_0")#text(", ")#mi("f \\in \\ell^\\infty")#text(", and ")#mi("\\varepsilon > 0")#text(". From the properties of a non-principal ultrafilter, any finite collection of such constraints is satisfiable for some n, and this then gives the desired subnet.")

#text("The reason why convergence of a subnet does not imply convergence of a subsequence is that the order structure on the subnet can be a lot sparser than the order structure on any associated subsequence, which makes convergence on the subnet a significantly weaker property. To converge on a subsequence, one must have stability on final segments of that subsequence, which is a significantly stronger condition than asking for stability on final segments of the subnet, because the pullback of a final segment from the subsequence to the subnet is a lot bigger than just one final segment of the subnet.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d8a0049a253560a8c5ec09985e3a16a5ba9efed2477e85e3506113fa985d689-6654c14eed8b5e451478326ac435779ba33f248bffa1eab63ff9f60c26bc735e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthias Hübner")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-522991")[#strong[#text("Matthias Hübner")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2019")])]

#text("Isn’t ")#mi("\\lambda")#text(" here in ")#mi("(\\ell^\\infty)^{\\prime}")#text(" i.e. in the dual of ")#mi("\\ell^\\infty")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b219fc2824bda66eb306a3cea966ec4cdda1f2ebbd5a1d636e9b8deb14b92211-6b4cc5abca9dbf4dca4383ea131ac6f1dc5010e50e41f350be751a90348d070a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shawn")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-46122")[#strong[#text("Shawn")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2010")])]

#text("Thanks! I need some time to digest all that.")#linebreak()#text(" It’s really amazing that you find the time to respond to your reader’s questions. It’s greatly appreciated!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d7d4a7358227aa4df0cc5cdf831892c910153180c4cc56d6e966ef9a8161bdef-1af4069f11670a89d2c550f598d57a77eb938edf4689939ea95275ed8889cbe4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guillermo Rey")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-184948")[#strong[#text("Guillermo Rey")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2012")])]

#text("I’ve been trying to find a historial reference for Exercise 7′ but I couldn’t find much on google that isn’t written by you with the name “Urysohn’s subsequence principle” and related things. Do you have any information on the history of this principle?")

#text("Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-184955")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2012")])]

#text("I believe the original reference is")

#text("P. Urysohn, Sur les classes L de M. Frechet, Enseignement Math. 25 (1926), 77-83.")

#text("although I do not currently have access to this article.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d7d4a7358227aa4df0cc5cdf831892c910153180c4cc56d6e966ef9a8161bdef-1af4069f11670a89d2c550f598d57a77eb938edf4689939ea95275ed8889cbe4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guillermo Rey")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-184956")[#strong[#text("Guillermo Rey")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2012")])]

#text("Thank you!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymousCoward")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-228445")[#strong[#text("anonymousCoward")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2013")])]

#text("Proof of Heine-Borel, in (!1 => !2) you didn’t close this parenthesis:")

#text("…(since otherwise one could easily construct…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-441390")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2014")])]

#text("In this wikipedia article ")#link("http://en.wikipedia.org/wiki/Directed_set")[#text("http://en.wikipedia.org/wiki/Directed_set")]#text(" (and also in Folland’s book), directed sets are defined as preordered set with the additional ”upper bound property”. In Definition 7 of this note, “partially ordered set” is used instead. Would this difference matter a lot?")

#emph[#text("[Not really, but pre-order is a slightly more convenient definition, and I’ve changed the notes to conform to this more common terminology. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-459797")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2015")])]

#text("In Douglas’s book ")#emph[#text("Banach Algebra Techniques in Operator Theory")]#text(", the author also uses “partially order” in the definition of directed sets. You said pre-order a “slightly more convenient” in the comment. Is it because one has one less axiom to check?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-459804")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2015")])]

#text("Yes, though more importantly, the deletion of that axiom allows the pullback ")#mi("\\phi^{-1}(Y)")#text(" of a directed set ")#mi("Y")#text(" by some surjective (or at least cofinal) map ")#mi("\\phi: X \\to Y")#text(" to remain directed even if ")#mi("\\phi")#text(" is not injective, which can be convenient for some purposes.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60f90e946d071c33ce8f0bb37273879d0794144101493a760f8a06b5648fc9b0-89bd3efac136e79204810f44695ab9bb609dcb6b3e49789e0ecc38656909c918.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jack")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-452564")[#strong[#text("jack")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2015")])]

#text("We have the word “generated” in topology and “span” in linear algebra. Given a vector space ")#mi("X")#text(" and a subset ")#mi("B")#text(" of ")#mi("X")#text(", the “span” of ")#mi("B")#text(" is a subspace of ")#mi("X")#text(", but ")#mi("B")#text(" is not necessarily a basis for span(B). On the other hand, given a set ")#mi("Y")#text(" and a family ")#mi("F")#text(" of subsets of ")#mi("Y")#text(" we always have ")#mi("F")#text(" as a basis for the “generated” topology ")#mi("\\mathscr{T}(F)")#text(" (generated by ")#mi("F")#text("). Why do we have such difference?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-452568")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2015")])]

#text("In general, ")#mi("F")#text(" is only a sub-base of ")#mi("{\\mathcal T}(F)")#text(", rather than a base. In the category of linear algebra, it is always possible (assuming the axiom of choice) to reduce a spanning set to a linearly independent set (and as such, the linear independence hypothesis is then included in the notion of a linear basis), but no such reduction is available in the topological category; the most useful reduction along these lines is to pass from a sub-base to a base (although this tends to make the base larger than then sub-base, rather than smaller).")

#text("Presumably a category-theoretic analysis of both the linear algebra category and the topological category would be able to pinpoint the difference here more precisely, but I am not an expert in these matters.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-452715")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2015")])]

#text("In the assumption of Exercise 13, if one adds the assumption that ")#mi("f")#text(" is a bijection, can one replace “continuous” with “a homeomorphism” in the statement?")

#emph[#text("[No; not all continuous bijections are homeomorphisms. It’s a good exercise to come up with a counterexample. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-479129")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2017")])]

#text("One should note that there are different versions of definitions for the concept “subnets”. And the one given in this post is “Willard subnet”, which implies the one (“Kelley subnet”) in Folland.")

#text("In practice of doing analysis, would such difference matter a lot? ")#emph[#text("[No, not really. See e.g. ")#link("http://thales.doa.fmph.uniba.sk/sleziak/texty/rozne/topo/subnets2.pdf")[#text("http://thales.doa.fmph.uniba.sk/sleziak/texty/rozne/topo/subnets2.pdf")]#text(" -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-485436")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2017")])]

#text("example 15 missing the direct sum notation (3 sentences from the end)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d8a0049a253560a8c5ec09985e3a16a5ba9efed2477e85e3506113fa985d689-6654c14eed8b5e451478326ac435779ba33f248bffa1eab63ff9f60c26bc735e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthias Hübner")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-512055")[#strong[#text("Matthias Hübner")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2019")])]

#text("In Example 12 (Half-open topology) it should be:")#linebreak()#text(" “for all sufficiently large $n$” ($n$ instead of $x$).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e3e10bf471189e7b9dad6311a00d8fee59d8448088d8a3657a7f76c94b1a631-27f7cd9fcb250764352c0d8d528545e2842fac20761c2b83ede82b451d866cb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bernhard")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-517319")[#strong[#text("Bernhard")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2019")])]

#text("I learned the theorem your call “Heine-Borel” as “Bolzano-Weierstrass”. Now, both seem wrong and correct in the sense that HB showed recoving compactness means bounded and closed (in R^n) and BW proved the equivalence of bounded and closed to sequential compactness. Maybe I will start calling it BBHW in future :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-530552")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2019")])]

#text("There seem to be typos in the first sentence of Example 11.")

#emph[#text("[Corrected – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-530553")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2019")])]

#text("What does the notation ")#mi("(X,a\\}")#text(" mean?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-530554")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2019")])]

#text("Also, in the following excerpt,")

#emph[#text("Also observe that a function ")#mi("n \\mapsto x_n")#text(" from the extended natural numbers ")#mi("{\\Bbb N} \\cup \\{+\\infty\\}")#text(" (with the order topology) into a topological space ")#mi("X")#text(" is continuous if and only if ")#mi("x_n \\to x_{+\\infty}")#text(" as ")#mi("n \\to \\infty")#text(", so one can interpret convergence of sequences as a special case of continuity.")#linebreak()#text(" ")]

#text("I think you meant to say as ")#mi("n \\to +\\infty")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-530715")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2019")])]

#text("Not sure if it is the problem of my chrome explorer or not.")

#text("I still see (literally) the following in the first sentence:")

#text("Any totally ordered set $(X, a \\}$ and $\\{ x \\in X: x < a \\}$ for all $a \\in X$.")

#text("Perhaps you meant for any totally ordered set ")#mi("X")#text(", the topology is generated by sets of the form ")#mi("\\{ x \\in X: x < a \\}")#text(" for all ")#mi("a \\in X")#text(".")

#emph[#text("[Should be fixed now – T.>]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-671488")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2023")])]

#text("What is the point/intuition of the introduced notions of “rich” and “asymptotically rich” sets in the proof of Theorem 1? Can the proof be written and simplified without these two notions?")

#emph[#text("[You are welcome to come up with your own arrangement of the proof; this is often an instructive exercise. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-672093")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2023")])]

#text("In Example 15, where continuity of functions from ")#mi("Z")#text(" to ")#mi("X\\times Y")#text(" is characterized, if one switches the directions of the maps, it does not work anymore: in general, it is not true that ")#mi("f: X\\times Y\\to Z")#text(" is continuous if and only if ")#mi("f(\\cdot, y): X\\to Z")#text(" is continuous for each ")#mi("y\\in Y")#text(" and ")#mi("f(x,\\cdot):Y\\to Z")#text(" is continuous for each ")#mi("x\\in X")#text(".")

#text("When tracing the proof, one thing that seems to be relevant for the contrast is that the inverse map ")#mi("g^{-1}")#text(" commutes with both union and intersections while the forward map ")#mi("g")#text(" does not commute with intersections.")

#text("Are there any “structural” reasons for this phenomenon?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-685982")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2024")])]

#text("Commenting on the length of the (iv) implies (iii) in Heine Borel theorem, you write that showing ")#linebreak()#text("(complete+bounded ")#mi("implies")#text(" finite intersection property) is logically equivalent to Konig’s lemma in the sense of reverse mathematics.")#linebreak()#strong[#text("What does reverse mathematics mean here?")]

#text("Also: I think Konig’s lemma refers to the existence of infinite rays in connected, locally finite graphs on a countably infinite vertex set. If this is correct, then I can see how the last part of the proof of the Heine-Borel theorem can be useful or relevant to prove Konig’s lemma.")

#text("PS: Another less useful question: is anything known about Heine-Borel actually proving their theorem for metric spaces?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-686016")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2024")])]

#text("The ")#link("https://en.wikipedia.org/wiki/Reverse_mathematics")[#text("Wikipedia page on reverse mathematics")]#text(" linked to in the notes is pretty comprehensive on this topic. (Strictly speaking, one should refer to the weak Konig lemma WKL_0 here, rather than the full Konig lemma, to get the reverse mathematics equivalence.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-690966")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2026")])]

#text("Dr Tao, In Def. 2.2, you mean the closure E bar of “E” not “X” right? ")#emph[#text("[Corrected, thanks – T.]")]

#text("Also, I know that the closure in this post refers to topological closure, but I vaguely feel that closures in other branches, such as Boolean closure, algebraically closed fields, seem to have certain connections with topological closure?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-691542")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2026")])]

#text("These notions of closure are not directly related to each other, but they are analogous. One way to formalize this analogy is through the language of category theory, where closure operators can be closely tied to ")#link("https://en.wikipedia.org/wiki/Adjoint_functors")[#text("adjunctions")]#text(", but this requires a certain amount of familiarity with category theory to fully appreciate.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-691877")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2026")])]

#text("Dear Dr Tao,")

#text("In def. 2.2 you said “The set of all adherent points of E is called the closure of E”, but when I check the wiki link and other blogs it seems like the adherent points are replaced by limit points. So which one is the correct definition? Intuitively what is the distinction between adherent points and limit points?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-691886")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2026")])]

#text("I am ")#link("https://gemini.google.com/share/3f00157813b5")[#text("outsourcing this question to an AI")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-691890")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2026")])]

#text("Dr. Tao:")

#text("When you outsourcing questions to an AI, do you actually check the AI response or just assuming AI would provide a good answer?")

#emph[#text("[I review the answer and post it if I believe it adequately answers the question. There are a number of AI-generated answers that I have eliminated for not meeting this criteria. -T]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-692600")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2026")])]

#text("In Example 10 you wrote that Zariski topology is important in algebraic geometry but it won’t be used in this course. I am wondering why you introduced a topology that won’t be used in this set of notes. Is it because it’s important not only in algebraic geometry but also in analysis? What structures do this topology capture?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-692606")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2026")])]

#text("I view education holistically; a given course should not narrowly restrict itself to a particular syllabus, but also give the student opportunities to connect the material (however loosely) to subjects outside of that syllabus.")

#text("In different areas of mathematics, we tend to impose various restrictions on the objects being studied. For instance, in analysis, we typically only study subsets of ambient Euclidean spaces (or affine spaces, projective spaces, etc.) if they are measurable (or obey various useful topological properties such being open, closed, connected, or compact, using the standard topology). In algebraic geometry, one tends to consider much narrower clases of sets, such as the ")#link("https://en.wikipedia.org/wiki/Definable_set")[#text("definable sets")]#text(" in the language of rings (or fields). When restricting attention to such sets, the Zariski topology is a much more natural topology to use; for instance, ")#link("https://en.wikipedia.org/wiki/Algebraic_variety")[#text("algebraic varieties")]#text(" become the closed sets in this topology, whilst the definable sets become the ")#link("https://en.wikipedia.org/wiki/Constructible_set_(topology)")[#text("constructible sets")]#text(".")

#text("It is possible to view both analysis and algebraic geometry in a somewhat unified fashion using the language of model theory, but this is even further beyond the scope of this course than the discussion in Example 10.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-692608")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2026")])]

#text("Dr Tao, I’m truly honored to receive a personal reply from you! Your response has given me the motivation to study algebraic geometry. The reason I asked this question is that I haven’t studied algebraic geometry, so I don’t understand why it is defined in terms of closed sets.")

#text("In analysis, such as real analysis, can the Zariski topology serve as some kind of inspiring or heuristic example to provide insights into the concepts of analysis?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/#comment-692609")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2026")])]

#text("For beginners to both subjects, I would not recommend trying to use one as a source of intuition for another. Most notably, the Zariski topology is not Hausdorff, whereas almost all the main topologies used in analysis are; and the Hausdorff property is used crucially in the latter subject in many places (for instance, to ensure that limits of sequences or nets are well defined). On the other hand, the notion of “Zariski open (generic)” in algebraic geometry does have many similarities with concepts such as “almost everywhere” or “outside of a set of the first category (a co-meager set)” in analysis.")

#text("These connections can be revisited once one has a firmer foundation in both topics.")
]
]
]
]
