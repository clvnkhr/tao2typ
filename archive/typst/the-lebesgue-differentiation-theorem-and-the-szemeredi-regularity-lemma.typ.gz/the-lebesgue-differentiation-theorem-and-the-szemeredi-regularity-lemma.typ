// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/
// Converted to Typst by tao2typ: "2026-10-14T15:16:25.047266+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Lebesgue differentiation theorem and the Szemeredi regularity lemma", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Lebesgue differentiation theorem and the Szemeredi regularity lemma")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 June 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/")[#text("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This post is a sequel of sorts to my ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("earlier post on hard and soft analysis, and the finite convergence principle")]#text(". Here, I want to discuss a well-known theorem in infinitary soft analysis – the ")#link("http://en.wikipedia.org/wiki/Lebesgue_differentiation_theorem")[#text("Lebesgue differentiation theorem")]#text(" – and whether there is any meaningful finitary version of this result. Along the way, it turns out that we will uncover a simple analogue of the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(", for subsets of the interval rather than for graphs. (Actually, regularity lemmas seem to appear in just about any context in which fine-scaled objects can be approximated by coarse-scaled ones.) The connection between regularity lemmas and results such as the Lebesgue differentiation theorem was recently highlighted ")#link("http://arxiv.org/abs/0705.2179")[#text("by Elek and Szegedy")]#text(", while the connection between the finite convergence principle and results such as the ")#link("http://en.wikipedia.org/wiki/Ergodic_theorem")[#text("pointwise ergodic theorem")]#text(" (which is a close cousin of the Lebesgue differentiation theorem) was recently detailed ")#link("http://arxiv.org/abs/0706.1512")[#text("by Avigad, Gerhardy, and Towsner")]#text(".")

#text("The Lebesgue differentiation theorem has many formulations, but we will avoid the strongest versions and just stick to the following model case for simplicity:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lebesgue differentiation theorem")]#text(". If ")#mi("f: [0,1] \\to [0,1]")#text(" is ")#link("http://en.wikipedia.org/wiki/Lebesgue_measurable")[#text("Lebesgue measurable")]#text(", then for ")#link("http://en.wikipedia.org/wiki/Almost_everywhere")[#text("almost every")]#text(" ")#mi("x \\in [0,1]")#text(" we have ")#mi("f(x) = \\lim_{r \\to 0} \\frac{1}{r} \\int_x^{x+r} f(y)\\ dy")#text(". Equivalently, the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_calculus")[#text("fundamental theorem of calculus")]#text(" ")#mi("f(x) = \\frac{d}{dy} \\int_0^y f(z) dz|_{y=x}")#text(" is true for almost every x in [0,1].")
]

#text("Here we use the oriented definite integral, thus ")#mi("\\int_x^y = - \\int_y^x")#text(". Specialising to the case where ")#mi("f = 1_A")#text(" is an ")#link("http://en.wikipedia.org/wiki/Indicator_function")[#text("indicator function")]#text(", we obtain the ")#link("http://en.wikipedia.org/wiki/Lebesgue%27s_density_theorem")[#text("Lebesgue density theorem")]#text(" as a corollary:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lebesgue density theorem")]#text(". Let ")#mi("A \\subset [0,1]")#text(" be Lebesgue measurable. Then for almost every ")#mi("x \\in A")#text(", we have ")#tao-math("\\frac{\\left|A \\cap [x-r,x+r]\\right|}{2r} \\to 1", block: false)#text(" as ")#mi("r \\to 0^+")#text(", where |A| denotes the Lebesgue measure of A.")
]

#text("In other words, almost all the points x of A are ")#emph[#text("points of density")]#text(" of A, which roughly speaking means that as one passes to finer and finer scales, the immediate vicinity of x becomes increasingly saturated with A. (Points of density are like robust versions of interior points, thus the Lebesgue density theorem is an assertion that measurable sets are almost like open sets. This is ")#link("http://en.wikipedia.org/wiki/Littlewood%27s_three_principles_of_real_analysis")[#text("Littlewood’s first principle")]#text(".) One can also deduce the Lebesgue differentiation theorem back from the Lebesgue density theorem by approximating f by a finite linear combination of indicator functions; we leave this as an exercise.")

#metadata(none) <tao-3c10d2b31244558a4a68>

#text("The Lebesgue differentiation and density theorems are ")#emph[#text("qualitative")]#text(" in nature: they assert that ")#mi("\\frac{1}{r} \\int_x^{x+r} f(y)\\ dy")#text(" ")#emph[#text("eventually")]#text(" gets close to f(x) for almost every x, or that A will ")#emph[#text("eventually")]#text(" occupy most of [x-r,x+r] for almost every x in A, by taking r small enough, but does not give a ")#emph[#text("quantitative")]#text(" bound for how small r has to be. The following simple example shows why there is a problem. Let n be a large integer, and partition [0,1] into ")#mi("2^n")#text(" ")#link("http://en.wikipedia.org/wiki/Interval_%28mathematics%29")[#text("dyadic intervals")]#text(" ")#mi("{}[0,1/2^n], [1/2^n,2/2^n], \\ldots, [1-1/2^n,1]")#text(" (never mind about the overlaps on the boundary, as they have zero measure, and the Lebesgue philosophy in analysis is to always ignore anything which happens on sets of measure zero). Let ")#mi("A_n")#text(" be the union of every other interval:")

#align(center)[#tao-fit-display[#mitex("A_n = [0,1/2^n] \\cup [2/2^n,3/2^n] \\cup \\ldots \\cup [1-2/2^n,1-1/2^n].")]]

#text("One then sees that if x is any element of ")#mi("A_n")#text(" which is not on the boundary, then it is indeed true that the local density ")#tao-math("\\frac{\\left|A_n \\cap [x-r,x+r]\\right|}{2r}", block: false)#text(" of ")#mi("A_n")#text(" will eventually converge to 1, but one has to wait until r is of size ")#mi("1/2^n")#text(" or smaller before one sees this; for scales much larger than this, the local density will remain stubbornly close to 1/2. A similar phenomenon holds for the indicator functions ")#mi("f_n := 1_{A_n}")#text(": the local average ")#mi("\\frac{1}{r} \\int_x^{x+r} f_n(y)\\ dy")#text(" will eventually get close to ")#mi("f_n(x)")#text(", which is either 0 or 1, but when ")#tao-math("\\left|r\\right| \\gg 1/2^n", block: false)#text(", these averages will also stay close to 1/2. (Closely related to this is the fact that the functions ")#mi("f_n")#text(" ")#link("http://en.wikipedia.org/wiki/Weak_convergence_%28Hilbert_space%29")[#text("converge weakly")]#text(" to 1/2, despite only taking values in {0,1}.)")

#text("Intuitively, what is going on here is that while each set ")#mi("A_n")#text(" is certainly Lebesgue measurable, these sets are getting increasingly “less measurable” as n gets large, and the rate of convergence in the Lebesgue differentiation and density theorems depends on how measurable the sets ")#mi("A_n")#text(" are. One can illustrate this by considering (non-rigorously) the limiting case ")#mi("n=\\infty")#text(" as follows. Suppose we select a random subset ")#mi("A_\\infty")#text(" of [0,1] by requiring each real number x in [0,1] to lie in ")#mi("A_\\infty")#text(" with an independent probability of 1/2 (thus we are flipping an uncountable number of coins to determine this set!). The ")#link("http://en.wikipedia.org/wiki/Law_of_large_numbers")[#text("law of large numbers")]#text(" (applied ")#emph[#text("very")]#text(" non-rigorously!) then suggests that with probability 1, ")#mi("A_\\infty")#text(" should have density 1/2 in every single interval I in [0,1], thus ")#tao-math("\\left|A_\\infty \\cap I\\right| = \\frac{1}{2} \\left|I\\right|", block: false)#text(". This would seem to violate the Lebesgue density theorem; but what is going on here is that the set ")#mi("A_\\infty")#text(" is in fact almost surely non-measurable (indeed, the Lebesgue density theorem provides a proof of this fact, modulo the issues of justifying several non-rigorous claims in this paragraph).")

#text("So, it seems that to proceed further we need to ")#emph[#text("quantify")]#text(" the notion of measurability, in order to decide which sets or functions are “more measurable” than others. There are several ways to make such a quantification. Here are some typical proposals:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition")]#text(". A set ")#mi("A \\subset [0,1]")#text(" is ")#mi("(\\epsilon,n)")#emph[#text("-measurable")]#text(" if there exists a set B which is the union of dyadic intervals ")#mi("{}[j/2^n, (j+1)/2^n]")#text(" at scale ")#mi("2^{-n}")#text(", such that A and B only differ on a set of Lebesgue measure (or ")#link("http://en.wikipedia.org/wiki/Outer_measure")[#text("outer measure")]#text(") ")#mi("\\epsilon")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition")]#text(". A function ")#mi("f: [0,1] \\to [0,1]")#text(" is ")#mi("(\\epsilon,n)")#emph[#text("-measurable ")]#text("if there exists a function g which is constant on the dyadic intervals ")#mi("{}[j/2^n, (j+1)/2^n]")#text(", which differs from f in ")#link("http://en.wikipedia.org/wiki/Lp_space")[#mi("L^1")#text("-norm")]#text(" by at most ")#mi("\\epsilon")#text(", thus ")#mi("\\int_0^1 |f(x)-g(x)|\\ dx \\leq \\epsilon")#text(".")
]

#text("(One can phrase these definitions using the ")#link("http://en.wikipedia.org/wiki/Sigma-algebra")[#mi("\\sigma")#text("-algebra")]#text(" generated by the dyadic intervals of length ")#mi("2^{-n}")#text("; we will not do so here, but these ")#mi("\\sigma")#text("-algebras are certainly underlying the ideas here. Their presence is particularly prominent in the “ergodic theory” approach to this circle of ideas, which we are not focusing on here.)")

#text("Then one can obtain the following quantitative results:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Quantitative Lebesgue differentiation theorem")]#text(". Let ")#mi("f: [0,1] \\to [0,1]")#text(" be ")#mi("(\\epsilon,n)")#text("-measurable. Then for all x in [0,1] outside of a set of measure ")#mi("O(\\sqrt{\\epsilon})")#text(" we have ")#mi("\\frac{1}{r} \\int_x^{x+r} f(y)\\ dy= f(x) + O(\\sqrt{\\epsilon})")#text(" for all ")#mi("0 < r < \\sqrt{\\epsilon} 2^{-n}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Quantitative Lebesgue density theorem")]#text(". Let ")#mi("A \\subset [0,1]")#text(" be ")#mi("(\\epsilon,n)")#text("-measurable. Then for all x in A outside of a set of measure ")#mi("O(\\sqrt{\\epsilon})")#text(" we have ")#tao-math("\\left|A \\cap [x-r,x+r]\\right| = (1 - O(\\sqrt{\\epsilon})) 2r", block: false)#text(" for all ")#mi("0 < r < \\sqrt{\\epsilon} 2^{-n}")#text(".")
]

#text("These results follow quickly from the ")#link("http://en.wikipedia.org/wiki/Hardy-Littlewood_maximal_function")[#text("Hardy-Littlewood maximal inequality")]#text(", and by exploiting the low “complexity” of the structured objects B and g which approximate A and f respectively; we omit the standard arguments.")

#text("To connect these quantitative results back to their qualitative counterparts, one needs to connect the quantitative notion of ")#mi("(\\epsilon,N)")#text("-measurability with the traditional qualitative notion of Lebesgue measurability. The relevant result that provides this connection is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lebesgue approximation theorem, first version")]#text(". Let ")#mi("A \\subset [0,1]")#text(" be measurable. Then for every ")#mi("\\epsilon > 0")#text(" there exists n such that A is ")#mi("(\\epsilon, n)")#text("-measurable.")

#strong[#text("Lebesgue approximation theorem, second version")]#text(". Let ")#mi("f: [0,1] \\to [0,1]")#text(" be measurable. Then for every ")#mi("\\epsilon > 0")#text(" there exists n such that f is ")#mi("(\\epsilon, n)")#text("-measurable.")
]

#text("These two results are easily seen to be equivalent. Let us quickly recall the proof of the first version:")

#strong[#text("Proof")]#text(". The claim is easily verified when A is the finite union of dyadic intervals, and then by monotone convergence one also verifies the claim when A is compact (or open). One then verifies that the claim is closed under countable unions, intersections, and complements, which then gives the claim for all ")#link("http://en.wikipedia.org/wiki/Borel_measure")[#text("Borel-measurable")]#text(" sets. The claim is also obviously true for null sets, and thus true for ")#link("http://en.wikipedia.org/wiki/Null_set")[#text("Lebesgue-measurable")]#text(" sets. ")#mi("\\Box")

#text("So, we’re done, right? Well, there is still an unsatisfactory issue: the Lebesgue approximation theorems guarantee, for any given ")#mi("\\epsilon")#text(", that a measurable set A or a measurable function f will eventually be ")#mi("(\\epsilon,n)")#text("-measurable by taking n large enough, but don’t give any bound as to what this n will be. In a sense, this is unavoidable, even if we consider “nice” objects such as compact sets A or piecewise constant functions f; the example of the set ")#mi("A_n")#text(" or the function ")#mi("f_n")#text(" discussed previously show that for fixed ")#mi("\\epsilon")#text(", one can be forced to take n to be arbitrarily large.")

#text("However, we can start looking for substitutes for these theorems which do have quantitative bounds. Let’s focus on the first version of the Lebesgue approximation theorem, and in particular in the case when A is compact. Then, we can write ")#mi("A = \\bigcap_{n=1}^\\infty A^{(n)}")#text(", where ")#mi("A^{(n)}")#text(" is the union of all the (closed) dyadic intervals which intersect A. The measures ")#tao-math("\\left|A^{(n)}\\right|", block: false)#text(" are a monotone decreasing sequence of numbers between 0 and 1, and thus (by the infinite convergence principle!) they have a limit, which (by the upper continuity of Lebesgue measure) is just ")#tao-math("\\left|A\\right|", block: false)#text(". Thus, for every ")#mi("\\epsilon > 0")#text(" we have ")#tao-math("\\left|A^{(n)}\\right| - \\left|A\\right| < \\epsilon", block: false)#text(" for all sufficiently large n, which explains why A is ")#mi("(\\epsilon,n)")#text("-measurable for all large n.")

#text("So now we see where the lack of a bound on n is coming from – it is the fact that the infinite convergence principle also does not provide an effective bound on the rate of convergence. But in the ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("previous posting on this topic")]#text(", we saw how the finite convergence theorem did provide an effective substitute for the infinite convergence principle. If we apply it directly to this sequence ")#tao-math("\\left|A^{(n)}\\right|", block: false)#text(", this is what we get:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Effective Lebesgue approximation theorem")]#text(". Let ")#mi("F: {\\Bbb N} \\to {\\Bbb N}")#text(" be any function, and let ")#mi("\\epsilon > 0")#text(". Then there exists an integer N with the following property: given any subset A of [0,1], there exists ")#mi("1 \\leq n \\leq N")#text(" such that ")#mi("A^{(n+F(n))}")#text(" is ")#mi("(\\epsilon, n)")#text("-measurable.")
]

#text("This theorem does give a specific upper bound on the scale n one has to reach in order to get quantitative measurability. The catch, though, is that the measurability is not attained for the original set A, but instead on some discretisation ")#mi("A^{(n+F(n))}")#text(" of A. However, we can make the scale at which we are forced to discretise to be arbitrarily finer than the scale at which we have the measurability.")

#text("Nevertheless, this theorem is still a little unsatisfying, because it did not directly say too much about the original set A. There is an alternate approach which gives a more interesting result. In the previous results, the goal was to try to approximate an arbitrary object (a set or a function) by a “structured” or “low-complexity” one (a finite union of intervals, or a piecewise constant function), thus trying to move away from “pseudorandom” or “high-complexity” objects (such as the sets ")#mi("A_n")#text(" and functions ")#mi("f_n")#text(" discussed earlier). Of course, the fact that these pseudorandom objects actually ")#emph[#text("exist")]#text(" is what is making this goal difficult to achieve satisfactorily. However, one can adopt a different philosophy, namely to embrace ")#emph[#text("both")]#text(" the structured ")#emph[#text("and")]#text(" the pseudorandom aspects of these objects, and focus instead on creating an efficient decomposition of arbitrary objects into the structured and pseudorandom components.")

#text("To do this, we need to understand what “pseudorandom” means. One clue is to look at the examples ")#mi("A_n")#text(" and ")#mi("f_n")#text(" discussed earlier. Observe that if one averages ")#mi("f_n")#text(" on any reasonable sized interval J, one gets something very close to the global average of ")#mi("f_n")#text(", i.e. 1/2. In other words, the integral of ")#mi("f_n")#text(" on an interval J is close to the global average of ")#mi("f_n")#text(" times ")#tao-math("\\left|J\\right|", block: false)#text(". (This is also true when J is a small interval, since in this case both expressions are small.) This motivates the following definition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition")]#text(". A function ")#mi("f: [0,1] \\to [0,1]")#text(" is said to be ")#mi("\\epsilon")#emph[#text("-regular")]#text(" on a dyadic interval I if we have ")#tao-math("\\left|\\int_J f(y)\\ dy - \\frac{\\left|J\\right|}{\\left|I\\right|} \\int_I f(y)\\ dy\\right| \\leq \\epsilon \\left|I\\right|", block: false)#text(" for all dyadic subintervals ")#mi("J \\subset I")#text(".")
]

#text("Thus, for instance, ")#mi("f_n")#text(" is ")#mi("2^{-n}")#text("-regular on [0,1]. We then have an analogue of the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(" for subsets of the interval, which I will dub the “Lebesgue regularity lemma”:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lebesgue regularity lemma")]#text(". If ")#mi("\\epsilon > 0")#text(" and ")#mi("f: [0,1] \\to [0,1]")#text(" is measurable, then there exists an positive integer ")#mi("n = O_\\epsilon(1)")#text(" (i.e. n is bounded by a quantity depending only on ")#mi("\\epsilon")#text("), such that f is ")#mi("\\epsilon")#text("-regular on all but at most ")#mi("\\epsilon 2^n")#text(" of the ")#mi("2^n")#text(" dyadic intervals of length ")#mi("2^{-n}")#text(".")
]

#strong[#text("Proof")]#text(". As with the proof of many other regularity lemmas, we shall rely primarily on the ")#emph[#text("energy increment argument")]#text(" (the ")#emph[#text("energy")]#text(" is also known as the ")#emph[#text("index")]#text(" in some literature). For minor notational reasons we will take ")#mi("\\epsilon")#text(" to be a negative power of 2. For each integer n, let ")#mi("f^{(n)}: [0,1] \\to [0,1]")#text(" be the conditional expectation of f to the dyadic intervals of length ")#mi("2^{-n}")#text(", thus on each such interval I, ")#mi("f^{(n)}")#text(" is equal to the constant value ")#mi("\\frac{1}{I} \\int_I f")#text(" (again, we are ignoring sets of measure zero). An easy application of ")#link("http://en.wikipedia.org/wiki/Pythagorean_theorem")[#text("Pythagoras’s theorem")]#text(" (for ")#mi("L^2([0,1])")#text(") shows that the ")#emph[#text("energies")]#text(" ")#tao-math("E_n := \\int_0^1 \\left|f^{(n)}(x)\\right|^2\\ dx", block: false)#text(" are an increasing sequence in n, and bounded between 0 and 1. Applying (a special case of) the finite convergence principle, we can find ")#mi("n = O_\\epsilon(1)")#text(" such that we have the energy ")#link("http://en.wikipedia.org/wiki/Metastability")[#text("metastability")]

#align(center)[#tao-fit-display[#mitex("E_{n+\\log_2 1/\\epsilon} - E_n \\leq \\epsilon^3.")]]

#text("(Indeed, we obtain a fairly civilised bound of ")#mi("n \\leq \\epsilon^3 \\log_2 1/\\epsilon")#text("). Applying Pythagoras’ theorem again, we conclude")

#align(center)[#tao-fit-display[#tao-math("\\int_0^1 \\left|f^{(n+\\log_2 1/\\epsilon)}(x) - f^{(n)}(x)\\right|^2 dx \\leq \\epsilon^3", block: true)]]

#text("which by ")#link("http://en.wikipedia.org/wiki/Markov%27s_inequality")[#text("Markov’s inequality")]#text(" implies that")

#align(center)[#tao-fit-display[#tao-math("\\int_I \\left|f^{(n+\\log_2 1/\\epsilon)}(x) - f^{(n)}(x)\\right|^2 dx \\leq \\epsilon^2 \\left|I\\right|", block: true)]]

#text("for all but ")#mi("\\epsilon 2^{n}")#text(" of the ")#mi("2^n")#text(" dyadic intervals I of length ")#mi("2^{-n}")#text(". The ")#link("http://en.wikipedia.org/wiki/Cauchy%E2%80%93Schwarz_inequality")[#text("Cauchy-Schwarz inequality")]#text(" then quickly shows that f is ")#mi("\\epsilon")#text("-regular on all of these intervals. ")#mi("\\Box")

#text("One can of course specialise the above lemma to indicator functions ")#mi("f = 1_A")#text(" to obtain a regularity lemma for subsets of the interval, whose formulation I will leave to the reader as an exercise.")

#text("An inspection of the proof shows that the full power of the finite convergence principle was not tapped here, because we only used it to get a metastability region of ")#mi("\\log_2 1/\\epsilon")#text(". One can get a stronger result (at the cost of worsening the bound on n) by extending this region of stability. To motivate this stronger version, first observe that if a function f is ")#mi("\\epsilon")#text("-regular on an interval I, then on that interval we have a decomposition f = c+h on I where ")#tao-math("c = \\frac{1}{\\left|I\\right|} \\int_I f(y) dy", block: false)#text(" is the mean of f on I (in particular, c is constant), and h has small averages in the sense that ")#tao-math("\\left|\\int_J h(y)\\ dy\\right| \\leq \\epsilon \\left|I\\right|", block: false)#text(" for all dyadic subintervals J of I. We can do better than this:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition")]#text(". A function ")#mi("f: [0,1] \\to [0,1]")#text(" is said to be ")#emph[#text("strongly")]#text(" ")#mi("(\\epsilon,m)")#emph[#text("-regular")]#text(" on a dyadic interval I if there exists a decomposition f=c+e+h on I, where ")#tao-math("c = \\frac{1}{\\left|I\\right|} \\int_I f(y) dy", block: false)#text(" is the mean of f on I, e is small in the sense that ")#tao-math("\\frac{1}{\\left|I\\right|} \\int_I |e(y)|\\ dy \\leq \\epsilon", block: false)#text(", and h has vanishing averages in the sense that ")#mi("\\int_J h(y) dy = 0")#text(" for all dyadic subintervals ")#mi("J \\subset I")#text(" with ")#tao-math("\\left|J\\right| \\geq 2^{-m} \\left|I\\right|", block: false)#text(".")
]

#text("Note that strong ")#mi("(\\epsilon,m)")#text("-regularity implies ")#mi("2\\epsilon")#text("-regularity as long as ")#mi("2^{-m} \\leq \\epsilon")#text(". Strong ")#mi("(\\epsilon,m)")#text("-regularity offers much better control on the fluctuation of f at finer scales, as long as the scale is not ")#emph[#text("too")]#text(" fine (this is where the parameter m comes in).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Strong Lebesgue regularity lemma")]#text(". If ")#mi("\\epsilon > 0")#text(", ")#mi("F: {\\Bbb N} \\to {\\Bbb N}")#text(", and ")#mi("f: [0,1] \\to [0,1]")#text(" is measurable, then there exists an positive integer ")#mi("n = O_{\\epsilon,F}(1)")#text(" such that f is ")#mi("(\\epsilon,F(n))")#text("-regular on all but at most ")#mi("\\epsilon 2^n")#text(" of the ")#mi("2^n")#text(" dyadic intervals of length ")#mi("2^{-n}")#text(".")
]

#text("The bound on n is rather poor, it is basically a ")#mi("1/\\epsilon^3")#text("-fold iteration of the function ")#mi("n \\mapsto n + F(n) \\log_2 1/\\epsilon")#text(" applied to 1, so for instance if one wanted F to be exponential in nature then n might be as large as a ")#link("http://en.wikipedia.org/wiki/Tetration")[#text("tower of exponentials")]#text(" of height ")#mi("1/\\epsilon^3")#text(" or so. (A very similar situation occurs for the Szemerédi regularity lemma, which has a variety of such strong versions, including one by ")#link("http://www.ams.org/mathscinet-getitem?mr=1804820")[#text("Alon-Fischer-Krivelevich-Szegedy")]#text(", one ")#link("http://www.informatik.hu-berlin.de/~schacht/pub/preprints/dense_reg1.pdf")[#text("by Rödl-Schacht")]#text(", and one ")#link("http://front.math.ucdavis.edu/math.CO/0504472")[#text("by myself")]#text(".)")

#text("We can now return to the Lebesgue differentiation theorem, and use the strong regularity lemma to obtain a more satisfactory quantitative version of that theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Quantitative Lebesgue differentiation theorem")]#text(". If ")#mi("\\epsilon > 0")#text(", ")#mi("F: {\\Bbb N} \\to {\\Bbb N}")#text(", and ")#mi("f: [0,1] \\to [0,1]")#text(" is measurable, then there exists an positive integer ")#mi("n = O_{\\epsilon,F}(1)")#text(" such that for all x in [0,1] outside of a set of measure ")#mi("O(\\epsilon)")#text(" we have the ")#link("http://en.wikipedia.org/wiki/Cauchy_sequence")[#text("Cauchy sequence property")]#text(" ")#tao-math("\\left|\\frac{1}{r} \\int_x^{x+r} f(y)\\ dy - \\frac{1}{s} \\int_x^{x+s} f(y)\\ dy\\right| \\leq \\epsilon", block: false)#text(" for all ")#mi("2^{-n-F(n)} < r, s < 2^{-n}")#text(".")
]

#text("This theorem can be deduced fairly easily by combining the strong regularity lemma with the Hardy-Littlewood maximal inequality (to deal with the errors e), and by covering (most of) the non-dyadic intervals [x,x+r] or [x,x+s] by dyadic intervals and using the boundedness of f to deal with the remainder. We leave the details as an exercise.")

#text("One sign that this is a true finitary analogue of the infinitary differentiation theorem is that this finitary theorem implies most of the infinitary theorem; namely, it shows that for any measurable f, and almost every x, the sequence ")#mi("\\frac{1}{r} \\int_x^{x+r} f(y)")#text(" is a Cauchy sequence as ")#mi("r \\to 0")#text(", although it does not show that the limit is equal to f(x). (Finitary statements can handle Cauchy sequences – which make sense even in the rationals – but have some trouble actually evaluating the limits of such sequences – which need the (infinite precision) real numbers and thus not truly finitary.) Conversely, using weak compactness methods one can deduce the quantitative differentiation theorem from the infinitary one, in much the same way that the finite and infinite convergence principles can be deduced from each other.")

#text("The strong Lebesgue regularity lemma can also be used to deduce the (one-dimensional case of the) ")#link("http://en.wikipedia.org/wiki/Rademacher%27s_theorem")[#text("Rademacher differentiation theorem")]#text(", namely that a ")#link("http://en.wikipedia.org/wiki/Lipschitz_continuity")[#text("Lipschitz continuous ")]#text("function from [0,1] to the reals is almost everywhere differentiable. To see this, suppose for contradiction that we could find a function g which was Lipschitz continuous but failed to be differentiable on a set of positive measure, thus for every x in this set, the (continuous) sequence ")#mi("\\frac{g(x+r)-g(x)}{r}")#text(" is not a Cauchy sequence as r goes to zero. We can normalise the Lipschitz constant of g to equal 1. Then by standard arguments we can find ")#mi("\\epsilon > 0")#text(" and a function ")#mi("F: {\\Bbb N} \\to {\\Bbb N}")#text(" such that for every x in a set of measure greater than ")#mi("\\epsilon")#text(", and every n, the sequence ")#mi("\\frac{g(x+r)-g(x)}{r}")#text(" fluctuates by at least ")#mi("\\epsilon")#text(" in the range ")#mi("2^{-n-F(n)} < r < 2^{-n}")#text(". Now let M be a very large integer (depending on ")#mi("\\epsilon")#text(" and F) and discretise g to scale ")#mi("2^{-M}")#text(" to create a piecewise linear approximant ")#mi("g_M")#text(", which is the antiderivative of a bounded function f which is constant on dyadic intervals of length ")#mi("2^{-M}")#text(". We apply the strong Lebesgue regularity lemma to f and find a scale ")#mi("n = O_{F,\\epsilon}(1)")#text(" for which the conclusion of that lemma holds; by choosing n large enough we can ensure that ")#mi("M \\geq n+F(n) \\geq n")#text(". It is then not hard to see that the lemma contradicts the previous assertion that ")#mi("\\frac{g(x+r)-g(x)}{r}")#text(" fluctuates for certain ranges of x and r.")

#text("In my next post I will talk about a new paper of mine using some of these ideas to establish a quantitative version of the Besicovitch projection theorem.")

#text("[")#emph[#text("Update")]#text(", June 19: Definition of strong regularity corrected.]")

#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/#comment-2458")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2007")]

#text("[…] The Lebesgue differentiation theorem and the Szemeredi regularity lemma This post is a sequel of sorts to my earlier post on hard and soft analysis, and the finite convergence principle. […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/#comment-2506")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2007")])]

#text("As I understand infinity [oo], reciprocity of limit theory allows this definition of infinity oo := 1/0.")

#text("Does reciprocity allow your arguments to be true for the interval [1,oo]?")

#text("This seems possible from my visual interpretation the illustration in the section ‘As a sphere’ of ‘Riemann sphere’ using 1 as the equator and 0,oo as the poles.")#linebreak()#text(" ")#link("http://en.wikipedia.org/wiki/Riemann_sphere")[#text("http://en.wikipedia.org/wiki/Riemann_sphere")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/#comment-2514")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2007")])]

#text("Dear Doug,")

#text("The map x -> 1/x from [0,1] to [1,\\infty] preserves the topological structure (such as limits), and in the case of the Riemann sphere, it also preserves the conformal structure (such as angles). But it does not preserve the measure or metric structure (there is a non-trivial Jacobian involved which distorts lengths and measures). So the results do not extend automatically.")

#text("Nevertheless, there are various analogues available in infinite-measure settings such as the real line, but one needs an additional decay hypothesis, for instance that the function f is absolutely integrable or that the set A has bounded measure. Also, instead of working with a decomposition into equally spaced intervals, it becomes more effective to work with unequally spaced intervals which are more adapted to where the function or set is distributed; in particular, the Calderon-Zygmund decomposition from harmonic analysis becomes very useful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A quantitative form of the Besicovitch projection theorem via multiscale analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/#comment-2527")[#strong[#text("A quantitative form of the Besicovitch projection theorem via multiscale analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2007")])]

#text("[…] the multiscale arguments used to establish various forms of the Lebesgue differentiation theorem in my previous post (in particular, the finite convergence principle, in the guise of pigeonholing in scales, plays an […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04f46819b994df538dd49762f260e79f7a82921ec4a697f6ad8d62b1997476b6-fd05cbb18a06fc83ead137c8cac5342ad18c1b2519ba0debf79fea195789e17b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeremy Avigad")]], [#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/#comment-2734")[#strong[#text("Jeremy Avigad")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2007")])]

#text("A theorem due to Steinhaus states that if A and B are subsets of the real line with positive Lebesgue measure, then the sumset A + B includes an interval.")

#text("Steinhaus originally stated the theorem in terms of distance sets, i.e. replacing B by -B. The article appeared in 1920 in the first volume of Fundamenta Mathematicae, and is available online:")

#link("http://matwbn.icm.edu.pl/spis.php?wyd=1")[#text("http://matwbn.icm.edu.pl/spis.php?wyd=1")]

#text("(To whet readers’ curiosity and encourage them to follow the link, I’ll note that 14 of the 24 papers in this first volume were written (or co-written, in one case) by a single person.)")

#text("Steinhaus’s theorem is not difficult to prove using the Lebesgue density theorem. But I first learned of it in a paper by Renling Jin, called “Sumset phenomenon” (Proceedings of the AMS, 2001; also available on Jin’s web page), where the result is obtained as an easy corollary of a theorem of nonstandard analysis. (Jin used his nonstandard result to show that if A and B are two subsets of the natural numbers with positive upper Banach density, then A + B is piecewise syndetic, and he has since gone on to make much more extensive use of nonstandard analysis in additive number theory.) Around that time, I developed a syntactic translation of nonstandard proofs to standard ones, and I decided to try it out on Jin’s proof of Steinhaus’s theorem.")

#text("With a little heuristic fiddling, I was able to find a constructively valid version of Steinhaus’s theorem, and a direct combinatorial proof. These are described on slides 9-13 of a short talk I gave a few years ago:")

#link("http://www.andrew.cmu.edu/user/avigad/Talks/dagstuhl.pdf")[#text("Click to access dagstuhl.pdf")]

#text("The argument follows a strategy mentioned in Tao’s post: the sets A and B are approximated from above by unions of the dyadic intervals that intersect them.")

#text("The translation for nonstandard arguments that I mentioned above is described in a paper called “Weak theories of nonstandard arithmetic and analysis,” and perhaps more perspicuously in Section 5.2 of a survey called “Forcing in proof theory,” both available on my web page. (It is also described on the slides at the link above.) Towsner and I have wondered whether the translation might provide a useful aid to “finitizing” methods of analysis. We are looking forward to following up on the topics that have been raised in this thread, as well as the paper by Elek and Szegedy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/#comment-2739")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2007")])]

#text("Dear Jeremy,")

#text("Thanks for your commentary and links. I think one can use the quantitative Lebesgue approximation theorem mentioned above to get a similarly quantitative version of Steinhaus’ theorem, which goes something like this: if A, B are measurable subsets of [0,1] of measure at least ")#mi("\\epsilon")#text(", and F is any function from the natural numbers to the natural numbers, then there exists a dyadic interval I in [0,2] of some length ")#mi("2^{-n}")#text(" such that A+B is “fills out I at scale ")#mi("2^{-n-F(n)}")#text("” in the sense that any dyadic subinterval J of I of length ")#mi("2^{-n-F(n)}")#text(" has non-empty intersection with A+B. Furthermore, one can get a uniform bound on n which depends only on ")#mi("\\epsilon")#text(" and F; these types of uniformity properties tend to be quite useful in applications (in particular, there are many applications of the Szemeredi regularity lemma which rely crucially on this type of uniform bound on the complexity), and seem to arise whenever the result one is finitising enjoys some sort of “weak compactness”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Non-measurable sets via non-standard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/#comment-33000")[#strong[#text("Non-measurable sets via non-standard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2008")])]

#text("[…] math.LO | Tags: Lebesgue density theorem, measurability, non-standard analysis | by Terence Tao Last year on this blog, I sketched out a non-rigorous probabilistic argument justifying the following well-known theorem: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 5: Differentiation theorems « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/#comment-47645")[#strong[#text("245A, Notes 5: Differentiation theorems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2010")])]

#text("[…] with a reasonable modulus of continuity, due to the increasingly oscillatory nature of . See this blog post for some further discussion of this issue, and what quantitative substitutes are available for such […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Asymptotic decay for a one-dimensional nonlinear wave equation « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/#comment-47974")[#strong[#text("Asymptotic decay for a one-dimensional nonlinear wave equation « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2010")])]

#text("[…] A compactness argument allows one to extract a quantitative estimate from this theorem (cf. this earlier blog post of mine) which, roughly speaking, tells us that there are large portions of the trajectory which behave […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5124054f77e9b690136b67b8f53c7b40f911c92c3ef844c3478db1fa1e59279c-8667361360d2e45fe75cc65e1ea76ab03b4956fe01ab7b44e8a2223a8d2cdf71.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jana Rodriguez Hertz")]], [#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/#comment-135379")[#strong[#text("Jana Rodriguez Hertz")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2012")])]

#text("Hi Terence,")

#text("what’s the exponent of \\varepsilon in the higher dimension version of the Quantitative Lebesgue density theorem? do you obtain the limit is 1-o(\\sqrt(\\varepsilon)) too? thank you, Jana")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5124054f77e9b690136b67b8f53c7b40f911c92c3ef844c3478db1fa1e59279c-8667361360d2e45fe75cc65e1ea76ab03b4956fe01ab7b44e8a2223a8d2cdf71.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jana Rodriguez Hertz")]], [#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/#comment-135380")[#strong[#text("Jana Rodriguez Hertz")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2012")])]

#text("sorry, I shouldn’t have said the limit. I’m interested in the dependence r(\\varepsilon) for higher dimension. that is, is there any information (perhaps adding hypothesis) on which r one has to take in order to obtain")#linebreak()#text(" |A \\cap B_r(x)|> 1-\\varepsilon |B_r(x)| ?")#linebreak()#text(" that’s it, sorry, and thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/#comment-506335")[#strong[#text("The Inscribed Square Problem | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2018")]

#text("[…] if has positive measure, then almost all points in have the density-1 property. Here is a nice comment on this from Terry Tao’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quantitative bounds for critically bounded solutions to the Navier-Stokes equations | What's new")]], [#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/#comment-519677")[#strong[#text("Quantitative bounds for critically bounded solutions to the Navier-Stokes equations | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2019")])]

#text("[…] of compactness by more complicated substitutes that give effective bounds; see for instance these previous blog posts for more discussion. I therefore was interested in trying to obtain a quantitative […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37f47cfb6fb19c5bb4b8296e04f78586af9cf04532d4a62569d53fbe4fed4748-7e255c6b999d815e584fae266dc3e13283967679af2bf6379d3b7a748b06e1b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bob")]], [#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/#comment-540124")[#strong[#text("Bob")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2020")])]

#text("Hi Terence,")#linebreak()#text(" when you claimed that we can deduce the Lebesgue differentiation theorem back from the Lebesgue density theorem by approximating ")#mi("f")#text(" by a finite linear combination of indicator functions, say ")#mi("g")#text(", did you plan to use a weak-(1,1) estimate for the maximal function raising from ")#tao-math("\\frac{\\left|I\\right|}{\\int_I \\left|f-g\\right|}", block: false)#text("? I’m asking since I’m wondering if this claim holds true also in the generalized context of complete separable metric spaces equipped with a probability measure, where in general we can’t rely on Besicovitch covering theorem to get the weak-(1,1) estimate…")

#text("Thanks,")

#text("Bob")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37f47cfb6fb19c5bb4b8296e04f78586af9cf04532d4a62569d53fbe4fed4748-7e255c6b999d815e584fae266dc3e13283967679af2bf6379d3b7a748b06e1b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bob")]], [#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/#comment-540127")[#strong[#text("Bob")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2020")])]

#text("I found in the literature that density theorem is equivalent to weak Vitaly property while the differentiation theorem is equivalent to strong Vitaly property and that there exists a complete separable metric space and a finite Borel measure where the weak property holds while the strong doesn’t… so, to answer my own question: in the context of complete separable metric spaces the equivalence between density theorem and differentiation theorem doesn’t hold true.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/#comment-626331")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2021")])]

#text("In the last two displayed equations of the proof of the Lebesgue regularity lemma, the left absolute value bar and the integral sign should be swapped.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/#comment-691704")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2026")])]

#text("Dr Tao,")

#text("I think that “particuarly” should be “particularly”.")

#text("Forgive my ignorance, but I would like to ask: Intuitively, did")#strong[#text(" ")]#text("the ”density” in the Lebesgue density theorem borrow the term from physics? Similarly, are concepts like density points and probability density functions, and so forth, related to density in physics?")

#emph[#text("[Corrected, thanks. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/#comment-691706")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2026")])]

#text("I am ")#link("https://gemini.google.com/share/c40837ab2ccd")[#text("outsourcing this question to an AI")]#text(".")
]
]
