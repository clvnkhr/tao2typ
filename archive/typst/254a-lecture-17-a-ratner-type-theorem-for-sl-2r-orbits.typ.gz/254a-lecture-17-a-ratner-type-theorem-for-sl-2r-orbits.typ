// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/03/15/254a-lecture-17-a-ratner-type-theorem-for-sl_2r-orbits/
// Converted to Typst by tao2typ: "2026-10-14T06:57:21.837238+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Lecture 17: A Ratner-type theorem for SL_2(R) orbits", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Lecture 17: A Ratner-type theorem for SL_2(R) orbits")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 March 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/03/15/254a-lecture-17-a-ratner-type-theorem-for-sl_2r-orbits/")[#text("https://terrytao.wordpress.com/2008/03/15/254a-lecture-17-a-ratner-type-theorem-for-sl_2r-orbits/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("In this final lecture, we establish a ")#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/")[#text("Ratner-type theorem")]#text(" for actions of the ")#link("http://en.wikipedia.org/wiki/Special_linear_group")[#text("special linear group")]#text(" ")#mi("SL_2({\\Bbb R})")#text(" on ")#link("http://en.wikipedia.org/wiki/Homogeneous_space")[#text("homogeneous spaces")]#text(". More precisely, we show:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" Let G be a ")#link("http://en.wikipedia.org/wiki/Lie_group")[#text("Lie group")]#text(", let ")#mi("\\Gamma < G")#text(" be a discrete subgroup, and let ")#mi("H \\leq G")#text(" be a subgroup isomorphic to ")#mi("SL_2({\\Bbb R})")#text(". Let ")#mi("\\mu")#text(" be an H-invariant probability measure on ")#mi("G/\\Gamma")#text(" which is ergodic with respect to H (i.e. all H-invariant sets either have full measure or zero measure). Then ")#mi("\\mu")#text(" is ")#emph[#text("homogeneous")]#text(" in the sense that there exists a closed connected subgroup ")#mi("H \\leq L \\leq G")#text(" and a closed orbit ")#mi("Lx \\subset G/\\Gamma")#text(" such that ")#mi("\\mu")#text(" is L-invariant and ")#link("http://en.wikipedia.org/wiki/Support_%28measure_theory%29")[#text("supported")]#text(" on Lx.")
]

#text("This result is a special case of a more general theorem of ")#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/")[#text("Ratner")]#text(", which addresses the case when H is generated by elements which act ")#link("http://en.wikipedia.org/wiki/Unipotent")[#text("unipotently")]#text(" on the ")#link("http://en.wikipedia.org/wiki/Lie_algebra")[#text("Lie algebra")]#text(" ")#mi("{\\mathfrak g}")#text(" by conjugation, and when ")#mi("G/\\Gamma")#text(" has finite volume. To prove this theorem we shall follow an argument ")#link("http://arxiv.org/abs/math/0603483")[#text("of Einsiedler")]#text(", which uses many of the same ingredients used in Ratner’s arguments but in a simplified setting (in particular, taking advantage of the fact that H is ")#link("http://en.wikipedia.org/wiki/Semisimple_Lie_algebra")[#text("semisimple")]#text(" with no non-trivial compact factors). These arguments have since been extended and made quantitative ")#link("http://arxiv.org/abs/0708.4040")[#text("by Einsiedler, Margulis, and Venkatesh")]#text(".")#linebreak()#text(" ")#metadata(none) <tao-c066ad14d5d13c2229c1>

#heading(level: 1)[#text("— Representation theory of ")#mi("SL_2({\\Bbb R)}")#text(" —")]

#text("Theorem 1 concerns the action of ")#mi("H \\equiv SL_2({\\Bbb R})")#text(" on a homogeneous space ")#mi("G/\\Gamma")#text(". Before we are able to tackle this result, we must first understand the linear actions of ")#mi("H \\equiv SL_2({\\Bbb R})")#text(" on real or complex vector spaces – in other words, we need to understand the ")#link("http://en.wikipedia.org/wiki/Representation_theory")[#text("representation theory")]#text(" of the Lie group ")#mi("SL_2({\\Bbb R})")#text(" (and its associated Lie algebra ")#mi("{\\mathfrak sl}_2({\\Bbb R})")#text(").")

#text("Of course, this theory is very well understood, and by using the machinery of ")#link("http://en.wikipedia.org/wiki/Weight_space")[#text("weight spaces")]#text(", ")#link("http://en.wikipedia.org/wiki/Ladder_operators")[#text("raising and lowering operators")]#text(", etc. one can completely classify all the finite-dimensional representations of ")#mi("SL_2({\\Bbb R})")#text("; in fact, all such representations are isomorphic to direct sums of ")#link("http://en.wikipedia.org/wiki/Symmetric_tensor")[#text("symmetric powers")]#text(" of the standard representation of ")#mi("SL_2({\\Bbb R})")#text(" on ")#mi("{\\Bbb R}^2")#text(". This classification quickly yields all the necessary facts we will need here. However, we will use only a minimal amount of this machinery here, to obtain as direct and elementary a proof of the results we need as possible.")

#text("The first fact we will need is that finite-dimensional representations of ")#mi("SL_2({\\Bbb R})")#text(" are ")#link("http://en.wikipedia.org/wiki/Completely_reducible")[#text("completely reducible")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" (Complete reducibility) Let ")#mi("SL_2({\\Bbb R})")#text(" act linearly (and smoothly) on a finite-dimensional real vector space V, and let W be a ")#mi("SL_2({\\Bbb R})")#text("-invariant subspace of V. Then there exists a ")#link("http://en.wikipedia.org/wiki/Complementary_subspace")[#text("complementary subspace")]#text(" W’ to W which is also ")#mi("SL_2({\\Bbb R})")#text("-invariant (thus V is isomorphic to the ")#link("http://en.wikipedia.org/wiki/Direct_sum_of_modules")[#text("direct sum")]#text(" of W and W’).")
]

#strong[#text("Proof.")]#text(" We will use ")#link("http://en.wikipedia.org/wiki/Unitarian_trick")[#text("Weyl’s unitary trick")]#text(" to create the complement W’, but in order to invoke this trick, we first need to pass from the non-compact group ")#mi("SL_2({\\Bbb R})")#text(" to a compact counterpart. This is done in several stages.")

#text("First, we linearise the action of the Lie group ")#mi("SL_2({\\Bbb R})")#text(" by differentiating to create a corresponding linear action of the Lie algebra ")#mi("{\\mathfrak sl}_2({\\Bbb R})")#text(" in the usual manner.")

#text("Next, we complexify the action. Let ")#mi("V^{\\Bbb C} := V \\otimes {\\Bbb C}")#text(" and ")#mi("W^{\\Bbb C} := W \\otimes {\\Bbb C}")#text(" be the ")#link("http://en.wikipedia.org/wiki/Complexification")[#text("complexifications")]#text(" of V and W respectively. Then the complexified Lie algebra ")#mi("{\\mathfrak sl}_2({\\Bbb C})")#text(" acts on both ")#mi("V^{\\Bbb C}")#text(" and ")#mi("W^{\\Bbb C}")#text(", and in particular the ")#link("http://en.wikipedia.org/wiki/Special_unitary_group")[#text("special unitary Lie algebra")]#text(" ")#mi("{\\mathfrak su}_2({\\Bbb C})")#text(" does also.")

#text("Since the special unitary group")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("SU_2({\\Bbb C}) = \\{ \\begin{pmatrix} \\alpha & \\beta \\\\ -\\overline{\\beta} & \\overline{\\alpha} \\end{pmatrix}: \\alpha,\\beta \\in {\\Bbb C}; \\left|\\alpha\\right|^2 + \\left|\\beta\\right|^2 = 1 \\}", block: true)]]

#text("is topologically equivalent to the 3-sphere ")#mi("S^3")#text(" and is thus ")#link("http://en.wikipedia.org/wiki/Simply_connected")[#text("simply connected")]#text(", a standard homotopy argument allows one to exponentiate the ")#mi("{\\mathfrak su}_2({\\Bbb C})")#text(" action to create a ")#mi("SU_2({\\Bbb C})")#text(" action, thus creating the desired compact action. (This trick is not restricted to ")#mi("{\\mathfrak sl}_2({\\Bbb R})")#text(", but can be generalised to other ")#link("http://en.wikipedia.org/wiki/Semisimple_Lie_algebra")[#text("semisimple Lie algebras")]#text(" using the ")#link("http://en.wikipedia.org/wiki/Cartan_decomposition")[#text("Cartan decomposition")]#text(".)")

#text("Now we can apply the unitary trick. Take any ")#link("http://en.wikipedia.org/wiki/Sesquilinear_form")[#text("Hermitian form")]#text(" ")#mi("\\langle,\\rangle")#text(" on ")#mi("V^{\\Bbb C}")#text(". This form need not be preserved by the ")#mi("SU_2({\\Bbb C})")#text(" action, but if one defines the averaged form")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\langle u, v \\rangle_{SU_2} := \\int_{SU_2({\\Bbb C})} \\langle gu, gv \\rangle\\ dg")]]

#text("where dg is Haar measure on the compact Lie group ")#mi("SU_2({\\Bbb C})")#text(", then we see that ")#mi("\\langle ,\\rangle_{SU_2}")#text(" is a Hermitian form which is ")#mi("SU_2({\\Bbb C})")#text("-invariant; thus this form endows ")#mi("V^{\\Bbb C}")#text(" with a Hilbert space structure with respect to which the ")#mi("SU_2({\\Bbb C})")#text("-action is unitary. If we then define ")#mi("(W^{\\prime})^{\\Bbb C}")#text(" to be the orthogonal complement of ")#mi("W^{\\Bbb C}")#text(" in this Hilbert space, then this vector space is invariant under the ")#mi("SU_2({\\Bbb C})")#text(" action, and thus (by differentiation) by the ")#mi("{\\mathfrak su}_2({\\Bbb C})")#text(" action. But observe that ")#mi("{\\mathfrak su}_2({\\Bbb C})")#text(" and ")#mi("{\\mathfrak sl}_2({\\Bbb R})")#text(" have the same complex span (namely, ")#mi("{\\mathfrak sl}_2({\\Bbb C})")#text("); thus the complex vector space ")#mi("(W^{\\prime})^{\\Bbb C}")#text(" is also ")#mi("{\\mathfrak sl}_2({\\Bbb R})")#text("-invariant.")

#text("The last thing to do is to undo the complexification. If we let W’ be the space of real parts of vectors in ")#mi("(W^{\\prime})^{\\Bbb C}")#text(" which are real modulo ")#mi("W^{\\Bbb C}")#text(", then one easily verifies that W’ is ")#mi("{\\mathfrak sl}_2({\\Bbb R})")#text("-invariant (hence ")#mi("SL_2({\\Bbb R})")#text("-invariant, by exponentiation) and is a complementary subspace to W, as required. ")#mi("\\Box")

#strong[#text("Remark 1.")]#text(" We can of course iterate the above lemma and conclude that every finite-dimensional representation of ")#mi("SL_2({\\Bbb R})")#text(" is the direct sum of irreducible representations, which explains the term “complete reducibility”. Complete reducibility of finite-dimensional representations of a Lie algebra (over a field of characteristic zero) is equivalent to that Lie algebra being ")#link("http://en.wikipedia.org/wiki/Semisimple_Lie_algebra")[#text("semisimple")]#text(". The situation is slightly more complicated for Lie groups, though, if such groups are not ")#link("http://en.wikipedia.org/wiki/Simply_connected")[#text("simply connected")]#text(". ")#mi("\\diamond")

#text("An important role in our analysis will be played by the one-parameter unipotent subgroup ")#mi("U := \\{ u^t: t \\in {\\Bbb R} \\}")#text(" of ")#mi("SL_2({\\Bbb R})")#text(", where")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("u^t := \\begin{pmatrix} 1 & t \\\\ 0 & 1 \\end{pmatrix}.")]]

#text("Clearly, the elements of U are unipotent when acting on ")#mi("{\\Bbb R}^2")#text(". It turns out that they are unipotent when acting on all other finite-dimensional representations also:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2. ")]#text("Suppose that ")#mi("SL_2({\\Bbb R)}")#text(" acts on a finite-dimensional real or complex vector space V. Then the action of any element of U on V is ")#link("http://en.wikipedia.org/wiki/Unipotent")[#text("unipotent")]#text(".")
]

#strong[#text("Proof.")]#text(" By complexifying V if necessary we may assume that V is complex. The action of the Lie group ")#mi("SL_2({\\Bbb R)}")#text(" induces a Lie algebra homomorphism ")#mi("\\rho: {\\mathfrak sl}_2({\\Bbb R}) \\to \\text{End}(V)")#text(". To show that the action of U is unipotent, it suffices to show that ")#mi("\\rho(\\log u)")#text(" is ")#link("http://en.wikipedia.org/wiki/Nilpotent")[#text("nilpotent")]#text(", where")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\log u = \\begin{pmatrix} 0 & 1 \\\\ 0 & 0 \\end{pmatrix}")]]

#text("is the infinitesimal generator of U. To show this, we exploit the fact that ")#mi("\\log u")#text(" induces a ")#link("http://en.wikipedia.org/wiki/Raising_operator")[#text("raising operator")]#text(". We introduce the diagonal subgroup ")#mi("D := \\{ d^t: t \\in {\\Bbb R}\\}")#text(" of ")#mi("SL_2({\\Bbb R})")#text(", where")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("d^t := \\begin{pmatrix} e^t & 0 \\\\ 0 & e^{-t} \\end{pmatrix}.")]]

#text("This group has infinitesimal generator")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\log d = \\begin{pmatrix} 1 & 0 \\\\ 0 & -1 \\end{pmatrix}.")]]

#text("Observe that ")#mi("{}[\\log d, \\log u] = 2 \\log u")#text(", and thus (since ")#mi("\\rho")#text(" is a Lie algebra homomorphism)")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("{}[ \\rho(\\log d), \\rho(\\log u)] = 2 \\rho(\\log u).")]]

#text("We can rewrite this as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("(\\rho(\\log d) -\\lambda-2)\\rho(\\log u) = \\rho(\\log u) (\\rho(\\log d)-\\lambda)")]]

#text("for any ")#mi("\\lambda \\in {\\Bbb C}")#text(", which on iteration implies that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("(\\rho(\\log d) -\\lambda-2r)^m\\rho(\\log u)^r = \\rho(\\log u)^r (\\rho(\\log d)-\\lambda)^m")]]

#text("for any non-negative integers m, r. But this implies that ")#mi("\\rho(\\log u)^r")#text(" raises ")#link("http://en.wikipedia.org/wiki/Generalized_eigenvector")[#text("generalised eigenvectors")]#text(" of ")#mi("\\rho(\\log d)")#text(" of eigenvalue ")#mi("\\lambda")#text(" to generalised eigenvectors of ")#mi("\\rho(\\log d)")#text(" of eigenvalue ")#mi("\\lambda+2m")#text(". But as V is finite dimensional, there are only finitely many eigenvalues of ")#mi("\\rho(\\log d)")#text(", and so ")#mi("\\rho(\\log u)")#text(" is nilpotent on each of the generalised eigenvectors of ")#mi("\\rho(\\log d)")#text(". By the ")#link("https://terrytao.wordpress.com/2007/10/12/the-jordan-normal-form-and-the-euclidean-algorithm/")[#text("Jordan normal form")]#text(", these generalised eigenvectors span V, and we are done.")#mi("\\Box")

#strong[#text("Exercise 1.")]#text(" By carrying the above analysis further (and also working with the adjoint of U to create lowering operators) show (for complex V) that ")#mi("\\rho(\\log d)")#text(" is diagonalisable, and the eigenvalues are all integers. For an additional challenge: deduce from this that the representation is isomorphic to a direct sum of the representations of ")#mi("SL_2({\\Bbb R})")#text(" on the symmetric tensor powers ")#mi("\\text{Sym}^k({\\Bbb R}^2)")#text(" of ")#mi("{\\Bbb R}^2")#text(" (or, if you wish, on the space of homogeneous polynomials of degree k on 2 variables). Of course, if you are stuck, you can turn to any book on representation theory (I recommend ")#link("http://www.ams.org/mathscinet-getitem?mr=1153249")[#text("Fulton and Harris")]#text("). ")#mi("\\Box")

#text("The group U is merely a subgroup of the group ")#mi("SL_2({\\Bbb R})")#text(", so it is not a priori evident that any vector (in a space that ")#mi("SL_2({\\Bbb R})")#text(" acts on) which is U-invariant, is also ")#mi("SL_2({\\Bbb R})")#text("-invariant. But, thanks to the highly non-commutative nature of ")#mi("SL_2({\\Bbb R})")#text(", this turns out to be the case, even in infinite dimensions, once one restricts attention to ")#emph[#text("continuous unitary")]#text(" actions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" (Mautner phenomenon). Let ")#mi("\\rho: SL_2({\\Bbb R}) \\to U(V)")#text(" be a continuous unitary action on a Hilbert space V (possibly infinite dimensional). Then any vector ")#mi("v \\in V")#text(" which is fixed by U, is also fixed by ")#mi("SL_2({\\Bbb R)}")#text(".")
]

#strong[#text("Proof.")]#text(" We use an argument of Margulis. We may of course take v to be non-zero. Let ")#mi("\\varepsilon > 0")#text(" be a small number. Then even though the matrix ")#mi("w^\\varepsilon := \\begin{pmatrix} 1 & 0 \\\\ \\varepsilon & 1 \\end{pmatrix}")#text(" is very close to the identity, the double orbit ")#mi("U w^\\varepsilon U")#text(" can stray very far away from U. Indeed, from the algebraic identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\begin{pmatrix} e^t & 0 \\\\ \\varepsilon & e^{-t} \\end{pmatrix} = u^{(e^t-1)/\\varepsilon} w^\\varepsilon u^{(e^{-t}-1)/\\varepsilon}")]]

#text("which is valid for any ")#mi("t \\in {\\Bbb R}")#text(", we see that this double orbit in fact comes very close to the diagonal group D. Applying (10) to the U-invariant vector v and taking inner products with v, we conclude from unitarity that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\langle \\rho( \\begin{pmatrix} e^t & 0 \\\\ \\varepsilon & e^{-t} \\end{pmatrix} ) v, v \\rangle = \\langle \\rho(w^\\varepsilon) v, v \\rangle.")]]

#text("Taking limits as ")#mi("\\varepsilon \\to 0")#text(" (taking advantage of the continuity of ")#mi("\\rho")#text(") we conclude that ")#mi("\\langle \\rho(d^t) v, v \\rangle = \\langle v, v \\rangle")#text(". Since ")#mi("\\rho(d^t) v")#text(" has the same length as v, we conclude from the converse ")#link("http://en.wikipedia.org/wiki/Cauchy%E2%80%93Schwarz_inequality")[#text("Cauchy-Schwarz inequality")]#text(" that ")#mi("\\rho(d^t) v = v")#text(", i.e. that v is D-invariant.")

#text("As U and D do not quite generate ")#mi("SL_2({\\Bbb R})")#text(", we have to work a bit more to finish the job. Let ")#mi("w^\\varepsilon")#text(" be as above. Observe that ")#mi("d^t w^\\varepsilon d^{-t}")#text(" converges to the identity as ")#mi("t \\to +\\infty")#text(", and thus ")#mi("\\langle \\rho(d^t w^\\varepsilon d^{-t}) v, v \\rangle \\to \\langle v, v \\rangle")#text(". Using the D-invariance we conclude that ")#mi("\\rho(w^\\varepsilon) v, v \\rangle = \\langle v, v \\rangle")#text(", and thus as before v is also invariant with respect to the group U’ generated by the ")#mi("w^\\varepsilon")#text(". Since U and U’ (and D, if desired) generate ")#mi("SL_2({\\Bbb R})")#text(", the claim follows. ")#mi("\\Box")

#strong[#text("Remark 2.")]#text(" The key fact about U being used here is that its Lie algebra is not trapped inside any proper ideal of ")#mi("sl_2({\\Bbb R})")#text(", which, in turn, follows from the fact that this Lie algebra is simple. One can do the same thing for semisimple Lie algebras provided that the unipotent group U is non-degenerate in the sense that it has non-trivial projection onto each simple factor. ")#mi("\\diamond")

#text("This phenomenon has an immediate dynamical corollary:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1")]#text(" (Moore ergodic theorem). Suppose that ")#mi("SL_2({\\Bbb R})")#text(" acts in a measure-preserving fashion on a probability space ")#mi("(X, {\\mathcal X}, \\mu)")#text(". If this action is ergodic with respect to ")#mi("SL_2({\\Bbb R})")#text(", then it is also ergodic with respect to U.")
]

#strong[#text("Proof. ")]#text(" Apply Lemma 3 to ")#mi("L^2(X, {\\mathcal X}, \\mu)")#text(". ")#mi("\\Box")

#heading(level: 1)[#text("— Proof of Theorem 1 —")]

#text("Having completed our representation-theoretic preliminaries, we are now ready to begin the proof of Theorem 1. The key is to prove the following dichotomy:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1. ")]#text(" (Lack of concentration implies additional symmetry) Let ")#mi("G, H, \\mu, \\Gamma")#text(" be as in Theorem 1. Suppose there exists a closed connected subgroup ")#mi("H \\leq L \\leq G")#text(" such that ")#mi("\\mu")#text(" is L-invariant. Then exactly one of the following statements hold:")

#enum(start: 1, 
[#text("(Concentration) ")#mi("\\mu")#text(" is supported on a closed orbit Lx of L.")],
[#text("(Additional symmetry) There exists a closed connected subgroup ")#mi("L < L^{\\prime} \\leq G")#text(" such that ")#mi("\\mu")#text(" is L’-invariant.")]
)
]

#text("Iterating this proposition (noting that the dimension of L’ is strictly greater than that of L) we will obtain Theorem 1. So it suffices to establish the proposition.")

#text("We first observe that the ergodicity allows us to obtain the concentration conclusion (1) as soon as ")#mi("\\mu")#text(" assigns any non-zero mass to an orbit of L:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4.")]#text(" Let the notation and assumptions be as in Proposition 1. Suppose that ")#mi("\\mu(L x_0) > 0")#text(" for some ")#mi("x_0")#text(". Then ")#mi("Lx_0")#text(" is closed and ")#mi("\\mu")#text(" is supported on ")#mi("Lx_0")#text(".")
]

#strong[#text("Proof. ")]#text("Since ")#mi("Lx_0")#text(" is H-invariant and ")#mi("\\mu")#text(" is H-ergodic, the set ")#mi("Lx_0")#text(" must either have full measure or zero measure. It cannot have zero measure by hypothesis, thus ")#mi("\\mu(Lx_0) = 1")#text(". Thus, if we show that ")#mi("Lx_0")#text(" is closed, we automatically have that ")#mi("\\mu")#text(" is supported on ")#mi("Lx_0")#text(".")

#text("As ")#mi("G/\\Gamma")#text(" is a homogeneous space, we may assume without loss of generality (conjugating L if necessary) that ")#mi("x_0")#text(" is at the origin, then ")#mi("Lx_0 \\equiv L / (\\Gamma \\cap L)")#text(". The measure ")#mi("\\mu")#text(" on this set can then be pulled back to a measure m on L by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\int_L f(g)\\ dm(g) = \\int_{L/(\\Gamma \\cap L)} \\sum_{g \\in x (\\Gamma \\cap L)} f(g)\\ d\\mu(x).")]]

#text("By construction, m is left L-invariant (i.e. a left ")#link("http://en.wikipedia.org/wiki/Haar_measure")[#text("Haar measure")]#text(") and right ")#mi("(\\Gamma \\cap L)")#text("-invariant. From uniqueness of left Haar measure up to constants, we see that for any g in L there is a constant ")#mi("c(g) > 0")#text(" such that ")#mi("m(E g) = c(g) m(E)")#text(" for all measurable E. It is not hard to see that ")#mi("c: L \\to {\\Bbb R}^+")#text(" is a character, i.e. it is continuous and multiplicative, thus ")#mi("c(gh) = c(g) c(h)")#text(" for all g, h in L. Also, it is the identity on ")#mi("(\\Gamma \\cap L)")#text(" and thus descends to a continuous function on ")#mi("L/(\\Gamma \\cap L)")#text(".")

#text("Now let ")#mi("K")#text(" be a compact subset of ")#mi("L/(\\Gamma \\cap L)")#text(" with positive ")#mi("\\mu")#text("-measure, and let ")#mi("g \\in L")#text(" be arbitrary. By the Poincare recurrence theorem, ")#mi("K \\cap g^n K")#text(" is non-empty for arbitrarily large ")#mi("n")#text(", and thus ")#mi("c(K) \\cap c(g)^n c(K)")#text(" is non-empty for arbitrary large ")#mi("n")#text(". Since ")#mi("c(K)")#text(" is bounded above and below, we conclude that ")#mi("c(g)=1")#text(" for all ")#mi("g")#text(" (i.e. L is ")#link("http://en.wikipedia.org/wiki/Unimodular_group")[#text("unimodular")]#text("). Thus m is right-invariant, which implies that ")#mi("\\mu")#text(" obeys the right-invariance property ")#mi("\\mu( K x_0 ) = \\mu( K g x_0 )")#text(" for any g in L with ")#mi("gx_0")#text(" sufficiently close to ")#mi("x_0")#text(" and any sufficiently small compact set ")#mi("K\\subset L")#text(" (small enough to fit inside a single ")#link("http://en.wikipedia.org/wiki/Fundamental_domain")[#text("fundamental domain")]#text(" of ")#mi("L/(\\Gamma \\cap L)")#text(").")

#text("Suppose that ")#mi("Lx_0")#text(" is not closed; then one can find a sequence ")#mi("g_n x_0")#text(" in ")#mi("Lx_0")#text(" that converges to ")#mi("x_0")#text(" but with the ")#mi("g_m g_n^{-1}")#text(" staying bounded away from the identity for ")#mi("m \\neq n")#text(". For a sufficiently small compact neighbourhood ")#mi("K")#text(" of the identity in ")#mi("L")#text(", the sets ")#mi("K g_n x_0")#text(" then are disjoint and all have the same measure for ")#mi("n")#text(" large enough; since ")#mi("\\mu(Lx_0)=1")#text(", this forces these sets to be null. But then the invariant measure ")#mi("m")#text(" annihilates ")#mi("K")#text(" and is thus null as well, a contradiction. ")#mi("\\Box")

#text("We return to the proof of Proposition 1. In view of Lemma 4, we may assume that ")#mi("\\mu")#text(" is totally non-concentrated on L-orbits in the sense that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\mu( L x ) = 0 \\text{ for all } x \\in G/\\Gamma.")]]

#text("In particular, for ")#mi("\\mu")#text("-almost every x and y, y does not lie in the orbit Lx of x and vice versa; informally, the group elements in G that are used to move from x to y should be somehow “transverse” to L.")

#text("On the other hand, we are given that ")#mi("\\mu")#text(" is ergodic with respect to H, and thus (by Corollary 1) ergodic with respect to U. This implies (cf. Proposition 2 from ")#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/")[#text("Lecture 9")]#text(") that ")#mi("\\mu")#text("-almost every point x in ")#mi("G/\\Gamma")#text(" is ")#emph[#text("generic")]#text(" (with respect to U) in the sense that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\int_{G/\\Gamma} f\\ d\\mu = \\lim_{T \\to +\\infty} \\frac{1}{T} \\int_0^T f( u^t x )\\ dt.")]]

#text("for all continuous compactly supported ")#mi("f: G/\\Gamma \\to {\\Bbb R}")#text(".")

#strong[#text("Exercise 2")]#text(". Prove this claim. (Hint: obtain continuous analogues of the theory from ")#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")[#text("Lecture 8")]#text(" and ")#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/")[#text("Lecture 9")]#text(".) ")#mi("\\diamond")

#text("The equation (15) (and the ")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem")[#text("Riesz representation theorem")]#text(") lets us describe the measure ")#mi("\\mu")#text(" in terms of the U-orbit of a generic point. On the other hand, from (14) and the ensuing discussion we see that any two generic points are likely to be separated from each other by some group element “transverse” to L. It is the interaction between these two facts which is going to generate the additional symmetry needed for Proposition 1. We illustrate this with a model case, in which the group element ")#link("http://en.wikipedia.org/wiki/Centralizer")[#text("centralises")]#text(" U:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2")]#text(" (central case). Let the notation and assumptions be as in Proposition 1. Suppose that x, y are generic points such that ")#mi("y = gx")#text(" for some ")#mi("g \\in G")#text(" that centralises U (i.e. it commutes with every element of u). Then ")#mi("\\mu")#text(" is invariant under the action of g.")
]

#strong[#text("Proof. ")]#text(" Let ")#mi("f: G/\\Gamma \\to {\\Bbb R}")#text(" be continuous and compactly supported. Applying (15) with x replaced by y=gx we obtain")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\int_{G/\\Gamma} f\\ d\\mu = \\lim_{T \\to +\\infty} \\frac{1}{T} \\int_0^T f( u^t gx )\\ dt.")]]

#text("Commuting g with ")#mi("u^t")#text(" and using (15) again, we conclude")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\int_{G/\\Gamma} f\\ d\\mu = \\int_{G/\\Gamma} f(gy)\\ d\\mu(y)")]]

#text("and the claim follows from the Riesz representation theorem. ")#mi("\\Box")

#text("Of course, we don’t just want invariance under one group element g; we want a whole group L’ of symmetries for which one has invariance. But it is not hard to leverage the former to the latter, provided one has enough group elements:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5.")]#text(" Let the notation and assumptions be as in Proposition 1. Suppose one has a sequence ")#mi("g_n")#text(" of group elements tending to the identity, such that the action of each of the ")#mi("g_n")#text(" preserve ")#mi("\\mu")#text(", and such that none of the ")#mi("g_n")#text(" lie in L. Then there exists a closed connected subgroup ")#mi("L < L^{\\prime} \\leq G")#text(" such that ")#mi("\\mu")#text(" is L-invariant.")
]

#strong[#text("Proof.")]#text(" Let S be the ")#link("http://en.wikipedia.org/wiki/Group_action#Orbits_and_stabilizers")[#text("stabiliser")]#text(" of ")#mi("\\mu")#text(", i.e. the set of all group elements g whose action preserves ")#mi("\\mu")#text(". This is clearly a closed subgroup of G which contains L. If we let ")#mi("L^{\\prime}")#text(" be the identity connected component of S, then L’ is a closed connected subgroup containing L which will contain ")#mi("g_n")#text(" for all sufficiently large n, and in particular is not equal to L. The claim follows. ")#mi("\\Box")

#text("From Proposition 2 and Lemma 5 we see that we are done if we can find pairs ")#mi("x_n, y_n = g_n x_n")#text(" of nearby generic points with ")#mi("g_n")#text(" going to the identity such that ")#mi("g_n \\not \\in L")#text(" and that ")#mi("g_n")#text(" centralises U. Now we need to consider the non-central case; thus suppose for instance that we have two generic points x, y=gx in which g is close to the identity but does not centralise U. The key observation here is that we can use the U-invariance of the situation to pull x and y slowly apart from each other. More precisely, since x and y are generic, we observe that ")#mi("u^t x")#text(" and ")#mi("u^t y")#text(" are also generic for any t, and that these two points differ by the conjugated group element ")#mi("g^t := u^t g u^{-t}")#text(". Taking logarithms (which are well-defined as long as ")#mi("g^t")#text(" stays close to the identity), we can write")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\log(g^t) = u^t \\log(g) u^{-t} = \\exp( t \\text{ad}(\\log u) ) \\log(g)")]]

#text("where ")#mi("\\text{ad}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Adjoint_representation")[#text("adjoint representation")]#text(". From Lemma 2, we know that ")#mi("\\text{ad}(\\log u): \\mathfrak{g} \\to \\mathfrak{g}")#text(" is nilpotent, and so (by Taylor expansion of the exponential) ")#mi("\\log(g^t)")#text(" depends polynomially on t. In particular, if g does not centralise U, then ")#mi("\\log(g^t)")#text(" is non-constant and thus must diverge to infinity as ")#mi("t \\to +\\infty")#text(". In particular, given some small ball B around the origin in ")#mi("{\\mathfrak g}")#text(" (with respect to some arbitrary norm), then whenever ")#mi("\\log g")#text(" lies inside B around the origin and is not central, there must be a first time ")#mi("t = t_g")#text(" such that ")#mi("\\log g^{t_g}")#text(" reaches the boundary ")#mi("\\partial B")#text(" of this ball. We write ")#mi("g^* := g^{t_g} \\in \\partial B")#text(" for the location of g when it escapes. We now have the following variant of Proposition 2:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3")]#text(" (non-central case). Let the notation and assumptions be as in Proposition 1. Suppose that ")#mi("x_n, y_n \\in G/\\Gamma")#text(" are generic points such that ")#mi("y_n = g_n x_n")#text(" for some ")#mi("g_n \\in G")#text(" which do not centralise u, but such that ")#mi("g_n")#text(" converge to the identity (in particular, ")#mi("g_n \\in B")#text(" for all sufficiently large n). Suppose furthermore that ")#mi("x_n, y_n")#text(" are ")#emph[#text("uniformly generic")]#text(" in the sense that for any continuous compactly supported ")#mi("f: G/\\Gamma \\to {\\Bbb R}")#text(", the convergence of (15) (with x replaced by ")#mi("x_n")#text(" or ")#mi("y_n")#text(") is uniform in n. Then ")#mi("\\mu")#text(" is invariant under the action of any limit point ")#mi("g^* \\in \\partial B")#text(" of the ")#mi("g^*_n")#text(".")
]

#strong[#text(" Proof.")]#text(" By passing to a subsequence if necessary we may assume that ")#mi("g^*_n")#text(" converges to ")#mi("g^*")#text(". For each sufficiently large n, we write ")#mi("T_n := t_{g_n}")#text(", thus ")#mi("g_n^t \\in B")#text(" for all ")#mi("0 \\leq t \\leq T_n")#text(", and ")#mi("g_n^{T_n} = g_n^*")#text(". We rescale this by defining the functions ")#mi("h_n: [0,1] \\to B")#text(" by ")#mi("h_n(s) := g_n^{s T_n}")#text(". From the unipotent nature of U, these functions are polynomial (with bounded degree), and also bounded (as they live in ")#mi("B")#text("), and are thus ")#link("http://en.wikipedia.org/wiki/Equicontinuity")[#text("equicontinuous")]#text(" (since all norms are equivalent on finite dimensional spaces). Thus, by the ")#link("http://en.wikipedia.org/wiki/Arzel%C3%A0-Ascoli_theorem")[#text("Arzelà-Ascoli theorem")]#text(", we can assume (after passing to another subsequence) that ")#mi("h_n")#text(" is uniformly convergent to some limit f, which is another polynomial. Since we already have ")#mi("h_n(1) = g_n^*")#text(" converging to ")#mi("g^*")#text(", this implies that for any ")#mi("\\varepsilon > 0")#text(" there exists ")#mi("\\delta > 0")#text(" such that ")#mi("h_n(s) = g^* + O(\\varepsilon)")#text(" for all ")#mi("1-\\delta \\leq s \\leq 1")#text(" and all sufficiently large n. In other words, we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("u^t g_n u^{-t} = g^* + O(\\varepsilon)")]]

#text("for sufficiently large n, whenever ")#mi("(1 - \\delta)T_n \\leq t \\leq T_n")#text(".")

#text("This is good enough to apply a variant of the Proposition 2 argument. Namely, if ")#mi("f: G/\\Gamma \\to {\\Bbb R}")#text(" is continuous and compactly supported, then by uniform genericity we have for T sufficiently large that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\int_{G/\\Gamma} f\\ d\\mu = \\frac{1}{\\delta T} \\int_{(1-\\delta) T}^T f( u^t y_n )\\ dt + O(\\varepsilon)")]]

#text("for all n. Applying (19) we can write ")#mi("u^t y_n = g^* u^t x_n + O(\\varepsilon)")#text(" on the support of f, and so by uniform continuity of f")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\int_{G/\\Gamma} f\\ d\\mu = \\frac{1}{\\delta T} \\int_{(1-\\delta) T}^T f( g^* u^t x_n )\\ dt + o(1)")]]

#text("where o(1) goes to zero as ")#mi("\\varepsilon \\to 0")#text(", uniformly in n. Using (15) again and then letting ")#mi("\\varepsilon \\to 0")#text(", we obtain the ")#mi("g^*")#text("-invariance of ")#mi("\\mu")#text(" as desired. ")#mi("\\Box")

#text("Now we have all the ingredients to prove Proposition 1, and thus Theorem 1.")

#strong[#text("Proof of Proposition 1.")]#text(" We know that ")#mi("\\mu")#text("-almost every point is generic. Applying ")#link("http://en.wikipedia.org/wiki/Egorov%27s_theorem")[#text("Egoroff’s theorem")]#text(", we can find sets ")#mi("E \\subset G/\\Gamma")#text(" of measure arbitrarily close to 1 (e.g. ")#mi("\\mu(E) \\geq 0.9")#text(") on which the points are uniformly generic.")

#text("Now let V be a small neighbourhood the origin in L. Observe from the ")#link("http://en.wikipedia.org/wiki/Fubini%27s_theorem")[#text("Fubini-Tonelli theorem")]#text(" that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\int_X \\frac{1}{m(V)} \\int_V 1_E(x) 1_E(gx)\\ \\ dm(g) d\\mu(x) \\geq 2\\mu(E)-1 \\geq 0.8")]]

#text("where m is the Haar measure on the unimodular group L, from which one can find a set ")#mi("E^{\\prime} \\subset E")#text(" of positive measure such that ")#mi("m( \\{ g \\in V: gx \\in E \\} ) = 0.7 m(V)")#text(" for all ")#mi("x \\in E^{\\prime}")#text("; one can view E’ as “points of density” of E in some approximate sense (and with regard to the L action).")

#text("Since E’ has positive measure, and using (14), it is not hard to find sequences ")#mi("x_n, y_n \\in E^{\\prime}")#text(" with ")#mi("y_n \\not \\in L x_n")#text(" for any n and with ")#mi("\\text{dist}(x_n,y_n) \\to 0")#text(" (using some reasonable metric on ")#mi("G/\\Gamma")#text(").")

#strong[#text("Exercise 3.")]#text(" Verify this. (")#emph[#text("Hint")]#text(": ")#mi("G/\\Gamma")#text(" can be covered by countably many balls of a fixed radius.) ")#mi("\\diamond")

#text("Next, recall that ")#mi("H \\equiv SL_2({\\Bbb R})")#text(" acts by conjugation on the Lie algebra ")#mi("{\\mathfrak g}")#text(" of G, and also leaves the Lie algebra ")#mi("{\\mathfrak l} \\subset {\\mathfrak g}")#text(" of L invariant. By Lemma 1, this implies there is a complementary subspace W of ")#mi("{\\mathfrak l}")#text(" in ")#mi("{\\mathfrak g}")#text(" which is also H-invariant (and in particular, U-invariant). From the inverse function theorem, we conclude that for any group element g in G sufficiently close to the identity, we can factor ")#mi("g = \\exp(w) l")#text(" where ")#mi("l \\in L")#text(" is also close to the identity, and ")#mi("w \\in W")#text(" is small (in fact this factorisation is unique). We let ")#mi("\\pi_L: g \\mapsto l")#text(" be the map from g to l; this is well-defined and smooth near the identity.")

#text("Let n be sufficiently large, and write ")#mi("y_n = g_n x_n")#text(" where ")#mi("g_n")#text(" goes to the identity as n goes to infinity. Pick ")#mi("l_n \\in V")#text(" at random (using the measure m conditioned to V). Using the inverse function theorem and continuity, we see that the random variable ")#mi("\\pi_L( l_n g_n )")#text(" is supported in a small neighbourhood of V, and that its distribution converges to the uniform distribution of V (in, say, ")#link("http://en.wikipedia.org/wiki/Total_variation#Total_variation_in_measure_theory")[#text("total variation norm")]#text(") as ")#mi("n \\to \\infty")#text(". In particular, we see that ")#mi("y^{\\prime}_n := l_n y_n \\in E")#text(" with probability at least 0.7 and ")#mi("x^{\\prime}_n := \\pi_L(l_n g_n) x_n \\in E")#text(" with probability at least 0.6 (say) if n is large enough. In particular we can find an ")#mi("l_n \\in V")#text(" such that ")#mi("y^{\\prime}_n, x^{\\prime}_n")#text(" both lie in E. Also by construction we see that ")#mi("y^{\\prime}_n = \\exp(w_n) x^{\\prime}_n")#text(" for some ")#mi("w_n \\in W")#text("; since ")#mi("y_n \\not \\in L x_n")#text(", we see that ")#mi("w_n")#text(" is non-zero. On the other hand, since W is transverse to ")#mi("{\\mathfrak l}")#text(" and the distance between ")#mi("x_n, y_n")#text(" go to zero, we see that ")#mi("w_n")#text(" goes to zero.")

#text("There are now two cases. If ")#mi("\\exp(w_n)")#text(" centralises U for infinitely many n, then from Proposition 2 followed by Lemma 5 we obtain conclusion 2 of Proposition 1 as required. Otherwise, we may pass to a subsequence and assume that none of the ")#mi("\\exp(w_n)")#text(" centralise U. Since W is preserved by U, we see that the group elements ")#mi("\\exp(w_n)^*")#text(" also lie in ")#mi("\\exp(K)")#text(" for some compact set K in W, and also on the boundary of B. This space is compact, and so by Proposition 3 we see that ")#mi("\\mu")#text(" is invariant under some group element ")#mi("g \\in \\exp(K) \\cap \\partial B")#text(", which cannot lie in L. Since the ball B can be chosen arbitrarily small, we can thus apply Lemma 5 to again obtain conclusion 2 of Proposition 1 as required. ")#mi("\\Box")

#text("[")#emph[#text("Update")]#text(", Oct 18 2011: A gap in the proof of Lemma 3 has been repaired, following a suggestion of Hee Oh.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f45ab10b45f8922ee5b40b2fcd7d25b41193cc32e517e957e81f44a95b7f7a3a-86fcf978faeb14fc5e4f80e80086cb54242bc7638d012f29894c40b71a5cf91a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of www.smasra.com")]], [#link("https://terrytao.wordpress.com/2008/03/15/254a-lecture-17-a-ratner-type-theorem-for-sl_2r-orbits/#comment-27354")[#strong[#text("www.smasra.com")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2008")])]

#text("looks nice thank you .. waiting for more maths operations :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/03/15/254a-lecture-17-a-ratner-type-theorem-for-sl_2r-orbits/#comment-27398")[#strong[#text("This w33k in the arXivs… « It’s Equal, but It’s Different…")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2008")]

#text("[…] 254A, Lecture 17: A Ratner-type theorem for SL_2(R) orbits […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2008/03/15/254a-lecture-17-a-ratner-type-theorem-for-sl_2r-orbits/#comment-124121")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2012")])]

#text("Dear Terry,")

#text("How do we know that the integrals in line 13 in the proof of lemma 4 converge?")

#text("A priori, it seems that the function c(g) need not be bounded, since the domain L.x_0 is not known to be compact.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/15/254a-lecture-17-a-ratner-type-theorem-for-sl_2r-orbits/#comment-124141")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2012")])]

#text("Oops, you’re right. I’m reinstating Einseidler’s original argument here (based on the Poincare recurrence theorem) instead.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2008/03/15/254a-lecture-17-a-ratner-type-theorem-for-sl_2r-orbits/#comment-125980")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2012")])]

#text("Could you elaborate a little more on how one makes the equicontinuity deduction")

#text("“…these functions are polynomial (with bounded degree), and also bounded (as they live in B), and are thus equicontinuous (since all norms are equivalent on finite dimensional spaces)”")

#text("as found in the proof of Prop 3?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/15/254a-lecture-17-a-ratner-type-theorem-for-sl_2r-orbits/#comment-126047")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2012")])]

#text("As all norms are equivalent on finite dimensional spaces, the sup norm on the space of bounded degree polynomials is equivalent to, say, the Lipschitz norm, which certainly controls equicontinuity.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2008/03/15/254a-lecture-17-a-ratner-type-theorem-for-sl_2r-orbits/#comment-145750")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2012")])]

#text("How much of the proof of lemma 4 carries over when we assume L to be, not a Lie group, but only a locally compact group?")

#text("I am mostly worried about the spots where we have to “choose a sufficiently small compact set K”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2008/03/15/254a-lecture-17-a-ratner-type-theorem-for-sl_2r-orbits/#comment-146304")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2012")])]

#text("First, a few typos: I believe in the statement of Proposition 3, you want the ")#mi("x_n, y_n")#text(" to be points in ")#mi("G/\\Gamma")#text(" rather than ")#mi("G")#text(". Also, in the proof of Proposition 3, it seems that ")#mi("g^\\ast")#text(" has suddenly turned into ")#mi("g_\\ast")#text(" in a few spots. I am assuming that ")#mi("g^\\ast = g_\\ast")#text(", anyway.")

#text("Now, a question: I’m confused about the notion of uniform genericity mentioned in Proposition 3. It seems to be a property of a sequence of points ")#mi("x_n")#text(" rather than a single point ")#mi("x")#text(" (since the uniformity demanded is over ")#mi("n")#text(").")

#text("However, in the beginning of the proof of Proposition 1, it is mentioned that Egoroff’s theorem can be used to show that a large subset of ")#mi("G/\\Gamma")#text(" is uniformly generic. But what does it mean for individual points in ")#mi("G/\\Gamma")#text(" to be uniformly generic?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/15/254a-lecture-17-a-ratner-type-theorem-for-sl_2r-orbits/#comment-146335")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2012")])]

#text("Thanks for the corrections!")

#text("To be uniformly generic in a subset E of ")#mi("G/\\Gamma")#text(" means that the convergence of (15) is uniform in that subset E. (In the proposition, E was a countable set ")#mi("\\{x_n\\}")#text(", but when applying Egoroff’s theorem, E becomes the complement of a set of small measure.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2008/03/15/254a-lecture-17-a-ratner-type-theorem-for-sl_2r-orbits/#comment-146380")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2012")])]

#text("Ah, okay. This makes sense.")

#text("In this case, maybe you shouldn’t use the phrase “…on which the points are uniformly generic.” as you do in the beginning of the proof of Proposition 1. It gave me the impression that there is a meaningful notion of uniform genericity for single points.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2008/03/15/254a-lecture-17-a-ratner-type-theorem-for-sl_2r-orbits/#comment-147763")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2012")])]

#text("In equations (20) and (21), ")#mi("T")#text(" is taken to be a large time (large enough that the RHS comes close to the LHS as promised by the Birkhoff ergodic theorem).")

#text("However, we are using equation (19) to deduce (21), and (19) only seems to apply for ")#mi("t")#text(" within the range ")#mi("(1 - \\delta) T_n \\leq t \\leq T_n")#text(".")

#text("How do we reconcile these two things? It seems that we need to set ")#mi("T = T_n")#text(" for some ")#mi("n")#text(" to get the equation (21), but a priori we could have ")#mi("T_n \\leq 100")#text(" for all ")#mi("n")#text(", and this might not be large enough for Birkhoff’s ergodic theorem to make the two sides of (20) close to equal.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/15/254a-lecture-17-a-ratner-type-theorem-for-sl_2r-orbits/#comment-147812")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2012")])]

#text("The ")#mi("g_n")#text(" are converging to the identity, and so the ")#mi("T_n")#text(" must necessarily go to infinity (otherwise ")#mi("g_n^*")#text(" cannot reach the boundary ")#mi("\\partial B")#text(" of the unit ball).")
]
]
