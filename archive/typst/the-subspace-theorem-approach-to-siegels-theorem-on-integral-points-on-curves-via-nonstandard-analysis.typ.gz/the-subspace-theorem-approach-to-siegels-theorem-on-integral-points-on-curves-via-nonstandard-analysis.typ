// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/07/07/the-subspace-theorem-approach-to-siegels-theorem-on-integral-points-on-curves-via-nonstandard-analysis/
// Converted to Typst by tao2typ: "2026-10-14T15:19:06.846251+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The subspace theorem approach to Siegel’s theorem on integral points on curves via nonstandard analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The subspace theorem approach to Siegel’s theorem on integral points on curves via nonstandard analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 July 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/07/07/the-subspace-theorem-approach-to-siegels-theorem-on-integral-points-on-curves-via-nonstandard-analysis/")[#text("https://terrytao.wordpress.com/2014/07/07/the-subspace-theorem-approach-to-siegels-theorem-on-integral-points-on-curves-via-nonstandard-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{\\bar{{\\bf Q}}}")#text(" be the algebraic closure of ")#mi("{{\\bf Q}}")#text(", that is to say the field of ")#link("http://en.wikipedia.org/wiki/Algebraic_number")[#text("algebraic numbers")]#text(". We fix an embedding of ")#mi("{\\bar{{\\bf Q}}}")#text(" into ")#mi("{{\\bf C}}")#text(", giving rise to a complex absolute value ")#tao-math("{z \\mapsto \\left|z\\right|}", block: false)#text(" for algebraic numbers ")#mi("{z \\in \\bar{{\\bf Q}}}")#text(".")

#text("Let ")#mi("{\\alpha \\in \\bar{{\\bf Q}}}")#text(" be of degree ")#mi("{D > 1}")#text(", so that ")#mi("{\\alpha}")#text(" is irrational. A classical ")#link("http://en.wikipedia.org/wiki/Liouville%27s_theorem_(transcendence_theory)")[#text("theorem of Liouville")]#text(" gives the quantitative bound ")#metadata(none) <tao-b6b935d912fb48186808>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|\\alpha - \\frac{p}{q}\\right| \\geq c \\frac{1}{\\left|q\\right|^D}", block: true)]]

#text("for the irrationality of ")#mi("{\\alpha}")#text(" fails to be approximated by rational numbers ")#mi("{p/q}")#text(", where ")#mi("{c>0}")#text(" depends on ")#mi("{\\alpha,D}")#text(" but not on ")#mi("{p,q}")#text(". Indeed, if one lets ")#mi("{\\alpha = \\alpha_1, \\alpha_2, \\dots, \\alpha_D}")#text(" be the Galois conjugates of ")#mi("{\\alpha}")#text(", then the quantity ")#tao-math("{\\prod_{i=1}^D \\left|q \\alpha_i - p\\right|}", block: false)#text(" is a non-zero natural number divided by a constant, and so we have the trivial lower bound")

#align(center)[#tao-fit-display[#tao-math("\\prod_{i=1}^D \\left|q \\alpha_i - p\\right| \\geq c", block: true)]]

#text("from which the bound ")#link(<tao-b6b935d912fb48186808>)[#text("(1)")]#text(" easily follows. A well known corollary of the bound ")#link(<tao-b6b935d912fb48186808>)[#text("(1)")]#text(" is that ")#link("http://en.wikipedia.org/wiki/Liouville_number")[#text("Liouville numbers")]#text(" are automatically transcendental.")

#text("The ")#link("http://en.wikipedia.org/wiki/Thue%E2%80%93Siegel%E2%80%93Roth_theorem")[#text("famous theorem of Thue, Siegel and Roth")]#text(" improves the bound ")#link(<tao-b6b935d912fb48186808>)[#text("(1)")]#text(" to ")#metadata(none) <tao-a5822a8c8b00deb97c29>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|\\alpha - \\frac{p}{q}\\right| \\geq c \\frac{1}{\\left|q\\right|^{2+\\epsilon}}", block: true)]]

#text("for any ")#mi("{\\epsilon>0}")#text(" and rationals ")#mi("{\\frac{p}{q}}")#text(", where ")#mi("{c>0}")#text(" depends on ")#mi("{\\alpha,\\epsilon}")#text(" but not on ")#mi("{p,q}")#text(". Apart from the ")#mi("{\\epsilon}")#text(" in the exponent and the implied constant, this bound is optimal, as can be seen from ")#link("http://en.wikipedia.org/wiki/Dirichlet%27s_theorem_on_diophantine_approximation")[#text("Dirichlet’s theorem")]#text(". This theorem is a good example of the ")#emph[#text("ineffectivity phenomenon")]#text(" that affects a large portion of modern number theory: the implied constant in the ")#mi("{\\gg}")#text(" notation is known to be finite, but there is no explicit bound for it in terms of the coefficients of the polynomial defining ")#mi("{\\alpha}")#text(" (in contrast to ")#link(<tao-b6b935d912fb48186808>)[#text("(1)")]#text(", for which an effective bound may be easily established). This is ultimately due to the reliance on the “")#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/")[#text("dueling conspiracy")]#text("” (or “repulsion phenomenon”) strategy. We do not as yet have a good way to rule out ")#emph[#text("one")]#text(" counterexample to ")#link(<tao-a5822a8c8b00deb97c29>)[#text("(2)")]#text(", in which ")#mi("{\\frac{p}{q}}")#text(" is far closer to ")#mi("{\\alpha}")#text(" than ")#tao-math("{\\frac{1}{\\left|q\\right|^{2+\\epsilon}}}", block: false)#text("; however we can rule out ")#emph[#text("two")]#text(" such counterexamples, by playing them off of each other.")

#text("A powerful strengthening of the Thue-Siegel-Roth theorem is given by the ")#emph[#text("subspace theorem")]#text(", first proven ")#link("http://en.wikipedia.org/wiki/Subspace_theorem")[#text("by Schmidt")]#text(" and then generalised further by several authors. To motivate the theorem, first observe that the Thue-Siegel-Roth theorem may be rephrased as a bound of the form ")#metadata(none) <tao-db69c34ce14b8db6175f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left| \\alpha p - \\beta q \\right| \\times \\left| \\alpha^{\\prime} p - \\beta^{\\prime} q \\right| \\geq c (1 + \\left|p\\right| + \\left|q\\right|)^{-\\epsilon}", block: true)]]

#text("for any algebraic numbers ")#mi("{\\alpha,\\beta,\\alpha^{\\prime},\\beta^{\\prime}}")#text(" with ")#mi("{(\\alpha,\\beta)}")#text(" and ")#mi("{(\\alpha^{\\prime},\\beta^{\\prime})}")#text(" linearly independent (over the algebraic numbers), and any ")#mi("{(p,q) \\in {\\bf Z}^2}")#text(" and ")#mi("{\\epsilon>0}")#text(", with the exception when ")#mi("{\\alpha,\\beta}")#text(" or ")#mi("{\\alpha^{\\prime},\\beta^{\\prime}}")#text(" are rationally dependent (i.e. one is a rational multiple of the other), in which case one has to remove some lines (i.e. subspaces in ")#mi("{{\\bf Q}^2}")#text(") of rational slope from the space ")#mi("{{\\bf Z}^2}")#text(" of pairs ")#mi("{(p,q)}")#text(" to which the bound ")#link(<tao-db69c34ce14b8db6175f>)[#text("(3)")]#text(" does not apply (namely, those lines for which the left-hand side vanishes). Here ")#mi("{c>0}")#text(" can depend on ")#mi("{\\alpha,\\beta,\\alpha^{\\prime},\\beta^{\\prime},\\epsilon}")#text(" but not on ")#mi("{p,q}")#text(". More generally, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Schmidt subspace theorem)")]#text(" ")#metadata(none) <tao-581eaf4658d71e887559>#text(" Let ")#mi("{d}")#text(" be a natural number. Let ")#mi("{L_1,\\dots,L_d: \\bar{{\\bf Q}}^d \\rightarrow \\bar{{\\bf Q}}}")#text(" be linearly independent linear forms. Then for any ")#mi("{\\epsilon>0}")#text(", one has the bound")

#align(center)[#tao-fit-display[#tao-math("\\prod_{i=1}^d \\left|L_i(x)\\right| \\geq c (1 + \\left\\|x\\right\\| )^{-\\epsilon}", block: true)]]

#text("for all ")#mi("{x \\in {\\bf Z}^d}")#text(", outside of a finite number of proper subspaces of ")#mi("{{\\bf Q}^d}")#text(", where")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (x_1,\\dots,x_d) \\right\\| := \\max( \\left|x_1\\right|, \\dots, \\left|x_d\\right| )", block: true)]]

#text("and ")#mi("{c>0}")#text(" depends on ")#mi("{\\epsilon, d}")#text(" and the ")#mi("{\\alpha_{i,j}}")#text(", but is independent of ")#mi("{x}")#text(".")
]

#text("Being a generalisation of the Thue-Siegel-Roth theorem, it is unsurprising that the known proofs of the subspace theorem are also ineffective with regards to the constant ")#mi("{c}")#text(". (However, the number of exceptional subspaces may be bounded effectively; cf. the situation with the Skolem-Mahler-Lech theorem, discussed in ")#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/")[#text("this previous blog post")]#text(".) Once again, the lower bound here is basically sharp except for the ")#mi("{\\epsilon}")#text(" factor and the implied constant: given any ")#mi("{\\delta_1,\\dots,\\delta_d > 0}")#text(" with ")#mi("{\\delta_1 \\dots \\delta_d = 1}")#text(", a simple volume packing argument (the same one used to prove the ")#link("http://en.wikipedia.org/wiki/Dirichlet%27s_approximation_theorem")[#text("Dirichlet approximation theorem")]#text(") shows that for any sufficiently large ")#mi("{N \\geq 1}")#text(", one can find integers ")#mi("{x_1,\\dots,x_d \\in [-N,N]}")#text(", not all zero, such that")

#align(center)[#tao-fit-display[#tao-math("\\left|L_i(x)\\right| \\ll \\delta_i", block: true)]]

#text("for all ")#mi("{i=1,\\dots,d}")#text(". Thus one can get ")#tao-math("{\\prod_{i=1}^d \\left|L_i(x)\\right|}", block: false)#text(" comparable to ")#mi("{1}")#text(" in many different ways.")

#text("There are important generalisations of the subspace theorem to other number fields than the rationals (and to other valuations than the Archimedean valuation ")#tao-math("{z \\mapsto \\left|z\\right|}", block: false)#text("); we will develop one such generalisation below.")

#text("The subspace theorem is one of many ")#emph[#text("finiteness theorems")]#text(" in Diophantine geometry; in this case, it is the number of exceptional subspaces which is finite. It turns out that finiteness theorems are very compatible with the language of ")#link("http://en.wikipedia.org/wiki/Nonstandard_analysis")[#text("nonstandard analysis")]#text(". (See ")#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/")[#text("this previous blog post")]#text(" for a review of the basics of nonstandard analysis, and in particular for the nonstandard interpretation of asymptotic notation such as ")#mi("{\\ll}")#text(" and ")#mi("{o()}")#text(".) The reason for this is that a standard set ")#mi("{X}")#text(" is finite if and only if it contains no strictly nonstandard elements (that is to say, elements of ")#mi("{{}^* X \\backslash X}")#text("). This makes for a clean formulation of finiteness theorems in the nonstandard setting. For instance, the standard form of ")#link("http://en.wikipedia.org/wiki/B%C3%A9zout%27s_theorem")[#text("Bezout’s theorem")]#text(" asserts that if ")#mi("{P(x,y), Q(x,y)}")#text(" are coprime polynomials over some field, then the curves ")#mi("{\\{ (x,y): P(x,y) = 0\\}}")#text(" and ")#mi("{\\{ (x,y): Q(x,y)=0\\}}")#text(" intersect in only finitely many points. The nonstandard version of this is then")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Bezout’s theorem, nonstandard form)")]#text(" ")#metadata(none) <tao-105f181b577a2e5d3fa2>#text(" Let ")#mi("{P(x,y), Q(x,y)}")#text(" be standard coprime polynomials. Then there are no strictly nonstandard solutions to ")#mi("{P(x,y)=Q(x,y)=0}")#text(".")
]

#text("Now we reformulate Theorem ")#link(<tao-581eaf4658d71e887559>)[#text("1")]#text(" in nonstandard language. We need a definition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3 (General position)")]#text(" Let ")#mi("{K \\subset L}")#text(" be nested fields. A point ")#mi("{x = (x_1,\\dots,x_d)}")#text(" in ")#mi("{L^d}")#text(" is said to be in ")#emph[#mi("{K}")#text("-general position")]#text(" if it is not contained in any hyperplane of ")#mi("{L^d}")#text(" definable over ")#mi("{K}")#text(", or equivalently if one has")

#align(center)[#tao-fit-display[#mitex("a_1 x_1 + \\dots + a_d x_d = 0 \\iff a_1=\\dots = a_d = 0")]]

#text("for any ")#mi("{a_1,\\dots,a_d \\in K}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Schmidt subspace theorem, nonstandard version)")]#text(" ")#metadata(none) <tao-3070dbffae0571ffa68f>#text(" Let ")#mi("{d}")#text(" be a standard natural number. Let ")#mi("{L_1,\\dots,L_d: \\bar{{\\bf Q}}^d \\rightarrow \\bar{{\\bf Q}}}")#text(" be linearly independent standard linear forms. Let ")#mi("{x \\in {}^* {\\bf Z}^d}")#text(" be a tuple of nonstandard integers which is in ")#mi("{{\\bf Q}}")#text("-general position (in particular, this forces ")#mi("{x}")#text(" to be strictly nonstandard). Then one has")

#align(center)[#tao-fit-display[#tao-math("\\prod_{i=1}^d \\left|L_i(x)\\right| \\gg \\left\\|x\\right\\|^{-o(1)},", block: true)]]

#text("where we extend ")#mi("{L_i}")#text(" from ")#mi("{\\bar{{\\bf Q}}}")#text(" to ")#mi("{{}^* \\bar{{\\bf Q}}}")#text(" (and also similarly extend ")#mi("{\\| \\|}")#text(" from ")#mi("{{\\bf Z}^d}")#text(" to ")#mi("{{}^* {\\bf Z}^d}")#text(") in the usual fashion.")
]

#text("Observe that (as is usual when translating to nonstandard analysis) some of the epsilons and quantifiers that are present in the standard version become hidden in the nonstandard framework, being moved inside concepts such as “strictly nonstandard” or “general position”. We remark that as ")#mi("{x}")#text(" is in ")#mi("{{\\bf Q}}")#text("-general position, it is also in ")#mi("{\\bar{{\\bf Q}}}")#text("-general position (as an easy Galois-theoretic argument shows), and the requirement that the ")#mi("{L_1,\\dots,L_d}")#text(" are linearly independent is thus equivalent to ")#mi("{L_1(x),\\dots,L_d(x)}")#text(" being ")#mi("{\\bar{{\\bf Q}}}")#text("-linearly independent.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Verify that Theorem ")#link(<tao-581eaf4658d71e887559>)[#text("1")]#text(" and Theorem ")#link(<tao-3070dbffae0571ffa68f>)[#text("4")]#text(" are equivalent. (")#emph[#text("Hint:")]#text(" there are only countably many proper subspaces of ")#mi("{{\\bf Q}^d}")#text(".)")
]

#text("We will not prove the subspace theorem here, but instead focus on a particular application of the subspace theorem, namely to counting integer points on curves. In this ")#link("http://www.ams.org/mathscinet-getitem?mr=1891001")[#text("paper of Corvaja and Zannier")]#text(", the subspace theorem was used to give a new proof of the following ")#link("http://en.wikipedia.org/wiki/Siegel's_theorem_on_integral_points")[#text("basic result of Siegel")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Siegel’s theorem on integer points)")]#text(" ")#metadata(none) <tao-a6795d042134720097a4>#text(" Let ")#mi("{P \\in {\\bf Q}[x,y]}")#text(" be an irreducible polynomial of two variables, such that the affine plane curve ")#mi("{C := \\{ (x,y): P(x,y)=0\\}}")#text(" either has genus at least one, or has at least three points on the line at infinity, or both. Then ")#mi("{C}")#text(" has only finitely many integer points ")#mi("{(x,y) \\in {\\bf Z}^2}")#text(".")
]

#text("This is a finiteness theorem, and as such may be easily converted to a nonstandard form:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Siegel’s theorem, nonstandard form)")]#text(" ")#metadata(none) <tao-a9535faeb5bbf57dc637>#text(" Let ")#mi("{P \\in {\\bf Q}[x,y]}")#text(" be a standard irreducible polynomial of two variables, such that the affine plane curve ")#mi("{C := \\{ (x,y): P(x,y)=0\\}}")#text(" either has genus at least one, or has at least three points on the line at infinity, or both. Then ")#mi("{C}")#text(" does not contain any strictly nonstandard integer points ")#mi("{(x_*,y_*) \\in {}^* {\\bf Z}^2 \\backslash {\\bf Z}^2}")#text(".")
]

#text("Note that Siegel’s theorem can fail for genus zero curves that only meet the line at infinity at just one or two points; the key examples here are the graphs ")#mi("{\\{ (x,y): y - f(x) = 0\\}}")#text(" for a polynomial ")#mi("{f \\in {\\bf Z}[x]}")#text(", and the ")#link("http://en.wikipedia.org/wiki/Pell%27s_equation")[#text("Pell equation")]#text(" curves ")#mi("{\\{ (x,y): x^2 - dy^2 = 1 \\}}")#text(". Siegel’s theorem can be compared with the more difficult ")#link("http://en.wikipedia.org/wiki/Faltings%27_theorem")[#text("theorem of Faltings")]#text(", which establishes finiteness of rational points (not just integer points), but now needs the stricter requirement that the curve ")#mi("{C}")#text(" has genus at least two (to avoid the additional counterexample of elliptic curves of positive rank, which have infinitely many rational points).")

#text("The standard proofs of Siegel’s theorem rely on a combination of the Thue-Siegel-Roth theorem and a number of results on abelian varieties (notably the ")#link("http://en.wikipedia.org/wiki/Mordell%E2%80%93Weil_theorem")[#text("Mordell-Weil theorem")]#text("). The Corvaja-Zannier argument rebalances the difficulty of the argument by replacing the Thue-Siegel-Roth theorem by the more powerful subspace theorem (in fact, they need one of the stronger versions of this theorem alluded to earlier), while greatly reducing the reliance on results on abelian varieties. Indeed, for curves with three or more points at infinity, no theory from abelian varieties is needed at all, while for the remaining cases, one mainly needs the existence of the ")#link("http://en.wikipedia.org/wiki/Abel%E2%80%93Jacobi_map")[#text("Abel-Jacobi embedding")]#text(", together with a relatively elementary theorem of Chevalley-Weil which is used in the proof of the Mordell-Weil theorem, but is significantly easier to prove.")

#text("The Corvaja-Zannier argument (together with several further applications of the subspace theorem) is presented nicely in ")#link("http://www.ams.org/mathscinet-getitem?mr=2487729")[#text("this Bourbaki expose of Bilu")]#text(". To establish the theorem in full generality requires a certain amount of algebraic number theory machinery, such as the theory of valuations on number fields, or of relative discriminants between such number fields. However, the basic ideas can be presented without much of this machinery by focusing on simple special cases of Siegel’s theorem. For instance, we can handle irreducible cubics that meet the line at infinity at exactly three points ")#mi("{[1,\\alpha_1,0], [1,\\alpha_2,0], [1,\\alpha_3,0]}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Siegel’s theorem with three points at infinity)")]#text(" ")#metadata(none) <tao-69857c144f48fc4bb4bd>#text(" Siegel’s theorem holds when the irreducible polynomial ")#mi("{P(x,y)}")#text(" takes the form")

#align(center)[#tao-fit-display[#mitex("P(x,y) = (y - \\alpha_1 x) (y - \\alpha_2 x) (y - \\alpha_3 x) + Q(x,y)")]]

#text("for some quadratic polynomial ")#mi("{Q \\in {\\bf Q}[x,y]}")#text(" and some distinct algebraic numbers ")#mi("{\\alpha_1,\\alpha_2,\\alpha_3}")#text(".")
]

#emph[#text("Proof:")]#text(" We use the nonstandard formalism. Suppose for sake of contradiction that we can find a strictly nonstandard integer point ")#mi("{(x_*,y_*) \\in {}^* {\\bf Z}^2 \\backslash {\\bf Z}^2}")#text(" on a curve ")#mi("{C := \\{ (x,y): P(x,y)=0\\}}")#text(" of the indicated form. As this point is infinitesimally close to the line at infinity, ")#mi("{y_*/x_*}")#text(" must be infinitesimally close to one of ")#mi("{\\alpha_1,\\alpha_2,\\alpha_3}")#text("; without loss of generality we may assume that ")#mi("{y_*/x_*}")#text(" is infinitesimally close to ")#mi("{\\alpha_1}")#text(".")

#text("We now use a version of the ")#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/")[#text("polynomial method")]#text(", to find some polynomials of controlled degree that vanish to high order on the “arm” of the cubic curve ")#mi("{C}")#text(" that asymptotes to ")#mi("{[1,\\alpha_1,0]}")#text(". More precisely, let ")#mi("{D \\geq 3}")#text(" be a large integer (actually ")#mi("{D=3}")#text(" will already suffice here), and consider the ")#mi("{\\bar{{\\bf Q}}}")#text("-vector space ")#mi("{V}")#text(" of polynomials ")#mi("{R(x,y) \\in \\bar{{\\bf Q}}[x,y]}")#text(" of degree at most ")#mi("{D}")#text(", and of degree at most ")#mi("{2}")#text(" in the ")#mi("{y}")#text(" variable; this space has dimension ")#mi("{3D}")#text(". Also, as one traverses the arm ")#mi("{y/x \\rightarrow \\alpha_1}")#text(" of ")#mi("{C}")#text(", any polynomial ")#mi("{R}")#text(" in ")#mi("{V}")#text(" grows at a rate of at most ")#mi("{D}")#text(", that is to say ")#mi("{R}")#text(" has a pole of order at most ")#mi("{D}")#text(" at the point at infinity ")#mi("{[1,\\alpha_1,0]}")#text(". By performing Laurent expansions around this point (which is a non-singular point of ")#mi("{C}")#text(", as the ")#mi("{\\alpha_i}")#text(" are assumed to be distinct), we may thus find a basis ")#mi("{R_1, \\dots, R_{3D}}")#text(" of ")#mi("{V}")#text(", with the property that ")#mi("{R_j}")#text(" has a pole of order at most ")#mi("{D+1-j}")#text(" at ")#mi("{[1,\\alpha_1,0]}")#text(" for each ")#mi("{j=1,\\dots,3D}")#text(".")

#text("From the control of the pole at ")#mi("{[1,\\alpha_1,0]}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|R_j(x_*,y_*)\\right| \\ll (\\left|x_*\\right|+\\left|y_*\\right|)^{D+1-j}", block: true)]]

#text("for all ")#mi("{j=1,\\dots,3D}")#text(". The exponents here become negative for ")#mi("{j > D+1}")#text(", and on multiplying them all together we see that")

#align(center)[#tao-fit-display[#tao-math("\\prod_{j=1}^{3D} \\left|R_j(x_*,y_*)\\right| \\ll (\\left|x_*\\right|+\\left|y_*\\right|)^{3D(D+1) - \\frac{3D(3D+1)}{2}}.", block: true)]]

#text("This exponent is negative for ")#mi("{D}")#text(" large enough (or just take ")#mi("{D=3}")#text("). If we expand")

#align(center)[#tao-fit-display[#mitex("R_j(x_*,y_*) = \\sum_{a+b \\leq D; b \\leq 2} \\alpha_{j,a,b} x_*^a y_*^b")]]

#text("for some algebraic numbers ")#mi("{\\alpha_{j,a,b}}")#text(", then we thus have")

#align(center)[#tao-fit-display[#tao-math("\\prod_{j=1}^{3D} \\left|\\sum_{a+b \\leq D; b \\leq 2} \\alpha_{j,a,b} x_*^a y_*^b\\right| \\ll (\\left|x_*\\right|+\\left|y_*\\right|)^{-\\epsilon}", block: true)]]

#text("for some standard ")#mi("{\\epsilon>0}")#text(". Note that the ")#mi("{3D}")#text("-dimensional vectors ")#mi("{(\\alpha_{j,a,b})_{a+b \\leq D; b \\leq 2}}")#text(" are linearly independent in ")#mi("{{\\bf C}^{3D}}")#text(", because the ")#mi("{R_j}")#text(" are linearly independent in ")#mi("{V}")#text(". Applying the Schmidt subspace theorem in the contrapositive, we conclude that the ")#mi("{3D}")#text("-tuple ")#mi("{( x_*^a y_*^b )_{a+b \\leq D; b \\leq 2} \\in {}^* {\\bf Z}^{3D}}")#text(" is not in ")#mi("{{\\bf Q}}")#text("-general position. That is to say, one has a non-trivial constraint of the form ")#metadata(none) <tao-f75c6596507878933aa2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{a+b \\leq D; b \\leq 2} c_{a,b} x_*^a y_*^b = 0")]]

#text("for some standard rational coefficients ")#mi("{c_{a,b}}")#text(", not all zero. But, as ")#mi("{P}")#text(" is irreducible and cubic in ")#mi("{y}")#text(", it has no common factor with the standard polynomial ")#mi("{\\sum_{a+b \\leq D; b \\leq 2} c_{a,b} x^a y^b}")#text(", so by Bezout’s theorem (Theorem ")#link(<tao-105f181b577a2e5d3fa2>)[#text("2")]#text(") the constraint ")#link(<tao-f75c6596507878933aa2>)[#text("(4)")]#text(" only has standard solutions, contradicting the strictly nonstandard nature of ")#mi("{(x_*,y_*)}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Rewrite the above argument so that it makes no reference to nonstandard analysis. (In this case, the rewriting is quite straightforward; however, there will be a subsequent argument in which the standard version is significantly messier than the nonstandard counterpart, which is the reason why I am working with the nonstandard formalism in this blog post.)")
]

#text("A similar argument works for higher degree curves that meet the line at infinity in three or more points, though if the curve has singularities at infinity then it becomes convenient to rely on the ")#link("http://en.wikipedia.org/wiki/Riemann-Roch_theorem")[#text("Riemann-Roch theorem")]#text(" to control the dimension of the analogue of the space ")#mi("{V}")#text(". Note that when there are only two or fewer points at infinity, though, one cannot get the negative exponent of ")#mi("{-\\epsilon}")#text(" needed to usefully apply the subspace theorem. To deal with this case we require some additional tricks. For simplicity we focus on the case of ")#link("http://en.wikipedia.org/wiki/Mordell_curve")[#text("Mordell curves")]#text(", although it will be convenient to work with more general ")#link("http://en.wikipedia.org/wiki/Number_field")[#text("number fields")]#text(" ")#mi("{{\\bf Q} \\subset K \\subset \\bar{{\\bf Q}}}")#text(" than the rationals:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8 (Siegel’s theorem for Mordell curves)")]#text(" ")#metadata(none) <tao-9fb8ab2285854be222da>#text(" Let ")#mi("{k}")#text(" be a non-zero integer. Then there are only finitely many integer solutions ")#mi("{(x,y) \\in {\\bf Z}^2}")#text(" to ")#mi("{y^2 - x^3 = k}")#text(". More generally, for any number field ")#mi("{K}")#text(", and any nonzero ")#mi("{k \\in K}")#text(", there are only finitely many algebraic integer solutions ")#mi("{(x,y) \\in {\\mathcal O}_K^2}")#text(" to ")#mi("{y^2-x^3=k}")#text(", where ")#mi("{{\\mathcal O}_K}")#text(" is the ring of algebraic integers in ")#mi("{K}")#text(".")
]

#text("Again, we will establish the nonstandard version. We need some additional notation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 9")]

#list(
[#text("We define an ")#emph[#text("almost rational integer")]#text(" to be a nonstandard ")#mi("{x \\in {}^* {\\bf Q}}")#text(" such that ")#mi("{Mx \\in {}^* {\\bf Z}}")#text(" for some standard positive integer ")#mi("{M}")#text(", and write ")#mi("{{\\bf Q} {}^* {\\bf Z}}")#text(" for the ")#mi("{{\\bf Q}}")#text("-algebra of almost rational integers.")],
[#text("If ")#mi("{K}")#text(" is a standard number field, we define an ")#emph[#text("almost ")#mi("{K}")#text("-integer")]#text(" to be a nonstandard ")#mi("{x \\in {}^* K}")#text(" such that ")#mi("{Mx \\in {}^* {\\mathcal O}_K}")#text(" for some standard positive integer ")#mi("{M}")#text(", and write ")#mi("{K {}^* {\\bf Z} = K {\\mathcal O}_K}")#text(" for the ")#mi("{K}")#text("-algebra of almost ")#mi("{K}")#text("-integers.")],
[#text("We define an ")#emph[#text("almost algebraic integer")]#text(" to be a nonstandard ")#mi("{x \\in {}^* {\\bar Q}}")#text(" such that ")#mi("{Mx}")#text(" is a nonstandard algebraic integer for some standard positive integer ")#mi("{M}")#text(", and write ")#mi("{\\bar{{\\bf Q}} {}^* {\\bf Z}}")#text(" for the ")#mi("{\\bar{{\\bf Q}}}")#text("-algebra of almost algebraic integers.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 10 (Siegel for Mordell, nonstandard version)")]#text(" ")#metadata(none) <tao-e1cd25577662126f1b0e>#text(" Let ")#mi("{k}")#text(" be a non-zero standard algebraic number. Then the curve ")#mi("{\\{ (x,y): y^2 - x^3 = k \\}}")#text(" does not contain any strictly nonstandard almost algebraic integer point.")
]

#text("Another way of phrasing this theorem is that if ")#mi("{x,y}")#text(" are strictly nonstandard almost algebraic integers, then ")#mi("{y^2-x^3}")#text(" is either strictly nonstandard or zero.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Verify that Theorem ")#link(<tao-9fb8ab2285854be222da>)[#text("8")]#text(" and Theorem ")#link(<tao-e1cd25577662126f1b0e>)[#text("10")]#text(" are equivalent.")
]

#text("Due to all the ineffectivity, our proof does not supply any bound on the solutions ")#mi("{x,y}")#text(" in terms of ")#mi("{k}")#text(", even if one removes all references to nonstandard analysis. It is a ")#link("http://en.wikipedia.org/wiki/Marshall_Hall%27s_conjecture")[#text("conjecture of Hall")]#text(" (a special case of the notorious ")#link("http://en.wikipedia.org/wiki/Abc_conjecture")[#text("ABC conjecture")]#text(") that one has the bound ")#tao-math("{\\left|x\\right| \\ll_\\epsilon \\left|k\\right|^{2+\\epsilon}}", block: false)#text(" for all ")#mi("{\\epsilon>0}")#text(" (or equivalently ")#tao-math("{\\left|y\\right| \\ll_\\epsilon \\left|k\\right|^{3+\\epsilon}}", block: false)#text("), but even the weaker conjecture that ")#mi("{x,y}")#text(" are of polynomial size in ")#mi("{k}")#text(" is open. (The best known bounds are of exponential nature, and are proven using a version of Baker’s method: see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=1288309")[#text("this text of Sprindzuk")]#text(".)")

#text("A direct repetition of the arguments used to prove Theorem ")#link(<tao-69857c144f48fc4bb4bd>)[#text("7")]#text(" will not work here, because the Mordell curve ")#mi("{\\{ (x,y): y^2 - x^3 = k \\}}")#text(" only hits the line at infinity at one point, ")#mi("{[0,1,0]}")#text(". To get around this we will exploit the fact that the Mordell curve is an elliptic curve and thus has a group law on it. We will then divide all the integer points on this curve by two; as elliptic curves have four 2-torsion points, this will end up placing us in a situation like Theorem ")#link(<tao-69857c144f48fc4bb4bd>)[#text("7")]#text(", with four points at infinity. However, there is an obstruction: it is not obvious that dividing an integer point on the Mordell curve by two will produce another integer point. However, this is essentially true (after enlarging the ring of integers slightly) thanks to a general principle of Chevalley and Weil, which can be worked out explicitly in the case of division by two on Mordell curves by relatively elementary means (relying mostly on unique factorisation of ideals of algebraic integers). We give the details below the fold.")

#heading(level: 1)[#strong[#text(" — 1. Dividing by two on the Mordell curve — ")]]

#text("This section will be elementary (in the sense that the arguments may be phrased in the first-order language of rings), and so it will make no difference whether we are working in the standard or nonstandard formalism. As such, we make no reference to nonstandard analysis here.")

#text("As is well known, any elliptic curve ")#mi("{C}")#text(" (after adjoining a point ")#mi("{0}")#text(" at infinity) has a group law ")#mi("{+}")#text(", with ")#mi("{P+Q+R=0}")#text(" whenever ")#mi("{P,Q,R}")#text(" are distinct collinear points on ")#mi("{C}")#text(", or ")#mi("{2P+R=0}")#text(" if the tangent line at ")#mi("{P}")#text(" meets ")#mi("{C}")#text(" at another point ")#mi("{R}")#text(". In the case of the Mordell curve ")#mi("{C = \\{ (x,y): y^2 - x^3 = k \\}}")#text(", the double ")#mi("{2(x,y) = (x_2,y_2)}")#text(" of a point ")#mi("{(x,y) \\in C}")#text(" is given by the formulae ")#metadata(none) <tao-40cb4b342f4525e4b53e>

#tao-aligned(keep: true)[


#tao-math("\\lambda  & := \\frac{3x^2}{2y}", block: true, numbering: n => [#text("(5)")])



#tao-math("x_2  & := \\lambda^2 - 2x", block: true)



#tao-math("y_2  & := \\lambda (x-x_2)-y", block: true)
]

#text("as long as ")#mi("{y \\neq 0}")#text(". (For ")#mi("{y=0}")#text(", the double will be the point at infinity.) Geometrically, ")#mi("{\\lambda}")#text(" is the slope of the tangent line to ")#mi("{C}")#text(" at ")#mi("{(x,y)}")#text(".")

#text("Over the complex numbers, the constraint ")#mi("{y \\neq 0}")#text(" removes three points ")#mi("{(-k^{1/3},0), (-\\omega k^{1/3},0), (-\\omega^2 k^{1/3},0)}")#text(" from ")#mi("{C}")#text(", where ")#mi("{\\omega := e^{2\\pi i/3}}")#text(" is the standard cube root of unity. This thrice punctured curve is no longer an affine plane curve, but one can make it affine again by incorporating ")#mi("{\\lambda}")#text(" as another coordinate, giving rise to the lifted curve")

#align(center)[#tao-fit-display[#mitex("C^{\\prime} := \\{ (x,y,\\lambda): y^2 -x^3 = k; 2y \\lambda = 3x^2 \\},")]]

#text("and the doubling map ")#mi("{P \\mapsto 2P}")#text(" lifts to the polynomial map ")#mi("{f: C^{\\prime} \\rightarrow C}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("f( x, y, \\lambda ) := ( \\lambda^2 - 2x, \\lambda(x-(\\lambda^2-2x)) - y).")]]

#text("Over the complex numbers, it is well known that the elliptic curve ")#mi("{C}")#text(" is isomorphic as a group to the torus ")#mi("{({\\bf R}/{\\bf Z})^2}")#text(", which implies that the map ")#mi("{f}")#text(" is four-to-one. Now we consider the inversion problem explicitly: given a point ")#mi("{(x_2,y_2) \\in C}")#text(", find a point ")#mi("{(x,y,\\lambda) \\in {\\bf C}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("x_2 = \\lambda^2 - 2x")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("y_2 := \\lambda (x-x_2)-y.")]]

#text("We would also like to avoid using division as much as possible, since in our application ")#mi("{(x_2,y_2)}")#text(" will be an integer point, and we would like ")#mi("{x,y,\\lambda}")#text(" to also be “close” to being integers too (in a sense to be made precise later). We can rearrange the above two equations as ")#metadata(none) <tao-ec31682fde561917952f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("x = \\frac{\\lambda^2-x_2}{2}")]]

#text("and ")#metadata(none) <tao-03e0769b10886aef0ff2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("y = \\lambda(x-x_2)-y_2")]]

#text("and so we see that to find ")#mi("{(x,y,\\lambda)}")#text(", it suffices to find ")#mi("{\\lambda}")#text(", and furthermore if ")#mi("{x_2,y_2,\\lambda}")#text(" are “close” to integers, then ")#mi("{x,y}")#text(" are close to integers also (up to a single division by two). One can also check from a routine computation that if ")#link(<tao-ec31682fde561917952f>)[#text("(6)")]#text(", ")#link(<tao-03e0769b10886aef0ff2>)[#text("(7)")]#text(", ")#link(<tao-40cb4b342f4525e4b53e>)[#text("(5)")]#text(" hold, then we have ")#mi("{y^2-x^3=y_2^2 - x_2^3}")#text(", so that ")#mi("{(x,y,\\lambda)}")#text(" indeed lies in ")#mi("{C^{\\prime}}")#text(".")

#text("If one inserts ")#link(<tao-ec31682fde561917952f>)[#text("(6)")]#text(", ")#link(<tao-03e0769b10886aef0ff2>)[#text("(7)")]#text(" into ")#link(<tao-40cb4b342f4525e4b53e>)[#text("(5)")]#text(", one arrives at the quartic equation ")#metadata(none) <tao-9f102fe3a7d618f99607>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\lambda^4 - 6 x_2 \\lambda^2 - 8 \\lambda y_2 - 3 x_2^2 = 0.")]]

#text("One could solve this equation by the general quartic formula, but actually the formula simplifies substantially for this specific quartic equation, and can be obtained as follows. The Mordell equation ")#mi("{y_2^2 - x_2^3 = k}")#text(" can be rewritten as")

#align(center)[#tao-fit-display[#mitex("y_2^2 = (x_2 + k^{1/3}) (x_2 + \\omega k^{1/3}) (x_2 + \\omega^2 k^{1/3}).")]]

#text("We can take square roots and then write")

#align(center)[#tao-fit-display[#mitex("y_2 = r s t")]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("r^2  & = x_2 + k^{1/3}", block: true)



#tao-math("s^2  & = x_2 + \\omega k^{1/3}", block: true)



#tao-math("t^2  & = x_2 + \\omega^2 k^{1/3}.", block: true)
]

#text("As each ")#mi("{r,s,t}")#text(" is determined up to sign, and ")#mi("{rst}")#text(" is fixed, there are exactly four choices for ")#mi("{(r,s,t)}")#text(" here (even when ")#mi("{y_2}")#text(" vanishes). For any such choice, if one sets ")#metadata(none) <tao-f41069a34e2ddd1a974c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\lambda := r+s+t,")]]

#text("then on squaring and rearranging we have")

#align(center)[#tao-fit-display[#mitex("\\lambda^2 - 3x_2 = 2(rs + st + tr)")]]

#text("and on squaring again")

#align(center)[#tao-fit-display[#mitex("\\lambda^4 - 6x_2 \\lambda^2 + 9 x_2^2 = 4(rs + st + tr)^2;")]]

#text("since")

#align(center)[#tao-fit-display[#mitex("(rs + st + tr)^2 = 3x_2^2 + 2 rst (r+s+t)")]]

#text("one soon sees that ")#link(<tao-9f102fe3a7d618f99607>)[#text("(8)")]#text(" holds. Thus we have found the four solutions ")#mi("{(x,y,\\lambda)}")#text(" to the equation ")#mi("{f(x,y,\\lambda) = (x_2,y_2)}")#text(" by choosing the square roots ")#mi("{r,s,t}")#text(" of ")#mi("{x_2+k^{1/3}, x_2+\\omega k^{1/3}, x_2+\\omega^2 k^{1/3}}")#text(", and then defining ")#mi("{\\lambda}")#text(" by ")#link(<tao-f41069a34e2ddd1a974c>)[#text("(9)")]#text(" and ")#mi("{x,y}")#text(" by ")#link(<tao-ec31682fde561917952f>)[#text("(6)")]#text(", ")#link(<tao-03e0769b10886aef0ff2>)[#text("(7)")]#text(". In particular, if ")#mi("{x_2,y_2}")#text(" are (rational) integers, then ")#mi("{r,s,t,\\lambda}")#text(" are algebraic integers, and ")#mi("{x,y}")#text(" are algebraic integers divided by two.")

#heading(level: 1)[#strong[#text(" — 2. The Chevalley-Weil principle — ")]]

#text("The ")#emph[#text("Chevalley-Weil principle")]#text(" asserts, roughly speaking, that if one has a “finite cover” of one affine variety ")#mi("{V}")#text(" by another ")#mi("{W}")#text(", with the varieties and covering maps defined over the rationals, then every integer point in ")#mi("{V}")#text(" lifts to a “near”-integer point of ")#mi("{W}")#text(". (There is also a version for projective varieties, which I will not discuss here; one can also generalise integers and rationals to other number fields.) To make the notion of “finite cover” precise, one needs the notion of an ")#link("http://en.wikipedia.org/wiki/Etale_morphism")[#text("etale morphism")]#text("; to make the notion of “near”-integer precise, we can use the notion of almost algebraic integer. We will not formalise the principle in full generality here; see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=715605")[#text("this text of Lang")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1745599")[#text("this text of Hindry-Silverman")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1757192")[#text("this text of Serre")]#text(", or ")#link("http://www.ams.org/mathscinet-getitem?mr=2216774")[#text("this text of Bombieri and Gubler")]#text(", for a precise statement.")

#text("Here, we will focus on simple special cases of the Chevalley-Weil principle, in which one can work “by hand” using quite classical methods from algebraic number theory. We begin with a very elementary example, which in some sense goes all the way back to Diophantus himself:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 11 (Baby case of Chevalley-Weil)")]#text(" Let ")#mi("{k}")#text(" be a non-zero integer, and let ")#mi("{(x,y) \\in {\\bf Z}^2}")#text(" be such that ")#mi("{y^2 = x(x+k)}")#text(". Then ")#mi("{x,x+k}")#text(" are “nearly perfect squares” in the sense that one has ")#mi("{x = au^2}")#text(", ")#mi("{x+k = bv^2}")#text(" for some integers ")#mi("{u,v,a,b}")#text(" with ")#mi("{a,b}")#text(" dividing ")#mi("{k}")#text(".")
]

#text("To interpret this result as a special case of the Chevalley-Weil principle, we take ")#mi("{V}")#text(" to be the affine plane curve ")#mi("{\\{ (x,y): y^2 = x(x+k)\\}}")#text(", ")#mi("{W}")#text(" to be the affine curve ")#mi("{\\{ (x,r,s): r^2 = x; s^2 = x+k \\}}")#text(", with covering map ")#mi("{(x,r,s) \\mapsto (x,rs)}")#text("; thus ")#mi("{W}")#text(" is a double cover of ")#mi("{V}")#text(", and the theorem is asserting that integer points in ")#mi("{V}")#text(" are covered by near-integer points in ")#mi("{W}")#text(" (up to square roots of factors of ")#mi("{k}")#text(").")

#text("By transfer, the above theorem also applies in the setting where ")#mi("{x,y}")#text(" are non-standard integers and ")#mi("{k}")#text(" remains standard; in that case, ")#mi("{u,v}")#text(" now become nonstandard also, but ")#mi("{a,b}")#text(" remain standard. In particular, ")#mi("{\\pm x^{1/2} = \\pm a^{1/2} u}")#text(" and ")#mi("{\\pm (x+k)^{1/2} = \\pm b^{1/2} v}")#text(" become almost algebraic integers.")

#emph[#text("Proof:")]#text(" We can assume that ")#mi("{y}")#text(", and hence ")#mi("{x}")#text(" and ")#mi("{x+k}")#text(", are non-zero, since the ")#mi("{y=0}")#text(" case is easily verified. We use the fundamental theorem of arithmetic to factor ")#mi("{y}")#text(" into primes ")#mi("{y = \\pm p_1^{c_1} \\dots p_r^{c_r}}")#text(" for some distinct primes ")#mi("{p_1,\\dots,p_r}")#text(" and positive natural numbers ")#mi("{c_1,\\dots,c_r}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("x(x+k) = p_1^{2c_1} \\dots p_r^{2c_r}.")]]

#text("On the other hand, the greatest common divisor of ")#mi("{x}")#text(" and ")#mi("{x+k}")#text(" is a divisor of ")#mi("{k}")#text(". From this, we see that for each prime ")#mi("{p_i}")#text(" not dividing ")#mi("{k}")#text(", ")#mi("{p_i}")#text(" will divide one of ")#mi("{x,x+k}")#text(" exactly ")#mi("{2c_i}")#text(" times, and not divide the other, whereas for primes ")#mi("{p_i}")#text(" dividing ")#mi("{k}")#text(", ")#mi("{p_i}")#text(" will either divide each of ")#mi("{x,x+k}")#text(" an even number of times, or an odd number of times. Collecting terms (including the units ")#mi("{\\pm 1}")#text(" in the prime factorisations of ")#mi("{x,x+k}")#text(") to form ")#mi("{a,b,u,v}")#text(", the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" One can reformulate the above argument by using the ")#mi("{p}")#text("-adic valuations ")#mi("{||_p}")#text(" instead of the fundamental theorem of arithmetic. That formulation is more convenient when proving the Chevalley-Weil theorem in full generality.")
]

#text("Now we give a variant of the above theorem which is of relevance for our application. It will be convenient to phrase the variant in the nonstandard setting.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 12 (Toddler case of Chevalley-Weil)")]#text(" ")#metadata(none) <tao-d142bda3c12cdab2d45d>#text(" Let ")#mi("{k}")#text(" be a non-zero standard algebraic number, and let ")#mi("{(x,y)\\in (\\bar{{\\bf Q}} {}^* {\\bf Z})^2}")#text(" be a pair of almost algebraic integers such that ")#mi("{y^2-x^3=k}")#text(". Then we can write ")#mi("{x+k^{1/3} = r^2}")#text(", ")#mi("{x + \\omega k^{1/3} = s^2}")#text(", ")#mi("{x + \\omega k^{1/3} = t^2}")#text(", where ")#mi("{r,s,t}")#text(" are almost algebraic integers.")
]

#text("This is a case of the Chevalley-Weil principle with ")#mi("{V = \\{ (x,y): y^2 - x^3 = k\\}}")#text(", ")#mi("{W = \\{ (x,r,s,t): r^2 = x+k^{1/3}, s^2 = x+\\omega k^{1/3}, t^2 = x +\\omega^2 k^{1/3} \\}}")#text(", and covering map ")#mi("{(x,r,s,t) \\mapsto (x,rst)}")#text(". The claim is then that any pre-image of an almost algebraic integer point is again an almost algebraic integer point.")

#emph[#text("Proof:")]#text(" We use essentially the same argument as the previous theorem, but in the language of ideals rather than numbers. The case ")#mi("{y=0}")#text(" is easy, so we assume that ")#mi("{y \\neq 0}")#text(". By choosing a suitably large standard number field ")#mi("{K}")#text(", we may assume that ")#mi("{Mx, My, Mk^{1/3}, \\omega M\\omega k^{1/3}, M \\omega^2 k^{1/3}}")#text(" are nonstandard algebraic integers in ")#mi("{{}^* {\\mathcal O}_K}")#text(" for some standard ")#mi("{M \\geq 1}")#text(". As is well known, the ring of algebraic integers ")#mi("{{\\mathcal O}_K}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Dedekind_domain")[#text("Dedekind domain")]#text(", so that one has unique factorisation of ideals. In particular, the nonstandard ")#link("http://en.wikipedia.org/wiki/Principal_ideal")[#text("principal ideal")]#text(" ")#mi("{(My)}")#text(", which is an ideal of ")#mi("{{}^* {\\mathcal O}_K}")#text(", factorises as a nonstandard product")

#align(center)[#tao-fit-display[#mitex("(My) = P_1^{c_1} \\dots P_r^{c_r}")]]

#text("for some distinct nonstandard prime ideals ")#mi("{P_1,\\dots,P_r}")#text(" (not necessarily principal), a nonstandard natural number ")#mi("{r}")#text(", and positive nonstandard natural numbers ")#mi("{c_1,\\dots,c_r}")#text(". Since ")#mi("{y^2 = (x+k^{1/3}) (x+\\omega k^{1/3}) (x+\\omega^2 k^{1/3})}")#text(", we conclude in particular that")

#align(center)[#tao-fit-display[#mitex("(Mx+Mk^{1/3}) (Mx+M\\omega k^{1/3}) (Mx+M\\omega^2 k^{1/3}) = (M) P_1^{2c_1} \\dots P_r^{2c_r}.")]]

#text("If (say) ")#mi("{(Mx+Mk^{1/3})}")#text(" and ")#mi("{(M\\omega x+Mk^{1/3})}")#text(" are both divisible by a prime ideal ")#mi("{P_i}")#text(", then ")#mi("{(Mk^{1/3} - M\\omega k^{1/3})}")#text(" is also; but the latter ideal is standard, and so such ")#mi("{P_i}")#text(" are standard, and furthermore the number of such ")#mi("{P_i}")#text(" is bounded. Similarly for other pairs from ")#mi("{(Mx+Mk^{1/3}), (Mx+M\\omega k^{1/3}), (Mx+M\\omega^2 k^{1/3})}")#text(". Thus for all other ")#mi("{P_i}")#text(", the ")#mi("{P_i}")#text(" divide exactly one of ")#mi("{(x+k^{1/3}), (x+\\omega k^{1/3}), (x+\\omega^2 k^{1/3})}")#text(" an even number of times, and do not divide the other two ideals. This implies a factorisation of the form")

#tao-aligned(keep: true)[


#tao-math("(Mx+Mk^{1/3})  & = A U^2;", block: true)



#tao-math("(Mx+M\\omega k^{1/3})  & = B V^2;", block: true)



#tao-math("(Mx+M\\omega^2 k^{1/3})  & = C W^2", block: true)
]

#text("where ")#mi("{U,V,W}")#text(" are nonstandard ideals and ")#mi("{A,B,C}")#text(" are standard ideals. From a well known geometry of numbers argument, the ")#link("http://en.wikipedia.org/wiki/Class_group")[#text("class group")]#text(" of ")#mi("{K}")#text(" is finite, which implies that any nonstandard ideal can be expressed as the product of a nonstandard principal ideal and a standard ")#link("http://en.wikipedia.org/wiki/Fractional_ideal")[#text("fractional ideal")]#text(". Thus we may write")

#align(center)[#tao-fit-display[#mitex("(x+k^{1/3}) = A^{\\prime} (u)^2; (x+\\omega k^{1/3}) = B^{\\prime} (v)^2; \\quad (x+\\omega^2 k^{1/3}) = C^{\\prime} (w)^2")]]

#text("where ")#mi("{A^{\\prime},B^{\\prime},C^{\\prime}}")#text(" are now standard fractional ideals. However, the ratio of two principal ideals is a principal fractional ideal, and thus ")#mi("{A^{\\prime} = (a^{\\prime})}")#text(", ")#mi("{B^{\\prime} = (b^{\\prime})}")#text(", ")#mi("{C^{\\prime} = (c^{\\prime})}")#text(" for some standard ")#mi("{a^{\\prime},b^{\\prime},c^{\\prime} \\in K}")#text(". In other words, we have")

#align(center)[#tao-fit-display[#mitex("x+k^{1/3} = e a^{\\prime} u^2; x+\\omega k^{1/3} = fb^{\\prime} v^2; \\quad x+\\omega^2 k^{1/3} = gc^{\\prime} w^2")]]

#text("for some nonstandard ")#link("http://en.wikipedia.org/wiki/Unit_(ring_theory)")[#text("units")]#text(" ")#mi("{e,f,g}")#text(". But from")

#text("\\begin")

#metadata(none) <tao-7cf6b0597fe4e3cb3559>#text(" Let ")#mi("{k}")#text(" be a standard non-zero algebraic number, and let ")#mi("{C^{\\prime}}")#text(" be the affine curve")

#align(center)[#tao-fit-display[#mitex("C^{\\prime} := \\{ (x,y,\\lambda): y^2 -x^3 = k; 2y \\lambda = 3x^2 \\},")]]

#text("Then ")#mi("{C^{\\prime}}")#text(" does not contain any strictly nonstandard almost algebraic integer point ")#mi("{(x,y,\\lambda)}")#text(".")

#text("Indeed, Theorem ")#link(<tao-d142bda3c12cdab2d45d>)[#text("12")]#text(" and the calculations from the previous section reveal that if the curve ")#mi("{\\{ (x,y): x^2 - y^3 \\}}")#text(" contains a strictly nonstandard almost algebraic integer point, then the lifted curve ")#mi("{C^{\\prime}}")#text(" does also.")

#text("The argument from Theorem ")#link(<tao-69857c144f48fc4bb4bd>)[#text("7")]#text(" can be adapted without much difficulty to show that ")#mi("{C^{\\prime}}")#text(" does not contain any strictly nonstandard point in ")#mi("{{}^* {\\bf Z}^3}")#text(". However to work with almost algebraic integers instead of nonstandard integers, we need to extend the subspace theorem to this setting, a topic to which we now turn.")

#heading(level: 1)[#strong[#text(" — 3. The subspace theorem in number fields — ")]]

#text("If ")#mi("{x \\in {\\bf Q} {}^* {\\bf Z}}")#text(" is a nonstandard almost rational integer which is non-zero, then one clearly has ")#tao-math("{\\left|x\\right| \\gg 1}", block: false)#text("; this is (up to the ")#mi("{o(1)}")#text(" exponent) the ")#mi("{d=1}")#text(" case of the subspace theorem, Theorem ")#link(<tao-3070dbffae0571ffa68f>)[#text("4")]#text(".")

#text("Now suppose that ")#mi("{x \\in K {}^* {\\bf Z}}")#text(" is a non-zero nonstandard almost algebraic integer for some standard number field ")#mi("{K}")#text(". Then it is no longer necessarily the case that ")#tao-math("{\\left|x\\right| \\gg 1}", block: false)#text("; for instance, this would imply that")

#align(center)[#tao-fit-display[#tao-math("\\left| p - \\sqrt{2} q\\right| \\gg 1", block: true)]]

#text("for any nonstandard integers ")#mi("{p,q}")#text(", which contradicts the Dirichlet approximation theorem. However, if ")#mi("{K}")#text(" is a Galois extension of ")#mi("{{\\bf Q}}")#text(", and ")#mi("{G = \\text{Gal}(K/Q)}")#text(" is the Galois group, then it is still true that")

#align(center)[#tao-fit-display[#tao-math("\\prod_{\\sigma \\in G} \\left|\\sigma(x)\\right| \\gg 1", block: true)]]

#text("since ")#mi("{\\prod_{\\sigma \\in G} \\sigma(x)}")#text(" is a non-zero element of ")#mi("{{\\bf Q} {}^* {\\bf Z}}")#text(".")

#text("In a similar spirit, we claim the following generalisation of the subspace theorem to number fields. If ")#mi("{x}")#text(" is an algebraic number of degree ")#mi("{D}")#text(", we write")

#align(center)[#tao-fit-display[#tao-math("\\left\\| x \\right\\|_\\infty := (\\left|x^{(1)}\\right| \\dots \\left|x^{(D)}\\right|)^{1/D}", block: true)]]

#text("for the norm at ")#mi("{\\infty}")#text(", where ")#mi("{x^{(1)},\\dots,x^{(D)}}")#text(" are the Galois conjugates of ")#mi("{x}")#text(", and for ")#mi("{(x_1,\\dots,x_d) \\in \\bar{{\\bf Q}}^d}")#text(", we write")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (x_1,\\dots,x_d) \\right\\|_\\infty := \\max( \\left\\|x_1\\right\\|_\\infty, \\dots, \\left\\|x_d\\right\\|_\\infty ).", block: true)]]

#text("Clearly this norm is Galois-invariant.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 13 (Schmidt subspace theorem for number fields)")]#text(" ")#metadata(none) <tao-cdc6f4c3662a92d1a3ce>#text(" Let ")#mi("{d}")#text(" be a standard natural number, and let ")#mi("{K}")#text(" be a standard Galois extension of ")#mi("{{\\bf Q}}")#text(", with Galois group ")#mi("{G := \\text{Gal}(K/{\\bf Q})}")#text(". For each ")#mi("{\\sigma \\in G}")#text(", let ")#mi("{L_{\\sigma,1},\\dots,L_{\\sigma,d}: \\bar{{\\bf Q}}^d \\rightarrow \\bar{{\\bf Q}}}")#text(" be linearly independent standard linear forms. Let ")#mi("{x \\in (K {}^* {\\bf Z})^d}")#text(" be in ")#mi("{K}")#text("-general position. Then one has")

#align(center)[#tao-fit-display[#tao-math("\\prod_{\\sigma \\in G} \\prod_{i=1}^d \\left|\\sigma( L_{\\sigma,i}(x))\\right| \\gg \\left\\|x\\right\\|_\\infty^{-o(1)},", block: true)]]

#text("where ")#mi("{\\sigma}")#text(" acts on ")#mi("{K {}^* {\\bf Z}}")#text(" (and hence on ")#mi("{(K {}^* {\\bf Z})^d}")#text(") in the obvious fashion.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" State a logically equivalent standard form of Theorem ")#link(<tao-cdc6f4c3662a92d1a3ce>)[#text("13")]#text(" (analogous to Theorem ")#link(<tao-581eaf4658d71e887559>)[#text("1")]#text("), and prove the logical equivalence.")
]

#text("Theorem ")#link(<tao-cdc6f4c3662a92d1a3ce>)[#text("13")]#text(" (in the logically equivalent standard form) was proven ")#link("https://terrytao.wordpress.com/2014/07/07/the-subspace-theorem-approach-to-siegels-theorem-on-integral-points-on-curves-via-nonstandard-analysis/?p-adic Thue-Siegel-Roth??")[#text("by Schlickewei")]#text(" (who also handled more general valuations than the complex absolute value ")#tao-math("{z \\mapsto \\left|z\\right|}", block: false)#text(", and also allowed the coefficients of ")#mi("{q}")#text(" to be ")#mi("{S}")#text("-integers rather than algebraic integers). However, Theorem ")#link(<tao-cdc6f4c3662a92d1a3ce>)[#text("13")]#text(" can also be deduced from using Theorem ")#link(<tao-581eaf4658d71e887559>)[#text("1")]#text(" as a black box, as we shall shortly demonstrate.")

#text("Let us see how Theorem ")#link(<tao-cdc6f4c3662a92d1a3ce>)[#text("13")]#text(" implies Theorem ")#link(<tao-7cf6b0597fe4e3cb3559>)[#text("2")]#text(".")

#emph[#text("Proof:")]#text(" (of Theorem ")#link(<tao-7cf6b0597fe4e3cb3559>)[#text("2")]#text(" assuming Theorem ")#link(<tao-cdc6f4c3662a92d1a3ce>)[#text("13")]#text("). This is a modification of the argument of Theorem ")#link(<tao-69857c144f48fc4bb4bd>)[#text("7")]#text(". Suppose for contradiction that we can find a non-zero algebraic number ")#mi("{k}")#text(" such that the curve")

#align(center)[#tao-fit-display[#mitex("C^{\\prime} := \\{ (x,y,\\lambda): y^2 -x^3 = k; 2y \\lambda = 3x^2 \\}")]]

#text("contains a strictly nonstandard almost algebraic integer point ")#mi("{(x_*,y_*,\\lambda_*)}")#text(". We may place ")#mi("{x_*,y_*,\\lambda_*}")#text(" inside ")#mi("{K {}^* {\\bf Z}}")#text(" for some number field ")#mi("{K}")#text(", which we may take to be Galois by enlarging ")#mi("{K}")#text(" as necessary. Let ")#mi("{G = \\text{Gal}(K/{\\bf Q})}")#text(" be the Galois group.")

#text("For each ")#mi("{\\sigma \\in G}")#text(", the points ")#mi("{\\sigma(x_*,y_*,\\lambda_*)}")#text(" are either bounded (i.e., ")#tao-math("{\\left|\\sigma(x_*)\\right|, \\left|\\sigma(y_*)\\right|, \\left|\\sigma(\\lambda_*)\\right| \\ll 1}", block: false)#text(") or unbounded. If ")#mi("{\\sigma(x_*,y_*,\\lambda_*)}")#text(" is bounded for all ")#mi("{\\sigma \\in G}")#text(" then the coefficients of ")#mi("{x_*,y_*,\\lambda_* \\in K {}^* {\\bf Z}}")#text(" are all bounded, so that ")#mi("{(x_*,y_*,\\lambda_*)}")#text(" is standard, a contradiction. Thus ")#mi("{\\sigma(x_*,y_*,\\lambda_*)}")#text(" is unbounded for at least one ")#mi("{\\sigma \\in G}")#text(".")

#text("Let ")#mi("{D}")#text(" be a large integer to be chosen later (actually ")#mi("{D=3}")#text(" will do here), and consider the vector space ")#mi("{V}")#text(" of polynomials ")#mi("{R(x,y,\\lambda) \\in \\bar{{\\bf Q}}[x,y,\\lambda]}")#text(" spanned by the monomials")

#align(center)[#tao-fit-display[#mitex("x^i y^j \\text{ for } j=0,\\dots,D \\text{ and } i=0,1,2")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("x^i \\lambda^j \\text{ for } j=1,\\dots,3D \\text{ and } i=0,1,2.")]]

#text("This space thus has dimension ")#mi("{3(4D+1)}")#text(". We claim that none of the non-zero polynomials ")#mi("{R(x,y,\\lambda)}")#text(" in ")#mi("{V}")#text(" vanish identically on ")#mi("{C^{\\prime}}")#text(". To see this, we divide into two cases. If ")#mi("{R}")#text(" contains at least one monomial with a non-trivial power of ")#mi("{\\lambda}")#text(", then we can write ")#mi("{R(x,y,\\lambda) = \\lambda^j P(x) + \\dots}")#text(" for some ")#mi("{1 \\leq j \\leq 3D}")#text(", where ")#mi("{P}")#text(" is a non-zero polynomial in ")#mi("{x}")#text(" of degree at most ")#mi("{2}")#text(" and ")#mi("{\\dots}")#text(" has degree less than ")#mi("{j}")#text(" in ")#mi("{\\lambda}")#text(". By inspecting the limits ")#mi("{x \\rightarrow - k^{1/3}, -\\omega k^{1/3}, -\\omega^2 k^{1/3}}")#text(", ")#mi("{y \\rightarrow 0}")#text(", ")#mi("{\\lambda\\rightarrow \\infty}")#text(" of ")#mi("{C^{\\prime}}")#text(", we see that if ")#mi("{R}")#text(" vanished on ")#mi("{C^{\\prime}}")#text(", then the non-zero polynomial ")#mi("{P}")#text(" of degree at most ")#mi("{2}")#text(" would have to vanish at all three points ")#mi("{x = -k^{1/3}, -\\omega k^{1/3}, -\\omega^2 k^{1/3}}")#text(", a contradiction. Finally, if ")#mi("{R}")#text(" has no terms involving ")#mi("{\\lambda}")#text(", then it is a polynomial in ")#mi("{x,y}")#text(" of degree at most ")#mi("{2}")#text(" in ")#mi("{x}")#text(", and thus not divisible by ")#mi("{y^2-x^3}")#text(", and the claim now follows from Bezout’s theorem.")

#text("We claim that for every ")#mi("{\\sigma \\in G}")#text(", we may find a basis ")#mi("{R_{\\sigma,1},\\dots,R_{\\sigma,3(4D+1)}}")#text(" for ")#mi("{V}")#text(" with the property that")

#align(center)[#tao-fit-display[#tao-math("\\prod_{i=1}^{3(4D+1)} \\left|\\sigma( R_{\\sigma,i}( x_*, y_*, \\lambda_* ))\\right| \\ll 1,", block: true)]]

#text("with the improvement ")#metadata(none) <tao-f0f8270db484173c2e0e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\prod_{i=1}^{3(4D+1)} \\left|\\sigma( R_{\\sigma,i}( x_*, y_*, \\lambda_* ))\\right| \\ll \\left\\| (x_*,y_*,\\lambda_*) \\right\\|^{-\\epsilon}", block: true)]]

#text("for some standard ")#mi("{\\epsilon > 0}")#text(" if ")#mi("{\\sigma(x_*,y_*,\\lambda_*)}")#text(" is unbounded (which, as previously observed, must hold at least once). If this claim held, then on multiplying these bounds together and applying Theorem ")#link(<tao-cdc6f4c3662a92d1a3ce>)[#text("13")]#text(", we conclude that the tuple")

#align(center)[#tao-fit-display[#mitex("( ( x_*^i y_*^j )_{j=0,\\dots,D; i=0,1,2}, ( x_*^i \\lambda_*^j )_{j=1,\\dots,3D; i=0,1,2} )")]]

#text("is not in ")#mi("{K}")#text("-general position, which implies that ")#mi("{R(x_*,y_*,\\lambda_*)=0}")#text(" for some non-zero ")#mi("{R \\in V}")#text(". But ")#mi("{R}")#text(" does not vanish identically on the irreducible curve ")#mi("{C^{\\prime}}")#text(", so by Bezout’s theorem ")#mi("{R}")#text(" can only vanish at standard points of ")#mi("{C^{\\prime}}")#text(", a contradiction.")

#text("It remains to prove the claim. To simplify the notation we just handle the case when ")#mi("{\\sigma}")#text(" is the identity ")#mi("{1}")#text(", as the other cases are treated similarly. If ")#mi("{(x_*, y_*, \\lambda_* )}")#text(" is bounded, then the claim is trivial (taking ")#mi("{R_{1,i}}")#text(" to be an arbitrary basis of ")#mi("{V}")#text(", e.g. the monomial basis), so assume that ")#mi("{(x_*,y_*,\\lambda_*)}")#text(" is unbounded. From the geometry of ")#mi("{C^{\\prime}}")#text(", we see that this can only occur if either ")#mi("{y_*}")#text(" is unbounded and ")#mi("{\\lambda_*}")#text(" is infinitesimally close to zero, or else if ")#mi("{\\lambda_*}")#text(" is unbounded, ")#mi("{y_*}")#text(" is infinitesimally close to zero, and ")#mi("{x_*}")#text(" is infinitesimally close to one of ")#mi("{-k^{1/3}}")#text(", ")#mi("{-\\omega k^{1/3}}")#text(", or ")#mi("{-\\omega^2 k^{1/3}}")#text(".")

#text("First suppose that ")#mi("{y_*}")#text(" is unbounded. Then as ")#mi("{y \\rightarrow \\infty}")#text(", one can perform a ")#link("http://en.wikipedia.org/wiki/Puiseux_series")[#text("Puiseux series")]#text(" expansion of any polynomial ")#mi("{V}")#text(" in powers of ")#mi("{y^{1/3}}")#text(", with the highest power being ")#mi("{y^{D + 2/3}}")#text(". As such, we may find a basis ")#mi("{R_1,\\dots,R_{3(4D+1)}}")#text(" of ")#mi("{V}")#text(" for which")

#align(center)[#tao-fit-display[#tao-math("\\left|R_i( x_*,y_*,\\lambda_*)\\right| \\ll \\left|y_*\\right|^{D+\\frac{2-i}{3}}", block: true)]]

#text("for ")#mi("{i=1,\\dots,3(4D+1)}")#text(", which gives ")#link(<tao-f0f8270db484173c2e0e>)[#text("(10)")]#text(" for ")#mi("{D}")#text(" large enough.")

#text("Now suppose that it is ")#mi("{\\lambda_*}")#text(" which is unbounded. Then as ")#mi("{\\lambda \\rightarrow \\infty}")#text(", ")#mi("{y \\rightarrow 0}")#text(", and ")#mi("{x}")#text(" converges to one of ")#mi("{-k^{1/3}, -\\omega k^{1/3}, -\\omega^2 k^{1/3}}")#text(", one can perform a Laurent series expansion of any polynomial in ")#mi("{V}")#text(" in powers of ")#mi("{\\lambda}")#text(", with the highest power being ")#mi("{\\lambda^{3D}}")#text(". Thus we may find a basis ")#mi("{R_1,\\dots,R_{3(4D+1)}}")#text(" of ")#mi("{V}")#text(" for which")

#align(center)[#tao-fit-display[#tao-math("\\left|R_i( x_*,y_*,\\lambda_*)\\right| \\ll \\left|\\lambda_*\\right|^{3D+1-i}", block: true)]]

#text("for ")#mi("{i=1,\\dots,3(4D+1)}")#text(", and again ")#link(<tao-f0f8270db484173c2e0e>)[#text("(10)")]#text(" follows for ")#mi("{D}")#text(" large enough. This concludes the proof of Theorem ")#link(<tao-69857c144f48fc4bb4bd>)[#text("7")]#text(". ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 4. Amplifying the subspace theorem — ")]]

#text("Now we show how Theorem ")#link(<tao-3070dbffae0571ffa68f>)[#text("4")]#text(" may be amplified to prove Theorem ")#link(<tao-cdc6f4c3662a92d1a3ce>)[#text("13")]#text(". Our arguments will use very little number theory, relying primarily on linear algebra and the nonstandard analysis framework. (As always, one can reformulate these arguments in the standard setting, but the linear algebra arguments become quite complicated, requiring the use of many rank reduction arguments, as per Section 2 of ")#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/")[#text("this previous blog post")]#text(".")

#text("Let ")#mi("{d, K, G, x}")#text(" be as in Theorem ")#link(<tao-cdc6f4c3662a92d1a3ce>)[#text("13")]#text(". The space ")#mi("{K}")#text(" is a ")#tao-math("{\\left|G\\right|}", block: false)#text("-dimensional vector space over ")#mi("{{\\bf Q}}")#text(", and so we may (non-canonically) identify ")#mi("{K}")#text(" with ")#tao-math("{{\\bf Q}^{\\left|G\\right|}}", block: false)#text(", and ")#mi("{(K {}^* {\\bf Z})^d}")#text(" with ")#tao-math("{({\\bf Q} {}^* {\\bf Z})^{\\left|G\\right| d}}", block: false)#text(". In particular, ")#mi("{x}")#text(" can be viewed as a ")#tao-math("{\\left|G\\right|d}", block: false)#text("-tuple of almost rational integers. It would be helpful if we knew that this tuple was in ")#mi("{{\\bf Q}}")#text("-general position, as one could then apply Theorem ")#link(<tao-3070dbffae0571ffa68f>)[#text("4")]#text(" directly to conclude. However, our hypothesis is only the weaker assertion that ")#mi("{x}")#text(" is in ")#mi("{K}")#text("-general position. Nevertheless, we may place ")#mi("{x}")#text(" in a certain “row echelon form” in terms of ")#mi("{{\\bf Q}}")#text("-general position parameters, and we will then be able to deduce Theorem ")#link(<tao-cdc6f4c3662a92d1a3ce>)[#text("13")]#text(" from averaging together various applications of Theorem ")#link(<tao-3070dbffae0571ffa68f>)[#text("4")]#text(", with the precise applications to use being uncovered through linear algebra.")

#text("We turn to the details. Recall that if ")#mi("{V}")#text(" is an ")#mi("{n}")#text("-dimensional vector space over a field ")#mi("{K}")#text(", then a ")#link("http://en.wikipedia.org/wiki/Flag_(linear_algebra)")[#text("flag")]#text(" in ")#mi("{V}")#text(" is a nested sequence of spaces")

#align(center)[#tao-fit-display[#mitex("\\{0\\} = V_0 \\subset V_1 \\subset \\dots \\subset V_n = V")]]

#text("such that each ")#mi("{V_i}")#text(" is a ")#mi("{K}")#text("-linear subspace of dimension ")#mi("{i}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 14 (Standard row echelon form)")]#text(" ")#metadata(none) <tao-cf842aaad9c252744f94>#text(" Let ")#mi("{K}")#text(" be a ")#mi("{D}")#text("-dimensional field extension of a field ")#mi("{F}")#text(", let ")#mi("{W}")#text(" be a ")#mi("{d}")#text("-dimensional ")#mi("{K}")#text("-vector space, and let ")#mi("{V}")#text(" be an ")#mi("{F}")#text("-linear subspace of ")#mi("{W}")#text(" (viewed as an ")#mi("{Dd}")#text("-dimensional vector space over ")#mi("{F}")#text("). Suppose also that the ")#mi("{F}")#text("-dimension of ")#mi("{\\pi(V)}")#text(" is at least ")#mi("{s}")#text(" for every non-zero ")#mi("{K}")#text("-linear functional ")#mi("{\\pi: W \\rightarrow K}")#text(" and some ")#mi("{s \\geq 0}")#text(". Then one may find a flag")

#align(center)[#tao-fit-display[#mitex("\\{0\\} = W_0 \\subset W_1 \\subset \\dots \\subset W_d = W")]]

#text("of ")#mi("{K}")#text("-subspaces of ")#mi("{K^d}")#text(", as well as natural numbers")

#align(center)[#tao-fit-display[#mitex("D \\geq r_1 \\geq \\dots \\geq r_d \\geq s")]]

#text("such that ")#mi("{(V \\cap W_i) / W_{i-1}}")#text(" has ")#mi("{F}")#text("-dimension ")#mi("{r_i}")#text(" for ")#mi("{i=1,\\dots,d}")#text(".")
]

#emph[#text("Proof:")]#text(" The case ")#mi("{d=0}")#text(" is trivial, so assume inductively that ")#mi("{d \\geq 1}")#text(" and that the claim has already been proven for ")#mi("{d-1}")#text(". Let ")#mi("{\\pi: W \\rightarrow K}")#text(" be a non-zero ")#mi("{K}")#text("-linear functional which minimises the ")#mi("{F}")#text("-dimension of the space ")#mi("{\\pi(V)}")#text("; if we denote the dimension of this space by ")#mi("{r_d}")#text(", then ")#mi("{s \\leq r_d \\leq D}")#text(". We set ")#mi("{W_d := W}")#text(", and let ")#mi("{W_{d-1}}")#text(" be the kernel of ")#mi("{\\pi}")#text(", then ")#mi("{W_{d-1}}")#text(" is a ")#mi("{K}")#text("-hyperplane in ")#mi("{W}")#text(". We claim that the ")#mi("{F}")#text("-dimension of ")#mi("{\\pi^{\\prime}(V \\cap W_{d-1})}")#text(" is at least ")#mi("{r_d}")#text(" for any non-zero ")#mi("{\\pi^{\\prime}: W_{d-1} \\rightarrow K}")#text(", for if this were not the case, one could find an extension ")#mi("{\\tilde \\pi: W \\rightarrow K}")#text(" of ")#mi("{\\pi^{\\prime}}")#text(" to ")#mi("{W}")#text(" which annihilated a section of ")#mi("{\\pi(V)}")#text(" in ")#mi("{V}")#text(", so that ")#mi("{\\tilde \\pi(V)= \\pi^{\\prime}(V \\cap W_{d-1})}")#text(", contradicting the minimality of ")#mi("{r_d}")#text(". We may thus apply the induction hypothesis to find a flag")

#align(center)[#tao-fit-display[#mitex("\\{0\\} = W_0 \\subset W_1 \\subset \\dots \\subset W_{d-1}")]]

#text("and natural numbers")

#align(center)[#tao-fit-display[#mitex("D \\geq r_1 \\geq \\dots \\geq r_{d-1} \\geq r_d")]]

#text("such that such that ")#mi("{(V \\cap W_i) / W_{i-1}}")#text(" has ")#mi("{F}")#text("-dimension ")#mi("{r_i}")#text(" for ")#mi("{i=1,\\dots,d-1}")#text(". The claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 15")]#text(" ")#metadata(none) <tao-6a04921306565da0dbb0>#text(" Let ")#mi("{K}")#text(" be a degree ")#mi("{D}")#text(" extension of ")#mi("{{\\bf Q}}")#text(", and let ")#mi("{x \\in (K {}^* {\\bf Z})^d}")#text(" be in ")#mi("{K}")#text("-general position. Then one find a ")#mi("{{\\bf Q}}")#text("-subspace ")#mi("{V}")#text(" of ")#mi("{K^d}")#text(" such that ")#mi("{x}")#text(" is an element of the ")#mi("{{}^*{\\bf Z}}")#text(" module ")#mi("{{}^* {\\bf Z} V = \\{ n_1 v_1 + \\dots + n_l v_l: n_1,\\dots,n_l \\in {\\bf Q} {}^* {\\bf Z} \\}}")#text(", where ")#mi("{v_1,\\dots,v_l}")#text(" is an arbitrary ")#mi("{{\\bf Q}}")#text("-basis of ")#mi("{V}")#text(". Furthermore, ")#mi("{x}")#text(" is a ")#mi("{{\\bf Q}}")#text("-generic point of ")#mi("{V}")#text(", in the sense that for any ")#mi("{{\\bf Q}}")#text("-basis ")#mi("{v_1,\\dots,v_l}")#text(" of ")#mi("{V}")#text(", one has ")#mi("{x = n_1 v_1 + \\dots + n_l v_l}")#text(" with ")#mi("{(n_1,\\dots,n_l)}")#text(" in ")#mi("{{\\bf Q}}")#text("-general position. (Equivalently, ")#mi("{x}")#text(" does not lie in ")#mi("{{}^*{\\bf Z} W}")#text(" for any proper ")#mi("{{\\bf Q}}")#text("-subspace ")#mi("{W}")#text(" of ")#mi("{V}")#text(".)")

#text("Furthermore, one may find linearly independent ")#mi("{K}")#text("-linear forms ")#mi("{L_1,\\dots,L_d: K^d \\rightarrow K}")#text(" and natural numbers")

#align(center)[#tao-fit-display[#mitex("D \\geq r_1 \\geq \\dots \\geq r_d \\geq 1")]]

#text("such that for each ")#mi("{1 \\leq i \\leq d}")#text(", the space ")#metadata(none) <tao-c0ff93ea8927a7366db0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("V^{\\prime}_i := L_i( V \\cap \\text{ker}(L_{i+1}) \\cap \\dots \\cap \\text{ker}(L_d) )")]]

#text("(which is a ")#mi("{{\\bf Q}}")#text("-subspace of ")#mi("{K}")#text(") has ")#mi("{{\\bf Q}}")#text("-dimension ")#mi("{r_i}")#text(".")
]

#text("This corollary is a sort of “regularity lemma” for points in ")#mi("{{}^* {\\bf Z} V}")#text("; this is perhaps the component of the argument which is the most difficult to convert into a standard setting.")

#emph[#text("Proof:")]#text(" Let ")#mi("{V}")#text(" denote the intersection of all the ")#mi("{{\\bf Q}}")#text("-subspaces ")#mi("{U}")#text(" of ")#mi("{K^d}")#text(" such that ")#mi("{x \\in {}^* {\\bf Z} U}")#text(". Then ")#mi("{V}")#text(" is itself a ")#mi("{{\\bf Q}}")#text("-subspace of ")#mi("{K^d}")#text(" with ")#mi("{x \\in {}^* {\\bf Z} V}")#text("; one can think of ")#mi("{V}")#text(" as the ")#mi("{K}")#text("-linear analogue of a “Zariski closure” of ")#mi("{x}")#text(". If ")#mi("{v_1,\\dots,v_l}")#text(" is a basis of ")#mi("{V}")#text(", then we have ")#mi("{x = n_1 v_1 + \\dots + n_l v_l}")#text(" for some ")#mi("{n_1,\\dots,n_l \\in {\\bf Q} {}^* {\\bf Z}}")#text("; if ")#mi("{(n_1,\\dots,n_l)}")#text(" is not in ")#mi("{{\\bf Q}}")#text("-general position, then we have a non-trivial dependence ")#mi("{c_1 n_1 + \\dots + c_l n_l = 0}")#text(" for some ")#mi("{c_1,\\dots,c_l \\in {\\bf Q}}")#text(", not all zero, and we may use this to place ")#mi("{x}")#text(" in ")#mi("{{}^* {\\bf Z} U}")#text(" for some proper ")#mi("{{\\bf Q}}")#text("-subspace ")#mi("{U}")#text(" of ")#mi("{V}")#text(", a contradiction. Thus ")#mi("{x}")#text(" is a ")#mi("{{\\bf Q}}")#text("-generic point in ")#mi("{{}^* {\\bf Z} V}")#text(".")

#text("Since ")#mi("{x}")#text(" is in ")#mi("{K}")#text("-general position, ")#mi("{\\pi(V)}")#text(" is non-trivial for any ")#mi("{K}")#text("-linear form ")#mi("{\\pi: K^d \\rightarrow K}")#text(". From Theorem ")#link(<tao-cf842aaad9c252744f94>)[#text("14")]#text(" we may then find a flag")

#align(center)[#tao-fit-display[#mitex("\\{0\\} = W_0 \\subset W_1 \\subset \\dots \\subset W_d = K^d")]]

#text("of ")#mi("{K}")#text("-subspaces of ")#mi("{K^d}")#text(", as well as natural numbers")

#align(center)[#tao-fit-display[#mitex("D \\geq r_1 \\geq \\dots \\geq r_d \\geq 1")]]

#text("such that ")#mi("{(V \\cap W_i) / W_{i-1}}")#text(" has ")#mi("{{\\bf Q}}")#text("-dimension ")#mi("{r_i}")#text(" for ")#mi("{i=1,\\dots,d}")#text(". If, for each ")#mi("{i=1,\\dots,d}")#text(", we let ")#mi("{L_i: K^d \\rightarrow K}")#text(" be a ")#mi("{K}")#text("-linear form that annihilates ")#mi("{W_{i-1}}")#text(" but does not annihilate ")#mi("{W_i}")#text(", we obtain the claim. ")#mi("\\Box")

#text("Next, we need a classical lemma on intersection of flags.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 16 (Schubert cell decomposition)")]#text(" ")#metadata(none) <tao-f872054c921d0dbddb60>#text(" Let")

#align(center)[#tao-fit-display[#mitex("\\{0\\} = V_0 \\subset V_1 \\subset \\dots \\subset V_n = V")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\{0\\} = W_0 \\subset W_1 \\subset \\dots \\subset W_n = V")]]

#text("be two flags on the same ")#mi("{n}")#text("-dimensional vector space ")#mi("{V}")#text(" over a field ")#mi("{F}")#text(". Then one can find a basis ")#mi("{e_1,\\dots,e_n}")#text(" of ")#mi("{F}")#text(" and a permutation ")#mi("{\\rho: \\{1,\\dots,n\\} \\rightarrow \\{1,\\dots,n\\}}")#text(" such that ")#mi("{e_i \\in V_i \\cap W_{\\rho(i)}}")#text(" for all ")#mi("{i=1,\\dots,n}")#text(".")
]

#emph[#text("Proof:")]#text(" For any ")#mi("{1 \\leq i \\leq d}")#text(", the function ")#mi("{j \\mapsto \\text{dim}(V_i \\cap W_j) - \\text{dim}(V_{i-1} \\cap W_j)}")#text(" is non-decreasing in ")#mi("{j}")#text(", is equal to ")#mi("{0}")#text(" when ")#mi("{j=0}")#text(", and ")#mi("{1}")#text(" when ")#mi("{j=d}")#text(", thus there exists a unique ")#mi("{1 \\leq \\rho(i) \\leq d}")#text(" such that this function equals ")#mi("{1}")#text(" for ")#mi("{j \\geq \\rho(i)}")#text(" and ")#mi("{0}")#text(" for ")#mi("{j < \\rho(i)}")#text(". By inspecting the quantities ")#mi("{i \\mapsto \\text{dim}(V_i \\cap W_{j-1}) - \\text{dim}(V_i \\cap W_j)}")#text(" for a given ")#mi("{j}")#text(", which similarly increase from ")#mi("{0}")#text(" to ")#mi("{1}")#text(", we see that there is at most one ")#mi("{i}")#text(" with ")#mi("{\\rho(i)=j}")#text(", thus ")#mi("{\\rho}")#text(" is a permutation. If we then choose ")#mi("{e_i}")#text(" to be an element of ")#mi("{V_i \\cap W_{\\rho(i)}}")#text(" that lies outside of ")#mi("{V_{i-1}}")#text(", we obtain the claim. ")#mi("\\Box")

#text("Let ")#mi("{d, K, G, L_{\\sigma,i}, x}")#text(" be as in Theorem ")#link(<tao-cdc6f4c3662a92d1a3ce>)[#text("13")]#text(", and let ")#mi("{L_1,\\dots,L_d}")#text(" and ")#mi("{r_1,\\dots,r_d}")#text(" be as in Corollary ")#link(<tao-6a04921306565da0dbb0>)[#text("15")]#text(", with ")#tao-math("{D=\\left|G\\right|}", block: false)#text(" being the degree of ")#mi("{K}")#text(". By permuting the ")#mi("{L_{\\sigma,i}}")#text(", we may assume that ")#tao-math("{\\left|\\sigma(L_{\\sigma,i}(x))\\right|}", block: false)#text(" is non-decreasing in ")#mi("{i}")#text(".")

#text("For each ")#mi("{\\sigma \\in G}")#text(", we apply Lemma ")#link(<tao-f872054c921d0dbddb60>)[#text("16")]#text(" to the flags")

#align(center)[#tao-fit-display[#mitex("\\{0\\} \\subset \\text{span}(L_d) \\subset \\text{span}(L_d,L_{d-1}) \\subset \\dots \\subset (\\bar{{\\bf Q}}^d)^*")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\{0\\} \\subset \\text{span}(L_{\\sigma,1}) \\subset \\text{span}(L_{\\sigma,1},L_{\\sigma,2}) \\subset \\dots \\subset (\\bar{{\\bf Q}}^d)^*")]]

#text("(with the span being over ")#mi("{\\bar{{\\bf Q}}}")#text(", and with the ")#mi("{L_i}")#text(" extened from ")#mi("{K}")#text("-linear forms to ")#mi("{\\bar{{\\bf Q}}}")#text("-linear forms) we may find a ")#mi("{\\bar{{\\bf Q}}}")#text("-basis ")#mi("{L^{\\prime}_{\\sigma,1},\\dots,L^{\\prime}_{\\sigma,d}}")#text(" of the ")#mi("{\\bar{{\\bf Q}}}")#text("-linear forms ")#mi("{(\\bar{{\\bf Q}}^d)^*}")#text(" on ")#mi("{\\bar{{\\bf Q}}^d}")#text(" and a permutation ")#mi("{\\rho_\\sigma: \\{1,\\dots,d\\} \\rightarrow \\{1,\\dots,d\\}}")#text(" such that for each ")#mi("{1 \\leq i \\leq d}")#text(", ")#mi("{L^{\\prime}_{\\sigma,i}}")#text(" is a ")#mi("{\\bar{{\\bf Q}}}")#text("-linear combination of ")#mi("{L_d,\\ldots,L_{d+1-i}}")#text(", and is also a ")#mi("{K}")#text("-linear combination of ")#mi("{L_{\\sigma,1},\\dots,L_{\\sigma,\\rho_\\sigma(i)}}")#text(". From the latter claim, the non-decreasing nature of ")#tao-math("{\\left|\\sigma(L_{\\sigma,i}(x))\\right|}", block: false)#text(", and the triangle inequality we have")

#align(center)[#tao-fit-display[#tao-math("\\prod_{i=1}^d \\left|L^{\\prime}_{\\sigma,i}(\\sigma(x))\\right| \\ll \\prod_{i=1}^d |\\sigma(L_{\\sigma,i}(x))|.", block: true)]]

#text("It will now suffice to show that ")#metadata(none) <tao-8db59feb4d217f26c79d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\prod_{\\sigma \\in G} \\prod_{i=1}^d \\left|\\sigma(L^{\\prime}_{\\sigma,i}(x))\\right| \\gg \\left\\|x\\right\\|_\\infty^{-o(1)}.", block: true)]]

#text("We will prove the inequalities ")#metadata(none) <tao-a32d0b4d7084ea7ae8ac>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\prod_{\\sigma \\in G} \\prod_{i=1}^j \\left|\\sigma(L^{\\prime}_{\\sigma,i}(x))\\right|^{r_{d+1-i}/\\left|G\\right|} \\gg \\left\\|x\\right\\|_\\infty^{-o(1)};", block: true)]]

#text("for all ")#mi("{1 \\leq j \\leq d}")#text("; since the standard quantities ")#tao-math("{\\left|G\\right|/r_{d+1-i}}", block: false)#text(" are finite and non-increasing in ")#mi("{i}")#text(", the claim ")#link(<tao-8db59feb4d217f26c79d>)[#text("(12)")]#text(" follows from taking a telescoping product of powers of ")#link(<tao-a32d0b4d7084ea7ae8ac>)[#text("(13)")]#text(".")

#text("To prove ")#link(<tao-a32d0b4d7084ea7ae8ac>)[#text("(13)")]#text(", we need a classical lemma concerning the canonical embedding of ")#mi("{K}")#text(" into ")#mi("{K^G}")#text(" via the Galois group action.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 17")]#text(" ")#metadata(none) <tao-d2b7ea260fab27913f5b>#text(" The space ")#mi("{\\{ (\\sigma(x))_{\\sigma \\in G}: x \\in K \\}}")#text(" spans ")#mi("{K^G}")#text(" as a ")#mi("{K}")#text("-linear space.")
]

#emph[#text("Proof:")]#text(" We give a nonstandard analysis proof. If this were not the case, then we would have coefficients ")#mi("{c_\\sigma \\in K}")#text(" for ")#mi("{\\sigma \\in G}")#text(", not all zero, such that")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\sigma \\in G} c_\\sigma \\sigma(x) = 0")]]

#text("for all ")#mi("{x \\in K}")#text(", and hence also for all ")#mi("{x \\in K {}^* {\\bf Z}}")#text(". Now let ")#mi("{\\delta_\\sigma > 0}")#text(" be nonstandard real numbers for ")#mi("{\\sigma \\in G}")#text(" such that ")#mi("{\\prod_{\\sigma \\in G} \\delta_\\sigma = 1}")#text(", and such that no two ")#mi("{\\delta_\\sigma}")#text(" are comparable. From the Dirichlet approximation theorem argument given at the start of this post, we can find a non-zero ")#mi("{x \\in K {}^* {\\bf Z}}")#text(" such that ")#tao-math("{\\left|\\sigma(x)\\right| \\ll \\delta_\\sigma}", block: false)#text(". On the other hand, the norm ")#mi("{\\prod_{\\sigma \\in G} \\sigma(x)}")#text(" is a non-zero rational integer and so ")#tao-math("{\\prod_{\\sigma \\in G} \\left|\\sigma(x)\\right| \\gg 1}", block: false)#text(". Combining the two estimates, we conclude that ")#tao-math("{\\left|\\sigma(x)\\right| \\sim \\delta_\\sigma}", block: false)#text(" for all ")#mi("{\\sigma \\in G}")#text(". But as the ")#mi("{\\delta_\\sigma}")#text(" are incomparable, this forces the ")#mi("{\\sigma(x)}")#text(" to be linearly independent over ")#mi("{K}")#text(", a contradiction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 18")]#text(" ")#metadata(none) <tao-725fed9d1ae909982052>#text(" If ")#mi("{V}")#text(" is a ")#mi("{{\\bf Q}}")#text("-subspace of ")#mi("{K}")#text(" of dimension ")#mi("{r}")#text(", then there exist distinct elements ")#mi("{\\sigma_1,\\dots,\\sigma_r}")#text(" of ")#mi("{G}")#text(" such that the ")#mi("{{\\bf Q}}")#text("-linear functions ")#mi("{x \\mapsto \\sigma_i(x)}")#text(" for ")#mi("{i=1,\\dots,r}")#text(" are ")#mi("{{\\bf Q}}")#text("-linearly independent on ")#mi("{V}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{e_1,\\dots,e_r}")#text(" be a ")#mi("{{\\bf Q}}")#text("-basis for ")#mi("{V}")#text(", which we complete to a ")#mi("{{\\bf Q}}")#text("-basis ")#mi("{e_1,\\dots,e_D}")#text(" for ")#mi("{K}")#text(". By Lemma ")#link(<tao-d2b7ea260fab27913f5b>)[#text("17")]#text(", the vectors ")#mi("{(\\sigma(e_i))_{\\sigma \\in G}}")#text(" for ")#mi("{i=1,\\dots,D}")#text(" span ")#mi("{K^G}")#text(" as a ")#mi("{K}")#text("-linear space, and are thus ")#mi("{K}")#text("-linearly independent. In particular, the matrix ")#mi("{(\\sigma(e_i))_{\\sigma \\in G; 1 \\leq i \\leq r}}")#text(" has full rank, and so has a minor ")#mi("{(\\sigma_j(e_i))_{1 \\leq i,j \\leq r}}")#text(" which is non-singular, giving the claim. ")#mi("\\Box")

#text("Now we can prove ")#link(<tao-a32d0b4d7084ea7ae8ac>)[#text("(13)")]#text(" for a given ")#mi("{1 \\leq j \\leq d}")#text(". For each ")#mi("{1 \\leq i \\leq j}")#text(", we apply Corollary ")#link(<tao-725fed9d1ae909982052>)[#text("18")]#text(" to the space ")#mi("{V^{\\prime}_i}")#text(" defined in ")#link(<tao-c0ff93ea8927a7366db0>)[#text("(11)")]#text(" to find distinct elements ")#mi("{\\sigma_{i,1},\\dots,\\sigma_{i,r_{d+1-i}}}")#text(" of ")#mi("{G}")#text(" such that the forms ")#mi("{x \\mapsto \\sigma_{i,l}(x)}")#text(" for ")#mi("{l=1,\\dots,r_{d+1-i}}")#text(" are ")#mi("{{\\bf Q}}")#text("-linearly independent on ")#mi("{V^{\\prime}_i}")#text("; applying an arbitrary element ")#mi("{\\mu}")#text(" of ")#mi("{G}")#text(", we also see that the forms ")#mi("{x \\mapsto \\mu \\sigma_{i,l}(x)}")#text(" for ")#mi("{l=1,\\dots,r_{d+1-i}}")#text(" are ")#mi("{{\\bf Q}}")#text("-linearly independent on ")#mi("{V^{\\prime}_i}")#text(". We will show that ")#metadata(none) <tao-b49b6976120c927c29fd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\prod_{i=1}^j \\prod_{l=1}^{r_{d+1-i}} \\left|\\mu\\sigma_{i,l}(L^{\\prime}_{\\mu \\sigma_{i,l},i}(x))\\right| \\gg \\left\\|x\\right\\|_\\infty^{-o(1)};", block: true)]]

#text("taking the geometric mean over all ")#mi("{\\mu \\in G}")#text(", we obtain ")#link(<tao-a32d0b4d7084ea7ae8ac>)[#text("(13)")]#text(".")

#text("It remains to prove ")#link(<tao-b49b6976120c927c29fd>)[#text("(14)")]#text(". By construction of the ")#mi("{L^{\\prime}_{\\sigma,i}}")#text(", we know that the ")#mi("{L^{\\prime}_{\\mu \\sigma_{i,l},i}(x)}")#text(" is a linear combination of the tuple")

#align(center)[#tao-fit-display[#mitex("x_j := (L_d(x), \\dots, L_{d+1-j}(x)) \\in (K {}^* {\\bf Z})^j.")]]

#text("This tuple lies in ")#mi("{{}^*{\\bf Z} V_j}")#text(", where ")#mi("{V_j \\subset K^j}")#text(" is the image of ")#mi("{V}")#text(" under the map ")#mi("{x \\mapsto (L_d(x), \\dots, L_{d+1-j}(x))}")#text(". By Corollary ")#link(<tao-6a04921306565da0dbb0>)[#text("15")]#text(", ")#mi("{V_j}")#text(" is a ")#mi("{{\\bf Q}}")#text("-vector space of dimension ")#mi("{r_d + \\dots + r_{d+1-j}}")#text(", and ")#mi("{x_j}")#text(" is a ")#mi("{{\\bf Q}}")#text("-generic point of ")#mi("{V_j}")#text(". By Theorem ")#link(<tao-3070dbffae0571ffa68f>)[#text("4")]#text(" (and the subsequent remarks), we will be able to conclude ")#link(<tao-b49b6976120c927c29fd>)[#text("(14)")]#text(" as soon as we show that the ")#mi("{r_d + \\dots + r_{d+1-j}}")#text(" expressions ")#mi("{\\mu\\sigma_{i,l}(L^{\\prime}_{\\mu \\sigma_{i,l},i}(x))}")#text(" for ")#mi("{i=1,\\dots,j}")#text(" and ")#mi("{l=1,\\dots,r_{d+1-i}}")#text(" are ")#mi("{\\bar{{\\bf Q}}}")#text("-linearly independent. Suppose for contradiction that one has a non-trivial linear dependence")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^j \\sum_{l=1}^{r_{d+1-i}} c_{i,l} \\mu\\sigma_{i,l}(L^{\\prime}_{\\mu \\sigma_{i,l},i}(x)) = 0")]]

#text("for some ")#mi("{c_{i,l} \\in \\bar{{\\bf Q}}}")#text(", not all zero. Let ")#mi("{i_*}")#text(" be the largest value of ")#mi("{i=1,\\dots,j}")#text(" for which there is a non-zero value of ")#mi("{c_{i,l}}")#text(". Each ")#mi("{L^{\\prime}_{\\mu \\sigma_{i_*,l},i_*}(x)}")#text(" is a ")#mi("{\\bar{{\\bf Q}}}")#text("-linear combination of ")#mi("{L_d(x),\\dots,L_{d+1-i_*}(x)}")#text(", with the coefficient of ")#mi("{L_{d+1-i_*}(x)}")#text(" being non-zero (otherwise the ")#mi("{L^{\\prime}_{\\sigma,i}}")#text(" could not be linearly independent in ")#mi("{i}")#text("). We conclude that there is a non-trivial ")#mi("{\\bar{{\\bf Q}}}")#text("-linear combination of the ")#mi("{\\mu \\sigma_{i_*,l}( L_{d+1-i_*}(x) )}")#text(" for ")#mi("{l=1,\\dots,r_{d+1-i_*}}")#text(", which is equal to a ")#mi("{\\bar{{\\bf Q}}}")#text("-linear combination of the ")#mi("{\\sigma(L_{d+1-i}(x))}")#text(" for ")#mi("{i=1,\\dots,i_*-1}")#text(" and ")#mi("{\\sigma \\in G}")#text(". But as ")#mi("{x_j}")#text(" is a ")#mi("{{\\bf Q}}")#text("-generic point in ")#mi("{V_j}")#text(", this can only happen if the corresponding linear combination of the forms ")#mi("{\\mu \\sigma_{i_*,l}( L_{d+1-i_*})}")#text(" and ")#mi("{\\sigma(L_{d+1-i})}")#text(" vanishes on ")#mi("{V_j}")#text(" (with the ")#mi("{L_{d+1-i}}")#text(" now interpreted as coordinate functions on ")#mi("{V_j}")#text("). This implies that the forms ")#mi("{x \\mapsto \\mu \\sigma_{i_*,l}}")#text(" are ")#mi("{{\\bf Q}}")#text("-linearly dependent on ")#mi("{V^{\\prime}_{i_*}}")#text(", giving the required contradiction. This proves ")#link(<tao-b49b6976120c927c29fd>)[#text("(14)")]#text(", and Theorem ")#link(<tao-cdc6f4c3662a92d1a3ce>)[#text("13")]#text(" follows.")

#heading(level: 1)[#strong[#text(" — 5. The flag structure of the magnitude of linear forms — ")]]

#text("Although we will not need this fact here, it is interesting to note that the subspace theorem (Theorem ")#link(<tao-3070dbffae0571ffa68f>)[#text("4")]#text(") gives rather precise control on the size of various linear combinations of algebraic numbers.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 19 (Schmidt subspace theorem, flag version)")]#text(" ")#metadata(none) <tao-7190cfb25510e8d24a0e>#text(" Let ")#mi("{d}")#text(" be a standard natural number, and let ")#mi("{x \\in {}^* {\\bf Z}^d}")#text(" be in ")#mi("{{\\bf Q}}")#text("-general position. Then one has a standard flag")

#align(center)[#tao-fit-display[#mitex("\\{0\\} = V_0 \\subset V_1 \\subset \\dots \\subset V_d = (\\bar{{\\bf Q}}^d)^*")]]

#text("in the space ")#mi("{(\\bar{{\\bf Q}}^d)^*}")#text(" of linear forms ")#mi("{L: (\\bar{{\\bf Q}}^d \\rightarrow \\bar{{\\bf Q}}}")#text(", as well as standard real numbers")

#align(center)[#tao-fit-display[#mitex("-\\infty < \\lambda_1 \\leq \\dots \\leq \\lambda_d = 1")]]

#text("with ")#metadata(none) <tao-b737ca7ee563ae80e457>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\lambda_1 + \\dots + \\lambda_d \\geq 0")]]

#text("such that ")#metadata(none) <tao-e6057f273b924a533ddf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\left|L(x)\\right| = \\left\\|x\\right\\|^{\\lambda_i + o(1)}", block: true)]]

#text("whenever ")#mi("{i=1,\\dots,d}")#text(" and ")#mi("{L \\in V_i \\backslash V_{i-1}}")#text(".")
]

#text("For instance, if ")#mi("{x_1, x_2 \\in {}^* {\\bf Z}}")#text(" are linearly independent over ")#mi("{{\\bf Q}}")#text(", then Theorem ")#link(<tao-7190cfb25510e8d24a0e>)[#text("19")]#text(" asserts that")

#align(center)[#tao-fit-display[#tao-math("\\left| \\alpha x_1 + \\beta x_2 \\right| = \\left\\|(x_1,x_2)\\right\\|^{o(1)}", block: true)]]

#text("for all ")#mi("{(\\alpha,\\beta) \\in \\bar{{\\bf Q}}^2}")#text(" outside of a one-dimensional subspace ")#mi("{V_1}")#text(" of ")#mi("{\\bar{{\\bf Q}}^2}")#text(", and we have")

#align(center)[#tao-fit-display[#tao-math("\\left| \\alpha x_1 + \\beta x_2 \\right| = \\left\\|(x_1,x_2)\\right\\|^{\\lambda_1 + o(1)}", block: true)]]

#text("for all non-zero ")#mi("{(\\alpha,\\beta) \\in V_1}")#text(" and some ")#mi("{\\lambda_1 \\geq -1}")#text(". One can use Theorem ")#link(<tao-cdc6f4c3662a92d1a3ce>)[#text("13")]#text(" obtain a similar description of the magnitude of ")#mi("{K}")#text("-linear forms (and their Galois conjugates) of a point ")#mi("{x \\in (K {}^* {\\bf Z})^d}")#text(" in ")#mi("{K}")#text("-general position, but we will not do so here.")

#emph[#text("Proof:")]#text(" For each standard ")#mi("{\\lambda \\in {\\bf R}}")#text(", the space")

#align(center)[#tao-fit-display[#tao-math("V(\\lambda) := \\{ L \\in (\\bar{{\\bf Q}}^d)^*: \\left|L(x)\\right| \\leq \\left\\|x\\right\\|^{\\lambda+o(1)} \\}", block: true)]]

#text("is a ")#mi("{\\bar{{\\bf Q}}}")#text("-linear subspace of ")#mi("{(\\bar{{\\bf Q}}^d)^*}")#text(", which is non-decreasing and right-continuous in ")#mi("{\\lambda}")#text(", and equals all of ")#mi("{(\\bar{{\\bf Q}}^d)^*}")#text(" when ")#mi("{\\lambda \\geq 1}")#text(". As subspaces of ")#mi("{(\\bar{{\\bf Q}}^d)^*}")#text(" must have an integer dimension between ")#mi("{0}")#text(" and ")#mi("{d}")#text(", we may thus find a complete flag")

#align(center)[#tao-fit-display[#mitex("\\{0\\} = V_0 \\subset V_1 \\subset \\dots \\subset V_d = (\\bar{{\\bf Q}}^d)^*")]]

#text("and extended real numbers")

#align(center)[#tao-fit-display[#mitex("-\\infty = \\lambda_0 \\leq \\lambda_1 \\leq \\dots \\leq \\lambda_d \\leq 1 \\leq \\lambda_{d+1} = +\\infty")]]

#text("such that ")#mi("{V(\\lambda) = V_i}")#text(" whenever ")#mi("{1 \\leq i \\leq d}")#text(" and ")#mi("{\\lambda_i \\leq \\lambda < \\lambda_{i+1}}")#text(". Selecting ")#mi("{L_i}")#text(" to be an element of ")#mi("{V_i \\backslash V_{i-1}}")#text(" for ")#mi("{i=1,\\dots,d}")#text(" and applying Theorem ")#link(<tao-3070dbffae0571ffa68f>)[#text("4")]#text(", we obtain ")#link(<tao-b737ca7ee563ae80e457>)[#text("(15)")]#text(", which in particular implies that the ")#mi("{\\lambda_1,\\dots,\\lambda_d}")#text(" are finite, at which point ")#link(<tao-e6057f273b924a533ddf>)[#text("(16)")]#text(" follows from the definition of the ")#mi("{V(\\lambda)}")#text(". Finally, by taking the coordinate linear forms we see that ")#tao-math("{\\left|L(x)\\right| \\gg \\left\\|x\\right\\|}", block: false)#text(" for at least one ")#mi("{L}")#text(", which forces ")#mi("{\\lambda_d=1}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Try to state and prove a standard version of Theorem ")#link(<tao-7190cfb25510e8d24a0e>)[#text("19")]#text(". (This is remarkably tricky – it takes the form of a “regularity lemma” in the spirit of Section 2 of ")#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/")[#text("this blog post")]#text(" – and may help to illustrate the power of the nonstandard formalism.)")
]

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01765f3c7e05429192a94f6e66e8b6597bc94b0f9ba99b7568e192872d49392d-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Francisco Javier Thayer")]], [#link("https://terrytao.wordpress.com/2014/07/07/the-subspace-theorem-approach-to-siegels-theorem-on-integral-points-on-curves-via-nonstandard-analysis/comment-page-1/#comment-388950")[#strong[#text("Francisco Javier Thayer")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2014")])]

#text("Re: Bezout. Referring to previous posts on Loeb measure, if ")#mi("T \\simeq \\infty")#text(" then the probability that ")#mi("(p, q) \\in \\{1, \\ldots T\\}")#text(" are relatively prime is ")#mi("1/zeta(2)")#text(". This is elementary (Hardy and Wright) and Loeb measure is merely a measure-theoretic interpretation of this. There are analogous results for square-free integers etc. I wonder if there is some way of doing something similar with polynomials?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f01005bd9a8b71b1dd9b3f7943f005f005d06e4aa720d188c09592684e70298d-a3a2ffd36508b03ca9acfe77066eeb285fa651c5e4aea7ec69ef6e88c6d66822.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Colin Rust")]], [#link("https://terrytao.wordpress.com/2014/07/07/the-subspace-theorem-approach-to-siegels-theorem-on-integral-points-on-curves-via-nonstandard-analysis/comment-page-1/#comment-395158")[#strong[#text("Colin Rust")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2014")])]

#text("As written, I think the proof of the theorem of Liouville in the second paragraph is only literally valid for algebraic integers not general irrational algebraic numbers (in which case the product is not guaranteed to be a natural number).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0848b78f6b6780908b2b1d724e695807d03e92f7e6b0acdf8bc70a6ced765db6-2b43c0a3089c5247f6165dd07a9918455c838c55a3aa69d3a52827d43dfe33ae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2014/07/07/the-subspace-theorem-approach-to-siegels-theorem-on-integral-points-on-curves-via-nonstandard-analysis/comment-page-1/#comment-486149")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2017")])]

#text("Is there an analog of subspace theorem for polynomial forms rather than just linear forms?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b2dab7c5f7cf57f80a74229b8b0f93998bf0d5d238b8e21bf89256bbda3a9a70-745170bd53116daa36e7ee588aec35d7a638ea49e038399c322f1ddd8c15961d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of complexsesame")]], [#link("https://terrytao.wordpress.com/2014/07/07/the-subspace-theorem-approach-to-siegels-theorem-on-integral-points-on-curves-via-nonstandard-analysis/comment-page-1/#comment-563405")[#strong[#text("complexsesame")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2020")])]

#text("Yes there is, essentially done by Corvaja-Zannier’s paper “On general Thue’s equation”. And there are a lot of further generalizations to projective varieties. But they are mostly limited by somehow reduce to the linear case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edd3147198d888c51d9915be45dcd600e9a399b87b95cb50746d03e795f55906-83f3945ec3332e3f1d70e7794134266a0dca3bb16f48c3bd95bdd30a7d61b505.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of RobertJDicks1")]], [#link("https://terrytao.wordpress.com/2014/07/07/the-subspace-theorem-approach-to-siegels-theorem-on-integral-points-on-curves-via-nonstandard-analysis/comment-page-1/#comment-693762")[#strong[#text("RobertJDicks1")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2026")])]

#text("“From class field theory, the class group of K is finite”. This should not depend on class field theory, no? The class group of a number field is always finite.")

#emph[#text("[Fair enough, reworded – T.]")]
]
