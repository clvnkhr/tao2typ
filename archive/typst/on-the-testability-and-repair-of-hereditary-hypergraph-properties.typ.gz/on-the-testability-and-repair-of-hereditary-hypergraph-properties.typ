// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/01/16/on-the-testability-and-repair-of-hereditary-hypergraph-properties/
// Converted to Typst by tao2typ: "2026-10-14T06:53:08.251268+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On the testability and repair of hereditary hypergraph properties", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On the testability and repair of hereditary hypergraph properties")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 January 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/01/16/on-the-testability-and-repair-of-hereditary-hypergraph-properties/")[#text("https://terrytao.wordpress.com/2008/01/16/on-the-testability-and-repair-of-hereditary-hypergraph-properties/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the ")#link("http://arxiv.org/")[#text("arXiv")]#text(" my joint paper with ")#link("http://www.math.ucla.edu/~timaustin/")[#text("Tim Austin")]#text(", “")#link("http://arxiv.org/abs/0801.2179")[#text("On the testability and repair of hereditary hypergraph properties")]#text("“, which has been submitted to ")#link("http://www3.interscience.wiley.com/journal/38107/home")[#text("Random Structures and Algorithms")]#text(". In this paper we prove some positive and negative results for the testability (and the local repairability) of various properties of directed or undirected graphs and hypergraphs, which can be either monochromatic or multicoloured.")

#text("The negative results have already been discussed in a ")#link("https://terrytao.wordpress.com/2007/10/31/on-the-property-testing-of-hereditary-graph-and-hypergraph-properties/")[#text("previous posting of mine")]#text(", so today I will focus on the positive results. The property testing results here are finitary results, but it turns out to be rather convenient to use a ")#link("http://front.math.ucdavis.edu/math.CO/0602037")[#text("certain correspondence principle")]#text(" (the hypergraph version of the Furstenberg correspondence principle) to convert the question into one about exchangeable probability measures on spaces of hypergraphs (i.e. on random hypergraphs whose probability distribution is invariant under exchange of vertices). Such objects are also closely related to the”graphons” and “hypergraphons” that emerge as graph limits, as studied by ")#link("http://arxiv.org/abs/math/0408173")[#text("Lovasz-Szegedy")]#text(", ")#link("http://arxiv.org/abs/0705.2179")[#text("Elek-Szegedy")]#text(", and others. Somewhat amusingly, once one does so, it then becomes convenient to keep track of objects indexed by vertex sets and how they are exchanged via the language of ")#link("http://en.wikipedia.org/wiki/Category_theory")[#text("category theory")]#text(", and in particular using the concept of a ")#link("http://en.wikipedia.org/wiki/Natural_transformation")[#text("natural transformation")]#text(" to describe such objects as exchangeable measures, graph colourings, and local modification rules. I will try to sketch out some of these connections, after describing the main positive results.")

#metadata(none) <tao-08eb56dbec9fe74a359e>

#heading(level: 1)[#text("— Statement of results —")]

#text("Property testing in graph and hypergraph theory has primarily focused on undirected graphs ")#mi("(V, E)")#text(", where ")#tao-math("E \\subset \\binom{V}{2} := \\{ e \\subset V: \\left|e\\right| = 2 \\}", block: false)#text(" is a set of undirected edges of a finite vertex set V. In this paper, we consider some more general objects than undirected graphs, in increasing order of generality:")

#enum(start: 1, 
[#emph[#text("Undirected ")#link("http://en.wikipedia.org/wiki/Hypergraph")[#text("hypergraphs")]]#text(" ")#mi("(V,E)")#text(" of some order k, where ")#tao-math("E \\subset \\binom{V}{k} := \\{ e \\subset V: \\left|e\\right| = k \\}", block: false)#text(" is a collection of unordered edges on a vertex set V of order k;")],
[#emph[#text("Directed hypergraphs")]#text(" ")#mi("(V,E)")#text(" of some order k, where ")#mi("E \\subset \\text{Inj}([k],V)")#text(" is a collection of injective maps from the k-element set ")#mi("{}[k] := \\{1,\\ldots,k\\}")#text(" to V (which should be viewed as directed edges of order k, or ")#emph[#text("k-edges")]#text(" for short);")],
[#emph[#text("Coloured directed hypergraphs")]#text(" ")#mi("(V,G_k)")#text(" of some order k, in which ")#mi("G_k: \\text{Inj}([k],V) \\to K_k")#text(" is a colouring of all k-edges by some finite palette ")#mi("K_k")#text(";")],
[#emph[#text("Multiple coloured directed hypergraphs")]#text(" ")#mi("(V,G_0,\\ldots,G_k)")#text(" of order k, in which ")#mi("G_j: \\text{Inj}([j],V) \\to K_j")#text(" is a colouring of j-edges by some component ")#mi("K_j")#text(" of a palette ")#mi("K = (K_0,\\ldots,K_k)")#text(". We’ll call such hypergraphs ")#emph[#text("K-hypergraphs")]#text(" for short. [It is natural, in view of the hypergraph regularity lemma, to consider multiple orders of hypergraphs at once, even if initially one is only interested in hypergraphs of a certain fixed order. For instance, one might be interested in graphs (which are hypergraphs of order 2), but the regularity lemma would then require one to partition the vertices into classes (thus creating a coloured hypergraph of order 1).]")]
)

#text("(We also consider a continuous analogue of these concepts, in which the vertex set is a probability space rather than a discrete set, and loops are allowed but for simplicity we will not discuss this generalisation here.)")

#text("We now fix a palette K. For any vertex set V, let ")#mi("K^{(V)}")#text(" be the collection of all K-hypergraphs on V. Observe that every injective map ")#mi("\\phi: V \\to W")#text(" induces a ")#emph[#link("http://en.wikipedia.org/wiki/Pullback")[#text("pullback")]#text(" map")]#text(" ")#mi("K^{(\\phi)}: K^{(W)} \\to K^{(V)}")#text(", which is ")#link("http://en.wikipedia.org/wiki/Covariance_and_contravariance_of_functors")[#text("contravariant")]#text(" in the sense that ")#mi("K^{(\\phi \\circ \\psi)} = K^{(\\psi)} \\circ K^{(\\phi)}")#text(" for any pair of injections ")#mi("\\psi: U \\to V")#text(" and ")#mi("\\phi: V \\to W")#text(". Thus one can view K as a contravariant ")#link("http://en.wikipedia.org/wiki/Functor")[#text("functor")]#text(" from a category of vertex sets to a category of spaces (which we will later identify as a category of sub-")#link("http://en.wikipedia.org/wiki/Cantor_space")[#text("Cantor spaces")]#text(").")

#text("We’ll be considering various properties of K-hypergraphs, or ")#emph[#text("K-properties")]#text(" for short. Formally, a K-property ")#mi("{\\mathcal P}")#text(" is an assignment ")#mi("V \\mapsto {\\mathcal P}^{(V)}")#text(" of a collection ")#mi("{\\mathcal P}^{(V)} \\subset K^{(V)}")#text(" of K-hypergraphs for each vertex set V; one should view ")#mi("{\\mathcal P}^{(V)}")#text(" as the collection of K-hypergraphs on V which satisfy the property ")#mi("{\\mathcal P}")#text(". We will restrict attention to those properties which are ")#emph[#text("hereditary")]#text(", which means that they are preserved under pullbacks; thus any given pullback map ")#mi("K^{(\\phi)}: K^{(W)} \\to K^{(V)}")#text(" restricts to a map ")#mi("{\\mathcal P}^{(\\phi)}: {\\mathcal P}^{(W)} \\to {\\mathcal P}^{(V)}")#text(". Thus hereditary properties can also be viewed as contravariant functors.")

#text("[Traditionally, hereditary properties are defined as those properties of (hyper)graphs which are preserved under (hyper)graph isomorphism as well as (hyper)graph restriction, but it is not hard to see that the above definition is equivalent.]")

#text("For graphs, examples of hereditary properties include that of being complete, of being bipartite, of being planar, of being four-colourable, of being triangle-free, etc.")

#text("It is convenient to extend a K-property ")#mi("{\\mathcal P}")#text(" from finite hypergraphs to infinite ones by declaring an infinite hypergraph to obey ")#mi("{\\mathcal P}")#text(" if and only if all of its finite induced subhypergraphs obey ")#mi("{\\mathcal P}")#text(". With this convention, ")#mi("{\\mathcal P}^{(V)}")#text(" becomes a closed subspace of ")#mi("K^{(V)}")#text(" (which we give the product topology), and in particular is compact.")

#text("We say that a K-property ")#mi("{\\mathcal P}")#text(" is ")#emph[#text("locally testable with one-sided error")]#text(" (or ")#emph[#text("testable")]#text(" for short) if one can probabilistically test for this property on large (hyper)graphs by verifying the property on a small random portions of the (hyper)graph. More formally, we say that ")#mi("{\\mathcal P}")#text(" is testable if for every ")#mi("\\varepsilon > 0")#text(" there exists an N and ")#mi("\\delta > 0")#text(" such that if ")#mi("G \\in K^{(V)}")#text(" is a K-hypergraph on a large vertex set V (with ")#tao-math("\\left|V\\right| > N", block: false)#text(") which N-locally obeys ")#mi("{\\mathcal P}")#text(" to accuracy ")#mi("1-\\delta")#text(" in the sense that the restriction of G to a randomly chosen N-element subset obeys ")#mi("{\\mathcal P}")#text(" with probability ")#mi("1-\\delta")#text(", then G itself is ")#mi("\\varepsilon")#text("-close to obeying ")#mi("{\\mathcal P}")#text(" in the sense that there is a K-hypergraph ")#mi("G^{\\prime} \\in {\\mathcal P}^{(V)}")#text(" such that G and G’ agree on a randomly chosen k-element subset of V with probability at least ")#mi("1-\\varepsilon")#text(". [This notion of testability has ")#emph[#text("one-sided ")]#text("error because there are no ")#link("http://en.wikipedia.org/wiki/False_negative")[#text("false negatives")]#text(": if a local portion of G disobeys ")#mi("{\\mathcal P}")#text(", then G itself certainly disobeys ")#mi("{\\mathcal P}")#text(", since ")#mi("{\\mathcal P}")#text(" is hereditary. See this ")#link("http://www.wisdom.weizmann.ac.il/~oded/test.html")[#text("web page of Goldreich")]#text(" for more discussion of property testing in general.]")

#text("Our first main positive result is:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(". Every hereditary K-property is testable.")
]

#text("This result was previously shown ")#link("http://www.math.tau.ac.il/~nogaa/PDFS/heredit2.pdf")[#text("by Alon and Shapira")]#text(" for undirected monochromatic graph properties, ")#link("http://www.informatik.hu-berlin.de/~schacht/pub/preprints/dense_reg2.pdf")[#text("by Rodl and Schacht")]#text(" for undirected monochromatic hypergraph properties, and ")#link("http://arxiv.org/abs/math/0612669")[#text("by Ishigami")]#text(" for partite hypergraph properties. There is also a substantial body of earlier partial results on property testing of graph and hypergraph properties, and properties of other combinatorial objects, which are too numerous to be listed here. Remarkably, this theorem can be used to prove some results in additive combinatorics, most notably ")#link("http://www.scholarpedia.org/article/Szemer%C3%A9di%27s_Theorem")[#text("Szemerédi’s theorem")]#text(" on arithmetic progressions; see for instance my ")#link("http://front.math.ucdavis.edu/math.CO/0604456")[#text("Montreal notes")]#text(" for further discussion.")

#text("Our other positive results go beyond testability to prove a stronger property, which we have dubbed “local repairability”. This notion, analogous to that of local correctability in the theory of error-correcting codes, takes a bit of notation to define properly. Define a ")#emph[#text("modification rule ")]#text("to be a pair ")#mi("T = (A,\\overline{T})")#text(", where A is a finite set of vertices, and for each vertex set V, ")#mi("\\overline{T}^{(V)}: K^{(A \\uplus V)} \\to K^{(V)}")#text(" is a map which converts K-hypergraphs on the ")#link("http://en.wikipedia.org/wiki/Disjoint_union")[#text("disjoint union")]#text(" ")#mi("A \\uplus V")#text(" to K-hypergraphs on V; one should view the vertex set A as supplying some “test data” in which to determine how to modify the rest of the hypergraph. We say that the modification rule is ")#emph[#text("local")]#text(" if the diagram")

#align(center)[#tao-fit-display[#mitex("\\begin{array}{ccc} K^{(A \\uplus W)} & \\stackrel{K^{(id_A \\uplus \\phi)}}{\\longrightarrow} & K^{(A \\uplus V)} \\\\ \\downarrow^{\\overline{T}^{(W)}} & & \\downarrow^{\\overline{T}^{(V)}} \\\\ K^{(W)} & \\stackrel{K^{(\\phi)}}{\\longrightarrow} & K^{(V)} \\end{array}")]]

#text("commutes for all injections ")#mi("\\phi: V \\to W")#text(". (Apologies for the clunky diagram; I have had some difficulties with doing advanced LaTeX in wordpress.) Informally, a local modification rule will modify each edge based only on the connectivity of the vertices of that edge with A, and will not care about the precise labels assigned to those vertices. We say that a local modification rule ")#link("http://en.wikipedia.org/wiki/Entailment")[#text("entails")]#text(" a K-property ")#mi("{\\mathcal P}")#text(" if we have ")#mi("\\overline{T}^{(V)}: K^{(A \\uplus V)} \\subset {\\mathcal P}^{(V)}")#text(" for all vertex sets V.")

#text("One can view a local modification rule T as defining a ")#link("http://en.wikipedia.org/wiki/Natural_transformation")[#text("natural transformation")]#text(" ")#mi("\\overline{T}")#text(" from the contravariant functor ")#mi("K^{\\uplus A}")#text(" (which assigns the space ")#mi("K^{(A \\uplus V)}")#text(" to each vertex set V) to the contravariant functor K. (We found it convenient to use the concept of a natural transformation in our paper, and in particular the standard fact that the composition of natural transformations is again a natural transformation, as it allowed us to easily localise or permute the vertex sets one was working on.)")

#text("Perhaps an example will illustrate what a “local modification rule” is. Suppose one has a graph G which is nearly complete bipartite, in the sense that one can partition the vertex set V into two vertex sets W and W’, such that at least 99% (say) of the edges between W and W’ lie in G, and at most 1% of the edges within W or within W’ lie in G. We would like to locally modify this graph to one which really is complete bipartite. One way to do this is to select a special vertex a inside V at random. One can then create a modified graph ")#mi("T_a(G)")#text(" on ")#mi("V_a := V \\backslash \\{a\\}")#text(", defined by partitioning ")#mi("V_a = W_a \\cup W^{\\prime}_a")#text(" into the vertices ")#mi("W_a")#text(" connected to a, and the vertices ")#mi("W^{\\prime}_a")#text(" not connected to a, and then forming the complete bipartite graph between ")#mi("W_a")#text(" and ")#mi("W^{\\prime}_a")#text(". One can view ")#mi("T_a(G)")#text(" as the action of a modification rule $(\\{1\\},T)$ on a pullback ")#mi("K^{(\\phi)}")#text(" of G, where ")#mi("\\phi: \\{1\\} \\uplus V_a \\to V")#text(" is the map that sends 1 to a and is the identity on ")#mi("V_a")#text(". The rule T entails the property of being complete bipartite. Also, observe that if a is chosen randomly, then ")#mi("T_a(G)")#text(" is close to G in the sense that any edge in G has at least a 95% chance (say) of being an edge in ")#mi("T_a(G)")#text(" (if V is large enough), and similarly any non-edge in G has at least a 95% chance of being a non-edge of ")#mi("T_a(G)")#text(".")

#text("We say that a K-property ")#mi("{\\mathcal P}")#text(" is ")#emph[#text("locally repairable")]#text(" if for every ")#mi("\\varepsilon > 0")#text(" there exists ")#mi("\\delta > 0")#text(", an N, and finite set A such that whenever ")#mi("G \\in K^{(V)}")#text(" is a sufficiently large K-hypergraph which N-locally obeys ")#mi("{\\mathcal P}")#text(" to accuracy ")#mi("1-\\delta")#text(", then there exists local modification rule ")#mi("T = (A, \\overline{T})")#text(" such that if ")#mi("\\phi: A \\to V")#text(" is a random injection, then the colour of any given edge in G will match the same edge in ")#mi("T_\\phi(G) := T^{(V \\backslash \\phi(A))}( K^{(\\phi \\cup \\text{id}_{V \\backslash \\phi(A)})}(G) )")#text(" with probability at least ")#mi("1-\\varepsilon")#text(", where ")#mi("\\phi \\cup \\text{id}_{V \\backslash \\phi(A)}: A \\uplus (V \\backslash \\phi(A)) \\to V")#text(" is the bijection that equals ")#mi("\\phi")#text(" on A and the identity on ")#mi("V \\backslash \\phi(A)")#text(".")

#text("The above definition was quite convoluted, but informally, if a property ")#mi("{\\mathcal P}")#text(" is locally repairable, then it is possible to probabilistically “repair” with high probability any large hypergraph G on V which “almost” obeys ")#mi("{\\mathcal P}")#text(" by first selecting a bounded number of random test vertices ")#mi("\\phi(A)")#text(", and modifying the colour of each edge outside of ")#mi("\\phi(A)")#text(" by looking only at how the vertices of that edge connect with ")#mi("\\phi(A)")#text(".")

#text("Local repairability is stronger than testability. Testability asserts that hypergraphs which nearly obey ")#mi("{\\mathcal P}")#text(" can be modified to actually obey ")#mi("{\\mathcal P}")#text(", but do not specify how to locate this modification; local repairability shows that such a modification can be built using a local modification rule. [Another indication of how repairability is stronger than testability is that we can use the repairability of various properties to deduce ")#link("http://en.wikipedia.org/wiki/Ramsey%27s_theorem")[#text("Ramsey’s theorem")]#text(", which does not seem to be the case for testability.]")

#text("With all this notation, we can state our next three theorems:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(". Every undirected graph property is locally repairable.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(". Every monotone hypergraph property is locally repairable.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4")]#text(". Every partite hypergraph property is locally repairable.")
]

#text("(There are precise definitions of what it means for a property to be undirected, monotone, or partite, which are given in our paper; but I will not give them here as they are not particularly illuminating.) These hypotheses are close to being sharp; we have counterexamples to local repairability for directed graph properties or undirected hypergraph properties once all assumptions of monotonicity or partiteness are dropped, as discussed in ")#link("https://terrytao.wordpress.com/2007/10/31/on-the-property-testing-of-hereditary-graph-and-hypergraph-properties/")[#text("my previous post")]#text(". I should remark that Theorem 4 is also implicitly present in a ")#link("http://arxiv.org/abs/math/0612669")[#text("paper of Ishigami")]#text(".")

#heading(level: 1)[#text("— The correspondence principle —")]

#text("Our proofs of the above theorems use the correspondence principle between statements concerning finite hypergraphs, and statements concerning exchangeable measures on spaces of infinite hypergraphs (or equivalently, concerning infinite exchangeable random hypergraphs).")

#text("The basic way the correspondence principle is invoked is via the following “compactness and contradiction” argument, which also appears in many other places in mathematics (e.g. in PDE):")

#enum(start: 1, 
[#text("Suppose we are trying to prove some asymptotic statement about finite hypergraphs. We assume for contradiction that the claim is false, thus obtaining a sequence of hypergraphs ")#mi("G_n \\in K^{(V_n)}")#text(" which form increasingly strong counterexamples to that statement. (Typically, the size of these graphs will go to infinity as n goes to infinity.)")],
[#text("We sample randomly from each of the finite graphs ")#mi("G_n \\in K^{(V_n)}")#text(" to create a sequence of infinite random graphs ")#mi("\\tilde G_n \\in K^{({\\Bbb Z})}")#text(", by randomly mapping ")#mi("{\\Bbb Z}")#text(" into ")#mi("V_n")#text(" and pulling back the graph. (There will be some collisions when multiple integers map to the same vertex, but as the original graph gets larger, these collisions get rarer, so it will actually not make much difference what we do in the case of collisions.) One can view each infinite random graph ")#mi("\\tilde G_n")#text(" as describing a Borel probability measure ")#mi("\\mu_n")#text(" on the Cantor space ")#mi("K^{({\\Bbb Z})}")#text(". This measure is ")#emph[#text("exchangeable")]#text(", in the sense that it is unchanged if we permute the underlying set of vertices ")#mi("{\\Bbb Z}")#text(". Informally, this measure describes all the “local” or “statistical” information one can observe about a given hypergraph.")],
[#text("We then exploit the fact that the space of ")#link("http://en.wikipedia.org/wiki/Borel_algebra")[#text("Borel")]#text(" probability measures on a given (")#link("http://en.wikipedia.org/wiki/Borel_algebra")[#text("standard Borel")]#text(") space is vaguely sequentially compact, so that (after passing to a subsequence) we can extract a vague limit ")#mi("\\mu")#text(" of the ")#mi("\\mu_n")#text(". Since the ")#mi("\\mu_n")#text(" are the laws of exchangeable random hypergraphs which are increasingly strong counterexamples to the initial statement one is trying to prove, the infinite random hypergraph corresponding to ")#mi("\\mu")#text(" should be a “perfect” counterexample to this statement.")],
[#text("We then work in the setting of infinite exchangeable random hypergraphs to show that no such perfect counterexamples in fact exist.")]
)

#text("Actually, in order to use the concept of a natural transformation effectively, it is convenient not to work with a single probability measure ")#mi("\\mu")#text(" on a single space of hypergraphs, but instead to work with a separate probability measure ")#mi("\\mu^{(V)}")#text(" on ")#mi("K^{(V)}")#text(" for each vertex set V, which is consistent with the pullback maps ")#mi("K^{(\\phi)}")#text(". One can view ")#mi("\\mu")#text(" as a natural transformation from a trivial functor ")#mi("V \\mapsto \\text{pt}")#text(" to the functor ")#mi("V \\mapsto K^{(V)}")#text(", in which we allow morphisms to be probability kernels rather than continuous maps. (A ")#emph[#text("probability kernel")]#text(" ")#mi("P: X \\rightsquigarrow Y")#text(" between two ")#link("http://en.wikipedia.org/wiki/Borel_algebra")[#text("standard Borel")]#text(" spaces is a map ")#mi("x \\mapsto P(x)")#text(" which assigns a Borel probability measure P(x) on Y to every point in x in a weakly measurable manner, thus the map ")#mi("x \\mapsto P(x)(E)")#text(" is measurable for every Borel set E in Y. One can think of a probability kernel as describing a random function from X to Y.)")

#text("By using the above correspondence principle, combined with a structural theorem ")#link("http://arxiv.org/abs/0801.1698")[#text("of Austin")]#text(" for exchangeable random hypergraphs (which is the infinitary analogue of the hypergraph regularity lemma, and also generalises a classical ")#link("http://en.wikipedia.org/wiki/De_Finetti's_theorem")[#text("theorem of de Finetti")]#text(" on exchangeable measures; it is closely related to similar results ")#link("http://www.ams.org/mathscinet-getitem?mr=883646")[#text("of Aldous")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1182678")[#text("of Kallenberg")]#text(") one can reformulate the concepts of testability and local repairability of a given K-property ")#mi("{\\mathcal P}")#text(" in terms of natural transformations on sub-Cantor spaces (closed subspaces of ")#link("http://en.wikipedia.org/wiki/Cantor_space")[#text("Cantor spaces")]#text("), where we allow morphisms on these spaces to either be deterministic (functions, possibly continuous), or probabilistic (i.e. probability kernels). The precise formulation is technical (requiring even more notation than just presented, in particular the concept of a ")#emph[#text("regularised exchangeable recipe")]#text(" ")#mi("V \\mapsto \\mu^{(V)}")#text(", which is the infinitary analogue of a regularised graph or hypergraph), but roughly speaking, a property ")#mi("{\\mathcal P}")#text(" is locally repairable if every regularised exchangeable recipe which almost surely obeys ")#mi("{\\mathcal P}")#text(" can be modified by a deterministically continuous natural transformation to surely obey ")#mi("{\\mathcal P}")#text(" while only modifying a small number of edges on average, whereas a")#mi("{\\mathcal P}")#text(" is testable if every regularised exchangeable recipe with almost surely obeys ")#mi("{\\mathcal P}")#text(" can be modified by a probabilistically continuous natural transformation (i.e. the morphisms are probability kernels which are continuous in the weak topology) whose output almost surely obeys ")#mi("{\\mathcal P}")#text(" for each input, and which also only modifying a small number of edges on average.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 5: Other topological recurrence results « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/16/on-the-testability-and-repair-of-hereditary-hypergraph-properties/#comment-24780")[#strong[#text("254A, Lecture 5: Other topological recurrence results « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2008")])]

#text("[…] Remark 4. More generally, one can interpret the theory of graphs and hypergraphs on a vertex set V through the lens of dynamics of actions; I learned this perspective from Balazs Szegedy, and it underlies my paper on the hypergraph correspondence principle, as well as my more recent paper with Tim Austin on hypergraph property testing. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The correspondence principle and finitary ergodic theory « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/16/on-the-testability-and-repair-of-hereditary-hypergraph-properties/#comment-32310")[#strong[#text("The correspondence principle and finitary ergodic theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2008")])]

#text("[…] it actually implies the k=3 case of Szemerédi’s theorem. (See also my previous blog posts on related topics.) It turns out that this result can be deduced from some infinitary versions of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 10: The Furstenberg correspondence principle « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/16/on-the-testability-and-repair-of-hereditary-hypergraph-properties/#comment-33700")[#strong[#text("254A, Lecture 10: The Furstenberg correspondence principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2008")])]

#text("[…] and hypergraphs to the measure theory of exchangeable measures: see this paper of myself, and of myself and Austin, for details. There is also a correspondence principle connecting ergodic convergence theorems with […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54b6b6a3e3289d9a615048307b7183b6e89ae36446685fb112f3b17296da5659-f50988431539fb7b3b50e75ff63cdcdbf93e99ca1351c51930670ecbada4b2fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of RaiulBaztepo")]], [#link("https://terrytao.wordpress.com/2008/01/16/on-the-testability-and-repair-of-hereditary-hypergraph-properties/#comment-37484")[#strong[#text("RaiulBaztepo")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2009")])]

#text("Hello!")#linebreak()#text(" Very Interesting post! Thank you for such interesting resource!")#linebreak()#text(" PS: Sorry for my bad english, I’v just started to learn this language ;)")#linebreak()#text(" See you!")#linebreak()#text(" Your, Raiul Baztepo")
]
