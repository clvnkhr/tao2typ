// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/01/13/distinguished-lecture-series-i-gregory-margulis-homogeneous-dynamics-and-number-theory-i/
// Converted to Typst by tao2typ: "2026-10-14T16:35:31.551619+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Distinguished Lecture Series I: Gregory Margulis, “Homogeneous dynamics and number theory I.”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Distinguished Lecture Series I: Gregory Margulis, “Homogeneous dynamics and number theory I.”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 January 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/01/13/distinguished-lecture-series-i-gregory-margulis-homogeneous-dynamics-and-number-theory-i/")[#text("https://terrytao.wordpress.com/2009/01/13/distinguished-lecture-series-i-gregory-margulis-homogeneous-dynamics-and-number-theory-i/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("http://www.math.ucla.edu/dls/2009/margulis.shtml")[#text("final distinguished lecture series")]#text(" for the academic year here at UCLA is being given this week by ")#link("http://en.wikipedia.org/wiki/Grigory_Margulis")[#text("Gregory Margulis")]#text(", who is giving three lectures on “homogeneous dynamics and number theory”. In his first lecture, Prof. Margulis surveyed some classical problems in number theory that turn out, rather surprisingly, to have more or less equivalent counterparts in homogeneous dynamics – the theory of dynamical systems on homogeneous spaces ")#mi("G/\\Gamma")#text(".")

#text("As usual, any errors in this post are due to my transcription of the talk.")

#metadata(none) <tao-6c93301896a316b14930>#text("Prof. Margulis began with perhaps the most famous open problem in number theory, namely the ")#link("http://en.wikipedia.org/wiki/Riemann_hypothesis")[#text("Riemann hypothesis")]#text(". From the work ")#link("http://www.ams.org/mathscinet-getitem?mr=633666")[#text("of Zagier")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=634284")[#text("of Sarnak")]#text(", one can rephrase this hypothesis in terms of closed orbits on the modular surface ")#mi("\\Omega_2 := SL_2({\\Bbb R})/SL_2({\\Bbb Z})")#text(", which one can think of as the space of all ")#link("http://en.wikipedia.org/wiki/Unimodular_lattice")[#text("unimodular lattices")]#text(" in ")#mi("{\\Bbb R}^2")#text(", or as the canonical circle bundle over the ")#link("http://en.wikipedia.org/wiki/Poincar%C3%A9_half-plane")[#text("upper half-plane")]#text(" ")#mi("({\\Bbb H}, \\frac{dx dy}{y})")#text(". On this surface we have the action of the one-parameter group")

#align(center)[#tao-fit-display[#mitex("U := \\{ \\begin{pmatrix} 1 & t \\\\ 0 & 1 \\end{pmatrix} \\} \\subset SL_2({\\Bbb R})")]]

#text("which correspond to horizontal translations on the upper half-plane. For each ")#mi("t > 0")#text(", there is a unique closed orbit ")#mi("C_t")#text(" of U of length t (which, on the upper half-plane, corresponds to a horizontal line). The Riemann hypothesis is then equivalent to the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{t} \\int_{C_t} f = \\int_{\\Omega_2} f + O( t^{-3/4 + \\varepsilon} )")]]

#text("for any fixed ")#mi("f \\in C^\\infty_0(\\Omega_2)")#text(" and ")#mi("\\varepsilon > 0")#text(" (with the implied constant in the O() notation depending on these parameters), where the integrals are with respect to Haar measure. See for instance this ")#link("http://www.ams.org/mathscinet-getitem?mr=1296930")[#text("paper of Verjovsky")]#text(" for further discussion of this connection. One should observe that the error term here is better than what probabilistic heuristics might naively suggest, namely ")#mi("O( t^{-1/2 + \\varepsilon} )")#text("; thus the orbits ")#mi("C_t")#text(" are distributed ")#emph[#text("better")]#text(" than a “random” curve of comparable length, in some sense. Incidentally, the bound of ")#mi("O( t^{-1/2 + \\varepsilon} )")#text(" is equivalent to the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(", and is thus close to the best bound known on the problem. Margulis also noted that one could restrict attention to K-invariant functions f, where ")#mi("K \\equiv SO_2({\\Bbb R})")#text(" was a maximal compact subgroup of ")#mi("SL_2({\\Bbb R})")#text(", which basically allows one to work on the half-plane ")#mi("{\\Bbb H}")#text(" rather than its circle bundle. However, he doubted that this formulation of the Riemann hypothesis was really the way to proceed in proving that hypothesis.")

#text("Nevertheless, there are many other problems in number theory for which non-trivial progress ")#emph[#text("has")]#text(" been made by converting them to a question on dynamics in homogeneous spaces. One famous example is the ")#link("http://en.wikipedia.org/wiki/Oppenheim_conjecture")[#text("Oppenheim conjecture")]#text(" (which I also blogged about ")#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/")[#text("here")]#text("), first proven in full generality by Margulis. It concerns the possible values ")#mi("Q(m_1,\\ldots,m_n)")#text(" of a real ")#link("http://en.wikipedia.org/wiki/Quadratic_form")[#text("quadratic form")]#text(" ")#mi("Q: {\\Bbb R}^n \\to {\\Bbb R}")#text(" on n variables, when the inputs ")#mi("m_1,\\ldots,m_n")#text(" are restricted to be integers, not all zero; in other words, one wants to study the set ")#mi("Q( {\\Bbb Z}^n \\backslash \\{0\\} )")#text(".")

#text("There are several obvious conditions that prevent this set from being dense in the reals. For instance, if the form is ")#link("http://en.wikipedia.org/wiki/Definite_bilinear_form")[#text("definite")]#text(", then of course Q takes values on only one half of the real line. Also, if Q has rational coefficients, or is a scalar multiple of a form with rational coefficients, then it is clear that Q will take values in a discrete set. Finally, for indefinite forms of two variables such as ")#mi("Q(x_1,x_2) = x_1^2 - \\lambda x_2^2 = (x_1 - \\sqrt{\\lambda} x_2) (x_1 + \\sqrt{\\lambda} x_2)")#text(", the classical theory of ")#link("http://en.wikipedia.org/wiki/Continued_fraction")[#text("continued fractions")]#text(" tells us that ")#mi("Q(m_1,m_2)")#text(" will stay a bounded distance away from zero for integers ")#mi("m_1,m_2")#text(" not both zero, as long as ")#mi("\\lambda")#text(" is a number whose continued fraction expansion consists of bounded integers (e.g. one can take ")#mi("\\lambda = 1 + \\sqrt{3}")#text(").")

#text("The Oppenheim conjecture (in its modern form) asserted that these are the only obstructions to ")#mi("Q( {\\Bbb Z}^n \\backslash \\{0\\} )")#text(" being dense, or to (the marginally simpler statement that) ")#mi("Q( {\\Bbb Z}^n \\backslash \\{0\\})")#text(" can be arbitrarily close to zero: thus any indefinite real irrational quadratic form in three or more variables should take values arbitrary close to zero for integer inputs, not all zero. (Oppenheim only conjectured this for ")#mi("n \\geq 5")#text(", by reasoning in analogy with ")#link("http://en.wikipedia.org/wiki/Meyer%27s_theorem")[#text("Meyer’s theorem")]#text(", which asserts that indefinite real ")#emph[#text("rational")]#text(" quadratic forms of five or more variables will attain zero for some non-trivial choice of integer inputs; this theorem fails in four or fewer variables, but it turns out that the Oppenheim conjecture does not.)")

#text("The hardest case of the Oppenheim conjecture is n=3; there are some easy arguments available that allow one to deduce the conjecture for many variables from the conjecture for few variables. Accordingly, the first progress on the problem was in the case when there were many variables. By using analytic number theory methods (in particular, the circle method), Davenport and his coauthors in a series of papers from 1945 to 1960 established the conjecture for all forms in 21 or more variables, and for diagonal forms in 5 or more variables. The methods gave effective bounds. More recently, the work ")#link("http://www.ams.org/mathscinet-getitem?mr=1740988")[#text("of Bentkus and Götze")]#text(" gave an effective proof of the Oppenheim conjecture for any quadratic form in nine or more variables, and recent work in progress by Götze and Margulis lowered this to five. Margulis noted that five variables was the natural limit of the circle method, for a reason which could be stated succinctly as")

#align(center)[#tao-fit-display[#mitex("\\frac{5}{2} > 2,")]]

#text("where the 2 on the denominator indicates the ")#mi("L^2")#text("-based nature of the circle method, and the 2 on the right-hand side indicates the degree of the quadratic form. (Similarly, more “linear” problems such as representing a number as the sum of primes are only amenable to the circle method when summing three or more primes, because ")#mi("\\frac{3}{2} > 1")#text(".) One can formalise this heuristic by computing what the most optimistic bounds on Fourier coefficients of sparse sets (e.g. the set of squares) one could hope to have (using Plancherel’s theorem, which is of course an ")#mi("L^2")#text("-based identity), and then inserting that into the circle method.")

#text("The reformulation of the Oppenheim conjecture as a dynamical one was first made explicit ")#link("http://www.ams.org/mathscinet-getitem?mr=507234")[#text("by Raghunathan")]#text(", although many of the ideas behind this connection appear earlier in a paper ")#link("http://www.ams.org/mathscinet-getitem?mr=70653")[#text("by Cassels and Swinnerton-Dyer")]#text(". The underlying space for this dynamical system is the space ")#mi("\\Omega_n := SL_n({\\Bbb R})/SL_n({\\Bbb Z})")#text(" of n-dimensional unimodular lattices; this is not a compact space, but it does have finite measure with respect to Haar measure, and should be thought of as a bounded region with a ")#link("http://en.wikipedia.org/wiki/Cusp_(singularity)")[#text("cusp")]#text(" glued onto it. (When n=2, the cusp is topologically a thickened version of a half-line; more generally, from the “")#link("http://en.wikipedia.org/wiki/Coarse_geometry")[#text("coarse geometry")]#text("” viewpoint it is a n-1-dimensional simplicial cone, which not coincidentally is also the ")#link("http://en.wikipedia.org/wiki/Weyl_chamber")[#text("Weyl chamber")]#text(" of ")#mi("SL_n({\\Bbb R})")#text(".)")

#text("Given a quadratic form Q of n variables, one can form the isometry group ")#mi("H_Q \\subset SL_n({\\Bbb R})")#text(" of unimodular transformations that preserve Q. This group acts on ")#mi("\\Omega_n")#text(", of course, and so if z is any point in ")#mi("\\Omega_n")#text(" (i.e. unimodular lattice) then one has an orbit ")#mi("H_Q z")#text(" in ")#mi("\\Omega_n")#text(". The Oppenheim conjecture can then be deduced from the following claim:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Claim 1")]#text(". Let Q be the quadratic form ")#mi("Q(x_1,x_2,x_3) := 2x_1x_3 - x_2^2")#text(" (say) on three variables, and let ")#mi("z \\in \\Omega_3")#text(" be such that the orbit ")#mi("H_Q z")#text(" is precompact (i.e. it stays away from the cusp). Then ")#mi("H_Q z")#text(" is closed (or equivalently, that ")#mi("H_Q \\cap G_z")#text(" is cocompact in ")#mi("H_Q")#text(", where ")#mi("G_z")#text(" is the stabiliser of z.")
]

#text("The deduction of the Oppenheim conjecture from this claim is immediate once one has two additional observations. The first observation, valid in any dimension n, is that ")#mi("H_Q {\\Bbb Z}^n")#text(" is precompact if and only if ")#mi("Q({\\Bbb Z}^n \\backslash \\{0\\})")#text(" stays a non-zero distance away from the origin; this is an easy consequence of the ")#emph[#text("Mahler compactness criterion")]#text(" for unimodular lattices, which asserts that a set of unimodular lattices is precompact iff the non-zero vertices of these lattices stay a bounded distance away from the origin. The second observation, which is specific to three dimensions, is that ")#mi("H_Q \\cap G_z")#text(" is precompact iff Q is rational (i.e. it is a scalar multiple of a form with rational coefficients) and anisotropic (which means that it does not attain the value zero over the rationals, except of course at the origin). This can be proven by elementary means (as was done by Cassels and Swinnerton-Dyer) but can also be deduced from the ")#emph[#text("Borel density theorem")]#text(".")

#text("(The above argument initially just shows that ")#mi("Q( {\\Bbb Z}^n \\backslash \\{0\\})")#text(" gets arbitrarily close to the origin, but a modification of the argument shows the stronger statement that ")#mi("Q({\\Bbb Z}^n)")#text(" is in fact dense in ")#mi("{\\Bbb R}")#text(".)")

#text("Next, Margulis turned to another classical number theory problem, which unlike the Oppenheim conjecture remains open:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#link("http://en.wikipedia.org/wiki/Littlewood_conjecture")[#text("Littlewood conjecture. ")]#text(" ")]#text("Let ")#mi("\\alpha, \\beta")#text(" be real numbers. Then ")#tao-math("\\liminf_{n \\to \\infty} n \\left\\|n \\alpha\\right\\| \\left\\| n\\beta\\right\\| = 0", block: false)#text(", where ")#tao-math("\\left\\|x\\right\\|", block: false)#text(" denotes the distance from x to the nearest integer.")
]

#text("As implicitly observed by Cassels and Swinnerton-Dyer, this conjecture follows from the n=3 case of the following Oppenheim-like conjecture:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1.")]#text(" Let ")#mi("n \\geq 3")#text(", and let ")#mi("L: {\\Bbb R}^n \\to {\\Bbb R}")#text(" be the product of n linear forms, such that L is not a scalar multiple of a form with rational coefficients. Then ")#mi("L({\\Bbb Z}^n \\backslash \\{0\\})")#text(" takes values arbitrarily close to zero.")
]

#text("(The conjecture is false for n=2.)")

#text("As with the Oppenheim conjecture, this conjecture has a dynamical reformulation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1, equivalent form.")]#text(" Let ")#mi("n \\geq 3")#text(", and let ")#mi("A \\subset SL_n({\\Bbb R})")#text(" be the subgroup consisting of diagonal matrices with positive entries, and let ")#mi("z \\in SL_n({\\Bbb R})/SL_n({\\Bbb Z})")#text(" be such that ")#mi("Az")#text(" is precompact. Then ")#mi("Az")#text(" is closed.")
]

#text("In a ")#link("http://www.ams.org/mathscinet-getitem?mr=2247967")[#text("recent work of Einseidler, Katok, and Lindenstrauss")]#text(", this equivalent form was used to show that the set of pairs ")#mi("(\\alpha, \\beta)")#text(" for which Littlewood’s conjecture fails has Hausdorff dimension zero. (It is not hard to show the much weaker statement that the set of exceptions has measure zero.) The basic idea is to show that if the Hausdorff dimension was positive, then it would support an invariant measure of positive entropy, and then to rule out the existence of such measures.")

#text("These questions can be viewed as special cases of a more general question: if G is a connected Lie group, ")#mi("\\Gamma")#text(" is a discrete subgroup, and Y is a smooth submanifold of ")#mi("G/\\Gamma")#text(", what is the asymptotic behaviour of ")#mi("gY")#text(" as ")#mi("g \\in G")#text(" tends to infinity? This problem seems to split into two sub-problems, the question of what ")#mi("gY")#text(" does near infinity (i.e. near any cusps), and what ")#mi("gY")#text(" does in the bounded part of ")#mi("G/\\Gamma")#text(". Roughly speaking, the first type of question is a question in geometry of numbers and covering theory, while the second type of question is one in ergodic theory and dynamical systems.")

#text("A decisive role seems to be played by whether g is unipotent (or is somehow generated by unipotents). The reason for this is the following basic observation: if two points x, y on ")#mi("G/\\Gamma")#text(" differ by a small group rotation ")#mi("h \\approx 1")#text(", then gx, gy will differ by a conjugate ")#mi("ghg^{-1}")#text(" of that rotation. If g is unipotent (or more precisely, if ")#mi("Ad(g)")#text(" is unipotent), then this conjugate will stretch itself away from the identity in a controlled (and specifically, in a polynomial) manner, leading to a controllable understanding of the asymptotic geometry of gY where Y contains both x and y. This basic observation is the key to the resolution of the Oppenheim conjecture. On the other hand, it doesn’t work for the diagonalisable flows that underlie the Littlewood conjecture because there is too much commutativity (and so not enough “stretching”). [Thus, somewhat counter-intuitively, the commutative nature of the dynamics makes the problem more difficult, rather than less.]")

#text("Margulis ended this first lecture by sketching the three basic examples of the above question that he wished to discuss in later lectures. The first example, which relates to the question of finding quantitative results on the Oppenheim conjecture, the homogeneous space is ")#mi("G/\\Gamma = SL_n({\\Bbb R})/SL_n({\\Bbb Z})")#text(", Y = Kz where z is a fixed lattice and ")#mi("K \\equiv SO_n({\\Bbb R})")#text(" is a maximal compact subgroup of G, and g ranges along a one-parameter subgroup. In the second example, which has to do with the asymptotics of integer points on homogeneous varieties, Y is the orbit of an arithmetic subgroup H of ")#mi("SL_n({\\Bbb R})")#text(", and one is interested in the equidistribution of ")#mi("g_i Y")#text(" for various ")#mi("g_i \\to \\infty")#text(". In the third example, which has to do with the metric theory of Diophantine approximation in ")#mi("{\\Bbb R}^n")#text(", one lifts up to ")#mi("SL_{n+1}({\\Bbb R})/SL_{n+1}({\\Bbb Z})")#text(", Y is an orbit of the standard lattice ")#mi("{\\Bbb Z}^{n+1}")#text(", and g ranges over a one-parameter group. [I assume that these examples will be fleshed out in more detail in the next two lectures.]")

#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Distinguished Lecture Series II: Gregory Margulis, “Homogeneous dynamics and number theory II.” « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/13/distinguished-lecture-series-i-gregory-margulis-homogeneous-dynamics-and-number-theory-i/#comment-34970")[#strong[#text("Distinguished Lecture Series II: Gregory Margulis, “Homogeneous dynamics and number theory II.” « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2009")])]

#text("[…] of the Oppenheim conjecture. (Due to lack of time, the third application mentioned in the previous lecture, namely metric theory of Diophantine approximation, was not […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lindenstrauss, Ngo, Smirnov, Villani « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/13/distinguished-lecture-series-i-gregory-margulis-homogeneous-dynamics-and-number-theory-i/#comment-46556")[#strong[#text("Lindenstrauss, Ngo, Smirnov, Villani « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2010")])]

#text("[…] which is also a special case of Ratner’s theorems; this was discussed earlier on this blog at this writeup of a lecture of Margulis, or at this discussion of Ratner’s theorems. Indeed, even though the Oppenheim conjecture is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/13/distinguished-lecture-series-i-gregory-margulis-homogeneous-dynamics-and-number-theory-i/#comment-56140")[#strong[#text("Conférence internationale Géométrie Ergodique (Orsay 2011) I « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2011")]

#text("[…] the topics mentioned above, I strongly recommend reading Terence Tao’s posts on this subject, specially these ones […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/13/distinguished-lecture-series-i-gregory-margulis-homogeneous-dynamics-and-number-theory-i/#comment-136235")[#strong[#text("Greg margulis | Movingonlinese")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2012")]

#text("[…] Distinguished Lecture Series I: Gregory Margulis, “Homogeneous …Jan 13, 2009 … The final distinguished lecture series for the academic year here at UCLA is being given this week by Gregory Margulis, who is giving three … […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/01/13/distinguished-lecture-series-i-gregory-margulis-homogeneous-dynamics-and-number-theory-i/#comment-432566")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2014")])]

#text("You mention that probabilistic heuristics suggest an error rate of ")#mi("O( t^{-1/2 + \\varepsilon} )")#text(". Could you say more about how we get this heuristic? Also, could you explain how this rate is equivalent to the prime number theorem? Is there a reference?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/13/distinguished-lecture-series-i-gregory-margulis-homogeneous-dynamics-and-number-theory-i/#comment-433238")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2014")])]

#text("The heuristic comes from concentration of measure (law of large numbers), which indicates that the sum of ")#mi("n")#text(" mostly independent oscillating bounded quantities should typically be of size ")#mi("O(n^{1/2+\\varepsilon})")#text(". For the classical Riemann hypothesis, this heuristic explanation of RH was first advanced by Denjoy (and is briefly mentioned for instance in ")#link("http://en.wikipedia.org/wiki/Riemann_hypothesis#Arguments_for_and_against_the_Riemann_hypothesis")[#text("the Wikipedia page on RH")]#text(".")
]
]
