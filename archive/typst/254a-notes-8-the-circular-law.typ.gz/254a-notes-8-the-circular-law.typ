// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/
// Converted to Typst by tao2typ: "2026-10-14T16:36:07.604661+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 8: The circular law", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 8: The circular law")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 March 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/")[#text("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In this final set of lecture notes for this course, we leave the realm of self-adjoint matrix ensembles, such as Wigner random matrices, and consider instead the simplest examples of non-self-adjoint ensembles, namely the iid matrix ensembles. (I had also hoped to discuss recent progress in eigenvalue spacing distributions of Wigner matrices, but have run out of time. For readers interested in this topic, I can recommend the recent ")#link("http://www.umpa.ens-lyon.fr/~aguionne/Exp.1019.A.Guionnet.pdf")[#text("Bourbaki exposé of Alice Guionnet")]#text(".)")#linebreak()#text(" The basic result in this area is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Circular law)")]#text(" Let ")#mi("{M_n}")#text(" be an ")#mi("{n \\times n}")#text(" iid matrix, whose entries ")#mi("{\\xi_{ij}}")#text(", ")#mi("{1 \\leq i,j \\leq n}")#text(" are iid with a fixed (complex) distribution ")#mi("{\\xi_{ij} \\equiv \\xi}")#text(" of mean zero and variance one. Then the spectral measure ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(" converges both in probability and almost surely to the circular law ")#tao-math("{\\mu_{circ} := \\frac{1}{\\pi} 1_{\\left|x\\right|^2+\\left|y\\right|^2 \\leq 1}\\ dx dy}", block: false)#text(", where ")#mi("{x, y}")#text(" are the real and imaginary coordinates of the complex plane.")
]

#text("This theorem has a long history; it is analogous to the semi-circular law, but the non-Hermitian nature of the matrices makes the spectrum so unstable that key techniques that are used in the semi-circular case, such as truncation and the moment method, no longer work; significant new ideas are required. In the case of random gaussian matrices, this result was established ")#link("http://www.ams.org/mathscinet-getitem?mr=2129906")[#text("by Mehta")]#text(" (in the complex case) and ")#link("http://www.ams.org/mathscinet-getitem?mr=964668")[#text("by Edelman")]#text(" (in the real case), as was sketched out in Notes. In 1984, ")#link("http://www.ams.org/mathscinet-getitem?mr=773436")[#text("Girko laid out")]#text(" a general strategy for establishing the result for non-gaussian matrices, which formed the base of all future work on the subject; however, a key ingredient in the argument, namely a bound on the least singular value of shifts ")#mi("{\\frac{1}{\\sqrt{n}} M_n - zI}")#text(", was not fully justified at the time. A rigorous proof of the circular law was then established ")#link("http://www.ams.org/mathscinet-getitem?mr=1428519")[#text("by Bai")]#text(", assuming additional moment and boundedness conditions on the individual entries. These additional conditions were then slowly removed in a sequence of papers by ")#link("http://arxiv.org/abs/math/0702386")[#text("Gotze-Tikhimirov")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2085255")[#text("Girko")]#text(", ")#link("http://arxiv.org/abs/0705.3773")[#text("Pan-Zhou")]#text(", and ")#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/")[#text("Tao-Vu")]#text(", with the last moment condition being removed in a ")#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/")[#text("paper of myself, Van Vu, and Manjunath Krishnapur")]#text(".")#linebreak()#text(" At present, the known methods used to establish the circular law for general ensembles rely very heavily on the joint independence of all the entries. It is a key challenge to see how to weaken this joint independence assumption.")#linebreak()#text(" ")#metadata(none) <tao-0ac8960f6a14e992cddf>

#heading(level: 1)[#strong[#text(" — 1. Spectral instability — ")]]

#text("One of the basic difficulties present in the non-Hermitian case is ")#emph[#text("spectral instability")]#text(": small perturbations in a large matrix can lead to large fluctuations in the spectrum. In order for any sort of analytic technique to be effective, this type of instability must somehow be precluded.")#linebreak()#text(" The canonical example of spectral instability comes from perturbing the right shift matrix")

#align(center)[#tao-fit-display[#mitex("U_0 := \\begin{pmatrix} 0 & 1 & 0 & \\ldots & 0 \\\\ 0 & 0 & 1 & \\ldots & 0 \\\\ \\vdots & \\vdots & \\vdots & \\ddots & \\vdots \\\\ 0 & 0 & 0 & \\ldots & 0 \\end{pmatrix}")]]

#text("to the matrix")

#align(center)[#tao-fit-display[#mitex("U_\\varepsilon := \\begin{pmatrix} 0 & 1 & 0 & \\ldots & 0 \\\\ 0 & 0 & 1 & \\ldots & 0 \\\\ \\vdots & \\vdots & \\vdots & \\ddots & \\vdots \\\\ \\varepsilon & 0 & 0 & \\ldots & 0 \\end{pmatrix}")]]

#text("for some ")#mi("{\\varepsilon > 0}")#text(".")#linebreak()#text(" The matrix ")#mi("{U_0}")#text(" is nilpotent: ")#mi("{U_0^n = 0}")#text(". Its characteristic polynomial is ")#mi("{(-\\lambda)^n}")#text(", and it thus has ")#mi("{n}")#text(" repeated eigenvalues at the origin. In contrast, ")#mi("{U_\\varepsilon}")#text(" obeys the equation ")#mi("{U_\\varepsilon^n = \\varepsilon I}")#text(", its characteristic polynomial is ")#mi("{(-\\lambda)^n - \\varepsilon (-1)^n}")#text(", and it thus has ")#mi("{n}")#text(" eigenvalues at the ")#mi("{n^{th}}")#text(" roots ")#mi("{\\varepsilon^{1/n} e^{2\\pi i j/n}}")#text(", ")#mi("{j=0,\\ldots,n-1}")#text(" of ")#mi("{\\varepsilon}")#text(". Thus, even for exponentially small values of ")#mi("{\\varepsilon}")#text(", say ")#mi("{\\varepsilon = 2^{-n}}")#text(", the eigenvalues for ")#mi("{U_\\varepsilon}")#text(" can be quite far from the eigenvalues of ")#mi("{U_0}")#text(", and can wander all over the unit disk. This is in sharp contrast with the Hermitian case, where eigenvalue inequalities such as the Weyl inequalities or Hoffman-Wielandt inequalities (")#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/")[#text("Notes 3a")]#text(") ensure stability of the spectrum.")#linebreak()#text(" One can explain the problem in terms of ")#link("http://en.wikipedia.org/wiki/Pseudospectrum")[#text("pseudospectrum")]#text(". The only spectrum of ")#mi("{U}")#text(" is at the origin, so the resolvents ")#mi("{(U-zI)^{-1}}")#text(" of ")#mi("{U}")#text(" are finite for all non-zero ")#mi("{z}")#text(". However, while these resolvents are finite, they can be extremely large. Indeed, from the nilpotent nature of ")#mi("{U_0}")#text(" we have the Neumann series")

#align(center)[#tao-fit-display[#mitex("(U_0-zI)^{-1} = -\\frac{1}{z} - \\frac{U_0}{z^2} - \\ldots - \\frac{U^{n-1}_0}{z^n}")]]

#text("so for ")#tao-math("{\\left|z\\right| < 1}", block: false)#text(" we see that the resolvent has size roughly ")#tao-math("{\\left|z\\right|^{-n}}", block: false)#text(", which is exponentially large in the interior of the unit disk. This exponentially large size of resolvent is consistent with the exponential instability of the spectrum:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Let ")#mi("{M}")#text(" be a square matrix, and let ")#mi("{z}")#text(" be a complex number. Show that ")#tao-math("{\\left\\| (M-zI)^{-1} \\right\\|_{op} \\geq R}", block: false)#text(" if and only if there exists a perturbation ")#mi("{M+E}")#text(" of ")#mi("{M}")#text(" with ")#tao-math("{\\left\\|E\\right\\|_{op} \\leq 1/R}", block: false)#text(" such that ")#mi("{M+E}")#text(" has ")#mi("{z}")#text(" as an eigenvalue.")
]

#text("This already hints strongly that if one wants to rigorously prove control on the spectrum of ")#mi("{M}")#text(" near ")#mi("{z}")#text(", one needs some sort of upper bound on ")#tao-math("{\\left\\|(M-zI)^{-1}\\right\\|_{op}}", block: false)#text(", or equivalently one needs some sort of lower bound on the least singular value ")#mi("{\\sigma_n(M-zI)}")#text(" of ")#mi("{M-zI}")#text(".")#linebreak()#text(" Without such a bound, though, the instability precludes the direct use of the ")#emph[#text("truncation method")]#text(", which was so useful in the Hermitian case. In particular, there is no obvious way to reduce the proof of the circular law to the case of bounded coefficients, in contrast to the semi-circular law where this reduction follows easily from the Hoffman-Wielandt inequality (see ")#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/")[#text("Notes 4")]#text("). Instead, we must continue working with unbounded random variables throughout the argument (unless, of course, one makes an additional decay hypothesis, such as assuming certain moments are finite; this helps explain the presence of such moment conditions in many papers on the circular law).")

#heading(level: 1)[#strong[#text(" — 2. Incompleteness of the moment method — ")]]

#text("In the Hermitian case, the moments")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{n} \\text{tr} (\\frac{1}{\\sqrt{n}} M)^k = \\int_{\\bf R} x^k\\ d\\mu_{\\frac{1}{\\sqrt{n} M_n}}(x)")]]

#text("of a matrix can be used (in principle) to understand the distribution ")#mi("{\\mu_{\\frac{1}{\\sqrt{n} M_n}}}")#text(" completely (at least, when the measure ")#mi("{\\mu_{\\frac{1}{\\sqrt{n} M_n}}}")#text(" has sufficient decay at infinity. This is ultimately because the space of real polynomials ")#mi("{P(x)}")#text(" is dense in various function spaces (the Weierstrass approximation theorem).")#linebreak()#text(" In the non-Hermitian case, the spectral measure ")#mi("{\\mu_{\\frac{1}{\\sqrt{n} M_n}}}")#text(" is now supported on the complex plane rather than the real line. One still has the formula")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{n} \\text{tr} (\\frac{1}{\\sqrt{n}} M)^k = \\int_{\\bf R} z^k\\ d\\mu_{\\frac{1}{\\sqrt{n} M_n}}(z)")]]

#text("but it is much less useful now, because the space of complex polynomials ")#mi("{P(z)}")#text(" no longer has any good density properties. (For instance, the uniform closure of the space of polynomials on the unit disk is not the space of continuous functions, but rather the space of holomorphic functions that are continuous on the closed unit disk.) In particular, the moments no longer uniquely determine the spectral measure.")#linebreak()#text(" This can be illustrated with the shift examples given above. It is easy to see that ")#mi("{U}")#text(" and ")#mi("{U_\\varepsilon}")#text(" have vanishing moments up to ")#mi("{(n-1)^{th}}")#text(" order, i.e.")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{n} \\text{tr} (\\frac{1}{\\sqrt{n}} U)^k = \\frac{1}{n} \\text{tr} (\\frac{1}{\\sqrt{n}} U_\\varepsilon)^k = 0")]]

#text("for ")#mi("{k=1,\\ldots,n-1}")#text(". Thus we have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf C} z^k\\ d\\mu_{\\frac{1}{\\sqrt{n} U}}(z) = \\int_{\\bf C} z^k\\ d\\mu_{\\frac{1}{\\sqrt{n} U_\\varepsilon}}(z) = 0")]]

#text("for ")#mi("{k=1,\\ldots,n-1}")#text(". Despite this enormous number of matching moments, the spectral measures ")#mi("{\\mu_{\\frac{1}{\\sqrt{n} U}}}")#text(" and ")#mi("{\\mu_{\\frac{1}{\\sqrt{n} U_\\varepsilon}}}")#text(" are vastly different; the former is a Dirac mass at the origin, while the latter can be arbitrarily close to the unit circle. Indeed, even if we set ")#emph[#text("all")]#text(" moments equal to zero,")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf C} z^k\\ d\\mu = 0")]]

#text("for ")#mi("{k=1,2,\\ldots}")#text(", then there are an uncountable number of possible (continuous) probability measures that could still be the (asymptotic) spectral measure ")#mi("{\\mu}")#text(": for instance, any measure which is rotationally symmetric around the origin would obey these conditions.")#linebreak()#text(" If one could somehow control the mixed moments")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf C} z^k \\overline{z}^l\\ d\\mu_{\\frac{1}{\\sqrt{n}} M_n}(z) = \\frac{1}{n} \\sum_{j=1}^n (\\frac{1}{\\sqrt{n}} \\lambda_j(M_n))^k (\\frac{1}{\\sqrt{n}} \\overline{\\lambda_j}(M_n))^l")]]

#text("of the spectral measure, then this problem would be resolved, and one could use the moment method to reconstruct the spectral measure accurately. However, there does not appear to be any obvious way to compute this quantity; the obvious guess of ")#mi("{\\frac{1}{n} \\text{tr} (\\frac{1}{\\sqrt{n}} M_n)^k (\\frac{1}{\\sqrt{n}} M_n^*)^l}")#text(" works when the matrix ")#mi("{M_n}")#text(" is ")#link("http://en.wikipedia.org/wiki/Normal_matrix")[#text("normal")]#text(", as ")#mi("{M_n}")#text(" and ")#mi("{M_n^*}")#text(" then share the same basis of eigenvectors, but generically one does not expect these matrices to be normal.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" The failure of the moment method to control the spectral measure is consistent with the instability of spectral measure with respect to perturbations, because moments are stable with respect to perturbations.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" ")#metadata(none) <tao-8db59feb4d217f26c79d>#text(" Let ")#mi("{k \\geq 1}")#text(" be an integer, and let ")#mi("{M_n}")#text(" be an iid matrix whose entries have a fixed distribution ")#mi("{\\xi}")#text(" with mean zero, variance ")#mi("{1}")#text(", and with ")#mi("{k^{th}}")#text(" moment finite. Show that ")#mi("{\\frac{1}{n} \\text{tr} (\\frac{1}{\\sqrt{n}} M_n)^k}")#text(" converges to zero as ")#mi("{n \\rightarrow \\infty}")#text(" in expectation, in probability, and in the almost sure sense. Thus we see that ")#mi("{\\int_{\\bf R} z^k\\ d\\mu_{\\frac{1}{\\sqrt{n} M_n}}(z)}")#text(" converges to zero in these three senses also. This is of course consistent with the circular law, but does not come close to establishing that law, for the reasons given above.")
]

#text("The failure of the moment method also shows that methods of free probability (")#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/")[#text("Notes 5")]#text(") do not work directly. For instance, observe that for fixed ")#mi("{\\varepsilon}")#text(", ")#mi("{U_0}")#text(" and ")#mi("{U_\\varepsilon}")#text(" (in the noncommutative probability space ")#mi("{(\\text{Mat}_n({\\bf C}), \\frac{1}{n} \\text{tr})}")#text(") both converge in the sense of ")#mi("{*}")#text("-moments as ")#mi("{n \\rightarrow \\infty}")#text(" to that of the right shift operator on ")#mi("{\\ell^2({\\bf Z})}")#text(" (with the trace ")#mi("{\\tau(T) = \\langle e_0, T e_0 \\rangle}")#text(", with ")#mi("{e_0}")#text(" being the Kronecker delta at ")#mi("{0}")#text("); but the spectral measures of ")#mi("{U_0}")#text(" and ")#mi("{U_\\varepsilon}")#text(" are different. Thus the spectral measure cannot be read off directly from the free probability limit.")

#heading(level: 1)[#strong[#text(" — 3. The logarithmic potential — ")]]

#text("With the moment method out of consideration, attention naturally turns to the Stieltjes transform")

#align(center)[#tao-fit-display[#mitex("s_n(z) = \\frac{1}{n} \\text{tr} (\\frac{1}{\\sqrt{n}} M_n - z I)^{-1} = \\int_{{\\bf C}} \\frac{d\\mu_{\\frac{1}{\\sqrt{n}} M_n}(w)}{w-z}.")]]

#text("Even though the measure ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(" is now supported on ")#mi("{{\\bf C}}")#text(" rather than ")#mi("{{\\bf R}}")#text(", the Stieltjes transform is still well-defined. The Plemelj formula for reconstructing spectral measure from the Stieltjes transform that was used in previous notes is no longer applicable, but there are other formulae one can use instead, in particular one has")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Show that")

#align(center)[#tao-fit-display[#mitex("\\mu_{\\frac{1}{\\sqrt{n}} M_n} = \\frac{1}{\\pi} \\partial_{\\bar z} s_n(z)")]]

#text("in the sense of distributions, where")

#align(center)[#tao-fit-display[#mitex("\\partial_{\\bar z} := \\frac{1}{2}( \\frac{\\partial}{\\partial x} + i \\frac{\\partial}{\\partial y})")]]

#text("is the Cauchy-Riemann operator, and one interprets ")#mi("{\\frac{1}{w-z}}")#text(" in a principal value sense.")
]

#text("One can control the Stieltjes transform quite effectively away from the origin. Indeed, for iid matrices with subgaussian entries, one can show (using the methods from ")#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")[#text("Notes 3")]#text(") that the operator norm of ")#mi("{\\frac{1}{\\sqrt{n}} M_n}")#text(" is ")#mi("{1+o(1)}")#text(" almost surely; this, combined with ")#link(<tao-8db59feb4d217f26c79d>)[#text("(4)")]#text(" and Laurent expansion, tells us that ")#mi("{s_n(z)}")#text(" almost surely converges to ")#mi("{-1/z}")#text(" locally uniformly in the region ")#tao-math("{\\{ z: \\left|z\\right| > 1 \\}}", block: false)#text(", and that the spectral measure ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(" converges almost surely to zero in this region (which can of course also be deduced directly from the operator norm bound). This is of course consistent with the circular law, but is not sufficient to prove it (for instance, the above information is also consistent with the scenario in which the spectral measure collapses towards the origin). One also needs to control the Stieltjes transform inside the disk ")#tao-math("{\\{ z: \\left|z\\right| \\leq 1 \\}}", block: false)#text(" in order to fully control the spectral measure.")#linebreak()#text(" For this, existing methods (such as predecessor comparison) are not particularly effective (mainly because of the spectral instability, and also because of the lack of analyticity in the interior of the spectrum). Instead, one proceeds by relating the Stieltjes transform to the ")#emph[#text("logarithmic potential")]

#align(center)[#tao-fit-display[#tao-math("f_n(z) := \\int_{{\\bf C}} \\log\\left|w-z\\right| d\\mu_{\\frac{1}{\\sqrt{n}} M_n}(w).", block: true)]]

#text("It is easy to see that ")#mi("{s_n(z)}")#text(" is essentially the (distributional) gradient of ")#mi("{f_n(z)}")#text(":")

#align(center)[#tao-fit-display[#mitex("s_n(z) = (- \\frac{\\partial}{\\partial x} + i \\frac{\\partial}{\\partial y}) f_n(z),")]]

#text("and thus ")#mi("{g_n}")#text(" is related to the spectral measure by the distributional formula ")#metadata(none) <tao-baff4fb62c8b1c5a7934>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\mu_{\\frac{1}{\\sqrt{n}} M_n} = \\frac{1}{2\\pi} \\Delta f_n")]]

#text("where ")#mi("{\\Delta := \\frac{\\partial^2}{\\partial x^2} + \\frac{\\partial^2}{\\partial y^2}}")#text(" is the Laplacian. (This is of course just reflecting the fact that ")#tao-math("{\\frac{1}{2\\pi} \\log \\left|z\\right|}", block: false)#text(" is the ")#link("http://en.wikipedia.org/wiki/Newtonian_potential")[#text("Newtonian potential")]#text(" in two dimensions.)")#linebreak()#text(" In analogy to previous continuity theorems, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Logarithmic potential continuity theorem)")]#text(" ")#metadata(none) <tao-a814a8866d18fd877b2d>#text(" Let ")#mi("{M_n}")#text(" be a sequence of random matrices with ")#tao-math("{\\left\\| \\frac{1}{\\sqrt{n}} M_n\\right\\|_{op} = O(1)}", block: false)#text(" almost surely, and suppose that for almost every complex number ")#mi("{z}")#text(", ")#mi("{f_n(z)}")#text(" converges almost surely (resp. in probability) to")

#align(center)[#tao-fit-display[#tao-math("f(z) := \\int_{\\bf C} \\log \\left|z-w\\right| d\\mu(w)", block: true)]]

#text("for some compactly supported probability measure ")#mi("{\\mu}")#text(". Then ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(" converges almost surely (resp. in probability) to ")#mi("{\\mu}")#text(" in the vague topology.")
]

#text("We remark that the bound on the operator norm can be relaxed, for instance to a bound on the Frobenius norm; similarly, the compact support hypothesis on ")#mi("{\\mu}")#text(" can be relaxed to a moment condition such as ")#tao-math("{\\int_{\\bf C} \\left|z\\right|^2\\ d\\mu(z) < \\infty}", block: false)#text(".")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" We prove the almost sure version of this theorem, and leave the convergence in probability version as an exercise.")#linebreak()#text(" On any bounded set ")#mi("{K}")#text(" in the complex plane, the functions ")#tao-math("{\\log \\left|\\cdot-w\\right|}", block: false)#text(" lie in ")#mi("{L^2(K)}")#text(" uniformly in ")#mi("{w}")#text(" for ")#mi("{w}")#text(" in a bounded set. From Minkowski’s integral inequality, we conclude that the ")#mi("{f_n}")#text(" and ")#mi("{f}")#text(" are uniformly bounded in ")#mi("{L^2(K)}")#text(". On the other hand, almost surely the ")#mi("{f_n}")#text(" converge pointwise to ")#mi("{f}")#text(". From the dominated convergence theorem this implies that ")#tao-math("{\\min( \\left|f_n-f\\right|, M )}", block: false)#text(" converges in ")#mi("{L^1(K)}")#text(" to zero for any ")#mi("{M}")#text("; using the uniform bound in ")#mi("{L^2(K)}")#text(" to compare ")#tao-math("{\\min(\\left|f_n-f\\right|,M)}", block: false)#text(" with ")#tao-math("{\\left|f_n-f\\right|}", block: false)#text(" and then sending ")#mi("{M \\rightarrow \\infty}")#text(", we conclude that ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" in ")#mi("{L^1(K)}")#text(". In particular, ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" in the sense of distributions; taking distributional Laplacians using ")#link(<tao-baff4fb62c8b1c5a7934>)[#text("(1)")]#text(" we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Establish the convergence in probability version of Theorem ")#link(<tao-a814a8866d18fd877b2d>)[#text("6")]#text(".")
]

#text("Thus, the task of establishing the circular law then reduces to showing, for almost every ")#mi("{z}")#text(", that the logarithmic potential ")#mi("{f_n(z)}")#text(" converges (in probability or almost surely) to the right limit ")#mi("{f(z)}")#text(".")#linebreak()#text(" Observe that the logarithmic potential")

#align(center)[#tao-fit-display[#tao-math("f_n(z) = \\frac{1}{n} \\sum_{j=1}^n \\log\\left|\\frac{\\lambda_j(M_n)}{\\sqrt{n}}-z\\right|", block: true)]]

#text("can be rewritten as a log-determinant:")

#align(center)[#tao-fit-display[#tao-math("f_n(z) = \\frac{1}{n} \\log \\left|\\det( \\frac{1}{\\sqrt{n}} M_n - zI )\\right|.", block: true)]]

#text("To compute this determinant, we recall that the determinant of a matrix ")#mi("{A}")#text(" is not only the product of its eigenvalues, but also has a magnitude equal to the product of its ")#emph[#text("singular")]#text(" values:")

#align(center)[#tao-fit-display[#tao-math("\\left|\\det A\\right| = \\prod_{j=1}^n \\sigma_j(A) = \\prod_{j=1}^n \\lambda_j(A^* A)^{1/2}", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("f_n(z) = \\frac{1}{2} \\int_0^\\infty \\log x\\ d\\nu_{n,z}(x)")]]

#text("where ")#mi("{d\\nu_{n,z}}")#text(" is the spectral measure of the matrix ")#mi("{(\\frac{1}{\\sqrt{n}} M_n - zI)^* (\\frac{1}{\\sqrt{n}} M_n - zI)}")#text(".")#linebreak()#text(" The advantage of working with this spectral measure, as opposed to the original spectral measure ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(", is that the matrix ")#mi("{(\\frac{1}{\\sqrt{n}} M_n - zI)^* (\\frac{1}{\\sqrt{n}} M_n - zI)}")#text(" is ")#emph[#text("self-adjoint")]#text(", and so methods such as the moment method or free probability can now be safely applied to compute the limiting spectral distribution. Indeed, Girko established that for almost every ")#mi("{z}")#text(", ")#mi("{\\nu_{n,z}}")#text(" converged both in probability and almost surely to an explicit (though slightly complicated) limiting measure ")#mi("{\\nu_z}")#text(" in the vague topology. Formally, this implied that ")#mi("{f_n(z)}")#text(" would converge pointwise (almost surely and in probability) to")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} \\int_0^\\infty \\log x\\ d\\nu_z(x).")]]

#text("A lengthy but straightforward computation then showed that this expression was indeed the logarithmic potential ")#mi("{f(z)}")#text(" of the circular measure ")#mi("{\\mu_{circ}}")#text(", so that the circular law would then follow from the logarithmic potential continuity theorem.")#linebreak()#text(" Unfortunately, the vague convergence of ")#mi("{\\nu_{n,z}}")#text(" to ")#mi("{\\nu_z}")#text(" only allows one to deduce the convergence of ")#mi("{\\int_0^\\infty F(x)\\ d\\nu_{n,z}}")#text(" to ")#mi("{\\int_0^\\infty F(x)\\ d\\nu_{z}}")#text(" for ")#mi("{F}")#text(" continuous and compactly supported. Unfortunately, ")#mi("{\\log x}")#text(" has singularities at zero and at infinity, and so the convergence")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty \\log x\\ d\\nu_{n,z}(x) \\rightarrow \\int_0^\\infty \\log x\\ d\\nu_{z}(x)")]]

#text("can fail if the spectral measure ")#mi("{\\nu_{n,z}}")#text(" sends too much of its mass to zero or to infinity.")#linebreak()#text(" The latter scenario can be easily excluded, either by using operator norm bounds on ")#mi("{M_n}")#text(" (when one has enough moment conditions) or even just the Frobenius norm bounds (which require no moment conditions beyond the unit variance). The real difficulty is with preventing mass from going to the origin.")#linebreak()#text(" The approach of Bai proceeded in two steps. Firstly, he established a polynomial lower bound")

#align(center)[#tao-fit-display[#mitex("\\sigma_n( \\frac{1}{\\sqrt{n}} M_n - z I ) \\geq n^{-C}")]]

#text("asymptotically almost surely for the least singular value of ")#mi("{\\frac{1}{\\sqrt{n}} M_n - z I}")#text(". This has the effect of capping off the ")#mi("{\\log x}")#text(" integrand to be of size ")#mi("{O(\\log n)}")#text(". Next, by using Stieltjes transform methods, the convergence of ")#mi("{\\nu_{n,z}}")#text(" to ")#mi("{\\nu_z}")#text(" in an appropriate metric (e.g. the Levi distance metric) was shown to be polynomially fast, so that the distance decayed like ")#mi("{O(n^{-c})}")#text(" for some ")#mi("{c>0}")#text(". The ")#mi("{O(n^{-c})}")#text(" gain can safely absorb the ")#mi("{O(\\log n)}")#text(" loss, and this leads to a proof of the circular law assuming enough boundedness and continuity hypotheses to ensure the least singular value bound and the convergence rate. This basic paradigm was also followed by later works such as that of Gotze-Tikhomirov, Pan-Zhou, and Tao-Vu, with the main new ingredient being the advances in the understanding of the least singular value (")#link("https://terrytao.wordpress.com/2010/03/05/254a-notes-7-the-least-singular-value/")[#text("Notes 7")]#text(").")#linebreak()#text(" Unfortunately, to get the polynomial convergence rate, one needs some moment conditions beyond the zero mean and unit variance rate (e.g. finite ")#mi("{2+\\eta^{th}}")#text(" moment for some ")#mi("{\\eta>0}")#text("). In my paper with Vu and Krishnapur, we used the additional tool of the Talagrand concentration inequality to eliminate the need for the polynomial convergence. Intuitively, the point is that only a small fraction of the singular values of ")#mi("{\\frac{1}{\\sqrt{n}} M_n - zI}")#text(" are going to be as small as ")#mi("{n^{-c}}")#text("; most will be much larger than this, and so the ")#mi("{O(\\log n)}")#text(" bound is only going to be needed for a small fraction of the measure. To make this rigorous, it turns out to be convenient to work with a slightly different formula for the determinant magnitude ")#tao-math("{\\left|\\det( A )\\right|}", block: false)#text(" of a square matrix than the product of the eigenvalues, namely the base-times-height formula")

#align(center)[#tao-fit-display[#tao-math("\\left|\\det( A )\\right| = \\prod_{j=1}^n \\text{dist}(X_j, V_j)", block: true)]]

#text("where ")#mi("{X_j}")#text(" is the ")#mi("{j^{th}}")#text(" row and ")#mi("{V_j}")#text(" is the span of ")#mi("{X_1,\\ldots,X_{j-1}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Establish the inequality")

#align(center)[#tao-fit-display[#mitex("\\prod_{j=n+1-m}^n \\sigma_j(A) \\leq \\prod_{j=1}^m \\text{dist}(X_j, V_j) \\leq \\prod_{j=1}^m \\sigma_j(A)")]]

#text("for any ")#mi("{1 \\leq m \\leq n}")#text(". (Hint: the middle product is the product of the singular values of the first ")#mi("{m}")#text(" rows of ")#mi("{A}")#text(", and so one should try to use the Cauchy interlacing inequality for singular values, see ")#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/")[#text("Notes 3a")]#text(".) Thus we see that ")#mi("{\\text{dist}(X_j, V_j)}")#text(" is a variant of ")#mi("{\\sigma_j(A)}")#text(".")
]

#text("The least singular value bounds, translated in this language (with ")#mi("{A := \\frac{1}{\\sqrt{n}} M_n - zI}")#text("), tell us that ")#mi("{\\text{dist}(X_j,V_j) \\geq n^{-C}}")#text(" with high probability; this lets ignore the most dangerous values of ")#mi("{j}")#text(", namely those ")#mi("{j}")#text(" that are equal to ")#mi("{n - O(n^{0.99})}")#text(" (say). For low values of ")#mi("{j}")#text(", say ")#mi("{j \\leq (1-\\delta) n}")#text(" for some small ")#mi("{\\delta}")#text(", one can use the moment method to get a good lower bound for the distances and the singular values, to the extent that the logarithmic singularity of ")#mi("{\\log x}")#text(" no longer causes difficulty in this regime; the limit of this contribution can then be seen by moment method or Stieltjes transform techniques to be ")#emph[#text("universal")]#text(" in the sense that it does not depend on the precise distribution of the components of ")#mi("{M_n}")#text(". In the medium regime ")#mi("{(1-\\delta)n < j < n-n^{0.99}}")#text(", one can use Talagrand’s inequality to show that ")#mi("{\\text{dist}(X_j,V_j)}")#text(" has magnitude about ")#mi("{\\sqrt{n-j}}")#text(", giving rise to a net contribution to ")#mi("{f_n(z)}")#text(" of the form ")#mi("{\\frac{1}{n} \\sum_{(1-\\delta)n < j < n - n^{0.99}} O( \\log \\sqrt{n-j} )}")#text(", which is small. Putting all this together, one can show that ")#mi("{f_n(z)}")#text(" converges to a universal limit as ")#mi("{n \\rightarrow \\infty}")#text(" (independent of the component distributions); see ")#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/")[#text("my paper with Vu and Krishnapur")]#text(" for details. As a consequence, once the circular law is established for one class of iid matrices, such as the complex gaussian random matrix ensemble, it automatically holds for all other ensembles also.")

#heading(level: 1)[#strong[#text(" — 4. Brown measure — ")]]

#text("We mentioned earlier that due to eigenvalue instability (or equivalently, due to the least singular value of shifts possibly going to zero), the moment method (and thus, by extension, free probability) was not sufficient by itself to compute the asymptotic spectral measure of non-Hermitian matrices in the large ")#mi("{n}")#text(" limit. However, this method can be used to give a heuristic ")#emph[#text("prediction")]#text(" as to what that measure is, known as the ")#emph[#text("Brown measure")]#text(", introduced ")#link("http://www.ams.org/mathscinet-getitem?mr=866489")[#text("by Brown")]#text(". While Brown measure is not ")#emph[#text("always")]#text(" the limiting spectral measure of a sequence of matrices, it turns out in practice that this measure can (with some effort) be shown to be the limiting spectral measure in key cases. As Brown measure can be computed (again, after some effort) in many cases, this gives a general strategy towards computing asymptotic spectral measure for various ensembles.")#linebreak()#text(" To define Brown measure, we use the language of free probability (")#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/")[#text("Notes 5")]#text("). Let ")#mi("{u}")#text(" be a bounded element (not necessarily self-adjoint) of a non-commutative probability space ")#mi("{({\\mathcal A}, \\tau)}")#text(", which we will assume to be tracial. To derive Brown measure, we mimic the Girko strategy used for the circular law. Firstly, for each complex number ")#mi("{z}")#text(", we let ")#mi("{\\nu_z}")#text(" be the spectral measure of the non-negative self-adjoint element ")#mi("{(u-z)^* (u-z)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Verify that the spectral measure of a positive element ")#mi("{u^* u}")#text(" is automatically supported on the non-negative real axis. (")#emph[#text("Hint:")]#text(" Show that ")#mi("{\\tau( P(u^* u) u^* u P(u^* u) ) \\geq 0}")#text(" for any real polynomial ")#mi("{P}")#text(", and use the spectral theorem.)")
]

#text("By the above exercise, ")#mi("{\\nu_z}")#text(" is a compactly supported probability measure on ")#mi("{[0,+\\infty)}")#text(". We then define the logarithmic potential ")#mi("{f(z)}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("f(z) = \\frac{1}{2} \\int_0^\\infty \\log x\\ d\\nu_z(x).")]]

#text("Note that ")#mi("{f}")#text(" may equal ")#mi("{-\\infty}")#text(" at some points.")#linebreak()#text(" To understand this determinant, we introduce the regularised determinant")

#align(center)[#tao-fit-display[#mitex("f_\\varepsilon(z) := \\frac{1}{2} \\int_0^\\infty \\log (\\varepsilon + x)\\ d\\nu_z(x)")]]

#text("for ")#mi("{\\varepsilon > 0}")#text(". From the monotone convergence theorem we see that ")#mi("{f_\\varepsilon(z)}")#text(" decreases pointwise to ")#mi("{f(z)}")#text(" as ")#mi("{\\varepsilon \\rightarrow 0}")#text(".")#linebreak()#text(" We now invoke the Gelfand-Naimark theorem and embed ")#mi("{{\\mathcal A}}")#text(" into the space of bounded operators on ")#mi("{L^2(\\tau)}")#text(", so that we may now obtain a functional calculus. (If ")#mi("{\\tau}")#text(" is not faithful, this embedding need not be injective, but this will not be an issue in what follows.) Then we can write")

#align(center)[#tao-fit-display[#mitex("f_\\varepsilon(z) = \\frac{1}{2} \\tau( \\log( \\varepsilon + (u-z)^* (u-z) ) ).")]]

#text("One can compute the first variation of ")#mi("{f_\\varepsilon}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Let ")#mi("{\\varepsilon > 0}")#text(". Show that the function ")#mi("{f_\\varepsilon}")#text(" is continuously differentiable with")

#align(center)[#tao-fit-display[#mitex("\\partial_x f_\\varepsilon(z) = -\\text{Re} \\tau( (\\varepsilon + (u-z)^* (u-z))^{-1} (u-z) )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\partial_y f_\\varepsilon(z) = -\\text{Im} \\tau( (\\varepsilon + (u-z)^* (u-z))^{-1} (u-z) ).")]]
]

#text("Then, one can compute the second variation at, say, the origin:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Let ")#mi("{\\varepsilon > 0}")#text(". Show that the function ")#mi("{f_\\varepsilon}")#text(" is twice continuously differentiable with")

#align(center)[#tao-fit-display[#mitex("\\partial_{xx} f_\\varepsilon(0) = \\text{Re} \\tau( (\\varepsilon + u^* u)^{-1} - (\\varepsilon + u^* u)^{-1} (u+u^*) (\\varepsilon + u^* u)^{-1} u )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\partial_{yy} f_\\varepsilon(0) = \\text{Re} \\tau( (\\varepsilon + u^* u)^{-1} - (\\varepsilon + u^* u)^{-1} (u^*-u) (\\varepsilon + u^* u)^{-1} u ).")]]
]

#text("We conclude in particular that")

#align(center)[#tao-fit-display[#mitex("\\Delta f_\\varepsilon(0) = 2\\text{Re} \\tau( (\\varepsilon + u^* u)^{-1} - (\\varepsilon + u^* u)^{-1} u^* (\\varepsilon + u^* u)^{-1} u )")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#tao-math("\\Delta f_\\varepsilon(0) = 2 ( \\left\\| (\\varepsilon + u^* u)^{-1/2} \\right\\|_{L^2(\\tau)}^2 - \\left\\| (\\varepsilon + u^* u)^{-1/2} u (\\varepsilon + u^* u)^{-1/2} \\right\\|_{L^2(\\tau)}^2 ).", block: true)]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" Show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\varepsilon + u^* u)^{-1/2} u (\\varepsilon + u^* u)^{-1/2} \\right\\|_{L^2(\\tau)} \\leq \\left\\| (\\varepsilon + u^* u)^{-1/2} \\right\\|_{L^2(\\tau)}.", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" Adapt the proof of Lemma 5 from ")#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/")[#text("Notes 5")]#text(".)")
]

#text("We conclude that ")#mi("{\\Delta f_\\varepsilon}")#text(" is non-negative at zero. Translating ")#mi("{u}")#text(" by any complex number we see that ")#mi("{\\Delta f_\\varepsilon}")#text(" is non-negative everywhere, that is to say that ")#mi("{f_\\varepsilon}")#text(" is subharmonic. Taking limits we see that ")#mi("{f}")#text(" is subharmonic also; thus if we define the ")#emph[#text("Brown measure")]#text(" ")#mi("{\\mu = \\mu_u}")#text(" of ")#mi("{u}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\mu := \\frac{1}{2\\pi} \\Delta f")]]

#text("(cf. ")#link(<tao-baff4fb62c8b1c5a7934>)[#text("(1)")]#text(") then ")#mi("{\\mu}")#text(" is a non-negative measure.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Show that for ")#tao-math("{\\left|z\\right| > \\rho(u) := \\rho(u^* u)^{1/2}}", block: false)#text(", ")#mi("{f}")#text(" is continuously differentiable with")

#align(center)[#tao-fit-display[#mitex("\\partial_x f(z) = -\\text{Re} \\tau( (u-z)^{-1} )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\partial_y f(z) = \\text{Im} \\tau( (u-z)^{-1} )")]]

#text("and conclude that ")#mi("{f}")#text(" is harmonic in this region; thus Brown measure is supported in the disk ")#tao-math("{\\{ z: \\left|z\\right| \\leq \\rho(u) \\}}", block: false)#text(". Using Green’s theorem, conclude also that Brown measure is a probability measure.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" In a finite-dimensional non-commutative probability space ")#mi("{(\\text{Mat}_n({\\bf C}), \\frac{1}{n} \\text{tr})}")#text(", show that Brown measure is the same as spectral measure.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" In a commutative probability space ")#mi("{(L^\\infty(\\Omega), {\\bf E})}")#text(", show that Brown measure is the same as the probability distribution.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" If ")#mi("{u}")#text(" is the left shift on ")#mi("{\\ell^2({\\bf Z})}")#text(" (with the trace ")#mi("{\\tau(T) := \\langle T e_0, e_0 \\rangle}")#text("), show that the Brown measure of ")#mi("{u}")#text(" is the uniform measure on the unit circle ")#tao-math("{\\{ z \\in {\\bf C}: \\left|z\\right|=1\\}}", block: false)#text(".")
]

#text("This last exercise illustrates the limitations of Brown measure for understanding asymptotic spectral measure. The shift ")#mi("{U_0}")#text(" and the perturbed shift ")#mi("{U_\\varepsilon}")#text(" introduced in previous sections both converge in the sense of ")#mi("{*}")#text("-moments as ")#mi("{n \\rightarrow \\infty}")#text(" (holding ")#mi("{\\varepsilon}")#text(" fixed) to the left shift ")#mi("{u}")#text(". For non-zero ")#mi("{\\varepsilon}")#text(", the spectral measure of ")#mi("{U_\\varepsilon}")#text(" does indeed converge to the Brown measure of ")#mi("{u}")#text(", but for ")#mi("{\\varepsilon=0}")#text(" this is not the case. This illustrates a more general principle, that Brown measure is the right asymptotic limit for “generic” matrices, but not for exceptional matrices. (See ")#link("http://www.ams.org/mathscinet-getitem?mr=1929504")[#text("this paper of Sniady")]#text(" for a precise formulation of this heuristic, using gaussian regularisation.)")#linebreak()#text(" The machinery used to establish the circular law in full generality can be used to show that Brown measure is the correct asymptotic spectral limit for other models:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 17")]#text(" Let ")#mi("{M_n}")#text(" be a sequence of random matrices whose entries are jointly independent and with all moments uniformly bounded, with variance uniformly bounded from below, and which converges in the sense of ")#mi("{*}")#text("-moments to an element ")#mi("{u}")#text(" of a non-commutative probability space. Then the spectral measure ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(" converges almost surely and in probability to the Brown measure of ")#mi("{u}")#text(".")
]

#text("This theorem is essentially Theorem 1.20 of my paper with ")#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/")[#text("Van Vu and Manjunath Krishnapur")]#text(". The main ingredients are those mentioned earlier, namely a polynomial lower bound on the least singular value, and the use of Talagrand’s inequality to control medium singular values (or medium codimension distances to subspaces). Of the two ingredients, the former is more crucial, and is much more heavily dependent at present on the joint independence hypothesis; it would be of interest to see how to obtain lower bounds on the least singular value in more general settings.")

#heading(level: 1)[#text("Comments (23)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67ba63ea9ae3c7dbb49e83e35bf6e60d1feeb630f2a4f0247c2b6eeced5355ba-8dca20a54563e8c29c82df6eccf3d851382571444392317e915598a16c289b48.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Smith")]], [#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-43889")[#strong[#text("James Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2010")])]

#text("‘if wants’ should be ‘if one wants’ after exercise 1")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0236b2c25d60909f1321db4b2f20fdbeee33e96895ecc1dbaeb75d68476e0557-822b66a6a892feeb4dedb47ff49b749735b6253d69e6ee1a1a10579502459d59.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mario Figueiredo")]], [#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-43894")[#strong[#text("Mario Figueiredo")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2010")])]

#text("Hi,")#linebreak()#text(" In the statement of Theorem 1, shouldn’t it be")#linebreak()#text(" $\\mu_{\\frac{1}{\\sqrt{n}} M_n}$ instead of")#linebreak()#text(" $\\mu_{\\frac{1}{\\sqrt{n} M_n}}$ ?")#linebreak()#text(" Mario.")

#emph[#text("[Corrected, thanks. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-43901")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2010")])]

#text("Dear Professor Terence Tao")

#text("This is a HTML query. Maybe it would be better not asking it here.")

#text("In Exercice 10 you have more than one paragraph. How do you manage to insert the border?")

#text("I use, for instance")

#text("p style=”text-align: justify; border: green 1px solid; padding: 20px;”")

#text("enclosed by “”, but it works for one paragraph only.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pif")]], [#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-43925")[#strong[#text("Pif")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2010")])]

#text("I don’t know the answer, but I know you can get it by looking at the source of the page (something like right-button of the mouse and then source).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-43930")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2010")])]

#text("Thank you.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-43927")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2010")])]

#text("I use a customised CSS for the paragraph formatting; see the bottom of")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/about/")[#text("About")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cd3293b17fc4102811ce87a71f982a006bff024f4fadf65e5afe06087907fc0-4ba76bf4fed42f8a2ca5c337f3ef79cd4db842b060b6a124a522d20c80bf75fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mustafa Said")]], [#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-46172")[#strong[#text("Mustafa Said")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2010")])]

#text("Dear Terry,")

#text("I have come upon a problem in my research project , concerning random matrices, that I need some help on. In particular: Suppose that ")#mi("X, Y")#text(" are square matrices that are independent and drawn from the uniform distribution on the sphere ")#mi("S^{n^2 - 1}")#text(" with respect to the Hilbert-Schmidt norm, ")#tao-math("\\left|\\left| A \\right|\\right|_2 = (\\sum_{i,j}^n \\left|a_{i,j}\\right|^2)^{1/2}", block: false)#text(". I want to find a lower bound on ")#tao-math("\\mathbb{E}(inf_{(A,B): [A,B] = 0} \\left|\\left| X - A \\right|\\right|_2 + \\left|\\left| Y - B \\right|\\right|_2)", block: false)#text(", where ")#mi("\\mathbb{E}")#text(" denotes the expectation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf439e996e29d20cb552d68ffe9f964d8919f4f9773b9c41c886fb326a5a9695-66573747b7b50dc2532a1c1acd7e23c9482f9aeb4a00f437399c08ade2278ee3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Jiang")]], [#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-47213")[#strong[#text("John Jiang")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2010")])]

#text("“Weilandt” -> “Wielandt” before section 2.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Outliers in the spectrum of iid matrices with bounded rank permutations « What’s new")]], [#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-49101")[#strong[#text("Outliers in the spectrum of iid matrices with bounded rank permutations « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2010")])]

#text("[…] will almost surely be distributed according to the circular law distribution in the limit . (See these lecture notes for further discussion of this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-99832")[#strong[#text("Smolin (2011) | Research Notebook")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2011")]

#text("[…] We can interpret the eigenvalue of this matrix valued process as the fraction of the time agent spends attending to the asset he follows most closely, the eigenvalue as the fraction of the time he spends attending to the asset he follows second most closely, and so on… Thus, we know that the distribution of attention across assets would subscribe to a Wigner Semi-Circle distribution as described here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e6ffa68d7217ab09e3895e918b12acff13750bdbbb8392acb1d0646e54f0eff9-c78a2fca147388d823dd2cbf86aa976f3d22c7e5d17c1280aa382ccf52635575.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-269701")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2014")])]

#text("How does one solve exercise 3 about the Cauchy-Riemann operator?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of keej")]], [#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-479981")[#strong[#text("keej")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2017")])]

#text("I have a question about the meaning of “almost sure convergence” in Theorem 1 (Circular Law), but it’s a more general question as well. Are the matrices to be interpreted as the n X n corner of an infinite matrix, or as independent matrices? I’m comparing this to the law of large numbers, where almost sure convergence relies on the numbers in the beginning of the sequence being “reused,” and doesn’t work if you take means of independent samples of n numbers.")

#emph[#text("[The former. If I recall correctly, this is needed in order to obtain almost sure uniform bounds on the operator norm of the matrices. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of keej")]], [#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-479994")[#strong[#text("keej")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2017")])]

#text("Thank you! I will try to check this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of keej")]], [#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-479993")[#strong[#text("keej")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2017")])]

#text("In Section 2, “Incompleteness of the moment method,” the integrals involving ")#mi("z")#text(" are meant to be over ")#mi("\\mathbb{C}")#text(", not ")#mi("\\mathbb{R}")#text(" as written, right?")

#text("Regarding Exercise 3: Even in the simplest case where ")#mi("\\mu")#text(" is just a point mass at the origin, I am not quite sure how to make sense of ")#mi("s(z) = -1/z")#text(" as a distribution. I guess one should take the Cauchy principal value, but is there a justification for this?")

#emph[#text("[Corrected, thanks. Yes, one takes the principal value interpretation here. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tornado92")]], [#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-488718")[#strong[#text("tornado92")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2017")])]

#text("I have a question about the proof of Theorem 6, specifically “using the uniform bound in ")#mi("L^2(K)")#text(" to compare ")#tao-math("\\min(\\left|f_n-f\\right|,M)", block: false)#text(" with ")#tao-math("\\left|f_n-f\\right|", block: false)#text(" and then sending $M \\rightarrow \\infty$ , we conclude that ")#mi("f_n")#text(" converges to ")#mi("f")#text(" in ")#mi("L^1(K)")#text(".”")

#text("I’m having trouble converting this part from post-rigorous to rigorous, which I guess a mathematician could easily do. Could someone spell out the details for me? I have an ugly ad-hoc proof but it doesn’t really follow the high-level reasoning in the quote, so I’m curious what was intended here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tornado92")]], [#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-488719")[#strong[#text("tornado92")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2017")])]

#text("I didn’t mean to say it wasn’t rigorous. Maybe I should just say I didn’t follow the proof.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of keej")]], [#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-489575")[#strong[#text("keej")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2017")])]

#text("To prove weak convergence of probability measures, it seems it suffices to prove convergence of the fourier transforms, stieltjes transforms, log potentials, or possibly other transforms. The drawbacks to using the Stieltjes transform in this case were described nicely in this post.")

#text("I’m trying to understand the chief advantage of the log potential. Is the log potential favored here mainly because ")#mi("\\prod \\lambda_i = \\prod \\sigma_i")#text(" (which allows us to consider measures on ")#mi("\\mathbb{R}")#text(")? Or are there other important benefits to using the log potential which I failed to discern?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-489895")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2017")])]

#text("Yes, this is the key identity that makes the Girko Hermitization method work (provided one can prevent the ")#mi("\\sigma_i")#text(" from getting too close to zero, of course.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of keej")]], [#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-491343")[#strong[#text("keej")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2018")])]

#text("When working with the noncommutative probability space of ")#mi("n \\times n")#text(" matrices with state ")#mi("\\tau_n = \\frac{1}{n} \\text{tr}")#text(", and when taking the limit as $n \\to \\infty$, what state does one use for the limiting probability space? It doesn’t seem like ")#mi("\\tau_n")#text(" has any nice limiting version, or in other words, I don’t know how to take the “normalized trace” of an infinite dimensional matrix. How do people get around this?")

#text("In the perturbed shift example you just take the vector state for ")#mi("e_0")#text(", but I’m not sure what the motivation is for this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-491355")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2018")])]

#text("There is no unique choice here, but one can for instance (after choosing a non-principal ultrafilter) take an ultraproduct of the finitary noncommutative probability spaces, and take the ultralimit of the finitary states, to obtain a limiting noncommutative space (where the limit will be along the ultrafilter, at least).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/30cc3d391807c30aa9899eb22d0f4fd955b0d824908ab82d558bde6d245b5fd5-704f324fc38babd4948bd6d3fdd9e15b8b201b599d098cb104f81992eb6dbebe.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-566941")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2020")])]

#text("In the proof of Theorem 6, it is written that ")#tao-math("\\log \\left|\\cdot - w\\right|", block: false)#text(" lie uniformly in ")#mi("L^2(K)")#text(" for any ")#mi("w")#text(". It seems to me that it holds only when ")#mi("w")#text(" is chosen in a bounded set, since ")#tao-math("\\int_K \\log^2\\left|z-w\\right| dz \\sim \\left|K\\right| \\log^2 \\left|w\\right|", block: false)#text(" for big values of ")#tao-math("\\left|w\\right|", block: false)#text(".")

#text("This is important since in the next line you use Minkowski, probably as follows:")

#tao-math("\\displaystyle \\int_K \\left|f(z)\\right|^2dz = \\int_K\\left|\\int_{\\mathbb C} \\log\\left|z-w\\right|d\\mu(w) \\right|^2dz \\le \\left[ \\int_{\\mathbb C} \\left(\\int_K \\log^2\\left|z-w\\right| dz \\right)^{1/2} d\\mu(w) \\right]^2", block: false)

#text("Here the integral that is inside is not uniformly bounded on ")#mi("w\\in \\mathbb C")#text(", and actually yields an unbounded function on ")#mi("w")#text(", so the overall integral should depend on ")#mi("\\mu")#text(".")

#text("Probably I am wrongly interpreting the proof, so what is the correct line of reasoning here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-567031")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2020")])]

#text("Oops, I had forgotten here to impose moment conditions on the various measures involved. In this particular application the measure ")#mi("\\mu")#text(" and also the empirical measures ")#mi("\\mu_{\\frac{1}{\\sqrt{n}} M_n}")#text(" in fact all have uniform compact support, so this problem is avoided. (More generally, due to the very slow divergence of the logarithm function, virtually any moment condition will be fine here, e.g., it will be enough to obtain an almost sure bound on the Frobenius norm ")#mi("(\\frac{1}{n^2} \\mathrm{tr}( M_n M_n^* ))^{1/2}")#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/30cc3d391807c30aa9899eb22d0f4fd955b0d824908ab82d558bde6d245b5fd5-704f324fc38babd4948bd6d3fdd9e15b8b201b599d098cb104f81992eb6dbebe.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/#comment-567152")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2020")])]

#text("I think that a generalization is present in “Around the circular law")#linebreak()#text(" ” by Charles Bordenave and Djalil Chafaı̈, where they just assume that ")#tao-math("\\log(1 + \\left|z\\right|)", block: false)#text(" is uniformly integrable for every ")#mi("\\mu_n")#text(".")

#text("And shouldn’t the Frobenius norm be greater than the operator norm? ")#tao-math("\\left\\|\\frac 1{\\sqrt {n}} M_n\\right\\|_F = O(1)", block: false)#text(" is not a relaxation of ")#tao-math("\\left\\|\\frac 1{\\sqrt {n}} M_n\\right\\|_{op} = O(1)", block: false)

#emph[#text("[I am bounding ")#tao-math("\\left\\|\\frac{1}{n} M_n\\right\\|_F", block: false)#text(", not ")#tao-math("\\left\\| \\frac{1}{\\sqrt{n}} M_n \\right\\|_F", block: false)#text(" – T.]")]
]
]
]
