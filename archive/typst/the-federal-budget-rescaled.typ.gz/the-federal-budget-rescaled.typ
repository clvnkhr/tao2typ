// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/
// Converted to Typst by tao2typ: "2026-10-14T16:35:44.048158+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The federal budget, rescaled", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The federal budget, rescaled")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 May 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/")[#text("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("In a recent Cabinet meeting, ")#link("http://www.washingtonpost.com/wp-dyn/content/article/2009/04/20/AR2009042000641.html")[#text("President Obama called")]#text(" for a $100 million spending cut in 90 days from the various federal departments as a sign of budget discipline. While this is nominally quite a large number, it was pointed out correctly by many people that this was in fact a negligible fraction of the total federal budget; for instance, ")#link("http://gregmankiw.blogspot.com/2009/04/fiscal-responsibility.html")[#text("Greg Mankiw noted")]#text(" that the cut was comparable to a family with an annual spending of $100,000 and a deficit of $34,000 deciding on a spending cut of $3. (Of course, this is by no means the only budgetary initiative being proposed by the administration; just today, for instance, a change in the taxation law for offshore income ")#link("http://thecaucus.blogs.nytimes.com/2009/05/04/obama-takes-aim-at-offshore-tax-havens/?hp")[#text("was proposed")]#text(" which could potentially raise about $210 billion over the next ten years, or about $630 a year with the above scaling, though it is not clear yet how feasible or effective this change would be.)")

#text("I thought that this sort of rescaling (converting $100 million to $3) was actually a rather good way of comprehending the vast amounts of money in the federal budget: we are not so adept at distinguishing easily between $1 million, $1 billion, and $1 trillion, but we are fairly good at grasping the distinction between $0.03, $30, and $30,000. So I decided to rescale (selected items in) the federal budget, together with some related numbers for comparison, by this ratio 100 million:3, to put various figures in perspective.")

#text("This is certainly not an advanced application of mathematics by any means, but I still found the results to be instructive. The same rescaling puts the entire population of the US at about nine – the size of a (large) family – which is of course consistent with the goal of putting the federal budget roughly on the scale of a family budget (bearing in mind, of course, that the federal government is only about a fifth of the entire US economy, so one might perhaps view the government as being roughly analogous to the “heads of household” of this large family). The implied (horizontal) length rescaling of ")#mi("\\sqrt{100 \\text{million}:3} \\approx 5770")#text(" is roughly comparable to the scaling used in Dubai’s “")#link("http://en.wikipedia.org/wiki/The_World_(archipelago)")[#text("The World")]#text("” (which is not a coincidence, if you think about it; the purpose of both rescalings is to map global scales to human scales). Perhaps readers may wish to contribute additional rescaled statistics of interest to those given below.")

#text("One caveat: the rescaling used here does create some noticeable distortions in other dimensional quantities. For example, if one rescales length by the implied factor of ")#mi("\\approx 5770")#text(", but leaves time unrescaled (so that a fiscal year remains a fiscal year), then this will rescale all speeds by a factor of ")#mi("\\approx 5770")#text(" also. For instance, the circumference of the Earth has been rescaled to a manageable-looking 6.9 kilometres (4.3 miles), but the speed of, say, a commercial airliner (typically about 900 km/hr, or 550 mi/hr) is rescaled also, to a mere 150 metres (or 160 yards) or so per hour, i.e. two or three meters or yards per minute – about the speed of a tortoise.")

#text("All amounts here are rounded to three significant figures (and in some cases, the precision may be worse than this). I am using here the FY2008 budget instead of the 2009 or 2010 one, as the data is more finalised; as such, the numbers here are slightly different from those of Mankiw. (For instance, the 2010 budget includes the expenditures for Iraq & Afghanistan, whereas in previous budgets these were appropriated separately.) I have tried to locate the most official and accurate statistics whenever possible, but corrections and better links are of course welcome.")

#text("FY 2008 budget:")

#list(
[#text("Total revenue: $")#link("http://www.cbo.gov/budget/historical.shtml")[#text("75,700")]

#list(
[#text("Individual income taxes: $")#link("http://www.cbo.gov/budget/historical.shtml")[#text("34,400")]],
[#text("Social security & other payroll taxes: $")#link("http://www.cbo.gov/budget/historical.shtml")[#text("27,000")]]
)],
[#text("Total spending: $")#link("http://www.cbo.gov/budget/historical.shtml")[#text("89,500")]

#list(
[#text("Net mandatory spending: $")#link("http://www.cbo.gov/budget/historical.shtml")[#text("48,000")]

#list(
[#text("Medicare, Medicaid, and SCHIP: $")#link("http://www.cbo.gov/budget/historical.shtml")[#text("20,500")]],
[#text("Social Security: $")#link("http://www.cbo.gov/budget/historical.shtml")[#text("18,400")]]
)],
[#text("Net interest: $")#link("http://www.cbo.gov/budget/historical.shtml")[#text("7,470")]],
[#text("Net discretionary spending: $")#link("http://www.cbo.gov/budget/historical.shtml")[#text("34,000")]

#list(
[#text("Department of Defense: $")#link("http://www.gpoaccess.gov/usbudget/fy08/pdf/budget/tables.pdf")[#text("14,300")]

#list(
[#text("DARPA: $")#link("http://www.cra.org/govaffairs/blog/archives/000640.html")[#text("89")]]
)],
[#text("Global War on Terror: $")#link("http://www.gpoaccess.gov/usbudget/fy08/pdf/budget/tables.pdf")[#text("4,350")]],
[#text("Department of Education: $")#link("http://www.gpoaccess.gov/usbudget/fy08/pdf/budget/tables.pdf")[#text("1,680")]],
[#text("Department of Energy: $")#link("http://www.gpoaccess.gov/usbudget/fy08/pdf/budget/tables.pdf")[#text("729")]],
[#text("NASA: $")#link("http://www.gpoaccess.gov/usbudget/fy08/pdf/budget/tables.pdf")[#text("519")]],
[#text("Net earmarks: $")#link("http://earmarks.omb.gov/resources/static_pdfs/2008_Earmarks_Summary.pdf")[#text("495")]],
[#text("NSF: $")#link("http://www.nsf.gov/about/budget/")[#text("180")]

#list(
[#text("Maths & Physical Sciences: $")#link("http://www.nsf.gov/about/budget/fy2008/pdf/04_fy2008.pdf")[#text("37.50")]]
)]
)]
)],
[#text("Budget deficit: $")#link("http://www.cbo.gov/budget/historical.shtml")[#text("13,800")]],
[#text("Additional appropriations (not included in regular budget)")

#list(
[#text("Iraq & Afghanistan: $")#link("http://assets.opencrs.com/rpts/RL33110_20080714.pdf")[#text("5,640")]]
)],
[#text("Spending cuts within 90 days of Apr 20, 2009: $")#link("http://www.washingtonpost.com/wp-dyn/content/article/2009/04/20/AR2009042000641.html")[#text("3")]],
[#text("Air force NY flyover “photo shoot”, Apr 27, 2009: $")#link("http://www.reuters.com/article/topNews/idUSTRE5474VW20090508")[#text("0.01")]],
[#text("Additional spending cuts for FY2010, proposed May 7, 2009: $")#link("http://www.nytimes.com/2009/05/07/us/politics/07budget.html?hp")[#text("510")]],
[#text("Projected annual revenue from proposed offshore tax code change: $")#link("http://thecaucus.blogs.nytimes.com/2009/05/04/obama-takes-aim-at-offshore-tax-havens/?hp")[#text("630")]]
)

#text("Other figures (for comparison)")

#list(
[#text("National debt held by public 2008: $")#link("http://www.cbo.gov/budget/historical.shtml")[#text("174,000")]

#list(
[#text("Held by foreign/international owners 2008: $")#link("http://fms.treas.gov/bulletin/b2008-4.pdf")[#text("85,900")]]
)],
[#text("National debt held by government agencies, 2008: $")#link("http://fms.treas.gov/bulletin/b2008-4.pdf")[#text("126,000")]

#list(
[#text("Held by ")#link("http://en.wikipedia.org/wiki/Social_Security_(United_States)")[#text("OASDI")]#text(" (aka (cumulative) “Social Security Surplus”): $")#link("http://fms.treas.gov/bulletin/b2008-4.pdf")[#text("64,500")]]
)],
[#text("National GDP 2008: $")#link("http://www.cbo.gov/budget/historical.shtml")[#text("427,000")]

#list(
[#text("National population 2008: ")#link("http://www.census.gov/")[#text("9")]],
[#text("GDP per capita 2008: $")#link("https://www.cia.gov/library/publications/the-world-factbook/print/us.html")[#text("47,000")]],
[#text("Land mass: ")#link("https://www.cia.gov/library/publications/the-world-factbook/print/us.html")[#text("0.27 sq km")]#text(" (0.1 sq mi, or 68 acres)")]
)],
[#text("World GDP 2008: $")#link("https://www.cia.gov/library/publications/the-world-factbook/print/xx.html")[#text("1,680,000")]

#list(
[#text("World population 2008: ")#link("https://www.cia.gov/library/publications/the-world-factbook/print/xx.html")[#text("204")]],
[#text("GDP per capita 2008 (PPP): $")#link("https://www.cia.gov/library/publications/the-world-factbook/print/xx.html")[#text("10,400")]],
[#text("Land mass: ")#link("https://www.cia.gov/library/publications/the-world-factbook/print/xx.html")[#text("4.47 sq km")]#text(" (1.73 sq mi)")]
)],
[#text("World’s richest (non-rescaled) person: Bill Gates (net worth $")#link("http://www.forbes.com/2009/03/11/worlds-richest-people-billionaires-2009-billionaires_land.html")[#text("1,200")]#text(", March 2009)")],
[#text("2008/2009 Bailout package (")#link("http://en.wikipedia.org/wiki/Troubled_Asset_Relief_Program")[#text("TARP")]#text("): $")#link("http://www.cbo.gov/ftpdocs/99xx/doc9961/01-16-TARP.pdf")[#text("21,000")]#text(" (maximum)")

#list(
[#text("Amount spent by Dec 2008: $")#link("http://www.cbo.gov/ftpdocs/99xx/doc9961/01-16-TARP.pdf")[#text("7,410")]],
[#text("AIG bailout from TARP: $")#link("http://www.cbo.gov/ftpdocs/99xx/doc9961/01-16-TARP.pdf")[#text("1,200")]

#list(
[#text("AIG Federal Reserve credit line: $")#link("http://www.nytimes.com/2008/10/31/business/31aig.html")[#text("4,320")]],
[#text("AIG bonuses in 2009 Q1: $")#link("http://www.nytimes.com/2009/03/18/business/18cuomo.html")[#text("4.95")]]
)],
[#text("GM & Chrysler loans: $")#link("http://www.cbo.gov/ftpdocs/99xx/doc9961/01-16-TARP.pdf")[#text("552")]]
)],
[#text("2009/2010 Stimulus package (")#link("http://en.wikipedia.org/wiki/American_Recovery_and_Reinvestment_Act_of_2009")[#text("ARRA")]#text("): $")#link("http://www.speaker.gov/newsroom/legislation?id=0273")[#text("23,600")]

#list(
[#text("Tax cuts (spread out over 10 years): $")#link("http://www.speaker.gov/newsroom/legislation?id=0273")[#text("8,640")]],
[#text("State and local fiscal relief: $")#link("http://www.speaker.gov/newsroom/legislation?id=0273")[#text("4,320")]],
[#text("Education: $")#link("http://www.ed.gov/policy/gen/leg/recovery/implementation.html")[#text("3,000")]

#list(
[#text("“Race to the top” education fund: $")#link("http://www.ed.gov/news/pressreleases/2009/03/03072009.html")[#text("150")]]
)],
[#text("Investments in scientific research: $")#link("http://www.ostp.gov/cs/news/news_detail?pressrelease.id=259")[#text("645")]

#list(
[#text("NSF allocation: $")#link("http://www.speaker.gov/newsroom/legislation?id=0273")[#text("90")]#text(" (was ")#link("http://www.talkingpointsmemo.com/docs/Collins-Nelson-Cuts/?resultpage=2&")[#text("initially $42")]#text(")")],
[#text("ARPA-E: $")#link("http://www.aaas.org/spp/rd/stim09c.htm")[#text("12")]]
)],
[#text("Pandemic flu preparedness: $")#link("http://www.cidrap.umn.edu/cidrap/content/influenza/panflu/news/feb1309funding.html")[#text("1.50")]#text(" (was ")#link("http://www.cidrap.umn.edu/cidrap/content/influenza/panflu/news/feb1309funding.html")[#text("initially $27")]#text(", after ")#link("http://www.cidrap.umn.edu/cidrap/content/influenza/panflu/news/feb1309funding.html")[#text("being dropped")]#text(" from FY2008 and FY2009 budgets)")

#list(
[#text("Additional request after A(H1N1) (“swine flu”) outbreak, Apr 28: $")#link("http://www.nytimes.com/2009/04/29/health/29flu.html")[#text("45")]]
)],
[#text("Volcano monitoring: $")#link("http://www.sciam.com/blog/60-second-science/post.cfm?id=stimulus-funds-already-out-the-door-2009-04-14")[#text("0.46")]#text(" (erroneously reported as $")#link("http://www.sciam.com/blog/60-second-science/post.cfm?id=stimulus-funds-already-out-the-door-2009-04-14")[#text("5.20")]#text(")")],
[#text("Salt marsh mouse preservation (aka “")#link("http://www.washingtontimes.com/news/2009/feb/12/earmark-less-bill-gives-pelosis-mouse-cookie/")[#text("Pelosi’s mouse")]#text("“): $")#link("http://www.politifact.com/truth-o-meter/statements/2009/feb/13/mike-pence/no-money-stimulus-san-francisco-mice/")[#text("0.00")]#text(" (erroneously reported as $")#link("http://www.politifact.com/truth-o-meter/statements/2009/feb/13/mike-pence/no-money-stimulus-san-francisco-mice/")[#text("0.90")]#text(")")]
)],
[#text("Market capitalization of NYSE")

#list(
[#text("May 2008 (peak): $")#link("http://www.nyxdata.com/nysedata/default.aspx?tabid=115")[#text("506,000")]],
[#text("March 2009: $")#link("http://www.nyxdata.com/nysedata/default.aspx?tabid=115")[#text("258,000")]],
[#text("Largest company by market cap: Exxon Mobil (approx $")#link("http://finance.yahoo.com/q?s=XOM&d=t")[#text("10,000")]#text(", Apr 2009)")]
)],
[#text("Value of US housing stock (2007): $")#link("http://www.bea.gov/national/FA2004/TableView.asp?SelectedTable=28&FirstYear=2002&LastYear=2007&Freq=Year")[#text("545,760")]

#list(
[#text("Total value of outstanding mortgages (2008): $")#link("http://www.federalreserve.gov/releases/z1/Current/z1r-4.pdf")[#text("330,000")]

#list(
[#text("Total value of sub-prime mortgages outstanding (2007 est): $")#link("http://www.msnbc.msn.com/id/17584725")[#text("39,000")]],
[#text("Total value of mortgage-backed securities (2008): $")#link("http://www.sifma.org/uploadedFiles/Research/Statistics/SIFMA_USBondMarketOutstanding.pdf")[#text("267,000")]]
)]
)],
[#text("Credit default swap contracts, total notional value:")

#list(
[#text("April 2008: $")#link("http://www.dtcc.com/news/press/releases/2008/tiw.php")[#text("1,320,000")]],
[#text("Oct 2008: $")#link("http://www.dtcc.com/news/press/releases/2008/tiw.php")[#text("1,040,000")]],
[#text("Credit default swaps related to mortgages: less than $")#link("http://www.dtcc.com/news/press/releases/2008/tiw.php")[#text("10,000")]]
)],
[#text("US trade balance (2007)")

#list(
[#text("Exports: $")#link("http://www.census.gov/foreign-trade/Press-Release/2007pr/final_revisions/07final.pdf")[#text("49,400")]],
[#text("Imports: $")#link("http://www.census.gov/foreign-trade/Press-Release/2007pr/final_revisions/07final.pdf")[#text("70,400")]],
[#text("Trade deficit: $")#link("http://www.census.gov/foreign-trade/Press-Release/2007pr/final_revisions/07final.pdf")[#text("21,000")]]
)]
)

#heading(level: 1)[#text("Comments (46)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38526")[#strong[#text("Taoconomics: Rescale us : Core Economics")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2009")]

#text("[…] Mathematician Terry Tao has devoted two seconds of his efficient attention to putting large numbers into perspective using the Mankiw rescaling; that is, $100m to $3 or the size of the US Federal Budget relative to an average family’s budget. The idea is to take big numbers a divide them by 100m/3. Tao does this for a ton of stuff in order to put things into perspective. He writes “This is certainly not an advanced application of mathematics by any means, but I still found the results to be instructive.” […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/827b6713d57d1c637f46b6527d3108c1d8a3e17756a6535e05ad85f0631dad1e-d337f6480d46d4f5115f7e981fa28b04c052be32534a356764ba437b9a1470e0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zygmund")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38535")[#strong[#text("Zygmund")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2009")])]

#text("Thanks for posting that. It’d be nice if more news outlets reported numbers in this manner; xkcd had made a similar point not long ago.")#linebreak()#text(" ")#link("http://xkcd.com/558/")[#text("http://xkcd.com/558/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38537")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2009")])]

#text("This table is a great summary of what is going on.")

#text("The ARRA number is deceptively large, for two reasons. First, ARRA is split between tax cuts and spending increases, while most of the other figures in the table are either revenue or spending, but not both. Second, ARRA is a multiyear program; about half of it will take place in FY 2010. Relative to other figures in the chart, the ARRA term should ideally be split up. ")#emph[#text("[I’ve made some changes to reflect this suggestion – T.]")]

#text("A related numerical exercise is to estimate your household’s relationship to federal fiscal numbers using your own adjusted gross income. The United States GDP is about 60% more than total AGI reported to the IRS. (In fact the ratio is close to the golden ratio.) So to estimate your relationship to fiscal item X, you should compute X*1.62*(your AGI)/GDP, where GDP = 427,000 in Terry’s units.")

#text("For instance, if your household reported $100K in AGI, then the conversion factor from Terry’s units to your household fraction is .379. In this case, your household fraction of the NSF was $68.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b03d754632fc640e395dce2739598f12dca1f9fef56cf08bf8c4c23daa9d57c-cc9afae8e28a43a4f1a325f5d4eaefd72021b320ddd2e8810b725a4f134fc796.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Putting the Budget into Perspective « Insular, Extraordinary")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38541")[#strong[#text("Putting the Budget into Perspective « Insular, Extraordinary")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2009")])]

#text("[…] May, 2009 Terence Tao has a great post about contextualizing the US federal budget. I thought it would be fun doing this for Japan’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38543")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2009")])]

#text("I do not know where else to post this question:")

#text("Is there any way that I get notice E-mails every time a new article on Terry’s What’s New has been created?")

#text("I do know that I can subscribe to the selected ones so that I get notice E-mails when new comments have been put specifically for those articles, but… I would just like to get notice E-mails every time new article has been put up, not comments though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38558")[#strong[#text("U.S. Economy Made Understandable | The Right Opposition")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2009")]

#text("[…] a look at The federal budget, rescaled at What’s New. You will have to overlook some of the math-speak at first but then scroll down […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38559")[#strong[#text("Readings | Venture Capital Bloggers Network")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2009")]

#text("[…] The federal budget, rescaled (Terry Tao) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5111509b2651e326d8e7595bab4294b63b6dd57fec076799cecfd21a4e437adf-ecd8cc96dbcbe71bbe1a164b7068d43197062bae6e91595fc2a3f60eedb83007.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38560")[#strong[#text("Mike")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2009")])]

#text("Wow! I really like the way you did this. It makes things a great deal more realistic when dealing with these massive numbers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13733fae139c69e0a1880ed65ca0323572bd8cc591c56e2f458f12985a4d7b3b-ea82770d6387e30675ab4774c111e966be00a6126768eb63eae3358709c420b6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Federal Budget Rescaled « Mike’s Space")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38561")[#strong[#text("The Federal Budget Rescaled « Mike’s Space")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2009")])]

#text("[…] Tao, apparently a gifted mathematician, rescaled the numbers of the federal budget to amounts even I can understand. Give his blog a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ff48c03f41f88b44cf768325e2fcdb360993454be01b9351bf2dbd937118c1c-2e6b7646513f6992b0cd442f40ba1e84ac224c37f58c50737e8151fc11af4af5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jason")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38563")[#strong[#text("jason")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2009")])]

#text("great info. love the $3 spending cut lol….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38564")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2009")]

#text("[…] The federal budget, rescaled In a recent Cabinet meeting, President Obama called for a $100 million spending cut in 90 days from the various federal […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Sogge")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38565")[#strong[#text("Chris Sogge")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2009")])]

#text("Great post!!! Scaling it always a good test. I’m impressed by this entry.")

#text("I believe that the philosophy of 100 million of cuts versus a deficit of 1.7 trillion, is that 100 million sounds larger due to the “100” compared to “1.7”. Normal people don’t think about the number of “zeros”. Obama is a good salesman.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38567")[#strong[#text("Information and Display « The Twofold Gaze")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2009")]

#text("[…] am being abstract so I’ll just say what brought on this discussion: good displays of information don’t always have to be flashy, sometimes a table will do. Terry Tao has a really cool break down of the several of the numbers that are relevant to the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38571")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2009")])]

#text("Interesting post.")

#text("There’s a neat Douglas Hofstadter essay called “On Number Numbness” that appears in his collection “Metamagical Themas” that’s about this topic. He even coins the nice term “innumeracy” for the lack of ability to understand (using some type of simple analysis like in this post) large numbers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38573")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2009")])]

#text("Very interesting post. Though, to be fair, one must point out that most families don’t need to spend money on protecting their borders and family members, nor are they expected to contribute money to research and development. Also, there is a non-scalable element to the $100m figure: unlike a $3 cut, a $100m cut involves overhead such as cancellation fees and damage payments.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38576")[#strong[#text("Understanding the US Federal budget - Politics & Current Affairs Forum")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2009")]

#text("[…] GDP 2008: $427,000 More in Terry’s blog post here. Conclude what you will from it __________________ Of all the beasts which God allows In […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9123832b2ddb4dacd4d3f7395499f0929f91f164a45dc3a3d3cda925139f9d7-08eaede51ae17992075c1ad507f6674277082e0298171194954bd7b4e955ff5c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of roadkill")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38577")[#strong[#text("roadkill")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2009")])]

#text("Excellent idea. Discussion at ")#link("http://www.politicsandcurrentaffairs.co.uk/Forum/us-politics-forum/66337-understanding-us-federal-budget.html")[#text("http://www.politicsandcurrentaffairs.co.uk/Forum/us-politics-forum/66337-understanding-us-federal-budget.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38579")[#strong[#text("Exciting New Blogs and New Posts « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2009")]

#text("[…] Terry Tao illuminatingly rescaled the US budget to match incomes and expenses of a single […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/abe53e2925b52c294782bd4e930d2feb2de5e11ce79155ce0379827eacee195d-0b2bcba381604c3b2c28513b8174ea7ebd6f528a5e4af90bf8fd28bc81c65024.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Haelfix")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38583")[#strong[#text("Haelfix")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2009")])]

#text("Amusing, the credit default swap numbers are so enormous its mindboggling.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38624")[#strong[#text("Carnival of Mathematics #52 « The Number Warrior")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2009")]

#text("[…] Tao has rescaled the United States federal budget to the scale of 100 million:3, to give a better perspective of the impact of spending. (I’ve […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nets Katz")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38630")[#strong[#text("Nets Katz")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2009")])]

#text("What I read in the newspaper is that the 2009 budget is 3.4 trillion with a deficit of 1.7 trillion. (Which motivates Mankiw’s choice of rescaling.) That budget is 100,000 with a deficit of 50000. I didn’t need the rescaling to notice the deficit was half of the budget.")

#text("By comparison, Fort Knox gold holdings rescale to just under 4.5 ounces whose spot value is around $4000. M2 money supply reported by the Fed for March 2009 (I have to multiply the number of billions by 30) is $250,908. M2 represents all physical currency + individual checking accounts plus savings accounts, but does not include certain institutional savings accounts included in M3 which is no longer published.")

#text("One power that typical law-abiding families do not have when paying their bills is the power to counterfeit money. But the federal reserve can, thereby continuously rescaling the units in this discussion. Recently")#linebreak()#text(" as part of quantitative easing, they are buying newly auctioned treasuries, and the press reports that this accounts for the calm in the")#linebreak()#text(" bond markets despite the large deficits and Chinese caution about buying")#linebreak()#text(" our bonds. It would be interesting to note in rescaled dollars at what rate the Fed balance sheet is expanding, but I don’t believe this is public information. It is the portion of our deficit that we are currently paying")#linebreak()#text(" with the printing press.")

#text("Interest rates, of course, need not be rescaled. The ten year bond rate is 3.35%. The 10 year TIPS rate is 1.75%. This predicts a 10 year forward average inflation rate of about 1.6%.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38645")[#strong[#text("Math Bloggers at Play « Let’s Play Math!")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2009")]

#text("[…] The federal budget, rescaled […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38646")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2009")])]

#text("Gold is indeed a tiny part of the modern world economy; the supply of gold has not grown nearly as fast as the world population multiplied by the material standard of living in recent centuries. In these rescaled units, the total amount of above-ground gold stocks in the world (about 160,000 tonnes, according to the sources I could find on the internet) becomes about 170 ounces (with about 2-3 ounces being mined every year), so given the rescaled world population of 204, there is not even enough physical gold available to have a 1 oz gold coin per person. So any return to the gold standard nowadays would either have to use quite minute quantities of gold to back one’s coins, notes, and savings accounts, or else to use gold to back only a small fraction of the outstanding monetary supply at any given time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f147b23fa17b8459be8625f2f29ffbcd49ac25d49d2e7d6b59c43d1cd3383316-c767091fe0f6909521add72291d96119528c3b7a10bfd4a6d300f9410592420b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38661")[#strong[#text("James")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2009")])]

#text("Anytime I feel like looking at the deficit I take a look here:")

#link("http://perotcharts.com")[#text("http://perotcharts.com")]

#text("Our government talks about irresponsible folks. If any of us ran our households like our government what would happen with that huge number. One of the main things we should be wondering is what is being given up to continue to have other countries give the US money. At some point creditors collect.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5a2baed8cb8a338d2fe51a2ba0ec68e2b5feb1b6ca1de69bbd46d109da6db92c-e9e99718a1ca2635311f000d00dc2b1dec156d8d65d3a9ffb048f7f9750350a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Georg")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38679")[#strong[#text("Georg")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2009")])]

#text("Rescaling monetary amounts is not compatible with rescaling other dimensionful quantities, though: it you rescale lengths like money, the price per area of land will go up by the inverse of the scaling factor, and the price per volume of, e.g., oil will go up like the inverse scaling factor. If you rescale areas like money instead, the price per volume will still go up like the inverse square root of the scaling factor. And if you rescale volumes like money instead, the price per area will now go down with the cube root of the scaling factor squared. The problem is that different goods are measured and sold in different dimensionful units.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38687")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2009")])]

#text("Dear Georg,")

#text("Yes, I mentioned dimensional distortions in the main post. For the purposes of economic rescaling (rescaling the national economy to resemble a family economy), one way to minimise distortion is to rescale horizontal distances but not vertical ones. (Note that the national economy and the family economy experience more or less the same vertical scales, but widely different horizontal scales.) This will then rescale volume and (the horizontal component of) area the same way (and in our economy, the horizontal component of area is far more important than the two vertical components).")

#text("Of course, this is no free lunch: this type of rescaling radically distorts slopes and hence geographical features (a hill would become something resembling an obelisk, for instance), and the physical properties of matter become highly non-isotropic (in particular, any physical phenomenon involving vertical rotation would be highly distorted). But for economic purposes (e.g. visualising oil reserves, gold reserves, arable land reserves, etc.) this non-isotropic scaling seems to suffice. For instance, with this rescaling the strategic national oil reserve consists of about 20 barrels of oil (with US daily consumption being about 0.6 barrels; worldwide proven reserves seem to be of the order of 40,000 barrels or so, though accurate figures seem to be difficult to obtain here). (If instead one wanted to conceptualise physical phenomena, e.g. climate change, then I would instead recommend an isotropic scaling, even if this means for instance that the atmosphere becomes only a few meters thick, and oceans become more like shallow ponds.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38705")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2009")])]

#text("Dimensional distortions are a tongue-in-cheek disgression from rescaling the federal budget and certain other economic resources. If you rescale the federal budget to your own adjusted gross income using the formula that I mentioned, i.e. rescale spending item X to X*1.62*(your AGI)/GDP, then it is a meaningful estimate of how much the government spends on X on your behalf. If you report a mid-range AGI to the IRS, then this meaningful rescaling only differs from Greg Mankiw’s thought experiment by a modest factor.")

#text("Maybe the most misleading aspect of this rescaling, though, is that less than half of the spending will ever be covered by from income taxes. Much of it comes from payroll taxes, and some of it comes from corporate taxes. This year and next year much of it is inflationary spending — but that spending is meant to prevent a deflationary collapse of the economy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38750")[#strong[#text("Fields medal winner Terence Tao rescales… « r3fresh [ simple comments ]")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2009")]

#text("[…] ")#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/")[#text("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ford")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38759")[#strong[#text("Ford")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2009")])]

#text("Wouldn’t it be simpler to divide by US population to get spending and debt per capita?")

#text("I always thought line-item veto could be a good idea IF total items vetoed had to add up to at least 10% of the total. Otherwise, it would be used more to control Congress (by letting allies but not enemies fund “pork”) than to balance the budget.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-38764")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2009")])]

#text("Dear Ford,")

#text("Since the rescaled US population here is close to 10, one can simply drop one more digit to get approximate per-capita data. But this makes the government look a bit on the small side; per-capita, after all, includes children and other non-working age citizens in the denominator, and also the federal government is only about a fifth of the US economy anyway. Since personal budgets are typically made on the family level, rather than a per-capita (or per-one-fifth-of-capita) level, it seemed more intuitive to me to pick a rescaling that would map the federal budget to what is roughly the size of a family budget. A population size of 9 is also about the bare minimum needed to crudely approximate a representative slice of the population as far as age ranges, incomes and genders are concerned; in contrast, per-capita data needs to be compared against an “average” citizen, as opposed to, say, a healthy, working-age male at the peak of his earnings capacity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-39111")[#strong[#text("randform » Blog Archive » scaling facts")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2009")]

#text("[…] a recent post on his blog Terence Tao had the idea to scale the US budget and other data with the scale factor […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-39197")[#strong[#text("Putting it in Perspective « OU Math Club")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2009")]

#text("[…] Terence Tao’s blog a few weeks ago he had a very interesting post about the federal budget of all things. If you watch the news you […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-39332")[#strong[#text("mlinksva's status on Wednesday, 10-Jun-09 20:08:00 UTC - Identi.ca")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2009")]

#text("[…] Simple+clever ")#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/")[#text("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-40959")[#strong[#text("Hyde Park Blvd » Blog Archive » Rescaled Reality")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")]

#text("[…] entire post and commentary are available here. Tags: economy, math, Terry […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-41333")[#strong[#text("Tracy M (churaesie) 's status on Tuesday, 08-Sep-09 06:48:04 UTC - Identi.ca")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2009")]

#text("[…] The federal budget, rescaled « What’s new a few seconds ago from xmpp […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e8b78c80fcf836808ab1cd414e591610488dabfbe61e4fce5f2bd2781c7994e-d0efe47f941b88ce2f5bad740cb2bfdf9b358f833993740483e8942a034d4cf0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jsk")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-51738")[#strong[#text("jsk")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2011")])]

#text("All the latest Federal Budget News ")#link("http://www.2012federalbudget.com")[#text("http://www.2012federalbudget.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-78950")[#strong[#text("California")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2011")]

#text("[…] absoluto, el mundo de los números (ni siquiera la política económica de EE UU le es ajena: ")#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/")[#text("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/")]#text("). Terrence Tao es el Mozart de las matemáticas; como dicen muchos de quienes lo conocen: “si […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67ff93f4e7e15999ef94c77de9b661b79bc05b2e0408a9d62a698e2753f94207-2973badff05aece490148e8bea3c8f572310e327a9bf689a7107707af2c8142e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of human mathematics")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-120476")[#strong[#text("human mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2012")])]

#text("Also, the difference between 7, 6, and 5 family members working would be pretty significant.")

#text("If you think the family is “too big”, you could say that they are caring for 1-2 grandparents, who don’t work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67ff93f4e7e15999ef94c77de9b661b79bc05b2e0408a9d62a698e2753f94207-2973badff05aece490148e8bea3c8f572310e327a9bf689a7107707af2c8142e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of human mathematics")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-120497")[#strong[#text("human mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2012")])]

#text("Actually, thinking about the 9 people as an extended family (not necessarily even living under the same roof) makes the thought experiment quite clearer.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67ff93f4e7e15999ef94c77de9b661b79bc05b2e0408a9d62a698e2753f94207-2973badff05aece490148e8bea3c8f572310e327a9bf689a7107707af2c8142e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of human mathematics")]], [#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-120679")[#strong[#text("human mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2012")])]

#text("Terence, the CBO links are now 404’ed. :(")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-182515")[#strong[#text("Visualizing Vastness - NYTimes.com")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2012")]

#text("[…] another important topic that bewilders most of us because of the gigantic numbers involved. In an illuminating blog post, the mathematician Terry Tao brings those numbers down to size by converting them to their […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-182834")[#strong[#text("Size of the Federal Budget | Admiral Hornblower")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2012")]

#text("[…] another important topic that bewilders most of us because of the gigantic numbers involved. In an illuminating blog post, the mathematician Terry Tao brings those numbers down to size by converting them to their […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-197291")[#strong[#text("Lesson Plan | Understanding the Mathematics of the Fiscal Cliff - NYTimes.com")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2012")]

#text("[…] the Budget to Household Size: The world-famous mathematician Terence Tao suggests rescaling federal budget numbers by converting $100 million to $3. This has the effect of scaling the entire federal budget of $3.54 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-197454")[#strong[#text("The Learning Network: Lesson Plan | Understanding the Mathematics of the Fiscal Cliff | Easy Nulled Script")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2012")]

#text("[…] the Budget to Household Size: The world-famous mathematician Terence Tao suggests rescaling federal budget numbers by converting $ 100 million to $ 3. This has the effect of scaling the entire federal budget of $ […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-630350")[#strong[#text("Who’s Afraid of Big Numbers? - The Inzider")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2021")]

#text("[…] money become more comprehensible if they are reframed in terms of more familiar amounts. In a 2009 blog post, the mathematician Terry Tao rescaled the entire United States federal budget to the annual […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/04/the-federal-budget-rescaled/#comment-630834")[#strong[#text("Scaling and Fame | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2021")]

#text("[…] was referenced for a post he wrote in May 2009 when Barack Obama was working on his first budget as President. The ratio of […]")
]
