// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/
// Converted to Typst by tao2typ: "2026-10-14T15:20:03.167588+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath15, sixth thread: the test problem and beyond", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath15, sixth thread: the test problem and beyond")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 March 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/")[#text("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is the sixth “research” thread of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("Polymath15 project")]#text(" to upper bound the ")#link("https://en.wikipedia.org/wiki/De_Bruijn%E2%80%93Newman_constant")[#text("de Bruijn-Newman constant")]#text(" ")#mi("{\\Lambda}")#text(", continuing ")#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/")[#text("this post")]#text(". Discussion of the project of a non-research nature can continue for now in ")#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/")[#text("the existing proposal thread")]#text(". Progress will be summarised at ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("this Polymath wiki page")]#text(".")

#text("The last two threads have been focused primarily on the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem")[#text("test problem")]#text(" of showing that ")#mi("{H_t(x+iy) \\neq 0}")#text(" whenever ")#mi("{t = y = 0.4}")#text(". We have been able to prove this for most regimes of ")#mi("{x}")#text(", or equivalently for most regimes of the natural number parameter ")#mi("{N := \\lfloor \\sqrt{\\frac{x}{4\\pi} + \\frac{t}{16}} \\rfloor}")#text(". In many of these regimes, a certain explicit approximation ")#mi("{A^{eff}+B^{eff}}")#text(" to ")#mi("{H_t}")#text(" was used, together with a non-zero normalising factor ")#mi("{B^{eff}_0}")#text("; see ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem")[#text("the wiki")]#text(" for definitions. The explicit upper bound")

#align(center)[#tao-fit-display[#tao-math("\\left|H_t - A^{eff} - B^{eff}\\right| \\leq E_1 + E_2 + E_3", block: true)]]

#text("has been proven for certain explicit expressions ")#mi("{E_1, E_2, E_3}")#text(" (see ")#link("http://michaelnielsen.org/polymath1/index.php?title=Effective_bounds_on_H_t_-_second_approach")[#text("here")]#text(") depending on ")#mi("{x}")#text(". In particular, if ")#mi("{x}")#text(" satisfies the inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{A^{eff}+B^{eff}}{B^{eff}_0}\\right| > \\frac{E_1}{\\left|B^{eff}_0\\right|} + \\frac{E_2}{\\left|B^{eff}_0\\right|} + \\frac{E_3}{\\left|B^{eff}_0\\right|}", block: true)]]

#text("then ")#mi("{H_t(x+iy)}")#text(" is non-vanishing thanks to the triangle inequality. (In principle we have an even more accurate approximation ")#mi("{A^{eff}+B^{eff}-C^{eff}}")#text(" available, but it is looking like we will not need it for this test problem at least.)")

#text("We have explicit upper bounds on ")#tao-math("{\\frac{E_1}{\\left|B^{eff}_0\\right|}}", block: false)#text(", ")#tao-math("{\\frac{E_2}{\\left|B^{eff}_0\\right|}}", block: false)#text(", ")#tao-math("{\\frac{E_3}{\\left|B^{eff}_0\\right|}}", block: false)#text("; see ")#link("http://michaelnielsen.org/polymath1/index.php?title=Controlling_H_t-A-B/B_0")[#text("this wiki page")]#text(" for details. They are tabulated in the range ")#mi("{3 \\leq N \\leq 2000}")#text(" ")#link("https://github.com/km-git-acc/dbn_upper_bound/blob/master/dbn_upper_bound/python/research/bounded_normalized_E1_and_E2_and_E3_and_overall_error.csv")[#text("here")]#text(". For ")#mi("{N \\geq 2000}")#text(", the upper bound ")#tao-math("{\\frac{E_3^*}{\\left|B^{eff}_0\\right|}}", block: false)#text(" for ")#tao-math("{\\frac{E_3}{\\left|B^{eff}_0\\right|}}", block: false)#text(" is monotone decreasing, and is in particular bounded by ")#mi("{1.53 \\times 10^{-5}}")#text(", while ")#tao-math("{\\frac{E_2}{\\left|B^{eff}_0\\right|}}", block: false)#text(" and ")#tao-math("{\\frac{E_1}{\\left|B^{eff}_0\\right|}}", block: false)#text(" are known to be bounded by ")#mi("{2.9 \\times 10^{-7}}")#text(" and ")#mi("{2.8 \\times 10^{-8}}")#text(" respectively (see ")#link("http://michaelnielsen.org/polymath1/index.php?title=Controlling_H_t-A-B/B_0")[#text("here")]#text(").")

#text("Meanwhile, the quantity ")#tao-math("{\\left|\\frac{A^{eff}+B^{eff}}{B^{eff}_0}\\right|}", block: false)#text(" can be lower bounded by")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n=1}^N \\frac{b_n}{n^s}\\right| - \\left|\\sum_{n=1}^N \\frac{a_n}{n^s}\\right|", block: true)]]

#text("for certain explicit coefficients ")#mi("{a_n,b_n}")#text(" and an explicit complex number ")#mi("{s = \\sigma + i\\tau}")#text(". Using the triangle inequality to lower bound this by")

#align(center)[#tao-fit-display[#tao-math("\\left|b_1\\right| - \\sum_{n=2}^N \\frac{\\left|b_n\\right|}{n^\\sigma} - \\sum_{n=1}^N \\frac{\\left|a_n\\right|}{n^\\sigma}", block: true)]]

#text("we can obtain a lower bound of ")#mi("{0.18}")#text(" for ")#mi("{N \\geq 2000}")#text(", which settles the test problem in this regime. One can get more efficient lower bounds by multiplying both Dirichlet series by a suitable Euler product mollifier; we have found ")#mi("{\\prod_{p \\leq P} (1 - \\frac{b_p}{p^s})}")#text(" for ")#mi("{P=2,3,5,7}")#text(" to be good choices to get a variety of further lower bounds depending only on ")#mi("{N}")#text(", see ")#link("https://github.com/km-git-acc/dbn_upper_bound/blob/master/dbn_upper_bound/python/research/mod_abbeff_lower_Nbounds.csv")[#text("this table")]#text(" and ")#link("http://michaelnielsen.org/polymath1/index.php?title=Controlling_A%2BB/B_0")[#text("this wiki page")]#text(". Comparing this against our tabulated upper bounds for the error terms we can handle the range ")#mi("{300 \\leq N \\leq 2000}")#text(".")

#text("In the range ")#mi("{11 \\leq N \\leq 300}")#text(", we have been able to obtain a suitable lower bound ")#tao-math("{\\left|\\frac{A^{eff}+B^{eff}}{B^{eff}_0}\\right| \\geq c}", block: false)#text(" (where ")#mi("{c}")#text(" exceeds the upper bound for ")#tao-math("{\\frac{E_1}{\\left|B^{eff}_0\\right|} + \\frac{E_2}{\\left|B^{eff}_0\\right|} + \\frac{E_3}{\\left|B^{eff}_0\\right|}}", block: false)#text(") by numerically evaluating ")#tao-math("{\\left|\\frac{A^{eff}+B^{eff}}{B^{eff}_0}\\right|}", block: false)#text(" at a mesh of points for each choice of ")#mi("{N}")#text(", with the mesh spacing being adaptive and determined by ")#mi("{c}")#text(" and an upper bound for the derivative of ")#tao-math("{\\left|\\frac{A^{eff}+B^{eff}}{B^{eff}_0}\\right|}", block: false)#text("; the data is available ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem#Controlling_.7CA.2BB.7C.2F.7CB_0.7C")[#text("here")]#text(".")

#text("This leaves the final range ")#mi("{N \\leq 10}")#text(" (roughly corresponding to ")#mi("{x \\leq 1600}")#text("). Here we can numerically evaluate ")#mi("{H_t(x+iy)}")#text(" to high accuracy at a fine mesh (see the data ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem#Small_values_of_x")[#text("here")]#text("), but to fill in the mesh we need good upper bounds on ")#mi("{H^{\\prime}_t(x+iy)}")#text(". It seems that we can get reasonable estimates using some contour shifting from the original definition of ")#mi("{H_t}")#text(" (see ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_second_approach")[#text("here")]#text("). We are close to finishing off this remaining region and thus solving the toy problem.")

#text("Beyond this, we need to figure out how to show that ")#mi("{H_t(x+iy) \\neq 0}")#text(" for ")#mi("{y > 0.4}")#text(" as well. General theory lets one do this for ")#mi("{y \\geq \\sqrt{1-2t} = 0.447\\dots}")#text(", leaving the region ")#mi("{0.4 < y < 0.448}")#text(". The analytic theory that handles ")#mi("{N \\geq 2000}")#text(" and ")#mi("{300 \\leq N \\leq 2000}")#text(" should also handle this region; for ")#mi("{N \\leq 300}")#text(" presumably the ")#link("https://en.wikipedia.org/wiki/Argument_principle")[#text("argument principle")]#text(" will become relevant.")

#text("The full argument also needs to be streamlined and organised; right now it sprawls over many wiki pages and github code files. (A very preliminary writeup attempt has begun ")#link("https://github.com/km-git-acc/dbn_upper_bound/tree/master/Writeup")[#text("here")]#text("). We should also see if there is much hope of extending the methods to push much beyond the bound of ")#mi("{\\Lambda \\leq 0.48}")#text(" that we would get from the above calculations. This would also be a good time to start discussing whether to move to the writing phase of the project, or whether there are still fruitful research directions for the project to explore.")

#text("Participants are also welcome to add any further summaries of the situation in the comments below.")

#heading(level: 1)[#text("Comments (102)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494016")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2018")])]

#text("I will be at a reduced level of activity this week as I will be involved in the opening week of activities at IPAM’s quantitative linear algebra program (including giving some tutorials in random matrix theory). I just wanted to record one observation here though. In order to use the argument principle, we need to evaluate the variation of ")#mi("\\mathrm{arg} H_t(x+iy)")#text(" on some rectangle, e.g. the rectangle bordering ")#mi("\\{ x+iy: 0 \\leq x \\leq 300; 0.4 \\leq y \\leq 0.45 \\}")#text(". We can work with ")#mi("h_t(z) := H_t(z) / B^{eff}_0(z)")#text(" instead (this is still holomorphic on this rectangle), as presumably this oscillates a bit less and is more numerically tractable.")

#text("Suppose we can evaluate ")#mi("h_t(x+iy)")#text(" on some mesh ")#mi("z_1,\\dots,z_k")#text(" around this rectangle, with the property that for any ")#mi("z")#text(" between adjacent points ")#mi("z_i, z_{i+1}")#text(" on this mesh, ")#tao-math("\\left|h_t(z)-h_t(z_i)\\right| < \\left|h_t(z_i)\\right|", block: false)#text(". (This is basically what we are already doing with the adaptive mesh.) Then not only is it the case that ")#mi("h_t")#text(" is non-zero, but the variation ")#mi("\\mathrm{arg} h_t(z) - \\mathrm{arg} h_t(z_i)")#text(" must be between ")#mi("-\\pi/2")#text(" and ")#mi("\\pi/2")#text(" for any such ")#mi("z")#text(", and in particular ")#mi("\\mathrm{arg} h_t(z_{i+1}) - \\mathrm{arg} h_t(z_i)")#text(" is just the standard branch of the argument of ")#mi("h_t(z_{i+1})/h_t(z_i)")#text(". This should allow us to compute the winding number by adding up all the variations in the argument and then dividing by ")#mi("2\\pi")#text(". Alternatively one could proceed visually: if one simply joins up the ")#mi("h_t(z_i)")#text(" by line segments (literally \"connecting the dots\") and plots them, the winding number of the true curve of ")#mi("h_t(z)")#text(" will match the winding number of this polygonal path, which should hopefully be visibly equal to zero.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494040")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2018")])]

#text("I will start working on the contour calculations.")#linebreak()#text(" Using the stationary point Pi/8 – (1/4)*atan((9+y)/x) results in further improvement in the derivative bound, with the average mesh spacing now around 0.065 (although most of the benefit is at the lower x values).")#linebreak()#text(" Also, earlier there was an issue with the I integral diverging for very small x, eg. x less than 13, but now it gives correct estimates for x greater than 0.")

#text("Although the older theta value (without the 1/4 factor) seems to give more stable exact integral estimates at larger x values.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494202")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2018")])]

#text("I attempted to create approximate plots of H/B0 and H’/H as z is varied along the rectangle above in a counterclockwise direction with step size 0.01. (A+B-C was used to approximate H, and NQ_(A+B-C) to approximate H’). Both never wound around the origin.")

#link("https://drive.google.com/open?id=1855iryE-7uDDEyW7hXJ5-3Njomsz-mMH")[#text("H/B0 plot")]#linebreak()#text(" ")#link("https://drive.google.com/open?id=1NHQwML2uyTZy9ZYsmbu0k8m5nrSMOiXn")[#text("H’/H plot")]#linebreak()#text(" ")#link("https://drive.google.com/open?id=18cFAymOWDVflQGPq207PwWERGVgcL5Vm")[#text("H’/H plot zoomed near the origin")]

#text("Are these plots the right way to go, and once made rigorous with an adaptive mesh and exact estimates, can they serve as proofs (backed by scripts which can always reproduce them)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494205")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2018")])]

#text("Thanks for this! The ")#mi("H/B_0")#text(" plot looks particularly good; while there is some oscillation (which by the way I would imagine would become damped if one puts in a few Euler product mollifiers, but I doubt we need to do that) the behavior looks simple enough that we should be able to rigorously control the winding number relatively easily, given that ")#mi("H/B_0")#text(" stays well away from the negative real axis most of the time. As I mentioned in a previous comment, as long as the mesh ")#mi("z_1, z_2, \\dots")#text(" is such that ")#tao-math("\\left|H/B_0(z) - H/B_0(z_i)\\right| < \\left|H/B_0(z_i)\\right|", block: false)#text(" for all ")#mi("z")#text(" on the segment connecting ")#mi("z_i")#text(" to ")#mi("z_{i+1}")#text(", the winding number for the trajectory of ")#mi("H/B_0(z)")#text(" will equal that of the polygonal path connecting the ")#mi("H/B_0(z_i)")#text(" (this is basically Rouche's theorem), and it is visually clear from the plot that this path does not wind around the origin (and one could numerically verify this if desired by summing the argument increments). As long as the polygonal path stays some distance ")#mi("\\varepsilon")#text(" away from origin, one should be able to tolerate errors of up to ")#mi("\\varepsilon")#text(" in the approximation (another application of Rouche's theorem).")

#text("The fact that ")#mi("H^{\\prime}/H")#text(" doesn't wind around the origin would give information about the zeroes of ")#mi("H^{\\prime}_t")#text(". The Ki-Kim-Lee paper studies this question also; the de Bruijn-Newman constant ")#mi("\\Lambda")#text(" is in fact just the first in a sequence of constants ")#mi("\\Lambda = \\Lambda_0 \\geq \\Lambda_1 \\geq \\dots")#text(" where ")#mi("\\Lambda_1")#text(" concerns the Riemann hypothesis for ")#mi("H^{\\prime}_t")#text(", ")#mi("\\Lambda^{\\prime}_2")#text(" concerns the Riemann hypothesis for ")#mi("H^{\\prime\\prime}_t")#text(", and so forth. (See Theorem 1.2 of ")#link("http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.164.5595&rep=rep1&type=pdf")[#text("Ki-Kim-Lee")]#text(".) It seems likely that a lot of what we do to control the zeroes of ")#mi("H_t")#text(" could also be carried over to ")#mi("H^{\\prime}_t")#text(", etc. (possibly with slightly better bounds on the corresponding de Bruijn-Newman constant), but I’m not sure if we have the energy to explore this direction too much (at some point it may make sense to just “declare victory” and write up what we have).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494248")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2018")])]

#text("Using an adaptive mesh, and the faster integral suggested by Rudolph, we get the plots below (visually, the difference from the earlier plot is that the vertices and edges of the polygon are of different color and the vertices are not equidistant). The second plot is a closeup near the origin.")

#link("https://drive.google.com/open?id=1oGQ4HfXlEiC5WUnWHOzAt5EJQlEg9SRb")[#text("Adaptive mesh plot of H/B0")]#linebreak()#text(" ")#link("https://drive.google.com/open?id=12zkFFXBF7H6Mjd1KBmLhZw10io3J_wer")[#text("Closeup near the origin")]

#text("Also, the data used to generate the plot is ")#link("https://drive.google.com/open?id=1fAu2rjhs5X7TIHbEf2VbKvIk_4Londkl")[#text("here")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494255")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2018")])]

#text("Why the polygon seems to be almost (but not really) closed?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494270")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2018")])]

#text("That must be because the adaptive mesh stopped at the ‘last’ point and not at the starting point. This can be easily changed.")

#text("Also, as a contrast to the above plot, here is an animated plot (fixed mesh) for the rectangle x= 0 to 50, and y= -0.2 to 0.2, within which we know that zeroes do occur.")

#link("https://drive.google.com/open?id=1diXD1cKyEd18wAyajAeypS7y_13Pt6Lt")[#text("Animated plot for a contour containing zeroes")]#text(". It winds around the origin 3 times, and is fun to watch!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494280")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2018")])]

#text("Thanks for this! The plot gets somewhat close to the origin, but presumably the distance is still much larger than the numerical accuracy for ")#mi("H_t/B_0")#text(" in this region. I’ve added links to these plots at the bottom of the test problem wiki page.")

#text("I think we will also need to conduct a similar exercise in the region ")#mi("11 \\leq N \\leq 300")#text(" in which the analytic lower bounds on ")#mi("A^{eff}+B^{eff}/B^{eff}_0")#text(" don’t work (even with the Euler product mollifier trick). Here we would need to numerically plot ")#mi("A^{eff}+B^{eff}/B^{eff}_0")#text(" around the rectangle and ensure that it not only fails to wind around the origin, but stays a distance at least ")#mi("c")#text(" away from some branch cut connecting the origin to infinity, where ")#mi("c")#text(" is an upper bound for the total error ")#mi("E_1 + E_2 + E_3 / B^{eff}_0")#text(". (Based on the existing plots, the negative real axis may serve as a reasonable branch cut for this purpose, since ")#mi("H_t/B_0")#text(" seems to move away from that axis rather quickly and stay away indefinitely.) One may need to do this for each ")#mi("N")#text(" separately, though for the purposes of just seeing how things should look we can just plot ")#mi("A^{eff} + B^{eff}/B^{eff}_0")#text(" for all ")#mi("11 \\leq N \\leq 300")#text(" at once without trying to worry about error terms and optimal mesh sizes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494719")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("Data for y=0.4, N=11 to 300 was available from the earlier adaptive mesh exercise (around 6 million points), so it was reused. For y=0.45, data for around 100k points was generated. For the horizontal sides of the rectangle, a few points were easily evaluated.")

#text("These are some of the resulting plots.")#linebreak()#text(" ")#link("https://drive.google.com/open?id=1fN7Wz8yCRlB6-JGIHB245KB7ZCaCrGH2")[#text("(A+B)/B0 plot for y=0.4, N=11 to 300 (green vertices and red edges)")]

#link("https://drive.google.com/open?id=1akQn7JrgX17rqPNbrfLfeKge4uFV5_Uf")[#text("(A+B)/B0 plot for the rectangle (no edges, green vertices for y=0.4, orange vertices for y=0.45, and black vertices for the horizontal sides)")]

#text("Since the y=0.45 data is too coarse, it’s vertices weren’t joined as in the first graph.")

#text("Comparing (A+B)/B0 values for y=0.4 and y=0.45, we see the latter are further away from the origin and also more tightly clustered. Minimum distance from the origin is around 0.31 (with a y=0.4 vertex), which compares favorably with the N=11 error bound of 0.163.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494721")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("Perhaps “horizontal sides” should be “vertical sides” ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494762")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("Thanks for this! The distance from the negative real axis should comfortably exceed the sum of the 0.165 error bound and the maximum fluctuation between mesh points (i.e. the derivative bound times the size of the mesh), since this was how the 0.4 mesh was designed at least.")

#text("Regarding the need to evaluate the y=0.45 data at a finer mesh, one possibility is to raise this value something larger, e.g. y=1, (thus making the rectangle a bit taller) and use analytic estimates (which improve as y increases; already when going from 0.4 to 0.45 we see that the orange dots are a bit closer to 1 than the green dots). If one is lucky one may be able to cover most of the N=11 to 300 region here. There is a catch though which is that the E_1,E_2,E_3 errors degrade exponentially as y increases (the E_3 error in particular contains an annoying factor of ")#mi("3^y")#text("), so there is a tradeoff. (Incidentally I now have slightly different values of E_1,E_2,E_3 in the pdf writeup which may be slightly better, and are designed to work for y from 0 to 1, compared to the old estimates which were valid up to ")#mi("y= 1/2")#text(".)")

#text("Anyway, it looks like we almost have covered everything we need to prove ")#mi("\\Lambda \\leq 0.48")#text(" (one could joke that we are now 4% closer to the Riemann hypothesis :). One just needs to make the meshes for the ")#mi("x \\leq 1000")#text(" and ")#mi("11 \\leq N \\leq 300")#text(" rectangle evaluations fine enough that (when combined with derivative bounds and error estimates) there is no possibility of unexpected winding around the origin.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494767")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("Thanks. Rudolph and I had started the y=0.45, N =11 to 300 adaptive mesh clockwise, which can be now be used as a backup if needed, after which we will also cover the N<11 rectangle.")

#text("Also, a minor detail is that the N=20 to 300 mesh had been run earlier (and similarly now) with c=0.065, and c=0.165 was used for N=11 to 19, which hopefully doesn't affect the results.")

#text("I tried the new e3 bound in the paper, although so far it seems to stay slightly higher than the current one. Will double check my formulas and share the update.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494769")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("Yes, the bound is slightly worse mainly because it is covering a larger range, ")#mi("y \\leq 1")#text(" instead of ")#mi("y \\leq 1/2")#text("; also because there was a slight error in the wiki treatment (I put it in boldface in ")#link("http://michaelnielsen.org/polymath1/index.php?title=Effective_bounds_on_H_t_-_second_approach#Bounding_G_.7Bt.2CN.7D.28s.29")[#text("http://michaelnielsen.org/polymath1/index.php?title=Effective_bounds_on_H_t_-_second_approach#Bounding_G_.7Bt.2CN.7D.28s.29")]#text(" ), which will probably also lead to some worsening if it is fixed. How bad is the degradation of the bound? There is scope to improve the bound a bit by making it a bit messier.")

#text("It’s fine to have different values of c for different meshes. Actually at the end of the day we may get better bounds away from zero than the c parameter, because we also get to use the fundamental theorem of calculus in the backwards direction too. For instance, let’s say we are trying to keep the function ")#mi("F(x) = H_t/B_0(x+i0.4)")#text(" away from zero and we are using a mesh ")#mi("x_1,x_2,\\dots")#text(" with rule ")#tao-math("x_{i+1} = x_i + \\frac{\\left|F(x_i)\\right| - c}{D}", block: false)#text(", where ")#mi("D")#text(" is a uniform upper bound for ")#tao-math("\\left|F^{\\prime}(x)\\right|", block: false)#text("; assume that all the mesh evaluations ")#tao-math("\\left|F(x_i)\\right|", block: false)#text(" are at least ")#mi("c")#text(". Then we certainly have")

#tao-math("\\displaystyle \\left|F(x)\\right| \\geq \\left|F(x_i)\\right| - D \\left|x-x_i\\right| \\geq \\left|F(x_i)\\right| - D \\left|x_{i+1}-x_i\\right| \\geq c", block: false)

#text("for ")#mi("x_i \\leq x \\leq x_{i+1}")#text(". But we also have")

#tao-math("\\displaystyle \\left|F(x)\\right| \\geq \\left|F(x_{i+1})\\right| - D \\left|x-x_{i+1}\\right|", block: false)

#text("and hence in fact we have the lower bound")

#tao-math("\\displaystyle \\left|F(x)\\right| \\geq \\max( \\left|F(x_i)\\right| + D \\left|x-x_i\\right|, \\left|F(x_{i+1})\\right| - D \\left|x-x_{i+1}\\right| )", block: false)#linebreak()#text(" ")#tao-math("= \\max( c + D \\left|x-x_{i+1}\\right|, \\left|F(x_{i+1})\\right| - D \\left|x-x_{i+1}\\right|) \\geq \\frac{c+\\left|F(x_{i+1})\\right|}{2},", block: false)

#text("which is a slightly better bound than ")#mi("c")#text(". (In fact this suggests that one may be able to take ")#mi("c=0")#text(" or even ")#mi("c")#text(" slightly negative and still get a good bound, which could be a modest speedup, albeit at the cost of incurring a slight risk that the mesh is not fine enough to get a usable bound.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494787")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("These are some of the older and newer e3 bounds I am getting with y=t=0.4")

#text("N, old, new")#linebreak()#text(" 11, 0.161, 0.181")#linebreak()#text(" 20, 0.064, 0.080")#linebreak()#text(" 50, 0.015, 0.021")#linebreak()#text(" 300, 0.0007, 0.001")

#text("I will also create a table with the new e1,e2,e3 and overall error for each N.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494802")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("One can replace the 1.46 in the e3 bound in Prop 5.6(vi) with ")#mi("\\exp(0.069) (1 + \\frac{10}{3(T^{\\prime}-3.33)} \\exp( \\frac{3.49}{(T^{\\prime}-3.33)}))")#text(", which may improve things a little bit. The 0.069 can be improved further to ")#tao-math("\\frac{3\\left|\\log \\frac{x}{4\\pi} + \\frac{i\\pi}{2}\\right|}{x-6} + \\frac{9}{(x-6)^2} + \\frac{3.58}{x-6}", block: false)#text(" but this will probably only give a tiny gain.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494824")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2018")])]

#text("I’ve now updated my copy of the writeup with these sharpened bounds (and this should propagate into the main github repo soon). Furthermore, the approach now also gives a quantitative error bound for ")#mi("A^{eff}+B^{eff}-C^{eff}")#text(" rather than ")#mi("A^{eff} + B^{eff}")#text("; the bound is the same except that the “")#mi("1+")#text("” term in the ")#mi("e_3")#text(" bound is dropped. This might give an alternate way to deal with ")#mi("N")#text(" just below 11 that may be more numerically efficient (which may be important as we go below 0.48).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494836")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2018")])]

#text("With the new improved bounds for e3 (of A+B) I get these values (t=y=0.4)")

#text("N, old, new")#linebreak()#text(" 11, 0.161, 0.133")#linebreak()#text(" 20, 0.064, 0.057")#linebreak()#text(" 50, 0.015, 0.01478")#linebreak()#text(" 300, 0.000725, 0.000720")

#text("The new bounds for e1 and e2 are sharper too.")

#text("I wasn’t completely sure about the (1-3y)+ factor in the paper, so have assumed it to be max(0,1-3y). ")#emph[#text("[Yes, this is correct. -T]")]

#text("A new table with e1,e2,e3_ab,e3_abc,e_toal_ab,e_total_abc is kept ")#link("https://github.com/km-git-acc/dbn_upper_bound/blob/master/dbn_upper_bound/python/research/e1_e2_e3_sharper_Nbound.csv")[#text("here")]

#emph[#text("[Added to wiki, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494859")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2018")])]

#text("The (A+B)/B0 mesh data for N=300 to 20, y=0.45, t=0.4, c=0.065 is kept ")#link("https://drive.google.com/open?id=15Xf9GsaAzydl-39zyG9nei5aZyaHwsFe")[#text("here")]

#text("Also, with the improved error bounds, even N=7 works with this approach. Too avoid too many outputs and c values, I generated mesh data with c=0.26 for N=7 to 19, y=0.4,t=0.4 and N=19 to 7, y=0.45,t=0.4, which are kept ")#link("https://drive.google.com/open?id=1kK8tV2bRfACm1lUKRFIktca58ZV8L8U3")[#text("here")]#text(" and ")#link("https://drive.google.com/open?id=13_mzqvtaZCghmj7oAZtDRXnkb2zbxQH3")[#text("here")]

#text("For t=0.4, this leaves the rectangle upto x~620 for the integral mesh.")

#text("Assuming the derivative bound does not change much if one used the (A+B-C)/B0 mesh, it may be possible to cover N=4 to 6 as well (with different c values). As an extreme, I tried ddx_bound_ABC=10*ddx_bound_AB, and it ran with c=0.26 for N=4 and c=0.16 for N=5,6 (a uniform value of 0.26 didn’t work for N=5,6).")

#emph[#text("[Links added to test problem wiki page. -T]")]
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494020")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2018")])]

#text("Summarizing some observations on the numerical effort. For the current test problem, as already mentioned in the post, we are now into the final regime of x<=1600, where the A+B lower bound and the E1+E2+E3 upper bound start overlapping. Hence for this regime, we are using a mesh with exact numerical integration of H_t and upper bound of H't, both with defined tails. There have been recently successive improvements in estimates of the latter, thus allowing a coarser mesh than assumed earlier. The whole exercise is expected to be completed in a few days.")

#text("There are two integral formulas for H_t, and so far we have focused mostly on the new one which is faster to compute, although optimized implementations have been successful even with the original integral. Meshes can be 1) fixed which is conceptually simpler, but one has to use smaller spacings, do a small post facto analysis using the derivative upper bound to check whether the spacings stay within the prescribed limits, and in the few cases where they don't, fill that part of the mesh with additional points), 2) adaptive, where the mesh points are computed in real time and things can be completed faster, but one has to be somewhat careful if the exercise is done in batches.")

#text("In terms of computational libraries, there seem to be tradeoffs of multiple kinds. There is mpmath which comes with the flexibility of python, but one either has to tolerate rounding errors induced by python, or write somewhat non-intuitive scripts. Pari/Gp eliminates those issues, allows us to write scripts almost like math formulas, and is pretty fast as well (probably compiling the scripts will result in further speed). There is also the Arb library, which potentially gives a significant speed boost, but the scripts are not math-like.")

#text("The A+B-C approximation is quite decent even at small x values, and is order of magnitudes faster than numerical integration. Right now it and its newton quotient are playing a good supporting role in terms of verifying whether the integral estimates H_t and H't are correct, and have been very useful in debugging our scripts. While attempting to push below 0.48, the approximation may acquire a much more active role.")

#text("A lot of the recent scripts for large scale computations is in the pari folder of the repo. In general, a lot more commenting and explanatory notes in the code is required to make it easier to understand, which I will work on in the next few days.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494049")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2018")])]

#text("\\hrefe –> \\href")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494057")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2018")])]

#text("I’m a different Anonymous than the one who was doing the interval arithmetic with the arb library, but I have access to several idle computers, let’s say the equivalent of 3 fairly fast quad-core PC’s. Would it be useful if I could contribute those computation resources for a while? It’s nothing like a real compute farm, but it’s probably like 8 or so typical laptops.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494064")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2018")])]

#text("That would be great. I guess for the current test problem, Anonymous@Arb has already completed the hard part (x from 1000 to 1600). But additional machines would be quite useful, while computing points along the rectangle above, and even more as we attempt to push the bound lower.")#linebreak()#text(" There are three main scripts we are using right now, which you could experiment with to gain familiarity.")#linebreak()#text(" 1) ")#link("https://pastebin.com/QDPvWa3g")[#text("Arb for numerical integration")]#linebreak()#text(" 2) ")#link("https://github.com/km-git-acc/dbn_upper_bound/blob/master/dbn_upper_bound/pari/Ht_eval.txt")[#text("Parigp for numerical integration and checks")]#linebreak()#text(" 3) ")#link("https://github.com/km-git-acc/dbn_upper_bound/blob/master/dbn_upper_bound/pari/abbeff_eval.txt")[#text("Parigp for A+B/B0 mesh")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494066")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2018")])]

#text("Ok, I’ve downloaded the script and built the arb and flint packages. I’ll continue tomorrow since it’s late here now.")

#text("By the way, if you have any computing budget and want cheap cpu cycles, hetzner.com/cloud works really well and is billed hourly at probably 10x cheaper than Amazon. The 8 core 32GB server is significantly faster than my 4 core bare metal machines. Not 2x faster since the 4-core machines have higher clock frequencies, but maybe 1.3x which is what you’d get scaling the clock rate. I’ve been playing with them for a while and they are impressive for the price.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494082")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2018")])]

#text("I have a nontechnical question about the function that we are trying to show is nonzero for certain inputs: what should it be called? Obviously it is called ")#mi("H_t(z)")#text(", but in the future if it gets its own Wikipedia page for example, then what should the page be called? I noticed that someone from the Numerical Algorithms Group is following the github mailing list for this project. What should they call this function if they add it to their proprietary library? Other contributors are using other C, Python, or PARI/GP numerical libraries; if an implementation is added upstream into these libraries then what should the function be called in these libraries?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c7b6dd2747205ae4279aaf2e8c440b39c56f49b68bddb50dc4e281bd0ca11d1-8bc210dbbf5934ee9409a367c6099918bef579f0b246d312a4d8a528276feeee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam Snogren")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494085")[#strong[#text("Sam Snogren")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2018")])]

#text("How about “Tao’s H-function”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494089")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2018")])]

#text("I’m trying to track down the provenance of this notation. The function ")#mi("H_t")#text(" is named as such in equation (1.3) of the ")#link("https://link.springer.com/article/10.1007/BF01205170")[#text("1994 paper of Csordas, Smith, and Varga")]#text(". This notation is also repeated in some earlier work by similar sets of authors, such as ")#link("https://link.springer.com/content/pdf/10.1007%2FBF01400887.pdf")[#text("this 1988 paper of Csordas, Norfolk, and Varga")]#text(". The ")#link("http://www.ams.org/journals/proc/1976-061-02/S0002-9939-1976-0434982-5/S0002-9939-1976-0434982-5.pdf")[#text("1976 paper of Newman")]#text(" instead introduces the function ")#mi("\\Xi_b")#text(" on equation (1.4), which is related to ")#mi("H_t")#text(" by the formula ")#mi("H_t(z) = \\frac{1}{8} \\Xi_{-t/4}(\\frac{z}{2})")#text(". The original 1950 ")#link("http://www.ams.org/journals/proc/1976-061-02/S0002-9939-1976-0434982-5/S0002-9939-1976-0434982-5.pdf")[#text("paper of de Bruijn")]#text(" mentions a function on equation (7.4) which is not given a name, but in our notation would be ")#mi("8 H_{1/2}( 4z)")#text(". So it may be that the ")#mi("H_t")#text(" notation first appeared in the work of Csordas et al., but the first appearance of anything resembling this function is by de Bruijn.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494097")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2018")])]

#text("Perhaps the letter ")#mi("H")#text(" in ")#mi("H_t")#text(" is because it satisfied the backwards heat equation?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of not Varga")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494129")[#strong[#text("not Varga")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2018")])]

#text("If the notation was first used in the 1988 paper then we could call it “Csordas’s, Norfolk’s, and Varga’s H-function.” Or we could call it the “Varga H-function” because Varga’s name is shorter and sounds more badass than the names Csordas or Norfolk.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494084")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2018")])]

#text("Something’s wrong with the typesetting of inequality (6) in the wiki page ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_second_approach")[#text("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_second_approach")]#text(". I think it’s missing one or more parentheses and a frac.")

#emph[#text("[Fixed, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494087")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2018")])]

#text("a squared denominator is still missing a left parenthesis")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494091")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2018")])]

#text("Is there a version of the derivative-of-Ht bounds (with integral and summation remainder bounds) that uses the original Ht formulation, without the fubini switch of integration and summation and without the theta?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494093")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2018")])]

#text("This would basically correspond to setting ")#mi("\\theta=0")#text(" in the current formulation. One could save a tiny amount in the bound by using the cosine form of the integral, rather than bounding the ")#mi("e^{izu}")#text(" and ")#mi("e^{-izu}")#text(" terms separately and then combining by the triangle inequality.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494092")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2018")])]

#text("It looks like the active work on this project is happening on the github mailing list and not on the blog.")

#text("For example I see “Yeah, one thing we can do is to find the ratio Ht/bound_ddx_Ht and then jump to the furthest point in the fixed mesh which meets the stepsize requirement. That would shorten the verification time. I had run a test of the verification script from x=1000 to 1005 (without jumping), and it around 30 minutes. I now think the ddxbound function (even the non optimized one would do) should also be computed in Arb if possible.”")

#text("What is bound_ddx_Ht and what are the fixed mesh and the stepsize requirements? What is the verification script and what does it do? What’s the ddxbound function, and what’s the difference between the optimized and non optimized one?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494096")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2018")])]

#text("bound_ddx_Ht is the D value in the upper bound of H’t …[D*exp(-theta_c*x)]")#linebreak()#text(" Anonymous@Arb had generated data from x=1000 to 1600 using a fixed mesh with stepsize of 0.005, which we have to now use to rigorously prove the non-vanishing of H_t in this x interval. For that we are running a verification script which essentially checks whether 0.005<=allowed step size (which is |H_t/upper bound H't|.")

#text("I guess in the process of running numerical exercises, we often come across technical and short term computational challenges. Sometimes they are related to the tools involved, and sometimes of an algorithmic nature, both of which need discussion and collaboration. For example, D turned out to be not that fast to calculate at large scale, so we decided to use the rows from the Arb output in a more optimal way.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494123")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2018")])]

#text("In the main wiki page, “|” is missing before ")#mi("N_0(T)")#text(" in its explicit (Backlund) estimate.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494126")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2018")])]

#text("The page ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_second_approach")[#text("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_second_approach")]#text(" has two equations labeled (1). One is for H’t(x) and the other is for theta.")

#emph[#text("[Renumbered – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494148")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2018")])]

#text("While working on transcribing the wiki arguments to a LaTeX writeup (you can see the latest draft at ")#link("https://github.com/km-git-acc/dbn_upper_bound/blob/master/Writeup/debruijn.pdf")[#text("https://github.com/km-git-acc/dbn_upper_bound/blob/master/Writeup/debruijn.pdf")]#text(" ) I found that it is slightly more natural to replace the correction term")

#mi("\\displaystyle C^{eff} := \\frac{1}{8} \\exp( \\frac{t\\pi^2}{64}) \\frac{s^{\\prime}(s^{\\prime}-1)}{2} (-1)^N ( \\pi^{-s^{\\prime}/2} \\Gamma(s^{\\prime}/2) a^{-\\sigma} C_0(p) U")#linebreak()#text(" ")#mi("\\displaystyle + \\pi^{-(1-s^{\\prime})/2} \\Gamma((1-s^{\\prime})/2) a^{-(1-\\sigma)} \\overline{C_0(p)} \\overline{U})")

#text("in the wiki by the minor variant")

#mi("\\displaystyle \\tilde C^{eff} :=\\frac{2 e^{-\\pi i y/8}}{8} \\exp( \\frac{t\\pi^2}{64}) (-1)^N \\mathrm{Re}( H_{0,1}(iT^{\\prime}) C_0(p) U e^{\\pi i/8} )")

#text("(using the notation of ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem")[#text("the wiki")]#text("). Numerically the two appear to be almost identical once ")#mi("x")#text(" is reasonably large (roughly speaking one is replacing the Gamma function with its Stirling approximation). It is sort of moot right now since we are not using the ")#mi("C^{eff}")#text(" correction, but this might be something of use in the future. Interestingly the phase of ")#mi("\\tilde C^{eff}")#text(" is very simple, it is just ")#mi("-\\pi y / 8")#text(" (up to sign); this is connected with the ")#mi("e^{-\\pi x/8}")#text(" type decay in the ")#mi("x")#text(" direction (as per the Cauchy-Riemann equations), together with the fact that ")#mi("H_t(x+iy)")#text(" is real when ")#mi("y=0")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494194")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2018")])]

#text("Just an observation that could maybe help speed up future numerical computations.")

#text("The following integral expression for ")#mi("H_t")#text(":")

#mi("H_t(z) = \\frac{1}{8}\\,\\int_{-8}^{8} \\xi\\left(\\frac12+\\frac{iz}{2}+\\sqrt{t}\\,v\\right) \\frac{1}{\\sqrt{\\pi}}\\,e^{-v^2} dv")

#text("with: ")#mi("\\xi(s) := \\frac{s(s-1)}{2} \\,\\pi^{-\\frac{s}{2}{}} \\,\\Gamma\\left(\\frac{s}{2}{}\\right)\\, \\zeta(s)")

#text("seems to provide a speed boost for direct numerical evaluation in CAS-tools. The additional bonus is that for higher ")#mi("x")#text(", it doesn’t need increasingly higher precision settings. I guess the speed comes from the optimised evaluation of ")#mi("\\zeta(s)")#text(". The strange thing however is that increasing the integral limits above 8 seems to adversely impacts the accuracy.")

#text("The following results and timings were obtained with pari/gp:")

#mi("H_{0.4}(10+0.4i) =")#linebreak()#text(" 0.03442027018705231123 – 0.0016782531784355935738*I in 116 ms.")

#mi("H_{0.4}(30+0.4i) =")#linebreak()#text(" -0.00010001026469315639165 – 7.135701992146987265 E-6*I in 162 ms.")

#mi("H_{0.4}(100+0.4i) =")#linebreak()#text(" 6.702152217279126684 E-16 + 3.133796584070556924 E-16*I in 172 ms")

#mi("H_{0.4}(300+0.4i) =")#linebreak()#text(" -4.015967420625146363 E-49 – 1.4006524430296850033 E-49*I in 208 ms.")

#mi("H_{0.4}(1000+0.4i) =")#linebreak()#text(" 1.4847586783170623283 E-169 + 3.0506306235580557898 E-167*I in 333 ms.")

#mi("H_{0.4}(3000+0.4i) =")#linebreak()#text(" -1.1441895900436789748 E-507 + 1.5701563504659934332 E-507*I in 612 ms.")

#mi("H_{0.4}(10000+0.4i) =")#linebreak()#text(" -5.577340153523143050 E-1701 – 4.087843212390861641 E-1700*I in 1,384 ms.")

#mi("H_{0.4}(30000+0.4i) =")#linebreak()#text(" 3.159248518322167576 E-5110 – 6.737020164746385398 E-5110*I in 3,139 ms.")

#mi("H_{0.4}(100000+0.4i) =")#linebreak()#text(" -9.351604489264646152 E-17047 + 4.384024397497349318 E-17047*I in 8,389 ms.")

#mi("H_{0.4}(300000+0.4i) =")#linebreak()#text(" -1.6800823865134499270 E-51156 – 2.434780317427023972 E-51155*I in 21,808 ms.")

#mi("H_{0.4}(1000000+0.4i) =")#linebreak()#text(" -9.922871600520644604 E-170537 – 7.584881610937171242 E-170537*I in 1min, 3,987 ms.")

#text("Pari/gp code used:")#linebreak()#text(" default(realprecision, 40)")#linebreak()#text(" xi(s)=(s/2)*(s-1)*Pi^(-s/2)*gamma(s/2)*zeta(s)")#linebreak()#text(" Ht(z,t)=1/8*intnum(x=-8,8,xi((1+I*z)/2+sqrt(t)*x)*1/sqrt(Pi)*exp(-x^2))")

#text("The numbers exactly match up to 20 digits with the already computed values by user Anonymous. To check the ")#mi("x \\ge 30000")#text(" values, I used ")#mi("H_{0.4}^{eff ABC}(z)")#text(" as a proxy. Grateful if someone could confirm by using the ARB libraries how well the fit actually is for these high values.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494197")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2018")])]

#text("Do you have a reference for that integral expression for Ht? I didn’t see it on the wiki.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494198")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2018")])]

#text("It is in the write-up on the wiki that prof. Tao is preparing (see link earlier in this thread).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494199")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2018")])]

#text("I see now, it’s equation (6) in the current version of the pdf. I don’t suppose we have any explicit bounds on the size of the tails of the integral.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494214")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2018")])]

#text("I have now written up some tail bounds for these integrals at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_third_approach")[#text("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_third_approach")]#text(" . One nice feature of the gaussian integral approach to computing ")#mi("H_t(x+iy)")#text(" is that one can shift the contour to any horizontal line ")#mi("\\int_{T-i\\infty}^{T+i\\infty}")#text(", in particular one can choose a single ")#mi("T")#text(" to handle multiple values of ")#mi("x")#text(" (though the integrand gets quite oscillatory and large if ")#mi("T")#text(" strays too far from ")#mi("x/2")#text("). This should be helpful for getting bounds on ")#mi("H^{\\prime}_t(x+iy)")#text(" that are uniform for ")#mi("x")#text(" in an interval; there may also be some speedup when computing ")#mi("H_t(x+iy)")#text(" for multiple values of ")#mi("x")#text(" by first evaluating and storing ")#mi("\\xi(\\sigma+iT)")#text(" for a fine mesh of ")#mi("\\sigma")#text(" and then integrating this function against various weights to recover ")#mi("H_t(x+iy)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494278")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2018")])]

#text("I tried to code the new Ht and Ht’ formulae as well as their bounds and couldn’t get the numbers properly reconciled. Could there maybe be a mistake (or typo) in the variable change step from defining:")

#mi("\\displaystyle s = \\frac{1-y+ix}{2} + \\sqrt{t} v")

#text("to")

#mi("\\displaystyle  \\exp( - \\frac{s - (\\frac{1-y+ix}{2})^2}{t} )")#text(" in the contour integral.")

#text("Shouldn’t this be:")

#mi("\\displaystyle  \\exp( - \\frac{\\left(s - \\frac{1-y+ix}{2}\\right)^2}{t} )")

#text("i.e. also including ")#mi("s")#text(" in the square?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494279")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2018")])]

#text("Yes, that is a typo, thanks for pointing it out! It propagated a few more lines into the wiki page but I think they are all fixed now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494282")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2018")])]

#text("In the wiki once xi’s functional eqn is used, the integral and the derivative seem to work if we use xi(1-sigma+iT) instead of taking its conjugate.")

#emph[#text("[I’ve made this change for now, but I’m not 100% convinced that one can do this – will look at it again tomorrow. -T]")]

#text("Also some typos in that section. The derivative has a division by t missing in few places, and after the cutoff X is introduced, the second exponential’s numerator should be squared like in other sections.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494727")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("Two remaining small typo’s in the ")#mi("\\exp( - \\frac{1-\\sigma+iT - (\\frac{1-y+ix}{2})^2}{t} ))")#text(" pieces under “one has” and under “and”.")

#text("An additional bonus of these new tail-bounded integrals is that now the evaluation of ")#mi("H_t^{^{\\prime}}")#text(" is just as fast as ")#mi("H_t")#text(" :) When I took the derivative of the original unbounded integral in pari/gp, ")#mi("H_t^{^{\\prime}}")#text(" evaluated 4-5 times slower!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494729")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("Comparing H_t estimates at x=1500,y=t=0.4, we get these values")#linebreak()#text(" A+B-C = (3.52-4.63i)*10^-252")#linebreak()#text(" Integral from -X to X = similar to A+B-C")#linebreak()#text(" Integral from 1/2 to X with xi(sig+iT)*(exp() + exp()) = (3.62+0.14i)*10^-252")#linebreak()#text(" Integral from 1/2 to X with xi(sig+iT)*exp() + xi(1-sig+iT)*exp() = similar to A+B-C")

#text("Also, possibly a typo in the functional eqn")#linebreak()#text(" xi(s)=xi(1-s) -> xi(sig+iT) = xi(1-sig-iT) (currently displayed as xi(1-sig+iT)")

#emph[#text("[Corrected, thanks – actually the formula was initially correct, but I made it incorrect earlier by misinterpreting a comment on this blog, but hopefully it is now all fixed -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494774")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("With the faster third approach integral now available, I would like to test its performance by rerunning the fixed step mesh (step size ")#mi("0.005")#text(") for ")#mi("x \\le 1600")#text(" and ")#mi("t=0.4,y=0.4")#text(".")

#text("For the previous run we have used a list of pre-computed values of ")#mi("H_{0.4}(x+0.4i)")#text(" (using the ARB library) and the bottleneck of the second integral approach was in evaluating the J-integral to establish the derivative bounds at each x-step.")

#text("You already mentioned as a benefit of the third approach, that by choosing T smartly, it might be possible to achieve a single derivative bound for multiple values of ")#mi("x")#text(" (within limits). This will certainly help, but are there maybe other ways to speed up computing the derivative bounds in the third integral approach?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494783")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("Beyond the trick of fixing T, and using the functional equation to halve the region of integration, I can’t think of any further speedups. One also needs to get upper bounds for the main portion ")#mi("\\int_0^X")#text(" of the derivative integral. The quickest way I know of would be to use the triangle inequality")

#tao-math("\\left|\\int_0^X \\dots\\right| \\leq \\frac{\\exp((T-x/2)^2/t)}{\\sqrt{4\\pi t^3}} \\int_0^X |\\xi( \\sigma+iT)|\\exp( - (\\sigma-(1-y)/2)^2/t) ( \\left|T-x/2\\right| + \\sigma - (1-y)/2 )\\ d\\sigma", block: false)

#text("as this integral has the nice feature that the dependence on ")#mi("x")#text(" is very simple once ")#mi("\\sigma,T")#text(" are fixed (it is of the form ")#tao-math("(A + B \\left|T-x/2\\right|) \\exp((T-x/2)^2/t)", block: false)#text(" for some numerically computable expressions ")#mi("A,B")#text("). I don’t know how well this bound compares with the true derivative, it would be helpful I think to have some numerical results on this.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494200")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2018")])]

#text("Nice! I didn’t realise that the zeta function was that fast to compute that this integral was numerically feasible. This may well give a different route to fast numerical evaluation of ")#mi("H_t")#text(" and its derivative with good error estimates, since it is easy to bound ")#mi("\\xi(s)")#text(" for say ")#mi("\\mathrm{Re}(s) \\geq 2")#text(" (just by using ")#tao-math("\\left|\\zeta(s)\\right| \\leq \\zeta(2) = \\frac{\\pi^2}{6}", block: false)#text(") and then also for ")#mi("\\mathrm{Re}(s) \\leq -1")#text(" by the functional equation. If the performance is significantly better than our current approach for the ranges of x we care about (something like ")#mi("x \\leq 1000")#text(", I guess) then we could certainly use this as a replacement method. I’ll try to write up some tail bound estimates in the spirit of what we already have on the wiki (and now on the writeup).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494281")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2018")])]

#text("This is a lot faster than Anonymous’ Arb code. You mention losing precision when increasing the integration limits. PARI/gp allows to tinker with the integration step in intnum(.), so that with:")#linebreak()#text(" Ht(z,t)=1/8*intnum(x=-16,16,xi((1+I*z)/2+sqrt(t)*x)*1/sqrt(Pi)*exp(-x^2), 3)")#linebreak()#text(" [ NB, the ‘3’ in argument to intnum means “divide integration step by 8”]")#linebreak()#text(" I get this for 1000+ 0.4i:")

#text("? Ht(1000+0.4*I, 0.4)")#linebreak()#text(" %10 = 1.484758678317062328342109271589162677850 E-169 + 3.050630623558055789723687410028754104648 E-167*I")

#text("Arb at 40 digits:")#linebreak()#text(" $ ./a.out 0.4 1000 0.4 40")#linebreak()#text(" Re[H]: 1.48475867831706232834210927158916267785e-169")#linebreak()#text(" Im[H]: 3.050630623558055789723687410028754104648e-167")

#text("For x = 100000+0.4*I, it would take probably several hours with Anonymous’ Arb code to compute ")#mi("H_{0.4} (x)")#text(" .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494283")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2018")])]

#text("For ")#mi("z = 1000000 + 0.4i")#text(", I used your PARI/gp code with integration limits -16 and 16, and with the integration step divided by 8. This gives the code:")#linebreak()#text(" Ht(z,t)=1/8*intnum(x=-16,16,xi((1+I*z)/2+sqrt(t)*x)*1/sqrt(Pi)*exp(-x^2), 3)")#linebreak()#text(" and the evaluation:")#linebreak()#text(" Ht(1000000+0.4*I, 0.4)")#linebreak()#text(" = -9.922871600520644601759753538816405378292 E-170537")#linebreak()#text(" – 7.584881610937171236393324520371825126356 E-170537*I")

#text("(excellent agreement), in 8 minutes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494284")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2018")])]

#text("With m=2 instead of m=3, the time is just over 3 minutes for the same integral:")#linebreak()#text(" ? Ht(z,t)=1/8*intnum(x=-16,16,xi((1+I*z)/2+sqrt(t)*x)*1/sqrt(Pi)*exp(-x^2), 2)")

#text("? Ht(1000000+0.4*I, 0.4)")#linebreak()#text(" %13 = -9.922871600520644601759753538816405378292 E-170537 – 7.584881610937171236393324520371825126356 E-170537*I")

#text("? ##")#linebreak()#text(" *** last result computed in 3min, 36,236 ms.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494196")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2018")])]

#text("P.S. whilst copying some latex from the wiki, I spotted that on our “home” wiki page under the header ")#mi("t=0")#text(", ")#mi("\\pi^{\\frac{s}{2}}")#text(" should be ")#mi("\\pi^{-\\frac{s}{2}}")#text(" in the definition of ")#mi("\\xi(s)")#text(". In the draft final write-up, it is stated correctly.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494201")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2018")])]

#text("I’m making progress on the writeup at ")#link("https://github.com/km-git-acc/dbn_upper_bound/blob/master/Writeup/debruijn.pdf")[#text("https://github.com/km-git-acc/dbn_upper_bound/blob/master/Writeup/debruijn.pdf")]#text(" . I’ve added a section on using the effective estimates to obtain asymptotic information (without explicit constants) for very large x. Basically, what happens is that for any ")#mi("0 < t \\leq 1/2")#text(", the zeroes become very predictable for real part larger than ")#mi("\\exp(C/t)")#text(" for a large absolute constant ")#mi("C")#text(": they become all real, and in fact for each natural number ")#mi("n \\geq \\exp(C/t)")#text(" there is precisely one real zero of the form ")#mi("x_n + O(x^{-ct})")#text(", where ")#mi("x_n")#text(" solves the equation")

#mi("\\frac{x_n}{4\\pi} \\log \\frac{x_n}{4\\pi} - \\frac{x_n}{4\\pi} + \\frac{5}{8} + \\frac{t}{16} \\log \\frac{x_n}{4\\pi} = n.")

#text("This is an increasing sequence that locally looks like an arithmetic progression. (One could in principle solve for ")#mi("x_n")#text(" explicitly using the Lambert W-function, though the resulting expression is not terribly enlightening.) As time advances, the zeroes all move left with speed close to ")#mi("-\\pi/4")#text(" (I recall there were some graphical numerics done previously that confirmed this marching to the left). Furthermore there is a Riemann-von Mangoldt formula: for ")#mi("X \\geq \\exp(C/t)")#text(", the number of zeroes of real part between 0 and X is")

#mi("\\frac{X}{4\\pi} \\log \\frac{X}{4\\pi} - \\frac{X}{4\\pi} + \\frac{t}{16} \\log \\frac{X}{4\\pi} + O(1)")

#text("where now ")#mi("O(1)")#text(" is bounded by an absolute constant. These results strengthen those of Ki-Kim-Lee, which had similar results but where the bounds depended on ")#mi("t")#text(" in a non-explicit fashion (and in particular could blow up as ")#mi("t \\to 0")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494684")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2018")])]

#text("Acknowledging that these plots are not in the domain of a large absolute constant ")#mi("C")#text(", the ‘marching upwards to the left’ of the zeros can already be seen in the lower ranges of ")#mi("x")#text(" at higher ")#mi("t")#text(". To test the exact ‘third approach’-integral, I ran the following implicit plots.")

#text("One for ")#mi("y=0")#text(" with ")#mi("t")#text(" varying (I suppressed the imaginary part where numerical error otherwise just shows as noise):")

#link("https://drive.google.com/open?id=1QSX7Ij0ULVDZb8uyHbBFywrsDmEzNO6L")[#text("With y=0")]

#text("And one for ")#mi("y=0.4")#text(" with ")#mi("t")#text(" varying. This one nicely reveals where the complex zeros (i.e. the red and green lines cross) of ")#mi("H_t")#text(" are hiding in the area below the line ")#mi("t=0")#text(":")

#link("https://drive.google.com/open?id=1-OcKQzCDqmePkhtF_rKKtxVosKRrXBPH")[#text("With y=0.4")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494697")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2018")])]

#text("Thanks for this! And the speed does seem very close to ")#mi("-\\pi/4")#text(", as predicted by theory.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494722")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("Similar results (for zeta nontrivial zeros representation as solutions to a similar equation) appeared in de Reyna and de Lune paper")

#link("https://arxiv.org/pdf/1305.3844.pdf")[#text("Click to access 1305.3844.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494726")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("The zeros dynamics implies that for each ")#mi("t > 0")#text(" and ")#mi("n \\geq \\exp (C / t)")#text(", the zeros ")#mi("x_n")#text(" (horizontal) velocities should be ")#mi("O(\\log x_n)")#text(", but since these velocities are in fact bounded (close to ")#mi("- \\pi / 4")#text("), it seems that (due to the regularity of the distribution of ")#mi("x_n")#text(") the infinite sum representing ")#mi("x_n")#text(" (horizontal) velocity should have a lot of cancellation (e.g. similar to cancellations in singular integrals) – which makes it bounded.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494757")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("Yes, in fact as the zeroes are so evenly spaced, the net force of nearby zeroes is negligible (something like ")#mi("O( \\log^2 x_n/x_n)")#text("). The ")#mi("-\\pi/4")#text(" drift is instead coming from a long-distance effect: there are somewhat fewer zeroes about ")#mi("x_n")#text(" units to the left of ")#mi("x_n")#text(" then there are ")#mi("x_n")#text(" units to the right of ")#mi("x_n")#text(", because the zeroes get denser as one moves away from the origin. The ")#mi("O(x_n)")#text(" additional zeroes to the right are ultimately the main source of the ")#mi("-\\pi/4")#text(" velocity to the left. (One would get a similar phenomenon if one forgot about the zeta function entirely and applied heat flow to ")#mi("\\frac{s(s-1)}{2} \\pi^{-s/2} \\Gamma(s/2) + \\frac{s(s-1)}{2} \\pi^{-(1-s)/2} \\Gamma((1-s)/2)")#text(" (i.e. the ")#mi("N=1")#text(" main term in the Riemann-Siegel formula) instead of ")#mi("\\xi(s)")#text(".)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494204")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2018")])]

#text("Is it possible that by including the ")#mi("C^{eff}")#text(" refinement in the asymptotic approximation, the threshold ")#mi("exp(C/t)")#text(" may be improved?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494209")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2018")])]

#text("Actually, the ")#mi("C^{eff}")#text(" error is not the dominant term that causes the problem. It’s more to do with the tail of ")#mi("B^{eff} = B^{eff}_0 \\sum_{n=1}^N \\frac{1}{n^{\\frac{1+y-ix}{2} + t\\overline{\\alpha_1}/2 - \\frac{t}{4} \\log n}}")#text(", or in the toy model ")#mi("B^{toy} = B^{toy}_0 \\sum_{n=1}^N \\frac{1}{n^{\\frac{1+y-ix}{2} + \\frac{t}{4} \\log \\frac{N^2}{n} - \\pi i t/8}}")#text(". In order to get good control on the zeroes, one needs the ")#mi("n=1")#text(" term to dominate all the others, and this only happens when ")#mi("t \\log N")#text(" is large, that is if ")#mi("x \\geq \\exp(C/t)")#text(" (note that for the purpose of locating zeroes one would mostly be interested in the ")#mi("y=0")#text(" case). Below this range, one expects all the ")#mi("n")#text(" summands to interact with each other in a nontrivial way, giving the same sort of complex behaviour one sees in the Riemann zeta function, where the slowly converging nature of ")#mi("\\sum_{n=1}^N \\frac{1}{n^{1/2+it}}")#text(" gives rise to oscillations on the critical line ")#mi("\\{1/2 + it: t \\in {\\bf R}\\}")#text(" that are still only poorly understood. (The ")#mi("C^{eff}")#text(" term is comparable in strength to the last term ")#mi("\\frac{1}{N^{1/2+it}}")#text(" in this sum; not entirely negligible, but still fairly small compared to the net contribution of the other summands.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494211")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2018")])]

#text("I think there’s a typo in the definition of ")#mi("F")#text(" in the new wiki page, where ")#mi("log s - 1")#text(" should be ")#mi("log(s - 1)")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494215")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2018")])]

#text("on the wiki a few lines below (3) a bound on abs(xi(s)) is written as an equation but it should be an inequality.")

#text("the inequality above (3) is missing one vertical bar")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494238")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2018")])]

#text("Here’s some output of an adaptive mesh script based on the “second approach” derivative bounds wiki page, for t=0.4, x between 20 and 1000, y=0.4, digits=20.")

#link("https://gist.githubusercontent.com/p15-git-acc/3ada0ff0b9ec77e23cb7cace0dcb8691/raw/807e1b0a16356a9bbd2a5af872f71bc064830c38/gistfile1.txt")[#text("https://gist.githubusercontent.com/p15-git-acc/3ada0ff0b9ec77e23cb7cace0dcb8691/raw/807e1b0a16356a9bbd2a5af872f71bc064830c38/gistfile1.txt")]

#text("It took 3 or 4 hours to run. The “D” and “step” values should mean the same thing as in ")#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-494166")[#text("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-494166")]#text(". The output should have full accuracy, not just for the H values but also for the “D” and “step” values.")

#text("If I understand correctly, other people have already covered this range of x, and furthermore the method I used is about to become obsolete due to the “third approach” for derivative bounds. For those reasons I haven’t yet spent any time turning the code into a single file that other people could build and run.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494272")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2018")])]

#text("I think any speedup seen with other libraries would be even more pronounced with a library like Arb. Moreover, it would be great to see how you wrote the adaptive mesh, so please share your scripts if possible.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6525d7cd9db10f0f8b9a18fa0e62f21ac78916ee3eed4debea5956daeaf030-72219f07d23f0f1bc893af77a76e1cfd99cff0d2c3626a52796f2e15ac6c7e88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494274")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2018")])]

#text("I have a non-expert question for the numerics-team: On which computer systems are you running your code? Is it parallelized? Can it use the GPU? Thanks for participating in this exciting project!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494277")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2018")])]

#text("As far as I know no one is using GPU, and parallelization is limited to running a few (like 2) instances of the same script on different ranges of x on the same computer. Different people are using different systems (windows, mac, linux). The use of github for version control has temporarily stagnated and it’s currently being used as a mailing list where people post new versions of their code as attachments to comments in a single issue thread.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6525d7cd9db10f0f8b9a18fa0e62f21ac78916ee3eed4debea5956daeaf030-72219f07d23f0f1bc893af77a76e1cfd99cff0d2c3626a52796f2e15ac6c7e88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494765")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("Is it possible to specify an upper bound for ")#mi("\\Lambda")#text(", which can not be overcome with the methods available today? Similar to the Prime Gap Conjecture, where the Bound ")#mi("H_1 = 6")#text(" is the best (assuming the generalized EH conjecture) – due to the parity problem for sieve methods. Did you identify any “no-go” problem in this project?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494773")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("There’s a typo in one of the lines between (1) and (2) in ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_third_approach")[#text("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_third_approach")]#text(" where a conj(xi(sigma + i*T)) has gone missing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494776")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("Updated C code (needs the arb library from arblib.org) to compute H or its derivative, implementing the third approach for derivative bounds:")#linebreak()#text(" ")#link("https://pastebin.com/1uk3V6CP")[#text("https://pastebin.com/1uk3V6CP")]

#text("./a.out 0.4 100 0.4 1 20")#linebreak()#text(" Re: 7.8282744022553779399e-16")#linebreak()#text(" Im: -2.537161602132201872e-16")

#text("time ./a.out 0.4 1e6 0.4 0 20")#linebreak()#text(" Re: -9.9228716005206446018e-170537")#linebreak()#text(" Im: -7.5848816109371712364e-170537")

#text("real 0m0.999s")#linebreak()#text(" user 0m0.996s")#linebreak()#text(" sys 0m0.004s")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494781")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("Is your first calculation an evaluation of ")#mi("H_{0.4}( 100 + i0.4)")#text("? It seems to differ from other evaluations of this quantity (which are roughly ")#mi("(6.7 + i 3.1) \\times 10^{-16}")#text("). If you are using the formulae on the wiki, there was an issue with some of the integrals not having the complex conjugate term ")#mi("\\xi( \\sigma + iT)")#text(" applied correctly, which has hopefully now been fixed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494782")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("Sorry, the first one is an evaluation of the derivative. The help string for the program is")

#text("—")

#text("Usage:")#linebreak()#text(" ./a.out t x y n d")

#text("Evaluate the nth derivative of H_t(x + yi) to d significant digits where H is the function involved in the definition of the De Bruijn-Newman constant.")#linebreak()#text(" Requires x >= 0 and y >= 0 and t <= 1/2 and n in {0, 1}.")

#text("—")

#text("so for")#linebreak()#text(" ./a.out 0.4 100 0.4 1 20")#linebreak()#text(" this means")#linebreak()#text(" t=0.4 x=100 y=0.4 derivative=1 digits=20")

#text("The output can be compared to what Rudolph found using PARI/GP in ")#link("https://github.com/km-git-acc/dbn_upper_bound/issues/50#issuecomment-375984748")[#text("https://github.com/km-git-acc/dbn_upper_bound/issues/50#issuecomment-375984748")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494784")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("Ah OK, thanks for clarifying. Good to see that all the numerics are in agreement :)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494809")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2018")])]

#text("Thanks, Anonymous. Do I read it correctly that your new ARB/C-code completed x=1,000,000 in less than a second? If so, that would be a stunning result and is a factor 60 (!) faster than the third approach in pari/gp. What kind of hardware are you running on? Could you maybe share some more timed results for ")#mi("H_{0.4}(x+0.4i)")#text(" e.g. in steps x=10^k?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494813")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2018")])]

#text("Yes Rudolph your idea to use zeta directly is pretty fast! Here’s what I have for x up to 1e10 in powers of 10, running on one core of a normal desktop computer that is about as fast as David’s.")

#text("./a.out 0.4 1 0.4 0 20")#linebreak()#text(" Re: 0.062123742002240553423")#linebreak()#text(" Im: -0.00028956980995331115603")#linebreak()#text(" 0.168s")

#text("./a.out 0.4 10 0.4 0 20")#linebreak()#text(" Re: 0.034420270187052311229")#linebreak()#text(" Im: -0.0016782531784355935738")#linebreak()#text(" 0.039s")

#text("./a.out 0.4 100 0.4 0 20")#linebreak()#text(" Re: 6.7021522172791266841e-16")#linebreak()#text(" Im: 3.1337965840705569244e-16")#linebreak()#text(" 0.057s")

#text("./a.out 0.4 1000 0.4 0 20")#linebreak()#text(" Re: 1.4847586783170623283e-169")#linebreak()#text(" Im: 3.0506306235580557897e-167")#linebreak()#text(" 0.133s")

#text("./a.out 0.4 1e4 0.4 0 20")#linebreak()#text(" Re: -5.5773401535231430494e-1701")#linebreak()#text(" Im: -4.0878432123908616412e-1700")#linebreak()#text(" 0.427s")

#text("./a.out 0.4 1e5 0.4 0 20")#linebreak()#text(" Re: -9.3516044892646461514e-17047")#linebreak()#text(" Im: 4.3840243974973493177e-17047")#linebreak()#text(" 1.997s")

#text("./a.out 0.4 1e6 0.4 0 20")#linebreak()#text(" Re: -9.9228716005206446018e-170537")#linebreak()#text(" Im: -7.5848816109371712364e-170537")#linebreak()#text(" 0.950s")

#text("./a.out 0.4 1e7 0.4 0 20")#linebreak()#text(" Re: 4.6135825683593727239e-1705458")#linebreak()#text(" Im: -1.4529659713176507443e-1705457")#linebreak()#text(" 1.297s")

#text("./a.out 0.4 1e8 0.4 0 20")#linebreak()#text(" Re: -5.8234400633053449049e-17054689")#linebreak()#text(" Im: -6.4741134049720791141e-17054690")#linebreak()#text(" 1.837s")

#text("./a.out 0.4 1e9 0.4 0 20")#linebreak()#text(" Re: -2.556450161624682077e-170547026")#linebreak()#text(" Im: 2.9149196815349427501e-170547026")#linebreak()#text(" 4.856s")

#text("./a.out 0.4 1e10 0.4 0 20")#linebreak()#text(" Re: 1.500919785954441619e-1705470421")#linebreak()#text(" Im: 7.8891699583970818103e-1705470423")#linebreak()#text(" 15.911s")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494814")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2018")])]

#text("Amazing! Only 8 days ago we were complaining about ")#mi("x=1600")#text(" taking 13 minutes to compute at 5 digits only and now we do ")#mi("x=10^{10}")#text(" in only 16 seconds at 20 digits on a home PC…")

#text("If we continue this way, the exact value of ")#mi("H_t")#text(" will be computed faster than its approximation :)")

#text("P.S.: ")#mi("x=1")#text(" seems slower than ")#mi("x=10")#text(". Also the timing for ")#mi("x=10^5")#text(" looks a bit odd. Are these correct?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494785")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("I’d like to mention here that one of the early approaches to bounding ")#mi("\\Lambda")#text(" may end up being more numerically viable as we go below 0.48. Right now we are relying on the following criterion:")

#strong[#text("Criterion 1:")]#text(" If ")#mi("H_{t_0}(x+iy) \\neq 0")#text(" whenever ")#mi("y \\geq \\varepsilon")#text(", then ")#mi("\\Lambda \\leq t_0 + \\frac{1}{2} \\varepsilon^2")#text(".")

#text("Verifying this criterion requires a lengthy mesh evaluation of either ")#mi("H_t")#text(" or an approximant ")#mi("A+B")#text(" which seems to be the computational bottleneck. On the other hand, we have a slightly different criterion from ")#link("http://michaelnielsen.org/polymath1/index.php?title=Dynamics_of_zeros")[#text("http://michaelnielsen.org/polymath1/index.php?title=Dynamics_of_zeros")]#text(" :")

#strong[#text("Criterion 2:")]#text(" If")

#text("All the zeroes of ")#mi("H_0(x+iy)")#text(" with ")#mi("0 \\leq x \\leq X")#text(" are real;")#linebreak()#text(" ")#mi("H_t(x+iy) \\neq 0")#text(" whenever ")#mi("0 \\leq t \\leq t_0")#text(", ")#mi("y \\geq \\varepsilon")#text(", and ")#mi("X \\leq x \\leq X+1")#text("; (one can also shrink this region a bit, see wiki) and")#linebreak()#text(" ")#mi("H_{t_0}(x+iy) \\neq 0")#text(" whenever ")#mi("y \\geq \\varepsilon")#text(" and ")#mi("x \\geq X")#text(",")

#text("then ")#mi("\\Lambda \\leq t_0 + \\frac{1}{2} \\varepsilon^2")#text(".")

#text("Because of extensive numerical verification of RH, the first condition will basically be automatic for any ")#mi("X")#text(" we would reasonably consider using. Probably one would pick ")#mi("X")#text(" so that the third condition can be verified analytically (much as we are already doing for ")#mi("t=\\varepsilon=0.4")#text(" at around ")#mi("N=300")#text(", so ")#mi("X \\approx 10^6")#text(").")#linebreak()#text(" The potential win here is that we only need to numerically evaluate ")#mi("H_t(x+iy)")#text(" (or ")#mi("A^{eff}+B^{eff}(x+iy)")#text(") for ")#mi("x")#text(" in a short interval ")#mi("[X,X+1]")#text(" rather than a long interval ")#mi("[0,X]")#text(". However, the drawback is that one has to do this for all ")#mi("0 \\leq t \\leq t_0")#text(" rather at just ")#mi("t=t_0")#text(", so we will also need derivative estimates in the t aspect. The main issue here is that I think the derivative begins to deteriorate as ")#mi("t \\to 0")#text(" (or more relevantly, the rigorous upper bounds on the derivative deteriorate). However, it may still be a net computational win, and maybe something to explore as we go beyond 0.48.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494806")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2018")])]

#text("A possible idea to bound the horizontal velocity of a (hypothetical) nonreal zero of ")#mi("H_t")#text(" is to represent it as a sum of the real zeros contribution (which may be bounded – using the cancellation in its representing sum) and the contribution due to other (hypothetical) nonreal zeros of ")#mi("H_t")#text(" (which may be bounded by using known estimates on the horizontal distribution of hypothetical “very rare” nonreal zeros of ")#mi("H_0")#text(" with ")#mi("y \\geq \\epsilon")#text(" and the contribution due to nonreal zeros with ")#tao-math("\\left|y\\right| \\leq \\varepsilon", block: false)#text(" is similar and may be absorbed by the contribution of the real zeros.)")#linebreak()#text(" The main idea here is to exploit also the known information on the horizontal distribution of “very rare” nonreal zeros of ")#mi("H_0")#text(" (hence also of ")#mi("H_t")#text(") with ")#mi("y \\geq \\epsilon")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494810")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2018")])]

#text("Is it possible (for fixed ")#mi("X")#text(") to use a 2D mesh with (adaptive) steps in both ")#mi("y")#text(" and ")#mi("t")#text(" intervals?")#linebreak()#text(" It seems that ")#mi("X")#text(" should be chosen near the middle of a relatively large gap between two consecutive zeros of ")#mi("H_0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494811")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2018")])]

#text("It seems that the second condition in criterion 2, with varying ")#mi("y, t")#text(" and varying ")#mi("x")#text(" in a short interval ")#mi("X_1, X_2")#text(" can be simplified by verifying it only for ")#mi("x")#text(" at the end points ")#mi("X_1, X_2")#text(" of the interval (to prevent from any nonreal zero to enter the interval while ")#mi("t")#text(" is increasing from ")#mi("0")#text(" to ")#mi("t_0")#text(").")#linebreak()#text(" Therefore it seems sufficient to use fixed ")#mi("x = X_1, X_2")#text(" and 2D mesh in both ")#mi("t")#text(" and ")#mi("y")#text(" (instead of 3D mesh in ")#mi("t, x, y")#text("). ")#mi("X_1, X_2")#text(" should be chosen with relatively large distances from the (nearest) zeros of ")#mi("H_0")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494801")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("Does ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_second_approach")[#text("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_second_approach")]#text(" have any limitations on x other than inequality (2) and the analogous inequality where X=0? Can the formulas on that page be used to evaluate Ht and to bound its derivative when x is near zero?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494825")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2018")])]

#text("Yes, that is one key advantage of this second approach. In contrast, the third approach technically works for x near zero, but the error term degrades because the parameter ")#mi("T")#text(", which prefers to be close to ")#mi("x/2")#text(", is constrained to be at least 1. This is mainly due to the breakdown of the Stirling approximation to the gamma function near the negative real axis (where the poles are). In principle one could tighten the third approach to give better results for very small ")#mi("x")#text(" (since by the functional equation we only need to evaluate xi on the right half-plane and so the negative real axis should not be an issue), but this looks like a region which is well controlled in any case, so this is presumably not a priority.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494831")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2018")])]

#text("I have a question that I want to call super naive except I that don’t want to discourage other readers of the blog from asking stupid questions too. When we accumulate certain evaluations of functions of endpoints of intervals on a mesh along a directed perimeter of a rectangle in the complex plane in order to count the zeros inside the rectangle, I understand how the derivative bound in ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_second_approach")[#text("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_second_approach")]#text(" helps us to determine the mesh granularity along the horizontal lines where y is constant and x varies, but I don’t understand how we determine the granularity along the vertical lines when y varies and x is constant. Is there a monotonicity property that we use? This question is for x < 2000.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494835")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2018")])]

#text("The function ")#mi("H_t")#text(" is holomorphic, so we have the Cauchy-Riemann equations ")#mi("\\frac{\\partial}{\\partial y} H_t(x+iy) = i \\frac{\\partial}{\\partial x} H_t(x+iy) = i H^{\\prime}_t(x+iy)")#text(", so the derivative bound controls both horizontal and vertical variation. Similarly for ")#mi("H_t(x+iy)/B_0(x+iy)")#text(", which is also holomorphic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494837")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2018")])]

#text("The derivative bound controls both horizontal and vertical variation, but does it control variation on the whole interval between vertical mesh points or only between horizontal mesh points? For the horizontal mesh there’s a statement about the bound “After fixing n0, X, theta, the only x dependence in these terms is a factor of exp(-theta*x), so one gets uniform estimates for any x >= x0.” Is there an analogous uniform estimate for any y >= y0, or do we not need one, or is it obvious from the uniform estimate for x?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494838")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2018")])]

#text("Good point! Fortunately ")#mi("y")#text(" only enters through the parameter ")#mi("a")#text(" (which is set equal to the four values of ")#mi("9+y, 9-y, 5+y, 5-y")#text(") and the bounds are monotone increasing in ")#mi("a")#text(" (as can be seen from inspection of the integrals). So for the ")#mi("a = 9+y, 5+y")#text(" terms one would need to substitute the upper bound on ")#mi("y")#text(", while for ")#mi("a = 9-y, 5-y")#text(" one would need the lower bound on ")#mi("y")#text(".")

#text("Alternatively, we can avoid all use of vertical line segments and work with an enormous rectangle ")#mi("\\{ x+iy: 0 \\leq x \\leq X^*, 0.4 \\leq y \\leq 0.45 \\}")#text(" where ")#mi("X^*")#text(" is much larger than ")#mi("X")#text(". When sending ")#mi("X^*")#text(" infinity, the analytic estimates ensure that the variation on the far right edge is asymptotically negligible, and analytic estimates should also be able to handle the variation between ")#mi("X")#text(" and ")#mi("X^*")#text(". The segments ")#mi("\\{ x+0.4 i: 0 \\leq x \\leq X \\}")#text(" and ")#mi("\\{ x +0.45 i: 0 \\leq x \\leq X \\}")#text(" (as well as the easy vertical line segment ")#mi("\\{ yi: 0.4 i \\leq y \\leq 0.45 i\\}")#text(") would still have to be done numerically, of course.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494839")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2018")])]

#text("We have two basic approaches right now to prevent zeroes of ")#mi("H_{t_0}(x+iy)")#text(" from entering the region ")#mi("y \\geq \\varepsilon")#text(". Our primary approach is to directly use the argument principle, evaluating ")#mi("H_{t_0}(x+iy)")#text(" either exactly or approximately at ")#mi("y = \\varepsilon")#text(" (and also at a higher horizontal line). In a previous comment I also mentioned a secondary approach in which the main task is to block out zeroes instead in a region ")#mi("\\{ x+iy: X \\leq x \\leq X+1; y \\geq \\varepsilon \\}")#text(" but now for all ")#mi("0 \\leq t \\leq t_0")#text(".")

#text("There is a third approach that I had previously discounted but am now rethinking, which is to start with the fact that the zeroes of ")#mi("H_0")#text(" are already known to be real up to a very large value ")#mi("X")#text(" of ")#mi("x")#text(" (something like ")#mi("X=10^{12}")#text(") due to the existing numerical work on RH, and try to prevent all the non-real zeroes from moving down into smaller values of x as ")#mi("t")#text(" increases. If for instance one can show that by time ")#mi("t=0.4")#text(" there are still no non-real zeroes with ")#tao-math("\\left|x\\right| \\leq 10^6", block: false)#text(" and ")#mi("y \\geq 0.4")#text(", then by combining this with our analytic results we can certify the entire region ")#mi("\\{ y \\geq 0.4 \\}")#text(" as free of zeroes of ")#mi("H_{0.4}")#text(" without doing any further numerics in the ")#tao-math("\\left|x\\right| \\leq 10^6", block: false)#text(" region. (Note that while non-real zeroes can (and eventually will) collide with their complex conjugate to become real, the converse cannot happen: zeroes that are real stay real forever.)")

#text("The problem I had been facing with this third approach was that there was no upper bound on the horizontal velocity of zeroes, particularly in the “big bang” period when ")#mi("t")#text(" is very close to zero. If there were two adjacent zeroes that were aligned to be almost horizontal to each other, then the one on the left will fly leftwards with a huge negative velocity. In principle, this might mean that one or more complex zeroes that were just outside the range ")#mi("10^{12}")#text(" of numerical verification at time ")#mi("t=0")#text(" could zoom into the bad zone ")#tao-math("\\left|x\\right| \\leq 10^6", block: false)#text(" in an arbitrarily small amount of time (unless there is some barrier to stop this, such as the one erected in the second approach).")

#text("However, what I now realise is that whenever this occurs, the other zero in the pair of nearby zeroes will acquire an equal and opposite large velocity to the right. So if one works with some sort of aggregate statistic that sums over all zeroes, rather than focusing on the dynamics of a single zero, then things appears to be much better behaved.")

#text("I am starting to work out what happens in particular to the statistic")

#mi("S(t) = \\sum_{H_t(x+iy) = 0: y>0} y e^{-x/X}")

#text("which is a weighted sum of zeroes above the real axis. At time 0 it should be possible to ensure that this expression is quite small for reasonably large X, e.g. ")#mi("X = 10^{10}")#text(". The derivative to this expression contains a lot of terms, one for each pair of zeroes, but the pairs that are far from each other (distance ")#mi("\\geq 1")#text(", say) seem to contribute ")#mi("O(S)")#text(" or better (plus some negligible errors), and the pairs that are close to each other seem to be contributing something like ")#mi("O( \\log X / X )")#text(" (using some Riemann von Mangoldt formulae that I have just added to the asymptotics section of the writeup that stay uniform as t approaches 0). So it looks like Gronwall’s inequality is going to keep this statistic small for later times such as ")#mi("t=0.4")#text(" which should hopefully be enough to prevent zeroes high above the real axis.")

#text("In order for this to work properly one needs effective Riemann von Mangoldt formulae on the number of zeroes of ")#mi("H_t")#text(" of real part up to any given ")#mi("X")#text(". This could be a bit messy. On the other hand it looks like error terms are something like ")#mi("O( \\log X/X )")#text(" of the main term which is very promising and could allow for a fair amount of slack in the effective estimates. Anyway I will try to work out something more precise on this possible third approach.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494844")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2018")])]

#text("Since the terms ")#mi("y e^{-x / X}")#text(" in the sum for ")#mi("S(t)")#text(" vanish for ")#mi("y=0")#text(", the restriction ")#mi("y > 0")#text(" in the sum may be relaxed to ")#mi("y \\geq 0")#text(" (which does not distinguish between real zeros and zeros with ")#mi("y> 0")#text(".) To deal simultaneously also with the ")#mi("y < 0")#text(" case, one may replace the factor ")#mi("y")#text(" by its absolute value ")#tao-math("\\left|y\\right|", block: false)#text(", but it seems better to replace it by ")#mi("y^2")#text(" (since the zeros vertical dynamics for ")#mi("y^2")#text(" is more regular for small ")#mi("y")#text(" than that of ")#mi("y")#text(" or ")#tao-math("\\left|y\\right|", block: false)#text(".) The statistic ")#mi("S(t)")#text(" can also be made more flexible by replacing ")#mi("x")#text(" (in the exponent) by ")#mi("c x")#text(".")

#text("Therefore, my suggestion is to modify the terms in the sum for ")#mi("S(t)")#text(" by ")#tao-math("y^2 e^{-c \\left|x\\right| / X}", block: false)#text(", where the (unrestricted!) sum is over all the zeros ")#mi("x + i  y")#text(" of ")#mi("H_t")#text(" and the scaling factor ")#mi("c")#text(" may depend on ")#mi("X")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494846")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2018")])]

#text("A more systematic (and flexible) approach is to use the general statistic")

#mi("S_W(t) := \\sum_{H_t (x + i y) = 0} W(x, y)")

#text("For sufficiently smooth weight function ")#mi("W")#text(" over the complex plane, with some desirable properties (e.g. ")#mi("W(x, 0) = 0")#text(" – to avoid contribution from the real zeros of ")#mi("H_t")#text(") such that by using information on the asymptotic distribution and dynamics of ")#mi("H_t")#text(" zeros, there is a sufficiently good estimate (or even a “main term”) with effective error bounds for the (time) derivative of the statistic ")#mi("S_W")#text(".")#linebreak()#text(" This approach (similar to the approach in Polymath8) seems to lead to a variational optimization problem for the weight function ")#mi("W")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494865")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2018")])]

#text("This is certainly a possibility; in particular it seems beneficial to truncate the ")#mi("e^{-x/X}")#text(" weight to be compactly supported. But this particular choice of weight seems to have relatively good properties, in particular I wrote up some asymptotic calculations at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Dynamics_of_zeros#Derivative_analysis")[#text("http://michaelnielsen.org/polymath1/index.php?title=Dynamics_of_zeros#Derivative_analysis")]#text(" that indicate that the quantity ")#mi("S(t)")#text(" grows quite slowly in time.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494879")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2018")])]

#text("The time derivatives of ")#mi("H_t")#text(" zeros and the statistic ")#mi("S")#text(" are well defined except for (at most countably many) “singular” t-values for which ")#mi("H_t")#text(" has a multiple zero. Since for any fixed ")#mi("t_0 > 0")#text(" there are at most finitely many non-real zeros of ")#mi("H_t")#text(" for each ")#mi("t \\geq t_0")#text(", it follows that there are only finitely many “singular” t-values in ")#mi("[t_0, +\\infty)")#text(", implying that ")#mi("S")#text(" is continuous and piecewise smooth on ")#mi("[t_0, + \\infty)")#text(" (it might not be differentiable only for such “singular” t-values).")#linebreak()#text(" Therefore the above estimates of ")#mi("S(t)")#text(" should apply for each open interval between consecutive singular t-values, and by continuity they should apply (for each fixed ")#mi("t_0 > 0")#text(") for all ")#mi("t \\geq  t_0")#text(" but in terms of ")#mi("S(t_0)")#text(" (still not in terms of ")#mi("S(0)")#text(" !).")#linebreak()#text(" Now by using the continuity of ")#mi("S")#text(" at ")#mi("t=0")#text(", we see that by letting ")#mi("t_0 \\to 0")#text(", the estimate of ")#mi("S(t)")#text(" via ")#mi("S(t_0)")#text(" tends to the desired estimate of ")#mi("S(t)")#text(" in terms of ")#mi("S(0)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494900")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2018")])]

#text("Can this approach (using the weighted sum statistic over ")#mi("H_t")#text(" zeros) be interpreted as a kind of sieve method (for ")#mi("H_t")#text(" zeros – similar to the usual sieve methods for primes)?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494840")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2018")])]

#text("Is the test problem finished, or finished enough to have served its purpose?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494864")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2018")])]

#text("I’ll defer to the numerics team for the precise status, but I think we have cleared all but the fairly small values of ")#mi("x")#text(" (maybe something like ")#mi("x \\leq 1000")#text(") for the toy problem, but should soon have the capability to do that also. The same methods, with a little bit more work (basically requiring one to analyse y=0.45 as well as 0.4) should then soon give the bound ")#mi("\\Lambda \\leq 0.48")#text(". Once we figure out how to do that it should be relatively easy to see how far the methods can be pushed, by testing various ways in which to lower the ")#mi("t = 0.4")#text(" and ")#mi("y = 0.4")#text(" parameters. (Presumably one does not need to do a full mesh evaluation etc. for these parameters to get a rough sense of whether the method is feasible there.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494866")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2018")])]

#text("I think everything except the x lte 1000, y=0.45 line segment (and the other two smaller sides of the rectangle) is covered. With the latest estimates on the (A+B) error bounds, we may in fact require to verify this segment only for N lte 6. We are running it now for the entire rectangle with the third integral approach.")

#text("Using the first and second integral approaches, the x lte 1600,y=0.4 part had been verified earlier (mentioned in these fifth thread comments ")#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-494175")[#text("1000 lte x lte 1600")]#text(" and ")#link("https://terrytao.wordpress.com/2018/03/02/polymath15-fifth-thread-finishing-off-the-test-problem/#comment-494166")[#text("x lt 1000")]#text(").")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494867")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2018")])]

#text("Here’s a script that counts roots of ")#mi("H_t(x + iy)")#text(" inside the region where ")#mi("x_a < x < x_b")#text(" and ")#mi("y_a < y < y_b")#text(" using the argument principle and Rouché's theorem. It is designed to be exact, using interval arithmetic and explicit tail bounds everywhere. On the other hand it is slow and it might not terminate for inputs that are much different from the examples below.")

#text("Most of the formulas are taken from ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_second_approach")[#text("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_second_approach")]#text(" .")

#text("Source code: ")#link("https://pastebin.com/TiFk6CfF")[#text("https://pastebin.com/TiFk6CfF")]

#text("—")

#text("./a.out t xa xb ya yb")

#text("Count the roots of H_t(x + yi).")#linebreak()#text(" xa < x < xb")#linebreak()#text(" ya < y < yb")

#text("—")

#text("./a.out 0 50 70 -1 2")#linebreak()#text(" 3")#linebreak()#text(" 0m13.731s")

#text("./a.out 0.4 50 70 -1 2")#linebreak()#text(" 2")#linebreak()#text(" 0m11.459s")

#text("./a.out 0.4 0 100 0.4 0.45")#linebreak()#text(" 0")#linebreak()#text(" 1m9.112s")

#text("./a.out 0.4 100 200 0.4 0.45")#linebreak()#text(" 0")#linebreak()#text(" 5m27.415s")

#text("./a.out 0.4 200 300 0.4 0.45")#linebreak()#text(" 0")#linebreak()#text(" 10m12.504s")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494895")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2018")])]

#text("For what it’s worth I also have")

#text("./a.out 0.4 300 1000 0.4 0.45")#linebreak()#text(" 0")#linebreak()#text(" 266m51.174s")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494897")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2018")])]

#text("Amazing. With your last four estimates, I guess all the pieces are in place and the ‘jigsaw’ is complete :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494906")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2018")])]

#text("Looks like a good time to roll over to a new thread then, since we’ve hit 100 comments in any case. Will do that now.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-495076")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2018")])]

#text("@Anonymous, to make it easier to find your scripts, I have created a Arb folder in the repo where the three pastebin links are documented.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath15, seventh thread: going below 0.48 | What's new")]], [#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494908")[#strong[#text("Polymath15, seventh thread: going below 0.48 | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2018")])]

#text("[…] thread of the Polymath15 project to upper bound the de Bruijn-Newman constant , continuing this post. Discussion of the project of a non-research nature can continue for now in the existing proposal […]")
]
