// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound/
// Converted to Typst by tao2typ: "2026-10-14T16:36:34.973872+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Erdos’ divisor bound", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Erdos’ divisor bound")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 July 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound/")[#text("https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of the basic problems in ")#link("http://en.wikipedia.org/wiki/Analytic_number_theory")[#text("analytic number theory")]#text(" is to obtain bounds and asymptotics for sums of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} f(n)")]]

#text("in the limit ")#mi("{x \\rightarrow \\infty}")#text(", where ")#mi("{n}")#text(" ranges over natural numbers less than ")#mi("{x}")#text(", and ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" is some ")#link("http://en.wikipedia.org/wiki/Arithmetic_function")[#text("arithmetic function")]#text(" of number-theoretic interest. (It is also often convenient to replace this sharply truncated sum with a ")#link("http://www.tricki.org/article/Smoothing_sums")[#text("smoother sum")]#text(" such as ")#mi("{\\sum_n f(n) \\psi(n/x)}")#text(", but we will not discuss this technicality here.) For instance, the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(" is equivalent to the assertion")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) = x + o(x)")]]

#text("where ")#mi("{\\Lambda}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(", while the ")#link("http://en.wikipedia.org/wiki/Riemann_hypothesis")[#text("Riemann hypothesis")]#text(" is equivalent to the stronger assertion")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) = x + O(x^{1/2+o(1)}).")]]

#text("It is thus of interest to develop techniques to estimate such sums ")#mi("{\\sum_{n \\leq x} f(n)}")#text(". Of course, the difficulty of this task depends on how “nice” the function ")#mi("{f}")#text(" is. The functions ")#mi("{f}")#text(" that come up in number theory lie on a broad spectrum of “niceness”, with some particularly nice functions being quite easy to sum, and some being insanely difficult.")

#text("At the easiest end of the spectrum are those functions ")#mi("{f}")#text(" that exhibit some sort of regularity or “smoothness”. Examples of smoothness include “Archimedean” smoothness, in which ")#mi("{f(n)}")#text(" is the restriction of some smooth function ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" from the reals to the natural numbers, and the derivatives of ")#mi("{f}")#text(" are well controlled. A typical example is")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\log n.")]]

#text("One can already get quite good bounds on this quantity by comparison with the integral ")#mi("{\\int_1^x \\log t\\ dt}")#text(", namely")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\log n = x \\log x - x + O(\\log x),")]]

#text("with sharper bounds available by using tools such as the ")#link("http://en.wikipedia.org/wiki/Euler%E2%80%93Maclaurin_formula")[#text("Euler-Maclaurin formula")]#text(" (see ")#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/")[#text("this blog post")]#text("). Exponentiating such asymptotics, incidentally, leads to one of the standard proofs of ")#link("http://en.wikipedia.org/wiki/Stirling's_approximation")[#text("Stirling’s formula")]#text(" (as discussed in ")#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/")[#text("this blog post")]#text(").")

#text("One can also consider “non-Archimedean” notions of smoothness, such as periodicity relative to a small period ")#mi("{q}")#text(". Indeed, if ")#mi("{f}")#text(" is periodic with period ")#mi("{q}")#text(" (and is thus essentially a function on the cyclic group ")#mi("{{\\bf Z}/q{\\bf Z}}")#text("), then one has the easy bound")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\leq x} f(n) = \\frac{x}{q} \\sum_{n \\in {\\bf Z}/q{\\bf Z}} f(n) + O( \\sum_{n \\in {\\bf Z}/q{\\bf Z}} \\left|f(n)\\right| ).", block: true)]]

#text("In particular, we have the fundamental estimate ")#metadata(none) <tao-700dd4c8b6a9ed8ef635>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{n \\leq x: q|n} 1 = \\frac{x}{q} + O(1).")]]

#text(" This is a good estimate when ")#mi("{q}")#text(" is much smaller than ")#mi("{x}")#text(", but as ")#mi("{q}")#text(" approaches ")#mi("{x}")#text(" in magnitude, the error term ")#mi("{O(1)}")#text(" begins to overwhelm the main term ")#mi("{\\frac{x}{q}}")#text(", and one needs much more delicate information on the fractional part of ")#mi("{\\frac{x}{q}}")#text(" in order to obtain good estimates at this point.")

#text("One can also consider functions ")#mi("{f}")#text(" which combine “Archimedean” and “non-Archimedean” smoothness into an “adelic” smoothness. We will not define this term precisely here (though the concept of a ")#link("http://en.wikipedia.org/wiki/Schwartz%E2%80%93Bruhat_function")[#text("Schwartz-Bruhat function")]#text(" is one way to capture this sort of concept), but a typical example might be")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\chi(n) \\log n")]]

#text("where ")#mi("{\\chi}")#text(" is periodic with some small period ")#mi("{q}")#text(". By using techniques such as ")#link("http://en.wikipedia.org/wiki/Summation_by_parts")[#text("summation by parts")]#text(", one can estimate such sums using the techniques used to estimate sums of periodic functions or functions with (Archimedean) smoothness.")

#text("Another class of functions that is reasonably well controlled are the ")#link("http://en.wikipedia.org/wiki/Multiplicative_function")[#text("multiplicative functions")]#text(", in which ")#mi("{f(nm) = f(n) f(m)}")#text(" whenever ")#mi("{n,m}")#text(" are coprime. Here, one can use the powerful techniques of ")#link("http://en.wikipedia.org/wiki/Multiplicative_number_theory")[#text("multiplicative number theory")]#text(", for instance by working with the ")#link("http://en.wikipedia.org/wiki/Dirichlet_series")[#text("Dirichlet series")]

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{f(n)}{n^s}")]]

#text("which are clearly related to the partial sums ")#mi("{\\sum_{n \\leq x} f(n)}")#text(" (essentially via the ")#link("http://en.wikipedia.org/wiki/Mellin_transform")[#text("Mellin transform")]#text(", a cousin of the Fourier and Laplace transforms); for this post we ignore the (important) issue of how to make sense of this series when it is not absolutely convergent (but see ")#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/")[#text("this previous blog post")]#text(" for more discussion). A primary reason that this technique is effective is that the Dirichlet series of a multiplicative function factorises as an ")#link("http://en.wikipedia.org/wiki/Euler_product")[#text("Euler product")]

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{f(n)}{n^s} = \\prod_p (\\sum_{j=0}^\\infty \\frac{f(p^j)}{p^{js}}).")]]

#text("One also obtains similar types of representations for functions that are not quite multiplicative, but are closely related to multiplicative functions, such as the von Mangoldt function ")#mi("{\\Lambda}")#text(" (whose Dirichlet series ")#mi("{\\sum_{n=1}^\\infty \\frac{\\Lambda(n)}{n^s} = -\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)}}")#text(" is not given by an Euler product, but instead by the ")#link("http://en.wikipedia.org/wiki/Logarithmic_derivative")[#text("logarithmic derivative")]#text(" of an Euler product).")

#text("Moving another notch along the spectrum between well-controlled and ill-controlled functions, one can consider functions ")#mi("{f}")#text(" that are ")#emph[#text("divisor sums")]#text(" such as")

#align(center)[#tao-fit-display[#mitex("f(n) = \\sum_{d \\leq R; d|n} g(d) = \\sum_{d \\leq R} 1_{d|n} g(d)")]]

#text("for some other arithmetic function ")#mi("{g}")#text(", and some ")#emph[#text("level")]#text(" ")#mi("{R}")#text(". This is a linear combination of periodic functions ")#mi("{1_{d|n} g(d)}")#text(" and is thus ")#emph[#text("technically")]#text(" periodic in ")#mi("{n}")#text(" (with period equal to the least common multiple of all the numbers from ")#mi("{1}")#text(" to ")#mi("{R}")#text("), but in practice this periodic is far too large to be useful (except for extremely small levels ")#mi("{R}")#text(", e.g. ")#mi("{R = O(\\log x)}")#text("). Nevertheless, we can still control the sum ")#mi("{\\sum_{n \\leq x} f(n)}")#text(" simply by rearranging the summation:")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} f(n) = \\sum_{d \\leq R} g(d) \\sum_{n \\leq x: d|n} 1")]]

#text("and thus by ")#link(<tao-700dd4c8b6a9ed8ef635>)[#text("(1)")]#text(" one can bound this by the sum of a main term ")#mi("{x \\sum_{d \\leq R} \\frac{g(d)}{d}}")#text(" and an error term ")#tao-math("{O( \\sum_{d \\leq R} \\left|g(d)\\right| )}", block: false)#text(". As long as the level ")#mi("{R}")#text(" is significantly less than ")#mi("{x}")#text(", one may expect the main term to dominate, and one can often estimate this term by a variety of techniques (for instance, if ")#mi("{g}")#text(" is multiplicative, then multiplicative number theory techniques are quite effective, as mentioned previously). Similarly for other slight variants of divisor sums, such as expressions of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq R; d | n} g(d) \\log \\frac{n}{d}")]]

#text("or expressions of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq R} F_d(n)")]]

#text("where each ")#mi("{F_d}")#text(" is periodic with period ")#mi("{d}")#text(".")

#text("One of the simplest examples of this comes when estimating the ")#link("http://en.wikipedia.org/wiki/Divisor_function")[#text("divisor function")]

#align(center)[#tao-fit-display[#mitex("\\tau(n) := \\sum_{d|n} 1,")]]

#text("which counts the number of divisors up to ")#mi("{n}")#text(". This is a multiplicative function, and is therefore most efficiently estimated using the techniques of multiplicative number theory; but for reasons that will become clearer later, let us “forget” the multiplicative structure and estimate the above sum by more elementary methods. By applying the preceding method, we see that")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\leq x} \\tau(n)  & = \\sum_{d \\leq x} \\sum_{n \\leq x:d|n} 1", block: true)



#tao-math(" & = \\sum_{d \\leq x} (\\frac{x}{d} + O(1))", block: true)
]

#metadata(none) <tao-aac6d0091fc3f8dfd3bc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("= x \\log x + O(x).")]]



#text("Here, we are (barely) able to keep the error term smaller than the main term; this is right at the edge of the divisor sum method, because the level ")#mi("{R}")#text(" in this case is equal to ")#mi("{x}")#text(". Unfortunately, at this high choice of level, it is not always possible to always keep the error term under control like this. For instance, if one wishes to use the standard divisor sum representation")

#align(center)[#tao-fit-display[#mitex("\\Lambda(n) = \\sum_{d|n} \\mu(d) \\log \\frac{n}{d},")]]

#text("where ")#mi("{\\mu}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Mobius_function")[#text("Möbius function")]#text(", to compute ")#mi("{\\sum_{n \\leq x} \\Lambda(n)}")#text(", then one ends up looking at")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\leq x} \\Lambda(n)  & = \\sum_{d \\leq x} \\mu(d) \\sum_{n \\leq x:d|n} \\log \\frac{n}{d}", block: true)



#tao-math(" & = \\sum_{d \\leq x} \\mu(d) ( \\frac{n}{d} \\log \\frac{n}{d} - \\frac{n}{d} + O(\\log \\frac{n}{d}) )", block: true)
]

#text("From Dirichlet series methods, it is not difficult to establish the identities")

#align(center)[#tao-fit-display[#mitex("\\lim_{s\\rightarrow 1^+} \\sum_{n=1}^\\infty \\frac{\\mu(n)}{n^s} = 0")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\lim_{s \\rightarrow 1^+} \\sum_{n=1}^\\infty \\frac{\\mu(n) \\log n}{n^s} = -1.")]]

#text("This suggests (but does not quite prove) that one has ")#metadata(none) <tao-36d2c3997d6b67084312>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_{n=1}^\\infty \\frac{\\mu(n)}{n} = 0")]]

#text(" and ")#metadata(none) <tao-91bb24de87ab29f69dda>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{n=1}^\\infty \\frac{\\mu(n)\\log n}{n} = -1")]]

#text(" in the sense of conditionally convergent series. Assuming one can justify this (which, ultimately, requires one to exclude zeroes of the Riemann zeta function on the line ")#mi("{\\text{Re}(s)=1}")#text(", as discussed in ")#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/")[#text("this previous post")]#text("), one is eventually left with the estimate ")#mi("{x + O(x)}")#text(", which is useless as a lower bound (and recovers only the classical Chebyshev estimate ")#mi("{\\sum_{n \\leq x} \\Lambda(n) \\ll x}")#text(" as the upper bound). The inefficiency here when compared to the situation with the divisor function ")#mi("{\\tau}")#text(" can be attributed to the signed nature of the Möbius function ")#mi("{\\mu(n)}")#text(", which causes some cancellation in the divisor sum expansion that needs to be compensated for with improved estimates.")

#text("However, there are a number of tricks available to reduce the level of divisor sums. The simplest comes from exploiting the change of variables ")#mi("{d \\mapsto \\frac{n}{d}}")#text(", which can in principle reduce the level by a square root. For instance, when computing the divisor function ")#mi("{\\tau(n) = \\sum_{d|n} 1}")#text(", one can observe using this change of variables that every divisor of ")#mi("{n}")#text(" above ")#mi("{\\sqrt{n}}")#text(" is paired with one below ")#mi("{\\sqrt{n}}")#text(", and so we have ")#metadata(none) <tao-836cfc25e6713bbb7916>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\tau(n) = 2 \\sum_{d \\leq \\sqrt{n}: d|n} 1")]]

#text(" except when ")#mi("{n}")#text(" is a perfect square, in which case one must subtract one from the right-hand side. Using this reduced-level divisor sum representation, one can obtain an improvement to ")#link(<tao-aac6d0091fc3f8dfd3bc>)[#text("(2)")]#text(", namely")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\tau(n) = x \\log x + (2\\gamma-1) x + O(\\sqrt{x}).")]]

#text("This type of argument is also known as the ")#link("http://planetmath.org/dirichlethyperbolamethod")[#text("Dirichlet hyperbola method")]#text(". A variant of this argument can also deduce the prime number theorem from ")#link(<tao-36d2c3997d6b67084312>)[#text("(3)")]#text(", ")#link(<tao-91bb24de87ab29f69dda>)[#text("(4)")]#text(" (and with some additional effort, one can even drop the use of ")#link(<tao-91bb24de87ab29f69dda>)[#text("(4)")]#text("); this is discussed at ")#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/")[#text("this previous blog post")]#text(".")

#text("Using this square root trick, one can now also control divisor sums such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\tau(n^2+1).")]]

#text("(Note that ")#mi("{\\tau(n^2+1)}")#text(" has no multiplicativity properties in ")#mi("{n}")#text(", and so multiplicative number theory techniques cannot be directly applied here.) The level of the divisor sum here is initially of order ")#mi("{x^2}")#text(", which is too large to be useful; but using the square root trick, we can expand this expression as")

#align(center)[#tao-fit-display[#mitex("2 \\sum_{n \\leq x} \\sum_{d \\leq n: d | n^2+1} 1")]]

#text("which one can rewrite as")

#align(center)[#tao-fit-display[#mitex("2 \\sum_{d \\leq x} \\sum_{d \\leq n \\leq x: n^2+1 = 0 \\text{ mod } d} 1.")]]

#text("The constraint ")#mi("{n^2+1=0 \\text{ mod } d}")#text(" is periodic in ")#mi("{n}")#text(" with period ")#mi("{d}")#text(", so we can write this as")

#align(center)[#tao-fit-display[#mitex("2 \\sum_{d \\leq x} ( \\frac{x}{d} \\rho(d) + O(\\rho(d)) )")]]

#text("where ")#mi("{\\rho(d)}")#text(" is the number of solutions in ")#mi("{{\\bf Z}/d{\\bf Z}}")#text(" to the equation ")#mi("{n^2+1 = 0 \\text{ mod } d}")#text(", and so")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\tau(n^2+1) = 2x \\sum_{d \\leq x} \\frac{\\rho(d)}{d} + O(\\sum_{d \\leq x} \\rho(d)).")]]

#text("The function ")#mi("{\\rho}")#text(" is multiplicative, and can be easily computed at primes ")#mi("{p}")#text(" and prime powers ")#mi("{p^j}")#text(" using tools such as ")#link("http://en.wikipedia.org/wiki/Quadratic_reciprocity")[#text("quadratic reciprocity")]#text(" and ")#link("http://en.wikipedia.org/wiki/Hensel%27s_lemma")[#text("Hensel’s lemma")]#text(". For instance, by ")#link("http://en.wikipedia.org/wiki/Fermat%27s_theorem_on_sums_of_two_squares")[#text("Fermat’s two-square theorem")]#text(", ")#mi("{\\rho(p)}")#text(" is equal to ")#mi("{2}")#text(" for ")#mi("{p=1 \\text{ mod } 4}")#text(" and ")#mi("{0}")#text(" for ")#mi("{p=3 \\text{ mod } 4}")#text(". From this and standard multiplicative number theory methods (e.g. by obtaining asymptotics on the Dirichlet series ")#mi("{\\sum_d \\frac{\\rho(d)}{d^s}}")#text("), one eventually obtains the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq x} \\frac{\\rho(d)}{d} = \\frac{3}{2\\pi} \\log x + O(1)")]]

#text("and also")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq x} \\rho(d) = O(x)")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\tau(n^2+1) = \\frac{3}{\\pi} x \\log x + O(x).")]]

#text("Similar arguments give asymptotics for ")#mi("{\\tau}")#text(" on other quadratic polynomials; see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=153648")[#text("this paper of Hooley")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1317484")[#text("these")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=1635774")[#text("papers")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=1681650")[#text("by McKee")]#text(". Note that the irreducibility of the polynomial will be important. If one considers instead a sum involving a reducible polynomial, such as ")#mi("{\\sum_{n \\leq x} \\tau(n^2-1)}")#text(", then the analogous quantity ")#mi("{\\rho(n)}")#text(" becomes significantly larger, leading to a larger growth rate (of order ")#mi("{x \\log^2 x}")#text(" rather than ")#mi("{x\\log x}")#text(") for the sum.")

#text("However, the square root trick is insufficient by itself to deal with higher order sums involving the divisor function, such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\tau(n^3+1);")]]

#text("the level here is initially of order ")#mi("{x^3}")#text(", and the square root trick only lowers this to about ")#mi("{x^{3/2}}")#text(", creating an error term that overwhelms the main term. And indeed, the asymptotic for such this sum has not yet been rigorously established (although if one heuristically drops error terms, one can arrive at a reasonable conjecture for this asymptotic), although some results are known if one averages over additional parameters (see e.g. this ")#link("http://www.ams.org/mathscinet-getitem?mr=263761")[#text("paper of Greaves")]#text(", or ")#link("http://arxiv.org/abs/1011.0019")[#text("this paper of Matthiesen")]#text(").")

#text("Nevertheless, there is an ingenious ")#link("http://www.ams.org/mathscinet-getitem?mr=44565")[#text("argument of Erdös")]#text(" that allows one to obtain good ")#emph[#text("upper")]#text(" and ")#emph[#text("lower")]#text(" bounds for these sorts of sums, in particular establishing the asymptotic ")#metadata(none) <tao-f4d566ecf2bebdfed615>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("x \\log x \\ll \\sum_{n \\leq x} \\tau(P(n)) \\ll x \\log x")]]

#text(" for any ")#emph[#text("fixed")]#text(" irreducible non-constant polynomial ")#mi("{P}")#text(" that maps ")#mi("{{\\bf N}}")#text(" to ")#mi("{{\\bf N}}")#text(" (with the implied constants depending of course on the choice of ")#mi("{P}")#text("). There is also the related moment bound ")#metadata(none) <tao-828f6474714ae855627b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\sum_{n \\leq x} \\tau^m(P(n)) \\ll x \\log^{O(1)} x")]]

#text(" for any fixed ")#mi("{P}")#text(" (not necessarily irreducible) and any fixed ")#mi("{m \\geq 1}")#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=249")[#text("due to van der Corput")]#text("; this bound is in fact used to dispose of some error terms in the proof of ")#link(<tao-f4d566ecf2bebdfed615>)[#text("(6)")]#text(". These should be compared with what one can obtain from the ")#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/")[#text("divisor bound")]#text(" ")#mi("{\\tau(n) \\ll n^{O(1/\\log \\log n)}}")#text(" and the trivial bound ")#mi("{\\tau(n) \\geq 1}")#text(", giving the bounds")

#align(center)[#tao-fit-display[#mitex("x \\ll \\sum_{n \\leq x} \\tau^m(P(n)) \\ll x^{1 + O(\\frac{1}{\\log \\log x})}")]]

#text("for any fixed ")#mi("{m \\geq 1}")#text(".")

#text("The lower bound in ")#link(<tao-f4d566ecf2bebdfed615>)[#text("(6)")]#text(" is easy, since one can simply lower the level in ")#link(<tao-836cfc25e6713bbb7916>)[#text("(5)")]#text(" to obtain the lower bound")

#align(center)[#tao-fit-display[#mitex("\\tau(n) \\geq \\sum_{d \\leq n^\\theta: d|n} 1")]]

#text("for any ")#mi("{\\theta>0}")#text(", and the preceding methods then easily allow one to obtain the lower bound by taking ")#mi("{\\theta}")#text(" small enough (more precisely, if ")#mi("{P}")#text(" has degree ")#mi("{d}")#text(", one should take ")#mi("{\\theta}")#text(" equal to ")#mi("{1/d}")#text(" or less). The upper bounds in ")#link(<tao-f4d566ecf2bebdfed615>)[#text("(6)")]#text(" and ")#link(<tao-828f6474714ae855627b>)[#text("(7)")]#text(" are more difficult. Ideally, if we could obtain upper bounds of the form ")#metadata(none) <tao-d41037502fcd64dedb92>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\tau(n) \\ll \\sum_{d \\leq n^\\theta: d|n} 1")]]

#text(" for any fixed ")#mi("{\\theta > 0}")#text(", then the preceding methods would easily establish both results. Unfortunately, this bound can fail, as illustrated by the following example. Suppose that ")#mi("{n}")#text(" is the product of ")#mi("{k}")#text(" distinct primes ")#mi("{p_1 \\ldots p_k}")#text(", each of which is close to ")#mi("{n^{1/k}}")#text(". Then ")#mi("{n}")#text(" has ")#mi("{2^k}")#text(" divisors, with ")#mi("{\\binom{n}{j}}")#text(" of them close to ")#mi("{n^{j/k}}")#text(" for each ")#mi("{0 \\ldots j \\leq k}")#text(". One can think of (the logarithms of) these divisors as being distributed according to what is essentially a ")#link("http://en.wikipedia.org/wiki/Bernoulli_distribution")[#text("Bernoulli distribution")]#text(", thus a randomly selected divisor of ")#mi("{n}")#text(" has magnitude about ")#mi("{n^{j/k}}")#text(", where ")#mi("{j}")#text(" is a random variable which has the same distribution as the number of heads in ")#mi("{k}")#text(" independently tossed fair coins. By the law of large numbers, ")#mi("{j}")#text(" should concentrate near ")#mi("{k/2}")#text(" when ")#mi("{k}")#text(" is large, which implies that the majority of the divisors of ")#mi("{n}")#text(" will be close to ")#mi("{n^{1/2}}")#text(". Sending ")#mi("{k \\rightarrow \\infty}")#text(", one can show that the bound ")#link(<tao-d41037502fcd64dedb92>)[#text("(8)")]#text(" fails whenever ")#mi("{\\theta < 1/2}")#text(".")

#text("This however can be fixed in a number of ways. First of all, even when ")#mi("{\\theta<1/2}")#text(", one can show weaker substitutes for ")#link(<tao-d41037502fcd64dedb92>)[#text("(8)")]#text(". For instance, for any fixed ")#mi("{\\theta > 0}")#text(" and ")#mi("{m \\geq 1}")#text(" one can show a bound of the form ")#metadata(none) <tao-c81d24a89ac9b8312b8e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\tau(n)^m \\ll \\sum_{d \\leq n^\\theta: d|n} \\tau(d)^C")]]

#text(" for some ")#mi("{C}")#text(" depending only on ")#mi("{m,\\theta}")#text(". This nice elementary inequality (first observed ")#link("http://www.ams.org/mathscinet-getitem?mr=998633")[#text("by Landreau")]#text(") already gives a quite short proof of van der Corput’s bound ")#link(<tao-828f6474714ae855627b>)[#text("(7)")]#text(".")

#text("For Erdös’s upper bound ")#link(<tao-f4d566ecf2bebdfed615>)[#text("(6)")]#text(", though, one cannot afford to lose these additional factors of ")#mi("{\\tau(d)}")#text(", and one must argue more carefully. Here, the key observation is that the counterexample discussed earlier – when the natural number ")#mi("{n}")#text(" is the product of a large number of fairly small primes – is quite atypical; most numbers have at least one large prime factor. For instance, the number of natural numbers less than ")#mi("{x}")#text(" that contain a prime factor between ")#mi("{x^{1/2}}")#text(" and ")#mi("{x}")#text(" is equal to")

#align(center)[#tao-fit-display[#mitex("\\sum_{x^{1/2} \\leq p \\leq x} (\\frac{x}{p} + O(1)),")]]

#text("which, thanks to ")#link("http://en.wikipedia.org/wiki/Mertens'_theorems")[#text("Mertens’ theorem")]

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x} \\frac{1}{p} = \\log\\log x + M+o(1)")]]

#text("for some absolute constant ")#mi("{M}")#text(", is comparable to ")#mi("{x}")#text(". In a similar spirit, one can show by similarly elementary means that the number of natural numbers ")#mi("{m}")#text(" less than ")#mi("{x}")#text(" that are ")#emph[#mi("{x^{1/m}}")#text("-smooth")]#text(", in the sense that all prime factors are at most ")#mi("{x^{1/m}}")#text(", is only about ")#mi("{m^{-cm} x}")#text(" or so. Because of this, one can hope that the bound ")#link(<tao-d41037502fcd64dedb92>)[#text("(8)")]#text(", while not true in full generality, will still be true for ")#emph[#text("most")]#text(" natural numbers ")#mi("{n}")#text(", with some slightly weaker substitute available (such as ")#link(<tao-828f6474714ae855627b>)[#text("(7)")]#text(") for the exceptional numbers ")#mi("{n}")#text(". This turns out to be the case by an elementary but careful argument.")

#text("The Erdös argument is quite robust; for instance, the more general inequality")

#align(center)[#tao-fit-display[#mitex("x \\log^{2^m-1} x \\ll \\sum_{n \\leq x} \\tau(P(n))^m \\ll x \\log^{2^m-1} x")]]

#text("for fixed irreducible ")#mi("{P}")#text(" and ")#mi("{m \\geq 1}")#text(", which improves van der Corput’s inequality ")#link(<tao-d41037502fcd64dedb92>)[#text("(8)")]#text(" was shown ")#link("http://www.ams.org/mathscinet-getitem?mr=289433")[#text("by Delmer")]#text(" using the same methods. (A slight error in the original paper of Erdös was also corrected in this latter paper.) In a forthcoming revision to ")#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/")[#text("my paper on the Erdös-Straus conjecture")]#text(", Christian Elsholtz and I have also applied this method to obtain bounds such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{a \\leq A} \\sum_{b \\leq B} \\tau(a^2 b + 1) \\ll AB \\log(A+B),")]]

#text("which turn out to be enough to obtain the right asymptotics for the number of solutions to the equation ")#mi("{\\frac{4}{p}= \\frac{1}{x}+\\frac{1}{y}+\\frac{1}{z}}")#text(".")

#text("Below the fold I will provide some more details of the arguments of Landreau and of Erdös.")

#metadata(none) <tao-7fb4c8dc42772b801940>

#heading(level: 1)[#strong[#text(" — 1. Landreau’s argument — ")]]

#text("We now prove ")#link(<tao-c81d24a89ac9b8312b8e>)[#text("(9)")]#text(", and use this to show ")#link(<tao-828f6474714ae855627b>)[#text("(7)")]#text(".")

#text("Suppose first that all prime factors of ")#mi("{n}")#text(" have magnitude at most ")#mi("{n^{c/2}}")#text(". Then by a greedy algorithm, we can factorise ")#mi("{n}")#text(" as the product ")#mi("{n = n_1 \\ldots n_r}")#text(" of numbers between ")#mi("{n^{c/2}}")#text(" and ")#mi("{n^c}")#text(". In particular, the number ")#mi("{r}")#text(" of terms in this factorisation is at most ")#mi("{2/c}")#text(". By the trivial inequality ")#mi("{\\tau(ab) \\leq \\tau(a) \\tau(b)}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\tau(n) \\leq \\tau(n_1) \\ldots \\tau(n_r)")]]

#text("and thus by the pigeonhole principle one has")

#align(center)[#tao-fit-display[#mitex("\\tau(n)^m \\leq \\tau(n_j)^{2m/c}")]]

#text("for some ")#mi("{j}")#text(". Since ")#mi("{n_j}")#text(" is a factor of ")#mi("{n}")#text(" that is at most ")#mi("{n^c}")#text(", the claim follows in this case (taking ")#mi("{C := 2m/c}")#text(").")

#text("Now we consider the general case, in which ")#mi("{n}")#text(" may contain prime factors that exceed ")#mi("{n^c}")#text(". There are at most ")#mi("{1/c}")#text(" such factors (counting multiplicity). Extracting these factors out first and then running the greedy algorithm again, we may factorise ")#mi("{n = n_1 \\ldots n_r q}")#text(" where the ")#mi("{n_i}")#text(" are as before, and ")#mi("{q}")#text(" is the product of at most ")#mi("{1/c}")#text(" primes. In particular, ")#mi("{\\tau(q) \\leq 2^{1/c}}")#text(" and thus")

#align(center)[#tao-fit-display[#mitex("\\tau(n) \\leq 2^{1/c} \\tau(n_1) \\ldots \\tau(n_r).")]]

#text("One now argues as before (conceding a factor of ")#mi("{2^{1/c}}")#text(", which is acceptable) to obtain ")#link(<tao-c81d24a89ac9b8312b8e>)[#text("(9)")]#text(" in full generality. (Note that this illustrates a useful principle, which is that large prime factors of ")#mi("{n}")#text(" are essentially harmless for the purposes of upper bounding ")#mi("{\\tau(n)}")#text(".)")

#text("Now we prove ")#link(<tao-828f6474714ae855627b>)[#text("(7)")]#text(". From ")#link(<tao-c81d24a89ac9b8312b8e>)[#text("(9)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\tau(P(n))^m \\ll \\sum_{d \\leq x: d|P(n)} \\tau(d)^{O(1)}")]]

#text("for any ")#mi("{n \\leq x}")#text(", and hence we can bound ")#mi("{\\sum_{n \\leq x} \\tau(P(n))^m}")#text(" by")

#align(center)[#tao-fit-display[#mitex("\\ll \\sum_{d \\leq x} \\tau(d)^{O(1)} \\sum_{n \\leq x: d|n; P(n) = 0 \\text{ mod } d} 1.")]]

#text("The inner sum is ")#mi("{\\frac{x}{d} \\rho(d) + O(\\rho(d)) = O( \\frac{x}{d} \\rho(d) )}")#text(", where ")#mi("{\\rho(d)}")#text(" is the number of roots of ")#mi("{P \\text{ mod } d}")#text(". Now, for fixed ")#mi("{P}")#text(", it is easy to see that ")#mi("{\\rho(p) = O(1)}")#text(" for all primes ")#mi("{p}")#text(", and from Hensel’s lemma one soon extends this to ")#mi("{\\rho(p^j)=O(1)}")#text(" for all prime powers ")#mi("{p}")#text(". (This is easy when ")#mi("{p}")#text(" does not divide the ")#link("http://en.wikipedia.org/wiki/Discriminant")[#text("discriminant")]#text(" ")#mi("{\\Delta(P)}")#text(" of ")#mi("{p}")#text(", as the zeroes of ")#mi("{P \\text{ mod } p}")#text(" are then simple. There are only finitely many primes that do divide the discriminant, and they can each be handled separately by Hensel’s lemma and an induction on the degree of ")#mi("{P}")#text(".) Meanwhile, from the Chinese remainder theorem, ")#mi("{\\rho}")#text(" is multiplicative. From this we obtain the crude bound ")#mi("{\\rho(d) \\ll \\tau(d)^{O(1)}}")#text(", and so we obtain a bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\tau(P(n))^m \\ll x \\sum_{d \\leq x} \\frac{\\tau(d)^{O(1)}}{d}.")]]

#text("This sum can easily be bounded by ")#mi("{x \\log^{O(1)}x}")#text(" by multiplicative number theory techniques, e.g. by first computing the Dirichlet series")

#align(center)[#tao-fit-display[#mitex("\\sum_{d=1}^\\infty \\frac{\\tau(d)^{O(1)}}{d^{1+\\frac{1}{\\log x}}}")]]

#text("via the Euler product. This proves ")#link(<tao-828f6474714ae855627b>)[#text("(7)")]#text(".")

#heading(level: 1)[#strong[#text(" — 2. Erdös’ argument — ")]]

#text("Now we prove ")#link(<tao-f4d566ecf2bebdfed615>)[#text("(6)")]#text(". We focus on the upper bound, as the proof of the lower bound has already been sketched.")

#text("We first make a convenient observation: from ")#link(<tao-828f6474714ae855627b>)[#text("(7)")]#text(" (with ")#mi("{m=2}")#text(") and the Cauchy-Schwarz inequality, we see that we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in E} \\tau(P(n)) \\ll x \\log x")]]

#text("whenever ")#mi("{E}")#text(" is a subset of the natural numbers less than ")#mi("{x}")#text(" of cardinality ")#mi("{O( x \\log^{-C} x )}")#text(" for some sufficiently large ")#mi("{C}")#text(". Thus we have the freedom to restrict attention to “generic” ")#mi("{n}")#text(", where by “generic” we mean “lying outside of an exceptional set of cardinality ")#mi("{O(x \\log^{-C} x)}")#text(" for the ")#mi("{C}")#text(" specified above”.")

#text("Let us now look at the behaviour of ")#mi("{P(n)}")#text(" for generic ")#mi("{n}")#text(". We first control the total number of prime factors:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1")]#text(" ")#metadata(none) <tao-e81935fb86434cdaaeee>#text(" For generic ")#mi("{n \\leq x}")#text(", ")#mi("{P(n)}")#text(" has ")#mi("{O( \\log \\log x )}")#text(" distinct prime factors.")
]

#text("This result is consistent with the ")#link("http://en.wikipedia.org/wiki/Hardy%E2%80%93Ramanujan_theorem")[#text("Hardy-Ramanujan")]#text(" and ")#link("http://en.wikipedia.org/wiki/Erd%C5%91s%E2%80%93Kac_theorem")[#text("Erdös-Kac")]#text(" theorems, though it does not quite follow from these results (because ")#mi("{P(n)}")#text(" lives in quite a sparse set of natural numbers).")

#emph[#text("Proof:")]#text(" If ")#mi("{P(n)}")#text(" has more than ")#mi("{A \\log_2 \\log x}")#text(" prime factors for some ")#mi("{A}")#text(", then ")#mi("{P(n)}")#text(" has at least ")#mi("{\\log^A x}")#text(" divisors, thus ")#mi("{\\tau(P(n)) \\geq \\log^A X}")#text(". The claim then follows from ")#link(<tao-828f6474714ae855627b>)[#text("(7)")]#text(" (with ")#mi("{m=1}")#text(") and Markov’s inequality, taking ")#mi("{A}")#text(" large enough. ")#mi("\\Box")

#text("Next, we try to prevent repeated prime factors:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" ")#metadata(none) <tao-73ef176d9f12809e6436>#text(" For generic ")#mi("{n \\leq x}")#text(", the prime factors of ")#mi("{P(n)}")#text(" between ")#mi("{\\log^{C} x}")#text(" and ")#mi("{x^{1/2}}")#text(" are all distinct.")
]

#emph[#text("Proof:")]#text(" If ")#mi("{p}")#text(" is a prime between ")#mi("{\\log^{C} x}")#text(" and ")#mi("{x^{1/2}}")#text(", then the total number of ")#mi("{n \\leq x}")#text(" for which ")#mi("{p^2}")#text(" divides ")#mi("{P(n)}")#text(" is")

#align(center)[#tao-fit-display[#mitex("\\rho(p^2) \\frac{x}{p^2} + O( \\rho(p^2) ) = O( \\frac{x}{p^2} ),")]]

#text("so the total number of ")#mi("{x}")#text(" that fail the above property is")

#align(center)[#tao-fit-display[#mitex("\\ll \\sum_{\\log^C x \\leq p \\leq x^{1/2}} \\frac{x}{p^2} \\ll \\frac{x}{\\log^C x}")]]

#text("which is acceptable. ")#mi("\\Box")

#text("It is difficult to increase the upper bound here beyond ")#mi("{x^{1/2}}")#text(", but fortunately we will not need to go above this bound. The lower bound cannot be significantly reduced; for instance, it is quite likely that ")#mi("{P(n)}")#text(" will be divisible by ")#mi("{2^2}")#text(" for a positive fraction of ")#mi("{n}")#text(". But we have the following substitute:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" ")#metadata(none) <tao-545ea538461003efdc8c>#text(" For generic ")#mi("{n \\leq x}")#text(", there are no prime powers ")#mi("{p^j}")#text(" dividing ")#mi("{P(n)}")#text(" with ")#mi("{p < x^{1/(\\log \\log x)^2}}")#text(" and ")#mi("{p^j \\geq x^{1/(\\log \\log x)^2}}")#text(".")
]

#emph[#text("Proof:")]#text(" By the preceding lemma, we can restrict attention to primes ")#mi("{p}")#text(" with ")#mi("{p < \\log^C x}")#text(". For each such ")#mi("{p}")#text(", let ")#mi("{p^j}")#text(" be the first power of ")#mi("{p}")#text(" exceeding ")#mi("{x^{1/(\\log \\log x)^2}}")#text(". Arguing as before, the total number of ")#mi("{n \\leq x}")#text(" for which ")#mi("{p^j}")#text(" divides ")#mi("{P(n)}")#text(" is")

#align(center)[#tao-fit-display[#mitex("\\ll \\frac{x}{p^j} \\ll \\frac{x}{x^{1/(\\log\\log x)^2}};")]]

#text("on the other hand, there are at most ")#mi("{\\log^C x}")#text(" primes ")#mi("{p}")#text(" to consider. The claim then follows from the union bound. ")#mi("\\Box")

#text("We now have enough information on the prime factorisation of ")#mi("{P(n)}")#text(" to proceed. We arrange the prime factors of ")#mi("{P(n)}")#text(" in increasing order (allowing repetitions):")

#align(center)[#tao-fit-display[#mitex("P(n) = p_1 \\ldots p_J.")]]

#text("Let ")#mi("{0 \\leq j \\leq J}")#text(" be the largest integer for which ")#mi("{p_1 \\ldots p_j \\leq x}")#text(". Suppose first that ")#mi("{J=j+O(1)}")#text(", then as in the previous section we would have")

#align(center)[#tao-fit-display[#mitex("\\tau(P(n)) \\ll \\tau(p_1 \\ldots p_j) \\leq \\sum_{d \\leq x: d | P(n)} 1")]]

#text("which is an estimate of the form ")#link(<tao-d41037502fcd64dedb92>)[#text("(8)")]#text(", and thus presumably advantageous.")

#text("Now suppose that ")#mi("{J}")#text(" is much larger than ")#mi("{j}")#text(". Since ")#mi("{P(n) = O(x^{O(1)})}")#text(", this implies in particular that ")#mi("{p_{j+1} \\leq x^{1/2}}")#text(" (say), which forces ")#metadata(none) <tao-47c4d6406db7b34454aa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("x^{1/2} \\leq p_1 \\ldots p_j \\leq x")]]

#text(" and ")#mi("{p_j \\leq x^{1/2}}")#text(".")

#text("For generic ")#mi("{n}")#text(", we have at most ")#mi("{O(\\log \\log x)}")#text(" distinct prime factors, and each such distinct prime less than ")#mi("{x^{1/(\\log \\log x)^2}}")#text(" contributes at most ")#mi("{x^{1/(\\log \\log x)^2}}")#text(" to the product ")#mi("{p_1 \\ldots p_j}")#text(". We conclude that generically, at least one of these primes ")#mi("{p_1,\\ldots,p_j}")#text(" must exceed ")#mi("{x^{1/(\\log \\log x)^2}}")#text(", thus we generically have")

#align(center)[#tao-fit-display[#mitex("x^{1/(\\log \\log x)^2} \\leq p_j \\leq x^{1/2}.")]]

#text("In particular, we have")

#align(center)[#tao-fit-display[#mitex("x^{1/(r+1)} \\leq p_j \\leq x^{1/r}")]]

#text("for some ")#mi("{2 \\leq r \\leq (\\log \\log x)^2}")#text(". This makes the quantity ")#mi("{p_1 \\ldots p_j}")#text(" ")#link("http://en.wikipedia.org/wiki/Smooth_number")[#mi("{x^{1/r}}")#text("-smooth")]#text(", i.e. all the prime factors are at most ")#mi("{x^{1/r}}")#text(". On the other hand, the remaining prime factors ")#mi("{p_{j+1}, \\ldots, p_J}")#text(" are at least ")#mi("{x^{1/(r+1)}}")#text(", and ")#mi("{P(n) = O(x^{O(1)})}")#text(", so we have ")#mi("{J = j + O(r)}")#text(". Thus we can write ")#mi("{P(n)}")#text(" as the product of ")#mi("{p_1 \\ldots p_j}")#text(" and at most ")#mi("{O(r)}")#text(" additional primes, which implies that")

#tao-aligned(keep: true)[


#tao-math("\\tau(P(n))  & \\ll \\exp(O(r)) \\tau(p_1 \\ldots p_j)", block: true)



#tao-math(" & = \\exp(O(r)) \\sum_{d: d | p_1 \\ldots p_j} 1.", block: true)
]

#text("The exponential factor looks bad, but we can offset it by the ")#mi("{x^{1/r}}")#text("-smooth nature of ")#mi("{p_1 \\ldots p_j}")#text(", which is inherited by its factors ")#mi("{d}")#text(". From ")#link(<tao-47c4d6406db7b34454aa>)[#text("(10)")]#text(", ")#mi("{d}")#text(" is at most ")#mi("{x}")#text("; by using the square root trick, we can restrict ")#mi("{d}")#text(" to be ")#emph[#text("at least")]#text(" the square root of ")#mi("{p_1 \\ldots p_j}")#text(", and thus to be at least ")#mi("{x^{1/4}}")#text(". Also, ")#mi("{d}")#text(" divides ")#mi("{P(n)}")#text(", and as such inherits many of the prime factorisation properties of ")#mi("{P(n)}")#text("; in particular, ")#mi("{O(\\log\\log x)}")#text(" distinct prime factors, and ")#mi("{d}")#text(" has no prime powers ")#mi("{p^j}")#text(" dividing ")#mi("{d}")#text(" with ")#mi("{p < x^{1/(\\log \\log x)^2}}")#text(" and ")#mi("{p^j \\geq x^{1/(\\log \\log x)^2}}")#text(".")

#text("To summarise, we have shown the following variant of ")#link(<tao-d41037502fcd64dedb92>)[#text("(8)")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (Lowering the level)")]#text(" For generic ")#mi("{n \\leq x}")#text(", we")

#align(center)[#tao-fit-display[#mitex("\\tau(P(n)) \\ll \\exp(O(r)) \\sum_{d \\in S_r: d | P(n)} 1")]]

#text("for some ")#mi("{1 \\leq r \\leq (\\log \\log x)^2}")#text(", where ")#mi("{S_r}")#text(" is the set of all ")#mi("{x^{1/r}}")#text("-smooth numbers ")#mi("{d}")#text(" between ")#mi("{x^{1/4}}")#text(" and ")#mi("{x}")#text(" with ")#mi("{O(\\log\\log x)}")#text(" distinct prime factors, and such that there are no prime powers ")#mi("{p^j}")#text(" dividing ")#mi("{d}")#text(" with ")#mi("{p < x^{1/(\\log \\log x)^2}}")#text(" and ")#mi("{p^j \\geq x^{1/(\\log \\log x)^2}}")#text(".")
]

#text("Applying this lemma (and discarding the non-generic ")#mi("{n}")#text("), we can thus upper bound ")#mi("{\\sum_{n \\leq x} \\tau(P(n))}")#text(" (up to acceptable errors) by")

#align(center)[#tao-fit-display[#mitex("\\ll \\sum_{1 \\leq r \\leq (\\log \\log x)^2} \\exp(O(r)) \\sum_{n \\leq x} \\sum_{d \\in S_r: d | P(n)} 1.")]]

#text("The level is now less than ")#mi("{x}")#text(" and we can use the usual methods to estimate the inner sums:")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\sum_{d \\in S_r: d | P(n)} 1 \\ll x \\sum_{d \\in S_r} \\frac{\\rho(d)}{d}.")]]

#text("Thus it suffices to show that ")#metadata(none) <tao-34a04005bcaf206eec99>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\sum_{1 \\leq r \\leq (\\log \\log x)^2} \\exp(O(r)) \\sum_{d \\in S_r} \\frac{\\rho(d)}{d} \\ll \\log x.")]]



#text("It is at this point that we need some algebraic number theory, and specifically the ")#link("http://en.wikipedia.org/wiki/Landau_prime_ideal_theorem")[#text("Landau prime ideal theorem")]#text(", via the following lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5")]#text(" We have ")#metadata(none) <tao-4cdcbb0ac2132ff4462f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\sum_{d \\leq x} \\frac{\\rho(d)}{d} \\ll \\log x.")]]


]

#emph[#text("Proof:")]#text(" Let ")#mi("{k}")#text(" be the number field formed by extending the rationals by adjoining a root ")#mi("{\\alpha}")#text(" of the irreducible polynomial ")#mi("{P}")#text(". The Landau prime ideal theorem (the generalisation of the prime number theorem to such fields) then tells us (among other things) that the number of prime ideals in ")#mi("{k}")#text(" of norm less than ")#mi("{x}")#text(" is ")#mi("{x/\\log x + O( x/\\log^2 x)}")#text(". Note that if ")#mi("{p}")#text(" is a prime with a simple root ")#mi("{P(n)=0 \\text{ mod } p}")#text(" in ")#mi("{{\\bf Z}/p{\\bf Z}}")#text(", then one can associate a prime ideal in ")#mi("{k}")#text(" of norm ")#mi("{p}")#text(" defined as ")#mi("{(p,\\alpha-n)}")#text(". As long as ")#mi("{p}")#text(" does not divide the discriminant, one has ")#mi("{\\rho(p)}")#text(" simple roots; but there are only ")#mi("{O(1)}")#text(" primes that divide the discriminant. From this we see that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x} \\rho(p) \\leq \\frac{x}{\\log x} + O( \\frac{x}{\\log^2 x} ).")]]

#text("(One can complement this upper bound with a lower bound, since the ideals whose norms are a power of a (rational) prime rather than a prime have only a negligible contribution to the ideal count, but we will not need the lower bound here). By summation by parts we conclude")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x} \\frac{\\rho(p)}{p} \\leq \\log\\log x + O(1)")]]

#text("and ")#link(<tao-4cdcbb0ac2132ff4462f>)[#text("(12)")]#text(" follows by standard multiplicative number theory methods (e.g. bounding ")#mi("{\\sum_{d \\leq x} \\frac{\\rho(d)}{d^{1+1/\\log x}}}")#text(" by computing the Euler product, noting that ")#mi("{\\rho(p^j) = \\rho(p)}")#text(" whenever ")#mi("{p}")#text(" does not divide the discriminant of ")#mi("{P}")#text(", thanks to Hensel’s lemma). ")#mi("\\Box")

#text("This proposition already deals with the bounded ")#mi("{r}")#text(" case. For large ")#mi("{r}")#text(" we need the following variant:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6")]#text(" For any ")#mi("{2 \\leq r \\leq (\\log \\log x)^2}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\in S_r} \\frac{\\rho(d)}{d} \\ll r^{-cr} \\log x")]]

#text("for some absolute constant ")#mi("{c>0}")#text(".")
]

#text("The bound ")#link(<tao-34a04005bcaf206eec99>)[#text("(11)")]#text(" then follows as a corollary of this proposition. In fact, one expects the ")#mi("{x^{1/r}}")#text("-smoothness in the definition of ")#mi("{S_r}")#text(" to induce a gain of about ")#mi("{\\frac{1}{r!}}")#text("; see ")#link("http://www.ams.org/mathscinet-getitem?mr=2467549")[#text("this survey of Granville")]#text(" for extensive discussion of this and related topics.")

#emph[#text("Proof:")]#text(" If ")#mi("{d \\in S_r}")#text(", then we can write ")#mi("{d = p_1 \\ldots p_j}")#text(" for some primes ")#mi("{p_1,\\ldots,p_j \\leq x^{1/r}}")#text(". As noted previously, the primes in this product that are less than ")#mi("{x^{1/(\\log\\log x)^2}}")#text(" each contribute at most ")#mi("{x^{1/(\\log\\log x)^2}}")#text(" to this product, and there are at most ")#mi("{O(\\log\\log x)}")#text(" of these primes, so their total contribution is at most ")#mi("{x^{O(1/\\log\\log x)}}")#text(". Since ")#mi("{d \\geq x^{1/2}}")#text(", we conclude that the primes that are greater than ")#mi("{x^{1/(\\log\\log x)^2}}")#text(" in the factorisation of ")#mi("{d}")#text(" must multiply to at least ")#mi("{x^{1/4}}")#text(" (say). By definition of ")#mi("{S_r}")#text(", these primes are distinct. By the pigeonhole principle, we can then find ")#mi("{t \\geq 1}")#text(" such that there are distinct primes ")#mi("{q_1,\\ldots,q_m}")#text(" between ")#mi("{x^{1/2^{t+1} r}}")#text(" and ")#mi("{x^{1/2^tr}}")#text(" which appear in the prime factorisation of ")#mi("{d}")#text(", where ")#mi("{m := \\lfloor \\frac{rt}{100}\\rfloor}")#text(" (say); by definition of ")#mi("{S_r}")#text(", all these primes are distinct and can thus be ordered as ")#mi("{q_1 < \\ldots < q_m}")#text(", and we can write ")#mi("{d = q_1 \\ldots q_m u}")#text(" for some ")#mi("{u \\leq x}")#text(". As the ")#mi("{\\rho(q_j)}")#text(" are bounded, we have")

#align(center)[#tao-fit-display[#mitex("\\rho(d) \\ll O(1)^m \\rho(u) \\ll O(1)^{rt} \\rho(u)")]]

#text("and so we can upper bound ")#mi("{\\sum_{d \\in S_r} \\frac{\\rho(d)}{d}}")#text(" by")

#align(center)[#tao-fit-display[#mitex("\\sum_{t \\ll (\\log \\log x)^2} O(1)^{rt} \\sum_{x^{1/2^{t+1} r} \\leq q_1 < \\ldots < q_m \\leq x^{1/2^t r}} \\frac{1}{q_1 \\ldots q_m} \\sum_{u<x} \\rho(u).")]]

#text("Using ")#link(<tao-4cdcbb0ac2132ff4462f>)[#text("(12)")]#text(" and symmetry we can bound this by")

#align(center)[#tao-fit-display[#mitex("\\sum_{t \\ll (\\log \\log x)^2} O(1)^{rt} \\frac{1}{m!} (\\sum_{x^{1/2^{t+1} r} \\leq q \\leq x^{1/2^t r}} \\frac{1}{q})^m \\log x.")]]

#text("By the prime number theorem (or ")#link("http://en.wikipedia.org/wiki/Mertens'_theorems")[#text("Mertens’ theorem")]#text(") we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{x^{1/2^{t+1} r} \\leq q \\leq x^{1/2^t r}} \\frac{1}{q} \\ll 1.")]]

#text("Inserting this bound and summing the series using ")#link("http://en.wikipedia.org/wiki/Stirling%27s_approximation")[#text("Stirling’s formula")]#text(", one obtains the claim. ")#mi("\\Box")

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d651f95a1baea5b307e95510a9008d3306c5e9e9c8d30c453607d8ea17832d30-e057d70cf77d673363d3289dbab6a6d96972787ba8b9dd99c602f59922e743d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lilian Matthiesen")]], [#link("https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound/#comment-59981")[#strong[#text("Lilian Matthiesen")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2011")])]

#text("Many thanks for this exposition! I would like to add that Erdös’s argument may be used to construct a pseudorandom majorant for the divisor function, as I’ve done in this paper (")#link("http://arxiv.org/abs/1011.0019")[#text("http://arxiv.org/abs/1011.0019")]#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/065138e1b1902805d7f744a8b774918e0ccbb72d8c610f9cb5f0d04cde9795e3-c304526fcf69ae299ab157ae31b1f0cc68fc0ab5c24aaa809399deb8b52fce69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mats Granvik")]], [#link("https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound/#comment-60366")[#strong[#text("Mats Granvik")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2011")])]

#text("The terms of the von Mangoldt can be expanded into series which have numerators that form a symmetric matrix:")

#link("http://math.stackexchange.com/questions/48946/do-these-series-converge-to-the-mangoldt-function")[#text("http://math.stackexchange.com/questions/48946/do-these-series-converge-to-the-mangoldt-function")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound/#comment-60833")[#strong[#text("Weekly Picks « Mathblogging.org — the Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2011")]

#text("[…] came in. On the non-English side, Series Divergentes portrayed John E. Littlewood (translation), Gaussianos wrote about the magical appearances of Gauss’s Theorem (translation) and Bloghetto started a new series on Pythagoras […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b5565ee6c59d445ea617333a6bffc7499124215a1fa2eddaa79abfe060ffe5e-d932f0cd5d7186640b5a5c0fe92c7498050fb4e0b12d419bf18016918a0d31a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of poemphychern")]], [#link("https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound/#comment-60976")[#strong[#text("poemphychern")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2011")])]

#text("楼主您好，请问您上面的公式是怎么编辑的？我是刚注册的，需要安装什么插件吗？怎么安装？")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound/#comment-61160")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2011")])]

#text("See")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/about/")[#text("About")]
]

#text("and")

#link("http://faq.wordpress.com/2007/02/18/can-i-put-math-or-equations-in-my-posts/")[#text("http://faq.wordpress.com/2007/02/18/can-i-put-math-or-equations-in-my-posts/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dfefed9d0023dce56a34632d43550a77e761f88545cab5c0bb3b7b1317ea607e-66fceddcc50c8d81a17a952a311bc4ff5c3a2149d63984c0b54d4004cbccf93c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ImNotSure")]], [#link("https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound/#comment-62308")[#strong[#text("ImNotSure")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2011")])]

#text("Hi Terence,")

#text("Nice exposition! I have a question, did you have a typo in formula (1)? it is ")#mi("n/q")#text(" or ")#mi("x/q")#text("?")

#text("And thanks for this post.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dfefed9d0023dce56a34632d43550a77e761f88545cab5c0bb3b7b1317ea607e-66fceddcc50c8d81a17a952a311bc4ff5c3a2149d63984c0b54d4004cbccf93c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ImNotSure")]], [#link("https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound/#comment-62332")[#strong[#text("ImNotSure")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2011")])]

#text("You welcome,")

#text("You have another typos, but I think that the readers can correct it when they read.")

#text("Bye bye.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Counting the number of solutions to the Erdös-Straus equation on unit fractions « What’s new")]], [#link("https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound/#comment-62343")[#strong[#text("Counting the number of solutions to the Erdös-Straus equation on unit fractions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2011")])]

#text("[…] input of the ErdH{o}s divisor bound on expressions of the form for polynomials , discussed in this recent blog post. (Actually, we need to tighten ErdH{o}s’ bound somewhat, to obtain some uniformity in the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound/#comment-90163")[#strong[#text("mathsetc")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2011")]

#text("[…] Erdos’ divisor bound (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound/#comment-100175")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2011")])]

#text("There is an error in the formula following (5). The asymptotic for $\\tau(n)$ derived using the Dirichlet hyperbola method is given by $\\tau(n) = n \\log n + (2\\gamma -1) n + O(\\sqrt(n))$, where $\\gamma$ denotes the Euler-Mascheroni constant. If this wasn’t simply a typo, you may have taken the approximation $H_n = \\log n + O(1)$ and reduced this to $n H_n = n \\log n + O(1)$ (where $H_n$ is the nth harmonic number). One must use, instead, the approximation $H_n = \\log n + \\gamma + O(n^(-1/2))$. This is where the $\\gamma$ becomes significant.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 7: Sieving and expanders « What’s new")]], [#link("https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound/#comment-131027")[#strong[#text("254B, Notes 7: Sieving and expanders « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2012")])]

#text("[…] power of here (as in Exercise 4), by using tools such as Landau’s prime ideal theorem; see this previous blog post for some related discussion. Remark 2 The combinatorial sieve is not the only type of sieve used […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bbac32f4d797c7cefcad9e47bdc87299f127572c530c4401f8ecee2e92bbe362-123da8c5136fbe13dbdb4c1814776caf56028e875deeff843136f9dc10859259.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Klazar")]], [#link("https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound/#comment-147964")[#strong[#text("Martin Klazar")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2012")])]

#text("I think there is a small gap/error in the derivation of the asymptotics for")#linebreak()#text(" sum_{n<x}tau(n^2+1). In the displayed formula after \"The constraint {n^2+1=0 \\hbox{ mod } d} is periodic in {n} with period {d}, so we can write this as…\" there instead of the term O(1) it should be correctly, I think, O(rho(d)). This is what one gets by splitting the range d<n<x for n into intervals with length d and a residual interval with length less than d.")#linebreak()#text(" (Even without the residual interval one still get this error term due to omitting the floors in [x/d].)")#linebreak()#text(" So instead of the trivial sum_{n<x}O(1)=O(x) one gets the sum sum_{n<x}rho(d) and is not done so easily. But one can show with some effort that the last sum is indeed O(x). It is not quite straightforward (for me) because rho(d) is unbounded and may be as large as 2^{omega(d)}.")

#emph[#text("[Edited, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A combinatorial subset sum problem associated with bounded prime gaps | What's new")]], [#link("https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound/#comment-233902")[#strong[#text("A combinatorial subset sum problem associated with bounded prime gaps | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("[…] from this paper of Shiu or this paper of Barban-Vehov, and can also be proven using the methods in this previous blog post. (The factor of is needed to account for the possibility that is not primitive, while the term […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6a7e33f46a7c25d521e374ad06d2196b46fc99992c6fffc48c49ac6660d4f3d1-68747cb559f25a252c5544da35220db4d5f5cbd68eb821c147c09fb02c4b3390.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MFH")]], [#link("https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound/#comment-456949")[#strong[#text("MFH")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2015")])]

#text("Hello Terry, the link to Dirichlet Hyperbola Method on planetmath.org does not work any more. I think it should be fixed to ")#link("http://planetmath.org/dirichlethyperbolamethod")[#text("http://planetmath.org/dirichlethyperbolamethod")]#linebreak()#text(" Best wishes,")#linebreak()#text(" Maximilian")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound/#comment-643479")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2022")])]

#text("For (1), the summary that follows. The main term should be ")#mi("x/q")#text(" not ")#mi("n/q")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d37a78db57722ca847c0890d993d604a290dfe9ae7f4f145cf0c52abcd98465-612c0aad0415c35ba32f9ec1ea65f8df3f28d31ff167a2e3f158241d22cdbb12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jess Mcallister")]], [#link("https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound/#comment-671739")[#strong[#text("Jess Mcallister")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2023")])]

#text("Hey Terrance,")#linebreak()#text(" Thanks for all your great work in the mathematical world. My name is Jessie, and I have just finished a mathematical conjecture of the Distribution of Divisor Pairs. As this conjecture also defines the distribution properties of the prime pairs, I am not sure the path to take, as for its implications when dealing with RSA encryption.")

#text("Within the formulas provided within the conjecture, the “randomness” of the distribribution of divisor pairs is completely explained not to be random, and the pattern within the divisor function can be explained as well.")

#text("The entire formula is in algebraic form, and the placement of prime numbers becomes apparent.")

#text("I am really interested in publishing my conjecture, but am not sure the right path in doing so.")

#text("As I am an untrained mathematician, I do not know the proper procedures in dealing with sensitive conjectures and would greatly appreciate your insights, in the possible paths forward.")
]
