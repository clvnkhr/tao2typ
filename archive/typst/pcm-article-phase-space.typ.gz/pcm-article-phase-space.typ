// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/12/21/pcm-article-phase-space/
// Converted to Typst by tao2typ: "2026-10-14T15:16:34.494089+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "PCM article: Phase space", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("PCM article: Phase space")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 December 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/12/21/pcm-article-phase-space/")[#text("https://terrytao.wordpress.com/2007/12/21/pcm-article-phase-space/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’m continuing my ")#link("https://terrytao.wordpress.com/category/paper/companion/")[#text("series of articles")]#text(" for the ")#link("http://gowers.wordpress.com/2007/09/06/hello-world/")[#text("Princeton Companion to Mathematics")]#text(" with my ")#link("http://www.math.ucla.edu/%7Etao/preprints/phase_space.pdf")[#text("article on phase space")]#text(". This brief article, which overlaps to some extent with my ")#link("http://www.math.ucla.edu/%7Etao/preprints/schrodinger.pdf")[#text("article on the Schrödinger equation")]#text(", introduces the concept of ")#emph[#text("phase space")]#text(", which is used to describe both the positions and momenta of a system in both classical and quantum mechanics, although in the latter one has to accept a certain amount of ambiguity (or non-commutativity, if one prefers) in this description thanks to the ")#link("http://en.wikipedia.org/wiki/Uncertainty_principle")[#text("uncertainty principle")]#text(". (Note that positions alone are not sufficient to fully characterise the state of a system; this observation essentially goes all the way back to ")#link("http://en.wikipedia.org/wiki/Zeno_of_Elea")[#text("Zeno")]#text(" with his ")#link("http://en.wikipedia.org/wiki/Zeno%27s_paradoxes#The_arrow_paradox")[#text("arrow paradox")]#text(".)")

#text("Phase space is also used in pure mathematics, where it is used to simultaneously describe position (or time) and frequency; thus the term “time-frequency analysis” is sometimes used to describe phase space-based methods in analysis. The counterpart of classical mechanics is then ")#link("http://en.wikipedia.org/wiki/Symplectic_geometry")[#text("symplectic geometry")]#text(" and ")#link("http://en.wikipedia.org/wiki/Hamiltonian_mechanics")[#text("Hamiltonian ODE")]#text(", while the counterpart of quantum mechanics is the theory of ")#link("http://en.wikipedia.org/wiki/Differential_operator")[#text("linear differential")]#text(" and ")#link("http://en.wikipedia.org/wiki/Pseudodifferential_operator")[#text("pseudodifferential")]#text(" operators. The former is essentially the “high-frequency limit” of the latter; this can be made more precise using the techniques of microlocal analysis, semi-classical analysis, and geometric quantisation.")

#text("As usual, I will highlight another author’s PCM article in this post, this one being ")#link("http://www.statslab.cam.ac.uk/Dept/People/kelly.html")[#text("Frank Kelly")]#text("‘s article “")#link("http://www.statslab.cam.ac.uk/~frank/PAPERS/PRINCETON/pcm0052.pdf")[#text("The mathematics of traffic in networks")]#text("“, a subject which, as a resident of Los Angeles, I can relate to on a personal level :-) . Frank’s article also discusses in detail ")#link("http://en.wikipedia.org/wiki/Braess%27_paradox")[#text("Braess’s paradox")]#text(", which is the rather unintuitive fact that adding extra capacity to a network can sometimes ")#emph[#text("increase")]#text(" the overall delay in the network, by inadvertently redirecting more traffic through bottlenecks! If nothing else, this paradox demonstrates that the mathematics of traffic is non-trivial.")

#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/12/21/pcm-article-phase-space/#comment-21380")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2007")])]

#text("Hi Terence,")

#text("The Braess’ Paradox is also discussed in Basar and Olsder ‘Dynamic Noncooperative Game Theory’ ")#link("http://www.amazon.com/gp/reader/089871429X/ref=sib_dp_pt/002-4635576-1700067#reader-link")[#text(" section 4.7")]#text(" as part of static noncooperative infinite games, p203-5.")

#text("HD Meikle. “A New Twist to Fourier Transforms’, chapter 6, Fourier Transforms in Statistics, p145-182, lists seven references from 1954-1999. In 2D and 3D, he illustrates how the:")#linebreak()#text(" a – “population average” is equivalent to the mechanics “center of gravity or first moment of area”;")#linebreak()#text(" b – “sum of the differences is at a minimum when taken from the mean” is equivalent to the mechanics “moment of inertia or second moment of area”;")#linebreak()#text(" c – “the third moment as a measure of skewness” and")#linebreak()#text(" d – fourth moment as “kurtosis”")#linebreak()#text(" These first “four moments of distribution are used to measure the position, width and shape of a distribution”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ec5e524d284cc5d38bade4e08e60639393fde5c0d5b1ce3b59b117247f7bc97-2c66d54592166a700609818e46170c725a3d9f247bb037e86749ac906bb9dcb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Conlon")]], [#link("https://terrytao.wordpress.com/2007/12/21/pcm-article-phase-space/#comment-21673")[#strong[#text("Peter Conlon")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2007")])]

#text("Dear Prof Tao,")#linebreak()#text(" There is a typo in the article in the second paragraph which mixes up the usual symbols for position (“q”) and momentum (“p”):")

#text("“…we do not simply mean the positions p of all the objects in the")#linebreak()#text(" system (which would occupy physical space or configuration space), but also their")#linebreak()#text(" velocities or momenta q (which would occupy momentum space).”")

#text("I suppose one might say “Mind your Ps and Qs!”")#linebreak()#text(" Peter")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris")]], [#link("https://terrytao.wordpress.com/2007/12/21/pcm-article-phase-space/#comment-21833")[#strong[#text("Chris")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2007")])]

#text("Hi Prof. Tao,")

#text("I have a sort of naive question for you (or perhaps anyone else who cares to answer) on the subject of classical mechanics.")

#text("Before Einsten, conservation of mass was an accepted principle; at least, I know that the chemists accepted it, though I’m not so sure if the physicists accepted it. Assuming the physicists did accept it… if Noether’s theorem in classical mechanics says that a conservation law should correspond to a symmetry, is there an associated symmetry that corresponds to the supposed conservation of mass?")

#text("Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/21/pcm-article-phase-space/#comment-21859")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2007")])]

#text("Dear Chris,")

#text("It’s an interesting question. It seems that for the Hamiltonian systems that arise in non-relativistic physics, the flow (or symmetry) corresponding to the total mass is always trivial (the Hamiltonian vector field associated to the mass is zero). In many cases it is because the mass is already constant on the whole phase space, but in other cases (e.g. KdV or compressible Euler) it seems that the symplectic form happens to degenerate to the constant-mass surfaces anyway. I don’t really have a good explanation of why this should be the case, though.")

#text("In special relativity, of course, the total mass is the magnitude of the total energy-momentum, and the latter is associated to spacetime translation invariance. (Somewhat confusingly, even though energy-momentum is additive – the total energy-momentum of a system is the sum of the energy-momenta of its components – mass is not additive in relativity. But total mass is still conserved, even though it is not the sum of the masses of the components.)")

#text("Dear Peter: thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2007/12/21/pcm-article-phase-space/#comment-21861")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2007")])]

#text("Yes, Chris there is, and it’s one of the fundamental underpinnings of science. It’s so fundamental you use it all the time and never even think of it!")

#text("First, remember that since Einstein we know that mass-energy is what’s really conserved. That is, “mass” and “energy” are really different ways of looking at the same thing, and we convert from units of mass to units of energy by multiplying a mass by the square of the speed of light: ")#mi("E=mc^2")#text(".")

#text("Now, what’s the quantity that’s Noether-conjugate to mass-energy? It’s time! That is, conservation of mass-energy is equivalent to the fact that the laws of physics stay the same as time goes by. In fact, if mass-energy was ")#emph[#text("not")]#text(" conserved, then the laws of physics would change over time, we wouldn’t be able to replicate experiments, and science couldn’t ever get off the ground in the first place!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a7dbf0fc4f87d9dd7d9265b8d742254449560def99ea67f4a0bdffbedeff30-6357b353d4083e451e5adfb16009055f7689e1058db5dc6c29d9cb3641abf55b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Baez")]], [#link("https://terrytao.wordpress.com/2007/12/21/pcm-article-phase-space/#comment-21892")[#strong[#text("John Baez")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2007")])]

#text("If “mass” really means “mass-energy”, as John A. suggests – that is, energy divided by the speed of light squared – then the corresponding symmetry is time translation (up to that factor of ")#mi("c^2")#text(").")

#text("If “mass” really means “invariant mass”, as Terry T. suggests – that is, the magnitude of the energy-momentum 4-vector – then it’s not so clear what the corresponding symmetry is supposed to mean, physically. I’ll try to come up with a snappy answer, but I’m not sure I’ll succeed.")

#text("(The debate over what “mass” really means is endless and unproductive, but modern particle physicists always use it to mean “invariant mass”, since the other sort might as well be called “energy” – especially if you use units where c = 1.)")

#text("All this is for relativistic physics. For nonrelativistic quantum mechanics, governed by the Galilei group instead of the Poincare group, mass is a cocycle! In other words, a quantum particle satisfying Schrodinger’s equation gives a representation of the Galilei group ")#emph[#text("only up to phase")]#text(" – and this phase fudge factor depends on the particle’s mass.")

#text("There’s a nice (but advanced) discussion of this near the end of Guillemin and Sternberg’s ")#emph[#text("Symplectic Techniques in Physics")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2007/12/21/pcm-article-phase-space/#comment-21905")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2007")])]

#text("John B.: Mass itself was conserved in the classical framework, yes, but we now know it to be only approximately conserved. I agree that a semantic debate is fruitless, but how’s this for another take on the matter.")

#text("Mass and energy are (approximately) separately conserved, so each one gets a symmetry. We’ll describe the mass one by an “infinitesimal symmetry” — an operator ")#mi("t_M")#text(" — and the energy one by a similar operator ")#mi("t_E")#text(". Saying that these two operators are infinitesimal symmetries means that physically realistic states are in the kernels of each operator.")

#text("Now here’s where I’m sort of guessing. Since the combination of mass and energy is conserved exactly, the sum of these two infinitesimal symmetries is exact. That is, physically realistic states are in the kernel of the sum. In particular, the intersection of the kernels is in the kernel, but there are states which ")#mi("t_M")#text(" and ")#mi("t_E")#text(" don’t kill, but their errors exacctly cancel each other out.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/21/pcm-article-phase-space/#comment-21947")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2007")])]

#text("Dear John A.: I am not sure exactly what your definitions of mass and energy are, but perhaps there is some confusion caused by popular accounts of mass “being converted into” energy or vice versa by, say, nuclear fission. Einstein’s equation reads ")#mi("E = mc^2")#text(", not ")#mi("E + mc^2 = \\text{const}")#text("; mass (in the mass-energy sense) and energy are simply the same thing, up to a scaling factor of ")#mi("c^2")#text(". Both are perfectly globally conserved in special relativity (and locally conserved in general relativity, in the sense that energy density is a component of a divergence-free tensor, namely the stress-energy tensor.)")

#text("I think the confusion may be caused by (a) mistakenly equating mass-energy ")#mi("m=E/c^2")#text(" with the invariant mass ")#mi("m_0 = \\sqrt{ E^2/c^4 - p^2/c^2}")#text("; and (b) mistakenly assuming that invariant mass is additive (i.e. that the invariant mass of a system equals the sum of the invariant mass of the components). If one makes both of these mistakes, it may seem that mass can “disappear”. For instance in Einstein’s original ")#mi("E=mc^2")#text(" paper (a beautiful and short paper, by the way, and well worth reading), he considers a stationary body of mass m emitting two photons in opposite directions with total energy E, and shows that the remaining body now has a mass of ")#mi("m-E/c^2")#text(". Since photons have zero ")#emph[#text("invariant")]#text(" mass (but positive mass-energy), it does look like mass has been converted into energy here, but that is only because of the false assumptions (a) and (b).")

#text("This Wikipedia article gives a fairly accurate discussion of these topics:")

#link("http://en.wikipedia.org/wiki/Mass-energy_equivalence")[#text("http://en.wikipedia.org/wiki/Mass-energy_equivalence")]

#text("Dear John B.: I think that the symmetry associated with the invariant mass of a system is the action of translating the system in spacetime along the four-velocity vector of that system. Note that when one chooses an inertial frame in which the system has zero total momentum, then the invariant mass and mass-energy agree to second order and so must yield the same symmetry, and indeed in this case translation along the four-velocity vector is just time translation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2007/12/21/pcm-article-phase-space/#comment-21960")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2007")])]

#text("Dr. Tao: I mean that the classical notions of “mass” and “energy” were separate concepts. Now we know them to be different aspects of the same thing, and they can be converted into each other, so their sum is what’s really conserved. But within the framework of classical mechanics, there were things called “mass” and “energy”, which were separately conserved.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Einstein’s derivation of E=mc^2 « What’s new")]], [#link("https://terrytao.wordpress.com/2007/12/21/pcm-article-phase-space/#comment-22345")[#strong[#text("Einstein’s derivation of E=mc^2 « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2007")])]

#text("[…] topic had come up in recent discussion on this blog, so I thought I would present Einstein’s derivation here. Actually, to be precise, in the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2007/12/21/pcm-article-phase-space/#comment-22607")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2007")])]

#text("Very nice article.")

#text("– page 2, middle of paragraph 2: Op(H) is sending functions to functions right?")

#text("– page 3, line 4: typo in “describes”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hassell’s proof of scarring for the Bunimovich stadium « What’s new")]], [#link("https://terrytao.wordpress.com/2007/12/21/pcm-article-phase-space/#comment-30859")[#strong[#text("Hassell’s proof of scarring for the Bunimovich stadium « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2008")])]

#text("[…] physical space. There is a (slightly weaker) form of this conjecture which considers scarring in phase space instead (thus the indicator function is replaced by a more general pseudodifferential operator); […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of From Bose-Einstein condensates to the nonlinear Schrodinger equation « What’s new")]], [#link("https://terrytao.wordpress.com/2007/12/21/pcm-article-phase-space/#comment-42541")[#strong[#text("From Bose-Einstein condensates to the nonlinear Schrodinger equation « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2009")])]

#text("[…] physical system has a phase space of states (which is often parameterised by position variables and momentum variables ). […]")
]
