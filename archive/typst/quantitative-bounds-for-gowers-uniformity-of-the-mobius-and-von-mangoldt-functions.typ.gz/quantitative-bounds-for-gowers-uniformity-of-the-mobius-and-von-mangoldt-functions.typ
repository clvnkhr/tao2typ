// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/
// Converted to Typst by tao2typ: "2026-10-14T16:38:57.292990+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Quantitative bounds for Gowers uniformity of the Mobius and von Mangoldt functions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Quantitative bounds for Gowers uniformity of the Mobius and von Mangoldt functions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 July 2021")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/")[#text("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://sites.google.com/view/joniteravainen/")[#text("Joni Teräväinen")]#text(" and myself have just uploaded to the arXiv our preprint “")#link("https://arxiv.org/abs/2107.02158")[#text("Quantitative bounds for Gowers uniformity of the Möbius and von Mangoldt functions")]#text("“. This paper makes quantitative the Gowers uniformity estimates on the Möbius function ")#mi("{\\mu}")#text(" and the von Mangoldt function ")#mi("{\\Lambda}")#text(".")

#text("To discuss the results we first discuss the situation of the Möbius function, which is technically simpler in some (though not all) ways. We assume familiarity with Gowers norms and standard notations around these norms, such as the averaging notation ")#mi("{\\mathop{\\bf E}_{n \\in [N]}}")#text(" and the exponential notation ")#mi("{e(\\theta) = e^{2\\pi i \\theta}}")#text(". The prime number theorem in qualitative form asserts that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} \\mu(n) = o(1)")]]

#text("as ")#mi("{N \\rightarrow \\infty}")#text(". With Vinogradov-Korobov error term, the prime number theorem is strengthened to")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} \\mu(n) \\ll \\exp( - c \\log^{3/5} N (\\log \\log N)^{-1/5} );")]]

#text("we refer to such decay bounds (With ")#mi("{\\exp(-c\\log^c N)}")#text(" type factors) as ")#emph[#text("pseudopolynomial decay")]#text(". Equivalently, we obtain pseudopolynomial decay of Gowers ")#mi("{U^1}")#text(" seminorm of ")#mi("{\\mu}")#text(":")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mu \\right\\|_{U^1([N])} \\ll \\exp( - c \\log^{3/5} N (\\log \\log N)^{-1/5} ).", block: true)]]

#text("As is well known, the Riemann hypothesis would be equivalent to an upgrade of this estimate to polynomial decay of the form")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mu \\right\\|_{U^1([N])} \\ll_\\varepsilon N^{-1/2+\\varepsilon}", block: true)]]

#text("for any ")#mi("{\\varepsilon>0}")#text(".")

#text("Once one restricts to arithmetic progressions, the situation gets worse: the ")#link("https://en.wikipedia.org/wiki/Siegel%E2%80%93Walfisz_theorem")[#text("Siegel-Walfisz theorem")]#text(" gives the bound ")#metadata(none) <tao-c5229074690540f67da2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| \\mu 1_{a \\text{ mod } q}\\right\\|_{U^1([N])} \\ll_A \\log^{-A} N", block: true)]]

#text(" ")#text(" for any residue class ")#mi("{a \\text{ mod } q}")#text(" and any ")#mi("{A>0}")#text(", but with the catch that the implied constant is ")#link("https://en.wikipedia.org/wiki/Effective_results_in_number_theory")[#text("ineffective")]#text(" in ")#mi("{A}")#text(". This ineffectivity cannot be removed without further progress on the notorious Siegel zero problem.")

#text("In 1937, Davenport was able to show the discorrelation estimate")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} \\mu(n) e(-\\alpha n) \\ll_A \\log^{-A} N")]]

#text("for any ")#mi("{A>0}")#text(" uniformly in ")#mi("{\\alpha \\in {\\bf R}}")#text(", which leads (by standard Fourier arguments) to the Fourier uniformity estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mu \\right\\|_{U^2([N])} \\ll_A \\log^{-A} N.", block: true)]]

#text("Again, the implied constant is ineffective. If one insists on effective constants, the best bound currently available is")

#metadata(none) <tao-30fe9d8526a58c5bcca1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\| \\mu \\right\\|_{U^2([N])} \\ll \\log^{-c} N", block: true)]]

#text("for some small effective constant ")#mi("{c>0}")#text(".")

#text("For the situation with the ")#mi("{U^3}")#text(" norm the previously known results were much weaker. ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2473624")[#text("Ben Green and I")]#text(" showed that ")#metadata(none) <tao-a99a715378fb01ab07f0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\mathop{\\bf E}_{n \\in [N]} \\mu(n) \\overline{F}(g(n) \\Gamma) \\ll_{A,F,G/\\Gamma} \\log^{-A} N")]]

#text(" ")#text(" uniformly for any ")#mi("{A>0}")#text(", any degree two (filtered) nilmanifold ")#mi("{G/\\Gamma}")#text(", any polynomial sequence ")#mi("{g: {\\bf Z} \\rightarrow G}")#text(", and any Lipschitz function ")#mi("{F}")#text("; again, the implied constants are ineffective. On the other hand, in a ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2391635")[#text("separate paper of Ben Green and myself")]#text(", we established the following inverse theorem: if for instance we knew that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mu \\right\\|_{U^3([N])} \\geq \\delta", block: true)]]

#text("for some ")#mi("{0 < \\delta < 1/2}")#text(", then there exists a degree two nilmanifold ")#mi("{G/\\Gamma}")#text(" of dimension ")#mi("{O( \\delta^{-O(1)} )}")#text(", complexity ")#mi("{O( \\delta^{-O(1)} )}")#text(", a polynomial sequence ")#mi("{g: {\\bf Z} \\rightarrow G}")#text(", and Lipschitz function ")#mi("{F}")#text(" of Lipschitz constant ")#mi("{O(\\delta^{-O(1)})}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} \\mu(n) \\overline{F}(g(n) \\Gamma) \\gg \\exp(-\\delta^{-O(1)}).")]]

#text("Putting the two assertions together and comparing all the dependencies on parameters, one can establish the qualitative decay bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mu \\right\\|_{U^3([N])} = o(1).", block: true)]]

#text("However the decay rate ")#mi("{o(1)}")#text(" produced by this argument is ")#emph[#text("completely")]#text(" ineffective: obtaining a bound on when this ")#mi("{o(1)}")#text(" quantity dips below a given threshold ")#mi("{\\delta}")#text(" depends on the implied constant in ")#link(<tao-a99a715378fb01ab07f0>)[#text("(3)")]#text(" for some ")#mi("{G/\\Gamma}")#text(" whose dimension depends on ")#mi("{\\delta}")#text(", and the dependence on ")#mi("{\\delta}")#text(" obtained in this fashion is ineffective in the face of a Siegel zero.")

#text("For higher norms ")#mi("{U^k, k \\geq 3}")#text(", the situation is even worse, because the quantitative inverse theory for these norms is poorer, and indeed it was only with the ")#link("https://arxiv.org/abs/1811.00718")[#text("recent work of Manners")]#text(" that any such bound is available at all (at least for ")#mi("{k>4}")#text("). Basically, Manners establishes if")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mu \\right\\|_{U^k([N])} \\geq \\delta", block: true)]]

#text("then there exists a degree ")#mi("{k-1}")#text(" nilmanifold ")#mi("{G/\\Gamma}")#text(" of dimension ")#mi("{O( \\delta^{-O(1)} )}")#text(", complexity ")#mi("{O( \\exp\\exp(\\delta^{-O(1)}) )}")#text(", a polynomial sequence ")#mi("{g: {\\bf Z} \\rightarrow G}")#text(", and Lipschitz function ")#mi("{F}")#text(" of Lipschitz constant ")#mi("{O(\\exp\\exp(\\delta^{-O(1)}))}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} \\mu(n) \\overline{F}(g(n) \\Gamma) \\gg \\exp\\exp(-\\delta^{-O(1)}).")]]

#text("(We allow all implied constants to depend on ")#mi("{k}")#text(".) Meanwhile, the bound ")#link(<tao-a99a715378fb01ab07f0>)[#text("(3)")]#text(" was extended to arbitrary nilmanifolds ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2877066")[#text("by Ben and myself")]#text(". Again, the two results when concatenated give the qualitative decay")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mu \\right\\|_{U^k([N])} = o(1)", block: true)]]

#text("but the decay rate is completely ineffective.")

#text("Our first result gives an effective decay bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" ")#metadata(none) <tao-7ae7d4d9ca3aeeaaafaa>#text(" For any ")#mi("{k \\geq 2}")#text(", we have ")#tao-math("{\\left\\| \\mu \\right\\|_{U^k([N])} \\ll (\\log\\log N)^{-c_k}}", block: false)#text(" for some ")#mi("{c_k>0}")#text(". The implied constants are effective.")
]

#text("This is off by a logarithm from the best effective bound ")#link(<tao-30fe9d8526a58c5bcca1>)[#text("(2)")]#text(" in the ")#mi("{k=2}")#text(" case. In the ")#mi("{k=3}")#text(" case there is some hope to remove this logarithm based on the improved quantitative inverse theory currently available in this case, but there is a technical obstruction to doing so which we will discuss later in this post. For ")#mi("{k>3}")#text(" the above bound is the best one could hope to achieve purely using the quantitative inverse theory of Manners.")

#text("We have analogues of all the above results for the von Mangoldt function ")#mi("{\\Lambda}")#text(". Here a complication arises that ")#mi("{\\Lambda}")#text(" does not have mean close to zero, and one has to subtract off some suitable approximant ")#mi("{\\Lambda^\\sharp}")#text(" to ")#mi("{\\Lambda}")#text(" before one would expect good Gowers norms bounds. For the prime number theorem one can just use the approximant ")#mi("{1}")#text(", giving")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\Lambda - 1 \\right\\|_{U^1([N])} \\ll \\exp( - c \\log^{3/5} N (\\log \\log N)^{-1/5} )", block: true)]]

#text("but even for the prime number theorem in arithmetic progressions one needs a more accurate approximant. In our paper it is convenient to use the “Cramér approximant”")

#align(center)[#tao-fit-display[#mitex("\\Lambda_{\\text{Cramér}}(n) := \\frac{W}{\\phi(W)} 1_{(n,W)=1}")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("W := \\prod_{p<Q} p")]]

#text("and ")#mi("{Q}")#text(" is the quasipolynomial quantity")

#metadata(none) <tao-50781ae6a4d70a21d399>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("Q = \\exp(\\log^{1/10} N).")]]

#text("Then one can show from the Siegel-Walfisz theorem and standard bilinear sum methods that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} (\\Lambda - \\Lambda_{\\text{Cramér}}(n)) e(-\\alpha n) \\ll_A \\log^{-A} N")]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\Lambda - \\Lambda_{\\text{Cramér}}\\right\\|_{U^2([N])} \\ll_A \\log^{-A} N", block: true)]]

#text("for all ")#mi("{A>0}")#text(" and ")#mi("{\\alpha \\in {\\bf R}}")#text(" (with an ineffective dependence on ")#mi("{A}")#text("), again regaining effectivity if ")#mi("{A}")#text(" is replaced by a sufficiently small constant ")#mi("{c>0}")#text(". All the previously stated discorrelation and Gowers uniformity results for ")#mi("{\\mu}")#text(" then have analogues for ")#mi("{\\Lambda}")#text(", and our main result is similarly analogous:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" For any ")#mi("{k \\geq 2}")#text(", we have ")#tao-math("{\\left\\| \\Lambda - \\Lambda_{\\text{Cramér}} \\right\\|_{U^k([N])} \\ll (\\log\\log N)^{-c_k}}", block: false)#text(" for some ")#mi("{c_k>0}")#text(". The implied constants are effective.")
]

#text("By standard methods, this result also gives quantitative asymptotics for counting solutions to various systems of linear equations in primes, with error terms that gain a factor of ")#mi("{O((\\log\\log N)^{-c})}")#text(" with respect to the main term.")

#text("We now discuss the methods of proof, focusing first on the case of the Möbius function. Suppose first that there is no “Siegel zero”, by which we mean a quadratic character ")#mi("{\\chi}")#text(" of some conductor ")#mi("{q \\leq Q}")#text(" with a zero ")#mi("{L(\\beta,\\chi)}")#text(" with ")#mi("{1 - \\beta \\leq \\frac{c}{\\log Q}}")#text(" for some small absolute constant ")#mi("{c>0}")#text(". In this case the Siegel-Walfisz bound ")#link(<tao-c5229074690540f67da2>)[#text("(1)")]#text(" improves to a quasipolynomial bound ")#metadata(none) <tao-e93247c8fc04bf168ecc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\| \\mu 1_{a \\text{ mod } q}\\right\\|_{U^1([N])} \\ll \\exp(-\\log^c N).", block: true)]]

#text(" ")#text(" To establish Theorem ")#link(<tao-7ae7d4d9ca3aeeaaafaa>)[#text("1")]#text(" in this case, it suffices by Manners’ inverse theorem to establish the polylogarithmic bound")

#metadata(none) <tao-3c08c664ccdf9d0effb0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\mathop{\\bf E}_{n \\in [N]} \\mu(n) \\overline{F}(g(n) \\Gamma) \\ll \\exp(-\\log^c N)")]]

#text("for all degree ")#mi("{k-1}")#text(" nilmanifolds ")#mi("{G/\\Gamma}")#text(" of dimension ")#mi("{O((\\log\\log N)^c)}")#text(" and complexity ")#mi("{O( \\exp(\\log^c N))}")#text(", all polynomial sequences ")#mi("{g}")#text(", and all Lipschitz functions ")#mi("{F}")#text(" of norm ")#mi("{O( \\exp(\\log^c N))}")#text(". If the nilmanifold ")#mi("{G/\\Gamma}")#text(" had bounded dimension, then one could repeat the arguments ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2877066")[#text("of Ben and myself")]#text(" more or less verbatim to establish this claim from ")#link(<tao-e93247c8fc04bf168ecc>)[#text("(5)")]#text(", which relied on the quantitative equidistribution theory on nilmanifolds developed in a ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2877065")[#text("separate paper of Ben and myself")]#text(". Unfortunately, in the latter paper the dependence of the quantitative bounds on the dimension ")#mi("{d}")#text(" was not explicitly given. In an appendix to the current paper, we go through that paper to account for this dependence, showing that all exponents depend at most doubly exponentially in the dimension ")#mi("{d}")#text(", which is barely sufficient to handle the dimension of ")#mi("{O((\\log\\log N)^c)}")#text(" that arises here.")

#text("Now suppose we have a Siegel zero ")#mi("{L(\\beta,\\chi)}")#text(". In this case the bound ")#link(<tao-e93247c8fc04bf168ecc>)[#text("(5)")]#text(" will ")#emph[#text("not")]#text(" hold in general, and hence also ")#link(<tao-3c08c664ccdf9d0effb0>)[#text("(6)")]#text(" will not hold either. Here, the usual way out (while still maintaining effective estimates) is to approximate ")#mi("{\\mu}")#text(" not by ")#mi("{0}")#text(", but rather by a more complicated approximant ")#mi("{\\mu_{\\text{Siegel}}}")#text(" that takes the Siegel zero into account, and in particular is such that one has the (effective) pseudopolynomial bound ")#metadata(none) <tao-f90e22675ced9c138e19>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left\\| (\\mu - \\mu_{\\text{Siegel}}) 1_{a \\text{ mod } q}\\right\\|_{U^1([N])} \\ll \\exp(-\\log^c N)", block: true)]]

#text(" ")#text(" for all residue classes ")#mi("{a \\text{ mod } q}")#text(". The Siegel approximant to ")#mi("{\\mu}")#text(" is actually a little bit complicated, and to our knowledge the first appearance of this sort of approximant only appears as late as this 2010 ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2607678")[#text("paper of Germán and Katai")]#text(". Our version of this approximant is defined as the multiplicative function such that")

#align(center)[#tao-fit-display[#mitex("\\mu_{\\text{Siegel}}(p^j) = \\mu(p^j)")]]

#text("when ")#mi("{p < Q}")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\mu_{\\text{Siegel}}(n) = \\alpha n^{\\beta-1} \\chi(n)")]]

#text("when ")#mi("{n}")#text(" is coprime to all primes ")#mi("{p<Q}")#text(", and ")#mi("{\\alpha}")#text(" is a normalising constant given by the formula")

#align(center)[#tao-fit-display[#mitex("\\alpha := \\frac{1}{L^{\\prime}(\\beta,\\chi)} \\prod_{p<Q} (1-\\frac{1}{p})^{-1} (1 - \\frac{\\chi(p)}{p^\\beta})^{-1}")]]

#text("(this constant ends up being of size ")#mi("{O(1)}")#text(" and plays only a minor role in the analysis). This is a rather complicated formula, but it seems to be virtually the only choice of approximant that allows for bounds such as ")#link(<tao-f90e22675ced9c138e19>)[#text("(7)")]#text(" to hold. (This is the one aspect of the problem where the von Mangoldt theory is simpler than the Möbius theory, as in the former one only needs to work with very rough numbers for which one does not need to make any special accommodations for the behavior at small primes when introducing the Siegel correction term.) With this starting point it is then possible to repeat the analysis of my previous papers with Ben and obtain the pseudopolynomial discorrelation bound")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} (\\mu - \\mu_{\\text{Siegel}})(n) \\overline{F}(g(n) \\Gamma) \\ll \\exp(-\\log^c N)")]]

#text("for ")#mi("{F(g(n)\\Gamma)}")#text(" as before, which when combined with Manners’ inverse theorem gives the doubly logarithmic bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mu - \\mu_{\\text{Siegel}} \\right\\|_{U^k([N])} \\ll (\\log\\log N)^{-c_k}.", block: true)]]

#text("Meanwhile, a direct sieve-theoretic computation ends up giving the singly logarithmic bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mu_{\\text{Siegel}} \\right\\|_{U^k([N])} \\ll \\log^{-c_k} N", block: true)]]

#text("(indeed, there is a good chance that one could improve the bounds even further, though it is not helpful for this current argument to do so). Theorem ")#link(<tao-7ae7d4d9ca3aeeaaafaa>)[#text("1")]#text(" then follows from the triangle inequality for the Gowers norm. It is interesting that the Siegel approximant ")#mi("{\\mu_{\\text{Siegel}}}")#text(" seems to play a rather essential component in the proof, even if it is absent in the final statement. We note that this approximant seems to be a useful tool to explore the “illusory world” of the Siegel zero further; see for instance the ")#link("https://arxiv.org/abs/2105.14653")[#text("recent paper of Chinis")]#text(" for some work in this direction.")

#text("For the analogous problem with the von Mangoldt function (assuming a Siegel zero for sake of discussion), the approximant ")#mi("{\\Lambda_{\\text{Siegel}}}")#text(" is simpler; we ended up using")

#align(center)[#tao-fit-display[#mitex("\\Lambda_{\\text{Siegel}}(n) = \\Lambda_{\\text{Cramér}}(n) (1 - n^{\\beta-1} \\chi(n))")]]

#text("which allows one to state the standard prime number theorem in arithmetic progressions with classical error term and Siegel zero term compactly as")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\Lambda - \\Lambda_{\\text{Siegel}}) 1_{a \\text{ mod } q}\\right\\|_{U^1([N])} \\ll \\exp(-\\log^c N).", block: true)]]

#text("Routine modifications of previous arguments also give")

#metadata(none) <tao-4225edcd1008ac31ef77>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\mathop{\\bf E}_{n \\in [N]} (\\Lambda - \\Lambda_{\\text{Siegel}})(n) \\overline{F}(g(n) \\Gamma) \\ll \\exp(-\\log^c N)")]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\Lambda_{\\text{Siegel}} \\right\\|_{U^k([N])} \\ll \\log^{-c_k} N.", block: true)]]

#text("The one tricky new step is getting from the discorrelation estimate ")#link(<tao-4225edcd1008ac31ef77>)[#text("(8)")]#text(" to the Gowers uniformity estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\Lambda - \\Lambda_{\\text{Siegel}} \\right\\|_{U^k([N])} \\ll (\\log\\log N)^{-c_k}.", block: true)]]

#text("One cannot directly apply Manners’ inverse theorem here because ")#mi("{\\Lambda}")#text(" and ")#mi("{\\Lambda_{\\text{Siegel}}}")#text(" are unbounded. There is a standard tool for getting around this issue, now known as the ")#emph[#text("dense model theorem")]#text(", which is the standard engine powering the ")#emph[#text("transference principle")]#text(" from theorems about bounded functions to theorems about certain types of unbounded functions. However the quantitative versions of the dense model theorem in the literature are expensive and would basically weaken the doubly logarithmic gain here to a triply logarithmic one. Instead, we bypass the dense model theorem and directly transfer the inverse theorem for bounded functions to an inverse theorem for unbounded functions by using the ")#emph[#text("densification")]#text(" approach to transference introduced ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3361771")[#text("by Conlon, Fox, and Zhao")]#text(". This technique turns out to be quantitatively quite efficient (the dependencies of the main parameters in the transference are polynomial in nature), and also has the technical advantage of avoiding the somewhat tricky “correlation condition” present in early transference results which are also not beneficial for quantitative bounds.")

#text("In principle, the above results can be improved for ")#mi("{k=3}")#text(" due to the stronger quantitative inverse theorems in the ")#mi("{U^3}")#text(" setting. However, there is a bottleneck that prevents us from achieving this, namely that the equidistribution theory of two-step nilmanifolds has exponents which are exponential in the dimension rather than polynomial in the dimension, and as a consequence we were unable to improve upon the doubly logarithmic results. Specifically, if one is given a sequence of bracket quadratics such as ")#mi("{\\lfloor \\alpha_1 n \\rfloor \\beta_1 n, \\dots, \\lfloor \\alpha_d n \\rfloor \\beta_d n}")#text(" that fails to be ")#mi("{\\delta}")#text("-equidistributed, one would need to establish a nontrivial linear relationship modulo 1 between the ")#mi("{\\alpha_1,\\beta_1,\\dots,\\alpha_d,\\beta_d}")#text(" (up to errors of ")#mi("{O(1/N)}")#text("), where the coefficients are of size ")#mi("{O(\\delta^{-d^{O(1)}})}")#text("; current methods only give coefficient bounds of the form ")#mi("{O(\\delta^{-\\exp(d^{O(1)})})}")#text(". An ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=457360")[#text("old result of Schmidt")]#text(" demonstrates proof of concept that these sorts of polynomial dependencies on exponents is possible in principle, but actually implementing Schmidt’s methods here seems to be a quite non-trivial task. There is also another possible route to removing a logarithm, which is to strengthen the inverse ")#mi("{U^3}")#text(" theorem to make the dimension of the nilmanifold logarithmic in the uniformity parameter ")#mi("{\\delta}")#text(" rather than polynomial. Again, the Freiman-Bilu theorem (see for instance ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2277597")[#text("this paper of Ben and myself")]#text(") demonstrates proof of concept that such an improvement in dimension is possible, but some work would be needed to implement it.")

#heading(level: 1)[#text("Comments (25)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-631056")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2021")])]

#text("Why not use the simple notation 1^x=e^{2 pi i x} ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-631058")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2021")])]

#text("We sometimes the ")#mi("1^x")#text(" notation humorously in informal conversation, but the notation ")#mi("e(x)")#text(" doesn’t use many more symbols than ")#mi("1^x")#text(" and is well established in the analytic number theory community. With ")#mi("1^x")#text(" there is always the danger that one might accidentally “simplify” ")#mi("1^x")#text(" to ")#mi("1")#text(" by incorrectly applying the laws of high school algebra, or be under the mistaken belief that ")#mi("1^x")#text(" is a real number just because ")#mi("1")#text(" and ")#mi("x")#text(" are reals. (Also, according to usual complex exponentiation conventions, ")#mi("1^x")#text(" is not just ")#mi("e(x)= e^{2\\pi ix}")#text(", but is in fact the multi-valued expression ")#mi("e(kx) = e^{2\\pi i kx}, k \\in {\\bf Z}")#text(".)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Webspinner")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-631068")[#strong[#text("Webspinner")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2021")])]

#text("Congratulations on this remarkable accomplishment. I suspect planning according to information goes a long way. It is rather unfortunate that (as can be observed so often, even today) Confucius on occasion does hit the innocent.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Webspinner")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-631098")[#strong[#text("Webspinner")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2021")])]

#text("Dear Prof. Tao,")

#text("I’m sorry, I must have seen a connection where there wasn’t one. We all have our experiences which influence the lesser parts of our brains (those where conditioning applies) and I sadly fell victim to mine. It is hard to counter-act these using the more advanced parts of the brain, but it is certainly possible.")

#text("Nevertheless, I’d still be very grateful if the corrections that I suggested a while ago could be implemented.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e68f7ae40e566556e9b16d984a2806cc9adf9a915fca9d3d42e2a0f4c58e3645-9c03e454e1b6b54e4d420472ce0ce70f6d7ec597e5de00e075753a84e854a61d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-631076")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2021")])]

#text("Last paragraph")

#text("(up to errors of {O(1/N)}), where the coefficients are of size {O(\\delta^{-d^{O(1)})}; current meth")

#text("My browser says that the formula does not parse")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-631083")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2021")])]

#text("What is known about the obstruction for improving the Vinogradov-Korobov error term?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-631102")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2021")])]

#text("The Vinogradov-Korobov error term comes from combining the classical proof of the prime number theorem (based on combining upper and lower bounds for ")#mi("\\zeta(s)")#text(" for ")#mi("s")#text(" near ")#mi("1+it")#text(" and ")#mi("1+2it")#text(") with the Vinogradov exponential sum estimates for sums like ")#mi("\\sum_{N \\leq n \\leq 2N} n^{it}")#text(", which are non-trivial in the region ")#mi("t \\ll \\exp( \\log^{3/2-\\varepsilon} N )")#text(". I think the bounds obtained from these two inputs is about as efficient as one could hope for without additional structural information on ")#mi("\\zeta")#text(", so to do better one would either have to (a) adapt a quite different proof of the prime number theorem, (b) extend the range of the Vinogradov exponential sum estimates, or (c) somehow use additional properties of the zeta function near ")#mi("1+it")#text(" and ")#mi("1+2it")#text(". I don’t know of any plausible way to make headway on any of these three options though. (Perhaps decoupling theorem technology may one day make some progress on (b), but this would require understanding how decoupling theorems depend on the degree of the polynomials involved in those theorems, and these dependencies are currently quite terrible.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47176abc6027d252e0db20fae62f5003bff62d078e3ea2ff0f2b631f7ef2e035-5270784285c1276e797a3382de6003aaba4b8908a292ad2cbe5ed7dd66bdc4ea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-631277")[#strong[#text("Curious")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2021")])]

#text("By a different proof of PNT are you implying the proof would not bother to consider zeta function directly? Perhaps PNT emerges through another structural consideration and a different argument without zeta function?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-631126")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2021")])]

#text("Defining the strictly multiplicative ")#mi("\\lambda_{k-1}(n) := e(1/k)^{\\Omega(n)\\mod k}")#text(" as generalized Liouville functions (with ")#mi("\\lambda_1(n) = \\lambda(n)")#text(" the “normal” Liouville function) can we say anything on the pseudorandomness of these? I think for example about 2D random-walk properties (")#link("https://mathworld.wolfram.com/RandomWalk2-Dimensional.html")[#text("https://mathworld.wolfram.com/RandomWalk2-Dimensional.html")]#text("). Could this lead to anything useful? Or are we happy about less complexity by sticking with k=2? I guess prime k could be more useful than compound.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-631156")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2021")])]

#text("Interesting question! Such functions are certainly studied on occasion in analytic number theory (Joni and I even have ")#link("https://arxiv.org/abs/1904.05096")[#text("a separate paper")]#text(" involving them). Their Dirichlet series involves fractional powers of the zeta function and so I believe the major arc theory is largely similar, e.g., they should obey some analogue of the Siegel–Walfisz theorem. On the other hand I’m not sure how to treat the minor arc sums (e.g., to control ")#mi("{\\bf E}_{n \\in [N]} \\lambda_{k-1}(n) e(\\alpha n)")#text(" for minor arc ")#mi("\\alpha")#text(") in an efficient fashion, as it is not clear to me if ")#mi("\\lambda_{k-1}")#text(" can be split into the standard “Type I” and “Type II” sums that one usually uses to handle these sums. There may already be literature in this direction, though I’m not sure how to search for it (there does not appear to be a standardised name for these generalised Liouville functions…).")

#text("EDIT: Actually, on further reflection it seems likely that some analogue of the Heath-Brown identity exists for the generalised Liouville function (basically by taking some Taylor expansion of some suitable modification of a fractional power of ")#mi("\\zeta")#text(" around ")#mi("\\zeta=1")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-631174")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2021")])]

#text("Any multiplicative function which is periodic on the primes should have a decomposition into Type I/II sums. There is work of Drappeau and Topacogullari on this (arXiv:1807.09569), also touched on in work of Teravainen and Matomaki (arXiv:1911.09076).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-631179")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2021")])]

#text("Thank you for the valueable comment! I try to go through it step by step and right now I am just trying hard to obtain the Dirichlet transforms, would you have you got a hint how to do that?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-631199")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2021")])]

#text("See here for proceedings to evaluate this expression ")#link("https://math.stackexchange.com/questions/4194549/dirichlet-transform-of-e2-pi-i-3-omegan")[#text("https://math.stackexchange.com/questions/4194549/dirichlet-transform-of-e2-pi-i-3-omegan")]#text(". In my hands the fractional powers of ")#mi("\\zeta")#text(" are cancelling to leave ")#mi("\\zeta(ks)")#text(" and product terms I cannot really proceed with.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Webspinner")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-631128")[#strong[#text("Webspinner")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2021")])]

#text("May I ask one question though, so that at least I know: How did the idea originate that Siegel zeroes might play a part in the proof?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-631416")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2021")])]

#text("just wishing a happy birthday!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-631424")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2021")])]

#text("Happy birthday to you !")#linebreak()#text(" Wishing you have the best work!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-631449")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2021")])]

#text("Saying happy birthday in all of the languages I can speak! 祝你生日快乐!, お誕生日おめでとう！생일 축하! Alles Gute zum Geburtstag! Bon anniversaire! Feliz cumpleaños! (I am kind of poor in chinese and german however…)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adrian Fellhauer")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-636866")[#strong[#text("Adrian Fellhauer")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2021")])]

#text("I hereby claim priority for the case of what you seem to call “infinite complexity”:")

#link("https://www.researchgate.net/publication/356006809_SOME_ASYMPTOTIC_LAWS_IN_THE_THEORY_OF_PRIMES#fullTextFileContent")[#text("https://www.researchgate.net/publication/356006809_SOME_ASYMPTOTIC_LAWS_IN_THE_THEORY_OF_PRIMES#fullTextFileContent")]

#text("This article has been submitted by me, its author, to the Bulletin of the Helenic Mathematical Society and is currently being peer-reviewed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adrian Fellhauer")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-636869")[#strong[#text("Adrian Fellhauer")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2021")])]

#text("Here are the non-linear cases:")

#link("https://www.researchgate.net/publication/356020318_NON-LINEAR_SIFTING_PROBLEMS")[#text("https://www.researchgate.net/publication/356020318_NON-LINEAR_SIFTING_PROBLEMS")]

#text("This is a pre-peer-review draft, and most of the computations aren’t yet made explicit. I’ll be working on that ’round the clock.")

#text("不患人不知，患不知人也。")#linebreak()#text(" Is this not also Confucius?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adrian Fellhauer")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-636870")[#strong[#text("Adrian Fellhauer")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2021")])]

#text("I meant “Hellenic”, I hope the key was stuck…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adrian Fellhauer")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-636872")[#strong[#text("Adrian Fellhauer")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2021")])]

#text("I apologize for the preliminary nature of these sketches, but the dire situation I’m in forces me to spend less time on them.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Higher uniformity of arithmetic functions in short intervals I. All intervals | What's new")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-642647")[#strong[#text("Higher uniformity of arithmetic functions in short intervals I. All intervals | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2022")])]

#text("[…] choose a more sophisticated approximant in the presence of a Siegel zero, as I did with Joni in this recent paper, but we do not do so […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c809c8ecd827a606bd89925b693c821803ce90ddff765a20613b5d133ee1120-3cc22ef8c558e72529ba9c2453a36bb902c9d97441f9d5fd5e4f6e1791b14c36.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of giuliocorazza")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-658972")[#strong[#text("giuliocorazza")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2022")])]

#text("I realise that I am launching a question on this post more than a year after its publication, but I think my question fits well with what has been discussed here. I would like to know how much confidence to place in a probabilistic approach to solving the Riemann hypothesis. In particular, a peculiar asymptotic power law of the Mertens function (as a sum of Möbius functions) is proven to be equivalent to the Riemann hypothesis. At the same time, a specific form of this asymptotic power law, namely the law of iterated log’s, appears within the Wiener process (as a limit of the sum of random variables). Here the question arises, if it actually makes sense: what are the exact tools at the disposal of contemporary mathematics to demonstrate a possible asymptotically random nature of a process generated by simple deterministic rules (such as the very definition of a prime number)? Or perhaps better, what aspects of the theory of stochastic processes are really connected with objects such as the Mertens function and can therefore help the understanding of those special deterministic processes and their asymptotic laws?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-658987")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2022")])]

#text("One should make a distinction between randomness and ")#link("https://en.wikipedia.org/wiki/Pseudorandomness")[#text("pseudorandomness")]#text(". The primes, or other proxies for the primes such as the Mobius function, are deterministic and are not expected to be directly related to any genuinely random process. However, they are conjectured to exhibit pseudorandom properties that give them similar statistics to a random process. While one cannot hope to directly use the random models to rigorously prove assertions about these deterministic number-theoretic objects, the random models can still produce very convincing predictions and conjectures regarding the behavior of these objects, and also suggest some ways to partially confirm the pseudorandomness conjectures. For instance, if control of one statistic (e.g. k-point correlations) of a random model can be used to control a different statistic (e.g., distribution of gaps), one can then hope that control of the analogous former statistic in the deterministic situation can similarly control the analogous latter statistic. (An example of this is ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=409385")[#text("Gallagher’s famous calculation")]#text(" showing how the Hardy-Littlewood conjecture for primes implies an exponential distribution for prime gaps.)")

#text("There are also correspondence principles (such as the Furstenberg correspondence principle) that allow one to associate various probability spaces (or more precisely, measure-preserving systems) as “asymptotic limits” of deterministic objects such as the Mobius function. Standard pseudorandomness conjectures such as the Chowla conjecture can then be viewed as asserting a precise description of these limiting spaces, and then one can often use tools from probability to perform various calculations on these spaces which can then be transferred back to number-theoretic assertions. In some cases one can still proceed in this fashion without the full strength of a Chowla-type conjecture by relying on just partial control of the limiting systems; see for instance ")#link("https://arxiv.org/abs/1804.08556")[#text("this paper of Frantzikinakis and Host")]#text(" for an example of this strategy.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quantitative bounds for sets lacking polynomial progressions with shifted prime difference | What's new")]], [#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/#comment-694044")[#strong[#text("Quantitative bounds for sets lacking polynomial progressions with shifted prime difference | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2026")])]

#text("[…] quantitative bounds in the linear case were obtained by Leng and by Teräväinen and myself, but our new method improves upon these bounds by roughly one iterated logarithm. On the other […]")
]
