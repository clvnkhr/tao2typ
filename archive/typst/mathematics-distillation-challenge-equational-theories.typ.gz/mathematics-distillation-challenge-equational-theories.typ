// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/
// Converted to Typst by tao2typ: "2026-10-14T15:21:10.721083+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Mathematics Distillation Challenge – Equational Theories", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Mathematics Distillation Challenge – Equational Theories")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 March 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/")[#text("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Mathematical research traditionally involves a small number of professional mathematicians working closely on difficult problems. However, I have long believed that there is a complementary way to do mathematics, in which one works with a broad community of mathematically minded people on problems which may not be as deep as the problems one traditionally works on, but still are of mathematical interest; and that modern technologies, including AI, are more suitable for contributing the latter type of workflow. The “")#link("https://en.wikipedia.org/wiki/Polymath_Project")[#text("Polymath projects")]#text("” were one example of this broad type of collaboration, where internet platforms such as blogs and wikis were used to facilitate such collaboration. Some years later, collaborative formalization projects (such as the ")#link("https://github.com/teorth/pfr")[#text("one to formalize the Polynomial Freiman–Ruzsa conjecture")]#text(" of Marton, discussed ")#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/")[#text("previously on this blog here")]#text(") became popular in some circles. And in 2024, I launched the ")#link("https://github.com/teorth/equational_theories")[#text("Equational Theories Project (ETP)")]#text(" (discussed on this blog ")#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/")[#text("here")]#text(" and ")#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/")[#text("here")]#text("), combining the rigor of Lean formalization with “")#link("https://en.wikipedia.org/wiki/GOFAI")[#text("good old fashioned AI")]#text("” (in the form of automated theorem provers) to settle (with formal verification) over 22 million true-false problems in universal algebra.")

#text("Continuing in this spirit, ")#link("https://damek.github.io/")[#text("Damek Davis")]#text(" and I are ")#link("https://competition.sair.foundation/competitions/mathematics-distillation-challenge-equational-theories-stage1/overview")[#text("launching a new project, in the form of an experimental competitive challenge")]#text(" hosted by the ")#link("https://sair.foundation/")[#text("SAIR Foundation")]#text(" (where I serve as a board member, and which is supplying technical support and compute). The idea of this challenge, motivated in part by this recent paper of ")#link("https://arxiv.org/abs/2509.20820")[#text("Honda, Murakami, and Zhang")]#text(", is to measure the extent to which the 22 million universal algebra true-false results obtained by the ETP can be “distilled” into a short, human-readable “cheat sheet”, similar to how a student in an undergraduate math class might distill the knowledge learned from that class into a single sheet of paper that the student is permitted to bring into an exam.")

#text("Here is a typical problem in universal algebra that the ETP was able to answer:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 1")]#text(" Suppose that ")#mi("{*: M \\times M \\rightarrow M}")#text(" is a binary operation such that ")#mi("{x * (y * z) = (z * w) * w}")#text(" for all ")#mi("{x,y,z,w}")#text(". Is it true that ")#mi("{x * (y * x) = (x * y) * z}")#text(" for all ")#mi("{x,y,z}")#text("?")
]

#text("Such a problem can be settled either by algebraically manipulating the initial equation to deduce the target equation, or by finding a counterexample to the target equation that still satisfies the initial equation. There are a variety of techniques to achieve either of these, but this sort of problem is difficult, and even undecidable in some cases; see ")#link("https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/")[#text("this paper of the ETP collaborators")]#text(" for more discussion. Nevertheless, many of these problems can be settled with some effort by humans, by automated theorem provers, or by frontier AI systems; here for instance is an ")#link("https://gemini.google.com/share/23d35d7eb8b4")[#text("AI-generated solution")]#text(" to the above problem.")

#text("However, these AI models are expensive, and do not reveal much insight as to where their answers come from. If one instead tries a smaller and cheaper model, such as one of the many open-source models available, it turns out that these models basically perform no better than random chance, in that when asked to say whether the answer to a question such as the above is true or false, they only answer correctly about 50% of the time.")

#text("But, similarly to how a student struggling with the material for a math class can perform better on an exam when provided the right guidance, it turns out that such cheap models can perform at least modestly better on this task (with success rates ")#link("https://benchmark.sair.foundation/benchmarks/mathematics-distillation-challenge-equational-theories-stage1")[#text("increasing to about 55%-60%")]#text(") if given the right prompt or “cheat sheet”.")

#text("“Stage 1” of the distillation challenge, which we ")#link("https://competition.sair.foundation/competitions/mathematics-distillation-challenge-equational-theories-stage1/overview")[#text("launched today")]#text(", asks for contestants to design a cheat sheet (of at most 10 kilobytes in size) that can increase the performance of these models on the above true-false problems to as high a level as possible. We have provided a “")#link("https://playground.sair.foundation/playground/mathematics-distillation-challenge-equational-theories-stage1")[#text("playground")]#text("” with which to test one’s cheat sheet (or a small number of example cheat sheets) some cheap models against a public set of 1200 problems (1000 of which were randomly selected, and rather easy, together with 200 “hard” problems that were selected to resist the more obvious strategies for resolving these questions); a brief video explaining how to use the playground can be found ")#link("https://www.youtube.com/watch?v=H5u2wtUE7UQ")[#text("here")]#text(".")

#text("Submissions stage will end on April 20, after which we will evaluate the submissions against a private subset of test questions. The top 1000 submissions will advance to a second stage which we are currently in the process of designing, which will involve more advanced models, but also the more difficult task of not just providing a true-false answer, but also a proof or counterexample to the problem.")

#text("The competition will be coordinated on ")#link("https://zulip.sair.foundation/#narrow/channel/13-Math-Distillation-Challenge---equational-theories/topic/discussions/with/191")[#text("this Zulip channel")]#text(", where I hope there will be a lively and informative discussion.")

#text("My hope is that the winning submissions will capture the most productive techniques for solving these problems, and/or provide general problem-solving techniques that would also be applicable to other types of mathematical problems. We started with the equational theory project data set for this pilot competition due to its availability and spectrum of difficulty levels, but if this type of distillation process leads to interesting results, one could certainly run in on many other types of mathematical problem classes to get some empirical data on how readily they can be solved, particularly after we learn from this pilot competition on how to encourage participation and share of best practices.")

#text("SAIR will also launch some other mathematical challenges in the coming months that will be of a more cooperative nature than this particular competitive challenge; stay tuned for further announcements.")

#heading(level: 1)[#text("Comments (21)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hopefula0ac40f0f2")]], [#link("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/#comment-691983")[#strong[#text("hopefula0ac40f0f2")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2026")])]

#text("Interesting project. Once enough submissions are there, one might ask for pairs (or triplets or…) of cheat sheets which score best.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/#comment-691984")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2026")])]

#text("The Zulip channel is invite only I think")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/#comment-691989")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2026")])]

#text("Oops, we forgot to open it up with the competition. Account registration should now be open.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b0061526726e1698319494389980f6b12d19ab6895342cce0e6e6aa0d592edb6-d7d2137ff42e2406055da7ea811966f4d0806590d4cca9a2b50ac82e6ff626e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikhled")]], [#link("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/#comment-691988")[#strong[#text("Mikhled")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2026")])]

#text("prof. Only 10 credits per day at the playground?!!")

#text("Can u scale up test My cheatsheet solved 10 normal and hard200 already in seconds, though in compliance with all stipulated technical, mathematical, and timing criteria yield 100% And please, regarding the instructions to AI by you in the box under the participants’ prompt box,")

#text("Does what u wrote – u started with the word you are mathematician – affect our cheatsheet prompt efficiency of (the participant’s code)? My cheat title is DRCM Mikhled")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/#comment-691990")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2026")])]

#text("Unfortunately with the compute budget we have, spread out over the anticipated number of contestants (which we are not currently capping), this is close to the maximum amount of free compute we can offer for this stage. Stage 2 will have a cap on the number of participants and we will be able to offer more compute per participant.")

#text("The playground is mostly intended to explain the contest format; I imagine that many contestants will develop their own custom testing frameworks with their own compute resources to be able to fine-tune their cheatsheets.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/#comment-691994")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2026")])]

#text("This project reminds me of the complexity class P/Poly. The cheat sheet is the “polynomial-length advice string”, which doesn’t depend on the specific input but instead is generically helpful across the whole set of (bounded length) inputs, in concert with a relatively efficient algorithm.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/#comment-691996")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2026")])]

#text("Are there any monetary prizes planned for Stage 1/2?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/#comment-691998")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2026")])]

#text("Not for Stage 1, but we are planning some modest prizes for Stage 2, and possibly some prize ceremony as well. Details to be determined – this is our first competition, and we are still working things out as we go along!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3791dc0015114c014ff04950b1fe76274abe6015549321150318a46ca8d5eab7-86972527d5c34629000b78d087dfc3df81fe8a853b89de7ec9d1dc6c704a4a92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of stacey8szmy")]], [#link("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/#comment-692000")[#strong[#text("stacey8szmy")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2026")])]

#text("Hey Prof. Tao")

#text("Most entries for the ETP Challenge are just static lists of laws.")

#text("But a list isn’t an intelligence; it’s a script.")

#text("​If we really want to see which AI-human collaboration has ‘solved’ Magma logic, could / should we be doing Head-to-Head Adjudication?")

#text("Pit the top frameworks against each other.")

#text("Give OS ‘A’ a complex implication generated by OS ‘B’ and see if it can maintain logical sovereignty or if it collapses. ​")

#text("A framework could/should be a Governance System; it should be able to adjudicate ‘illegal’ or ‘impossible’ structures without crashing.")

#text("Why aren’t we testing whose architecture actually holds the realm the longest? I know you said next phases will be developed, I hope this is something we can be anticipating.")

#text("Thanks for the Mathematics Distillation Challenge.")

#text("~Team Zer00logy")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/#comment-692001")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2026")])]

#text("It is possible that the provided prompts are just an elaborate way of providing a random seed to a stochastic sampling algorithm. Because of that, encouraging submissions with > 50% success rate might introduce a selection bias.")

#text("I would, for the final assessment, include a large set of “null-prompts”, e.g. prompts that sound like being mathematically helpful but in the end aren’t, and score success rates against the obtained null distribution.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/#comment-692012")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2026")])]

#text("We actually are willing to accept prompts that encourage non-deterministic strategies that increase the success rate to something intermediate between 50% and 100%, though contestants will have to be responsible for avoiding overfitting such a prompt on the given test set (which will likely cause deterioration in performance when we test against the final evaluation set of problems). In Stage 2 we will in fact explicitly ask the LLM to produce a probability between 0 and 1 that a given implication is true (to be scored by log-loss), though to get full credit they will need to supply a deterministically verifiable certificate such as a Lean proof or an explicit counterexample.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/#comment-692004")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2026")])]

#text("I’m currently at 93.3% for the 1,000 “normal” questions, and 79.9% for the 200 “hard” questions, in terms of accuracy, when using weak model LLMs (not frontier). I’m trying to figure out if the juice is worth the squeeze for further optimization. Do you have ballpark figures for what is good or not? Thanks.")

#text("-Kendon")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/#comment-692011")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2026")])]

#text("We have various benchmark results for this challenge ")#link("https://benchmark.sair.foundation/benchmarks/mathematics-distillation-challenge-equational-theories-stage1")[#text("here")]#text(" that you can compare against. We are currently in the process of implementing a way in which competitors can “publish” their cheatsheets and performance results and hopefully build upon each other’s work; we plan to introduce a rule that if a cheatsheet of one contestant is cited as an inspiration for another contestant that qualifies for Stage 2, then the first contestant will also automatically qualify, to encourage such sharing. Hopefully this will also give more clarity as to what kind of performance is achievable.")

#text("Our final evaluation will be on a different subset of the 22 million equational implications than the 1200 problems provided. The entire set can be downloaded from ")#link("https://teorth.github.io/equational_theories/implications/")[#text("this tool")]#text(" to use for further testing and to avoid overfitting. If it turns out that our initial set becomes saturated, we will tune our evaluation set to be more challenging than that set.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f26b3659fb6b099517ea4c92440487e45a5827ec56ec1f6c443563661325228e-365bf005030384271604c8572a99e64589d790d78c6c4b3392e75b0bab1f085f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Garbid")]], [#link("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/#comment-692022")[#strong[#text("Garbid")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2026")])]

#text("Dear Prof. Tao,")

#text("Thank you for adding the Free-form prompt template — great improvement! Would it be possible to also add a completely clean template with no additions before or after the cheatsheet? This would allow testing of approaches that require full control over what the model sees.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/#comment-692025")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2026")])]

#text("Claude Opus 4.6 in “Extended thinking” mode constructed a counterexample to Problem 1 in approx. 3 minutes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/#comment-692026")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2026")])]

#text("It would be amusing to feed this blog into an AI and distill the knowledge in here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48af5f5c3a719a07c0bd3c447beb41301eac5a81f35ed3dc27d03e13a13e4508-c00319622336897de62f39c3d5d5e7db3c2a17c87dbd4f1be087f832bc49b2a4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George Robinson")]], [#link("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/#comment-692028")[#strong[#text("George Robinson")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2026")])]

#text("Terry—")

#text("The distillation challenge is elegant: compress 22M truths into <10KB so low-resource models hit 55%+. But the binary framing—“true/false”—hides a subtlety. Many equations hold in finite models (say, order < 100) yet fail in infinite ones (free magma, Z-modules). The “yes” isn’t absolute; it’s relative to finiteness.")

#text("A cheap trick: tag each truth with a finite/infinite split, e.g., “associativity: finite yes, infinite counterexample at order ω”. Add a small “doubt band”—say ±0.01 on confidence—for borderline cases where finite proofs exist but infinite extensions diverge. No extra bits needed—just a flag.")

#text("Does it boost? Probably—finite hits are 70-80% of the dataset, infinite the noisy tail. Models learn “check finite first, doubt if infinite”.")

#text("Curious if you’d see that as noise or signal.")

#text("—George")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/#comment-692031")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2026")])]

#text("First, a reminder: any use of AI tools to generate comments must be disclosed.")

#text("For this particular data set, <A HREF=\"")#link("https://teorth.github.io/equational_theories/dashboard/")[#text("https://teorth.github.io/equational_theories/dashboard/")]#text(" it turns out that less than a thousand, or below 0.05%, of the implications change in truth value if one enforces that the magma be finite. For Stage 1, this is too negligible a signal to make a significant impact on the competition. It may become more relevant for Stage 2, in which we also ask to supply proofs or counterexamples, as we now have this small number of negative implications for which no finite counterexample exists.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/177c450127630f3fc5502ea8ddaddd9d5290bfa44b5202bc6e5ab61352028a49-91e6e3665eb4fa0f62575371a4c808f27851c56c8a56b86e57099a56544d3353.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kendonshirley")]], [#link("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/#comment-692036")[#strong[#text("kendonshirley")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2026")])]

#emph[#text("In the Hasse diagram, about 30 nodes near the top sit almost alone. One connection in, one connection out, wormholing straight from layer 1 down to layer 11. These are equations that force every slot to be filled. On an infinite set, two inputs can still land in the same slot. On a finite set that’s impossible. That one difference creates about 1,000 new wormhole connections from those 30 thin nodes to the big attractor nodes at the bottom. The 1,385 nodes in the middle are completely unchanged.")]

#emph[#text("The last unsolved problem (E677 to E255) is one of these connections. We can see in the diagram exactly where it goes: finiteness forces E677 through idempotency, which reaches E255. The path is there. The formal proof is what’s left.")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/177c450127630f3fc5502ea8ddaddd9d5290bfa44b5202bc6e5ab61352028a49-91e6e3665eb4fa0f62575371a4c808f27851c56c8a56b86e57099a56544d3353.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kendonshirley")]], [#link("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/#comment-692037")[#strong[#text("kendonshirley")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2026")])]

#text("I should have said it a bit more cleanly perhaps… the top nodes can’t connect to the middle nodes in the Hesse map, because of the “rule-of-six”. The middle is stable, and full, as all have 6 connections (seems to be a magical lattice type number). So the top node have to reach out to the bottom nodes, which have weak connections (almost anything implies them). In summary: the middle is closed for business, so these finite equations at the top are linked to weak nodes at the bottom (perhaps idempotency for the last unsolved equation for this reason).")

#text("I think this is also why those ~1k have no finite counterexamples, as Professor Tao pointed out. The counterexamples have to be infinite, because every finite magma that satisfies these equations also satisfies the implication.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b932220f0b94bfd8f89cdd412868e5b84d85649af0c460d3c7896906ca88c277-5f6c594c1f2ac8c1655ec0ef650ad972c0973e65b0338ed2f5d016bc124cb1d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carnival of Mathematics 250 – TOM ROCKS MATHS")]], [#link("https://terrytao.wordpress.com/2026/03/13/mathematics-distillation-challenge-equational-theories/#comment-692186")[#strong[#text("Carnival of Mathematics 250 – TOM ROCKS MATHS")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2026")])]

#text("[…] competition is open until April 20th and is open to anyone that registers here. Good […]")
]
