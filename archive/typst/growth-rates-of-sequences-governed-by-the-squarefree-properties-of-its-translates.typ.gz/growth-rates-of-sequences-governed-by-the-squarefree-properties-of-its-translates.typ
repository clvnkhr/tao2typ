// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/12/01/growth-rates-of-sequences-governed-by-the-squarefree-properties-of-its-translates/
// Converted to Typst by tao2typ: "2026-10-14T11:15:05.304335+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Growth rates of sequences governed by the squarefree properties of its translates", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Growth rates of sequences governed by the squarefree properties of its translates")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 December 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/12/01/growth-rates-of-sequences-governed-by-the-squarefree-properties-of-its-translates/")[#text("https://terrytao.wordpress.com/2025/12/01/growth-rates-of-sequences-governed-by-the-squarefree-properties-of-its-translates/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Wouter van Doorn and I have uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/2512.01087")[#text("Growth rates of sequences governed by the squarefree properties of its translates")]#text("“. In this paper we answer a number of ")#link("https://zbmath.org/0472.10002")[#text("questions of Erdős} (")]#link("https://www.erdosproblems.com/1102")[#text("Problem 1102")]#text(" and ")#link("https://www.erdosproblems.com/1103")[#text("Problem 1103")]#text(" on the Erdős problem web site) regarding how quickly a sequence ")#mi("{A = \\{a_1 < a_2 < \\dots\\}}")#text(" of increasing natural numbers can grow if one constrains its translates ")#mi("{n+A}")#text(" to interact with the set ")#mi("{\\mathcal{SF} = \\{1,2,3,5,6,7,10,\\dots\\}}")#text(" of squarefree numbers in various ways. For instance, Erdős defined a sequence ")#mi("{A}")#text(" to have “Property ")#mi("{P}")#text("” if each of its translates ")#mi("{n+A}")#text(" only intersected ")#mi("{\\mathcal{SF}}")#text(" in finitely many points. Erdős believed this to be quite a restrictive condition on ")#mi("{A}")#text(", writing “Probably a sequence having property P must increase fairly fast, but I have no results in this direction.”. Perhaps surprisingly, we show that while these sequences must be of density zero, they can in fact grow arbitrary slowly in the sense that one can have ")#mi("{a_j \\leq j f(j)}")#text(" for all sufficiently large ")#mi("{j}")#text(" and any specified function ")#mi("{f(j)}")#text(" that tends to infinity as ")#mi("{j \\rightarrow \\infty}")#text(". For instance, one can find a sequence that grows like ")#mi("{O(j \\log\\log\\log j)}")#text(". The density zero claim can be proven by a version of the Maier matrix method, and also follows from known moment estimates on the gaps between squarefree numbers; the latter claim is proven by a greedy construction in which one slowly imposes more and more congruence conditions on the sequence to ensure that various translates of the sequence stop being squarefree after a certain point.")

#text("Erdős also defined a somewhat complementary property ")#mi("{Q}")#text(", which asserts that for infinitely many ")#mi("{n}")#text(", ")#emph[#text("all")]#text(" the elements ")#mi("{n+a}")#text(" of ")#mi("{A}")#text(" for ")#mi("{a \\leq n}")#text(" are square-free. Since the squarefree numbers themselves have density ")#mi("{6/\\pi^2}")#text(", it is easy to see that a sequence with property ")#mi("{Q}")#text(" must have (upper) density at most ")#mi("{6/\\pi^2}")#text(" (because it must be “admissible” in the sense of avoiding one residue class modulo ")#mi("{p^2}")#text(" for each ")#mi("{p}")#text("). Erdős observed that any sufficiently rapidly growing (admissible) sequence would obey property ")#mi("{Q}")#text(" but beyond that, Erdős writes “I have no precise information about the rate of increase a sequence having property Q must have.”. Our results in this direction may also be surprising: we show that there exist sequences with property ")#mi("{Q}")#text(" with density exactly ")#mi("{6/\\pi^2}")#text(" (or equivalently, ")#mi("{a_j \\sim \\frac{\\pi^2}{6} j}")#text("). This requires a recursive sieve construction, in which one starts with an initial scale ")#mi("{n}")#text(" and finds a much larger number ")#mi("{n^{\\prime}}")#text(" such that ")#mi("{n^{\\prime}+a}")#text(" is squarefree for most of the squarefree numbers ")#mi("{a \\leq n^{\\prime}}")#text(" (and all of the squarefree numbers ")#mi("{a \\leq n}")#text("). We quantify Erdős’s remark by showing that an (admissible) sequence will necessarily obey property ")#mi("{Q}")#text(" once it grows significantly faster than ")#mi("{\\exp( C j \\log j)}")#text(", but need not obey this property if it only grows like ")#mi("{\\exp(O(j^{1/2} \\log^{1/2} j))}")#text(". This is achieved through further application of sieve methods.")

#text("A third property studied by Erdős is the property of having squarefree sums, so that ")#mi("{a_i + a_j}")#text(" is squarefree for all ")#mi("{i,j}")#text(". Erdős writes, “In fact one can find a sequence which grows exponentially. Must such a sequence really increase so fast? I do not expect that there is such a sequence of polynomial growth.” Here our results are relatively weak: we can construct such a sequence that grows like ")#mi("{\\exp(O(j \\log j))}")#text(", but do not know if this is optimal; the best lower bound we can produce on the growth, coming from the large sieve, is ")#mi("{\\gg j^{4/3}}")#text(". (Somewhat annoyingly, the precise form of the large sieve inequality we needed was not in the literature, so we have an appendix supplying it.) We suspect that further progress on this problem requires advances in inverse sieve theory.")

#text("A weaker property than squarefree sums (but stronger than property ")#mi("{Q}")#text("), referred to by Erdős as property ")#mi("{\\overline{P}}")#text(", asserts that there are infinitely many ")#mi("{n}")#text(" such that all elements of ")#mi("{n+A}")#text(" (not just the small ones) are square-free. Here, the situation is close to, but not quite the same, as that for property ")#mi("{Q}")#text("; we show that sequences with property ")#mi("{\\overline{P}}")#text(" must have upper density strictly less than ")#mi("{6/\\pi^2}")#text(", but can have density arbitrarily close to this value.")

#text("Finally, we looked at a further question of Erdős on the size of an admissible set ")#mi("{A}")#text(". Because the squarefree numbers are admissible, the maximum number ")#mi("{A(x)}")#text(" of elements of an admissible set ")#mi("{A}")#text(" up to ")#mi("{x}")#text(" (")#link("https://oeis.org/A083544")[#text("OEIS A083544")]#text(") is at least the number ")#tao-math("{\\left|{\\mathcal SF} \\cap [x]\\right|}", block: false)#text(" of squarefree elements up to ")#mi("{x}")#text(" (")#link("https://oeis.org/A013928")[#text("A013928")]#text("). It was observed by Ruzsa that the former sequence is greater than the latter for infinitely many ")#mi("{x}")#text(". Erdős asked, “Probably this holds for all large x. It would be of some interest to estimate A(x) as accurately as possible.”")

#text("We are able to show")

#align(center)[#tao-fit-display[#mitex("\\frac{\\sqrt{x}}{\\log x} \\ll A(x) - \\frac{6}{\\pi^2} x \\ll x^{4/5},")]]

#text("with the upper bound coming from the large sieve and the lower bound from a probabilistic construction. In contrast, a classical result of Walfisz shows that")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\mathcal SF} \\cap [x]\\right| - \\frac{6}{\\pi^2} x \\ll x^{1/2} \\exp(-c \\log^{3/5} x / (\\log\\log x)^{1/5}).", block: true)]]

#text("Together, this implies that Erdős’s conjecture holds ")#tao-math("{A(x) > \\left|{\\mathcal SF} \\cap [x]\\right|}", block: false)#text(" for all sufficiently large ")#mi("{x}")#text(". Numerically, it appears that in fact this conjecture holds for all ")#mi("{n>17}")#text(":")

#image("../assets/429030db26bfb7007232f09a48271880337f83b06db11a09744b85f124a90ab3-e61132bd40e3924a9e0c37084730e32f1f2c735b713bef6b9708443f2b3f8adb.png", width: 90%)

#text("However, we do not currently have enough numerical data for the sequence ")#mi("{A(x)}")#text(" to completely confirm the conjecture in all cases. This could potentially be a crowdsourced project (similar to the Erdős-Guy-Selfridge project reported on in ")#link("https://terrytao.wordpress.com/2025/06/03/decomposing-a-factorial-into-large-factors-second-version/")[#text("this previous blog post")]#text(").")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/01/growth-rates-of-sequences-governed-by-the-squarefree-properties-of-its-translates/#comment-689202")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2025")])]

#text("Showkeys is still enabled (I assume not deliberately)")

#emph[#text("[Thanks, we will correct this in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0b423fadc513ac0411dd0514ea026a2d16a4135f02398c6cf3e216875f731e7-f10415d608fb7f54446cf1edbfc12d995d6764cec76d613dd19362a166d378a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Justin Bian")]], [#link("https://terrytao.wordpress.com/2025/12/01/growth-rates-of-sequences-governed-by-the-squarefree-properties-of-its-translates/#comment-689240")[#strong[#text("Justin Bian")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2025")])]

#text("There’s a little grammar thing in the blog post that might bump a little, “Perhaps surprisingly, we show that in fact, while these sequences must be of density zero, they can grow arbitrarily slowly (instead of arbitrary slowly) in the sense that …”, ♥️🍀")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0b423fadc513ac0411dd0514ea026a2d16a4135f02398c6cf3e216875f731e7-f10415d608fb7f54446cf1edbfc12d995d6764cec76d613dd19362a166d378a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Justin Bian")]], [#link("https://terrytao.wordpress.com/2025/12/01/growth-rates-of-sequences-governed-by-the-squarefree-properties-of-its-translates/#comment-689241")[#strong[#text("Justin Bian")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2025")])]

#text("And in para 2 and 3 we have LaTeX problem for Erdős’ name; “Erdős observed that any sufficiently rapidly growing (admissible) sequence would obey property {Q} but beyond that, Erd\\H{o}s (instead of Erdős) writes ‘I have no precise information …” and “A third property studied by Erd\\H{o}s (instead of Erdős) is the property of having squarefree sums, …”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/01/growth-rates-of-sequences-governed-by-the-squarefree-properties-of-its-translates/#comment-696061")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("I am Kenta Kitamura (KitaKen1 on GitHub).")#linebreak()#text("I have prepared a Lean 4 proof of the finite admissible-set conjecture discussed in this post.")

#text("Following the notation of the paper, let A(x) be the maximum of |B ∩ [x]| over all admissible sets B, where [x] = {n ∈ ℕ : n ≤ x}, and let |SF ∩ [x]| count the squarefree integers up to x. ")#linebreak()#strong[#text("Conjecture")]#text(". A(x) > |SF ∩ [x]| for every x ≥ 18. Because A(x) = A(⌊x⌋), the Lean formalization uses a natural-number argument N.")

#text("The answer is ")#strong[#text("affirmative")]#text(". ")#linebreak()#text("More precisely, it proves ")#linebreak()#text("A(N) = |SF ∩ [N]| for 1 ≤ N ≤ 8, ")#linebreak()#text("A(N) > |SF ∩ [N]| for 9 ≤ N ≤ 16, ")#linebreak()#text("A(17) = |SF ∩ [17]| = 12, and ")#linebreak()#text("A(N) > |SF ∩ [N]| for every N ≥ 18.")

#text("Equivalently, for every positive integer N, A(N) = |SF ∩ [N]| if and only if N ∈ {1,…,8,17}.")

#text("The Lean repository follows this notation: the extremal function is `A`, and the squarefree count is named `squarefreeCount`. ")#linebreak()#text("The formal statement, proof, and verification materials are available at the links below. ")#linebreak()#text("GitHub: ")#link("https://github.com/KitaKen1/finite-admissible-sets-lean")[#text("https://github.com/KitaKen1/finite-admissible-sets-lean")]#text(" ")#linebreak()#text("Lean4Web: ")#link("https://live.lean-lang.org/#url=https%3A%2F%2Fraw.githubusercontent.com%2FKitaKen1%2Ffinite-admissible-sets-lean%2Frefs%2Fheads%2Fmain%2Flean4web%2FAdmissibleSetsLean4Web.lean")[#text("open the standalone proof")]#text(" (Lean/mathlib v4.34.0-rc2).")

#text("This finite result is related to, but is not a solution of, the distinct infinite-sequence Erdős Problem #1103. ")#linebreak()#text("AI Usage Disclosure: This work was produced with assistance from ChatGPT and OpenAI Codex using GPT-6 Astra.")
]
