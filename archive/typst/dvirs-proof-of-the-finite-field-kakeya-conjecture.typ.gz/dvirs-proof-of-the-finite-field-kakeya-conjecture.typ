// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T15:16:43.083372+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Dvir’s proof of the finite field Kakeya conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Dvir’s proof of the finite field Kakeya conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 March 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/")[#text("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("One of my favourite unsolved problems in mathematics is the ")#link("http://en.wikipedia.org/wiki/Kakeya_conjecture#Kakeya_conjecture")[#text("Kakeya conjecture")]#text(" in geometric measure theory. This conjecture is descended from the")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("http://en.wikipedia.org/wiki/Kakeya_conjecture#Kakeya_needle_problem")[#strong[#text("Kakeya needle problem.")]]#text(" (1917) What is the least area in the plane required to continuously rotate a needle of unit length and zero thickness around completely (i.e. by ")#mi("360^\\circ")#text(")?")
]

#text("For instance, one can rotate a unit needle inside a unit disk, which has area ")#mi("\\pi/4")#text(". By using a ")#link("http://en.wikipedia.org/wiki/Deltoid_curve")[#text("deltoid")]#text(" one requires only ")#mi("\\pi/8")#text(" area.")

#text("In 1928, Besicovitch showed that that in fact one could rotate a unit needle using an ")#emph[#text("arbitrarily small")]#text(" amount of positive area. This unintuitive fact was a corollary of two observations. The first, which is easy, is that one can ")#emph[#text("translate")]#text(" a needle using arbitrarily small area, by sliding the needle along the direction it points in for a long distance (which costs zero area), turning it slightly (costing a small amount of area), sliding back, and then undoing the turn. The second fact, which is less obvious, can be phrased as follows. Define a ")#emph[#text("Kakeya set")]#text(" in ")#mi("{\\Bbb R}^2")#text(" to be any set which contains a unit line segment in each direction. (See this ")#link("http://www.math.ucla.edu/~tao/java/Besicovitch.html")[#text("Java applet")]#text(" of mine, or the ")#link("http://en.wikipedia.org/wiki/Kakeya_set")[#text("wikipedia page")]#text(", for some pictures of such sets.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem.")]#text(" (Besicovitch, 1919) There exists Kakeya sets ")#mi("{\\Bbb R}^2")#text(" of arbitrarily small area (or more precisely, Lebesgue measure).")
]

#text("In fact, one can construct such sets with zero Lebesgue measure. On the other hand, it was shown ")#link("http://www.ams.org/mathscinet-getitem?mr=272988")[#text("by Davies")]#text(" that even though these sets had zero area, they were still necessarily two-dimensional (in the sense of either ")#link("http://en.wikipedia.org/wiki/Hausdorff_dimension")[#text("Hausdorff dimension")]#text(" or ")#link("http://en.wikipedia.org/wiki/Minkowski_dimension")[#text("Minkowski dimension")]#text("). This led to an analogous conjecture in higher dimensions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Kakeya conjecture.")]#text(" A Besicovitch set in ")#mi("{\\Bbb R}^n")#text(" (i.e. a subset of ")#mi("{\\Bbb R}^n")#text(" that contains a unit line segment in every direction) has Minkowski and Hausdorff dimension equal to n.")
]

#text("This conjecture remains open in dimensions three and higher (and gets more difficult as the dimension increases), although many partial results are known. For instance, when n=3, it is known that Besicovitch sets have ")#link("http://www.ams.org/mathscinet-getitem?mr=1363209")[#text("Hausdorff dimension at least 5/2")]#text(" and (upper) ")#link("http://www.ams.org/mathscinet-getitem?mr=1804528")[#text("Minkowski dimension at least ")#mi("5/2 + 10^{-10}")]#text(". See my ")#link("http://www.ams.org/mathscinet-getitem?mr=1820041")[#text("Notices article")]#text(" for a general survey of this problem (and its connections with Fourier analysis, additive combinatorics, and PDE), my ")#link("http://www.ams.org/mathscinet-getitem?mr=1964819")[#text("paper with Katz")]#text(" for a more technical survey, and ")#link("http://www.ams.org/mathscinet-getitem?mr=1660476")[#text("Wolff’s survey")]#text(" for a systematic treatment of the field (up to about 1998 or so).")

#text("In 1999, ")#link("http://www.ams.org/mathscinet-getitem?mr=1660476")[#text("Wolff proposed")]#text(" a simpler ")#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/")[#text("finite field analogue")]#text(" of the Kakeya conjecture as a model problem that avoided all the technical issues involving Minkowski and Hausdorff dimension. If ")#mi("F^n")#text(" is a vector space over a finite field F, define a ")#emph[#text("Kakeya set")]#text(" to be a subset of ")#mi("F^n")#text(" which contains a line in every direction.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Finite field Kakeya conjecture.")]#text(" Let ")#mi("E \\subset F^n")#text(" be a Kakeya set. Then E has cardinality at least ")#tao-math("c_n \\left|F\\right|^n", block: false)#text(", where ")#mi("c_n > 0")#text(" depends only on n.")
]

#text("This conjecture has had a significant influence in the subject, in particular inspiring work on the ")#emph[#text("sum-product phenomenon")]#text(" in finite fields, which has since proven to have many applications in number theory and computer science. Modulo minor technicalities, the progress on the finite field Kakeya conjecture was, until very recently, essentially the same as that of the original “Euclidean” Kakeya conjecture.")

#text("Last week, the finite field Kakeya conjecture was proven using a ")#link("http://arxiv.org/abs/0803.2336")[#text("beautifully simple argument")]#text(" by ")#link("http://www.wisdom.weizmann.ac.il/~zdvir/")[#text("Zeev Dvir")]#text(", using the ")#emph[#text("polynomial method")]#text(" in algebraic extremal combinatorics. The proof is so short that I can present it in full here.")

#metadata(none) <tao-962013ae09e912dc8c7b>#text("The polynomial method is used to control the size of various sets E by looking at one or more polynomials P which vanish on that set E. This philosophy of course closely resembles that of ")#link("http://en.wikipedia.org/wiki/Algebraic_geometry")[#text("algebraic geometry")]#text(", and indeed one could classify the polynomial method as a kind of “combinatorial algebraic geometry”. An important difference, though, is that in the combinatorial setting we work over fields that are definitely ")#emph[#text("not")]#text(" algebraically closed; in particular, we are primarily interested in polynomials and their zero sets over ")#emph[#text("finite")]#text(" fields. [Also, whereas algebraic geometry is more concerned with ")#emph[#text("specific")]#text(" (and often highly structured) polynomials, the polynomial method requires that one consider rather ")#emph[#text("generic")]#text(" (and usually quite high degree) polynomials.]")

#text("For instance, in high school we learn the following connection between one-dimensional sets E, and polynomials P(x) of one variable:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Factor theorem.")]#text(" Let F be a field, and ")#mi("d \\geq 1")#text(" be an integer. Let ")#mi("F[x]")#text(" denote the polynomials in one variable with coefficients in F.")

#enum(start: 1, 
[#text("If ")#mi("P \\in F[x]")#text(" is a non-zero polynomial of degree at most d, then the set ")#mi("\\{x \\in F: P(x) = 0 \\}")#text(" has cardinality at most d.")],
[#text("Conversely, given any set ")#mi("E \\subset F")#text(" of cardinality at most d, there exists a non-zero polynomial ")#mi("P \\in F[x]")#text(" of degree at most d that vanishes on E.")]
)
]

#text("Thus, to obtain an ")#emph[#text("upper bound")]#text(" on the size of a one-dimensional set E, it would suffice to exhibit a non-zero low-degree polynomial that vanishes on E; conversely, to ")#emph[#text("lower bound")]#text(" the size of E, one would have to show that the only low-degree polynomial that vanishes on E is the zero polynomial. It is the latter type of observation which is of relevance to the finite field Kakeya problem.")

#text("There are analogues of both 1. and 2. above in higher dimensions. For instance, the ")#link("http://en.wikipedia.org/wiki/Schwartz-Zippel_lemma_and_testing_polynomial_identities")[#text("Schwartz-Zippel lemma")]#text(" is a higher-dimensional analogue of 1, as is the ")#link("http://www.ams.org/mathscinet-getitem?mr=1684621")[#text("combinatorial nullstellensatz")]#text(" of Alon, while ")#link("http://www.ams.org/mathscinet-getitem?mr=252400")[#text("Stepanov’s method ")]#text("exploits a higher-dimensional analogue of 2. (")#link("http://en.wikipedia.org/wiki/Bezout%27s_theorem")[#text("Bézout’s theorem")]#text(" from algebraic geometry also qualifies as a variant of 1.) These sorts of techniques and results are collectively referred to as the ")#emph[#text("polynomial method")]#text(" in extremal algebraic combinatorics. For Dvir’s argument, we will need a very simple higher-dimensional version of 2. that comes from basic linear algebra, namely")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma.")]#text(" Let ")#mi("E \\subset F^n")#text(" be a set of cardinality less than ")#mi("\\binom{n+d}{n}")#text(" for some ")#mi("d \\geq 0")#text(". Then there exists a non-zero polynomial ")#mi("P \\in F[x_1,\\ldots,x_n]")#text(" on n variables of degree at most d which vanishes on E.")
]

#strong[#text("Proof.")]#text(" Let V be the vector space of polynomials in ")#mi("F[x_1,\\ldots,x_n]")#text(" of degree at most d. Elementary combinatorics reveals that V has dimension ")#mi("\\binom{n+d}{n}")#text(". On the other hand, the vector space ")#mi("F^E")#text(" of F-valued functions on E has dimension ")#tao-math("\\left|E\\right| < \\binom{n+d}{d}", block: false)#text(". Hence the evaluation map ")#mi("P \\mapsto (P(x))_{x \\in E}")#text(" from V to ")#mi("F^E")#text(" is non-injective, and the claim follows. ")#mi("\\Box")

#text("Dvir’s argument combines this lemma with")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition. ")]#text("Let ")#mi("P \\in F[x_1,\\ldots,x_n]")#text(" be a polynomial of degree at most ")#tao-math("\\left|F\\right|-1", block: false)#text(" which vanishes on a Kakeya set E. Then P is identically zero.")
]

#strong[#text("Proof. ")]#text(" Suppose for contradiction that P is non-zero. We can write ")#mi("P = \\sum_{i=0}^d P_i")#text(", where ")#tao-math("0 \\leq d \\leq \\left|F\\right|-1", block: false)#text(" is the degree of P and ")#mi("P_i")#text(" is the ")#mi("i^{th}")#text(" homogeneous component, thus ")#mi("P_d")#text(" is non-zero. Since P vanishes on E, d cannot be zero.")

#text("Let ")#mi("v \\in F^n \\backslash \\{0\\}")#text(" be an arbitrary direction. As E is a Kakeya set, E contains a line ")#mi("\\{  x + tv: t \\in F \\}")#text(" for some ")#mi("x = x_v \\in F^n")#text(", thus ")#mi("P(x+tv) = 0")#text(" for all ")#mi("t \\in F")#text(". The left-hand side is a polynomial in t of degree at most ")#tao-math("\\left|F\\right|-1", block: false)#text(", and thus vanishes identically by the factor theorem. In particular, the ")#mi("t^d")#text(" coefficient of this polynomial, which is ")#mi("P_d(v)")#text(", vanishes for any non-zero v. Since ")#mi("P_d")#text(" is homogeneous of degree ")#mi("d > 0")#text(", ")#mi("P_d")#text(" vanishes on all of ")#mi("F^n")#text(". Since ")#mi("P_d")#text(" also has degree less than ")#tao-math("\\left|F\\right|", block: false)#text(", repeated application of the factor theorem for each variable in turn (or the ")#link("http://en.wikipedia.org/wiki/Schwartz-Zippel_lemma_and_testing_polynomial_identities")[#text("Schwarz-Zippel lemma")]#text(", which is much the same thing) shows that ")#mi("P_d = 0")#text(", a contradiction. ")#mi("\\Box")

#strong[#text("Remark.")]#text(" The point here is that a low-degree polynomial which vanishes on a line must also vanish on the ")#link("http://en.wikipedia.org/wiki/Point_at_infinity")[#text("point at infinity")]#text(" where the line touches the ")#link("http://en.wikipedia.org/wiki/Hyperplane_at_infinity")[#text("hyperplane at infinity")]#text(". Thus a polynomial which vanishes on a Kakeya set vanishes at the entire hyperplane at infinity. One can then divide out the defining polynomial for that hyperplane and repeat the process to conclude that the polynomial vanishes identically. ")#mi("\\diamond")

#text("Combining the lemma and the proposition we obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary. ")]#text(" Every Kakeya set in ")#mi("F^n")#text(" has cardinality at least ")#tao-math("\\binom{\\left|F\\right|+n-1}{n}", block: false)#text(".")
]

#text("Since ")#tao-math("\\binom{\\left|F\\right|+n-1}{n} = \\frac{1}{n!} \\left|F\\right|^n + O_n( \\left|F\\right|^{n-1} )", block: false)#text(", this establishes the finite field Kakeya conjecture.")

#text("This bound seems to be quite tight. For instance, it gives the lower bound of ")#tao-math("\\frac{\\left|F\\right|(\\left|F\\right|+1)}{2}", block: false)#text(" for Kakeya sets in ")#mi("F^2")#text(" (which was already implicitly observed by Wolff). The best known lower bound currently in this case is ")#tao-math("\\frac{\\left|F\\right|(\\left|F\\right|+1)}{2} + \\frac{5}{14} \\left|F\\right| + O(1)", block: false)#text(", due ")#link("http://arxiv.org/abs/math/0607734")[#text("to Cooper")]#text(" (see also a related paper ")#link("http://arxiv.org/abs/math/0510356v2")[#text("by Faber")]#text("); in the other direction, an example of ")#link("http://www.ams.org/mathscinet-getitem?mr=2031165")[#text("Mockenhaupt and myself")]#text(" shows that such sets can have cardinality ")#tao-math("\\frac{\\left|F\\right|(\\left|F\\right|+1)}{2} + \\frac{1}{2} \\left|F\\right| + O(1)", block: false)#text(".")

#text("It now seems sensible to revisit other problems in extremal combinatorics over finite fields to see if the polynomial method can yield results there. Certainly close relatives of the Kakeya conjecture (e.g. the Nikodym set conjecture, or the Kakeya maximal function conjecture) should now be establishable by these methods. On the other hand, there are other problems (such as the sum-product problem, ")#link("http://en.wikipedia.org/wiki/Szemeredi-Trotter_theorem")[#text("Szemerédi-Trotter type theorems")]#text(", and distance set problems) which are sensitive to the choice of field F (and in particular, whether that field contains a subfield of index 2); see this ")#link("http://www.ams.org/mathscinet-getitem?mr=2053599")[#text("paper of Bourgain, Katz, and myself")]#text(" for further discussion. It would be interesting to see if there are ways to adapt the polynomial method in order to detect the existence of subfields.")

#text("Unfortunately, the polynomial method is extremely dependent on the algebraic nature of the finite field setting and does not seem to extend directly to the Euclidean case (though there may be a chance that they may extend instead to certain problems in discrete combinatorial incidence geometry, such as the ")#link("http://www.ams.org/mathscinet-getitem?mr=1280600")[#text("“joints” problem of Sharir")]#text(", perhaps by using various embedding theorems). On the other hand, this result lends significant ")#emph[#text("indirect")]#text(" support to the Euclidean Kakeya conjecture; in particular, the result morally rules out any “algebraic” counterexample to the Euclidean conjecture, since a highly algebraic example to this conjecture would likely be adaptable to the finite field setting. (The examples of zero measure Kakeya sets in the Euclidean plane have no finite field analogue, but they are non-algebraic in nature, and in particular take advantage of the multiple scales available in the Euclidean setting.)")

#text("[")#emph[#text("Update")]#text(", Mar 24: Proof of proposition expanded.]")

#text("[")#emph[#text("Update")]#text(", Mar 25: See also these posts by ")#link("http://ilaba.wordpress.com/2008/03/23/the-kakeya-problem-in-finite-fields/")[#text("Izabella Laba")]#text(" and ")#link("http://quomodocumque.wordpress.com/2008/03/25/give-the-people-who-like-the-kakeya-problem-what-they-want/")[#text("Quomodocumque")]#text(".]")

#heading(level: 1)[#text("Comments (45)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-27590")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2008")])]

#text("Beautiful!")

#text("I would certainly call this an argument in algebraic geometry, by the way — algebraic geometers certainly do work over finite fields and not only over their algebraic closures! And arguments like the one presented here, where one shows existence of a polynomial vanishing on some specified set (i.e. a variety passing through some set of points) are quite common, even when the variety is, as you describe it, “generic” and not some specific algebraic set contemplated in advance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-27597")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2008")])]

#text("Dear JSE,")

#text("Well, you’re much closer to algebraic geometry as it is currently practised than I am, so I will cede the point (my knowledge of the subject sort of stops at the graduate level). It does seem hard to draw a sharp line where the algebraic geometry stops and the combinatorics begins. On the other hand, there does seem to be some differences in emphasis between this type of algebraic extremal combinatorics and more classical algebraic geometry. For instance, in the combinatorial approach one tends to study polynomials individually (except when it is necessary to invoke dimension-counting arguments, as in the above lemma), whereas in classical algebraic geometry one tends to collect polynomials into ideals or rings and manipulate those objects instead. It also seems that many of the fundamental theorems in algebraic geometry (e.g. Hilbert’s nullstellensatz) are not directly useful for combinatorics (due in part to their reliance on algebraic closure, and also because the effective bounds associated with such theorems are sometimes a bit poor), though there are often very useful substitutes (e.g. Alon’s combinatorial nullstellensatz) which can be used instead. Still, the two subjects are definitely extremely close to each other (as I said above, one can certainly classify the polynomial method as belonging to the broader subject of algebraic geometry, even if it does not exactly fit into the classical approach to the subject).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2fec6cda624d52107a9ca52311a6e3b3cad0f6434789ff44cfdc285b2e0ffb7f-f83f3bcd84fabb4e452d15e87221de7935af17d8fcb74d23c84019c0917a31af.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of carlbrannen")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-27600")[#strong[#text("carlbrannen")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2008")])]

#text("Okay, intuitively I understand the 2-d case. But only by translating it into blue-collar terms. What’s the minimum tread area in which you can turn a forklift 360 degrees? (If you only count area where the front wheels diverge from the paths of the rear wheels or vice versa.) The solution is to not turn the steering wheel much, but to take long cuts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2f8227a846b36e3e309bf24cf32c945871ca072445ad29d145457e6656bff2b-ca21191d89242f09621f597bdb4eacf9d9f2f92a71e86a08c5d40967c298da18.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ninguem")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-27608")[#strong[#text("ninguem")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2008")])]

#text("There is something missing in the proof of the proposition. You proved that P_d vanishes for all v nonzero in F^n. That is not the same as P_d being identically zero since F is finite. I guess that should follow from d < |F| but is not automatic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-27609")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2008")])]

#text("Good point; I’ve amended the proof of the proposition accordingly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-27626")[#strong[#text("Give the people (who like the Kakeya problem) what they want « Quomodocumque")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2008")]

#text("[…] the people (who like the Kakeya problem) what they want 25Mar08 Wow — make one comment on Terry’s blog and you get a ton of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-27650")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2008")])]

#text("Here’s another question, in the vein of “how seriously should we take the analogy between the finite field situation and the Euclidean situation”?")

#text("(as usual, all math here is done on the fly and should not be considered checked.)")

#text("Suppose that you fix some constants c_n and consider subsets S of F_q^n with cardinality at most c_n q^d; is this what you would take as a model for a subset of R^n with Hausdorff dimension at most d?")

#text("Now one can find a polynomial f of degree on order q^{d/n} vanishing on S.")

#text("Let L be a line intersecting S in more than q^{d/n} points. Then f must vanish identically on L. So f also vanishes at the intersection of L with H, the hyperplane at infinity.")

#text("As in Dvir’s argument we can represent f projectively by a homogeneous form of degree at most q^{d/n} which doesn’t vanish identically on H. So its vanishing on H is contained in a hypersurface of degree at most q^{d/n}, which should have at most q^{n -2 + d/n} points or so. So this is an upper bound for the number of directions in which there exists a line with “excess intersection” with S in this sense.")

#text("So here’s a question — Let S be a subset of R^n of Hausdorff dimension d, and let D be the set of directions in which there exists a line L such that L intersect S has Hausdorff dimension greater than d/n. Do you expect it to follow that D has Hausdorff dimension at most n-2+d/n?")

#text("This evidently implies the Kakeya conjecture; do you see it as essentially the same, or is this a much stronger statement?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-27655")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2008")])]

#text("The standard conjecture for this is the Kakeya maximal function conjecture. Ignoring factors of ")#mi("\\log q")#text(", the finite field version of this conjecture is the following: if S is a set and D is a set of directions in which there exists a line L that intersects S in at least k points, then")

#tao-math("\\left|D\\right| \\ll \\left|S\\right| q^{n-1} / k^n.", block: false)#text(" (*)")

#text("The Kakeya set conjecture essentially corresponds to the case in which ")#mi("k=q")#text(" and ")#tao-math("\\left|D\\right|=q^{n-1}", block: false)#text(". Other extreme cases include the case ")#tao-math("\\left|S\\right|=k=1, \\left|D\\right|=q^{n-1}", block: false)#text(" (a point) and ")#tao-math("\\left|S\\right|=k=q, \\left|D\\right|=1", block: false)#text(" (a line).")

#text("In Euclidean space, the analogue of the conjecture is as follows: if ")#mi("0 < \\delta < 1")#text(", S is a ")#mi("\\delta")#text("-separated set in ")#mi("{\\Bbb R}^n")#text(" and D is a ")#mi("\\delta")#text("-separated set of directions in which there exists a unit line segment which comes within ")#mi("\\delta")#text(" of at least k points in S, then")

#tao-math("\\left|D\\right| \\ll \\left|S\\right| (1/\\delta)^{n-1} / k^n", block: false)#text(" (**)")

#text("(i.e. ")#mi("1/\\delta")#text(" basically plays the role of q in the Euclidean case). Morally speaking (ignoring technicalities regarding the distinction between Hausdorff dimension, lower Minkowski dimension, and upper Minkowski dimension), (**) implies that")

#mi("\\dim(D) \\leq \\dim(S) + n - 1 - n s")#text(" (***)")

#text("whenever D is a family of lines which intersect S in a set of dimension s.")

#text("The estimate (**) is best possible in all parameter ranges, as one can see by considering examples in which S is a ball or a tube. (It is not however believed that (***) is sharp; there is a conjecture of Wolff on this relating to “Furstenberg sets”, and in fact a paper of myself and Nets Katz, combined with a “discretised sum-product theorem” of Bourgain, gives a tiny improvement to (***) in the case n=2, s=1/2, dim(D)=1.) However, it appears that (*) is only sharp at certain discrete parameter regimes, e.g. E needs to be an integer power of d. Your argument suggests there is in fact some sharp transition phenomena, e.g. if ")#tao-math("\\left|E\\right|=q^d", block: false)#text(" and ")#mi("k = c q^{d/n}")#text(" then one expects only the trivial bound ")#tao-math("\\left|D\\right| \\leq q^{n-1}", block: false)#text(" when c is a small constant (consider for instance the case d=0), but you obtain the refinement ")#tao-math("\\left|D\\right| \\ll q^{n-2+d/n}", block: false)#text(" when c is a large constant.")

#text("So it looks like your argument should be able to not only establish the Kakeya maximal function conjecture in the finite field case, but even indicate some parameter ranges in which an improvement is possible! But such improvement would definitely be a phenomenon specific to finite fields.")

#text("The survey article of Wolff mentioned in the main post is perhaps still the best reference for these things, in case you want to know more.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2fec6cda624d52107a9ca52311a6e3b3cad0f6434789ff44cfdc285b2e0ffb7f-f83f3bcd84fabb4e452d15e87221de7935af17d8fcb74d23c84019c0917a31af.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of carlbrannen")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-27661")[#strong[#text("carlbrannen")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2008")])]

#text("As I figured out while driving over to the airport, my comment on understanding the 2-d case intuitively is completely wrong. Let me try and make a better intuitive explanation.")

#text("(1) Suppose instead of turning the needle around its center, you pick a point perpendicular to the needle and swing the needle around that point. This will sweep out an annulus. As the point you sweep around gets farther from the needle, the annulus gets thinner, but longer. It turns out that these two effects cancel, the area stays the same (at least to first order).")

#text("(2) When you rotate the needle by x radians, you inevitably sweep out an area of ")#mi("x/4")#text(". To make the total area swept out be small, you have to arrange the swept areas so that they overlap. This is very non intuitive.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/42c313fab04e3cb67c81d9af78067bea2d77fb0aeb10a80078f4a792449870a3-932f3c6c05070b2c033f69b3f994c17b1c341210a923bb4ec4d3b3951a8f4eb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nikolay Vereshchagin")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-27673")[#strong[#text("Nikolay Vereshchagin")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2008")])]

#text("I have a question related to Kakeya’s sets and proofs of Kakeya’s conjecture.")

#text("Let L be a collection of lines in F^n such that L has exactly one line going in each direction (thus L has about |F|^{n-1} lines).")#linebreak()#text(" Let E stand for the Kakeya set consisting of all points in lines from L.")#linebreak()#text(" Consider the following random variable X_L in E: we pick at random a line in L and output a random point lying on that line. The Shannon entropy H(X_L) of this random variable is at most log |E|. We need a lower bound for H(X_L). My question is: is it always true that H(X_L) is about n log|F| (say, up to an additive O(n log log |F|) term)? The truth of Kakeya’s")#linebreak()#text(" conjecture gives a hope that this might be true.")

#text("We need an answer to this question")#linebreak()#text(" to analyse our “geometric” protocol to generate strings of large Shannon entropy (")#link("http://lpcs.math.msu.su/~ver/papers/rsf.pdf")[#text("http://lpcs.math.msu.su/~ver/papers/rsf.pdf")]#text(")")#linebreak()#text(" Previously, we used Gerd and Tao’s proof of the lower bound |E|>|F|^{n/2+1} and showed that H(X_L)>(n/2+1)log|F|.")

#text("I do not see how to use Dvir’s arguments.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f107feef30f63efadc42feae23a7dd31c3777a59b9a42e968a0c5fa5c85f99cc-a8cfddbb3b20e8e8db1e5e8bc342323c8274c4eb5c9ca71916a68002e2687116.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zeev Dvir")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-27677")[#strong[#text("Zeev Dvir")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2008")])]

#text("To Nikolay,")

#text("It is possible to prove the claim that you stated using a similar argument to the one I used for Kakeya sets. It actually shows that X_L is close to having min-entropy (1-eps)*n*log(q) for every eps>0 (provided q >~ n^{1/eps}).")

#text("This argument (in a slightly more complicated setting, involving curves) will appear soon in a paper I am writing with Avi Wigderson (the paper deals with application to the construction of randomness extractors).")

#text("Best,")#linebreak()#text(" Zeev.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/826a2728424b30ad8cc83000d2bfd8744edcd1bafba060e1c70b63281a0934f6-5e3de4a3d5bde314bee2c1b42ac7f851cee463773970099eaeb046cc61a7dd19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of harrison")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-27705")[#strong[#text("harrison")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2008")])]

#text("Prof. Tao (or Mr. Dvir, whoever can answer),")

#text("It was pointed out to me that the argument is fairly similar to the encryption/decryption algorithms for Reed-Solomon codes. Is this coincidental, is it just a consequence of the polynomial method, or is there a deeper connection that I’m missing?")

#text("Thanks,")

#text("Harrison")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-27825")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2008")])]

#text("(Wow!!)")

#text("Is there an analog to the finite Kakeya problems for more combinatorial notions of the term “lines” like those used in the Hales-Jewett theorem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-27826")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2008")])]

#text("Dear Harrison,")

#text("One can certainly interpret this proof in coding language; the proposition in the post can be viewed as an assertion that a Reed-Solomon code of a certain order can be uniquely decoded by looking at the restriction of that code to a Kakeya set, and the Lemma can be viewed as a lower bound on the capacity of that code. I believe that this proof of Kakeya was motivated by some computer science considerations that are somewhat related to coding theory, but I do not know the full details.")

#text("Dear Gil: Well, there is of course the density Hales-Jewett theorem of Furstenberg and Katznelson, which (viewed contrapositively) is the assertion that if a set contains a point in every combinatorial line, then it has asymptotically full measure, which is an assertion of a vaguely Kakeya-type nature. Of course, algebraic methods such as the polynomial method are unlikely to apply directly to such a combinatorial situation that has no obvious algebraic structure, but it is still an interesting question as to whether some other proof of the density Hales-Jewett theorem (including, perhaps, a simplified ergodic theory proof) is available.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-27830")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2008")])]

#text("Right, but density H-J is only a vaguely Kakeya type question. If you insist on having a “combinatorial line” in each “direction” how large should the set be? (There are various combinatorial notions of lines/direction you can take but as the condition is weaker maybe the set need not be so very large. )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-27831")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2008")])]

#text("Hmm, now that I think about it, there is a significant difference between finite field Kakeya and HJ. Both take place on a discrete cube ")#mi("{}[k]^d")#text(" (in the finite field case we identify [k] with a finite field). But Kakeya is only non-trivial in the regime when d is fixed and k goes to infinity, while in contrast Hales-Jewett is only interesting in the regime when k was fixed and d goes to infinity. For bounded d the combinatorial lines split into easily understood families and there is not much of interest to say.")

#text("From past experience with HJ I would have to say that how one defines the “number” of lines involved is going to be very important; a naive notion of cardinality is probably not the right one (it assigns too much weight to those lines with about half of the coordinates being active). A randomly formulated problem in this area is likely to be either trivially true, trivially false, or otherwise not terribly interesting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-27851")[#strong[#text("Gil")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2008")])]

#text("Dear Terry,")

#text("One nice problem for practicing discretization+polynomial method or other methods is this: What is the largest measure of a subset ")#mi("X")#text(" of the ")#mi("d")#text("-sphere which does not contain two orthogonal vectors. a natural guess is the twice the measure of a spherical cup of radius ")#mi("\\pi/4")#text(". When ")#mi("d")#text(" is large this is roughly a fraction ")#mi("(1/\\sqrt {2}) ^d")#text(" of the total measure of the sphere.")

#text("Now, the corresponding problem for the discrete cube (when the dimension is 4 times a prime number) can be solved (up to a factor 2 or so) by the polynomial method based on calculations over the field of 2 elements. This result translates to a result for the Euclidean question which is the best known but it is far from the conjecture. (It gives")#linebreak()#text(" measure ")#mi("2^{ (H(1/4)-1) d}")#text(". ) This is essentially Frankl-Wilson’s theorem.")

#text("One can try to discretize differently and use the polynomial methods for other fields and finding an appropriate “weighting” is indeed part of the difficulty but so far nobody managed to do it. There are promising competing methods which at present gives weaker bounds.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seva")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-28325")[#strong[#text("Seva")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2008")])]

#text("Actually, why is “Kakeya only non-trivial in the regime when ")#mi("d")#text(" is fixed and ")#mi("k")#text(" goes to infinity”? What is the smallest size of a subset of ")#mi("F_3^r")#text(", containing a line in every direction? (The field ")#mi("F_3")#text(" seems to be particularly interesting in this context as in this case the notion of a line is identical to that of a three-term arithmetic progression, not to mention that this is the first non-trivial case.) The trivial lower bound for the smallest size of such a set is ")#mi("3^{r/2}")#text(", and it seems that a random subset of $F_3^r$ of size at least ")#mi("3^{(2/3+\\epsilon)r}")#text(" possesses the property in question with positive probability. Isn’t the gap between ")#mi("3^{r/2}")#text(" and ")#mi("3^{(2/3+\\epsilon)r}")#text(" worth investigation?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c7c03e7ab8c60f478a2eb55a393772121cb17999c03c19ef6743cfcf0e310f3-1290859cb7066c5931d0ac491c4e466fa020ddc660a280de414a7f93a6c96f23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Clifford Smyth")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-29528")[#strong[#text("Clifford Smyth")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2008")])]

#text("Hi,")

#text("What are some upper bounds on the minimum size of a Kakeya set in F_q^n?")

#text("I found one of size (q-1)^n + 2^n – 1. Surely there are smaller ones?")

#text("Cliff")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-29605")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2008")])]

#text("Dear Seva: You do have a point. Previous literature on the Kakeya problem did not seek to control the dependence of constants on the dimension, and so there were basically no interesting non-trivial results in the asymptotically high dimensional regime, but it is certainly possible to pose these questions in this regime. Very different techniques would probably be needed; in particular, in analogy with the Hales-Jewett theory, one might expect methods from ergodic theory to start playing some role. (In the F_3 case, it’s also possible, by analogy with the theory surrounding Roth’s theorem, that Fourier-analytic and additive-combinatorial techniques could also be effective.)")

#text("Dear Cliff,")

#text("In two dimensions, there are reasonably sharp results (giving sets close to q^2/2) in")

#link("http://arxiv.org/abs/math/0510356")[#text("http://arxiv.org/abs/math/0510356")]#linebreak()#text(" ")#link("http://arxiv.org/abs/math/0607734")[#text("http://arxiv.org/abs/math/0607734")]

#text("(and see also a comment in")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://quomodocumque.wordpress.com/2008/03/25/give-the-people-who-like-the-kakeya-problem-what-they-want/")[#text("Give the people (who like the Kakeya problem) what they want")]
]

#text(")")

#text("In higher dimensions, the best construction I know of uses the two-dimensional construction, combined with the trivial observation that the Cartesian product of two Kakeya sets is still a Kakeya set (in a higher dimensional space, of course). This gives about q^d / 2^{d/2} in the case when d is even, and slightly worse than this when d is odd. This is a fair distance away from Dvir’s bound, which is about q^d/d!. So there is still a little bit of room to close the gap here, and in particular to settle the question of whether the density of Kakeya sets needs to decay faster than exponentially (i.e. it is asymptotically less than c^d q^d as d -> infinity for any c > 0).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47cf536a51631ec4b38ff424e5181f3f5dfbe6e46f54bd6a2be37ee99ef9ee1f-6939e0a3def1a37cf5300a1228d1dff321cf60c80699f8b36743c1243685ddc8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Simeon Ball")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-29638")[#strong[#text("Simeon Ball")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2008")])]

#text("The bound in the two-dimensional case for q odd was recently improved to q(q+1)/2+(q-1)/2 by Blokhuis and Mazzocca.")

#text("This bound is tight as seen by the conic construction. Let C be a conic in PG(2,q), L the line at infinity, and m a bisecant to C (a line is incident with two points of the conic). Let E be the external points to C (which are the points that are incident with two tangents of C). Then the set")#linebreak()#text(" (E U C U m) \\ L is a Kakeya (Besikovitch) set with q(q+1)/2+(q-1)/2 points.")

#text("Moreover, Blokhuis and Mazzocca have shown that all such sets that attain the bound come from this construction. The bound follows from an old result of Jamison. I have detailed this in")

#link("http://www-ma4.upc.es/~simeon/kakeya.pdf")[#text("Click to access kakeya.pdf")]

#text("To classify the sets meeting the bound, you use similar arguments to those used by Segre in the fifties to prove that a set of q+1 points in PG(2,q), q odd, with the property that every line is incident with at most two points of the set, is a conic. The proof of this has been done by Blokhuis and Mazzocca, although I’m not sure this preprint is available yet.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47cf536a51631ec4b38ff424e5181f3f5dfbe6e46f54bd6a2be37ee99ef9ee1f-6939e0a3def1a37cf5300a1228d1dff321cf60c80699f8b36743c1243685ddc8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Simeon Ball")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-29723")[#strong[#text("Simeon Ball")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2008")])]

#text("I forgot to mention in the previous post that L should be a tangent to C at a point P and that m is incident with P.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3af734de1a904d0463d5cc51fc6d9174b884a7d754e47c2f45d2e51577fadbec-94f43da60127cc8743557c5f99cde3014515d2216d6ac48d7d3e2daa90ad88c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Francesco Mazzocca")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-31317")[#strong[#text("Francesco Mazzocca")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2008")])]

#text("The results by A.Blokhuis and F.Mazzocca about the finite Kakeya problem in two dimensional case, cited by Simeon Ball, will appear on the last volume of Bolyai Society Mathematical Studies dedicated to L.Lovász’s 60th birthday ( ")#link("http://www.springer.com/math/numbers/book/978-3-540-85218-6?detailsPage=toc")[#text("http://www.springer.com/math/numbers/book/978-3-540-85218-6?detailsPage=toc")]#text(" )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-32010")[#strong[#text("Plans and Updates « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2008")]

#text("[…] on the finite field Kakeya problem. The proof was extremely simple to start with (see Tao’s post ) and Zvi’s presentation was even simpler. It is a very interesting question how, given […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Kakeya conjecture and the Ham Sandwich theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-33676")[#strong[#text("The Kakeya conjecture and the Ham Sandwich theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2008")])]

#text("[…] as a partial analogue of Dvir’s arguments in the finite field setting (which I discussed in this blog post) to the Euclidean setting; in particular, both arguments rely crucially on the ability to create a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathaaron")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-33822")[#strong[#text("mathaaron")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2008")])]

#text("some progresses toward these problems")

#link("http://arxiv.org/abs/0812.1043")[#text("http://arxiv.org/abs/0812.1043")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5c29e84c0c4597e0c074f4339f7ff2487033be1e0762c8ac692f11533bd6c3ef-853569db70f48f661553e8a39bae130f5ae188cdf4a11319a8e2f3476ab44e07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mike")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-34101")[#strong[#text("mike")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2008")])]

#text("Dr. tau,")#linebreak()#text(" have you seen Michael anthony’s solution to Riemann Hypothesis?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Kakeya set and maximal conjectures for algebraic varieties over finite fields « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-36627")[#strong[#text("The Kakeya set and maximal conjectures for algebraic varieties over finite fields « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2009")])]

#text("[…] of Dvir and later authors on the Kakeya problem in finite fields, which I have discussed in this earlier blog post. Dvir established the following: Kakeya set conjecture for finite fields. Let F be a finite […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Recent progress on the Kakeya conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-38692")[#strong[#text("Recent progress on the Kakeya conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2009")])]

#text("[…] analogue of the low-degree algebraic geometry used in the incidence geometry approaches (see also this blog post for more discussion). Indeed, one can view Dvir’s argument in the incidence geometry […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Guth-Katz bound on the Erdős distance problem « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-48201")[#strong[#text("The Guth-Katz bound on the Erdős distance problem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2010")])]

#text("[…] method (similar to, say, how Dvir proved the finite fields Kakeya conjecture, as discussed in this previous blog post). As such, the result in fact holds over an arbitrary field, but we will stick to for sake of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Szemeredi-Trotter theorem via the polynomial ham sandwich theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-50314")[#strong[#text("The Szemeredi-Trotter theorem via the polynomial ham sandwich theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2011")])]

#text("[…] arbitrary fields (not just over ), and can be proven by a simple linear algebra argument (see e.g. this previous blog post). However, the cell decomposition is more flexible than this algebraic fact due to the ability to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-90598")[#strong[#text("On a short proof of Schwartz-Zippel lemma – Kenneth Shum's scrapbook")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2011")]

#text("[…] by a solution to Kakeya set over finite field (see e.g. Terry Tao’s post), Dana Moshkovitz recently give an alternate proof of the Schwartz-Zippel lemma, (Schwartz-Zippel) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-116792")[#strong[#text("“Kakeya sets over non-archimedean local rings,” by Dummit and Hablicsek « Quomodocumque")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2011")]

#text("[…] this point, if you haven’t thought about the Kakeya conjecture before, you might want to read Terry’s long expository post about the Kakeya conjecture and Dvir’s theorem; I cannot do it any better […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-165611")[#strong[#text("Two Short Proofs of Hard Theorems « murphmath")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2012")]

#text("[…] Terry Tao’s blog post […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed7571e22dd00bf24cffea80472f8ec320b3401a0109c7102a69fdd9742ebf1a-920070984b07e652b6bea948f42739208e48678997192cf26684f0fd5c47963d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Punting in clearings of arbitrarily small Lebesgue measure | Complex Projective 4-Space")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-248602")[#strong[#text("Punting in clearings of arbitrarily small Lebesgue measure | Complex Projective 4-Space")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("[…] a beautiful proof (which would certainly win Bradley’s elegance prize!), again mentioned in an article by Terry […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Algebraic combinatorial geometry: the polynomial method in arithmetic combinatorics, incidence combinatorics, and number theory | What's new")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-249019")[#strong[#text("Algebraic combinatorial geometry: the polynomial method in arithmetic combinatorics, incidence combinatorics, and number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2013")])]

#text("[…] Alon is also another relatively early use of the polynomial method. More recently, it underlies Dvir’s proof of the Kakeya conjecture over finite fields and Guth and Katz’s near-complete solution to the Erdos distance problem in the plane, and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54587362e3e90e4212276c9a7abec5f6aee9a3619e078f2d3cb3d6bd98733259-0860c041e6988901b219c05722c10496b87ea26324c4aedfa4b2a19bc77a3441.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohammad")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-251464")[#strong[#text("Mohammad")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2013")])]

#text("Would you mind clarifying the following intuition ” …take advantage of the multiple scales available in the Euclidean setting” ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-468706")[#strong[#text("Ellenberg’s announcement of a solution to the cap-set problem | in theory")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2016")]

#text("[…] that had resisted attacks from powerful Fourier-analytic proofs, and was solved by Zeev Dvir with a relatively simple application of the polynomial method. One may hope that the method has not yet exhausted its […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A symmetric formulation of the Croot-Lev-Pach-Ellenberg-Gijswijt capset bound | What's new")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-468722")[#strong[#text("A symmetric formulation of the Croot-Lev-Pach-Ellenberg-Gijswijt capset bound | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("[…] method in superficially similar problems such as the finite field Kakeya problem (discussed in this previous post), it was natural to wonder that this method could be applicable to the cap set problem (see for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-472234")[#strong[#text("Introduction to the polynomial method (and other similar things) | Short, Fat Matrices")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2016")]

#text("[…] that this differs slightly from Terry Tao’s exposition.) To do this, we suppose to the contrary that . Then by the previous result, there exists a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-546654")[#strong[#text("Or Ordentlich, Oded Regev and Barak Weiss: New bounds for Covering Density! | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2020")]

#text("[…] aspect of the proof is the use of finite field Kakaya-type questions. Since the breakthrough by Zeev Dvir, many people had hopes for applications from the finite fields results to the Euclidean setting (in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb93277246d27483db84dbdf8b958efe326e092bd255e477b90b7e0ecb44ab12-86f20ba181a3633c7728b3039c49825d1088a9248cab6746d91b450b369d6de0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kakeya 转针问题 & 何为维度 – 南外数学逻辑与生活社")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-637987")[#strong[#text("Kakeya 转针问题 & 何为维度 – 南外数学逻辑与生活社")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2021")])]

#text("[…] Dvir 对有限 Kakeya 问题的优美证明 — ")#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/")[#text("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-660337")[#strong[#text("Barnabás Janzer: Rotation inside convex Kakeya sets | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2022")]

#text("[…] problem is the conjecture that every Kakeya set in has Housdorff dimension . in 2008, Zeev Dvir found a simple remarkable proof for a finite field analog of the conjecture. Finding possible connections between the finite field […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-688308")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2025")])]

#text("I’ve been exploring a variant of the Kakeya problem inspired by practical constraints on motion. Specifically, I’m considering a version where a unit-length needle must rotate through all directions (i.e., generate a Kakeya set), but ")#strong[#text("its motion is constrained by a finite fuel budget")]#text(".")

#text("In this setup:")

#list(
[#strong[#text("Rotating")]#text(" the needle by an angle Δθ incurs a fuel cost proportional to ∣Δθ∣, and")],
[#strong[#text("Translating")]#text(" the needle from one pivot to another incurs cost proportional to the Euclidean distance moved.")]
)

#text("The goal is to construct a path (sequence of rotations and translations) that allows the needle to sweep through all directions while minimizing total fuel consumption, or staying under a fixed budget.")

#text("I’m interested in whether this “fuel-constrained Kakeya problem” still admits near-zero-area constructions, or whether the fuel constraint regularizes the geometry in a way that fundamentally limits fractality or compressibility.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/#comment-688309")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2025")])]

#text("This variant looks related to the theory of rectifiability and Favard length. It is an old observation of Kahane that the two-dimensional Kakeya problem can also be reformulated in terms of one-dimensional projections of subsets of the plane; in particular, the existence of Kakeya sets of zero measure corresponds, roughly speaking, to the existence of 1-dimensional subsets of the plane (such as the product of two Cantor sets of dimension 1/2) in which almost every projection has measure zero (i.e., the Favard length vanishes). Your finite fuel consumption requirement is akin to a rectifiability condition on such a set, which will enforce positive Favard length.")

#text("One starting point to learn about this is this recent Notices article by Krystal Taylor: ")#link("https://www.ams.org/journals/notices/202411/noti3079/noti3079.html")[#text("https://www.ams.org/journals/notices/202411/noti3079/noti3079.html")]
]
]
