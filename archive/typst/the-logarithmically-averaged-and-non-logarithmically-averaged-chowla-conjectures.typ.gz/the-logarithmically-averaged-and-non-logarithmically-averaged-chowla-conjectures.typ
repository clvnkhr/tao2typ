// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/10/20/the-logarithmically-averaged-and-non-logarithmically-averaged-chowla-conjectures/
// Converted to Typst by tao2typ: "2026-10-14T16:38:12.584501+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The logarithmically averaged and non-logarithmically averaged Chowla conjectures", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The logarithmically averaged and non-logarithmically averaged Chowla conjectures")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 October 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/10/20/the-logarithmically-averaged-and-non-logarithmically-averaged-chowla-conjectures/")[#text("https://terrytao.wordpress.com/2017/10/20/the-logarithmically-averaged-and-non-logarithmically-averaged-chowla-conjectures/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{\\lambda: {\\bf N} \\rightarrow \\{-1,1\\}}")#text(" be the ")#link("https://en.wikipedia.org/wiki/Liouville_function")[#text("Liouville function")]#text(", thus ")#mi("{\\lambda(n)}")#text(" is defined to equal ")#mi("{+1}")#text(" when ")#mi("{n}")#text(" is the product of an even number of primes, and ")#mi("{-1}")#text(" when ")#mi("{n}")#text(" is the product of an odd number of primes. The ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=177943")[#text("Chowla conjecture")]#text(" asserts that ")#mi("{\\lambda}")#text(" has the statistics of a random sign pattern, in the sense that ")#metadata(none) <tao-cf4fa7dc8fcb2ba390d8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\lim_{N \\rightarrow \\infty} \\mathbb{E}_{n \\leq N} \\lambda(n+h_1) \\dots \\lambda(n+h_k) = 0")]]

#text("for all ")#mi("{k \\geq 1}")#text(" and all distinct natural numbers ")#mi("{h_1,\\dots,h_k}")#text(", where we use the averaging notation")

#align(center)[#tao-fit-display[#mitex("\\mathbb{E}_{n \\leq N} f(n) := \\frac{1}{N} \\sum_{n \\leq N} f(n).")]]

#text("For ")#mi("{k=1}")#text(", this conjecture is equivalent to the ")#link("https://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(" (as discussed in ")#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/")[#text("this previous blog post")]#text("), but the conjecture remains open for any ")#mi("{k \\geq 2}")#text(".")

#text("In recent years, it has been realised that one can make more progress on this conjecture if one works instead with the logarithmically averaged version ")#metadata(none) <tao-936c0335b37f56b2f7d5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\lim_{N \\rightarrow \\infty} \\mathbb{E}_{n \\leq N}^{\\log} \\lambda(n+h_1) \\dots \\lambda(n+h_k) = 0")]]

#text("of the conjecture, where we use the logarithmic averaging notation")

#align(center)[#tao-fit-display[#mitex("\\mathbb{E}_{n \\leq N}^{\\log} f(n) := \\frac{\\sum_{n \\leq N} \\frac{f(n)}{n}}{\\sum_{n \\leq N} \\frac{1}{n}}.")]]

#text("Using the summation by parts (or telescoping series) identity ")#metadata(none) <tao-9bfdeb7791f90a7f8bed>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_{n \\leq N} \\frac{f(n)}{n} = \\sum_{M < N} \\frac{1}{M(M+1)} (\\sum_{n \\leq M} f(n)) + \\frac{1}{N} \\sum_{n \\leq N} f(n)")]]

#text("it is not difficult to show that the Chowla conjecture ")#link(<tao-cf4fa7dc8fcb2ba390d8>)[#text("(1)")]#text(" for a given ")#mi("{k,h_1,\\dots,h_k}")#text(" implies the logarithmically averaged conjecture ")#link(<tao-936c0335b37f56b2f7d5>)[#text("(2)")]#text(". However, the converse implication is not at all clear. For instance, for ")#mi("{k=1}")#text(", we have already mentioned that the Chowla conjecture")

#align(center)[#tao-fit-display[#mitex("\\lim_{N \\rightarrow \\infty} \\mathbb{E}_{n \\leq N} \\lambda(n) = 0")]]

#text("is equivalent to the prime number theorem; but the logarithmically averaged analogue")

#align(center)[#tao-fit-display[#mitex("\\lim_{N \\rightarrow \\infty} \\mathbb{E}^{\\log}_{n \\leq N} \\lambda(n) = 0")]]

#text("is significantly easier to show (a proof with the Liouville function ")#mi("{\\lambda}")#text(" replaced by the closely related Möbius function ")#mi("{\\mu}")#text(" is given in ")#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/")[#text("this previous blog post")]#text("). And indeed, significantly more is now known for the logarithmically averaged Chowla conjecture; in ")#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/")[#text("this paper of mine")]#text(" I had proven ")#link(<tao-936c0335b37f56b2f7d5>)[#text("(2)")]#text(" for ")#mi("{k=2}")#text(", and in ")#link("https://terrytao.wordpress.com/2017/08/09/the-structure-of-logarithmically-averaged-correlations-of-multiplicative-functions-with-applications-to-the-chowla-and-elliott-conjectures/")[#text("this recent paper with Joni Teravainen")]#text(", we proved the conjecture for all odd ")#mi("{k}")#text(" (with a different proof also given ")#link("https://terrytao.wordpress.com/2017/10/07/odd-order-cases-of-of-the-logarithmically-averaged-chowla-conjecture/")[#text("here")]#text(").")

#text("In view of this emerging consensus that the logarithmically averaged Chowla conjecture was easier than the ordinary Chowla conjecture, it was thus somewhat of a surprise for me to read a ")#link("https://arxiv.org/abs/1710.07049")[#text("recent paper of Gomilko, Kwietniak, and Lemanczyk")]#text(" who (among other things) established the following statement:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" Assume that the logarithmically averaged Chowla conjecture ")#link(<tao-936c0335b37f56b2f7d5>)[#text("(2)")]#text(" is true for all ")#mi("{k}")#text(". Then there exists a sequence ")#mi("{N_i}")#text(" going to infinity such that the Chowla conjecture ")#link(<tao-cf4fa7dc8fcb2ba390d8>)[#text("(1)")]#text(" is true for all ")#mi("{k}")#text(" along that sequence, that is to say")

#align(center)[#tao-fit-display[#mitex("\\lim_{N_i \\rightarrow \\infty} \\mathbb{E}_{n \\leq N_i} \\lambda(n+h_1) \\dots \\lambda(n+h_k) = 0")]]

#text("for all ")#mi("{k}")#text(" and all distinct ")#mi("{h_1,\\dots,h_k}")#text(".")
]

#text("This implication does not use any special properties of the Liouville function (other than that they are bounded), and in fact proceeds by ergodic theoretic methods, focusing in particular on the ergodic decomposition of invariant measures of a shift into ergodic measures. Ergodic methods have proven remarkably fruitful in understanding these sorts of number theoretic and combinatorial problems, as could already be seen by the ")#link("http://www.ams.org/mathscinet-getitem?mr=498471")[#text("ergodic theoretic proof of Szemerédi’s theorem by Furstenberg")]#text(", and more recently by ")#link("https://arxiv.org/abs/1708.00677")[#text("the work of Frantzikinakis and Host on Sarnak’s conjecture")]#text(". (My ")#link("https://terrytao.wordpress.com/2017/08/09/the-structure-of-logarithmically-averaged-correlations-of-multiplicative-functions-with-applications-to-the-chowla-and-elliott-conjectures/")[#text("first paper with Teravainen")]#text(" also uses ergodic theory tools.) Indeed, many other results in the subject were first discovered using ergodic theory methods.")

#text("On the other hand, many results in this subject that were first proven ergodic theoretically have since been reproven by more combinatorial means; my ")#link("https://terrytao.wordpress.com/2017/10/07/odd-order-cases-of-of-the-logarithmically-averaged-chowla-conjecture/")[#text("second paper with Teravainen")]#text(" is an instance of this. As it turns out, one can also prove Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" by a standard combinatorial (or probabilistic) technique known as the ")#link("https://en.wikipedia.org/wiki/Second_moment_method")[#text("second moment method")]#text(". In fact, one can prove slightly more:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" ")#metadata(none) <tao-040264644dd55339c009>#text(" Let ")#mi("{k}")#text(" be a natural number. Assume that the logarithmically averaged Chowla conjecture ")#link(<tao-936c0335b37f56b2f7d5>)[#text("(2)")]#text(" is true for ")#mi("{2k}")#text(". Then there exists a set ")#mi("{{\\mathcal N}}")#text(" of natural numbers of logarithmic density ")#mi("{1}")#text(" (that is, ")#mi("{\\lim_{N \\rightarrow \\infty} \\mathbb{E}_{n \\leq N}^{\\log} 1_{n \\in {\\mathcal N}} = 1}")#text(") such that")

#align(center)[#tao-fit-display[#mitex("\\lim_{N \\rightarrow \\infty: N \\in {\\mathcal N}} \\mathbb{E}_{n \\leq N} \\lambda(n+h_1) \\dots \\lambda(n+h_k) = 0")]]

#text("for any distinct ")#mi("{h_1,\\dots,h_k}")#text(".")
]

#text("It is not difficult to deduce Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" from Theorem ")#link(<tao-040264644dd55339c009>)[#text("2")]#text(" using a diagonalisation argument. Unfortunately, the known cases of the logarithmically averaged Chowla conjecture (")#mi("{k=2}")#text(" and odd ")#mi("{k}")#text(") are currently insufficient to use Theorem ")#link(<tao-040264644dd55339c009>)[#text("2")]#text(" for any purpose other than to reprove what is already known to be true from the prime number theorem. (Indeed, the even cases of Chowla, in either logarithmically averaged or non-logarithmically averaged forms, seem to be far more powerful than the odd cases; see Remark 1.7 of ")#link("https://arxiv.org/abs/1708.02610")[#text("this paper of myself and Teravainen")]#text(" for a related observation in this direction.)")

#text("We now sketch the proof of Theorem ")#link(<tao-040264644dd55339c009>)[#text("2")]#text(". For any distinct ")#mi("{h_1,\\dots,h_k}")#text(", we take a large number ")#mi("{H}")#text(" and consider the limiting the second moment")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{N \\rightarrow \\infty} \\mathop{\\bf E}_{n \\leq N}^{\\log} \\left|\\mathop{\\bf E}_{m \\leq H} \\lambda(n+m+h_1) \\dots \\lambda(n+m+h_k)\\right|^2.", block: true)]]

#text("We can expand this as")

#align(center)[#tao-fit-display[#mitex("\\limsup_{N \\rightarrow \\infty} \\mathop{\\bf E}_{m,m^{\\prime} \\leq H} \\mathop{\\bf E}_{n \\leq N}^{\\log} \\lambda(n+m+h_1) \\dots \\lambda(n+m+h_k)")]]

#align(center)[#tao-fit-display[#mitex("\\lambda(n+m^{\\prime}+h_1) \\dots \\lambda(n+m^{\\prime}+h_k).")]]

#text("If all the ")#mi("{m+h_1,\\dots,m+h_k,m^{\\prime}+h_1,\\dots,m^{\\prime}+h_k}")#text(" are distinct, the hypothesis ")#link(<tao-936c0335b37f56b2f7d5>)[#text("(2)")]#text(" tells us that the inner averages goes to zero as ")#mi("{N \\rightarrow \\infty}")#text(". The remaining averages are ")#mi("{O(1)}")#text(", and there are ")#mi("{O( k^2 )}")#text(" of these averages. We conclude that")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{N \\rightarrow \\infty} \\mathop{\\bf E}_{n \\leq N}^{\\log} \\left|\\mathop{\\bf E}_{m \\leq H} \\lambda(n+m+h_1) \\dots \\lambda(n+m+h_k)\\right|^2 \\ll k^2 / H.", block: true)]]

#text("By Markov’s inequality (and ")#link(<tao-9bfdeb7791f90a7f8bed>)[#text("(3)")]#text("), we conclude that for any fixed ")#mi("{h_1,\\dots,h_k, H}")#text(", there exists a set ")#mi("{{\\mathcal N}_{h_1,\\dots,h_k,H}}")#text(" of upper logarithmic density at least ")#mi("{1-k/H^{1/2}}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\limsup_{N \\rightarrow \\infty} \\mathbb{E}_{n \\leq N}^{\\log} 1_{n \\in {\\mathcal N}_{h_1,\\dots,h_k,H}} \\geq 1 - k/H^{1/2}")]]

#text("such that")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{n \\leq N} \\left|\\mathop{\\bf E}_{m \\leq H} \\lambda(n+m+h_1) \\dots \\lambda(n+m+h_k)\\right|^2 \\ll k / H^{1/2}.", block: true)]]

#text("By deleting at most finitely many elements, we may assume that ")#mi("{{\\mathcal N}_{h_1,\\dots,h_k,H}}")#text(" consists only of elements of size at least ")#mi("{H^2}")#text(" (say).")

#text("For any ")#mi("{H_0}")#text(", if we let ")#mi("{{\\mathcal N}_{h_1,\\dots,h_k, \\geq H_0}}")#text(" be the union of ")#mi("{{\\mathcal N}_{h_1,\\dots,h_k, H}}")#text(" for ")#mi("{H \\geq H_0}")#text(", then ")#mi("{{\\mathcal N}_{h_1,\\dots,h_k, \\geq H_0}}")#text(" has logarithmic density ")#mi("{1}")#text(". By a diagonalisation argument (using the fact that the set of tuples ")#mi("{(h_1,\\dots,h_k)}")#text(" is countable), we can then find a set ")#mi("{{\\mathcal N}}")#text(" of natural numbers of logarithmic density ")#mi("{1}")#text(", such that for every ")#mi("{h_1,\\dots,h_k,H_0}")#text(", every sufficiently large element of ")#mi("{{\\mathcal N}}")#text(" lies in ")#mi("{{\\mathcal N}_{h_1,\\dots,h_k,\\geq H_0}}")#text(". Thus for every sufficiently large ")#mi("{N}")#text(" in ")#mi("{{\\mathcal N}}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{n \\leq N} \\left|\\mathop{\\bf E}_{m \\leq H} \\lambda(n+m+h_1) \\dots \\lambda(n+m+h_k)\\right|^2 \\ll k / H^{1/2}.", block: true)]]

#text("for some ")#mi("{H \\geq H_0}")#text(" with ")#mi("{N \\geq H^2}")#text(". By Cauchy-Schwarz, this implies that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\leq N} \\mathop{\\bf E}_{m \\leq H} \\lambda(n+m+h_1) \\dots \\lambda(n+m+h_k) \\ll k^{1/2} / H^{1/4};")]]

#text("interchanging the sums and using ")#mi("{N \\geq H^2}")#text(" and ")#mi("{H \\geq H_0}")#text(", this implies that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\leq N} \\lambda(n+h_1) \\dots \\lambda(n+h_k) \\ll k^{1/2} / H^{1/4} \\leq k^{1/2} / H_0^{1/4}.")]]

#text("We conclude on taking ")#mi("{H_0}")#text(" to infinity that")

#align(center)[#tao-fit-display[#mitex("\\lim_{N \\rightarrow \\infty; N \\in {\\mathcal N}} \\mathop{\\bf E}_{n \\leq N} \\lambda(n+h_1) \\dots \\lambda(n+h_k) = 0")]]

#text("as required.")

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2017/10/20/the-logarithmically-averaged-and-non-logarithmically-averaged-chowla-conjectures/#comment-487857")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2017")])]

#text("The last formula in the post does not parse.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/10/20/the-logarithmically-averaged-and-non-logarithmically-averaged-chowla-conjectures/#comment-487867")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2017")])]

#text("Can the above construction of the set ")#mi("\\mathcal N")#text(" (given ")#mi("h_1, ..., h_k")#text(") be made explicit ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/10/20/the-logarithmically-averaged-and-non-logarithmically-averaged-chowla-conjectures/#comment-487903")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2017")])]

#text("Unfortunately not in any useful way (this is one of the main drawbacks of probabilistic methods such as the second moment method).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/10/20/the-logarithmically-averaged-and-non-logarithmically-averaged-chowla-conjectures/#comment-487869")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2017")])]

#text("PROFESSOR TAO, PLEASE IF I MAY ASK, IN WHICH AREA ARE CURRENTLY DOING YOUR RESEARCH?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark")]], [#link("https://terrytao.wordpress.com/2017/10/20/the-logarithmically-averaged-and-non-logarithmically-averaged-chowla-conjectures/#comment-487902")[#strong[#text("Mark")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2017")])]

#text("Any chance one can deduce infinitely many twin primes from a sufficiently strong quantitative “infinitely often” version of the two point correlation conjecture (and then, in turn, logarithmically averaged four point correlation conjecture)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/10/20/the-logarithmically-averaged-and-non-logarithmically-averaged-chowla-conjectures/#comment-487904")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2017")])]

#text("Yes, but one (using current methods, at least) needs to gain factors of ")#mi("O_A(\\log^{-A} x)")#text(" or so in the error terms, which are well beyond current technology (which relies on the fact that most numbers are divisible by small primes, which is of course false for the ")#mi("O( \\log^{-1} x)")#text(" portion of numbers that are actually large primes). See for instance the last section of ")#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/")[#text("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/")]#text(" There is perhaps some wiggle room that avoids this issue if one inserts some preliminary sieve to remove all small primes (which is the usual way to avoid losing logarithmic factors), but one would then probably need some powerful sieve axioms such as the Elliott-Halberstam conjecture to proceed. It may be something to look at once the Chowla conjecture (or its logarithmically averaged counterpart) is solved.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/10/20/the-logarithmically-averaged-and-non-logarithmically-averaged-chowla-conjectures/#comment-487906")[#strong[#text("Empirically testing Chowla conjecture")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2017")]

#text("[…] Tao’s most recent blog post looks at the Chowla conjecture theoretically. This post looks at the same conjecture empirically […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aula")]], [#link("https://terrytao.wordpress.com/2017/10/20/the-logarithmically-averaged-and-non-logarithmically-averaged-chowla-conjectures/#comment-487937")[#strong[#text("Aula")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2017")])]

#text("The third display after (3) is inside a broken link.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c2e5a74e5c44819e3b488cefed88cd751e6b44d155c1c343b34325ebe09a24a-5c706ec675da98f0cd1ece0be9de0b52bae041828a45b794bc813d29b91ec933.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sumit shingare")]], [#link("https://terrytao.wordpress.com/2017/10/20/the-logarithmically-averaged-and-non-logarithmically-averaged-chowla-conjectures/#comment-685726")[#strong[#text("Sumit shingare")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2024")])]

#text("Prof. Tao")

#text("I have a question about the approximate multiplicative functions. Roughly, I want to know how the multiplicativity of an arithmetic function of +1s and -1s affects the balancing of +1s and -1s. Also, I have one more related number theoretic question about the Liouvillie function. Here are the detailed questions.")

#link("https://drive.google.com/file/d/1NtAw6zCdNYuHxMMEE-JG_Uwqr0Wme-aR/view?usp=drivesdk")[#text("https://drive.google.com/file/d/1NtAw6zCdNYuHxMMEE-JG_Uwqr0Wme-aR/view?usp=drivesdk")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/10/20/the-logarithmically-averaged-and-non-logarithmically-averaged-chowla-conjectures/#comment-685727")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2024")])]

#text("Due to the sparsity of values of the multiplication table (see ")#link("https://en.wikipedia.org/wiki/Erd%C5%91s%E2%80%93Tenenbaum%E2%80%93Ford_constant")[#text("https://en.wikipedia.org/wiki/Erd%C5%91s%E2%80%93Tenenbaum%E2%80%93Ford_constant")]#text(" ), your measure of multiplicativity is basically decoupled from more traditional notions of density. For instance, one can obtain a positive answer to your question 1 by selecting a function ")#mi("f(n)")#text(" that is always equal to ")#mi("+1")#text(" when ")#mi("n")#text(" has about ")#mi("\\log\\log n")#text(" prime factors, but is equal to ")#mi("+1")#text(" with a probability of ")#mi("1/4")#text(" and ")#mi("-1")#text(" with a probability of ")#mi("3/4")#text(" when $n$ has about ")#mi("2 \\log\\log n")#text(" factors. The Hardy-Ramanajuan law would then ensure that this function has mean 1 asymptotically, but would have multiplicative density 1/4 in your notation.")

#text("Your second question is basically asking for the asymptotic behavior of ")#mi("\\lambda(n+1) \\lambda(m+1) \\lambda(nm+1)")#text(" as ")#mi("n,m \\to \\infty")#text(". A suitable generalization of the Chowla conjecture would then indicate that this expression has asymptotic mean zero, and so the multiplicative density should be 1/2, but this is likely out of reach of current methods.")
]
]
