// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/
// Converted to Typst by tao2typ: "2026-10-14T16:38:41.817280+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Equidistribution of Syracuse random variables and density of Collatz preimages", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Equidistribution of Syracuse random variables and density of Collatz preimages")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 January 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/")[#text("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Define the ")#emph[#text("Collatz map")]#text(" ")#mi("{\\mathrm{Col}: {\\bf N}+1 \\rightarrow {\\bf N}+1}")#text(" on the natural numbers ")#mi("{{\\bf N}+1 = \\{1,2,\\dots\\}}")#text(" by setting ")#mi("{\\mathrm{Col}(N)}")#text(" to equal ")#mi("{3N+1}")#text(" when ")#mi("{N}")#text(" is odd and ")#mi("{N/2}")#text(" when ")#mi("{N}")#text(" is even, and let ")#mi("{\\mathrm{Col}^{\\bf N}(N) := \\{ N, \\mathrm{Col}(N), \\mathrm{Col}^2(N), \\dots \\}}")#text(" denote the forward Collatz orbit of ")#mi("{N}")#text(". The notorious ")#link("https://en.wikipedia.org/wiki/Collatz_conjecture")[#text("Collatz conjecture")]#text(" asserts that ")#mi("{1 \\in \\mathrm{Col}^{\\bf N}(N)}")#text(" for all ")#mi("{N \\in {\\bf N}+1}")#text(". Equivalently, if we define the backwards Collatz orbit ")#mi("{(\\mathrm{Col}^{\\bf N})^*(N) := \\{ M \\in {\\bf N}+1: N \\in \\mathrm{Col}^{\\bf N}(M) \\}}")#text(" to be all the natural numbers ")#mi("{M}")#text(" that encounter ")#mi("{N}")#text(" in their forward Collatz orbit, then the Collatz conjecture asserts that ")#mi("{(\\mathrm{Col}^{\\bf N})^*(1) = {\\bf N}+1}")#text(". As a partial result towards this latter statement, ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1980260")[#text("Krasikov and Lagarias")]#text(" in 2003 established the bound ")#metadata(none) <tao-961b6dd3ede3cb8ecbaa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\# \\{ N \\leq x: N \\in (\\mathrm{Col}^{\\bf N})^*(1) \\} \\gg x^\\gamma")]]



#text(" for all ")#mi("{x \\geq 1}")#text(" and ")#mi("{\\gamma = 0.84}")#text(". (This improved upon previous values of ")#mi("{\\gamma = 0.81}")#text(" obtained ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1270613")[#text("by Applegate and Lagarias")]#text(" in 1995, ")#mi("{\\gamma = 0.65}")#text(" ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1270612")[#text("by Applegate and Lagarias")]#text(" in 1995 by a different method, ")#mi("{\\gamma=0.48}")#text(" ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1218235")[#text("by Wirsching")]#text(" in 1993, ")#mi("{\\gamma=0.43}")#text(" ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1024983")[#text("by Krasikov")]#text(" in 1989, ")#mi("{\\gamma=0.3}")#text(" ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1067972")[#text("by Sander")]#text(" in 1990, and some ")#mi("{\\gamma>0}")#text(" ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=480321")[#text("by Crandall")]#text(" in 1978.) This is still the largest value of ")#mi("{\\gamma}")#text(" for which ")#link(<tao-961b6dd3ede3cb8ecbaa>)[#text("(1)")]#text(" has been established. Of course, the Collatz conjecture would imply that we can take ")#mi("{\\gamma}")#text(" equal to ")#mi("{1}")#text(", which is the assertion that a positive density set of natural numbers obeys the Collatz conjecture. This is not yet established, although the results in ")#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values")[#text("my previous paper")]#text(" do at least imply that a positive density set of natural numbers iterates to an (explicitly computable) bounded set, so in principle the ")#mi("{\\gamma=1}")#text(" case of ")#link(<tao-961b6dd3ede3cb8ecbaa>)[#text("(1)")]#text(" could now be verified by an (enormous) finite computation in which one verifies that every number in this explicit bounded set iterates to ")#mi("{1}")#text(". In this post I would like to record a possible alternate route to this problem that depends on the distribution of a certain family of random variables that appeared in my previous paper, that I called ")#emph[#text("Syracuse random variables")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Syracuse random variables)")]#text(" For any natural number ")#mi("{n}")#text(", a ")#emph[#text("Syracuse random variable")]#text(" ")#mi("{\\mathbf{Syrac}({\\bf Z}/3^n{\\bf Z})}")#text(" on the cyclic group ")#mi("{{\\bf Z}/3^n{\\bf Z}}")#text(" is defined as a random variable of the form ")#metadata(none) <tao-1a11d92430356c94da90>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\mathbf{Syrac}({\\bf Z}/3^n{\\bf Z}) = \\sum_{m=1}^n 3^{n-m} 2^{-{\\mathbf a}_m-\\dots-{\\mathbf a}_n}")]]



#text(" where ")#mi("{\\mathbf{a}_1,\\dots,\\mathbf{a_n}}")#text(" are independent copies of a geometric random variable ")#mi("{\\mathbf{Geom}(2)}")#text(" on the natural numbers with mean ")#mi("{2}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf P}( \\mathbf{a}_1=a_1,\\dots,\\mathbf{a}_n=a_n) = 2^{-a_1-\\dots-a_n}")]]

#text("} for ")#mi("{a_1,\\dots,a_n \\in {\\bf N}+1}")#text(". In ")#link(<tao-1a11d92430356c94da90>)[#text("(2)")]#text(" the arithmetic is performed in the ring ")#mi("{{\\bf Z}/3^n{\\bf Z}}")#text(".")
]

#text("Thus for instance")

#tao-aligned(keep: true)[


#tao-math("\\mathrm{Syrac}({\\bf Z}/3{\\bf Z})  & = 2^{-\\mathbf{a}_1} \\text{ mod } 3", block: true)



#tao-math("\\mathrm{Syrac}({\\bf Z}/3^2{\\bf Z})  & = 2^{-\\mathbf{a}_1-\\mathbf{a}_2} + 3 \\times 2^{-\\mathbf{a}_2} \\text{ mod } 3^2", block: true)



#tao-math("\\mathrm{Syrac}({\\bf Z}/3^3{\\bf Z})  & = 2^{-\\mathbf{a}_1-\\mathbf{a}_2-\\mathbf{a}_3} + 3 \\times 2^{-\\mathbf{a}_2-\\mathbf{a}_3} + 3^2 \\times 2^{-\\mathbf{a}_3} \\text{ mod } 3^3", block: true)
]

#text("and so forth. After reversing the labeling of the ")#mi("{\\mathbf{a}_1,\\dots,\\mathbf{a}_n}")#text(", one could also view ")#mi("{\\mathrm{Syrac}({\\bf Z}/3^n{\\bf Z})}")#text(" as the mod ")#mi("{3^n}")#text(" reduction of a ")#mi("{3}")#text("-adic random variable")

#align(center)[#tao-fit-display[#mitex("\\mathbf{Syrac}({\\bf Z}_3) = \\sum_{m=1}^\\infty 3^{m-1} 2^{-{\\mathbf a}_1-\\dots-{\\mathbf a}_m}.")]]

#text("The probability density function ")#mi("{b \\mapsto \\mathbf{P}( \\mathbf{Syrac}({\\bf Z}/3^n{\\bf Z}) = b )}")#text(" of the Syracuse random variable can be explicitly computed by a recursive formula (see Lemma 1.12 of ")#link("https://arxiv.org/abs/1909.03562")[#text("my previous paper")]#text("). For instance, when ")#mi("{n=1}")#text(", ")#mi("{\\mathbf{P}( \\mathbf{Syrac}({\\bf Z}/3{\\bf Z}) = b )}")#text(" is equal to ")#mi("{0,1/3,2/3}")#text(" for ")#mi("{x=b,1,2 \\text{ mod } 3}")#text(" respectively, while when ")#mi("{n=2}")#text(", ")#mi("{\\mathbf{P}( \\mathbf{Syrac}({\\bf Z}/3^2{\\bf Z}) = b )}")#text(" is equal to")

#align(center)[#tao-fit-display[#mitex("0, \\frac{8}{63}, \\frac{16}{63}, 0, \\frac{11}{63}, \\frac{4}{63}, 0, \\frac{2}{63}, \\frac{22}{63}")]]

#text("when ")#mi("{b=0,\\dots,8 \\text{ mod } 9}")#text(" respectively.")

#text("The relationship of these random variables to the Collatz problem can be explained as follows. Let ")#mi("{2{\\bf N}+1 = \\{1,3,5,\\dots\\}}")#text(" denote the odd natural numbers, and define the ")#emph[#text("Syracuse map")]#text(" ")#mi("{\\mathrm{Syr}: 2{\\bf N}+1 \\rightarrow 2{\\bf N}+1}")#text(" by")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Syr}(N) := \\frac{3n+1}{2^{\\nu_2(3N+1)}}")]]

#text("where the ")#mi("{2}")#text("–")#link("https://en.wikipedia.org/wiki/Valuation_(algebra)")[#text("valuation")]#text(" ")#mi("{\\nu_2(3n+1) \\in {\\bf N}}")#text(" is the number of times ")#mi("{2}")#text(" divides ")#mi("{3N+1}")#text(". We can define the forward orbit ")#mi("{\\mathrm{Syr}^{\\bf N}(n)}")#text(" and backward orbit ")#mi("{(\\mathrm{Syr}^{\\bf N})^*(N)}")#text(" of the Syracuse map as before. It is not difficult to then see that the Collatz conjecture is equivalent to the assertion ")#mi("{(\\mathrm{Syr}^{\\bf N})^*(1) = 2{\\bf N}+1}")#text(", and that the assertion ")#link(<tao-961b6dd3ede3cb8ecbaa>)[#text("(1)")]#text(" for a given ")#mi("{\\gamma}")#text(" is equivalent to the assertion ")#metadata(none) <tao-3b64db95cb55c763391c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\# \\{ N \\leq x: N \\in (\\mathrm{Syr}^{\\bf N})^*(1) \\} \\gg x^\\gamma")]]



#text(" for all ")#mi("{x \\geq 1}")#text(", where ")#mi("{N}")#text(" is now understood to range over odd natural numbers. A brief calculation then shows that for any odd natural number ")#mi("{N}")#text(" and natural number ")#mi("{n}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Syr}^n(N) = 3^n 2^{-a_1-\\dots-a_n} N + \\sum_{m=1}^n 3^{n-m} 2^{-a_m-\\dots-a_n}")]]

#text("where the natural numbers ")#mi("{a_1,\\dots,a_n}")#text(" are defined by the formula")

#align(center)[#tao-fit-display[#mitex("a_i := \\nu_2( 3 \\mathrm{Syr}^{i-1}(N) + 1 ),")]]

#text("so in particular")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Syr}^n(N) = \\sum_{m=1}^n 3^{n-m} 2^{-a_m-\\dots-a_n} \\text{ mod } 3^n.")]]

#text("Heuristically, one expects the ")#mi("{2}")#text("-valuation ")#mi("{a = \\nu_2(N)}")#text(" of a typical odd number ")#mi("{N}")#text(" to be approximately distributed according to the geometric distribution ")#mi("{\\mathbf{Geom}(2)}")#text(", so one therefore expects the residue class ")#mi("{\\mathrm{Syr}^n(N) \\text{ mod } 3^n}")#text(" to be distributed approximately according to the random variable ")#mi("{\\mathbf{Syrac}({\\bf Z}/3^n{\\bf Z})}")#text(".")

#text("The Syracuse random variables ")#mi("{\\mathbf{Syrac}({\\bf Z}/3^n{\\bf Z})}")#text(" will always avoid multiples of three (this reflects the fact that ")#mi("{\\mathrm{Syr}(N)}")#text(" is never a multiple of three), but attains any non-multiple of three in ")#mi("{{\\bf Z}/3^n{\\bf Z}}")#text(" with positive probability. For any natural number ")#mi("{n}")#text(", set")

#align(center)[#tao-fit-display[#mitex("c_n := \\inf_{b \\in {\\bf Z}/3^n{\\bf Z}: 3 \\nmid b} \\mathbf{P}( \\mathbf{Syrac}({\\bf Z}/3^n{\\bf Z}) = b ).")]]

#text("Equivalently, ")#mi("{c_n}")#text(" is the greatest quantity for which we have the inequality ")#metadata(none) <tao-47eb4101aad28dc40014>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{(a_1,\\dots,a_n) \\in S_{n,N}} 2^{-a_1-\\dots-a_m} \\geq c_n")]]



#text(" for all integers ")#mi("{N}")#text(" not divisible by three, where ")#mi("{S_{n,N} \\subset ({\\bf N}+1)^n}")#text(" is the set of all tuples ")#mi("{(a_1,\\dots,a_n)}")#text(" for which")

#align(center)[#tao-fit-display[#mitex("N = \\sum_{m=1}^n 3^{m-1} 2^{-a_1-\\dots-a_m} \\text{ mod } 3^n.")]]

#text("Thus for instance ")#mi("{c_0=1}")#text(", ")#mi("{c_1 = 1/3}")#text(", and ")#mi("{c_2 = 2/63}")#text(". On the other hand, since all the probabilities ")#mi("{\\mathbf{P}( \\mathbf{Syrac}({\\bf Z}/3^n{\\bf Z}) = b)}")#text(" sum to ")#mi("{1}")#text(" as ")#mi("{b \\in {\\bf Z}/3^n{\\bf Z}}")#text(" ranges over the non-multiples of ")#mi("{3}")#text(", we have the trivial upper bound")

#align(center)[#tao-fit-display[#mitex("c_n \\leq \\frac{3}{2} 3^{-n}.")]]

#text("There is also an easy submultiplicativity result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" ")#metadata(none) <tao-8ac1ef5381caf75418d7>#text(" For any natural numbers ")#mi("{n_1,n_2}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("c_{n_1+n_2-1} \\geq c_{n_1} c_{n_2}.")]]
]

#emph[#text("Proof:")]#text(" Let ")#mi("{N}")#text(" be an integer not divisible by ")#mi("{3}")#text(", then by ")#link(<tao-47eb4101aad28dc40014>)[#text("(4)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{(a_1,\\dots,a_{n_1}) \\in S_{n_1,N}} 2^{-a_1-\\dots-a_{n_1}} \\geq c_{n_1}.")]]

#text("If we let ")#mi("{S^{\\prime}_{n_1,N}}")#text(" denote the set of tuples ")#mi("{(a_1,\\dots,a_{n_1-1})}")#text(" that can be formed from the tuples in ")#mi("{S_{n_1,N}}")#text(" by deleting the final component ")#mi("{a_{n_1}}")#text(" from each tuple, then we have ")#metadata(none) <tao-a3c377f20af5d619fd97>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_{(a_1,\\dots,a_{n_1-1}) \\in S^{\\prime}_{n_1,N}} 2^{-a_1-\\dots-a_{n_1-1}} \\geq c_{n_1}.")]]



#text(" Next, observe that if ")#mi("{(a_1,\\dots,a_{n_1-1}) \\in S^{\\prime}_{n_1,N}}")#text(", then")

#align(center)[#tao-fit-display[#mitex("N = \\sum_{m=1}^{n_1-1} 3^{m-1} 2^{-a_1-\\dots-a_m} + 3^{n_1-1} 2^{-a_1-\\dots-a_{n_1-1}} M")]]

#text("with ")#mi("{M = M_{N,n_1,a_1,\\dots,a_{n_1-1}}}")#text(" an integer not divisible by three. By definition of ")#mi("{S_{n_2,M}}")#text(" and a relabeling, we then have")

#align(center)[#tao-fit-display[#mitex("M = \\sum_{m=1}^{n_2} 3^{m-1} 2^{-a_{n_1}-\\dots-a_{m+n_1-1}} \\text{ mod } 3^{n_2}")]]

#text("for all ")#mi("{(a_{n_1},\\dots,a_{n_1+n_2-1}) \\in S_{n_2,M}}")#text(". For such tuples we then have")

#align(center)[#tao-fit-display[#mitex("N = \\sum_{m=1}^{n_1+n_2-1} 3^{m-1} 2^{-a_1-\\dots-a_{n_1+n_2-1}} \\text{ mod } 3^{n_1+n_2-1}")]]

#text("so that ")#mi("{(a_1,\\dots,a_{n_1+n_2-1}) \\in S_{n_1+n_2-1,N}}")#text(". Since")

#align(center)[#tao-fit-display[#mitex("\\sum_{(a_{n_1},\\dots,a_{n_1+n_2-1}) \\in S_{n_2,M}} 2^{-a_{n_1}-\\dots-a_{n_1+n_2-1}} \\geq c_{n_2}")]]

#text("for each ")#mi("{M}")#text(", the claim follows. ")#mi("\\Box")

#text("From this lemma we see that ")#mi("{c_n = 3^{-\\beta n + o(n)}}")#text(" for some absolute constant ")#mi("{\\beta \\geq 1}")#text(". Heuristically, we expect the Syracuse random variables to be somewhat approximately equidistributed amongst the multiples of ")#mi("{{\\bf Z}/3^n{\\bf Z}}")#text(" (in Proposition 1.4 of ")#link("https://arxiv.org/abs/1909.03562")[#text("my previous paper")]#text(" I prove a fine scale mixing result that supports this heuristic). As a consequence it is natural to conjecture that ")#mi("{\\beta=1}")#text(". I cannot prove this, but I can show that this conjecture would imply that we can take the exponent ")#mi("{\\gamma}")#text(" in ")#link(<tao-961b6dd3ede3cb8ecbaa>)[#text("(1)")]#text(", ")#link(<tao-3b64db95cb55c763391c>)[#text("(3)")]#text(" arbitrarily close to one:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3")]#text(" ")#metadata(none) <tao-895a6072c8d3559373b6>#text(" Suppose that ")#mi("{\\beta=1}")#text(" (that is to say, ")#mi("{c_n = 3^{-n+o(n)}}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text("). Then")

#align(center)[#tao-fit-display[#mitex("\\# \\{ N \\leq x: N \\in (\\mathrm{Syr}^{\\bf N})^*(1) \\} \\gg x^{1-o(1)}")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(", or equivalently")

#align(center)[#tao-fit-display[#mitex("\\# \\{ N \\leq x: N \\in (\\mathrm{Col}^{\\bf N})^*(1) \\} \\gg x^{1-o(1)}")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(". In other words, ")#link(<tao-961b6dd3ede3cb8ecbaa>)[#text("(1)")]#text(", ")#link(<tao-3b64db95cb55c763391c>)[#text("(3)")]#text(" hold for all ")#mi("{\\gamma < 1}")#text(".")
]

#text("I prove this proposition below the fold. A variant of the argument shows that for any value of ")#mi("{\\beta}")#text(", ")#link(<tao-961b6dd3ede3cb8ecbaa>)[#text("(1)")]#text(", ")#link(<tao-3b64db95cb55c763391c>)[#text("(3)")]#text(" holds whenever ")#mi("{\\gamma < f(\\beta)}")#text(", where ")#mi("{f: [0,1] \\rightarrow [0,1]}")#text(" is an explicitly computable function with ")#mi("{f(\\beta) \\rightarrow 1}")#text(" as ")#mi("{\\beta \\rightarrow 1}")#text(". In principle, one could then improve the Krasikov-Lagarias result ")#mi("{\\gamma = 0.84}")#text(" by getting a sufficiently good upper bound on ")#mi("{\\beta}")#text(", which is in principle achievable numerically (note for instance that Lemma ")#link(<tao-8ac1ef5381caf75418d7>)[#text("2")]#text(" implies the bound ")#mi("{c_n \\leq 3^{-\\beta(n-1)}}")#text(" for any ")#mi("{n}")#text(", since ")#mi("{c_{kn-k+1} \\geq c_n^k}")#text(" for any ")#mi("{k}")#text(").")

#metadata(none) <tao-207bd6bf1beeef467ded>

#heading(level: 1)[#strong[#text(" — 1. Proof of proposition — ")]]

#text("Assume ")#mi("{\\beta=1}")#text(". Let ")#mi("{\\varepsilon>0}")#text(" be sufficiently small, and let ")#mi("{n_0}")#text(" be sufficiently large depending on ")#mi("{\\varepsilon}")#text(". We first establish the following proposition, that shows that elements in a certain residue class have a lot of Syracuse preimages:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4")]#text(" There exists a residue class of ")#mi("{{\\bf Z}/3^{n_0}{\\bf Z}}")#text(" with the property that for all integers ")#mi("{N}")#text(" in this class, and all non-negative integers ")#mi("{j}")#text(", there exist natural numbers ")#mi("{n_j, L_j}")#text(" with")

#align(center)[#tao-fit-display[#mitex("(2-\\varepsilon^2) n_j \\leq L_j \\leq (2+\\varepsilon^2) n_j")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(4/3)^{(1-\\varepsilon^2) (1+\\varepsilon)^j n_0} \\leq 3^{-n_j} 2^{L_j} \\leq (4/3)^{(1+\\varepsilon^2) (1+\\varepsilon)^j n_0}")]]

#text("and at least ")#mi("{3^{-n_j - \\varepsilon^4 n_j} 2^{L_j}}")#text(" tuples")

#align(center)[#tao-fit-display[#mitex("(a_1,\\dots,a_{n_j-1}) \\in S^{\\prime}_{n_j,N}")]]

#text("obeying the additional properties ")#metadata(none) <tao-a820ccc956a73d9674d3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("a_1+\\dots+a_{n_j-1} = L_j")]]



#text(" and ")#metadata(none) <tao-2de312557e6fd639b6bc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("a_1+\\dots+a_i - \\frac{\\log 3}{\\log 2} i \\geq - \\varepsilon^5 n_0")]]



#text(" for all ")#mi("{1 \\leq i \\leq n_j-1}")#text(".")
]

#emph[#text("Proof:")]#text(" We begin with the base case ")#mi("{j=0}")#text(". By ")#link(<tao-47eb4101aad28dc40014>)[#text("(4)")]#text(" and the hypothesis ")#mi("{\\beta=1}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\sum_{(a_1,\\dots,a_{n_0-1}) \\in S^{\\prime}_{n_0,N}} 2^{-a_1-\\dots-a_{n_0-1}} \\gg 3^{-(1+\\varepsilon^6) n_0}")]]

#text("for all integers ")#mi("{N}")#text(" not divisible by ")#mi("{3}")#text(". Let ")#mi("{S^{\\prime\\prime}_{n_0,N}}")#text(" denote the tuples ")#mi("{(a_1,\\dots,a_{n_0-1})}")#text(" in ")#mi("{S^{\\prime}_{n_0,N}}")#text(" that obey the additional regularity hypotheses ")#metadata(none) <tao-32e83e92d45d71f69dcf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left|a_1 + \\dots + a_i - 2i\\right| \\leq - \\varepsilon^5 n_0", block: true)]]



#text(" for all ")#mi("{1 \\leq i \\leq n_0-1}")#text(",note that this implies in particular the ")#mi("{j=0}")#text(" case of ")#link(<tao-2de312557e6fd639b6bc>)[#text("(7)")]#text(". From the Chernoff inequality (noting that the geometric random variable ")#mi("{\\mathrm{Geom}(2)}")#text(" has mean ")#mi("{2}")#text(") and the union bound we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{b \\in {\\bf Z}/3^{n_0}{\\bf Z}: 3 \\not | b} \\sum_{(a_1,\\dots,a_{n_0-1}) \\in S^{\\prime}_{n_0,b} \\backslash S^{\\prime\\prime}_{n_0,b}} 2^{-a_1-\\dots-a_{n_0-1}} \\ll 3^{-c \\varepsilon^5 n_0}")]]

#text("for an absolute constant ")#mi("{c>0}")#text(" (where we use the periodicity of ")#mi("{S^{\\prime}_{n_0,N}, S^{\\prime\\prime}_{n_0,N}}")#text(" in ")#mi("{N}")#text(" to define ")#mi("{S^{\\prime}_{n_0,b}, S^{\\prime\\prime}_{n_0,b}}")#text(" for ")#mi("{b \\in {\\bf Z}/3^{n_0}{\\bf Z}}")#text(" by abuse of notation). Hence by the pigeonhole principle we can find a residue class ")#mi("{b}")#text(" not divisible by ")#mi("{3}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\sum_{(a_1,\\dots,a_{n_0-1}) \\in S^{\\prime}_{n_0,b} \\backslash S^{\\prime\\prime}_{n_0,b}} 2^{-a_1-\\dots-a_{n_0-1}} \\ll 3^{-(1+c \\varepsilon^5) n_0}")]]

#text("and hence by the triangle inequality we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{(a_1,\\dots,a_{n_0-1}) \\in S^{\\prime\\prime}_{n_0,N}} 2^{-a_1-\\dots-a_{n_0-1}} \\gg 3^{-(1+\\varepsilon^6) n_0}")]]

#text("for all ")#mi("{N}")#text(" in this residue class.")

#text("Henceforth ")#mi("{N}")#text(" is assumed to be an element of this residue class. For ")#mi("{(a_1,\\dots,a_{n_0-1}) \\in S^{\\prime\\prime}_{n_0,N}}")#text(", we see from ")#link(<tao-32e83e92d45d71f69dcf>)[#text("(8)")]

#align(center)[#tao-fit-display[#mitex("a_1 + \\dots + a_{n_0-1} = (2+O(\\varepsilon^5)) n_0,")]]

#text("hence by the pigeonhole principle there exists ")#mi("{L_0 = (2+O(\\varepsilon^5)) n_0}")#text(" (so in particular ")#mi("{3^{-n_0} 2^{L_0} = (4/3)^{(1+O(\\varepsilon^5))n_0}}")#text(") such that")

#align(center)[#tao-fit-display[#mitex("\\sum_{(a_1,\\dots,a_{n_0-1}) \\in S^{\\prime\\prime}_{n_0,N}: a_1+\\dots+a_{n_0-1} = L_0} 2^{-L_0} \\gg 3^{-(1+\\varepsilon^6) n_0}")]]

#text("so the number of summands here is at least ")#mi("{\\gg 2^{L_0} 3^{-(1+\\varepsilon^6) n_0}}")#text(". This establishes the base case ")#mi("{j=0}")#text(".")

#text("Now suppose inductively that ")#mi("{j \\geq 1}")#text(", and that the claim has already been proven for ")#mi("{j-1}")#text(". By induction hypothesis, there exists natural numbers ")#mi("{n_{j-1}, L_{j-1}}")#text(" with")

#align(center)[#tao-fit-display[#mitex("(2-\\varepsilon^2) n_{j-1} \\leq L_{j-1} \\leq (2+\\varepsilon^2) n_{j-1}")]]

#text("and ")#metadata(none) <tao-e81935fb86434cdaaeee>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("(4/3)^{(1-\\varepsilon^2) (1+\\varepsilon)^{j-1} n_0} \\leq 3^{-n_{j-1}} 2^{L_{j-1}} \\leq (4/3)^{(1+\\varepsilon^2) (1+\\varepsilon)^{j-1} n_0}")]]



#text(" (which in particular imply that ")#mi("{n_{j-1} = (1+O(\\varepsilon^2)) (1+\\varepsilon)^{j-1} n_0}")#text(") and at least ")#mi("{3^{-n_{j-1} - \\varepsilon^4 n_{j-1}} 2^{L_{j-1}}}")#text(" tuples ")#metadata(none) <tao-4b9d56be24988360850e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("(a_1,\\dots,a_{n_{j-1}-1}) \\in S^{\\prime}_{n_{j-1},N}")]]



#text(" obeying the additional properties ")#metadata(none) <tao-9d981ef303f57b8e14a5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("a_1+\\dots+a_{n_{j-1}-1} = L_{j-1}")]]



#text(" and ")#link(<tao-2de312557e6fd639b6bc>)[#text("(7)")]#text(" for all ")#mi("{1 \\leq i \\leq n_{j-1}-1}")#text(".")

#text("Let ")#mi("{n_{j}}")#text(" be an integer such that ")#metadata(none) <tao-8d01331027ac8fe4a37c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("3^{-n_{j}} 2^{L_{j-1} + 2(n_{j}-n_{j-1})} \\asymp (4/3)^{(1+\\varepsilon)^j n_0} N.")]]



#text(" One easily checks that")

#align(center)[#tao-fit-display[#mitex("n_{j} = (1+\\varepsilon+O(\\varepsilon^2)) n_{j-1} = (1+O(\\varepsilon^2)) (1+\\varepsilon)^{j-1} n_0.")]]

#text("For each tuple ")#link(<tao-4b9d56be24988360850e>)[#text("(10)")]#text(", we may write (as in the proof of Lemma ")#link(<tao-8ac1ef5381caf75418d7>)[#text("2")]#text(")")

#align(center)[#tao-fit-display[#mitex("N = \\sum_{m=1}^{n_{j-1}-1} 3^{m-1} 2^{-a_1-\\dots-a_m} + 3^{n_{j-1}-1} 2^{-L_{j-1}} M_{\\vec a}")]]

#text("for some integers ")#mi("{M_{\\vec a}}")#text(". We claim that these integers lie in distinct residue classes modulo ")#mi("{3^k}")#text(" where")

#align(center)[#tao-fit-display[#mitex("k :=\\lfloor \\frac{\\log 2}{\\log 3} L_{j-1} - n_{j-1} + \\varepsilon^4 n_{j-1} \\rfloor.")]]

#text("Indeed, suppose that ")#mi("{M_{\\vec a} = M_{\\vec b} \\text{ mod } 3^k}")#text(" for two tuples ")#mi("{\\vec a = (a_1,\\dots,a_{n_{j-1}-1})}")#text(", ")#mi("{\\vec b = (b_1,\\dots,b_{n_{j-1}-1})}")#text(" of the above form. Then")

#align(center)[#tao-fit-display[#mitex("\\sum_{m=1}^{n_{j-1}-1} 3^{m-1} 2^{-a_1-\\dots-a_m} = \\sum_{m=1}^{n_{j-1}-1} 3^{m-1} 2^{-b_1-\\dots-b_m} \\text{ mod } 3^{n_{j-1}-1+k}")]]

#text("(where we now invert ")#mi("{2}")#text(" in the ring ")#mi("{{\\bf Z}/3^{n_{j-1}-1+k}{\\bf Z}}")#text("), or equivalently")

#align(center)[#tao-fit-display[#mitex("\\sum_{m=1}^{n_{j-1}-1} 3^{m-1} 2^{a_{m+1}+\\dots+a_{n_{j-1}-1}} = \\sum_{m=1}^{n_{j-1}-1} 3^{m-1} 2^{b_{m+1}+\\dots+b_{n_{j-1}-1}} \\text{ mod } 3^{n_{j-1}-1+k}.")]]

#text("By ")#link(<tao-9d981ef303f57b8e14a5>)[#text("(11)")]#text(", ")#link(<tao-2de312557e6fd639b6bc>)[#text("(7)")]#text(", all the summands on the left-hand side are natural numbers of size ")#mi("{O( 2^{L_{j-1}} 3^{O(\\varepsilon^5 n_{j-1})})}")#text(", hence the sum also has this size; similarly for the right-hand side. From the estimates of ")#mi("{n_{j-1}, n_{j}}")#text(", we thus see that both sides are natural numbers between ")#mi("{1}")#text(" and ")#mi("{3^{n_{j-1}-1+k}}")#text(", by hypothesis on ")#mi("{k}")#text(". Thus we may remove the modular constraint and conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{m=1}^{n_{j-1}-1} 3^{m-1} 2^{a_{m+1}+\\dots+a_{n_{j-1}-1}} = \\sum_{m=1}^{n_{j-1}-1} 3^{m-1} 2^{b_{m+1}+\\dots+b_{n_{j-1}-1}}")]]

#text("and then a routine induction (see Lemma 6.2 of ")#link("https://arxiv.org/abs/1909.03562")[#text("my paper")]#text(") shows that ")#mi("{(a_1,\\dots,a_{n_{j-1}-1}) = (b_1,\\dots,b_{n_{j-1}-1})}")#text(". This establishes the claim.")

#text("As a corollary, we see that every residue class modulo ")#mi("{3^{n_j-n_{j-1}}}")#text(" contains")

#align(center)[#tao-fit-display[#mitex("O( 3^{k - (n_j-n_{j-1})} ) = O( 2^{L_{j-1}} 3^{-n_j + \\varepsilon^4 n_{j-1}} )")]]

#text("of the ")#mi("{M_{\\vec a}}")#text(" at most. Since there were at least ")#mi("{3^{-n_{j-1} - \\varepsilon^4 n_{j-1}} 2^{L_{j-1}}}")#text(" tuples ")#mi("{\\vec a}")#text(" to begin with, we may therefore forbid up to ")#mi("{O(3^{n_j-n_{j-1} - 3 \\varepsilon^4 n_{j-1}})}")#text(" residue classes modulo ")#mi("{3^{n_j-n_{j-1}}}")#text(", and still have ")#mi("{\\gg 3^{-n_{j-1} - \\varepsilon^4 n_{j-1}} 2^{L_{j-1}}}")#text(" surviving tuples ")#mi("{\\vec a}")#text(" with the property that ")#mi("{M_{\\vec a}}")#text(" avoids all the forbidden classes.")

#text("Let ")#mi("{\\vec a}")#text(" be one of the tuples ")#link(<tao-4b9d56be24988360850e>)[#text("(10)")]#text(". By the hypothesis ")#mi("{\\beta = 1}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{(a_{n_{j-1}},\\dots,a_{n_j-1}) \\in S^{\\prime}_{n_j-n_{j-1},M_{\\vec a}}} 2^{-a_{n_{j-1}}-\\dots-a_{n_j-1}} \\gg 3^{-(1+\\varepsilon^6) (n_j-n_{j-1})}.")]]

#text("Let ")#mi("{S^{\\prime\\prime\\prime}_{n_j-n_{j-1},M}}")#text(" denote the set of tuples ")#mi("{(a_{n_{j-1}},\\dots,a_{n_j-1}) \\in S^{\\prime}_{n_j-n_{j-1},M}}")#text(" with the additional property")

#align(center)[#tao-fit-display[#tao-math("\\left|a_{n_{j-1}} + \\dots + a_i - 2(i-n_{j-1}+1)\\right| \\leq - \\varepsilon^3 (n_j - n_{j-1})", block: true)]]

#text("for all ")#mi("{n_{j-1} \\leq i \\leq n_j - 1}")#text(", then by the Chernoff bound we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{b \\in {\\bf Z}/3^{n_j-n_{j-1}}{\\bf Z}} \\sum_{(a_{n_{j-1}},\\dots,a_{n_j-1}) \\in S^{\\prime}_{n_j-n_{j-1},b} \\backslash S^{\\prime\\prime\\prime}_{n_j-n_{j-1},b}} 2^{-a_{n_{j-1}}-\\dots-a_{n_j-1}}")]]

#align(center)[#tao-fit-display[#mitex("\\ll 3^{-c\\varepsilon^3 (n_j-n_{j-1})}")]]

#text("for some absolute constant ")#mi("{c>0}")#text(". Thus, by the Markov inequality, by forbidding up to ")#mi("{O(3^{n_j-n_{j-1} - 3 \\varepsilon^4 n_{j-1}})}")#text(" classes, we may ensure that")

#align(center)[#tao-fit-display[#mitex("\\sum_{(a_{n_{j-1}},\\dots,a_{n_j-1}) \\in S^{\\prime}_{n_j-n_{j-1},M_{\\vec a}} \\backslash S^{\\prime\\prime\\prime}_{n_j-n_{j-1},M_{\\vec a}}} 2^{-a_{n_{j-1}}-\\dots-a_{n_j-1}} \\ll 3^{-(1+\\varepsilon^5) (n_j-n_{j-1})}")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("\\sum_{(a_{n_{j-1}},\\dots,a_{n_j-1}) \\in S^{\\prime\\prime\\prime}_{n_j-n_{j-1},M_{\\vec a}}} 2^{-a_{n_{j-1}}-\\dots-a_{n_j-1}} \\gg 3^{-(1+\\varepsilon^6) (n_j-n_{j-1})}.")]]

#text("We thus have")

#align(center)[#tao-fit-display[#mitex("\\sum_{a_1,\\dots,a_{n_j-1}} 2^{-a_{n_{j-1}}-\\dots-a_{n_j-1}} \\gg 3^{-n_{j-1} - \\varepsilon^4 n_{j-1}} 2^{L_{j-1}} 3^{-(1+\\varepsilon^6) (n_j-n_{j-1})}")]]

#text("where ")#mi("{(a_1,\\dots,a_{n_j-1})}")#text(" run over all tuples with ")#mi("{\\vec a = (a_1,\\dots,a_{n_{j-1}-1})}")#text(" being one of the previously surviving tuples, and ")#mi("{(a_{n_{j-1}},\\dots,a_{n_j-1}) \\in S^{\\prime\\prime\\prime}_{n_j-n_{j-1},M_{\\vec a}}}")#text(". By ")#link(<tao-9d981ef303f57b8e14a5>)[#text("(11)")]#text(" we may rearrange this a little as")

#align(center)[#tao-fit-display[#mitex("\\sum_{a_1,\\dots,a_{n_j-1}} 2^{-a_1-\\dots-a_{n_j-1}} \\gg 3^{-n_{j} - \\varepsilon^4 n_{j-1}-\\varepsilon^6 (n_j-n_{j-1})}.")]]

#text("By construction, we have")

#align(center)[#tao-fit-display[#mitex("a_1 + \\dots + a_{n_j-1} = L_{j-1} + (2 + O(\\varepsilon^3)) (n_j - n_{j-1})")]]

#text("for any tuple in the above sum, hence by the pigeonhole principle we may find an integer ")#metadata(none) <tao-5744323314533d2583cc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("L_j = L_{j-1} + (2 + O(\\varepsilon^3)) (n_j - n_{j-1})")]]



#text(" for which")

#align(center)[#tao-fit-display[#mitex("\\sum_{a_1,\\dots,a_{n_j-1}: a_1+\\dots+a_{n_j-1}=L_j} 2^{-a_1-\\dots-a_{n_j-1}} \\geq 3^{-n_{j} - \\varepsilon^4 n_j}.")]]

#text("In particular the number of summands is at least ")#mi("{3^{-n_{j} - \\varepsilon^4 n_j} 2^{L_j}}")#text(". Also observe from ")#link(<tao-5744323314533d2583cc>)[#text("(13)")]#text(", ")#link(<tao-8d01331027ac8fe4a37c>)[#text("(12)")]#text(" that")

#tao-aligned(keep: true)[


#tao-math("3^{-n_j} 2^{L_j}  & = 3^{-n_{j} + O( \\varepsilon^3 (n_j - n_{j-1})} 2^{L_{j-1} + 2(n_j - n_{j-1})}", block: true)



#tao-math(" & = (4/3)^{(1+\\varepsilon)^j n_0} 3^{( \\varepsilon^3 (n_j - n_{j-1})}", block: true)
]

#text("so in particular")

#align(center)[#tao-fit-display[#mitex("(4/3)^{(1-\\varepsilon^2) (1+\\varepsilon)^j n_0} \\leq 3^{-n_j} 2^{L_j} \\leq (4/3)^{(1+\\varepsilon^2) (1+\\varepsilon)^j n_0}.")]]

#text("It is a routine matter to verify that all tuples in this sum lie in ")#mi("{S^{\\prime}_{n_j,N}}")#text(" and obeys the requirements ")#link(<tao-a820ccc956a73d9674d3>)[#text("(6)")]#text(", ")#link(<tao-2de312557e6fd639b6bc>)[#text("(7)")]#text(", closing the induction hypothesis. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 5")]#text(" For all ")#mi("{N}")#text(" in the residue class from the previous proposition, and all ")#mi("{j \\geq 0}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\{ M \\in (\\mathrm{Syr}^{\\bf N})^*(N): M \\leq 3 (4/3)^{(1+\\varepsilon^2) (1+\\varepsilon)^j n_0} N \\}")]]

#align(center)[#tao-fit-display[#mitex("\\gg (4/3)^{(1-\\varepsilon) (1+\\varepsilon)^j n_0}.")]]

#text("In particular, we have")

#align(center)[#tao-fit-display[#mitex("\\{ M \\in (\\mathrm{Syr}^{\\bf N})^*(N): M \\leq x \\} \\gg_{\\varepsilon,n_0,N} x^{1-\\varepsilon}")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(".")
]

#emph[#text("Proof:")]#text(" For every tuple ")#mi("{(a_1,\\dots,a_{n_j-1})}")#text(" in the previous proposition, we have")

#align(center)[#tao-fit-display[#mitex("N = \\sum_{m=1}^{n_{j}-1} 3^{m-1} 2^{-a_1-\\dots-a_m} + 3^{n_{j}-1} 2^{-L_{j}} M")]]

#text("for some integer ")#mi("{M}")#text(". As before, all these integers ")#mi("{M}")#text(" are distinct, and have magnitude")

#align(center)[#tao-fit-display[#mitex("M \\leq 3^{-n_j+1} 2^{L_j} N \\leq \\leq 3 (4/3)^{(1+\\varepsilon^2) (1+\\varepsilon)^j n_0} N.")]]

#text("From construction we also have ")#mi("{\\mathrm{Syr}^{n_j}(M) = N}")#text(", so that ")#mi("{M \\in (\\mathrm{Syr}^{\\bf N})^*(N)}")#text(". The number of tuples is at least")

#align(center)[#tao-fit-display[#mitex("3^{-n_j - \\varepsilon^4 n_j} 2^{L_j}")]]

#text("which can be computed from the properties of ")#mi("{n_j,L_j}")#text(" to be of size at least ")#mi("{(4/3)^{(1-\\varepsilon) (1+\\varepsilon)^j n_0}}")#text(". This gives the first claim, and the second claim follows by taking ")#mi("{j}")#text(" to be the first integer for which ")#mi("{3 (4/3)^{(1+\\varepsilon^2) (1+\\varepsilon)^j n_0} N \\geq x}")#text(". ")#mi("\\Box")

#text("To conclude the proof of Proposition ")#link(<tao-895a6072c8d3559373b6>)[#text("3")]#text(", it thus suffices to show that")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6")]#text(" Every residue class ")#mi("{b \\text{ mod } 3^{n_0}}")#text(" has a non-trivial intersection with ")#mi("{(\\mathrm{Syr}^{\\bf N})^*(1)}")#text(".")
]

#text("Indeed, if we let ")#mi("{b \\text{ mod } 3^{n_0}}")#text(" be the residue class from the preceding propositions, and use this lemma to produce an element ")#mi("{N}")#text(" of ")#mi("{(\\mathrm{Syr}^{\\bf N})^*(1)}")#text(" that lies in this class, then from the inclusion ")#mi("{(\\mathrm{Syr}^{\\bf N})^*(N) \\subset (\\mathrm{Syr}^{\\bf N})^*(1)}")#text(" we obtain ")#link(<tao-3b64db95cb55c763391c>)[#text("(3)")]#text(" with ")#mi("{\\gamma = 1-O(\\varepsilon)}")#text(", and then on sending ")#mi("{\\varepsilon}")#text(" to zero we obtain the claim.")

#emph[#text("Proof:")]#text(" An easy induction (based on first establishing that ")#mi("{2^{2 \\times 3^n} = 1 + 3^{n+1} \\text{ mod } 3^{n+2}}")#text(" for all natural numbers ")#mi("{n}")#text(") shows that the powers of two modulo ")#mi("{3^{n_0+1}}")#text(" occupy every residue class not divisible by ")#mi("{3}")#text(". From this we can locate an integer ")#mi("{N}")#text(" in ")#mi("{b \\text{ mod } 3^{n_0}}")#text(" of the form ")#mi("{N = \\frac{2^n-1}{3}}")#text(". Since ")#mi("{\\mathrm{Syr}(N)=1}")#text(", the claim follows. ")#mi("\\Box")

#text("We remark that the same argument in fact shows (assuming ")#mi("{\\beta=1}")#text(" of course) that")

#align(center)[#tao-fit-display[#mitex("\\# \\{ N \\leq x: N \\in (\\mathrm{Col}^{\\bf N})^*(N_0) \\} \\gg_{N_0} x^{1-o(1)}")]]

#text("in the limit ")#mi("{x \\rightarrow \\infty}")#text(" for any natural number ")#mi("{N_0}")#text(" not divisible by three.")

#heading(level: 1)[#text("Comments (98)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537292")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2020")])]

#text("Is it possible to extend proposition 3 for each given ")#mi("\\beta")#text(" to find the explicit expression of the best possible ")#mi("\\gamma")#text(" as a function of each given ")#mi("\\beta")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537402")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2020")])]

#text("The argument I give in this post does give in principle an explicit way to convert a specific value of ")#mi("\\beta")#text(" to a specific value of ")#mi("\\gamma")#text(", but it is quite inefficient and would not give the best possible ")#mi("\\gamma")#text(". Heuristically one can obtain a relationship as follows. From (5) we have for any natural number ")#mi("N")#text(" not divisible by 3 that")

#mi("\\displaystyle \\sum_{(a_1,\\dots,a_{n-1}) \\in S^{\\prime}_{n,N}} 2^{-a_1-\\dots-a_{n-1}} \\gg 3^{-(\\beta+o(1)) n}.")

#text("The law of large numbers suggests that typically one has ")#mi("a_1+\\dots+a_{n-1} \\approx 2(n-1)")#text(". (Making this intuition precise is in fact a bit tricky, and is the reason why the arguments in the post are rather technical and lead to inefficiencies in converting from ")#mi("\\beta")#text(" values to ")#mi("\\gamma")#text(" values.) If one blindly inserts this law of large number approximation, we see that")

#mi("\\displaystyle \\# S^{\\prime}_{n,N} \\gg 3^{-\\beta n + o(n)} 2^{2n}.")

#text("This basically tells us that ")#mi("\\mathrm{Syr}^{-n}(N)")#text(" (or ")#mi("\\mathrm{Syr}^{-n+1}(N)")#text(") has ")#mi("\\gg 3^{-\\beta n + o(n)} 2^{2n}")#text(" preimages, each of which have size about ")#mi("3^{-n} 2^{a_1+\\dots+a_{n-1}} N \\approx (4/3)^n N")#text(" by the equation just after (3). (A good rule of thumb is that each iterate of the Syracuse map tends to reduce the magnitude by about 3/4 on the average.) Applying this heuristic to ")#mi("N=1")#text(", and setting ")#mi("x = (4/3)^n")#text(", we then arrive at a predicted value of ")#mi("\\gamma")#text(" given by")

#mi("\\displaystyle ((4/3)^n)^\\gamma = (3^{-\\beta n} 2^{2n})")

#text("or equivalently")

#mi("\\displaystyle \\gamma = \\frac{\\log 4 - \\beta \\log 3}{\\log 4 - \\log 3}")

#text("or")

#mi("\\displaystyle \\beta = \\frac{\\log 4 - \\gamma \\log(4/3)}{\\log 3}.")

#text("If we take this numerology as the value of the best in principle value of ")#mi("\\gamma")#text(" one can get for a given ")#mi("\\beta")#text(", this argument would need ")#mi("\\beta")#text(" to be less than ")#mi("\\log 4 / \\log 3 \\approx 1.26")#text(" to get a nontrivial bound for ")#mi("\\gamma")#text(", and less than ")#mi("\\frac{\\log 4 - 0.84 \\log(4/3)}{\\log 3} \\approx 1.04")#text(" to improve upon Krasikov-Lagarias. (For comparison, the inequality ")#tao-math("\\beta \\leq \\left|\\log_3 c_2\\right|", block: false)#text(" gives an upper bound for ")#mi("\\beta")#text(" of ")#mi("\\log(63/2)/\\log 3 \\approx 3.14")#text("; this can presumably be improved upon substantially, but clearly there is a gap to close here. Perhaps a computation of ")#mi("c_3")#text(" and ")#mi("c_4")#text(" would shed some more light on the situation.) However if one wishes to get a better numerical value of ")#mi("\\gamma")#text(", it may be possible to work with a more complicated quantity than ")#mi("\\beta")#text(", taking into account the entire distribution of the Syracuse random variable and not just the infimal value of the distribution function. (In some sense this is what Krasikov and Lagarias actually do, though not quite in this language.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e0fd56049a8189a380fda42273fee0bc2b9ce50a7a224700afce1fe96194008-d71b4d207f9bb85a02159d9eb02ffc3ded2bfbce61de425e7d3d85b4f53db867.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uwe Stroinski")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537428")[#strong[#text("Uwe Stroinski")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2020")])]

#text("Instead of computing the ")#mi("c_n")#text(" for large ")#mi("n")#text(" exactly it might be sufficient to lower bound the numerator by ")#mi("1")#text(" and to work out the denominator with your recursive formula.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537434")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2020")])]

#text("The denominator unfortunately grows quite fast: the worst case is that the denominator for ")#mi("c_n")#text(" is ")#mi("\\prod_{m =0}^n (2^{2 \\times 3^m} - 1)")#text(", though already for ")#mi("n=2")#text(" there is a little bit of cancellation and the final denominator ends up being ")#mi("2^{2 \\times 3}-1 = 63")#text(" rather than ")#mi("(2^2-1) \\times (2^{2 \\times 3}-1) = 189")#text(". My feeling is that while it is technically true that the probability densities are rational numbers, by the time ")#mi("n")#text(" gets even moderately large (e.g., ")#mi("n=4")#text(") it is better off thinking of them as being generic real numbers.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537303")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2020")])]

#text("The inequality ")#mi("c_n \\leq 3^{-\\beta (n-1)}")#text(" (given below proposition 3) seems to imply an upper (not lower!) bound on ")#mi("\\beta")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537389")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2020")])]

#text("Mistakes like these tend to come from fatigue. And they tend to artificially bolster one’s confidence, especially if the subject is integral to one’s philosophical gestalt.")

#text("Taking a break is a good thing. Take care! Best wishes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537333")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2020")])]

#text("Wow, very exciting result. I am just wondering, can you make o(1) arbitrarily small, meaning that o(1) goes to 0 and thus having the collatz conjecture settled?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537406")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2020")])]

#text("Not with the current argument, but I would imagine that the limit of the method would be to show that the preimage of any given number ")#mi("N")#text(" not divisible by 3 has positive density (so the ")#mi("x^{-o(1)}")#text(" error would be replaced by an constant depending only on ")#mi("N")#text("). Note that my previous paper already shows that a positive proportion of all orbits reach a bounded value, so by the pigeonhole principle there is at least one number ")#mi("N")#text(" whose preimage has positive density.")

#text("As I stated in the previous post, the full Collatz conjecture is still well out of reach of current methods (though Alex Kontorovich ")#link("https://twitter.com/AlexKontorovich/status/1172715174786228224")[#text("has recently pointed out")]#text(" that there is a remote possibility that one could perhaps engineer a counterexample to the conjecture if one could somehow demonstrate enough “Turing completeness” to the iteration). However, partial results such as these can still give various worthwhile insights on the nature of the problem and its connection to other questions, even if this is not sufficient to lead to a full resolution of the problem. For instance these arguments seem to indicate that the 3-adic structure of the Collatz iteration (as captured by the Syracuse random variables ")#mi("\\mathbf{Syrac}({\\bf Z}/3^n{\\bf Z})")#text(") should be studied further, particularly for statistical versions of the Collatz conjecture (in which one is primarily focused on controlling the behaviour of “typical” orbits rather than _all_ orbits); previous work has focused more on the 2-adic structure than the 3-adic (and perhaps ultimately the two need to somehow be combined, though how to do so is still beyond our current technology). Related to this, these arguments also highlight the fact that the Syracuse map ")#mi("\\mathrm{Syr}")#text(" is better suited than the Collatz map ")#mi("\\mathrm{Col}")#text(" (or the standard acceleration ")#mi("\\mathrm{Col}_2")#text(") for studying the 3-adic structure (this is basically because each application of ")#mi("\\mathrm{Syr}")#text(" contains precisely one multiplication by 3 and a variable number of divisions by ")#mi("2")#text(", in contrast for instance to ")#mi("\\mathrm{Col}_2: n \\mapsto \\frac{3n+1}{2}, \\frac{n}{2}")#text(" that contains exactly one division by 2 but a variable number of multiplications by ")#mi("3")#text("). As I previously mentioned, I think it will also be instructive to see how these results depend on the precise parameters of the Collatz-type iteration one is studying (e.g., if one replaces ")#mi("3x+1")#text(" with some other affine form).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537411")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2020")])]

#text("It may help if you define positive density. Do you mean positive ‘natural’ density. I think you are confusing natural density with some other one.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537431")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2020")])]

#text("The arguments in my paper currently apply to logarithmic density, but I believe this is mainly a technical restriction and that with some additional work they can be upgraded to natural density (I believe someone is looking into this question right now); see Remarks 1.4 and 1.16 of my paper.")

#text("More generally, it is often the case in analytic number theory problems that an easier result in logarithmic density (or sometimes Dirichlet density) is established first, with the harder natural density result coming later, so it makes sense to focus first on the logarithmic density problem to get some initial results, basically because the logarithmic density enjoys some approximate multiplicative invariance properties that natural density lacks. (For instance, the fact that the set ")#mi("\\{ n: \\lambda(n)=+1\\}")#text(" of numbers that are the product of an even number of primes has logarithmic density 1/2 can be proven in an elementary half-page argument, but to get natural density 1/2 is equivalent to the prime number theorem. The fact that ")#mi("\\{ n: \\lambda(n)=\\lambda(n+1)=+1\\}")#text(" has logarithmic density 1/4 was only established in 2015, but the natural density statement remains open, being the first unknown case of the Chowla conjecture.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537437")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2020")])]

#text("There are infinite sets where the natural and log densities are equivalent. But there are also, if I recall, infinite subsets where the natural density is not defined. And also infinite subsets where the natural density is zero. Bridging the gap between the two densities in light of all these obstacles seems crazy to me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537535")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")])]

#text("Maybe you used this Theorem already,")#linebreak()#text(" Davenport–Erdős theorem.")

#text("The reverse direction iterations make the mind swirl. Trying to use the forms one gets to say whether some notion of logarithmic density transfers to natural density looks crazy.")

#text("My work gives concrete examples one can use to test the idea with. But even staying abstract is a waste of time.")

#text("I support horizontal progress, but it isn’t partial progress to me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537544")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")])]

#text("Somewhere in the above arguments I saw n sub j minus n sub j, which is zero. Too tedious to track and check whether you’ve some indexing error. These iterations are a hell.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537553")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")])]

#text("Saw an inequality where it should perhaps read n sub (j -1) – 1 instead of n sub (j) – 1.")

#text("Anyway, epsilon cannot be between 0 and 1 and all of these inequalities hold in general.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dmitriy Z")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537369")[#strong[#text("Dmitriy Z")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2020")])]

#text("It seems that the inequality ")#mi("c_n \\le \\frac{3}{2}3^{-n}")#text(" should be in other direction. So this implies that ")#mi("\\beta \\ge 1")#text(" while an upper bound on ")#mi("\\beta")#text(" is ")#tao-math("\\left|\\log_3 c_2\\right|", block: false)#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537392")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2020")])]

#text("I don’t think it is possible to find and ‘repair’ where all of the probabilistic type approaches “fail”. They fail from the start, and so cannot be ‘repaired”. There is no remedy. But it obviously won’t stop more folks from trying. Absolutely bizarre….")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/61fe96948c5a63ccf3c158b300059337fefc1b16d8fbf0668f70f40339d67920-a25a80f8fc491e04880f184c06eb5c36e7e752dcd9b0302f8e601cd1ac85960c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gottfried H")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-540937")[#strong[#text("Gottfried H")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2020")])]

#text("@Jeff – might you please provide a link to your work?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537550")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")])]

#text("In the definition of ")#mi("c_n")#text(", it seems that the constraint ")#mi("3 \\mid b")#text(" should be removed.")

#emph[#text("[It’s actually ")#mi("3 \\nmid b")#text(", but there was a LaTeX issue that I will try to correct – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537576")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")])]

#text("It seems simpler to just remove this constraint (thereby simplifying the expression for ")#mi("c_n")#text(") since this constraint (")#mi("3 \\mid b")#text(") clearly does not contribute to the probability expression of ")#mi("c_n")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537584")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")])]

#text("Unfortunately this would then make the infimum equal to zero.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537588")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")])]

#text("I meant that in the expression for ")#mi("c_n")#text(", the probability in the RHS (for each fixed n) as a function of ")#mi("b")#text(" should vanish(!) whenever ")#mi("3 \\mid b")#text(". Hence inclusion or removal of this constraint should not affect the expression for ")#mi("c_n")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537620")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")])]

#text("The infimum of a set of non-negative numbers will vanish if one or more zeroes are added to the set on which the infimum is taken. (This is in contrast to the supremum, which remains unaffected by addition of zero entries.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537563")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")])]

#text("In the definition of ")#mi("c_n")#text(" (just above equation (4)), should ")#mi("3^2")#text(" be ")#mi("3^n")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537565")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")])]

#text("Also, this isn’t an error, but it took me a while to figure out why the summand in Definition 1 is ")#mi("3^{n-m} 2^{-a_m-a_{m+1} - \\cdots - a_n}")#text(", but the summand in the 3-adic discussion below is ")#mi("3^{m-1} 2^{-a_1-a_2-\\cdots-a_m}")#text(". (Answer: You made the change of variable ")#mi("m^{\\prime} = n+1-m")#text(" and reindexed ")#mi("a^{\\prime}_j = a_{n+1-j}")#text(". So ")#mi("n-m = m^{\\prime}-1")#text(" and ")#mi("a_m+a_{m+1} + \\cdots + a_n = a^{\\prime}_1 + a^{\\prime}_2 + \\cdots + a^{\\prime}_m")#text(". Then you sent ")#mi("n \\to \\infty")#text(".)")

#emph[#text("[Clarification added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da0ec9b31e705282008f3ab8aeddb7301d9dbed14ad1c06f1f2ac827c0693df8-14b8c1f1069c91b68ee14e0162b6103030088b46ee4703d45ff4b4182b239997.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jürgen Sander")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537566")[#strong[#text("Jürgen Sander")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")])]

#text("Dear Terence,")

#text("just for historical completeness you may wish to know that, independently of the work of Krasikov, a comparable â though slightly weaker (my constant 3/10, Krasikovâs constant 3/7) â result was published (see attachment) at the same time.")

#text("Best wishes,")#linebreak()#text(" JÃ¼rgen")

#text("“”””””””””””””””””””””””””””””””””””””””””””””””””””””””””””””””””")#linebreak()#text(" Prof. Dr. JÃ¼rgen Sander")

#text("VizeprÃ¤sident fÃ¼r Studium, Lehre, studentische Belange")#linebreak()#text(" und Digitalisierung")

#text("UniversitÃ¤t Hildesheim")

#text("UniversitÃ¤tsplatz 1, D-31141 Hildesheim, Germany")#linebreak()#text(" Telefon.: +49 (0)5121 883-40140")#linebreak()#text(" Email: ")#link("mailto:sander@imai.uni-hildesheim.de")[#text("sander@imai.uni-hildesheim.de")]#text(",")#linebreak()#text(" Sekret.: Tel. +49 (0)5121 883-40100, Fax +49 (0)5121 883-40101")

#text("“”””””””””””””””””””””””””””””””””””””””””””””””””””””””””””””””””")

#emph[#text("[Reference added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a47d47e95fcd24a3f41dfbff1015ccb0d0936409c31ad8a95de463d8e71cca86-537a73a0ee4ae2704991ef894a45295132a107125042924a108fb86d88bcfd11.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allan van Hulst")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537585")[#strong[#text("Allan van Hulst")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")])]

#text("I’m curious if you were able to resolve (some) of the difficulties described in the previous post relating to the explicit computation (where a technical limitation around n=10 arose, if I remember correctly).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537834")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2020")])]

#text("Dear Pro.Tao,")#linebreak()#text(" By the way, firstly I would like to greet” Happy New Year” to you. Next, I need to suggest some ideas which is not related to above topic. I really think you do not spend most of time solving Collatz conjecture 100%. Your past Collatz conjecture paper was very good.If there is a string between Collatz, Goldbach, Twin prime, Riemann , you should do Collatz 100% as you as possible. My idea is very stupid , foolish and crazy. I do not need any one understands me.")#linebreak()#text(" I think you should spend most of time focusing on Hodge conjecture and Birch Swinnerton Dyer conjecture . I think two above problems are very easy if comparing the rest of 4 problems. The level of two problems is equal to Poincare conjecture. Poincare conjecture is very very very hard , but it there is still a point end “bottom”. In contrast of four rest problems, they do not have bottom like the center of Pacific ocean. I guarantee more 200 years ,noone can solve them.Although I am not an expert in maths, I believe in my sense completely. This is not proved by sience. I always use my sense to help and save many people. My predictions are always true and right in every field of human beings. I always want to bring many good things to you. Pro.Tao , you should quickly do the greatest thing before 50 age. Not over 65 age.")#linebreak()#text(" Today, a crazy man meets a genius man each other. I do not need you reply my question. I only want you think deeply my idea every night before bedtime. I always side by side to you.")#linebreak()#text(" Byebye ,Pro.Tao.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c8b535ba19730c35a11a54e0f6a172b8257b3231d3f6bcb585012a98f16a4c7-b074f52a1020db534fef6621b105be8a1ffe96a2efd905bdf88cb80e35925a68.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ehud Schreiber")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537598")[#strong[#text("Ehud Schreiber")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")])]

#text("I seem to be confused – you say that c_3 and c_4 should be computed, but in the previous post it seems you’ve computed the steady-state distribution up to n=10, so essentially have the c’s up to that. If so, how does the “empirical” slope of -log_3(c_n) look like? Does it support beta = 1?")

#emph[#text("[I have that data on my home computer; will look it up later this afternoon -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537631")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")])]

#text("OK, here is the data I have:")

#mi("n")#text(" ")#mi("c_n")#text(" ")#mi("-\\log(c_n)/(n-1)")#linebreak()#text(" 2 0.031746 3.140")#linebreak()#text(" 3 0.006096 2.321")#linebreak()#text(" 4 0.001789 1.919")#linebreak()#text(" 5 0.000445 1.756")#linebreak()#text(" 6 0.000124 1.637")#linebreak()#text(" 7 0.000035 1.555")#linebreak()#text(" 8 0.000011 1.4785")#linebreak()#text(" 9 0.000003 1.4331")#linebreak()#text(" 10 0.000001 1.3941")

#text("(Not completely confident in the numerical accuracy of the n=10 data.)")

#text("Particularly reassuring is the fact that ")#mi("c_n")#text(" begins decreasing by a factor of close to 3 after a while, which is consistent with the upper bounds for ")#mi("\\beta")#text(" converging to 1. On the other hand it doesn’t look like brute force by itself is going to lead to any computationally feasible improvement of the Krasikov-Lagarias exponent this way.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537644")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")])]

#text("Is it possible to combine the current approach with the Krasikov-Lagarias approach ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537734")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2020")])]

#text("Good question! I think their linear programming approach could conceivably lead to some more refined bounds on ")#mi("c_n")#text(" that could lead to slightly sharper numerical upper bounds on ")#mi("\\beta")#text(", and perhaps they may shed some light on how one might hope to reach ")#mi("\\beta=1")#text(". Roughly speaking, translated to this setting, the approach proceeds by exploiting various inequalities between the more general quantities")

#mi("\\displaystyle c_n(b,m) := \\inf_{b^{\\prime} = b \\text{ mod } 3^m} {\\bf P}( {\\bf Syrac}({\\bf Z}/3^n{\\bf Z}) = b^{\\prime} )")

#text("for various residue classes ")#mi("b \\text{ mod } 3^m")#text(" with ")#mi("1 \\leq m \\leq n")#text(", thus for instance ")#mi("c_n = \\min( c_n(1,1), c_n(2,1) )")#text(" (and ")#mi("c_n(b,m)")#text(" vanishes when ")#mi("b")#text(" is a multiple of 3). Clearly these quantities are all non-negative with")

#mi("\\displaystyle c_n(b,m) = \\mathrm{min}( c_n(b, m+1), c_n(b+3^m, m+1), c_n(b+2 \\times 3^m, m+1))")

#text("and there is also a recursive inequality")

#mi("\\displaystyle c_{n+1}(b,m+1) \\geq \\frac{ \\sum_{1 \\leq a \\leq 2 \\times 3^m: 2^a b = 1 \\text{ mod } 3} 2^{-a} c_n( \\frac{2^a b - 1}{3}, m ) }{1 - 2^{-2 \\times 3^m}}")

#text("that follows easily from Lemma 1.12 of my paper. Thus for instance")

#mi("c_n(1,1) = \\mathrm{min}( c_n(1,2), c_n(4,2), c_n(7,2) )")

#mi("c_n(2,1) = \\mathrm{min}( c_n(2,2), c_n(5,2), c_n(8,2) )")

#mi("c_{n+1}(1,2) \\geq \\frac{64}{63} ( \\frac{1}{4} c_n(1,1) + \\frac{1}{16} c_n(2,1) )")

#mi("c_{n+1}(2,2) \\geq \\frac{64}{63} ( \\frac{1}{2} c_n(1,1) + \\frac{1}{8} c_n(2,1) )")

#mi("c_{n+1}(4,2) \\geq \\frac{64}{63} ( \\frac{1}{64} c_n(1,1) + \\frac{1}{4} c_n(2,1) )")

#mi("c_{n+1}(8,2) \\geq \\frac{64}{63} ( \\frac{1}{32} c_n(1,1) + \\frac{1}{2} c_n(2,1) )")

#mi("c_{n+1}(7,2) \\geq \\frac{64}{63} ( \\frac{1}{16} c_n(1,1) + \\frac{1}{64} c_n(2,1) )")

#mi("c_{n+1}(5,2) \\geq \\frac{64}{63} ( \\frac{1}{8} c_n(1,1) + \\frac{1}{32} c_n(2,1) )")

#text("etc.. One can then hope to prove various lower bounds of the form ")#mi("c_n(b,m) \\geq a_{b,m} 3^{\\beta n}")#text(" for various constants ")#mi("a_{b,m}")#text(" by induction provided that ")#mi("a_{b,m}, \\beta")#text(" obey certain inequalities of their own (basically a dual set of inequalities to the ones listed above). This approach can probably improve slightly upon the bound ")#mi("\\beta \\leq -\\log(c_n)/(n-1)")#text(" that I am using here (for instance I would imagine that the inequalities listed above would already improve upon the first bound ")#mi("\\beta \\leq 3.14")#text(" by a fair amount), though it would require significantly more numerical effort for any given value of ")#mi("n")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537741")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2020")])]

#text("Looking at the Krasikov-Lagarias paper, they observe a symmetry that I had not previously noticed, which in my notation is that")

#mi("{\\bf P}( {\\bf Syrac}({\\bf Z}/3^n {\\bf Z}) = 2b ) = 2 {\\bf P}( {\\bf Syrac}({\\bf Z}/3^n {\\bf Z}) = b )")

#text("whenever ")#mi("n \\geq 1")#text(" and ")#mi("b = 1 \\text{ mod } 3")#text(", which basically follows from splitting the geometric random variable ")#mi("\\mathbf{a}_1")#text(" appearing in (2) as ")#mi("2 \\mathbf{a}^{\\prime}_1 - \\mathbf{c}")#text(" where ")#mi("\\mathbf{a}^{\\prime}_1")#text(" is another geometric random variable of mean 4/3 (so ")#mi("\\mathbf{a}^{\\prime}_1=n")#text(" with probability ")#mi("3 \\times 4^{-n}")#text(") and ")#mi("\\mathbf{c} \\in \\{0,1\\}")#text(" is a Bernoulli random variable of mean 2/3, independent of all the other variables, and then observing that the residue class of (2) mod 3 is entirely determined by ")#mi("\\mathbf{c}")#text(". So this simplifies the preceding calculations because we now have ")#mi("c_n(2b,m) = 2 c_n(b,m)")#text(" whenever ")#mi("b = 1 \\text{ mod } 3")#text(". In particular ")#mi("c_n(1,1) = c_n")#text(", ")#mi("c_n(2,1) = 2c_n")#text(", and the above system of inequalities basically simplifies after some calculation to")

#mi("c_{n+1} \\geq \\frac{2}{21} c_n")

#text("leading to the bound ")#mi("\\beta \\leq 2.14")#text(" instead of ")#mi("\\beta \\leq 3.14")#text(". More generally I think with this new observation that the bound ")#mi("c_{n_1+n_2-1} \\geq c_{n_1} c_{n_2}")#text(" improves to ")#mi("c_{n_1+n_2-1} \\geq 3 c_{n_1} c_{n_2}")#text(" (we gain a factor of 3 in (5) now), leading to the improved bound ")#mi("\\beta \\leq - \\log(3c_n)/(n-1)")#text(" which for instance improves the ")#mi("n=10")#text(" bound to ")#mi("\\beta \\leq 1.2830")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537898")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2020")])]

#text("Is it possible that there are other similar splittings of random variables which may lead to additional other symmetries and recursive relations for more efficient computation of ")#mi("c_n")#text(" and improved related inequalities ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537942")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2020")])]

#text("So I now realise that the above identity generalises to")

#mi("{\\mathbf P}( \\mathbf{Syrac}({\\mathbf Z}/3^n {\\mathbf Z}) = 2b )")#linebreak()#text(" ")#mi("= 2 {\\mathbf P}( \\mathbf{Syrac}( {\\mathbf Z}/3^n {\\mathbf Z}) = b ) - {\\mathbf P}( \\mathbf{Syrac}( {\\mathbf Z}/3^{n-1} {\\mathbf Z}) = \\frac{2b-1}{3} ),")

#text("for any integer ")#mi("b")#text(" and any ")#mi("n \\geq 1")#text(", with the convention that the second term on the RHS vanishes when ")#mi("\\frac{2b-1}{3}")#text(" is not an integer. In fact this identity uniquely determines the Syracuse random variables. The identity follows from the fact that the geometric random variable ")#mi("{\\mathbf a}_1")#text(" is equivalent to the random variable that equals ")#mi("1")#text(" with probability ")#mi("1/2")#text(" and ")#mi("\\mathbf{a}_1+1")#text(" with probability ")#mi("1/2")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537651")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")])]

#text("Lemma 2 indicates the possible convexity of the sequence")#linebreak()#text(" ")#mi("\\log c_n /(n-1)")#text(" of (decreasing ?) upper bounds for ")#mi("\\beta")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c8b535ba19730c35a11a54e0f6a172b8257b3231d3f6bcb585012a98f16a4c7-b074f52a1020db534fef6621b105be8a1ffe96a2efd905bdf88cb80e35925a68.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ehud Schreiber")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537684")[#strong[#text("Ehud Schreiber")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2020")])]

#text("Writing a quick-and-dirty R code, I get the same results for ")#mi("n \\leq 4")#text(".")#linebreak()#text(" In particular, ")#mi("c_3 = 1598/(2^{18} - 1)")#text(", so the cancellation persists. I can’t say for ")#mi("c_4")#text(", as it involves ")#mi("2^{54} - 1")#text(" while double precision gives only 53 bits of precision…")

#text("Looking at the values of ")#mi("-\\log_3 c_n")#text(" it certainly seems that ")#mi("\\beta = 1")#text(", although it would be difficult to distinguish between that and ")#mi("\\beta = 1.1")#text(". It even seems that ")#mi("-\\log_3 c_n")#text(" is ")#mi("n + O(1)")#text(" or even ")#mi("n + \\text{const} + o(1)")#text(", but again distinguishing between that and ")#mi("n + O(\\log n)")#text(" is impossible with this “empirical” data.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537695")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2020")])]

#text("You can you use my work to get real data to compare this bizarre guesswork with. It was a hell to figure out.")

#text("But unfavorable comparisons take all the fun out of guessing games. Better to keep the blinders on :).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537726")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2020")])]

#text("This observed cancellation indicates that the sequence")#linebreak()#text(" ")#mi("d_n: = (2^{2 \\times 3^{n-1}} -1) c_n")#text(" is a sequence of integers.")#linebreak()#text(" If so, the recursive expression for ")#mi("c_n")#text(" can be used to find the corresponding recursive expression for ")#mi("d_n")#text(" which may be used to prove that ")#mi("d_n")#text(" is indeed a sequence of integers.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537931")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2020")])]

#text("Numerically, I can obtain ")#mi("d_1=1, d_2 = 2, d_3=1598, d_4 = 322293411417192")#text(", and then I run out of precision. This sequence does not appear in the OEIS (of course, we haven’t yet proven that it is even a sequence of integers; perhaps if we do I will submit it there). But it is clear that the series grows extremely fast (one has ")#mi("d_n = 2^{2 \\times 3^n - O( n )}")#text(" for instance).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537938")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2020")])]

#text("Yeah, I had to resort to doing the large calculations in my mind when my machine ran out of precision :). And of course my subsequent proofs are rigorous. But who cares?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537733")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2020")])]

#text("Interesting! I will check my own data later today but perhaps it can be conjectured that the probability densities ")#mi("{\\bf P}( \\mathbf{Syrac}({\\bf Z}/3^n{\\bf Z})=b)")#text(" are always integer multiples of ")#mi("1 / (2^{2 \\times 3^{n-1}}-1)")#text(". If this conjecture is true, it is presumably due to some alternate formula for these densities that I’m not seeing currently, but which may be worthwhile to uncover.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537897")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2020")])]

#text("This conjecture means that the cancelled factor is ")#mi("2^{3^{n-1}} +1")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-685758")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2024")])]

#text("Dear prof. Tao,")

#text("I managed to get up to n=19. I did not run into memory issues but computational speed issues. n=20 would have taken a month. Your accuracy at n=10 is perfect. Or at least I got the same answer. I am quite sure I have used a completely different method.")

#text("n cn -log3(cn)/(n-1)")#linebreak()#text("2 0.031745910 3.140317486")#linebreak()#text("3 0.006095873 2.321175227")#linebreak()#text("4 0.001789068 1.919409395")#linebreak()#text("5 0.000444575 1.756395817")#linebreak()#text("6 0.000123991 1.637575751")#linebreak()#text("7 3.52543E-05 1.555435349")#linebreak()#text("8 1.14414E-05 1.479564651")#linebreak()#text("9 3.38689E-06 1.433125938")#linebreak()#text("10 1.03095E-06 1.394186227")#linebreak()#text("11 3.07406E-07 1.364912566")#linebreak()#text("12 9.9569E-08 1.334114066")#linebreak()#text("13 3.14237E-08 1.310418557")#linebreak()#text("14 9.80922E-09 1.291135355")#linebreak()#text("15 3.07433E-09 1.274346551")#linebreak()#text("16 9.97263E-10 1.257708308")#linebreak()#text("17 3.23295E-10 1.243185072")#linebreak()#text("18 1.04342E-10 1.230608541")#linebreak()#text("19 3.42233E-11 1.218613844")

#text("I have the probability distribution for al b’s up to n=19 in a single database. My approach is completely different but I was able to convert my approach (by a simple division) into yours. Would love to discuss this with you. I may have found a way to crack it!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-685759")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2024")])]

#text("My name got lost. The post on 10 sept 2024 at 7.40 was made by Glenn Rexwinkel")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ecd3505053e823752e133e50092b53322e52a28b1566e42b351cf4683bb37b5-71206d714602e6fa76e941616865d1b5606cc72b044287d8e45e6f273d56bfc0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.P. McCarthy")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537692")[#strong[#text("J.P. McCarthy")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2020")])]

#text("that ")#mi("1 \\in \\mathrm{Col}^{{\\bf N}}(n)")#text(" for all ")#mi("N \\in \\bf{N}+1")#text(".")

#text("Should be ")#mi("n\\in\\bf{N}+1")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39d042cd343763a0074f825ecdf61ade3a1f833c09d7322d7ed33b69d91748e0-004ee65ff1042e640b0bfa8bf9563704de056663a81b46994f471f2da9bfde76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bogdan")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537813")[#strong[#text("Bogdan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2020")])]

#text("You write:”…a positive density set of natural numbers iterates to an (explicitly computable) bounded set, so in principle the case \\gamma=1 of (1) could now be verified by an (enormous) finite computation”")

#text("I do not understand this for two reasons.")

#text("First, the title of your paper talks about “almost bounded values”, not bounded ones. And to reduce the problem to finite computation, we ready need the orbits to iterate to BOUNDED set, not almost bounded one.")

#text("Second, the case \\gamma=1 of (1) seems to correspond to “almost all” with NATURAL density, while your paper proves the statement for a different density.")

#text("Can you please clarify?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537841")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2020")])]

#text("I’m confused about why anyone would do the above bizarre guesswork when I already rid us of such crutches several years ago.")

#text("The quest for a positive density is a waste of time too, using probabilistic methods. Good grief people. Didn’t the 3x-1 case teach you all anything?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537882")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2020")])]

#text("This is discussed further in Remarks 1.4 and 3.1 of the paper. The argument that shows that almost all values iterate to almost bounded values also shows (and is in fact equivalent to) the assertion that for any ")#mi("\\delta>0")#text(", there is a ")#mi("C>0")#text(" such that a set of natural numbers of logarithmic density at least ")#mi("1-\\delta")#text(" iterate to a value bounded by ")#mi("C")#text(" (and in fact the arguments give an in principle explicit relation between ")#mi("C")#text(" and ")#mi("\\delta")#text(", which I believe to be of the form ")#mi("C = \\exp( \\delta^{-O(1)})")#text("). In particular, setting ")#mi("\\delta")#text(" to be any fixed value between 0 and 1, e.g., ")#mi("\\delta=1/2")#text(", we conclude that there is a positive (logarithmic) density set of numbers that iterates to an explicitly computable bounded set.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-538070")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2020")])]

#text("Have you tried working this argument out with pre-images of 3x-1 ?")

#text("What do you mean exactly by ‘in principle’?")

#text("Is it explicit or not?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-538117")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2020")])]

#text("Every step in the argument can be made quantitative (with no ")#link("https://en.wikipedia.org/wiki/Effective_results_in_number_theory")[#text("ineffective")]#text(" bounds), so it is just a matter of carefully keeping track of all the implied constants if one wants. However, this would be time consuming and quite messy to optimize; usually it is more efficient to wait until the non-explicit form of an argument has become more streamlined before attempting to invest the effort to convert it to a fully explicit form.")

#text("Regarding the 3x-1 problem: it needs to be checked, of course, but I expect that pretty much all the results in my paper (or in this blog post) will carry over with only minor changes to the 3x-1 problem. Now it is of course true that the direct analogue of the Collatz conjecture is false for the 3x-1 conjecture due to the existence of the two known additional cycles (5,14,7,20,10) and (17,50, …, 34). However this does not exclude the possibility that progress can be made simultaneously on understanding both iterations. For instance, one could envisage that there is an argument common to both the 3x+1 and 3x-1 iterations that establishes the existence of an absolute constant C such that all orbits of either iteration end up reaching a number less than or equal to C: note that the two additional cycles of the 3x-1 iteration are not in contradiction to the above claim. If we could prove this partial result, and if C could be given explicitly and was of a computationally feasible magnitude, one could then finish off the 3x+1 conjecture for good by numerically verifying that all iterates of the 3x+1 map starting from a number less than or equal to C eventually reached 1. This would of course not work for the (false) 3x-1 conjecture due to the existence of the additional two cycles, so the failure of the 3x-1 conjecture does not prohibit this strategy from being a viable approach to the 3x+1 problem. [Basically, one should make a distinction between the asymptotic and non-asymptotic components of the dynamics. The 3x+1 and 3x-1 dynamics differ non-asymptotically (by which I mean the dynamics on small integers ")#mi("n \\leq C")#text(") due to the additional cycles possessed by the former but not the latter, but there is no evidence at present that the asymptotic dynamics of the two (by which I mean the dynamics on large integers ")#mi("n > C")#text(") are particularly different from each other. Indeed, one could unify the 3x+1 and 3x-1 dynamics by working on the integers rather than the natural numbers, in which case the unified conjecture asserts that all orbits eventually reach one of the five known cycles (listed for instance on ")#link("https://en.wikipedia.org/wiki/Collatz_conjecture#Iterating_on_all_integers")[#text("the Wikipedia page")]#text("), of which only one lives in the positive integers, with three others living in the negative integers and one being the zero cycle.]")

#text("That said, I don’t view the results of my paper as coming close to giving a partial result of the above form. However, a realistic goal would be that of obtaining an explicit C for which iterations of either the 3x+1 or 3x-1 map would end up reaching a value C or below for a set of positive (logarithmic) density. Again, combined with a suitable numerical verification, this would establish the 3x+1 conjecture for a set of inputs of positive logarithmic density, without being in contradiction to the failure of the 3x-1 conjecture.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-538122")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2020")])]

#text("It seems that establishing explicit numerical bounds ")#mi("C")#text(" corresponding to some given logarithmic densities and improving the current bound for ")#mi("\\gamma")#text(" are suitable for a Polymath project.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-538131")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2020")])]

#text("I must say I admire your optimism and energy. And I especially admire your dedication to your convictions. If you polymath this, doing large calculations on 3x-1 prior may help. Perhaps the ‘17’ cycle acts as a catch or net of sorts such that ‘more’, in the sense of some density measure, numbers map to it than the other two separately, whether or not there are more cycles.")

#text("Just stay healthy sir.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-537941")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2020")])]

#text("I can now establish that ")#mi("c_n")#text(" is always an integer multiple of ")#mi("1/(2^{2 \\times 3^{n-1}}-1)")#text(". In fact, if for any integer ")#mi("b")#text(" we define the quantities")

#mi("\\displaystyle d_n(b) := (2^{2 \\times 3^{n-1}}-1) {\\mathbb P}( \\mathbf{Syrac}({\\bf Z}/3^n {\\bf Z} = b \\text { mod } 3^n )")

#text("then one can show inductively that the ")#mi("d_n(b)")#text(" are all natural numbers.")

#text("It is convenient to define ")#mi("d_n(b)=0")#text(" for ")#mi("b")#text(" non-integer. Then ")#mi("d_n")#text(" is periodic with period ")#mi("3^n")#text(", and ")#mi("d_1(0)=0, d_1(1)=1, d_1(2)=2")#text(". This establishes the ")#mi("n=1")#text(" case. To obtain the higher ")#mi("n")#text(" case we obtain a recursive formula for ")#mi("d_n(b)")#text(" that only involves integer arithmetic. We can assume that ")#mi("b")#text(" is an integer not divisible by 3, since ")#mi("d_n(b)")#text(" vanishes otherwise. From Lemma 1.12 of my paper and some calculation we see that")

#mi("\\displaystyle d_n(b) = \\frac{4^{3^{n-1}}}{4^{3^{n-2}}-1} \\sum_{a=1}^{2 \\times 3^{n-1}} d_{n-1}( \\frac{2^a b-1}{3} ) 2^{-a}. \\quad (1)")

#text("The main problem here is the denominator ")#mi("4^{3^{n-2}}-1")#text(", which needs to be canceled. The key point here is that")

#mi("\\displaystyle 2^{2 \\times 3^{n-2}} = 1 + 3^{n-2} \\text{ mod } 3^{n-1}")

#text("which is easily established by induction. Splitting the sum into triples ")#mi("a, a+2 \\times 3^{n-2},a+4 \\times 3^{n-2}")#text(" for ")#mi("1 \\leq a \\leq 2 \\times 3^{n-2}")#text(", we arrive at")

#mi("\\displaystyle d_n(b) = \\frac{4^{3^{n-2}}}{4^{3^{n-2}}-1} \\sum_{a=1}^{2 \\times 3^{n-2}} 2^{-a} \\times")

#mi("\\displaystyle ( 4^{2 \\times 3^{n-2}} d_{n-1}( \\frac{2^a b-1}{3} ) + 4^{3^{n-2}} d_{n-1}( \\frac{2^a b-1}{3} + 2^a b 3^{n-2})")

#mi("\\displaystyle + d_{n-1}( \\frac{2^a b-1}{3} + 2^{a+1} b 3^{n-2} ) ).")

#text("Now one observes that ")#mi("\\frac{2^a b-1}{3},  \\frac{2^a b-1}{3} + 2^a b 3^{n-2}, \\frac{2^a b-1}{3} + 2^{a+1} b 3^{n-2}")#text(" sweep out the residue classes mod ")#mi("3^{n-1}")#text(" that reduce to ")#mi("\\frac{2^a b-1}{3}")#text(" modulo ")#mi("3^{n-2}")#text(", hence")

#mi("\\displaystyle d_{n-1}( \\frac{2^a b-1}{3} ) + d_{n-1}( \\frac{2^a b-1}{3} + 2^a b 3^{n-2}) + d_{n-1}( \\frac{2^a b-1}{3} + 2^{a+1} b 3^{n-2} )")#linebreak()#text(" ")#mi("\\displaystyle = d_{n-2}( \\frac{2^a b-1}{3} ).")

#text("Using this and the ")#mi("n-1")#text(" case of (1), we arrive after some calculation at the recursive identity")

#mi("\\displaystyle d_n(b) = \\sum_{a=1}^{2 \\times 3^{n-2}} 2^{2 \\times 3^{n-2} - a} (d_{n-1}( \\frac{2^a b-1}{3} + 2^a b 3^{n-2} )")#linebreak()#text(" ")#mi("\\displaystyle + (4^{3^{n-2}}+1) d_{n-1}( \\frac{2^a b-1}{3} ) )")#linebreak()#text(" ")#mi("\\displaystyle + d_{n-1}(b)")

#text("and hence the ")#mi("d_n(b)")#text(" are all natural numbers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-538014")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2020")])]

#text("A bit of Basic algebra works wonders. Well, now you have a small taste of the amount of work I did.")

#text("Getting hooked on this will wear you down. It’s not worth it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4aba73246595af8ea0554c834a7ac4fbe0ee0ec25feb6b98b53f26f490ce923-6687e092c7bc015e84b352f3951935ed5d5507b3e9b45ffa3dfbc4ca9cd38f27.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gabe Khan")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-538063")[#strong[#text("Gabe Khan")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2020")])]

#text("I realize this might be too optimistic, and apologies again if this is obvious. However, from the recursive identity it seems that the most important term to get lower bounds on ")#mi("d_{n-1}(b)")#text(" is ")#mi("\\sum_{a=1}^{2 \\times 3^{n-2}} 2^{2 \\times 3^{n-2}-a} 4^{3^{n-2}} d_{n-1} ( \\frac{ 2^a b - 1}{3} )")#text(". Everything else in the series seems to be much smaller (i.e. grows slower than ")#mi("2^{2 \\times 3^{n-1}}")#text("). As such, if you could get an upper bound on how many small values of ")#mi("a")#text(" you can pick so that ")#mi("d_{n-1} ( \\frac{ 2^a b - 1}{3}  )")#text(" is zero (i.e. how many ")#mi("a")#text(" so that ")#mi("2^a b-1")#text(" is divisible by 9), one might hope that this gives something to induct on to get lower bounds on the ")#mi("c_n")#text(".")

#text("This alone is almost certainly not sharp enough to actually get good bounds, but that partial sum seems to be the key terms in the recursive formula.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-538112")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2020")])]

#text("Yes, this is the main term, and in fact the series should decay exponentially in ")#mi("a")#text(", so that only the first few terms should be significant. It may indeed make sense to truncate the recursive formulae for these sorts of expressions to the low values of ")#mi("a")#text(" (e.g., ")#mi("a \\leq 10")#text(") to obtain a sparser system of linear inequalities that could be more tractable even at the cost of a small amount of optimality in the final exponents.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4aba73246595af8ea0554c834a7ac4fbe0ee0ec25feb6b98b53f26f490ce923-6687e092c7bc015e84b352f3951935ed5d5507b3e9b45ffa3dfbc4ca9cd38f27.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gabe Khan")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-538203")[#strong[#text("Gabe Khan")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2020")])]

#text("Right, and since ")#mi("\\frac{1}{3} = \\sum_{a=1}^\\infty \\frac{1}{4^a}")#text(", this suggests that for a given ")#mi("n")#text(", we can expect to find ")#mi("b")#text(" so that ")#mi("d_{n-1}( \\frac{2^a b -1}{3})")#text(" vanishes for ")#mi("a = 1,3,5, \\ldots")#text(" However, it seems like this is somehow the “worst case”. By truncating the series, the hope would be to verify this to some level. As you mentioned, there will definitely be some loss in this approximation.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-538086")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2020")])]

#text("A classical approach to estimate ")#mi("c_n")#text(" is to find from its recursive expression the corresponding (functional) identity satisfied by its generating function (e.g. ")#mi("C(z) = \\sum_n c_n z^n")#text(") and estimate its coefficients (as done e.g. by the circle method for the partition function.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-538113")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2020")])]

#text("This is indeed tempting; however the formulae for ")#mi("c_n")#text(" contain a minimum at one point, which does not interact well with classical generating functions. (There is a remote possibility that some sort of “")#link("https://en.wikipedia.org/wiki/Tropical_semiring")[#text("tropical")]#text(" generating function” might be useful here, although those are more suited for working with maxima rather than minima.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6487b8870feab7a37d3c4844cf30a8e400d7a181f0eca982101de46e5af208d5-3cac68fb1d0a118b9dc866660162d3d5f6537fa83b0bbdcc6f3f34fd85ff97eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dyachenko Eduard")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-538441")[#strong[#text("Dyachenko Eduard")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2020")])]

#text("In the table, the transformation introduced by Collaz for the number 27 is parsed.")#linebreak()#text(" The main proffer is reduced the “length of the number” when converting oddness of the form 4k+1and possibilities preserving it when converting 4k+3.")#linebreak()#text(" Since the transformation 4k+3 cannot be stored indefinitely, periodically the “length of the number” decreases.")#linebreak()#text(" As a result the sequence to transformed a number of the form 2^p/3^q")#linebreak()#text(" The work can be read here(")#link("https://zenodo.org/record/3630682#.XjagkGhKjIU")[#text("https://zenodo.org/record/3630682#.XjagkGhKjIU")]#text(").")#linebreak()#text(" i n(i) D(i) r(i)-r(i)>1 4k(i)+1 4k(i)+3 k(i) P(i)")#linebreak()#text(" 0 27 1/ 2 -1 4*6+3 14+13 even 1")#linebreak()#text(" 1 41 1/ 4 -2 2 4*10 + 1")#linebreak()#text(" 2 31 1/ 2 -1 4*7+3 16+15 odd 4")#linebreak()#text(" 3 47 1/ 2 -1 4*11+3 odd")#linebreak()#text(" 4 71 1/ 2 -1 4*17+3 odd")#linebreak()#text(" 5 107 1/ 2 -1 4*26+3 even")#linebreak()#text(" 6 161 1/ 4 -2 2 4*40+1")#linebreak()#text(" 7 121 1/ 4 -2 2 4*30+1")#linebreak()#text(" 8 91 1/ 2 -1 4*22+3 46+45 even 1")#linebreak()#text(" 9 137 1/ 4 -2 2 4*34+1")#linebreak()#text(" 10 103 1/ 2 -1 4*25+3 52+51 odd 2")#linebreak()#text(" 11 155 1/ 2 -1 4*38+3 even")#linebreak()#text(" 12 233 1/ 4 -2 2 4*58+1")#linebreak()#text(" 13 175 1/ 2 -1 4*43+3 88+87 odd 3")#linebreak()#text(" 14 263 1/ 2 -1 4*65+3 odd")#linebreak()#text(" 15 395 1/ 2 -1 4*98+3 even")#linebreak()#text(" 16 593 1/ 4 -2 2 4*148+1")#linebreak()#text(" 17 445 1/ 8 -3 3 4*111+1")#linebreak()#text(" 18 167 1/ 2 -1 4*41+3 84+83 odd 2")#linebreak()#text(" 19 251 1/ 2 -1 4*62+3 even")#linebreak()#text(" 20 377 1/ 4 -2 2 4*94+1")#linebreak()#text(" 21 283 1/ 2 -1 4*70+3 213+212 even 1")#linebreak()#text(" 22 425 1/ 4 -2 2 4*106+1")#linebreak()#text(" 23 319 1/ 2 -1 4*79+3 160+159 odd 5")#linebreak()#text(" 24 479 1/ 2 -1 4*119+3 odd")#linebreak()#text(" 25 719 1/ 2 -1 4*179+3 odd")#linebreak()#text(" 26 1079 1/ 2 -1 4*269+3 odd")#linebreak()#text(" 27 1619 1/ 2 -1 4*404+3 even")#linebreak()#text(" 28 2429 1/ 8 -3 3 4*607+1")#linebreak()#text(" 29 911 1/ 2 -1 4*227+3 456+455 odd 3")#linebreak()#text(" 30 1367 1/ 2 -1 4*341+3 odd")#linebreak()#text(" 31 2051 1/ 2 -1 4*512+3 even")#linebreak()#text(" 32 3077 1/16 -4 4 4*769+1")#linebreak()#text(" 33 577 1/ 4 -2 2 4*144+1")#linebreak()#text(" 34 433 1/ 4 -2 2 4*108+1")#linebreak()#text(" 35 325 1/16 -4 4 4*81+1")#linebreak()#text(" 36 61 1/ 8 -3 3 4*15+1")#linebreak()#text(" 37 23 1/ 2 -1 4*5+3 12+11 odd 2")#linebreak()#text(" 38 35 1/ 2 -1 4*8+3 even")#linebreak()#text(" 39 53 1/32 -5 5 4*13+1")#linebreak()#text(" 40 5 1/16 -4 4 4*1+1")#linebreak()#text(" 41 1 1/ 1 0")#linebreak()#text(" balance -70 46 24")#linebreak()#text(" Text is available under the Creative Commons NonCommercial-NoDerivatives 4.0 International")#linebreak()#text(" (CC BY-NC-ND 4.0)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6487b8870feab7a37d3c4844cf30a8e400d7a181f0eca982101de46e5af208d5-3cac68fb1d0a118b9dc866660162d3d5f6537fa83b0bbdcc6f3f34fd85ff97eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dyachenko Eduard")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-538448")[#strong[#text("Dyachenko Eduard")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2020")])]

#text("Unfortunately, the table is not obvious, although I tried to insert correctly.")#linebreak()#text(" The work can be read here(")#link("https://zenodo.org/record/3630682#.XjagkGhKjIU")[#text("https://zenodo.org/record/3630682#.XjagkGhKjIU")]#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of y.y.")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-539317")[#strong[#text("y.y.")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2020")])]

#text("apologies for my english.")#linebreak()#text(" I have commented your previous blog posts about the conjecture. there I have appended professor Peter Hellekalek’s this paper:")#linebreak()#text(" ")#link("https://arxiv.org/abs/1605.02634")[#text("https://arxiv.org/abs/1605.02634")]#linebreak()#text(" the paper seems to concern Syracuse function in 3-adic as you mentioned.")#linebreak()#text(" and I wrote that ∀x∈(2N_0+1), ∃μ∈N, f^(1+μ)(x)＜x.")#linebreak()#text(" because the function have its inverse and it can be defined by RCWA with metrices.")#linebreak()#text(" the structure contains S_3 especially C_3 and yes, 2-adic is somehow combined. there is no randomness.")#linebreak()#text(" I don’t have background in mathematics, but I would be grateful if professor Tao could get to know my findings. it seems something important to prove (or progress to prove) the conjecture. thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of y.y.")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-539364")[#strong[#text("y.y.")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2020")])]

#text("Mistake. when x=1, f^(1+μ)(x)=x. 1 is a unique fixed-point. and μ=2, of course. As for the indices μ, it can also be defined as resides when it is in inverse form.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of y.y.")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-539932")[#strong[#text("y.y.")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2020")])]

#text("So the particular orbit such as; x∈2N_0+1, Syrac(x)→2N_0+1:= (3x+1)/2^-(1+n), Syrac(x)＞x.")#linebreak()#text(" These numbers can be determined as certain subset. Looking at the subset as in inverse, we can also demermine the image of the subset. Then consider the intersection of the image and its preimage, we see that the set of the intersecion goes to null at m times. I think that is not so interesting part of the problem for mathematicians. The interesting obserbation of the problem is that the syracuse function has its inverse which S_3 acts on.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-539944")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2020")])]

#text("Again mistake. Remove “/” or “-” from (3x+1)/2^-(1+n) ! Don’t factorial!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b38f377a107ffa1d9a77d24fc9e9f78f3380239ea30a78188d9760413d224f5-d4cd0e27cf9b0dae97f623aafca35e544acd2e515fd5aca8eb7cd3ef3cd9063d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter C")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-539843")[#strong[#text("Peter C")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2020")])]

#text("I’ve worked on this problem with varying approaches over the years. Recently msg’d you via email on a traverse method to the 3x+1 tree. Sourcing from odd multiple of 3 numbers, the problem can be converted into an infinite density series to explain that all numbers land at key nodes N*, and vice versa. Those key nodes (N*) all descend in a formulated way (which another infinite density series can explain) to other N*. I’d love to chat with you about it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b38f377a107ffa1d9a77d24fc9e9f78f3380239ea30a78188d9760413d224f5-d4cd0e27cf9b0dae97f623aafca35e544acd2e515fd5aca8eb7cd3ef3cd9063d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter C")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-541048")[#strong[#text("Peter C")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2020")])]

#text("As mentioned previously, if one defines a way to progress outward rather than the typical inward motions (i.e. to land a 1) it is easily shown that all numbers flow outwards to Mod(n,3)=0 nodes; traversing in the odd numbers only.")

#text("Such a step can be declared as:")#linebreak()#text(" NewN = w [(-3*(w^2)+7w)n -1] / [3(2^(w-1))], where w=MOD(n,3)")#linebreak()#text(" E.g 5->3, w=2, n=5, NewN=3; This would count as 1 step to get to divisible by 3.")

#text("A number like 17 would require 3 steps to get to a divisible by 3 outer node, div3 require no steps (i.e. 3, 9, 21, etc.)")

#text("This approach yields a density series: (x:0 to inf) Ʃ [2^x] / [3^(x+1)] = 1,")#linebreak()#text(" where x = STEPS to get w=0")

#text("However, such a method doesn’t guarantee that a given number & chain actually attaches to the rest of tree. Therefore a secondary density series explains that the attaching nodes all derive from other attaching nodes.")

#text("So Logically, if all numbers flow outwards to a div3, that chain contains an N* (can be considered the source node for that chain of nodes), N* comes from a (N*-1)/4 node [which will flow inward to its own relative N* and outward div3], etc.. A similar series can be generated here to ensure the total sum =1 as well.")

#text("Example: 35 would have 2 steps to to get to a div3. Its N* is 53, (N*-1)/4 = 13, 13 is an N*,")#linebreak()#text(" (13-1)/4 = 3, its N* is 5 (the base case).")

#text("This would account for all chains, unless one odd number out there isn’t part of a chain. If that happens, it would seem contradictory because that means an infinite amount of chains & nodes exist (so far not seen) that don’t link back using the (N*-1)/4 rule.")

#text("It my impression that the typical approaches to solving this problem are the problem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6487b8870feab7a37d3c4844cf30a8e400d7a181f0eca982101de46e5af208d5-3cac68fb1d0a118b9dc866660162d3d5f6537fa83b0bbdcc6f3f34fd85ff97eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-542173")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2020")])]

#text("The main proffer is reduced the “length of the number” when converting oddness of the form 4k+1and possibilities preserving it when converting 4k+3.")#linebreak()#text(" Since the transformation 4k+3 cannot be stored indefinitely, periodically the “length of the number” decreases.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b38f377a107ffa1d9a77d24fc9e9f78f3380239ea30a78188d9760413d224f5-d4cd0e27cf9b0dae97f623aafca35e544acd2e515fd5aca8eb7cd3ef3cd9063d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter C")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-542175")[#strong[#text("Peter C")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2020")])]

#text("I believe you are saying the method I have suggested gives a way to convert the overall tree into odds from {4K+1,4K+3} forms. Yes. The important aspect is the periodic nature of the Steps. Using densities to understand the entire set of odd numbers, you can convert the tree into the series mentioned above (x:0 to inf) Ʃ [2^x] / [3^(x+1)] = 1. The secondary part of most importance is only one N* exists in a chain, and that is joins to another N* as well. One must decompose the tree in a slightly different manner that it is typical known, but is equivalent… the answer becomes apparent then. All number flow outwards to a multiple of 3, all multiple of 3 have exactly 1 N* in its chain, and N* join inwards. Each have density series that are cyclical and sum to 1.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of y.y.")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-540997")[#strong[#text("y.y.")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2020")])]

#text("I am really glad if the conjecture would be affirmatively solved in the near future because I’ve been obsessed this. I have no mathematical background nor related areas so that I cannot write the paper about this in my own. but again say, I have found the inverse map of the Syracuse map which is known as a surjective but not injective mapping. The inverse map has of course one-one correspondence for all x∈2N_0+1. The conjecture is for group theory. I wonder who should I contact to discuss this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-541056")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2020")])]

#text("Alex Kontorovich’s twitter thread is really interesting, another thing to keep us up at night. I guess it isn’t lost on you that it’s reminiscent of your approach to Navier-Stokes blowup.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-541060")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2020")])]

#text("Another (graph theoretic) interpretation of the Collatz conjecture is that it is equivalent to the connectedness of the (infinite) graph corresponding to the Col mapping and that this graph has only the trivial cycle.")#linebreak()#text(" Is it possible that graph theoretic methods may help to get more results ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/089d0cedccdbee32786c7e296994cf315ef1b3c6f13b880e696921e040d47aec-d939e5745c48f83ef6584b0b100445f6f5430f1060f2ee4de3f5348e174ac098.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arunava mondal")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-546075")[#strong[#text("Arunava mondal")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2020")])]

#text("Very good explanation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/089d0cedccdbee32786c7e296994cf315ef1b3c6f13b880e696921e040d47aec-d939e5745c48f83ef6584b0b100445f6f5430f1060f2ee4de3f5348e174ac098.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arunava mondal")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-546076")[#strong[#text("Arunava mondal")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2020")])]

#text("Sir what is formality conjecture.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d198e68bf7530730fe45eb4350a7fdc35f4ef10b4f1fecba1beae18e5cccce76-5086be055639ae1c370115c0e18c8dfea67f17f3c8d62359acbc95e79aed378d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Li Jiang")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-581798")[#strong[#text("Li Jiang")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2020")])]

#text("The essence of Collatz conjecture is the iterative operation of odd numbers. It is known from the basic theorem of arithmetic: the number of factors with a value equal to 2 in each even number is determined for the even number, so an iterative operation for odd numbers ")#mi("x")#text(" can be defined: ")#mi("T=\\frac{3x+1}{2^a}")#text(", (where ")#mi("a")#text(" is the number of factors whose value in ")#mi("3x+1")#text(" is equal to 2), the result of the operation ")#mi("T")#text(" is still odd number. According to this definition, the general formula for continuous iteration of odd number can be derived")

#mi("T^{(k)}(x)=\\dfrac{\\displaystyle{3^k x+\\sum_{i=1}^{k}2^{g(i-1)}3^{k-i}}}{2^{g(k)}}.")#text(" (where ")#mi("g(i+1)>g(i), g(0)=0")#text(").")

#text("From this, if the continuous iteration may cause loops, then we can deduce the equation")

#mi("x=\\dfrac{\\displaystyle{\\sum_{i=1}^{k}2^{g(i-1)}3^{k-i}}}{2^{g(k)}-3^k}.")

#text("Solving this equation can get the result that the equation has no positive integer solution except 1, which indicates that continuous iteration cannot cause a loop.")

#text("On the other hand, the continuous iterative formula can be transformed into a linear indefinite equation")

#mi("A_kY=B_kx+C_k.")#text(" (where ")#mi("\\displaystyle{Y=T^{(k)}(x), A_k=2^{g(k)}, B_k=3^k, C_k=\\sum_{i=1}^{k}2^{g(i-1)}3^{k-i}}")#text(")")

#text("The process of solving the equation reveals that it is impossible for odd numbers to reach infinity through iterative operations. Therefore, all odd numbers will return to 1 after a limited number of iterations.")#linebreak()#text(" By extending this result to even numbers, it can be determined that all positive integers will return to 1 after a finite number of iterations, which fully proves Collatz conjecture.")

#text("My article The Collatz conjecture and linear indefinite equation is in the following website")#linebreak()#text(" ")#link("http://www.sciepub.com/tjant/content/8/2")[#text("http://www.sciepub.com/tjant/content/8/2")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-581821")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2020")])]

#text("where is the 0.8 in your equation 4.9 coming from?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d198e68bf7530730fe45eb4350a7fdc35f4ef10b4f1fecba1beae18e5cccce76-5086be055639ae1c370115c0e18c8dfea67f17f3c8d62359acbc95e79aed378d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Li Jiang")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-581858")[#strong[#text("Li Jiang")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2020")])]

#mi("C_4>0.8")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d198e68bf7530730fe45eb4350a7fdc35f4ef10b4f1fecba1beae18e5cccce76-5086be055639ae1c370115c0e18c8dfea67f17f3c8d62359acbc95e79aed378d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Li Jiang")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-581885")[#strong[#text("Li Jiang")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2020")])]

#text("Correction: ")#mi("C_4>0.8\\times 3^k")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-581968")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2020")])]

#text("You mean ")#mi("C_4>0.8\\times 3^4")#text(" ? ")#mi("C_4 > 64.8")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-581970")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2020")])]

#mi("C_k")#text(" then seems to be diverging.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18a7866c654cf3fe1ab1279db62496f1558286f44647c5b36d79ac83fd1c4771-6f3e77fee47e6083ed03276fb5c145cccb35c5dd51132e7b400ddf4c6d140ff4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hollis Williams")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-582015")[#strong[#text("Hollis Williams")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2020")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/career-advice/be-sceptical-of-your-own-work/")[#text("Be sceptical of your own work")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d198e68bf7530730fe45eb4350a7fdc35f4ef10b4f1fecba1beae18e5cccce76-5086be055639ae1c370115c0e18c8dfea67f17f3c8d62359acbc95e79aed378d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Li Jiang")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-581996")[#strong[#text("Li Jiang")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2020")])]

#text("Sorry, it should the sum of the first 4 items of ")#mi("C_k")#text(" be greater than ")#mi("0.8\\times 3^k")#text(".")#linebreak()#text(" When ")#mi("k\\rightarrow\\infty, C_k")#text(" is divergent, but ")#mi("\\frac{C_k}{A_k}")#text(" is always a finite value.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-582060")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2020")])]

#text("$A_k = 2^{g(k)}$ where $g(k)$ is typically less than $k$. So $\\frac{C_k}{A_k}\\approx\\frac{3^k}{2^k}$ which also diverges.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d198e68bf7530730fe45eb4350a7fdc35f4ef10b4f1fecba1beae18e5cccce76-5086be055639ae1c370115c0e18c8dfea67f17f3c8d62359acbc95e79aed378d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Li Jiang")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-582110")[#strong[#text("Li Jiang")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2020")])]

#text("Please read my article:")#linebreak()#text(" In the process of determining the special solutions ")#mi("X_0")#text(" and ")#mi("Y_0")#text(" of the indefinite equation, formula (4.8) is obtained, where")#linebreak()#text(" ")#mi("X_0=\\frac{C_k+uA_k}{r_2}")

#text("Since $latex r_2 ")#text(" \\frac{C_k}{A_k}+u.$")

#text("Therefore, if ")#mi("X_0")#text(" is finite then ")#mi("\\frac{C_k}{A_k}")#text(" cannot be divergent.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-582112")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2020")])]

#text("since ")#mi("r_2 < A_k")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-582113")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2020")])]

#text("so ")#mi("X_0 > \\frac{C_k}{A_k}+u")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/99b219735290d1db44f01383e73dacc4011c029fb9e34acc90fefbbb3d57d57b-5404f706761bcd847d9d075cfd717e277b5fc662f51cb0278c3e2bd694a441e6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cifra Finale")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-622244")[#strong[#text("Cifra Finale")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("Dear prof. Tao and readers of this blog, we are Dr. Cinzia, Silvana graduate in Materials Technology and their Dad Giovanni Di Savino, Air Force technician, we believe that Collatz’s conjecture can be simplified: Euclid with the formula 2 * n + 1 generates infinite odd numbers and proves that there is a prime number greater than the largest known prime. Certainly the first known and the first greater than the first known can be generated and identifiable but no prime can be generated that can be defined as the first greater than all the former. Thales measures “the inaccessible and unattainable”, Euclid generates and demonstrates the existence of the inaccessible and unreachable prime number, Gauss with the Fundamental Theorem of Arithmetic demonstrates the factorization mentioned by Euclid and states that every natural number is the product of prime numbers. Einstein, with the theory of relativity and with E = m * c ^ 2 shows that as the digits that make up the number increase, (the largest prime number we know today we write it with the power notation of two minus one (2 ^ 82.589. 933 -1) or with 24,862,048 decimal digits that can be reported on paper in km of writing) the same becomes inaccessible and unreachable, the “space” to be analyzed increases and the quantity = space to be processed which can be communicated with a maximum speed that does not can exceed: “the speed of light”. Larger numbers correspond to larger spaces, it follows that it takes longer to process that number which, however large, inaccessible and unreachable it may be Euclid has shown that it exists, Thales has shown that it can be measured and Einstein made us take act and showed us that our life cycles are insufficient to know the prime number greater than the largest known. The natural numbers, also generated with primes that exist and that we will never know, are the even and odd numbers that can be in a sequence that must be considered in the Collatz conjecture. Results of verification of numbers already made, are to be considered as records to be overcome. The numbers and sequences referred to in the conjecture are infinite and therefore it is impossible to represent the sequences but it is possible to satisfy the conjecture,.Statement in 1930 by the German mathematician Lothar Collatz, the procedure is also known as the Ulam or Thwaites conjecture, as the Kakutani or Syracuse problem, as the Hasse algorithm, or even as the hail sequence. Intuition might suggest that the number you start with affects the number you end up with but Collatz predicted that if you start with a positive integer and run this process long enough, all initial values ​​will lead to 1. And once you reach 1 , the rules of Collatz’s conjecture limit you to one cycle: 1, 4, 2, 1, 4, 2, 1, over and over forever. Euclid formulating 2 * n + 1 generates all the infinite odd numbers which, factored with the Fundamental Theorem of Arithmetic, do not have 2 among their factors; Collatz formulating n * 3 + 1 makes even any odd number of starting or sequence of the statement of Collatz; the even number or which has become even has 2 among its factors and any even number is a multiple of it. The result of an even number divided by 2 can also be an odd number but Collatz with its algorithm (n * 3 + 1) makes any known and unknown odd number even and the known and unknown even number can be divided by 2 and , halving the even numbers, we always arrive at 2/2 = 1 which being odd becomes 4 (1 * 3 + 1) which in turn becomes 2 (4/2) and then 2/2 = 1 to continue indefinitely 1_4_2 . thanks for reading")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95703cb64738bf251f2138af0140e5c1a76ffe994b4771c93e89e05d290a9ef0-9b50b3852f96816721fe32bbc75b1dbc46ba8ad8d4a9f99141405a88bd6bf885.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sacirisi")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-624402")[#strong[#text("sacirisi")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2021")])]

#text("The Fundamental Theorem of Arithmetic proves that the infinite (hereinafter ∞) natural numbers are primes or compounds and are the producer of prime numbers; satisfying the two versions of Goldbach’s conjecture will allow us to prove that even ∞ natural numbers are the sum of 2 prime numbers, ∞ odd numbers are the sum of only 3 prime numbers; satisfying Euclid’s twin primes conjecture allows us to give a solution to the strong version of Goldbach’s conjecture, “all even ∞ are the sum of two primes” by not looking for the impossible combinatorics between two primes whose quantity and value we do not know , but analyzing the distances between two consecutive prime numbers spaced only by the multiple numbers. ")#link("https://www.facebook.com/groups/5349868060/?multi_permalinks=10158013236403061")[#text("https://www.facebook.com/groups/5349868060/?multi_permalinks=10158013236403061")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95703cb64738bf251f2138af0140e5c1a76ffe994b4771c93e89e05d290a9ef0-9b50b3852f96816721fe32bbc75b1dbc46ba8ad8d4a9f99141405a88bd6bf885.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sacirisi")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-634728")[#strong[#text("sacirisi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2021")])]

#text("mutatis mutandis at 20210927. The Collatz conjecture is defined as a quagmire or labyrinth from which it is best to stay away. I went in, I left and I can go in and out whatever the starting number. The only way to get out of the “quagmire or labyrinth” was known that it was necessary to find the way to get to 1. All even numbers that are the result of a power of 2 arrive at 1, from half of the smaller power 2 ^ 1 to the middle from the largest and the smallest generable. The even number is: either a choice of the starting number and, if it is the result of 2 ^ n, we arrive at 1 after so many divisions by 2 equal to the value of the exponent of the power of 2, or it is the result of a number odd * 3 + 1. There is the odd number that multiplying it * 3 + 1 obtains a result equal to the result of a power of 2 with even exponent ≥2. The primes are infinite and are generated by the known primes, the odd numbers that * 3 + 1 generate the powers “to get out of the quagmire” are infinite and are the sum of the results of the even powers ≥0 notes or the odd binary number with digits which are the results of even powers ≥0. Each starting number generates new, unique and unrepeatable numbers; among these there is an odd number which is the sum of the results of powers of 2 with even exponent. ")#link("https://www.facebook.com/photo/?fbid=3082225312098634&set=pcb.10158351014883061")[#text("https://www.facebook.com/photo/?fbid=3082225312098634&set=pcb.10158351014883061")]#text(" Emzari Papava Fan Club")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95703cb64738bf251f2138af0140e5c1a76ffe994b4771c93e89e05d290a9ef0-9b50b3852f96816721fe32bbc75b1dbc46ba8ad8d4a9f99141405a88bd6bf885.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sacirisi")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-635845")[#strong[#text("sacirisi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2021")])]

#text("mutatis mutandis at 15 apr: Because the Collatz algorithm will never create an infinite loop. With any natural number and with the Collatz algorithm we obtain an odd number that multiplying it * 3 + 1 generates an even number which is the result of a power of 2, the algorithm halves even numbers, results of powers of 2 , until you get 1. All numbers end with a power of 2, all numbers end at 1. il lavoro:")#link("https://www.facebook.com/groups/5349868060")[#text("https://www.facebook.com/groups/5349868060")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95703cb64738bf251f2138af0140e5c1a76ffe994b4771c93e89e05d290a9ef0-9b50b3852f96816721fe32bbc75b1dbc46ba8ad8d4a9f99141405a88bd6bf885.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sacirisi")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-635847")[#strong[#text("sacirisi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2021")])]

#text("The steps to get to 1: will never know the factors of natural numbers which are the result of the production of prime numbers raised to a power equal to a natural number. We do not know which is the largest number to verify and we will never know the largest value of the exponent of the factor 2. In the Collatz conjecture, this value determines the steps required to halve an even number and arrive at an odd number. For an even number that is the result of a power of 2, the number of operations required to reach 1 is the exponent value of the power of 2; for an even number which is the result of the product of a power of 2 and powers of odd primes, the number of operations necessary to arrive at 1 is the sum of the exponents of all powers of 2 which are factors of the even numbers that the algorithm generates by multiplying the odd * 3 + 1 and that, with the power of the final 2, include the succession of values ​​that the algorithm generates in each starting number.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-625642")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2021")])]

#text("I would like to share my result on the problem with polymath project.")#linebreak()#text(" I tried to write the result mathematically as possible as I could.")#linebreak()#text(" There might be some mistakes on notations because I am not a math-researcher, sorry.")#linebreak()#text(" I think this would be some of help for understanding that the pseudo-randomness, invariant measure, and the most difficulty part of the problem. Thank you.")

#link("https://drive.google.com/file/d/1KtzjqtceHlf5sCvjEMCkVvnVQbMo8nFP/view?usp=sharing")[#text("https://drive.google.com/file/d/1KtzjqtceHlf5sCvjEMCkVvnVQbMo8nFP/view?usp=sharing")]#linebreak()#text(" ")#link("https://drive.google.com/file/d/1TmiKN4vLwY3r3gZ367u1G8hjrTNtFVr0/view?usp=sharing")[#text("https://drive.google.com/file/d/1TmiKN4vLwY3r3gZ367u1G8hjrTNtFVr0/view?usp=sharing")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee9bf66104c58d0fff497f81c56a9edf54153ead4d5ab887abad88d7b6fd1f2f-890b51d9c9a32c4666207c18708b3db7647139aa2f3f361c7044e76a4f103522.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-633128")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2021")])]

#text("On falling into a non-trivial orbit Dear professor, despite trying to understand your arguments, I can’t, but I still wanted to ask you if with this technique, using the pre-images, Collatz’s conjecture in reverse, it would be possible to show that every orbit has a multiple of three (actually every orbit originates from a multiple of 3)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-633146")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2021")])]

#text("Yes, this is true. For if ")#mi("n")#text(" is not a multiple of ")#mi("3")#text(", then simple modular arithmetic reveals that ")#mi("2^k n = 1 \\text{ mod } 9")#text(" for some natural number ")#mi("k")#text(". Then ")#mi("\\frac{2^k-1}{3}")#text(" is a multiple of three whose orbit will contain ")#mi("n")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7aec453a9034c7eeffe6f209c8e448dbca1b1f2d3260aee32642f2ffbc3f668-28d4a5811aa5a0f2ff850d3b376d9d5a2df29b53e9cc60294bae7498712bf3b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-633201")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2021")])]

#text("Thank you Professor and excuse me because I think I am not expressing myself well.")#linebreak()#text(" Every n odd multiple of 3 (or an orbit containing one) cannot fall into a non-trivial periodic orbit")#linebreak()#text(" Is it proven that no odd n can fall into periodic orbit? I think not yet, right?")#linebreak()#text(" So I was wondering if your technique could be used to show that every reverse orbit contains an odd n multiple of 3 (the origin).")

#text("Orbits that escape to infinity")

#text("I take the opportunity to ask what is the value of the fact that, if k is the number of multiplications by 3 and y is the number of divisions by 2, when k goes to infinity, y-k also goes to infinity")#linebreak()#text(" This is deduced from an accelerated Col2 type map, which follows the worst possible trajectory, ascending, in the sense of the time an orbyt maintaining a multiplication by 3 and a division by 2, and ensures that for all odd n, its worst trajectory, in this sense, is finite, and ends up dividing more than once by 2")

#text("If n odd, n + 1 even = z * 2 ^ t, then in t steps of a Col2 map the worst orbit ends, in this sense")

#mi("odd\\, n + (n + 1) = n +( z \\times  2 ^ t) \\rightarrow n + z \\times  (3 ^ t-2 ^ t) = even")

#text("Thanks")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95703cb64738bf251f2138af0140e5c1a76ffe994b4771c93e89e05d290a9ef0-9b50b3852f96816721fe32bbc75b1dbc46ba8ad8d4a9f99141405a88bd6bf885.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sacirisi")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-659621")[#strong[#text("sacirisi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2022")])]

#text("With the Collatz algorithm it is not possible to process all natural numbers because we do not know: quantities and values ​​of even and odd numbers and all their factors. From Tartaglia’s triangle we can detect odd numbers which are the sum of the results of the infinite powers of 2 which have an even index and which are also equal to the previous odd * 4 + 1. These are all the odd numbers that * 3 + 1 generate an even number that is the result of a base power 2 and even index 2 ^ (2 * n≥1) and that, the nth half, ends at 1 because ½ of 2 ^ 1 = 2 ^ 0 = 1. pre print ")#link("https://vixra.org/abs/2112.0004")[#text("https://vixra.org/abs/2112.0004")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a5afb1404bc54689bb712dd3eec8f34106bce55f459fa82749b42ee50316ec35-7b8485e534f04942a7a434a85e50258031df76c11160cd05aef75e33c40fc567.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cynthia Moore")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-682057")[#strong[#text("Cynthia Moore")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2023")])]

#text("ISO someone interested in reviewing my Collatz sketch. Please contact ")#link("mailto:CynthiaMooreMath@gmail.com")[#text("CynthiaMooreMath@gmail.com")]#text(". Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/#comment-689046")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2025")])]

#text("Prof. Tao, thank you for the clear exposition on the Syracuse random variables and how the quantity c_n controls the density of Collatz preimages. In your post you define Syrac(Z/3^nZ) and c_n := inf_{3∤b} P(Syrac=b), prove submultiplicativity c_{n1+n2-1} ≥ c_{n1}c_{n2}, and note that the “beta=1” equidistribution heuristic c_n = 3^{-n+o(n)} would imply preimage density x^{1-o(1)} (Proposition 3). I am exploring a complementary, purely algebraic two-layer calculus for the accelerated Syracuse map that might be of interest in this context.")

#text("Difference layer. From a one-block affine/difference identity I obtain a global sum rule Σ_i κ_i Δ_i = 0. Reducing mod any odd prime q≠3 produces a single linear “slot” ⟨κ,D⟩≡0 (mod q). Moreover, via finite backward branching one can surject onto this slot (and lift to prime powers), so every residue class allowed by the slot is actually realized. This gives an exact “equidistribution inside the hyperplane” at each odd q.")

#text("Offset layer and CRT. Transporting the odd cofactor H around one period yields, for any “offset prime” q dividing (2^{M+N}-3^N), a local two-coordinate affine constraint aD_{j-1}+bD_j≡c (mod q). Choosing a second, coprime “slot prime” q’≠3 for which κ is not a shift-eigenvector, the pair of rows (offset at q, slot at q’) is independent in the CRT product, which overdetermines the window and obstructs nontrivial cycles. (There are only finitely many “eigen” primes for a fixed κ.)")

#text("Question. Do your mixing or equidistribution tools for Syrac(Z/3^nZ) suggest a way to quantify slot-level uniformity simultaneously at two coprime odd moduli (say q=5, q’=7)—enough to make the above two-row CRT obstruction rigorous without extra hypotheses? Any pointers would be very valuable.")

#link("https://www.researchgate.net/publication/395507038_Mirror-Modular_Spine_Congruence_Saturation_and_Covariant_CRT_Closure_Solve_the_3x_1_Puzzle/stats")[#text("https://www.researchgate.net/publication/395507038_Mirror-Modular_Spine_Congruence_Saturation_and_Covariant_CRT_Closure_Solve_the_3x_1_Puzzle/stats")]
]
