// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/
// Converted to Typst by tao2typ: "2026-10-14T16:38:53.258715+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Sendov’s conjecture for sufficiently high degree polynomials", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Sendov’s conjecture for sufficiently high degree polynomials")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 December 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/")[#text("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper “")#link("https://arxiv.org/abs/2012.04125")[#text("Sendov’s conjecture for sufficiently high degree polynomials")]#text("“. This paper is a contribution to an old ")#link("https://en.wikipedia.org/wiki/Sendov%27s_conjecture")[#text("conjecture of Sendov")]#text(" on the zeroes of polynomials:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Sendov’s conjecture)")]#text(" Let ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" be a polynomial of degree ")#mi("{n \\geq 2}")#text(" that has all zeroes in the closed unit disk ")#tao-math("{\\{ z: \\left|z\\right| \\leq 1 \\}}", block: false)#text(". If ")#mi("{\\lambda_0}")#text(" is one of these zeroes, then ")#mi("{f^{\\prime}}")#text(" has at least one zero in ")#tao-math("{\\{z: \\left|z-\\lambda_0\\right| \\leq 1\\}}", block: false)#text(".")
]

#text("It is common in the literature on this problem to normalise ")#mi("{f}")#text(" to be monic, and to rotate the zero ")#mi("{\\lambda_0}")#text(" to be an element ")#mi("{a}")#text(" of the unit interval ")#mi("{[0,1]}")#text(". As it turns out, the location of ")#mi("{a}")#text(" on this unit interval ")#mi("{[0,1]}")#text(" ends up playing an important role in the arguments.")

#text("Many cases of this conjecture are already known, for instance")

#list(
[#text("When ")#mi("{n<9}")#text(" (")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1683144")[#text("Brown-Xiang 1999")]#text(");")],
[#text("When ")#mi("{a=0}")#text(" (")#link("https://en.wikipedia.org/wiki/Gauss%E2%80%93Lucas_theorem")[#text("Gauss-Lucas theorem")]#text(");")],
[#text("When ")#mi("{a \\leq \\frac{1}{n-1}}")#text(" (")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2759118")[#text("Bojanov 2011")]#text(");")],
[#text("When ")#mi("{c \\leq a \\leq 1-c}")#text(" for a fixed ")#mi("{c>0}")#text(", and ")#mi("{n}")#text(" is sufficiently large depending on ")#mi("{c}")#text(" (")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3162254")[#text("Dégot 2014")]#text(");")],
[#text("When ")#mi("{C n^{-1/7} \\leq a \\leq 1 - C n^{-1/4}}")#text(" for a sufficiently large absolute constant ")#mi("{C}")#text(" (")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=4137129")[#text("Chalebgwa 2020")]#text(");")],
[#text("When ")#mi("{a=1}")#text(" (")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=237753")[#text("Rubinstein 1968")]#text("; ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=239062")[#text("Goodman-Rahman-Ratti 1969")]#text("; ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=239061")[#text("Joyal 1969")]#text(");")],
[#text("When ")#mi("{a \\geq 1-\\varepsilon_n}")#text(", where ")#mi("{\\varepsilon_n>0}")#text(" is sufficiently small depending on ")#mi("{n}")#text(" (")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1219199")[#text("Miller 1993")]#text("; ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1190363")[#text("Vajaitu-Zaharescu 1993")]#text(");")],
[#text("When ")#mi("{a \\geq 1 - \\frac{1}{2 n^9 4^n}}")#text(" (")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2849157")[#text("Chijiwa 2011")]#text(");")],
[#text("When ")#mi("{a \\geq 1 - \\frac{90}{n^{12} \\log n}}")#text(" (")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3225918")[#text("Kasmalkar 2014")]#text(").")]
)

#text("In particular, in high degrees the only cases left uncovered by prior results are when ")#mi("{a}")#text(" is close (but not too close) to ")#mi("{0}")#text(", or when ")#mi("{a}")#text(" is close (but not too close) to ")#mi("{1}")#text("; see Figure 1 of my paper.")

#text("Our main result covers the high degree case uniformly for all values of ")#mi("{a \\in [0,1]}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" There exists an absolute constant ")#mi("{n_0}")#text(" such that Sendov’s conjecture holds for all ")#mi("{n \\geq n_0}")#text(".")
]

#text("In principle, this reduces the verification of Sendov’s conjecture to a finite time computation, although our arguments use compactness methods and thus do not easily provide an explicit value of ")#mi("{n_0}")#text(". I believe that the compactness arguments can be replaced with quantitative substitutes that provide an explicit ")#mi("{n_0}")#text(", but the value of ")#mi("{n_0}")#text(" produced is likely to be extremely large (certainly much larger than ")#mi("{9}")#text(").")

#text("Because of the previous results (particularly those of Chalebgwa and Chijiwa), we will only need to establish the following two subcases of the above theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Sendov’s conjecture near the origin)")]#text(" ")#metadata(none) <tao-06422333651d44e488e5>#text(" Under the additional hypothesis ")#mi("{a = o(1/\\log n)}")#text(", Sendov’s conjecture holds for sufficiently large ")#mi("{n}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Sendov’s conjecture near the unit circle)")]#text(" ")#metadata(none) <tao-4187c4de53956a449701>#text(" Under the additional hypothesis ")#mi("{1-o(1) \\leq a \\leq 1 - \\varepsilon_0^n}")#text(" for a fixed ")#mi("{\\varepsilon_0>0}")#text(", Sendov’s conjecture holds for sufficiently large ")#mi("{n}")#text(".")
]

#text("We approach these theorems using the “compactness and contradiction” strategy, assuming that there is a sequence of counterexamples whose degrees ")#mi("{n}")#text(" going to infinity, using various compactness theorems to extract various asymptotic objects in the limit ")#mi("{n \\rightarrow \\infty}")#text(", and somehow using these objects to derive a contradiction. There are many ways to effect such a strategy; we will use a formalism that I call “")#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/")[#text("cheap nonstandard analysis")]#text("” and which is common in the PDE literature, in which one repeatedly passes to subsequences as necessary whenever one invokes a compactness theorem to create a limit object. However, the particular choice of asymptotic formalism one selects is not of essential importance for the arguments.")

#text("I also found it useful to use the language of probability theory. Given a putative counterexample ")#mi("{f}")#text(" to Sendov’s conjecture, let ")#mi("{\\lambda}")#text(" be a zero of ")#mi("{f}")#text(" (chosen uniformly at random among the ")#mi("{n}")#text(" zeroes of ")#mi("{f}")#text(", counting multiplicity), and let ")#mi("{\\zeta}")#text(" similarly be a uniformly random zero of ")#mi("{f^{\\prime}}")#text(". We introduce the ")#emph[#text("logarithmic potentials")]

#align(center)[#tao-fit-display[#tao-math("U_\\lambda(z) := {\\bf E} \\log \\frac{1}{\\left|z-\\lambda\\right|}; \\quad U_\\zeta(z) := {\\bf E} \\log \\frac{1}{\\left|z-\\zeta\\right|}", block: true)]]

#text("and the ")#emph[#text("Stieltjes transforms")]

#align(center)[#tao-fit-display[#mitex("s_\\lambda(z) := {\\bf E} \\frac{1}{z-\\lambda}; \\quad s_\\zeta(z) := {\\bf E} \\log \\frac{1}{z-\\zeta}.")]]

#text("Standard calculations using the fundamental theorem of algebra yield the basic identities")

#align(center)[#tao-fit-display[#tao-math("U_\\lambda(z) = \\frac{1}{n} \\log \\frac{1}{\\left|f(z)\\right|}; \\quad U_\\zeta(z) = \\frac{1}{n-1} \\log \\frac{n}{\\left|f^{\\prime}(z)\\right|}", block: true)]]

#text("and")

#metadata(none) <tao-8e6a0ab2937027144d3c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("s_\\lambda(z) = \\frac{1}{n} \\frac{f^{\\prime}(z)}{f(z)}; \\quad s_\\zeta(z) = \\frac{1}{n-1} \\frac{f^{\\prime\\prime}(z)}{f^{\\prime}(z)}")]]

#text("and in particular the random variables ")#mi("{\\lambda, \\zeta}")#text(" are linked to each other by the identity")

#metadata(none) <tao-e77c4b3f81059b97c4d2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("U_\\lambda(z) - \\frac{n-1}{n} U_\\zeta(z) = \\frac{1}{n} \\log \\left|s_\\lambda(z)\\right|.", block: true)]]

#text("On the other hand, the hypotheses of Sendov’s conjecture (and the Gauss-Lucas theorem) place ")#mi("{\\lambda,\\zeta}")#text(" inside the unit disk ")#tao-math("{\\{ z:\\left|z\\right| \\leq 1\\}}", block: false)#text(". Applying ")#link("https://en.wikipedia.org/wiki/Prokhorov%27s_theorem")[#text("Prokhorov’s theorem")]#text(", and passing to a subsequence, one can then assume that the random variables ")#mi("{\\lambda,\\zeta}")#text(" converge in distribution to some limiting random variables ")#mi("{\\lambda^{(\\infty)}, \\zeta^{(\\infty)}}")#text(" (possibly defined on a different probability space than the original variables ")#mi("{\\lambda,\\zeta}")#text("), also living almost surely inside the unit disk. Standard potential theory then gives the convergence")

#metadata(none) <tao-7b4b1cfd022b3dfa9128>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("U_\\lambda(z) \\rightarrow U_{\\lambda^{(\\infty)}}(z); \\quad U_\\zeta(z) \\rightarrow U_{\\zeta^{(\\infty)}}(z)")]]

#text("and")

#metadata(none) <tao-60ff29141db1fd0dd887>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("s_\\lambda(z) \\rightarrow s_{\\lambda^{(\\infty)}}(z); \\quad s_\\zeta(z) \\rightarrow s_{\\zeta^{(\\infty)}}(z)")]]

#text("at least in the local ")#mi("{L^1}")#text(" sense. Among other things, we then conclude from the identity ")#link(<tao-e77c4b3f81059b97c4d2>)[#text("(2)")]#text(" and some elementary inequalities that")

#align(center)[#tao-fit-display[#mitex("U_{\\lambda^{(\\infty)}}(z) = U_{\\zeta^{(\\infty)}}(z)")]]

#text("for all ")#tao-math("{\\left|z\\right|>1}", block: false)#text(". This turns out to have an appealing interpretation in terms of Brownian motion: if one takes two Brownian motions in the complex plane, one originating from ")#mi("{\\lambda^{(\\infty)}}")#text(" and one originating from ")#mi("{\\zeta^{(\\infty)}}")#text(", then the location where these Brownian motions first exit the unit disk ")#tao-math("{\\{ z: \\left|z\\right| \\leq 1 \\}}", block: false)#text(" will have the same distribution. (In our paper we actually replace Brownian motion with the closely related formalism of ")#link("https://en.wikipedia.org/wiki/Balayage")[#text("balayage")]#text(".) This turns out to connect the random variables ")#mi("{\\lambda^{(\\infty)}}")#text(", ")#mi("{\\zeta^{(\\infty)}}")#text(" quite closely to each other. In particular, with this observation and some additional arguments involving both the unique continuation property for harmonic functions and Grace’s theorem (discussed in ")#link("https://terrytao.wordpress.com/2020/11/28/holomorphic-images-of-disks/")[#text("this previous post")]#text("), with the latter drawn from the prior ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3162254")[#text("work of Dégot")]#text(", we can get very good control on these distributions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5")]#text(" ")#metadata(none) <tao-fbb7b5bf4ca348eeeebf>

#list(
[#text("(i) If ")#mi("{a = o(1)}")#text(", then ")#mi("{\\lambda^{(\\infty)}, \\zeta^{(\\infty)}}")#text(" almost surely lie in the semicircle ")#mi("{\\{ e^{i\\theta}: \\pi/2 \\leq \\theta \\leq 3\\pi/2\\}}")#text(" and have the same distribution.")],
[#text("(ii) If ")#mi("{a = 1-o(1)}")#text(", then ")#mi("{\\lambda^{(\\infty)}}")#text(" is uniformly distributed on the circle ")#tao-math("{\\{ z: \\left|z\\right|=1\\}}", block: false)#text(", and ")#mi("{\\zeta^{(\\infty)}}")#text(" is almost surely zero.")]
)
]

#text("In case (i) (and strengthening the hypothesis ")#mi("{a=o(1)}")#text(" to ")#mi("{a=o(1/\\log n)}")#text(" to control some technical contributions of “outlier” zeroes of ")#mi("{f}")#text("), we can use this information about ")#mi("{\\lambda^{(\\infty)}}")#text(" and ")#link(<tao-60ff29141db1fd0dd887>)[#text("(4)")]#text(" to ensure that the normalised logarithmic derivative ")#mi("{\\frac{1}{n} \\frac{f^{\\prime}}{f} = s_\\lambda}")#text(" has a non-negative winding number in a certain small (but not too small) circle around the origin, which by the ")#link("https://en.wikipedia.org/wiki/Argument_principle")[#text("argument principle")]#text(" is inconsistent with the hypothesis that ")#mi("{f}")#text(" has a zero at ")#mi("{a = o(1)}")#text(" and that ")#mi("{f^{\\prime}}")#text(" has no zeroes near ")#mi("{a}")#text(". This is how we establish Theorem ")#link(<tao-06422333651d44e488e5>)[#text("3")]#text(".")

#text("Case (ii) turns out to be more delicate. This is because there are a number of “near-counterexamples” to Sendov’s conjecture that are compatible with the hypotheses and conclusion of case (ii). The simplest such example is ")#mi("{f(z) = z^n - 1}")#text(", where the zeroes ")#mi("{\\lambda}")#text(" of ")#mi("{f}")#text(" are uniformly distributed amongst the ")#mi("{n^{th}}")#text(" roots of unity (including at ")#mi("{a=1}")#text("), and the zeroes of ")#mi("{f^{\\prime}}")#text(" are all located at the origin. In my paper I also discuss a variant of this construction, in which ")#mi("{f^{\\prime}}")#text(" has zeroes mostly near the origin, but also acquires a bounded number of zeroes at various locations ")#mi("{\\lambda_1+o(1),\\dots,\\lambda_m+o(1)}")#text(" inside the unit disk. Specifically, we take")

#align(center)[#tao-fit-display[#mitex("f(z) := \\left(z + \\frac{c_2}{n}\\right)^{n-m} P(z) - \\left(a + \\frac{c_2}{n}\\right)^{n-m} P(a)")]]

#text("where ")#mi("{a = 1 - \\frac{c_1}{n}}")#text(" for some constants ")#mi("{0 < c_1 < c_2}")#text(" and")

#align(center)[#tao-fit-display[#mitex("P(z) := (z-\\lambda_1) \\dots (z-\\lambda_m).")]]

#text("By a perturbative analysis to locate the zeroes of ")#mi("{f}")#text(", one eventually would be able to arrive at a true counterexample to Sendov’s conjecture if these locations ")#mi("{\\lambda_1,\\dots,\\lambda_m}")#text(" were in the open lune")

#align(center)[#tao-fit-display[#tao-math("\\{ \\lambda: \\left|\\lambda\\right| < 1 < \\left|\\lambda-1\\right| \\}", block: true)]]

#text("and if one had the inequality")

#metadata(none) <tao-50b8d2c3973594d74271>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("c_2 - c_1 - c_2 \\cos \\theta + \\sum_{j=1}^m \\log \\left|\\frac{1 - \\lambda_j}{e^{i\\theta} - \\lambda_j}\\right| < 0", block: true)]]

#text("for all ")#mi("{0 \\leq \\theta \\leq 2\\pi}")#text(". However, if one takes the mean of this inequality in ")#mi("{\\theta}")#text(", one arrives at the inequality")

#align(center)[#tao-fit-display[#tao-math("c_2 - c_1 + \\sum_{j=1}^m \\log \\left|1 - \\lambda_j\\right| < 0", block: true)]]

#text("which is incompatible with the hypotheses ")#mi("{c_2 > c_1}")#text(" and ")#tao-math("{\\left|\\lambda_j-1\\right| > 1}", block: false)#text(". In order to extend this argument to more general polynomials ")#mi("{f}")#text(", we require a stability analysis of the endpoint equation")

#metadata(none) <tao-a9f6815747c1b2f9466e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("c_2 - c_1 + c_2 \\cos \\theta + \\sum_{j=1}^m \\log \\left|\\frac{1 - \\lambda_j}{e^{i\\theta} - \\lambda_j}\\right| = 0", block: true)]]

#text("where we now only assume the closed conditions ")#mi("{c_2 \\geq c_1}")#text(" and ")#tao-math("{\\left|\\lambda_j-1\\right| \\geq 1}", block: false)#text(". The above discussion then places all the zeros ")#mi("{\\lambda_j}")#text(" on the arc")

#metadata(none) <tao-404fcfb394d23199f6d9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\{ \\lambda: \\left|\\lambda\\right| < 1 = \\left|\\lambda-1\\right|\\}", block: true)]]

#text("and if one also takes the ")#emph[#text("second")]#text(" Fourier coefficient of ")#link(<tao-a9f6815747c1b2f9466e>)[#text("(6)")]#text(" one also obtains the vanishing second moment")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^m \\lambda_j^2 = 0.")]]

#text("These two conditions are incompatible with each other (except in the degenerate case when all the ")#mi("{\\lambda_j}")#text(" vanish), because all the non-zero elements ")#mi("{\\lambda}")#text(" of the arc ")#link(<tao-404fcfb394d23199f6d9>)[#text("(7)")]#text(" have argument in ")#mi("{\\pm [\\pi/3,\\pi/2]}")#text(", so in particular their square ")#mi("{\\lambda^2}")#text(" will have negative real part. It turns out that one can adapt this argument to the more general potential counterexamples to Sendov’s conjecture (in the form of Theorem ")#link(<tao-4187c4de53956a449701>)[#text("4")]#text("). The starting point is to use ")#link(<tao-8e6a0ab2937027144d3c>)[#text("(1)")]#text(", ")#link(<tao-60ff29141db1fd0dd887>)[#text("(4)")]#text(", and Theorem ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("5")]#text("(ii) to obtain good control on ")#mi("{f^{\\prime\\prime}/f^{\\prime}}")#text(", which one then integrates and exponentiates to get good control on ")#mi("{f^{\\prime}}")#text(", and then on a second integration one gets enough information about ")#mi("{f}")#text(" to pin down the location of its zeroes to high accuracy. The constraint that these zeroes lie inside the unit disk then gives an inequality resembling ")#link(<tao-50b8d2c3973594d74271>)[#text("(5)")]#text(", and an adaptation of the above stability analysis is then enough to conclude. The arguments here are inspired by the previous arguments ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1219199")[#text("of Miller")]#text(", which treated the case when ")#mi("{a}")#text(" was extremely close to ")#mi("{1}")#text(" via a similar perturbative analysis; the main novelty is to control the error terms not in terms of the magnitude of the largest zero ")#mi("{\\zeta}")#text(" of ")#mi("{f^{\\prime}}")#text(" (which is difficult to manage when ")#mi("{n}")#text(" gets large), but rather by the variance of those zeroes, which ends up being a more tractable expression to keep track of.")

#heading(level: 1)[#text("Comments (41)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f348a777241daa94887b93b96e34916d3933e6d863191a97022fe0eb2a3618fd-0e25347f4b524ba31a6896353db106f90927b23c12f78ceb706ed00134066b82.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of BlogPython")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609001")[#strong[#text("BlogPython")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2020")])]

#text("looks like it ends with an extra phase “The conjecture is”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b9d2b471a95950cf9ab900a2a956433a802e53dd7dce19b8f99e969eecbfb6d-928b219cdc034ba412fab685a5c24ece80537934e15e706cc872bf337f74deba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of allenknutson")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609002")[#strong[#text("allenknutson")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2020")])]

#text("It’s nice to see unsolved problems in the theory of polynomials in one complex variable!")

#text("I gather from the multitude of partial results that people care about this problem. Is there any obvious reason other than “it’s odd to have an unsolved problem in the theory of polynomials in one complex variable”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609014")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2020")])]

#text("Well, the zeroes and critical points of a polynomial are both of interest in many applications, so I imagine it would be natural to ask what general relationships exist between the two sets of points, beyond what the classical Gauss-Lucas theorem (in the complex case) or Rolle’s theorem (in the real case) provides.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/faf5907e93a0671e219db1830637fe07df16be8300106375d2579b6d55e31284-5065c5cd37c418f9be50c7cfb4d6c311e9a9b3b65f8a75ff43b5c34a3669e637.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oliver Knill")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609040")[#strong[#text("Oliver Knill")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2020")])]

#text("There is just also the elegance of the problem. Mathematicians at the time of Gauss would have liked it. It will be attractive also in 100 years, especially if not yet solved. It can also lead to beautiful and accessible problems in a single variable calculus course, like the following simple case which could be used in a lecture on Rolle’s theorem (as mentioned before in the comments)")

#text("“If f(x) is a real polynomial of degree n larger 1 with n roots in [-1,1], then there exists a critical point in distance 1 or less of any of the roots. Why does n=1 not work? Find a polynomial where the distance is 1.”")

#text("There is also just the beauty of what one can see when looking at polynomials, their roots and the critical points. Cases with a randomly chosen polynomial with 20, or 100 roots with red critical points ")#link("http://www.math.harvard.edu/~knill/various/sendov")[#text("http://www.math.harvard.edu/~knill/various/sendov")]#text(" indicates that often the critical points are quite close to the roots like moons to planets but that this often also fails and roots can cluster without critical points nearby.")

#text("As the random case has been mentioned in the post, it begs for the question what the distribution of the critical points is in the n to infinity limit, if the roots of the polynomial are uniformly distributed in the unit disc. Uniform again?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64f3b0fca28c506b4615cf526d7ee775d296fde4f6d95b36db775e086b954716-75e7d2df91f29a7e3c295781845eaa8a68134b9f108abc5606280796bb938a9f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of folkertt")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609100")[#strong[#text("folkertt")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2020")])]

#text("Well yes, but an interesting question may be what happens for rational functions, entire functions and/or those that satisfy some growth condition. or the Riemann zeta function for example, or functions that satisfy some functional equation. Someone could have thought along these lines. Interesting topic for speculation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609117")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2020")])]

#text("Although we do have many reasons to analyze the zeroes and poles (the latter being more well understood) of the Riemann zeta function, but I think analyzing ")#mi("\\zeta")#text(" does not fall in this league.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609134")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2020")])]

#text("There is some literature on zeroes of derivatives of the Riemann zeta function, starting with a classical paper of Speiser that the Riemann Hypothesis holds if and only if all the non-real zeroes of ")#mi("\\zeta^{\\prime}")#text(" lie on or to the right of the critical line. In general, as one keeps differentiating the zeta function, it is numerically observable that more and more of the zeroes start drifting to the right of the critical line and cluster in curves; see for instance ")#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/")[#text("these slides of Binder et al.")]#text(". The situation is actually rather analogous to what happens to the zeroes of the Riemann xi function under the de Bruijn heat flow (with the notable difference that the higher derivatives do not obey a functional equation that makes the zeroes symmetric around the critical line). It is not widely expected that a closer study of these higher derivatives is likely to yield any substantive progress towards questions such as the Riemann hypothesis, but there are some interesting numerical phenomena here (though most likely arising primarily from general facts about derivatives of meromorphic functions, rather than having specifically a number theoretic origin).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609128")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2020")])]

#text("It is a ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3283656")[#text("result of Kabluchko")]#text(" (confirming a conjecture of Pemantle and Rivin) that the critical points of a large degree polynomial with zeroes sampled from a fixed distribution, are also asymptotically distributed with respect to the same distribution.")

#text("The phenomenon you observed numerically that critical points tend to be “paired” to nearby zeroes has begun to be rigorously explained, see for instance ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=4136480")[#text("this recent paper")]#text(" by O’Rourke and Williams. Note that as there are ")#mi("n")#text(" zeroes and ")#mi("n-1")#text(" critical points, the pigeonhole principle will force one zero to be “unpaired”. Visually, numerical experiments suggest that this unpaired zero lurks near the center of the cluster of zeroes, and this seems to make sense in view of ")#link("https://en.wikipedia.org/wiki/B%C3%B4cher%27s_theorem")[#text("Bocher’s theorem")]#text(" and mean field approximation, but as far as I know there is not even a rigorous formulation of this phenomenon at present.")

#text("There is also some recent work on the dynamics of zeroes of repeated derivatives of such polynomials, such as ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=4011508")[#text("this paper of Steinerberger")]#text(" and a followup ")#link("https://arxiv.org/abs/2010.14320")[#text("work of Hoskins and Kabluchko")]#text(". It is also connected to the story of fractional free convolution powers which I ")#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/")[#text("recently wrote")]#text(" a paper with Shylakhtenko about.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11a24b38007dc03aa218f3eb92b8e79681e6f810e378f3bfa2729b078f8609ac-505d6030ec57e5ef3a5aa385754c06d78ee8b223b1e093b26795af5b0a91bc31.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rajan Anantharaman")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609091")[#strong[#text("Rajan Anantharaman")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2020")])]

#text("Dear Friend Many thanks for this and others by Terence Tao that / who I admire tho sometimes not understood Best wishes Rajan")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e129a68dcf0bb46ecba772753b8f9af1ec273d49cbd7ace8069058648b03b58-7eb33440dcbae163fc1d170d08c9c52deb82d4eb4253cf0fbe7e8b13997f3aa7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609140")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2020")])]

#text("I was wondering if there’s more progress to be made by looking at an individual zero of ")#mi("f^{\\prime}")#text(" as follows: Take ")#mi("f(z;n) = (z-a) g(z)^n")#text(", with ")#mi("g")#text(" a monic polynomial with all zeros in the unit disk (!= a). Take ")#mi("n")#text(" large (")#mi(">n_0")#text("), find a zero ")#mi("z^*")#text(" of ")#mi("f^{\\prime}")#text(" in the unit disk centered on ")#mi("a")#text(". Then turn ")#mi("n")#text(" into a continuous variable ")#mi("w")#text(" and look at what happens to ")#mi("z^*")#text(" as a function of ")#mi("w")#text(".")#linebreak()#text(" We get ")#mi("dz^*/dw (1/(z-a)^2 - w d/dz(g^{\\prime}/g)) |_{z^*} = g^{\\prime}(z^*) / g(z^*)")#linebreak()#text(" I’m not sure what you can do with that. ")#mi("g^{\\prime}/g = \\sum_b 1/(z-b)")#text(", where ")#mi("b")#text(" ranges over the zeros of ")#mi("g")#text(", so the RHS is a sum of single pole terms, while the LHS is the sum of double pole terms — can we show that ")#mi("dz/dw")#text(" must vanish as ")#mi("z^*")#text(" approaches the boundary of the disk? Can we show that ")#mi("z*")#text(" always avoids other zeros of ")#mi("f^{\\prime}")#text(" as ")#mi("w")#text(" varies so that we don’t have zero pair annihilation/creation?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609146")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2020")])]

#text("Are there similar conjectures on possible (algebraic geometrical) relationships between the set of zeros and the set of critical points for polynomials maps of several (real or complex) variables ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609180")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2020")])]

#text("I don’t know of any explicit conjectures, but presumably they would involve the structure of the associated ")#link("https://en.wikipedia.org/wiki/Amoeba_(mathematics)")[#text("amoebas")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609228")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2020")])]

#text("What an incredible paper!!!")#linebreak()#text(" For your perfect information, may I suggest to complete your preprint by recent results concerning the cases n = 9 and n = 10 and their related references:")

#text("1) Zaizhao Meng. Proof of the Sendov conjecture for polynomials of degree nine. ArXiv, 17 May 2018.")

#text("2) D.S. Bhattarai. A proof of the Sendov conjecture for polynomials of degree ten. International Journal of Scientific and Research Publications, 9 (8):182-191, August 2019.")

#text("Moreover the Ph.D thesis of T.P. Chalebgwa is devoted to this conjecture. In particular he has published an interesting article extending a previous result given by Dégot.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609234")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2020")])]

#text("Spam:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2020/11/28/holomorphic-images-of-disks/")[#text("Holomorphic images of disks")]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2020/11/28/holomorphic-images-of-disks/")[#text("Holomorphic images of disks")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonym")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609233")[#strong[#text("Anonym")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2020")])]

#text("More precisely:")#linebreak()#text(" T.P. Chalebgwa. Sendov’s conjecture : A note on a paper of Dégot. ArXiv:1804.09953, 26 April 2018.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609293")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2020")])]

#text("In order to response to a previous post, there exists another famous similar conjecture, Kurepa’s conjecture.")#linebreak()#text(" Such a conjecture remains an open problem nowadays, despite the proof of Barsky & Benzeghou published in the JTNB which was dismissed by themselves in the same journal.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8de4c4a741f975dddb27de8326d1633379be18c063df3cffbc5c481c3726b7a6-bccebc8c92d5303bdba924497147368f53b54ed93aff9f0baad86419a1924a69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609295")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2020")])]

#text("I would like for other interested people to check out the following paper by M.Sc Theophilus Agama submitted last year where he claims to prove Sendov’s conjecture as an application of his theory –")#linebreak()#text(" T. Agama. Expansivity theory and proof of Sendov’s conjecture. ArXiv: 1907.12825, 30 July 2019")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1ced1bf58675142f83a17d6a3f85fa0ff2e0fa98c7047b7cf3bac528b407f17-c56f4399a41dca409d2aa0ecdfc63cf7c3b8ee66208f48f1d52f576a19830524.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexandre Eremenko")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609310")[#strong[#text("Alexandre Eremenko")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2020")])]

#text("On p. 14, 3d line after (2.9) “tales” must be “takes”.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cris")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609311")[#strong[#text("Cris")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2020")])]

#text("Following the two last posts, a well-known connex conjecture is the lonely runner problem.")#linebreak()#text(" For example this problem was studied by T. Agama in a recent preprint entitled ‘Distribution of boundary points of expansion and application to the lonely runner conjecture’ which was uploaded to the ArXiv on september 5, 2019.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609445")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2020")])]

#text("It seems that theorem 2 is sufficient to imply Sendov’s conjecture by the following (perturbative) simple argument:")

#text("Let ")#mi("p(z)")#text(" be a polynomial of degree ")#mi("n \\in [2, n_0)")#text(" and has all its zeros in the closed unit disk.")

#text("Define for a (perturbation) parameter ")#mi("c > 0")

#text("(1) ")#mi("p_c(z) := c z^{n_0} + p(z)")

#text("It is easy to verify that for sufficiently small ")#mi("c")#text(", the polynomial ")#mi("p_c(z)")#text(" has precisely ")#mi("n")#text(" bounded zeros (counting multiplicities) converging to the corresponding zeros of ")#mi("p(z)")#text(" as ")#mi("c \\to 0")#text(", while the remaining ")#mi("n_0 - n")#text(" zeros of ")#mi("p_c(z)")#text(" are unbounded and converging (on the Riemann sphere) to ")#mi("\\infty")#text(" as ")#mi("c \\to 0")#text(".")

#text("Similarly, for sufficiently small ")#mi("c")#text(", ")#mi("p_c^{\\prime}(z)")#text(" has precisely ")#mi("n -1")#text(" bounded zeros (counting multiplicities) converging to the corresponding zeros of ")#mi("p^{\\prime}(z)")#text(" as ")#mi("c \\to 0")#text(", while the remaining ")#mi("n_0 - n")#text(" zeros of ")#mi("p_c^{\\prime}(z)")#text(" are unbounded and converging (on the Riemann sphere) to ")#mi("\\infty")#text(" as ")#mi("c \\to 0")#text(".")

#text("For any sufficiently small ")#mi("\\epsilon >0")#text(", there is a sufficiently small ")#mi("c")#text(" such that each zero (")#mi("z_i(p)")#text(", say) of ")#mi("p")#text(" has a corresponding zero ")#mi("z_i(p_c)")#text(" of ")#mi("p_c")#text(" such that")

#text("(2) ")#tao-math("\\left|z_i(p) - z_i(p_c)\\right| < \\epsilon", block: false)#text(" for ")#mi("i = 1, ... , n")

#text("while the remaining ")#mi("n_0 - n")#text(" unbounded zeros of ")#mi("p_c")#text(" have sufficiently large magnitudes, for instance")

#text("(3) ")#tao-math("\\left|z_i(p_c)\\right| \\geq 10", block: false)#text(" for ")#mi("i = n+1, ... , n_0")

#text("Similarly, this sufficiently small parameter ")#mi("c")#text(" can be chosen to satisfy also the following similar constraints for the zeros of ")#mi("p^{\\prime}")#text(" and ")#mi("p_c^{\\prime}")

#text("(2') ")#tao-math("\\left|z_i(p^{\\prime}) - z_i(p_c^{\\prime})\\right| < \\epsilon", block: false)#text(" for ")#mi("i = 1, ... , n-1")

#text("(3') ")#tao-math("\\left|z_i(p_c^{\\prime})\\right| \\geq 10", block: false)#text(" for ")#mi("i = n, ... , n_0 -1")

#text("Now, observe that for each ")#mi("i = 1, ... , n")#text(", the zero ")#mi("z_i(p)")#text(" of ")#mi("p(z)")#text(" is (by (2)) ")#mi("\\epsilon")#text("-approximated by the zero ")#mi("z_i(p_c)")#text(" of ")#mi("P_c(z)")#text(". Since ")#tao-math("\\left|z_i(p)\\right| \\leq 1", block: false)#text(" we have")

#text("(4) ")#tao-math("\\left|z_i(p_c)\\right| \\leq 1 + \\epsilon", block: false)

#text("Which implies (via a scaled version of theorem 2 for ")#mi("p_c")#text(") the existence of a zero ")#mi("z_j(p_c^{\\prime})")#text(" of ")#mi("p_c^{\\prime}")#text(" such that")

#text("(5) ")#tao-math("\\left|z_j(p_c^{\\prime}) - z_i(p_c)\\right| \\leq 1+ \\epsilon", block: false)

#text("From (4) and (5) we see that")

#text("(6) ")#tao-math("\\left|z_j(p_c^{\\prime})\\right| \\leq 2 + 2 \\epsilon", block: false)

#text("Hence by (3') it follows (for sufficiently small ")#mi("\\epsilon")#text(") that")

#text("(7) ")#mi("j < n")#linebreak()#text(" (i.e. ")#mi("z_j(p_c^{\\prime})")#text(" is a bounded(!) critical point of ")#mi("p_c")#text(")")

#text("By (2') (with condition (7) for the index ")#mi("j")#text(") we have")

#text("(8) ")#tao-math("\\left|z_j(p^{\\prime}) - z_j(p_c^{\\prime})\\right| < \\epsilon", block: false)

#text("From (2), (5), (8) we have")

#text("(9) ")#tao-math("\\left|z_i(p) - z_j(p^{\\prime})\\right| \\leq 1+ 3 \\epsilon", block: false)#linebreak()#text(" (where the index j is dependent on the index i)")

#text("Since (9) holds for any positive ")#mi("\\epsilon")#text(", it proves Sendov’s conjecture.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609475")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2020")])]

#text("Unfortunately the scaled version of Theorem 2 would require all ")#mi("n_0")#text(" zeroes of ")#mi("p_c")#text(" to be under control, not just the first ")#mi("n")#text(", so I don’t think one can easily deduce (5) from (4).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609505")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2020")])]

#text("To all the interested readers, the aforementioned reference in the present blog of Dr. TP Chalebgwa entitled “Sendov conjecture : A note on a paper of Dégot” was in fact published in Analysis Mathematica 46(3):447-463 Springer Verlag NY September 2020.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609507")[#strong[#text("Chris")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2020")])]

#text("It seems effectively that Sendov’s conjecture has been proven.")#linebreak()#text(" What about Kurepa’s conjecture now?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikke")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609594")[#strong[#text("Mikke")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2020")])]

#text("Why not ?")#linebreak()#text(" There are so many conjectures.")#linebreak()#text(" But if you want to become Fields medalist, as Alexander Grothendieck or Terence Tao for instance, you should demonstrate the ultimate conjecture i.e. the Riemann hypothesis (even if a proof has been proposed since several years in theoretical physics by Prof. German Robredo Sierra of the University of Madrid) …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609601")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2020")])]

#text("To the best of my knowledge, the Riemann hypothesis has not been proven up to now despite intensive research works since many decades and a proposition coming from Ouganda but later dismissed by the maths community.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609604")[#strong[#text("Andy")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2020")])]

#text("I do totally agree with you.")#linebreak()#text(" There are still plenty of conjectures in various and heterogeneous fields of maths and theoretical physics.")#linebreak()#text(" But no doubt that the Graal is Riemann’s hypothesis, one of the remaining unsolved problems of the century in the sense of the Clay Mathematics Institute.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-609792")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2020")])]

#text("Techical redirection prblems")#linebreak()#text(" If we clic on ‘Dégot 2014’ we are redirected to the right place.")#linebreak()#text(" But if we clic on ‘work of Dégot’ we return to the first page of the present blog and not to the announced page.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-610034")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2020")])]

#text("Dear Professor,")#linebreak()#text(" Do you have already updated your preprint (and your blog) with the proofs of the Sendov conjecture for polynomials of degree 9 and 10 (see the post of December 9 at 7:34 on your blog for the two corresponding references) ?")#linebreak()#text(" Best regards")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-610048")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2020")])]

#text("No, as I have not been able to confirm the veracity of their arguments (note that there is a history of multiple incorrect attempts at proving this conjecture). The degree 9 preprint, which is unpublished, relies on a further preprint of that author that was placed on the arXiv in 2013 but still remains unpublished to this day, while the degree 10 paper, while technically published in a journal, is not written to professional standards. In neither case do I see convincing evidence of a suitable level of peer review.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3184e2d2b198ccbbb770a514bac914a82f3e32e074940810c6ec6760b6b2f43-392ec8d2d61f8a46137696237f0a60a1da2be09a76d6b63af19abcb3bb1195b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vesselin")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-610083")[#strong[#text("Vesselin")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2020")])]

#text("For a rational function other than a polynomial, may there be a similar kind of relation between the critical points and the divisor of zeros and poles?")

#text("Also Sendov’s conjecture and some of its partial progresses tended to have a parallel to this mean value conjecture of Smale’s fro “The fundamental theorem of algebra and complexity theory”: *If ")#mi("f(z) = z + \\cdots + c_nz^n")#text(" is a degree-")#mi("n")#text(" complex polynomial normalized by ")#mi("f(0) = 0")#text(" and ")#mi("f^{\\prime}(0) = 1")#text(", is there a critical point ")#mi("\\alpha")#text(", ")#mi("f^{\\prime}(\\alpha) = 0")#text(", with ")#tao-math("\\left|f(\\alpha) / \\alpha\\right| < 1", block: false)#text("?* (The supposedly extremal of value ")#mi("1-1/n")#text(" coming from the supposedly extremal polynomial ")#mi("f(z) = z - z^n/n")#text(".) As far as I am aware, despite of the partial cases solved, for general polynomials the lowest proved absolute constant upper bound is still the \"4\" coming out of Koebe's quarter theorem? Apologies for the naive question: any chance of your method bearing on that problem also?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-611542")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2020")])]

#text("My guess would be that rational functions would be significantly less “rigid” than polynomials (as one can sense from e.g., Runge’s theorem) and that not much can be said here. For instance even the Gauss-Lucas theorem does not seem to have any reasonable analogue for rational functions.")

#text("I looked briefly at applying compactness methods to Smale’s conjecture, but it seems there is a lot less compactness present than in the Sendov conjecture problem, where Prokhorov’s theorem can be used to good effect on the empirical distribution of zeroes or critical points. If one takes a sequence of appropriately normalised putative counterexamples to Smale’s conjecture that asymptotically saturates the Koebe bound then one seems to get a sequence of polynomials that converges locally uniformly to (a branch of) the inverse of the Koebe function, away from the slit ")#mi("(-\\infty,-1/4]")#text(" associated to that function. So all the critical points of the polynomials will cluster near this slit, or near infinity (and one of the critical points has to converge to ")#mi("-1/4")#text(", to saturate the bound). But there doesn’t seem to be much mileage one can then extract from the limit objects – I think one can show that the majority of zeroes of the polynomial will go to infinity, but that’s about it. Probably some rather different methods (perhaps from conformal geometry?) are needed to make progress on this problem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sadboibruin")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-610270")[#strong[#text("sadboibruin")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2020")])]

#text("our mans Terrence Tao does it again while I just failed my 32A final 😪")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-610274")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2020")])]

#text("Dear Profes5or,")#linebreak()#text(" Following one of your previous answer on this post, I never heard of the IJSRP journal in maths too, but its impact factor is of 6.64.")#linebreak()#text(" Furthermore have you already studied the Kurepa conjecture?")#linebreak()#text(" Best,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c30af3cbe85dbd2d21acd23fceb3d34b0c975a33d40efb5157ce15db52b31822-0dacf7d04a23e84a3245ed4e2a7ef9e3b32c74759baa102c714e9e4f5c7e6d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-610386")[#strong[#text("Tim")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2020")])]

#text("Finding some $n_0$ and getting it as low as possible sounds like a polymath-project.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-610712")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2020")])]

#text("Since he used compactness many times, don’t expect it to be smaller than some exponential tower.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-611692")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2020")])]

#text("This thought occurred to me also. As commented elsewhere, the use of compactness right now will likely make the bounds quite poor if one tries to directly quantify the arguments in my paper. As one lower bound for how far one can get, to cover the middle range of ")#mi("a")#text(" (not too close to 0 or to 1) I use the results of Chalebgwa, which only apply for ")#mi("n \\geq 20800/a^7(1-a)^4")#text(", so the first value of ")#mi("n")#text(" for which this result is non-vacuous is about ")#mi("n \\approx 2.8 \\times 10^7")#text(". But probably the arguments I have that cover the range when ")#mi("a")#text(" is close to 0, or close (but not too close) to 1, will have even worse requirements on ")#mi("n")#text(". [In particular, my arguments rely on unique continuation theorems; the usual quantitative analogue of such theorems are the Carleman inequalities, which have exponential weights in them, and if this is combined in any way with some sort of pigeonholing argument then tower-exponential type bounds would be expected. On the other hand, we also rely a lot on the logarithmic potential, which as its name suggests could potentially turn a bound of size ")#mi("N")#text(" into a bound of size ")#mi("\\log N")#text(" in certain circumstances. So there may be some hope of keeping the total bounds somewhat civilised in nature.]")

#text("But perhaps once a “second generation” proof of the large n case comes out that relies less on compactness methods, a polymath project could be somewhat productive. It does resemble Polymath8 in that (a) the arguments are quite modular and one could work independently in different aspects of it (e.g., improving the analysis of Chalebgwa would be one obvious direction), and (b) there is a specific numerical “score” that one can use to measure progress which (as in Polymath8) would be a decreasing natural number, thus giving a natural termination point of the project when the number stops decreasing.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-611052")[#strong[#text("Хипотезата на акад. Сендов най-после получи доказателство – Война и мир")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2020")]

#text("[…] научни публикации. Публикуването на резултатите от неговото решение в блога му е изключително интересно и показва, че дори към днешна […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vlad")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-611711")[#strong[#text("Vlad")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2020")])]

#text("Dear Professor,")#linebreak()#text(" Maybe we have to check first the expansivity theory of Agama who claimed in a preprint uploaded to ArXiv last summer to have proved the Sendov-Ilieff conjecture.")#linebreak()#text(" Furthermore the approach followed by Meng in his preprints of 2013 and 2018 may be precised in the same way.")#linebreak()#text(" Last but not least, as commented before, the published paper of Bhattarai seems to be interesting too (even if its asian journal of publication is still unknown both in the maths and in the theoretical physics communities).")

#emph[#text("[Please do not ")#link("https://en.wikipedia.org/wiki/Sock_puppet_account")[#text("sockpuppet")]#text(" to give the illusion of multiple independent commenters. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7652eeb2b805811a86da6a98532347bf446d399d5b03d9abcf71493febdbfbe0-eb93d9cfe2ecf0dcd197b9181968a046c9f1fdfb6f68b8167a89ab54b00bee49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of athenanoctua")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-688843")[#strong[#text("athenanoctua")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2025")])]

#text("I wonder, for a steepest ascent path on the modulus surface of a polynomial from one of its roots to one of its critical points, whether the length of the projection of this path on the complex plane is at most one.")

#text("I am always seeing this to be true in simulations with better margins than numerical precision. I do not know yet how to prove or disprove it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78a9668bc87019752cb588bedfb132969716da2b1ab8a8011686d2ed1f85a762-708e5329096987355205cc66198457a7ab335f430826992f68908126a8759e5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lech Mazur")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-693805")[#strong[#text("Lech Mazur")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2026")])]

#text("I’ve posted an AI-generated proof of Sendov’s conjecture in full, formalized in Lean 4: ")#link("https://www.proofatlas.ai/papers/sendov-conjecture/SENDOV_CONJECTURE_PROOF_AUGUST_5_2026.pdf")[#text("https://www.proofatlas.ai/papers/sendov-conjecture/SENDOV_CONJECTURE_PROOF_AUGUST_5_2026.pdf")]#text(". Formalization overview: ")#link("https://www.proofatlas.ai/formalizations/sendov-conjecture/")[#text("https://www.proofatlas.ai/formalizations/sendov-conjecture/")]#text(" (the site is about many AI agents collaborating on math without duplicating effort).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A digestion of the proof of Sendov’s conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/#comment-693886")[#strong[#text("A digestion of the proof of Sendov’s conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2026")])]

#text("[…] a sequence of papers culminating in this paper of Brown and Xiang) and for sufficiently large (in a paper of myself, which in turn built upon several partial results in this setting). This left the case of […]")
]
