// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/12/27/tricks-wiki-use-basic-examples-to-calibrate-exponents/
// Converted to Typst by tao2typ: "2026-10-14T16:35:29.527232+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Tricks Wiki: Use basic examples to calibrate exponents", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Tricks Wiki: Use basic examples to calibrate exponents")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 December 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/12/27/tricks-wiki-use-basic-examples-to-calibrate-exponents/")[#text("https://terrytao.wordpress.com/2008/12/27/tricks-wiki-use-basic-examples-to-calibrate-exponents/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#strong[#text("Title:")]#text(" Use basic examples to calibrate exponents")

#strong[#text("Motivation:")]#text(" In the more quantitative areas of mathematics, such as analysis and combinatorics, one has to frequently keep track of a large number of exponents in one’s identities, inequalities, and estimates. For instance, if one is studying a set of N elements, then many expressions that one is faced with will often involve some power ")#mi("N^p")#text(" of N; if one is instead studying a function f on a measure space X, then perhaps it is an ")#mi("L^p")#text(" norm ")#tao-math("\\left\\|f\\right\\|_{L^p(X)}", block: false)#text(" which will appear instead. The exponent ")#mi("p")#text(" involved will typically evolve slowly over the course of the argument, as various algebraic or analytic manipulations are applied. In some cases, the exact value of this exponent is immaterial, but at other times it is crucial to have the correct value of ")#mi("p")#text(" at hand. One can (and should) of course carefully go through one’s arguments line by line to work out the exponents correctly, but it is all too easy to make a sign error or other mis-step at one of the lines, causing all the exponents on subsequent lines to be incorrect. However, one can guard against this (and avoid some tedious line-by-line exponent checking) by continually ")#emph[#text("calibrating")]#text(" these exponents at key junctures of the arguments by using basic examples of the object of study (sets, functions, graphs, etc.) as test cases. This is a simple trick, but it lets one avoid many unforced errors with exponents, and also lets one compute more rapidly.")

#strong[#text("Quick description: ")]#text(" When trying to quickly work out what an exponent p in an estimate, identity, or inequality should be without deriving that statement line-by-line, test that statement with a simple example which has non-trivial behaviour with respect to that exponent p, but trivial behaviour with respect to as many other components of that statement as one is able to manage. The “non-trivial” behaviour should be parametrised by some very large or very small parameter. By matching the dependence on this parameter on both sides of the estimate, identity, or inequality, one should recover p (or at least a good prediction as to what p should be).")

#strong[#text("General discussion:")]#text(" The test examples should be as basic as possible; ideally they should have trivial behaviour in all aspects except for one feature that relates to the exponent p that one is trying to calibrate, thus being only “barely” non-trivial. When the object of study is a function, then (appropriately rescaled, or otherwise modified) bump functions are very typical test objects, as are Dirac masses, constant functions, Gaussians, or other functions that are simple and easy to compute with. In additive combinatorics, when the object of study is a subset of a group, then subgroups, arithmetic progressions, or random sets are typical test objects. In graph theory, typical examples of test objects include complete graphs, complete bipartite graphs, and random graphs. And so forth.")

#text("This trick is closely related to that of using ")#link("http://en.wikipedia.org/wiki/Dimensional_analysis")[#text("dimensional analysis")]#text(" to recover exponents; indeed, one can view dimensional analysis as the special case of exponent calibration when using test objects which are non-trivial in one dimensional aspect (e.g. they exist at a single very large or very small length scale) but are otherwise of a trivial or “featureless” nature. But the calibration trick is more general, as it can involve parameters (such as probabilities, angles, or eccentricities) which are not commonly associated with the physical concept of a dimension. And personally, I find example-based calibration to be a much more satisfying (and convincing) explanation of an exponent than a calibration arising from formal dimensional analysis.")

#text("When one is trying to calibrate an inequality or estimate, one should try to pick a basic example which one expects to ")#emph[#text("saturate")]#text(" that inequality or estimate, i.e. an example for which the inequality is close to being an equality. Otherwise, one would only expect to obtain some partial information on the desired exponent p (e.g. a lower bound or an upper bound only). Knowing the examples that saturate an estimate that one is trying to prove is also useful for several other reasons – for instance, it strongly suggests that any technique which is not efficient when applied to the saturating example, is unlikely to be strong enough to prove the estimate in general, thus eliminating fruitless approaches to a problem and (hopefully) refocusing one’s attention on those strategies which actually have a chance of working.")

#text("Calibration is best used for the type of quick-and-dirty calculations one uses when trying to rapidly map out an argument that one has roughly worked out already, but without precise details; in particular, I find it particularly useful when ")#link("https://terrytao.wordpress.com/advice-on-writing-papers/write-a-rapid-prototype-first/")[#text("writing up a rapid prototype")]#text(". When the time comes to write out the paper in full detail, then of course one should instead carefully work things out line by line, but if all goes well, the exponents obtained in that process should match up with the preliminary guesses for those exponents obtained by calibration, which adds confidence that there are no exponent errors have been committed.")

#strong[#text("Prerequisites:")]#text(" Undergraduate analysis and combinatorics.")

#metadata(none) <tao-c27d14c16ff2e3116e7c>

#strong[#text("Example 1. ")]#text("(Elementary identities) There is a familiar identity for the sum of the first n squares:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("1^2 + 2^2 + 3^2 + \\ldots + n^2 = ???")]]

#text("But imagine that one has forgotten exactly what the RHS of (1) was supposed to be… one remembers that it was some polynomial in n, but can’t remember what the degree or coefficients of the polynomial were. Now one can of course try to rederive the identity, but there are faster (albeit looser) ways to reconstruct the right-hand side. Firstly, we can look at the asymptotic test case ")#mi("n \\to \\infty")#text(". On the LHS, we are summing n terms of size at most ")#mi("n^2")#text(", so the LHS is at most ")#mi("n^3")#text("; thus, if we believe the RHS to be a polynomial in n, it should be at most cubic in n. We can do a bit better by approximating the sum in the LHS by the integral ")#mi("\\int_0^n x^2\\ dx = n^3/3")#text(", which strongly suggests that the cubic term on the RHS should be ")#mi("n^3/3")#text(". So now we have")

#align(center)[#tao-fit-display[#mitex("1^2 + 2^2 + 3^2 + \\ldots + n^2 = \\frac{1}{3} n^3 + a n^2 + b n + c")]]

#text("for some coefficients a,b,c that we still have to work out.")

#text("We can plug in some other basic cases. A simple one is n=0. The LHS is now zero, and so the constant coefficient c on the RHS should also vanish. A slightly less obvious base case is n=-1. The LHS is still zero (note that the LHS for n-1 should be the LHS for n, minus ")#mi("n^2")#text("), and so the RHS still vanishes here; thus by the factor theorem, the RHS should have both n and n+1 as factors. We are now looking at")

#align(center)[#tao-fit-display[#mitex("1^2 + 2^2 + 3^2 + \\ldots + n^2 = n(n+1) ( \\frac{1}{3} n + d )")]]

#text("for some unspecified constant d. But now we just need to try one more test case, e.g. n=1, and we learn that ")#mi("d = 1/6")#text(", thus recovering the correct formula")

#align(center)[#mi("\\displaystyle 1^2 + 2^2 + 3^2 + \\ldots + n^2 = \\frac{n(n+1) (2n+1)}{6}")#text(". (1′)")]

#text("Once one has the formula (1′) in hand, of course, it is not difficult to verify by a textbook use of mathematical induction that the formula is in fact valid. (Alternatively, one can prove a more abstract theorem that the sum of the first n ")#mi("k^{th}")#text(" powers is necessarily a polynomial in n for any given k, at which point the above analysis actually becomes a rigorous derivation of (1′).)")

#text("Note that the optimal strategy here is to start with the most basic test cases (")#mi("n \\to \\infty, n = 0, n = -1")#text(") first before moving on to less trivial cases. If instead one used, e.g. n=1, n=2, n=3, n=4 as the test cases, one would eventually have obtained the right answer, but it would have been more work.")

#strong[#text("Exercise 1.")]#text(" (")#link("http://en.wikipedia.org/wiki/Partial_fraction")[#text("Partial fractions")]#text(") If ")#mi("w_1,\\ldots,w_k")#text(" are distinct complex numbers, and P(z) is a polynomial of degree less than k, establish the existence of a partial fraction decomposition")

#align(center)[#tao-fit-display[#mitex("\\frac{P(z)}{(z-w_1) \\ldots (z-w_k)} = \\frac{c_1}{z-w_1} + \\ldots + \\frac{c_k}{z-w_k},")]]

#text("(Hint: use the ")#link("http://en.wikipedia.org/wiki/Polynomial_remainder_theorem")[#text("remainder theorem")]#text(" and induction) and use the test cases ")#mi("z \\to w_j")#text(" for ")#mi("j=1,\\ldots,k")#text(" to compute the coefficients ")#mi("c_1,\\ldots,c_k")#text(". Use this to deduce the ")#link("http://en.wikipedia.org/wiki/Lagrange_polynomial")[#text("Lagrange interpolation formula")]#text(". ")#mi("\\diamond")

#strong[#text("Example 2.")]#text(" (Counting cycles in a graph) Suppose one has a ")#link("http://en.wikipedia.org/wiki/Graph_(mathematics)")[#text("graph")]#text(" G on N vertices with an edge density of ")#mi("\\delta")#text(" (thus, the number of edges is ")#mi("\\delta \\binom{N}{2}")#text(", or roughly ")#mi("\\delta N^2")#text(" up to constants). There is a standard ")#link("http://en.wikipedia.org/wiki/Cauchy%E2%80%93Schwarz_inequality")[#text("Cauchy-Schwarz")]#text(" argument that gives a lower bound on the number of four-")#link("http://en.wikipedia.org/wiki/Cycle_(graph_theory)")[#text("cycles")]#text(" ")#mi("C_4")#text(" (i.e. a circuit of four vertices connected by four edges) present in G, as a function of ")#mi("\\delta")#text(" and N. It only takes a few minutes to reconstruct this argument to obtain the precise bound, but suppose one was in a hurry and wanted to guess the bound rapidly. Given the “polynomial” nature of the Cauchy-Schwarz inequality, the bound is likely to be some polynomial combination of ")#mi("\\delta")#text(" and N, such as ")#mi("\\delta^p N^q")#text(" (omitting constants and lower order terms). But what should p and q be?")

#text("Well, one can test things with some basic examples. A really trivial example is the empty graph (where ")#mi("\\delta = 0")#text("), but this is too trivial to tell us anything much (other than that p should probably be positive). At the other extreme, consider the complete graph on N vertices, where ")#mi("\\delta = 1")#text("; this renders p irrelevant, but still makes q non-trivial (and thus, hopefully, computable). In the complete graph, every set of four points yields a four-cycle ")#mi("C_4")#text(", so the number of four-cycles here should be about ")#mi("N^4")#text(" (give or take some constant factors, such as 4! – remember that we are in a hurry here, and are ignoring these sorts of constant factors). This tells us that q should be at most 4, and if we expect the Cauchy-Schwarz bound to be saturated for the complete graph (which is a good bet – arguments based on the Cauchy-Schwarz inequality tend to work well in very “uniformly distributed” situations) – then we would expect q to be exactly 4.")

#text("To calibrate p, we need to test with graphs of density ")#mi("\\delta")#text(" less than 1. Given the previous intuition that Cauchy-Schwarz arguments work well in uniformly distributed situations, we would want to use a test graph of density ")#mi("\\delta")#text(" that is more or less uniformly distributed. A good example of such a graph is a ")#emph[#text("random")]#text(" graph G on N vertices, in which each edge has an independent probability of ")#mi("\\delta")#text(" of lying in G. By the ")#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/")[#text("law of large numbers")]#text(", we expect the edge density of such a random graph to be close to ")#mi("\\delta")#text(" on the average. On the other hand, each one of the roughly ")#mi("N^4")#text(" four-cycles ")#mi("C_4")#text(" connecting the N vertices has a probability about ")#mi("\\delta^4")#text(" of lying in the graph, since the ")#mi("C_4")#text(" has four edges, each with an independent probability of ")#mi("\\delta")#text(" of lying in the edge. The events that each of the four-cycles lies in the graph G aren’t completely independent of each other, but they are still close enough to being so that one can guess using the law of large numbers that the total number of 4-cycles should be about ")#mi("\\delta^4 N^4")#text(" on the average (up to constants). [Actually, linearity of expectation will give us this claim even without any independence whatsoever.] So this leads one to predict p=4, thus the number of 4-cycles in any graph on N vertices of density ")#mi("\\delta")#text(" should be ")#mi("\\geq c \\delta^4 N^4")#text(" for some absolute constant ")#mi("c>0")#text(", and this is indeed the case (provided that one also counts degenerate cycles, in which some vertices are repeated).")

#text("If one is nervous about using the random graph as the test graph, one could try a graph at the other end of the spectrum – e.g. the complete graph on about ")#mi("\\sqrt{\\delta} N")#text(" vertices, which also has edge density about ")#mi("\\delta")#text(". Here one quickly calculates that the number of 4-cycles is about ")#mi("\\delta^2 N^4")#text(", which is a larger quantity than in the random case (and this fits with the intuition that this graph is packing the same number of edges into a tighter space, and should thus increase the number of cycles). So the random graph is still the best candidate for a near-extremiser for this bound. (Actually, if the number of 4-cycles is close to the Cauchy-Schwarz lower bound, then the graph becomes ")#emph[#text("pseudorandom")]#text(", which roughly speaking means any randomly selected small subgraph of that graph is indistinguishable from a random graph.)")

#text("One should caution that sometimes the random object is ")#emph[#text("not")]#text(" the extremiser, and so does not always calibrate an estimate correctly. For instance, consider ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di%27s_theorem")[#text("Szemerédi’s theorem")]#text(", that asserts that given any ")#mi("0 < \\delta < 1")#text(" and ")#mi("k > 1")#text(", that any subset of ")#mi("\\{1,\\ldots,N\\}")#text(" of density ")#mi("\\delta")#text(" should contain at least one arithmetic progression of length k, if N is large enough. One can then ask what is the minimum number of k-term arithmetic progressions such a set would contain. Using the random subset of ")#mi("\\{1,\\ldots,N\\}")#text(" of density ")#mi("\\delta")#text(" as a test case, we would guess that there should be about ")#mi("\\delta^k N^2")#text(" (up to constants depending on k). However, it turns out that the number of progressions can be significantly less than this (basically thanks to the old ")#link("http://www.ams.org/mathscinet-getitem?mr=18694")[#text("counterexample of Behrend")]#text("): given any constant C, one can get significantly fewer than ")#mi("\\delta^C N^2")#text(" k-term progressions. But, thanks to an ")#link("http://www.ams.org/mathscinet-getitem?mr=106865")[#text("averaging argument of Varnavides")]#text(", it is known that there are at least ")#mi("c(k,\\delta) N^2")#text(" k-term progressions (for N large enough), where ")#mi("c(k,\\delta) > 0")#text(" is a positive quantity. (Determining the exact order of magnitude of ")#mi("c(k,\\delta)")#text(" is still an important open problem in this subject.) So one can at least calibrate the correct dependence on N, even if the dependence on ")#mi("\\delta")#text(" is still unknown.")

#strong[#text("Example 3.")]#text(" (Sobolev embedding) Given a reasonable function ")#mi("f: {\\Bbb R}^n \\to {\\Bbb R}")#text(" (e.g. a ")#link("http://en.wikipedia.org/wiki/Schwartz_space")[#text("Schwartz class function")]#text(" will do), the ")#link("http://en.wikipedia.org/wiki/Sobolev_inequality")[#text("Sobolev embedding theorem")]#text(" gives estimates such as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\| f \\right\\|_{L^q({\\Bbb R}^n)} \\leq C_{n,p,q} \\left\\|\\nabla f\\right\\|_{L^p({\\Bbb R}^n)}", block: true)]]

#text("for various exponents p, q. Suppose one has forgotten the exact relationship between p, q, and n and wants to quickly reconstruct it, without rederiving the proof of the theorem or looking it up. One could use dimensional analysis to work out the relationship (and we will come to that shortly), but an equivalent way to achieve the same result is to test the inequality (2) against a suitably basic example, preferably one that one expects to saturate (2).")

#text("To come as close to saturating (2) as possible, one wants to keep the gradient of f small, while making f large; among other things, this suggests that unnecessary oscillations in f should be kept to a minimum. A natural candidate for an extremiser, then, would be a ")#emph[#text("rescaled bump function")]#text(" ")#mi("f(x) = A\\phi(x/L)")#text(", where ")#mi("\\phi \\in C^\\infty_0({\\Bbb R}^n)")#text(" is some fixed bump function, ")#mi("A > 0")#text(" is an amplitude parameter, and ")#mi("L > 0")#text(" is a parameter, thus f is a rescaled bump function of bounded amplitude O(A) that is supported on a ball of radius O(r) centred at the origin. [As the estimate (2) is linear, the amplitude A turns out to ultimately be irrelevant here, but the amplitude plays a more crucial role in nonlinear estimates; for instance, it explains why nonlienar estimates typically have the same number of appearances of a given unknown function f in each term. Also, it is sometimes convenient to carefully choose the amplitude in order to attain a convenient normalisation, e.g. to set one of the norms in (2) equal to 1.]")

#text("The ball that f is supported on has volume about ")#mi("O(L^n)")#text(" (allowing implied constants to depend on n), and so the ")#mi("L^q")#text(" norm of f should be about ")#mi("O(L^{n/q} )")#text(" (allowing implied constants to depend on q as well). As for the gradient of f, since f oscillates by O(A) over a length scale of O(L), one expects ")#mi("\\nabla f")#text(" to have size about ")#mi("O(A/L)")#text(" on this ball (remember, derivatives measure “")#link("http://en.wikipedia.org/wiki/Slope")[#text("rise over run")]#text("“!), and so the ")#mi("L^p")#text(" norm of ")#mi("\\nabla f")#text(" should be about ")#mi("O( \\frac{A}{L} L^{n/p} )")#text(". Inserting this numerology into (2), and equating powers of L (note A cancels itself into irrelevance, and could in any case be set to equal 1), we are led to the relation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\frac{n}{p} - 1 = \\frac{n}{q}")]]

#text("which is indeed one of the necessary conditions for (2). (The other necessary conditions are that p and q lie strictly between 1 and infinity, but these require a more complicated test example to establish.)")

#text("One can efficiently perform the above argument using the language of dimensional analysis. Giving f the units of amplitude A, and giving space the units of length L, we see that the n-dimensional integral ")#mi("\\int_{{\\Bbb R}^n}\\ dx")#text(" has units of ")#mi("L^n")#text(", and thus ")#mi("L^p({\\Bbb R}^n)")#text(" norms have units of ")#mi("L^{n/p}")#text(". Meanwhile, from the rise-over-run interpretation of the derivative, ")#mi("\\nabla f")#text(" has units of ")#mi("A/L")#text(", thus the LHS and RHS of (2) have units of ")#mi("A L^{n/q}")#text(" and ")#mi("\\frac{A}{L} L^{n/p}")#text(" respectively. Equating these dimensions gives (3). Observe how this argument is basically a shorthand form of the argument based on using the rescaled bump function as a test case; with enough practice one can use this shorthand to calibrate exponents rapidly for a wide variety of estimates.")

#strong[#text("Exercise 2.")]#text(" Convert the above discussion into a rigorous proof that (3) is a necessary condition for (2). (Hint: exploit the freedom to send L to zero or to infinity.) What happens to the necessary conditions if ")#mi("{\\Bbb R}^n")#text(" is replaced with a bounded domain (such as the unit cube ")#mi("{}[0,1]^n")#text(", assuming Dirichlet boundary conditions) or a discrete domain (such as the lattice ")#mi("{\\Bbb Z}^n")#text(", replacing the gradient with a discrete gradient of course)? ")#mi("\\diamond")

#strong[#text("Exercise 3. ")]#text(" If one replaces (2) by the variant estimate")

#align(center)[#tao-math("\\displaystyle \\left\\| f \\right\\|_{L^q({\\Bbb R}^n)} \\leq C_{n,p,q} (\\left\\|f\\right\\|_{L^p({\\Bbb R}^n)} + \\left\\|\\nabla f\\right\\|_{L^p({\\Bbb R}^n)})", block: false)#text(" (2′)")]

#text("establish the necessary condition")

#align(center)[#mi("\\displaystyle \\frac{n}{p} - 1 \\leq \\frac{n}{q} \\leq \\frac{n}{p}")#text(". (3′)")]

#text("What happens to the dimensional analysis argument in this case? ")#mi("\\diamond")

#strong[#text("Remark 1. ")]#text(" There are many other estimates in harmonic analysis which are saturated by some modification of a bump function; in addition to the isotropically rescaled bump functions used above, one could also rescale bump functions by some non-isotropic linear transformation (thus creating various “squashed” or “stretched” bumps adapted to disks, tubes, rectangles, or other sets), or modulate bumps by various frequencies, or translate them around in space. One can also try to superimpose several such transformed bump functions together to amplify the counterexample. The art of selecting good counterexamples can be somewhat difficult, although with enough trial and error one gets a sense of what kind of arrangement of bump functions are needed to make the right-hand side small and the left-hand side large in the estimate under study. ")#mi("\\diamond")

#strong[#text("Example 3 ")]#text(" (Scale-invariance in nonlinear PDE) The model equations and systems studied in nonlinear PDE often enjoy various symmetries, notably scale-invariance symmetry, that can then be used to calibrate various identities and estimates regarding solutions to those equations. For sake of discussion, let us work with the ")#link("http://en.wikipedia.org/wiki/Nonlinear_Schr%C3%B6dinger_equation")[#text("nonlinear Schrödinger equation")]#text(" (NLS)")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("i u_t + \\Delta u = \\left|u\\right|^{p-1} u", block: true)]]

#text("where ")#mi("u: {\\Bbb R} \\times {\\Bbb R}^n \\to {\\Bbb C}")#text(" is the unknown field, ")#mi("\\Delta")#text(" is the spatial Laplacian, and ")#mi("p > 1")#text(" is a fixed exponent. (One can also place in some other constants in (4), such as Planck’s constant ")#mi("\\hbar")#text(", but we have normalised this constant to equal 1 here, although it is sometimes useful to reinstate this constant for calibration purposes.) If u is one solution to (4), then we can form a rescaled family ")#mi("u^{(\\lambda)}")#text(" of such solutions by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("u^{(\\lambda)}(t,x) := \\frac{1}{\\lambda^a} u( \\frac{t}{\\lambda^b}, \\frac{x}{\\lambda} )")]]

#text("for some specific exponents a, b; these play the role of the rescaled bump functions in Example 2. The exponents a,b can be worked out by testing (4) using (5), and we leave this as an exercise to the reader, but let us instead use the shorthand of dimensional analysis to work these exponents out. Let’s give u the units of amplitude A, space the units of length L, and time the units of duration T. Then the three terms in (4) have units ")#mi("A/T")#text(", ")#mi("A/L^2")#text(", and ")#mi("A^p")#text(" respectively; equating these dimensions gives ")#mi("T=L^2")#text(" and ")#mi("A=L^{-2/(p-1)}")#text(". (In particular, time has “twice the dimension” of space; this is a feature of many non-relativistic equations such as Schrödinger, heat, or viscosity equations. For relativistic equations, of course, time and space have the same dimension with respect to scaling.) On the other hand, the scaling (5) multiplies A, T, and L by ")#mi("\\lambda^{-a}")#text(", ")#mi("\\lambda^b")#text(", and ")#mi("\\lambda")#text(" respectively; to maintain consistency with the relations ")#mi("T=L^2")#text(" and ")#mi("A=L^{-2/(p-1)}")#text(" we must thus have ")#mi("a=2/(p-1)")#text(" and ")#mi("b=2")#text(".")

#strong[#text("Exercise 4. ")]#text(" Solutions to (4) (with suitable smoothness and decay properties) enjoy a conserved Hamiltonian ")#mi("H(u)")#text(", of the form")

#align(center)[#tao-fit-display[#tao-math("H(u) = \\int_{{\\Bbb R}^n} \\frac{1}{2} \\left|\\nabla u\\right|^2 + \\alpha \\left|u\\right|^q\\ dx", block: true)]]

#text("for some constants ")#mi("\\alpha, q")#text(". Use dimensional analysis (or the rescaled solutions (5) as test cases) to compute q. (The constant ")#mi("\\alpha")#text(", unfortunately, cannot be recovered from dimensional analysis, and other model test cases, such as solitons or other solutions obtained via ")#link("http://en.wikipedia.org/wiki/Separation_of_variables")[#text("separation of variables")]#text(", also turn out unfortunately to not be sensitive enough to ")#mi("\\alpha")#text(" to calibrate this parameter.) ")#mi("\\diamond")

#strong[#text("Remark 2.")]#text(" The scaling symmetry (5) is not the only symmetry that can be deployed to calibrate identities and estimates for solutions to NLS. For instance, we have a simple phase rotation symmetry ")#mi("u \\mapsto e^{i\\theta} u")#text(" for such solutions, where ")#mi("\\theta \\in {\\Bbb R}")#text(" is an arbitrary phase. This symmetry suggests that in any identity involving u and its complex conjugate ")#mi("\\bar{u}")#text(", the net number of factors of u, minus the factors of ")#mi("\\bar{u}")#text(", in each term of the identity should be the same. (Factors without phase, such as |u|, should be ignored for this analysis.) Other important symmetries of NLS, which can also be used for calibration, include space translation symmetry, time translation symmetry, and ")#link("https://terrytao.wordpress.com/2008/12/27/tricks-wiki-use-basic-examples-to-calibrate-exponents/tosio.math.toronto.edu/wiki/index.php/Galilean")[#text("Galilean invariance")]#text(". (While these symmetries can of course be joined together, to create a large-dimensional family of transformed solutions arising from a single base solution u, for the purposes of calibration it is usually best to just use each of the generating symmetries separately.) For gauge field equations, gauge invariance is of course a crucial symmetry, though one can make the calibration procedure with respect to this symmetry automatic by working exclusively with gauge-invariant notation (see also my earlier post on ")#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/")[#text("gauge theory")]#text("). Another important test case for Schrödinger equations is the ")#link("http://tosio.math.toronto.edu/wiki/index.php/High-frequency_limit")[#text("high-frequency limit")]#text(" ")#tao-math("\\left|\\xi\\right| \\to \\infty", block: false)#text(", closely related to the ")#emph[#text("semi-classical limit")]#text(" ")#mi("\\hbar \\to 0")#text(", that allows one to use classical mechanics to calibrate various identities and estimates in quantum mechanics. ")#mi("\\diamond")

#strong[#text("Exercise 5.")]#text(" Solutions to (4) (again assuming suitable smoothness and decay) also enjoy a ")#link("https://terrytao.wordpress.com/2008/12/27/tricks-wiki-use-basic-examples-to-calibrate-exponents/tosio.math.toronto.edu/wiki/index.php/Virial_identity")[#text("virial identity")]#text(" of the form")

#align(center)[#tao-fit-display[#tao-math("\\partial_{tt} \\int_{{\\Bbb R}^n} x^2 \\left|u(t,x)\\right|^2\\ dx = \\int_{{\\Bbb R}^n} ???\\ dx", block: true)]]

#text("where the right-hand side only involves u and its spatial derivatives ")#mi("\\nabla u")#text(", and does not explicitly involve the spatial variable x. Using the various symmetries, predict the type of terms that should go on the right-hand side. (Again, the coefficients of these terms are unable to be calibrated using these methods, but the exponents should be accessible.) ")#mi("\\diamond")

#strong[#text("Remark 3.")]#text(" Einstein used this sort of calibration technique (using the symmetry of spacetime diffeomorphisms, better known as the ")#link("http://en.wikipedia.org/wiki/Principle_of_relativity")[#text("general principle of relativity")]#text(", as well as the non-relativistic limit of Newtonian gravity as another test case) to derive the ")#link("http://en.wikipedia.org/wiki/Einstein_field_equations")[#text("Einstein equations of gravity")]#text(", although the one constant that he was unable to calibrate in this fashion was the ")#link("http://en.wikipedia.org/wiki/Cosmological_constant")[#text("cosmological constant")]#text(". ")#mi("\\diamond")

#strong[#text("Example 4")]#text(" (Fourier-analytic identities in additive combinatorics). Fourier analysis is a useful tool in additive combinatorics for counting various configurations in sets, such as arithmetic progressions ")#mi("n, n+r, n+2r")#text(" of length three. (It turns out that classical Fourier analysis is not able to handle progressions of any longer length, but that is a story for another time – see e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=1631259")[#text("this paper of Gowers")]#text(" for some discussion.) A typical situation arises when working in a finite group such as ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(", and one has to compute an expression such as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{n, r \\in {\\Bbb Z}/N{\\Bbb Z}} f(n) g(n+r) h(n+2r)")]]

#text("for some functions ")#mi("f,g,h: {\\Bbb Z}/N{\\Bbb Z} \\to {\\Bbb C}")#text(" (for instance, these functions could all be the indicator function of a single set ")#mi("A \\subset {\\Bbb Z}/N{\\Bbb Z}")#text("). The quantity (6) can be expressed neatly in terms of the Fourier transforms ")#mi("\\hat f, \\hat g, \\hat h: {\\Bbb Z}/N{\\Bbb Z} \\to {\\Bbb C}")#text(", which we normalise as ")#mi("\\hat f(\\xi) := \\frac{1}{N} \\sum_{x \\in {\\Bbb Z}/N{\\Bbb Z}} f(x) e^{-2\\pi i x \\xi/N}")#text(". It is not too difficult to compute this expression by means of the Fourier inversion formula and some routine calculation, but suppose one was in a hurry and only had a vague recollection of what the Fourier-analytic expression of (6) was – something like")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("N^p \\sum_{\\xi \\in {\\Bbb Z}/N{\\Bbb Z}}\\hat f( a \\xi ) \\hat g( b \\xi ) \\hat h( c \\xi )")]]

#text("for some coefficients p, a, b, c, but the precise values of which have been forgotten. (In view of some other Fourier-analytic formulae, one might think that some of the Fourier transforms ")#mi("\\hat f, \\hat g, \\hat h")#text(" might need to be complex conjugated for (7), but this should not happen here, because (6) is linear in f,g,h rather than anti-linear; cf. the discussion in Example 3 about factors of u and ")#mi("\\bar{u}")#text(".) How can one quickly calibrate the values of p,a,b,c without doing the full calculation?")

#text("To isolate the exponent p, we can consider the basic case ")#mi("f \\equiv g \\equiv h \\equiv 1")#text(", in which case the Fourier transforms are just the ")#link("http://en.wikipedia.org/wiki/Kronecker_delta")[#text("Kronecker delta")]#text(" function (e.g. ")#mi("\\hat f(\\xi)")#text(" equals 1 for ")#mi("\\xi=0")#text(" and vanishes otherwise). The expression (6) is just ")#mi("N^2")#text(", while the expression (7) is ")#mi("N^p")#text(" (because only one of the summands is non-trivial); thus p must equal 2. (Exercise: reinterpret the above analysis as a dimensional analysis.)")

#text("Next, to calibrate a,b,c, we modify the above basic test case slightly, modulating the f,g,h so that a different element of the sum in (7) is non-zero. Let us take ")#mi("f(x) := e^{2\\pi i a x \\xi/N}")#text(", ")#mi("g(x) := e^{2\\pi i b x \\xi/N}")#text(", ")#mi("h(x) := e^{2\\pi i c x \\xi/N}")#text(" for some fixed frequency ")#mi("\\xi")#text("; then (4) is again equal to ")#mi("N^p=N^2")#text(", while (6) is equal to")

#align(center)[#tao-fit-display[#mitex("\\sum_{n,r \\in {\\Bbb Z}/N{\\Bbb Z}} e^{2\\pi i [ a n + b (n+r) + c(n+2r)] \\xi / N}.")]]

#text("In order for this to equal ")#mi("N^2")#text(" for any ")#mi("\\xi")#text(", we need the linear form ")#mi("an+b(n+r)+c(n+2r)")#text(" to vanish identically, which forces a=c and b=-2a. We can normalise a=1 (by using the change of variables ")#mi("\\xi \\mapsto a \\xi")#text("), thus leading us to the correct expression for (7), namely")

#align(center)[#mi("\\displaystyle N^2 \\sum_{\\xi \\in {\\Bbb Z}/N{\\Bbb Z}}\\hat f( \\xi ) \\hat g( -2 \\xi ) \\hat h( \\xi )")#text(".")]

#text("Once one actually has this formula, of course, it is a routine matter to check that it actually is the right answer.")

#strong[#text("Remark 4.")]#text(" One can also calibrate a,b,c in (7) by observing the identity ")#mi("n - 2(n+r) + (n+2r)=0")#text(" (which reflects the fact that the second derivative of a linear function is necessarily zero), which gives a modulation symmetry ")#mi("f(x) \\mapsto f(x) e^{2\\pi i \\alpha x}")#text(", ")#mi("g(x) \\mapsto g(x) e^{-4\\pi i \\alpha x}")#text(", ")#mi("h(x) \\mapsto h(x) e^{2\\pi i \\alpha x}")#text(" to (6). Inserting this symmetry into (7) reveals that ")#mi("a=c")#text(" and ")#mi("b=-2a")#text(" as before. ")#mi("\\diamond")

#strong[#text("Remark 5.")]#text(" By choosing appropriately normalised conventions, one can avoid some calibration duties altogether. For instance, when using Fourier analysis on a finite group such as ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(", if one expects to be analysing functions that are close to constant (or subsets of the group of positive density), then it is natural to endow physical space with normalised counting measure (and thus, by Pontryagin duality, frequency space should be given non-normalised counting measure). [Conversely, if one is analysing functions concentrated on only a bounded number of points, then it may be more convenient to give physical space counting measure and frequency space normalised counting measure.] In practical terms, this means that any physical space sum, such as ")#mi("\\sum_{x \\in {\\Bbb Z}/N{\\Bbb Z}} f(x)")#text(", should instead be replaced with a physical space average ")#mi("{\\Bbb E}_{x \\in {\\Bbb Z}/N{\\Bbb Z}} f(x) = \\frac{1}{N} \\sum_{x \\in {\\Bbb Z}/N{\\Bbb Z}} f(x)")#text(", while keeping sums over frequency space variables unchanged; when one does so, all powers of N “miraculously” disappear, and there is no longer any need to calibrate using the constant function 1 as was done above. Of course, this does not eliminate the need to perform other calibrations, such as that of the coefficients a,b,c above. ")#mi("\\diamond")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carl")]], [#link("https://terrytao.wordpress.com/2008/12/27/tricks-wiki-use-basic-examples-to-calibrate-exponents/#comment-34414")[#strong[#text("Carl")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2008")])]

#text("Hi,")

#text("In example 1 the integral of x^2 from 0 to n should be n^3/3. ")#emph[#text("[Corrected, thanks. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tmr")]], [#link("https://terrytao.wordpress.com/2008/12/27/tricks-wiki-use-basic-examples-to-calibrate-exponents/#comment-34429")[#strong[#text("tmr")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2008")])]

#text("In example 1, can you please elaborate on how you can take n=-1 as an example? Can you take n=-2?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tmr")]], [#link("https://terrytao.wordpress.com/2008/12/27/tricks-wiki-use-basic-examples-to-calibrate-exponents/#comment-34434")[#strong[#text("tmr")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2008")])]

#text("Ok, I understand now. You extended the definition of LHS for negative n as well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d23623bea3b47552b66949227c40ae466715a00098e43bfdc86b13272b3196f7-7e5f7c761d708615001147a322fec83a1062f224426813fb30729c5dfa75fa26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of daoguozhou")]], [#link("https://terrytao.wordpress.com/2008/12/27/tricks-wiki-use-basic-examples-to-calibrate-exponents/#comment-34490")[#strong[#text("daoguozhou")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2008")])]

#text("The beautiful article clarifies something in PDE. In my opinion, Tricks Wiki is of great help to graduate students like me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of \\sqrt[4]{3}")]], [#link("https://terrytao.wordpress.com/2008/12/27/tricks-wiki-use-basic-examples-to-calibrate-exponents/#comment-34495")[#strong[#text("\\sqrt[4]{3}")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2008")])]

#text("It would be better to clarify the Riemann Hypothesis, e.g.,")#linebreak()#text(" by finding only two zeros which are not on 1/2.")#linebreak()#text(" Happy New Year!")#linebreak()#text(" Symbolic Logic")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/390517060033239b9bf4fdf38be68020e8c3713bc59523c096d8f998664e0bbe-8a87dc77dc8f1db8ed403dfd640cfca3565b7b89c4f53fa7c5cbd2c0bed27bd8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2008/12/27/tricks-wiki-use-basic-examples-to-calibrate-exponents/#comment-34518")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2008")])]

#text("Lovely! I realized some time ago that the test case in Example 1 applied to 1/(1 – x^n) can also be used to extract the coefficients of the DFT matrix of order n, but using it to extract the coefficients of the Lagrange interpolating polynomial is sneaky.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A mathematical formalisation of dimensional analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2008/12/27/tricks-wiki-use-basic-examples-to-calibrate-exponents/#comment-211408")[#strong[#text("A mathematical formalisation of dimensional analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2012")])]

#text("[…] this inequality, as a necessary condition for (5). (See also this blog post for an equivalent way to establish these conditions, using rescaled test functions instead of […]")
]
