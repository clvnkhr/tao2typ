// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/10/28/van-kampens-theorem-via-covering-spaces/
// Converted to Typst by tao2typ: "2026-10-14T15:18:30.235220+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "van Kampen’s theorem via covering spaces", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("van Kampen’s theorem via covering spaces")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 October 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/10/28/van-kampens-theorem-via-covering-spaces/")[#text("https://terrytao.wordpress.com/2012/10/28/van-kampens-theorem-via-covering-spaces/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("If ")#mi("{M}")#text(" is a connected ")#link("http://en.wikipedia.org/wiki/Topological_manifold")[#text("topological manifold")]#text(", and ")#mi("{p}")#text(" is a point in ")#mi("{M}")#text(", the (topological) ")#link("http://en.wikipedia.org/wiki/Fundamental_group")[#text("fundamental group")]#text(" ")#mi("{\\pi_1(M,p)}")#text(" of ")#mi("{M}")#text(" at ")#mi("{p}")#text(" is traditionally defined as the space of equivalence classes of loops starting and ending at ")#mi("{p}")#text(", with two loops considered equivalent if they are homotopic to each other. (One can of course define the fundamental group for more general classes of topological spaces, such as locally path connected spaces, but we will stick with topological manifolds in order to avoid pathologies.) As the name suggests, it is one of the most basic topological invariants of a manifold, which among other things can be used to classify the ")#link("http://en.wikipedia.org/wiki/Covering_space")[#text("covering spaces")]#text(" of that manifold. Indeed, given any such covering ")#mi("{\\phi: N \\rightarrow M}")#text(", the fundamental group ")#mi("{\\pi_1(M,p)}")#text(" acts (on the right) by monodromy on the fibre ")#mi("{\\phi^{-1}(\\{p\\})}")#text(", and conversely given any discrete set with a right action of ")#mi("{\\pi_1(M,p)}")#text(", one can find a covering space with that monodromy action (this can be done by “tensoring” the universal cover with the given action, as illustrated below the fold). In more category-theoretic terms: monodromy produces an ")#link("http://en.wikipedia.org/wiki/Equivalence_of_categories")[#text("equivalence of categories")]#text(" between the category of covers of ")#mi("{M}")#text(", and the category of discrete ")#mi("{\\pi_1(M,p)}")#text("-sets.")

#text("One of the basic tools used to compute fundamental groups is ")#link("http://en.wikipedia.org/wiki/Seifert%E2%80%93van_Kampen_theorem")[#text("van Kampen’s theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (van Kampen’s theorem)")]#text(" Let ")#mi("{M_1, M_2}")#text(" be connected open sets covering a connected topological manifold ")#mi("{M}")#text(" with ")#mi("{M_1 \\cap M_2}")#text(" also connected, and let ")#mi("{p}")#text(" be an element of ")#mi("{M_1 \\cap M_2}")#text(". Then ")#mi("{\\pi_1(M_1 \\cup M_2,p)}")#text(" is isomorphic to the ")#link("http://en.wikipedia.org/wiki/Free_product#Generalization:_Free_product_with_amalgamation")[#text("amalgamated free product")]#text(" ")#mi("{\\pi_1(M_1,p) *_{\\pi_1(M_1\\cap M_2,p)} \\pi_1(M_2,p)}")#text(".")
]

#text("Since the topological fundamental group is customarily defined using loops, it is not surprising that many proofs of van Kampen’s theorem (e.g. the one in ")#link("http://www.math.cornell.edu/~hatcher/AT/ATpage.html")[#text("Hatcher’s text")]#text(") proceed by an analysis of the loops in ")#mi("{M_1 \\cup M_2}")#text(", carefully deforming them into combinations of loops in ")#mi("{M_1}")#text(" or in ")#mi("{M_2}")#text(" and using the combinatorial description of the amalgamated free product (which was discussed in ")#link("https://terrytao.wordpress.com/2008/10/06/finite-subsets-of-groups-with-no-finite-models/")[#text("this previous blog post")]#text("). But I recently learned (thanks to the responses to ")#link("http://mathoverflow.net/questions/110511/an-etale-version-of-the-van-kampen-theorem")[#text("this recent MathOverflow question of mine")]#text(") that by using the above-mentioned equivalence of categories, one can convert statements about fundamental groups to statements about coverings. In particular, van Kampen’s theorem turns out to be equivalent to a basic statement about how to glue a cover of ")#mi("{M_1}")#text(" and a cover of ")#mi("{M_2}")#text(" together to give a cover of ")#mi("{M}")#text(", and the amalgamated free product emerges through its categorical definition as a ")#link("http://en.wikipedia.org/wiki/Coproduct")[#text("coproduct")]#text(", rather than through its combinatorial description. One advantage of this alternate proof is that it can be extended to other contexts (such as the ")#link("http://en.wikipedia.org/wiki/Etale_fundamental_group")[#text("étale fundamental groups")]#text(" of varieties or schemes) in which the concept of a path or loop is no longer useful, but for which the notion of a covering is still important. I am thus recording (mostly for my own benefit) the covering-based proof of van Kampen’s theorem in the topological setting below the fold.")

#metadata(none) <tao-4cc656097b43f825a109>

#heading(level: 1)[#strong[#text(" — 1. Proof of van Kampen theorem — ")]]

#text("The proof of van Kampen’s theorem boils down (after using the above-mentioned equivalence of categories between covers of a manifold ")#mi("{M}")#text(", and sets with an action of the fundamental group) to the following fact about covers:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Gluing of covers)")]#text(" ")#metadata(none) <tao-99552de9998a2b8267df>#text(" Let ")#mi("{M_1, M_2}")#text(" be connected open sets covering a connected topological manifold ")#mi("{M}")#text(" with ")#mi("{M_1 \\cap M_2}")#text(" also connected, and let ")#mi("{p}")#text(" be an element of ")#mi("{M_1 \\cap M_2}")#text(". If ")#mi("{\\phi_1: N_1 \\rightarrow M_1}")#text(" and ")#mi("{\\phi_2: N_2 \\rightarrow M_2}")#text(" are covering maps which become isomorphic upon restricting the base to ")#mi("{M_1 \\cap M_2}")#text(", then there is a covering map ")#mi("{\\phi: N \\rightarrow M}")#text(" which becomes isomorphic to ")#mi("{\\phi_1}")#text(" on restricting the base to ")#mi("{M_1}")#text(", and isomorphic to ")#mi("{\\phi_2}")#text(" on restricting the base to ")#mi("{M_2}")#text(" (and with all four isomorphisms forming a commuting square).")
]

#text("This proposition is easily verified by gluing together ")#mi("{N_1}")#text(" and ")#mi("{N_2}")#text(" as topological spaces along the indicated isomorphism between ")#mi("{\\phi_1^{-1}(M_1 \\cap M_2)}")#text(" and ")#mi("{\\phi_2^{-1}(M_1 \\cap M_2)}")#text(", and checking that the resulting space is still a covering space.")

#text("Now we can prove van Kampen’s theorem. Suppose that one has group homomorphisms ")#mi("{f_1: \\pi_1(M_1,p) \\rightarrow G}")#text(", ")#mi("{f_2: \\pi_1(M_2,p) \\rightarrow G}")#text(" to a target group ")#mi("{G}")#text(" which form a commuting square with the canonical homomorphisms from ")#mi("{\\pi_1(M_1 \\cap M_2,p)}")#text(" to ")#mi("{\\pi_1(M_1,p)}")#text(" and ")#mi("{\\pi_1(M_2,p)}")#text(". It will suffice to show that there is a unique homomorphism ")#mi("{f: \\pi_1(M,p) \\rightarrow G}")#text(" such that ")#mi("{f_i}")#text(" factors as the composition of ")#mi("{f}")#text(" with the canonical homomorphism from ")#mi("{\\pi_1(M_i,p)}")#text(" to ")#mi("{\\pi_1(M_1 \\cup M_2,p)}")#text(" for ")#mi("{i=1,2}")#text(".")

#text("We first demonstrate existence. Let ")#mi("{\\tilde \\phi_1: \\tilde M_1 \\rightarrow M_1}")#text(" be a universal cover for ")#mi("{M_1}")#text(", thus ")#mi("{\\tilde M_1}")#text(" is simply connected, and if we pick a base point ")#mi("{x_1 \\in \\tilde\\phi_1^{-1}(\\{p\\})}")#text(", then every other point ")#mi("{y}")#text(" in that fibre there is a unique element ")#mi("{g_1 \\in \\pi_1(M_1,p)}")#text(" for which ")#mi("{y = x_1 g}")#text(", where ")#mi("{x_1 g}")#text(" is the (right) action of ")#mi("{g}")#text(" by ")#link("http://en.wikipedia.org/wiki/Monodromy")[#text("monodromy")]#text(" on ")#mi("{x_1}")#text(". This gives a left action of ")#mi("{\\pi_1(M_1,p)}")#text(" on ")#mi("{M_1}")#text(" by ")#link("http://en.wikipedia.org/wiki/Deck_transformation#Deck_transformation")[#text("deck transformations")]#text(" ")#mi("{D_h: \\tilde M_1 \\rightarrow \\tilde M_1}")#text(" for each ")#mi("{h \\in \\pi_1(M_1,p)}")#text(", which maps ")#mi("{x_1 g}")#text(" to ")#mi("{x_1 hg}")#text(" for any ")#mi("{g \\in \\pi_1(M_1,p)}")#text(":")

#align(center)[#tao-fit-display[#mitex("D_h (x_1 g) = x_1 hg.")]]

#text("The fibres of the universal cover ")#mi("{\\tilde \\phi_1}")#text(" are copies of ")#mi("{\\pi_1(M_1,p)}")#text(". We can now form a new cover ")#mi("{\\phi_1: N_1 \\rightarrow M_1}")#text(" whose fibres are copies of ")#mi("{G}")#text(", by first forming the Cartesian product ")#mi("{G \\times \\tilde M_1}")#text(" (which still covers ")#mi("{M_1}")#text(") and then quotienting out by the equivalence ")#mi("{(g f_1(g_1), x) \\equiv (g, D_{g_1} x)}")#text(" for all ")#mi("{g \\in G}")#text(", ")#mi("{x \\in \\tilde M_1}")#text(", ")#mi("{h \\in \\pi_1(M_1,p)}")#text(". This is a (possibly disconnected) covering space for ")#mi("{M_1}")#text(", whose fibre above ")#mi("{p}")#text(" can be identified with ")#mi("{G}")#text(" by identifying ")#mi("{g \\in G}")#text(" with the equivalence class ")#mi("{[(g, x_1)]}")#text(". The monodromy (right) action of ")#mi("{\\pi_1(M_1,p)}")#text(" on this fibre is then identified with the right action of ")#mi("{\\pi_1(M_1,p)}")#text(" on ")#mi("{G}")#text(" induced by ")#mi("{f_1}")#text(". Furthermore, the group ")#mi("{G}")#text(" acts on ")#mi("{N_1}")#text(" on the left by deck transformations, with each ")#mi("{g \\in G}")#text(" mapping ")#mi("{[(g^{\\prime},x)]}")#text(" to ")#mi("{[(gg^{\\prime},x)]}")#text(".")

#text("Similarly, we can form a covering ")#mi("{\\phi_2: N_2 \\rightarrow M_2}")#text(" of ")#mi("{M_2}")#text(" whose monodromy action of ")#mi("{\\pi_1(M_2,p)}")#text(" on the fibre ")#mi("{\\phi_2^{-1}(\\{p\\})}")#text(" can be identified with the right action of ")#mi("{\\pi_1(M_2,p)}")#text(" on ")#mi("{G}")#text(" induced by ")#mi("{f_2}")#text(". When both of these covering spaces are restricted to ")#mi("{M_1 \\cap M_2}")#text(", the monodromy action of ")#mi("{\\pi_1(M_1 \\cap M_2,p)}")#text(" on the fibre above ")#mi("{p}")#text(" are then isomorphic to each other, and thus the two restrictions are isomorphic to each other too. By Proposition ")#link(<tao-99552de9998a2b8267df>)[#text("2")]#text(", we can then glue these two covers together to obtain a cover ")#mi("{\\phi: M \\rightarrow N}")#text(" which is isomorphic to ")#mi("{\\phi_1}")#text(" or ")#mi("{\\phi_2}")#text(" upon restricting the base to ")#mi("{M_1}")#text(" or ")#mi("{M_2}")#text(" respectively, with all four isomorphisms forming a commuting square; in particular, the fibre ")#mi("{\\phi^{-1}(\\{p\\})}")#text(" is still identified with ")#mi("{G}")#text(". The monodromy right action of ")#mi("{\\pi_1(M,p)}")#text(" on ")#mi("{\\phi^{-1}(\\{p\\})}")#text(" then restricts to the previously described action of ")#mi("{\\pi_1(M_1,p)}")#text(" on ")#mi("{G}")#text(" and of ")#mi("{\\pi_1(M_2,p)}")#text(" on ")#mi("{G}")#text(". Also, because ")#mi("{G}")#text(" acted on the left by deck transformations on both ")#mi("{N_1}")#text(" and ")#mi("{N_2}")#text(", in a manner which can be seen to be compatible with the isomorphism on restriction to ")#mi("{M_1 \\cap M_2}")#text(", ")#mi("{G}")#text(" continues to act by deck transformations on the gluid cover ")#mi("{N}")#text(". As monodromy actions commute with deck transformations, we conclude that the right action of an element ")#mi("{g}")#text(" of ")#mi("{\\pi_1(M,p)}")#text(" on ")#mi("{G}")#text(" is given by right multiplication by an element ")#mi("{f(g)}")#text(" of ")#mi("{G}")#text(". It is then routine to verify that ")#mi("{f}")#text(" is a homomorphism with the required properties.")

#text("Now we prove uniqueness. It suffices to show that ")#mi("{\\pi_1(M,p)}")#text(" is generated as a group by the images of ")#mi("{\\pi_1(M_1,p)}")#text(" and ")#mi("{\\pi_1(M_2,p)}")#text(". Suppose this were not the case, so that the images of ")#mi("{\\pi_1(M_1,p)}")#text(" and ")#mi("{\\pi_1(M_2,p)}")#text(" generate a proper subgroup ")#mi("{G}")#text(" of ")#mi("{\\pi_1(M,p)}")#text(". Let ")#mi("{\\tilde \\phi: \\tilde M \\rightarrow M}")#text(" be a universal cover of ")#mi("{M}")#text(", so that the fibre ")#mi("{\\tilde \\phi^{-1}(\\{p\\})}")#text(" may be identified with ")#mi("{\\pi_1(M,p)}")#text(" (after fixing a reference point in that fibre as before). Let ")#mi("{\\tilde M_1}")#text(" be the restriction of ")#mi("{\\tilde M}")#text(" to ")#mi("{M_1}")#text(". The monodromy (right) action of ")#mi("{\\pi_1(M_1,p)}")#text(" on the fibre above ")#mi("{p}")#text(" is induced by the canonical homomorphism from ")#mi("{\\pi_1(M_1,p)}")#text(" to ")#mi("{\\pi_1(M,p)}")#text(". In particular, ")#mi("{G}")#text(" is preserved by this action, and so one can find a proper subcover ")#mi("{N_1}")#text(" of ")#mi("{\\tilde M_1}")#text(" whose fibre corresponds to ")#mi("{G}")#text(". Similarly, we can find a proper subcover ")#mi("{N_2}")#text(" of the restriction ")#mi("{\\tilde M_2}")#text(" of ")#mi("{\\tilde M}")#text(" to ")#mi("{M_2}")#text(" with the same fibre. By Proposition ")#link(<tao-99552de9998a2b8267df>)[#text("2")]#text(", we may glue these two covers together to obtain a proper subcover ")#mi("{N}")#text(" of ")#mi("{\\tilde M}")#text(". But such a proper subcover cannot exist because ")#mi("{\\tilde M}")#text(" is connected, and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The arguments above relied heavily on the universal cover and its attendant deck transformations and monodromy actions, mostly in order to give a concrete equivalence between coverings of ")#mi("{M}")#text(" and discrete sets with actions of the fundamental group ")#mi("{\\pi_1(M,p)}")#text(". It is also possible to proceed without constructing this cover, working instead with a directed family of Galois covers as a substitute for the universal cover to obtain this ")#link("http://en.wikipedia.org/wiki/Equivalence_of_categories")[#text("equivalence of categories")]#text("; this is the approach in ")#link("http://en.wikipedia.org/wiki/Grothendieck%27s_Galois_theory")[#text("Grothendieck’s Galois theory")]#text(", which among other things can be used to construct the ")#link("http://en.wikipedia.org/wiki/Etale_fundamental_group")[#text("étale fundamental group")]#text(", as this is a context in which universal covers need not exist, but one still has plenty of Galois covers. See for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=2548205")[#text("Szamuely’s text")]#text(" for more details.")
]

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chorasimilarity")]], [#link("https://terrytao.wordpress.com/2012/10/28/van-kampens-theorem-via-covering-spaces/#comment-186981")[#strong[#text("chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2012")])]

#text("Have you seen the book ")#link("http://pages.bangor.ac.uk/~mas010/topgpds.html")[#text("Topology and Groupoids")]#text(" by ")#link("http://pages.bangor.ac.uk/~mas010/")[#text("Ronald Brown")]#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2716a10479f679370c8d043cafe98877fcd5b0dea56beea10f5140e323d5c793-1aeebf232c15b849abeb42c53a962cab31f34b30140baf07deed52bc25841e28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JuanPi")]], [#link("https://terrytao.wordpress.com/2012/10/28/van-kampens-theorem-via-covering-spaces/#comment-186982")[#strong[#text("JuanPi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2012")])]

#text("“such as locally path connected spaces, … to avoid path-ologies.”")#linebreak()#text(" That’s a funny one!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7155eb310475c3569346a19a68401df1743a9e73b405568dff18a6714c472660-33311cce7a1b211eebe6667f586b94d4f26e9c90dcc933aa3b616912ba58b757.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rodolfo Niborski")]], [#link("https://terrytao.wordpress.com/2012/10/28/van-kampens-theorem-via-covering-spaces/#comment-187010")[#strong[#text("Rodolfo Niborski")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2012")])]

#text("In the first sentence, did you mean to say “with two loops considered equivalent to each other if they are homotopic” ? ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Approximate groupoids may be useful « chorasimilarity")]], [#link("https://terrytao.wordpress.com/2012/10/28/van-kampens-theorem-via-covering-spaces/#comment-187015")[#strong[#text("Approximate groupoids may be useful « chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2012")])]

#text("[…] by way of groupoids, of the Van Kampen theorem on the fundamental group of a union of spaces, Terence Tao has a post about this subject. I wonder if he is after some applications of his results on approximate groups in the realm of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/063b675704132fba480f5d8523d45eaa6dc1a29606f3921d71f5ba0b6df3a79b-85ac7e85c91e2494dd2382e5ffdaa6d08684f7e06205f699a9f94f45d85b434f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan Reich")]], [#link("https://terrytao.wordpress.com/2012/10/28/van-kampens-theorem-via-covering-spaces/#comment-187111")[#strong[#text("Ryan Reich")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2012")])]

#text("I enjoyed this presentation! Your argument has the following conceptual summary (which I do not intend as a criticism, but just a road map):")#linebreak()#text(" 1. Given the universal cover of M, a map ")#mi("\\pi_1(M) \\to G")#text(" is the same as a covering space of M that is a principal G-bundle (with G considered as a discrete group).")#linebreak()#text(" 2. (Proposition 2) The pushout of two covering spaces over an open covering of M is a covering space of M, and if they are both principal G-bundles, then so is the pushout.")#linebreak()#text(" 3. The restriction of a $G$-bundle to an open subspace U of M corresponds to the restriction of ")#mi("\\pi_1(M) \\to G")#text(" to ")#mi("\\pi_1(U)")#text(".")#linebreak()#text(" The proof is then: by Point 1 we can do the construction entirely with G-bundles; by Point 2 we can create the map to G, which by Point 3 has the desired restriction properties and is unique because pushouts are unique.")

#text("This is, I guess, the Grothendieck-Galois-theoretic proof of the theorem. I think you could summarize even further by using the word “stack”, but I won’t :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/10/28/van-kampens-theorem-via-covering-spaces/#comment-188492")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2012")])]

#text("I think the proof in the book of Douady (Theories Galoisiennes) is slightly smoother because it is 98% categorical (in fact there is a topos version due to Ronnie Brown and company). Their proof is roughly like this. If one has a pushout diagram of groups G,H,K where K has maps into G,H respectively, then by the universal property for the pushout, call it A, an A-set is the same thing as a G-set X, an H-set Y and a K-set isomorphism between these. The gluing argument above then implies the category if pi_1(M)-sets is equivalent to the category of A-sets for the pushout A of the fundamental groups via the natural maps. It is an easy exercise in category theory to deduce that a group homomorphism which induces an equivalence of action categories is an isomorphism.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Expanding polynomials over finite fields of large characteristic, and a regularity lemma for definable sets « What’s new")]], [#link("https://terrytao.wordpress.com/2012/10/28/van-kampens-theorem-via-covering-spaces/#comment-192676")[#strong[#text("Expanding polynomials over finite fields of large characteristic, and a regularity lemma for definable sets « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2012")])]

#text("[…] an étale version of the van Kampen theorem for the fundamental group, which I discussed in this previous blog post. With this fact (and another, rather deep fact, about the étale fundamental group in zero […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3572314ef8354eeb8d4b6acf7f90768856e6ba3c71e51e97f804aa0cd1cc60bf-8c0ee2a928a6a075cc39082074e13516da43fc42ea53d61247e04c201fb0452c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pablocecil")]], [#link("https://terrytao.wordpress.com/2012/10/28/van-kampens-theorem-via-covering-spaces/#comment-194553")[#strong[#text("pablocecil")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2012")])]

#text("In his book Algebraic Topology. A First Course, Bill Fulton attributes this proof to Grothedieck.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae8694af88c9a2be82908d939b142aa32e281d7c015e5005efb82b5639fbc74f-4d7aed741d719062aba62ef4c88e5ccdd4be1b5752daaab58815a95f3fcde7c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brydustin")]], [#link("https://terrytao.wordpress.com/2012/10/28/van-kampens-theorem-via-covering-spaces/#comment-457792")[#strong[#text("brydustin")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2015")])]

#text("In van Kampen’s theorem, the intersection is assumed to be connected…. shouldn’t it be assumed to be simply connected?")

#emph[#text("[van Kampen’s theorem can handle the situation in which the intersection is not simply connected (the free product becomes an amalgamated free product over the fundamental group of the intersection. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/10/28/van-kampens-theorem-via-covering-spaces/#comment-507679")[#strong[#text("Week 9 - Introduction to Topology")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2018")]

#text("[…] alternative derivation of the Seifert-van Kampen Theorem is sketched in Terence Tao’s blog. The derivation is based on covering […]")
]
