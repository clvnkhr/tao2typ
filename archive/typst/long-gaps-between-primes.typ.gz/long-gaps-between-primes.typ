// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/
// Converted to Typst by tao2typ: "2026-10-14T10:22:58.830530+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Long gaps between primes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Long gaps between primes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 December 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/")[#text("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.uiuc.edu/~ford/")[#text("Kevin Ford")]#text(", ")#link("http://people.maths.ox.ac.uk/greenbj/")[#text("Ben Green")]#text(", ")#link("http://mech.math.msu.su/~kon/kon1.htm")[#text("Sergei Konyagin")]#text(", ")#link("http://www.magd.ox.ac.uk/member-of-staff/james-maynard/")[#text("James Maynard")]#text(", and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/1412.5029")[#text("Long gaps between primes")]#text("“. This is a followup work to our ")#link("http://arxiv.org/abs/1408.5110")[#text("two")]#text(" ")#link("http://arxiv.org/abs/1408.4505")[#text("previous papers")]#text(" (discussed in ")#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/")[#text("this previous post")]#text("), in which we had simultaneously shown that the maximal gap")

#align(center)[#tao-fit-display[#mitex("G(X) := \\sup_{p_n, p_{n+1} \\leq X} p_{n+1}-p_n")]]

#text("between primes up to ")#mi("{X}")#text(" exhibited a lower bound of the shape ")#metadata(none) <tao-0dd654989d6ccf1eb083>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("G(X) \\geq f(X) \\log X \\frac{\\log \\log X \\log\\log\\log\\log X}{(\\log\\log\\log X)^2}")]]

#text("for some function ")#mi("{f(X)}")#text(" that went to infinity as ")#mi("{X \\rightarrow \\infty}")#text("; this improved upon previous work of Rankin and other authors, who established the same bound but with ")#mi("{f(X)}")#text(" replaced by a constant. (Again, see ")#link("https://terrytao.wordpress.com/2014/08/21/large-gaps-between-consecutive-prime-numbers/")[#text("the previous post")]#text(" for a more detailed discussion.)")

#text("In our previous papers, we did not specify a particular growth rate for ")#mi("{f(X)}")#text(". In ")#link("http://arxiv.org/abs/1408.4505")[#text("my paper with Kevin, Ben, and Sergei")]#text(", there was a good reason for this: our argument relied (amongst other things) on the inverse conjecture on the Gowers norms, as well as the Siegel-Walfisz theorem, and the known proofs of both results both have ineffective constants, rendering our growth function ")#mi("{f(X)}")#text(" similarly ineffective. ")#link("http://arxiv.org/abs/1408.5110")[#text("Maynard’s approach")]#text(" ostensibly also relies on the Siegel-Walfisz theorem, but (as shown in ")#link("http://arxiv.org/abs/1405.2593")[#text("another recent paper of his")]#text(") can be made quite effective, even when tracking ")#mi("{k}")#text("-tuples of fairly large size (about ")#mi("{\\log^c x}")#text(" for some small ")#mi("{c}")#text("). If one carefully makes all the bounds in Maynard’s argument quantitative, one eventually ends up with a growth rate ")#mi("{f(X)}")#text(" of shape ")#metadata(none) <tao-4af4e217c06a9b00b977>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("f(X) \\asymp \\frac{\\log \\log \\log X}{\\log\\log\\log\\log X},")]]

#text("thus leading to a bound")

#align(center)[#tao-fit-display[#mitex("G(X) \\gg \\log X \\frac{\\log \\log X}{\\log\\log\\log X}")]]

#text("on the gaps between primes for large ")#mi("{X}")#text("; this is an unpublished calculation of James’.")

#text("In this paper we make a further refinement of this calculation to obtain a growth rate ")#metadata(none) <tao-adca5146416ee41992ac>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("f(X) \\asymp \\log \\log \\log X")]]

#text("leading to a bound of the form ")#metadata(none) <tao-c6f556046e0c00469fe2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("G(X) \\geq c \\log X \\frac{\\log \\log X \\log\\log\\log\\log X}{\\log\\log\\log X}")]]

#text("for large ")#mi("{X}")#text(" and some small constant ")#mi("{c}")#text(". Furthermore, this appears to be the limit of current technology (in particular, falling short of ")#link("http://en.wikipedia.org/wiki/Cram%C3%A9r%27s_conjecture")[#text("Cramer’s conjecture")]#text(" that ")#mi("{G(X)}")#text(" is comparable to ")#mi("{\\log^2 X}")#text("); in the spirit of ")#link("http://books.google.com/books?id=tmORL-UYOyEC&pg=PA467&lpg=PA467#v=onepage&q&f=false")[#text("Erdös’ original prize")]#text(" on this problem, I would like to offer 10,000 USD for anyone who can show (in a refereed publication, of course) that the constant ")#mi("{c}")#text(" here can be replaced by an arbitrarily large constant ")#mi("{C}")#text(".")

#text("The reason for the growth rate ")#link(<tao-adca5146416ee41992ac>)[#text("(3)")]#text(" is as follows. After following the sieving process discussed in the previous post, the problem comes down to something like the following: can one sieve out all (or almost all) of the primes in ")#mi("{[x,y]}")#text(" by removing one residue class modulo ")#mi("{p}")#text(" for all primes ")#mi("{p}")#text(" in (say) ")#mi("{[x/4,x/2]}")#text("? Very roughly speaking, if one can solve this problem with ")#mi("{y = g(x) x}")#text(", then one can obtain a growth rate on ")#mi("{f(X)}")#text(" of the shape ")#mi("{f(X) \\sim g(\\log X)}")#text(". (This is an oversimplification, as one actually has to sieve out a random subset of the primes, rather than all the primes in ")#mi("{[x,y]}")#text(", but never mind this detail for now.)")

#text("Using the quantitative “")#link("http://arxiv.org/abs/1405.2593")[#text("dense clusters of primes")]#text("” machinery of Maynard, one can find lots of ")#mi("{k}")#text("-tuples in ")#mi("{[x,y]}")#text(" which contain at least ")#mi("{\\gg \\log k}")#text(" primes, for ")#mi("{k}")#text(" as large as ")#mi("{\\log^c x}")#text(" or so (so that ")#mi("{\\log k}")#text(" is about ")#mi("{\\log\\log x}")#text("). By considering ")#mi("{k}")#text("-tuples in arithmetic progression, this means that one can find lots of residue classes modulo a given prime ")#mi("{p}")#text(" in ")#mi("{[x/4,x/2]}")#text(" that capture about ")#mi("{\\log\\log x}")#text(" primes. In principle, this means that union of all these residue classes can cover about ")#mi("{\\frac{x}{\\log x} \\log\\log x}")#text(" primes, allowing one to take ")#mi("{g(x)}")#text(" as large as ")#mi("{\\log\\log x}")#text(", which corresponds to ")#link(<tao-adca5146416ee41992ac>)[#text("(3)")]#text(". However, there is a catch: the residue classes for different primes ")#mi("{p}")#text(" may collide with each other, reducing the efficiency of the covering. In our previous papers on the subject, we selected the residue classes randomly, which meant that we had to insert an additional logarithmic safety margin in expected number of times each prime would be shifted out by one of the residue classes, in order to guarantee that we would (with high probability) sift out most of the primes. This additional safety margin is ultimately responsible for the ")#mi("{\\log\\log\\log\\log X}")#text(" loss in ")#link(<tao-4af4e217c06a9b00b977>)[#text("(2)")]#text(".")

#text("The main innovation of this paper, beyond detailing James’ unpublished calculations, is to use ideas from the literature on efficient hypergraph covering, to avoid the need for a logarithmic safety margin. The hypergraph covering problem, roughly speaking, is to try to cover a set of ")#mi("{n}")#text(" vertices using as few “edges” from a given hypergraph ")#mi("{H}")#text(" as possible. If each edge has ")#mi("{m}")#text(" vertices, then one certainly needs at least ")#mi("{n/m}")#text(" edges to cover all the vertices, and the question is to see if one can come close to attaining this bound given some reasonable uniform distribution hypotheses on the hypergraph ")#mi("{H}")#text(". As before, random methods tend to require something like ")#mi("{\\frac{n}{m} \\log r}")#text(" edges before one expects to cover, say ")#mi("{1-1/r}")#text(" of the vertices.")

#text("However, it turns out (under reasonable hypotheses on ")#mi("{H}")#text(") to eliminate this logarithmic loss, by using what is now known as the “semi-random method” or the “Rödl nibble”. The idea is to randomly select a small number of edges (a first “nibble”) – small enough that the edges are unlikely to overlap much with each other, thus obtaining maximal efficiency. Then, one pauses to remove all the edges from ")#mi("{H}")#text(" that intersect edges from this first nibble, so that all remaining edges will not overlap with the existing edges. One then randomly selects another small number of edges (a second “nibble”), and repeats this process until enough nibbles are taken to cover most of the vertices. Remarkably, it turns out that under some reasonable assumptions on the hypergraph ")#mi("{H}")#text(", one can maintain control on the uniform distribution of the edges throughout the nibbling process, and obtain an efficient hypergraph covering. This strategy was carried out in detail in an influential ")#link("http://www.ams.org/mathscinet-getitem?mr=993646")[#text("paper of Pippenger and Spencer")]#text(".")

#text("In our setup, the vertices are the primes in ")#mi("{[x,y]}")#text(", and the edges are the intersection of the primes with various residue classes. (Technically, we have to work with a family of hypergraphs indexed by a prime ")#mi("{p}")#text(", rather than a single hypergraph, but let me ignore this minor technical detail.) The semi-random method would ")#emph[#text("in principle")]#text(" eliminate the logarithmic loss and recover the bound ")#link(<tao-adca5146416ee41992ac>)[#text("(3)")]#text(". However, there is a catch: the analysis of Pippenger and Spencer relies heavily on the assumption that the hypergraph is uniform, that is to say all edges have the same size. In our context, this requirement would mean that each residue class captures exactly the same number of primes, which is not the case; we only control the number of primes in an average sense, but we were unable to obtain any concentration of measure to come close to verifying this hypothesis. And indeed, the semi-random method, when applied naively, does not work well with edges of variable size – the problem is that edges of large size are much more likely to be eliminated after each nibble than edges of small size, since they have many more vertices that could overlap with the previous nibbles. Since the large edges are clearly the more useful ones for the covering problem than small ones, this bias towards eliminating large edges significantly reduces the efficiency of the semi-random method (and also greatly complicates the ")#emph[#text("analysis")]#text(" of that method).")

#text("Our solution to this is to iteratively ")#emph[#text("reweight")]#text(" the probability distribution on edges after each nibble to compensate for this bias effect, giving larger edges a greater weight than smaller edges. It turns out that there is a natural way to do this reweighting that allows one to repeat the Pippenger-Spencer analysis in the presence of edges of variable size, and this ultimately allows us to recover the full growth rate ")#link(<tao-adca5146416ee41992ac>)[#text("(3)")]#text(".")

#text("To go beyond ")#link(<tao-adca5146416ee41992ac>)[#text("(3)")]#text(", one either has to find a lot of residue classes that can capture significantly more than ")#mi("{\\log\\log x}")#text(" primes of size ")#mi("{x}")#text(" (which is the limit of the multidimensional Selberg sieve of Maynard and myself), or else one has to find a very different method to produce large gaps between primes than the Erdös-Rankin method, which is the method used in all previous work on the subject.")

#text("It turns out that the arguments in this paper can be combined with the ")#link("http://en.wikipedia.org/wiki/Maier%27s_matrix_method")[#text("Maier matrix method")]#text(" to also produce chains of consecutive large prime gaps whose size is of the order of ")#link(<tao-c6f556046e0c00469fe2>)[#text("(4)")]#text("; three of us (Kevin, James, and myself) will detail this in a future paper. (A similar combination was also recently observed in connection with our earlier result ")#link(<tao-0dd654989d6ccf1eb083>)[#text("(1)")]#text(" ")#link("http://arxiv.org/abs/1407.2213")[#text("by Pintz")]#text(", but there are some additional technical wrinkles required to recover the full gain of ")#link(<tao-adca5146416ee41992ac>)[#text("(3)")]#text(" for the chains of large gaps problem.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (31)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ac08578e0edfc897ba8259f941762c2c4419cb63fb57bafed3975794bd8573a-78dfc549694bf79c3787425760bffa7b7a0389839d3af0e3c06010309348dcf7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of samuelfhopkins")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-445341")[#strong[#text("samuelfhopkins")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2014")])]

#text("Do you think the non-uniform hypergraph packing developed in your paper could be applied to this question?: ")#link("http://mathoverflow.net/questions/121961/is-there-a-n-2-version-of-the-erd%C5%91s-hanani-conjecture")[#text("http://mathoverflow.net/questions/121961/is-there-a-n-2-version-of-the-erd%C5%91s-hanani-conjecture")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-445347")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2014")])]

#text("Hmm. One could try simply applying our covering theorem off-the-shelf (Corollary 1 from our paper), but it looks like the hypergraph here is already uniform, so our theorem won’t add much power beyond what existing tools give; we do allow the edges to grow somewhat in size, but perhaps not as fast as in that application. But one would have to compute all the parameters carefully to see for certain whether our version of the theorem gets any further than previous ones with regards to what values of k and t it can handle. (We also didn’t try very hard to optimise the bound on codegree needed, since in our application the codegree ends up being very small.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-445368")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2014")])]

#text("Is the constant c in (4) effective?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-445405")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2014")])]

#text("Yes, we manage to avoid the use of the (ineffective) Siegel-Walfisz theorem by deleting an exceptional prime from the multidimensional Selberg sieve, leading to an effective (but quite small) value of c.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0c966f83956f88e0ae0569a5a0b03c90ac4da8d83a15599ca142d3f1d3503e6-6da5889455160fc1a4651d11d6dc54150c1eee35c9adbd8ae366b68451ab2690.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of goingtoinfinity")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-513506")[#strong[#text("goingtoinfinity")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2019")])]

#text("is it feasible to calculate the actual numerical value of c?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-445384")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2014")])]

#text("Let ")#mi("m(k)")#text(" be the largest ")#mi("m")#text(" for which DHL[k, m+1] holds. What should be the bound in (4) in terms of the function ")#mi("m(k)")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-445406")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2014")])]

#text("It depends on how large one can make ")#mi("k")#text(" in terms of the order of magnitude ")#mi("x")#text(" of the primes being considered (and in the Erdos-Rankin method, x is of the order of ")#mi("\\log X")#text("). Roughly speaking, the quantity ")#mi("f(X)")#text(" in (1) is then the largest one can make ")#mi("m")#text(". With current technology, ")#mi("k")#text(" can be as large as ")#mi("\\log^c x")#text(" and ")#mi("m")#text(" as large as ")#mi("\\log k")#text(", which is why we can make ")#mi("f(X)")#text(" as large as ")#mi("\\log\\log\\log X")#text(". (In our previous papers we took ")#mi("k")#text(" to be a large constant independent of ")#mi("x")#text(", but this will not create a ")#mi("f(X)")#text(" that grows with ")#mi("x")#text(".)")

#text("If one assumes a sufficiently strong version of the prime tuples conjecture, then one could conceivably take ")#mi("m")#text(" as large as ")#mi("k")#text(", in which case ")#mi("f(X)")#text(" becomes ")#mi("\\log\\log X")#text(". This is likely to be the limit of the Erdos-Rankin method (from probabilistic heuristics, one should not expect ")#mi("k")#text(" to ever get larger than ")#mi("\\log x")#text(" if one is to capture ")#mi("\\sim k")#text(" primes of size ")#mi("x")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-445430")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2014")])]

#text("Hence ")#mi("m >>\\log^2 k")#text(" should imply (4) without the denominator.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-445432")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2014")])]

#text("Some tangentially relevant question: Can you claim Erdos’ prize now? And do you put a time limit on the prize you offer?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2108f61ac4b72751222a3ca4c0a3c94cdf7a7a4533ade03a483f2f0830a83f54-736b5d7e61507ab6e071a037b6570fba88784f8f0294a1aa67d272ccd9f87cbb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Pratt")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-445553")[#strong[#text("Kyle Pratt")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2014")])]

#text("Very nice work.")

#text("The lower bound on G(X) after (2) is not what you meant to say. As written, this is the result of Westzynthius, not the improved result of Maynard.")

#emph[#text("[I think it’s correct as stated; the Westzynthius bound has an additional logarithm in both the numerator and denominator. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2108f61ac4b72751222a3ca4c0a3c94cdf7a7a4533ade03a483f2f0830a83f54-736b5d7e61507ab6e071a037b6570fba88784f8f0294a1aa67d272ccd9f87cbb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Pratt")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-445717")[#strong[#text("Kyle Pratt")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2014")])]

#text("Ah yes, thanks.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-445857")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2014")])]

#text("A natural generalization (analogous to ")#mi("H_m")#text(" definition) of the maximal prime gap function ")#mi("G(X)")#text(" to cluster of ")#mi("m")#text(" consecutive prime gaps seems to be")#linebreak()#text(" ")#mi("G_m(X) := \\max_{p_{n+m} \\leq X} (p_{n+m} - p_n)")

#text("Clearly, ")#mi("G_m(X)")#text(" is subadditive in ")#mi("m")#text(", in particular")#linebreak()#text(" ")#mi("G_m(X) \\leq m G(X)")#text(" for ")#mi("m = 1, 2, 3, ...")#linebreak()#text(" It seems that this upper bound is quite good.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-445872")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2014")])]

#text("In fact, the bound ")#mi("G_m(X) /G(x) \\leq m")#text(" is not necessarily good for large ")#mi("m")#text(". It is possible that ")#mi("\\liminf_X G_m(X)/G(X)")#text(" and ")#mi("\\limsup_X G_m(X)/G(X)")#text(" (which are in ")#mi("[1, m]")#text(") can be both unbounded and ")#mi("o(m)")#text(" as ")#mi("m \\rightarrow \\infty")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/744af6de8cc8d5fa42cf0dbd096e88eef82f4b51081b78514bff85bf909eab07-d4d0b110ce3d5330716c189c6d455c2cd768a34ab962b2a8c3755b79505fb788.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gerhard Paseman")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-446294")[#strong[#text("Gerhard Paseman")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2014")])]

#text("There are some typos and areas for small improvements in clarity and exposition (e.g. “that are all either at least log 20 x .”). Would you like me to send the corrections and suggestions to you in bulk via email, or would you prefer them piecemeal here as comments?")

#emph[#text("[Either is fine – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/744af6de8cc8d5fa42cf0dbd096e88eef82f4b51081b78514bff85bf909eab07-d4d0b110ce3d5330716c189c6d455c2cd768a34ab962b2a8c3755b79505fb788.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gerhard Paseman")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-446568")[#strong[#text("Gerhard Paseman")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2014")])]

#text("Ok. In your section 1, isn’t Y(x) just j(P(x))-1 [ or h(x) – 1, to alter notation from Hagedorn’s 2009, or even L(P(x)), using Jacobsthal’s L(x) from his 1960 paper] ? I may have got Y(x) wrong, but if not, I see some of the paragraphs in that section that could be made more clear. Also, in defining a arrow right after (3.5), I think you want a script S for the index set, not the plain S in “s \\in S”.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d57d55e60f821c1d05e39e34c9f7770b30a9a51ebc94969c5c6db5cd7bae3144-2d1d60be21e3bf6a907ac9aa471919572194be3ccb33d6dbea29fe5343b9132d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hiklicepleh")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-448437")[#strong[#text("hiklicepleh")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2015")])]

#text("Using the result Schoenfeld, assuming the Riemann hypothesis, we can choose the best result for p_n. It turns recursion.")

#text("|pi(n) – Li(n)| < 1/(8*pi)(n^1/2)logn – ")#link("http://en.wikipedia.org/wiki/Riemann_hypothesis#Distribution_of_prime_numbers")[#text("http://en.wikipedia.org/wiki/Riemann_hypothesis#Distribution_of_prime_numbers")]

#text("Take n=p_n. |n – Li(p_n)| < 1/(8*pi)(p_n^1/2)log(p_n)")

#text("Now we can choose the best result for p_n. (maybe)")

#text("For example take p_n=cnlogn(loglognloglogloglogn/logloglogn). Could this somehow help?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chains of large gaps between primes | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-461963")[#strong[#text("Chains of large gaps between primes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2015")])]

#text("[…] our preprint “Chains of large gaps between primes“. This paper was announced in our previous paper with Konyagin and Green, which was concerned with the largest […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-465931")[#strong[#text("Mathematics: It’s About the Future | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2016")]

#text("[…] to the Future II” also came closer. For best result of 2014 we nominate discoveries by Tao and others about gaps between […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1f4d23e13312dfddbb50fea9283c09b96ba78aef7aa7578b889cbdd2f9dd60f-029ffd63045431468f4d5099f159e6d1c06ca48357999ee785e74f090febfcd4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jaime Maldonado")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-468999")[#strong[#text("Jaime Maldonado")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2016")])]

#text("That wants the gap size? … The voids or gaps between two prime numbers can not be determined, in fact, are as large as the largest prime number known to date, but still, this big hole is repeated indefinitely as you all gap you can find up to this prime number. If tomorrow is a much higher prime number, say a million million digits then there is a gap of that size and many of twice that size … and so …. I can prove it. A gap double in size depends on two numbers in the middle of two consecutive gap of the same size that can be twins or one cousin cousins ​​and not the other or both compounds, in this case the gap doubles.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eba78b9309025b46ae9af737374d44e6ca10a6218387ce2923c97a033a6971e-5a7c703fdb52f5e3069f4ca2710a6352efe8edf6129cdedaf4d9c9dcfc6841d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stefan Kohl")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-483111")[#strong[#text("Stefan Kohl")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2017")])]

#text("I’d just like to point out that ‘refereed publication’ alone is a pretty weak requirement when offering a prize. — That something got refereed is as such not necessarily a sign of quality, even not if it is published in a journal indexed by zbMATH — cf. e.g. ")#link("https://zbmath.org/?q=an:1360.81259")[#text("https://zbmath.org/?q=an:1360.81259")]#text(", ")#link("https://zbmath.org/?q=an:06699962")[#text("https://zbmath.org/?q=an:06699962")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Long gaps in sieved set | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-492900")[#strong[#text("Long gaps in sieved set | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2018")])]

#text("[…] around variants of the question of finding large gaps between primes. As discussed for instance in this previous post, it is now known that within the set of primes , one can find infinitely adjacent elements whose […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e00078a8c46fa0e0e324652e18fc56f727ea3c48adcce65393ab3108b85c3e6b-742020c8dab9b2728a436d1a6771b778dd726785efdc45f0a586565a48c3e7c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LAGRIDA")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-509390")[#strong[#text("LAGRIDA")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("I write an article about prime numbers construction where i give the reason of irregularty of primes,")#linebreak()#text(" the complete article : ")#link("http://lagrida.com/prime_numbers_construction.html")[#text("http://lagrida.com/prime_numbers_construction.html")]#linebreak()#text(" For ")#mi("p,q \\in \\mathbb{P}")#text(" with q is the next prime of p, consider the set ")#mi("\\mathcal{B}_q = \\{a \\in \\mathbb{N}^{*} \\text{ and } a \\text{ coprime to } \\displaystyle{\\small \\left( \\prod_{\\substack{a \\leq q \\\\ \\text{a prime}}} {\\normalsize a} \\right)} and a \\leq \\displaystyle{\\small \\left( \\prod_{\\substack{a \\leq q \\\\ \\text{a prime}}} {\\normalsize a} \\right)} \\}")

#text("it’s clear that :")#linebreak()#text(" ")#mi("\\# \\mathcal{B}_q = {\\small \\prod_{\\substack{a \\leq q \\\\ \\text{a prime}}} {\\normalsize (a-1)}}")

#text("In my article, i proove :")

#text("For ")#mi("q \\geq 3")#text(" :")

#mi("\\#\\{(b,b+2) \\in \\mathcal{B}_q^2\\} = \\displaystyle{\\small \\left( \\prod_{\\substack{3 \\leq a \\leq q \\\\ \\text{a prime}}} {\\normalsize (a-2)} \\right)} - 1")

#text("For ")#mi("q \\geq 3")#text(" :")

#mi("\\#\\{(b,b+4) \\in \\mathcal{B}_q^2 \\} = \\displaystyle{\\small \\left( \\prod_{\\substack{3 \\leq a \\leq q \\\\ \\text{a prime}}} {\\normalsize (a-2)} \\right)}")

#text("For ")#mi("q \\geq 5")#text(" :")

#mi("\\#\\{(b,b+6) \\in \\mathcal{B}_q^2\\} = 2 \\text{ if } q = 5")#text(" if ")#mi("q = 5")

#text("And if ")#mi("q \\geq 7")#text(", and b denote the next prime to prime number b’, then :")

#mi("\\#\\{(b,b+6) \\in \\mathcal{B}_q^2\\} = 2 \\displaystyle\\left( {\\small \\left( \\prod_{\\substack{7 \\leq a \\leq q \\\\ \\text{a prime}}} {\\normalsize (a-2)} \\right)} + {\\small \\left( \\prod_{\\substack{5 \\leq a \\leq p \\\\ \\text{a prime}}} {\\normalsize (a-3)} \\right)} + \\sum_{\\substack{5 \\leq b^{\\prime} < p \\\\ \\text{b' prime}}} {\\small \\left( \\prod_{\\substack{5 \\leq a \\leq b^{\\prime} \\\\ \\text{a prime}}} {\\normalsize (a-3)} \\right)} {\\small \\left( \\prod_{\\substack{b < a \\leq q \\\\ \\text{a prime}}} {\\normalsize (a-2)} \\right)} \\right)")

#text("For ")#mi("q \\geq 5")#text(" :")

#mi("\\#\\{(b,b+2,b+6,b+8) \\in \\mathcal{B}_q^4 \\} = \\displaystyle{\\small \\left( \\prod_{\\substack{3 \\leq a \\leq q \\\\ \\text{a prime}}} {\\normalsize (a-4)} \\right)}")

#text("And following the same proofs we can calculate the number of elements in ")#mi("\\mathcal{B}_q")#text("$ with gaps ")#mi("8, 10, \\cdots")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e00078a8c46fa0e0e324652e18fc56f727ea3c48adcce65393ab3108b85c3e6b-742020c8dab9b2728a436d1a6771b778dd726785efdc45f0a586565a48c3e7c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LAGRIDA")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-509391")[#strong[#text("LAGRIDA")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("There is a Latex error, i will rewrite the formule of ")#mi("\\# \\{(b,b+6) \\in \\mathcal{B}_q^2 \\}")#text(" :")#linebreak()#text(" ")#mi("\\#\\{(b,b+6) \\in \\mathcal{B}_q^2\\} = 2 \\displaystyle\\left( {\\small \\left( \\prod_{\\substack{7 \\leq a \\leq q \\\\ \\text{a prime}}} {\\normalsize (a-2)} \\right)} + {\\small \\left( \\prod_{\\substack{5 \\leq a \\leq p \\\\ \\text{a prime}}} {\\normalsize (a-3)} \\right)} + \\sum_{\\substack{5 \\leq b^{\\prime} < p \\\\ \\text{b' prime}}} {\\small \\left( \\prod_{\\substack{5 \\leq a \\leq b^{\\prime} \\\\ \\text{a prime}}} {\\normalsize (a-3)} \\right)} {\\small \\left( \\prod_{\\substack{b < a \\leq q \\\\ \\text{a prime}}} {\\normalsize (a-2)} \\right)} \\right)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e00078a8c46fa0e0e324652e18fc56f727ea3c48adcce65393ab3108b85c3e6b-742020c8dab9b2728a436d1a6771b778dd726785efdc45f0a586565a48c3e7c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LAGRIDA")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-509414")[#strong[#text("LAGRIDA")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("For ")#mi("q \\geq 5")#text(" we have ")#mi("\\#\\{(b,b+2,b+6,b+8) \\in \\mathcal{B}_q^4 \\} = \\displaystyle{\\small \\left( \\prod_{\\substack{5 \\leq a \\leq q \\\\ \\text{a prime}}} {\\normalsize (a-4)} \\right)}")#text(" (error of writting)")

#text("Latex code didn’t write the complete setence of ")#mi("\\#\\{(b,b+6) \\in \\mathcal{B}_q^2\\}")#text(" !")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1f4d23e13312dfddbb50fea9283c09b96ba78aef7aa7578b889cbdd2f9dd60f-029ffd63045431468f4d5099f159e6d1c06ca48357999ee785e74f090febfcd4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jaimemaldonadolondono")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-509415")[#strong[#text("jaimemaldonadolondono")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("Gracias por esta publicación, es de máximo interes para mi. Hasta hoy 12/25/18 los matemáticos se encuentran muy lejos de conocer o descubrir la verdad sobre la distribución de los Números Primos y de las Brechas entre dos consecutivos … Espero darla a conocer en el teanscurso del año 2019.")

#text("Thanks for this publication, it is of maximum interest to me. Until today 12/25/18 the mathematicians are very far from knowing or discovering the truth about the distribution of the Prime Numbers and the Gaps between two consecutive … I hope to make it known in the course of the year 2019.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e00078a8c46fa0e0e324652e18fc56f727ea3c48adcce65393ab3108b85c3e6b-742020c8dab9b2728a436d1a6771b778dd726785efdc45f0a586565a48c3e7c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LAGRIDA")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-509533")[#strong[#text("LAGRIDA")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2018")])]

#text("What do you think Mr Terrence about those values of gaps in ")#mi("\\mathcal{B}_q")#text(" ? i think if we enter analytique théory to my work, we will have a very great results ?")#linebreak()#text(" The complete article : ")#link("http://lagrida.com/prime_numbers_construction.html")[#text("http://lagrida.com/prime_numbers_construction.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Large prime gaps and probabilistic models | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-520372")[#strong[#text("Large prime gaps and probabilistic models | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2019")])]

#text("[…] choices of , which is only enough to establish the far weaker bound , which was already known (see this previous paper for a discussion of the best known unconditional lower bounds on ). An inspection of the argument […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 4: Probabilistic models and heuristics for the primes (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-635698")[#strong[#text("254A, Supplement 4: Probabilistic models and heuristics for the primes (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2021")])]

#text("[…] model to be slightly incorrect; see below. For the most recent rigorous lower bounds on , see this recent post. As for upper bounds, it was shown by Cramér on the Riemann hypothesis that , and a slight further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erdos problem #385, the parity problem, and Siegel zeroes | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-685598")[#strong[#text("Erdos problem #385, the parity problem, and Siegel zeroes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2024")])]

#text("[…] function, one can be more efficient than this; for instance, using equation (1.2) from this paper of Ford, Green, Konyagin, Maynard, and myself, it is possible to completely sieve out any interval of sufficiently large length using only those […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-687176")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2025")])]

#text("I am currently studying this paper!")#linebreak()#text("Is the process of calculating E(X_{i}(W)^2) on page 21 valid?(I think the result is correct in itself.)")#linebreak()#text("It seems to me that a copy of the random variable is needed, as in the calculation of the expected value on page 31.")

#emph[#text("[I think the calculation works fine as is, without introducing an additional copy of ")#mi("{\\mathbf W}")#text(". Note that the square is inside the expectation, not outside of it. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/#comment-687185")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2025")])]

#text("Thank you for your response. It seems I was mistaken!")
]
