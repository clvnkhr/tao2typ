// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/
// Converted to Typst by tao2typ: "2026-10-14T11:03:16.119247+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Undecidable translational tilings with only two tiles, or one nonabelian tile", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Undecidable translational tilings with only two tiles, or one nonabelian tile")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 August 2021")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/")[#text("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://www.math.ucla.edu/~greenfeld/")[#text("Rachel Greenfeld")]#text(" and I have just uploaded to the arXiv our preprint “")#link("https://arxiv.org/abs/2108.07902")[#text("Undecidable translational tilings with only two tiles, or one nonabelian tile")]#text("“. This paper studies the following question: given a finitely generated group ")#mi("{G}")#text(", a (periodic) subset ")#mi("{E}")#text(" of ")#mi("{G}")#text(", and finite sets ")#mi("{F_1,\\dots,F_J}")#text(" in ")#mi("{G}")#text(", is it possible to tile ")#mi("{E}")#text(" by translations ")#mi("{a_j+F_j}")#text(" of the tiles ")#mi("{F_1,\\dots,F_J}")#text("? That is to say, is there a solution ")#mi("{\\mathrm{X}_1 = A_1, \\dots, \\mathrm{X}_J = A_J}")#text(" to the (translational) ")#emph[#text("tiling equation")]#text(" ")#metadata(none) <tao-2f62b3464ee2ebbf142c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("(\\mathrm{X}_1 \\oplus F_1) \\uplus \\dots \\uplus (\\mathrm{X}_J \\oplus F_J) = E")]]

#text(" ")#text(" for some subsets ")#mi("{A_1,\\dots,A_J}")#text(" of ")#mi("{G}")#text(", where ")#mi("{A \\oplus F}")#text(" denotes the set of sums ")#mi("{\\{a+f: a \\in A, f \\in F \\}}")#text(" if the sums ")#mi("{a+f}")#text(" are all disjoint (and is undefined otherwise), and ")#mi("{\\uplus}")#text(" denotes disjoint union. (One can also write the tiling equation in the language of convolutions as ")#mi("{1_{\\mathrm{X}_1} * 1_{F_1} + \\dots + 1_{\\mathrm{X}_J} * 1_{F_J} = 1_E}")#text(".)")

#text("A bit more specifically, the paper studies the ")#emph[#text("decidability")]#text(" of the above question. There are two slightly different types of decidability one could consider here:")

#list(
[#strong[#text("Logical decidability")]#text(". For a given ")#mi("{G, E, J, F_1,\\dots,F_J}")#text(", one can ask whether the solvability of the tiling equation ")#link(<tao-2f62b3464ee2ebbf142c>)[#text("(1)")]#text(" is provable or disprovable in ZFC (where we encode all the data ")#mi("{G, E, F_1,\\dots,F_J}")#text(" by appropriate constructions in ZFC). If this is the case we say that the tiling equation ")#link(<tao-2f62b3464ee2ebbf142c>)[#text("(1)")]#text(" (or more precisely, the solvability of this equation) is logically decidable, otherwise it is logically undecidable.")],
[#strong[#text("Algorithmic decidability")]#text(". For data ")#mi("{G,E,J, F_1,\\dots,F_J}")#text(" in some specified class (and encoded somehow as binary strings), one can ask whether the solvability of the tiling equation ")#link(<tao-2f62b3464ee2ebbf142c>)[#text("(1)")]#text(" can be correctly determined for all choices of data in this class by the output of some Turing machine that takes the data as input (encoded as a binary string) and halts in finite time, returning either YES if the equation can be solved or NO otherwise. If this is the case, we say the tiling problem of solving ")#link(<tao-2f62b3464ee2ebbf142c>)[#text("(1)")]#text(" for data in the given class is algorithmically decidable, otherwise it is algorithmically undecidable.")]
)

#text("Note that the notion of logical decidability is “pointwise” in the sense that it pertains to a single choice of data ")#mi("{G,E,J,F_1,\\dots,F_J}")#text(", whereas the notion of algorithmic decidability pertains instead to ")#emph[#text("classes")]#text(" of data, and is only interesting when this class is infinite. Indeed, any tiling problem with a finite class of data is trivially decidable because one could simply code a Turing machine that is basically a lookup table that returns the correct answer for each choice of data in the class. (This is akin to how a student with a good memory could pass any exam if the questions are drawn from a finite list, merely by memorising an answer key for that list of questions.)")

#text("The two notions are related as follows: if a tiling problem ")#link(<tao-2f62b3464ee2ebbf142c>)[#text("(1)")]#text(" is algorithmically undecidable for some class of data, then the tiling equation must be logically undecidable for at least one choice of data for this class. For if this is not the case, one could algorithmically decide the tiling problem by searching for proofs or disproofs that the equation ")#link(<tao-2f62b3464ee2ebbf142c>)[#text("(1)")]#text(" is solvable for a given choice of data; the logical decidability of all such solvability questions will ensure that this algorithm always terminates in finite time.")

#text("One can use the ")#link("https://en.wikipedia.org/wiki/G%C3%B6del%27s_completeness_theorem")[#text("Gödel completeness theorem")]#text(" to interpret logical decidability in terms of universes (also known as ")#link("https://en.wikipedia.org/wiki/Structure_(mathematical_logic)")[#text("structures")]#text(" or models) of ZFC. In addition to the “standard” universe ")#mi("{{\\mathfrak U}}")#text(" of sets that we believe satisfies the axioms of ZFC, there are also other “nonstandard” universes ")#mi("{{\\mathfrak U}^*}")#text(" that also obey the axioms of ZFC. If the solvability of a tiling equation ")#link(<tao-2f62b3464ee2ebbf142c>)[#text("(1)")]#text(" is logically undecidable, this means that such a tiling exists in some universes of ZFC, but not in others.")

#text("(To continue the exam analogy, we thus see that a yes-no exam question is logically undecidable if the answer to the question is yes in some parallel universes, but not in others. A course syllabus is algorithmically undecidable if there is no way to prepare for the final exam for the course in a way that guarantees a perfect score (in the standard universe).)")

#text("Questions of decidability are also related to the notion of ")#link("https://en.wikipedia.org/wiki/Aperiodic_tiling")[#text("aperiodicity")]#text(". For a given ")#mi("{G, E, J, F_1,\\dots,F_J}")#text(", a tiling equation ")#link(<tao-2f62b3464ee2ebbf142c>)[#text("(1)")]#text(" is said to be ")#emph[#text("aperiodic")]#text(" if the equation ")#link(<tao-2f62b3464ee2ebbf142c>)[#text("(1)")]#text(" is solvable (in the standard universe ")#mi("{{\\mathfrak U}}")#text(" of ZFC), but none of the solutions (in that universe) are completely periodic (i.e., there are no solutions ")#mi("{\\mathrm{X}_1 = A_1,\\dots, \\mathrm{X}_J = A_J}")#text(" where all of the ")#mi("{A_1,\\dots,A_J}")#text(" are periodic). Perhaps the most well-known example of an aperiodic tiling (in the context of ")#mi("{{\\bf R}^2}")#text(", and using rotations as well as translations) come from the ")#link("https://en.wikipedia.org/wiki/Penrose_tiling")[#text("Penrose tilings")]#text(", but there are many others besides.")

#text("It was (essentially) observed by Hao Wang in the 1960s that if a tiling equation is logically undecidable, then it must necessarily be aperiodic. Indeed, if a tiling equation fails to be aperiodic, then (in the standard universe) either there is a periodic tiling, or there are no tilings whatsoever. In the former case, the periodic tiling can be used to give a finite proof that the tiling equation is solvable; in the latter case, the compactness theorem implies that there is some finite fragment of ")#mi("{E}")#text(" that is not compatible with being tiled by ")#mi("{F_1,\\dots,F_J}")#text(", and this provides a finite proof that the tiling equation is unsolvable. Thus in either case the tiling equation is logically decidable.")

#text("This observation of Wang clarifies somewhat how logically undecidable tiling equations behave in the various universes of ZFC. In the standard universe, tilings exist, but none of them will be periodic. In nonstandard universes, tilings may or may not exist, and the tilings that do exist may be periodic (albeit with a nonstandard period); but there must be at least one universe in which no tiling exists at all.")

#text("In one dimension when ")#mi("{G={\\bf Z}}")#text(" (or more generally ")#mi("{G = {\\bf Z} \\times G_0}")#text(" with ")#mi("{G_0}")#text(" a finite group), a simple pigeonholing argument shows that no tiling equations are aperiodic, and hence all tiling equations are decidable. However the situation changes in two dimensions. In 1966, Berger (a student of Wang) ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=216954")[#text("famously showed that")]#text(" there exist tiling equations ")#link(<tao-2f62b3464ee2ebbf142c>)[#text("(1)")]#text(" in the discrete plane ")#mi("{E = G = {\\bf Z}^2}")#text(" that are aperiodic, or even logically undecidable; in fact he showed that the tiling problem in this case (with arbitrary choices of data ")#mi("{J, F_1,\\dots,F_J}")#text(") was algorithmically undecidable. (Strictly speaking, Berger established this for a variant of the tiling problem known as the ")#emph[#text("domino problem")]#text(", but later ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=255431")[#text("work of Golomb")]#text(" showed that the domino problem could be easily encoded within the tiling problem.) This was accomplished by encoding the ")#link("https://en.wikipedia.org/wiki/Halting_problem")[#text("halting problem for Turing machines")]#text(" into the tiling problem (or domino problem); the latter is well known to be algorithmically undecidable (and thus have logically undecidable instances), and so the latter does also. However, the number of tiles ")#mi("{J}")#text(" required for Berger’s construction was quite large: his construction of an aperiodic tiling required ")#mi("{J = 20426}")#text(" tiles, and his construction of a logically undecidable tiling required an even larger (and not explicitly specified) collection of tiles. Subsequent work by many authors did reduce the number of tiles required; in the ")#mi("{E=G={\\bf Z}^2}")#text(" setting, the current world record for the fewest number of tiles in an aperiodic tiling is ")#mi("{J=8}")#text(" (due ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1156132")[#text("to Amman, Grunbaum, and Shephard")]#text(") and for a logically undecidable tiling is ")#mi("{J=11}")#text(" (due ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2507046")[#text("to Ollinger")]#text("). On the other hand, it is conjectured (see ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=992195")[#text("Grunbaum-Shephard")]#text(" and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1369421")[#text("Lagarias-Wang")]#text(") that one cannot lower ")#mi("{J}")#text(" all the way to ")#mi("{1}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Periodic tiling conjecture)")]#text(" If ")#mi("{E}")#text(" is a periodic subset of a finitely generated abelian group ")#mi("{G}")#text(", and ")#mi("{F}")#text(" is a finite subset of ")#mi("{G}")#text(", then the tiling equation ")#mi("{\\mathrm{X} \\oplus F = E}")#text(" is not aperiodic.")
]

#text("This conjecture is known to be true in two dimensions (by ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=4060876")[#text("work of Bhattacharya")]#text(" when ")#mi("{G=E={\\bf Z}^2}")#text(", and more recently ")#link("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/")[#text("by us")]#text(" when ")#mi("{E \\subset G = {\\bf Z}^2}")#text("), but remains open in higher dimensions. By the preceding discussion, the conjecture implies that every tiling equation with a single tile is logically decidable, and the problem of whether a given periodic set can be tiled by a single tile is algorithmically decidable.")

#text("In this paper we show on the other hand that aperiodic and undecidable tilings exist when ")#mi("{J=2}")#text(", at least if one is permitted to enlarge the group ")#mi("{G}")#text(" a bit:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Logically undecidable tilings)")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>

#list(
[#text("(i) There exists a group ")#mi("{G}")#text(" of the form ")#mi("{G = {\\bf Z}^2 \\times G_0}")#text(" for some finite abelian ")#mi("{G_0}")#text(", a subset ")#mi("{E_0}")#text(" of ")#mi("{G_0}")#text(", and finite sets ")#mi("{F_1, F_2 \\subset G}")#text(" such that the tiling equation ")#mi("{(\\mathbf{X}_1 \\oplus F_1) \\uplus (\\mathbf{X}_2 \\oplus F_2) = {\\bf Z}^2 \\times E_0}")#text(" is logically undecidable (and hence also aperiodic).")],
[#text("(ii) There exists a dimension ")#mi("{d}")#text(", a periodic subset ")#mi("{E}")#text(" of ")#mi("{{\\bf Z}^d}")#text(", and finite sets ")#mi("{F_1, F_2 \\subset G}")#text(" such that tiling equation ")#mi("{(\\mathbf{X}_1 \\oplus F_1) \\uplus (\\mathbf{X}_2 \\oplus F_2) = E}")#text(" is logically undecidable (and hence also aperiodic).")],
[#text("(iii) There exists a ")#emph[#text("non-abelian")]#text(" finite group ")#mi("{G_0}")#text(" (with the group law still written additively), a subset ")#mi("{E_0}")#text(" of ")#mi("{G_0}")#text(", and a finite set ")#mi("{F \\subset {\\bf Z}^2 \\times G_0}")#text(" such that the nonabelian tiling equation ")#mi("{\\mathbf{X} \\oplus F = {\\bf Z}^2 \\times E_0}")#text(" is logically undecidable (and hence also aperiodic).")]
)
]

#text("We also have algorithmic versions of this theorem. For instance, the algorithmic version of (i) is that the problem of determining solvability of the tiling equation ")#mi("{(\\mathbf{X}_1 \\oplus F_1) \\uplus (\\mathbf{X}_2 \\oplus F_2) = {\\bf Z}^2 \\times E_0}")#text(" for a given choice of finite abelian group ")#mi("{G_0}")#text(", subset ")#mi("{E_0}")#text(" of ")#mi("{G_0}")#text(", and finite sets ")#mi("{F_1, F_2 \\subset {\\bf Z}^2 \\times G_0}")#text(" is algorithmically undecidable. Similarly for (ii), (iii).")

#text("This result (together with a negative result discussed below) suggest to us that there is a significant qualitative difference in the ")#mi("{J=1}")#text(" theory of tiling by a single (abelian) tile, and the ")#mi("{J \\geq 2}")#text(" theory of tiling with multiple tiles (or one non-abelian tile). (The positive results on the periodic tiling conjecture certainly rely heavily on the fact that there is only one tile, in particular there is a “dilation lemma” that is only available in this setting that is of key importance in the two dimensional theory.) It would be nice to eliminate the group ")#mi("{G_0}")#text(" from (i) (or to set ")#mi("{d=2}")#text(" in (ii)), but I think this would require a fairly significant modification of our methods.")

#text("Like many other undecidability results, the proof of Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("2")]#text(" proceeds by a sequence of reductions, in which the undecidability of one problem is shown to follow from the undecidability of another, more “expressive” problem that can be encoded inside the original problem, until one reaches a problem that is so expressive that it encodes a problem already known to be undecidable. Indeed, all three undecidability results are ultimately obtained from Berger’s undecidability result on the domino problem.")

#text("The first step in increasing expressiveness is to observe that the undecidability of a single tiling equation follows from the undecidability of a system of tiling equations. More precisely, suppose we have non-empty finite subsets ")#mi("{F_j^{(m)}}")#text(" of a finitely generated group ")#mi("{G}")#text(" for ")#mi("{j=1,\\dots,J}")#text(" and ")#mi("{m=1,\\dots,M}")#text(", as well as periodic sets ")#mi("{E^{(m)}}")#text(" of ")#mi("{G}")#text(" for ")#mi("{m=1,\\dots,M}")#text(", such that it is logically undecidable whether the system of tiling equations ")#metadata(none) <tao-4cc728f76d6756f4f95e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("(\\mathrm{X}_1 \\oplus F_1^{(m)}) \\uplus \\dots \\uplus (\\mathrm{X}_J \\oplus F_J^{(m)}) = E^{(m)}")]]

#text(" ")#text(" for ")#mi("{m=1,\\dots,M}")#text(" has no solution ")#mi("{\\mathrm{X}_1 = A_1,\\dots, \\mathrm{X}_J = A_J}")#text(" in ")#mi("{G}")#text(". Then, for any ")#mi("{N>M}")#text(", we can “stack” these equations into a single tiling equation in the larger group ")#mi("{G \\times {\\bf Z}/N{\\bf Z}}")#text(", and specifically to the equation")

#metadata(none) <tao-56774bef0ca81ad692f0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("(\\mathrm{X}_1 \\oplus F_1) \\uplus \\dots \\uplus (\\mathrm{X}_J \\oplus F_J) = E")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("F_j := \\biguplus_{m=1}^M F_j^{(m)} \\times \\{m\\}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("E := \\biguplus_{m=1}^M E^{(m)} \\times \\{m\\}.")]]

#text("It is a routine exercise to check that the system of equations ")#link(<tao-4cc728f76d6756f4f95e>)[#text("(2)")]#text(" admits a solution in ")#mi("{G}")#text(" if and only if the single equation ")#link(<tao-56774bef0ca81ad692f0>)[#text("(3)")]#text(" admits a equation in ")#mi("{G \\times {\\bf Z}/N{\\bf Z}}")#text(". Thus, to prove the undecidability of a single equation of the form ")#link(<tao-56774bef0ca81ad692f0>)[#text("(3)")]#text(" it suffices to establish undecidability of a system of the form ")#link(<tao-4cc728f76d6756f4f95e>)[#text("(2)")]#text("; note here how the freedom to select the auxiliary group ")#mi("{G_0}")#text(" is important here.")

#text("We view systems of the form ")#link(<tao-4cc728f76d6756f4f95e>)[#text("(2)")]#text(" as belonging to a kind of “language” in which each equation in the system is a “sentence” in the language imposing additional constraints on a tiling. One can now pick and choose various sentences in this language to try to encode various interesting problems. For instance, one can encode the concept of a function ")#mi("{f: {\\bf Z}^2 \\rightarrow G_0}")#text(" taking values in a finite group ")#mi("{G_0}")#text(" as a single tiling equation ")#metadata(none) <tao-3f524cdc07a11d7c6220>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\mathrm{X} \\oplus (\\{0\\} \\times G_0) = {\\bf Z}^2 \\times G_0")]]

#text(" ")#text(" since the solutions to this equation are precisely the graphs")

#align(center)[#tao-fit-display[#mitex("\\mathrm{X} = \\{ (n, f(n)): n \\in {\\bf Z}^2 \\}")]]

#text("of a function ")#mi("{f: {\\bf Z}^2 \\rightarrow G_0}")#text(". By adding more tiling equations to this equation to form a larger system, we can start imposing additional constraints on this function ")#mi("{f}")#text(". For instance, if ")#mi("{x+H}")#text(" is a coset of some subgroup ")#mi("{H}")#text(" of ")#mi("{G_0}")#text(", we can impose the additional equation")

#metadata(none) <tao-e4ab4e3b1493d5a997b4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\mathrm{X} \\oplus (\\{0\\} \\times H) = {\\bf Z}^2 \\times (x+H)")]]

#text("to impose the additional constraint that ")#mi("{f(n) \\in x+H}")#text(" for all ")#mi("{n \\in {\\bf Z}^2}")#text(", if we desire. If ")#mi("{G_0}")#text(" happens to contain two distinct elements ")#mi("{1, -1}")#text(", and ")#mi("{h \\in {\\bf Z}^2}")#text(", then the additional equation")

#metadata(none) <tao-625e0f649de27800fc3b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\mathrm{X} \\oplus (\\{0,h\\} \\times \\{0\\}) = {\\bf Z}^2 \\times \\{-1,1\\}")]]

#text("imposes the additional constraints that ")#mi("{f(n) \\in \\{-1,1\\}}")#text(" for all ")#mi("{n \\in {\\bf Z}^2}")#text(", and additionally that")

#align(center)[#tao-fit-display[#mitex("f(n+h) = -f(n)")]]

#text("for all ")#mi("{n \\in {\\bf Z}^2}")#text(".")

#text("This begins to resemble the equations that come up in the ")#link("https://en.wikipedia.org/wiki/Wang_tile")[#text("domino problem")]#text(". Here one has a finite set of ")#emph[#text("Wang tiles")]#text(" – unit squares ")#mi("{T}")#text(" where each of the four sides is colored with a color ")#mi("{c_N(T), c_S(T), c_E(T), c_W(T)}")#text(" (corresponding to the four cardinal directions North, South, East, and West) from some finite set ")#mi("{{\\mathcal C}}")#text(" of colors. The domino problem is then to tile the plane with copies of these tiles in such a way that adjacent sides match. In terms of equations, one is seeking to find functions ")#mi("{c_N, c_S, c_E, c_W: {\\bf Z}^2 \\rightarrow {\\mathcal C}}")#text(" obeying the pointwise constraint ")#metadata(none) <tao-f3c4e53dcdcfb9b297b0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("(c_N(n), c_S(n), c_E(n), c_W(n)) \\in {\\mathcal W}")]]

#text(" ")#text(" for all ")#mi("{n \\in {\\bf Z}^2}")#text(" where ")#mi("{{\\mathcal W}}")#text(" is the set of colors associated to the set of Wang tiles being used, and the matching constraints")

#metadata(none) <tao-bbcb41750822950e029f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("c_S(n+(0,1)) = c_N(n); \\quad c_W(n+(1,0)) = c_E(n)")]]

#text("for all ")#mi("{{\\bf Z}^2}")#text(". As it turns out, the pointwise constraint ")#link(<tao-f3c4e53dcdcfb9b297b0>)[#text("(7)")]#text(" can be encoded by tiling equations that are fancier versions of ")#link(<tao-3f524cdc07a11d7c6220>)[#text("(4)")]#text(", ")#link(<tao-e4ab4e3b1493d5a997b4>)[#text("(5)")]#text(", ")#link(<tao-625e0f649de27800fc3b>)[#text("(6)")]#text(" that involve only one unknown tiling set ")#mi("{{\\mathrm X}}")#text(", but in order to encode the matching constraints ")#link(<tao-bbcb41750822950e029f>)[#text("(8)")]#text(" we were forced to introduce a second tile (or work with nonabelian tiling equations). This appears to be an inherent feature of the method, since we found a partial rigidity result for tilings of one tile in one dimension that obstructs this encoding strategy from working when one only has one tile available. The result is as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Swapping property)")]#text(" Consider the solutions to a tiling equation")

#metadata(none) <tao-72c77c1798f755b007c5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\mathrm{X} \\oplus F = E")]]

#text("in a one-dimensional group ")#mi("{G = {\\bf Z} \\times G_0}")#text(" (with ")#mi("{G_0}")#text(" a finite abelian group, ")#mi("{F}")#text(" finite, and ")#mi("{E}")#text(" periodic). Suppose there are two solutions ")#mi("{\\mathrm{X} = A_0, \\mathrm{X} = A_1}")#text(" to this equation that agree on the left in the sense that")

#align(center)[#tao-fit-display[#mitex("A_0 \\cap (\\{0, -1, -2, \\dots\\} \\times G_0) = A_1 \\cap (\\{0, -1, -2, \\dots\\} \\times G_0).")]]

#text("For any function ")#mi("{\\omega: {\\bf Z} \\rightarrow \\{0,1\\}}")#text(", define the “swap” ")#mi("{A_\\omega}")#text(" of ")#mi("{A_0}")#text(" and ")#mi("{A_1}")#text(" to be the set")

#align(center)[#tao-fit-display[#mitex("A_\\omega := \\{ (n, g): n \\in {\\bf Z}, (n,g) \\in A_{\\omega(n)} \\}")]]

#text("Then ")#mi("{A_\\omega}")#text(" also solves the equation ")#link(<tao-72c77c1798f755b007c5>)[#text("(9)")]#text(".")
]

#text("One can think of ")#mi("{A_0}")#text(" and ")#mi("{A_1}")#text(" as “genes” with “nucleotides” ")#mi("{\\{ g \\in G_0: (n,g) \\in A_0\\}}")#text(", ")#mi("{\\{ g \\in G_0: (n,g) \\in A_1\\}}")#text(" at each position ")#mi("{n \\in {\\bf Z}}")#text(", and ")#mi("{A_\\omega}")#text(" is a new gene formed by choosing one of the nucleotides from the “parent” genes ")#mi("{A_0}")#text(", ")#mi("{A_1}")#text(" at each position. The above proposition then says that the solutions to the equation ")#link(<tao-72c77c1798f755b007c5>)[#text("(9)")]#text(" must be closed under “genetic transfer” among any pair of genes that agree on the left. This seems to present an obstruction to trying to encode equation such as")

#align(center)[#tao-fit-display[#mitex("c(n+1) = c^{\\prime}(n)")]]

#text("for two functions ")#mi("{c, c^{\\prime}: {\\bf Z} \\rightarrow \\{-1,1\\}}")#text(" (say), which is a toy version of the matching constraint ")#link(<tao-bbcb41750822950e029f>)[#text("(8)")]#text(", since the class of solutions to this equation turns out not to obey this swapping property. On the other hand, it is easy to encode such equations using two tiles instead of one, and an elaboration of this construction is used to prove our main theorem.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (20)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/#comment-633044")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2021")])]

#text("It seems that in the line below conjecture 1, “known” should be “true”.")

#emph[#text("[The text is now clarified – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/#comment-633045")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2021")])]

#text("is there any relationship between aperiodic tiling and quasiperiodicity (i.e a kind of “quasiperiodic tiling”)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/#comment-633054")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2021")])]

#text("Some aperiodic tilings are quasiperiodic (the Penrose tilings, for instance), but there are many aperiodic tilings that are not quasiperiodic. For instance, there is an aperiodic tiling of Kari of the plane by Wang tiles that is quasiperiodic on each horizontal row ")#mi("{\\bf Z} \\times \\{n\\}")#text(" with a frequency ")#mi("\\alpha_n")#text(", but the frequency changes as one goes from one row to the next in a non-quasiperiodic fashion (")#mi("\\alpha_{n+1}")#text(" is either ")#mi("2\\alpha_n")#text(" or ")#mi("\\frac{3}{2} \\alpha_n")#text(", in fact).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d380eed1b8ce19b306ee631f0f7fe4ba8d1640f6aa7c87ba99c149981c1db51-0db9cb72e4fcae65beb249711891235ac47b6fffa63daa1b48a69b7c6c0c9b05.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MyMathYourMath")]], [#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/#comment-633047")[#strong[#text("MyMathYourMath")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2021")])]

#text("In what case are the sums disjoint ? Are they generally non disjoint if the choice is arbitrary")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/#comment-633055")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2021")])]

#text("In general a sum set ")#mi("A+F")#text(" will have collisions and it will not be a disjoint sum. For instance if ")#mi("F = \\{0,1\\}")#text(", then ")#mi("2{\\bf Z} \\otimes F = {\\bf Z}")#text(" (the sums ")#mi("a+f")#text(" with ")#mi("a")#text(" even and ")#mi("f \\in \\{0,1\\}")#text(" cover the integers with multiplicity one), but ")#mi("{\\bf Z} \\otimes F")#text(" is undefined (there are are collisions ")#mi("a+f=a^{\\prime}+f^{\\prime}")#text(", e.g., ")#mi("3+1=4+0")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d380eed1b8ce19b306ee631f0f7fe4ba8d1640f6aa7c87ba99c149981c1db51-0db9cb72e4fcae65beb249711891235ac47b6fffa63daa1b48a69b7c6c0c9b05.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MyMathYourMath")]], [#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/#comment-633152")[#strong[#text("MyMathYourMath")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2021")])]

#text("sorry, I just got to view this on a computer, on the phone was a bit tough to decipher. so Z \\times F is not well-defined then due to the overlaps? interesting example, thanks! wouldn’t have thought to write the integers as F x 2Z! appreciate the reply Dr. Tao!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2a85e534696ef6a0b6a5de0f1f3f2b205d025b177f4c552a5cde01e8ac58998c-a21243e72d71594e72e6ae5e24a36cb646d0820c1842d239a68e887d4d7403c2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 🆒 maths: Undecidable translational tilings with only two tiles, or one nonabelian tile – Mathematics, for all Mankind!")]], [#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/#comment-633048")[#strong[#text("🆒 maths: Undecidable translational tilings with only two tiles, or one nonabelian tile – Mathematics, for all Mankind!")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2021")])]

#text("[…] Undecidable translational tilings with only two tiles, or one nonabelian tile […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/#comment-633052")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2021")])]

#text("Was surprised to not see reference, even in passing, to Socolar and Taylor’s construction in “An aperiodic hexagonal tile” (JCTA, 2011) ")#link("https://doi.org/10.1016/j.jcta.2011.05.001")[#text("https://doi.org/10.1016/j.jcta.2011.05.001")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/#comment-633056")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2021")])]

#text("Thanks for this reference, which we were not aware of! They produce a single tile (which can be discretised in the hexagonal lattice) such that the collection of all its rotations and reflections in this lattice (of which there are twelve) form an aperiodic tiling, so in our language this gives an aperiodic translational tiling with ")#mi("J=12")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fba7098f7286623bf3673657f1ff96e3be67e69487e67018084add49c3ba031-5aa510afc990f970bb1801ee33b9d7ffaae5f7cd3249f3ff8927bd3e0b9d5b8d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nkv")]], [#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/#comment-633074")[#strong[#text("nkv")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2021")])]

#text("Basic beginner question: Can I say that logical decidability is model independent but algorithmic decidability is model specific? Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/#comment-633145")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2021")])]

#text("Yes, a given problem can be algorithmically decidable in some models and undecidable in others. For instance, consider the problem of determining whether, given a Turing machine ")#mi("T")#text(" as input, there is a proof in ZFC that ")#mi("T")#text(" (with empty input) halts in finite time. In models in which ZFC is consistent, this problem is equivalent to the halting problem, since if ")#mi("T")#text(" does halt in finite time then there is a proof that it does so (just verify that program halts after a finite time), and if it doesn’t halt then there is no way it can be proven to halt without proving inconsistency. Thus in these models the problem is undecidable. On the other hand, in models where ZFC is inconsistent, every statement is provable, and so the problem is now trivially decidable (the algorithm is simply to always return YES).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fba7098f7286623bf3673657f1ff96e3be67e69487e67018084add49c3ba031-5aa510afc990f970bb1801ee33b9d7ffaae5f7cd3249f3ff8927bd3e0b9d5b8d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of venky")]], [#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/#comment-633317")[#strong[#text("venky")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2021")])]

#text("Thank you. This a great application of the second incompleteness theorem using which you can build models that contain (possibly nonstandard) halting proofs for any Turing machine. Do you have any particular thoughts on showing the existence of (possibly nonstandard) proofs versus supplying a concrete solution?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0cf77a6aac09fe2a9236ed0c65d1f78de5fced9f811e779bcc0a79d9d924e70c-cf646853c5134ef56006521adc27f1b57cc0a61de3c7d809a4f4cc7dd8f43991.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of endlessydarcknes")]], [#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/#comment-633293")[#strong[#text("endlessydarcknes")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2021")])]

#text("Hello Terry this article has been published in a scientific research journal would be SCALE and the University of San Francisco, in addition it has already been recognized by the Mexican mathematical society. Please!!!")

#link("http://www.scielo.org.bo/scielo.php?script=sci_arttext&pid=S2225-87872020000200006")[#text("http://www.scielo.org.bo/scielo.php?script=sci_arttext&pid=S2225-87872020000200006")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trozer133")]], [#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/#comment-633305")[#strong[#text("Trozer133")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2021")])]

#text("Please don’t tell lies.")#linebreak()#text(" The Mexican Mathematical Society (SMM) doesn’t have recognised the veracity of this article.")#linebreak()#text(" All the oficial post are made on the oficial page or YouTube channel.")#linebreak()#text(" Don’t lose your time on quackeries")#linebreak()#text(" (Sorry for my bad English)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0c966f83956f88e0ae0569a5a0b03c90ac4da8d83a15599ca142d3f1d3503e6-6da5889455160fc1a4651d11d6dc54150c1eee35c9adbd8ae366b68451ab2690.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of goingtoinfinity")]], [#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/#comment-633401")[#strong[#text("goingtoinfinity")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2021")])]

#text("I have two questions on Theorem 11.2:")#linebreak()#text(" 1) Does the result have consequences for the Heesch problem: ")#link("https://en.wikipedia.org/wiki/Heesch%27s_problem")[#text("https://en.wikipedia.org/wiki/Heesch%27s_problem")]#text(" ? I.e. is a consequence of your theorem that all positive integers can be Heesch numbers?")

#text("2) Is it possible to show represent the shape of the tiles that correspond to Theorem 11.2 (and Theorem 1.8 and 1.9)?")

#text("Sorry if these questions are naive. (My interest comes from a different discipline, namely i use aperiodic tiles/tiles with finite Heesch numbers as an examples to study explainability in deep learning systems).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8a94518cec29198c93e0dee478f627c358142810fc7258c9f94c5bd58d009248-8a48e4ec821fe7d6018b16662759e733a85b82f6b90e759fcec8ef05adc81ab6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zuchongzhi")]], [#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/#comment-633523")[#strong[#text("zuchongzhi")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2021")])]

#text("Did you notice this paper?")

#link("https://www.ams.org/journals/tran/2017-369-05/S0002-9947-2016-06963-9/")[#text("https://www.ams.org/journals/tran/2017-369-05/S0002-9947-2016-06963-9/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/#comment-637957")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2021")])]

#text("A simple question. How to see ")#mi("A\\oplus F = G")#text(" as a convolution ")#mi("1_A \\ast 1_F = 1")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/#comment-637971")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2021")])]

#text("A beautiful part of logic and math. This shows the infinite complexity of math and correlated areas (Maybe all things). You are the Mozart.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A counterexample to the periodic tiling conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/#comment-657879")[#strong[#text("A counterexample to the periodic tiling conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2022")])]

#text("[…] of Ammann, Grümbaum, and Shephard of eight tiles in which tile aperiodically. Recently, Rachel and I constructed a pair of tiles in that tiled a periodic subset of aperiodically (in fact we could even make the tiling question […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Undecidability of translational monotilings | What's new")]], [#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/#comment-681827")[#strong[#text("Undecidability of translational monotilings | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2023")])]

#text("[…] of the Sudoku problem into the monotiling problem follows from a modification of the methods in our previous papers, which had also introduced versions of the Sudoku problem, and created a “tiling […]")
]
