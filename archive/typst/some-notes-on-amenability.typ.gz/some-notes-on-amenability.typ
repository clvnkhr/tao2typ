// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/
// Converted to Typst by tao2typ: "2026-10-14T16:35:41.244521+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Some notes on amenability", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Some notes on amenability")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 April 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/")[#text("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Recently, I have been studying the concept of ")#link("http://en.wikipedia.org/wiki/Amenable_group")[#text("amenability")]#text(" on groups. This concept can be defined in a “combinatorial” or “finitary” fashion, using ")#link("http://en.wikipedia.org/wiki/F%C3%B8lner_sequence")[#text("Følner sequences")]#text(", and also in a more “functional-analytic” or “infinitary”‘ fashion, using invariant means. I wanted to get some practice passing back and forth between these two definitions, so I wrote down some notes on how to do this, and also how to take some facts about amenability that are usually proven in one setting, and prove them instead in the other. These notes are thus mostly for my own benefit, but I thought I might post them here also, in case anyone else is interested.")

#metadata(none) <tao-e642592c2d65d9a76a3e>

#heading(level: 1)[#strong[#text(" — 1. Equivalent definitions of amenability — ")]]

#text("For simplicity I will restrict attention to countable groups ")#mi("{G}")#text(". Given any ")#mi("{f: G \\rightarrow {\\mathbb R}}")#text(" and ")#mi("{x \\in G}")#text(", I define the left-translation ")#mi("{\\tau_x f: G \\rightarrow {\\mathbb R}}")#text(" by the formula ")#mi("{\\tau_x f(y) := f(x^{-1} y)}")#text(". Given ")#mi("{g: G \\rightarrow {\\mathbb R}}")#text(" as well, I define the inner product ")#mi("{\\langle f, g \\rangle := \\sum_{x \\in G} f(x) g(x)}")#text(" whenever the right-hand side is convergent.")

#text("All ")#mi("{\\ell^p}")#text(" spaces are real-valued. The cardinality of a finite set ")#mi("{A}")#text(" is denoted ")#tao-math("{\\left|A\\right|}", block: false)#text(". The symmetric difference of two sets ")#mi("{A, B}")#text(" is denoted ")#mi("{A \\Delta B}")#text(".")

#text("A ")#emph[#text("finite mean")]#text(" is a non-negative, finitely supported function ")#mi("{\\mu: G \\rightarrow {\\mathbb R}^+}")#text(" such that ")#tao-math("{\\left\\| \\mu \\right\\|_{\\ell^1(G)}=1}", block: false)#text(". A ")#emph[#text("mean")]#text(" is a non-negative linear functional ")#mi("{\\lambda: \\ell^\\infty(G) \\rightarrow {\\mathbb R}}")#text(" such that ")#mi("{\\lambda(1)=1}")#text(". Note that every finite mean ")#mi("{\\mu}")#text(" can be viewed as a mean ")#mi("{\\lambda_\\mu}")#text(" by the formula ")#mi("{\\lambda_\\mu(f) := \\langle f, \\mu \\rangle}")#text(".")

#text("The following equivalences were established ")#link("http://www.ams.org/mathscinet-getitem?mr=79220")[#text("by Følner")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" Let ")#mi("{G}")#text(" be a countable group. Then the following are equivalent:")

#list(
[#text("(i) There exists a left-invariant mean ")#mi("{\\lambda: \\ell^\\infty(G) \\rightarrow {\\mathbb R}}")#text(", i.e. mean such that ")#mi("{\\lambda(\\tau_x f) = \\lambda(f)}")#text(" for all ")#mi("{f \\in \\ell^\\infty(G)}")#text(" and ")#mi("{x \\in G}")#text(".")],
[#text("(ii) For every finite set ")#mi("{S \\subset G}")#text(" and every ")#mi("{\\epsilon > 0}")#text(", there exists a finite mean ")#mi("{\\nu}")#text(" such that ")#tao-math("{\\left\\| \\nu - \\tau_x \\nu\\right\\|_{\\ell^1(G)} \\leq \\epsilon}", block: false)#text(" for all ")#mi("{x \\in S}")#text(".")],
[#text("(iii) For every finite set ")#mi("{S \\subset G}")#text(" and every ")#mi("{\\epsilon > 0}")#text(", there exists a non-empty finite set ")#mi("{A \\subset G}")#text(" such that ")#tao-math("{\\left|(x \\cdot A) \\Delta A\\right|/\\left|A\\right| \\leq \\epsilon}", block: false)#text(" for all ")#mi("{x \\in S}")#text(".")],
[#text("(iv) There exists a sequence ")#mi("{A_n}")#text(" of non-empty finite sets such that ")#tao-math("{\\left|x \\cdot A_n \\Delta A_n\\right| / \\left|A_n\\right| \\rightarrow 0}", block: false)#text(" as ")#mi("{n \\rightarrow \\infty}")#text(" for each ")#mi("{x \\in G}")#text(". (Such a sequence is called a ")#emph[#text("Følner sequence")]#text(".)")]
)
]

#emph[#text("Proof:")]#text(" We shall use an argument ")#link("http://www.ams.org/mathscinet-getitem?mr=180832")[#text("of Namioka")]#text(".")

#text("(i) implies (ii): Suppose for contradiction that (ii) failed, then there exists ")#mi("{S, \\epsilon}")#text(" such that ")#tao-math("{\\sup_{x \\in S} \\left\\| \\nu - \\tau_x \\nu\\right\\|_{\\ell^1(G)} > \\epsilon}", block: false)#text(" for all means ")#mi("{\\nu}")#text(". The set ")#mi("{\\{ (\\nu - \\tau_x \\nu)_{x \\in S}: \\nu \\in \\ell^1(G) \\}}")#text(" is then a convex set of ")#mi("{(\\ell^1(G))^S}")#text(" that is bounded away from zero. Applying the Hahn-Banach separation theorem, there thus exists a linear functional ")#mi("{\\rho \\in (\\ell^1(G)^S)^*}")#text(" such that ")#mi("{\\rho((\\nu-\\tau_x \\nu)_{x \\in S}) \\geq 1}")#text(" for all means ")#mi("{\\nu}")#text(". Since ")#mi("{(\\ell^1(G)^S)^* \\equiv \\ell^\\infty(G)^S}")#text(", there thus exist ")#mi("{m_x \\in \\ell^\\infty(G)}")#text(" for ")#mi("{x \\in S}")#text(" such that ")#mi("{\\sum_{x \\in S} \\langle \\nu - \\delta_x*\\nu, m_x \\rangle \\geq 1}")#text(" for all means ")#mi("{\\nu}")#text(", thus ")#mi("{\\langle \\nu, \\sum_{x \\in S} m_x - \\tau_{x^{-1}} m_x \\rangle \\geq 1}")#text(". Specialising ")#mi("{\\nu}")#text(" to the Kronecker means ")#mi("{\\delta_y}")#text(" we see that ")#mi("{\\sum_{x \\in S} m_x-\\tau_{x^{-1}} m_x \\geq 1}")#text(" pointwise. Applying the mean ")#mi("{\\lambda}")#text(", we conclude that ")#mi("{\\sum_{x \\in S} \\lambda(m_x)-\\lambda(\\tau_{x^{-1}} m_x) \\geq 1}")#text(". But this contradicts the left-invariance of ")#mi("{\\lambda}")#text(".")

#text("(ii) implies (iii): Fix ")#mi("{S}")#text(" (which we can take to be non-empty), and let ")#mi("{\\epsilon > 0}")#text(" be a small quantity to be chosen later. By (ii) we can find a finite mean ")#mi("{\\nu}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\nu - \\tau_x \\nu\\right\\|_{\\ell^1(G)} < \\epsilon/\\left|S\\right|", block: true)]]

#text("for all ")#mi("{x \\in S}")#text(".")

#text("Using the layer-cake decomposition, we can write ")#mi("{\\nu = \\sum_{i=1}^k c_i 1_{E_i}}")#text(" for some nested non-empty sets ")#mi("{E_1 \\supset E_2 \\supset \\ldots \\supset E_k}")#text(" and some positive constants ")#mi("{c_i}")#text(". As ")#mi("{\\nu}")#text(" is a mean, we have ")#tao-math("{\\sum_{i=1}^k c_i \\left|E_i\\right| = 1}", block: false)#text(". On the other hand, observe that ")#tao-math("{\\left|\\nu - \\tau_x \\nu\\right|}", block: false)#text(" is at least ")#mi("{c_i}")#text(" on ")#mi("{(x \\cdot E_i) \\Delta E_i}")#text(". We conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i=1}^k c_i \\left|(x \\cdot E_i) \\Delta E_i\\right| \\leq \\frac{\\epsilon}{\\left|S\\right|} \\sum_{i=1}^k c_i \\left|E_i\\right|", block: true)]]

#text("for all ")#mi("{x \\in S}")#text(", and thus")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i=1}^k c_i \\sum_{x \\in S} \\left|(x \\cdot E_i) \\Delta E_i\\right| \\leq \\epsilon \\sum_{i=1}^k c_i |E_i|.", block: true)]]

#text("By the pigeonhole principle, there thus exists ")#mi("{i}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\in S} \\left|(x \\cdot E_i) \\Delta E_i\\right| \\leq \\epsilon \\left|E_i\\right|", block: true)]]

#text("and the claim follows.")

#text("(iii) implies (iv): Write the countable group ")#mi("{G}")#text(" as the increasing union of finite sets ")#mi("{S_n}")#text(" and apply (iii) with ")#mi("{\\epsilon := 1/n}")#text(" and ")#mi("{S := S_n}")#text(" to create the set ")#mi("{A_n}")#text(".")

#text("(iv) implies (i): Use the Hahn-Banach theorem to select an infinite mean ")#mi("{\\rho \\in \\ell^\\infty({\\mathbb N})^* \\backslash \\ell^1({\\mathbb N})}")#text(", and define ")#tao-math("{\\lambda( m ) = \\rho( ( \\langle m, \\frac{1}{\\left|A_n\\right|} 1_{A_n} \\rangle )_{n \\in {\\mathbb N}} )}", block: false)#text(". (Alternatively, one can define ")#mi("{\\lambda(m)}")#text(" to be an ")#link("http://en.wikipedia.org/wiki/Ultralimit")[#text("ultralimit")]#text(" of the ")#tao-math("{\\langle m, \\frac{1}{\\left|A_n\\right|} 1_{A_n} \\rangle}", block: false)#text(".) ")#mi("\\Box")

#text("Any countable group obeying any (and hence all) of (i)-(iv) is called ")#emph[#text("amenable")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The above equivalences are proven in a non-constructive manner, due to the use of the Hahn-Banach theorem (as well as the contradiction argument). Thus, for instance, it is not immediately obvious how to convert an invariant mean into a Følner sequence, despite the above equivalences.")
]

#heading(level: 1)[#strong[#text(" — 2. Examples of amenable groups — ")]]

#text("We give some model examples of amenable and non-amenable groups:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2")]#text(" ")#metadata(none) <tao-d4f568b800c6a61b3ba2>#text(" Every finite group is amenable.")
]

#emph[#text("Proof:")]#text(" Trivial (either using invariant means or Følner sequences). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3")]#text(" ")#metadata(none) <tao-2dba2454d80024acf671>#text(" The integers ")#mi("{{\\mathbb Z} = ({\\mathbb Z},+)}")#text(" are are amenable.")
]

#emph[#text("Proof:")]#text(" One can take the sets ")#mi("{A_N = \\{1,\\ldots,N\\}}")#text(" as the Følner sequence, or an ultralimit as an invariant mean. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4")]#text(" The free group ")#mi("{F_2}")#text(" on two generators ")#mi("{e_1,e_2}")#text(" is not amenable.")
]

#emph[#text("Proof:")]#text(" We first argue using invariant means. Suppose for contradiction that one had an invariant mean ")#mi("{\\lambda}")#text(". Let ")#mi("{E_1, E_2, E_{-1}, E_{-2} \\subset F_2}")#text(" be the set of all words beginning with ")#mi("{e_1}")#text(", ")#mi("{e_2}")#text(", ")#mi("{e_1^{-1}, e_2^{-1}}")#text(" respectively. Observe that ")#mi("{E_2 \\subset (e_1^{-1} \\cdot E_1) \\backslash E_1}")#text(", thus ")#mi("{\\lambda(1_{E_2}) \\leq \\lambda(\\tau_{e_1^{-1}} 1_{E_1}) - \\lambda( 1_{E_1} )}")#text(". By invariance we conclude that ")#mi("{\\lambda(1_{E_2}) = 0}")#text("; similarly for ")#mi("{1_{E_1}}")#text(", ")#mi("{1_{E_{-1}}}")#text(", ")#mi("{1_{E_{-2}}}")#text(". Since the identity element clearly must have mean zero, we conclude that the mean ")#mi("{\\lambda}")#text(" is identically zero, which is absurd.")

#text("Now we argue using Følner sequences. If ")#mi("{F_2}")#text(" were amenable, then for any ")#mi("{\\epsilon > 0}")#text(" we could find a finite non-empty set ")#mi("{A}")#text(" such that ")#mi("{x \\cdot A}")#text(" differs from ")#mi("{A}")#text(" by at most ")#tao-math("{\\epsilon \\left|A\\right|}", block: false)#text(" points for ")#mi("{x = e_1, e_2, e_1^{-1}, e_2^{-1}}")#text(". The set ")#mi("{e_1 \\cdot (A \\cap (E_2 \\cup E_{1} \\cup E_{-2}))}")#text(" is contained in ")#mi("{e_1 \\cdot A}")#text(" and in ")#mi("{E_1}")#text(", and so")

#align(center)[#tao-fit-display[#tao-math("\\left|e_1 \\cdot (A \\backslash E_{-1})\\right| \\leq \\left|A \\cap E_1\\right| + \\epsilon \\left|A\\right|,", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\left|A\\right| - \\left|A \\cap E_{-1}\\right| \\leq \\left|A \\cap E_1\\right| + \\epsilon |A|.", block: true)]]

#text("Similarly for permutations. Summing up over all four permutations, we obtain")

#align(center)[#tao-fit-display[#tao-math("4\\left|A\\right| - \\left|A\\right| \\leq \\left|A\\right| + 4 \\epsilon \\left|A\\right|,", block: true)]]

#text("leading to a contradiction for ")#mi("{\\epsilon}")#text(" small enough (any ")#mi("{\\epsilon < 1/2}")#text(" will do). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The non-amenability of the free group is related to the ")#link("http://en.wikipedia.org/wiki/Banach%E2%80%93Tarski_paradox")[#text("Banach-Tarski paradox")]#text(" (see my ")#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/")[#text("earlier lecture notes")]#text(" on this).")
]

#text("Now we generate some more amenable groups.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5")]#text(" ")#metadata(none) <tao-a0e992cc131b2c41449e>#text(" Let ")#mi("{0 \\rightarrow H \\rightarrow G \\rightarrow K \\rightarrow 0}")#text(" be a ")#link("http://en.wikipedia.org/wiki/Exact_sequence")[#text("short exact sequence")]#text(" of countable groups (thus ")#mi("{H}")#text(" can be identified with a normal subgroup of ")#mi("{G}")#text(", and ")#mi("{K}")#text(" can be identified with ")#mi("{G/H}")#text("). If ")#mi("{H}")#text(" and ")#mi("{K}")#text(" are amenable, then ")#mi("{G}")#text(" is amenable also.")
]

#emph[#text("Proof:")]#text(" Using invariant means, there is a very short proof: given invariant means ")#mi("{\\lambda_H}")#text(", ")#mi("{\\lambda_K}")#text(" for ")#mi("{H, K}")#text(", we can build an invariant mean ")#mi("{\\lambda_G}")#text(" for ")#mi("{G}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\lambda_G(f) := \\lambda_K( F )")]]

#text("for any ")#mi("{f \\in \\ell^\\infty(G)}")#text(", where ")#mi("{F: K \\rightarrow {\\mathbb R}}")#text(" is the function defined as ")#mi("{F(xH) := \\lambda_H( f(x \\cdot) )}")#text(" for all cosets ")#mi("{xH}")#text(" (note that the left-invariance of ")#mi("{\\lambda_H}")#text(" shows that the exact choice of coset representative ")#mi("{x}")#text(" is irrelevant). (One can view ")#mi("{\\lambda_G}")#text(" as sort of a “product measure” of the ")#mi("{\\lambda_H}")#text(" and ")#mi("{\\lambda_K}")#text(".)")

#text("Now we argue using Følner sequences instead. Let ")#mi("{E_n}")#text(", ")#mi("{F_n}")#text(" be Følner sequences for ")#mi("{H, K}")#text(" respectively. Let ")#mi("{S}")#text(" be a finite subset of ")#mi("{G}")#text(", and let ")#mi("{\\epsilon > 0}")#text(". We would like to find a finite non-empty subset ")#mi("{A \\subset G}")#text(" such that ")#tao-math("{\\left|(x \\cdot A) \\backslash A\\right| \\leq \\epsilon \\left|A\\right|}", block: false)#text(" for all ")#mi("{x \\in S}")#text("; this will demonstrate amenability. (Note that by taking ")#mi("{S}")#text(" to be symmetric, we can replace ")#tao-math("{\\left|(x \\cdot A) \\backslash A\\right|}", block: false)#text(" with ")#tao-math("{\\left|(x \\cdot A) \\Delta A\\right|}", block: false)#text(" without difficulty.)")

#text("By taking ")#mi("{n}")#text(" large enough, we can find ")#mi("{F_n}")#text(" such that ")#mi("{\\pi(x) \\cdot F_n}")#text(" differs from ")#mi("{F_n}")#text(" by at most ")#tao-math("{\\epsilon \\left|F_n\\right|/2}", block: false)#text(" elements for all ")#mi("{x \\in S}")#text(", where ")#mi("{\\pi: G \\rightarrow K}")#text(" is the projection map. Now, let ")#mi("{F^{\\prime}_n}")#text(" be a preimage of ")#mi("{F_n}")#text(" in ")#mi("{G}")#text(". Let ")#mi("{T}")#text(" be the set of all group elements ")#mi("{t \\in H}")#text(" such that ")#mi("{S \\cdot F^{\\prime}_n}")#text(" intersects ")#mi("{F^{\\prime}_n \\cdot t}")#text(". Observe that ")#mi("{T}")#text(" is finite. Thus, by taking ")#mi("{m}")#text(" large enough, we can find ")#mi("{E_m}")#text(" such that ")#mi("{t \\cdot E_m}")#text(" differs from ")#mi("{E_m}")#text(" by at most ")#tao-math("{\\epsilon \\left|E_m\\right|/2\\left|T\\right|}", block: false)#text(" points for all ")#mi("{t \\in T}")#text(".")

#text("Now set ")#mi("{A := F^{\\prime}_n \\cdot E_m = \\{ zy: y \\in E_m, z \\in F^{\\prime}_n \\}}")#text(". Observe that the sets ")#mi("{z \\cdot E_m}")#text(" for ")#mi("{z \\in F^{\\prime}_n}")#text(" lie in disjoint cosets of ")#mi("{H}")#text(" and so ")#tao-math("{\\left|A\\right| = \\left|E_m\\right| \\left|F^{\\prime}_n\\right| = \\left|E_m\\right| \\left|F_n\\right|}", block: false)#text(". Now take ")#mi("{x \\in S}")#text(", and consider an element of ")#mi("{(x \\cdot A) \\backslash A}")#text(". This element must take the form ")#mi("{xzy}")#text(" for some ")#mi("{y \\in E_m}")#text(" and ")#mi("{z \\in F^{\\prime}_n}")#text(". The coset of ")#mi("{H}")#text(" that ")#mi("{xzy}")#text(" lies in is given by ")#mi("{\\pi(x) \\pi(z)}")#text(". Suppose first that ")#mi("{\\pi(x) \\pi(z)}")#text(" lies outside of ")#mi("{F_n}")#text(". By construction, this occurs for at most ")#tao-math("{\\epsilon \\left|F_n\\right|/2}", block: false)#text(" choices of ")#mi("{z}")#text(", leading to at most ")#tao-math("{\\epsilon \\left|E_m\\right| \\left|F_n\\right|/2 = \\epsilon \\left|A\\right|/2}", block: false)#text(" elements in ")#mi("{(x \\cdot A) \\backslash A}")#text(".")

#text("Now suppose instead that ")#mi("{\\pi(x) \\pi(z)}")#text(" lies in ")#mi("{F_n}")#text(". Then we have ")#mi("{xz = z^{\\prime} t}")#text(" for some ")#mi("{z^{\\prime} \\in F^{\\prime}_n}")#text(" and ")#mi("{t \\in T}")#text(", by construction of ")#mi("{T}")#text(", and so ")#mi("{xzy = z^{\\prime}ty}")#text(". But as ")#mi("{xzy}")#text(" lies outside of ")#mi("{A}")#text(", ")#mi("{ty}")#text(" must lie outside of ")#mi("{E_m}")#text(". But by construction of ")#mi("{E_m}")#text(", there are at most ")#tao-math("{\\epsilon \\left|E_m\\right|/2\\left|T\\right|}", block: false)#text(" possible choices of ")#mi("{y}")#text(" that do this for each fixed ")#mi("{x, t}")#text(", leading to at most ")#tao-math("{\\epsilon \\left|E_m\\right| \\left|F_n\\right|/2 = \\epsilon \\left|A\\right|/2}", block: false)#text(". We thus have ")#tao-math("{\\left|(x \\cdot A) \\backslash A\\right| \\leq \\epsilon \\left|A\\right|}", block: false)#text(" as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6")]#text(" ")#metadata(none) <tao-aa49aefc8e31b779d703>#text(" Let ")#mi("{G_1 \\subset G_2 \\subset \\ldots}")#text(" be a sequence of countable amenable groups. Then ")#mi("{G := \\bigcup_n G_n}")#text(" is amenable.")
]

#emph[#text("Proof:")]#text(" We first use invariant means. An invariant mean on ")#mi("{\\ell^\\infty(G_n)}")#text(" induces a mean on ")#mi("{\\ell^\\infty(G)}")#text(" which is invariant with respect to translations by ")#mi("{G_n}")#text(". Taking an ultralimit of these means, we obtain the claim.")

#text("Now we use Følner sequences. Given any finite set ")#mi("{S \\subset G}")#text(" and ")#mi("{\\epsilon > 0}")#text(", we have ")#mi("{S \\subset G_n}")#text(" for some ")#mi("{n}")#text(". As ")#mi("{G_n}")#text(" is amenable, we can find ")#mi("{A \\subset G_n}")#text(" such that ")#tao-math("{\\left|(x \\cdot A) \\Delta A\\right| \\leq \\epsilon \\left|A\\right|}", block: false)#text(" for all ")#mi("{x \\in S}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7")]#text(" Every countable ")#link("http://en.wikipedia.org/wiki/Virtually")[#text("virtually")]#text(" ")#link("http://en.wikipedia.org/wiki/Solvable_group")[#text("solvable")]#text(" group ")#mi("{G}")#text(" is amenable.")
]

#emph[#text("Proof:")]#text(" Every virtually solvable group contains a solvable group of finite index, and thus contains a normal solvable subgroup of finite index. (Note that every subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(" of index ")#mi("{I}")#text(" contains a normal subgroup of index at most ")#mi("{I!}")#text(", namely the stabiliser of the ")#mi("{G}")#text(" action on ")#mi("{G/H}")#text(".) By Proposition ")#link(<tao-a0e992cc131b2c41449e>)[#text("5")]#text(" and Proposition ")#link(<tao-d4f568b800c6a61b3ba2>)[#text("2")]#text(", we may thus reduce to the case when ")#mi("{G}")#text(" is solvable. By inducting on the derived length of this solvable group using Proposition ")#link(<tao-a0e992cc131b2c41449e>)[#text("5")]#text(" again, it suffices to verify this when the group is abelian. By Proposition ")#link(<tao-aa49aefc8e31b779d703>)[#text("6")]#text(", it suffices to verify this when the group is abelian and finitely generated. By Proposition ")#link(<tao-a0e992cc131b2c41449e>)[#text("5")]#text(" again, it suffices to verify this when the group is cyclic. But this follows from Proposition ")#link(<tao-d4f568b800c6a61b3ba2>)[#text("2")]#text(" and Proposition ")#link(<tao-2dba2454d80024acf671>)[#text("3")]#text(". ")#mi("\\Box")

#heading(level: 1)[#text("Comments (33)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-38193")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2009")])]

#text("In Theorem 1.iii, should that K be a G? ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcb7765dcebcb66b358418fd292f07b386c0a7291a90aeb9f6bca628bfb97942-d37902696adeaffae267d8a41e7d46cff565608798c847245651b7b074aca171.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spencer")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-38200")[#strong[#text("Spencer")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2009")])]

#text("Hello,")

#text("I’d never heard of amenability before coming across it on this blog and to the uninitiated it feels like a strange definition. Most of the theorems are of the form “If X holds then G is amenable” or “If H,K etc are amenable then G is amenable”. Are there results which *use* amenability in a positive way? – like a problem which was otherwise confusing but now we can say “Aha! This is trivial because G is clearly amenable” or suchlike.")

#text("This may be asking too much but I suppose what I’m really saying is: If one were trying to convince someone that amenability is a worthwhile concept and the ‘right’ definition of a more intuitive idea then what would one say?")

#text("Spencer")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-38201")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2009")])]

#text("Spencer: I’ve never really heard of amenability before either, but here are my thoughts off-the-cuff. There are two sides to this definition, as Dr. Tao is emphasizing.")

#text("First is the existence of an invariant structure on the group. I can see glimmers of why a mean in particular would be useful, but just the existence of invariant structures is nice. From my more geometric perspective, I’m drawn to the example of having a left-invariant measure on a Lie group.")

#text("Second is the combinatorial side, which I think can be summarized as follows. If you give me any finite collection of group elements to act on the group, then I can give you a finite collection of points such that your translations send most of them back into the collection. That is, no matter what bunch of movements you’re allowed to use, I can find a place in the group that’s more or less stable.")

#text("The really interesting part is, of course, that these two conditions are actually equivalent, despite how different they look on the surface. What Dr. Tao is trying to do is to push this equivalence deeper. Some applications of amenability suggest using the first property, while others suggest using the second. But since they’re both equivalent, it should be possible to use either property to prove either collection of applications.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d509e4a67398165676196d672585ced90e7a9aff3d5e153a8ae82ca3a3719829-6913ece6216ee2882ebb73ce44bcf73b0437e510ad495f289d6450d43f808d08.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Danny Calegari")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-38202")[#strong[#text("Danny Calegari")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2009")])]

#text("One typical application is to dynamics. For example, it is a very useful fact that a homeomorphism of a compact topological space preserves an invariant probability measure. One way to construct such a measure is as follows. The homeomorphism f in question generates an action of the group Z of integers on the metric space (by taking powers, inverses of powers, etc.). Fix a point p in the space, and for every finite subset S of the integers, consider the probability measure mu_S which counts the points f^n(p) with n in S with equal weight. If S is the set of integers between -n and n for some big n, the probability measure mu_S is “almost invariant” under f. A weak limit of such measures associated to a Folner sequence in Z is actually invariant under the action of Z.")

#text("This fact generalizes to amenable groups in a straightforward way: if an amenable group G acts on a compact topological space, fix a point p in the space, and for every finite subset S of G, associate a probability measure mu_S on the space in more-or-less the same way. Again, a weak limit of measures associated to a Folner sequence is invariant.")

#text("You can then ask the question of why one cares about invariant measures, or indeed about dynamics . . .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d509e4a67398165676196d672585ced90e7a9aff3d5e153a8ae82ca3a3719829-6913ece6216ee2882ebb73ce44bcf73b0437e510ad495f289d6450d43f808d08.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Danny Calegari")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-38203")[#strong[#text("Danny Calegari")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2009")])]

#text("Here’s another example, probably of no interest to anyone who is not already aware of it. In any group G, the commutator subgroup G’ is the subgroup generated by commutators (i.e. expressions of the form ghg^{-1}h^{-1} where g and h are in G). For every element g in G’, define the commutator length of g to be the smallest number of commutators in G whose product is equal to g. You can then define the stable commutator length of an element g in G’ to be the following limit: stable commutator length of g = lim_{n \\to \\infty} (commutator length of g^n) divided by n. A non-obvious fact is that if G is amenable, the stable commutator length of every element of G’ is zero. By constrast, in a free group, the stable commutator length of every (nontrivial) element is at least 1/2.")

#text("This is one of the algebraic tips of a big iceberg; a slightly more technical statement is that if G is an amenable group, the (real) bounded cohomology of G vanishes.")

#text("Since I brought it up, I might as well refer you to an expository note I wrote for the Notices at ")#link("http://www.ams.org/notices/200809/tx080901100p.pdf")[#text("http://www.ams.org/notices/200809/tx080901100p.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-38205")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2009")])]

#text("The original motivation of amenability, I believe, came from trying to understand the Banach-Tarski paradox: how a ball in three dimensions can be cut up and reassembled to create, say, two balls of the same size as the original. This paradoxical decomposition is possible in three and higher dimensions but not in one or two dimensions; to oversimplify massively, this is because the group of rotations is basically amenable in one and two dimensions but not amenable in higher dimensions. I discuss this a bit in my post")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/")[#text("245B, notes 2: Amenability, the ping-pong lemma, and the Banach-Tarski paradox (optional)")]
]

#text("As Danny says, one of the main benefits of amenability of a group G is that it allows one to take asymptotic averages over G, which brings the powerful tools of ergodic theory and dynamical systems into play to create all sorts of nice asymptotic invariants. More generally, I think that the representation theory of infinite groups is quite sensitive to whether the group is amenable or not, though I am not an expert in these matters.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian Forrest")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-38206")[#strong[#text("Brian Forrest")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2009")])]

#text("The notion of amenability has a natural extension to locally compact groups. Here the interplay between the topology and the group structure is significant. For example there are compact Lie groups that are amenable as locally compact groups (all compact groups have this property), but are not amenable in the discrete topology because they contain a copy of the free group on two generators.")

#text("The heory of amenable groups (both locally compact and discrete) is massive. There are literally hundreds of properties that are implied by amenability, imply amanability or are equivalent to amenability. There are also numerous fundamental generalizations of concept to many other mathematical objects. Overall, the concept plays an important role in many diverse branches of mathematics.")

#text("A very good reference is A. Paterson’s book “Amenability”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcb7765dcebcb66b358418fd292f07b386c0a7291a90aeb9f6bca628bfb97942-d37902696adeaffae267d8a41e7d46cff565608798c847245651b7b074aca171.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spencer")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-38209")[#strong[#text("Spencer")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2009")])]

#text("Thanks Danny, John, Terry and Brian. Very helpful comments.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed17483d3ed4d7d10057b393b19644932b1c128489f779cdfa61157b5ba4c4f0-6debdf4df0a3d023d474e85afd48042e8d91b02207860348bfa72e905fc3b77f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Behrstock")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-38257")[#strong[#text("Jason Behrstock")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2009")])]

#text("The following gives a nice geometric/financial criterion for non-amenability of finitely generated groups. For a proof see chapter 6 of Gromov’s book on Metric Structures for Riemannian and Non-Riemannian Spaces.")

#text("Suppose that at each vertex of the Cayley graph of a finitely generated group G is a person holding a dollar. At a given time everybody is told to pass their dollar bill to a neighbor who lives within a uniformly fixed distance (this bound depends only on the group G and the choice of generating set). This can be done so that each person’s net worth increases if and only if the group G is non-amenable. Thus, one can think of non-amenable groups as those where Ponzi schemes can benefit everyone.")

#text("This criterion can be used, for instance, to give a simple proof of Proposition 4 above: the Cayley graph of the free group with respect to the natural choice of generators is an infinite 4-valent tree, if everyone passes their dollar towards the origin then everyone’s net worth increases. (Iterate to get rich!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-38260")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2009")])]

#text("Dear Jason,")

#text("This is indeed an amusing interpretation of non-amenability. It seems related to another characterisation I know of, namely that a group is non-amenable if and only if its Cayley graph supports non-trivial bounded harmonic functions (i.e. if Liouville’s theorem fails for the group).")

#text("Very roughly speaking, it seems that amenable groups are the ones which can be “approximated by finite groups” (or by finite group-like objects), whereas non-amenable groups are those which are genuinely inapproximable by finitary objects. Thus the latter groups tend to exhibit all sorts of nasty behaviour that one doesn’t see in the finitary world (e.g. Ponzi schemes that actually work!)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d509e4a67398165676196d672585ced90e7a9aff3d5e153a8ae82ca3a3719829-6913ece6216ee2882ebb73ce44bcf73b0437e510ad495f289d6450d43f808d08.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Danny Calegari")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-38279")[#strong[#text("Danny Calegari")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2009")])]

#text("Hi Terry – I’m confused by your last comment. I seem to remember that it’s a theorem of Kaimanovich and Vershik that for any amenable group G there is *some* symmetric nondegenerate (i.e. generating G as a semigroup) probability measure for which the Poisson boundary is trivial (i.e. there are no nontrivial bounded harmonic functions) – I think this was a conjecture of Furstenburg. But I think there are examples (some due to Kaimanovich-Vershik?, some to Erschler? and others??) of amenable groups for which other symmetric nondegenerate measures – even measures of finite support – do have nontrivial Poisson boundary. In fact, didn’t Erschler construct a compact Riemannian manifold with amenable fundamental group whose universal cover admits lots of bounded harmonic functions?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4e1a73953be134bb5fd91b9c5761a22ae99047f124b929a587fd309c0bf649c-87128c91c4823bae580e0e3609ea4e940f96a8809d71cc317a58651229746ec2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anders Karlsson")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-38288")[#strong[#text("Anders Karlsson")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2009")])]

#text("Danny is right. Many finitely generated amenable groups (especially those of exponential growth) do have nontrivial bounded harmonic functions w.r.t certain probability measures, even symmetric and finitely supported ones. Perhaps the simplest examples to see this are solvable so-called wreath products or Lamplighter groups, for more details see for example Kaimanovich-Vershik")#linebreak()#text(" ")#link("http://projecteuclid.org/DPubS?service=UI&version=1.0&verb=Display&handle=euclid.aop/1176993497")[#text("http://projecteuclid.org/DPubS?service=UI&version=1.0&verb=Display&handle=euclid.aop/1176993497")]#linebreak()#text(" page 480.")

#text("Think of the lattice Z^d with lamps at each vertex.")#linebreak()#text(" The group G can be thought of Z^d (the position of the lamplighter) and finite sets of vertices of Z^d (=lamps switched on). (The group operation is the natural one; the lamps are Z/2Z). Consider the simple symmetric random walk of a “lamplighter” on Z^d. If d is at least 3 this random walk is transient. He may switch on/off the lamp where he stands. For d at least 3 this means that the lamp configuration eventually stabilize in each finite region. So the function assigning to a starting postition of the lamplighter and finite lamp configuration, the probability that the lamp at (for example) the origin of Z^d eventually remains switched on, is a nontrivial bounded harmonic function on G. For d=1 or 2 the same can be achieved with asymmetric measure. (BTW, it is known that when d=1 the corresponding standard Cayley graph is the simplest Diestel-Leader graph.)")

#text("Note that this is in a sense a discrete phenomenon: it is known that for symmetric probability measures absolutely continuous w.r.t Haar on an amenable Lie group, every bounded harmonic function is constant. For more information I recommend Erschler ")#link("http://www.springerlink.com/content/qxmjna69xe8v67un/")[#text("http://www.springerlink.com/content/qxmjna69xe8v67un/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-38292")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2009")])]

#text("Dear Danny and Anders, thanks for the correction! I didn’t realise the subtlety involving the choice of symmetric measure. (As mentioned in the main post, I’m still in the process of understanding amenability!) So to summarise:")

#text("For non-amenable groups, one has non-constant bounded harmonic functions for any choice of symmetric measure;")

#text("For amenable groups, there are symmetric measures for which all bounded harmonic functions are constant, but (at least in the discrete case) there can exist symmetric measures with respect to which non-constant bounded harmonic functions exist.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Orr")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-38360")[#strong[#text("Orr")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2009")])]

#text("Hi,")#linebreak()#text(" In Theorem 1, ii implies iii, I think an epsilon is missing from the last two equations.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-38367")[#strong[#text("A Problem on Planar Percolation « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2009")]

#text("[…] proof by Itai, Russ, Yuval, and Oded of the “dying percolation property” for nonamenable groups was outlined. And the Burton-Keane beautiful result on unique infinite connected […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8fa6ce7e5acbb5a3889d3d4712b657537f41c95ec0df1b8520a2803b6324715-a1ecb495c584f06e8e7457b985abc5200fb6205366def16e7bb49bc7fd5bcf6e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adebayo emmanuel")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-38952")[#strong[#text("adebayo emmanuel")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2009")])]

#text("I am really interested in the article and even the topic at large.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a8c1203d7f31aafc34322b009621eb45b736076bb0a611be7053943dfafc686-51bcccf5ddb2ff5658e8ce8dc6b1c1fd8cc866c0e0306612367dcd242fb15df0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gábor Pete")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-40246")[#strong[#text("Gábor Pete")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("I think it’s worth adding to the discussion on non-constant bounded harmonic functions that for many amenable groups (e.g., the lamplighter group over Z^3), the only known symmetric measures with no such functions have UNBOUNDED support. In fact, it is a well-known question whether the Liouville property of a group is independent of the finite generating set taken. On the other hand, it is known to be NOT a quasi-isometry invariant property of graphs and Riemannian manifolds (T. Lyons 1987 and I. Benjamini 1991).")

#text("The failure of Liouville property is interesting for many reasons, e.g., it is equivalent to having positive speed and positive entropy for the random walk with steps given by that measure.")

#text("From the point of view of random walks, it is quite counterintuitive at first glance that a symmetric measure with unbounded jumps can be slower than any (or at least, any natural) walk with symmetric bounded jumps on the same group. But in the usual construction, those unbounded jumps are supported on large Folner sets, so it’s not really that surprising.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-41113")[#strong[#text("excuses, excuses « Since it is not …")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2009")]

#text("[…] sometimes it allows quicker/slicker proofs of certain results (for instance, see Prop. 5 in these expository notes by Terence Tao). So, I thought it might be worth a post looking at amenability from the function-space […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Some notes on group extensions « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-43337")[#strong[#text("Some notes on group extensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2010")])]

#text("[…] results in group theory in a succinct form using this notation. For instance, one of the results in my earlier blog post on amenability now states that amenable-by-amenable groups are amenable. Another example that I have been looking […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A computational perspective on set theory « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-43937")[#strong[#text("A computational perspective on set theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2010")])]

#text("[…] low and high dimensional cases is that the free group is not amenable, whereas is amenable. See these previous blog posts for further discussion.) Possibly related posts: (automatically generated)The “no […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3701999ab0c8d9e5c19f88ffc4db78e030d839ec8a33332ca050fb9a4cde496-8f7a1cd13854a1701470ff72d39349d021974a15c851718907ce84396b21d2dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Treger")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-120012")[#strong[#text("Robert Treger")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2012")])]

#text("Consider a projective manifold X with large, residually finite, and a non-amenable fundamental group. Let U denote its universal covering. It is known that U has infinitely many bounded harmonic functions. Do those functions separate points on U provided U is Stein?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dasziggy")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-151906")[#strong[#text("dasziggy")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2012")])]

#text("In Theorem 1, (i) ==> (ii), shouldn’t the negation of (ii) be:")

#text("“There exists {S, \\epsilon} s.t. for all means {\\nu} there \\textbf{exists} {x \\in S} such that {\\| \\nu – \\tau_x \\nu\\|_{\\ell^1(G)} > \\epsilon} .”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-214252")[#strong[#text("First Bourbaki seminar of 2013 « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2013")]

#text("[…] For more details on these properties (in the case of countable groups), the reader might want to consult Terence Tao’s notes on this subject. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cd3293b17fc4102811ce87a71f982a006bff024f4fadf65e5afe06087907fc0-4ba76bf4fed42f8a2ca5c337f3ef79cd4db842b060b6a124a522d20c80bf75fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mustafa Said")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-218979")[#strong[#text("Mustafa Said")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2013")])]

#text("There is a good set of notes on “Amenability for von Neumann Algebras, Hyperfiniteness” by Remi Boutonnet")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/176de11fc6e13ae464bb0f083b8abe7853350302dac3cf123d30a646bdc1df40-dbcadf484c84a65762b4f221def31c7cf65e5a7b620e15701911f025fd4738fe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S.")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-472514")[#strong[#text("S.")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2016")])]

#text("Nice. I have a question about the conditions (iii) and (iv) in Theorem 1:, is there a possibility to prove the equivalence of both conditions without using that ")#mi("G")#text(" is countable?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Generalisations of the limit functional | What's new")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-480545")[#strong[#text("Generalisations of the limit functional | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2017")])]

#text("[…] can be viewed as a demonstration of the amenability of the natural numbers (or integers); see this previous blog post for further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DHan")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-618466")[#strong[#text("DHan")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2021")])]

#text("I think in theorem 1, the part from (ii) to (iii), the first inequality is not very clear from the observation. I prefer Namioka’s proof for this. But anyway, many thanks for this post!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-681820")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2023")])]

#text("in prop5, if H is uncountable ,why preimage of F_{n} is finite?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-681822")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2023")])]

#text("We select one preimage of each element of ")#mi("F_n")#text(" to create ")#mi("F^{\\prime}_n")#text(", so ")#mi("F^{\\prime}_n")#text(" will have the same cardinality as ")#mi("F_n")#text(". (We do not use the *entire* preimage, which could indeed be infinite.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-681825")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2023")])]

#text("thanks a lot")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cba52b765fe7214aed16fb881b02033ca3ef3359ed9ffac48fdcfacf8b4f1136-d29d63e39e61439e63c79d23dc461ed0a078d9b98805954b17c18ce2f8535892.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sundara Narasimhan")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-684445")[#strong[#text("Sundara Narasimhan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2024")])]

#text("Is the invariant mean not necessarily a continuous linear functional of ")#mi("\\ell^{\\infty}(G)")#text("?")

#text("I’m trying to see an invariant mean on ")#mi("(\\mathbb{Z}, +)")#text(", one candidate should exist because ")#mi("(\\mathbb{Z}, +)")#text(" is amenable. If it was a continuous positive linear functional with total mass 1, it should be in of the form ")#mi("(a_n)_{n \\in \\mathbb{Z}}")#text(" and such that ")#mi("\\sum_{n \\in \\mathbb{Z}} a_n=1")#text(". It is also ")#mi("\\mathbb{Z}")#text(" invariant, so it would force all ")#mi("a_i")#text(" to be equal. However, such a choice of ")#mi("(a_n)_{n \\in \\mathbb{Z}}")#text(" does not exist.")

#text("So what is a good candidate for the invariant mean? Am I missing some easy non-continous candidate?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-684455")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2024")])]

#text("One needs the axiom of choice (or some slightly weaker version thereof, such as the ultrafilter lemma) in order to construct an invariant mean. I discuss these means further at ")#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/")[#text("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/")]

#text("Note that the Riesz representation theorem concerns continuous linear functionals on ")#mi("c_0(G)")#text(", rather than ")#mi("\\ell^\\infty(G)")#text(", so does not preclude the possibility of continuous linear functionals on ")#mi("\\ell^\\infty(G)")#text(" that don’t arise from finite measures on ")#mi("G")#text(" (and indeed the Hahn-Banach theorem provides such functionals).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/#comment-684873")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2024")])]

#text("In the proof of Proposition4, is")

#link("https://s0.wp.com/latex.php?latex=%7Be_1+%5Ccdot+%28A+%5Ccap+%28E_2+%5Ccup+E_%7B-1%7D+%5Ccup+E_%7B-2%7D%29%29%7D&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%7Be_1+%5Ccdot+%28A+%5Ccap+%28E_2+%5Ccup+E_%7B-1%7D+%5Ccup+E_%7B-2%7D%29%29%7D&bg=ffffff&fg=000000&s=0&c=20201002")]

#text("supposed to be with E_1 rather than E_{-1}, and adding a union with {e} as well? ")#linebreak()#text("e_1cdot(Acap({e}cup E_1cup E_2cup E_{-2}))")

#text("As written now I don’t think it is contained in E_1 (if e_{-1}in A, for example), neither is it the set e_1cdot(Asetminus E_{-1}), which appears in its place in the next inequality.")

#emph[#text("[Corrected, thanks – T.]")]
]
