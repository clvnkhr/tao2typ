// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/
// Converted to Typst by tao2typ: "2026-10-14T11:03:11.037493+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Gowers uniformity norm of order 1+", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Gowers uniformity norm of order 1+")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 July 2021")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/")[#text("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the modern theory of higher order Fourier analysis, a key role are played by the ")#link("https://en.wikipedia.org/wiki/Gowers_norm")[#text("Gowers uniformity norms")]#text(" ")#mi("{\\| \\|_{U^k}}")#text(" for ")#mi("{k=1,2,\\dots}")#text(". For finitely supported functions ")#mi("{f: {\\bf Z} \\rightarrow {\\bf C}}")#text(", one can define the (non-normalised) Gowers norm ")#tao-math("{\\left\\|f\\right\\|_{\\tilde U^k({\\bf Z})}}", block: false)#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{\\tilde U^k({\\bf Z})}^{2^k} := \\sum_{n,h_1,\\dots,h_k \\in {\\bf Z}} \\prod_{\\omega_1,\\dots,\\omega_k \\in \\{0,1\\}} {\\mathcal C}^{\\omega_1+\\dots+\\omega_k} f(x+\\omega_1 h_1 + \\dots + \\omega_k h_k)", block: true)]]

#text("where ")#mi("{{\\mathcal C}}")#text(" denotes complex conjugation, and then on any discrete interval ")#mi("{[N] = \\{1,\\dots,N\\}}")#text(" and any function ")#mi("{f: [N] \\rightarrow {\\bf C}}")#text(" we can then define the (normalised) Gowers norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^k([N])} := \\left\\| f 1_{[N]} \\right\\|_{\\tilde U^k({\\bf Z})} / \\left\\|1_{[N]} \\right\\|_{\\tilde U^k({\\bf Z})}", block: true)]]

#text("where ")#mi("{f 1_{[N]}: {\\bf Z} \\rightarrow {\\bf C}}")#text(" is the extension of ")#mi("{f}")#text(" by zero to all of ")#mi("{{\\bf Z}}")#text(". Thus for instance")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^1([N])} = \\left|\\mathop{\\bf E}_{n \\in [N]} f(n)\\right|", block: true)]]

#text("(which technically makes ")#mi("{\\| \\|_{U^1([N])}}")#text(" a seminorm rather than a norm), and one can calculate")

#metadata(none) <tao-4ce7bcf6e148d5048b8e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\|f\\right\\|_{U^2([N])} \\asymp (N \\int_0^1 \\left|\\mathop{\\bf E}_{n \\in [N]} f(n) e(-\\alpha n)\\right|^4\\ d\\alpha)^{1/4}", block: true)]]

#text("where ")#mi("{e(\\theta) := e^{2\\pi i \\alpha}}")#text(", and we use the averaging notation ")#tao-math("{\\mathop{\\bf E}_{n \\in A} f(n) = \\frac{1}{\\left|A\\right|} \\sum_{n \\in A} f(n)}", block: false)#text(".")

#text("The significance of the Gowers norms is that they control other multilinear forms that show up in additive combinatorics. Given any polynomials ")#mi("{P_1,\\dots,P_m: {\\bf Z}^d \\rightarrow {\\bf Z}}")#text(" and functions ")#mi("{f_1,\\dots,f_m: [N] \\rightarrow {\\bf C}}")#text(", we define the multilinear form")

#align(center)[#tao-fit-display[#mitex("\\Lambda^{P_1,\\dots,P_m}(f_1,\\dots,f_m) := \\sum_{n \\in {\\bf Z}^d} \\prod_{j=1}^m f_j 1_{[N]}(P_j(n)) / \\sum_{n \\in {\\bf Z}^d} \\prod_{j=1}^m 1_{[N]}(P_j(n))")]]

#text("(assuming that the denominator is finite and non-zero). Thus for instance")

#tao-aligned(keep: true)[


#tao-math("\\Lambda^{\\mathrm{n}}(f)  & = \\mathop{\\bf E}_{n \\in [N]} f(n)", block: true)



#tao-math("\\Lambda^{\\mathrm{n}, \\mathrm{n}+\\mathrm{r}}(f,g)  & = (\\mathop{\\bf E}_{n \\in [N]} f(n)) (\\mathop{\\bf E}_{n \\in [N]} g(n))", block: true)
]

#align(center)[#tao-fit-display[#mitex("\\Lambda^{\\mathrm{n}, \\mathrm{n}+\\mathrm{r}, \\mathrm{n}+2\\mathrm{r}}(f,g,h) \\asymp \\mathop{\\bf E}_{n \\in [N]} \\mathop{\\bf E}_{r \\in [-N,N]} f(n) g(n+r) h(n+2r)")]]

#align(center)[#tao-fit-display[#mitex("\\Lambda^{\\mathrm{n}, \\mathrm{n}+\\mathrm{r}, \\mathrm{n}+\\mathrm{r}^2}(f,g,h) \\asymp \\mathop{\\bf E}_{n \\in [N]} \\mathop{\\bf E}_{r \\in [-N^{1/2},N^{1/2}]} f(n) g(n+r) h(n+r^2)")]]

#text("where we view ")#mi("{\\mathrm{n}, \\mathrm{r}}")#text(" as formal (indeterminate) variables, and ")#mi("{f,g,h: [N] \\rightarrow {\\bf C}}")#text(" are understood to be extended by zero to all of ")#mi("{{\\bf Z}}")#text(". These forms are used to count patterns in various sets; for instance, the quantity ")#mi("{\\Lambda^{\\mathrm{n}, \\mathrm{n}+\\mathrm{r}, \\mathrm{n}+2\\mathrm{r}}(1_A,1_A,1_A)}")#text(" is closely related to the number of length three arithmetic progressions contained in ")#mi("{A}")#text(". Let us informally say that a form ")#mi("{\\Lambda^{P_1,\\dots,P_m}(f_1,\\dots,f_m)}")#text(" is ")#emph[#text("controlled")]#text(" by the ")#mi("{U^k[N]}")#text(" norm if the form is small whenever ")#mi("{f_1,\\dots,f_m: [N] \\rightarrow {\\bf C}}")#text(" are ")#mi("{1}")#text("-bounded functions with at least one of the ")#mi("{f_j}")#text(" small in ")#mi("{U^k[N]}")#text(" norm. This definition was made more precise by Gowers and Wolf, who then defined the ")#emph[#text("true complexity")]#text(" of a form ")#mi("{\\Lambda^{P_1,\\dots,P_m}}")#text(" to be the least ")#mi("{s}")#text(" such that ")#mi("{\\Lambda^{P_1,\\dots,P_m}}")#text(" is controlled by the ")#mi("{U^{s+1}[N]}")#text(" norm. For instance,")

#list(
[#mi("{\\Lambda^{\\mathrm{n}}}")#text(" and ")#mi("{\\Lambda^{\\mathrm{n}, \\mathrm{n} + \\mathrm{r}}}")#text(" have true complexity ")#mi("{0}")#text(";")],
[#mi("{\\Lambda^{\\mathrm{n}, \\mathrm{n} + \\mathrm{r}, \\mathrm{n} + \\mathrm{2r}}}")#text(" has true complexity ")#mi("{1}")#text(";")],
[#mi("{\\Lambda^{\\mathrm{n}, \\mathrm{n} + \\mathrm{r}, \\mathrm{n} + \\mathrm{2r}, \\mathrm{n} + \\mathrm{3r}}}")#text(" has true complexity ")#mi("{2}")#text(";")],
[#text("The form ")#mi("{\\Lambda^{\\mathrm{n}, \\mathrm{n}+2}}")#text(" (which among other things could be used to count twin primes) has infinite true complexity (which is quite unfortunate for applications).")]
)

#text("Roughly speaking, patterns of complexity ")#mi("{1}")#text(" or less are amenable to being studied by classical Fourier analytic tools (the Hardy-Littlewood circle method); patterns of higher complexity can be handled (in principle, at least) by the methods of higher order Fourier analysis; and patterns of infinite complexity are out of range of both methods and are generally quite difficult to study. See ")#link("https://terrytao.wordpress.com/wp-content/uploads/2021/07/higher-order-fourier-analysis.pdf")[#text("these recent slides of myself")]#text(" (or ")#link("https://www.him.uni-bonn.de/programs/current-trimester-program/harmonic-analysis-and-analytic-number-theory/tao-lecture-series/")[#text("this video of the lecture")]#text(") for some further discussion.")

#text("Gowers and Wolf formulated a conjecture on what this complexity should be, at least for linear polynomials ")#mi("{P_1,\\dots,P_m}")#text("; Ben Green and I thought we had resolved this conjecture ")#link("https://terrytao.wordpress.com/2010/02/12/an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/")[#text("back in 2010")]#text(", though it turned out ")#link("https://terrytao.wordpress.com/2020/11/26/a-correction-to-an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/")[#text("there was a subtle gap in our arguments")]#text(" and we were only able to resolve the conjecture in a partial range of cases. However, the full conjecture was recently ")#link("https://arxiv.org/abs/2106.15437")[#text("resolved by Daniel Altman")]#text(".")

#text("The ")#mi("{U^1}")#text(" (semi-)norm is so weak that it barely controls any averages at all. For instance the average")

#align(center)[#tao-fit-display[#mitex("\\Lambda^{2\\mathrm{n}}(f) = \\mathop{\\bf E}_{n \\in [N], \\text{ even}} f(n)")]]

#text("is not controlled by the ")#mi("{U^1[N]}")#text(" semi-norm: it is perfectly possible for a ")#mi("{1}")#text("-bounded function ")#mi("{f: [N] \\rightarrow {\\bf C}}")#text(" to even have vanishing ")#mi("{U^1([N])}")#text(" norm but have large value of ")#mi("{\\Lambda^{2\\mathrm{n}}(f)}")#text(" (consider for instance the parity function ")#mi("{f(n) := (-1)^n}")#text(").")

#text("Because of this, I propose inserting an additional norm in the Gowers uniformity norm hierarchy between the ")#mi("{U^1}")#text(" and ")#mi("{U^2}")#text(" norms, which I will call the ")#mi("{U^{1^+}}")#text(" (or “profinite ")#mi("{U^1}")#text("“) norm:")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f\\right\\|_{U^{1^+}[N]} := \\frac{1}{N} \\sup_P \\left|\\sum_{n \\in P} f(n)\\right| = \\sup_P \\left| \\mathop{\\bf E}_{n \\in [N]} f 1_P(n)\\right|", block: true)]]

#text("where ")#mi("{P}")#text(" ranges over all arithmetic progressions in ")#mi("{[N]}")#text(". This can easily be seen to be a norm on functions ")#mi("{f: [N] \\rightarrow {\\bf C}}")#text(" that controls the ")#mi("{U^1[N]}")#text(" norm. It is also basically controlled by the ")#mi("{U^2[N]}")#text(" norm for ")#mi("{1}")#text("-bounded functions ")#mi("{f}")#text("; indeed, if ")#mi("{P}")#text(" is an arithmetic progression in ")#mi("{[N]}")#text(" of some spacing ")#mi("{q \\geq 1}")#text(", then we can write ")#mi("{P}")#text(" as the intersection of an interval ")#mi("{I}")#text(" with a residue class modulo ")#mi("{q}")#text(", and from Fourier expansion we have")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{n \\in [N]} f 1_P(n) \\ll \\sup_\\alpha \\left|\\mathop{\\bf E}_{n \\in [N]} f 1_I(n) e(\\alpha n)\\right|.", block: true)]]

#text("If we let ")#mi("{\\psi}")#text(" be a standard bump function supported on ")#mi("{[-1,1]}")#text(" with total mass and ")#mi("{\\delta>0}")#text(" is a parameter then")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} f 1_I(n) e(\\alpha n)")]]

#align(center)[#tao-fit-display[#mitex("\\ll |\\mathop{\\bf E}_{n \\in [-N,2N]; h, k \\in [-N,N]} \\frac{1}{\\delta} \\psi(\\frac{h}{\\delta N})")]]

#align(center)[#tao-fit-display[#mitex("1_I(n+h+k) f(n+h+k) e(\\alpha(n+h+k))|")]]

#tao-aligned(keep: true)[


#tao-math(" & \\ll \\left|\\mathop{\\bf E}_{n \\in [-N,2N]; h, k \\in [-N,N]} \\frac{1}{\\delta} \\psi(\\frac{h}{\\delta N}) 1_I(n+k) f(n+h+k) e(\\alpha(n+h+k))\\right|", block: true)



#tao-math(" & + \\delta", block: true)
]

#text("(extending ")#mi("{f}")#text(" by zero outside of ")#mi("{[N]}")#text("), as can be seen by using the triangle inequality and the estimate")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{h \\in [-N,N]} \\frac{1}{\\delta} \\psi(\\frac{h}{\\delta N}) 1_I(n+h+k) - \\mathop{\\bf E}_{h \\in [-N,N]} \\frac{1}{\\delta} \\psi(\\frac{h}{\\delta N}) 1_I(n+k)")]]

#align(center)[#tao-fit-display[#mitex("\\ll (1 + \\mathrm{dist}(n+k, I) / \\delta N)^{-2}.")]]

#text("After some Fourier expansion of ")#mi("{\\delta \\psi(\\frac{h}{\\delta N})}")#text(" we now have")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} f 1_P(n) \\ll \\frac{1}{\\delta} \\sup_{\\alpha,\\beta} |\\mathop{\\bf E}_{n \\in [N]; h, k \\in [-N,N]} e(\\beta h + \\alpha (n+h+k))")]]

#align(center)[#tao-fit-display[#mitex("1_P(n+k) f(n+h+k)| + \\delta.")]]

#text("Writing ")#mi("{\\alpha h + \\alpha(n+h+k)}")#text(" as a linear combination of ")#mi("{n, n+h, n+k}")#text(" and using the Gowers–Cauchy–Schwarz inequality, we conclude")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{n \\in [N]} f 1_P(n) \\ll \\frac{1}{\\delta} \\left\\|f\\right\\|_{U^2([N])} + \\delta", block: true)]]

#text("hence on optimising in ")#mi("{\\delta}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f\\right\\|_{U^{1^+}[N]} \\ll \\left\\|f\\right\\|_{U^2[N]}^{1/2}.", block: true)]]

#text("Forms which are controlled by the ")#mi("{U^{1^+}}")#text(" norm (but not ")#mi("{U^1}")#text(") would then have their true complexity adjusted to ")#mi("{0^+}")#text(" with this insertion.")

#text("The ")#mi("{U^{1^+}}")#text(" norm recently appeared implicitly in ")#link("https://arxiv.org/abs/1903.02592")[#text("work of Peluse")]#text(" ")#link("https://arxiv.org/abs/2003.04122")[#text("and Prendiville")]#text(", who showed that the form ")#mi("{\\Lambda^{\\mathrm{n}, \\mathrm{n}+\\mathrm{r}, \\mathrm{n}+\\mathrm{r}^2}(f,g,h)}")#text(" had true complexity ")#mi("{0^+}")#text(" in this notation (with polynomially strong bounds). [Actually, strictly speaking this control was only shown for the third function ")#mi("{h}")#text("; for the first two functions ")#mi("{f,g}")#text(" one needs to localize the ")#mi("{U^{1^+}}")#text(" norm to intervals of length ")#mi("{\\sim \\sqrt{N}}")#text(". But I will ignore this technical point to keep the exposition simple.] The weaker claim that ")#mi("{\\Lambda^{\\mathrm{n}, \\mathrm{n}+\\mathrm{r}^2}(f,g)}")#text(" has true complexity ")#mi("{0^+}")#text(" is substantially easier to prove (one can apply the circle method together with Gauss sum estimates).")

#text("The well known inverse theorem for the ")#mi("{U^2}")#text(" norm tells us that if a ")#mi("{1}")#text("-bounded function ")#mi("{f}")#text(" has ")#mi("{U^2[N]}")#text(" norm at least ")#mi("{\\eta}")#text(" for some ")#mi("{0 < \\eta < 1}")#text(", then there is a Fourier phase ")#mi("{n \\mapsto e(\\alpha n)}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{n \\in [N]} f(n) e(-\\alpha n)\\right| \\gg \\eta^2;", block: true)]]

#text("this follows easily from ")#link(<tao-4ce7bcf6e148d5048b8e>)[#text("(1)")]#text(" and Plancherel’s theorem. Conversely, from the Gowers–Cauchy–Schwarz inequality one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{n \\in [N]} f(n) e(-\\alpha n)\\right| \\ll \\left\\|f\\right\\|_{U^2[N]}.", block: true)]]

#text("For ")#mi("{U^1[N]}")#text(" one has a trivial inverse theorem; by definition, the ")#mi("{U^1[N]}")#text(" norm of ")#mi("{f}")#text(" is at least ")#mi("{\\eta}")#text(" if and only if")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{n \\in [N]} f(n)\\right| \\geq \\eta.", block: true)]]

#text("Thus the frequency ")#mi("{\\alpha}")#text(" appearing in the ")#mi("{U^2}")#text(" inverse theorem can be taken to be zero when working instead with the ")#mi("{U^1}")#text(" norm.")

#text("For ")#mi("{U^{1^+}}")#text(" one has the intermediate situation in which the frequency ")#mi("{\\alpha}")#text(" is not taken to be zero, but is instead major arc. Indeed, suppose that ")#mi("{f}")#text(" is ")#mi("{1}")#text("-bounded with ")#tao-math("{\\left\\|f\\right\\|_{U^{1^+}[N]} \\geq \\eta}", block: false)#text(", thus")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{n \\in [N]} 1_P(n) f(n)\\right| \\geq \\eta", block: true)]]

#text("for some progression ")#mi("{P}")#text(". This forces the spacing ")#mi("{q}")#text(" of this progression to be ")#mi("{\\ll 1/\\eta}")#text(". We write the above inequality as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{n \\in [N]} 1_{n=b\\ (q)} 1_I(n) f(n)\\right| \\geq \\eta", block: true)]]

#text("for some residue class ")#mi("{b\\ (q)}")#text(" and some interval ")#mi("{I}")#text(". By Fourier expansion and the triangle inequality we then have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{n \\in [N]} e(-an/q) 1_I(n) f(n)\\right| \\geq \\eta", block: true)]]

#text("for some integer ")#mi("{a}")#text(". Convolving ")#mi("{1_I}")#text(" by ")#mi("{\\psi_\\delta: n \\mapsto \\frac{1}{N\\delta} \\psi(\\frac{n}{N\\delta})}")#text(" for ")#mi("{\\delta}")#text(" a small multiple of ")#mi("{\\eta}")#text(" and ")#mi("{\\psi}")#text(" a Schwartz function of unit mass with Fourier transform supported on ")#mi("{[-1,1]}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{n \\in [N]} e(-an/q) (1_I * \\psi_\\delta)(n) f(n)\\right| \\gg \\eta.", block: true)]]

#text("The Fourier transform ")#mi("{\\xi \\mapsto \\sum_n 1_I * \\psi_\\delta(n) e(- \\xi n)}")#text(" of ")#mi("{1_I * \\psi_\\delta}")#text(" is bounded by ")#mi("{O(N)}")#text(" and supported on ")#mi("{[-\\frac{1}{\\delta N},\\frac{1}{\\delta N}]}")#text(", thus by Fourier expansion and the triangle inequality we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{n \\in [N]} e(-an/q) e(-\\xi n) f(n)\\right| \\gg \\eta^2", block: true)]]

#text("for some ")#mi("{\\xi \\in [-\\frac{1}{\\delta N},\\frac{1}{\\delta N}]}")#text(", so in particular ")#mi("{\\xi = O(\\frac{1}{\\eta N})}")#text(". Thus we have")

#metadata(none) <tao-6f649068410fa68f5c46>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|\\mathop{\\bf E}_{n \\in [N]} f(n) e(-\\alpha n)\\right| \\gg \\eta^2", block: true)]]

#text("for some ")#mi("{\\alpha}")#text(" of the major arc form ")#mi("{\\alpha = \\frac{a}{q} + O(1/\\eta)}")#text(" with ")#mi("{1 \\leq q \\leq 1/\\eta}")#text(". Conversely, for ")#mi("{\\alpha}")#text(" of this form, some routine summation by parts gives the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{n \\in [N]} f(n) e(-\\alpha n)\\right| \\ll \\frac{q}{\\eta} \\left\\|f\\right\\|_{U^{1^+}[N]} \\ll \\frac{1}{\\eta^2} \\left\\|f\\right\\|_{U^{1^+}[N]}", block: true)]]

#text("so if ")#link(<tao-6f649068410fa68f5c46>)[#text("(2)")]#text(" holds for a ")#mi("{1}")#text("-bounded ")#mi("{f}")#text(" then one must have ")#tao-math("{\\left\\|f\\right\\|_{U^{1^+}[N]} \\gg \\eta^4}", block: false)#text(".")

#text("Here is a diagram showing some of the control relationships between various Gowers norms, multilinear forms, and duals of classes ")#mi("{{\\mathcal F}}")#text(" of functions (where each class of functions ")#mi("{{\\mathcal F}}")#text(" induces a dual norm ")#tao-math("{\\left\\| f \\right\\|_{{\\mathcal F}^*} := \\sup_{\\phi \\in {\\mathcal F}} \\mathop{\\bf E}_{n \\in[N]} f(n) \\overline{\\phi(n)}}", block: false)#text(":")

#image("../assets/55034473493a66a3f2b8eb75716fa79fe56706b1752ab854d892d2f8ccff0f3e-8c8adf1890bef38a9745adb5f2deeab0d511c0b337c9472ffa04971f3c122df4.png", width: 90%)

#text("Here I have included the three classes of functions that one can choose from for the ")#mi("{U^3}")#text(" inverse theorem, namely degree two nilsequences, bracket quadratic phases, and local quadratic phases, as well as the more narrow class of globally quadratic phases.")

#text("The Gowers norms have counterparts for measure-preserving systems ")#mi("{(X,T,\\mu)}")#text(", known as ")#emph[#text("Host-Kra seminorms")]#text(". The ")#mi("{U^1(X)}")#text(" norm can be defined for ")#mi("{f \\in L^\\infty(X)}")#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^1(X)} := \\lim_{N \\rightarrow \\infty} \\int_X |\\mathop{\\bf E}_{n \\in [N]} T^n f|\\ d\\mu", block: true)]]

#text("and the ")#mi("{U^2}")#text(" norm can be defined as")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^2(X)}^4 := \\lim_{N \\rightarrow \\infty} \\mathop{\\bf E}_{n \\in [N]} \\left\\| T^n f \\overline{f} \\right\\|_{U^1(X)}^2.", block: true)]]

#text("The ")#mi("{U^1(X)}")#text(" seminorm is orthogonal to the ")#emph[#text("invariant factor")]#text(" ")#mi("{Z^0(X)}")#text(" (generated by the (almost everywhere) invariant measurable subsets of ")#mi("{X}")#text(") in the sense that a function ")#mi("{f \\in L^\\infty(X)}")#text(" has vanishing ")#mi("{U^1(X)}")#text(" seminorm if and only if it is orthogonal to all ")#mi("{Z^0(X)}")#text("-measurable (bounded) functions. Similarly, the ")#mi("{U^2(X)}")#text(" norm is orthogonal to the ")#emph[#text("Kronecker factor")]#text(" ")#mi("{Z^1(X)}")#text(", generated by the eigenfunctions of ")#mi("{X}")#text(" (that is to say, those ")#mi("{f}")#text(" obeying an identity ")#mi("{Tf = \\lambda f}")#text(" for some ")#mi("{T}")#text("-invariant ")#mi("{\\lambda}")#text("); for ergodic systems, it is the largest factor isomorphic to rotation on a compact abelian group. In analogy to the Gowers ")#mi("{U^{1^+}[N]}")#text(" norm, one can then define the Host-Kra ")#mi("{U^{1^+}(X)}")#text(" seminorm by")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^{1^+}(X)} := \\sup_{q \\geq 1} \\frac{1}{q} \\lim_{N \\rightarrow \\infty} \\int_X |\\mathop{\\bf E}_{n \\in [N]} T^{qn} f|\\ d\\mu;", block: true)]]

#text("it is orthogonal to the ")#emph[#text("profinite factor")]#text(" ")#mi("{Z^{0^+}(X)}")#text(", generated by the periodic sets of ")#mi("{X}")#text(" (or equivalently, by those eigenfunctions whose eigenvalue is a root of unity); for ergodic systems, it is the largest factor isomorphic to rotation on a profinite abelian group.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (25)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52199fa021c337c1315ca742cb5f11ddbb063546fdfab7b8e3ffdfe5bf11cf1b-7c732e386466770316e978619f8228a1388b783fbcf060fc75f647127b3efab3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Freddie Manners")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-631871")[#strong[#text("Freddie Manners")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2021")])]

#text("Is it possible to state precisely, in terms of this ")#mi("U^{1^+}")#text(" norm, what “true complexity” bound would suffice to generalize results of Peluse and Prendiville to general polynomial patterns of true complexity ")#mi("0^+")#text("? They make some statements in their papers but I have not fully translated between those and these more concise ")#mi("U^{1+}")#text(" statements.")

#text("There seemed to be some subtlety about whether you have ")#mi("U^{1^+}")#text(" control in one position or all positions, which determines whether you can get ")#mi("\\log^c")#text(" or ")#mi("\\log \\log^c")#text(", but I could be wrong about that.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-631879")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2021")])]

#text("I think in the notation of this blog post, the two papers of Peluse and Prendiville show bounds of the form")

#tao-math("\\displaystyle \\Lambda^{\\mathrm{n}, \\mathrm{n}+\\mathrm{r}, \\mathrm{n}+\\mathrm{r}^2}(f,g,h) \\ll \\min( \\left\\| f \\right\\|_{U^{1^+}_{\\sqrt{N}}[N]}, \\left\\| g \\right\\|_{U^{1^+}_{\\sqrt{N}}[N]}, \\left\\| h \\right\\|_{U^{1^+}[N]})^c", block: false)

#text("for ")#mi("1")#text("-bounded ")#mi("f,g,h")#text(", where the subscript here denotes a local version of the ")#mi("U^{1^+}")#text(" norm,")

#tao-math("\\displaystyle \\left\\|f\\right\\|_{U^{1^+}_{\\sqrt{N}}[N]} = {\\bf E}_{n_0 \\in [N]} \\sup_{P} \\left|{\\bf E}_{n \\in [n_0,n_0+\\sqrt{N}]} f 1_P(n)\\right|.", block: false)

#text("This localisation is necessary because of the scenario in which ")#mi("f,g")#text(" are locally constant at scale ")#mi("\\sqrt{N}")#text(" at which point the form ")#mi("\\Lambda^{\\mathrm{n}, \\mathrm{n}+\\mathrm{r}, \\mathrm{n}+\\mathrm{r}^2}(f,g,h)")#text(" basically collapses to ")#mi("\\Lambda^{\\mathrm{n}, \\mathrm{n}+\\mathrm{r}^2}(fg,h)")#text(" and one can no longer exploit any further uniformity of the individual functions ")#mi("f,g")#text(".")

#text("I have heard from Sarah that analogous results are now known for any average involving polynomials of distinct degree, but this work might not be publicly available yet. I’m not sure what the situation is for the polynomial patterns that are suspected to be of complexity ")#mi("0^+")#text(" but do not have distinct degrees.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52199fa021c337c1315ca742cb5f11ddbb063546fdfab7b8e3ffdfe5bf11cf1b-7c732e386466770316e978619f8228a1388b783fbcf060fc75f647127b3efab3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frederick Manners")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-631896")[#strong[#text("Frederick Manners")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2021")])]

#text("I see, thanks — that’s what’s meant above about the first two indices being different and having at best local norm control.")

#text("I think my confusion was more about the stage of the argument where you take certain ")#mi("U^{1^+}")#text("-control statements as a black box, and try to deduce the corresponding instance of the polynomial Szemerédi theorem for these configurations, with as good a bound as possible.")

#text("For illustration take ")#mi("\\Lambda^{n,n+r,n+r^2,n+r^3}")#text(". Reading a bit more of the relevant papers, I think the following are true statements in your language above:–")

#text("1. the bound")

#tao-math("\\displaystyle \\left| \\Lambda^{n,n+r,n+r^2,n+r^3}(f_0,f_1,f_2,f_3) \\right| \\ll \\left\\|f_1\\right\\|_{U^{1^+}_{N^{1/3}}}^c", block: false)

#text("is known, by [Peluse, “Bounds for sets with no polynomial progressions”], and as a black box this inequality enough to deduce polynomial Szemerédi for ")#mi("(n,n+r,n+r^2,n+r^3)")#text(" for densities ")#mi("\\log \\log^c")#text(" (by vanilla density increment);")

#text("2. the comments in [“A polylogarithmic bound in the non-linear Roth theorem”, Section 7] seem to suggest that if we knew")

#tao-math("\\displaystyle \\left| \\Lambda^{n,n+r,n+r^2,n+r^3}(f_0,f_1,f_2,f_3) \\right| \\ll \\min \\left( \\left\\|f_0\\right\\|_{U^{1^+}_{N^{1/3}}}, \\left\\|f_1\\right\\|_{U^{1^+}_{N^{1/3}}}, \\left\\|f_2\\right\\|_{U^{1^+}_{N^{2/3}}}, \\left\\|f_3\\right\\|_{U^{1^+}} \\right)^c", block: false)

#text("then we could feed that into the more powerful “multiplicative gain” density increment machine, essentially as a black box, to get a ")#mi("\\log^c")#text(" bound (not currently known in the published literature).")

#text("I’m not 100% sure this summary is accurate; hopefully I can be corrected if not.")

#text("It is a little surprising in this picture (if correct) that you could get control over one ")#mi("f_i")#text(" but not the others, so either I’ve misunderstood, or it is a (plausible) quirk of the proofs that the lowest-degree polynomial is somehow special. I guess it seems this issue has been resolved in unpublished work and the better bound is now known.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-631926")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2021")])]

#text("One probably needs to talk to Sarah or Sean for the most up to date status of this problem, but it is certainly easier to use the global ")#mi("U^{1^+}")#text(" norm for density increment purposes with polylogarithmic bounds than the local one if it is available to control the multilinear form, and in the case of say ")#mi("n,n+r,n+r^2,n+r^3")#text(" it is only the fourth function ")#mi("f_3")#text(" that has any hope of being controlled by the global norm, for the geometric reason that ")#mi("n+r^3")#text(" is the only element of this quadruple that is very well separated (distance ")#mi("\\sim N")#text(") from the rest of the quadruple for typical values of ")#mi("r")#text(". But it seems with Sarah and Sean’s approach that ")#mi("f_3")#text(" is the hardest function to get their estimates for; they initially only get to control the form in terms of ")#mi("f_0,f_1")#text(" and then struggle to move up to ")#mi("f_2")#text(" and then to ")#mi("f_3")#text(". But once they get control by the global norm of ")#mi("f_3")#text(" I would imagine that their multiplicative-gain density increment approach would work, at least for the first increment, though for subsequent increments one may need to keep careful track of how the coefficients of the (renormalised) polynomials are growing.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f680d6065b871d86ea59304a47fa11d01d4c98420243df99780c7e65066572bd-d1e10746ec1254ecd362392a7ec6eebe4f94143890139bd0da21465438ad5a88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Prendiville")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-632012")[#strong[#text("Sean Prendiville")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2021")])]

#text("Personally, I am confident that the argument sketched in §7.1 of ")#link("https://arxiv.org/abs/2003.04122")[#text("https://arxiv.org/abs/2003.04122")]#text(" should yield control of all functions (and hence poly-logarithmic bounds) for distinct-degree progressions.")

#text("In order to implement the strategy sketched, it seems like one cannot use Sarah’s very general results (")#link("https://arxiv.org/abs/1909.00309")[#text("https://arxiv.org/abs/1909.00309")]#text(") as a black box, and must re-run her arguments with mildly more general hypotheses (although we did not think too hard about bootstrapping her results to give the more general statements required). I could be entirely mistaken, but the obstructions appear to be only technical (albeit lengthy). Sarah or others may have since thought more about this.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a36759ca0ad47beb4d4ff93618bbe77b838afcb0fc0cc5d20115104799214b3-79160095b82466f3b5c3c39a031d47f4b92afbae09e26c02967958f825fb9e98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vivian")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-631872")[#strong[#text("Vivian")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2021")])]

#text("Thank you, Professor Tao")

#text("Sent from my iPhone")

#text(">")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77e0f45b2c163f0db68f67758a4ed40b468150c428e3fd740a0545437246f519-693cd4831cb7723793e26d53603a281f8175d5e0b6513d001030a7742d2dbf54.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-631923")[#strong[#text("Mark")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2021")])]

#text("Can you explain how does")

#tao-math("\\displaystyle  \\left|\\mathop{\\bf E}_{n \\in [N]} e(-an/q) 1_I(n) f(n)\\right| \\geq \\eta", block: false)

#text("implies")

#tao-math("\\displaystyle  \\left|\\mathop{\\bf E}_{n \\in [N]} e(-an/q) (1_I * \\psi_\\delta)(n) f(n)\\right| \\gg \\eta", block: false)#linebreak()#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-631927")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2021")])]

#text("This follows from ")#mi("L^1")#text(" estimates on ")#tao-math("\\left|1_I - 1_I * \\psi_\\delta\\right|", block: false)#text(" and the triangle inequality (the errors picked up are of size ")#mi("O(\\delta)")#text(" and can be absorbed into the right-hand side by letting ")#mi("\\delta")#text(" be a sufficiently small multiple of ")#mi("\\eta")#text("). The ")#mi("L^1")#text(" estimate follows in turn from the decay and unit mass properties of ")#mi("\\psi_\\delta")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/525dc816d22c9058c3171cfe4ab5559419ddb1d2df61e9b9830586d3a1240bbd-bf0e93343a6fc132cc9759a4e8da8ccf896a61a0173c8d6b68851263077103f9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lillian")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-631929")[#strong[#text("Lillian")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2021")])]

#text("Could you please give a brief explanation for the inequality")

#tao-math("\\displaystyle  \\mathop{\\bf E}_{n \\in [N]} f 1_P(n) \\ll \\left|\\mathop{\\bf E}_{n \\in [N]; h, k \\in [-N,N]} \\frac{1}{\\delta} \\psi(\\frac{h}{\\delta N}) 1_{q|h} 1_P(n+k) f(n+h+k)\\right| + \\delta", block: false)

#text("It looks plausible, but I can’t quite convince myself it is correct. For example, I don’t really see where does ")#mi("+\\delta")#text(" on the RHS come from?")

#emph[#text("[Fixed some typos and added further explanation -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/846afa485064000606a8bea15e40a1e4e03041e965633c8cebcf0a78542a17c6-096dce8defe685996cc9d3c050bbf9c8a230ec1f7176b58d638adbc545a9bd16.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yasmin")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-631935")[#strong[#text("yasmin")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2021")])]

#text("Dear Prof Tao,")#linebreak()#text(" I have two questions:")#linebreak()#text(" “The Fourier transform of {1_I * \\psi_\\delta} is bounded and supported on {[-1/\\delta,1/\\delta]}”")#linebreak()#text(" – What is the normalisation here? Isn’t $(1_I * \\psi_\\delta)^\\hat (0) = (1_I)\\hat (0) (\\psi_\\delta)^ (0) = |I| \\sim N$ which is unbounded?")

#text("“{\\alpha = \\frac{a}{q} + O(1/\\eta)}”")#linebreak()#text(" – Isn’t the O-term here larger than the main term (a/q)?")

#emph[#text("[Fixed some typos and added further explanation -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10b50fc38518f7946e5dfab15edcc2b8cb5a8c4808a802d3cdbcd3f4ff5c5b10-4c6b6c8da20edd569432113f173f867bfaa101f8740a40c256b7eb4ed74e87ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Griesmer")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-631937")[#strong[#text("John Griesmer")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2021")])]

#text("It may be worth mentioning that the true complexity of ")#mi("(n, n+r, n+r^2)")#text(" for ergodic averages was determined by ")#link("https://doi.org/10.1515/9783110889383.193")[#text("Furstenberg and Weiss [FW96]")]#text(", and for polynomial expressions of the form ")#mi("(n, n+p(r), n+q(r), n + s(r))")#text(" by ")#link("https://arxiv.org/abs/math/0606567")[#text("Frantzikinakis (arxiv:0606567)")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-632044")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2021")])]

#text("Could you post your last Friday’s lecture slides on HIM website? You skipped many slides, and would be helpful for students who are new to the subject.")

#emph[#text("[Slides are now posted – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e00da20f9205b53730ddc7db8b57e7573e0c606d899ea012a788630df017b39-8294e8c97cdb46126c0fd0e5b3f29ef06693e4dc95327ff4debaec66480393b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan Norris")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-632072")[#strong[#text("Ryan Norris")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2021")])]

#text("When you do the Fourier expansion of psi(h/delta N) (I assume you are thinking of it as function in integer variable h) to obtain coefficient beta, don’t you need an L^1 upper bound of quality O(1) for its Fourier transform to get the desired conclusion? It’s support is [0,1], but the largest value (coming from zeroth coefficient) is delta*N, which doesn’t seem to be good enough. Or did I mess up the normalisation somewhere?")

#emph[#text("[Because of the rapid decay of the Fourier transform of ")#mi("\\psi")#text(", the Fourier transform of ")#mi("\\psi(h/\\delta N)")#text(" is effectively localised to an interval of length ")#mi("O(1/\\delta N)")#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-632082")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2021")])]

#text("Trivial typo, but in the definition of the multilinear form in the displayed equation after (1), the ")#mi("f")#text(" on the RHS should be an ")#mi("f_j")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f0b9a908987dfdfc75dae02356a635e8ff78f8d3d1ca98913514ae4baf88d46-d00c0befd789903b432aea6071945fa92bf8636b4820e83fbd2e6a03dea15f9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-632095")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2021")])]

#text("For which class of forms does it make sense to define the complexity? I think Gowers and Wolf defined it only for multilinear forms arising from systems of linear equations, which wouldn’t include the Peluse-Prendiville example (or other examples arising in the work of Peluse and Peluse-Prendiville).")

#text("I am worried about the following phenomenon: Suppose we have a multilinear form which is controlled very nicely by a norm which is easy to work with, but happens to not be a Gowers norm. Should we really then say it has complexity infinity?")

#text("I was also a bit concerned with whether, if we prove a multilinear form is controlled by a simple norm using a complicated inductive process that passes through the first 10 Gowers norm, it is reasonable to say the problem is complexity 0 just because the final statement doesn’t involve any Gowers norms, but I can’t really complain because a version of this occurs already in the paper of Gowers and Wolf.")

#text("I guess one would like to have a heuristic conjecture along the lines of “If this multilinear form is controlled by any nice norm, then it is controlled by some Gowers norm”. Is it reasonable to believe this for translation-invariant multilinear forms, say, which would include the progressions and Peluse-Prendiville examples?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52199fa021c337c1315ca742cb5f11ddbb063546fdfab7b8e3ffdfe5bf11cf1b-7c732e386466770316e978619f8228a1388b783fbcf060fc75f647127b3efab3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Freddie Manners")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-632097")[#strong[#text("Freddie Manners")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2021")])]

#text("“I guess one would like to have a heuristic conjecture along the lines of “If this multilinear form is controlled by any nice norm, then it is controlled by some Gowers norm”.”")

#text("It is almost certainly hard to formulate such a conjecture correctly, but I think it should be true-ish in some settings once you eliminate ways in which it is not true.")

#text("For instance, I think the case of polynomial multilinear averages over finite fields should be fairly solid. That is, given polynomials ")#mi("P_i : \\mathbb{F}_p^d \\to \\mathbb{F}_p")#text(", averages")

#mi("\\displaystyle E_{v_1,\\dots,v_d \\in F_p^{n}} f_1(P_1(v_1,\\dots,v_d)) \\dots f_k(P_k(v_1,\\dots,v_d))")

#text("should be controlled by a norm ")#mi("U^{s+1}")#text(" for some “complexity” s depending on the polynomials, such that if it is controlled by any other norm, that norm control is, in some very vague sense, a weaker statement than ")#mi("U^{s+1}")#text(" control.")

#text("(In “vague” I include things such as UAP norms or generalized-convolution-cut-norms, which are loosely but not actually equivalent to Gowers norms.)")

#text("The point is that you can consider which 1-bounded functions in your norm have ")#tao-math("\\left\\|f\\right\\| = 1", block: false)#text(". For Gowers norms, these will be phase polynomials ")#mi("f(x) = \\exp(2 \\pi i P(x))")#text(" for ")#mi("P")#text(" a polynomial of degree ")#mi("s")#text(". Because there is no such thing as a polynomial of degree 1.5, and because extremal functions of polynomial multilinear averages are also basically phase polynomials, and for other reasons, I’m willing to guess that the Gowers norm hierarchy is the full story, as per your heuristic conjecture.")

#text("Certainly one case where things get more complicated is when you allow “functions in more than one variable”. For example, consider the multilinear average")

#mi("\\displaystyle E_{x,y,z,w \\in \\mathbb{F}_p^n} A(x,y) B(x,z) C(w,y) D(w,z).")

#text("(Feel free to disguise this in terms of multilinear forms by adding spurious plus signs.)")

#text("This is controlled by the Schatten-4 norm, or basically any other spectral norm, but the Schatten-4 norm is of interest because it “looks like” a Gowers norm. However, it is certainly meaningful to say that this has true complexity infinity because it fails to be controlled by any true Gowers norm on ")#mi("\\displaystyle \\mathbb{F}_p^{2n}")#text(". But Schatten-4 control is clearly better than nothing. Maybe this realizes your concern.")

#text("In general you will have a raft of different possible norm controls, often incomparable, based on what their 100% functions look like (e.g., things like “all at most quadratic functions ")#mi("\\displaystyle F(x,y,z)")#text("” and “all at most trilinear functions ")#mi("\\displaystyle F(x,y,z)")#text("” can all be assigned norms). But they should still be *coarsely* classified by degree: in other words, such norms should always fit between two consecutive Gowers norms, or fall off one end of the list. I think that coarse measure is what should be understood by complexity in this generality, while understanding that it is not the full story.")

#text("For polynomial forms in one variable over the integers, you certainly need to include “local” Gowers norms, where certain parameters are constrained to have local sizes, as Terry points out above. I don’t know how fine the hierarchy of such local norms is: it seems plausible that you can mimic the difficulties arising for functions in several variables by using different scales as if they were different variables, but I have not thought hard about this.")

#text("Not sure if that answers any of your questions satisfactorily.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-632203")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2021")])]

#text("I agree with basically everything Freddie said. In general one would expect the notion of complexity to take values in some weird partially ordered set, where some norms control others but there is no obvious reason why there should be a total ordering. But in the case of one-dimensional averages at a given spatial scale there does seem to be this remarkable phenomenon that there is this one-dimensional hierarchy of Gowers norms ")#mi("U^{s+1}")#text(" that control everything (after belatedly adding this final norm ")#mi("U^{1+}")#text(" to the hierarchy). For instance, the “")#mi("u^3")#text(" norm” that comes from taking the maximal inner product of ")#mi("f")#text(" against a globally quadratic phase (as opposed to a locally quadratic phase) is intermediate in strength between the ")#mi("U^2")#text(" and ")#mi("U^3")#text(" norms (as depicted on the diagram in the blog post, where it is labeled ")#mi("\\mathrm{quad.}^*")#text("), but does not seem to be associated as the true complexity of any polynomial average, as far as I know; any average that is sensitive to globally quadratic phases is automatically also sensitive to locally quadratic phases (or degree 2 nilsequences, or bracket quadratic phases) and thus is really controlled by ")#mi("U^3")#text(" rather than ")#mi("u^3")#text(". As such the ")#mi("u^3")#text(" norm plays only a very minor role in additive combinatorics.")

#text("It reminds me a bit of the phenomenon in ")#link("https://en.wikipedia.org/wiki/Reverse_mathematics")[#text("reverse mathematics")]#text(", where one would a priori expect a hugely complicated partially ordered set of theories of arithmetic where various theorems in analysis (Bolzano-Weierstrass, Heine-Borel, etc.) naturally live, but instead one ends up with a “big five” of arithmetic theories (")#mi("RCA_0")#text(", ")#mi("WKL_0")#text(", etc.) which are basically the “complexity” for the vast majority of such theorems.")

#text("The situation is currently understood the best in the ergodic theory setting, where the analogue of the notion of complexity is known as the “characteristic factor” – the maximal factor ")#mi("Z")#text(" of a given system ")#mi("X")#text(" in which all functions ")#mi("f \\in L^\\infty(X)")#text(" orthogonal to ")#mi("L^2(Z)")#text(" (or equivalently, all functions ")#mi("f \\in L^\\infty(X)")#text(" with vanishing conditional expectation ")#mi("{\\bf E}(f|Z)")#text(" are negligible for a given ergodic average. For any given multiple polynomial average we now know that the characteristic factor is always one of the Host-Kra factors ")#mi("Z^s(X)")#text(", or the profinite factor ")#mi("Z^{0+}(X)")#text(" (modulo some minor technicalities at small primes where there is “ramification”), though the proof proceeds by first controlling things by some Host-Kra seminorm ")#mi("\\| \\|_{U^{s+1}}")#text(" (the analogue of the Gowers norm in the ergodic setting) of enormous degree and then whittling down the degree. Perhaps as the degree-lowering theory matures we will have a better understanding of where true complexity actually comes from and why the Gowers uniformity hierarchy is pretty much all that shows up, but the phenomenon still only partially understood at present.")

#text("As discussed in other comments, the situation seems to be markedly different in the setting of polynomial averages over finite fields, where there are many more algebraic obstructions in play.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10b50fc38518f7946e5dfab15edcc2b8cb5a8c4808a802d3cdbcd3f4ff5c5b10-4c6b6c8da20edd569432113f173f867bfaa101f8740a40c256b7eb4ed74e87ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Griesmer")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-632206")[#strong[#text("John Griesmer")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2021")])]

#text("There are polynomial averages whose characteristic factor is strictly between ")#mi("Z^{1}")#text(" and ")#mi("Z^{2}")#text(" (and therefore is not one of the ")#mi("Z^s")#text(" or ")#mi("Z^{0+}")#text("): Theorem B of ")#link("https://arxiv.org/abs/math/0606567")[#text(" Frantzikinakis’s three polynomials paper")]#text(" shows that the characteristic factor for ")#mi("\\frac{1}{N}\\sum_{n=1}^N f\\circ T^n\\cdot f\\circ T^{2n}\\cdot f\\circ T^{n^2}")#text(" is the maximal 2 step affine factor of ")#mi("X")#text(", which is (often) strictly between ")#mi("Z^1(X)")#text(" and ")#mi("Z^2(X)")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-632209")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2021")])]

#text("Huh, I was not aware of this very interesting example! On the algebraic side it seems to boil down to the identity")

#mi("\\displaystyle \\alpha (n^2+2n) - 2 \\alpha (n+r)^2 + \\alpha(n+2r)^2 - 2\\alpha(n+r^2) = 0")

#text("for real ")#mi("\\alpha")#text(" which shows that globally quadratic phases are non-negligible for this average, but there isn’t an analogous identity (or near-identity) for locally quadratic functions. So perhaps on the combinatorial side the average ")#mi("\\Lambda^{n,n+r, n+2r, n+r^2}")#text(" is in fact controlled by the ")#mi("u^3")#text(" norm and not just the ")#mi("U^3")#text(" norm (and not by the ")#mi("U^2")#text(" norm), which would be the first example of a “complexity 1.5 pattern” that I am aware of. I stand corrected!")

#text("EDIT: a concrete conjecture in this regard would be that")

#tao-math("\\displaystyle \\Lambda^{n,n+r,n+2r,n+r^2}(f,g,h,k) \\ll \\min( \\left\\|f\\right\\|_{u^3_{\\sqrt{N}}}, \\left\\|g\\right\\|_{u^3_{\\sqrt{N}}}, \\left\\|h\\right\\|_{u^3_{\\sqrt{N}}}, \\left\\|k\\right\\|_{U^2} )^c", block: false)

#text("for some ")#mi("c>0")#text(" and all ")#mi("1")#text("-bounded ")#mi("f,g,h,k")#text(", with the obvious definitions for the local norm ")#mi("u^3_{\\sqrt{N}}")#text(". There does seem to some chance that the degree lowering machinery could stretch to cover this case without needing to touch the inverse ")#mi("U^3")#text(" theorem which currently does not enjoy polynoimal bounds.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f0b9a908987dfdfc75dae02356a635e8ff78f8d3d1ca98913514ae4baf88d46-d00c0befd789903b432aea6071945fa92bf8636b4820e83fbd2e6a03dea15f9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-632348")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2021")])]

#text("If we look at the average ")#mi("\\Lambda^{n-r, n, n+r, n+r^2, n+r^4}")#text(" then the identity ")#mi("(n-r)^3  - 2 n^3 + 3 n^2 -3n  + (n+r)^3 - 3 (n+r^2)^2  + 3 (n+r^4) = 0")#text(" appears, showing that a cubic phase in any of the first three variables is not negligible.")

#text("Are locally quadratic phases non-negligible for these functions? I don’t see why they would be, since they don’t have any special structure when polynomials are multiplied and thus they should only see the three linearly dependent terms ")#mi("n-r, n ,n+r")#text(", where we know only additive phases contribute.")

#text("So maybe the norm relevant for this example is strictly incomparable with the ")#mi("U^3")#text(" norm?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52199fa021c337c1315ca742cb5f11ddbb063546fdfab7b8e3ffdfe5bf11cf1b-7c732e386466770316e978619f8228a1388b783fbcf060fc75f647127b3efab3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Freddie Manners")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-632099")[#strong[#text("Freddie Manners")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2021")])]

#text("Actually I guess parts of this are not as mysterious as I’m trying to make it. You are essentially asking for a converse to Gowers–Wolf: for (say) a system of linear forms of complexity ")#mi("s")#text(" at index ")#mi("1")#text(", show that for all ")#mi("\\varepsilon>0")#text(" there exists ")#mi("\\delta>0")#text(" such that if ")#tao-math("\\left\\|f\\right\\|_{U^{s+1}} > \\varepsilon", block: false)#text(" then there exist 1-bounded functions ")#mi("g_2,\\dots,g_k")#text(" such that")

#tao-math("\\displaystyle \\left|\\Lambda_{\\Phi}(f, g_2,\\dots,g_k)\\right| > \\delta.", block: false)

#text("The point is that ")#mi("\\Lambda_{\\Phi}")#text(" is vacuously and optimally controlled by the “")#mi("\\Phi")#text(" cut-norm”, namely the supremum of the left-hand side over all 1-bounded functions ")#mi("g_i")#text(". Gowers–Wolf asserts that this cut-norm is bounded above (in a very weak sense) by ")#mi("U^{s+1}")#text(" for a suitably chosen ")#mi("s")#text("; this would imply the two norms are equivalent (in a very weak sense).")

#text("For systems of linear forms, or polynomial forms over finite fields, I would be fairly confident this is true, but am also confident it is not known. For polynomial forms over the integers, I have no idea what to expect.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f0b9a908987dfdfc75dae02356a635e8ff78f8d3d1ca98913514ae4baf88d46-d00c0befd789903b432aea6071945fa92bf8636b4820e83fbd2e6a03dea15f9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-632123")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2021")])]

#text("I think this is not true as you state for polynomial forms over finite fields.")

#text("For one, we could have ")#mi("P_i (v_1,v_2) = v_i v_2^{i-1}")#text(" in which case we need to use the multiplicative group Gowers norm and not the additive group Gowers norm. Probably one can even get elliptic Gowers norms to show up as well.")

#text("You could say “well, those are all really different types of Gowers norms even if they’re not literally part of the same sequence of norms” but then you could have each ")#mi("P_i")#text(" of the form ")#mi("Q_i^3 - Q_i")#text(" for other polynomials ")#mi("Q_i")#text(" and then you would need to know about the average value of your ")#mi("f_i")#text("s against the number of ways of representing them as ")#mi("x^3 - x")#text(", which is not periodic additively or multiplicatively.")

#text("There’s a lot of norms you could potentially need to get the full picture.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52199fa021c337c1315ca742cb5f11ddbb063546fdfab7b8e3ffdfe5bf11cf1b-7c732e386466770316e978619f8228a1388b783fbcf060fc75f647127b3efab3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Freddie Manners")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-632126")[#strong[#text("Freddie Manners")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2021")])]

#text("Of course you are right — I had not considered things like geometric progressions or even more badly-behaved examples. Was the point in your original post that adding “translation-invariant” is a good way to kill these off and fall back into the safe ergodic-theoretic world I probably imagined I lived in?")

#text("I think a number of my comments above could wind up being technically correct as stated if I simply bundle all these examples in as “infinite complexity”, but I guess that’s exactly the thing you objected to in the first place.")

#text("I think it is a consistent if unambitious world-view to say that “complexity” really means “degree complexity”, and has to do with cases whether the 100% solutions are necessarily phase polynomials of bounded degree; and if not, the “degree complexity” is infinite and you are on your own.")

#text("Certainly given your examples, I don’t know how to tell whether a system of polynomial forms has finite degree complexity just by looking at it, and that seems like a very natural question I would like to know the answer to.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f0b9a908987dfdfc75dae02356a635e8ff78f8d3d1ca98913514ae4baf88d46-d00c0befd789903b432aea6071945fa92bf8636b4820e83fbd2e6a03dea15f9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-632131")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2021")])]

#text("I’m not sure if translation-invariant is a good way to kill off all of these, though I suspect it might be. I asked because I thought someone else might know.")

#text("For systems of polynomial forms, or, slightly differently, systems of polynomial equations, I a while ago had an idea (inspired by some stuff Jacob Tsimerman told me) of using Galois theory to classify what kind of norms you should need for a given system, based on the theory that the worst-behaved functions for a given system of forms should be characteristic functions of sets of points with a fixed splitting behavior in a Galois cover of the line. But even proving the purely Galois-theoretic statements needed for this idea to make sense proved tricky, let alone making it actually interface with the combinatorics.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d7c1b6cb2355225c4aa81f58c25106da2b399f567af87a7508495d00d6e5f26-19de1650d1de83dd1fdbf582eeadeff0ce510532025de0101576a5993fd23004.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quân Nguyễn")]], [#link("https://terrytao.wordpress.com/2021/07/25/the-gowers-uniformity-norm-of-order-1/#comment-657000")[#strong[#text("Quân Nguyễn")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2022")])]

#text("Dear prof Tao,")#linebreak()#text(" I’ve attempted to prove but don’t know if the following identity is actually true:")

#tao-math("\\displaystyle  \\left\\|f\\right\\|_{U^k([N])} \\asymp (N \\int_{\\mathbf R \\setminus \\mathbf Z} \\left|\\mathop{\\bf E}_{n \\in [N]} f(n) e(-\\alpha n)\\right|^{2^k}\\ d\\alpha)^{2^{-k}}", block: false)

#emph[#text("[This is only true for ")#mi("k=2")#text(" – T.]")]
]
