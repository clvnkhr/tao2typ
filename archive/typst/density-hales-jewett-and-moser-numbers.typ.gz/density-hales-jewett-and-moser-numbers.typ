// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/02/04/density-hales-jewett-and-moser-numbers/
// Converted to Typst by tao2typ: "2026-10-14T08:54:14.507805+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Density Hales-Jewett and Moser numbers", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Density Hales-Jewett and Moser numbers")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 February 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/02/04/density-hales-jewett-and-moser-numbers/")[#text("https://terrytao.wordpress.com/2010/02/04/density-hales-jewett-and-moser-numbers/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded the D.H.J. Polymath article “")#link("http://arxiv.org/abs/1002.0374")[#text("Density Hales-Jewett and Moser numbers")]#text("” to the arXiv, submitted to the Szemeredi birthday conference proceedings.")

#text("This article investigates the ")#emph[#text("Density Hales-Jewett numbers")]#text(" ")#mi("c_{n,3}")#text(", defined as the largest subset of the n-dimensional cube ")#mi("[3]^n")#text(" containing no combinatorial line, as well as the related Moser numbers ")#mi("c^{\\prime}_{n,3}")#text(", defined as the largest subset of the n-dimensional cube containing no geometric line. We compute the first six numbers in each sequence in this paper. For the DHJ numbers, they are 1,2,6,18,52,150,450 and for the Moser numbers they are 1,2,6,16,43,124,353. The last two elements of both sequences are new; the computation ")#mi("c^{\\prime}_{6,3}=353")#text(" was the hardest and required a non-trivial amount of computer assistance.")

#text("We also establish the asymptotic lower bounds")

#align(center)[#tao-fit-display[#mitex("c_{n,3} \\geq 3^n \\exp( - O(\\sqrt{\\log n}) )")]]

#text("and")

#align(center)[#mi("c^{\\prime}_{n,3} \\geq (2 \\sqrt{\\frac{9}{4\\pi}} + o(1)) \\frac{3^n}{\\sqrt{n}}")#text(".")]

#text("In contrast, the best known upper bound to these quantities is ")#mi("O(3^n / \\log^{1/3}_* n)")#text(", ")#link("https://terrytao.wordpress.com/2009/10/22/a-new-proof-of-the-density-hales-jewett-theorem/")[#text("obtained by the sister project to this Polymath project")]#text(".")

#text("We also show a counterexample to a certain “hyper-optimistic conjecture” which would have generalised the ")#link("http://en.wikipedia.org/wiki/Lubell%E2%80%93Yamamoto%E2%80%93Meshalkin_inequality")[#text("Lubell-Yamamoto–Meshalkin (LYM) inequality")]#text(" to this setting.")

#text("Thanks to all the participants for this interesting experiment in collaborative mathematics. This is certainly a different type of project from the ones I normally am involved in, but I found it to be an enjoyable and educational experience.")

#text("There is still some time to make further (minor) corrections; I think the deadline for the final submission should be in April.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4259f5b59b4e7a54ecd7595690a54c8e5d51f8952c5473e634b40275c841ddb-208c5aa391ce87553ec1b820b6b558ff273d6b839a07a6e548aee99a6fefb808.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan O'Donnell")]], [#link("https://terrytao.wordpress.com/2010/02/04/density-hales-jewett-and-moser-numbers/#comment-43504")[#strong[#text("Ryan O'Donnell")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2010")])]

#text("It hardly matters since it’s on a log*, but… for the upper bounds, the power of 1/3 can be 1/2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2010/02/04/density-hales-jewett-and-moser-numbers/#comment-43520")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2010")])]

#text("A huge thanks to Terry for getting this paper into shape")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of obryant")]], [#link("https://terrytao.wordpress.com/2010/02/04/density-hales-jewett-and-moser-numbers/#comment-43596")[#strong[#text("obryant")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2010")])]

#text("I remember this being discussed, but I don’t recall if there was a decision as to whether to include a statement along the lines of: “participants were supported by grants from the National Science Foundation, the Research Foundation of CUNY, et cetera.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/04/density-hales-jewett-and-moser-numbers/#comment-43599")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2010")])]

#text("Hmm, interesting question. We are not identifying individual authors in the current text (there would be a question of where does one draw the line – is supplying a single comment, for instance, sufficient to be considered an author?) so there does not appear to be any simple way to display individual grant information. One could instead display aggregate grant information, as you suggest, but this information may not have much content (again, what if a grantee only contributed a single comment to the project?).")

#text("One possibility would be to set up an “About the participants” page on the wiki page for this project, where everyone who was inclined could put some brief data to this effect on the page.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of obryant")]], [#link("https://terrytao.wordpress.com/2010/02/04/density-hales-jewett-and-moser-numbers/#comment-43662")[#strong[#text("obryant")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2010")])]

#text("I never thought of the grant information as being content. As far as I know, its only purpose is to make it easier for agencies to defend to their budgets to legislators. Do you think the grant info influences readers, or perhaps referees? I can see that happening: “well, I don’t have time to write this report, but the gal’s got NSF funding, so it’s probably alright.”")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6ceb080a45d12b3ca0415a3f26fcaa7d79baab9d51ded188c662d51b5e2e14a-6b7a30d24dbcef7a10fa1443b6287112be80df4764835c827417b842bff2b356.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric Naslund")]], [#link("https://terrytao.wordpress.com/2010/02/04/density-hales-jewett-and-moser-numbers/#comment-676402")[#strong[#text("Eric Naslund")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2023")])]

#text("I am curious whether a related concept has been considered. Let ")#mi("c_{n,m,3}")#text(" denote the largest subset of ")#mi("\\{1,2,...,m\\}^n")#text(" that does not contain ")#mi("3")#text(" elements ")#mi("x,y,z")#text(" such that for all ")#mi("i")#text(", either ")#mi("x_i=y_i=z_i")#text(" or ")#mi("z_i-y_i=y_i-x_i=1")#text(". Let ")#mi("c_{n,m,3}^{\\prime}")#text(" denote the largest subset of ")#mi("\\{1,2,...,m\\}^n")#text(" that does not contain ")#mi("3")#text(" elements ")#mi("x,y,z")#text(" such that for all ")#mi("i")#text(", either ")#mi("x_i=y_i=z_i")#text(" or ")#mi("z_i-y_i=y_i-x_i=1")#text(" or ")#mi("z_i-y_i=y_i-x_i=-1")#text(". Similarly define ")#mi("c_{n,m,k}")#text(" and ")#mi("c_{n,m,k}^{\\prime}")#text(" for ")#mi("m\\geq k\\geq 3")#text(" for sets with ")#mi("k")#text(" such elements.")

#text("Then ")#mi("c_{n,k,k}")#text(" and ")#mi("c_{n,k,k}^{\\prime}")#text(" are the counts for combinatorial lines and geometric lines, respectively, mentioned in the paper and the blog post. The methods of the paper apply equally for ")#mi("m>k")#text(".")

#text("Let’s define the following slight modification: Let ")#mi("t_{n,m,3}")#text(" (")#mi("t")#text(" for torus) denote the largest subset of ")#mi("\\{1,2,...,m\\}^n")#text(" that does not contain ")#mi("3")#text(" elements ")#mi("x,y,z")#text(" such that for all ")#mi("i")#text(", either ")#mi("x_i=y_i=z_i")#text(" or ")#mi("z_i-y_i \\equiv y_i-x_i \\equiv 1\\pmod{m}")#text(". Let ")#mi("t_{n,m,3}^{\\prime}")#text(" denote the largest subset of ")#mi("\\{1,2,...,m\\}^n")#text(" that does not contain ")#mi("3")#text(" elements ")#mi("x,y,z")#text(" such that for all ")#mi("i")#text(", they are all equal, or ")#mi("z_i-y_i \\equiv y_i-x_i \\equiv 1\\pmod{m}")#text(" or ")#mi("z_i-y_i \\equiv y_i-x_i \\equiv -1\\pmod{m}")#text(" (and similarly define ")#mi("t_{n,m,k}")#text(" and ")#mi("t_{n,m,k}^{\\prime}")#text(" for ")#mi("m>=k>3")#text(").")

#text("Is anything known about the correct size, up to sub-exponential factors, for any ")#mi("t_{n,m,k}")#text(" for any parameters other than ")#mi("t_{n,3,3}^{\\prime}")#text(" which is the capset problem? Has anyone written about this problem before?")

#text("In other words, is it known whether or not")

#mi("\\displaystyle \\lim_{n\\rightarrow \\infty} (t_{n,m,k})^{1/n} = m")

#text("for any parameters ")#mi("m,k")#text("?")

#text("Is it known whether or not")

#mi("\\displaystyle \\lim_{n\\rightarrow \\infty} (t_{n,m,k}^{\\prime})^{1/n} = m")

#text("for any parameters ")#mi("m,k")#text(" other than ")#mi("m=k=3")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6ceb080a45d12b3ca0415a3f26fcaa7d79baab9d51ded188c662d51b5e2e14a-6b7a30d24dbcef7a10fa1443b6287112be80df4764835c827417b842bff2b356.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric Naslund")]], [#link("https://terrytao.wordpress.com/2010/02/04/density-hales-jewett-and-moser-numbers/#comment-676404")[#strong[#text("Eric Naslund")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2023")])]

#text("I can add – using the methods of [Tao and Sawin](")#link("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/")[#text("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/")]#text(") I can show that the slice-rank method cannot yield exponential upper bounds for ")#mi("t_{n,m,k}")#text(" for ")#mi("k\\geq 3,m\\geq 3")#text(", and cannot yield exponential upper bounds for ")#mi("t_{n,m,k}^{\\prime}")#text(" for ")#mi("k\\geq 4,m\\geq 5")#text(".")

#text("I was very curious if these problems have been considered before in the literature. (")#mi("t_{n,3,3}")#text(" corresponds to ")#mi("3")#text("-APs with difference in ")#mi("{0,1}^n")#text(")")
]
]
