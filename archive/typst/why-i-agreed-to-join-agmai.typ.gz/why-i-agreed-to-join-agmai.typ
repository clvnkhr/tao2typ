// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/
// Converted to Typst by tao2typ: "2026-10-23T11:55:43.724177+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Why I agreed to join AGMAI", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Why I agreed to join AGMAI")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/")[#text("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-23 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://www.hairer.org/")[#text("Martin Hairer")]#text(", cross-posted from ")#link("https://proofsandprompts.com/2026/09/22/why-i-agreed-to-join-agmai/")[#text("Proofs and Prompts")]#text(". — T.]")]

#text("There has been a lot of speculation regarding the “Advisory Group on Mathematics and Artifical Intelligence” ")#link("https://agmai.org/")[#text("agmai.org")]#text(" since it was announced on Monday. In this short blog post, I would like to explain in a bit more detail how the group works, what we are trying to achieve, and why I agreed to be part of this group.")

#text("First of all, let me lay down some facts that seem to have been drowned in a torrent of misinformation. The most important one is that we are genuinely independent of OpenAI and any other of the so-called `frontier’ AI labs. Yes, the original impetus of forming this group was OpenAI’s response to the statement ")#link("https://mathandai.org/")[#text("A Severe Misalignment of AI in Mathematics")]#text(", but not all members of the group were contacted by OpenAI in the first place, there is nobody besides the nine of us taking part in our conversations, we do not receive any monetary compensation, and our technical support (so far mainly regarding IT, legal, and communications) is being provided by the IAS. We also have not signed any documents placing any constraints whatsoever on what we state in public and whose advice we seek, besides the obvious confidentiality requirements. The other fundamental fact is that our overarching aim is to represent as well as we possibly can the interests of the mathematical community. This is a tall order and we may end up doing a terrible job at it (I certainly hope not!), but I am absolutely certain that all nine of us take this extremely seriously and are acting in good faith.")

#text("I am acutely aware of many of the pitfalls of being part of such a group. At a most basic level, the mathematics community consists of people with a very broad range of views and opinions (often strongly held ones!), and the nine of us clearly don’t form a representative sample. As an independent body our role is purely advisory, so the AI labs can choose to simply ignore it. It would also be very naïve to believe that the AI labs won’t try to spin whatever we say in a way that suits their PR machine, which dwarfs anything we could possibly come up with. Finally, given that the unprecedented situation we find ourselves in has the potential of impacting the lives of so many people (I intentionally do not use the word `career’ since for many of us mathematics is so much more than just a career), whatever statement we make and / or advice we give will necessarily upset a sizable fraction of the maths community. So why on earth would I accept to be part of this?")

#text("Here are some of the reasons that swayed my mind:")

#enum(start: 1, 
[#text("The recent releases, on privately controlled websites, of high-profile mathematical results combined with abject levels of scholarship and only minimal presentation effort has been undermining the usual standards of scientific practice. If we refuse to answer when being asked how to do better (irrespective of whether that ask is being done in good faith), how could we then complain about this behaviour?")

#text("It is obvious that AI has already had a profound impact on mathematical research and raises numerous questions of correct attribution of ideas, priority, human understanding of ideas, etc. Many aspects of this revolution will be addressed within our community, but it makes no sense of taking a hard `ostrich’ approach of simply ignoring the AI labs and refusing to talk to them on principle.")

#text("It is perfectly legitimate to question OpenAI’s motivations, but the fact is that they have now made an effort (as belated and minimal as it is) to engage with the mathematical community. Turning them down without even trying to engage with them would be the easiest way for them to get a PR win painting the mathematical community as a bunch of out of touch luddites.")

#text("In the `Severe Misalignment’ statement, which has now been endorsed by nearly 8000 mathematicians, we conclude by saying that “These issues must be addressed urgently, in the mathematical community, by the companies developing these technologies, […]”. It would be rather hypocritical of myself to then chicken out at the first opportunity of actually having a chance of setting up some form of communications channel between the mathematical community and the AI labs just because I could get some flack for it.")]
)

#text("Regarding the actual advice we intend to provide, it is a fact that AI companies have in recent months been producing some high profile mathematical results and that their publication and dissemination has been falling far short of acceptable mathematical practice, whichever way that is defined. However, the situation at hand is sufficiently unprecedented that we genuinely haven’t completely made up our minds yet on the best way forward and we fully intend to gather as much feedback as possible, be it through ")#link("https://agmai.org/input/")[#text("our feedback form")]#text(", discussions with colleagues, the discussions on this blog, etc. We are going through a period of intense turmoil (and this doesn’t just concern mathematics) but I am heartened by the many intense but thoughtful and respectful discussions I have experienced both inside my own institution and at gatherings of mathematicians like the ICM over the past few months. I am convinced that the mathematical community can emerge all the more united and stronger from this experience.")

#heading(level: 1)[#text("Comments (50)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696184")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("what confidentiality requirements?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696192")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("This is the exact bureaucratic construction I wrote about in the previous post.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696222")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("Any mathematician who agrees to sign a confidentiality agreement with Anthropic, OpenAI or any other company or organisation like them is a sellout.")

#text("These companies are the enemies of mathematics. Stop legitimising them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696286")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("Exactly.")

#text("The ‘obvious confidentiality requirements’ are not obvious at all. In fact they seem insidious and invidious.")

#text("What stops someone on this group pulling up the drawbridge and becoming the next Tsimermann?")

#text("None of the people on this board have anything to lose. Why are no 2nd year PhD students from mid-ranking universities on the board? Why no postdocs who have seen their future wiped out? Why no lecturers at state colleges who will see a 80 per cent fall in undergraduate applications?")

#text("When the drawbridge is pulled, these people will all be fine – especially if they have cosy contacts and secret agreements which involve selling out their prestige by advertising OpenAI’s ‘achievements’.")

#text("If there is even a whiff of NDA or confidentiality agreement then we can be sure this board is not acting in the best interest of mathematics, but only of the self-selected mathematical elites.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696188")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Great post!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696190")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Maybe they should promptly provide the list of problems allegedly solved, and the problems they tried and failed to solve, as well as how much compute they burned on each failed and sucessful attempt. Writeups can wait. Making a claim to have solved 100 problems without saying which ones seems like a very dishonest way to control PR. On site vibemath there are 725+ problems solved by AI already, so 100 more is not that impressive, unless we know exactly which they claim now. Also that would clarify which ongoing projects are outdated, since hiding these claims is hurting everyone. Since they are going to release them anyway, it would only be fair to make their claims concrete. They should also commit to their lean certificates in some way, so that at a later date we may check if they are telling the truth.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696264")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("They don’t own you and the community anything. Nobody owns math")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696191")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("When Andrew Wiles announced his proof of Fermat’s Last Theorem in 1993, it took experts an extended period of careful review before they discovered a gap in the argument. Wiles then spent considerable time working to resolve the problem and eventually published a corrected version of the proof with Richard Taylor.")

#text("This history reminds us that reviewing mathematical proofs is an extremely difficult task. Any claim should be examined carefully and critically rather than accepted solely based on how convincing it appears.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696200")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("By contrast, as far as I know, OpenAI have not published a single proof with the latest models that has been found incorrect.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b9a26d07b23d3b08937d705bf63be4e9cfb155b0c3c71efb989592a9df73904-2fa35e19c5de7c145ea2c70abf3921818c497d07d64ed2ed68245c54b93966ed.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of objecteclecticf375435795")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696212")[#strong[#text("objecteclecticf375435795")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("It is difficult to make a mistake in the proof if you have a finished formalisation… Although strangely enough the nonsofic group proof relied on a wrong literature result, which strangely enough *they fixed in the formalisation but did not mention in the paper*. (I have no idea of the motivation behind that)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696193")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("A company that seeks to replace all knowledge workers and reduce human beings to technofeudal serfdom may not negotiate in good faith. I feel like sending 9 mathematicians against them is overkill, but I understand they didn’t want to take any chances. Their CEO is a college dropout. They do not know how to think for themselves.")

#text("Expect them to have their own in house mathematicians, maybe even Fields medalists, work with you. This is a trick to gain rapport and assuage your professional concerns. Expect them to use you for free publicity and have a lawyer review anything before you sign it.")

#text("In game theory, one way to reach equilibrium is to put what they value at risk. They feel like they have leverage over everyone. What leverage do you have? How can you hold what they value at risk?")

#text("Your concern should focus on intellectual property theft for their financial gain and for publishing awful, fallacious proofs. Make them give a chalk talk outlining their unique work to establish dominance.")

#text("Whenever they talk about an AI utopia or dystopia or a post scarcity future then deduct 20 points for sci-fi delusions in accordance with the Crackpot Index. Keep a running tab and report back to us.")

#link("https://en.wikipedia.org/wiki/Crackpot_index")[#text("https://en.wikipedia.org/wiki/Crackpot_index")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/405e1d672c0ab83f1d84482438fbc82652da4b21362c53de0422d09daa52f36c-53f5f0374f5de6e4d825657aeaa8fb1b4adfcda92e0c82cbcb55bcb9224e8536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcin Kotowski")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696232")[#strong[#text("Marcin Kotowski")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("Yeah, exactly, so: “What leverage do you have?” Negotiating from a position of power if you have no cards (pardon the infamous phrase) seems… not a good strategy.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696281")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("Mathematicians have essentially zero leverage here (what are you going to do, stop making mathematical results public?); OpenAI implies as much in its very own statement on the advisory group (i.e., when the company says that nothing done by the group will prevent the company from continuing its mathematical research). Pretending to be a tough-guy negotiator in this situation — invoking game theory and the crackpot index, fantasizing about “making” OpenAI give a chalk talk — is asinine and pointless; the author of the comment, as is obvious, has just been psychologically thrown off-balance by the situation and is bitter (hence the non-sequitor personal attacks on the CEO and OpenAI employees). He or she knows that their comment is empty theater.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696194")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("I am sorry, but I just don’t understand why you would give away so much for so little. Engaging in good faith (with the level of credibility this group is offering) should involve some actual accountability requirements of openai.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/405e1d672c0ab83f1d84482438fbc82652da4b21362c53de0422d09daa52f36c-53f5f0374f5de6e4d825657aeaa8fb1b4adfcda92e0c82cbcb55bcb9224e8536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcin Kotowski")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696233")[#strong[#text("Marcin Kotowski")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("Maybe because the balance of negotiating power is vastly on the side of OpenAI? Yes, hard pill to swallow.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696257")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("this is not a good opinion. The legitimacy of OpenAI in mathematics relies a lot on the reputation of mathematicians willing to talk to them (look at the faux advertisement they roped Terry Tao in). ")#linebreak()#text("if the mathematics community as a whole denounces OpenAI then that is going to hurt their legitimacy. You have to stop believing everything OpenAI tells you")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/405e1d672c0ab83f1d84482438fbc82652da4b21362c53de0422d09daa52f36c-53f5f0374f5de6e4d825657aeaa8fb1b4adfcda92e0c82cbcb55bcb9224e8536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcin Kotowski")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696283")[#strong[#text("Marcin Kotowski")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("I’m not saying mathematicians havo literally zero leverage here. It’s just OpenAI is overwhelmingly the stronger side here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696483")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2026")])]

#text("The legitimacy of OpenAI requires their results to be true. Of course, the mathematical community can collectively ignore them, and continue all their usual conferences and paper publishing presenting results as if they were new. It would be like the chess community declaring that Magnus Carlsen is the best chess-playing entity on planet earth. Sure, they can believe that if they want to.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0638f8025e96d915d66b224c4075737a02701e62e30a2d836fcda36598360d3-bb0d4ee5ce1d65f1f1daab94cbddb5f4ca0c1db5e7927da2097f36f3aeb988dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of phenomenal18e147ff2c")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696197")[#strong[#text("phenomenal18e147ff2c")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("I believe it is well intentioned. I would point out is that AGMAI is addressing what concerns the elite colleges in US (and elsewhere). The advisory group did not include anyone from the mid level colleges in US. The control of the elite colleges over funding sources (NSF) and the referring process by itself raises questions, what other control the elite colleges wish gain? Updating of The review process of mathematics journals and funding sources is long overdue. Most people acknowledge that there is huge amount of politics in mathematics community, but no-one feels eager to correct it. Under current situation, it is possible to censor certain author’s work, solely based on competition and politics.")

#text("AGMAI is created by the elite colleges, for the issues that elite colleges face, and for the benefit of the elite colleges. It has very little concerns about broader mathematical community. Elites are talking to themselves.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696254")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("Could you write more about the politics in mathematics community? That will be beneficial to everyone. Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0638f8025e96d915d66b224c4075737a02701e62e30a2d836fcda36598360d3-bb0d4ee5ce1d65f1f1daab94cbddb5f4ca0c1db5e7927da2097f36f3aeb988dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of phenomenal18e147ff2c")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696315")[#strong[#text("phenomenal18e147ff2c")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("Politics is non-existent in math.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696199")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("I am glad that respected mathematicians from diverse backgrounds who devoted their life to high quality research and training of students who successfully went on in various directions are taking this call. Even if they do not specifically represent my opinion, they at least represent some opinions in favor of math and in favor of high quality research. I think its also great that there are various differentiated opinions about this, but after all, criticism should be constructive. Despite all things that one may dislike, at least there is now input from mathematicians who have a deep understanding of what math research means, and who deeply understand the inner workings of the job market, of funding mechanisms and so on. Its not kindergarten, we cannot ignore the people we don’t like and hope they go away; if math community reacts childish why would anyone from the outside take it serious in the long run.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0638f8025e96d915d66b224c4075737a02701e62e30a2d836fcda36598360d3-bb0d4ee5ce1d65f1f1daab94cbddb5f4ca0c1db5e7927da2097f36f3aeb988dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of phenomenal18e147ff2c")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696201")[#strong[#text("phenomenal18e147ff2c")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("By the way, am I the only one who makes a distinction between proving a conjecture and giving a counter example to a conjecture? Mixing these two up, is the same as spreading misinformation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696208")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Do you consider the AKS primality test a proof that primes is in P or a counterexample to the conjecture that it’s not?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696293")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("No serious person actually conjectured primes is not in P. For one the GRH would have to be false, but also other wild coincidences would have to happen infinitely often.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696302")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("Indeed, but it’s spiritually closer to a counterexample than a “normal proof” because it’s a construction. The distinction between proof and counterexample is meaningless, if anything you would distinguish between constructive and non-constructive proofs. But even then, the line is blurry (and constructive proofs can be more complex than non-constructive proofs) so I don’t think the distinction is too useful except when it’s super clear. Regardless, implying that something like the NS counterexample or even the Jacobian counterexample doesn’t count as a proof is just silly.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696202")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("release the results, why gate keep?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696203")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("the new vanguard of mathematics")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d588a49dcd262417c38119c66b0b17c3c2349e37e8d76765eb530e1ebd66e477-884ce7f5e374b7082b57ef2afc6fb777de252576af92d30f761fc44fa61312ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jimmy")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696206")[#strong[#text("Jimmy")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("The independence points are what make this credible rather than just another advisory panel: no compensation, no signed constraints from OpenAI, and technical support only through the IAS means the group can actually disagree with the labs it reviews, which is the entire job. The misalignment statement was the right trigger, but the lasting contribution will be whether working mathematicians keep a standing channel to raise concerns before capabilities ship. From following how AI coding tools are governed day to day – I maintain a small independent tracker of Codex usage-limit resets and reset failures – the pattern is consistent: bodies with real independence surface problems months before internal review does. Curious which question the nine of you pick up first.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696211")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Since the proofs will presumably be Lean verified (or some other proof-checking software), it might make sense to add an expert on Lean verification to the advisory group such as Kevin Buzzard or Jeremy Avigad.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696213")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Well, yes, we should react, but not in this way. I feel like OpenAI is already flipping the narrative by suggesting the form in which the community should respond. “Advisory board” with the people that they themselves approached, from a handful of elite institutions — even if you have the best intentions, this looks like going behind everyone else’s back (and it is, in a way).")

#text("I would prefer another open letter where we ")#emph[#text("demand")]#text(" that OpenAI do this, this and that (to be decided what exactly, I guess). This way it is a reaction, but not a collaboration.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696241")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("Most actions that people take right now will be going behind everyone else’s back to some degree.")

#text("What exactly would a letter demanding anything even do? This would be completely pointless. We’d be making demands from a position of weakness. It’s better for an advisory group like this to exist so that some of our voices are heard in a clean and consistent way.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696247")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("if we don’t have any power, why does openai even bother with this group? and how would the existence of the group solve the problem of us not having any power?")

#text("these results are pointless without someone to read them, so they do need us in some capacity")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696243")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("We are in no position to demand anything from OpenAI. We have little or no leverage over them.")

#text("This is why engaging in dialogue is the least bad course of action.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696216")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("Thank you for Prof for elaborating on this matter. I was initially surprised to see you and others as part of that board and had wrongly assumed that you will be associated with OpenAI.")

#text("In midst of the disappointment events that happened in the last two weeks or so, one reason though to celebrate as a mathematician is Serre turning 100!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696231")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("AGMAI will be dealing with adversaries who live and breathe “The Art of the Deal”.")

#text("If they are friendly, they try to trick you (read e.g. the New Yorker article about Altman). If they are hostile, they will exaggerate the cards they hold.")

#text("I think adversarial IP laywers and professors should be brought in to increase your leverage. It is the strongest weapon and they know it.")

#text("2023 models could recite whole works before they trained it out of them to keep up appearances. Models are derivative works of all human IP.")

#text("Millenium prizes are at $1 million? It would be easy to lauch a GoFundMe for a $20 million prize for a mathematician who proves substantial and inherent similarity of the output to the training corpus to establish IP theft.")

#text("Linear algebra is literally your domain. Use it in an adversarial fashion!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696234")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("I think we as a mathematics community need to take up this very seriously, and to play our cards very carefully. We do have some significant leverage here, and companies like OpenAI do not hold all the cards in their hands, but need us. While we should be aware of their ways, to put it mildly, we can also enforce good faith on this whole procedure, and cut through whatever their bottom line is to find a protocol that would be fair and reasonable, and which, if they refuse, will reflect on them appropriately.")

#text("Now let us ask what do these companies ")#strong[#text("want")]#text(" from mathematical community, and let us see what is legitimate and what is dishonest about it, with clarity and approaching things in an honest way, with the kind of honesty mathematics teaches us all.")

#text("1. Obviously, they want PR about capabilities of their models. That is one of the main reasons they are now putting huge resources into doing math – they are using it as a benchmark to show off.")

#text("2. They also want legitimacy. They want their results to be admitted as legitimate, to validate their models. We need to be aware that")#strong[#text(" lean is not perfect")]#text(". It does contain possible bugs, and only when proofs are accepted and digested by math community they become legitimate.")

#text("3. They want to develop their models. Recently, in an interview with Dwarkesh Patel, OpenAI researcher Noam Brown pointed out that while their models are powerful, their abilities are “jagged”, uneven, they lack judgement, they lack direction, ideas need to be supplemented etc. Their own internal researchers, according to him, spend 7-8000 dollars in compute on codex ")#emph[#strong[#text("per day")]]#text(" and their researchers still have to guide AI. Prompts and ideas supplied in chats by mathematics people are ")#strong[#text("very valuable data")]#text(" for them too. We should always keep that in mind.")

#text("4. They say that we cannot and should not slow down their models. Now that is one of the dishonest takes they do. It is not about slowing them down, it is about transparency and assigning credit where credit is due. That goes both ways. Currently, and make no mistake about it, models are not uniformly better than human mathematicians – they are better at some aspects of doing math, mostly combining existing math across fields and groundwork computation. Whether – or if – that will change in near future is unclear. But we should ")#strong[#text("insist on transparency")]#text(" because for a benchmark (which they want) to be meaningful, there needs to be honest reporting on both failures and successes, and an honest account of resources used.")

#text("5. To continue on the last point, they ")#strong[#text("do not want")]#text(" full transparency. They want to hide their failures, and to spice up their successes. Sam Altman has said that ChatGPT 5 was already as capable as a maths university professor – which is laughable if anyone remembers interacting with this model a year ago. Our role – as math community – is to evaluate their capabilities in an honest way, so we cannot and must not grant them this lack of transparency.")

#text("Crucially, we need to realize a few points. They, as a company, do not have any interest in mathematical problems per se. The only reason they are now piling into mathematics is because they want PR, benchmark, and development of the side abilities mathematics provides. That is also their selling point. Mathematics, except perhaps cryptography and some particular applications, has no immediate use, and hence there is no direct safety issue associated with solving math problems. This also provides a unique advantage.")

#text("There are other unique strengths of our community. Unlike some other branches of science, mathematics has a somewhat unified community, world congress every 4 years, and a clear valuation system that is our great asset. We, and only we, can judge value of the math results that llms provide. Also, mathematical inquiry is at the root of any theoretical scientific endeavor, and the abilities for mathematics translate to other fields, which is essential for AI.")

#text("Most importantly, we can set an example for other fields that AI is aiming at. If we as a community step up, and ask for the benefits of AI in math to be shared in a fair manner, that can set a precedent for other areas. There is great responsibility in this point.")

#text("So what should we do, and how can we use our position to contain the unhealthy tendencies of these companies. We need to keep in mind that a lot of people in those companies are researchers themselves and might share some of the values we can appeal to. Also, in their public statements, even leaders of these companies sometimes make statements that make them seem benevolent, but which might not be held sincerely. ")#strong[#text("We should hold them accountable to their own words! ")]

#text("The committee can make a public statement, offer, not only to OpenAI, but also to Anthropic, and other companies like Meta, xAI, Google DeepMind, and also Chinese AI companies like DeepSeek, Kimi, Qwen, and European ones like Mistral. Now that might be of higher or lesser interest to each of them, but we should set a standard, and increase our leverage by company peer pressure. They need us, and they do have a lot to lose if they refuse our offer. OpenAI is wrong in thinking they call all the shots – they don’t, but neither do we. Therefore, ")#strong[#text("our offer should be reasonable, and fair")]#text(". We need to demonstrate our wisdom, for the sake of not only our profession, but, by setting precedent, for humanity as well.")

#text("What can we offer? Here is one idea. We can demand that ")#strong[#text("testing of models against problems")]#text(", where huge amounts of resources are required (far exceeding the subscription that a single mathematician can pay), ")#strong[#text("needs to go through our community.")]#text(" We pick – and suggest – problems to be tried. Either by simple prompts or by other means. The result – either fail or succeed, are published ")#strong[#text("publicly")]#text(" and ")#strong[#text("transparently")]#text(" as well as prompts. In return, we offer to curate and check the solutions, and provide the desired legitimacy.")

#text("There is a precedent to this. Terence Tao blog has hosted many collaborative ")#strong[#text("polymath projects")]#text(", where anyone could participate. Having such a precedent is a huge advantage. This might be a way to accept these works, and in terms of credit sharing it seems pretty fair. Other collaborative reviews have also existed, one of the most notable being quick and slick review of Deolalikar’s P vs NP claimed proof, where anonymous contributors played a crucial role. Also, we might ")#strong[#text("offer to interactively test their models ")]#text("– with huge credit budgets – in a guided way in such projects, as a collective effort. In this way, there is a real way to incorporate testing and benchmarking without the danger of PR stunt capture. If that is what they want, we can offer that. We should hold them to their words, and cut through any attempt at manipulation with directness and honesty.")

#text("Another idea might be to organize our own, mathematics llm hubs, that protect IP inside chats. This is perhaps not directly associated with the OpenAI initiative, but there is a need for protective layers. Also, this way we can redistribute compute with discount through this layer, and, very importantly, have scrutability of what went into solving some problems i.e. how much credit to assign to mathematician and how much belongs to the machine. Because otherwise the credit system on which mathematical research relies is going to collapse. This is of course under assumption that AI won’t be able to replace human researchers completely – that, while they are better at some things, they are not able to do everything, including providing insight and ideas, as this has been proven to be the case for art and software engineering, and realistically we can expect it to hold for quite a while. But as far as OpenAI and other companies are concerned, it is essential that we guard our ideas and valuable interactions from being scrapped for free.")

#text("Whatever we do, it is very important to ")#strong[#text("get unified as a community with our core demands")]#text(", and to make no apologies and no excuses to corporate bullying, while")#strong[#text(" remaining fair ")]#text("to whatever is reasonable in their legitimate interests, and holding them accountable to what they say and not let ourselves be manipulated or bullied.")

#text("For those out of the companies that sign up to our offer, we will provide legitimacy, benchmarking and other benefits that they need. To those that keep hostile attitude our response should be equally clear. We should refuse to review or publish their claims for a set period of time (several years, for instance, which is in fact common for reviewing process in mathematics, but is an eternity in their ambitious plans to score quick and dishonest PR victories) or to give any legitimacy to their claims of solved problems, pointing out their unfair practices, unreliability of lean and their refusal to play fair and not be harmful to as noble a human endeavor as mathematics uniquely is.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696245")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("I unfortunately have to disagree that we hold significant leverage over OpenAI/Anthropic. Perhaps in the past, before a lot of mathematicians helped them train their models, we had more leverage. But if we all stopped helping them now, they’d be fine.")

#text("About legitimacy: I disagree that the community decides which solutions are legitimate. If a solution is correct, we don’t get to say it doesn’t count because we don’t like how it was obtained. If we tried something like that, the bad PR would accrue to us, not the AI companies. It would be seen as “Mathematicians take their toys and go home because AI defeated them at their own game.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696268")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("It’s uncertain if they have already achieved recursive self-Improvement. If not then human input would still be valuable, that could be a leverage.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3faa003a0b34c0e2f3c98c375ecfddd9765c04ac62e43788961dfa000bea68d9-bbd62e902d34927ad78ee27ff0a279d6fea05298f6ee54a6425c879b20f89ea6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of obryant")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696242")[#strong[#text("obryant")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("For leverage, we could legally close the arXiv (or the arXiv 2.0, if needed) to the AI companies. Or at the very least, extract payment from them for our labor and productivity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696248")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("The arXiv is a great tool for disseminating math research, but it’s not (nor is it intended to be) the gatekeeper of which results are legitimate. Plus, OpenAI and Anthropic probably don’t care much about where they’re allowed to post their work (they have plenty of server space of their own…)")

#text("As a community, we need to face up to the fact that we don’t really ")#emph[#text("have")]#text(" leverage here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696251")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("I understood that “closure of arXiv” also referred to blocking AI scrapers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696253")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("Isn’t the point to close it for scraping. The models are learning from the arXiv, just as they do from the reddit threads and other resources like twitter, and in these cases there was a significant leverage in these two examples. ArXiv contains far more dense and reliable data to train on.")

#text("As for them posting proofs without engagement from math community, who is going to check and confirm the results? There is quite a lot of cranks self-publishing mathematics, and even a few respectable mathematicians (like the one that claimed ABC conjecture) whose work needs peer review process and suffers if community doesn’t take them seriously. There are hundreds of supposed proofs of P not equal to NP, and some of P equal to NP, of Riemann conjecture and other famous problems that nobody does take seriously. Lean certificate is not enough because lean has been shown to contain bugs in the past. While it increases probability that the work is correct it cannot replace peer review process.")

#text("If OpenAI didn’t think they need mathematics community, they wouldn’t have launched this initiative after the debacle with Navier-Stokes slop preprint and controversies with the whole process.")

#text("The set of names and institutions behind this advisory board screams that OpenAI desperately wanted legitimacy.")

#text("If they want to improve their relations and not be seen as hostile and dishonest, they have to play by the rules. If all they want is to whitewash poor PR they got from the Navier Stokes incident – and it did burn them, Scott Aaronson attests to it on his blog (and he worked at OpenAI and knows people there) – then the advisory board should call it, dissolve and let them face another PR disaster. As for maths community, it doesn’t depend on IPO and can afford to take a stand regardless of the media spin they might attempt.")

#text("In short, for those falling for the hostile hype – time to grow a spine.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0638f8025e96d915d66b224c4075737a02701e62e30a2d836fcda36598360d3-bb0d4ee5ce1d65f1f1daab94cbddb5f4ca0c1db5e7927da2097f36f3aeb988dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of phenomenal18e147ff2c")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696255")[#strong[#text("phenomenal18e147ff2c")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("You are actually talking about ranking (by rank of journals etc.). Legitimacy of a work comes out when other people starts using the “result”. In my personal experience, Istarted getting impossible “results” by using a “result” (published in Annals) that was false. The Annals paper had to be withdrawn.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696288")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("I have a bunch of papers on arxiv. You don’t speak for me.")

#text("The level of gatekeeping by the mathematics community is astonishing and reprehensible.")

#text("Not only do you want to prevent AI companies announcing new results, you want to gatekeep their use of all science.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696524")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("Honestly, if you think that the AI companies really care about science ‘twinheterodox’ then I have a bridge to sell you")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696262")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("Why are non of the signatories of the A Severe Misalignment of AI in Mathematics paper on the board? Seems a bit intentional.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Diana Gillooly")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696274")[#strong[#text("Diana Gillooly")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("The author of this blog post, Martin Hairer, is a member of both groups.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696266")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("As I see it, a profession (the mathematicians) panicked and threatened to relative irrelevancy by another! You people are not as different from the IA companies as you fancy yourselves. You are just defending your interests! Hardly any mathematician has treated the possibility of a solution to Navier-Stokes as good news! Ai companies should not be allowed to appropriate user data. Of course. But mathematics is not your private property. Who are you to demand that AI companies be kept out of math research? The overall attitude of your profession made me almost in sympathy with OpenAi.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/why-i-agreed-to-join-agmai/comment-page-1/#comment-696289")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("AI companies should be kept out of everything, not only math. They are IP laundromats that rearrange human thought and apply known procedures at astronomical speed.")

#text("All of that runs on gigantic sums of borrowed money [1] that they use for the required compute, science stunts and massive influencer campaigns.")

#text("Why should math results belong to those who are best at getting hundreds of billions using questionable tactics?")

#text("There is also no fundamental reason at all for humans to lie down and resign to being blue collar workers who take the instructions of machines. None at all.")

#text("If mathematicians highlight the broader issues and not only those of their own profession, they’ll easily have something like 75% popular support.")

#text("[1] And circular deals where BigGPU gives companies money to buy BigGPU graphics cards, just like Juniper did with routers in 2000. Juniper stock stock then collapsed.")
]
]
