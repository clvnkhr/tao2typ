// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/05/17/the-birkhoff-kakutani-theorem/
// Converted to Typst by tao2typ: "2026-10-14T09:10:41.037505+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Birkhoff-Kakutani theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Birkhoff-Kakutani theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 May 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/05/17/the-birkhoff-kakutani-theorem/")[#text("https://terrytao.wordpress.com/2011/05/17/the-birkhoff-kakutani-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A topological space ")#mi("{X}")#text(" is said to be ")#emph[#text("metrisable")]#text(" if one can find a metric ")#mi("{d: X \\times X \\rightarrow [0,+\\infty)}")#text(" on it whose open balls ")#mi("{B(x,r) := \\{ y \\in X: d(x,y) < r \\}}")#text(" generate the topology.")

#text("There are some obvious necessary conditions on the space ")#mi("{X}")#text(" in order for it to be metrisable. For instance, it must be ")#link("http://en.wikipedia.org/wiki/Hausdorff_space")[#text("Hausdorff")]#text(", since all metric spaces are Hausdorff. It must also be ")#link("http://en.wikipedia.org/wiki/First-countable_space")[#text("first countable")]#text(", because every point ")#mi("{x}")#text(" in a metric space has a countable neighbourhood base of balls ")#mi("{B(x,1/n)}")#text(", ")#mi("{n=1,2,\\ldots}")#text(".")

#text("In the converse direction, being Hausdorff and first countable is not always enough to guarantee metrisability, for a variety of reasons. For instance the ")#link("http://en.wikipedia.org/wiki/Long_line_(topology)")[#text("long line")]#text(" is not metrisable despite being both Hausdorff and first countable, due to a failure of ")#link("http://en.wikipedia.org/wiki/Paracompact")[#text("paracompactness")]#text(", which prevents one from gluing together the local metric structures on this line into a global one. Even after adding in paracompactness, this is still not enough; the real line with the ")#link("http://en.wikipedia.org/wiki/Lower_limit_topology")[#text("lower limit topology")]#text(" (also known as the ")#emph[#text("Sorgenfrey line")]#text(") is Hausdorff, first countable, and paracompact, but still not metrisable (because of a failure of ")#link("http://en.wikipedia.org/wiki/Second-countable_space")[#text("second countability")]#text(" despite being ")#link("http://en.wikipedia.org/wiki/Separable_space")[#text("separable")]#text(").")

#text("However, there is one important setting in which the Hausdorff and first countability axioms ")#emph[#text("do")]#text(" suffice to give metrisability, and that is the setting of ")#link("http://en.wikipedia.org/wiki/Topological_group")[#text("topological groups")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Birkhoff-Kakutani theorem)")]#text(" Let ")#mi("{G}")#text(" be a topological group (i.e. a topological space that is also a group, such that the group operations ")#mi("{\\cdot: G \\times G \\rightarrow G}")#text(" and ")#mi("{()^{-1}: G \\rightarrow G}")#text(" are continuous). Then ")#mi("{G}")#text(" is metrisable if and only if it is both Hausdorff and first countable.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" It is not hard to show that a topological group is Hausdorff if and only if the singleton set ")#mi("{\\{\\text{id}\\}}")#text(" is closed. More generally, in an arbitrary topological group, it is a good exercise to show that the closure of ")#mi("{\\{\\text{id}\\}}")#text(" is always a closed normal subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(", whose quotient ")#mi("{G/H}")#text(" is then a Hausdorff topological group. Because of this, the study of topological groups can usually be reduced immediately to the study of Hausdorff topological groups. (Indeed, in many texts, topological groups are automatically understood to be an abbreviation for “Hausdorff topological group”.)")
]

#text("The standard proof of the Birkhoff-Kakutani theorem (which we have taken from ")#link("http://www.ams.org/mathscinet-getitem?mr=73104")[#text("this book of Montgomery and Zippin")]#text(") relies on the following Urysohn-type lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Urysohn-type lemma)")]#text(" ")#metadata(none) <tao-1ffb6a8634b36d55fec6>#text(" Let ")#mi("{G}")#text(" be a Hausdorff first countable group. Then there exists a bounded continuous function ")#mi("{f: G \\rightarrow [0,1]}")#text(" with the following properties:")

#list(
[#text("(Unique maximum) ")#mi("{f(\\text{id}) = 1}")#text(", and ")#mi("{f(x) < 1}")#text(" for all ")#mi("{x \\neq \\text{id}}")#text(".")],
[#text("(Neighbourhood base) The sets ")#mi("{\\{ x \\in G: f(x) > 1-1/n \\}}")#text(" for ")#mi("{n=1,2,\\ldots}")#text(" form a neighbourhood base at the identity.")],
[#text("(Uniform continuity) For every ")#mi("{\\varepsilon > 0}")#text(", there exists an open neighbourhood ")#mi("{U}")#text(" of the identity such that ")#tao-math("{\\left|f(gx)-f(x)\\right| \\leq \\epsilon}", block: false)#text(" for all ")#mi("{g \\in U}")#text(" and ")#mi("{x \\in G}")#text(".")]
)
]

#text("Note that if ")#mi("{G}")#text(" had a left-invariant metric, then the function ")#mi("{f(x) := \\max( 1 - \\text{dist}(x,\\text{id}), 0)}")#text(" would suffice for this lemma, which already gives some indication as to why this lemma is relevant to the Birkhoff-Kakutani theorem.")

#text("Let us assume Lemma ")#link(<tao-1ffb6a8634b36d55fec6>)[#text("2")]#text(" for now and finish the proof of the Birkhoff-Kakutani theorem. We only prove the difficult direction, namely that a Hausdorff first countable topological group ")#mi("{G}")#text(" is metrisable. We let ")#mi("{f}")#text(" be the function from Lemma ")#link(<tao-1ffb6a8634b36d55fec6>)[#text("2")]#text(", and define the function ")#mi("{d_f := G \\times G \\rightarrow [0,+\\infty)}")#text(" by the formula ")#metadata(none) <tao-32c220482c68413fbf82>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("d_f( g, h ) := \\left\\| \\tau_g f - \\tau_h f \\right\\|_{BC(G)} = \\sup_{x \\in G} \\left|f(g^{-1} x) - f(h^{-1} x)\\right|", block: true)]]

#text("where ")#mi("{BC(G)}")#text(" is the space of bounded continuous functions on ")#mi("{G}")#text(" (with the supremum norm) and ")#mi("{\\tau_g}")#text(" is the left-translation operator ")#mi("{\\tau_g f(x) := f(g^{-1} x)}")#text(".")

#text("Clearly ")#mi("{d_f}")#text(" obeys the the identity ")#mi("{d_f(g,g) = 0}")#text(" and symmetry ")#mi("{d_f(g,h) = d_f(h,g)}")#text(" axioms, and the triangle inequality ")#mi("{d_f(g,k) \\leq d_f(g,h) + d_f(h,k)}")#text(" is also immediate. This already makes ")#mi("{d_f}")#text(" a ")#link("http://en.wikipedia.org/wiki/Pseudometric_space")[#text("pseudometric")]#text(". In order for ")#mi("{d_f}")#text(" to be a genuine metric, what is needed is that ")#mi("{f}")#text(" have no non-trivial translation invariances, i.e. one has ")#mi("{\\tau_g f \\neq f}")#text(" for all ")#mi("{g \\neq \\text{id}}")#text(". But this follows since ")#mi("{f}")#text(" attains its maximum at exactly one point, namely the group identity ")#mi("{\\text{id}}")#text(".")

#text("To put it another way: because ")#mi("{f}")#text(" has no non-trivial translation invariances, the left translation action ")#mi("{\\tau}")#text(" gives an embedding ")#mi("{g \\mapsto \\tau_g f}")#text(", and ")#mi("{G}")#text(" then inherits a metric ")#mi("{d_f}")#text(" from the metric structure on ")#mi("{BC(G)}")#text(".")

#text("Now we have to check whether the metric ")#mi("{d_f}")#text(" actually generates the topology. This amounts to verifying two things. Firstly, that every ball ")#mi("{B(x,r)}")#text(" in this metric is open; and secondly, that every open neighbourhood of a point ")#mi("{x \\in G}")#text(" contains a ball ")#mi("{B(x,r)}")#text(".")

#text("To verify the former claim, it suffices to show that the map ")#mi("{g \\mapsto \\tau_g f}")#text(" from ")#mi("{G}")#text(" to ")#mi("{BC(G)}")#text(" is continuous, follows from the uniform continuity hypothesis. The second claim follows easily from the neighbourhood base hypothesis, since if ")#mi("{d_f(g,h) < 1/n}")#text(" then ")#mi("{f(g^{-1} h) > 1-1/n}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The above argument in fact shows that if a group ")#mi("{G}")#text(" is metrisable, then it admits a left-invariant metric. The idea of using a suitable continuous function ")#mi("{f}")#text(" to generate a useful metric structure on a topological group is a powerful one, for instance underlying the ")#emph[#text("Gleason lemmas")]#text(" which are fundamental to the solution of ")#link("http://en.wikipedia.org/wiki/Hilbert's_fifth_problem")[#text("Hilbert’s fifth problem")]#text(". I hope to return to this topic in a future post.")
]

#text("Now we prove Lemma ")#link(<tao-1ffb6a8634b36d55fec6>)[#text("2")]#text(". By first countability, we can find a countable neighbourhood base")

#align(center)[#tao-fit-display[#mitex("V_1 \\supset V_2 \\supset \\ldots \\supset \\{\\text{id}\\}")]]

#text("of the identity. As ")#mi("{G}")#text(" is Hausdorff, we must have")

#align(center)[#tao-fit-display[#mitex("\\bigcap_{n=1}^\\infty V_n = \\{\\text{id}\\}.")]]

#text("Using the continuity of the group axioms, we can recursively find a sequence of nested open neighbourhoods of the identity ")#metadata(none) <tao-8c3b59f15babd916995e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("U_1 \\supset U_{1/2} \\supset U_{1/4} \\supset \\ldots \\supset \\{\\text{id}\\}")]]

#text("such that each ")#mi("{U_{1/2^n}}")#text(" is symmetric (i.e. ")#mi("{g \\in U_{1/2^n}}")#text(" if and only if ")#mi("{g^{-1} \\in U_{1/2^n}}")#text("), is contained in ")#mi("{V_n}")#text(", and is such that ")#mi("{U_{1/2^{n+1}} \\cdot U_{1/2^{n+1}} \\subset U_{1/2^n}}")#text(" for each ")#mi("{n \\geq 0}")#text(". In particular the ")#mi("{U_{1/2^n}}")#text(" are also a neighbourhood base of the identity with ")#metadata(none) <tao-68bca10eea2ba33f6f15>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\bigcap_{n=1}^\\infty U_{1/2^n} = \\{\\text{id}\\}.")]]

#text("For every dyadic rational ")#mi("{a/2^n}")#text(" in ")#mi("{(0,1)}")#text(", we can now define the open sets ")#mi("{U_{a/2^n}}")#text(" by setting")

#align(center)[#tao-fit-display[#mitex("U_{a/2^n} := U_{1/2^{n_k}} \\cdot \\ldots \\cdot U_{1/2^{n_1}}")]]

#text("where ")#mi("{a/2^n = 2^{-n_1} + \\ldots + 2^{-n_k}}")#text(" is the binary expansion of ")#mi("{a/2^n}")#text(" with ")#mi("{1 \\leq n_1 < \\ldots < n_k}")#text(". By repeated use of the hypothesis ")#mi("{U_{1/2^{n+1}} \\cdot U_{1/2^{n+1}} \\subset U_{1/2^n}}")#text(" we see that the ")#mi("{U_{a/2^n}}")#text(" are increasing in ")#mi("{a/2^n}")#text("; indeed, we have the inclusion ")#metadata(none) <tao-78fbd9ec4f620ff73f58>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("U_{1/2^n} \\cdot U_{a/2^n} \\subset U_{(a+1)/2^n}")]]

#text("for all ")#mi("{n \\geq 1}")#text(" and ")#mi("{1 \\leq a < 2^n}")#text(".")

#text("We now set")

#align(center)[#tao-fit-display[#mitex("f(x) := \\sup \\{ 1 - \\frac{a}{2^n}: n \\geq 1; 1 \\leq a < 2^n; x \\in U_{a/2^n} \\}")]]

#text("with the understanding that ")#mi("{f(x)=0}")#text(" if the supremum is over the empty set. One easily verifies using ")#link(<tao-78fbd9ec4f620ff73f58>)[#text("(4)")]#text(" that ")#mi("{f}")#text(" is continuous, and furthermore obeys the uniform continuity property. The neighbourhood base property follows since the ")#mi("{U_{1/2^n}}")#text(" are a neighbourhood base of the identity, and the unique maximum property follows from ")#link(<tao-68bca10eea2ba33f6f15>)[#text("(3)")]#text(". This proves Lemma ")#link(<tao-1ffb6a8634b36d55fec6>)[#text("2")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" A very similar argument to the one above also establishes that every topological group ")#mi("{G}")#text(" is ")#link("http://en.wikipedia.org/wiki/Completely_regular_space")[#text("completely regular")]#text(".")
]

#text("Notice that the function ")#mi("{f}")#text(" constructed in the above argument was localised to the set ")#mi("{V_1}")#text(". As such, it is not difficult to localise the Birkhoff-Kakutani theorem to ")#emph[#text("local groups")]#text(". A local group is a topological space ")#mi("{G}")#text(" equipped with an identity ")#mi("{\\text{id}}")#text(", a ")#emph[#text("partially defined")]#text(" inversion operation ")#mi("{()^{-1}: \\Lambda \\rightarrow G}")#text(", and a ")#emph[#text("partially defined")]#text(" product operation ")#mi("{\\cdot: \\Omega \\rightarrow G}")#text(", where ")#mi("{\\Lambda}")#text(", ")#mi("{\\Omega}")#text(" are open subsets of ")#mi("{G}")#text(" and ")#mi("{G \\times G}")#text(", obeying the following restricted versions of the group axioms:")

#enum(start: 1, 
[#text("(Continuity) ")#mi("{\\cdot}")#text(" and ")#mi("{()^{-1}}")#text(" are continuous on their domains of definition.")],
[#text("(Identity) For any ")#mi("{g \\in G}")#text(", ")#mi("{\\text{id} \\cdot g}")#text(" and ")#mi("{g \\cdot \\text{id}}")#text(" are well-defined and equal to ")#mi("{g}")#text(".")],
[#text("(Inverse) For any ")#mi("{g \\in \\Lambda}")#text(", ")#mi("{g \\cdot g^{-1}}")#text(" and ")#mi("{g^{-1} \\cdot g}")#text(" are well-defined and equal to ")#mi("{\\text{id}}")#text(". ")#mi("{\\text{id}^{-1}}")#text(" is well-defined and equal to ")#mi("{\\text{id}}")#text(".")],
[#text("(Local associativity) If ")#mi("{g, h, k \\in G}")#text(" are such that ")#mi("{g \\cdot h}")#text(", ")#mi("{(g \\cdot h) \\cdot k}")#text(", ")#mi("{h \\cdot k}")#text(", and ")#mi("{g \\cdot (h \\cdot k)}")#text(" are all well-defined, then ")#mi("{(g \\cdot h) \\cdot k = g \\cdot (h \\cdot k)}")#text(".")]
)

#text("Informally, one can view a local group as a topological group in which the closure axiom has been almost completely dropped, but with all the other axioms retained. A basic way to generate a local group is to start with an ordinary topological group ")#mi("{G}")#text(" and restrict it to an open neighbourhood ")#mi("{U}")#text(" of the identity, with ")#mi("{\\Lambda := \\{ g \\in U: g^{-1} \\in U \\}}")#text(" and ")#mi("{\\Omega := \\{ (g,h) \\in U \\times U: gh \\in U \\}}")#text(". However, this is not quite the only way to generate local groups (ultimately because the local associativity axiom does not necessarily imply a (stronger) global associativity axiom in which one considers two different ways to multiply more than three group elements together).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" Another important example of a local group is that of a ")#emph[#text("group chunk")]#text(", in which the sets ")#mi("{\\Lambda}")#text(" and ")#mi("{\\Omega}")#text(" are somehow “generic”; for instance, ")#mi("{G}")#text(" could be an algebraic variety, ")#mi("{\\Lambda, \\Omega}")#text(" Zariski-open, and the group operations birational on their domains of definition. This is somewhat analogous to the notion of a “")#mi("{99\\%}")#text(" group” in additive combinatorics. There are a number of ")#emph[#text("group chunk theorems")]#text(", starting with a ")#link("http://www.ams.org/mathscinet-getitem?mr=74083")[#text("theorem of Weil")]#text(" in the algebraic setting, which roughly speaking assert that a generic portion of a group chunk can be identified with the generic portion of a genuine group.")
]

#text("We then have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Birkhoff-Kakutani theorem for local groups)")]#text(" Let ")#mi("{G}")#text(" be a local group which is Hausdorff and first countable. Then there exists an open neighbourhood ")#mi("{V_0}")#text(" of the identity which is metrisable.")
]

#emph[#text("Proof:")]#text(" (Sketch) It is not difficult to see that in a local group ")#mi("{G}")#text(", one can find a symmetric neighbourhood ")#mi("{V_0}")#text(" of the identity such that the product of any ")#mi("{100}")#text(" (say) elements of ")#mi("{V_0}")#text(" (multiplied together in any order) are well-defined, which effectively allows us to treat elements of ")#mi("{V_0}")#text(" as if they belonged to a group for the purposes of simple algebraic manipulation, such as applying the cancellation laws ")#mi("{gh=gk \\implies h=k}")#text(" for ")#mi("{g,h,k \\in V_0}")#text(". Inside this ")#mi("{V_0}")#text(", one can then repeat the previous arguments and eventually end up with a continuous function ")#mi("{f \\in BC(G)}")#text(" supported in ")#mi("{V_0}")#text(" obeying the conclusions of Lemma ")#link(<tao-1ffb6a8634b36d55fec6>)[#text("2")]#text(" (but in the uniform continuity conclusion, one has to restrict ")#mi("{x}")#text(" to, say, ")#mi("{V_0^{10}}")#text(", to avoid issues of ill-definedness). The definition ")#link(<tao-32c220482c68413fbf82>)[#text("(1)")]#text(" then gives a metric on ")#mi("{V_0}")#text(" with the required properties, where we make the convention that ")#mi("{\\tau_g f(x)}")#text(" vanishes for ")#mi("{x \\not \\in V_0^{10}}")#text(" (say) and ")#mi("{g \\in V_0}")#text(". ")#mi("\\Box")

#text("My motivation for studying local groups is that it turns out that there is a correspondence (first observed ")#link("http://arxiv.org/abs/0909.2190")[#text("by Hrushovski")]#text(") between the concept of an approximate group in additive combinatorics, and a locally compact local group in topological group theory; I hope to discuss this correspondence further in a subsequent post.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d7d451446c663656d1d44ae48a7dc814e596957df786c2732bc7cc5c60442cfa-39588a548a78a50414d50e5fe676ebf3fa7c84b2aee8aab266f23f07e6cbaa4b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of oec")]], [#link("https://terrytao.wordpress.com/2011/05/17/the-birkhoff-kakutani-theorem/#comment-52810")[#strong[#text("oec")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2011")])]

#text("Lemma 2 should probably read: “Let be a Hausdorff first countable _group_”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/704b81e58ca29743b47850bb62f82d988587af8aa950d2d86ccec5d2d2505f3a-ae78c7c51eb8b92e65e74b0790dfb510525c2923707a533c2fcc07a150e39602.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of plm")]], [#link("https://terrytao.wordpress.com/2011/05/17/the-birkhoff-kakutani-theorem/#comment-52817")[#strong[#text("plm")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2011")])]

#text("Thank you very much for the -extra- efforts in giving references and motivations. It really helps alot -really.")

#text("I hope this does not make you feel like a magician giving away his tricks. I think Arne Beurling had a different attitude, and I wonder how mathematicians were/are distributed, with respect to this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2011/05/17/the-birkhoff-kakutani-theorem/#comment-52837")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2011")])]

#text("Looking forward to learn more about the correspondence between local groups and approximate groups and maybe Gromov’s proof.")

#text("Here is why: all information about a (local) group is contained in the group operation (as a function). In metric spaces with dilations (aka dilatation structures or dilation structures), in particular in groups with a left invariant metric endowed with an approximate contraction, the operation of a locally compact local group which is conical (or contractible, like in in particular Carnot groups) appear as a limit of operations which are only approximately associative, so these operations are only approximate group operations.")

#text("So, let us compare approximate groups with “approximate groups operations” like those appearing in metric spaces with dilations:")

#text("Approximate groups are finite sets in groups which are “approximately closed” with respect to an exact group operation. Under rough equivalence,")#linebreak()#text(" i.e. seen from afar in a combinatorial sense, they may be alike local groups which are contractible, then by a theorem of Siebert nilpotent graded groups.")

#text("Approximate group operations (induced by the approximate self-similarity of")#linebreak()#text(" a metric space with dilations) don’t need an ambient group operation in order to be defined. Instead, in the limit (of a scale parameter), which corresponds to looking at smaller and smaller regions around a point in the metric space, again a la Gromov, these operations converge to a local conical, or contractible group.")

#text("How are these related? Probably Hrushovski correspondence between local groups and additive combinatorics cold answer to this, anyway that is what I hope in a part of a joint project with Laurentiu Leustean.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Locally compact groups with faithful finite-dimensional representations « What’s new")]], [#link("https://terrytao.wordpress.com/2011/05/17/the-birkhoff-kakutani-theorem/#comment-53149")[#strong[#text("Locally compact groups with faithful finite-dimensional representations « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2011")])]

#text("[…] For future reference, we note that this already shows that is first-countable, and hence metrisable, thanks to the Birkhoff-Kakutani theorem as discussed earlier. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hilbert fifth’s problem without one parameter subgroups | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/05/17/the-birkhoff-kakutani-theorem/#comment-53618")[#strong[#text("Hilbert fifth’s problem without one parameter subgroups | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2011")])]

#text("[…] motivation lies in the project described first time in public here. In fact, one of the reasons to start this blog is to have a place where I can leisurely explain […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brouwer’s fixed point and invariance of domain theorems, and Hilbert’s fifth problem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/05/17/the-birkhoff-kakutani-theorem/#comment-53850")[#strong[#text("Brouwer’s fixed point and invariance of domain theorems, and Hilbert’s fifth problem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2011")])]

#text("[…] group is of course locally compact Hausdorff; it is also first countable, and hence (by the Birkhoff-Kakutani theorem, discussed in this post) is also metrisable. Because of this, it is not difficult to show that the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hilbert’s fifth problem and Gleason metrics « What’s new")]], [#link("https://terrytao.wordpress.com/2011/05/17/the-birkhoff-kakutani-theorem/#comment-54020")[#strong[#text("Hilbert’s fifth problem and Gleason metrics « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2011")])]

#text("[…] bump functions with which to create a metric, in a variant of the analysis used to prove the Birkhoff-Kakutani theorem); Theorem 5 also requires Peter-Weyl theorem (to dispose of certain compact subgroups that arise en […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gleason’s lemma « What’s new")]], [#link("https://terrytao.wordpress.com/2011/05/17/the-birkhoff-kakutani-theorem/#comment-56083")[#strong[#text("Gleason’s lemma « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2011")])]

#text("[…] construction was already seen in the proof of the Birkhoff-Kakutani theorem, which is the main tool used to establish Proposition 6. For the other propositions, the idea is to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on local groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/05/17/the-birkhoff-kakutani-theorem/#comment-68214")[#strong[#text("Notes on local groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2011")])]

#text("[…] a global topological group is first-countable if and only if it is locally first countable. (By the Birkhoff-Kakutani theorem, this implies that such groups are metrisable if and only if they are locally […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3c19e3c1378e4e42f77be0d4ed44706da50f84349f4a9de186dc91f9638c2b1-1dc76913eda898a74c4afc601c1b17b68466e721835168462273d92296ffc939.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kasper Henriksen")]], [#link("https://terrytao.wordpress.com/2011/05/17/the-birkhoff-kakutani-theorem/#comment-141345")[#strong[#text("Kasper Henriksen")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2012")])]

#text("I take it that the theorem is stated as is because the slightly more general “a topological group is pseudometrizable if and only if it is first countable” (from which the Birkhoff-Kakutani theorem would follow by quotienting out the closure of the identity) is false")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/17/the-birkhoff-kakutani-theorem/#comment-141520")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2012")])]

#text("Actually, that latter formulation is equivalent to the one stated here. Given that the reduction to the Hausdorff case is not too difficult, and that metrics are more familiar than pseudometrics, I did not state the theorem in the maximally general formulation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/56306846bfe1ec0b8db66ee06c0b7610e9fa42e68ab885d5aef6783a978bdd52-cf2a5601dcf90267ee325e191c7fefffc53450b5576f4402abaf3b5657087ead.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klaus Schilling")]], [#link("https://terrytao.wordpress.com/2011/05/17/the-birkhoff-kakutani-theorem/#comment-471096")[#strong[#text("Klaus Schilling")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2016")])]

#text("May Birkhoff-Kakutani be proven via Nagata-Smirnov?")
]
