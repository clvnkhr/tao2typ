// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/05/25/cancellation-for-the-multilinear-hilbert-transform/
// Converted to Typst by tao2typ: "2026-10-14T16:37:42.243096+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Cancellation for the multilinear Hilbert transform", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Cancellation for the multilinear Hilbert transform")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 May 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/05/25/cancellation-for-the-multilinear-hilbert-transform/")[#text("https://terrytao.wordpress.com/2015/05/25/cancellation-for-the-multilinear-hilbert-transform/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper “")#link("http://arxiv.org/abs/1505.06479")[#text("Cancellation for the multilinear Hilbert transform")]#text("“, submitted to ")#link("http://www.springer.com/mathematics/applications/journal/13348")[#text("Collectanea Mathematica")]#text(". This paper uses methods from additive combinatorics (and more specifically, the arithmetic regularity and counting lemmas from ")#link("https://terrytao.wordpress.com/2010/02/12/an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/")[#text("this paper of Ben Green and myself")]#text(") to obtain a slight amount of progress towards the open problem of obtaining ")#mi("{L^p}")#text(" bounds for the trilinear and higher Hilbert transforms (as discussed in ")#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/")[#text("this previous blog post")]#text("). For instance, the trilinear Hilbert transform")

#align(center)[#tao-fit-display[#mitex("H_3( f_1, f_2, f_3 )(x) := p.v. \\int_{\\bf R} f_1(x+t) f_2(x+2t) f_3(x+3t)\\ \\frac{dt}{t}")]]

#text("is not known to be bounded for any ")#mi("{L^{p_1}({\\bf R}) \\times L^{p_2}({\\bf R}) \\times L^{p_3}({\\bf R})}")#text(" to ")#mi("{L^p({\\bf R})}")#text(", although it is conjectured to do so when ")#mi("{1/p =1/p_1 +1/p_2+1/p_3}")#text(" and ")#mi("{1 < p_1,p_2,p_3,p < \\infty}")#text(". (For ")#mi("{p}")#text(" well below ")#mi("{1}")#text(", one can use additive combinatorics constructions to demonstrate unboundedness; see ")#link("http://www.ams.org/mathscinet-getitem?mr=2449537")[#text("this paper of Demeter")]#text(".) One can approach this problem by considering the truncated trilinear Hilbert transforms")

#align(center)[#tao-fit-display[#tao-math("H_{3,r,R}( f_1, f_2, f_3 )(x) := \\int_{r \\leq \\left|t\\right| \\leq R} f_1(x+t) f_2(x+2t) f_3(x+3t)\\ \\frac{dt}{t}", block: true)]]

#text("for ")#mi("{0 < r < R}")#text(". It is not difficult to show that the boundedness of ")#mi("{H_3}")#text(" is equivalent to the boundedness of ")#mi("{H_{3,r,R}}")#text(" with bounds that are uniform in ")#mi("{R}")#text(" and ")#mi("{r}")#text(". On the other hand, from Minkowski’s inequality and Hölder’s inequality one can easily obtain the ")#emph[#text("non-uniform")]#text(" bound of ")#mi("{2 \\log \\frac{R}{r}}")#text(" for ")#mi("{H_{3,r,R}}")#text(". The main result of this paper is a slight improvement of this trivial bound to ")#mi("{o( \\log \\frac{R}{r})}")#text(" as ")#mi("{R/r \\rightarrow \\infty}")#text(". Roughly speaking, the way this gain is established is as follows. First there are some standard time-frequency type reductions to reduce to the task of obtaining some non-trivial cancellation on a single “tree”. Using a “generalised von Neumann theorem”, we show that such cancellation will happen if (a discretised version of) one or more of the functions ")#mi("{f_1,f_2,f_3}")#text(" (or a dual function ")#mi("{f_0}")#text(" that it is convenient to test against) is small in the Gowers ")#mi("{U^3}")#text(" norm. However, the arithmetic regularity lemma alluded to earlier allows one to represent an arbitrary function ")#mi("{f_i}")#text(", up to a small error, as the sum of such a “Gowers uniform” function, plus a structured function (or more precisely, an ")#emph[#text("irrational virtual nilsequence")]#text("). This effectively reduces the problem to that of establishing some cancellation in a single tree in the case when all functions ")#mi("{f_0,f_1,f_2,f_3}")#text(" involved are irrational virtual nilsequences. At this point, the contribution of each component of the tree can be estimated using the “counting lemma” from my paper with Ben. The main term in the asymptotics is a certain integral over a nilmanifold, but because the kernel ")#mi("{\\frac{dt}{t}}")#text(" in the trilinear Hilbert transform is odd, it turns out that this integral vanishes, giving the required cancellation.")

#text("The same argument works for higher order Hilbert transforms (and one can also replace the coefficients in these transforms with other rational constants). However, because the quantitative bounds in the arithmetic regularity and counting lemmas are so poor, it does not seem likely that one can use these methods to remove the logarithmic growth in ")#mi("{R/r}")#text(" entirely, and some additional ideas will be needed to resolve the full conjecture.")

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70f27b4d1c8742038cde02426deb40c6a17aeba2c04d2c8a9945b24fa8f813db-11536d1cbc6cfd84f35ff55d2262152fd089fbed1c7b74321d327daf292ab96f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaeldbydbcl")]], [#link("https://terrytao.wordpress.com/2015/05/25/cancellation-for-the-multilinear-hilbert-transform/#comment-456105")[#strong[#text("michaeldbydbcl")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2015")])]

#text("Hi, Prof.Tao, I’m your big fan:) You are true genius!!!!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/25/cancellation-for-the-multilinear-hilbert-transform/#comment-456106")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2015")])]

#text("The arguments ")#mi("x + t, x + 2 t, x  + 3 t")#text(" of ")#mi("f_1, f_2, f_3")#text(" in the integrand form an arithmetic progression, is this necessary? (i.e. is it possible to get cancellation for a more general sequence of arguments?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/05/25/cancellation-for-the-multilinear-hilbert-transform/#comment-456108")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2015")])]

#text("Yes, one can work with ")#mi("x+c_1 t, x+c_2 t, \\dots")#text(" for rationally commensurate coefficients ")#mi("c_1,c_2,\\dots")#text(" and obtain similar results. However something strange happens in the non rationally commensurate case, one cannot easily discretise the problem and one now needs to develop a continuous version of the arithmetic regularity and counting lemmas (this should be possible but would require redoing a number of previous papers in the continuous setting). There is ")#link("http://www.ams.org/mathscinet-getitem?mr=1825259")[#text("a previous paper of Christ")]#text(" in which a similar distinction between the commensurate and non-commensurate cases arose.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel")]], [#link("https://terrytao.wordpress.com/2015/05/25/cancellation-for-the-multilinear-hilbert-transform/#comment-456128")[#strong[#text("pavel")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2015")])]

#text("Dear Terry,")

#text("thanks for the great read. There is a typo in the first display on p. 8 (v2), where all n’s should be replaced by -n’s. Also, at the end of p.15 (v2) ")#tao-math("\\left|\\alpha\\right|\\leq 1", block: false)#text(" follows from the counting lemma because the Lipschitz function in the integral is wlog bounded by 1.")

#text("Lastly, on p. 14 you pass to a product of nilmanifolds. It seems to me however that the product of the nilsequences g_i(n) need not be irrational, consider for instance the case when matching Taylor coefficients of two sequences are (almost) equal. The vector-valued version of the arithmetic regularity lemma that you mention of course removes this problem.")

#text("best,")#linebreak()#text(" pavel")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/05/25/cancellation-for-the-multilinear-hilbert-transform/#comment-456129")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2015")])]

#text("Thanks for pointing out this subtle issue (and its fix)! This will be corrected in the next revision of the ms.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/25/cancellation-for-the-multilinear-hilbert-transform/#comment-456154")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2015")])]

#text("I always belive Pro.Tao’s ability.I don’t need anyone in the world consider him as genius.The world is similar to the sea.Many animals kills each other for food,aggressive,race.The time will prove who is the best great of all time,who is the sun of math.You wait!!!not long.Pro.Tao always give reader many amazing things.I am sure 100% he does a breakthrough in this year,even every year.I live faraway him,but I know him very very very well,even his wife not well like me.Bu")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/25/cancellation-for-the-multilinear-hilbert-transform/#comment-456155")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2015")])]

#text("But one thing I admire him is that he is always humble.If anyone says he is talented,he immediately says no")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/25/cancellation-for-the-multilinear-hilbert-transform/#comment-456167")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2015")])]

#text("Let")

#mi("H^{*}_3 (f_1, f_2, f_3) := \\sup_{r, R} H_{3, r, R} (f_1, f_2, f_3)")

#text("be the corresponding “maximal trilinear Hilbert transform”. Is there any conjecture about its boundedness?")

#emph[#text("[I don’t know if it is explicitly stated in the literature, but based on analogy with the linear and bilinear Hilbert transform, the natural conjecture would be that it obeys the same estimates that the ordinary trilinear Hilbert transform does. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e867149d493a7150ab468a9a18def5708e9a34e3daffea9e77fbd0c5b527493-c4d479d2f4ed77509b0d1c303fd1a48de36baaca9f793217e845cbd5a158163b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rajeshd007")]], [#link("https://terrytao.wordpress.com/2015/05/25/cancellation-for-the-multilinear-hilbert-transform/#comment-456268")[#strong[#text("rajeshd007")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2015")])]

#text("As a signal processing engineer, I am not at all interested in multilinear Hilbert transform. You are wasting time on them. Please attack this problem and help me: ")#link("http://mathoverflow.net/q/165038/14414")[#text("http://mathoverflow.net/q/165038/14414")]

#text("It can revolutionize signal processing . I’ve got ample proofs for that, and would share if anyone interested to collaborate.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e867149d493a7150ab468a9a18def5708e9a34e3daffea9e77fbd0c5b527493-c4d479d2f4ed77509b0d1c303fd1a48de36baaca9f793217e845cbd5a158163b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rajeshd007")]], [#link("https://terrytao.wordpress.com/2015/05/25/cancellation-for-the-multilinear-hilbert-transform/#comment-456272")[#strong[#text("rajeshd007")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2015")])]

#text("Also see this metric space for signals : ")#link("http://mathoverflow.net/q/193656/14414")[#text("http://mathoverflow.net/q/193656/14414")]#text(" : Mathematicians should take a serious note of it.")
]
]
