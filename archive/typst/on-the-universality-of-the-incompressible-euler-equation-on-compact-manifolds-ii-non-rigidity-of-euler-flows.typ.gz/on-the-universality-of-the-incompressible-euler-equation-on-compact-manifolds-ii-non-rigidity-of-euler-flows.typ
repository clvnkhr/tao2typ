// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/02/19/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds-ii-non-rigidity-of-euler-flows/
// Converted to Typst by tao2typ: "2026-10-14T16:38:31.819441+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On the universality of the incompressible Euler equation on compact manifolds, II.  Non-rigidity of Euler flows", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On the universality of the incompressible Euler equation on compact manifolds, II.  Non-rigidity of Euler flows")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 February 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/02/19/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds-ii-non-rigidity-of-euler-flows/")[#text("https://terrytao.wordpress.com/2019/02/19/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds-ii-non-rigidity-of-euler-flows/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I have just uploaded to the arXiv my paper “")#link("https://arxiv.org/abs/1902.06313")[#text("On the universality of the incompressible Euler equation on compact manifolds, II. Non-rigidity of Euler flows")]#text("“, submitted to ")#link("http://www.ybook.co.jp/pafa.html")[#text("Pure and Applied Functional Analysis")]#text(". This paper continues my attempts to establish “universality” properties of the Euler equations on Riemannian manifolds ")#mi("{(M,g)}")#text(", as I conjecture that the freedom to set the metric ")#mi("{g}")#text(" ought to allow one to “program” such Euler flows to exhibit a wide range of behaviour, and in particular to achieve finite time blowup (if the dimension is sufficiently large, at least).")

#text("In coordinates, the Euler equations read ")#metadata(none) <tao-c23c23a7c71feb7e0bd8>

#tao-aligned(keep: true)[


#tao-math("\\partial_t u^k + u^j \\nabla_j u^k  & = - \\nabla^k p", block: true, numbering: n => [#text("(1)")])



#tao-math("\\nabla_k u^k  & = 0", block: true)
]

#text("where ")#mi("{p: [0,T] \\rightarrow C^\\infty(M)}")#text(" is the pressure field and ")#mi("{u: [0,T] \\rightarrow \\Gamma(TM)}")#text(" is the velocity field, and ")#mi("{\\nabla}")#text(" denotes the Levi-Civita connection with the usual Penrose abstract index notation conventions; we restrict attention here to the case where ")#mi("{u,p}")#text(" are smooth and ")#mi("{M}")#text(" is compact, smooth, orientable, connected, and without boundary. Let’s call ")#mi("{u}")#text(" an ")#emph[#text("Euler flow")]#text(" on ")#mi("{M}")#text(" (for the time interval ")#mi("{[0,T]}")#text(") if it solves the above system of equations for some pressure ")#mi("{p}")#text(", and an ")#emph[#text("incompressible flow")]#text(" if it just obeys the divergence-free relation ")#mi("{\\nabla_k u^k=0}")#text(". Thus every Euler flow is an incompressible flow, but the converse is certainly not true; for instance the various conservation laws of the Euler equation, such as conservation of energy, will already block most incompressible flows from being an Euler flow, or even being approximated in a reasonably strong topology by such Euler flows.")

#text("However, one can ask if an incompressible flow can be ")#emph[#text("extended")]#text(" to an Euler flow by adding some additional dimensions to ")#mi("{M}")#text(". In my paper, I formalise this by considering warped products ")#mi("{\\tilde M}")#text(" of ")#mi("{M}")#text(" which (as a smooth manifold) are products ")#mi("{\\tilde M = M \\times ({\\bf R}/{\\bf Z})^m}")#text(" of ")#mi("{M}")#text(" with a torus, with a metric ")#mi("{\\tilde g}")#text(" given by")

#align(center)[#tao-fit-display[#mitex("d \\tilde g^2 = g_{ij}(x) dx^i dx^j + \\sum_{s=1}^m \\tilde g_{ss}(x) (d\\theta^s)^2")]]

#text("for ")#mi("{(x,\\theta) \\in \\tilde M}")#text(", where ")#mi("{\\theta^1,\\dots,\\theta^m}")#text(" are the coordinates of the torus ")#mi("{({\\bf R}/{\\bf Z})^m}")#text(", and ")#mi("{\\tilde g_{ss}: M \\rightarrow {\\bf R}^+}")#text(" are smooth positive coefficients for ")#mi("{s=1,\\dots,m}")#text("; in order to preserve the incompressibility condition, we also require the volume preservation property ")#metadata(none) <tao-b9f6da279ec59af95d12>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\prod_{s=1}^m \\tilde g_{ss}(x) = 1")]]

#text("though in practice we can quickly dispose of this condition by adding one further “dummy” dimension to the torus ")#mi("{({\\bf R}/{\\bf Z})^m}")#text(". We say that an incompressible flow ")#mi("{u}")#text(" is ")#emph[#text("extendible to an Euler flow")]#text(" if there exists a warped product ")#mi("{\\tilde M}")#text(" extending ")#mi("{M}")#text(", and an Euler flow ")#mi("{\\tilde u}")#text(" on ")#mi("{\\tilde M}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("\\tilde u(t,(x,\\theta)) = u^i(t,x) \\frac{d}{dx^i} + \\sum_{s=1}^m \\tilde u^s(t,x) \\frac{d}{d\\theta^s}")]]

#text("for some “swirl” fields ")#mi("{\\tilde u^s: [0,T] \\times M \\rightarrow {\\bf R}}")#text(". The situation here is motivated by the familiar situation of studying axisymmetric Euler flows ")#mi("{\\tilde u}")#text(" on ")#mi("{{\\bf R}^3}")#text(", which in cylindrical coordinates take the form")

#align(center)[#tao-fit-display[#mitex("\\tilde u(t,(r,z,\\theta)) = u^r(t,r,z) \\frac{d}{dr} + u^z(t,r,z) \\frac{d}{dz} + \\tilde u^\\theta(t,r,z) \\frac{d}{d\\theta}.")]]

#text("The base component")

#align(center)[#tao-fit-display[#mitex("u^r(t,r,z) \\frac{d}{dr} + u^z(t,r,z) \\frac{d}{dz}")]]

#text("of this flow is then a flow on the two-dimensional ")#mi("{r,z}")#text(" plane which is not quite incompressible (due to the failure of the volume preservation condition ")#link(<tao-b9f6da279ec59af95d12>)[#text("(2)")]#text(" in this case) but still satisfies a system of equations (coupled with a passive scalar field ")#mi("{\\rho}")#text(" that is basically the square of the swirl ")#mi("{\\tilde u^\\rho}")#text(") that is reminiscent of the Boussinesq equations.")

#text("On a fixed ")#mi("{d}")#text("-dimensional manifold ")#mi("{(M,g)}")#text(", let ")#mi("{{\\mathcal F}}")#text(" denote the space of incompressible flows ")#mi("{u: [0,T] \\rightarrow \\Gamma(TM)}")#text(", equipped with the smooth topology (in spacetime), and let ")#mi("{{\\mathcal E} \\subset {\\mathcal F}}")#text(" denote the space of such flows that are extendible to Euler flows. Our main theorem is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]

#list(
[#text("(i) (Generic inextendibility) Assume ")#mi("{d \\geq 3}")#text(". Then ")#mi("{{\\mathcal E}}")#text(" is of the first category in ")#mi("{{\\mathcal F}}")#text(" (the countable union of nowhere dense sets in ")#mi("{{\\mathcal F}}")#text(").")],
[#text("(ii) (Non-rigidity) Assume ")#mi("{M = ({\\bf R}/{\\bf Z})^d}")#text(" (with an arbitrary metric ")#mi("{g}")#text("). Then ")#mi("{{\\mathcal E}}")#text(" is somewhere dense in ")#mi("{{\\mathcal F}}")#text(" (that is, the closure of ")#mi("{{\\mathcal E}}")#text(" has non-empty interior).")]
)
]

#text("More informally, starting with an incompressible flow ")#mi("{u}")#text(", one usually cannot extend it to an Euler flow just by extending the manifold, warping the metric, and adding swirl coefficients, even if one is allowed to select the dimension of the extension, as well as the metric and coefficients, arbitrarily. However, many such flows can be ")#emph[#text("perturbed")]#text(" to be extendible in such a manner (though different perturbations will require different extensions, in particular the dimension of the extension will not be fixed). Among other things, this means that conservation laws such as energy (or momentum, helicity, or circulation) no longer present an obstruction when one is allowed to perform an extension (basically this is because the swirl components of the extension can exchange energy (or momentum, etc.) with the base components in a basically arbitrary fashion.")

#text("These results fall short of my hopes to use the ability to extend the manifold to create universal behaviour in Euler flows, because of the fact that each flow requires a different extension in order to achieve the desired dynamics. Still it does seem to provide a little bit of support to the idea that high-dimensional Euler flows are quite “flexible” in their behaviour, though not completely so due to the generic inextendibility phenomenon. This flexibility reminds me a little bit of the flexibility of weak solutions to equations such as the Euler equations provided by the “")#link("https://en.wikipedia.org/wiki/Homotopy_principle")[#mi("{h}")#text("-principle")]#text("” of Gromov and its variants (as discussed in ")#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/")[#text("these recent notes")]#text("), although in this case the flexibility comes from adding additional dimensions, rather than by repeatedly adding high-frequency corrections to the solution.")

#text("The proof of part (i) of the theorem basically proceeds by a dimension counting argument (similar to that in the proof of Proposition 9 of ")#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/")[#text("these recent lecture notes of mine")]#text("). Heuristically, the point is that an arbitrary incompressible flow ")#mi("{u}")#text(" is essentially determined by ")#mi("{d-1}")#text(" independent functions of space and time, whereas the warping factors ")#mi("{\\tilde g_{ss}}")#text(" are functions of space only, the pressure field is one function of space and time, and the swirl fields ")#mi("{u^s}")#text(" are technically functions of both space and time, but have the same number of degrees of freedom as a function just of space, because they solve an evolution equation. When ")#mi("{d>2}")#text(", this means that there are fewer unknown functions of space and time than prescribed functions of space and time, which is the source of the generic inextendibility. This simple argument breaks down when ")#mi("{d=2}")#text(", but we do not know whether the claim is actually false in this case.")

#text("The proof of part (ii) proceeds by direct calculation of the effect of the warping factors and swirl velocities, which effectively create a forcing term (of Boussinesq type) in the first equation of ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(1)")]#text(" that is a combination of functions of the Eulerian spatial coordinates ")#mi("{x^i}")#text(" (coming from the warping factors) and the Lagrangian spatial coordinates ")#mi("{a^\\beta}")#text(" (which arise from the swirl velocities, which are passively transported by the flow). In a non-empty open subset of ")#mi("{{\\mathcal F}}")#text(", the combination of these coordinates becomes a non-degenerate set of coordinates for spacetime, and one can then use the Stone-Weierstrass theorem to conclude. The requirement that ")#mi("{M}")#text(" be topologically a torus is a technical hypothesis in order to avoid topological obstructions such as the hairy ball theorem, but it may be that the hypothesis can be dropped (and it may in fact be true, in the ")#mi("{M = ({\\bf R}/{\\bf Z})^d}")#text(" case at least, that ")#mi("{{\\mathcal E}}")#text(" is dense in all of ")#mi("{{\\mathcal F}}")#text(", not just in a non-empty open subset).")

#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/19/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds-ii-non-rigidity-of-euler-flows/#comment-512854")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2019")])]

#text("Awesome paper,I was just reading how to form eddies,seems I have many years to catch up to become your level")#linebreak()#text(" .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/041e0d8efb404a6a2cf18b2270a848edf2c64e454a9f79bc7b5042d769355180-62fe160b29fccbce5500ff3d0ac989c0d3a0e9678d38be9c88331b114d02c1d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/19/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds-ii-non-rigidity-of-euler-flows/#comment-512865")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2019")])]

#text("There is an extraneous “. We say that” at the end of the post")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a7dbf0fc4f87d9dd7d9265b8d742254449560def99ea67f4a0bdffbedeff30-6357b353d4083e451e5adfb16009055f7689e1058db5dc6c29d9cb3641abf55b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Baez")]], [#link("https://terrytao.wordpress.com/2019/02/19/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds-ii-non-rigidity-of-euler-flows/#comment-512867")[#strong[#text("John Baez")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2019")])]

#text("“just obeys the divergence-free relation ")#mi("\\nabla_k u^k")#text("“. You want to add “= 0”.")

#text("I’m just starting to read this blog post. Looks great!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/19/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds-ii-non-rigidity-of-euler-flows/#comment-512904")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2019")])]

#text("Is there any indication that for large dimension it is easier to establish finite time blowup for some Euler flows?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/19/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds-ii-non-rigidity-of-euler-flows/#comment-512923")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2019")])]

#text("Even the best PDE expert, they do not understand Terry’work.Me too.But I has seen a giant bridge across the Pacific of Pro.Tao.")#linebreak()#text(" Dr.Tao is not only a mathematician, he is regarded as the Coach of the world’s biggest football team in maths.He is very clever in tactics and strategy in doing maths.Opponent never discover Terry ‘s plot. Today I truly congratuate Terry. Next time I am waiting to be fun from Goldbach strong conjecture from Terry.At any rate , the knight Terry will certainly conquere Goldbach “monster” in early 2019. If this happens early, all that day I am full although I do not eat any more.")#linebreak()#text(" Best wishes,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/19/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds-ii-non-rigidity-of-euler-flows/#comment-513251")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2019")])]

#text("I completely agree above ” anonymous” professor with such remark.I am not a mathematician.But I am very talented in guess and predictions.When I was a student, I was the fastest and the best accurate in doing multiple choices if comparing with the whole university.When I went out of university,I have many times of arguments with doctor, teacher, engineer,technician,processor….etc.But finally,the victories belong to me.I always win in betting which football team will win in World cup,I also win lottery over 200 times.So,I guarantee that Pro.Tao will do a next great breakthrough after FLT and Poincare conjecture in 2019.You try to imagine that 100 current famous mathematicians like 100 billiard cubes into a tables, and which cube will run into a hole.I affirm that only cube in a hole is certain Pro.Tao")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/19/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds-ii-non-rigidity-of-euler-flows/#comment-513329")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2019")])]

#text("Oh,regardless of yours’ dislike (10000 dislikes are not meaningful to me).I never lose in betting.This is the first time that I bet against the whole math community.Despite of saying 1000 times, I always claim that Pro.Tao will certainly do a century great breakthrough work in 2019.When I was a student , at the same time I against 1000 others(including professor),but I finally win.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/19/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds-ii-non-rigidity-of-euler-flows/#comment-513576")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2019")])]

#text("I find myself will agree. All PdE mathematicians bow down at Terry. Even expert find his Navier Stoke don’t blow up in Sobolev space, which I thought ever since my child years. In June 2016 Terry proves the Riemann hypotheses, which will change number theory ever since the days of Gauss and Fermat. If only he put the proof on ArXiV soon.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/02/19/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds-ii-non-rigidity-of-euler-flows/#comment-512930")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2019")])]

#text("Well, every smooth solution to the Euler equation ")#mi("u: [0,T) \\to \\Gamma(TM)")#text(", ")#mi("p: [0,T) \\times M \\to {\\bf R}")#text(" in some ")#mi("d")#text("-dimensional manifold ")#mi("M")#text(" can be automatically lifted to a solution ")#mi("\\tilde u: [0,T) \\to \\Gamma(M \\times N)")#text(", ")#mi("\\tilde p: [0,T) \\times M \\times N \\to {\\bf R}")#text(" in a ")#mi("d+d^{\\prime}")#text("-dimensional product manifold ")#mi("M \\times N")#text(" (for an arbitrary ")#mi("d^{\\prime}")#text("-dimensional manifold ")#mi("N")#text(") by considering the “purely horizontal” flow")

#mi("\\tilde u(x,y) := u^i(x) \\frac{d}{dx^i}")

#text("and")

#mi("\\tilde p(x,y) := p(x)")

#text("for ")#mi("x \\in M, y \\in N")#text(", where ")#mi("x = (x^1,\\dots,x^d)")#text(" denote local coordinates for the ")#mi("x")#text(" variable. As a consequence, if one can prove global regularity in higher dimensions, one automatically gets global regularity in lower dimensions as a consequence; contrapositively, if one can construct a lower dimensional example of finite time blowup, one also gets finite time blowup examples in all higher dimensions. So if one is set on proving finite time blowup, it ought to be easier to do so in higher dimensions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/12e548896ed935a205f016e1b71ed726474be179a4a750a9f712465d989ae2e1-97b4703b3273421e391281cd7e4d271fb74b251af6c4f3b54a3e2286e7da907d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Taylor")]], [#link("https://terrytao.wordpress.com/2019/02/19/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds-ii-non-rigidity-of-euler-flows/#comment-512911")[#strong[#text("Richard Taylor")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2019")])]

#text("Once bitten twice shy, Terry? ;)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/19/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds-ii-non-rigidity-of-euler-flows/#comment-513014")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2019")])]

#text("By compactifying the spacetime manifold ")#mi("\\mathbb R \\times M")#text(" and considering the subgroup of automorphisms preserving the PDE system, if for some initial data there is a blowup at some spacetime point with corresponding time coordinate ")#mi("t = +\\infty")#text(" and there is an automorphism preserving the PDE system and sending this blowup point (with ")#mi("t = +\\infty")#text(") to a point with ")#mi("t \\in (0, \\infty)")#text(", it seems that such automorphism “transfers” the infinite-time blowup to a finite-time blowup. Hence it seems helpful to study this subgroup of spacetime automorphisms which preserve the PDE system.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/02/19/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds-ii-non-rigidity-of-euler-flows/#comment-513719")[#strong[#text("Navies – Pages")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2019")]

#text("[…] which is not quite incompressible (due to the failure of the volume preservation condition (2) in this case) but still satisfies a system of equations (coupled with a passive scalar […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/02/19/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds-ii-non-rigidity-of-euler-flows/#comment-625699")[#strong[#text("Cuatro matemáticos demuestran que era imposible predecir el destino de 29.000 patitos de goma en el mar – Info-spain")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2021")]

#text("[…] la red social Twitter, se enteró de que el investigador australiano Terence Tao había publicado en su blog los últimos detalles de su batalla para resolver ese problema del milenio. Tao fue un niño […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/02/19/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds-ii-non-rigidity-of-euler-flows/#comment-625740")[#strong[#text("Cuatro matemáticos demuestran que era imposible predecir el destino de 29.000 patitos de goma en el mar » Mascarillas para protección del coronavirus")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2021")]

#text("[…] la red social Twitter, se enteró de que el investigador australiano Terence Tao había publicado en su blog los últimos detalles de su batalla para resolver ese problema del milenio. Tao fue un niño […]")
]
