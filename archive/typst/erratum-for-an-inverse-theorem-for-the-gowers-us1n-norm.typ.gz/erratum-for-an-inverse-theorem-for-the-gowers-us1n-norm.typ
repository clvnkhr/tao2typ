// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/04/25/erratum-for-an-inverse-theorem-for-the-gowers-us1n-norm/
// Converted to Typst by tao2typ: "2026-10-14T11:11:52.009855+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Erratum for “An inverse theorem for the Gowers U^{s+1}[N]-norm”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Erratum for “An inverse theorem for the Gowers U^{s+1}[N]-norm”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 April 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/04/25/erratum-for-an-inverse-theorem-for-the-gowers-us1n-norm/")[#text("https://terrytao.wordpress.com/2024/04/25/erratum-for-an-inverse-theorem-for-the-gowers-us1n-norm/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The purpose of this post is to report an ")#link("https://terrytao.wordpress.com/wp-content/uploads/2024/04/erratum-4.pdf")[#text("erratum")]#text(" to the 2012 paper “")#link("https://zbmath.org/1282.11007")[#text("An inverse theorem for the Gowers ")#mi("{U^{s+1}[N]}")#text("-norm")]#text("” of ")#link("https://people.maths.ox.ac.uk/greenbj/")[#text("Ben Green")]#text(", myself, and ")#link("https://ma.huji.ac.il/~tamarz/")[#text("Tamar Ziegler")]#text(" (previously discussed in ")#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/")[#text("this blog post")]#text("). The main results of this paper have been superseded with stronger quantitative results, first in ")#link("https://arxiv.org/abs/1811.00718")[#text("work of Manners")]#text(" (using somewhat different methods), and more recently in a remarkable ")#link("https://arxiv.org/abs/2402.17994")[#text("paper of Leng, Sah, and Sawhney")]#text(" which combined the methods of our paper with several new innovations to obtain quite strong bounds (of quasipolynomial type); see also an alternate proof of our main results (again by quite different methods) ")#link("https://zbmath.org/1503.37012")[#text("by Candela and Szegedy")]#text(". In the course of their work, they discovered some fixable but nontrivial errors in our paper. These (rather technical) issues were already implicitly corrected in this followup work which supersedes our own paper, but for the sake of completeness we are also providing a formal erratum for our original paper, which can be found ")#link("https://terrytao.wordpress.com/wp-content/uploads/2024/04/erratum-4.pdf")[#text("here")]#text(". We thank Leng, Sah, and Sawhney for bringing these issues to our attention.")

#text("Excluding some minor (mostly typographical) issues which we also have reported in this erratum, the main issues stemmed from a conflation of two notions of a degree ")#mi("{s}")#text(" filtration")

#align(center)[#tao-fit-display[#mitex("G = G_0 \\geq G_1 \\geq \\dots \\geq G_s \\geq G_{s+1} = \\{1\\}")]]

#text("of a group ")#mi("{G}")#text(", which is a nested sequence of subgroups that obey the relation ")#mi("{[G_i,G_j] \\leq G_{i+j}}")#text(" for all ")#mi("{i,j}")#text(". The weaker notion (sometimes known as a ")#emph[#text("prefiltration")]#text(") permits the group ")#mi("{G_1}")#text(" to be strictly smaller than ")#mi("{G_0}")#text(", while the stronger notion requires ")#mi("{G_0}")#text(" and ")#mi("{G_1}")#text(" to equal. In practice, one can often move between the two concepts, as ")#mi("{G_1}")#text(" is always normal in ")#mi("{G_0}")#text(", and a prefiltration behaves like a filtration on every coset of ")#mi("{G_1}")#text(" (after applying a translation and perhaps also a conjugation). However, we did not clarify this issue sufficiently in the paper, and there are some places in the text where results that were only proven for filtrations were applied for prefiltrations. The erratum fixes this issues, mostly by clarifying that we work with filtrations throughout (which requires some decomposition into cosets in places where prefiltrations are generated). Similar adjustments need to be made for multidegree filtrations and degree-rank filtrations, which we also use heavily on our paper.")

#text("In most cases, fixing this issue only required minor changes to the text, but there is one place (Section 8) where there was a non-trivial problem: we used the claim that the final group ")#mi("{G_s}")#text(" was a central group, which is true for filtrations, but not necessarily for prefiltrations. This fact (or more precisely, a multidegree variant of it) was used to claim a factorization for a certain product of nilcharacters, which is in fact not true as stated. In the erratum, a substitute factorization for a slightly different product of nilcharacters is provided, which is still sufficient to conclude the main result of this part of the paper (namely, a statistical linearization of a certain family of nilcharacters in the shift parameter ")#mi("{h}")#text(").")

#text("Again, we stress that these issues do not impact the paper of Leng, Sah, and Sawhney, as they adapted the methods in our paper in a fashion that avoids these errors.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/25/erratum-for-an-inverse-theorem-for-the-gowers-us1n-norm/#comment-684815")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2024")])]

#text("Possible to check this in Lean?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/04/25/erratum-for-an-inverse-theorem-for-the-gowers-us1n-norm/#comment-684819")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2024")])]

#text("In principle I believe all of the theory required to prove the inverse theory for the Gowers norms is formalizable, but it would require significant amounts of time and effort at our current level of proof formalization technology; even the equidistribution theory of nilsequences, which is a relatively small component of the theory, would require quite a bit of setup. (However, the U^3 theory is significantly simpler, particularly over finite fields and may potentially be within reach of current additive combinatorics formalization projects.)")

#text("Given that there are now multiple proofs of this theorem, I think that having the result formalized is not an urgent priority for the field; also, I can imagine that simpler proofs could emerge in the future, and that formalizing one of the current proofs with current tools may not be the most efficient strategy. Sometimes it makes sense simply to wait…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/25/erratum-for-an-inverse-theorem-for-the-gowers-us1n-norm/#comment-684836")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2024")])]

#text("If it requires significant effort and the underlying theory is not coded in Lean already makes it an interesting challenge of Lean’s expressiveness. That the error was uncorrected for around 10+ years makes it a canonical example for the practical application of mechanical proof checking to the working mathematician’s toolkit: crowdsourced acceptance of a proof is evidently unreliable. Would it merit a BS, MS or PHD for a student in search of a topic to say demonstrate both that the erroneous proof doesnt check, and that the simplest recent proof does check, putting the work in to code the theory of equidistribution theory of nilsequences and so on? Framing it as a suitable thesis topic should motivate someone to take it on.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/04/25/erratum-for-an-inverse-theorem-for-the-gowers-us1n-norm/#comment-684879")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2024")])]

#text("Pure formalization projects are not ideal for thesis projects, as they may not provide sufficient broader mathematical training, and may also not allow the student to achieve sufficient recognition in an active mathematical field that would advance their career prospects. (In the future, it is conceivable that mathematical formalization itself becomes a mainstream academic profession, but we aren’t quite at that point yet.) Also, such a single-author approach negates one of the most compelling advantages of a formalization project, which is that it can be parallelized and crowdsourced to a far greater extent than most other mathematical projects.")

#text("There are beginning to be examples of formalization “hackathons” during summer schools or workshops in which students work together to formalize various small components of a larger task in a specialized field, allowing them to practice both the mathematics of that field and the language of the proof assistant. This to me is a more promising model; if for instance a workshop in additive combinatorics was interested, then the formalization of various components of the theory of inverse theorems and nilsequences could indeed be feasible. (I think there may be a group at Bonn that may already be working somewhat in this direction, though.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/25/erratum-for-an-inverse-theorem-for-the-gowers-us1n-norm/#comment-684883")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2024")])]

#text("There is a town/gown gap between what is considered valuable and meaty in pure math and what is actually pretty hard and ought to be considered valuable and meaty in applied computational symbolic logic and the formal representation of mathematical ideas. This is reflected in considerable and constant frustration that I see on the Lean chat website in the matter of funding for work on proof checking. A lot of effort and attention has lately gone into whether LLMs can make it easier to automate what is apparently a boring task. For some people it is interesting and exciting to find ways to encode these theories. The Lean chat website is buzzing 24/7 and you can get almost instant help for very obscure technical questions. I’ve never seen anything like it. The real problem seems to be the prevailing value system that gives low marks and recognition to the encoding task. Would it help if we called it “computer science” or something like that? But wouldn’t that also create a status and communication gap between people who like to do the encoding and people who are apt to create the (occasionally flawed) content to be encoded?")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/25/erratum-for-an-inverse-theorem-for-the-gowers-us1n-norm/#comment-684887")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2024")])]

#text("Hey Terry, are you going to say anything about the 15k+ dead Palestinian children or is your sympathy only reserved for Israeli captives (half of whom were soldiers)? I noticed you signed a petition about the Israeli captives, but have said nothing about the thousands of dead Palestinian children.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/25/erratum-for-an-inverse-theorem-for-the-gowers-us1n-norm/#comment-684918")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2024")])]

#text("What petition and why does it matter? Not like there is anything we can do to change the situation…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/25/erratum-for-an-inverse-theorem-for-the-gowers-us1n-norm/#comment-684919")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2024")])]

#text("Not to dismiss the suffering of the Palestinian people, but yeah, nothing we can do")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/25/erratum-for-an-inverse-theorem-for-the-gowers-us1n-norm/#comment-684920")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2024")])]

#text("Page 59 of the corrected paper (beginning of section 11) has a minor typo.")

#emph[#text("[Could you be more specific? I could not locate the issue. -T]")]
]
