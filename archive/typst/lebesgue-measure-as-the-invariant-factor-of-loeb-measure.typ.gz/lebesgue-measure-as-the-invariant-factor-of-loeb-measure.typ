// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/06/25/lebesgue-measure-as-the-invariant-factor-of-loeb-measure/
// Converted to Typst by tao2typ: "2026-10-14T16:37:25.893589+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Lebesgue measure as the invariant factor of Loeb measure", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Lebesgue measure as the invariant factor of Loeb measure")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 June 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/06/25/lebesgue-measure-as-the-invariant-factor-of-loeb-measure/")[#text("https://terrytao.wordpress.com/2014/06/25/lebesgue-measure-as-the-invariant-factor-of-loeb-measure/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("There are a number of ways to ")#link("http://en.wikipedia.org/wiki/Construction_of_the_real_numbers")[#text("construct the real numbers")]#text(" ")#mi("{{\\bf R}}")#text(", for instance")

#list(
[#text("as the ")#link("http://en.wikipedia.org/wiki/Complete_metric_space")[#text("metric completion")]#text(" of ")#mi("{{\\bf Q}}")#text(" (thus, ")#mi("{{\\bf R}}")#text(" is defined as the set of Cauchy sequences of rationals, modulo Cauchy equivalence);")],
[#text("as the space of ")#link("http://en.wikipedia.org/wiki/Dedekind_cut")[#text("Dedekind cuts")]#text(" on the rationals ")#mi("{{\\bf Q}}")#text(";")],
[#text("as the space of ")#link("http://www.ams.org/notices/200402/what-is.pdf")[#text("quasimorphisms")]#text(" ")#mi("{\\phi: {\\bf Z} \\rightarrow {\\bf Z}}")#text(" on the integers, quotiented by bounded functions. (I believe this construction first appears in ")#link("http://www.ams.org/mathscinet-getitem?mr=821569")[#text("this paper of Street")]#text(", who credits the idea to Schanuel, though the germ of this construction arguably goes all the way back to Eudoxus.)")]
)

#text("There is also a fourth family of constructions that proceeds via nonstandard analysis, as a special case of what is known as the ")#emph[#text("nonstandard hull construction")]#text(". (Here I will assume some basic familiarity with nonstandard analysis and ultraproducts, as covered for instance in ")#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/")[#text("this previous blog post")]#text(".) Given an unbounded nonstandard natural number ")#mi("{N \\in {}^* {\\bf N} \\backslash {\\bf N}}")#text(", one can define two external additive subgroups of the nonstandard integers ")#mi("{{}^* {\\bf Z}}")#text(":")

#list(
[#text("The group ")#tao-math("{O(N) := \\{ n \\in {}^* {\\bf Z}: \\left|n\\right| \\leq CN \\text{ for some } C \\in {\\bf N} \\}}", block: false)#text(" of all nonstandard integers of magnitude less than or comparable to ")#mi("{N}")#text("; and")],
[#text("The group ")#tao-math("{o(N) := \\{ n \\in {}^* {\\bf Z}: \\left|n\\right| \\leq C^{-1} N \\text{ for all } C \\in {\\bf N} \\}}", block: false)#text(" of nonstandard integers of magnitude infinitesimally smaller than ")#mi("{N}")#text(".")]
)

#text("The group ")#mi("{o(N)}")#text(" is a subgroup of ")#mi("{O(N)}")#text(", so we may form the quotient group ")#mi("{O(N)/o(N)}")#text(". This space is isomorphic to the reals ")#mi("{{\\bf R}}")#text(", and can in fact be used to construct the reals:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" For any coset ")#mi("{n + o(N)}")#text(" of ")#mi("{O(N)/o(N)}")#text(", there is a unique real number ")#mi("{\\text{st} \\frac{n}{N}}")#text(" with the property that ")#mi("{\\frac{n}{N} = \\text{st} \\frac{n}{N} + o(1)}")#text(". The map ")#mi("{n + o(N) \\mapsto \\text{st} \\frac{n}{N}}")#text(" is then an isomorphism between the additive groups ")#mi("{O(N)/o(N)}")#text(" and ")#mi("{{\\bf R}}")#text(".")
]

#emph[#text("Proof:")]#text(" Uniqueness is clear. For existence, observe that the set ")#mi("{\\{ x \\in {\\bf R}: Nx \\leq n + o(N) \\}}")#text(" is a Dedekind cut, and its supremum can be verified to have the required properties for ")#mi("{\\text{st} \\frac{n}{N}}")#text(". ")#mi("\\Box")

#text("In a similar vein, we can view the unit interval ")#mi("{[0,1]}")#text(" in the reals as the quotient ")#metadata(none) <tao-87f633634cc4b02f6286>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("[0,1] \\equiv [N] / o(N)")]]

#text("where ")#mi("{[N]}")#text(" is the nonstandard (i.e. internal) set ")#mi("{\\{ n \\in {\\bf N}: n \\leq N \\}}")#text("; of course, ")#mi("{[N]}")#text(" is not a group, so one should interpret ")#mi("{[N]/o(N)}")#text(" as the image of ")#mi("{[N]}")#text(" under the quotient map ")#mi("{{}^* {\\bf Z} \\rightarrow {}^* {\\bf Z} / o(N)}")#text(" (or ")#mi("{O(N) \\rightarrow O(N)/o(N)}")#text(", if one prefers). Or to put it another way, ")#link(<tao-87f633634cc4b02f6286>)[#text("(1)")]#text(" asserts that ")#mi("{[0,1]}")#text(" is the image of ")#mi("{[N]}")#text(" with respect to the map ")#mi("{\\pi: n \\mapsto \\text{st} \\frac{n}{N}}")#text(".")

#text("In this post I would like to record a nice measure-theoretic version of the equivalence ")#link(<tao-87f633634cc4b02f6286>)[#text("(1)")]#text(", which essentially appears already in standard texts on Loeb measure (see e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=1810844")[#text("this text of Cutland")]#text("). To describe the results, we must first quickly recall the construction of ")#emph[#text("Loeb measure")]#text(" on ")#mi("{[N]}")#text(". Given an internal subset ")#mi("{A}")#text(" of ")#mi("{[N]}")#text(", we may define the elementary measure ")#mi("{\\mu_0(A)}")#text(" of ")#mi("{A}")#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\mu_0(A) := \\text{st} \\frac{\\left|A\\right|}{N}.", block: true)]]

#text("This is a finitely additive probability measure on the Boolean algebra of internal subsets of ")#mi("{[N]}")#text(". We can then construct the ")#emph[#text("Loeb outer measure")]#text(" ")#mi("{\\mu^*(A)}")#text(" of any subset ")#mi("{A \\subset [N]}")#text(" in complete analogy with Lebesgue outer measure by the formula")

#align(center)[#tao-fit-display[#mitex("\\mu^*(A) := \\inf \\sum_{n=1}^\\infty \\mu_0(A_n)")]]

#text("where ")#mi("{(A_n)_{n=1}^\\infty}")#text(" ranges over all sequences of internal subsets of ")#mi("{[N]}")#text(" that cover ")#mi("{A}")#text(". We say that a subset ")#mi("{A}")#text(" of ")#mi("{[N]}")#text(" is ")#emph[#text("Loeb measurable")]#text(" if, for any (standard) ")#mi("{\\epsilon>0}")#text(", one can find an internal subset ")#mi("{B}")#text(" of ")#mi("{[N]}")#text(" which differs from ")#mi("{A}")#text(" by a set of Loeb outer measure at most ")#mi("{\\epsilon}")#text(", and in that case we define the ")#emph[#text("Loeb measure")]#text(" ")#mi("{\\mu(A)}")#text(" of ")#mi("{A}")#text(" to be ")#mi("{\\mu^*(A)}")#text(". It is a routine matter to show (e.g. using the Carathéodory extension theorem) that the space ")#mi("{{\\mathcal L}}")#text(" of Loeb measurable sets is a ")#mi("{\\sigma}")#text("-algebra, and that ")#mi("{\\mu}")#text(" is a countably additive probability measure on this space that extends the elementary measure ")#mi("{\\mu_0}")#text(". Thus ")#mi("{[N]}")#text(" now has the structure of a probability space ")#mi("{([N], {\\mathcal L}, \\mu)}")#text(".")

#text("Now, the group ")#mi("{o(N)}")#text(" acts (Loeb-almost everywhere) on the probability space ")#mi("{[N]}")#text(" by the addition map, thus ")#mi("{T^h n := n+h}")#text(" for ")#mi("{n \\in [N]}")#text(" and ")#mi("{h \\in o(N)}")#text(" (excluding a set of Loeb measure zero where ")#mi("{n+h}")#text(" exits ")#mi("{[N]}")#text("). This action is clearly seen to be measure-preserving. As such, we can form the ")#emph[#text("invariant factor")]#text(" ")#mi("{Z^0_{o(N)}([N]) = ([N], {\\mathcal L}^{o(N)}, \\mu\\downharpoonright_{{\\mathcal L}^{o(N)}})}")#text(", defined by restricting attention to those Loeb measurable sets ")#mi("{A \\subset [N]}")#text(" with the property that ")#mi("{T^h A}")#text(" is equal ")#mi("{\\mu}")#text("-almost everywhere to ")#mi("{A}")#text(" for each ")#mi("{h \\in o(N)}")#text(".")

#text("The claim is then that this invariant factor is equivalent (up to almost everywhere equivalence) to the unit interval ")#mi("{[0,1]}")#text(" with Lebesgue measure ")#mi("{m}")#text(" (and the trivial action of ")#mi("{o(N)}")#text("), by the same factor map ")#mi("{\\pi: n \\mapsto \\text{st} \\frac{n}{N}}")#text(" used in ")#link(<tao-87f633634cc4b02f6286>)[#text("(1)")]#text(". More precisely:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" Given a set ")#mi("{A \\in {\\mathcal L}^{o(N)}}")#text(", there exists a Lebesgue measurable set ")#mi("{B \\subset [0,1]}")#text(", unique up to ")#mi("{m}")#text("-a.e. equivalence, such that ")#mi("{A}")#text(" is ")#mi("{\\mu}")#text("-a.e. equivalent to the set ")#mi("{\\pi^{-1}(B) := \\{ n \\in [N]: \\text{st} \\frac{n}{N} \\in B \\}}")#text(". Conversely, if ")#mi("{B \\in [0,1]}")#text(" is Lebesgue measurable, then ")#mi("{\\pi^{-1}(B)}")#text(" is in ")#mi("{{\\mathcal L}^{o(N)}}")#text(", and ")#mi("{\\mu( \\pi^{-1}(B) ) = m( B )}")#text(".")
]

#text("More informally, we have the measure-theoretic version")

#align(center)[#tao-fit-display[#mitex("[0,1] \\equiv Z^0_{o(N)}( [N] )")]]

#text("of ")#link(<tao-87f633634cc4b02f6286>)[#text("(1)")]#text(".")

#emph[#text("Proof:")]#text(" We first prove the converse. It is clear that ")#mi("{\\pi^{-1}(B)}")#text(" is ")#mi("{o(N)}")#text("-invariant, so it suffices to show that ")#mi("{\\pi^{-1}(B)}")#text(" is Loeb measurable with Loeb measure ")#mi("{m(B)}")#text(". This is easily verified when ")#mi("{B}")#text(" is an elementary set (a finite union of intervals). By countable subadditivity of outer measure, this implies that Loeb outer measure of ")#mi("{\\pi^{-1}(E)}")#text(" is bounded by the Lebesgue outer measure of ")#mi("{E}")#text(" for any set ")#mi("{E \\subset [0,1]}")#text("; since every Lebesgue measurable set differs from an elementary set by a set of arbitrarily small Lebesgue outer measure, the claim follows.")

#text("Now we establish the forward claim. Uniqueness is clear from the converse claim, so it suffices to show existence. Let ")#mi("{A \\in {\\mathcal L}^{o(N)}}")#text(". Let ")#mi("{\\epsilon>0}")#text(" be an arbitrary standard real number, then we can find an internal set ")#mi("{A_\\epsilon \\subset [N]}")#text(" which differs from ")#mi("{A}")#text(" by a set of Loeb measure at most ")#mi("{\\epsilon}")#text(". As ")#mi("{A}")#text(" is ")#mi("{o(N)}")#text("-invariant, we conclude that for every ")#mi("{h \\in o(N)}")#text(", ")#mi("{A_\\epsilon}")#text(" and ")#mi("{T^h A_\\epsilon}")#text(" differ by a set of Loeb measure (and hence elementary measure) at most ")#mi("{2\\epsilon}")#text(". By the (contrapositive of the) ")#link("http://en.wikipedia.org/wiki/Overspill")[#text("underspill principle")]#text(", there must exist a standard ")#mi("{\\delta>0}")#text(" such that ")#mi("{A_\\epsilon}")#text(" and ")#mi("{T^h A_\\epsilon}")#text(" differ by a set of elementary measure at most ")#mi("{2\\epsilon}")#text(" for all ")#tao-math("{\\left|h\\right| \\leq \\delta N}", block: false)#text(". If we then define the nonstandard function ")#mi("{f_\\epsilon: [N] \\rightarrow {}^* {\\bf R}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("f(n) := \\text{st} \\frac{1}{\\delta N} \\sum_{m \\in [N]: m \\leq n \\leq m+\\delta N} 1_{A_\\epsilon}(m),")]]

#text("then from the (nonstandard) triangle inequality we have")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{N} \\sum_{n \\in [N]} \\left|f(n) - 1_{A_\\epsilon}(n)\\right| \\leq 3\\epsilon", block: true)]]

#text("(say). On the other hand, ")#mi("{f}")#text(" has the Lipschitz continuity property")

#align(center)[#tao-fit-display[#tao-math("\\left|f(n)-f(m)\\right| \\leq \\frac{2\\left|n-m\\right|}{\\delta N}", block: true)]]

#text("and so in particular we see that")

#align(center)[#tao-fit-display[#mitex("\\text{st} f(n) = \\tilde f( \\text{st} \\frac{n}{N} )")]]

#text("for some Lipschitz continuous function ")#mi("{\\tilde f: [0,1] \\rightarrow [0,1]}")#text(". If we then let ")#mi("{E_\\epsilon}")#text(" be the set where ")#mi("{\\tilde f \\geq 1 - \\sqrt{\\epsilon}}")#text(", one can check that ")#mi("{A_\\epsilon}")#text(" differs from ")#mi("{\\pi^{-1}(E_\\epsilon)}")#text(" by a set of Loeb outer measure ")#mi("{O(\\sqrt{\\epsilon})}")#text(", and hence ")#mi("{A}")#text(" does so also. Sending ")#mi("{\\epsilon}")#text(" to zero, we see (from the converse claim) that ")#mi("{1_{E_\\epsilon}}")#text(" is a Cauchy sequence in ")#mi("{L^1}")#text(" and thus converges in ")#mi("{L^1}")#text(" for some Lebesgue measurable ")#mi("{E}")#text(". The sets ")#mi("{A_\\epsilon}")#text(" then converge in Loeb outer measure to ")#mi("{\\pi^{-1}(E)}")#text(", giving the claim. ")#mi("\\Box")

#text("Thanks to ")#link("http://en.wikipedia.org/wiki/Lebesgue_differentiation_theorem")[#text("the Lebesgue differentiation theorem")]#text(", the conditional expectation ")#mi("{{\\bf E}( f | Z^0_{o(N)}([N]))}")#text(" of a bounded Loeb-measurable function ")#mi("{f: [N] \\rightarrow {\\bf R}}")#text(" can be expressed (as a function on ")#mi("{[0,1]}")#text(", defined ")#mi("{m}")#text("-a.e.) as")

#align(center)[#tao-fit-display[#mitex("{\\bf E}( f | Z^0_{o(N)}([N]))(x) := \\lim_{\\epsilon \\rightarrow 0} \\frac{1}{2\\epsilon} \\int_{[x-\\epsilon N,x+\\epsilon N]} f\\ d\\mu.")]]

#text("By the abstract ergodic theorem from ")#link("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/")[#text("the previous post")]#text(", one can also view this conditional expectation as the element in the closed convex hull of the shifts ")#mi("{T^h f}")#text(", ")#mi("{h = o(N)}")#text(" of minimal ")#mi("{L^2}")#text(" norm. In particular, we obtain a form of the von Neumann ergodic theorem in this context: the averages ")#mi("{\\frac{1}{H} \\sum_{h=1}^H T^h f}")#text(" for ")#mi("{H=O(N)}")#text(" converge (as a net, rather than a sequence) in ")#mi("{L^2}")#text(" to ")#mi("{{\\bf E}( f | Z^0_{o(N)}([N]))}")#text(".")

#text("If ")#mi("{f: [N] \\rightarrow [-1,1]}")#text(" is (the standard part of) an internal function, that is to say the ultralimit of a sequence ")#mi("{f_n: [N_n] \\rightarrow [-1,1]}")#text(" of finitary bounded functions, one can view the measurable function ")#mi("{F := {\\bf E}( f | Z^0_{o(N)}([N]))}")#text(" as a limit of the ")#mi("{f_n}")#text(" that is analogous to the “graphons” that emerge as limits of graphs (see e.g. the recent text of Lovasz on ")#link("http://www.ams.org/mathscinet-getitem?mr=3012035")[#text("graph limits")]#text("). Indeed, the measurable function ")#mi("{F: [0,1] \\rightarrow [-1,1]}")#text(" is related to the discrete functions ")#mi("{f_n: [N_n] \\rightarrow [-1,1]}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\int_a^b F(x)\\ dx = \\text{st} \\lim_{n \\rightarrow p} \\frac{1}{N_n} \\sum_{a N_n \\leq m \\leq b N_n} f_n(m)")]]

#text("for all ")#mi("{0 \\leq a < b \\leq 1}")#text(", where ")#mi("{p}")#text(" is the nonprincipal ultrafilter used to define the nonstandard universe. In particular, from the Arzela-Ascoli diagonalisation argument there is a subsequence ")#mi("{n_j}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\int_a^b F(x)\\ dx = \\lim_{j \\rightarrow \\infty} \\frac{1}{N_{n_j}} \\sum_{a N_{n_j} \\leq m \\leq b N_{n_j}} f_n(m),")]]

#text("thus ")#mi("{F}")#text(" is the asymptotic density function of the ")#mi("{f_n}")#text(". For instance, if ")#mi("{f_n}")#text(" is the indicator function of a randomly chosen subset of ")#mi("{[N_n]}")#text(", then the asymptotic density function would equal ")#mi("{1/2}")#text(" (almost everywhere, at least).")

#text("I’m continuing to look into understanding the ergodic theory of ")#mi("{o(N)}")#text(" actions, as I believe this may allow one to apply ergodic theory methods to the “single-scale” or “non-asymptotic” setting (in which one averages only over scales comparable to a large parameter ")#mi("{N}")#text(", rather than the traditional asymptotic approach of letting the scale go to infinity). I’m planning some further posts in this direction, though this is still a work in progress.")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2014/06/25/lebesgue-measure-as-the-invariant-factor-of-loeb-measure/comment-page-1/#comment-379778")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2014")])]

#text("Expository tag was left out.")

#emph[#text("[Well spotted! Added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09581d1d24def81624cb7e1ab800581929ead4a96ce88f043a382a078666edb4-700dc8156594914b289927512591c2fa59393ea7cf9632831a5d00a00f0b6f40.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Todd Trimble")]], [#link("https://terrytao.wordpress.com/2014/06/25/lebesgue-measure-as-the-invariant-factor-of-loeb-measure/comment-page-1/#comment-379798")[#strong[#text("Todd Trimble")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2014")])]

#text("My understanding is that Street had learned of this construction of ")#mi("\\mathbb{R}")#text(" from Schanuel, and that Schanuel in some sense credits the idea to Eudoxus.")

#text("EDIT: A little of the history of the “Eudoxus reals” is told here: ")#link("http://arxiv.org/pdf/math/0405454v1.pdf")[#text("http://arxiv.org/pdf/math/0405454v1.pdf")]#text(" (see section 5). Indeed it is due to Schanuel (if not Eudoxus).")

#emph[#text("[References updated – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09b347b0cc390c2eb22c2ff1c7c2fb61b7f0725968a25dbd03ed282f71cbbe25-41a0f8918e73828fdf6b34aef93af5ad50da425cbd812ae491a977eaddeda04f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joerg Grande")]], [#link("https://terrytao.wordpress.com/2014/06/25/lebesgue-measure-as-the-invariant-factor-of-loeb-measure/comment-page-1/#comment-379805")[#strong[#text("Joerg Grande")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2014")])]

#text("To construct the reals as the quotient ")#mi("O(N)/o(N)")#text(", the definition of ")#mi("o(N)")#text(" should not refer to ")#mi("{\\bf R}")#text(". Perhaps ")#tao-math("o(N) := \\{ n \\in {}^* {\\bf Z} : c \\left|n\\right| \\leq N, \\text{ for all } c \\in {\\bf N}, c > 0 \\}", block: false)#text("?")

#emph[#text("[Definition changed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7bf107c3783d7a6ca4e01321852ac52a13bf66490351ef74eb3fb30513dffd1c-8ac4bb51243c74382155f8362324925734c9c1107b8513baf7076451b3a35ec6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2014/06/25/lebesgue-measure-as-the-invariant-factor-of-loeb-measure/comment-page-1/#comment-380060")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2014")])]

#text("Norbert A’Campo attributes his construction of the real numbers to the Poincare rotation number (“slope”) of an orientation preserving homeomorphism of the circle. ")#link("http://arxiv.org/abs/math/0301015")[#text("http://arxiv.org/abs/math/0301015")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/679be868820eb1e0a34e7f37f68bfb61a96fb172fa2e80f401cc59146f2ef308-ec0413b01f6b53290ebd91fcb476d5ebf6827c9ef128d6b21dbaa7d42445035b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikhail Katz")]], [#link("https://terrytao.wordpress.com/2014/06/25/lebesgue-measure-as-the-invariant-factor-of-loeb-measure/comment-page-1/#comment-380119")[#strong[#text("Mikhail Katz")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2014")])]

#text("Beautiful post! Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7bf107c3783d7a6ca4e01321852ac52a13bf66490351ef74eb3fb30513dffd1c-8ac4bb51243c74382155f8362324925734c9c1107b8513baf7076451b3a35ec6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2014/06/25/lebesgue-measure-as-the-invariant-factor-of-loeb-measure/comment-page-1/#comment-380152")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2014")])]

#text("o(N) and O(N) are some pretty funny-looking groups. This works since N is transfinite? How is this different from compactifying on the circle ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01765f3c7e05429192a94f6e66e8b6597bc94b0f9ba99b7568e192872d49392d-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Francisco Javier Thayer")]], [#link("https://terrytao.wordpress.com/2014/06/25/lebesgue-measure-as-the-invariant-factor-of-loeb-measure/comment-page-1/#comment-380410")[#strong[#text("Francisco Javier Thayer")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2014")])]

#text("If ")#mi("T \\in \\star \\mathbb{N}")#text(" is infinite there are lots of “probability measures” ")#mi("\\mu")#text(" on the hyperinteger interval ")#mi("[1, T]")#text(" whose “loebification” ")#mi("L \\mu")#text(" is translation invariant by “standard” translations. For example ")#mi("\\mu(A) = \\frac{\\sum_{k \\in A} k^{-1}}{\\sum_{k=1}^T k^{-1}}")#text(" defined for internal sets ")#mi("A")#text(". This particular countably additive measure ")#mi("L \\mu")#text(" also has the property that multiplication by a standard positive integer ")#mi("a")#text(" is almost everywhere defined as a mapping on ")#mi("[1, t]")#text(", though is not measure preserving. This is a consequence of the fact ")#mi("L \\mu[1, \\lfloor T/a \\rfloor]")#text(" has ")#mi("L\\mu")#text(" measure ")#mi("1")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Algebraic probability spaces | What's new")]], [#link("https://terrytao.wordpress.com/2014/06/25/lebesgue-measure-as-the-invariant-factor-of-loeb-measure/comment-page-1/#comment-381793")[#strong[#text("Algebraic probability spaces | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2014")])]

#text("[…] to be convenient in the ergodic theory arising from nonstandard analysis (such as that described in this previous post), in which the groups involved are uncountable and the underlying spaces are not standard Borel […]")
]
