// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:34:56.852865+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Open question: effective Skolem-Mahler-Lech theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Open question: effective Skolem-Mahler-Lech theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 May 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/")[#text("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The Skolem-Mahler-Lech theorem in algebraic number theory is a significant generalisation of the obvious statement that a polynomial either has finitely many zeroes (in particular, the set of zeroes is bounded), or it vanishes identically. It appeals to me (despite not really being within my areas of expertise) because it is one of the simplest (non-artificial) results I know of which (currently) comes with an ")#emph[#text("ineffective")]#text(" bound – a bound which is provably finite, but which cannot be computed! It appears that to obtain an effective result, one may need a rather different proof. (I thank ")#link("http://homepages.inf.ed.ac.uk/kousha/")[#text("Kousha Etessami")]#text(" and ")#link("http://www.maths.ed.ac.uk/~tom/")[#text("Tom Lenagan")]#text(" for drawing this problem to my attention.)")

#text("Ineffective bounds seem to arise particularly often in number theory. I am aware of at least three ways in which they come in:")

#enum(start: 1, 
[#text("By using methods from soft (infinitary) analysis.")],
[#text("By using the fact that any finite set in a metric space is bounded (i.e. is contained in a ball of finite radius centred at a designated origin).")],
[#text("By using the fact that any set of finite diameter in a metric space is bounded.")]
)

#text("Regarding #1, there are often ways to make these arguments quantitative and effective, as discussed in ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("my previous post")]#text(". But #2 and #3 seem to be irreducibly ineffective: if you know that a set A has finite cardinality or finite diameter, you know it has finite distance to the origin, but an upper bound on the cardinality or diameter does not translate to an effective bound on the radius of the ball centred at the origin needed to contain the set. [In the spirit of the preceding post, one can conclude an effective “meta-bound” on such a set, establishing a large annulus ")#tao-math("\\{ x: N \\leq \\left|x\\right| \\leq N+F(N)\\}", block: false)#text(" in which the set has no presence, but this is not particularly satisfactory.] The problem with the Skolem-Mahler-Lech theorem is that all the known proofs use #2 at some point.")

#metadata(none) <tao-3263491dd15d4b15619a>

#text("So, what ")#emph[#text("is")]#text(" the Skolem-Mahler-Lech theorem? There are many ways to phrase it, but let us use the formulation using linear recurrence sequences, and in particular restrict attention to ")#emph[#text("integer")]#text(" linear recurrence sequences for simplicity (which was the scope of the original result of Skolem; Mahler and Lech handled algebraic numbers and elements of fields of characteristic zero respectively. The situation in positive characteristic is more subtle, as this ")#link("http://arxiv.org/abs/math/0510583")[#text("recent paper of Derksen shows")]#text("). By definition, an integer linear recurrence sequence is a sequence ")#mi("x_0, x_1, x_2, \\ldots")#text(" of integers which obeys a linear recurrence relation")

#align(center)[#tao-fit-display[#mitex("x_n = a_1 x_{n-1} + a_2 x_{n-2} + \\ldots + a_d x_{n-d}")]]

#text("for some integer ")#mi("d \\geq 1")#text(" (the ")#emph[#text("degree")]#text(" of the linear recurrence sequence), some integer coefficients ")#mi("a_1,\\ldots, a_d")#text(" with ")#mi("a_d")#text(" non-zero, and all ")#mi("n \\geq d")#text(". This data, together with the first d values ")#mi("x_0,\\ldots,x_{d-1}")#text(" of the sequence, clearly determine the entire sequence. The most famous example of a linear recurrence sequence is of course the ")#link("http://en.wikipedia.org/wiki/Fibonacci_number")[#text("Fibonacci sequence")]#text(" ")#mi("0,1,1,2,3,5,\\ldots")#text(" given by")

#align(center)[#mi("x_n = x_{n-1} + x_{n-2}")#text("; ")#mi("x_0 = 0, x_1 = 1")#text(".")]

#text("It is also a nice exercise to show that any polynomial sequence (e.g. the squares ")#mi("0, 1, 4, 9, \\ldots")#text(" is a linear recurrence sequence), or more generally that the component-wise sum or product of two linear recurrence sequences is another linear recurrence sequence. (Hint: this is related to the fact that the sum or product of ")#link("http://en.wikipedia.org/wiki/Algebraic_integer")[#text("algebraic integers")]#text(" is again an algebraic integer.)")

#text("The Skolem-Mahler-Lech theorem concerns the set of zeroes ")#mi("Z := \\{ n \\in {\\Bbb N}: x_n = 0 \\}")#text(" of a given integer linear recurrence sequence. In the case of the Fibonacci sequence, the set of zeroes is pretty boring, just {0}. To give a somewhat trivial example, the linear recurrence sequence")

#align(center)[#mi("x_n = x_{n-2}")#text("; ")#mi("x_0 = 0, x_1 = 1")]

#text("has a zero set which is the even numbers ")#mi("\\{0,2,4,\\ldots\\}")#text(". Similarly, the linear recurrence sequence")

#align(center)[#mi("x_n = x_{n-4} + x_{n-2}")#text("; ")#mi("x_0 = x_1 = x_3 = 0, x_2 = 1")]

#text("has a zero set ")#mi("\\{ 0, 1, 3, 5, \\ldots \\}")#text(", i.e. the odd numbers together with 0. One can ask whether more interesting zero sets are possible; for instance, can one design a linear recurrence system which only vanishes at the square numbers ")#mi("\\{0,1,4,9,\\ldots\\}")#text("? The Skolem-Mahler-Lech theorem says no:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Skolem-Mahler-Lech theorem")]#text(". The zero set of a linear recurrence set is eventually periodic, i.e. it agrees with a periodic set for sufficiently large n. In fact, a slightly stronger statement is true: the zero set is the union of a finite set and a finite number of residue classes ")#mi("\\{ n \\in {\\Bbb N}: n = r \\mod m \\}")#text(".")
]

#text("Interestingly, all known proofs of this theorem require that one introduce the ")#link("http://en.wikipedia.org/wiki/P-adic_number")[#text("p-adic integers")]#text(" ")#mi("{\\Bbb Z}_p")#text(" (or a thinly disguised version thereof). Let me quickly sketch a proof as follows (loosely based on the proof ")#link("http://www.ams.org/mathscinet-getitem?mr=819259")[#text("of Hansel")]#text("). Firstly it is not hard to reduce to the case where the final coefficient ")#mi("a_d")#text(" is non-zero. Then, by elementary linear algebra, one can get a closed form for the linear recurrence sequence as")

#align(center)[#tao-fit-display[#mitex("x_n = \\langle A^n v, w \\rangle")]]

#text("where A is an invertible ")#mi("d \\times d")#text(" matrix with integer coefficients, and v, w are d-dimensional vectors with integer coefficients (one can write A, v, w explicitly in terms of ")#mi("a_1,\\ldots,a_d")#text(" and ")#mi("x_0,\\ldots,x_{d-1}")#text(", but it is not necessary to do so for this argument). Since A is invertible, we can find a large prime p such that A is also invertible modulo p; for technical reasons we also need p to be larger than 2 so (any prime not dividing 2 det(A) will do). Let us now fix this p. The invertible matrices ")#mi("A^n \\mod p")#text(" over the finite field ")#mi("{\\Bbb F}_p")#text(" take on only finitely many values, thus by the pigeonhole principle there must exist a finite ")#mi("m \\geq 1")#text(" such that ")#mi("A^m = I \\mod p")#text(", where I is the identity matrix.")

#text("This m is going to be the eventual period of the zero set; more precisely, for every ")#mi("r = 0,\\ldots,m-1")#text(", I claim that the modified zero set ")#mi("\\{ n \\in {\\Bbb N}: x_{mn+r} = 0 \\}")#text(" is either finite, or equal to all of ")#mi("{\\Bbb N}")#text(" (this will clearly imply the Skolem-Mahler-Lech theorem). To see this claim, suppose that this modified zero set is infinite for some r, thus")

#align(center)[#tao-fit-display[#mitex("\\langle A^{mn} A^r v, w \\rangle = 0")]]

#text("for infinitely any n. By construction of m, we can write ")#mi("A^m = I + p B")#text(" for some integer-valued matrix B, thus")

#align(center)[#mi("P(n) = 0")#text(" for infinitely many integers n, where")]

#align(center)[#mi("P(n) := \\langle (1+pB)^{n} A^r v, w \\rangle")#text(".")]

#text("This identity makes sense in the (rational) integers ")#mi("{\\Bbb Z}")#text(", and hence also in the larger ring of p-adic integers ")#mi("{\\Bbb Z}_p")#text(". On the other hand, observe from binomial expansion that P(n) can be expressed as a formal power series in p with coefficients polynomial in n:")

#align(center)[#mi("P(n) = \\sum_{j=0}^\\infty p^j P_j(n)")#text(".")]

#text("Here the ")#mi("P_j")#text(" are polynomials with coefficients in the p-adic integers. Indeed, the binomial expansion of ")#mi("(I+pB)^n")#text(" contains terms involving a polynomial in ")#mi("n")#text(" times ")#mi("\\frac{p^k}{k!}")#text(" for natural number ")#mi("k")#text(". The number of times ")#mi("p")#text(" divides ")#mi("k")#text(" is ")#mi("\\lfloor k/p \\rfloor + \\lfloor k/p^2 \\rfloor + \\dots \\leq k/p + k/p^2 + \\dots = k/(p-1)")#text(" which grows slower than ")#mi("k")#text(" since ")#mi("p")#text(" was assumed to be larger than 2; hence each of the ")#mi("P_j")#text(" can be built using only finitely many of the terms in the binomial expansion.")

#text("Because of this, the function ")#mi("P: {\\Bbb Z} \\to {\\Bbb Z}")#text(" extends continuously to a function ")#mi("P: {\\Bbb Z}_p \\to {\\Bbb Z}_p")#text(", such that ")#mi("n \\mapsto P(n) \\mod p^j")#text(" is a polynomial in n for each j. In other words, P is a uniform limit of polynomials in the p-adic topology. [Note that the ")#link("http://en.wikipedia.org/wiki/Stone-Weierstrass_theorem")[#text("Stone-Weierstrass theorem")]#text(" is not applicable here, because we are using p-adic valued functions rather than real or complex-valued ones.] What we need to show is that if P has infinitely many zeroes, then it vanishes everywhere (which is of course what we expect polynomial-like objects to do).")

#text("Now if ")#mi("P(n_0) = 0")#text(" for some ")#mi("n_0")#text(" (either an integer or a p-adic integer, it doesn’t matter), one can then formally divide ")#mi("P(n) = P(n)-P(n_0)")#text(" by ")#mi("n-n_0")#text(" (as in the ")#link("http://en.wikipedia.org/wiki/Factor_theorem")[#text("factor theorem")]#text(" from high school algebra) to conclude that ")#mi("P(n) = (n-n_0) Q(n)")#text(" for some continuous function Q which, like P, is a polynomial modulo ")#mi("p^j")#text(" for each j, and whose “constant coefficient” ")#mi("Q_0(n)")#text(" either vanishes, or has degree strictly less than the corresponding coefficient ")#mi("P_0(n)")#text(" of P. Iterating this fact, we eventually see that if P has infinitely many zeroes, then it contains a factor with vanishing constant coefficient, or in other words it is divisible by p. We iterate this fact again and conclude that if P has infinitely many zeroes then it must be divisible by arbitrarily many powers of p, and thus must vanish everywhere. This concludes the proof.")

#text("Now, the above proof clearly gives a quite effective and computable bound on the eventual period m of the zero set. By ")#link("http://www.ams.org/mathscinet-getitem?mr=1923966")[#text("working somewhat harder")]#text(", Evertse, Schlickewei, and Schmidt obtained an effective bound on how many exceptional zeroes there are – zeroes of one of these almost polynomials P which do not cause P to vanish entirely. But there appears to be no effective bound known as to how ")#emph[#text("large")]#text(" these zeroes are! In particular, one does not even know how to decide whether this set is non-empty, thus we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Open problem")]#text(". Given an integer linear recurrence sequence (i.e. given the data ")#mi("d, a_1,\\ldots,a_d, x_0,\\ldots,x_{d-1}")#text(" as integers), is the truth of the statement “")#mi("x_n \\neq 0")#text(" for all n” decidable in finite time?")
]

#text("(Note that I am only asking here for decidability, and not even asking for effective bounds.) It is faintly outrageous that this problem is still open; it is saying that we do not know how to decide the halting problem even for “linear” automata!")

#text("The basic problem seems to boil down to one of determining whether an “almost polynomial” ")#mi("P: {\\Bbb Z}_p \\to {\\Bbb Z}_p")#text(" (i.e. a uniform limit of polynomials) has an ")#emph[#text("integer")]#text(" zero or not. It is not too hard to find the ")#emph[#text("p-adic")]#text(" zeroes of P to any specified accuracy (by using the p-adic version of ")#link("http://en.wikipedia.org/wiki/Newton%27s_method")[#text("Newton’s method")]#text(", i.e. ")#link("http://en.wikipedia.org/wiki/Hensel%27s_lemma")[#text("Hensel’s lemma")]#text("), but it seems that one needs to know the zeroes to ")#emph[#text("infinite")]#text(" accuracy in order to decide whether they are integers or not. It may be that some techniques from Diophantine approximation (e.g. some sort of p-adic analogue of the ")#link("http://en.wikipedia.org/wiki/Thue-Siegel-Roth_theorem")[#text("Thue-Siegel-Roth theorem")]#text(") are relevant. Alternatively, one might want to find a completely different proof of the Skolem-Mahler-Lech theorem, which does not use p-adics at all.")

#text("[Update, May 26: Typos, example, and full statement of SML theorem corrected.]")

#text("[Update, Sep 26, 2016: it was pointed out by Kamil Rychlewicz that the argument requires the prime p to be larger than 2.]")

#heading(level: 1)[#text("Comments (40)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/faaea4b7c5b04ead9c268663613ffcafa523cef7b85d370aaa07e69b3b4f55a2-b45439409ba81279ca30a7ebe5943c45a989379226691336f70e59356093ae5a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Richter")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1215")[#strong[#text("Johan Richter")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2007")])]

#text("There is a typo in your statement of the theorem, the “if” shoudl be “of”. (At least, the statement would make better sense than.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f2060c6149bd657144d550418b609703e03ef9d9f396fd49a96b4517ae9f8c4-51b3b67b52eff2358f9ae9503a8aa4d9ee5875ccde9abee20b7ee2d9742c8d0e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maurizio")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1218")[#strong[#text("Maurizio")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2007")])]

#text("There is also a typo about the recurrence with ")#mi("x_n = x_{n-4}")#text(": the zeros are {2,6,10,…}, ie the numbers in the remainder class of 2 mod 4.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1224")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2007")])]

#text("Thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1226")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2007")])]

#text("I’ve been very partial myself to the following “trivial” way of proving that a set is finite")#linebreak()#text(" without getting any more information at all: “A compact and discrete topological space")#linebreak()#text(" is finite”. This is clearly related to #2 and #3 above, and I find this to be often efficient")#linebreak()#text(" in (at least) understanding sophisticated finiteness theorems in number theory: they")#linebreak()#text(" are often obtained by combining two conditions, one of which looks like discreteness")#linebreak()#text(" and the other like compactness (but this is not always transferrable to a proof,")#linebreak()#text(" as far as I can see).")#linebreak()#text(" For instance the finiteness of ideal class group of number fields can be proved in this manner (using the adele/idele framework; the ideal class group being represented as a quotient of a compact group in such a way that the quotient topology is discrete). This is an interesting example also because in this case the proof can be made (and indeed, it was from the beginning) effective — the Minkowski bound from geometry of numbers gives an effective upper bound on the norm of ideals generating the ideal class group –, but it is effective in a non-practical way (it gives an exponential-time algorithm).")

#text("Incidentally, I’ve been wondering at some point what the analogue in “noncommutative geometry” of this simple statement could be. The best candidate I had what something")#linebreak()#text(" like : “any C^* algebra with unit which is equal to its enveloping von Neumann")#linebreak()#text(" algebra is finite dimensional”, but I don’t know it this is true (or if it makes sense!), the idea being that this means that any the first condition is analogue of compactness, and the second means “every measurable function is continuous”, so should be analogue")#linebreak()#text(" of discreteness.")

#text("In the paper of Evertse, Schlickewei and Schmidt, the main tool (if I remember right) is")#linebreak()#text(" Schmidt’s subspace theorem (or its generalizations), hence indeed clearly related to the Thue-Siegel-Roth theorem. Finding an effective version of this would thus solve")#linebreak()#text(" the problem — and many more besides…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1228")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2007")])]

#text("P.S. Some typos in the previous comment:")

#text("(1) the second-to-last paragraph should read")

#text("Incidentally, I’ve been wondering at some point what the analogue in “noncommutative geometry” of this simple statement could be. The best candidate I had what something")#linebreak()#text(" like : “any C^* algebra with unit which is equal to its enveloping von Neumann")#linebreak()#text(" algebra is finite dimensional”, but I don’t know it this is true (or if it makes sense!). The idea is that the first condition is an analogue of compactness, and the second means “every measurable function is continuous”, so should be analogue of discreteness.")

#text("(2) I don’t know who first gave the proof of the finiteness of the ideal class group in the")#linebreak()#text(" manner which I mentioned; maybe Chevalley when introducing ideles? It is")#linebreak()#text(" explained at least in the chapter on global fields in the proceedings of the Brighton")#linebreak()#text(" conference on Algebraic Number Theory (edited by Cassels and Fr\\”olich).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1243")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2007")]

#text("[…] Open question: effective Skolem-Mahler-Lech theorem The Skolem-Mahler-Lech theorem in algebraic number theory is a significant generalisation of the obvious statement that […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1276")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2007")])]

#text("Dear Emmanuel,")

#text("Very interesting remarks! I might classify the “compact + discrete -> finite” method as being more in the spirit of #1, though. If one had a sufficiently quantitative measure of both compactness and discreteness, one could hope to obtain a quantitative measure of finiteness; for instance, if one is in a metric space, and one has a bound for metric entropy numbers (how many balls of radius ")#mi("\\epsilon")#text(" are needed to cover the space) and minimal separation between elements (i.e. uniform discreteness), then one easily gets a bound on the cardinality. Things get harder when the topology is not metrisable or the discreteness is not uniform, though; even for closed subsets of [0,1] one already sees the ")#link("http://en.wikipedia.org/wiki/Konig_lemma")[#text("weak Konig lemma")]#text(" come up in the compactness theory (i.e. Bolzano-Weierstrass) which suggests, at minimum, that the quantitative bounds extractable from this method are likely to be terrible.")

#text("I don’t have anything intelligent to say about the noncommutative version, but perhaps others will…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9d00e86ca8cffb6563fa6d82adfdceb9240d70813780bf0099170bd53cbe49f-d1146be2136fe601e3437e4ef8dc7a871b4c56e029cfda7fd997b69781efe2ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jordan Ellenberg")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1295")[#strong[#text("Jordan Ellenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2007")])]

#text("Akshay pointed this post out to me with the comment that it is reminiscent of Chabauty. That seems right. Chabauty’s theorem applies to curves X over Q with the property that genus(X) not give any bound on the ")#emph[#text("height")]#text(" of a point on your curve. So again, one has a bound on the number of “exceptional” (which in this case means “rational”) points, but not a bound on their size.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9d00e86ca8cffb6563fa6d82adfdceb9240d70813780bf0099170bd53cbe49f-d1146be2136fe601e3437e4ef8dc7a871b4c56e029cfda7fd997b69781efe2ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jordan Ellenberg")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1296")[#strong[#text("Jordan Ellenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2007")])]

#text("Um, most of that comment was eaten for reasons not transparent to me. Briefly: Chabauty’s theorem, under some hypotheses, tells you that the rational points on a curve X are supported on the zeroes of some p-adic analytic functions. As in your post, with some work you can get a bound on the number of such zeroes (see e.g. Coleman, “Effective Chabauty”, and later work of Lorenzini-Tucker) but, again as above, there seems no way to leverage this into a bound on the height of a rational point.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e3ea0e461d1d736c668411472d5f628588e8adf015c16fbbe10de0d15fd1eca-70ff2301f8f81ca485a632489f67c0312ea697218a8a0e60e2a3013f321cf13e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felipe Voloch")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1320")[#strong[#text("Felipe Voloch")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2007")])]

#text("Skolem-Mahler-Lech and Chabauty are the same thing, actually. Chabauty extended ideas of Skolem from linear tori to abelian varieties. This is explained in e.g. Borevich-Shafarevich or Cassels book on local fields.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1321")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2007")])]

#text("Dear Jordan and Felipe, thank you for your comments! (Jordan: wordpress tends to eat anything which looks like html, in particular anything involving < and > can get mangled.)")

#text("I am very happy to hear about the connection between Skolem-Mahler-Lech and Chabauty. A really nice prize in this area would be an effective version of Faltings’ theorem (i.e. effective bounds on the heights of the rational points; I believe one already has effective bounds on the cardinality, and the problem is related to either #2 or #3 above). I understand that Chabauty’s theorem is like a baby version of Faltings’ theorem, so there is now a natural progression of difficulty from effective SML to effective Chabauty to effective Faltings, though it seems that even the first step looks quite hard.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea086d595857c6e6cc3d79fe43f949e5f69db162916b3327b3027d7f0c42be6d-f0d869df2ff85b2432b2526b509cc785de7a31ddf4185d7e912c3b8e84798649.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1356")[#strong[#text("A")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2007")])]

#text("“ineffective bound – a bound which is provably finite, but which cannot be computed!”")

#text("Are ineffective bounds uncomputable, in the sense that Turing might have intended, or have they simply not been computed in the proof?")

#text("Thanks,")#linebreak()#text(" A")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1359")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2007")])]

#text("Dear A,")

#text("That is essentially correct, or more precisely an ineffective bound is one for which we do not know how to compute in the sense of Turing, even after close inspection of the proof. It may be, however, that new proofs may provide an effective bound on the same quantity.")

#text("To give a somewhat artificial example of an ineffective bound, let n be the first even number larger than 2 that cannot be expressed as the sum of two primes, or 0 if no such N exists (i.e. if the even Goldbach conjecture is true). Regardless of whether the Goldbach conjecture is true or false, this number n is clearly finite. However, the argument provides no effective bound n < N on the size of n. If it did, then the Goldbach conjecture would be decidable in finite time (we would simply verify whether all even numbers between 4 and N are the sum of two primes; if they are, and n < N, then the Goldbach conjecture must be true.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd8e905c50da784fe206f24e84bbadf70fbbfe973c30f6547a054d8c498190c4-b7d585e30add71f93e6ece7c10be9601dccb24f453b04ad0cd603e1ed9b81258.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of martin hofmann")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1488")[#strong[#text("martin hofmann")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2007")])]

#text("Re halting problem for “linear automata”: couldn’t one compute the eigenvalues of the matrix A first;")#linebreak()#text(" if they all have absolute value below 1 then we will get 0 eventually.")#linebreak()#text(" if the largest and the second largest eigenvalue (by absolute value) have different absolute value then the largest eigenvalue will dominate the behaviour and it should be possible to compute effectively when this happens. (zeroes could only occur prior to that point)")#linebreak()#text(" if the k largest eigenvalues (by absolute value) have equal absolute value then we could look at their arguments. I believe (this may well be wrong) that the argument of a complex solution of a real polynomial must be a rational fraction of 2*pi (because of the sum of angles in a polylateral).")#linebreak()#text(" By looking at the least common denominator of those fractions one could find out how close to each other their respective")#linebreak()#text(" powers could possibly get and once the contributions of smaller eigenvalues peter out one can again exclude the possibility of a zero.")#linebreak()#text(" Does that make some sense?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kousha Etessami")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1499")[#strong[#text("Kousha Etessami")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2007")])]

#text("It is worth pointing out that,")#linebreak()#text(" if one adopts a very rigid notion of “effectiveness”,")#linebreak()#text(" then Blondel and Portier (2002)")#linebreak()#text(" give a simple proof that:")#linebreak()#text(" “The presence of a zero in an integer linear recurrent sequence is NP-hard to decide”,")#linebreak()#text(" (Lin. Algebra and Its Applications, 351-352, pp. 91-98, 2002.). The proof is based on an old")#linebreak()#text(" automata-theoretic argument by Stockmeyer and Meyer.")#linebreak()#text(" The result applies already to non-negative")#linebreak()#text(" linear recurrence sequences (LRSs), where")#linebreak()#text(" the sequence is")#linebreak()#text(" x_i = u^T A^i v , i = 0,1,2,….")#linebreak()#text(" for a given non-negative dxd matrix A, and")#linebreak()#text(" given non-negative vectors u and v.")#linebreak()#text(" (In fact, if suffices to let u, A, and v, all have")#linebreak()#text(" entries in {0,1}.)")#linebreak()#text(" It is easy to see that for such non-negative")#linebreak()#text(" LRSs there is also an NP upper bound,")#linebreak()#text(" so this very restricted problem is NP-complete.")#linebreak()#text(" A simple corollary of the")#linebreak()#text(" NP-hardness proof is")#linebreak()#text(" the following lower bound: there is a family")#linebreak()#text(" of (non-negative) LRSs, L_n,")#linebreak()#text(" n=1,2, …, of")#linebreak()#text(" “encoding size” O(n)")#linebreak()#text(" (the coefficients are given in binary, etc.)")#linebreak()#text(" such that, for every n,")#linebreak()#text(" the sequence L_n does contain a zero,")#linebreak()#text(" but the smallest index for a zero is")#linebreak()#text(" 2^{Omega(n)}.")#linebreak()#text(" (In other words, there is an “exponential”")#linebreak()#text(" lower bound on the location of the first zero")#linebreak()#text(" in the non-negative case.)")#linebreak()#text(" So, … perhaps a way to")#linebreak()#text(" gradually gain a better understanding")#linebreak()#text(" for the general LRS case (where the matrix")#linebreak()#text(" A can have both positive and negative entries)")#linebreak()#text(" would be to answer the following")#linebreak()#text(" Question: Is there a family of LRSs, L’_n,")#linebreak()#text(" n=1,2,…, of size O(n), such that")#linebreak()#text(" for every n, the sequence L’_n contains a zero,")#linebreak()#text(" but the smallest index for a zero is")#linebreak()#text(" 2^{2^{Omega(n)}} ?")#linebreak()#text(" (Perhaps it is not hard to answer this affirmatively.")#linebreak()#text(" If so, then replace double-exponential by")#linebreak()#text(" triple-exponential, …. non-elementary,…")#linebreak()#text(" non-primitive-recursive,… etc.)")#linebreak()#text(" Even if one believes that an effective")#linebreak()#text(" Skolem-Mahler-Lech theorem should exist,")#linebreak()#text(" it is not at all clear (at least not to me)")#linebreak()#text(" what the right conjecture for the bound should be.")#linebreak()#text(" There is a lot of motivation,")#linebreak()#text(" in particular for applications in computer science,")#linebreak()#text(" for finding a small upper bound if one exists.")#linebreak()#text(" On the other hand, if one can show an")#linebreak()#text(" astronomical (e.g., non-elementary) lower bound,")#linebreak()#text(" then, at least from an applied perspective,")#linebreak()#text(" the decidability question becomes a lot less relevant.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd8e905c50da784fe206f24e84bbadf70fbbfe973c30f6547a054d8c498190c4-b7d585e30add71f93e6ece7c10be9601dccb24f453b04ad0cd603e1ed9b81258.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of martin hofmann")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1534")[#strong[#text("martin hofmann")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2007")])]

#text("I try to make my suggestion a bit more precise.")#linebreak()#text(" If ")#mi("\\lambda_1,\\ldots,\\lambda_k")#text(" are the eigenvalues of A ordered by decreasing absolute value, so ")#tao-math("\\left|\\lambda_1\\right|", block: false)#text(" is largest then")

#mi("x_n = \\sum_i=1..k p_i(n) \\lambda_i^n")

#text("where the ")#mi("p_i(n)")#text(" are polynomials in n of degree less than the (algebraic) multiplicity of ")#mi("\\lambda_i")#text(".")#linebreak()#text(" Each ")#mi("\\lambda_i")#text(" is a root of the real characteristic polynomial of A. I claim that therefore ")#tao-math("\\epsilon_i :=  \\lambda_i / \\left|\\lambda_i\\right|", block: false)#text(" is a d-th root of unity.")#linebreak()#text(" Thus, we have")

#tao-math("x_n = \\sum_i=1..k p_i(n) \\epsilon_i^n \\left|\\lambda_i\\right|^n", block: false)

#text("So, by distinguishing cases modulo n we are lead to deciding whether or not an expression of the form")

#mi("\\sum_i=1..k q_i(n) \\alpha_i^n")

#text("where the ")#mi("\\alpha_i")#text(" are positive real numbers and the ")#mi("q_i")#text(" are complex polynomials in n, has a zero.")#linebreak()#text(" Assuming that ")#mi("\\alpha_1")#text(" is the largest we can effectively compute ")#mi("n_0")#text(" after which no more zeros can occur. Such ")#mi("n_0")#text(" must be beyond the zeros of the ")#mi("q_i")#text(" and be such that the contribution of the summands with ")#mi("i>1")#text(" becomes negligible in view of the exponential gap between the summand i=1 and the later ones.")#linebreak()#text(" This does not contradict Kousha’s comments: It may well be that the bounds so obtainable are quite large and therefore the procedure becomes inefficient in practice.")#linebreak()#text(" PS:")#linebreak()#text(" Now, if ")#tao-math("\\left|\\lambda_1\\right| = 0", block: false)#text(" so ")#mi("x_n = 0")#text(" for large n because ")#mi("x_n")#text(" is an integer.")#linebreak()#text(" If ")#tao-math("\\left|\\lambda_1\\right| > 1", block: false)#text(" and ")#tao-math("\\left|\\lambda_1\\right| > \\left|\\lambda_2\\right|", block: false)#text(" then ")#tao-math("\\left|x_n\\right| \\to \\infty", block: false)#text(" and we can compute a bound after which no more zeros can be expected from the polynomials ")#mi("p_i")#text(" and the ")#mi("\\lambda_i")#text(".")#linebreak()#text(" If ")#tao-math("\\left|\\lambda_1\\right| = \\left|\\lambda_2\\right| > 1", block: false)#text(" and (for simplicity) ")#tao-math("\\left|\\lambda_2\\right| > \\left|\\lambda_3\\right|", block: false)#linebreak()#text(" then since both ")#mi("\\lambda_1")#text(" and ")#mi("\\lambda_2")#text(" are roots of the characteristic polynomial of A their complex argument must be an integer multiple of ")#mi("2*\\pi/d")#text(". This means that ")#tao-math("\\left|p_1*\\lambda_1^n + p_2*\\lambda_2^n\\right|", block: false)#text(" is either ")#tao-math("\\Omega(\\left|\\lambda_1\\right|^n)", block: false)#text(" and therefore eventually dominates the contribution of the smaller eigenvalues or 0 which would occur periodically and once could then look recursively at the situation at smaller eigenvalues. I have here assumed that the coefficients ")#mi("p_1")#text(" and ")#mi("p_2")#text(" are constants rather than polynomials in n. The hope would be that a similar argument could be carried out in that more general case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1558")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2007")])]

#text("Dear Martin,")

#text("Thanks for your suggestions. Unfortunately, it is not the case that the argument of an algebraic integer is always a d^th root of unity. Consider for instance the number ")#mi("\\lambda = 3+4i")#text(", which solves the equation ")#mi("\\lambda^2 - 6 \\lambda + 25 = 0")#text(" but whose argument has phase ")#mi("\\tan^{-1} \\frac{4}{3}")#text(", which is a transcendental multiple of ")#mi("2\\pi")#text(". Once there are multiple transcendental phases at the eigenvalues of the maximum magnitude, it is not clear how to proceed (though, as I said in my post, it may be that some tools from Diophantine approximation become relevant).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kousha Etessami")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1609")[#strong[#text("Kousha Etessami")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2007")])]

#text("Regarding the latest comments, another reference worth mentioning")#linebreak()#text(" is the following fairly recent survey:")

#text("“Skolem’s problem: on the border between decidability and undecidability”,")#linebreak()#text(" authors: V. Halava, T. Harju, M. Hirvensalo, J. Karhumaki,")#linebreak()#text(" Tech report 683, Turku Unviersity Computer Science, 2005.")#linebreak()#text(" (Link:")#linebreak()#text(" ")#link("http://www.tucs.fi/publications/insight.php?id=tHaHaHiKa05a")[#text("http://www.tucs.fi/publications/insight.php?id=tHaHaHiKa05a")]#text(" )")

#text("They survey the known decidable cases, and in particular they use")#linebreak()#text(" spectral techniques (roughly related to Martin’s suggestions) combined")#linebreak()#text(" with Baker’s powerful theorem from")#linebreak()#text(" transcendental number theory on linear independence of logarithms")#linebreak()#text(" of algebraic numbers;")#linebreak()#text(" but all this only allows them to solve some special cases,")#linebreak()#text(" such as the case where the linear recurrence has length at most 5")#linebreak()#text(" (plus some cases where the eigenvalues of the correlated matrix")#linebreak()#text(" have restricted structure).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1665")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2007")])]

#text("Dear Kousha,")

#text("Thanks for the link to the interesting survey! It is remarkable how even Baker’s theorem only gets as far as length 5 recurrences. Perhaps this indicates that transcendence theory is in fact not quite the right tool for the task, and one needs to exploit the algebraic structure more…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ec8ea5901a25f2a0002a471116ac4f55f2d90936362cd21cbdabbbab84ba8f7-5ec12642268b149a531451f2c5b8258d1d9ef78977f835b1a4b8241fd1f8403e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joel Ouaknine")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1762")[#strong[#text("Joel Ouaknine")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2007")])]

#text("As an aside, another interesting source of “ineffective bounds” arises from the theory of well-quasi orders, such as Higman’s Lemma or the Robertson-Seymour theorem. For example, Robertson-Seymour easily implies that there is a finite set S of graphs such that a given graph G is planar iff it does not have any graph in S as a minor. Now, of course, in this instance Kuratowski’s theorem tells us in fact that S precisely consists of K_{3,3} and K_5, but Robertson-Seymour could not even give us a bound on the cardinality of S, other than to say it was finite.")

#text("In general, there are many other such examples from the theory of algorithms in which no equivalent “Kuratwoski’s theorem” is known to exist. There are even cases in which no effective bounds can be given at all. For example, the set of reachable configurations of a “lossy counter machine” (a certain kind of faulty Turing machine) can always be represented by a finite automaton, however it is known that that automaton cannot in general be computed from the lossy counter machine, and in fact the minimum number of states of the representing automaton, while finite, cannot be computed either.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd8e905c50da784fe206f24e84bbadf70fbbfe973c30f6547a054d8c498190c4-b7d585e30add71f93e6ece7c10be9601dccb24f453b04ad0cd603e1ed9b81258.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of martin hofmann")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1882")[#strong[#text("martin hofmann")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2007")])]

#text("Dear Terence,")

#text("thank you for taking the time to dispel my somewhat naive attempts at")#linebreak()#text(" using eigenvalues. A triangle with 2 angles equal to each other is")#linebreak()#text(" unfortunately not in general equilateral…")

#text("Now I was trying to understand your p-adic proof to see what exactly")#linebreak()#text(" is the measure going down in this hypothetical infinite regress. In")#linebreak()#text(" the techreport that Kousha pointed out they make a big deal of these")#linebreak()#text(" binomial coefficients and their respective v_p-values. In view of your")#linebreak()#text(" proof this looks like unnecessary hocus pocus. On the other hand, while")#linebreak()#text(" your argument is completely transparent to me when")#linebreak()#text(" P(n) mod p^j is a polynomial with integer")#linebreak()#text(" coefficients, I cannot yet see how it works when P(n) mod p^j")#linebreak()#text(" has fractional coefficients (perhaps with denominators = 0 mod p) like in")#linebreak()#text(" P(x) = choose(x,3) and p=3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e3ea0e461d1d736c668411472d5f628588e8adf015c16fbbe10de0d15fd1eca-70ff2301f8f81ca485a632489f67c0312ea697218a8a0e60e2a3013f321cf13e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felipe Voloch")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1883")[#strong[#text("Felipe Voloch")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2007")])]

#text("Martin,")

#text("You are free to choose p, given the recurrence, and avoid its presence in denominators. On the other hand, the p-adic proof gives a bound on the number of solutions, when finite and it depends on p. To get the best bound sometimes requires some careful estimates or “hocus pocus”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1886")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2007")])]

#text("Dear Emmanuel,")

#text("I asked my operator algebra colleagues here at UCLA about your question, and am enclosing a response from Sorin Popa and Narutaka Ozawa. Tim Austin also commented that the original formulation of the question can be answered in the negative: the ring of continuous")#linebreak()#text(" functions on the Cech-Stone compactification of ")#mi("{\\Bbb N}")#text(" is itself a von Neumann algebra, for example, being just ")#mi("l^\\infty")#text(".")

#text("—")

#text("Kowalski’s question can in fact be posed")#linebreak()#text(" in two ways, on which I comment below.")#linebreak()#text(" Note first of all that requiring A to be")#linebreak()#text(" “equal” or merely isomorphic to its enveloping vN algebra")#linebreak()#text(" means already that the C* algebra A")#linebreak()#text(" is a W* algebra, i.e. an algebra that")#linebreak()#text(" can be represented faithfully on a Hilbert space as a vN algebra")#linebreak()#text(" and that by Sakai’s theorem this is equivalent to the fact that")#linebreak()#text(" it has predual as a Banach space. Also, Sakai’s theorem")#linebreak()#text(" identifies the enveloping vN algebra with the (Banach) bidual")#linebreak()#text(" ")#mi("A^{**}")#text(" of A.")

#text("1 Asking that the C*-algebra A be “equal” to")#linebreak()#text(" its bidual ")#mi("A^{**}")#text(" (which is equal to the enveloping vN algebra),")#linebreak()#text(" in the sense that the canonical embedding of A into the bidual")#linebreak()#text(" is an equality. This trivially implies the algebra is finite")#linebreak()#text(" dimensional, since it is very easy to see that if it is")#linebreak()#text(" infinite dimensional then A contains a")#linebreak()#text(" non-normal state (i.e. a state which fails to be")#linebreak()#text(" completely additive on mutually orthogonal")#linebreak()#text(" projections), in fact even a “singular” state ")#mi("\\varphi")#text(",")#linebreak()#text(" i.e. a state with the property that it is identically 0")#linebreak()#text(" under projections p with ")#mi("\\varphi(p)")#text(" as close to 0")#linebreak()#text(" as you want. Or ")#mi("A=A^{**}")#text(" prevents that from happening.")

#text("2 Asking that the C* algebra A be isomorphic to its bidual ")#mi("A^{**}")#text(".")#linebreak()#text(" This also implies that A is finite dimensional, but")#linebreak()#text(" the proof is a bit more difficult: one can show that")#linebreak()#text(" if ")#mi("I=I_A")#text(" denotes a set of largest cardinality")#linebreak()#text(" such that there exist mutually orthogonal non-zero")#linebreak()#text(" projections ")#mi("\\pi_i, i \\in I")#text(", in the vN algebra A, then")#linebreak()#text(" ")#mi("I_{A^{**}}")#text(" has strictly larger cardinality than ")#mi("I_A")#linebreak()#text(" (unless of course A is fin dim).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1888")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2007")])]

#text("Thanks for getting this information! Now I’ll try to understand the details.")

#text("I also wish I could get some interesting application… (At the time I was thinking vaguely about such questions, I was optimistically hoping there might be some tough finiteness questions in number theory, such as that of Tate-Shafarevich groups, which would be approachable by noncommutative geometry).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59e7cc015abe36655329b57fc473d54b0124e40428d9299fab3212350430dace-d68dc7a9cd8bb487b1e36264fcdb4a497a80be48ec13c7aec300b89cdfa2d222.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1891")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2007")])]

#text("Here is a basic question, continuing the naive eigenvalue approach. Suppose that a_1, …, a_n are a collection of algebraic integers closed under the action of Gal(Q^{alg}/Q). Suppose that a_i/a_j is never a root of unity for i not equal to j. Does there always exist a norm ||, either archimedean or non-archimedean, such that the maximum of |a_1|, …, |a_n| is unique?")

#text("I find it completely implausible that such a thing should be true, but I don’t have a counter-example and it is true for n=2. (Kronecker’s Lemma applied to a_1/a_2, see for example Borevich and Shafarevich, “Number Theory”, Section 2.3 Thrm 2.) So I am curious whether anyone here has a counter-example.")

#text("The point is that, if the a_i are the eigenvalues of A, then whenever such a norm exists, we can give explicit bounds past which can’t be zero. For example, it is hard to bound (3+4i)^n-(3-4i)^n away from zero in the archimedean norm, but quite simple in the (1+2i)-adic norm.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59e7cc015abe36655329b57fc473d54b0124e40428d9299fab3212350430dace-d68dc7a9cd8bb487b1e36264fcdb4a497a80be48ec13c7aec300b89cdfa2d222.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-1892")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2007")])]

#text("Grrr, why do I always think of the good counterexamples after asking the questions?")

#text("(1+2i)*(2+3i), (1+2i)*(2-3i), (1-2i)(2+3i), (1-2i)(2-3i)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd8e905c50da784fe206f24e84bbadf70fbbfe973c30f6547a054d8c498190c4-b7d585e30add71f93e6ece7c10be9601dccb24f453b04ad0cd603e1ed9b81258.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of martin hofmann")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-2197")[#strong[#text("martin hofmann")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2007")])]

#text("Apparently one can use the Baker’s theorem to determine a bound on n")#linebreak()#text(" beyond which it can no longer happen that a nonzero but small contribution of the dominant eigenvalues cancels against the contribution of the smaller eigenvalues.")

#text("What seems difficult is when the contribution of the dominant eigenvalues is zero itself.")

#text("So, one is essentially lead to the following question: let exp(i phi_j) and exp(i theta_j) be algebraic numbers for j=1..ell. Let")

#text("Z = {n | exp(i (phi_1 + n theta_1)) + … + exp(i (phi_ell + n theta_ell)) = 0}")

#text("Can we effectively compute a number N so that Z is either infinite or contained in {0..N} ?")

#text("It would be enough to answer the question for exp(i (phi_j + n theta_j)) replaced by cos(phi_j + n theta_j) because eigenvalues come in conjugate pairs.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cef48b06a0a62b2e2f7de82fceedd7f3726373a5958101e7ceb07bba02fc53a-3007dee16f9db997bede2259916ead4f939be2f61d42abf6a7baba5a030fa899.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Funny One")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-13131")[#strong[#text("The Funny One")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2007")])]

#text("Hey Kousha,")

#text("Thanks for providing the link to the amazing survey, i was really impressed by it and the things people think of these days, thought it was just me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/861a383e6da5a2b552fa5999d2f6be1daa9e218e27fe2eeadc26a623fabe33a6-9cf0c0d3d408c0ef04b54b748fd9abbdb06aa1259a0bb43ffd9159c2ee8fcd44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Navtej Kohli")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-24740")[#strong[#text("Navtej Kohli")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2008")])]

#text("Wish i had the talent to write such posts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/390517060033239b9bf4fdf38be68020e8c3713bc59523c096d8f998664e0bbe-8a87dc77dc8f1db8ed403dfd640cfca3565b7b89c4f53fa7c5cbd2c0bed27bd8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-36268")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2009")])]

#text("It occurred to me today that it’s possible to embed the Frobenius coin problem into this problem, as follows: the number of ways to represent a non-negative integer as a non-negative sum of a fixed set of non-negative integers has a rational generating function, equivalently, is a sequence that satisfies an integer linear recurrence. The coin problem asks for the largest number such that no such representations exist, i.e. the largest zero of such a sequence. And the coin problem is known to be NP-hard (in general) as well (although the existence of zeroes is trivial here). Perhaps this would be an instructive special case?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of davidspeyer")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-36270")[#strong[#text("davidspeyer")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2009")])]

#text("That’s interesting, but it isn’t hard to give a bound in the coin case — if I recall correctly, the product of the coin values works. The NP-hard problem is determining the actual position of that last zero. Whereas in Skolem-Mahler-Lech, we seem to actually have a computability issue — there is no known bound at all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-41284")[#strong[#text("The Orbit Problem « Gödel’s Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2009")]

#text("[…] this a theorem? Terry Tao raises a related question in his famous blog on recurrence sequences. He gives it as an example of a question that we should know the answer to, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-42913")[#strong[#text("Mathematical Embarrassments « Gödel’s Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2009")]

#text("[…] linear recursion zero problem. An ME due to Tao is a problem about linear recurrences. Given a linear recurrence over the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-43917")[#strong[#text("The Skolem-Mahler-Lech theorem « Cam's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2010")]

#text("[…] proof of the SML theorem that I’ll give was essentially lifted from Terrence Tao’s blog. He in turn essentially lifted it from this paper of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af541218a81b87d52fffdce2b5b80f346d0557197d5644a5eb0d7b6ff44db2d8-26087d8ecc59926cd237e5b0b7ea01f6744475ff928da51953c1ea1b4a561697.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vagabond")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-46954")[#strong[#text("Vagabond")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2010")])]

#text("Incidentally a lemma due to Turan comes very close to proving Skolem Mahler Lech theorem. Its says if one knows the values of an exponential polynomial along an n length AP then one can find an estimate of it at the n+1 th point. Applied to the the specific case under consideration ( i.e. an exponential polynomial of order n) it says if the exponential polynomial vanishes at an arithmetic progression of length n then it vanishes on the complete arithmetic progression. So Szemeredi’s theorem tells us that the structure of the zero set has to be union of complete AP plus a set of dnsity zero set ( having no AP of length n). Though it does not prove Skolem Mahler Lech theorem it’s tantalizingly close and provides the extra information about the geometry of the zero sets …. that the exceptional set do not have an n length AP and using estimates from Ramsey theory one can find a bound on how many zeros can be there in an interval ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/76accfe5628579d6d7b031a1601c5efcb8eab510e10c8bd8847b792f9312add3-cabe31d49f0a491a27c2a2c4043a07ffe49d2f1dbebf64cf7dd62d5f3a999b45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Stanley")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-46975")[#strong[#text("Richard Stanley")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2010")])]

#text("I am curious about generalizations of Mahler-Skolem-Lech. I believe it is still")#linebreak()#text(" open for algebraic power series or even D-finite power series. Is this correct?")#linebreak()#text(" In other words, if ")#mi("y=\\sum a_i x^i")#text(" is algebraic (satisfies a polynomial equation whose coefficients are polynomials in ")#mi("x")#text(") or more generally D-finite (satisfies a linear differential equation whose coefficients are polynomials in ")#mi("x")#text("), then is the set of ")#mi("i")#text("‘s for which ")#mi("a_i=0")#text(" eventually a union of arithmetic progressions? This is known to be false for algebraically differential series ")#mi("y")#text(", i.e., ")#mi("y")#text(" satisfies an equation that is a polynomial in ")#mi("x, y, y^{\\prime}, y^{\\prime\\prime}, \\dots")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f485e092feba54fdaa267e6d09e8803d6fd165f648841ad4887d7b7b67002019-aea4141198ffddc4a6c03c1bdf094392754309230b9db8c218177c5d3706a7eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Komjath")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-49337")[#strong[#text("Peter Komjath")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2011")])]

#text("This paper may be of interest (sorry if already mentioned):")#linebreak()#text(" Bruce E. Litow: A Decision Method for the Rational Sequence Problem Electronic Colloquium on Computational Complexity (ECCC) 4(55): (1997)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eab44e598de3a1c84cf877df3b0204850e721db299ec8096f9be24bc2798ac11-a51b23c95fc4308f79fbfc4128a6fd9b80704ea202e79e4984ed86a842a0f8be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of From letter exchange to blog exchange | To All You Zombies")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-223058")[#strong[#text("From letter exchange to blog exchange | To All You Zombies")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2013")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/")[#text("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/")]#text(", retrieved 7.4.2013 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The subspace theorem approach to Siegel’s theorem on integral points on curves via nonstandard analysis | What's new")]], [#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-388660")[#strong[#text("The subspace theorem approach to Siegel’s theorem on integral points on curves via nonstandard analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2014")])]

#text("[…] may be bounded effectively; cf. the situation with the Skolem-Mahler-Lech theorem, discussed in this previous blog post.) Once again, the lower bound here is basically sharp except for the factor and the implied […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/25/open-question-effective-skolem-mahler-lech-theorem/#comment-636818")[#strong[#text("Caleb Stanford (@calebstanford4)")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2021")]

#text("Minor correction: in your definition of LRS, you need to require that ")#mi("a_d \\ne 0")#text(". Otherwise, you allow eventually-periodic sequences like ")#mi("1, 0, 0, 0, \\ldots")#text(" for which the Skolem-Mahler-Lech theorem as stated does not hold (the zeros here are not a union of full residue classes).")

#emph[#text("[Corrected, thanks – T.]")]
]
