// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/12/06/additive-energy-of-regular-measures-in-one-and-higher-dimensions-and-the-fractional-uncertainty-principle/
// Converted to Typst by tao2typ: "2026-10-14T15:20:34.516575+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Additive energy of regular measures in one and higher dimensions, and the fractal uncertainty principle", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Additive energy of regular measures in one and higher dimensions, and the fractal uncertainty principle")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 December 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/12/06/additive-energy-of-regular-measures-in-one-and-higher-dimensions-and-the-fractional-uncertainty-principle/")[#text("https://terrytao.wordpress.com/2020/12/06/additive-energy-of-regular-measures-in-one-and-higher-dimensions-and-the-fractional-uncertainty-principle/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://www.math.ucla.edu/~cladekl/")[#text("Laura Cladek")]#text(" and I have just uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/2012.02747")[#text("Additive energy of regular measures in one and higher dimensions, and the fractal uncertainty principle")]#text("“. This paper concerns a continuous version of the notion of additive energy. Given a finite measure ")#mi("{\\mu}")#text(" on ")#mi("{{\\bf R}^d}")#text(" and a scale ")#mi("{r>0}")#text(", define the energy ")#mi("{\\mathrm{E}(\\mu,r)}")#text(" at scale ")#mi("{r}")#text(" to be the quantity ")#metadata(none) <tao-ff0ea194607d481a25de>#tao-math("\\displaystyle  \\mathrm{E}(\\mu,r) := \\mu^4\\left( \\{ (x_1,x_2,x_3,x_4) \\in ({\\bf R}^d)^4: \\left|x_1+x_2-x_3-x_4\\right| \\leq r \\}\\right) \\ \\ \\ \\ \\ (1)", block: false)#text(" ")#text(" where ")#mi("{\\mu^4}")#text(" is the product measure on ")#mi("{({\\bf R}^d)^4}")#text(" formed from four copies of the measure ")#mi("{\\mu}")#text(" on ")#mi("{{\\bf R}^d}")#text(". We will be interested in Cantor-type measures ")#mi("{\\mu}")#text(", supported on a compact set ")#mi("{X \\subset B(0,1)}")#text(" and obeying the Ahlfors-David regularity condition")

#align(center)[#tao-fit-display[#mitex("\\mu(B(x,r)) \\leq C r^\\delta")]]

#text("for all balls ")#mi("{B(x,r)}")#text(" and some constants ")#mi("{C, \\delta > 0}")#text(", as well as the matching lower bound")

#align(center)[#tao-fit-display[#mitex("\\mu(B(x,r)) \\geq C^{-1} r^\\delta")]]

#text("when ")#mi("{x \\in X}")#text(" whenever ")#mi("{0 < r < 1}")#text(". One should think of ")#mi("{X}")#text(" as a ")#mi("{\\delta}")#text("-dimensional fractal set, and ")#mi("{\\mu}")#text(" as some vaguely self-similar measure on this set.")

#text("Note that once one fixes ")#mi("{x_1,x_2,x_3}")#text(", the variable ")#mi("{x_4}")#text(" in ")#link(<tao-ff0ea194607d481a25de>)[#text("(1)")]#text(" is constrained to a ball of radius ")#mi("{r}")#text(", hence we obtain the trivial upper bound ")#metadata(none) <tao-5f2b1d6f5492140fa7b4>#mi("\\displaystyle  \\mathrm{E}(\\mu,r) \\leq C^4 r^\\delta. \\ \\ \\ \\ \\ (2)")#text(" ")#text(" If the set ")#mi("{X}")#text(" contains a lot of “additive structure”, one can expect this bound to be basically sharp; for instance, if ")#mi("{\\delta}")#text(" is an integer, ")#mi("{X}")#text(" is a ")#mi("{\\delta}")#text("-dimensional unit disk, and ")#mi("{\\mu}")#text(" is Lebesgue measure on this disk, one can verify that ")#mi("{\\mathrm{E}(\\mu,r) \\sim r^\\delta}")#text(" (where we allow implied constants to depend on ")#mi("{d,\\delta}")#text(". However we show that if the dimension is non-integer, then one obtains a gain:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" If ")#mi("{0 < \\delta < d}")#text(" is not an integer, and ")#mi("{X, \\mu}")#text(" are as above, then")

#align(center)[#tao-fit-display[#mitex("\\mathrm{E}(\\mu,r) \\lesssim_{C,\\delta,d} r^{\\delta+\\beta}")]]

#text("for some ")#mi("{\\beta>0}")#text(" depending only on ")#mi("{C,\\delta,d}")#text(".")
]

#text("Informally, this asserts that Ahlfors-David regular fractal sets of non-integer dimension cannot behave as if they are approximately closed under addition. In fact the gain ")#mi("{\\beta}")#text(" we obtain is quasipolynomial in the regularity constant ")#mi("{C}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\beta = \\exp\\left( - O_{\\delta,d}( 1 + \\log^{O_{\\delta,d}(1)}(C) ) \\right).")]]

#text("(We also obtain a localised version in which the regularity condition is only required to hold at scales between ")#mi("{r}")#text(" and ")#mi("{1}")#text(".) Such a result was previously obtained (with more explicit values of the ")#mi("{O_{\\delta,d}()}")#text(" implied constants) in the one-dimensional case ")#mi("{d=1}")#text(" ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3558305")[#text("by Dyatlov and Zahl")]#text("; but in higher dimensions there does not appear to have been any results for this general class of sets ")#mi("{X}")#text(" and measures ")#mi("{\\mu}")#text(". In the paper of Dyatlov and Zahl it is noted that some dependence on ")#mi("{C}")#text(" is necessary; in particular, ")#mi("{\\beta}")#text(" cannot be much better than ")#mi("{1/\\log C}")#text(". This reflects the fact that there ")#emph[#text("are")]#text(" fractal sets that do behave reasonably well with respect to addition (basically because they are built out of long arithmetic progressions at many scales); however, such sets are not very Ahlfors-David regular. Among other things, this result readily implies a dimension expansion result")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dim}( f( X, X) ) \\geq \\delta + \\beta")]]

#text("for any non-degenerate smooth map ")#mi("{f: {\\bf R}^d \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(", including the sum map ")#mi("{f(x,y) := x+y}")#text(" and (in one dimension) the product map ")#mi("{f(x,y) := x \\cdot y}")#text(", where the non-degeneracy condition required is that the gradients ")#mi("{D_x f(x,y), D_y f(x,y): {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" are invertible for every ")#mi("{x,y}")#text(". We refer to the paper for the formal statement.")

#text("Our higher-dimensional argument shares many features in common with that of Dyatlov and Zahl, notably a reliance on the modern tools of additive combinatorics (and specifically the Bogulybov-Ruzsa lemma ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2994996")[#text("of Sanders")]#text("). However, in one dimension we were also able to find a completely elementary argument, avoiding any particularly advanced additive combinatorics and instead primarily exploiting the order-theoretic properties of the real line, that gave a superior value of ")#mi("{\\beta}")#text(", namely")

#align(center)[#tao-fit-display[#mitex("\\beta := c \\min(\\delta,1-\\delta) C^{-25}.")]]

#text("One of the main reasons for obtaining such improved energy bounds is that they imply a ")#emph[#text("fractal uncertainty principle")]#text(" in some regimes. We focus attention on the model case of obtaining such an uncertainty principle for the semiclassical Fourier transform")

#align(center)[#tao-fit-display[#mitex("{\\mathcal F}_h f(\\xi) := (2\\pi h)^{-d/2} \\int_{{\\bf R}^d} e^{-i x \\cdot \\xi/h} f(x)\\ dx")]]

#text("where ")#mi("{h>0}")#text(" is a small parameter. If ")#mi("{X, \\mu, \\delta}")#text(" are as above, and ")#mi("{X_h}")#text(" denotes the ")#mi("{h}")#text("-neighbourhood of ")#mi("{X}")#text(", then from the Hausdorff-Young inequality one obtains the trivial bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| 1_{X_h} {\\mathcal F}_h 1_{X_h} \\right\\|_{L^2({\\bf R}^d) \\rightarrow L^2({\\bf R}^d)} \\lesssim_{C,d} h^{\\max\\left(\\frac{d}{2}-\\delta,0\\right)}.", block: true)]]

#text("(There are also variants involving pairs of sets ")#mi("{X_h, Y_h}")#text(", but for simplicity we focus on the uncertainty principle for a single set ")#mi("{X_h}")#text(".) The ")#emph[#text("fractal uncertainty principle")]#text(", when it applies, asserts that one can improve this to")

#align(center)[#tao-fit-display[#tao-math("\\left\\| 1_{X_h} {\\mathcal F}_h 1_{X_h} \\right\\|_{L^2({\\bf R}^d) \\rightarrow L^2({\\bf R}^d)} \\lesssim_{C,d} h^{\\max\\left(\\frac{d}{2}-\\delta,0\\right) + \\beta}", block: true)]]

#text("for some ")#mi("{\\beta>0}")#text("; informally, this asserts that a function and its Fourier transform cannot simultaneously be concentrated in the set ")#mi("{X_h}")#text(" when ")#mi("{\\delta \\leq \\frac{d}{2}}")#text(", and that a function cannot be concentrated on ")#mi("{X_h}")#text(" and have its Fourier transform be of maximum size on ")#mi("{X_h}")#text(" when ")#mi("{\\delta \\geq \\frac{d}{2}}")#text(". A modification of the disk example mentioned previously shows that such a fractal uncertainty principle cannot hold if ")#mi("{\\delta}")#text(" is an integer. However, in one dimension, the fractal uncertainty principle is known to hold for all ")#mi("{0 < \\delta < 1}")#text(". The above-mentioned results of Dyatlov and Zahl were able to establish this for ")#mi("{\\delta}")#text(" close to ")#mi("{1/2}")#text(", and the remaining cases ")#mi("{1/2 < \\delta < 1}")#text(" and ")#mi("{0 < \\delta < 1/2}")#text(" were later established by ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3779959")[#text("Bourgain-Dyatlov")]#text(" and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3803716")[#text("Dyatlov-Jin")]#text(" respectively. Such uncertainty principles have applications to hyperbolic dynamics, in particular in establishing spectral gaps for certain Selberg zeta functions.")

#text("It remains a largely open problem to establish a fractal uncertainty principle in higher dimensions. Our results allow one to establish such a principle when the dimension ")#mi("{\\delta}")#text(" is close to ")#mi("{d/2}")#text(", and ")#mi("{d}")#text(" is assumed to be odd (to make ")#mi("{d/2}")#text(" a non-integer). There is also work of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=4085124")[#text("Han and Schlag")]#text(" that obtains such a principle when one of the copies of ")#mi("{X_h}")#text(" is assumed to have a product structure. We hope to obtain further higher-dimensional fractal uncertainty principles in subsequent work.")

#text("We now sketch how our main theorem is proved. In both one dimension and higher dimensions, the main point is to get a preliminary improvement ")#metadata(none) <tao-0e7546ed18407142890e>#mi("\\displaystyle  \\mathrm{E}(\\mu,r_0) \\leq \\varepsilon r_0^\\delta \\ \\ \\ \\ \\ (3)")#text(" ")#text(" over the trivial bound ")#link(<tao-5f2b1d6f5492140fa7b4>)[#text("(2)")]#text(" for any small ")#mi("{\\varepsilon>0}")#text(", provided ")#mi("{r_0}")#text(" is sufficiently small depending on ")#mi("{\\varepsilon, \\delta, d}")#text("; one can then iterate this bound by a fairly standard “induction on scales” argument (which roughly speaking can be used to show that energies ")#mi("{\\mathrm{E}(\\mu,r)}")#text(" behave somewhat multiplicatively in the scale parameter ")#mi("{r}")#text(") to propagate the bound to a power gain at smaller scales. We found that a particularly clean way to run the induction on scales was via use of the Gowers uniformity norm ")#mi("{U^2}")#text(", and particularly via a clean Fubini-type inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{U^2(V \\times V^{\\prime})} \\leq \\left\\|f\\right\\|_{U^2(V; U^2(V^{\\prime}))}", block: true)]]

#text("(ultimately proven using the Gowers-Cauchy-Schwarz inequality) that allows one to “decouple” coarse and fine scale aspects of the Gowers norms (and hence of additive energies).")

#text("It remains to obtain the preliminary improvement. In one dimension this is done by identifying some “left edges” of the set ")#mi("{X}")#text(" that supports ")#mi("{\\mu}")#text(": intervals ")#mi("{[x, x+K^{-n}]}")#text(" that intersect ")#mi("{X}")#text(", but such that a large interval ")#mi("{[x-K^{-n+1},x]}")#text(" just to the left of this interval is disjoint from ")#mi("{X}")#text(". Here ")#mi("{K}")#text(" is a large constant and ")#mi("{n}")#text(" is a scale parameter. It is not difficult to show (using in particular the Archimedean nature of the real line) that if one has the Ahlfors-David regularity condition for some ")#mi("{0 < \\delta < 1}")#text(" then left edges exist in abundance at every scale; for instance most points of ")#mi("{X}")#text(" would be expected to lie in quite a few of these left edges (much as most elements of, say, the ternary Cantor set ")#mi("{\\{ \\sum_{n=1}^\\infty \\varepsilon_n 3^{-n} \\varepsilon_n \\in \\{0,1\\} \\}}")#text(" would be expected to contain a lot of ")#mi("{0}")#text("s in their base ")#mi("{3}")#text(" expansion). In particular, most pairs ")#mi("{(x_1,x_2) \\in X \\times X}")#text(" would be expected to lie in a pair ")#mi("{[x,x+K^{-n}] \\times [y,y+K^{-n}]}")#text(" of left edges of equal length. The key point is then that if ")#mi("{(x_1,x_2) \\in X \\times X}")#text(" lies in such a pair with ")#mi("{K^{-n} \\geq r}")#text(", then there are relatively few pairs ")#mi("{(x_3,x_4) \\in X \\times X}")#text(" at distance ")#mi("{O(K^{-n+1})}")#text(" from ")#mi("{(x_1,x_2)}")#text(" for which one has the relation ")#mi("{x_1+x_2 = x_3+x_4 + O(r)}")#text(", because ")#mi("{x_3,x_4}")#text(" will both tend to be to the right of ")#mi("{x_1,x_2}")#text(" respectively. This causes a decrement in the energy at scale ")#mi("{K^{-n+1}}")#text(", and by carefully combining all these energy decrements one can eventually cobble together the energy bound ")#link(<tao-0e7546ed18407142890e>)[#text("(3)")]#text(".")

#text("We were not able to make this argument work in higher dimension (though perhaps the cases ")#mi("{0 < \\delta < 1}")#text(" and ")#mi("{d-1 < \\delta < d}")#text(" might not be completely out of reach from these methods). Instead we return to additive combinatorics methods. If the claim ")#link(<tao-0e7546ed18407142890e>)[#text("(3)")]#text(" failed, then by applying the Balog-Szemeredi-Gowers theorem we can show that the set ")#mi("{X}")#text(" has high correlation with an approximate group ")#mi("{H}")#text(", and hence (by the aforementioned Bogulybov-Ruzsa type theorem of Sanders, which is the main source of the quasipolynomial bounds in our final exponent) ")#mi("{X}")#text(" will exhibit an approximate “symmetry” along some non-trivial arithmetic progression of some spacing length ")#mi("{r}")#text(" and some diameter ")#mi("{R \\gg r}")#text(". The ")#mi("{r}")#text("-neighbourhood ")#mi("{X_r}")#text(" of ")#mi("{X}")#text(" will then resemble the union of parallel “cylinders” of dimensions ")#mi("{r \\times R}")#text(". If we focus on a typical ")#mi("{R}")#text("-ball of ")#mi("{X_r}")#text(", the set now resembles a Cartesian product of an interval of length ")#mi("{R}")#text(" with a subset of a ")#mi("{d-1}")#text("-dimensional hyperplane, which behaves approximately like an Ahlfors-David regular set of dimension ")#mi("{\\delta-1}")#text(" (this already lets us conclude a contradiction if ")#mi("{\\delta<1}")#text("). Note that if the original dimension ")#mi("{\\delta}")#text(" was non-integer then this new dimension ")#mi("{\\delta-1}")#text(" will also be non-integer. It is then possible to contradict the failure of ")#link(<tao-0e7546ed18407142890e>)[#text("(3)")]#text(" by appealing to a suitable induction hypothesis at one lower dimension.")

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/124f2317c08c4d35f23785e647ba4da7ea5b54e91cc0b97f90495f7b029a8950-52e8d46162151a102d40dcda946c298a4443f49577a98fe9dd24447fc7395ac3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rafik zeraoulia")]], [#link("https://terrytao.wordpress.com/2020/12/06/additive-energy-of-regular-measures-in-one-and-higher-dimensions-and-the-fractional-uncertainty-principle/#comment-608520")[#strong[#text("rafik zeraoulia")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2020")])]

#text("Dear Prof Tao ,In which case we could have a uniforme distribution (Gaussian) for additive energy ? for integer dimension or non integer ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/06/additive-energy-of-regular-measures-in-one-and-higher-dimensions-and-the-fractional-uncertainty-principle/#comment-608577")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2020")])]

#text("Proposition 2.1: The last expression is missing; “In fact we can take …”")

#emph[#text("[This will be deleted in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/06/additive-energy-of-regular-measures-in-one-and-higher-dimensions-and-the-fractional-uncertainty-principle/#comment-608604")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2020")])]

#text("What was the motivation behind the introduction of the (apparently artificial) expression ")#mi("x_1 + x_2 - x_3 - x_4")#text(" in the definition (1) ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/12/06/additive-energy-of-regular-measures-in-one-and-higher-dimensions-and-the-fractional-uncertainty-principle/#comment-608624")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2020")])]

#text("Additive energy is a statistical measure of the extent to which a given set ")#mi("X")#text(" (in this case, the support of ")#mi("\\mu")#text(") contains additive structure, which roughly speaking means that the set ")#mi("X")#text(" behaves approximately as if it is closed under addition. The intuition here is that if ")#mi("X")#text(" is approximately closed under addition, then the sums ")#mi("x_1+x_2, x_1,x_2 \\in X")#text(" range in an unusually small set, so one should expect to see a lot of “collisions” ")#mi("x_1+x_2=x_3+x_4")#text(" or “near-collisions” ")#mi("x_1+x_2=x_3+x_4+O(r)")#text("” between these sums. The additiv energy measures these collisions, and turns out to be a convenient proxy for additive structure for a number of reasons, such as its connection to the Gowers uniformity norm and to the Fourier transform of the underlying measure ")#mi("\\mu")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/124f2317c08c4d35f23785e647ba4da7ea5b54e91cc0b97f90495f7b029a8950-52e8d46162151a102d40dcda946c298a4443f49577a98fe9dd24447fc7395ac3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rafik Zeraoulia")]], [#link("https://terrytao.wordpress.com/2020/12/06/additive-energy-of-regular-measures-in-one-and-higher-dimensions-and-the-fractional-uncertainty-principle/#comment-608631")[#strong[#text("Rafik Zeraoulia")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2020")])]

#text("if am true I think this definition for additive energy coincide with sub-energy function definition such that one can construct sub energy function in one dimension or higher by the following assumption : f_c(x_1,x_2,x_3,x_4) go to infinity if x_1+x_2+x_3+x_4 go also to infinity one can replace this weaker condition x_1+x_2+x_3+x_4 with stronger conditions like x_1 go infty or x_2 go infty ,…. ,Now my question here is : Is that Additive energy function a physical notion or mathematical notion like sub-energy function which it used widely in statistical mechanics ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiao")]], [#link("https://terrytao.wordpress.com/2020/12/06/additive-energy-of-regular-measures-in-one-and-higher-dimensions-and-the-fractional-uncertainty-principle/#comment-608684")[#strong[#text("Xiao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2020")])]

#text("A typo just founded p. 34 “Let u’ denotes”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/06/additive-energy-of-regular-measures-in-one-and-higher-dimensions-and-the-fractional-uncertainty-principle/#comment-608688")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2020")])]

#text("In Proposition 5.1 a symbol may be missing in the sentence ‘In fact one can take to be quasipolynomial in (…)’ after the word take. Is it r0 ?")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/06/additive-energy-of-regular-measures-in-one-and-higher-dimensions-and-the-fractional-uncertainty-principle/#comment-608977")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2020")])]

#text("In the bibliography, the reference #13 could be quoted as follows:")#linebreak()#text(" [13] O.E. Raz, J. Zahl. . 29 pages, arXiv:2010.04845, October 2020.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/06/additive-energy-of-regular-measures-in-one-and-higher-dimensions-and-the-fractional-uncertainty-principle/#comment-608979")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2020")])]

#text("Instead of ‘Theorems 1.4, 1.5’ you could mention ‘Theorems 1.4 and 1.5’ (3 occurrences)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonym")]], [#link("https://terrytao.wordpress.com/2020/12/06/additive-energy-of-regular-measures-in-one-and-higher-dimensions-and-the-fractional-uncertainty-principle/#comment-608993")[#strong[#text("Anonym")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2020")])]

#text("Dear Professor Tao,")#linebreak()#text(" Very interesting and unexpected paper.")#linebreak()#text(" In order to optimize it, I just have a very minor lexical suggestion related to the expressions compare and compared “against” or “to”.")#linebreak()#text(" Maybe these expressions should be replaced by compare and compared “with”.")#linebreak()#text(" Yours sincerely")
]
