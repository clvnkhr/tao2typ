// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/11/19/sum-difference-exponents-for-boundedly-many-slopes-and-rational-complexity/
// Converted to Typst by tao2typ: "2026-10-14T15:21:08.015693+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Sum-difference exponents for boundedly many slopes, and rational complexity", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Sum-difference exponents for boundedly many slopes, and rational complexity")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 November 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/11/19/sum-difference-exponents-for-boundedly-many-slopes-and-rational-complexity/")[#text("https://terrytao.wordpress.com/2025/11/19/sum-difference-exponents-for-boundedly-many-slopes-and-rational-complexity/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I have uploaded to the arXiv my paper “")#link("http://arxiv.org/abs/2511.15135")[#text("Sum-difference exponents for boundedly many slopes, and rational complexity")]#text("“. This is the second spinoff of my previous project with Bogdan Georgiev, Javier Gómez–Serrano, and Adam Zsolt Wagner that I ")#link("https://terrytao.wordpress.com/2025/11/05/mathematical-exploration-and-discovery-at-scale/")[#text("recently posted about")]#text(". One of the many problems we experimented using the AlphaEvolve tool with was that of computing sum-difference constants. While AlphaEvolve did modest improve one of the known lower bounds on sum-difference constants, it also revealed an asymptotic behavior to these constants that had not been previously observed, which I then gave a rigorous demonstration of in this paper.")

#text("In the original formulation of the sum-difference problem, one is given a finite subset ")#mi("{E}")#text(" of ")#mi("{{\\bf R}^2}")#text(" with some control on projections, such as")

#tao-aligned(keep: true)[


#tao-math("\\left|\\{ a: (a,b) \\in E \\}\\right|  & \\leq N", block: true)



#tao-math("\\left|\\{ b: (a,b) \\in E \\}\\right|  & \\leq N", block: true)



#tao-math("\\left|\\{ a+b: (a,b) \\in E \\}\\right|  & \\leq N", block: true)
]

#text("and one then asks to obtain upper bounds on the quantity")

#metadata(none) <tao-8367cd66fdd136bba8ba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|\\{ a-b: (a,b) \\in E \\}\\right|.", block: true)]]

#text("This is related to Kakeya sets because if one joins a line segment between ")#mi("{(a,0)}")#text(" and ")#mi("{(b,1)}")#text(" for every ")#mi("{(a,b) \\in E}")#text(", one gets a family of line segments whose set of directions has cardinality ")#link(<tao-8367cd66fdd136bba8ba>)[#text("(1)")]#text(", but whose slices at heights ")#mi("{0,1,1/2}")#text(" have cardinality at most ")#mi("{N}")#text(".")

#text("Because ")#mi("{a-b}")#text(" is clearly determined by ")#mi("{a}")#text(" and ")#mi("{b}")#text(", one can trivially get an upper bound of ")#mi("{N^2}")#text(" on ")#link(<tao-8367cd66fdd136bba8ba>)[#text("(1)")]#text(". In 1999, ")#link("https://zbmath.org/0930.43005")[#text("Bourgain utilized")]#text(" what was then the very recent “Balog–Szemerédi–Gowers lemma” to improve this bound to ")#mi("{N^{2-\\frac{1}{13}}}")#text(", which gave a new lower bound of ")#mi("{\\frac{13d+12}{25}}")#text(" on the (Minkowski) dimension of Kakeya sets in ")#mi("{{\\bf R}^d}")#text(", which improved upon the ")#link("https://zbmath.org/0848.42015")[#text("previous bounds")]#text(" of Tom Wolff in high dimensions. (A side note: Bourgain challenged Tom to also obtain a result of this form, but when they compared notes, Tom obtained the slightly weaker bound of ")#mi("{N^{2-\\frac{1}{14}}}")#text(", which gave Jean great satisfaction.) Currently, the ")#link("https://zbmath.org/0980.42013")[#text("best upper bound")]#text(" known for this quantity is ")#mi("{N^{2-\\frac{1}{6}}}")#text(".")

#text("One can get better bounds by adding more projections. For instance, if one also assumes")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ a+2b: (a,b) \\in E \\}\\right| \\leq N", block: true)]]

#text("then ")#link("https://zbmath.org/0980.42013")[#text("one can improve")]#text(" the upper bound for ")#link(<tao-8367cd66fdd136bba8ba>)[#text("(1)")]#text(" to ")#mi("{N^{2-\\frac{1}{4}}}")#text(". The ")#emph[#text("arithmetic Kakeya conjecture")]#text(" asserts that, by adding enough projections, one can get the exponent arbitrarily close to ")#mi("{1}")#text(". If one could achieve this, this would imply the Kakeya conjecture in all dimensions. Unfortunately, even with arbitrarily many projections, the ")#link("https://zbmath.org/1027.42014")[#text("best exponent we can reach asymptotically")]#text(" is ")#mi("{1.67513\\dots}")#text(".")

#text("It was ")#link("https://zbmath.org/1438.42040")[#text("observed by Ruzsa")]#text(" that all of these questions can be equivalently formulated in terms of Shannon entropy. For instance, the upper bound ")#mi("{N^{2-\\frac{1}{6}}}")#text(" of ")#link(<tao-8367cd66fdd136bba8ba>)[#text("(1)")]#text(" turns out to be equivalent to the entropy inequality")

#align(center)[#tao-fit-display[#mitex("{\\bf H}(X-Y) \\leq (2-\\frac{1}{6}) \\max( {\\bf H}(X), {\\bf H}(Y) , {\\bf H}(X+Y) )")]]

#text("holding for all discrete random variables ")#mi("{X, Y}")#text(" (not necessarily independent) taking values in ")#mi("{{\\bf R}^2}")#text(". In the language of this paper, we write this as")

#align(center)[#tao-fit-display[#mitex("SD(\\{0,1,\\infty\\}; -1) \\leq 2-\\frac{1}{6}.")]]

#text("Similarly we have")

#align(center)[#tao-fit-display[#mitex("SD(\\{0,1,2,\\infty\\}; -1) \\leq 2-\\frac{1}{4}.")]]

#text("As part of the AlphaEvolve experiments, we directed this tool to obtain lower bounds for ")#mi("{SD(\\{0,1,\\infty\\}; \\frac{a}{b})}")#text(" for various rational numbers ")#mi("{\\frac{a}{b}}")#text(", defined as the best constant in the inequality")

#align(center)[#tao-fit-display[#mitex("{\\bf H}(X+\\frac{a}{b} Y) \\leq SD(\\{0,1,\\infty\\}; \\frac{a}{b}) \\max( {\\bf H}(X), {\\bf H}(Y) , {\\bf H}(X+Y) ).")]]

#text("We did not figure out a way for AlphaEvolve to efficiently establish upper bounds on these quantities, so the bounds provided by AlphaEvolve were of unknown accuracy. Nevertheless, they were sufficient to give a strong indication that these constants decayed logarithmically to ")#mi("{2}")#text(" as ")#mi("{a+b \\rightarrow \\infty}")#text(":")

#image("../assets/f36a5051518b11b201c6ff4438ac736091fea1c8855a6e7f6d79686a58106d85-94fc363d3f188c0aa4311a30a70e6d140c61b5d391d6f076e807adbd972dcf48.png", width: 90%)

#text("The first main result of this paper is to confirm that this is indeed the case, in that")

#align(center)[#tao-fit-display[#tao-math("2 - \\frac{c_2}{\\log(2+\\left|a\\right|+\\left|b\\right|)} \\leq SD(\\{0,1,\\infty\\}; \\frac{a}{b}) \\leq 2 - \\frac{c_1}{\\log(2+\\left|a\\right|+\\left|b\\right|)}", block: true)]]

#text("whenever ")#mi("{a/b}")#text(" is in lowest terms and not equal to ")#mi("{0, 1, \\infty}")#text(", where ")#mi("{c_1,c_2>0}")#text(" are absolute constants. The lower bound was obtained by observing the shape of the examples produced by AlphaEvolve, which resembled a discrete Gaussian on a certain lattice determined by ")#mi("{a,b}")#text(". The upper bound was established by an application of the “entropic Plünnecke–Ruzsa calculus”, relying particularly on the entropic Ruzsa triangle inequality, the entropic Balog–Szemerédi–Gowers lemma, as well as an entropy form of an inequality of Bukh.")

#text("The arguments also apply to settings where there are more projections under control than just the ")#mi("{0,1,\\infty}")#text(" projections. If one also controls projections ")#mi("{X + r_i Y}")#text(" for various rationals ")#mi("{r_1,\\dots,r_k}")#text(" and ")#mi("{R}")#text(" denotes the set of slopes of the projections under control, then it turns out that the associated sum-difference constant ")#mi("{SD(\\{0,1,\\infty,r_1,\\dots,r_k\\}; s)}")#text(" still decays to ")#mi("{2}")#text(", but now the key parameter is not the height ")#tao-math("{\\left|a\\right|+\\left|b\\right|}", block: false)#text(" of ")#mi("{s}")#text(", but rather what I call the ")#emph[#text("rational complexity")]#text(" of ")#mi("{s}")#text(" with respect to ")#mi("{R}")#text(", defined as the smallest integer ")#mi("{D}")#text(" for which one can write ")#mi("{s}")#text(" as a ratio ")#mi("{P(r_1,\\dots,r_k)/Q(r_1,\\dots,r_k)}")#text(" where ")#mi("{P,Q}")#text(" are integer-coefficient polynomials of degree at most ")#mi("{D}")#text(" and coefficients at most ")#mi("{2^D}")#text(". Specifically, ")#mi("{SD(\\{0,1,\\infty,r_1,\\dots,r_k\\}; s)}")#text(" decays to ")#mi("{2}")#text(" at a polynomial rate in ")#mi("{D}")#text(", although I was not able to pin down the exponent of this decay exactly. The concept of rational complexity may seem somewhat artificial, but it roughly speaking measures how difficult it is to use the entropic Plünnecke–Ruzsa calculus to pass from control of ")#mi("{X, Y, X+Y}")#text(", and ")#mi("{X+r_i Y}")#text(" to control of ")#mi("{X+sY}")#text(".")

#text("While this work does not make noticeable advances towards the arithmetic Kakeya conjecture (we only consider regimes where the sum-difference constant is close to ")#mi("{2}")#text(", rather than close to ")#mi("{1}")#text("), it does highlight the fact that these constants are extremely arithmetic in nature, in that the influence of projections ")#mi("{X+r_iY}")#text(" on ")#mi("{X+sY}")#text(" is highly dependent on how efficiently one can represent ")#mi("{s}")#text(" as a rational combination of the ")#mi("{r_i}")#text(".")

#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2025/11/19/sum-difference-exponents-for-boundedly-many-slopes-and-rational-complexity/#comment-689104")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2025")])]

#text("Terry,")

#text("I wasn’t aware that Wolff obtained an arithmetic Kakeya result with exponent N^(13/14). Does a write-up of that proof still exist somewhere? I’ve spent some time thinking about this problem over the years.")

#text("I also have a couple of comments/questions regarding the related AI paper:")

#strong[#text("1. Nikodym set construction:")]#text(" It isn’t entirely clear what you were asking the AI to do. I assumed you were asking it to construct large sets for a fixed field. However, you reported that it produced algebraic constructions that applied to general fields, with sizes estimated using Weil-type considerations. Did you explicitly instruct it to look among algebraic constructions, or did it start by just trying to construct a set for a fixed field and then “discover” the algebraic constructions on its own?")

#strong[#text("2. Furstenberg–Sárközy problem:")]#text(" I’m not surprised that the AI didn’t produce a better construction following Ruzsa’s approach. Constructing a set to run Ruzsa’s argument is essentially equivalent to finding a clique in a dense graph. Assuming quadratic residues behave sufficiently randomly, the clique should be logarithmic in the modulus m, meaning that sets perform worse as m grows. When I looked at this years ago, I was able to check all small m, and the set of residues modulo 205 was optimal. It might well be for all m if the cliques really are logarithmic.")

#text("For the AI to find a better set, it would essentially need to either (1) discover a new algorithm for finding cliques in dense graphs (an NP-complete problem), or (2) uncover new properties of quadratic residues. Either scenario would likely be more exciting than simply improving the exponent in the problem. That said, I suspect that Ruzsa’s approach is probably not optimal for a lower bound. Did you try asking the AI to construct a large set avoiding squares without going through the Ruzsa route?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/11/19/sum-difference-exponents-for-boundedly-many-slopes-and-rational-complexity/#comment-689106")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2025")])]

#text("I don’t think Tom wrote up the argument; apparently he and Jean had made it some sort of friendly competition (this is from my memory of what Jean told me).")

#text("Nikodym: you can see the prompts used at ")#link("https://github.com/google-deepmind/alphaevolve_repository_of_problems/blob/main/experiments/finite_field_nikodym_problem/finite_field_nikodym.ipynb")[#text("https://github.com/google-deepmind/alphaevolve_repository_of_problems/blob/main/experiments/finite_field_nikodym_problem/finite_field_nikodym.ipynb")]#text(" . We were using what we call the “generalizer mode” of AlphaEvolve, in which we do not fix the size parameter ")#mi("p")#text(" in advance, but ask AE to produce a function that takes ")#mi("p")#text(" as input and returns a candidate Nikodym set as output. This is then scored based on an averaged basket of possible ")#mi("p")#text(" that includes both small and large primes (initially we selected ")#mi("p")#text(" randomly each time the verifier was called, but we found that the hillclimbing was better if we used a fixed set of primes throughout). This tends to force AE to produce interpretable code that creates a single algorithm that works for many primes, as opposed to having ad hoc constructions for each separate prime.")

#text("Furstenberg-Sarkozy: I don’t believe we tried anything other than the Ruzsa construction, as this was the only method we knew of that gave asymptotic power savings as ")#mi("N \\to \\infty")#text(". I could launch a new AlphaEvolve run to try to lower bound what we call ")#mi("C_{6.31}(k,N)")#text(" or ")#mi("C_{6.31}(k,{\\bf Z}/M{\\bf Z})")#text(" for specific ranges of ")#mi("k, N, M")#text("; we could also try the generalizer mode of using a variable ")#mi("N")#text(" perhaps starting with providing the Ruzsa construction as a hint; if you have some more specific suggestions on what would be interesting, I can look into this. (From memory, I think we ran experiments on this problem before figuring out the generalizer mode of AE.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/11/19/sum-difference-exponents-for-boundedly-many-slopes-and-rational-complexity/#comment-689130")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2025")])]

#text("Just reporting on some experiments we ran, asking AlphaEvolve to construct ")#mi("k=2")#text(" Furstenberg-Sarkozy sets of various ranges of size: when restricteed to ")#mi("N \\leq 10^4")#text(", AE tried increasingly ornate versions of the greedy algorithm that gave sets of size about ")#mi("N^{0.7}")#text(" empirically. For ")#mi("N \\leq 10^7")#text(", AE latched onto the Ruzsa construction (which it somehow “knew” from its training data) which gave roughly ")#mi("N^{0.72}")#text(" after some minor optimizations, and was unable to find anything better.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/11/19/sum-difference-exponents-for-boundedly-many-slopes-and-rational-complexity/#comment-689131")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2025")])]

#text("Thanks for the update! I was doing some experiments before I replied. When you say “latched on to the Ruzsa construction” was it working in base 205 or some other base? Do you have reason to believe it learned the construction from its training data versus having discovered the approach on its own?")

#text("While that’s a bit disappointing, I guess it’s an interesting question of what the greedy construction actually theoretically gives. I don’t think there is any theoretical result known above an exponent $1/2$ other than variants of Ruzsa.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/11/19/sum-difference-exponents-for-boundedly-many-slopes-and-rational-complexity/#comment-689134")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2025")])]

#text("It refers to the Ruzsa construction by name; it initially worked with base 25, but for the most recent evolution (scoring about 0.73 in the exponent) it is doing something more compliated. In AE’s self-description: “This implementation uses a portfolio of Ruzsa-style constructions, including")#linebreak()#text(" “compounded” constructions. It dynamically chooses the best construction")#linebreak()#text(" from this portfolio for a given N. For smaller N, it densifies the sparse")#linebreak()#text(" Ruzsa set using a biased greedy algorithm.”")

#text("The code (in Python) is somewhat complicated, but still readable; I can send you a copy if you are interested.")

#text("For smaller N, AE’s best evolution (scoring an exponent of about 0.71) is doing some baroque version of a greedy algorithm. According to its self-description, ” This version employs a multi-start local search approach. It generates a diverse portfolio of initial subsets using simple greedy strategies,and then refines each initial subset using a “swarm intelligence rearrangement”")#linebreak()#text(" local search. The best valid subset found across all refinements is returned.”. Again, I can send a copy of the code if you wish.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2025/11/19/sum-difference-exponents-for-boundedly-many-slopes-and-rational-complexity/#comment-689135")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2025")])]

#text("Well I see AI won’t spare us from puzzling over cryptic and convoluted claims from fellow researchers:) I would be interested in seeing the code if you’re up for sharing it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2025/11/19/sum-difference-exponents-for-boundedly-many-slopes-and-rational-complexity/#comment-689136")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2025")])]

#text("I’m not sure how much effort you’re putting into running these experiments, but a related problem that might be worth trying if it isn’t much work is the lower bound the first case of polynomial Roth (those sets avoiding x, x+y, x+y^2). The current record uses a variant of Ruzsa’s construction but there might be more room for variation on that problem. This was studied in: ")#link("https://arxiv.org/abs/1908.06058")[#text("https://arxiv.org/abs/1908.06058")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/11/19/sum-difference-exponents-for-boundedly-many-slopes-and-rational-complexity/#comment-689145")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2025")])]

#text("We’re starting an AE run now on this problem; so far, non-Ruzsa constructions are numerically performing at an exponent of about 0.752.")

#text("I also just started a run optimize the use of Theorem 1.5 in the paper of Younis you linked to try to improve the asymptotic exponent ")#mi("\\gamma")#text(" beyond the current record of ")#mi("\\gamma = 0.7685")#text(". Initially, the verifier didn’t quite code the condition ")#mi("r_{i+1}-r^{\\prime}_{i+1} \\neq (r_i - r^{\\prime}_i)^2 \\text{ mod } m")#text(" correctly (it required ")#mi("r_{i+1} > r^{\\prime}_{i+1}")#text(" instead of ")#mi("r_{i+1} \\neq r^{\\prime}_{i+1}")#text("), giving rise to a suspiciously too-good-to-be-true exponent ")#mi("\\gamma = \\log 6 / 2\\log 3 \\approx 0.815464877")#text(" using ")#mi("m = 3")#text(", ")#mi("R_0 = \\{0,1,2\\}")#text(", ")#mi("R_i = \\{0,2\\}")#text(" for ")#mi("i>0")#text("; but I just fixed the bug and will run it again and will see what happens.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/11/19/sum-difference-exponents-for-boundedly-many-slopes-and-rational-complexity/#comment-689146")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2025")])]

#text("Update: after about 5 hours (and a nap on my part), AE claims to have improved Younis’s exponent from ")#mi("\\gamma = 0.7685")#text(" to ")#mi("0.7731")#text(". The construction starts off the same as Younis with ")#mi("m=65")#text(" and ")#mi("R_0 = \\{0,\\dots,m-1\\}")#text(" but then does something else than alternate between two sets ")#mi("R_1, R_2")#text(". Here is the current record holding sequence of sets ")#mi("R_0, R_1, R_2, \\dots")#text(" (I only asked for finite sequences, and this one terminates at ")#mi("R_{42}")#text("):")

#text("{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64}, {0, 37, 42, 48, 54, 59, 31}, {0, 33, 5, 6, 38, 27, 11, 43, 44, 28, 16, 49, 21, 22, 54, 59, 60}, {26, 36, 38, 43, 16, 48, 21, 53, 58, 31}, {1, 3, 35, 40, 9, 42, 14, 16, 48, 29, 53, 22, 55, 27, 61}, {3, 6, 48, 51, 24, 27, 30}, {32, 2, 36, 6, 40, 10, 44, 14, 47, 17, 51, 21, 55, 25, 59, 29, 63}, {33, 36, 38, 13, 15, 21, 53, 55, 58, 61}, {0, 37, 5, 39, 11, 44, 13, 18, 50, 52, 24, 57, 26, 31, 63}, {1, 35, 8, 42, 20, 54, 23}, {3, 35, 41, 14, 47, 20, 24, 58, 62}, {4, 6, 7, 8, 9, 46, 48, 49, 50, 51, 52, 54, 26, 27, 28, 29, 31}, {33, 36, 9, 12, 14, 55, 31}, {64, 4, 37, 5, 36, 10, 42, 43, 15, 48, 20, 21, 53, 54, 26, 59, 31}, {2, 12, 46, 15, 56, 25, 59}, {0, 2, 4, 6, 8, 19, 21, 23, 25, 27, 29, 31, 42, 44, 46, 48, 50, 52, 63}, {64, 33, 9, 41, 43, 51, 20, 53, 61, 30}, {35, 37, 6, 12, 18, 52, 24, 58, 60, 29}, {1, 33, 6, 39, 12, 44, 28, 17, 50, 23, 55, 60}, {2, 3, 44, 45, 13, 46, 47, 23, 24, 25, 26, 57}, {64, 37, 43, 16, 49, 18, 24, 56, 62, 31}, {38, 7, 41, 14, 48, 17, 26, 60, 29}, {0, 2, 3, 4, 5, 6, 7, 45, 46, 47, 48, 50, 24, 25, 26, 27, 28}, {64, 1, 42, 18, 20, 23, 61}, {0, 33, 5, 38, 10, 11, 12, 43, 44, 28, 17, 49, 23, 22, 55, 54, 60}, {32, 5, 8, 11, 49, 52, 29}, {0, 34, 4, 38, 8, 42, 12, 46, 15, 50, 19, 54, 23, 58, 27, 61, 30}, {2, 36, 44, 13, 47, 55, 24}, {0, 34, 4, 38, 7, 42, 12, 46, 15, 50, 19, 53, 23, 57, 27, 61, 30}, {2, 36, 5, 48, 17, 55, 24}, {34, 36, 38, 11, 13, 14, 15, 16, 19, 56, 57, 59, 61}, {64, 36, 5, 38, 10, 12, 44, 49, 18, 51, 23, 25, 31, 62, 57}, {1, 4, 42, 45, 48, 21, 24}, {32, 1, 4, 36, 39, 8, 43, 12, 47, 16, 51, 20, 54, 24, 58, 28, 62}, {1, 4, 41, 44, 46, 49, 21, 24, 26, 29}, {1, 33, 35, 7, 40, 9, 27, 14, 46, 48, 20, 53, 22, 59, 61}, {36, 8, 42, 14, 19, 25, 31}, {32, 64, 4, 37, 5, 38, 27, 10, 43, 15, 16, 48, 21, 22, 53, 54, 59}, {1, 39, 44, 46, 49, 51, 54, 56, 59, 61}, {4, 36, 42, 15, 48, 21, 63}, {32, 33, 35, 8, 10, 11, 12, 13, 50, 52, 53, 54, 55, 56, 58, 30, 31}, {39, 8, 51, 20, 28, 62, 31}, {32, 1, 36, 5, 39, 9, 43, 13, 47, 17, 51, 20, 55, 24, 59, 28, 63}")

#text("The solutions are still evolving, so I expect some small further improvements in the next few hours. Interesting though that it discovered the same starting position as Younis (though it took about 4 hours before it latched on that 65 could be a useful modulus, it was obsessed with 41 for a while, eventually managing to get as far as 0.7670 with that choice).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2025/11/19/sum-difference-exponents-for-boundedly-many-slopes-and-rational-complexity/#comment-689150")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2025")])]

#text("It’s not clear to me if the AI is claiming to have an infinite sequence of sets that theoretically improve the result, or is it just finding an admissible sequence up to the parameter it is being given.")

#text("Regarding 41, recall that this modulus works well for the Frustenberg-Sarkozy problem. According to the remarks at the end of his paper, Ruzsa originally discovered the argument with a set of residues mod 5, Balog then improved it using a set of residues mod 41 and then Ruzsa found his set of residues mod 65. Following that pattern (if the AI is amenable to suggestion) it might be worth suggesting it try some residues mod 205.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/11/19/sum-difference-exponents-for-boundedly-many-slopes-and-rational-complexity/#comment-689153")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2025")])]

#text("I believe any finite admissible sequence can be continued indefinitely by adding an infinite sequence of singleton sets such as ")#mi("\\{0\\}")#text(", so every such sequence should provide a lower bound on ")#mi("\\gamma")#text(".")

#text("AE has improved the exponent marginally to 0.7732, but I will stop it now and ask it to search ")#mi("m=205")#text(" specifically and see what happens.")

#text("UPDATE: For ")#mi("m=205")#text(" AE can get up to 0.7702, but then stalls. So, not a bad choice of ")#mi("m")#text(", but apparently not optimal.")
]
]
