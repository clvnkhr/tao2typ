// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/
// Converted to Typst by tao2typ: "2026-10-14T09:05:35.565347+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Nonstandard analysis as a completion of standard analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Nonstandard analysis as a completion of standard analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 November 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/")[#text("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Many structures in mathematics are ")#emph[#text("incomplete")]#text(" in one or more ways. For instance, the field of rationals ")#mi("{{\\bf Q}}")#text(" or the reals ")#mi("{{\\bf R}}")#text(" are ")#emph[#text("algebraically incomplete")]#text(", because there are some non-trivial algebraic equations (such as ")#mi("{x^2=2}")#text(" in the case of the rationals, or ")#mi("{x^2=-1}")#text(" in the case of the reals) which could ")#emph[#text("potentially")]#text(" have solutions (because they do not imply a necessarily false statement, such as ")#mi("{1=0}")#text(", just using the laws of algebra), but do not ")#emph[#text("actually")]#text(" have solutions in the specified field.")

#text("Similarly, the rationals ")#mi("{{\\bf Q}}")#text(", when viewed now as a metric space rather than as a field, are also ")#emph[#text("metrically incomplete")]#text(", beause there exist sequences in the rationals (e.g. the decimal approximations ")#mi("{3, 3.1, 3.14, 3.141, \\ldots}")#text(" of the irrational number ")#mi("{\\pi}")#text(") which could ")#emph[#text("potentially")]#text(" converge to a limit (because they form a ")#link("http://en.wikipedia.org/wiki/Cauchy_sequence")[#text("Cauchy sequence")]#text("), but do not ")#emph[#text("actually")]#text(" converge in the specified metric space.")

#text("A third type of incompleteness is that of ")#emph[#text("logical incompleteness")]#text(", which applies now to formal theories rather than to fields or metric spaces. For instance, ")#link("http://en.wikipedia.org/wiki/Zermelo%E2%80%93Fraenkel_set_theory")[#text("Zermelo-Frankel-Choice (ZFC) set theory")]#text(" is logically incomplete, because there exist statements (such as the consistency of ZFC) which could ")#emph[#text("potentially")]#text(" be provable by the theory (because it does not lead to a contradiction, or at least so we believe, just from the axioms and deductive rules of the theory), but is not ")#emph[#text("actually")]#text(" provable in this theory.")

#text("A fourth type of incompleteness, which is slightly less well known than the above three, is what I will call ")#emph[#text("elementary incompleteness")]#text(" (and which model theorists call the failure of the ")#emph[#text("countable saturation property")]#text("). It applies to any structure that is describable by a first-order language, such as a field, a metric space, or a universe of sets. For instance, in the language of ordered real fields, the real line ")#mi("{{\\bf R}}")#text(" is elementarily incomplete, because there exists a sequence of statements (such as the statements ")#mi("{0 < x < 1/n}")#text(" for natural numbers ")#mi("{n=1,2,\\ldots}")#text(") in this language which are ")#emph[#text("potentially")]#text(" simultaneously satisfiable (in the sense that any finite number of these statements can be satisfied by some real number ")#mi("{x}")#text(") but are not ")#emph[#text("actually")]#text(" simultaneously satisfiable in this theory.")

#text("In each of these cases, though, it is possible to start with an incomplete structure and ")#emph[#text("complete")]#text(" it to a much larger structure to eliminate the incompleteness. For instance, starting with an arbitrary field ")#mi("{k}")#text(", one can take its algebraic completion (or ")#link("http://en.wikipedia.org/wiki/Algebraic_closure")[#text("algebraic closure")]#text(") ")#mi("{\\overline{k}}")#text("; for instance, ")#mi("{{\\bf C} = \\overline{{\\bf R}}}")#text(" can be viewed as the algebraic completion of ")#mi("{{\\bf R}}")#text(". This field is usually significantly larger than the original field ")#mi("{k}")#text(", but contains ")#mi("{k}")#text(" as a subfield, and every element of ")#mi("{\\overline{k}}")#text(" can be described as the solution to some polynomial equation with coefficients in ")#mi("{k}")#text(". Furthermore, ")#mi("{\\overline{k}}")#text(" is now ")#link("http://en.wikipedia.org/wiki/Algebraically_closed_field")[#text("algebraically complete")]#text(" (or algebraically closed): every polynomial equation in ")#mi("{\\overline{k}}")#text(" which is potentially satisfiable (in the sense that it does not lead to a contradiction such as ")#mi("{1=0}")#text(" from the laws of algebra), is actually satisfiable in ")#mi("{\\overline{k}}")#text(".")

#text("Similarly, starting with an arbitrary metric space ")#mi("{X}")#text(", one can take its ")#link("http://en.wikipedia.org/wiki/Completion_(metric_space)")[#text("metric completion")]#text(" ")#mi("{\\overline{X}}")#text("; for instance, ")#mi("{{\\bf R} = \\overline{{\\bf Q}}}")#text(" can be viewed as the metric completion of ")#mi("{{\\bf Q}}")#text(". Again, the completion ")#mi("{\\overline{X}}")#text(" is usually much larger than the original metric space ")#mi("{X}")#text(", but contains ")#mi("{X}")#text(" as a subspace, and every element of ")#mi("{\\overline{X}}")#text(" can be described as the limit of some Cauchy sequence in ")#mi("{X}")#text(". Furthermore, ")#mi("{\\overline{X}}")#text(" is now a complete metric space: every sequence in ")#mi("{\\overline{X}}")#text(" which is potentially convergent (in the sense of being a Cauchy sequence), is now actually convegent in ")#mi("{\\overline{X}}")#text(".")

#text("In a similar vein, we have the ")#link("http://en.wikipedia.org/wiki/G%C3%B6del%27s_completeness_theorem")[#text("Gödel completeness theorem")]#text(", which implies (among other things) that for any consistent first-order theory ")#mi("{T}")#text(" for a first-order language ")#mi("{L}")#text(", there exists at least one ")#emph[#text("completion")]#text(" ")#mi("{\\overline{T}}")#text(" of that theory ")#mi("{T}")#text(", which is a consistent theory in which every sentence in ")#mi("{L}")#text(" which is potentially true in ")#mi("{\\overline{T}}")#text(" (because it does not lead to a contradiction in ")#mi("{\\overline{T}}")#text(") is actually true in ")#mi("{\\overline{T}}")#text(". Indeed, the completeness theorem provides at least one model (or ")#link("http://en.wikipedia.org/wiki/Structure_(mathematical_logic)")[#text("structure")]#text(") ")#mi("{{\\mathfrak U}}")#text(" of the consistent theory ")#mi("{T}")#text(", and then the completion ")#mi("{\\overline{T} = \\text{Th}({\\mathfrak U})}")#text(" can be formed by interpreting every sentence in ")#mi("{L}")#text(" using ")#mi("{{\\mathfrak U}}")#text(" to determine its truth value. Note, in contrast to the previous two examples, that the completion is usually not unique in any way; a theory ")#mi("{T}")#text(" can have multiple inequivalent models ")#mi("{{\\mathfrak U}}")#text(", giving rise to distinct completions of the same theory.")

#text("Finally, if one starts with an arbitrary structure ")#mi("{{\\mathfrak U}}")#text(", one can form an ")#emph[#text("elementary completion")]#text(" ")#mi("{{}^* {\\mathfrak U}}")#text(" of it, which is a significantly larger structure which contains ")#mi("{{\\mathfrak U}}")#text(" as a substructure, and such that every element of ")#mi("{{}^* {\\mathfrak U}}")#text(" is an elementary limit of a sequence of elements in ")#mi("{{\\mathfrak U}}")#text(" (I will define this term shortly). Furthermore, ")#mi("{{}^* {\\mathfrak U}}")#text(" is elementarily complete; any sequence of statements that are potentially simultaneously satisfiable in ")#mi("{{}^* {\\mathfrak U}}")#text(" (in the sense that any finite number of statements in this collection are simultaneously satisfiable), will actually be simultaneously satisfiable. As we shall see, one can form such an elementary completion by taking an ")#link("http://en.wikipedia.org/wiki/Ultraproduct")[#text("ultrapower")]#text(" of the original structure ")#mi("{{\\mathfrak U}}")#text(". If ")#mi("{{\\mathfrak U}}")#text(" is the ")#emph[#text("standard universe")]#text(" of all the ")#emph[#text("standard")]#text(" objects one considers in mathematics, then its elementary completion ")#mi("{{}^* {\\mathfrak U}}")#text(" is known as the ")#emph[#text("nonstandard universe")]#text(", and is the setting for ")#link("http://en.wikipedia.org/wiki/Nonstandard_analysis")[#text("nonstandard analysis")]#text(".")

#text("As mentioned earlier, completion tends to make a space much larger and more complicated. If one algebraically completes a finite field, for instance, one necessarily obtains an infinite field as a consequence. If one metrically completes a countable metric space with no isolated points, such as ")#mi("{{\\bf Q}}")#text(", then one necessarily obtains an uncountable metric space (thanks to the ")#link("http://en.wikipedia.org/wiki/Baire_category_theorem")[#text("Baire category theorem")]#text("). If one takes a logical completion of a consistent first-order theory that can model ")#link("http://en.wikipedia.org/wiki/True_arithmetic")[#text("true arithmetic")]#text(", then this completion is no longer describable by a recursively enumerable schema of axioms, thanks to ")#link("http://en.wikipedia.org/wiki/G%C3%B6del's_incompleteness_theorems")[#text("Gödel’s incompleteness theorem")]#text(". And if one takes the elementary completion of a countable structure, such as the integers ")#mi("{{\\bf Z}}")#text(", then the resulting completion ")#mi("{{}^* {\\bf Z}}")#text(" will necessarily be uncountable.")

#text("However, there are substantial benefits to working in the completed structure which can make it well worth the massive increase in size. For instance, by working in the algebraic completion of a field, one gains access to the full power of ")#link("http://en.wikipedia.org/wiki/Algebraic_geometry")[#text("algebraic geometry")]#text(". By working in the metric completion of a metric space, one gains access to powerful tools of real analysis, such as the ")#link("http://en.wikipedia.org/wiki/Baire_category_theorem")[#text("Baire category theorem")]#text(", the ")#link("http://en.wikipedia.org/wiki/Heine-Borel_theorem")[#text("Heine-Borel theorem")]#text(", and (in the case of Euclidean completions) the ")#link("http://en.wikipedia.org/wiki/Bolzano-Weierstrass_theorem")[#text("Bolzano-Weierstrass theorem")]#text(". By working in a logically and elementarily completed theory (aka a ")#emph[#text("saturated model")]#text(") of a first-order theory, one gains access to the branch of model theory known as ")#emph[#text("definability theory")]#text(", which allows one to analyse the structure of definable sets in much the same way that algebraic geometry allows one to analyse the structure of algebraic sets. Finally, when working in an elementary completion of a structure, one gains a ")#emph[#text("sequential compactness")]#text(" property, analogous to the Bolzano-Weierstrass theorem, which can be interpreted as the foundation for much of nonstandard analysis, as well as providing a unifying framework to describe various correspondence principles between finitary and infinitary mathematics.")

#text("In this post, I wish to expand upon these above points with regard to elementary completion, and to present nonstandard analysis as a completion of standard analysis in much the same way as, say, complex algebra is a completion of real algebra, or real metric geometry is a completion of rational metric geometry.")

#metadata(none) <tao-e6a602ca17b90362e1b1>

#heading(level: 1)[#strong[#text(" — 1. Elementary convergence — ")]]

#text("In order to understand the concept of a metric completion of a metric space ")#mi("{X = (X,d)}")#text(", one needs to know about the distinction between a Cauchy sequence and a convergent sequence. Similarly, to talk about the elementary completion of a structure ")#mi("{{\\mathfrak U}}")#text(", one needs the notion of an elementarily Cauchy sequence and an elementarily convergent sequence.")

#text("Let us set out some notation. We assume that we have some ")#link("http://en.wikipedia.org/wiki/First-order_logic")[#text("first-order language")]#text(" ")#mi("{L}")#text(", which allows one to form sentences involving the first-order logical symbols (")#mi("{\\forall}")#text(", ")#mi("{\\exists}")#text(", ")#mi("{\\vee}")#text(", ")#mi("{\\wedge}")#text(", ")#mi("{\\neg}")#text(", ")#mi("{\\implies}")#text(", etc.), variables of one or more types, the equality symbol ")#mi("{=}")#text(", some constant symbols, and some operations and relations. For instance:")

#list(
[#mi("{L}")#text(" could be the language of multiplicative groups, in which there is only one type of object (a group element), a constant symbol ")#mi("{e}")#text(", a binary operation ")#mi("{\\cdot}")#text(" from pairs of group elements to group elements, and a unary operation ")#mi("{()^{-1}}")#text(" from group elements to group elements.")],
[#mi("{L}")#text(" could be the language of real ordered fields, in which there is one type of object (a field element), constant symbols ")#mi("{0, 1}")#text(", binary operations ")#mi("{+, \\cdot}")#text(", and unary operations ")#mi("{-, ()^{-1}}")#text(" (with the latter only being defined for non-zero elements), and the order relation ")#mi("{<}")#text(".")],
[#mi("{L}")#text(" could be the language of (formal) metric spaces, in which there are two types of objects (points in the space, and real numbers), the constants, operations and relations of a real ordered field, and a metric operation ")#mi("{d}")#text(" from pairs of points in the space to real numbers.")],
[#mi("{L}")#text(" could be the language of sets, in which there is one type of object (a set) and one relation ")#mi("{\\in}")#text(".")],
[#text("etc., etc.")]
)

#text("We assume that the language has at most countably many types, constants, operations, and relations. In particular, there are at most countably many sentences in ")#mi("{L}")#text(".")

#text("A ")#link("http://en.wikipedia.org/wiki/Structure_(mathematical_logic)")[#text("structure")]#text(" ")#mi("{{\\mathfrak U}}")#text(" for a language ")#mi("{L}")#text(" is a way of interpreting each of the object classes in ")#mi("{L}")#text(" as a set, and each of the constants, operations, and relations as an elements, functions, and relations on those sets respectively. For instance, a structure for the language of groups would be a set ")#mi("{G}")#text(", together with a constant symbol ")#mi("{e \\in G}")#text(", a binary function ")#mi("{\\cdot: G \\times G \\rightarrow G}")#text(", and a unary operation ")#mi("{()^{-1}: G \\rightarrow G}")#text(". In particular, groups are structures for the language of groups, but so are many non-groups. Each structure ")#mi("{{\\mathfrak U}}")#text(" can be used to ")#emph[#text("interpret")]#text(" any given sentence ")#mi("{S}")#text(" in ")#mi("{L}")#text(", giving it a truth value of true or false. We write ")#mi("{{\\mathfrak U} \\models S}")#text(" if ")#mi("{S}")#text(" is interpreted to be true by ")#mi("{{\\mathfrak U}}")#text(". For instance, the axioms of a group can be expressed as a single sentence ")#mi("{A}")#text(", and a structure ")#mi("{{\\mathfrak U}}")#text(" for the language of groups is a group if and only if ")#mi("{{\\mathfrak U} \\models A}")#text(".")

#text("Now we introduce the notion of elementary convergence.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Elementary convergence)")]#text(" Let ")#mi("{{\\mathfrak U}}")#text(" be a structure for a language ")#mi("{L}")#text(", and let ")#mi("{x_1, x_2, \\ldots}")#text(" be a sequence of objects in ")#mi("{{\\mathfrak U}}")#text(" (all of the same type). Let ")#mi("{x}")#text(" be another object in ")#mi("{{\\mathfrak U}}")#text(" of the same type as the ")#mi("{x_n}")#text(".")

#list(
[#text("We say that the sequence ")#mi("{x_n}")#text(" is ")#emph[#text("elementarily Cauchy")]#text(" if, for every predicate ")#mi("{P(x)}")#text(" that takes one variable of the same type as the ")#mi("{x_n}")#text(" as input, the truth value of ")#mi("{P(x_n)}")#text(" becomes eventually constant (i.e. either ")#mi("{P(x_n)}")#text(" is true for all sufficiently large ")#mi("{n}")#text(", or ")#mi("{P(x_n)}")#text(" is false for all sufficiently large ")#mi("{n}")#text("). We write this eventual truth value as ")#mi("{\\lim_{n \\rightarrow \\infty} P(x_n)}")#text(".")],
[#text("We say that the sequence ")#mi("{x_n}")#text(" is ")#emph[#text("elementarily convergent")]#text(" to ")#mi("{x}")#text(" if we have ")#mi("{\\lim_{n \\rightarrow \\infty} P(x_n) = P(x)}")#text(" for every predicate ")#mi("{P(x)}")#text(" that takes one variable of the same type as the ")#mi("{x_n}")#text(" or ")#mi("{x}")#text(" as input.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" One can view the predicates ")#mi("{P}")#text(" (or more precisely, the sets ")#mi("{\\{ x \\in {\\mathfrak U}: P(x) \\text{ true}\\}}")#text(") as generating a topology on ")#mi("{{\\mathfrak U}}")#text(" (or more precisely, on the domain of one of the object types of ")#mi("{L}")#text(" in ")#mi("{{\\mathfrak U}}")#text("), in which case elementary convergence can be interpreted as convergence in this topology. Indeed, as there are only countably many predicates, this topology is metrisable.")
]

#text("To give an example, let us use the language of ordered fields ")#mi("{L}")#text(", with the model ")#mi("{{\\bf R}}")#text(", and pick a transcendental number ")#mi("{x}")#text(", e.g. ")#mi("{x = \\pi}")#text(". Then the sequence ")#mi("{x+\\frac{1}{n}}")#text(" is elementarily convergent to ")#mi("{x}")#text(". The reason for this is that the language ")#mi("{L}")#text(" is fairly limited in nature, and as such it can only define a fairly small number of sets; in particular, if ")#mi("{P}")#text(" is a predicate of one variable, then the ")#link("http://en.wikipedia.org/wiki/Tarski%E2%80%93Seidenberg_theorem")[#text("Tarski-Seidenberg theorem")]#text(" tells us that the set ")#mi("{\\{ y \\in {\\bf R}: P(y) \\text{ true} \\}}")#text(" cut out by that set has to be a ")#link("http://en.wikipedia.org/wiki/Semialgebraic_set")[#text("semi-algebraic set")]#text(" over the algebraic reals, i.e. a finite union of (possibly unbounded) intervals (which can be open, closed, or half-open) whose endpoints are algebraic reals. In particular, a transcendental number ")#mi("{x}")#text(", if it lies in such a set, lies in the interior of such a set, and so ")#mi("{x+\\frac{1}{n}}")#text(" will also lie in such a set for ")#mi("{n}")#text(" large enough, and similarly if ")#mi("{x}")#text(" lies outside such a set.")

#text("In contrast, if one picks an algebraic number for ")#mi("{x}")#text(", such as ")#mi("{x = \\sqrt{2}}")#text(", then ")#mi("{x+\\frac{1}{n}}")#text(" does ")#emph[#text("not")]#text(" converge in an elementary sense to ")#mi("{x}")#text(", because one can find a predicate such as ")#mi("{P(y) := (y^2=2)}")#text(" which is true for ")#mi("{x}")#text(" but not true for any of the ")#mi("{x+\\frac{1}{n}}")#text(". So the language ")#mi("{L}")#text(" has sufficiently “poor vision” that it cannot easily distinguish a transcendental number such as ")#mi("{\\pi}")#text(" from nearby numbers such as ")#mi("{\\pi + \\frac{1}{n}}")#text(", but its vision is significantly better at algebraic numbers, and in particular can distinguish ")#mi("{\\sqrt{2}}")#text(" from ")#mi("{\\sqrt{2}+\\frac{1}{n}}")#text(" easily. So we see that elementary convergence is, in this case, a slightly stronger concept than the usual topological or metric notion of convergence on ")#mi("{{\\bf R}}")#text(".")

#text("In the case of the real model ")#mi("{{\\bf R}}")#text(" of ordered fields, elementary limits are unique, but this is not the case in general. For instance, in the language of fields, and using the complex model ")#mi("{{\\bf C}}")#text(", any given complex number ")#mi("{z}")#text(" is elementarily indistinguishable from its complex conjugate ")#mi("{\\overline{z}}")#text(", and so any sequence ")#mi("{z_n}")#text(" of complex numbers that would converge elementarily to ")#mi("{z}")#text(", would also converge elementarily to ")#mi("{\\overline{z}}")#text(". (In fact, there is an enormous Galois group ")#mi("{\\text{Gal}({\\bf C}/\\overline{{\\bf Q}})}")#text(", the action of which is completely undetectable with regards to elementary convergence.)")

#text("A related problem is that the operations on a structure ")#mi("{{\\mathfrak U}}")#text(" are not necessarily continuous with respect to these elementary limits. For instance, if ")#mi("{x_n, y_n}")#text(" are sequences of real numbers that converge elementarily to ")#mi("{x, y}")#text(" respectively, it is not necessarily the case that ")#mi("{x_n+y_n}")#text(" converge to ")#mi("{x+y}")#text(" (consider for instance the case when ")#mi("{x_n = \\pi+1/n}")#text(" and ")#mi("{y_n = -\\pi+1/n}")#text(").")

#text("One way to partially resolve these problem is to consider the convergence not just of sequences of individual objects ")#mi("{x_n}")#text(", but of sequences of families ")#mi("{(x_{n,\\alpha})_{\\alpha \\in A}}")#text(" of objects:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2 (Joint elementary convergence)")]#text(" Let ")#mi("{{\\mathfrak U}}")#text(" be a structure a language ")#mi("{L}")#text(", let ")#mi("{A}")#text(" be a set, and for each natural number ")#mi("{n}")#text(", let ")#mi("{(x_{n,\\alpha})_{\\alpha \\in A}}")#text(" be a tuple of of elements in ")#mi("{{\\mathfrak U}}")#text(", and let ")#mi("{(x_\\alpha)_{\\alpha \\in A}}")#text(" be another tuple in ")#mi("{{\\mathfrak U}}")#text(", with each ")#mi("{x_{n,\\alpha}}")#text(" having the same type as ")#mi("{x_\\alpha}")#text(".")

#list(
[#text("We say that the tuples ")#mi("{(x_{n,\\alpha})_{\\alpha \\in A}}")#text(" are ")#emph[#text("jointly elementarily Cauchy")]#text(" if, for every natural number ")#mi("{m}")#text(", every predicate ")#mi("{P(y_1,\\ldots,y_m)}")#text(" of ")#mi("{m}")#text(" variables in ")#mi("{L}")#text(" of the appropriate type, and every ")#mi("{\\alpha_1,\\ldots,\\alpha_m \\in A}")#text(", the truth value of ")#mi("{P(x_{n,\\alpha_1},\\ldots,x_{n,\\alpha_m})}")#text(" is eventually constant.")],
[#text("We say that the tuples ")#mi("{(x_{n,\\alpha})_{\\alpha \\in A}}")#text(" are ")#emph[#text("jointly elementarily convergent")]#text(" to ")#mi("{(x_\\alpha)_{\\alpha \\in A}}")#text(" if, for every natural number ")#mi("{m}")#text(", every predicate ")#mi("{P(y_1,\\ldots,y_m)}")#text(" of ")#mi("{m}")#text(" variables in ")#mi("{L}")#text(" of the appropriate type, and every ")#mi("{\\alpha_1,\\ldots,\\alpha_m \\in A}")#text(", the truth value of ")#mi("{P(x_{n,\\alpha_1},\\ldots,x_{n,\\alpha_m})}")#text(" converges to the truth value of ")#mi("{P(x_{\\alpha_1},\\ldots,x_{\\alpha_m})}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".")]
)
]

#text("For instance, using the complex model ")#mi("{{\\bf C}}")#text(" of the language of fields, if ")#mi("{z_n}")#text(" converges elementarily to (say) ")#mi("{i}")#text(", then we cannot prevent ")#mi("{z_n}")#text(" from also converging elementarily to ")#mi("{-i}")#text(". (Indeed, it is not hard to see that ")#mi("{z_n}")#text(" converges elementarily to ")#mi("{i}")#text(" if and only ")#mi("{z_n \\in\\{-i,+i\\}}")#text(" for all sufficiently large ")#mi("{n}")#text(".) But if we ask that ")#mi("{(z_n,i)}")#text(" jointly converges to ")#mi("{(i,i)}")#text(", then ")#mi("{(z_n,i)}")#text(" will not also jointly converge to ")#mi("{(-i,i)}")#text(" (though it does jointly converge to ")#mi("{(-i,-i)}")#text(").")

#text("In a similar fashion, if ")#mi("{x_n,y_n}")#text(" are reals that converge ")#emph[#text("jointly")]#text(" elementarily to ")#mi("{x,y}")#text(", then ")#mi("{x_n+y_n}")#text(" will converge elemntarily to ")#mi("{x+y}")#text(" also.")

#text("Now we give a more sophisticated example. Here, ")#mi("{L}")#text(" is the language of set theory, and ")#mi("{{\\mathfrak U}}")#text(" is a model of ZFC. In ZFC set theory, we can of course construct most of the objects we are used to in modern mathematics, such as a copy ")#mi("{{\\bf R}_{\\mathfrak U}}")#text(" of the real line, a copy ")#mi("{{\\bf N}_{\\mathfrak U}}")#text(" of the natural numbers, and so forth. Note that ")#mi("{{\\mathfrak U}}")#text("‘s interpretation ")#mi("{{\\bf N}_{\\mathfrak U}}")#text(" of the natural numbers may be different from the “true” natural numbers ")#mi("{{\\bf N}}")#text("; in particular, in non-standard models of set theory, ")#mi("{{\\bf N}_{\\mathfrak U}}")#text(" may be much larger than ")#mi("{{\\bf N}}")#text(" (e.g. it may be an ultrapower ")#mi("{{}^* {\\bf N}}")#text(" of ")#mi("{{\\bf N}}")#text("). Because of this, we will be careful to subscript ")#mi("{{\\mathfrak U}}")#text("‘s copies of such objects in order to distinguish them from their true counterparts, though it will not make much difference for this immediate example.")

#text("We can also define in ")#mi("{{\\mathfrak U}}")#text(" all the formal apparatus needed for probability theory, such as a probability space ")#mi("{(\\Omega,{\\mathcal B},{\\bf P})}")#text(" and a real-valued random variable ")#mi("{X: \\Omega \\rightarrow {\\bf R}_{\\mathfrak U}}")#text(" on that space.")

#text("Now suppose that inside ")#mi("{{\\mathfrak U}}")#text(" we have a sequence ")#mi("{(\\Omega_n,{\\mathcal B}_n,{\\bf P}_n)}")#text(" of probability spaces, and a sequence ")#mi("{X_n: \\Omega_n \\rightarrow {\\bf R}_{\\mathfrak U}}")#text(" of random variables on these probability spaces. Now suppose the quintuple ")#mi("{(\\Omega_n,{\\mathcal B}_n,{\\bf P}_n,X_n,{\\bf R}_{\\mathfrak U})}")#text(" is jointly elementarily convergent to a limit ")#mi("{(\\Omega, {\\mathcal B}, {\\bf P}, X,{\\bf R}_{\\mathfrak U})}")#text(". The axioms of being a probability space can be encoded inside the first order language of set theory, so the limit ")#mi("{(\\Omega, {\\mathcal B}, {\\bf P})}")#text(" is also a probability space (as viewed inside ")#mi("{{\\mathfrak U}}")#text("). Similarly, ")#mi("{X: \\Omega \\rightarrow {\\bf R}_{\\mathfrak U}}")#text(" is a random variable on this probability space.")

#text("Now let ")#mi("{q, r}")#text(" be rational numbers. If ")#mi("{{\\bf P}(X > q) > r}")#text(", then by the definition of elementary convergence (and the fact that rational numbers can be defined using an expression of finite length in the language ")#mi("{L}")#text("), we see that ")#mi("{{\\bf P}_n(X_n > q) > r}")#text(" holds for all sufficiently large ")#mi("{n}")#text(". From this, one can deduce that the ")#mi("{X_n}")#text(" ")#link("http://en.wikipedia.org/wiki/Convergence_of_random_variables")[#text("converge in distribution")]#text(" to ")#mi("{X}")#text(". Thus we see that in this case, joint elementary convergence is at least as strong as convergence in distribution, though (much as with the example with elementary convergence in ")#mi("{{\\bf R}}")#text(" using the language of ordered fields) the two notions of convergence are not equivalent.")

#text("We included ")#mi("{{\\bf R}_{\\mathfrak U}}")#text(" in the quintuple due to the use of real numbers such as ")#mi("{{\\bf P}(X > q)}")#text(" in the above discussion, but it is not strictly necessary, because one can construct ")#mi("{{\\bf R}_{\\mathfrak U}}")#text(" uniquely in ")#mi("{{\\mathfrak U}}")#text(" from the axioms of set theory by using one of the standard constructions of the real numbers. But note that while we may use the set ")#mi("{{\\bf R}_{\\mathfrak U}}")#text(" of real numbers in the above elementary convergence, one cannot invoke specific real numbers unless they are “constructible” in the sense that they can be uniquely specified in the language ")#mi("{L}")#text(". If one wished to be able to use arbitrary real numbers as constants, one would not only place ")#mi("{{\\bf R}_{\\mathfrak U}}")#text(" into the quintuple, but also place in every element ")#mi("{x}")#text(" of ")#mi("{{\\bf R}_{\\mathfrak U}}")#text(" into the tuple (thus making the tuple quite large, and most likely uncountable, though note from ")#link("http://en.wikipedia.org/wiki/Skolem's_paradox")[#text("Skolem’s paradox")]#text(" that it is possible for ")#mi("{{\\bf R}_{\\mathfrak U}}")#text(" to be (externally) countable even as it is uncountable from the internal perspective of ")#mi("{{\\mathfrak U}}")#text(").")

#text("As we see from the above discussion, joint elementary convergence is a useful notion even when some of the elements in the tuple are constant. We isolate this case with another definition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3 (Joint relative elementary convergence)")]#text(" Let ")#mi("{{\\mathfrak U}}")#text(" be a structure for a language ")#mi("{L}")#text(", let ")#mi("{A,B}")#text(" be sets, and for each natural number ")#mi("{n}")#text(", let ")#mi("{(x_{n,\\alpha})_{\\alpha \\in A}}")#text(" be a tuple of of elements in ")#mi("{{\\mathfrak U}}")#text(", and let ")#mi("{(x_\\alpha)_{\\alpha \\in A}}")#text(" and ")#mi("{(c_\\beta)_{\\beta \\in B}}")#text(" be further tuples in ")#mi("{{\\mathfrak U}}")#text(". We say that the tuples ")#mi("{(x_{n,\\alpha})_{\\alpha \\in A}}")#text(" are ")#emph[#text("jointly elementarily convergent")]#text(" to ")#mi("{(x_\\alpha)_{\\alpha \\in A}}")#text(" ")#emph[#text("relative to the constants")]#text(" ")#mi("{(c_\\beta)_{\\beta \\in B}}")#text(" if the disjoint union ")#mi("{(x_{n,\\alpha})_{\\alpha \\in A} \\uplus (c_\\beta)_{\\beta \\in B}}")#text(" is jointly elementarily convergent to ")#mi("{(x_{\\alpha})_{\\alpha \\in A} \\uplus (c_\\beta)_{\\beta \\in B}}")#text(".")

#text("We define the notion of ")#mi("{(x_{n,\\alpha})_{\\alpha \\in A}}")#text(" are ")#emph[#text("jointly elementarily Cauchy relative to the constants")]#text(" ")#mi("{(c_\\beta)_{\\beta \\in B}}")#text(" similarly.")
]

#text("Informally, if ")#mi("{(x_{n,\\alpha})_{\\alpha \\in A}}")#text(" is jointly elementarily convergent to ")#mi("{(x_\\alpha)_{\\alpha \\in A}}")#text(" relative to ")#mi("{(c_\\beta)_{\\beta \\in B}}")#text(" if the language ")#mi("{L}")#text(" is unable to asymptotically distinguish the ")#mi("{x_{n,\\alpha}}")#text(" from the ")#mi("{x_\\alpha}")#text(", even if it “knows” about the constants ")#mi("{c_\\beta}")#text(".")

#heading(level: 1)[#strong[#text(" — 2. Elementary completion — ")]]

#text("Not every sequence in a structure is elementarily Cauchy or elementarily convergent. However, we have the following simple fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4 (Arzelá-Ascoli)")]#text(" ")#metadata(none) <tao-8760d12e729567e54d6e>#text(" Let ")#mi("{{\\mathfrak U}}")#text(" be a structure for a language ")#mi("{L}")#text(", and let ")#mi("{x_n}")#text(" be a sequence of elements in ")#mi("{{\\mathfrak U}}")#text(" (all of the same type). Then there is a subsequence of the ")#mi("{x_n}")#text(" that is elementarily Cauchy.")
]

#emph[#text("Proof:")]#text(" There are at most countably many predicates ")#mi("{P_1(x), P_2(x), \\ldots}")#text(" of a single variable of the right type in ")#mi("{L}")#text(". By the infinite pigeonhole principle, we can find a subsequence ")#mi("{x_{n_{1,1}}, x_{n_{1,2}}, \\ldots}")#text(" of the ")#mi("{x_n}")#text(" such that ")#mi("{P_1(x_{n_{1,i}})}")#text(" is eventually constant. We can find a further subsequence ")#mi("{x_{n_{2,1}}, x_{n_{2,2}}, \\ldots}")#text(" of that sequence for which ")#mi("{P_2(x_{n_{2,i}})}")#text(" is eventually constant. We continue extracting subsequences ")#mi("{x_{n_{k,1}},x_{n_{k,2}},\\ldots}")#text(" of this nature for each ")#mi("{k=1,2,\\ldots}")#text(", and then the diagonal sequence ")#mi("{k \\mapsto x_{n_{k,k}}}")#text(" is elementarily Cauchy, as desired. ")#mi("\\Box")

#text("The same argument works when considering countably many variables and countably many constants (as there are still only countably many predicates to deal with):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5 (Arzelá-Ascoli)")]#text(" Let ")#mi("{{\\mathfrak U}}")#text(" be a structure for a language ")#mi("{L}")#text(", let ")#mi("{A, B}")#text(" be at most countable sets, and for each natural number ")#mi("{n}")#text(", let ")#mi("{(x_{n,\\alpha})_{\\alpha \\in A}}")#text(" be a tuple of of elements in ")#mi("{{\\mathfrak U}}")#text(", and let ")#mi("{(c_\\beta)_{\\beta \\in B}}")#text(" be another tuple in ")#mi("{{\\mathfrak U}}")#text(". Then there is a subsequence ")#mi("{(x_{n_j,\\alpha})_{\\alpha \\in A}}")#text(" which is jointly elementarily Cauchy relative to ")#mi("{(c_\\beta)_{\\beta \\in B}}")#text(".")
]

#text("As in the metric case, not every elementarily Cauchy sequence is elementarily convergent, and not every sequence has an elementarily convergent subsequence. For instance, in the language of ordered fields, using the structure ")#mi("{{\\bf R}}")#text(", the sequence ")#mi("{\\frac{1}{n}}")#text(" has no elementarily convergent subsequence (because any limit of such a subsequence would be positive but also less than ")#mi("{1/n}")#text(" for arbitrarily large ")#mi("{n}")#text(", contradicting the ")#link("http://en.wikipedia.org/wiki/Archimedean_property")[#text("Archimedean property")]#text(" of the reals). From Proposition ")#link(<tao-8760d12e729567e54d6e>)[#text("4")]#text(", we conclude that the reals are elementarily incomplete; there must exist some subsequence of ")#mi("{1/n}")#text(" that is elementarily Cauchy, but not elementarily convergent.")

#text("However, we can always complete any structure ")#mi("{{\\mathfrak U}}")#text(" by passing to the ")#link("http://en.wikipedia.org/wiki/Ultraproduct")[#text("ultrapower")]#text(" ")#mi("{{}^* {\\mathfrak U}}")#text(". This concept has been discussed in previous blog posts, so we give only a quick review here.")

#text("For the rest of this post, we fix a single ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("non-principal ultrafilter")]#text(" ")#mi("{\\alpha_\\infty \\in \\beta {\\bf N} \\backslash {\\bf N}}")#text(" on the (standard) natural numbers ")#mi("{{\\bf N}}")#text(". (See this ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("previous blog post")]#text(" for some basic discussion of what non-principal ultrafilters are, and how they are used in non-standard analysis.) A property ")#mi("{P(\\alpha)}")#text(" of a natural number ")#mi("{\\alpha}")#text(" is said to hold ")#emph[#text("for all ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")]#text(" if the set of ")#mi("{\\alpha}")#text(" for which ")#mi("{P(\\alpha)}")#text(" holds lies in the ultrafilter ")#mi("{\\alpha_\\infty}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 6 (Ultrapower)")]#text(" Let ")#mi("{{\\mathfrak U}}")#text(" be a structure for some language ")#mi("{L}")#text(". Given two sequences ")#mi("{(x_\\alpha)_{\\alpha \\in {\\bf N}}}")#text(" and ")#mi("{(y_\\alpha)_{\\alpha \\in {\\bf N}}}")#text(" of objects in ")#mi("{{\\mathfrak U}}")#text(", we say that the sequences are ")#emph[#text("equivalent")]#text(" if one has ")#mi("{x_\\alpha = y_\\alpha}")#text(" for all ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text(". The equivalence class associated to a given sequence ")#mi("{(x_\\alpha)_{\\alpha \\in {\\bf N}}}")#text(" will be called the ")#emph[#text("ultralimit")]#text(" of the ")#mi("{x_\\alpha}")#text(" and denoted ")#mi("{\\lim_{\\alpha \\rightarrow \\alpha_\\infty} x_\\alpha}")#text(". The ")#emph[#text("ultrapower")]#text(" ")#mi("{{}^* {\\mathfrak U}}")#text(" of ")#mi("{{\\mathfrak U}}")#text(" is the collection of all ultralimits ")#mi("{\\lim_{\\alpha \\rightarrow \\alpha_\\infty} x_\\alpha}")#text(" of sequences of objects in ")#mi("{{\\mathfrak U}}")#text(". By identifying ")#mi("{{}^* x := \\lim_{\\alpha \\rightarrow \\alpha_\\infty} x}")#text(" with ")#mi("{x}")#text(" for every object ")#mi("{x}")#text(" in ")#mi("{{\\mathfrak U}}")#text(", we see that every object in ")#mi("{{\\mathfrak U}}")#text(" can be identified with an object in ")#mi("{{}^* {\\mathfrak U}}")#text(". We refer to elements of ")#mi("{{\\mathfrak U}}")#text(" as ")#emph[#text("standard objects")]#text(", and elements of ")#mi("{{}^* {\\mathfrak U}}")#text(" as ")#emph[#text("non-standard objects")]#text(".")

#text("Every relation and operation in ")#mi("{{\\mathfrak U}}")#text(" can be extended to ")#mi("{{}^* {\\mathfrak U}}")#text(" by taking ultralimits. For instance, given a ")#mi("{k}")#text("-ary relation ")#mi("{R(y_1,\\ldots,y_k)}")#text(", and non-standard objects ")#mi("{x_i = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} x_{i,\\alpha}}")#text(" for ")#mi("{i=1,\\ldots,k}")#text(", we say that ")#mi("{R(x_1,\\ldots,x_k)}")#text(" holds in ")#mi("{{}^* {\\mathfrak U}}")#text(" if and only if ")#mi("{R(x_{1,\\alpha},\\ldots,x_{k,\\alpha})}")#text(" holds in ")#mi("{{\\mathfrak U}}")#text(" for all ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text(". Similarly, given a ")#mi("{k}")#text("-ary operation ")#mi("{f(y_1,\\ldots,y_k)}")#text(" and non-standard objects ")#mi("{x_i = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} x_{i,\\alpha}}")#text(", we define the non-standard object ")#mi("{f(x_1,\\ldots,x_k)}")#text(" to be the ultralimit ")#mi("{\\lim_{\\alpha \\rightarrow \\alpha_\\infty} f(x_{1,\\alpha},\\ldots,x_{k,\\alpha})}")#text(" of the standard objects ")#mi("{f(x_{1,\\alpha},\\ldots,x_{k,\\alpha})}")#text(".")
]

#text("Ultrapowers are also discussed in more detail in ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("this previous blog post")]#text(". A fundamental ")#link("http://en.wikipedia.org/wiki/Ultraproduct#.C5.81o.C5.9B.27s_theorem")[#text("theorem of Los asserts")]#text(" that the ultrapower ")#mi("{{}^* {\\mathfrak U}}")#text(" is ")#link("http://en.wikipedia.org/wiki/Elementary_equivalence")[#text("elementarily equivalent")]#text(" to ")#mi("{{\\mathfrak U}}")#text(": any sentence in ")#mi("{L}")#text(" which is true in ")#mi("{{\\mathfrak U}}")#text(", is also true in ")#mi("{{}^* {\\mathfrak U}}")#text(", and vice versa; this fact is also known as the ")#link("http://en.wikipedia.org/wiki/Transfer_principle")[#text("transfer principle")]#text(" for nonstandard analysis. For instance, the ultrapower of an ordered field is an ordered field, the ultrapower of an algebraically closed field is an algebraically closed field, and so forth. One must be slightly careful, though, with models ")#mi("{{\\mathfrak U}}")#text(" that involve standard objects such as a copy ")#mi("{{\\mathfrak U}}")#text(" of the natural numbers, or a copy ")#mi("{{\\bf R}_{\\mathfrak U}}")#text(" of the real numbers; the ultrapower ")#mi("{{}^* {\\mathfrak U}}")#text(" will have their own non-standard copy ")#mi("{{\\bf N}_{{}^* {\\mathfrak U}} = {}^* {\\bf N}_{\\mathfrak U}}")#text(" and ")#mi("{{\\bf R}_{{}^* {\\mathfrak U}} = {}^* {\\bf R}_{\\mathfrak U}}")#text(" of these objects, which are considerably larger than their standard counterparts, in the sense that they contain many more elements. Thus, for instance, if one is taking the ultrapower of a standard probability space ")#mi("{(\\Omega, {\\mathcal B}, {\\bf P})}")#text(", in which the probability measure ")#mi("{{\\bf P}: {\\mathcal B} \\rightarrow {\\bf R}}")#text(" takes values in the standard reals, the ultrapower ")#mi("{({}^* \\Omega, {}^* {\\mathcal B}, {}^* {\\bf P})}")#text(" is a non-standard probability space, in which the non-standard probability measure ")#mi("{{}^* {\\bf P}: {}^* {\\mathcal B} \\rightarrow {}^* {\\bf R}}")#text(" now takes values in the non-standard reals.")

#text("One can view the ultrapower ")#mi("{{}^* {\\mathfrak U}}")#text(" as the completion of ")#mi("{{\\mathfrak U}}")#text(", in much the same way as the reals are a completion of the rationals:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Elementary completeness)")]#text(" ")#metadata(none) <tao-b5cef039ed574d1d1609>#text(" Every elementarily Cauchy sequence ")#mi("{x_n}")#text(" in an ultrapower ")#mi("{{}^* {\\mathfrak U}}")#text(" is elementarily convergent.")
]

#text("This property is also known as ")#link("http://en.wikipedia.org/wiki/Saturated_model")[#text("countable saturation")]#text(".")

#emph[#text("Proof:")]#text(" We can write ")#mi("{x_n = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} x_{n,\\alpha}}")#text(" for each natural number ")#mi("{n \\in {\\bf N}}")#text(" and a sequence ")#mi("{x_{n,\\alpha}}")#text(" of standard objects in ")#mi("{{\\mathfrak U}}")#text(". As before, we enumerate the predicates ")#mi("{P_1,P_2,P_3,\\ldots}")#text(" of one variable. For each natural number ")#mi("{m \\in {\\bf N}}")#text(", the truth value of ")#mi("{P_m(x_n)}")#text(" becomes eventually constant; we will call this constant ")#mi("{\\lim_{n \\rightarrow \\infty} P_m(x_n)}")#text(".")

#text("Now let ")#mi("{M}")#text(" be a standard natural number. By construction, there exists an ")#mi("{n_M}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("P_m(x_{n_M}) = \\lim_{n \\rightarrow \\infty} P_m(x_n)")]]

#text("for all ")#mi("{1 \\leq m \\leq M}")#text(". As ")#mi("{x_{n_M}}")#text(" is the ultralimit of the ")#mi("{x_{n_M,\\alpha}}")#text(", there thus exists a set ")#mi("{E_M \\in p}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("P_m(x_{n_M,\\alpha}) = \\lim_{n \\rightarrow \\infty} P_m(x_n)")]]

#text("for all ")#mi("{\\alpha \\in E_M}")#text(". By replacing each ")#mi("{E_M}")#text(" with ")#mi("{\\bigcap_{M^{\\prime} \\leq M} E_{M^{\\prime}}}")#text(" if necessary, we may assume that the ")#mi("{E_M}")#text(" are decreasing: ")#mi("{E_1 \\supset E_2 \\supset \\ldots}")#text(".")

#text("For each ")#mi("{\\alpha \\in {\\bf N}}")#text(", let ")#mi("{M_\\alpha}")#text(" be the largest integer in ")#mi("{\\{0,\\ldots,\\alpha\\}}")#text(" such that ")#mi("{\\alpha \\in E_{M_\\alpha}}")#text(", or ")#mi("{M_\\alpha=0}")#text(" if no such integer exists. By construction, we see that for any ")#mi("{m \\in {\\bf N}}")#text(", we haved")

#align(center)[#tao-fit-display[#mitex("P_m(x_{n_{M_\\alpha}, \\alpha}) = \\lim_{n \\rightarrow \\infty} P_m(x_n)")]]

#text("whenever ")#mi("{\\alpha \\in E_m}")#text(" and ")#mi("{\\alpha \\geq m}")#text(". If we then set ")#mi("{x}")#text(" to be the non-standard object ")#mi("{x := \\lim_{\\alpha \\rightarrow \\alpha_\\infty} x_{n_{M_\\alpha},\\alpha}}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("P_m(x) = \\lim_{n \\rightarrow \\infty} P_m(x_n)")]]

#text("for each ")#mi("{m \\in {\\bf N}}")#text(", and thus ")#mi("{x_n}")#text(" converges elementarily to ")#mi("{x}")#text(" as required. ")#mi("\\Box")

#text("Combining this theorem with Proposition ")#link(<tao-8760d12e729567e54d6e>)[#text("4")]#text(" we conclude an analogue of the Bolzano-Weierstrass theorem for ultrapowers:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 8 (Bolzano-Weierstrass for ultrapowers)")]#text(" In an ultrapower ")#mi("{{}^* {\\mathfrak U}}")#text(", every sequence ")#mi("{x_n}")#text(" of non-standard objects in ")#mi("{{}^* {\\mathfrak U}}")#text(" has an elementarily convergent subsequence ")#mi("{x_{n_j}}")#text(".")
]

#text("The same argument works (but with more complicated notation) for countable families of objects, and with countably many constants:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9 (Bolzano-Weierstrass for ultrapowers, II)")]#text(" Let ")#mi("{{}^* {\\mathfrak U}}")#text(" be an ultrapower, let ")#mi("{A, B}")#text(" be at most countable, let ")#mi("{n \\mapsto (x_{n,\\alpha})_{\\alpha \\in A}}")#text(" be a sequence of tuples of nonstandard objects in ")#mi("{{}^* {\\mathfrak U}}")#text(", and let ")#mi("{(c_\\beta)_{\\beta \\in B}}")#text(" be another sequence of tuples of nonstandard objects. Then there is a subsequence ")#mi("{(x_{n_j,\\alpha})_{\\alpha \\in A}}")#text(" which converges jointly elementarily to a limit ")#mi("{(x_\\alpha)_{\\alpha \\in A}}")#text(" relative to the constants ")#mi("{(c_\\beta)_{\\beta \\in B}}")#text(".")
]

#text("The proof of this theorem proceeds almost exactly as in the single variable case, the key point being that the number of predicates that one has to stabilise remains countable.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" If one took the ultrafilter ")#mi("{\\alpha_\\infty}")#text(" over a larger set than the natural numbers ")#mi("{{\\bf N}}")#text(", then one could make the sets ")#mi("{A, B}")#text(" larger as well. Such larger saturation properties, beyond countable saturation, are useful in model theory (particularly when combined with the use of large cardinals, such as inaccessible cardinals), but we will not need them here.")
]

#text("Conversely, every nonstandard object can be viewed as the elementary limit of standard objects:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 10")]#text(" ")#metadata(none) <tao-d0d9d67e7044779c37a2>#text(" Let ")#mi("{x \\in {}^* {\\mathfrak U}}")#text(" be a nonstandard object. Then there is a sequence ")#mi("{x_n \\in {\\mathfrak U}}")#text(" of standard objects that converges elementarily to ")#mi("{x}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{P_1,P_2,\\ldots}")#text(" be an enumeration of the predicates of one variable. For any natural number ")#mi("{n}")#text(", there exists a nonstandard object ")#mi("{y \\in {}^* {\\mathfrak U}}")#text(" such that ")#mi("{P_i(y)}")#text(" has the same truth value as ")#mi("{P_i(x)}")#text(" for all ")#mi("{i=1,\\ldots,n}")#text(", namely ")#mi("{y=x}")#text(". By transfer, there must therefore exist a standard object ")#mi("{x_n \\in {\\mathfrak U}}")#text(" such that ")#mi("{P_i(x_n)}")#text(" has the same truth value as ")#mi("{P_i(x)}")#text(". Thus ")#mi("{x_n}")#text(" converges elementarily to ")#mi("{x}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" If ")#mi("{x}")#text(" is the ultralimit of a sequence ")#mi("{x_n}")#text(" of standard objects, show that there is a subsequence ")#mi("{x_{n_j}}")#text(" that converges elementarily to ")#mi("{x}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2 (Heine-Borel theorem for structures)")]#text(" Given any structure ")#mi("{{\\mathfrak U}}")#text(", show that the following four statements are equivalent:")

#list(
[#text("(Countable saturation) If ")#mi("{P_1(x), P_2(x),\\ldots}")#text(" are a countable family of predicates, such that if any finite number of ")#mi("{P_i}")#text(" are simultaneously satisfiable in ")#mi("{{\\mathfrak U}}")#text(" (i.e. for each ")#mi("{n}")#text(" there exists ")#mi("{x_n \\in {\\mathfrak U}}")#text(" such that ")#mi("{P_i(x_n)}")#text(" holds for all ")#mi("{i=1,\\ldots,n}")#text("), then the entire family of ")#mi("{P_i}")#text(" are simultaneously satisfiable (i.e. there exists ")#mi("{x \\in {\\mathfrak U}}")#text(" such that ")#mi("{P_i(x)}")#text(" holds for all ")#mi("{i}")#text(").")],
[#text("(Countable compactness) Every countable cover of ")#mi("{{\\mathfrak U}}")#text(" by sets of the form ")#mi("{\\{ x \\in {\\mathfrak U}: P(x) \\text{ true}\\}}")#text(" for some predicate ")#mi("{P}")#text(", has a finite subcover.")],
[#text("(Elementary completeness) Every elementarily Cauchy sequence in ")#mi("{{\\mathfrak U}}")#text(" has an elementarily convergent subsequence.")],
[#text("(Bolzano-Weierstrass property) Every elementary sequence in ")#mi("{{\\mathfrak U}}")#text(" has an elementarily convergent subsequence.")]
)
]

#text("From Proposition ")#link(<tao-d0d9d67e7044779c37a2>)[#text("10")]#text(" and Theorem ")#link(<tao-b5cef039ed574d1d1609>)[#text("7")]#text(" we see that ")#mi("{{}^* {\\mathfrak U}}")#text(" can be viewed as an elementary completion of ")#mi("{{\\mathfrak U}}")#text(", though the analogy with metric completion is not perfect because elementary limits are not unique.")

#text("The Bolzano-Weierstrass theorem for ultrapowers can then be used to derive the foundational properties of nonstandard analysis. For instance, consider the standard natural numbers ")#mi("{1, 2, 3, \\ldots}")#text(" in ")#mi("{{\\bf N}}")#text(", and hence in ")#mi("{{}^* {\\bf N}}")#text(". Applying the Bolzano-Weierstrass theorem for ultraproducts, we conclude that some subsequence ")#mi("{n_j}")#text(" of natural numbers will converge elementarily to a non-standard natural number ")#mi("{N \\in {}^* {\\bf N}}")#text(". For any standard natural number ")#mi("{m \\in {\\bf N}}")#text(", we have ")#mi("{n_j > m}")#text(" for all sufficiently large ")#mi("{j}")#text(", and hence on taking elementary limits we have ")#mi("{N > m}")#text(" (since ")#mi("{m}")#text(" is constructible). Thus we have constructed an ")#emph[#text("unbounded")]#text(" nonstandard natural number, i.e. a number which is larger than all standard natural numbers.")

#text("In a similar spirit, we can also use the Bolzano-Weierstrass theorem construct ")#emph[#text("infinitesimal")]#text(" nonstandard real numbers ")#mi("{0 < \\epsilon = o(1)}")#text(" which are positive, but less than every standard positive real number (and in particular less than ")#mi("{1/n}")#text(" for any standard ")#mi("{n}")#text(").")

#text("More generally, we have the ")#link("http://en.wikipedia.org/wiki/Overspill")[#text("overspill principle")]#text(": if ")#mi("{P(n,c_1,\\ldots,c_k)}")#text(" is a predicate involving some non-standard constants ")#mi("{c_1,\\ldots,c_k}")#text(", such that ")#mi("{P(n,c_1,\\ldots,c_k)}")#text(" is true for arbitrarily large standard natural numbers ")#mi("{n \\in {\\bf N}}")#text(", then it must also be true for at least one unbounded nonstandard natural number ")#mi("{n \\in {}^* {\\bf N}}")#text(". Indeed, one simply takes a sequence ")#mi("{n_j \\in {\\bf N}}")#text(" of standard natural numbers for which ")#mi("{P(n_j,c_1,\\ldots,c_k)}")#text(", and extracts a subsequence of these ")#mi("{n_j}")#text(" which converges elementarily to a non-standard limit ")#mi("{n}")#text(" (relative to ")#mi("{c_1,\\ldots,c_k}")#text("), which must then be unbounded. Contrapositively, if ")#mi("{P(n,c_1,\\ldots,c_k)}")#text(" holds for all unbounded ")#mi("{n}")#text(", then it must also hold for all sufficiently large standard ")#mi("{n}")#text(".")

#text("Similarly, we have the ")#emph[#text("underspill principle")]#text(": if a predicate ")#mi("{P(x,c_1,\\ldots,c_k)}")#text(" is true for arbitrarily small positive standard real ")#mi("{x}")#text(", then it must also be true for at least one infinitesimal positive non-standard real ")#mi("{x}")#text("; and contrapositively, if it is true for all infinitesimal positive non-standard real ")#mi("{x}")#text(", then it is also true for all sufficiently small standard real ")#mi("{x}")#text(".")

#text("A typical application of these principles is in the nonstandard formulation of continuity:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 11 (Nonstandard formulation of continuity)")]#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a standard function, which can then be extended by ultralimits to the nonstandard completion ")#mi("{{}^* f: {}^* {\\bf R} \\rightarrow {}^* {\\bf R}}")#text(". Let ")#mi("{x \\in {\\bf R}}")#text(". Then the following are equivalent:")

#list(
[#mi("{f}")#text(" is continuous at ")#mi("{x}")#text(".")],
[#text("One has ")#mi("{{}^* f(y) = f(x)+o(1)}")#text(" whenever ")#mi("{y}")#text(" is a nonstandard real such that ")#mi("{y=x+o(1)}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" If ")#mi("{f}")#text(" is continuous, then the “epsilon-delta” definition implies that whenever ")#mi("{y=x+o(1)}")#text(" (so that ")#tao-math("{\\left|y-x\\right| < \\delta}", block: false)#text(" for every standard ")#mi("{\\delta>0}")#text("), one has ")#tao-math("{\\left|{}^* f(y)-f(x)\\right| < \\epsilon}", block: false)#text(" for every standard ")#mi("{\\epsilon}")#text(" (by transfer), and thus ")#mi("{{}^* f(y) = f(x) + o(1)}")#text(". Conversely, if ")#mi("{f}")#text(" is discontinuous at ")#mi("{x}")#text(", then there exists a sequence ")#mi("{x_n}")#text(" of standard reals converging to ")#mi("{x}")#text(" such that ")#tao-math("{\\left|f(x_n)-f(x)\\right| > \\epsilon}", block: false)#text(" for some standard ")#mi("{\\epsilon>0}")#text("; taking ultralimits using Bolzano-Weierstrass to extract a subsequence that is elementarily convergent relative to ")#mi("{f}")#text(", we thus have a non-standard ")#mi("{y=x+o(1)}")#text(" with ")#tao-math("{\\left|{}^* f(y)-f(x)\\right| > \\epsilon}", block: false)#text(", so that ")#mi("{{}^* f(y) \\neq f(x) + o(1)}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" With the notation as above, show that ")#mi("{f}")#text(" is uniformly continuous if and only if ")#mi("{{}^* f(y) = {}^* f(x) + o(1)}")#text(" whenever ")#mi("{x, y \\in {}^* {\\bf R}}")#text(" are such that ")#mi("{y = x + o(1)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" With the notation as above, show that ")#mi("{f}")#text(" is differentiable at a standard real ")#mi("{x}")#text(" with derivative ")#mi("{f^{\\prime}(x)}")#text(" if and only if ")#mi("{{}^* f(x+h) = f(x) + h f^{\\prime}(x) + o(h)}")#text(" for all nonstandard reals ")#mi("{h = o(1)}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 3. The correspondence principle — ")]]

#text("One can use the Bolzano-Weierstrass theorem for ultrapowers to establish various versions of the correspondence principle, as ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("discussed")]#text(" ")#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")[#text("previously")]#text(" on this blog. A simple example occurs when demonstrating the equivalence of colouring theorems, such as the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 12 (van der Waerden theorem, infinitary version)")]#text(" ")#metadata(none) <tao-585acf1152797d6e81c0>#text(" Suppose the integers are coloured by finitely many colours. Then there exist arbitrarily long monochromatic arithmetic progressions.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 13 (van der Waerden theorem, finitary version)")]#text(" ")#metadata(none) <tao-7723ee3c8ebce97b6e9c>#text(" For every ")#mi("{c}")#text(" and ")#mi("{k}")#text(" there exists ")#mi("{N}")#text(" such that whenever ")#mi("{\\{-N,\\ldots,N\\}}")#text(" is coloured by ")#mi("{c}")#text(" colours, there exists a monochromatic arithmetic progression of length ")#mi("{k}")#text(".")
]

#text("It is clear that Theorem ")#link(<tao-7723ee3c8ebce97b6e9c>)[#text("13")]#text(" implies Theorem ")#link(<tao-585acf1152797d6e81c0>)[#text("12")]#text(". To deduce Theorem ")#link(<tao-585acf1152797d6e81c0>)[#text("12")]#text(" from Theorem ")#link(<tao-7723ee3c8ebce97b6e9c>)[#text("13")]#text(", we can argue as follows. Suppose Theorem ")#link(<tao-7723ee3c8ebce97b6e9c>)[#text("13")]#text(" fails, then there exists ")#mi("{c}")#text(" and ")#mi("{k}")#text(", and arbitrarily large standard natural number ")#mi("{N}")#text(" for which there exists a ")#mi("{c}")#text("-colouring of ")#mi("{\\{-N,\\ldots,N\\}}")#text(" without any monochromatic arithmetic progressions of length ")#mi("{k}")#text(". Applying the overspill principle (or the Bolzano-Weierstrass theorem), there must then also exist an unbounded nonstandard natural number for which there exists a ")#mi("{c}")#text("-colouring of ")#mi("{\\{-N,\\ldots,N\\}}")#text(" without any monochromatic arithmetic progressions of length ")#mi("{k}")#text(". But the nonstandard interval ")#mi("{\\{-N,\\ldots,N\\}}")#text(" contains the standard integers ")#mi("{{\\bf Z}}")#text(" as a subset, thus the integers can now also be ")#mi("{c}")#text("-coloured without any monochromatic arithmetic progressions of length ")#mi("{k}")#text(", contradicting Theorem ")#link(<tao-585acf1152797d6e81c0>)[#text("12")]#text(".")

#text("As another example, we can relate qualitative and quantitative results in algebraic geometry. For instance, ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("as noted previously on this blog")]#text(", the following basic result in algebraic geometry,")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 14 (Qualitative decomposition into varieties)")]#text(" ")#metadata(none) <tao-72238ca87f04155f84f3>#text(" Every algebraic set over an algebraically closed field can be decomposed into finitely many algebraic varieties.")
]

#text("is equivalent to the following more quantitative version:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 15 (Quantitative decomposition into varieties)")]#text(" ")#metadata(none) <tao-4172b9e06820a061eeab>#text(" Every algebraic set ")#mi("{A}")#text(" of complexity at most ")#mi("{M}")#text(" over an algebraically closed field can be decomposed at most ")#mi("{C_M}")#text(" algebraic varieties, each of complexity at most ")#mi("{C_M}")#text(", where ")#mi("{C_M}")#text(" depends only on ")#mi("{M}")#text(".")
]

#text("(For a definition of complexity see ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("the previous blog post")]#text(".)")

#text("Clearly Theorem ")#link(<tao-4172b9e06820a061eeab>)[#text("15")]#text(" implies Theorem ")#link(<tao-72238ca87f04155f84f3>)[#text("14")]#text(". To show the converse implication, suppose that Theorem ")#link(<tao-4172b9e06820a061eeab>)[#text("15")]#text(" failed, then there exists ")#mi("{M}")#text(" such that for every standard natural number ")#mi("{N}")#text(" there exists an algebraic set ")#mi("{A_N}")#text(" of complexity at most ")#mi("{M}")#text(" over some field ")#mi("{k_N}")#text(" that cannot be decomposed into fewer than ")#mi("{N}")#text(" algebraic varieties. We use the Bolzano-Weierstrass theorem for ultrapowers to extract a subsequence ")#mi("{A_{N_j}, k_{N_j}}")#text(" that converges jointly elementarily to some limit ")#mi("{A, k}")#text(". As each of the ")#mi("{k_{N_j}}")#text(" are algebraically closed fields, the elementary limit ")#mi("{k}")#text(" is also. As the ")#mi("{A_{N_j}}")#text(" were algebraic sets over ")#mi("{k_{N_j}}")#text(" of uniformly bounded complexity, ")#mi("{A}")#text(" is an algebraic set over ")#mi("{k}")#text(", and thus by Theorem ")#link(<tao-72238ca87f04155f84f3>)[#text("14")]#text(" is decomposable into at most ")#mi("{N_0}")#text(" algebraic varieties for some finite ")#mi("{N_0}")#text(". The property of being decomposable into at most ")#mi("{N_0}")#text(" algebraic varieties can be phrased in an elementarily open manner, i.e. as the disjunction of sentences in first-order logic; this is essentially established in ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("the previous blog post")]#text(", with the key point being that any top-dimensional component of an algebraic set has a lesser degree than that of the original set, and so has a uniform bound on complexity. Thus, we see that for all sufficiently large ")#mi("{j}")#text(", ")#mi("{A_{N_j}}")#text(" must also be decomposable into at most ")#mi("{N_0}")#text(" algebraic varieties, a contradiction.")

#text("Our final example, namely the Furstenberg correspondence principle, is a bit more sophisticated. Here, we are demonstrating the equivalence of the following two statements:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 16 (Furstenberg recurrence theorem)")]#text(" ")#metadata(none) <tao-411195755a2354f96708>#text(" Let ")#mi("{(X, {\\mathcal B}, \\mu, T)}")#text(" be a measure-preserving system, and let ")#mi("{A \\subset X}")#text(" have positive measure. Let ")#mi("{k \\geq 1}")#text(". Then there exists ")#mi("{r > 0}")#text(" such that ")#mi("{A \\cap T^r A \\cap \\ldots \\cap T^{(k-1)r} A}")#text(" has positive measure.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 17 (Szemerédi’s theorem)")]#text(" ")#metadata(none) <tao-8651347d5d501956a468>#text(" Every set of integers of positive upper density contains arbitrarily long arithmetic progressions.")
]

#text("It is easy to use Theorem ")#link(<tao-8651347d5d501956a468>)[#text("17")]#text(" to show Theorem ")#link(<tao-411195755a2354f96708>)[#text("16")]#text(", so we focus on the reverse inclusion. Suppose that Theorem ")#link(<tao-8651347d5d501956a468>)[#text("17")]#text(" failed, then there exists a standard integer ")#mi("{k \\geq 1}")#text(", a standard real ")#mi("{\\delta > 0}")#text(", and a standard set ")#mi("{A \\subset {\\bf Z}}")#text(" of integers of positive upper density at least ")#mi("{\\delta}")#text(" that has no arithmetic progressions of length ")#mi("{k}")#text(". In particular, for arbitrarily large standard ")#mi("{N}")#text(", there exists a subset of ")#mi("{\\{-N,\\ldots,N\\}}")#text(" of density at least ")#mi("{\\delta}")#text(" without any progressions of length ")#mi("{k}")#text(". Applying the overspill principle, there thus exists an unbounded nonstandard ")#mi("{N}")#text(" and a nonstandard subset ")#mi("{A}")#text(" of ")#mi("{\\{-N,\\ldots,N\\}}")#text(" of density at least ")#mi("{\\delta}")#text(" without any progressions of length ")#mi("{k}")#text(".")

#text("Let ")#mi("{{\\mathcal A}}")#text(" be the collection of all nonstandard subsets of ")#mi("{\\{-N,\\ldots,N\\}}")#text(". (Note that not every subset of a nonstandard set remains nonstandard; it may instead merely be an external subset. See ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("this previous blog post")]#text(" for further discussion.) This is a Boolean algebra. From countable saturation we see that this Boolean algebra has the following special property: if any set ")#mi("{E}")#text(" in this Boolean algebra is partitioned into an (externally) countable family ")#mi("{(E_n)_{n \\in {\\bf N}}}")#text(" of further elements in this Boolean algebra, then all but finitely many of the ")#mi("{E_n}")#text(" are empty. For if this were not the case, then by the axiom of choice, one could find a subsequence ")#mi("{n_j}")#text(" and a set of elements ")#mi("{x_{n_j}}")#text(" of ")#mi("{E_{n_j}}")#text(". Passing to a further subsequence, we can assume that the ")#mi("{x_{n_j}}")#text(" converge elementarily to a limit ")#mi("{x}")#text(". But then this limit lies in ")#mi("{E}")#text(" but not in any of the ")#mi("{E_n}")#text(", a contradiction.")

#text("From the above property, we see that any (external) finitely additive measure ")#mi("{\\mu: {\\mathcal A} \\rightarrow [0,1]}")#text(" on ")#mi("{{\\mathcal A}}")#text(" is automatically a ")#link("http://en.wikipedia.org/wiki/Pre-measure")[#text("premeasure")]#text(", and thus by the ")#link("http://en.wikipedia.org/wiki/Hahn-Kolmogorov_theorem")[#text("Hahn-Kolmogorov extension theorem")]#text(", can be extended to a countably additive measure on the ")#link("http://en.wikipedia.org/wiki/Complete_measure")[#text("measure-theoretic completion")]#text(" ")#mi("{\\overline{\\langle {\\mathcal A}\\rangle}}")#text(" of the (external) ")#mi("{\\sigma}")#text("-algebra ")#mi("{\\langle {\\mathcal A}\\rangle}")#text(" generated by ")#mi("{{\\mathcal A}}")#text(".")

#text("In particular, if we consider the nonstandard normalised counting measure")

#align(center)[#tao-fit-display[#mitex("E \\mapsto \\frac{\\# E}{2N+1}")]]

#text("on ")#mi("{{\\mathcal A}}")#text(" and take its standard part,")

#align(center)[#tao-fit-display[#mitex("\\mu: E \\mapsto \\text{st}(\\frac{\\# E}{2N+1})")]]

#text("this is a finitely additive probability measure on ")#mi("{{\\mathcal A}}")#text(", and hence extends to a probability measure in ")#mi("{{\\mathcal B} := \\overline{\\langle {\\mathcal A} \\rangle}}")#text(", which we will continue to call ")#mi("{\\mu}")#text(". This measure is known as the ")#emph[#text("Loeb measure")]#text(" on the nonstandard set ")#mi("{\\{-N,\\ldots,N\\}}")#text(". Observe that any nonstandard subset of ")#mi("{\\{-N,\\ldots,N\\}}")#text(" of infinitesimal density will have Loeb measure zero. On the other hand, the set ")#mi("{A}")#text(" had density at least ")#mi("{\\delta}")#text(", and so will have Loeb measure at least ")#mi("{\\delta}")#text(" also.")

#text("Next, we define the shift ")#mi("{T: \\{-N,\\ldots,N\\} \\rightarrow \\{-N,\\ldots,N\\}}")#text(" by ")#mi("{Tx := x+1}")#text(", leaving ")#mi("{T}")#text(" undefined for ")#mi("{x=N}")#text(". But observe that ")#mi("{\\{N\\}}")#text(" has an infinitesimal density, hence has Loeb measure zero. So ")#mi("{T}")#text(" is defined almost everywhere, and is easily seen to be measurable and measure-preserving; it has an (almost everywhere defined) inverse that is also measurable and measure-preserving. Thus ")#mi("{\\{-N,\\ldots,N\\}}")#text(" with Loeb measure and the shift ")#mi("{T}")#text(" becomes a measure-preserving system. Applying Theorem ")#link(<tao-411195755a2354f96708>)[#text("16")]#text(", we can thus find a standard ")#mi("{r>0}")#text(" such that ")#mi("{A \\cap T^r A \\cap \\ldots \\cap T^{(k-1)r} A}")#text(" has positive Loeb measure, so ")#mi("{A}")#text(" contains a ")#mi("{k}")#text("-term arithmetic progression, a contradiction.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" As stated, the measure space structure on ")#mi("{\\{-N,\\ldots,N\\}}")#text(" is not separable (i.e. countably generated) or regular (coming from a metric space). However, this can be fixed by restricting attention to the much smaller ")#mi("{\\sigma}")#text("-algebra generated by ")#mi("{A}")#text(" and its shifts (after dealing with the null sets on which ")#mi("{T}")#text(" is not defined, e.g. by cutting out the ")#mi("{o(N)}")#text(" neighbourhood of ")#mi("{\\{-N,N\\}}")#text("). We omit the details.")
]

#heading(level: 1)[#strong[#text(" — 4. The Szemerédi regularity lemma — ")]]

#text("Finally, we use nonstandard analysis to give a proof of the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(", which we phrase as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 18 (Szemerédi regularity lemma)")]#text(" ")#metadata(none) <tao-d79c54f4266fad075601>#text(" Let ")#mi("{G = (V,E)}")#text(" be a finite graph, and let ")#mi("{\\epsilon > 0}")#text(". Then there exists a vertex partition ")#mi("{V = V_1 \\cup \\ldots \\cup V_m}")#text(" with ")#mi("{m \\leq C(\\epsilon)}")#text(" such that for all pairs ")#mi("{(i,j)}")#text(" outside of a bad set ")#mi("{S}")#text(" with ")#tao-math("{\\sum_{(i,j) \\in S} \\left|V_i\\right| \\left|V_j\\right| \\leq \\epsilon \\left|V\\right|^2}", block: false)#text(", there exists a density ")#mi("{d_{ij}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left| E(A,B) - d_{ij} \\right|V_i\\left| \\left|V_j\\right| \\right| \\leq \\epsilon \\left|V_i\\right| \\left|V_j\\right|", block: true)]]

#text("for all ")#mi("{A \\subset V_i}")#text(" and ")#mi("{B \\subset V_j}")#text(", where ")#tao-math("{E(A,B) := \\left|E \\cap (A \\times B)\\right|}", block: false)#text(", viewing ")#mi("{E}")#text(" as a symmetric subset of ")#mi("{V \\times V}")#text(".")
]

#text("Here we do not make the cells ")#mi("{V_i}")#text(" in the partition of equal size, as is customary, but it is not too difficult to obtain this additional property from the above formulation of the lemma. The ability of nonstandard analysis to establish regularity lemmas was first observed by ")#link("http://arxiv.org/abs/0705.2179")[#text("Elek and Szegedy")]#text(".")

#text("An application of the Bolzano-Weierstrass theorem for ultraproducts shows that this lemma is equivalent to the following nonstandard version:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 19 (Szemerédi regularity lemma, nonstandard formulation)")]#text(" ")#metadata(none) <tao-75e00e6b5bd84b6295b3>#text(" Let ")#mi("{G = (V,E)}")#text(" be a nonstandard finite graph, and let ")#mi("{\\epsilon > 0}")#text(". Then there exists a vertex partition ")#mi("{V = V_1 \\cup \\ldots \\cup V_m}")#text(", where ")#mi("{m}")#text(" is a standard natural number and ")#mi("{V_1,\\ldots,V_m}")#text(" are nonstandard subsets of ")#mi("{V}")#text(" such that for all pairs ")#mi("{(i,j)}")#text(" outside of a bad set ")#mi("{S}")#text(" with ")#tao-math("{\\sum_{(i,j) \\in S} \\left|V_i\\right| \\left|V_j\\right| \\leq \\epsilon \\left|V\\right|^2}", block: false)#text(", there exists a standard density ")#mi("{d_{ij}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left| E(A,B) - d_{ij} \\right|V_i\\left| \\left|V_j\\right| \\right| \\leq \\epsilon \\left|V_i\\right| \\left|V_j\\right|", block: true)]]

#text("for all ")#mi("{A \\subset V_i}")#text(" and ")#mi("{B \\subset V_j}")#text(".")
]

#text("To see why Lemma ")#link(<tao-75e00e6b5bd84b6295b3>)[#text("19")]#text(" implies Lemma ")#link(<tao-d79c54f4266fad075601>)[#text("18")]#text(", suppose that Lemma ")#link(<tao-d79c54f4266fad075601>)[#text("18")]#text(" failed. Then there is a standard ")#mi("{\\epsilon > 0}")#text(" such that for every standard ")#mi("{m}")#text(" one could find a standard finite graph ")#mi("{G_m = (V_m,E_m)}")#text(" which could not be regularised into ")#mi("{m}")#text(" or fewer cells as required by the lemma. Applying the Bolzano-Weierstrass theorem for ultraproducts, we can assume that ")#mi("{G_m}")#text(" converges elementarily (relative to ")#mi("{\\epsilon}")#text(") to a limit ")#mi("{G = (V,E)}")#text(", which is then a nonstandard finite graph ")#mi("{G = (V,E)}")#text(" which cannot be regularised into any standard finite number of cells. But this contradicts Lemma ")#link(<tao-75e00e6b5bd84b6295b3>)[#text("19")]#text(".")

#text("It remains to prove Lemma ")#link(<tao-75e00e6b5bd84b6295b3>)[#text("19")]#text(". Let ")#mi("{\\mu_V: {\\mathcal B}_V \\rightarrow [0,1]}")#text(" be Loeb measure on ")#mi("{V}")#text(" (as constructed in the previous section), and ")#mi("{\\mu_{V \\times V}: {\\mathcal B}_{V \\times V} \\rightarrow [0,1]}")#text(" be Loeb measure on ")#mi("{V \\times V}")#text(". It is easy to see that ")#mi("{{\\mathcal B}_{V \\times V}}")#text(" contains the product ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}_V \\times {\\mathcal B}_V}")#text(" as a subalgebra, and that the product measure ")#mi("{\\mu_V \\times \\mu_V}")#text(" is the restriction of ")#mi("{\\mu_{V \\times V}}")#text(" to ")#mi("{{\\mathcal B}_V \\times {\\mathcal B}_V}")#text(". The edge set ")#mi("{E}")#text(", viewed as a symmetric nonstandard subset of ")#mi("{V \\times V}")#text(", is measurable in ")#mi("{{\\mathcal B}_{V \\times V}}")#text(", but is not necessarily measurable in ")#mi("{{\\mathcal B}_V \\times {\\mathcal B}_V}")#text(". One can then form the conditional expectation ")#mi("{f := {\\bf E}( 1_E | {\\mathcal B}_V \\times {\\mathcal B}_V )}")#text(", which is a ")#mi("{{\\mathcal B}_V \\times {\\mathcal B}_V}")#text("-measurable function that is defined up to ")#mi("{\\mu_V \\times \\mu_V}")#text("-almost everywhere equivalence, and takes values in ")#mi("{[0,1]}")#text(".")

#text("The ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}_V \\times {\\mathcal B}_V}")#text(" is generated by product sets ")#mi("{A \\times B}")#text(" of ")#mi("{{\\mathcal B}_V}")#text("-measurable functions, which in turn can be approximated in measure to arbitrary accuracy by product sets of nonstandard sets. As ")#mi("{f}")#text(" is ")#mi("{{\\mathcal B}_V \\times {\\mathcal B}_V}")#text("-measurable, we can approximate it to less than ")#mi("{\\epsilon^2}")#text(" in ")#mi("{L^1(\\mu_V \\times \\mu_V)}")#text(" norm by a finite linear combination of indicator functions of products of nonstandard sets. Organising these products, we thus see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f - \\sum_{i=1}^{m} \\sum_{j=1}^{m} d_{ij} 1_{V_i \\times V_j} \\right\\|_{L^1(\\mu_V \\times \\mu_V)} < \\epsilon^2", block: true)]]

#text("for some finite partition of ")#mi("{V}")#text(" into nonstandard sets ")#mi("{V_1,\\ldots,V_{m}}")#text(" and some standard real numbers ")#mi("{d_{ij} \\in [0,1]}")#text(". By Markov’s inequality, we thus see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f - d_{ij} \\right\\|_{L^1(V_i \\times V_j)} < \\epsilon \\mu_V(V_i) \\mu_V(V_j)", block: true)]]

#text("for all ")#mi("{(i,j)}")#text(" outside of a bad set ")#mi("{S}")#text(" with")

#align(center)[#tao-fit-display[#mitex("\\sum_S \\mu_V(V_i) \\mu_V(V_j) \\leq \\epsilon.")]]

#text("Now let ")#mi("{A \\subset V_i}")#text(" and ")#mi("{B \\subset V_j}")#text(" be nonstandard sets, with ")#mi("{(i,j)}")#text(" outside of ")#mi("{S}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f 1_{A \\times B} - d_{ij} 1_{A \\times B} \\right\\|_{L^1(V_i \\times V_j)} < \\epsilon \\mu_V(V_i) \\mu_V(V_j).", block: true)]]

#text("On the other hand, ")#mi("{1_E - f}")#text(" is orthogonal to all ")#mi("{{\\mathcal B}_V \\times {\\mathcal B}_V}")#text(" functions, and in particular to ")#mi("{1_{A \\times B}}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("\\int_{V \\times V} 1_E 1_{A \\times B}\\ d\\mu_{V \\times V} = \\int_{V \\times V} f 1_{A \\times B}\\ d\\mu_{V \\times V}.")]]

#text("Since")

#align(center)[#tao-fit-display[#tao-math("\\int_{V \\times V} 1_E 1_{A \\times B}\\ d\\mu_{V \\times V} = \\frac{\\left|E(A,B)\\right|}{\\left|V\\right|^2}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\int_{V \\times V} d_{ij} 1_{A \\times B}\\ d\\mu_{V \\times V} = d_{ij} \\frac{ \\left|A\\right| \\left|B\\right| }{\\left|V\\right|^2}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\mu_V(V_i) = \\left|V_i\\right|/\\left|V\\right|; \\mu_V(V_j) = \\left|V_j\\right|/\\left|V\\right|", block: true)]]

#text("we thus see that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{\\left|E(A,B)\\right|}{\\left|V\\right|^2} - d_{ij} \\frac{ \\left|A\\right| \\left|B\\right| }{\\left|V\\right|^2}\\right| < \\epsilon \\frac{\\left|V_i\\right| \\left|V_j\\right|}{\\left|V\\right|^2}.", block: true)]]

#text("Thus ")#mi("{G}")#text(" has been regularised using a finite number of cells, as required.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (59)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/79a190795d80e8c530d4a698e6be06bac867e32eed945b944b9cc603f8f83754-717d77f039a97e939bab0746ac8ac93e3d6f29dd80ba56d28d6bf76de4a9939f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of none")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48288")[#strong[#text("none")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2010")])]

#text("Thanks for this great post, it demystifies a topic I’ve wondered about for while. There are several typos that are a bit hard for me to enter here since I can only have one large window on this screen. But it says R_M in a few places where it should say R_{\\mathfrak U}, I think.")

#text("“(In fact, there is an enormous Galois group {\\hbox{Gal}({\\bf C}/\\overline{{\\bf Q}})}, the action of which is completely undetectable with regards to absolute elementary convergence is completely unable to detect.) ” is garbled.")

#text("One or two others that I remember but am not seeing now. I’ll try to find them on a re-read.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48290")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2010")])]

#text("I’m very much enjoying the post. A very minor typo: in the fourth paragraph you meant to say slightly ")#emph[#text("less")]#text(" well known.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48292")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2010")])]

#text("how do we know that ")#mi("3, 3.1, 3.14, . . .")#text(" is not converging to a rational number?")

#emph[#text("[Because ")#mi("\\pi")#text(" is known to be irrational, and limits in the real numbers are unique – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a813ea376d0943b6f47639a66e1961541ae0c338e7cb2d268eadf954d2b27794-cd40e84deaaab9d7d9574fd608399fde97d93d7c3ae2111b631c055ebe624528.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Graviton")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48304")[#strong[#text("Greg Graviton")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2010")])]

#text("Concerning Furstenberg’s recurrence theorem, I take it that you define the topology on ")#mi("X")#text(" as follows: a basis of open sets is given by the nonstandard subsets of ")#mi("[-N,N]")#text(" (actually, these sets are also closed).")

#text("But: a measure preserving system is usually assumed to be second countable, whereas there are uncountably many nonstandard subsets of ")#mi("[-N,N]")#text(".")

#text("If I remember correctly, your usual remedy to this problem was to restrict attention to the sigma-algebra generated by the shifts of ")#mi("A")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48309")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2010")])]

#text("This is correct: at present the measure space is neither seperable nor metrisable, but as you say this can be fixed by cutting the sigma algebra down to size. Technically, the statement of the Furstenberg recurrence theorem is valid for arbitrary measure-preserving systems, though for technical reasons, the proof of the theorem usually proceeds by first reducing to the case of regular measure-preserving systems in which the sigma algebra can be identified with the Borel sigma algebra of a Polish space, in order to use tools such as disintegration. I’ve added a remark to indicate this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Concentration compactness via nonstandard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48330")[#strong[#text("Concentration compactness via nonstandard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2010")])]

#text("[…] in this previous blog post (and see also this later post on ultralimit analysis, as well as the most recent post on this topic). Very briefly, we will need to fix a non-principal ultrafilter on the natural numbers. Once one […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c18447788622f4b07a911f2987fbfc936b33c184d26523b2f48bda19edba8c4-1a22b1dffcc73b00078ad604f783567bb7705d2548ef5b4fc70128067d9dd58f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Weinstein")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48365")[#strong[#text("Jonathan Weinstein")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2010")])]

#text("I had some trouble understanding your non-standard definition of uniform continuity (Exercise 3.) I tried to write down my own non-standard versions of continuity and uniform continuity: Let ")#mi("I \\subset {}^*{\\bf R}")#text(" be the set of non-negative infinitesimals (less than every positive standard real.) Then continuity is, in shortest form,")#linebreak()#text(" ")#tao-math("\\displaystyle \\left|x-y\\right| \\in I \\Rightarrow \\left|f(x)-f(y)\\right| \\in I", block: false)#linebreak()#text(" or in longer form")#linebreak()#text(" ")#tao-math("\\displaystyle \\forall \\epsilon \\in I: \\forall x: \\exists \\delta \\in I : \\left|x-y\\right| < \\epsilon \\Rightarrow  \\left|f(x)-f(y)\\right|<\\delta", block: false)#linebreak()#text(" where the epsilon and delta quantifiers come in a non-standard, but perhaps more intuitive order: \"If x only moves a tiny bit, so does f(x).\"")#linebreak()#text(" Now, if I did this right, uniform continuity would arise by switching the order of quantifiers, similarly to standard except the delta instead of epsilon quantifier gets switched with x:")#linebreak()#text(" ")#tao-math("\\displaystyle \\forall \\epsilon \\in I: \\exists \\delta \\in I: \\forall x  : \\left|x-y\\right| < \\epsilon \\Rightarrow  \\left|f(x)-f(y)\\right|<\\delta", block: false)#linebreak()#text(" By contrast, I can't see where your definition distinguishes the order of quantifiers. I understand ")#mi("f(y) = f(x) + o(1)")#text(" to be shorthand for ")#tao-math("\\left|f(y)-f(x)\\right| \\in I", block: false)#text(" but I feel like this shorthand is obscuring what the infinitesimal is allowed to depend on. Assuming your intended meaning is correct, maybe there is just some convention here I don't know; I have read about non-standard analysis but never worked with it. I will highly appreciate hearing about any mistakes I made here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48366")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2010")])]

#text("In general, nonstandard analysis largely eliminates the need to carefully order one’s quantifiers as is the case in standard analysis, but in return, one must now carefully distinguish between what objects are standard and what objects are nonstandard.")

#text("Continuity is equivalent to the property that ")#tao-math("\\left|x-y\\right| \\in I \\implies \\left|f(x)-f(y)\\right| \\in I", block: false)#text(" for all ")#emph[#text("standard")]#text(" reals ")#mi("x \\in {\\bf R}")#text(" and non-standard reals ")#mi("y \\in {}^* {\\bf R}")#text(". Uniform continuity is equivalent to the same property ")#tao-math("\\left|x-y\\right| \\in I \\implies \\left|f(x)-f(y)\\right| \\in I", block: false)#text(", but now where ")#mi("x \\in {}^* {\\bf R}")#text(" and ")#mi("y \\in {}^* {\\bf R}")#text(" are ")#emph[#text("both")]#text(" permitted to be non-standard.")

#text("It may help to think of a nonstandard real ")#mi("x")#text(" as an (ultra)limit of a sequence of standard reals ")#mi("x_n")#text(", with a non-negative infinitesimal in ")#mi("I")#text(" being the (ultra)limit of a sequence of non-negative standard reals that converges (in the standard sense) to zero. In standard analysis, continuity is equivalent to the claim that if ")#mi("y_n")#text(" is a sequence of (standard) real numbers and ")#mi("x")#text(" is a (standard) real number such that ")#tao-math("\\left|x-y_n\\right| \\to 0", block: false)#text(" as ")#mi("n \\to \\infty")#text(", then ")#tao-math("\\left|f(x)-f(y_n)\\right| \\to 0", block: false)#text(" as ")#mi("n \\to \\infty")#text(". Uniform continuity is equivalent to the claim that if ")#mi("x_n, y_n")#text(" are two sequences of (standard) real numbers such that ")#tao-math("\\left|x_n-y_n\\right| \\to 0", block: false)#text(" as ")#mi("n \\to \\infty")#text(", then ")#tao-math("\\left|f(x_n)-f(y_n)\\right| \\to 0", block: false)#text(" as ")#mi("n \\to \\infty")#text(". Viewed in this way, we see that the nonstandard definitions of continuity and uniform continuity are basically the ultralimits of the standard definitions.")

#text("More generally, a rough first approximation to nonstandard analysis can be obtained by introducing an additional parameter ")#mi("n")#text(", and interpreting “standard” as “independent of ")#mi("n")#text("” and “nonstandard” as “allowed to depend on ")#mi("n")#text("“. (Similarly, “infinitesimal” becomes “going to zero as ")#mi("n \\to \\infty")#text("“, and so forth.) This is only a rough approximation because one also needs an ultrafilter to decide what sets of ")#mi("n")#text(" are more “important” than others in order to decide whether a given nonstandard object has a given property. (e.g. is the quantity ")#mi("(-1)^n")#text(" positive or negative in the nonstandard universe? It depends on whether the even numbers or the odd numbers are contained in the ultrafilter.)")

#text("In any case, it is an excellent exercise to try to formally establish the equivalence of the standard and nonstandard formulations of both concepts from first principles (i.e. using the definition of ultralimit); using underflow or countable saturation is the slickest way to proceed, but it is instructive to do it “with bare hands” as well, to see how the quantifiers are being automatically absorbed by the ultralimit process.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c18447788622f4b07a911f2987fbfc936b33c184d26523b2f48bda19edba8c4-1a22b1dffcc73b00078ad604f783567bb7705d2548ef5b4fc70128067d9dd58f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Weinstein")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48369")[#strong[#text("Jonathan Weinstein")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2010")])]

#text("Thanks, that’s extremely helpful! Part of the reason my intuition was messed up was that I forgot non-standard reals can be infinite as well as infinitesimal. So I didn’t notice the key idea that a prototypical non-uniformly continuous function like exp(x) is actually not even continuous at infinite non-standard reals. Likewise, I see that f(x)=1/x restricted to (0,1] is continuous at standard reals but discontinuous at infinitesimals.")#linebreak()#text(" I look forward to trying to read the rest of the article…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48370")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2010")])]

#text("Yes, this is correct. On a compact (metric space) domain, every nonstandard point is infinitesimally close to a standard point (this is basically the Heine-Borel theorem), and so uniform continuity and continuity become the same concept on such domains (as is already well known in standard analysis); but on non-compact domains this is no longer the case.")

#text("(One little subtlety though: while functions such as ")#mi("1/x")#text(" and ")#mi("\\exp(x)")#text(" are not uniformly continuous in the sense that ")#tao-math("\\left|x-y\\right| \\in I \\implies \\left|f(x)-f(y)\\right| \\in I", block: false)#text(" holds for all nonstandard ")#mi("x, y")#text(", they are still continuous in the ")#emph[#text("internal")]#text(" sense, in that for every nonstandard ")#mi("\\varepsilon > 0")#text(" and nonstandard ")#mi("x")#text(" there exists a nonstandard ")#mi("\\delta > 0")#text(" such that ")#tao-math("\\left|f(x)-f(y)\\right| \\leq \\varepsilon", block: false)#text(" whenever ")#mi("y")#text(" is nonstandard with ")#tao-math("\\left|x-y\\right| \\leq \\delta", block: false)#text(". Indeed, from the transfer principle, any continuous function f will become internally continuous when transferred to the nonstandard world. But this notion of continuity is distinct from the more “external” notion of continuity that involves the external concept of an infinitesimal.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed46753abb9b9d7ba883d5f49e124f7cdf1fa4982cfdc2d73317ea132b59f9f-16e7223e25b645f3285465cecad79eaa69988183cc76bd52780a04e9496ddd80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of katz")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48484")[#strong[#text("katz")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2010")])]

#text("Thanks for a great post. There is a small detail I don’t follow: you require countability of the _constants_ which appears to make the construction inapplicable to R, an important case :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48486")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2010")])]

#text("Unfortunately I believe a restriction of this form is necessary in order to get elementary completeness (which, once one allows uncountably many constants, is subtly different from countable saturation, which does indeed hold with arbitrary constants). For instance, consider the sequence ")#mi("x_n = n")#text(" in the hyperreals ")#mi("{}^* {\\bf R}")#text(". With at most countably many constants, one can extract a subsequence ")#mi("x_{n_j}")#text(" that is elementarily convergent to some (unbounded) hyperreal limit ")#mi("x")#text(". But if one allows every single hyperreal as a constant, then it is impossible for any subsequence ")#mi("x_{n_j}")#text(" to converge elementarily to a limit ")#mi("x")#text(", because the predicate ")#mi("P(y) := (y=x)")#text(" (which uses ")#mi("x")#text(" as a constant) would be false for each of the ")#mi("x_{n_j}")#text(" but true for ")#mi("x")#text(".")

#text("(I do not know, though, if the hyperreals are elementarily complete if one allows all the standard reals (but not the hyperreals) as constants.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed46753abb9b9d7ba883d5f49e124f7cdf1fa4982cfdc2d73317ea132b59f9f-16e7223e25b645f3285465cecad79eaa69988183cc76bd52780a04e9496ddd80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of katz")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48504")[#strong[#text("katz")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2010")])]

#text("Can one view the discussion of elementary completeness as taking place with Q* as the backdrop, or must the constants be left unspecified and dependent on the application? Incidentally, as per the discussion of continuity versus uniform continuity, there is a parallel distinction between convergence and uniform convergence which happens to be the background necessary to understand Cauchy’s 1853 paper on the sum theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d539cc9d03ba01b36a7cf5d1bf280126d93e7b1658ff63499bb72261510bb711-9225e709ba3e67284f6a54c62f03c801ba9c62a2ec96843c4c19fcaa20bdd036.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Rood")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48554")[#strong[#text("John Rood")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2010")])]

#text("Can you say anything useful about nilpotent infinitesimals, aka differential forms etc?")

#link("http://en.wikipedia.org/wiki/Differential_%28infinitesimal%29")[#text("http://en.wikipedia.org/wiki/Differential_%28infinitesimal%29")]

#text("Maybe these are simply outside your development here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48556")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2010")])]

#text("One can certainly use the hyperreals to construct rings with nilpotent infinitesimals via a quotient space construction. For instance, starting with a nonstandard infinitesimal ")#mi("dx")#text(" in the hyperreals ")#mi("{}^* {\\bf R}")#text(", we can construct the space ")#mi("o(dx)")#text(" of hyperreals of magnitude bounded by ")#mi("\\varepsilon dx")#text(" for every standard ")#mi("\\varepsilon > 0")#text(". This is an ideal of ")#mi("O({\\bf R})")#text(", the space of bounded hyperreals, and so one can form the quotient space ")#mi("{\\bf R}[dx] := O({\\bf R}) / o( dx )")#text(", which is a commutative ring containing the standard reals as a subring for which ")#mi("dx^2 = 0")#text(". Any standard differentiable function ")#mi("f: {\\bf R} \\to {\\bf R}")#text(" extends to a function ")#mi("f: {\\bf R}[dx] \\to {\\bf R}[dx]")#text(", obeying the Newton approximation ")#mi("f(x+tdx) = f(x) + t f^{\\prime}(x) dx")#text(" for any standard ")#mi("x, t")#text(". One can use this as a rigorous basis for differential infinitesimal calculus if desired.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d539cc9d03ba01b36a7cf5d1bf280126d93e7b1658ff63499bb72261510bb711-9225e709ba3e67284f6a54c62f03c801ba9c62a2ec96843c4c19fcaa20bdd036.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Rood")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48563")[#strong[#text("John Rood")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2010")])]

#text("Hmmm. Very good. But let me stick my neck out a bit farther.")

#text("Are we then talking about something like embedding the exterior algebra into some multivariable version of the nonstandard reals?")

#text("One point I wish to make is that (cf the wikipedia link in my previous post) the standard topos models my involve intuitionistic logic in which, say, the law of the excluded middle fails. I presume you don’t have such models in mind … ?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed46753abb9b9d7ba883d5f49e124f7cdf1fa4982cfdc2d73317ea132b59f9f-16e7223e25b645f3285465cecad79eaa69988183cc76bd52780a04e9496ddd80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of katz")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48621")[#strong[#text("katz")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2010")])]

#text("John: the hyperreals are commutative, so you won’t get very far with the exterior algebra here. Also, the hyperreals are built in the context of ZFC with classical logic, and in this sense is consevative. Lawvere’s approach, while it has its advantages, necessitates jettisoning traditional set theory as well as classical logic, but results in a surprisingly “clean” presentation of certain topics whose classical treatment is more cumbersome.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d539cc9d03ba01b36a7cf5d1bf280126d93e7b1658ff63499bb72261510bb711-9225e709ba3e67284f6a54c62f03c801ba9c62a2ec96843c4c19fcaa20bdd036.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Rood")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48653")[#strong[#text("John Rood")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2010")])]

#text("Thank you for this reply. Of course they’re commutative, sorry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d539cc9d03ba01b36a7cf5d1bf280126d93e7b1658ff63499bb72261510bb711-9225e709ba3e67284f6a54c62f03c801ba9c62a2ec96843c4c19fcaa20bdd036.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Rood")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48658")[#strong[#text("John Rood")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2010")])]

#text("Dear katz, thinking about this a bit more, I find I still have a question. But, this leads me to a question of “protocol” on this blog, namely, is there some way I can take this conversation out of this context, say by contacting you directly by email or something. Or you can contact me (my email address is known to the blog, of course).")

#text("It occurs to me that one should (?) (or might?–where does the following go wrong) have vectors over the nonstandard reals, then vector spaces, then algebras like the tensor algebra, Lie algebras AND the exterior algebra. All of these things would be carrying along with them “little differentials”, i.e. infinitesimals. Does this make any sense? Then one might hope to recover the “Lie Bracket” by a standard geometric argument (about going around the sides of an “infinitesimal” parallelogram which doesn’t commute) which produces a new vector (field) from two input vector (fields) as a sort of first order approximation (infinitesimally) of this geometric non-commutativity.")

#text("As I say, I’d be interested to hear what you have to say / know about this, and where it goes wrong … ?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed46753abb9b9d7ba883d5f49e124f7cdf1fa4982cfdc2d73317ea132b59f9f-16e7223e25b645f3285465cecad79eaa69988183cc76bd52780a04e9496ddd80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of katz")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48662")[#strong[#text("katz")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2010")])]

#text("I think all of the items you mentioned should go through without problem. The hyperreal approach to Lie groups and algebras is already in Robinson I think. Actually I was unable to find your email address via this site. You can contact me by looking for first name Mikhail. I prefer not to leave an email address here so as to minimize robot-generated mail. Otherwise we can continue here; I am sure Terry will let us know if we overuse his hospitality :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d539cc9d03ba01b36a7cf5d1bf280126d93e7b1658ff63499bb72261510bb711-9225e709ba3e67284f6a54c62f03c801ba9c62a2ec96843c4c19fcaa20bdd036.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Rood")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48671")[#strong[#text("John Rood")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2010")])]

#text("Ok, tyvm. Let me mention that I do now have your email address with a tip o’ the hat to Terry and I presume that you also have mine.")

#text("So (and please forgive me if I am making superficial errors here) the “obvious” question is: If all this Lie Theory goes through using Robinson’s nonstandard analysis, what does one get from Lawvere’s approach? I am aware that Lie Groups are about as well behaved as one can expect any spaces to be. Maybe more general spaces … bla bla bla … ?")

#text("Is there a simple answer to this question of what is Lawvere up to? (Even a non-simple answer might be of interest …)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed46753abb9b9d7ba883d5f49e124f7cdf1fa4982cfdc2d73317ea132b59f9f-16e7223e25b645f3285465cecad79eaa69988183cc76bd52780a04e9496ddd80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of katz")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48674")[#strong[#text("katz")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2010")])]

#text("Lawvere’s approach allows for a certain additional elegance (some would say, simplicity) due to the presence of nilsquare infinitesimals. To take an elementary example, if y=f(x) is differentiable then for nilsquare dx one would have dy=f'(x)dx without a higher order error term. Similarly, one can define the tangent plane as everything proportional to nilsquare infinitesimal displacements. A planetary orbit can be thought of literally as made up of infinitesimal straight line segments.")

#text("As I see it, the disadvantage of the approach is an absence of the full power of the transfer principle which is available in the hyperreal framework. I hereby challenge John L. Bell to produce an infinitesimal proof of the invariant subspace conjecture :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d539cc9d03ba01b36a7cf5d1bf280126d93e7b1658ff63499bb72261510bb711-9225e709ba3e67284f6a54c62f03c801ba9c62a2ec96843c4c19fcaa20bdd036.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Rood")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48681")[#strong[#text("John Rood")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2010")])]

#text("Ok, very good. But I find I still have a point of confusion. Are all infinitesimals’ squares zero? Do Leibniz’ higher order infinitesimals make sense? Which kind is dx?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed46753abb9b9d7ba883d5f49e124f7cdf1fa4982cfdc2d73317ea132b59f9f-16e7223e25b645f3285465cecad79eaa69988183cc76bd52780a04e9496ddd80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of katz")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48690")[#strong[#text("katz")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2010")])]

#text("No, some infinitesimals are invertible and therefore not nilsquare. To have dy=f'(x)dx we must start with a nilsquare dx. Leibniz would not hear of nilsquare ones. Rather, they are in the spirit of his critic Nieuwentijdt. A great account of all this is in John L. Bell’s article in the Stanford Encyclopedia of Philosophy.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d539cc9d03ba01b36a7cf5d1bf280126d93e7b1658ff63499bb72261510bb711-9225e709ba3e67284f6a54c62f03c801ba9c62a2ec96843c4c19fcaa20bdd036.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Rood")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48707")[#strong[#text("John Rood")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2010")])]

#text("Yes! Very nice way into this topic, apparently:")

#link("http://plato.stanford.edu/entries/continuity/")[#text("http://plato.stanford.edu/entries/continuity/")]

#text("Here is a quotation from the section about Smooth Infinitesimal Analysis:")

#text("for all infinitesimal ε, not ε ≠ 0 [endquote]")

#text("Evidently not compatible with the Law of the Excluded Middle …")

#text("Amazing how the “intuitive” history of mathematics (analysis) can be formalized! And the internet makes all of this easier to access.")

#text("katz, thank you very much for your discussion here.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/79a190795d80e8c530d4a698e6be06bac867e32eed945b944b9cc603f8f83754-717d77f039a97e939bab0746ac8ac93e3d6f29dd80ba56d28d6bf76de4a9939f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of none")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48892")[#strong[#text("none")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2010")])]

#text("So I wonder to what extent this nonstandard stuff breaks the “standard” proofs in calculus, that depend on the least-upper-bound axiom, which fails in this non-Archimedian version of the reals. The nonstandard reals are elementarily equivalent to the standard reals, i.e. they satisfy the same first-order sentences, but the least-upper-bound property is second-order and can tell the two models apart. I didn’t know any logic when I took calculus but I guess this means that my “rigorous” calculus course was actually done in second-order logic, which means(?) that its proofs relied on a tacit, informal version of set theory under the covers. That gap got taken care of later in logic class, where we went over an explicit encoding of the reals in ZFC, which meant that the calculus proofs worked because we could treat second-order statements about reals as first-order statements about sets. But to develop calculus with nonstandard reals, it looks like you have to do all the proofs over again; you don’t get to add new, easier proofs while still keeping the old ones. Does that look right? I’ve never really thought about this before.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed46753abb9b9d7ba883d5f49e124f7cdf1fa4982cfdc2d73317ea132b59f9f-16e7223e25b645f3285465cecad79eaa69988183cc76bd52780a04e9496ddd80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of katz")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48937")[#strong[#text("katz")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2010")])]

#text("In response to the comment by “none”: second order statements remain valid if interpreted as applying to internal sets, in particular natural extensions of real sets. Thus, the least upper bound will exist, etc. For instance, the natural extension of the open interval (0,1) will contain all decimal expansions starting with infinitely many 9s, and the least upper bound is 1.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f2e90f7b1bd21c93d591d1a92d96a7a440843f6b82aa209f6788de28cd62882-87274f964b908ad08db58e6b1f6039f4f476139fc572ab012d956cf2a8d3b101.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Albanius")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48905")[#strong[#text("Albanius")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2010")])]

#text("It would be very helpful to see this as a pdf.")

#text("My attempts to print from this page or copy to MS-Word did not capture the symbols.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c18447788622f4b07a911f2987fbfc936b33c184d26523b2f48bda19edba8c4-1a22b1dffcc73b00078ad604f783567bb7705d2548ef5b4fc70128067d9dd58f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Weinstein")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48906")[#strong[#text("Jonathan Weinstein")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2010")])]

#text("Albanius,")

#text("Prof. Tao provides valuable, informative and entertaining content, with higher quality than most published material, for free. I would hate to complain about the file format.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f2e90f7b1bd21c93d591d1a92d96a7a440843f6b82aa209f6788de28cd62882-87274f964b908ad08db58e6b1f6039f4f476139fc572ab012d956cf2a8d3b101.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Albanius")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48907")[#strong[#text("Albanius")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2010")])]

#text("It is precsiely because the content is so valuable that I would like to be able to print it out to study.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48908")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2010")])]

#text("Albanius, the AMS has been publish Prof. Tao’s in printed book form once per year. See for example here: ")#link("http://www.ams.org/bookstore-getitem/item=MBK-59")[#text("http://www.ams.org/bookstore-getitem/item=MBK-59")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e175b5c4a891b5cb70ff72ff0a4753ef0ed98ed66826b0925010f0e3b47d4d69-1df3e1a1387bcfff4408cfbf21a6e0ab4e652a8634ed0f5c0693f25b8ab1c310.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous2")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48991")[#strong[#text("anonymous2")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2010")])]

#text("In Firefox choose File > Print and it formats the blog post nicely and includes the “special” characters (i.e. TeX). WordPress does that by default.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f2e90f7b1bd21c93d591d1a92d96a7a440843f6b82aa209f6788de28cd62882-87274f964b908ad08db58e6b1f6039f4f476139fc572ab012d956cf2a8d3b101.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Albanius")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48992")[#strong[#text("Albanius")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2010")])]

#text("Newbie mistake, sorry.")

#text("After clicking the PRINT button between the essay and the comments,")#linebreak()#text(" the next window had an option for PDF, which created a pdf file I could save and print, just what I wanted.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8fe2bfbdc7c2702a3afe4050e7e55a9060e7f4e94fad9a7e7f2702ee2e480b7d-eaa84c8d5df2be9c25972b214d03523b40a47b0867aef38d0df9ea130b0153a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alex")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48974")[#strong[#text("alex")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2010")])]

#text("Terry Tao thank you for all the beautiful mathematics, I am learning a lot reading your blog.")

#text("You said that the model of real numbers for the language of ordered fields can see algebraic numbers precisely but see transcendental numbers fuzzily. I was wondering if anyone has applied this method to prove/construct a number transcendental?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e6578556426b234d2b90abc9c4068a5cda98d38521b8f58a3e9a3aa7db13a65-244faf6bdd1cead59736e5d98131c2c7c7cc0c89da024c9f2827b70496eb0930.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quinn Culver")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48986")[#strong[#text("Quinn Culver")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2010")])]

#text("Typo in the proof of Proposition 4?:")#linebreak()#text(" “…is elementarily convergent, as desired.” Should be “is elementarily Cauchy, as desired.”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e6578556426b234d2b90abc9c4068a5cda98d38521b8f58a3e9a3aa7db13a65-244faf6bdd1cead59736e5d98131c2c7c7cc0c89da024c9f2827b70496eb0930.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quinn Culver")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-48987")[#strong[#text("Quinn Culver")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2010")])]

#text("Another potential typo: in Definition 6, “…for all ")#mi("n")#text(" sufficiently close to ")#mi("p")#text(".” should be “…for all ")#mi("\\alpha")#text(" sufficiently close to ")#mi("\\alpha_{\\infty}")#text(".”")#linebreak()#text(" (If you’d prefer I not point out minor typos like this, let me know.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb9b14c4f3b8ddd3ec179613cf5e6417e66305974e7457655828e12f97779c31-49f5595229e131378b0c2f9a70b4e675d508a25fb69b06944134e5b895dc215e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew N. Petersen")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-49699")[#strong[#text("Matthew N. Petersen")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2011")])]

#text("Is there a nonstandard definition of Absolute Continuity? I haven’t been able to discover one yet.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-49713")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2011")])]

#text("A function ")#mi("f: {\\bf R} \\to {\\bf R}")#text(" is absolutely continuous iff *f maps nonstandard elementary sets (i.e. a union of nonstandard-finitely many nonstandard intervals) of infinitesimal length to nonstandard elementary sets of infinitesimal length (or subsets thereof).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb9b14c4f3b8ddd3ec179613cf5e6417e66305974e7457655828e12f97779c31-49f5595229e131378b0c2f9a70b4e675d508a25fb69b06944134e5b895dc215e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew N. Petersen")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-49739")[#strong[#text("Matthew N. Petersen")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2011")])]

#text("Thank you!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-51529")[#strong[#text("Non-standard analysis link round-up « Matthew’s Math Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2011")]

#text("[…] Two posts on Terry Tao’s blog: [1] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 6: Ultraproducts as a bridge between hard analysis and soft analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-93080")[#strong[#text("254A, Notes 6: Ultraproducts as a bridge between hard analysis and soft analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2011")])]

#text("[…] some extent the two constructions are at least partially interchangeable in this setting. (See also these previous posts for the use of ultralimits as a substitute for topological limits.) In the theory of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A cheap version of nonstandard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-136448")[#strong[#text("A cheap version of nonstandard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2012")])]

#text("[…] of a countable family of nested satisfiable formulae is simultaneously satisfiable. (See this previous blog post for more on the analogy between the use of nonstandard analysis and the use of metric completions.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ec2e562f9e0cbbea8748b9102e416a5f4aa944d2320e2dc55e604dbdd3ede6de-4e7a381651b25620449fcdacefef2f8a03e061a4ca1c3fce8c70010c4e15b92e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sıcak videolar")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-137327")[#strong[#text("sıcak videolar")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2012")])]

#text("Terry Tao thank you for all the beautiful mathematics, I am learning a lot reading your blog.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-185899")[#strong[#text("Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2012")])]

#text("[…] the Loeb -algebra, called Loeb measure, such that for any internal subset of , one has . See e.g. this previous blog post for the details of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An informal version of the Furstenberg correspondence principle | What's new")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-221343")[#strong[#text("An informal version of the Furstenberg correspondence principle | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2013")])]

#text("[…] leads to the Furstenberg correspondence principle, discussed for instance in these previous blog posts. Such principles allow one to rigorously pass back and forth between the combinatorics of strings […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-255863")[#strong[#text("Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2013")])]

#text("[…] space as a “completion” of the standard space , analogous to metric completion; see this previous blog post for further discussion of this perspective. A related perspective is to view as a double-precision […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e6f8f2bb5eb2e164d382a08c9c55562160f62afd3805e9affb3caeb03122d15-a9d50eade842fff7563eeed2eb1528521d4a50b3b6dd2083cae36cea06a1a5b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Costas Drossos")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-396031")[#strong[#text("Costas Drossos")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("Is there any relationship of your ultralimit concept with Kochen’s ultralimits.")#linebreak()#text(" Do you know any concrete development of ultraroots?")#linebreak()#text(" I might state a conjecture: A appropriate model for Nelson’s IST is given through ultraroots in contradistinction with Robinson which uses ultrapowers. What is your opinion?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed46753abb9b9d7ba883d5f49e124f7cdf1fa4982cfdc2d73317ea132b59f9f-16e7223e25b645f3285465cecad79eaa69988183cc76bd52780a04e9496ddd80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikhail Katz")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-396037")[#strong[#text("Mikhail Katz")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("I note that ultraroots have not been mentioned on this post previously. It might be easier for other participants to follow this discussion if you explain what they are.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e6f8f2bb5eb2e164d382a08c9c55562160f62afd3805e9affb3caeb03122d15-a9d50eade842fff7563eeed2eb1528521d4a50b3b6dd2083cae36cea06a1a5b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Costas Drossos")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-396101")[#strong[#text("Costas Drossos")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("An ultraroot of a structure U is a structure Ultraroot(U) such that its ultrapower is U. The thing is that I have seen the definition but not a technical development. Thus the ultraroot of R will give not an extension of R like e.g. *R, but a vague deformation of it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed46753abb9b9d7ba883d5f49e124f7cdf1fa4982cfdc2d73317ea132b59f9f-16e7223e25b645f3285465cecad79eaa69988183cc76bd52780a04e9496ddd80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikhail Katz")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-396117")[#strong[#text("Mikhail Katz")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("At first sight it seems as though ")#mi("\\mathbb R")#text(" will not have any ultraroot ")#mi("A")#text(" because the ultrapower of such an ")#mi("A")#text(" would necessarily contain infinite elements which are not to be found in ")#mi("\\mathbb R")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e6f8f2bb5eb2e164d382a08c9c55562160f62afd3805e9affb3caeb03122d15-a9d50eade842fff7563eeed2eb1528521d4a50b3b6dd2083cae36cea06a1a5b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Costas Drossos")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-396137")[#strong[#text("Costas Drossos")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("Take a diameter of poincare disk, (-n,n)\\cap R. then teke the ultralimits of this. then we have R! Then (-n,n)\\cap R. is the ultraroot of R.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e8714050c4cc43338ccabc5e3ff72ae04fa405170f512aca7511e4f4b1521757-972b0fb19263fe7a95ebc8b3a7a67d01a3c3d8bc7cad19a96dfeaad4d6e5057d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Two old-ish Terry Tao posts about model theory | sylvy's mathsy blog")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-461077")[#strong[#text("Two old-ish Terry Tao posts about model theory | sylvy's mathsy blog")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2015")])]

#text("[…] this which talks about nonstandard analysis, notions of `elementary convergence’ and `elementary […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplemental: Weak solutions from the perspective of nonstandard analysis (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-508599")[#strong[#text("254A, Supplemental: Weak solutions from the perspective of nonstandard analysis (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2018")])]

#text("[…] has similar properties to the standard one, but also some additional properties. As discussed in this previous post, the relationship between the standard universe and the nonstandard universe is somewhat […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-533870")[#strong[#text("Generalized Limit Expressed through Ultralimits | Victor Porton's Math Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2019")]

#text("[…] let me remind the definition of ultralimit as defined in the “standard” nonstandard […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-533873")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2019")])]

#text("A more general construction than ultralimits is described in ")#link("https://mathematics21.org/limit-of-discontinuous-function/")[#text("the mathematical monograph Limit of a Discontinuous Function")]#text(". My generalized limit is defined for ")#emph[#text("every")]#text(" (!) function. And unlike ultralimits, my generalized limit is a generalization of the traditional limit, in the sense that knowing a generalized limit, it is possible to restore the value (or the absence thereof) the traditional limit value.")

#text("From the announce of my book:")

#text("“No root of -1? No limit of discontinuous function?”")

#text("This book opens a new way to discontinuous calculus. The author succeeds to generalize limits for arbitrary discontinuous functions and proceeds to define non-differentiable solutions of differential equations. The book, “Limit of discontinuous function” not only discusses the foundations of infinitesimal calculus, but also simplifies the students’ grasp of the central concepts of discontinuity and mathematical nondifferentiable analysis. It starts with concepts of basic math, benefitting even novice students to do such things as to find simple solutions of calculations of infinite sums using author’s concept of generalized limit of discontinuous.")

#text("The author opens a door to a new world where functions aren’t just functions or analytical expressions; they illustrate profound concepts at a low level of complexity.")

#text("This book opens a new way to discontinuous calculus. The author succeeds to generalize limits for arbitrary discontinuous functions and proceeds to define non-differentiable solutions of differential equations. The book, “Limit of discontinuous function” not only discusses the foundations of infinitesimal calculus, but also simplifies the students’ grasp of the central concepts of discontinuity and mathematical nondifferentiable analysis. It starts with concepts of basic math, benefitting even novice students to do such things as to find simple solutions of calculations of infinite sums using author’s concept of generalized limit of discontinuous.")

#text("The author opens a door to a new world where functions aren’t just functions or analytical expressions; they illustrate profound concepts at a low level of complexity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-533875")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2019")])]

#text("Here (for the special case of compact spaces) my generalized limit is defined in elementary terms: ")#link("https://blog.mathematics21.org/2019/12/24/generalized-limit-expressed-through-ultralimits/")[#text("https://blog.mathematics21.org/2019/12/24/generalized-limit-expressed-through-ultralimits/")]#text(" (but to know the arbitrary case and more details read ")#link("https://mathematics21.org/limit-of-discontinuous-function/")[#text("my research monograph")]#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/674a384b74f1322ae2f2557e8b96d92d95a2876a99710d8235849ef0c11a910b-485143805f42f41670b052c1a79d29a7cb7c69f29b2862d6cd115605f8aec541.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of $0.99 and my one cent – Left Adjoint to Forgetful Thinking")]], [#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-626466")[#strong[#text("$0.99 and my one cent – Left Adjoint to Forgetful Thinking")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2021")])]

#text("[…] post I was (more than) a bit skeptical about the hyperreal numbers, but after reading around (e.g., Terence Tao’s blog on the subject), I’m realising how terribly naïve I am about it. I’m by no means an […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-687440")[#strong[#text("Infinitesimals and Nonstandard Analysis | Ketchup Spills")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2025")]

#text("[…] one should highlight the blog entry of Terry Tao on nonstandard analysis for a more technical […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/#comment-687526")[#strong[#text("Complex Numbers & Its Calculus | Equatorial Frequencies")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2025")]

#text("[…] of length or distance, to which will be considered as a metric space. As Terence Tao said in his blog post, it is in this respect that is the completion of […]")
]
