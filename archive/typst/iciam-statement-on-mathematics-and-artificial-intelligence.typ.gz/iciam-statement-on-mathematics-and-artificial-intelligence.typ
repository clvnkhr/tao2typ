// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/25/iciam-statement-on-mathematics-and-artificial-intelligence/
// Converted to Typst by tao2typ: "2026-10-14T16:39:34.213630+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "ICIAM Statement on Mathematics and Artificial Intelligence", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("ICIAM Statement on Mathematics and Artificial Intelligence")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/25/iciam-statement-on-mathematics-and-artificial-intelligence/")[#text("https://terrytao.wordpress.com/2026/09/25/iciam-statement-on-mathematics-and-artificial-intelligence/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Just a quick post to note that the ")#link("https://iciam.org/")[#text("International Council for Industrial and Applied Mathematics")]#text(" (ICIAM) has released a ")#link("https://iciam.org/news/26/9/24/iciam-statement-mathematics-and-artificial-intelligence")[#text("statement on mathematics and artificial intelligence")]#text(" (")#link("https://iciam.org/sites/default/files/2026-09/iciam%20statement_mathematics%20and%20ai_1.pdf")[#text("as well as a longer version")]#text("), which makes many points echoing several already made recently here and elsewhere.")

#text("The longer statement also makes reference to a recent ")#link("https://www.lms.ac.uk/news/navier-stokes-equations-breakthrough")[#text("statement by the London Mathematical Society")]#text(" on recent developments around the Navier-Stokes equation. Perhaps the comments to this post can also be used to report other institutional statements on these topics.")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/abb544e9e4012d51c43f0312703520dfdeeef958b677649fb0859769f59be27e-1911e9eb211777b5ef6b9a09b8e9eabaf83bb08d40068976a6057588c80f67d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adrian")]], [#link("https://terrytao.wordpress.com/2026/09/25/iciam-statement-on-mathematics-and-artificial-intelligence/#comment-696383")[#strong[#text("Adrian")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Now I do hate to trash-talk someone, but so far the significant developments of AI have all been counter-examples. In parallel to AI development, computational power has greatly improved, and even from what we are being told, it has been used to its fullest extent to locate these counter-examples.")

#text("In the interest of mathematical discovery, one has to ask the question whether the cost of the vast computational resources used up by AI are really a good investment when compared to human labour, which may be surprisingly cheap.")

#text("In fact, I know a mathematician who works for free, and who would work a lot better if he would merely be granted his human rights…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1644c7ada1fe9126712ff045feaa8f551fb55d85d7023f53c7d53b48d0c268d6-8bcc80eff677b687935f6f20ed89884887470a9adbe385af8acab1d6a2aee536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of phenomenal18e147ff2c")]], [#link("https://terrytao.wordpress.com/2026/09/25/iciam-statement-on-mathematics-and-artificial-intelligence/#comment-696393")[#strong[#text("phenomenal18e147ff2c")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("I made similar points before. AI is overselling by announcing that they “proved” so and so conjectures. As best as I understand, they are producing counter examples. Some in thsi blog would not make any distinction between proving a conjecture and producing a counter exaample.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/25/iciam-statement-on-mathematics-and-artificial-intelligence/#comment-696394")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("I don’t think that’s quite true. For example, the Ehrhart volume conjecture was a significant result that AI helped prove rather than refute. There is probably also some selection bias: a false conjecture can remain open precisely because mathematicians have spent decades trying to prove it rather than conducting enormous automated searches for counterexamples.")

#text("More importantly, mathematics is partly a testbed. Proofs and programs are unusually easy to verify, making math and coding natural environments for developing systems capable of longer reasoning, self-correction, and eventually increasingly autonomous improvement.")

#text("The cost comparison is also less obvious than it sounds. The Navier–Stokes effort reportedly used about 130 billion output tokens and 10,000 agents over 88 hours; outside estimates put the compute cost around $15M.")

#text("Suppose an expert mathematician costs $75–125/hour once salary, benefits, institutional overhead, etc. are included. $15M buys only about 120,000–200,000 human research hours, or roughly 60–100 full-time researcher-years. The AI experiment, by contrast, may have involved as much as 880,000 agent-hours, compressed into less than four days. That’s roughly $17 per nominal agent-hour at the $15M estimate. Obviously an agent-hour and a mathematician-hour aren’t equivalent, but it shows why “humans are cheaper” isn’t at all obvious.")

#text("And 130B tokens is an extraordinary search budget: using OpenAI’s rough English conversion, it corresponds mechanically to about 97.5 billion words of output. I wouldn’t pretend tokens can be converted directly into “human thinking hours,” but no human research group could generate or examine possibilities at that scale.")

#text("You can certainly argue that spending $15M to solve a $1M prize problem makes no economic sense if the objective is merely Navier–Stokes. I agree. But that’s not really the objective. The mathematics is a proving ground for building increasingly capable autonomous reasoning systems. If those systems improve, the cost can be amortized across essentially every intellectual task they are later used for.")

#text("And inference costs will keep falling. Today’s expensive frontier experiment can become tomorrow’s cheap model. So I don’t think current compute cost is a strong long-term objection.")

#text("There is a sad human aspect to this, but ignoring it won’t change the trajectory. The cat is out of the bag. If machines become substantially better than humans at some kinds of mathematical work, mathematics will inevitably reorganize around that fact.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/abb544e9e4012d51c43f0312703520dfdeeef958b677649fb0859769f59be27e-1911e9eb211777b5ef6b9a09b8e9eabaf83bb08d40068976a6057588c80f67d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adrian")]], [#link("https://terrytao.wordpress.com/2026/09/25/iciam-statement-on-mathematics-and-artificial-intelligence/#comment-696410")[#strong[#text("Adrian")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("Well, we have previously seen that the reasoning models choose “unconventional” tasks for optimising a target function. Humans have evolved for billions of years with the general aim of not destroying humanity (the carrier of its selfish genes), and that goal has so far been reached, despite all the trouble we do have.")

#text("The AI does not have that advantage. And if that leads to a catastrophe, the cat will be back in its bag in no time.")

#text("Also, the example you cited appears to be heavily based upon earliear work. And while that is true for much of human mathematics, I imagine AI to have sifted through large bodies of research problems in order to find those it can actually solve. Note in particular that AI solved only a part of the Ehrhart volume conjecture.")

#text("Does that mean that humans won’t loose out to machines? I don’t know, because no-one really knows what goes on inside these models, not even their own inventors.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1644c7ada1fe9126712ff045feaa8f551fb55d85d7023f53c7d53b48d0c268d6-8bcc80eff677b687935f6f20ed89884887470a9adbe385af8acab1d6a2aee536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of phenomenal18e147ff2c")]], [#link("https://terrytao.wordpress.com/2026/09/25/iciam-statement-on-mathematics-and-artificial-intelligence/#comment-696424")[#strong[#text("phenomenal18e147ff2c")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("Human mathematicians also teach. Although 40 percent of our job is supposed to be research, in reality our salary is mostly paid for teaching. ")#strong[#text("So, we are proving theorems for free")]#text(" (a hobby and a “test”). And, vast majority are working on their own programs, not on well known long standing conjectures. I do not see how AI will be able to find what I am working on, and quickly solve it to put me out oh job? AI can kill a billion people (as Bill Gates said), but it is not a threat to mathematics profession.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b2b8d6d9809fce8225eb505f6667f1ff87b81e2590ed87dc1757858c4554acc-e7346170e75d01c0c7ca9c695c4e20018907cbad54f078fcd00a0c3e8e3c2950.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cheesecakestupendousf90a258c3f")]], [#link("https://terrytao.wordpress.com/2026/09/25/iciam-statement-on-mathematics-and-artificial-intelligence/#comment-696412")[#strong[#text("cheesecakestupendousf90a258c3f")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("This statement gives me a direction. As a MPhi in Math, I want to find a job that applies math in industry.")

#text("Kind regards, Sishou My interests")#link("https://interests-davis.blogspot.com/2026/05/my-interests.html?m=1")[#text("https://interests-davis.blogspot.com/2026/05/my-interests.html?m=1")]#text(" ")#link("https://interests-davis.blogspot.com/2026/05/my-interests.html?m=1")[#text("https://interests-davis.blogspot.com/2026/05/my-interests.html?m=1")]#text(" ________________________________")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/25/iciam-statement-on-mathematics-and-artificial-intelligence/#comment-696425")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("Another statement, another case of missing the point, dodging the question, running in circles. The issue here is whether AI in math will lead to making math and society more ethical, more *right,* or less ethical, less *right.*")

#text("Is AI in math going to make more jobs? Better jobs? It must. Is it going to make math better for society? It must. It is so silly seeing such a smart community completely fall for thinking that their field exists in an ethics vacuum, that the only things that matter are “understanding.” No. To the extent that math exists in such a vacuum, it doesn’t matter!")

#text("The chief question isn’t about whether AI will lead to better math or better understanding. It’s so much bigger than that. Don’t you understand? Governments will happily close down professional mathematics funding in the age of AI if you don’t start staking a claim that *human* math is important for the betterment of society — and that AI will only make it moreso.")

#text("Don’t you get it? What do you see when you look at funding for liberal arts, journalism, and the humanities? This is the Hellfire you should be preoccupied with, not quibbles about what exactly AI in math is currently missing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1644c7ada1fe9126712ff045feaa8f551fb55d85d7023f53c7d53b48d0c268d6-8bcc80eff677b687935f6f20ed89884887470a9adbe385af8acab1d6a2aee536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of phenomenal18e147ff2c")]], [#link("https://terrytao.wordpress.com/2026/09/25/iciam-statement-on-mathematics-and-artificial-intelligence/#comment-696450")[#strong[#text("phenomenal18e147ff2c")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("You impatience is clear here. Math profession has many gaps like any other professions. It is not AI vs Math. AI spun out of Math.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1644c7ada1fe9126712ff045feaa8f551fb55d85d7023f53c7d53b48d0c268d6-8bcc80eff677b687935f6f20ed89884887470a9adbe385af8acab1d6a2aee536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of phenomenal18e147ff2c")]], [#link("https://terrytao.wordpress.com/2026/09/25/iciam-statement-on-mathematics-and-artificial-intelligence/#comment-696430")[#strong[#text("phenomenal18e147ff2c")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("I thought about the Jacobian conjecture. If you have that kind of infinite computing power, the counter example came out of simple enumerating the triples of polynomials ")#mi("(F_1, F_2, F_3)")#text(" in 3 variables, compute the Jacobian, and check the injectivity. Number of monomial of degree 3 in 3 variable are only a few. Some of you should think what it took to settle NC.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/25/iciam-statement-on-mathematics-and-artificial-intelligence/#comment-696443")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("that’s incorrect, read Tao’s post about that counterexample")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1644c7ada1fe9126712ff045feaa8f551fb55d85d7023f53c7d53b48d0c268d6-8bcc80eff677b687935f6f20ed89884887470a9adbe385af8acab1d6a2aee536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of phenomenal18e147ff2c")]], [#link("https://terrytao.wordpress.com/2026/09/25/iciam-statement-on-mathematics-and-artificial-intelligence/#comment-696446")[#strong[#text("phenomenal18e147ff2c")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("Can you give the link?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1644c7ada1fe9126712ff045feaa8f551fb55d85d7023f53c7d53b48d0c268d6-8bcc80eff677b687935f6f20ed89884887470a9adbe385af8acab1d6a2aee536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of phenomenal18e147ff2c")]], [#link("https://terrytao.wordpress.com/2026/09/25/iciam-statement-on-mathematics-and-artificial-intelligence/#comment-696465")[#strong[#text("phenomenal18e147ff2c")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("I read Tao’s post. It is certainly impressive, and mathematical argument. It does not explain how Levent A’s example is outside a miracle or a brute force checking.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1644c7ada1fe9126712ff045feaa8f551fb55d85d7023f53c7d53b48d0c268d6-8bcc80eff677b687935f6f20ed89884887470a9adbe385af8acab1d6a2aee536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of phenomenal18e147ff2c")]], [#link("https://terrytao.wordpress.com/2026/09/25/iciam-statement-on-mathematics-and-artificial-intelligence/#comment-696447")[#strong[#text("phenomenal18e147ff2c")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("The author of the counter example did not give any details (gave a 3-liner). So, nothing stops us from speculating. It is possible that the author did it in more completed way. I do not see, how with enough computing power, what I wrote can go wrong? He was clearly working with integer coefficients.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c468377144f25fa6779f0067feba68c953d8b299fe553b0f836174dd933947f-69e5c9ffeca36f03ef3737cb65abb5e04ed1efe89727aea1cd203170ab5fe878.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jimmy")]], [#link("https://terrytao.wordpress.com/2026/09/25/iciam-statement-on-mathematics-and-artificial-intelligence/#comment-696469")[#strong[#text("Jimmy")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("Statements like this matter less for their novelty than for their convergence: when ICIAM, the LMS, and individual mathematicians keep landing on the same cautions, that is a signal the community is settling on shared facts rather than competing talking points. The invitation to use the comments as a clearing house for other institutional statements is quietly the most useful part – coordination starts with a common list. It is the same pattern I rely on in a much smaller register with AI coding tools: usage limits and reset windows are discussed anecdotally everywhere, so I keep a small tracker of them at codexreset.today. Verified reference points, even narrow ones, seem to be a precondition for any calm discussion of capability and risk.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/25/iciam-statement-on-mathematics-and-artificial-intelligence/#comment-696478")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2026")])]

#text("Thank you, Claude!")
]
]
