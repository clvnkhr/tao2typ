// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/
// Converted to Typst by tao2typ: "2026-10-14T15:20:01.086357+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath15, second thread: generalising the Riemann-Siegel approximate functional equation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath15, second thread: generalising the Riemann-Siegel approximate functional equation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 February 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/")[#text("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is the second “research” thread of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("Polymath15 project")]#text(" to upper bound the ")#link("https://en.wikipedia.org/wiki/De_Bruijn%E2%80%93Newman_constant")[#text("de Bruijn-Newman constant")]#text(" ")#mi("{\\Lambda}")#text(", continuing ")#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/")[#text("this previous thread")]#text(". Discussion of the project of a non-research nature can continue for now in ")#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/")[#text("the existing proposal thread")]#text(". Progress will be summarised at ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("this Polymath wiki page")]#text(".")

#text("We now have the following proposition (see ")#link("http://michaelnielsen.org/polymath1/index.php?title=Dynamics_of_zeros")[#text("this page")]#text(" for a proof sketch) that looks like it can give a numerically feasible approach to bound ")#mi("{\\Lambda}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" Suppose that one has parameters ")#mi("{t_0, T, \\varepsilon > 0}")#text(" obeying the following properties:")

#list(
[#text("All the zeroes of ")#mi("{H_0(x+iy)=0}")#text(" with ")#mi("{0 \\leq x \\leq T}")#text(" are real.")],
[#text("There are no zeroes ")#mi("{H_t(x+iy)=0}")#text(" with ")#mi("{0 \\leq t \\leq t_0}")#text(" in the region ")#mi("{\\{ x+iy: x \\geq T; 1-2t \\geq y^2 \\geq \\varepsilon^2 + (T-x)^2 \\}}")#text(".")],
[#text("There are no zeroes ")#mi("{H_{t_0}(x+iy)=0}")#text(" with ")#mi("{x > T}")#text(" and ")#mi("{y \\geq \\varepsilon}")#text(".")]
)

#text("Then one has ")#mi("{\\Lambda \\leq t_0 + \\frac{1}{2} \\varepsilon^2}")#text(".")
]

#text("The first hypothesis is already known for ")#mi("{T}")#text(" up to about ")#mi("{10^{12}}")#text(" (we should find out exactly what we can reach here). Preliminary calculations suggest that we can obtain the third item provided that ")#mi("{t_0, \\varepsilon \\gg \\frac{1}{\\log T}}")#text(". The second hypothesis requires good numerical calculation for ")#mi("{H_t}")#text(", to which we now turn.")

#text("The initial definition of ")#mi("{H_t}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#mitex("H_t(z) := \\int_0^\\infty e^{tu^2} \\Phi(u) \\cos(zu)\\ du")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\Phi(u) := \\sum_{n=1}^\\infty (2\\pi^2 n^4 e^{9u} - 3\\pi n^2 e^{5u} ) \\exp(-\\pi n^2 e^{4u}).")]]

#text("This formula has proven numerically computable to acceptable error up until about the first hundred zeroes of ")#mi("{H_t}")#text(", but degrades after that, and so other exact or approximate formulae for ")#mi("{H_t}")#text(" are needed. One possible exact formula that could be useful is")

#align(center)[#tao-fit-display[#mitex("H_t(z) = \\frac{1}{2} (K_{t,\\theta}(z) + \\overline{K_{t,\\theta}(\\overline{z})})")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("K_{t,\\theta}(z) := \\sum_{n=1}^\\infty (2\\pi^2 n^4 I_{t,\\theta}(z-9i, \\pi n^2) - 3\\pi n^2I_{t,\\theta}(z-5i, \\pi n^2))")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("I_{t,\\theta}(b,\\beta) := \\int_{i\\theta}^{i\\theta+i\\infty} \\exp(tu^2 - \\beta e^{4u} + ibu)\\ du")]]

#text("and ")#mi("{-\\pi/8 < \\theta < \\pi/8}")#text(" can be chosen arbitrarily. We are still trying to see if this can be implemented numerically to give better accuracy than the previous formula.")

#text("It seems particularly promising to develop a generalisation of the ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93Siegel_formula")[#text("Riemann-Siegel approximate functional equation")]#text(" for ")#mi("{H_0}")#text(". ")#link("http://michaelnielsen.org/polymath1/index.php?title=Asymptotics_of_H_t")[#text("Preliminary computations")]#text(" suggest in particular that we have the approximation")

#align(center)[#tao-fit-display[#mitex("H_t(x+iy) \\approx \\frac{1}{4} (F_t(\\frac{1+ix-y}{2}) + \\overline{F_t(\\frac{1+ix+y}{2})})")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("F_t(s) := \\pi^{-s/2} \\Gamma(\\frac{s+4}{2}) \\sum_{n \\leq \\sqrt{\\mathrm{Im}(s)/2\\pi}} \\frac{\\exp( \\frac{t}{16} \\log^2 \\frac{s+4}{2\\pi n^2})}{n^s}.")]]

#text("Some very preliminary numerics suggest that this formula is reasonably accurate even for moderate values of ")#mi("{x}")#text(", though further numerical verification is needed. As a proof of concept, one could take this approximation as exact for the purposes of seeing what ranges of ")#mi("{T}")#text(" one can feasibly compute with (and for extremely large values of ")#mi("{T}")#text(", we will presumably have to introduce some version of the ")#link("https://en.wikipedia.org/wiki/Odlyzko%E2%80%93Sch%C3%B6nhage_algorithm")[#text("Odlyzko-Schönhage algorithm")]#text(". Of course, to obtain a rigorous result, we will eventually need a rigorous version of this formula with explicit error bounds. It may also be necessary to add more terms to the approximation to reduce the size of the error.")

#text("Sujit Nair has kindly summarised for me the current state of affairs with ")#link("https://github.com/km-git-acc/dbn_upper_bound")[#text("the numerics")]#text(" as follows:")

#text("—")

#list(
[#text("We need a real milestone and work backward to set up intermediate goals. This will definitely help bring in focus!")],
[#text("So far, we have some utilities to compute zeroes of ")#mi("{H_t}")#text(" with a nonlinear solver which uses roots of ")#mi("{H_0}")#text(" as an initial condition. The solver is a wrapper around MINPACK’s implementation of Powell’s method. There is some room for optimization. For example, we aren’t providing the solver with the analytical Jacobian which speeds up the computation and increases accuracy.")],
[#text("We have some results in the output folder which contains the first 1000 roots of ")#mi("{H_t}")#text(" for some small values of ")#mi("{t \\in \\{0.01, 0.1, 0.22\\}}")#text(", etc. They need some more organization and visualization.")]
)

#text("We have a decent initial start but we have some ways to go. Moving forward, here is my proposition for some areas of focus. We should expand and prioritize after some open discussion.")

#enum(start: 1, 
[#text("Short term Optimize the existing framework and target to have the first million zeros of ")#mi("{H_t}")#text(" (for a reasonable range of ")#mi("{t}")#text(") and the corresponding plots. With better engineering practice and discipline, I am confident we can get to a few tens of millions range. Some things which will help include parallelization, iterative approaches (using zeroes of ")#mi("{H_t}")#text(" to compute zeroes of ")#mi("{H_{t + \\delta t}}")#text("), etc.")],
[#text("Medium term We need to explore better ways to represent the zeros and compute them. An analogy is the computation of Riemann zeroes up to height ")#mi("{T}")#text(". It is computed by computing the sign changes of ")#mi("{Z(t)}")#text(" (page 119 of Edwards) and by exploiting the ")#mi("{\\sqrt {T}}")#text(" speed up with the Riemann-Siegel formulation (over Euler-Maclaurin). For larger values of ")#mi("{j}")#text(", I am not sure the root solver based approach is going to work to understand the gaps between zeroes.")],
[#text("Long term We also need a better understanding of the errors involved in the computation — truncation, hardware/software, etc.")]
)

#heading(level: 1)[#text("Comments (102)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492044")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("One medium-term numerical goal which would be helpful would be to gather some data regarding the accuracy of the Riemann-Siegel type approximations. When ")#mi("t=0")#text(", the error term in these approximations is about ")#mi("O(x^{-1/2})")#text(" times the main term; hopefully a similar accuracy is present for ")#mi("t>0")#text(" as well. If we are lucky, that is enough accuracy that it will be justifiable (for a preliminary pass at least) to pretend that the Riemann-Siegel expansion is in fact exact, and then try to control zeroes of that expansion at large height.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492062")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2018")])]

#text("I ran some quick tests using the original Riemann Siegel eqns (as implemented in Gourdon’s work), and checked the effect of using the first few error terms. As expected, the difference is significant and even the estimates of the smaller zeroes become much better. It would be great to have corresponding first few error terms for Ht.")

#text("Also, there seem to be practical considerations with the root finding algorithms using initial guesses. If there are many close roots in an interval, then it’s difficult to trivially control which root will the algorithm converge to. Which results in occasionally the algorithm converging to the same root from multiple nearby guesses, and missing a few in between. It can be dealt with by carefully and iteratively expanding the interval where a root should be searched for, till the algorithm finds a sign change.")

#text("But then it’s unclear whether this approach is less or more expensive than the original approach of simply evaluating H_t at close enough regularly spaced intervals and then counting the sign changes.")

#text("Will try out the counting approach between two large T heights for some t values.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492063")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2018")])]

#text("Oh, just noticed you have mentioned the root solving limitations in the last section.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492049")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2018")])]

#text("Perhaps Gauss-Legendre quadrature, a method in the family of Gaussian")#linebreak()#text(" quadrature methods, could be useful in obtaining a few high-accuracy values of H_t(z), for example to validate other computation methods. A reference at Wikipedia: ")#link("https://en.wikipedia.org/wiki/Gaussian_quadrature")[#text("https://en.wikipedia.org/wiki/Gaussian_quadrature")]#text(" .")

#text("I experimented with trying to compute H_0 (2*z_100), where z_100 is the")#linebreak()#text(" imaginary part of the 100th zeta zero, using the first exact formula. Using 5120 intervals of equal lengths, a length of 1/1600 as it turns out, and a 100-point Gauss-Legendre method on each interval, the command in PARI/gp returned a numerical value of roughly 1 E-156 after 31 minutes. For comparison, H_0 (2*z_100 + 1) returns roughly 9.9 E-60, much larger than at 2*z_100; this is to be expected if the integration of the very oscillatory H_0 function is highly accurate, since 2*z_100 is a zero of H_0 .")

#text("I should add that I’ve only used Gaussian quadrature methods on a couple of occasions, and that it’s new to me…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492073")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2018")])]

#text("I find that the Gauss-Legendre method using a 400-point rule and 32 intervals of length 1/16 delivers the same accuracy as above in computing H_0(2*z_100), but in only 15 seconds. This includes the time spent initializing the tables of weights and abscissas for the 400-point Gauss-Legendre rule.")

#text("For illustration and reference, the PARI/gp command entered is copied below:")

#text("intnumgaussinit(400);")#linebreak()#text(" s = 0.0; x=2*z100 ;")#linebreak()#text(" for(J=0,32, s=s+intnumgauss(X=J/16,(J+1)/16, Phi(X)*cos(x*X),));")#linebreak()#text(" s")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492064")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2018")])]

#text("A possible approach for such approximation to ")#mi("H_t(z)")#text(" is to use its Taylor series in powers of ")#mi("t")

#mi("H_t(z) = \\sum_{n \\geq 0} a_n(z) t^n")

#text("Where ")#mi("a_n(z) := (1/ n!) \\int_0^{\\infty} u^{2 n} \\Phi (u) \\cos (z u) du")

#text("Since ")#mi("a_0(z) = H_0(z)")#text(", and ")#mi("H_t(z)")#text(" is entire (in both ")#mi("z")#text(" and ")#mi("t")#text("), the Taylor coefficients ")#mi("a_n(z)")#text(" (which are entire functions) are super exponentially decaying, so in order to estimate ")#mi("H_t(z)")#text(" by truncating its Taylor series, the required number of terms should depend on the required precision ")#mi("\\delta")#text("(say), ")#mi("z")#text(" and ")#mi("t")#text(" and is expected to be roughly proportional to ")#mi("\\log (1/ \\delta) / \\log (1/t)")#text(".")#linebreak()#text(" It seems that the asymptotic approximations of ")#mi("a_n(z)")#text(" (via their defining integrals) should be similar to that of ")#mi("a_0(z)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492066")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2018")])]

#text("From the integral representation of ")#mi("a_n(z)")#text(" (or directly from the backwards heat equation for ")#mi("H_t(z)")#text("), it follows that")

#mi("a_n(z) = (-1/n) a_{n-1}^{\\prime\\prime}(z)")#text(" , ")#mi("n \\geq 1")

#text("So it seems that the asymptotic expansions of the coefficients ")#mi("a_n(z)")#text(" can be computed recursively from that of ")#mi("a_0(z) = H_0(z)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492077")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2018")])]

#text("This approach can be used for each given disk ")#tao-math("\\left|z - z_0\\right| \\leq r", block: false)#text(" with an explicit analytic approximation ")#mi("F_(z)")#text(" of ")#mi("H_0(z)")#text(" and with explicit (uniform) upper bound ")#mi("M(E)")#text(" on the magnitude of the approximation error ")#mi("E = H_0 - F")#text(" on the given disk, to derive for each (complex) ")#mi("t")#text(" an explicit analytic approximation ")#mi("F_t(z)")#text(" to ")#mi("H_t(z)")#text(" with an explicit (uniform) bound ")#mi("M(E_t)")#text(" on the magnitude of the approximation error ")#mi("E_t = H_t - F_t")#text(" on the given disk as follows:")#linebreak()#text(" Using Taylor series expansion for ")#mi("H_t(z)")#text(", with the coefficients")

#mi("a_n(z) = ((-1)^n / n!) H_0^{2 n}(z)")

#text("It is natural to approximate them (replacing ")#mi("H_0")#text(" by ")#mi("F")#text(") and truncate the resulting series to ")#mi("N")#text(" terms, giving")

#mi("F_t(z) := \\sum_{n < N} b_n(z) t^n")

#text("where ")#mi("b_n(z) = ((-1)^n / n!) F^{2 n}(z)")

#text("Note that ")#mi("F_0(z) = F(z)")#text(" and the coefficients ")#mi("b_n")#text(" can be computed recursively (for ")#mi("n = 0, ..., N-1")#text(") using the same recursive relation of ")#mi("a_n")#text(" above.")

#text("The bound ")#mi("M(E_t)")#text(" follows from Cauchy estimates for the coefficients ")#mi("a_n(z)")#text(" and ")#mi("b_n(z)")#text(" (as derivatives of ")#mi("H_0(z), F(z)")#text("), giving")

#mi("M(E_t) \\leq \\sum_{n < N} [(t^n / n!) (2 n)! M(E) / r^{2 n}]")

#mi("+ \\sum_{n \\geq N} [(t^n / n!) (2 n)! M(H_0) / r^{2 n}]")

#text("Where ")#mi("M(H_0)")#text(" is an upper bound on ")#tao-math("\\left|H_0\\right|", block: false)#text(" in the given disk which is upper bounded by ")#mi("M(F) + M(E)")#text(".")

#text("Remark: It seems that for each given ")#mi("z, t")#text(", one may take the disk center ")#mi("z_0 = z")#text(", but the disk radius ")#mi("r")#text(" and the number of terms ")#mi("N")#text(" should be optimized (to minimize ")#mi("M(E_t)")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492078")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2018")])]

#text("Correction: in the expressions above for the coefficients ")#mi("a_n(z),  b_n(z)")#text(", the repeated derivatives ")#mi("H_0^{2 n}(z), F^{2 n}(z)")#text(" should be ")#mi("H_0^{(2 n)}(z), F^{(2 n)}(z)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492079")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2018")])]

#text("I just realized that unfortunately, Cauchy derivatives estimates used for the bound are not sufficient (the second sum diverges). The approximant ")#mi("F_t")#text(" may (hopefully) still be useful, but it seems that a better local estimates for the of magnitude of the derivatives of ")#mi("H_0")#text(" are required for a rigorous bound.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492085")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2018")])]

#text("Michael Rubinstein has a gzipped file with the first 35,161,820 zeros of the Riemann zeta function, as described in the Readme at: ")#link("http://oto.math.uwaterloo.ca/~mrubinst/L_function_public/ZEROS/Readme.txt")[#text("http://oto.math.uwaterloo.ca/~mrubinst/L_function_public/ZEROS/Readme.txt")]#text(" . The zipped file zeros_0001_35161820.gz is in the directory: ")#link("http://oto.math.uwaterloo.ca/~mrubinst/L_function_public/ZEROS/DEGREE_1/")[#text("http://oto.math.uwaterloo.ca/~mrubinst/L_function_public/ZEROS/DEGREE_1/")]#text(" .")#linebreak()#text(" He’s also the author of “l-calc”, an L-function calculator, described in")#linebreak()#text(" “Software” at ")#link("http://oto.math.uwaterloo.ca/~mrubinst/L_function_public/L.html")[#text("http://oto.math.uwaterloo.ca/~mrubinst/L_function_public/L.html")]#linebreak()#text(" In the past, I’ve succeeded in building lcalc from source code using “make” in Linux, but today the “build” process encountered a bug/error.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492088")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2018")])]

#text("I changed one line in the Makefile, so as to use the System/Distribution C++ compiler originating from Red Hat. With that modification, the build process using the “make” command completed without a hitch, and as administrator/root, I installed lcalc.")

#text("lcalc is very fast: for roughly 12 significant figures, it computes one million Riemann zeta zeros in just over 5 minutes. I’m now running lcalc to compute the first 10 million zeros.")#linebreak()#text(" The command and output at the prompt for 1 million zeros were:")

#text("$ time lcalc –zeros=1000000 > /dev/null")

#text("real 5m8.578s")#linebreak()#text(" user 4m55.946s")#linebreak()#text(" sys 0m0.758s")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492114")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2018")])]

#text("The command:")#linebreak()#text(" $ time lcalc -zeros=10000000 > /dev/null ,")#linebreak()#text(" which computes the first 10,000,000 zeros of zeta, then redirects the output to “trash” instead of displaying it on the terminal, took about 2 hours to finish.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92de18753b09812cfe78cbce04b76697dc7573ea3c4722016f2b8a9b4502f3a4-5e12eff0f87d0e218c957596559df00bf9c36b15eba61d0bb1667c6f3b57e4e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit Nair")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492096")[#strong[#text("Sujit Nair")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2018")])]

#text("Terry, the right side of ")#mi("F_t(s)")#text(" doesn’t make sense if ")#mi("s = x + iy")#text(".")

#text("It took some fiddling around (and going over the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Asymptotics_of_H_t")[#text("asymptotics page")]#text(") for me to realize that ")#mi("s = \\frac{1+ix-y}{2}")#text(".")

#text("Maybe you should define ")#mi("s")#text(" before the expression for ")#mi("F_t(s)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492097")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2018")])]

#text("Actually to evaluate ")#mi("H_t(x+iy)")#text(" one has to evaluate ")#mi("F_t")#text(" at two values of ")#mi("s")#text(", ")#mi("s = \\frac{1+ix-y}{2}")#text(" and ")#mi("s = \\frac{1+ix+y}{2}")#text(" (see the equation before the definition of ")#mi("F_t(s)")#text("). So I would prefer to think of ")#mi("s")#text(" as an independent variable rather than as a quantity defined in terms of ")#mi("x")#text(" and ")#mi("y")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92de18753b09812cfe78cbce04b76697dc7573ea3c4722016f2b8a9b4502f3a4-5e12eff0f87d0e218c957596559df00bf9c36b15eba61d0bb1667c6f3b57e4e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit Nair")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492099")[#strong[#text("Sujit Nair")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2018")])]

#text("If that is the case, shouldn’t the summation limit in ")#mi("F_t(s)")#text(" be in terms of ")#mi("s")#text(". Right now, it is ")#mi("\\sqrt{x/4\\pi}")#text("?")

#text("I am trying to recover Riemann-Siegel for ")#mi("H_0(x)")#text(" and it is stumping me.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92de18753b09812cfe78cbce04b76697dc7573ea3c4722016f2b8a9b4502f3a4-5e12eff0f87d0e218c957596559df00bf9c36b15eba61d0bb1667c6f3b57e4e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit Nair")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492100")[#strong[#text("Sujit Nair")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2018")])]

#text("Ah. I think I got it.")

#text("So you mean ")#mi("\\sqrt{\\Re(s) /4\\pi}")#text(" in the summation limit on the right side?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92de18753b09812cfe78cbce04b76697dc7573ea3c4722016f2b8a9b4502f3a4-5e12eff0f87d0e218c957596559df00bf9c36b15eba61d0bb1667c6f3b57e4e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit Nair")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492101")[#strong[#text("Sujit Nair")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2018")])]

#text("Actually, this won’t work. For example, computing ")#mi("H_0(x)")#text(" would require computing ")#mi("F_0(\\frac{1+ix}{2})")#text(". In this case, ")#mi("\\sqrt{\\Re(s)/4\\pi} = \\sqrt{1/8\\pi} < 1")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492116")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2018")])]

#text("In my PARI/gp code for ")#mi("F_{t}(s)")#text(" , I put ")#mi("Im(s)/2\\pi")#text(" where your expression had ")#mi("x/4\\pi")#text(" : ")#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491988")[#text("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491988")]#text(" .")#linebreak()#text(" Hopefully, this substitution was correct for the purpose of computing ")#mi("H_{t}")#text(" .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492117")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2018")])]

#text("Yes, one should have ")#mi("\\mathrm{Im}(s)/2\\pi")#text(" instead of ")#mi("x/4\\pi")#text(" there. I’ll edit the text accordingly.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492111")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2018")])]

#text("On running the approx functional eqn (Ht_AFE for brevity) for t=0 between heights T=50000 to 100000 (H_0 has 34517 actual zeros in this range), we get these results")

#text("T range———–detected—not—–actual—-% not detected")#linebreak()#text(" 50000-60000——6613——58—–6671——-0.87%")#linebreak()#text(" 60000-70000——6773——30—–6803——-0.44%")#linebreak()#text(" 70000-80000——6869——50—–6919——-0.72%")#linebreak()#text(" 80000-90000——6969——48—–7017——-0.68%")#linebreak()#text(" 90000-100000—-7053——-54—-7107——–0.76%")#linebreak()#text(" Total—————34277——240—34517——-0.70%")

#text("Whenever zeros were not detected they came in pairs, for eg.")

#text("Ht_AFE root–Actual root")#linebreak()#text(" 54677.865—-54677.8535")#linebreak()#text(" 54680.645—-54680.66596")#linebreak()#text(" ——————54681.9331")#linebreak()#text(" ——————54682.27354")#linebreak()#text(" 54684.085—-54684.04412")#linebreak()#text(" 54685.165—-54685.18586")

#text("Instead near the undetected ones, Ht_AFE came close to the origin and flipped back forming a local minima or maxima, which I think is due to these zeros being close by. In a plot of actual H_0, its likely the function just crosses the origin before going back.")

#text("The computations are being done using a multiprecision library mpmath using 30 significant digits, hence I checked if increasing the precision in this region to 100 digits would help. Using a bisection solver")

#text("Solving Ht_AFE between 54679.0 and 54681 -> 54680.642507114… as expected")#linebreak()#text(" Solving Ht_AFE between 54681.0 and 54683 -> 54681.0000000000…")#linebreak()#text(" Solving Ht_AFE between 54680.65 and 54684.08 -> 54680.650000….")#linebreak()#text(" the last two instances showing the solver sticks to the endpoint of the given interval. Similar behavior was observed at another such pair.")

#text("I will now run the same exercise at T>2000000, and check the behavior there. As indicated by the AFE formula, Its likely that beyond a certain height such pairs will be either rare or non-existent, as Ht_AFE simulates H_t with higher precision.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92de18753b09812cfe78cbce04b76697dc7573ea3c4722016f2b8a9b4502f3a4-5e12eff0f87d0e218c957596559df00bf9c36b15eba61d0bb1667c6f3b57e4e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit Nair")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492131")[#strong[#text("Sujit Nair")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2018")])]

#text("KM, mpmath is a good find!")

#text("I assume you are still using the root solver to detect, right?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492139")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("From a numerical viewpoint, If there is a cluster of closely packed zeros of a function ")#mi("f(z)")#text(", a fast local root solver based on Newton-Raphson algorithm (")#mi("z_{k+1} = z_k - f(z_k) / f^{\\prime}(z_k)")#text(") is expected to show such erratic behavior (because the increment ")#mi("- f(z_k) /f ^{\\prime}(z_k)")#text(" can be very large if ")#mi("z_k")#text(" is very close to a local maximizer of ")#tao-math("\\left|f(z)\\right|", block: false)#text(" on the real axis – inside the zeros cluster).")

#text("A possible solution is to limit the increment magnitude")#linebreak()#text(" ")#tao-math("\\left|z_{k+1} - z_k\\right|", block: false)#text(" to be at most ")#mi("1")#text("(say), and then to verify that ")#tao-math("\\left|f(z_{k+1})\\right| \\leq  \\left|f(z_k)\\right|", block: false)#text(" (e.g. by dividing the increment by a suitable power of ")#mi("2")#text("). The resulting monotonicity of ")#tao-math("\\left|f(z_k)\\right|", block: false)#text(" ensures convergence of ")#mi("z_k")#text(" to a local minimizer of ")#tao-math("\\left|f(z)\\right|", block: false)#text(" (on the real axis). If complex increments are allowed, then (obviously) if ")#mi("f(z)")#text(" is analytic, any local minimizer of ")#tao-math("\\left|f(z)\\right|", block: false)#text(" must be a zero of ")#mi("f")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492161")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("I think using root solving approaches with closely packed zeroes is feasible if done carefully, as you laid out. What also should be considered while doing this is that the zero density gradually increases with T, and the gaps between zeroes can sometimes be much smaller than average gaps in that region.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492151")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("No, this is based on evaluating the function for each z with step size of 0.01, and then counting the sign changes..the intervals have to become finer for larger heights (I am using 0.002 for the T>2 mn exercise). Currently the zero location is taken as the midpoint of an interval where a sign change took place.")

#text("The bisection solver was only used to investigate further where a zero pair had been missed. I think such solvers in general can also be used to find the exact roots in the intervals with detected sign changes (thus improving upon the midpoint estimate). The counting method and the solver approach are then complementary.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92de18753b09812cfe78cbce04b76697dc7573ea3c4722016f2b8a9b4502f3a4-5e12eff0f87d0e218c957596559df00bf9c36b15eba61d0bb1667c6f3b57e4e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit Nair")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492159")[#strong[#text("Sujit Nair")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("Got it. Is there a branch for this on github? I didn’t see any after a “git fetch”.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492162")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("Well these were some adhoc loops, repeatedly calling the AFE function and recording the output on my PC. I will upload whatever I have as a separate branch.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492160")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("Platt’s recent paper (Math. comp. 86(2017), 2449-2467)")#linebreak()#text(" ")#link("https://doi.org/10.1090/mcom/3198")[#text("https://doi.org/10.1090/mcom/3198")]

#text("Describes an efficient (using FFT) algorithm for the computation of more than ")#mi("10^{11}")#text(" first Zeta zeros with (rigorous) absolute precision of ")#mi("10^{-30}")#text(". Is it possible to extend this algorithm for a large-scale, high-precision computation of ")#mi("H_t")#text(" zeros?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492164")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("Thanks for the link. Well having a FFT version to compute the AFE at many simultaneous points would be cool. The single point evaluations have become quite slow at larger heights.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492126")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2018")])]

#text("I’m trying to set up a numerical integration expression for the second exact formula in the post for ")#mi("H_0(2 Im(\\rho_{1}))")#text(", where ")#mi("\\rho_{1}")#text(" is the first non-trivial zero of zeta.")#linebreak()#text(" I tried the same expression with realprecision = 150, and with realprecision = 200. I get respectively roughly 4 e-29 and 1 e-38.")#linebreak()#text(" This puzzles me, and I’m wondering if it could be that the integrand takes on large values, but I haven’t looked into that.")

#text("For reference, the PARI/gp code, along with the output for realprecision = 200 digits are copied below.")

#text("z=2*z1;")#linebreak()#text(" t=0.0;")#linebreak()#text(" thet=Pi/8 – 1/(4*z);")#linebreak()#text(" K=0.0;")#linebreak()#text(" for(Y=1, 80, b=z-9*I;")#linebreak()#text(" beta=Pi*Y^2;")#linebreak()#text(" K=K+2*Pi*Pi*(Y^4)*sum(J=0,64, intnumgauss(X=J/16, (J+1)/16, exp( t*(X+I*thet)^2 – beta*exp(4*(X+I*thet)) + I*b*(X+I*thet)), ) ) ;")#linebreak()#text(" b = z-5*I;")#linebreak()#text(" K=K – 3*Pi*(Y^2)*sum(J=0,64, intnumgauss(X=J/16, (J+1)/16, exp( t*(X+I*thet)^2 – beta*exp(4*(X+I*thet)) + I*b*(X+I*thet)), ) ) );")#linebreak()#text(" print( real((K+conj(K)))/2)")

#text("Output:")#linebreak()#text(" 1.08 E-38 // realprecision = 200 digits")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492128")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2018")])]

#text("I used the first formula for ")#mi("K_{t,\\theta}(z)")#text(" after equation (2) [ 1st thread ] to evaluate numerically ")#mi("H_0(2Im(\\rho_{1}))")#text(" .")

#text("Among the (numerical) expressions in the first thread springing from (2) to (3), it’s the one with value closest to zero.")

#text("Phi(X) = sum(Y=1, 50, (2*Pi*Pi*(Y^4)*exp(9*X) -3*Pi*(Y^2)*exp(5*X))*exp(-Pi*(Y^2)*exp(4*X)))")

#text("intnumgaussinit(800); // 800-point Gauss-Legendre method")

#text("realprecision = 154 significant digits")

#text("For the PARI/gp numerical integration code:")

#text("z=2*z1;")#linebreak()#text(" t=0.0;")#linebreak()#text(" thet=Pi/8 – 1/(4*z);")#linebreak()#text(" K=0.0;")#linebreak()#text(" for(J=0, 256 , K=K+intnumgauss(X=J/128, (J+1)/128, Phi(X+I*thet)*exp(I*z*(X+I*thet)) ));")#linebreak()#text(" print( real((K+conj(K)))/2)")

#text("output:")#linebreak()#text(" 1.809 E-127")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492141")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("It seems at first glance as though the real/imaginary parts of the integrand ")#mi("H_{0,\\theta}")#text(" might decay more rapidly when ")#mi("\\theta = 0")#text(" than when ")#mi("\\theta = \\pi/8 - \\epsilon")#text(" …")#linebreak()#text(" Below, there is some data on the real part of the integrand for the choice ")#mi("\\theta = 0")#text(":")

#text("z=2*z1;")#linebreak()#text(" t=0.0;")#linebreak()#text(" thet=0.0;")#linebreak()#text(" for(J=0, 16 ,X=J/16.0;")#linebreak()#text(" K=real(Phi(X+I*thet)*exp(I*z*(X+I*thet)) );")#linebreak()#text(" print(X,” “, K))")

#text("0.00000000000000000000 0.4466969004671234441")#linebreak()#text(" 0.06250000000000000000 -0.07506099482654958609")#linebreak()#text(" 0.1250000000000000000 -0.2247326399152970553")#linebreak()#text(" 0.1875000000000000000 0.05928707622660076264")#linebreak()#text(" 0.2500000000000000000 0.02137269899984563796")#linebreak()#text(" 0.3125000000000000000 -0.004075283488938568051")#linebreak()#text(" 0.3750000000000000000 -0.0001521228758848166709")#linebreak()#text(" 0.4375000000000000000 1.281421125067103168 E-5")#linebreak()#text(" 0.5000000000000000000 3.364341936999641644 E-10")#linebreak()#text(" 0.5625000000000000000 -3.299802452045272008 E-10")#linebreak()#text(" 0.6250000000000000000 4.775197762416083978 E-14")#linebreak()#text(" 0.6875000000000000000 3.527315493478114852 E-18")#linebreak()#text(" 0.7500000000000000000 -4.571153262716285137 E-24")#linebreak()#text(" 0.8125000000000000000 -1.053342402347743622 E-31")#linebreak()#text(" 0.8750000000000000000 3.104515713884114793 E-41")#linebreak()#text(" 0.9375000000000000000 1.738363069214473369 E-54")#linebreak()#text(" 1.000000000000000000 -5.101940498958935872 E-70")

#text("? z")#linebreak()#text(" %101 = 28.26945028346938758")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92de18753b09812cfe78cbce04b76697dc7573ea3c4722016f2b8a9b4502f3a4-5e12eff0f87d0e218c957596559df00bf9c36b15eba61d0bb1667c6f3b57e4e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit Nair")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492158")[#strong[#text("Sujit Nair")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("KM, David,")

#text("Here is some feedback from ")#link("http://fredrikj.net/")[#text("Fredrik Johansson")]#text(" (main author of mpmath) to compute ")#mi("H_t")#text(" with arbitrary precision.")

#text("——————-")

#text("I was going to recommend implementing the function H_t using Arb (")#link("http://arblib.org/")[#text("http://arblib.org/")]#text("). This will be a bit more complicated to code for than mpmath, but it should be much faster, and it will allow obtaining rigorous error bounds.")

#text("I recently added code for rigorous numerical integration ")#link("http://fredrikj.net/blog/2017/11/new-rigorous-numerical-integration-in-arb/")[#text(" which is described here")]

#text("This is using a rigorous, adaptive version of Gauss-Legendre quadrature which should be quite efficient for the type of integrand defining H_t, although there could be some subtleties in practice.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492165")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("Thanks, will try it out.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492168")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("Thanks, this is encouraging news.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492174")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("An adaptive version of Gauss-Legendre quadrature seems particularly appropriate, at least for ")#mi("H_0")#text(", since the integrand decreases extremely rapidly on e.g. the interval [0,2],")#linebreak()#text(" cf.:")#linebreak()#text(" ")#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492141")[#text("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492141")]#text(" .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492171")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("There are two references regarding the Riemann-Siegel formula that I’d like to mention as possibly relevant: the first is Chapter 7 of Edwards’ book, and the second is Chapter 3 of Glen Pugh’s Master’s Thesis at the University of British Columbia, available from the link ")#link("https://web.viu.ca/pughg/thesis.d/masters.thesis.pdf")[#text("https://web.viu.ca/pughg/thesis.d/masters.thesis.pdf")]#text(" .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492176")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("Thanks for this! I am in the process of extending the Riemann-Siegel formula to ")#mi("H_t")#text(" and trying to compute the next term in the asymptotic expansion. I now see that the main term should only have an accuracy of ")#mi("O(x^{-1/4})")#text(" (I had previously thought it was ")#mi("O(x^{-1/2})")#text(") and so a first correction term will probably be needed (which would improve the accuracy to a much more tolerable ")#mi("O(x^{-3/4})")#text("). It is unfortunately a bit of a mess though and I have already caught a number of sign errors etc. in my calculations, but Pugh’s thesis will be a good cross-check. (I have some partial computations on the wiki at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Asymptotics_of_H_t")[#text("http://michaelnielsen.org/polymath1/index.php?title=Asymptotics_of_H_t")]#text(" right now, but it is not yet completed.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492180")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("A side qiestion. Looking at the (impressive) asymptotic expansions and error estimations I wonder if this part could also be automated (a la Zeilberger-Wilf etc.). and not just the numerical work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6525d7cd9db10f0f8b9a18fa0e62f21ac78916ee3eed4debea5956daeaf030-72219f07d23f0f1bc893af77a76e1cfd99cff0d2c3626a52796f2e15ac6c7e88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492192")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2018")])]

#text("This sounds very interesting, could you please elaborate a bit more on this?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492182")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("OK, my preliminary computations suggest that a refined asymptotic expansion for ")#mi("H_t(x+iy)")#text(" is")

#mi("H_t(x+iy) \\approx A+B+C")

#text("[EDIT: This should be ")#mi("A+B-C")#text("] where")

#mi("\\displaystyle A := \\frac{1}{8} \\frac{s(s-1)}{2} \\pi^{-s/2} \\Gamma(\\frac{s}{2}) \\sum_{n=1}^N \\frac{\\exp( \\frac{t}{16} \\log^2 \\frac{s+4}{2\\pi n^2} )}{n^s}")#linebreak()#text(" ")#mi("\\displaystyle B := \\frac{1}{8} \\frac{s(s-1)}{2} \\pi^{-(1-s)/2} \\Gamma(\\frac{1-s}{2}) \\sum_{m=1}^M \\frac{\\exp( \\frac{t}{16} \\log^2 \\frac{5-s}{2\\pi m^2} )}{m^{1-s}}")#linebreak()#text(" ")#mi("\\displaystyle C:= \\frac{1}{8} \\frac{s(s-1)}{2} \\pi^{-s/2} \\Gamma(\\frac{s}{2}) \\frac{\\Gamma(1-s)e^{-i\\pi s}}{2\\pi i} (2\\pi iM)^{s-1} \\times")#linebreak()#text(" ")#mi("\\displaystyle \\times \\exp( - \\frac{t\\pi^2}{64} ) \\Psi( \\frac{s}{2\\pi i M}-N )")#linebreak()#text(" where ")#mi("s := \\frac{1+ix-y}{2}")#text(", ")#mi("N,M")#text(" are integers with ")#mi("N,M = \\sqrt{\\frac{x}{4\\pi}} + O(1)")#text(" (for instance one can set ")#mi("N = M = \\lfloor \\sqrt{x/4\\pi}\\rfloor")#text(" if one wishes), one uses the standard branch of the logarithm throughout, and ")#mi("\\Psi")#text(" is the function")

#mi("\\Psi(\\alpha) := 2\\pi \\frac{\\cos(\\pi(\\alpha^2/2 - \\alpha - 1/8))}{\\cos(\\pi \\alpha)} \\exp( \\frac{i\\pi}{2} \\alpha^2 - \\frac{5 \\pi i}{8} ).")

#text("This refines the previous approximation, which was essentially ")#mi("H_t(x+iy) \\approx A+B")#text(". Roughly speaking, the first term ")#mi("A")#text(" should be of size ")#mi("e^{-\\pi x/8} x^{(7-y)/4} \\exp( t \\log^2 x )")#text(", the second term ")#mi("B")#text(" should be of size ")#mi("e^{-\\pi x/8} x^{(7+y)/4} \\exp( t \\log^2 x )")#text(" (and become dominant once ")#mi("y")#text(" is significantly larger than ")#mi("1/\\log x")#text("), and the final term ")#mi("C")#text(" should be of size ")#mi("e^{-\\pi x/8} x^{6/4}")#text(", with the error being of the order of ")#mi("e^{-\\pi x/8} x^{4/4}")#text(" (plus perhaps another error of size ")#mi("e^{-\\pi x/8} x^{3/4} \\exp( t \\log^2 x )")#text(" that becomes relevant when ")#mi("t")#text(" is much larger than ")#mi("1/\\log x")#text(").")

#text("The function ")#mi("\\Psi")#text(" looks strange, but can also be defined as the unique solution to the functional equations")#linebreak()#text(" ")#mi("\\Psi(\\alpha) = 2\\pi i - e^{-2\\pi i \\alpha} \\Psi(\\alpha+1)")#linebreak()#text(" ")#mi("\\Psi(\\alpha+1)-\\Psi(\\alpha) = \\frac{2\\pi}{\\sqrt{i}} \\exp(i \\pi \\alpha^2)")

#text("and is also given by a contour integral")

#mi("\\Psi(\\alpha) = \\int_C \\frac{\\exp( \\frac{iz^2}{4\\pi} + \\alpha z )}{e^z-1}\\ dz")

#text("where ")#mi("C")#text(" is for instance the contour ")#mi("t \\mapsto \\pi i - (1-i) t")#text(" for ")#mi("-\\infty < t < \\infty")#text(".")

#text("The formula is messy, but can be simplified a little (up to lower order terms) by using the Stirling approximation and collecting some terms. An interesting feature is that one can modify ")#mi("N")#text(" and ")#mi("M")#text(" by ")#mi("O(1)")#text(" without making significant changes to the final approximation, although some of the individual terms in that approximation would change. (This is one way to check that all the signs etc. in the above approximation are accurate.) If one sets ")#mi("t=0")#text(" and ")#mi("y=0")#text(" then one essentially recovers the classical Riemann-Siegel asymptotics (after extracting the main term of the remainder and discarding the rest).")

#text("I will try to write up a rigorous proof of this approximation with an error term (using ")#mi("O()")#text(" notation with unspecified constants for now, since putting in explicit constants, while ultimately necessary, will make the derivation far more messier). (I started the computations on the wiki but they are unfinished and not properly organised, I will probably end up rewriting it.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492183")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("Another function ")#mi("\\Phi")#text(" is already used in the definition of ")#mi("H_t")#text(".")

#emph[#text("[Good point; I’ve renamed it ")#mi("\\Psi")#text(" for now. -T.]")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492206")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2018")])]

#text("In the sub-page on ")#mi("H_t")#text(" asymptotics, the letter ")#mi("t")#text(" denotes also the imaginary part of ")#mi("s")#text(".")

#emph[#text("[Changed to ")#mi("T")#text(" – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492189")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("I started writing the various formulae , mainly as functions of ")#mi("s")#text(", in PARI/gp.")#linebreak()#text(" It finds a sign change in ")#mi("Re(H_{0})")#text(" near ")#mi("x=30")#text(", ")#mi("y=0")#text(", which looks questionable.")#linebreak()#text(" I figure I’ll take another look at these formulae later.")

#text("Function definitions:")

#text("ga =")#linebreak()#text(" (S)->S*(S-1)*exp(-S*log(Pi)/2)*gamma(S/2)/16")

#text("gb =")#linebreak()#text(" (S)->S*(S-1)*exp((S-1)*log(Pi)/2)*gamma((1-S)/2)/16")

#text("M =")#linebreak()#text(" (S)->floor(sqrt(imag(S)/(2*Pi)))")

#text("A =")#linebreak()#text(" (S)->ga(S)*sum(Y=1,M(S),exp((t/16)*(log((S+4)/(2*Pi*(Y^2)))^2))*exp(-S*log(Y)))")

#text("B =")#linebreak()#text(" (S)->gb(S)*sum(Y=1,M(S),exp((t/16)*(log((5-S)/(2*Pi*Y^2))^2))*exp((S-1)*log(Y)))")

#text("Phi =")#linebreak()#text(" (Z)->2*Pi*(cos(Pi*((Z^2)/2-Z-1/8))/cos(Pi*Z))*exp(I*(Pi/2)*(Z^2)-(5/8)*Pi*I)")

#text("C =")#linebreak()#text(" (S)->ga(S)*gamma(1-S)*(exp(-I*Pi*S)/(2*Pi*I))*exp((S-1)*log(2*Pi*I*M(S)))*exp(-t*(Pi^2)/64)*Phi(S/(2*Pi*M(S)*I)-M(S))")

#text("E =")#linebreak()#text(" (S)->A(S)+B(S)+C(S)")

#text("H =")#linebreak()#text(" (Z)->E(I*real(Z)/2+(1-imag(Z))/2)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492190")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("Could there be a sign error in ")#mi("A + B + C")#text(" ?")

#text("(for my functions based on Terry’s calculations), i.e.")

#text("Changing from ")#mi("A+B+C")#text(" to ")#mi("A+B-C")#text(" improves accuracy,")#linebreak()#text(" at least some of the time :")

#text("E3(S) = A(S)+B(S)-C(S)")

#text("H3(Z) = E3(I*real(Z)/2+(1-imag(Z))/2)")

#text("Calculations:")

#text("? abs(zeta(1/2+I*74919.075161121))")#linebreak()#text(" = 1.44654472644 E-9")

#text("? abs(H3(2*74919.075161121))/abs(H(2*74919.075161121))")#linebreak()#text(" = 0.000834063509455")

#text("I also checked that two zeros of ")#mi("H_0")#text(" that were missed in [440, 444] via sign changes in the old formula, without remainder, are found when using the H3 above, near twice the zeta zeros: 220.7 and 221.45 .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5869d8b1448ca10fca0bd94d7cbc089633423849ab93255b0123f887992ce41a-6ba6395656430792a6ea6ae7d9ac3e6b5677fa135c4d519e4810981160304521.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492211")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2018")])]

#text("Is there a Riemann-Siegel integral formula for every $H_t$?")#link("http://mathworld.wolfram.com/Riemann-SiegelIntegralFormula.html")[#text("http://mathworld.wolfram.com/Riemann-SiegelIntegralFormula.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492380")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2018")])]

#text("Glen Pugh writes on one of his web pages:")#linebreak()#text(" “Gram’s Law is the statement that zeros of Z(t) alternate with the Gram points”, references at: ")#link("https://web.viu.ca/pughg/RiemannZeta/RiemannZetaLong.html")[#text("https://web.viu.ca/pughg/RiemannZeta/RiemannZetaLong.html")]#text(" and ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93Siegel_theta_function")[#text("https://en.wikipedia.org/wiki/Riemann%E2%80%93Siegel_theta_function")]#text(" .")#linebreak()#text(" For ")#mi("H_{t}")#text(", could there be an analogue of Gram’s Law and/or an analogue of the Riemann-Siegel ")#mi("\\vartheta")#text(" function ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492500")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2018")])]

#text("Could there be an analogue for the ")#mi("H_{t}")#text(" of the Hardy function ")#mi("Z(T)")#text(" ?")#linebreak()#text(" The ")#mi("Z(.)")#text(" function can be used with Euler-Maclaurin summation to get very accurate values of the zeta zeroes:")#linebreak()#text(" ")#link("https://web.viu.ca/pughg/RiemannZeta/RiemannZetaLong.html#ZetaFunction")[#text("https://web.viu.ca/pughg/RiemannZeta/RiemannZetaLong.html#ZetaFunction")]#linebreak()#text(" Also, Edwards Section 6.4 of Chapter 6.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/041e0d8efb404a6a2cf18b2270a848edf2c64e454a9f79bc7b5042d769355180-62fe160b29fccbce5500ff3d0ac989c0d3a0e9678d38be9c88331b114d02c1d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492184")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("Dear Terry,")

#text("There are smoothed approximate functional equations that are exact and provide much better error terms (for instance one can select Gaussian kernels e^{-x^2} in the smooth weights). See for instance the method of proof in ")#link("https://arxiv.org/pdf/math/0111312.pdf")[#text("https://arxiv.org/pdf/math/0111312.pdf")]#text(" (the argument is folklore). Cutting such a smoothed approximate functional equation at N = \\sqrt{T} \\log T gives an excellent error term at the price of a slightly longer computation (by a factor of \\log T). Is there a particular reason why the same technique wouldn’t go through in the case of H_t ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492185")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("There are likely formulae like this – the exact formula in the third display of this blog post is something of this sort, actually (particularly if one applies a smooth splitting of the contour from ")#mi("i\\theta-\\infty")#text(" to ")#mi("i\\theta+\\infty")#text(" rather than a rough one), but I think these formulae will be slower to compute, even if they are slightly more compact in form. The error term in the Riemann-Siegel formula has an asymptotic expansion whose first few terms decay extremely fast (each term in the expansion is about ")#mi("T^{-1/2}")#text(" the size of the previous one), and are far easier to compute than the additional ")#mi("\\sqrt{T} \\log T - \\sqrt{T}")#text(" terms one would need in the smoothed formula.")

#text("One way to think about it is this: Poisson summation suggests that any summation of ")#mi("\\frac{1}{n^s}")#text(" in the range ")#mi("n \\sim N")#text(" can be converted to a summation of ")#mi("\\frac{1}{m^{1-s}}")#text(" in the range ")#mi("m \\sim \\frac{T}{2\\pi N}")#text(", up to some tractable Gamma factors. Naively, the former sum takes about ")#mi("O(N)")#text(" terms to compute and the latter takes ")#mi("O(T/2\\pi N)")#text(" to compute. One can split the Poisson summation in various ways, but the most efficient thing we can really do is to sum directly for ")#mi("n")#text(" up to ")#mi("\\sqrt{T/2\\pi}")#text(" and then apply Poisson summation beyond that range, for ")#mi("O(\\sqrt{T})")#text(" computations; the rough cutoff introduces an error term but we fortunately have a good asymptotic expansion for it. A smooth cutoff removes this small error term, but at the cost of placing more of the summation on the inefficient side of the Poisson summation formula, and does not seem to be a win in practice (certainly none of the numerical literature on RH verification use these sorts of formulae). Here by the way is a place where numerics diverges from theory, since when computational complexity (or implied constants) are not an issue it is certainly advantageous to smooth sums whenever possible.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492194")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2018")])]

#text("I decided to count zeta zeros via sign changes in the real part of a function I defined in PARI/gp that I called H3, based on Terry Tao’s Riemann-Siegel formula calculations.")#linebreak()#text(" It’s set to look for zeros of zeta with imaginary part below 16,000.")#linebreak()#text(" The output is being written to a file, so that I can use it later.")#linebreak()#text(" The command that is now running is copied below, and already up to height 4000.0, the count of zeta zeros is complete.")

#text("last = 1.0;")#linebreak()#text(" count=0;")#linebreak()#text(" for(J=1000,1600000,")#linebreak()#text(" new = real(H3(J/50.0));")#linebreak()#text(" if( (new*last)<0,")#linebreak()#text(" count=count+1;")#linebreak()#text(" write(zeros_to_16k, count,\" \", J/100.0));")#linebreak()#text(" last = new);")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492195")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2018")])]

#text("The agreement with tables of zeta zeros using H3, with ")#mi("A+B-C")#text(" instead of ")#mi("A+B+C")#text(", is excellent. It seems likely either I made a mistake in defining ")#mi("C(s)")#text(", or there was a mistake (sign error) in the complex equations…")#linebreak()#text(" H3 locates 17423 zeta zeros up to height 16000.0, and tables of zeta zeros say there are in fact 17425. It appears H3 didn’t locate zeros 5229.198557199 and 5229.241811259.")

#text("Through re-scaling, this appears as two “very near misses” with respect to sign changes:")

#text("? for(J=1045820, 1045860, print(J/200.0,” “, real(H3(J/100.0))*(10^1778)))")

#text("[…]")#linebreak()#text(" 5229.18000000 0.0191439033097")#linebreak()#text(" 5229.18500000 0.0151796159916")#linebreak()#text(" 5229.19000000 0.0117431220497")#linebreak()#text(" 5229.19500000 0.00883338972137")#linebreak()#text(" 5229.20000000 0.00644920191919")#linebreak()#text(" 5229.20500000 0.00458915818597")#linebreak()#text(" 5229.21000000 0.00325167668798")#linebreak()#text(" 5229.21500000 0.00243499624578")#linebreak()#text(" 5229.22000000 0.00213717840158")#linebreak()#text(" 5229.22500000 0.00235610952246")#linebreak()#text(" 5229.23000000 0.00308950293842")#linebreak()#text(" 5229.23500000 0.00433490111440")#linebreak()#text(" 5229.24000000 0.00608967785543")#linebreak()#text(" 5229.24500000 0.00835104054402")#linebreak()#text(" 5229.25000000 0.0111160324088")#linebreak()#text(" […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492204")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2018")])]

#text("The 17,425th zeta zero, as determined by a sign change in the real part of H3, is off by only 0.000074 .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492220")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2018")])]

#text("It is entirely plausible that I made a sign error. I will not have time to do this until much later today, but I suspect that I managed to forget about the minus sign in the formula for the remainder R(s) in the Riemann-Siegel formula ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93Siegel_formula")[#text("https://en.wikipedia.org/wiki/Riemann%E2%80%93Siegel_formula")]#text(" .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492222")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2018")])]

#text("Ok, thanks! I’m computing another dataset of zeta zeros up to height 64000 (using H3), and writing the output to a file. I’m not sure what the best tests might be for “quality control”, i.e. that the data is what it should be theoretically.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492225")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2018")])]

#text("I too have started a new search for H_0 zeroes with the new eqn (between heights 50k to 100k), and the initial results show a dramatic improvement.")

#text("If by quality control you mean number of zeroes, there are 38379 H_0 zeroes from 0 to 64000, so it can be compared against that. Also with the zeroes estimated to two decimal places, the average gap between the estimated and actual zeroes near the 50k mark is close to 0.005.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492232")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2018")])]

#text("The program found, via sign changes in the real part of “H3”, 83816 of the 83818 non-trivial zeta zeros ")#mi("rho")#text(" with imaginary part between 0 and 64,000 .")#linebreak()#text(" I plan to use something close to the secant method , ")#link("https://en.wikipedia.org/wiki/Secant_method")[#text("https://en.wikipedia.org/wiki/Secant_method")]#text(" , to locate with higher precision the sign changes in the real part of “H3” …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492234")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2018")])]

#text("The approximate zeta zero, using ")#mi("H_{0}")#text(" with remainder term, at 63999.4809 (via sign change) is off by 0.0004 from the actual zeta zero at 63999.4813 .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492235")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2018")])]

#text("So the new eqn has detected all sign changes and hence all 15142 zeroes between T=50k and 70k (in terms of zeta zeroes, T between 25k to 35k), hence I have stopped the benchmarking exercise on my side.")

#text("Now running computations for t=0.5 and T>2 million. As predicted by theory, we should start seeing both a decrease in average zero spacing and standard deviation of zero spacings, as the zeroes drift downward and become more regularly spaced.")

#text("At this point, we can start dividing t ranges between ourselves. For eg. I am planning to explore and generate statistics for t between 0.48 and 0.5 for a start.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492241")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2018")])]

#text("For zeta zeroes with heights between 32k and 64k, I looked at the errors in the approximations using ")#mi("H_{0}")#text(" with the remainder term, as compared to tables of zeta zeroes.")

#text("The approximate zeta zeroes are based on where the real part of ")#mi("H_{0}")#text(" with remainder, changes sign. My program finds that the average error is 0.000113 .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492254")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2018")])]

#text("Sujit, KM,")#linebreak()#text(" I’ll send Sujit my Github handle when I find it…")#linebreak()#text(" I’m not a Python programmer, but I can try to run your programs, to do a share of the ")#mi("H_{t}")#text(" zeros computations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492347")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2018")])]

#text("By the way, checking some statistics for t=0.5 and upto first 30000 zeroes")

#text("T N_t(T) # detected zeroes of H_t")#linebreak()#text(" 10000 4519.665 4521")#linebreak()#text(" 20000 10142.321 10143")#linebreak()#text(" 30000 16181.355 16182")

#text("pretty good match so far.")

#text("Also I just realized the (t/16)log(T/4PI) factor, and hence the drift is quite small. So even at T=10^15, we can expect just 1 more zero at t=0.5 compared to at t=0.")

#text("Also, as you had noticed, at t=0 there were 2 zeroes undetected with the ABC eqn at 2*5229.198 and 2*5229.242, but it seems at t=0.5, ABC has detected the corresponding zeroes for those ones too.")

#text("n H_0.5 zero zeta zero H_0 zero")#linebreak()#text(" 4765 10457.4445 5229.1985 10458.3971")#linebreak()#text(" 4766 10458.9976 5229.2418 10458.4836")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492375")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2018")])]

#link("https://kommonmann.wordpress.com/")[#text("https://kommonmann.wordpress.com/")]#text(" :")#linebreak()#text(" That’s interesting what you have about ")#mi("H_{0.4}")#text(" . At some point, we might try doing an exact count of zeroes of ")#mi("H_{0.4}")#text(" in a rectangle, something like a numerical contour integral, as far as I know, similar to what was done before “Turing’s trick” was found.")#linebreak()#text(" It could be something to think about.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492231")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2018")])]

#text("I have located the sign error (I had reversed the orientation of a contour). The correct approximation is indeed ")#mi("H_t = A+B-C")#text(". Thanks for pointing it out! I am working on replacing the wiki page with corrected (and more logically structured) asymptotics.")

#emph[#text("[Edit: wiki page now replaced. -T]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492340")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2018")])]

#text("I put together in a script file h3zeros16k.gp the PARI/gp commands and function definitions for the zeta zeros with height below 16000, based on the code above. Unfortunately, the script won’t run: it prints nothing.")#linebreak()#text(" But the examples scripts from PARI/gp Headquarters do work, for example lucas.gp to perform Lucas-Lehmer tests.")#linebreak()#text(" GP script files can be compiled with the gp2c compiler package. This worked for the example GP script lucas.gp .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e70b55be4e76ed4f99e16b4b554c4d7035f36b54d1dd9680b885e0b4aa828f9-18dbe7f885900e6341d64234d76a919ae68437b645f70e40809405029ed4a540.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PGniewek")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492219")[#strong[#text("PGniewek")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2018")])]

#text("Dear Terry, a minor nitpick: there appears to be an error in the second equation below the box containing Proposition 1 in this post: the argument of the rightmost exponential function is ")#mi("\\exp( -\\pi n^2 u)")#text(" and I think it should be ")#mi("\\exp( -\\pi n^2 e^{4u})")#text(". Cheers.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492240")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2018")])]

#text("Here is a very crude computation that nevertheless indicates that it should be possible to obtain a reasonable value of ")#mi("T")#text(" for which one can hope to establish the zero-free property ")#mi("H_t(x+iy)")#text(" whenever ")#mi("y \\geq \\varepsilon")#text(" and ")#mi("x \\geq T")#text(" for usable choices of ")#mi("t,\\varepsilon")#text(".")

#text("I’ll pick ")#mi("t=0.4")#text(" and ")#mi("\\varepsilon=0.4")#text("; this will lead to a bound ")#mi("\\Lambda \\leq t + \\frac{1}{2} \\varepsilon^2 = 0.48")#text(" which is better than 0.5. I’ll pretend that the A+B approximation is exact, thus")

#mi("H_t(x+iy) = \\frac{1}{8} \\frac{s(s-1)}{2} \\pi^{-s/2} \\Gamma(s/2) \\sum_{n \\leq N} \\frac{\\exp( \\frac{t}{16} \\log^2 \\frac{s+4}{2\\pi n^2})}{n^s}")#linebreak()#text(" ")#mi("+ \\frac{1}{8} \\frac{s(s-1)}{2} \\pi^{-(1-s)/2} \\Gamma((1-s)/2) \\sum_{n \\leq N} \\frac{\\exp( \\frac{t}{16} \\log^2 \\frac{5-s}{2\\pi n^2})}{n^{1-s}}")

#text("with ")#mi("s = \\frac{1-y+ix}{2}")#text(". To make ")#mi("H_t(x+iy)")#text(" non-zero, it suffices to make the first term in the second sum larger in magnitude than the sum of all the other magnitudes put together. Cancelling some factors, and using the approximation ")#tao-math("\\left|\\Gamma(s/2)\\right| \\approx T^{-y/2} \\left|\\Gamma((1-s)/2)\\right|", block: false)#text(", this amounts to asking that")

#mi("\\exp( \\frac{t}{16} \\mathrm{Re}\\log^2(5-s) )")

#mi("< (T/\\pi)^{-y/2} \\sum_{n \\leq N}  \\frac{\\exp( \\frac{t}{16} \\mathrm{Re} \\log^2 \\frac{s+4}{2\\pi n^2})}{n^{(1-y)/2}}")

#mi("+ \\sum_{2 \\leq n \\leq N}  \\frac{\\exp( \\frac{t}{16} \\mathrm{Re} \\log^2 \\frac{5-s}{2\\pi n^2})}{n^{(1+y)/2}}.")

#text("We approximate ")#mi("\\mathrm{Re} \\log^2 \\frac{s+4}{2\\pi n^2}")#text(" as ")#mi("\\log^2 \\frac{x}{4\\pi} - \\frac{\\pi^2}{4} - 4 \\log \\frac{x}{4\\pi n} \\log n")#text(" and similarly with ")#mi("s+4")#text(" replaced by ")#mi("5-x")#text(", so we reduce to showing that")

#mi("1")

#mi("< (T/\\pi)^{-y/2} \\sum_{n \\leq N}  \\frac{1}{n^{(1-y)/2 + \\frac{t}{4} \\log \\frac{x}{4\\pi n}}}")

#mi("+ \\sum_{2 \\leq n \\leq N}  \\frac{1}{n^{(1+y)/2 + \\frac{t}{4} \\log \\frac{x}{4\\pi n}}}.")

#text("In order to do a cheap computation, I crudely bounded ")#mi("\\log \\frac{x}{4\\pi n} \\geq \\frac{1}{2} \\log \\frac{x}{4\\pi}")#text(", and then extended the sum to all ")#mi("n")#text(", giving the criterion")

#mi("1 < (T/\\pi)^{y/2} \\zeta( \\frac{1-y}{2} + \\frac{t}{8} \\log \\frac{T}{4\\pi} ) + \\zeta( \\frac{1+y}{2} + \\frac{t}{8} \\log \\frac{T}{4\\pi} ) - 1")#text(".")

#text("Setting ")#mi("y = t = 0.4")#text(", it seems that we can make this criterion for ")#mi("T = 10^{11}")#text(" or so, which is only barely within range of what is numerically verified for RH. One can probably do better if one doesn't bound things quite as crudely. It's also possible that when ")#mi("t=0.4")#text(", the sum for ")#mi("H_t")#text(" is quite rapidly convergent, and one could numerically verify the absence of zeroes for ")#mi("y \\geq 0.4")#text(" for quite a large range of ")#mi("T")#text(", e.g. ")#mi("10^{11} \\leq T \\leq 10^{13}")#text(", and then use something like the above argument to handle all larger values of ")#mi("T")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492256")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2018")])]

#text("In proposition 1 [of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Asymptotics_of_H_t")[#text("wiki page on asymptotics")]#text("], the definition of ")#mi("w")#text(" (which appears in both sides) and the exponent in the LHS, is not sufficiently clear.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492269")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2018")])]

#text("I am not quite sure what you are referring to here. There is a definition of the complex exponential ")#mi("w^{s-1}")#text(", but this is not a definition of ")#mi("w")#text(" itself, which is a dummy variable of integration.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492275")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2018")])]

#text("I was confused because the letter ")#mi("s")#text(" in the exponent of ")#mi("w^{s-1}")#text(" appears so tiny and unrecognizable (even under magnification) as the letter ")#mi("s")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492277")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2018")])]

#text("The letter ")#mi("S")#text(" in the exponent seems to be distorted(!) in that wiki page (but not here).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492270")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2018")])]

#text("Set ")#mi("B_0(s) := \\frac{1}{8} \\frac{s(s-1)}{2} \\pi^{-(1-s)/2} \\Gamma((1-s)/2) \\exp( \\frac{t}{16} \\log^2 \\frac{5-s}{2\\pi})")#text(" for the main term of ")#mi("B")#text(". A plausible objective would be to show that for ")#mi("t = 0.4")#text(" and ")#mi("y = 0.4")#text(" and ")#mi("s = \\frac{1+ix-y}{2}")#text(", the quantity ")#mi("A(s)+B(s)")#text(" does not vanish for all ")#mi("x")#text(" larger than some reasonable threshold ")#mi("T")#text(". This is equivalent to ")#mi("\\frac{A(s)+B(s)}{B_0(s)}")#text(" not vanishing; if I did not make any computational errors, this function can be written explicitly as")

#mi("\\sum_{n \\leq N} \\frac{1}{n^{1-s + \\frac{t}{4} \\log \\frac{5-s}{2\\pi n}}}")

#mi("+ \\pi^{\\frac{1-2s}{2}} \\frac{\\Gamma(s/2)}{\\Gamma((1-s)/2)} \\exp( \\frac{t}{4} (\\log^2 \\frac{s+4}{2\\pi} - \\log^2 \\frac{5-s}{2\\pi}) \\sum_{n \\leq N} \\frac{1}{n^{s + \\frac{t}{4} \\log \\frac{s+4}{2\\pi n}}}.")

#text("In the limit ")#mi("x \\to \\infty")#text(" this quantity converges to ")#mi("1")#text("; the question is how fast it converges and at what point it stays a significant distance away from zero (so that we would be able to replace ")#mi("A+B")#text(" by the full ")#mi("H_t")#text(" and still get a zero free region). This looks like something that could be amenable to numerics, given that the sums here should converge reasonably quickly once ")#mi("x")#text(" is moderately large. (In particular, comparative plots of ")#mi("(A+B)/B_0")#text(", ")#mi("(A+B-C)/B_0")#text(", and ")#mi("H_t/B_0")#text(" for smallish values of ")#mi("x")#text(" could be quite revealing as to the feasibility of this strategy.)")

#emph[#text("[Edited to restore some missing denominators of ")#mi("2\\pi")#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492280")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2018")])]

#text("I see that the LHS of the inequality, for ")#mi("n=1")#text(", has ")#mi("log^{2} (5-s)")#text(", but that the RHS for 2<= n <=N has an extra ")#mi("2\\pi")#text(" as in: ")#mi("log^{2} (5-s)/(2 \\pi n^{2}")#text(" …")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492305")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2018")])]

#text("Oops, good catch! I think I have restored all the missing denominators of ")#mi("2\\pi")#text(" now. (Also I had a ")#mi("4\\pi")#text(" which should also have been a ")#mi("2\\pi")#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492341")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2018")])]

#text("Some results on (A+B-C)/B0 and (A+B)/B0 computations for t=0.4, y=0.4. Two exercises were run,")

#text("one with x range with step size 1.0,")#linebreak()#text(" and the other a shorter one with single point evaluations with x = powers of 10")

#text("val below refers to the modulus |(A+B)/B0|")#linebreak()#text(" x range——minval–maxval–avgval–stdevval")#linebreak()#text(" upto 100k—0.179—4.491—1.077—0.455")#linebreak()#text(" 100k-200k—0.488—3.339—1.053—0.361")#linebreak()#text(" 200k-300k—0.508—3.049—1.047—0.335")#linebreak()#text(" 300k-400k—0.517—2.989—1.043—0.321")#linebreak()#text(" 400k-500k—0.535—2.826—1.041—0.310")#linebreak()#text(" 500k-600k—0.529—2.757—1.039—0.303")#linebreak()#text(" 600k-700k—0.548—2.728—1.038—0.296")

#text("more granular upto x=6000 (min value at x=29)")#linebreak()#text(" x range——minval–maxval–avgval–stdevval")#linebreak()#text(" upto 1000—0.179—4.074—1.219—0.782")#linebreak()#text(" 1000-2000—0.352—4.403—1.164—0.712")#linebreak()#text(" 2000-3000—0.352—4.050—1.145—0.671")#linebreak()#text(" 3000-4000—0.338—4.174—1.134—0.640")#linebreak()#text(" 4000-5000—0.386—4.491—1.128—0.615")#linebreak()#text(" 5000-6000—0.377—4.327—1.120—0.599")

#text("x+yi————-(A+B-C)/B0—-(A+B)/B0")#linebreak()#text(" 10^2 + 0.4i—-0.80-0.35i—-0.25-0.18i")#linebreak()#text(" 10^3 + 0.4i—-0.50+0.44i—-0.39+0.51i")#linebreak()#text(" 10^4 + 0.4i—-0.52+0.01i—-0.52-0.01i")#linebreak()#text(" 10^5 + 0.4i—-1.28-0.15i—-1.28-0.16i")#linebreak()#text(" 10^6 + 0.4i—-1.29-0.76i—-1.29-0.76i")#linebreak()#text(" 10^7 + 0.4i—-1.54+0.13i—-1.54+0.13i")#linebreak()#text(" 10^8 + 0.4i—-1.47-0.09i—-1.47-0.09i")#linebreak()#text(" 10^9 + 0.4i—-1.23+0.18i—-1.23+0.18i")#linebreak()#text(" 10^10 + 0.4i—-0.86+0.07i—-0.86+0.07i")#linebreak()#text(" 10^11 + 0.4i—-1.09-0.07i—-1.09-0.07i")#linebreak()#text(" 10^12 + 0.4i—-0.996+0.09i—0.996+0.09i")#linebreak()#text(" 10^13 + 0.4i—-0.953+0.045i–0.953+0.045i")

#text("It seems (A+B)/B0 starts staying away from zero after a very short range, but converges to 1 quite slowly.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492401")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2018")])]

#text("This is very promising numerical data! It suggests for instance that the C error term is largely irrelevant for ")#mi("x \\geq 10^4")#text(" or so. One could now hope to establish that ")#mi("H_t(x+iy) \\neq 0")#text(" for all ")#mi("x")#text(" and ")#mi("y = 0.4")#text(" by doing a numerical verification up to, say, ")#mi("x = 10^6")#text(", and then for ")#mi("x > 10^6")#text(", showing that ")#tao-math("\\left|A+B\\right|/B_0 \\geq 0.4", block: false)#text(" (which seems plausible from the numerical data, and can hopefully be proven by some combination of numerics and analysis) and that ")#tao-math("\\left|H_t - (A+B)\\right|/B_0 < 0.4", block: false)#text(" (e.g. by showing ")#tao-math("\\left|H_t - (A+B-C)\\right|/B_0 < 0.3", block: false)#text(" and ")#tao-math("\\left|C\\right|/B_0 < 0.1", block: false)#text("). If ")#mi("(A+B)/B_0")#text(" not only stays away from the origin, but also from the negative real axis, then the argument principle (and Rouche’s theorem) should also preclude zeroes in the region ")#mi("y > 0.4")#text(" as well (one may also have to control what goes on at some large value of ")#mi("y")#text(", e.g. ")#mi("y=10")#text(", but I think this should be very easy).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492402")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2018")])]

#text("Since ")#mi("H_t(x+iy) \\neq 0")#text(" for any ")#mi("t \\geq 0")#text(" and ")#mi("y \\geq 1")#text(", it is not clear why larger values of ")#mi("y")#text(" should be considered?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492422")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2018")])]

#text("To apply the argument principle to establish a zero-free region such as ")#tao-math("\\{ x+iy: T_1 \\leq \\left|x\\right| \\leq T_2, y \\geq 0.4 \\}", block: false)#text(", it is not enough to know that the function ")#mi("H_t(x+iy)")#text(" is non-zero on the boundary of the region; one also must control the winding number. For ")#mi("y")#text(" very large (I conservatively put ")#mi("y=10")#text(", but one can probably do much better) one can approximate ")#mi("H_t(x+iy)")#text(" quite well by ")#mi("B_0")#text(" whose contribution to the winding number is very well controlled (coming almost entirely from the gamma function factor). One may still have to control ")#mi("H_t(x+iy)")#text(" for say ")#mi("0.4 \\leq y \\leq 10")#text(" on the ")#mi("x = T_1, T_2")#text(" sides, but probably we can take ")#mi("T_1")#text(" small enough that this verification is easy, and for ")#mi("T_2")#text(" large enough perhaps the analysis estimates would suffice.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492445")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2018")])]

#text("Some results for t=0.4, y=0.4 for Real((A+B)/B0) and |C/B0|. Every point n+yi was evaluated, where n is a natural number (showing results till n = 0.7 million)")

#text("While it may be possible for (A+B)/B0 and C/B0 to have different behavior between these points, I think that’s unlikely since n+0.4i is effectively random for H_t, and the sample size of observations is large.")

#text("It seems Real((A+B)/B0) stays positive beyond a small height and afterwards becomes comfortably above 0.4 and keeps moving towards 1. This reflects also in |(A+B)/B0|")

#text("n————–minval—maxval")#linebreak()#text(" upto 1000—(0.09)—4.06")#linebreak()#text(" 1000-2000—0.02—–4.33")#linebreak()#text(" 2000-3000—0.15—–3.99")#linebreak()#text(" 3000-4000—0.19—–3.99")#linebreak()#text(" 4000-5000—0.34—–4.48")#linebreak()#text(" 5000-6000—0.33—–4.33")#linebreak()#text(" 6000-7000—0.35—–3.88")#linebreak()#text(" ———————————")#linebreak()#text(" upto 100k—(0.09)—4.48")#linebreak()#text(" 100k-200k—0.48—–3.32")#linebreak()#text(" 200k-300k—0.50—–3.00")#linebreak()#text(" 300k-400k—0.52—–2.97")#linebreak()#text(" 400k-500k—0.53—–2.82")#linebreak()#text(" 500k-600k—0.53—–2.75")#linebreak()#text(" 600k-700k—0.55—–2.72")

#text("|C/B0| keeps moving towards 0 and is less than 0.1 beyond a small height.")

#text("n————–minval—maxval")#linebreak()#text(" upto 1000—0.058—2.125")#linebreak()#text(" 1000-2000—0.036—0.160")#linebreak()#text(" 2000-3000—0.028—0.095")#linebreak()#text(" 3000-4000—0.023—0.071")#linebreak()#text(" 4000-5000—0.020—0.060")#linebreak()#text(" 5000-6000—0.018—0.052")#linebreak()#text(" 6000-7000—0.016—0.045")#linebreak()#text(" ——————————————-")#linebreak()#text(" upto 100k—0.002236—2.124627")#linebreak()#text(" 100k-200k—0.001262—0.005360")#linebreak()#text(" 200k-300k—0.000888—0.003030")#linebreak()#text(" 300k-400k—0.000699—0.002158")#linebreak()#text(" 400k-500k—0.000572—0.001681")#linebreak()#text(" 500k-600k—0.000485—0.001382")#linebreak()#text(" 600k-700k—0.000424—0.001176")

#text("As a contrast, I also ran the same exercise for t=0.05 and y=0.4. It seems for t=0.05 to show similar behavior as t=0.4, we will have to go to much larger heights as expected.")

#text("|(A+B)/B0|")#linebreak()#text(" n————–minval—maxval")#linebreak()#text(" upto 100k—0.092—9.231")#linebreak()#text(" 100k-200k—0.172—10.001")#linebreak()#text(" 200k-300k—0.160—10.461")#linebreak()#text(" 300k-400k—0.185—10.177")#linebreak()#text(" 400k-500k—0.158—9.925")#linebreak()#text(" 500k-600k—0.183—9.826")#linebreak()#text(" 600k-700k—0.188—9.928")

#text("Real((A+B)/B0)")#linebreak()#text(" n————–minval—maxval")#linebreak()#text(" upto 100k—(1.24)—8.89")#linebreak()#text(" 100k-200k—(1.29)—9.98")#linebreak()#text(" 200k-300k—(1.35)—10.34")#linebreak()#text(" 300k-400k—(1.17)—10.16")#linebreak()#text(" 400k-500k—(1.22)—9.91")#linebreak()#text(" 500k-600k—(0.94)—9.64")#linebreak()#text(" 600k-700k—(1.23)—9.85")

#text("|C/B0|")#linebreak()#text(" upto 100k—0.0130—2.2336")#linebreak()#text(" 100k-200k—0.0097—0.0315")#linebreak()#text(" 200k-300k—0.0082—0.0236")#linebreak()#text(" 300k-400k—0.0073—0.0200")#linebreak()#text(" 400k-500k—0.0067—0.0177")#linebreak()#text(" 500k-600k—0.0061—0.0161")#linebreak()#text(" 600k-700k—0.0058—0.0149")

#text("Computing H_t independently of the ABC approach at such large heights (for eg. using the integral) is quite tricky and expensive, as shown by David in some of the comments below. We may need a Euler Maclaurin type formula, which was being attempted in one of the threads some time back.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492465")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2018")])]

#text("Evaluating H_t(x+iy) for t=0.4 and y=0.8,1.2,…4.4 upto height 50k (for integer x) gives these results,")

#text("min value of Real((A+B)/B0)")#linebreak()#text(" —–x range")#linebreak()#text(" y—-upto10k-10k20k-20k30k-30k40k-40k50k")#linebreak()#text(" ———————————————————")#linebreak()#text(" 0.8—-0.19—–0.52—–0.55—–0.55—–0.57")#linebreak()#text(" 1.2—-0.38—–0.60—–0.61—–0.62—–0.64")#linebreak()#text(" 1.6—-0.47—–0.65—–0.67—–0.67—–0.69")#linebreak()#text(" 2.0—-0.55—–0.70—–0.72—–0.72—–0.73")#linebreak()#text(" 2.4—-0.61—–0.74—–0.76—–0.76—–0.77")#linebreak()#text(" 2.8—-0.67—–0.78—–0.79—–0.80—–0.80")#linebreak()#text(" 3.2—-0.71—–0.81—–0.82—–0.82—–0.83")#linebreak()#text(" 3.6—-0.74—–0.84—–0.85—–0.85—–0.85")#linebreak()#text(" 4.0—-0.77—–0.86—–0.87—–0.87—–0.87")#linebreak()#text(" 4.4—-0.80—–0.88—–0.89—–0.89—–0.89")

#text("min value of |H/B0|")#linebreak()#text(" ——x range")#linebreak()#text(" y—-upto10k-10k20k-20k30k-30k40k-40k50k")#linebreak()#text(" ———————————————————")#linebreak()#text(" 0.8—–0.18—–0.52—–0.55—–0.56—–0.58")#linebreak()#text(" 1.2—–0.15—–0.60—–0.62—–0.62—–0.64")#linebreak()#text(" 1.6—–0.20—–0.66—–0.67—–0.68—–0.69")#linebreak()#text(" 2.0—–0.35—–0.70—–0.72—–0.72—–0.73")#linebreak()#text(" 2.4—–0.48—–0.75—–0.76—–0.76—–0.77")#linebreak()#text(" 2.8—–0.59—–0.78—–0.79—–0.80—–0.80")#linebreak()#text(" 3.2—–0.67—–0.81—–0.82—–0.83—–0.83")#linebreak()#text(" 3.6—–0.74—–0.84—–0.85—–0.85—–0.85")#linebreak()#text(" 4.0—–0.78—–0.86—–0.87—–0.87—–0.87")#linebreak()#text(" 4.4—–0.82—–0.88—–0.89—–0.89—–0.89")

#text("As expected, the behavior seen at t=0.4,y=0.4 becomes more pronounced as y is increased, and the above values converge to 1 faster. Also, Real((A+B)/B0) never went negative in this exercise.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492262")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2018")])]

#text("In the wiki page on ")#mi("H_t")#text(" asymptotics (just above “approximation for ")#mi("t > 0")#text("“), it seems that in the exact expression of ")#mi("R_{t, N, M}(s)")#text(", the second sum (unlike the first sum) is independent of ")#mi("t")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492325")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2018")])]

#text("Is it possible (by obtaining more information on the dynamics of ")#mi("\\sigma_{max}(t)")#text(") to improve the upper bound for ")#mi("\\Lambda")#text(" in proposition 1 above (e.g. by reducing the factor ")#mi("1/2")#text(" in this bound for certain values of ")#mi("t_0")#text(" and ")#mi("\\epsilon")#text(")?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492377")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2018")])]

#text("For t=0.5, we see evidence of the zeros getting quite regularly spaced compared to the the zeros for t=0, even while the average zero gap remains almost the same.")

#text("T range—# of——–avg—-avg——-stdev—stdev")#linebreak()#text(" ————-H_0.5—–zero—zero——zero—–zero")#linebreak()#text(" ————-zeroes—-gap—-gap——gap——gap")#linebreak()#text(" ————————H_0.5—-H_0—–H_0.5—-H_0")#linebreak()#text(" —————————————————————")#linebreak()#text(" upto 10k–4521—–2.21—–2.21—–0.65—–1.00")#linebreak()#text(" 10k-20k—5622—–1.78—–1.78—–0.23—–0.71")#linebreak()#text(" 20k-30k—6039—–1.66—–1.66—–0.18—–0.66")#linebreak()#text(" 30k-40k—6310—–1.58—–1.58—–0.16—–0.63")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ef5e7c93b176a7617e0416f01e04497ff82ab5c2c8a9a015396c34d0d8687f-c34001fba30c1ceff6ba27b0aca55b12eda5633cec557f8295aa918df4469699.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug Stoll")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492386")[#strong[#text("Doug Stoll")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2018")])]

#text("I just found these blogs today. For all of you looking to confirm the Ho zeros here is potentially helpful hint. For Riemann zeta zeros one can use the following for a very “quick and rather good” approximation to the kth zero. I derived and tested this myself several months ago but have not published it nor have I seen it anywhere.")

#text("zz[k] ~ 2e*Pi*A/(ProdLog[A]) +Pi/k – (4.7159-0.3538loglog(k+1))/log(k+1)")

#text("Where A = (8k-7)/8e and ProdLog [A] = W[A] whichever notation you are more used to.")

#text("It works extremely well even out to 10^24 as I compared it to the published sets of zeros. It is not perfect as it presumes monotonically decreasing spacing but it is close.")

#text("So I would expect you to look at 2X this value +/- a little. It would be very informative to see if there is a “consistent” decrement or a “simple function” from 2X towards the origin the further up the i-axis one goes.")

#text("And a caution, be careful of your step size exactly for the reason the zeros still will crowd together. You should use a decreasing test step size. To get a feel for the stats of the first 10^13 zeta zeros and particularly the ones that get very close together (and therefore have an impact on the dB-N constant I refer you to:")

#link("http://numbers.computation.free.fr/Constants/Miscellaneous/zetazeroscompute.html")[#text("http://numbers.computation.free.fr/Constants/Miscellaneous/zetazeroscompute.html")]#text(" –")

#text("particularly to published samples of zeros explored out to 10^24. Notice that the smallest spacing in your current range of interest (to 10^12) is 0.0001008 at T = 18,403,609,310.0854 (60,917,681,409th zeta zero). The smallest you should find in your test out to 160000 should be the 97,484th zero at 73,235.205353")

#text("I have heuristically found an estimate (unpublished) over the range of zz’s found to date that the minimum spacing for zeta zero’s is larger than:")#linebreak()#text(" min gap > 10^{[loglog[T]^3/2 + Pi/2]}")

#text("and the maximum spacing is:")#linebreak()#text(" max gap < 2/3*loglog[T]^3/2+1)*expected gap where the expected gap can be found from above as zz[k+1]-zz[k].")

#text("This is all extremely exciting if you improve Odlyzko's 1999 value for lamda's lower bound of -2.7*10^-9. This is feeling like it could be 0. What an interesting find that would be. Prove RH and show it is just barely true as expected.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Ruxton")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492391")[#strong[#text("Michael Ruxton")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2018")])]

#text("Didn’t this thread start with Rodgers and Tao proving lambda >= 0?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ef5e7c93b176a7617e0416f01e04497ff82ab5c2c8a9a015396c34d0d8687f-c34001fba30c1ceff6ba27b0aca55b12eda5633cec557f8295aa918df4469699.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug Stoll")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492400")[#strong[#text("Doug Stoll")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2018")])]

#text("No – proving it was non-negative – but allowing for 0,")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492397")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2018")])]

#text("I’d recommend taking a look at the Proposal post written by Terry Tao here: ")#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/")[#text("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/")]#text(" .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492419")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2018")])]

#text("Using an 800-point Gauss-Legendre method,")#linebreak()#text(" I can accurately evaluate the integral")#linebreak()#text(" for H_0(2*z200), where z200 is the 200th zero of Riemann zeta.")

#text("By optimizing over the parameters, I got it down to")#linebreak()#text(" 14 seconds.")

#text("The real precision was set to 140 digits, because")#linebreak()#text(" there is a lot of cancellation, and the tail")#linebreak()#text(" oscillations are extremely tiny.")

#text("Below, x6 := 2*z200 :")

#text("? intnumgaussinit(800); // 40 seconds to initialize 800-point method")#linebreak()#text(" time = 41,428 ms.")

#text("? s=0.0;for(J=0,16, s=s+intnumgauss(X=J/12,(J+1)/12, Phi(X)*cos(x6*X),)); s")#linebreak()#text(" time = 13,778 ms.")#linebreak()#text(" %95 = 3.07144223057202094576[…] E-141 // 14 seconds elapsed time")

#text("? x6")#linebreak()#text(" %96 = 792.76370844600000000000[…]00000000000000000000")

#text("? zeta(1/2+I*x6/2)")#linebreak()#text(" time = 92 ms.")

#text("%97 = -7.0548531809481797311234[…] E-10 + 7.029082149944[…] E-10*I")

#text("? \\p")#linebreak()#text(" realprecision = 154 significant digits (140 digits displayed)")

#text("Phi(X):= sum(Y=1,50,(2*Pi*Pi*(Y^4)*exp(9*X)-3*Pi*(Y^2)*exp(5*X))*exp(-Pi*(Y^2)*exp(4*X)))")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492421")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2018")])]

#text("For z400, I can get the time down to 38 seconds")#linebreak()#text(" to compute accurately H_0(2*z400).")

#text("It seems pretty clear that the main factor in the time taken")#linebreak()#text(" is the increasing real precision needed, when")#linebreak()#text(" passing from 200th to 400th and higher.")

#text("The table below is a first approximation")#linebreak()#text(" to the time needed to compute accurately H_0(2*z_k) using the integral,")#linebreak()#text(" where z_k is the k’th zero of zeta:")

#text("k=1000 time=2.36861 minutes")#linebreak()#text(" k=2000 time=6.42653 minutes")#linebreak()#text(" k=3000 time=11.5225 minutes")#linebreak()#text(" k=4000 time=17.4365 minutes")#linebreak()#text(" k=5000 time=24.0442 minutes")#linebreak()#text(" k=6000 time=31.2631 minutes")#linebreak()#text(" k=7000 time=39.0333 minutes")#linebreak()#text(" k=8000 time=47.3089 minutes")#linebreak()#text(" k=9000 time=56.0535 minutes")#linebreak()#text(" k=10000 time=65.2369 minutes")

#text("========================================")

#text("Commands to PARI/gp and output:")

#text("? z400=679.742197883;")

#text("? \\p 38")#linebreak()#text(" realprecision = 38 significant digits")

#text("? zeta(1/2+I*z400)")#linebreak()#text(" %153 = -1.269246632[…] E-9 + 4.28823209915[…] E-9*I")

#text("? \\p 240")#linebreak()#text(" realprecision = 250 significant digits (240 digits displayed)")

#text("? z400=679.742197883;")#linebreak()#text(" ? x8=2*z400;")

#text("? s=0.0;for(J=0,14, s=s+intnumgauss(X=J/11,(J+1)/11, Phi(X)*cos(x8*X),)); s")#linebreak()#text(" %157 = 7.88880866256[…] E-237")

#text("? s=0.0;for(J=0,14, s=s+intnumgauss(X=J/11,(J+1)/11, Phi(X)*cos((x8+1)*X),)); s")#linebreak()#text(" %158 = 5.28032674733[…] E-228")

#text("? ##")#linebreak()#text(" *** last result computed in 37,923 ms.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492423")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2018")])]

#text("For z800, the 800th non-trivial zeta zero, the time to compute")#linebreak()#text(" the integral for H_0(2*z800) grows to almost 3 minutes.")

#text("Below, the assumption is that time is proportional")#linebreak()#text(" to ")#mi("k^{2.211}")#text(" . Then beyond the 10000th zeta")#linebreak()#text(" zero, the time to compute ")#mi("H_{0}(2z_{k})")#linebreak()#text(" using the integral formula becomes prohibitive:")

#text("k=1000 time=4.80261 minutes")#linebreak()#text(" k=2000 time=22.2359 minutes")#linebreak()#text(" k=3000 time=54.4995 minutes")#linebreak()#text(" k=4000 time=102.951 minutes")#linebreak()#text(" k=5000 time=168.617 minutes")#linebreak()#text(" k=6000 time=252.331 minutes")#linebreak()#text(" k=7000 time=354.805 minutes")#linebreak()#text(" k=8000 time=476.661 minutes")#linebreak()#text(" k=9000 time=618.455 minutes")#linebreak()#text(" k=10000 time=780.688 minutes")

#text("================================================")

#text("Commands to PARI/gp and output for z800:")

#text("? z800=1183.712775296;")

#text("? x10=2*z800;")

#text("? \\p 410")

#text("? #")#linebreak()#text(" timer = 1 (on)")

#text("? s=0.0;for(J=0,15, s=s+intnumgauss(X=J/11,(J+1)/11, Phi(X)*cos((x10)*X),));s")#linebreak()#text(" time = 2min, 55,979 ms.")#linebreak()#text(" %179 = 7.096[…] E-410")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492425")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2018")])]

#text("In the wiki page on the dynamics of simple zeros, the factor ")#mi("-2")#text(" in the RHS of the result should be ")#mi("2")#text(".")#linebreak()#text(" By the way, the simplifying assumption (for the Hadamard factorization) that ")#mi("H_t")#text(" has no zero at the origin, is not needed (since it leads to the same final result.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3e70213003ccd073b80e315c81fe872823884f16498500131d5cd1f05259060-5b0be47db6542147f7d241ef2dc6c3e6600433181762f92f13a74211cd903572.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492449")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2018")])]

#text("An attempt from UChicago on Hilbert’s eighth ")#link("https://arxiv.org/pdf/1708.02653.pdf")[#text("https://arxiv.org/pdf/1708.02653.pdf")]#text(" ")#link("http://faculty.chicagobooth.edu/nicholas.polson/research/polson-hilbert-8.pdf")[#text("http://faculty.chicagobooth.edu/nicholas.polson/research/polson-hilbert-8.pdf")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492451")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2018")])]

#text("In the arxiv paper, the function ")#mi("\\psi")#text(" (also known as Digamma), defined by (21) as the logarithmic derivative of the Gamma function, should have its poles at the poles of ")#mi("\\Gamma")#text(" (i.e. the nonpositive integers). But by (63), these poles should coincide with the zeros of ")#mi("\\xi (1/2 + s^{1/2})")#text(" which are known to have quasi-random properties. So there must be an error in the derivation of (63).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-495328")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2018")])]

#text("Great catch! But I asked Polson about it and apparently (63) was not intended to be the digamma function — it was just an unfortunate choice of notation. The 7th version (April 1st) on arXiv has $\\psi_{\\alpha}$ instead of $\\psi$, but still this is apparently defining a new function, and is not claimed to be the digamma function.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492454")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2018")])]

#text("There’s an expository paper by Andrew Booker that discusses Turing’s method and it’s use in the verification of the Riemann Hypothesis to some height. It would be nice if Turing’s method could be generalized to the functions ")#mi("H_{t}")#text(" . Here’s a link to Andrew Booker’s paper:")#linebreak()#text(" ")#link("http://www.homepages.ucl.ac.uk/~ucahipe/turing1.pdf")[#text("http://www.homepages.ucl.ac.uk/~ucahipe/turing1.pdf")]#text(" .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492459")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2018")])]

#text("The ODE dynamics of the simple zeros of ")#mi("H_t")#text(" for ")#mi("t > 0")#text(" is based on the fact that ")#mi("H_t")#text(" (in addition of obeying the Bacwards heat equation) is an even entire function of order 1 (allowing simple Hadamard factorization). Is ")#mi("H_t")#text(" of order 1 also for some ")#mi("t  < 0")#text(" values?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492463")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2018")])]

#mi("H_t")#text(" is of order 1 for all ")#mi("t")#text(" (see the Ki-Kim-Lee paper).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f073aa7d6d371a94634d0b648f6c1ccfb4fb788e8265a833a5e5f4f58dcd386b-3f0b58e93549ddf442d4c319fc8c86345d7e8a1364993ee225a68e3fb0544a8a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bob Robbins")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492462")[#strong[#text("Bob Robbins")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2018")])]

#text("Wanna work on the Robbinsian method for finding new primes? I found the pattern.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c9922ef884a925c2ef30bfd921c2576b8d7ce1f6e48fd33a485b6605d85d516-da74e966c9f95f06157b9459617424430f9f8a71219eb03c13f5cebdf36f5d44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zgtzsj")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492483")[#strong[#text("zgtzsj")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2018")])]

#text("Would you like to share it?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492474")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2018")])]

#text("For t>0, a simplified form of Gram’s type law works quite well at larger T heights for quickly detecting roots. It takes advantage of the fact that zero locations get more predictable as t or T increase.")

#text("Using this I was able to compute for both t=0.4 and t=0.5, 85031 zeroes each between T = 500k and 600k. N_t estimate for both is around 85030.67")

#text("If after finding the first few zeroes in a region using the classical approach we see that that the stdev(zero gaps)/avg_zero_gap metric is less than a certain value, for eg. 10%, which would imply an interval of avg_gap/2 would cover 5 standard deviations, then such a method can be used. The zero gaps are not seen to follow a normal distribution and have a fatter tail to the right hand side, but the fatter tail shrinks as t or T are increased.")

#text("The pseudoalgo works in a 3 step loop,")#linebreak()#text(" 1) Take a known root z_(t,i-1) and form a search interval")#linebreak()#text(" [z_(t,i-1) + avg_expected_gap/2, z_(t,i-1) + 3*avg_expected_gap/2]")#linebreak()#text(" 2) Evaluate H_t at the interval endpoints and detect if there is a sign change")#linebreak()#text(" 3) If a sign change exists, locate the root z_(t,i) using an interval solver")

#text("Locating z_(t,i) and using that to form the next search interval is necessary. For eg. we can’t use [z_(t,i-1) + 3*avg_gap/2, z_(t,i-1) + 5*avg_gap/2] and so on, since if there is a series of smaller or larger gaps, predetermined search intervals fail to detect all the roots. Also avg_expected_gap can be changed at every step, for eg. using [T-0.9T]/[N_t(T) – N_t(0.9T)]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath15, third thread: computing and approximating H_t | What's new")]], [#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-492497")[#strong[#text("Polymath15, third thread: computing and approximating H_t | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2018")])]

#text("[…] thread of the Polymath15 project to upper bound the de Bruijn-Newman constant , continuing this previous thread. Discussion of the project of a non-research nature can continue for now in the existing proposal […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/#comment-499814")[#strong[#text("El proyecto Polymath15 logra reducir la cota superior de la constante de Bruijn-Newman | Ciencia | La Ciencia de la Mula Francis")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2018")]

#text("[…] parte real de sus ceros determina una cota superior para el valor de Λ). En el segundo hilo [Tao, 02 Feb 2018] se decidió atacar el problema empezando por una versión sencilla (test problem) con […]")
]
