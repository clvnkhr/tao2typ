// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:35:02.026162+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Pythagoras’ theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Pythagoras’ theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 September 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/")[#text("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("My colleague ")#link("http://www.math.ucla.edu/~ricardo/")[#text("Ricardo Pérez-Marco")]#text(" showed me a very cute proof of ")#link("http://en.wikipedia.org/wiki/Pythagorean_theorem")[#text("Pythagoras’ theorem")]#text(", which I thought I would share here; it’s not particularly earth-shattering, but it is perhaps the most intuitive proof of the theorem that I have seen yet.")

#image("../assets/b7ed7aa9c0a0d4c21403d9f559114fe488434a59e580c27a0907b4a070480a5a-9210158156e640cdfc45e2ebe1fb8c8539e58d6487d5e95f3a900c9725d51fbf.jpg", width: 90%)

#text("In the above diagram, a, b, c are the lengths BC, CA, and AB of the right-angled triangle ACB, while x and y are the areas of the right-angled triangles CDB and ADC respectively. Thus the whole triangle ACB has area x+y.")

#text("Now observe that the right-angled triangles CDB, ADC, and ACB are all similar (because of all the common angles), and thus their areas are proportional to the square of their respective hypotenuses. In other words, (x,y,x+y) is proportional to ")#mi("(a^2, b^2, c^2)")#text(". Pythagoras’ theorem follows.")

#metadata(none) <tao-d888bcfd865457b67f6a>

#text("Here is a more “modern” way to look at Pythagoras’ theorem. The statement ")#mi("a^2 + b^2 = c^2")#text(" is equivalent to the assertion that the matrices ")#mi("\\begin{pmatrix} a & b \\\\ -b & a \\end{pmatrix}")#text(" and ")#mi("\\begin{pmatrix} c & 0 \\\\ 0 & c \\end{pmatrix}")#text(" have the same determinant. But it is easy to see geometrically that the linear transformations associated to these matrices differ by a rotation, and the claim follows.")

#text("Homework: why are the above two proofs essentially the same proof?")

#heading(level: 1)[#text("Comments (76)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69c4b2c71b7ba4d74ae1cd25a160190f2442b9ea2918c4c934db9712adfb4a2e-9b365d9e6cc5463408882a9f846e30c3459064e9d27b6e6daca114faf90a7f3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lalit warkde")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-34738")[#strong[#text("lalit warkde")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2009")])]

#text("watch any one of the links below to get the best explanation for pythagoras theorem")

#link("http://www.authorstream.com/Presentation/lalitwarkde-85464-pythagoras-theorem-mathematics-lalit-education-ppt-powerpoint/")[#text("http://www.authorstream.com/Presentation/lalitwarkde-85464-pythagoras-theorem-mathematics-lalit-education-ppt-powerpoint/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0aec19de3251f677275a11b0fcdab5eafc48153ec481a092f49b6b1cd55a85b7-8a7161f1bc3c05df6ee87bc37f0e81ce811f8054ab6da7d2d1c10675374e31cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nilotpal Sinha")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-50624")[#strong[#text("Nilotpal Sinha")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2011")])]

#text("Dear Prof. Tao")

#text("I think there is a typographical error in the line “while x and y are the areas of the right-angled triangles ADC and CDB respectively.” As per the diagram, x and y are the areas of CDB and ADC respectively instead of the reverse order.")

#emph[#text("[Corrected, thanks – T.]")]#emph[]

#text("Regarding the Pythagoras theorem, one of the most beautiful and non-trivial one is due to Dijkstra. You probably might already know it but I would like to post it just in case.")

#text("Theorem (Djikstra). If a, b, c are the sides a triangle and A, B and C are the respective opposite angles then sign(A + B – C) = sign(a² + b² – c²).")

#text("In a right triangle, A + B = 90 = C. Hence LHS is zero and this implies a² + b² = c². We have the Pythagoras Theorem as a special case of this simple looking theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0aec19de3251f677275a11b0fcdab5eafc48153ec481a092f49b6b1cd55a85b7-8a7161f1bc3c05df6ee87bc37f0e81ce811f8054ab6da7d2d1c10675374e31cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nilotpal Sinha")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-50627")[#strong[#text("Nilotpal Sinha")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2011")])]

#text("Dear Prof. Tao,")

#text("In his monumental book Elements, Euclid has proved the following theorem.")

#text("Theorem. (Euclid). If one erects similar figures on the sides of a right triangle, then the sum of the areas of the two smaller ones equals the area of the larger one.")

#text("The beauty of Euclid’s theorem is that there is no restriction on the shape of figures erected along the sides of a right triangle as long as they are similar. This proof by Pérez-Marco is a special case of Euclid’s theorem where we have erected similar right triangles on the sides of a right triangle.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-73298")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2011")])]

#text("Pythagoras’ theorem is so basic.So its proof,the simpler,the better :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-73301")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2011")])]

#text("And i think one basic proof is enough(like the one you mentioned), other “brilliant”,”amazing” proofs are not necesssary.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-74101")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2011")])]

#text("These are excellents mathematicans,Pythagoras,Terence Tao, and above all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-75461")[#strong[#text("Recent reading – Pythagoras’ Theorem « Linear Algebra")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2011")]

#text("[…] I read a pretty old post of Prof Tao on Pythagoras’ Theorem. All of us know what Pythagoras’ theorem says, and the 1st part of Tao ‘s post gives a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a624a4976f0260836d3507a8d0635c137f906c3377e77cfa2bf34a0ffc879d0e-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Palais")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-229987")[#strong[#text("Richard Palais")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2013")])]

#text("As has been mentioned, the proof you give Terry (which is definitely my own favorite), is often attributed to Einstein. In fact, Einstein attributes it to himself ! In his autobiography he says he discovered it at age twelve when his uncle told him about the theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cd3293b17fc4102811ce87a71f982a006bff024f4fadf65e5afe06087907fc0-4ba76bf4fed42f8a2ca5c337f3ef79cd4db842b060b6a124a522d20c80bf75fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mustafa Said")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-231846")[#strong[#text("Mustafa Said")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2013")])]

#text("Recently, I have found a way to generate a family of normal matrices with integer entries using Pythagorean triples. The construction may be new, as I have not been able to find it in the literature. If anyone is interested, I can send you my note.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b99e06edd9d5cd4aebd308915f8f7233853912e21d11a82affd0e84c72cbfef9-f8860ba084e08575cfa6eab5eb5a0bd939e7fe970b5b4faef153575b7c177ded.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Colin McLarty")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-242908")[#strong[#text("Colin McLarty")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("The earliest recorded use of the Pythagorean theorem in a proof to my knowledge (by far not the earliest hint that people knew the theorem) suggests this is the proof Hippocrates of Chios used in the 5th century BCE. He uses the theorem not for squares but for segments of circles cut off by the sides of an isoceles right triangle, to prove his famous theorem on areas of lunes, which suggests he saw it as bascially a theorem on scaling arbitrary figures. See ")#link("http://en.wikipedia.org/wiki/Lune_of_Hippocrates")[#text("http://en.wikipedia.org/wiki/Lune_of_Hippocrates")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/042e59057107e70fdbb04b472d1310c87bb9b6c40a467e702ca665af2dfc38ec-528f7dde35a73aa37951093959fea6efcfb0edd8f15f522c4ec289f2b3bc0816.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sushma sharma")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-242922")[#strong[#text("sushma sharma")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("A pythagoras triplet represents the lengths of the sides of a right triangle where all three sides have integer length..!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8451de615081149633e1028cdafd96db9f3985726146ebdf054e7822d9835833-b9598a1f91090ad452a4ea0ee7ddd92e9092f9e78ad6642c342abe4e43ad5983.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shay Ben Moshe")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-251098")[#strong[#text("Shay Ben Moshe")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2013")])]

#text("I find this proof wonderful, however I think that using the fact that the determinant of a rotation matrix is 1 is circular, because we use the identity $sin^2(x)+cos^2(x)=1$, which follows from the Pythagoras’ theorem.")#linebreak()#text(" A solution might be stating that this matrix take one orthonormal basis to another, and therefore the matrix is orthonormal, and thus its determinant is 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/256e4cf60029d7a192fcb3cd094b323a2452f8749f60f56dc949f3bc185fc5ce-cee646572d30373cfb8587c0be549bb3cfe1f9f61523ac1f488198698724cb83.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nice proofs of Pythagoras’ theorem | mathbeauty")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-251823")[#strong[#text("Nice proofs of Pythagoras’ theorem | mathbeauty")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("[…] Pythagoras’ theorem | What’s new. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4fdf28b2c5d85f9be69f92644129447cbc4c21a1771abbf416351bacddfa1f2-86f071612fc47af8119a715628ef2b21e573a1562aa201860d378b28fbbdd975.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pythagoras’ theorem | Cassandra Lee Yieng")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-450331")[#strong[#text("Pythagoras’ theorem | Cassandra Lee Yieng")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2015")])]

#text("[…] So we have Pythagoras’ Theorem: in a right-angled triangle, adding up the squares of the two shortest sides gives the square of the longest one. Terence Tao posted an intuitive proof here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c3e6583de50434ea37624ef3fce1c3d19320c9cc06bb9c0506241ba66b13b9e-efcd4532f53fc1dcfd402a61fdd2db3977843e83e24266a36b0054c3831f8266.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cliff")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-452694")[#strong[#text("Cliff")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2015")])]

#text("Interesting extensions of Pythagoras theorem.")#linebreak()

#text("Bet you didn’t know this about Pythagoras.")#linebreak()
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-452697")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2015")])]

#text("To find all Pythagorean triples ")#mi("(a, b, c)")#text(" with consecutive ")#mi("a, b")#text(", let ")#mi("S:= a+b")#text(" and observe that")#linebreak()#text(" ")#mi("S^2 - 2 c^2 = (a+b)^2 - 2(a^2+b^2) = -(a-b)^2 = -1")

#text("One can verify that the solution of this (Pell’s) equation (for the n-th such triple) is given by")

#mi("S_n + c_n \\sqrt {2} = (1+ \\sqrt {2})^{2 n +1}")

#text("Which implies (for the n-th such triple) the simple formula")

#mi("S_n = \\lfloor (1+\\sqrt{2})^{2 n +1} /2 \\rfloor")

#text("Showing asymptotically geometric growth of the solutions ")#mi("(a_n, b_n , c_n)")#text(" with (asymptotic) ratio ")#mi("(1+ \\sqrt {2})^2 = 5.828...")#text(".")

#text("The first few solutions are:")

#mi("S_1 = 7, S_2 = 41, S_3 = 239, S_4 =1393")

#text("with corresponding Pythagorean triples solutions")

#mi("(3, 4 , 5), (20, 21, 29), (119,120,169), (696,697,985)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-454775")[#strong[#text("A more motivated proof of the Pythagorean theorem | Daniel McLaury's Mathematical Diary")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2015")]

#text("[…] Pythagoras’s theorem | What’s New […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-470631")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2016")])]

#text("I wish you had explained it well instead of being elusive.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-476367")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2017")])]

#text("The differentials in Pi and Pythagoras are all same only look different…, the order of all is founded in One…..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e91c7c14b684e25f1f12cb96694809c656d595a4b3278f065a4c9cd8de02e23f-a6d691cc014692b6d4b3d92572ec90f14a54b4ad94c27e126b7cfdac4d8d4f50.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-588988")[#strong[#text("Kevin")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2020")])]

#text("Here is an interesting proof involving dividing a triangle into infinitely many smaller triangles and using infinite geometric series:")

#link("https://ibtaskmaker.com/maker.php?q1=618")[#text("https://ibtaskmaker.com/maker.php?q1=618")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-589001")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2020")])]

#text("Is the Euclidean norm in R^2 the only norm which is invariant under a positive dimensional group of linear transformation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-589302")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2020")])]

#text("Up to a linear change of coordinates, yes (this follows from the classification of one-dimensional Lie subgroups of ")#mi("GL_2({\\bf R})")#text(", which arise from applying the exponential to one-dimensional Lie subalgebras of ")#mi("{\\mathfrak gl}_2({\\bf R})")#text(" and ruling out those groups that are non-compact; one can also use ")#link("https://en.wikipedia.org/wiki/Unitarian_trick")[#text("Weyl’s unitary trick")]#text("). If one allows degenerate metrics or pseudometrics then one also has the Galilean semimetric ")#tao-math("\\left\\|(x,t)\\right\\| := \\left|t\\right|", block: false)#text(" and the Lorentz pseudometrics ")#tao-math("\\left\\| (x,t)\\right\\|^2 = t^2 - c^2 x^2", block: false)#text(", and linear transforms thereof (cf. the ")#link("https://en.wikipedia.org/wiki/SL2(R)#Classification_of_elements")[#text("classification of elements")]#text(" of ")#mi("SL_2({\\bf R})")#text(" into elliptic, parabolic, and hyperbolic elements).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-2/#comment-637984")[#strong[#text("Het verhaal achter: de Pythagoraskalender (1) – Bollebus")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2021")]

#text("[…] Tao, Pythagoras’ Theorem. Blog, 2007. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f88718510e07a7be094a9daec9a4746582cc3017ae314838e4a43eeed262ae60-22963fac043ad48c8e0dff3c25d7f7e638848b62f70a0f26582df11d0a455a51.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rupert Swarbrick")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9331")[#strong[#text("Rupert Swarbrick")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2007")])]

#text("This is interesting. I totally agree that it’s cute and short, but I really don’t see why it’s obvious that ADC and CDB are similar. Unless I’m missing something, could it be that showing this is where the effort in the proof comes in?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d707e8de9784e4e7b1280b0f9cdf443cb5644f007cceb7b2c0fefb18212fbea-2cb1a896650c47f72bd25f53a26a7779cb7445b3d76dbbf401a05d1371c4d41e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dickpalais")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-476368")[#strong[#text("dickpalais")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2017")])]

#text("There is an interesting story that goes with this proof. Einstein, in a biographical note, says that when he was about 12 years old, his uncle told him about Pythagoras theorem one evening and challenged him to find a proof. Einstein says he came up with that proof by the next morning.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9333")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2007")])]

#text("Dear Rupert,")

#text("ADC is similar to ACB because they have two angles in common (a right angle, and the angle at A). Similarly CDB is similar to ACB. Since two triangles that are similar to a third are also similar to each other, the claim follows.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9335")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2007")])]

#text("My favorite proof of the Pythagorean theorem is given by ")#link("http://www.dbai.tuwien.ac.at/proj/pf2html/proofs/pythagoras/pythagoras/pythagoras3.gif")[#text("this")]#text(" picture. You can place four copies of the triangle in a tray which is a square of size a+b, leaving a square of size c. Or you can place those four same triangles in the same tray in a different arrangement, leaving a square of size a and a square of size b. But Perez-Marco’s proof is comparably virtuous.")

#text("Arguably the determinant “proof” is not quite fair, or not a proof. The Pythagorean theorem confirms the analytic definition of plane geometry using the axioms of synthetic geometry. But expressing areas with determinants relies on analytic geometry.")

#text("On the other hand, once you have the basic Pythagorean theorem (or perhaps the n-dimensional version for the l^2 norm of vectors) to validate analytic geometry, you can use it to write interesting generalized Pythagorean theorem. The widest and prettiest such generalization that I know is as follows: If you have a flat k-dimensional region in R^n, then the square of its volume is the sum of the squares of the volumes of its (n choose k) coordinate projections. (So as a special case, you get the expected Pythagorean theorem for the facets of a simplex with a fully right-angled corner.) There is an elegant proof, I’m sure with variations, using determinants and minors.")

#text("But I have the feeling that there are yet more general such results.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arkadas Ozakin")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9343")[#strong[#text("Arkadas Ozakin")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2007")])]

#text("Alexander Givental has a nice discussion of Pythagoras’ theorem where he praises this proof, here: ")#link("http://math.berkeley.edu/~giventh/papers/eu.pdf")[#text("http://math.berkeley.edu/~giventh/papers/eu.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ibrahim")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-589736")[#strong[#text("ibrahim")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2020")])]

#text("what a nice surprise to see you here hocam")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9344")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2007")])]

#text("Dear Greg,")

#text("That is a nice proof too. Perez-Marco’s proof though is the first area-based proof I have seen that does not require subtraction (the proof you link to adds in four triangles and then subtracts them at the end). So it is a bit more “tropical” or “combinatorial”.")

#text("The determinantal proof can be expressed in synthetic geometry without circularity (i.e. without secretly using Pythagoras’ theorem within the proof). After arbitrarily selecting an origin, synthetic geometry (with heavy reliance on the parallel postulate, of course) allows one to express the plane as a vector space, and one can show that linear transformations on this space affect area (of, say, triangles) by a proportionality constant, which one can then declare by definition to be the determinant of that transformation (there is a slight issue regarding orientation, but never mind that). Then one can set up the Cartesian coordinate system (which does not require Pythagoras’ theorem, as we will not need the formula for the metric in this system) and convert linear transformations to matrices. The fact that the determinant is multilinear in the rows of the matrix can be shown by various area cut-and-paste and similarity arguments. If you put it all together you get something which is remarkably similar to the first proof given in the post. [It will be much longer, of course, because one is also setting up a lot of modern analytic geometry, linear algebra, etc. along the way, but one can view all that as a ")#link("http://en.wikipedia.org/wiki/Sunk_cost")[#text("sunk cost")]#text(" of modern mathematics. :-) ]")

#text("As for the k-dimensional version of Pythagoras, I guess the modern interpretation would be that a Hilbert space structure on a vector space V canonically induces one on the exterior power ")#mi("\\bigwedge^k V")#text(", for instance passing to the totally anti-symmetric component of the Hilbert space ")#mi("V^{\\otimes k}")#text(" under the permutation action of ")#mi("S_k")#text(", which is clearly unitary. (Indeed, one can verify that the map ")#mi("V \\mapsto \\bigwedge^k V")#text(" is a functor in the category of Hilbert spaces.) If one then uses an orthonormal basis on V to generate an orthonormal basis of ")#mi("\\bigwedge^k V")#text(" via wedge products I think you then get the claim. Whether this is the “simple” proof of the theorem depends on your taste, I guess. :-)")

#text("Arkadas: Thank you very much for the link! It seems this proof (in one form or another) has quite a long history, dating back to Euclid himself.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9348")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2007")])]

#text("The two-triangle proof does not require subtraction, but it does require division, because the triangle areas are merely proportional to the terms rather than equal. Although Givental argues that division is more essential to the story than subtraction. Hmm…")

#text("After saying that the determinants are not quite a proof, it bothered me that you had said that it was equivalent to the two-triangle proof, which counts by any measure. Basically your long explanation resolves this inconsistency. Even so, the length of your fill-in does indicate to me that using determinants is still contrary to the intentions of the Pythagorean theorem, even if it isn’t truly circular.")

#text("Yes, you have a perfectly fine first-year graduate proof of the generalized Pythagorean theorem. But there is also a proof, which may or may not be an equivalent proof, that uses only undergraduate linear algebra and geometry. You can assume that the region in question is a parallelipiped that is subtended by vectors that make rectangular matrix M. Then you can show that its volume is sqrt(det M^T M) by rotational invariance. Then you can take the determinant of [[0,M^T],[-M,I]] in two ways. You can either do a block row operation to see that its determinant is det M^T M; or you can group the terms in its determinant to get a sum of squares of minors.")

#text("Probably the graduate proof is conceptually better in the end, but this phrasing is also interesting from the point of view of enumerative combinatorics.")

#text("(My apologies for not latexing the formulas. It’s because you have no preview button.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9349")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2007")])]

#text("Dear Terry,")

#text("I think that the proof you mention is usually attributed to Einstein.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9352")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2007")])]

#text("One qualm I have here is the assertion that areas of similar figures are in the “duplicate ratio” of their sides. That is, x:y::a^2:b^2. Of course it’s true in Euclidean geometry, but the last time I looked at the Elements, the theory of proportions didn’t come up until book V, while the Pythagorean Theorem caps off book I. Are you sure that you aren’t begging the question somewhere here?")

#text("Even if not, it’s still unsettling. This proof may be “intuitive” to you, but it’s based on a much more complicated theoretical background than the better-known proofs. Frankly, I’ve yet to find one that improves on the elegance of Euclid’s, exhibiting explicit shears to send the two squares onto the third.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9356")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2007")])]

#text("Dear John,")

#text("According to the Givental reference mentioned above, the assertion that areas of similar figures are in the duplicate ratios of their sides is Euclid’s VI.19, but does not use Pythagoras’ theorem in its proof. Indeed, Euclid gives two independent proofs of Pythagoras: the shearing proof in I.47 and a variant of the above proof in VI.31. In any event, one can nowadays prove VI.19 by a variety of means (for instance, one could invoke the uniqueness of Haar measure up to constants).")

#text("One could argue that the two proofs of Euclid are essentially the same proof (modulo some basic linear algebra); they are both exploiting the multilinearity, antisymmetry, and rotation invariance properties of ")#mi("2 \\times 2")#text(" determinants (or wedge products, if you wish) to achieve the same end result, but use those properties in a slightly different order to get there. Elegance is of course a subjective matter of taste, but I find the proof above to be easier to remember than the shearing proof, and it feels like less of a “fortunate coincidence” that the proof works at all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kaiming")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9357")[#strong[#text("kaiming")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2007")])]

#text("Finally, I understood a theorem or proof discussed here!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b2998bcffc8177489c8ec6d6a7626fb64df094597326e49411769be46619937c-4efccc0eb0bcc79e40a4daa24a2011b51de3cdabf7598e0fec0d7b5ca610596d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jasper Crowne")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9360")[#strong[#text("Jasper Crowne")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2007")])]

#text("I’ve seen this proof given in two of my physics courses (one on “mathematical methods” and one on fluid dynamics) as a cute application of dimensional analysis; I’m pretty sure the source for that formulation is G. I. Barenblatt’s book on self-similarity, and he cites A. B. Migdal’s book Qualitative Methods in Quantum Theory.")

#text("Barenblatt also states in the footnote that typically similarity of triangles is given after Pythagoras’ Theorem in rigorous geometry courses (so John’s objection is not new).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jay")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9410")[#strong[#text("jay")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2007")])]

#text("Yes, in the page 2 of Migdal’s book!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9438")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2007")])]

#text("I don’t know much about generalizations, but it seems to me that")#linebreak()#text(" the problem known as Fermat’s Last Theorem is an obvious such one.")#linebreak()#text(" Since it may be of interest to smart high school students, let me share")#linebreak()#text(" a partial proof of it, which doesn’t seem is mentioned in Wikipedia.")#linebreak()#text(" It uses simple inequalities, which might be enlightening to people")#linebreak()#text(" thinking analytically, and is due to I. Paasche, Praxis der Math. 3 (1961), 80:")#linebreak()#text(" For x>0 and n>2 we have x^n + (1+2x)^n/2 \\leq (x+1)^n (Exercise 1).")#linebreak()#text(" Thus if a^2 – 1 \\leq 2b, the equation a^n + b^n = c^n so no solutions")#linebreak()#text(" in natural numbers a,b,c and n>2 (Exercise 2).")#linebreak()#text(" Does anybody know a stronger result, which uses just high school")#linebreak()#text(" level arguments?")#linebreak()#text(" Personally, I like Fermat better than Pythagoras. To have his student")#linebreak()#text(" Hippasus drowned for coming up with a new idea (Square root of 2,")#linebreak()#text(" Wikipedia) seems like sending a bad message for the future.")#linebreak()#text(" Thankfully, present day mathematicians respect their own original")#linebreak()#text(" thinkers and don’t have to rely on other areas of science for input.")#linebreak()#text(" On the other hand, Fermat’s likely bluff must have driven a lot of")#linebreak()#text(" people crazy, but then he lived in different times:")#linebreak()#text(" “It was the convention among mathematicians in his day to challenge")#linebreak()#text(" each other to prove a result, often not publishing their own proof")#linebreak()#text(" to retain an advantage in such competitions” (Fermat, Wikipedia).")#linebreak()#text(" Anonymous: what do you think about the book “Henri Poincare")#linebreak()#text(" and Relativity Theory,” by A. A. Logunov (2004), available at:")#linebreak()#text(" ")#link("http://arxiv.org/abs/physics/0408077")[#text("http://arxiv.org/abs/physics/0408077")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of François")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9503")[#strong[#text("François")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2007")])]

#text("According to ")#link("http://xavier.hubaut.info/coursmath/var/pytha.htm")[#text("http://xavier.hubaut.info/coursmath/var/pytha.htm")]#text(" this proof is due to Henri Lebesgue.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9511")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2007")])]

#text("There is a beautiful discussion of this proof in Polya’s Mathematics and Plausible Reasoning, where he shows not just the proof but how one might think of it. Roughly his account goes like this. You are trying to show that ")#mi("a^2+b^2=c^2")#text(". The obvious geometric interpretation of this is to put squares on the sides of the triangle, as one often sees. But a standard move in mathematics, one that Polya strongly advocates, is to ")#emph[#text("generalize")]#text(". In this instance, if you’re in a generalizing frame of mind, you will notice that you could use ")#emph[#text("any")]#text(" shape: there’s no particular reason to use squares. But another standard move in mathematics is to ")#emph[#text("specialize")]#text(". One also observes that it is sufficient to prove the result for just one shape. Is there a good shape to pick? Well, a pretty good candidate is a triangle of the shape you start with, since if you put one on the hypotenuse it will have the same area as the triangle itself. It is then easy to see that the other two triangles are congruent to the smaller triangles in your diagram. I hope I’ve explained that clearly: it’s one of my all-time favourite how-to-think-of-this-proof discussions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91841f5e59201923e09be98a5cf5917591fef164a2a040b79e78d927874dd4bf-c2c4379bfc95793e545279b1b6a44f80c80394352dfb8cc2ea2a9f97264ce0e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Cook")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9513")[#strong[#text("James Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2007")])]

#text("Another “modern” way to think of this is to note that the operator with matrix ")#mi("\\begin{pmatrix} a & b \\\\-b & a \\end{pmatrix}")#text(" preserves the inner product on ")#mi("\\bold{R}^2")#text(" with the factor ")#mi("a^2+b^2")#text("; this of course amounts to another way of stating Terry’s observation about determinants.")

#text("To “prove” the Pythagorean theorem is essentially to give an argument for why we should use the 2-norm to measure distances; the reason always comes down to the niceness of the rotation group. (See ")#link("http://www.scottaaronson.com/papers/island.pdf")[#text("here")]#text(" for a discussion arising in the context of quantum mechanics.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9517")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2007")])]

#text("I once gave a talk about Pythagoras’s theorem and before it I worked out an answer to exactly this question (of why the 2-norm is rotation-invariant). It’s a slightly strange answer but it at least has the quality of a derivation rather than a verification. The basic idea is to use calculus, which can be done in several ways. One is to say that we know that if we have a parametrized curve ")#mi("(x(t),y(t))")#text(" that is always orthogonal to its tangent, then it will describe a circle. (This is how I avoid mentioning the number 2.) The condition works out as ")#mi("x(t)x^{\\prime}(t)+y(t)y^{\\prime}(t)=0")#text(", or equivalently ")#mi("\\frac{d}{dt}(x(t)^2+y(t)^2)=0")#text(". In other words, ")#mi("x^2+y^2")#text(" is constant along such a curve: note that the number 2 came out of solving a simple calculus problem rather than out of the blue.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9518")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2007")])]

#text("PS Just looked at the Givental discussion mentioned above and found that he talks about Polya’s discussion and that Polya himself seems to have suggested that the idea of approaching it like that was due to Euclid.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e23ea31230ea71ae18ec0dbd2a8a603ed2a04a629e852bb276b96c9ba2b2e2f1-e89718d62ddbc42fd300ead58f018902393318d642672627d62f6cced1c3b79c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9533")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2007")])]

#text("By the way, Terry, this submission is misclassified! It should clearly be math.HO.")

#text(":-) What an ironic comment to post here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9534")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2007")])]

#text("Now math.HO. :-)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-589340")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2020")])]

#text("What does HO mean?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sam")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9596")[#strong[#text("sam")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2007")])]

#text("I dont follow all the discussion here. But, here is a simple way to look at the Pythagoras theorem.")#linebreak()#text(" 1) It is a scaled version of the identity ")#mi("\\sin^2(\\theta) + \\cos^2(\\theta) = 1")#text(".")

#text("2) It is easy to see where the squares come from in the above identity. It comes from the composition of two projections. In triangle ABC, think of AB as being of unit length. Then the projection of AB on BC gives a ")#mi("\\cos(\\theta)")#text(" and this followed by the projection of BC on BD gives another ")#mi("\\cos(\\theta)")#text(". Thus BD is ")#mi("\\cos^2(\\theta)")#text(". Similarly DA is ")#mi("\\sin^2(\\theta)")#text(".")

#text("3) Is this considered obvious enough?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f88718510e07a7be094a9daec9a4746582cc3017ae314838e4a43eeed262ae60-22963fac043ad48c8e0dff3c25d7f7e638848b62f70a0f26582df11d0a455a51.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rupert Swarbrick")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9597")[#strong[#text("Rupert Swarbrick")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2007")])]

#text("Oh dear, I realised why they were similar on the bus on the way home and this is the first time since then I’ve been on the internet. Sorry for the stupid comment!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9611")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2007")])]

#text("Sam, I hope you’re not using the Pythagoras’ Theorem to proof the trig identity. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sam")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9616")[#strong[#text("sam")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2007")])]

#text("Anonymous, if I were to prove the identity using the Pythagoras’ Theorem, I dont need to think of it as two projections. ")#mi("BC = AB \\cos(\\theta)")#text(" and ")#mi("CA = AB \\sin(\\theta)")#text(". Now using the Pythagoras’ theorem the result follows.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9627")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2007")])]

#text("Dear Sam,")

#text("You are correct that one can use the identity ")#mi("AB = AD + DB")#text(" instead of ")#mi("\\text{area}(ACB) = \\text{area}(ADC) + \\text{area}(ACB)")#text(", together with the similarity of the triangles ACB, ADC, ABC, to obtain a proof of Pythagoras’ theorem which does not involve area and is thus a little more elementary. As is often the case, though, the elementary proof is a little longer than the “slick” proof, requiring a bit more algebraic manipulation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Dimakis")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-9781")[#strong[#text("Alex Dimakis")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2007")])]

#text("I was thinking that the proof essentially used the fact that any orthogonal")#linebreak()#text(" triangle can be expressed as a union of two scaled copies of itself. (only rotations and translations allowed). This reminded me of iterated function systems (IFS) -but with some restrictions on the mappings.")#linebreak()#text(" Does this go any deeper? Are there identities one can get from a self-similarity property of a class of objects?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott David Kelly")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-11542")[#strong[#text("Scott David Kelly")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2007")])]

#text("I’m just not convinced…")

#link("http://rjmason.blogspot.com/2007/04/with-many-cheerful-facts-about-square.html")[#text("http://rjmason.blogspot.com/2007/04/with-many-cheerful-facts-about-square.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/add6ac292e2699841111424ecc77a44f097aabdbd9ff1511882839de955ee942-8f57554be21b6c5997ca8c31640c8aeac1d6b636258305cce13037e3bbb9144f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of derek hacon")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-11572")[#strong[#text("derek hacon")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2007")])]

#text("Surely the point of Pythagoras is that, although it´s so obvious intuitively (e.g. via the arguments given in various posts), deducing it rigourously from axioms for euclidean geometry seems to be a waste of energy. The classical way of getting around the problem was, of course, to replace all those charming axioms by the notion of euclidean distance, thus turning Pythagoras into a definition (of distance) rather than a theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-11689")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2007")])]

#text("Hi Terence,")

#text("I am speculating the following:")

#text("Consider constructing this 2D geometric representation that appears to unify concepts of Pythagoras, Archimedes, Newton and Einstein:")

#text("An [obtainable?] ideal of E=mc^2 [from Einstein] when m=1:")

#text("At the origin (0,0), construct a circle with a radius representing c as a vector.")

#text("All rays from the origin may be considered as vectors of c.")

#text("Focus only upon the x and y axes.")

#text("In all four quadrants, draw the hypotenuse from the end of each vector c on the x to the y axis, to construct a circumscribed square.")

#text("Note that each hypotenuse is equal to c*2^(1/2) from Pythagoras.")

#text("Each hypotenuse may represent a scalar relative speed.")

#text("Circumscribe the original circle within a square where both the x and y axes bisect the edges, each of length 2c, of this square.")

#text("This is a step in how Archimedes attempted to determine the value of PI by maximizing the perimeter of a regular polygon within and minimizing the perimeter of a regular polygon outside the circle.")

#text("In Newton’s equation: F=ma=(1/2)mv^2")

#text("From the above construction, with m=1: (1/2)*(c*2^(1/2))^2=c^2.")

#text("This is apparently the energy E obtained by Einstein when m=1.")

#text("Yet the maximum relative speed from -x to x or -y to y is 2c.")

#text("If Einstein had used this value then maybe E would equal 4c^2.")

#text("This appears to suggest that c may be “constant extrema” rather than merely a constant.")

#text("The constructions allow for these areas:")#linebreak()#text(" square c^2 < square 2*c^2 < circle 2*PI*c^2 < square (2c)^2=4c^2")

#text("Please correct any errors.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/003c83b5df1e699383d8de8badaaed0e0e1f9b4acc2e7fc309fa6f60dd4d7848-7957b46895cc56a8e83455506682b5f82b4d923a846c3917ec2a0c0c617f11df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of piyushdadriwala")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-11825")[#strong[#text("piyushdadriwala")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2007")])]

#text("i am piyush dadriwala,very creative ,i have done some new search in maths,a new theorum on right angle triange,a new formula and table for two digits,workon pascal triangle and get a unique method (equation),through pyramid.")#linebreak()#text(" piyushdadriwala")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbf445dd3ded972a5d1b62126dac2900bf47db6c85c39b95626f92b945e4f092-821d2a67ec2aa6fd2150e7112d80a9cf9bad4da7b90b8dab1f324d9a6a89f5c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-11837")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2007")])]

#text("This is the only theorem a proof of which was published by a President of the United States. By the way, Jimmy Carter’s Command Thesis at Naval Postgraduate School (roughly equivalent to a M.S., and gave him the right to command a naval vessel, when he had seniority) used Laplace transforms correctly. When JFK had a dinner for top scientists, it was said that this was the greatest scientific dinner at the White House — since Jefferson dined alone. How far we’ve fallen to the anti-scientist Bush. Harding published a wonderful translation of Agricola’s De Rerum Metallica, but that was mostly qualitative. Other countries have had Mathematicians in high and top office; unlikely ever again in the USA.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-11949")[#strong[#text("Pagina lu’ Nicu » Blog Archive » Insemnari Matematice")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2007")]

#text("[…] Cei pasionati de matematica o sa aprecieze demonstratia: link. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a8e70b3b045ce2d2c9ca3cca7435b1f8e9d6b694b5cc1733bf73565a54ccae7e-90e401a0377a3c06d35cdea617bc01dfdee80057a7f07cd1f06c5081df7756c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dave Flanders")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-12009")[#strong[#text("Dave Flanders")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2007")])]

#text("I am not a mathematician, but wandered onto this blog somewhat by accident. I know of a site which claims to have 75 proofs of the Pythagoras theorem (see link). I would be interested to hear from the “experts” how many of these proofs are actually unique. In any event, the site may be of interest to some of you.")

#link("http://www.cut-the-knot.org/pythagoras/index.shtml")[#text("http://www.cut-the-knot.org/pythagoras/index.shtml")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e833b6f6241ea9335c528e96292a69094230e53202fc077f499cafb5def22092-8afd75c92ea211cfec1d98c1820c7d42c47f83778b4a669040ed9d022f045f32.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Welford")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-12177")[#strong[#text("Michael Welford")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2007")])]

#text("The proof shown here has long been been my favorite. But the fact that the largest triangle is reflected compared to the smaller ones feels like a blemish. This has bothered me many for years now. I’ve seen other proofs that display triangles congruent to the ones in this proof, and always the smaller triangles share the same sense and the big one is reflected.")

#text("Is this big triangle reflected business the “issue regarding orientation” that you mention in your comment? If so could you expand on the issue?")

#text("Thank you for this post. I’ll be looking at rotation matrices to see if they can help me exorcise my reflection demon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-12228")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2007")])]

#text("Dear Michael,")

#text("I think the presence of the minus sign in the determinant formula ")#mi("\\det \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} = ad-bc")#text(" makes some sort of reflection or subtraction inevitable. Note that one can use arguments which do not involve reflection but instead involve subtraction, for instance the proof mentioned in Greg Kuperberg’s first comment. But I doubt that a “totally positive” proof exists, given how fundamental determinants are to the relevant geometry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b29a7adf98fedc044a7d40dbe30f01e031e53712ddb6d43eda31b89f6ed5e72-5b66fde2700663134500b3ab52a6ae75b36db68dfa2ec56586c26ab09713a3e9.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jd2718")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-13848")[#strong[#text("jd2718")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2007")])]

#text("I saw a nice Euclidean proof today (sometimes called the “windmill”)")

#text("On right triangle ABC (rt angle at C) raise squares ACFG, BCHI, and ABDE. Construct perpendicular CK to DE, interesecting AB at J.")

#text("Note triangles EAC and BAG are congruent (SAS).")#linebreak()#text(" (EA and BA are sides of the same square. AC and AG are sides of the same square. Included angles are each a rt angle + angle BAC)")

#text("The area of EAC is half of rectangle AEKJ (common base, same altitude)")#linebreak()#text(" The area of BAG is half AGFC (common base, same altitude).")#linebreak()#text(" AGFC = AEKJ")

#text("The process can be repeated to show JKDB = BCHI, leadiing to Pythagoras (the sum of the squares equals the area of the two rectangles, which form the square of the hypotenuse.")

#text("Nothing fancier here than SAS.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/932ed592f893eef3bc636a8f4beb1296a0e591646747b9b56c21c30da01c6440-328e45c09d3dd1e43bcff04745a90e7031cd3f2c8e9e5a53a55855f03a975551.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Richter")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-13950")[#strong[#text("Johan Richter")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2007")])]

#text("Here’s a nice presentation of Euclide’s elements where you can find the above proof, among other things: ")#link("http://aleph0.clarku.edu/~djoyce/java/elements/toc.html")[#text("http://aleph0.clarku.edu/~djoyce/java/elements/toc.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b327d28fdba8d414d83a5ad722d540b3eeddd0fafaec2c962c38eb76ca160b89-4b626ae0e22d635b57a7d370cb1efa1a0869d671ea85f8d487eebc939447cb67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A Parr")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-25372")[#strong[#text("A Parr")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2008")])]

#text("I don’t know where anyone would get the idea that Jimmy Carter was ever much of a nuclear engineer on any submarine in the Navy. I suppose you can create as he’s been known to do some very creative publicity seeking info. But for what it’s worth one source before me (Oct entry) said he went to the Navy Postgrad School. Actually, he went to Union College in N.Y., One source said he was on a nuclear submarine, the Seawolf. He left the Navy in 1953, the nuclear Seawolf was launched in 1957 and striken in 1997. If he grad from the Academy in1946 and left the Navy in 53. I sure didn’t see anyone trying to keep him in. I have 20 years in the Navy. 3 nuclear boats and 3 surface ships. Got a Masters in Advance Calculus and might have enough experience at sea, not in school to qualify for command.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-25451")[#strong[#text("Prokrastination oder Blogroll (I): Terence Tao at LEMUREN-Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2008")]

#text("[…] Satz des Pythagoras-theorem […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-25501")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("When Jimmy Carter graduated Navy Postgraduate School, he had the equivalent of an M.S.")

#text("He’d written a Command Thesis. It granted him, on passing, the right to command a vessel when he had enough seniority (which he never did).")

#text("The thesis was about towed (by surface vessels or submarines) passive arrays of microphones, and the signal analysis thereof, and actually used either Laplace Transforms or Fourier Transforms (I forget which, but someone here should be able to supply the thesis date, title, and which of those it used).")

#text("Not a Nuclear Physicist (not counting being mentored by Hiram Rickover, Father of the Nuclear Navy, Jimmy took one single Intro to Nuclear Engineering course. Jimmy Carter was the closest we’ve had to a Scientist President since the great Thomas Jefferson, and the metallurgical and mining engineer Hoover, albeit he was not known for publishing Math.")

#text("Compare and contrast to the man who, in his first Presidential campaign, in debate, when challenged with clear and unambiguous arithmetic that exposed the bald lie that one can simultaneously cut taxes, boost military spending, and balance the budget, glibly dismissed the disproof as “Fuzzy math!”")

#text("I know this great blog by Terry Tao is NOT about politics, but at this point it is arithmetically significant that the misadventure in Iraq has cost several TRILLION dollars in amortized estimated real cost to the U.S. Economy. I mention that, because of this week’s White House Budget, the first to exceed $3 x 10^12, raises the “defense” budget to MORE THAN THAT OF EVERY OTHER NATION IN THE WORLD ADDED TOGETHER.")

#text("I don’t care if you vote Democrat, Republican, Independent, Socialist, Natural Law, or whatever fringe you want. And don’t go waving Arrow’s Theorem in my face. But shouldn’t the President of the United States actually have a clue about simple arithmetic, and should hire Cabinet officers some of whom know Algebra, Geometry, Calculus, and (one can hope) enough Differential Equations to follow the basic theorems in Mathematical Economics. Shouldn’t the Secretary of the Treasury understand Non-Gaussian Merton-Black-Scholes theory, the relationship between volatility and the spot asset’s price as important for explaining return skewness and strike-price biases in the Black- Scholes (1973) model, the Cox Call Option Valuation Models? As S. G. Kou has written [Computational Intelligence for Financial Engineering, 2000. (CIFEr) Proceedings of the IEEE/IAFE/INFORMS 2000 Conference on,")#linebreak()#text(" Publication Date: 2000")#linebreak()#text(" On page(s): 129-131]:")

#text("“Brownian motion and normal distribution have been widely used to study option pricing and the return of assets. Despite the successes of the Black-Scholes-Merton model based on Brownian motion and normal distribution, two puzzles which emerged from many empirical investigations, have had much attention recently: 1) the leptokurtic and asymmetric features; 2) the volatility smile. Much research has been conducted on modifying the Black-Scholes models to explain the two puzzles. To incorporate the leptokurtic and asymmetric features, a variety of models have been proposed. The article proposes a novel model which has three properties: 1) it has leptokurtic and asymmetric features, under which the return distribution of the assets has a higher peak and two heavier tails than the normal distribution, especially the left tail; 2) it leads to analytical solutions to many option pricing problems, including: call and put options, and options on futures; interest rate derivatives such as caplets, caps, and bond options; exotic options, such as perpetual American options, barrier and lookback options; 3) it can reproduce the ‘volatility smile'”")

#text("I’d rather see the Volatility Smile than ever again that smug dry-drunk draft-dodger smirk from the (thankfully last by him) State of the Union and Intersection Speech.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-25502")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("Sorry, I forgot to sign the above, contrasting:")#linebreak()#text(" Jefferson, Thomas 1801-09")#linebreak()#text(" Hoover, Herbert 1929-33")#linebreak()#text(" Carter, Jimmy 1977-81")#linebreak()#text(" Bush, George W. 2001-09")

#text("And the word is Nuclear. Repeat after me. “Noo-cle-ar.” Not “nook-u-lar.”")

#text("*sigh*")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bdfe397f73c05b78bc83a973dbc8c56cef68443e11e02a4e7f9b44427799d6a4-78a643a0953b34e957b3f31f66c22b8fcb8bedc75188c044133ad0fe18013626.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Geoffrey A. Landis")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-25546")[#strong[#text("Geoffrey A. Landis")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("(some guy named A. Parr wrote):")#linebreak()#text(" I don’t know where anyone would get the idea that Jimmy Carter was")#linebreak()#text(" ever much of a nuclear engineer on any submarine in the Navy.")

#text("I have to admit to being baffled at A. Parr’s post, apparently in reply to Jonathan’s comment. Jonathan didn’t ever state that Jimmy Carter was a nuclear engineer on a submarine in the Navy, so why in the world is Parr so excited about rebutting something that wasn’t actually said?")

#text("Carter served on submarines (1), and he also served as a nuclear engineer (2). However, he did not serve as a nuclear engineer onboard a submarine.")

#text("(1)DEC 1948 – FEB 1951 — Duty aboard USS Pomfret (SS-391); FEB 1951 – NOV 1951 — Duty with Shipbuilding and Naval Inspector of Ordnance, Groton, CT as prospective Engineering Officer of the USS K-1; NOV 1951 – OCT 1952 — Duty aboard USS K-1")

#text("(2) 1952-1953, Duty with US Atomic Energy Commission (duty with Division of Reactor Development, duty with Naval Reactors Branch, US Atomic Energy Commission, Washington, D.C. “assisting in the design and development of nuclear propulsion plants for naval vessels.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kc")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-26711")[#strong[#text("kc")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2008")])]

#text("There is a slight extension of the Generalized Pythagoras theorem")#linebreak()#text(" mentioned by Greg Kuperberg earlier. If one represents a ")#mi("k")#text("-flag in ")#mi("R^n")#text(" as being spanned by the columns of an")#linebreak()#text(" ")#mi("n \\times k")#text(" real matrix ")#mi("X")#text(" and let ")#mi("X_I")#text(" denotes the ")#mi("k \\times k")#text(" sub-determinant determined by the rows of ")#mi("X")#text(" indexed by ")#mi("I")#text(",")#linebreak()#text(" then the Pythagoras theorem is ")#tao-math("\\det(X^TX)=\\sum_{\\left|I\\right|=k}  (X_I)^2,", block: false)#text(" which states that the square of the volume of the ")#mi("k")#text("-flag")#linebreak()#text(" is the sum of squares of the volumes of the projections.")

#text("As usual, by de-symmetrizing one get ")#tao-math(":=\\det X^TY =\\sum_{\\left|I\\right|=k} (X_I Y_I)", block: false)#text(" which follows from Cauchy-Binet ( ")#link("http://en.wikipedia.org/wiki/Cauchy-Binet_formula")[#text("http://en.wikipedia.org/wiki/Cauchy-Binet_formula")]#text(" ). But one")#linebreak()#text(" can generalize further by introducing an arbitrary “metric” ")#mi("A")#text(" into the “inner product” to get")#linebreak()#text(" ")#tao-math("A:=\\det(X^TA Y)=\\sum_{\\left|I\\right|=k,\\left|J\\right|=k} A_{IJ}X_I Y_J", block: false)#text(" where")#linebreak()#text(" ")#mi("A_{IJ}")#text(" is the ")#mi("I,J")#text(" minor of ")#mi("A")#text(" which can be proved by")#linebreak()#text(" applying Cauchy-Binet twice: ")#mi("\\det(X^T(AY))=\\sum_{I} X_I (AY)_I= \\sum_{I} X_I \\sum_{J}A_{IJ}X_J")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3d673fb32d9c24608594a70e088a3b49d1c94b28ccf14d81c0e75ddf8ed1fca-ac25f8bff55160d5ff71baff4d6997f506abbdb2034e48fe84bf880a149ce79d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Teorema di Pitagora « In teoria")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-27041")[#strong[#text("Teorema di Pitagora « In teoria")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2008")])]

#text("[…] di Pitagora Leggo (in ritardo) questo interessante post di Terry Tao sul teorema di Pitagora. Mi è piaciuto tanto che lo riproduco qui […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee1c6342ac1721745a7353468cd3c901d2f73a04aa0acaf218a02ff62ff1eb2d-c7a0c0f4d89df933bff8c10095e5496289ddc8d307ba1797246a4882182011ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dsilvestre")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-27151")[#strong[#text("dsilvestre")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2008")])]

#text("Hi Terry!")#linebreak()#text(" I didn’t know in wich post to say this but…")#linebreak()#text(" Did you know that this week, on 14 March, it is pi day?")

#link("http://www.piday.org/")[#text("http://www.piday.org/")]

#text("I’m trying to memorize some digits of pi. In youtube there are people who can tell hundreds of digits with the eyes closed.")#linebreak()#text(" I only know 10 decimal places by now: 3.1415926535…")

#text("How many decimals of pi do you know from memory?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-27268")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2008")])]

#text("Happy pi day!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5a7f92be19c5d5807ed875f5e04c2a92e736e78ec796c1469b5203ffd722ab4-e55e84c1dcaf118ec1f73573073c1393c8d30ddf5af1a2c4cb728e7d8221ca24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni V.")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-27321")[#strong[#text("Giovanni V.")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2008")])]

#text("Hi Terry and everyone. I enjoy your blog. And i find it very interesting.")#linebreak()#text(" Someone mentioned the book of Logounov on (special!) relativity theory and Poincaré, Nedless to say, poincaré was a true genius but Einstein was not less, altough he wasn0t strong in pure math. I have read carefully the book of logunov and it’s ok, apart from the manifestly hate with Einstein fame. The summary of his work is: Einstein did not create special relativity so he’s not the genius other claims. But Logunov forget that the work of Einstein in special relativity was only two articles long and he did The General Theory which is the result of a true genious’s mind. Lest remember his contributions to early Quantum Mechanics and Statistical Mechanics of Brownian Motion. Indeed Logunov doesn’t believe the General Theory of Einstein is Right, and he has tried to formulate the own theory (without any success!). So be careful with the work of logunov…altough he is technically never wrong with the formulas derived from the work of Poincaré. But, let me say this. Einstein organized the work of Lorentz and Poincaré in a single beautiful article based on only two postulate! That’s what the real success of Einstein in 1905. But, I repeat, any thought of that great man was really exciting.")#linebreak()#text(" About general relativity:")#linebreak()#text(" Probably is right that Hilbert obtained the action for the gravitational field some days before Einstein, but nobody really honest could say that The General Theory of Relativity is an Hilbert creation!")#linebreak()#text(" Have fun")

#text("Giovanni")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rose stonkey")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-29776")[#strong[#text("rose stonkey")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2008")])]

#text("I was feeling excited to see 75 proves on thr link but when i read all i don’t feel any of these is unique actually there are 75 comments & suggestions but not proofs")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-29871")[#strong[#text("Elegant Proofs - 1 « Newton Excel Bach, not (just) an Excel Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2008")]

#text("[…] A different approach to this method is given at: Terence Tao […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2440d6a669b266b1e0ded0cf262bd8572dc362e7aa000fb14c6782e94a6cbf7-545719ca34e8c1d255335ce8638b341f6cc5ba0edfe9ede6f49618c2d9c7de51.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Teorema de Pitágoras « problemas | teoremas")]], [#link("https://terrytao.wordpress.com/2007/09/14/pythagoras-theorem/comment-page-1/#comment-29941")[#strong[#text("Teorema de Pitágoras « problemas | teoremas")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2008")])]

#text("[…] ainda nesta entrada de Terence Tao e respectivos […]")
]
