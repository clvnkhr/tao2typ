// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/
// Converted to Typst by tao2typ: "2026-10-14T16:38:31.552969+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Request for comments from the ICM Structure Committee", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Request for comments from the ICM Structure Committee")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 February 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/")[#text("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("[")#emph[#text("This post is collectively authored by the ")#link("https://www.mathunion.org/icm/next-icm")[#text("ICM structure committee")]#text(", whom I am currently chairing – T.")]#text("]")

#text("The ")#link("https://en.wikipedia.org/wiki/International_Congress_of_Mathematicians")[#text("International Congress of Mathematicians")]#text(" (ICM) is widely considered to be the premier conference for mathematicians. It is held every four years; for instance, the ")#link("http://www.icm2018.org/portal/main.html")[#text("2018 ICM")]#text(" was held in Rio de Janeiro, Brazil, and the ")#link("http://icm2022.ru/en/")[#text("2022 ICM")]#text(" is to be held in Saint Petersburg, Russia. The most high-profile event at the ICM is the awarding of the ")#link("https://www.mathunion.org/imu-awards/imu-awards-prizes-and-special-lecture")[#text("10 or so prizes")]#text(" of the ")#link("https://en.wikipedia.org/wiki/International_Mathematical_Union")[#text("International Mathematical Union")]#text(" (IMU) such as the ")#link("https://en.wikipedia.org/wiki/Fields_Medal")[#text("Fields Medal")]#text(", and the lectures by the prize laureates; but there are also approximately twenty plenary lectures from leading experts across all mathematical disciplines, several public lectures of a less technical nature, about 180 more specialised invited lectures divided into about twenty section panels, each corresponding to a mathematical field (or range of fields), as well as various outreach and social activities, exhibits and ")#link("http://icm2022.ru/en/satellite-events/")[#text("satellite programs")]#text(", and meetings of the ")#link("https://www.mathunion.org/organization/general-assembly")[#text("IMU General Assembly")]#text("; see for instance the ")#link("http://www.icm2018.org/portal/program-at-a-glance.html")[#text("program for the 2018 ICM")]#text(" for a sample schedule. In addition to these official events, the ICM also provides more informal networking opportunities, in particular allowing mathematicians at all stages of career, and from all backgrounds and nationalities, to interact with each other.")

#text("For each Congress, a")#link("https://www.mathunion.org/icm/next-icm")[#text(" Program Committee")]#text(" (together with subcommittees for each section) is entrusted with the task of selecting who will give the lectures of the ICM (excluding the lectures by prize laureates, which are selected by separate ")#link("https://www.mathunion.org/imu-awards/imu-awards-prizes-and-special-lecture")[#text("prize committees")]#text("); they also have decided how to appropriately subdivide the entire field of mathematics into sections. Given the prestigious nature of invitations from the ICM to present a lecture, this has been an important and challenging task, but one for which past Program Committees have managed to fulfill in a largely satisfactory fashion.")

#text("Nevertheless, in the last few years there has been substantial discussion regarding ways in which the process for structuring the ICM and inviting lecturers could be further improved, for instance to reflect the fact that the distribution of mathematics across various fields has evolved over time. At the ")#link("http://www.icm2018.org/portal/imu-assembly.html")[#text("2018 ICM General Assembly")]#text(" meeting in Rio de Janeiro, a ")#link("https://www.mathunion.org/fileadmin/IMU/Organization/GA/Resolutions/Resolutions2018r.pdf")[#text("resolution was adopted")]#text(" to create a new Structure Committee to take on some of the responsibilities previously delegated to the Program Committee, focusing specifically on the structure of the scientific program. On the other hand, the Structure Committee is ")#emph[#text("not")]#text(" involved with the format for prize lectures, the selection of prize laureates, or the selection of plenary and sectional lecturers; these tasks are instead the responsibilities of other committees (the local Organizing Committee, the prize committees, and the Program Committee respectively).")

#text("The ")#link("https://www.mathunion.org/icm/next-icm")[#text("first Structure Committee")]#text(" was constituted on 1 Jan 2019, with the following members:")

#list(
[#list(
[#link("https://en.wikipedia.org/wiki/Terence_Tao")[#text("Terence Tao")]#text(" [Chair from 15 Feb, 2019]")],
[#link("https://en.wikipedia.org/wiki/Carlos_Kenig")[#text("Carlos Kenig")]#text(" [IMU President (from 1 Jan 2019), ")#emph[#text("ex officio")]#text("]")],
[#link("https://en.wikipedia.org/wiki/Nalini_Anantharaman")[#text("Nalini Anantharaman")]],
[#link("https://en.wikipedia.org/wiki/Alexei_Borodin")[#text("Alexei Borodin")]],
[#link("https://en.wikipedia.org/wiki/Annalisa_Buffa")[#text("Annalisa Buffa")]],
[#link("https://en.wikipedia.org/wiki/H%C3%A9l%C3%A8ne_Esnault")[#text("Hélène Esnault")]#text(" [from 21 Mar, 2019]")],
[#link("https://en.wikipedia.org/wiki/Irene_Fonseca")[#text("Irene Fonseca")]],
[#link("https://en.wikipedia.org/wiki/J%C3%A1nos_Koll%C3%A1r")[#text("János Kollár")]#text(" [until 21 Mar, 2019]")],
[#link("https://en.wikipedia.org/wiki/L%C3%A1szl%C3%B3_Lov%C3%A1sz")[#text("Laci Lovász")]#text(" [Chair until 15 Feb, 2019]")],
[#link("https://en.wikipedia.org/wiki/Terry_Lyons_(mathematician)")[#text("Terry Lyons")]],
[#link("https://en.wikipedia.org/wiki/St%C3%A9phane_Mallat")[#text("Stephane Mallat")]],
[#link("https://en.wikipedia.org/wiki/Hiraku_Nakajima")[#text("Hiraku Nakajima")]],
[#link("https://en.wikipedia.org/wiki/%C3%89va_Tardos")[#text("Éva Tardos")]],
[#link("https://de.wikipedia.org/wiki/Peter_Teichner")[#text("Peter Teichner")]],
[#link("https://en.wikipedia.org/wiki/Akshay_Venkatesh")[#text("Akshay Venkatesh")]],
[#link("https://en.wikipedia.org/wiki/Anna_Wienhard")[#text("Anna Wienhard")]]
)]
)

#text("As one of our first actions, we on the committee are using this blog post to solicit input from the mathematical community regarding the topics within our remit. Among the specific questions (in no particular order) for which we seek comments are the following:")

#enum(start: 1, 
[#text("Are there suggestions to change the format of the ICM that would increase its value to the mathematical community?")],
[#text("Are there suggestions to change the format of the ICM that would encourage greater participation and interest in attending, particularly with regards to junior researchers and mathematicians from developing countries?")],
[#text("What is the correct balance between research and exposition in the lectures? For instance, how strongly should one emphasize the importance of good exposition when selecting plenary and sectional speakers? Should there be “Bourbaki style” expository talks presenting work not necessarily authored by the speaker?")],
[#text("Is the balance between plenary talks, sectional talks, and public talks at an optimal level? There is only a finite amount of space in the calendar, so any increase in the number or length of one of these types of talks will come at the expense of another.")],
[#text("The ICM is generally perceived to be more important to pure mathematics than to applied mathematics. In what ways can the ICM be made more relevant and attractive to applied mathematicians, or should one not try to do so?")],
[#text("Are there structural barriers that cause certain areas or styles of mathematics (such as applied or interdisciplinary mathematics) or certain groups of mathematicians to be under-represented at the ICM? What, if anything, can be done to mitigate these barriers?")]
)

#text("Of course, we do not expect these complex and difficult questions to be resolved within this blog post, and debating these and other issues would likely be a major component of our internal committee discussions. Nevertheless, we would value constructive comments towards the above questions (or on other topics within the scope of our committee) to help inform these subsequent discussions. We therefore welcome and invite such commentary, either as responses to this blog post, or sent privately to one of the members of our committee. We would also be interested in having readers share their personal experiences at past congresses, and how it compares with other major conferences of this type. (But in order to keep the discussion focused and constructive, we request that comments here refrain from discussing topics that are out of the scope of this committee, such as suggesting specific potential speakers for the next congress, which is a task instead for the 2022 ICM Program Committee.)")

#heading(level: 1)[#text("Comments (55)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512194")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2019")])]

#text("I propose the following:")

#text("In the exceptional cases accept receiving submissions out-of-sight (maybe to be read by a specifically assigned person). These exceptional cases may include physically disabled persons or as in my case an amateur person (which may even not have money to pay for airtickets) which made ")#link("http://www.mathematics21.org/algebraic-general-topology.html")[#text("significant contributions to mathematics")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512236")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2019")])]

#text("I think this is a good proposal but of course it’s bad etiquette to self promote so blatantly hence the mountain of downlikes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512237")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2019")])]

#text("My intention was more not to self promote but to exclude unsupported claim of being a real amateur mathematician (rather than a crackpot) with a checkable source of my work")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ebf33b531b4e8dd08b454c5f771488c3eb69eefb28c1522dfd6abd7b5de3e90-3648a13ba16939805f798516267ff2452301134564bb5f7b96b681c1828ceb20.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-513288")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2019")])]

#text("It is still self-promotion: otherwise, you could just speak of disabled persons and amateur mathematicians without saying that you belong to one of these categories. Though, I do admit that you are a real amateur mathematician.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b6403233a554aaeac03e605d1f9d26df359640df3149b1fafcdad6d89a09f56-801a7f586384bf64dfd5956bddb77ddff9c8195ee64dc31070f77a99a9ad692c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jon")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512203")[#strong[#text("jon")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2019")])]

#text("Thank you for this discussion. Some ideas on some of the points of order :")

#text("1. and 2. Shorten the plenary talks to 45 minutes and use all the 15 minutes won to organize (a) some Q&A sessions that are specifically for graduate students (lots of hands-on advice on organisation, etc. some universities do provide that kind of support, but a lot of others don’t) and (b) an explicit “find co-authors” meet-up where people who would otherwise be shy to ask randomly around could attend.")

#text("3. One’s style of exposition can certainly evolve with training and open-mindedness. Some coaching to speakers ahead of the event might be offered (I know I benefited from remarks of people outside my area, or even outside math, to improve accessibility of the content and my own way talking). For example some people follow what you say, others what you write/draw, so the speaker should manage to convey his message both ways, and so on.")

#text("5. In the UK the BMC and BAMC are very distinct events, which sometimes are held together, e.g. ")#link("http://www.claymath.org/events/joint-british-mathematical-colloquiumbritish-applied-mathematical-colloquium")[#text("http://www.claymath.org/events/joint-british-mathematical-colloquiumbritish-applied-mathematical-colloquium")]#text(" The organisers may have suggestions for bridging the gap. And also putting the Gauss prize more at the forefront, or perhaps adding a new prize like the Fields and Nevanlinna with the 40 years old limit.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2eaee1d4d36fcd6a578ec2c7dab368611a4593e1115fc0d157af1c4db194525a-e120adcbe5ab0c67de73e26cd0b9626da1ff8e398e90a77bc0b9617bc878c852.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Catherine A. Roberts")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512217")[#strong[#text("Catherine A. Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2019")])]

#text("Rio was my first ICM. I attended in my role as Executive Director for the American Mathematical Society. This summer, I’ll attend ICIAM. I suggest that some of the people on this new ICM committee attend ICIAM to increase their awareness of what the applied math community does at its every-4-year international meeting.")

#text("In Rio, I did not find many talks of interest to me as an applied mathematician — although I had anticipated this, since in my mind ICM is for pure math and ICIAM is for applied math. So, while it was a bit of a personal disappointment, I was fine with it….you know, when you go to see a movie that is a romantic comedy, you take it for what it is and don’t hold it to the same expectations you might have for a different genre of movie.")

#text("On a personal note, the paucity of female and non-white speakers was striking. I felt like I’d been propelled back in time. While I suppose this helped me realize the math community in the United States has progressed farther than much of the rest of the world (in spite of the fact that we still have A LONG WAY TO GO), the impact this ICM experience had on me was profound and disheartening. I am still trying to sort out my feelings about the experience.")

#text("My one concrete suggestion: dedicate some time during the main banquet or opening ceremony to celebrate the lives and mathematics of prior ICM prize winners who have died since the prior ICM.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512318")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2019")])]

#text("Are you implying that the speakers for ICM be based on their gender, race and other ethnographic considerations, rather than be chosen based on the quality of their work? Really, take your social justice campaign elsewhere.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/879f56e34ec5a20bd59251608d441db7c3d83433f03e11ab1823a241be2516e0-e99b4a3d5825208bd49348cb0b60e9b3dbcd247f923544b11075f9963a7443ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Julia Dent")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512434")[#strong[#text("Julia Dent")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2019")])]

#text("Take your hatred of justice back to the gutter, child.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512545")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2019")])]

#text("Define justice. In this context, this means selecting among the best, not considering race, gender. Run your social justice crusade else where. Next, debate issues, not the person, using logical reasoning. Take your ad hominem and emotional arguments elsewhere.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ecb79b7aa837433526668fd379e483d22663d2e7a8e093c3d1f96477d891ba5-58ef039206bf515937bd49c2772c6e9acd1766f2f3b5f62af3da79465679fb4b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512347")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2019")])]

#text("Madam/Sir, are you assuming their genders and races?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/58b174c7cb7d460981cbb31f1772f9ed15c7cb9bc8e93d97e70aae8d9e4829e5-5db96651edc28c662788758c9888bfc165337f367224703d0fae0c75469dd5ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Helge Holden")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512573")[#strong[#text("Helge Holden")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2019")])]

#text("Your comments regarding the balance between “pure” and “applied” mathematics go directly to the heart of the matter for the ICM Structure Committee: How can one present the best of current mathematics within a given a timeframe that allows for around 200 talks within the current format? To find the right balance between applications and more core mathematics is very difficult, and a task for the Structure Committee.")

#text("The question of diversity of speakers (age, gender, geography, and scientific area) and quality of speakers is the responsibility of the Program Committee, and not the Structure Committee. The Program Committee has full autonomy in deciding all speakers at the ICM.")

#text("The questions of commemorating deceased prize winners was discussed, and it was decided against it for the reason that it felt wrong to mention only some mathematicians at the expensive of the many excellent mathematicians who have passed away.")

#text("Helge Holden")#linebreak()#text(" IMU Secretary General")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512224")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2019")])]

#text("Is string theory considered to be “pure” or “applied” mathematics ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/744af6de8cc8d5fa42cf0dbd096e88eef82f4b51081b78514bff85bf909eab07-d4d0b110ce3d5330716c189c6d455c2cd768a34ab962b2a8c3755b79505fb788.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of grpaseman")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512229")[#strong[#text("grpaseman")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2019")])]

#text("[Second attempt at post. GRP 2019.02.06.]")

#text("Partly in rejoinder to Catherine Roberts:")

#text("Rio was my ninth ICM, and the first as an unaffiliated researcher. I was impressed by the increase in participation by non white and non European and non male members. I won’t speak to whether the population of speakers and attendees is diverse enough; I will say that the trend over this sample of Congresses is toward increasing diversity, increasing participation of women, and increasing popularization, which includes scientific and technical applications of mathematics. I encourage the trend Ms. Roberts suggests, but add that the trend started earlier.")

#text("Rio 2018 was the first in which I presented some joint work. I did not take the opportunity to make more than one submission for a Short Communication, because of my interpretation of the submission policy, which seemed more strict than in previous congresses. One hope I have is that the submission process for Short Communications start earlier and allow for multiple submissions. This would allow for a possibility of a different selection process. If one registered and submitted abstracts early, they could vote on which submitted abstracts they would like to see presented at the congress. This could inform the committee who makes the final selection, and possibly indicate how to schedule presentations better. Politics may get in the way of applying this system to invited lectures, but a modification may prove useful even for invited lectures.")

#text("If in addition to earlier submission of abstracts were allowed, a submission of topics of interest were taken, it might help restructure the Congress format; those attendees interested in resolving questions publicly could use this as a clearinghouse (think of a good hybrid of Twitter and MathOverflow) which would not only inform of the interests of the attendees, but possibly reorganize research efforts on a global scale. (“Hey, someone else thought of my problem and actually put something online about it!”)")

#text("I under-appreciated the social events provided by the Congress. (My mistake, no blame falling on the organizers.) While I believe the events were run adequately, imagine what (good) might happen if professional event planners were tasked with a goal list selected by the attendees. The recommendation might be coffee hours (which could also serve tea) three times each day with large posters containing explanations on topics and links to scheduled presentations related to each topic. ( Or they might suggest one eight hour dance party to meet the goals; party planning is not my forte, but good party planning should be someone’s forte.)")

#text("I am willing to share more of my experience from past Congresses, and make further posts on this blog regarding ideas for a new structure for ICM2022. People who wish to can check my profiles at MathOverflow to reach me by email.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512258")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2019")])]

#text("The proper form of address would be Dr. Roberts or Prof. Roberts. Your biases are showing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512319")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2019")])]

#text("What biases are you talking about? Enough of your political correctness and social justice campaign.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512320")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2019")])]

#text("Are you serious? Should one start pointing out biases when some one with a PhD is addressed with just their name? If so, should we point out airline tickets as being sexist? Take your political correctness elsewhere.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab73d37fc03cd141d608ddc6b93e6751496e73921170a31be0e350709a436131-0a37e6935ffa29b67f1bd42d861577f6855291dedfeb08dfeefc66be172b3229.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512334")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2019")])]

#text("You are the one who is showing cultural bias. There are many countries where it is unusual to address someone as “Dr X” simply because they have a Ph.D. I even know of some countries where it is illegal to do so in many contexts, as only medical doctors have this privilege.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-521431")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2019")])]

#text("I’m so tired of childishness in Dr. Tao’s comments. “Take your X elsewhere” remarks are (to most people who aren’t the poster) aggressive, dimwitted, and tragically trashy.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/14ac0ae7fd696758a9c386bf25d6f755a15b3ba9f6e91e2bad88627dc33b5220-0d542ae24deb3e921bbaf2dcafc24588f536c35e46e558dd7e594c07af00a649.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mason Porter")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512240")[#strong[#text("Mason Porter")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2019")])]

#text("In terms of promoting inclusiveness, one place to start is the 2022 ICM itself and the deep concern (which I believe many share) expressed in the letter that AWM president Ami Radunskaya sent to the ICM organizing committee: ")#link("https://sites.google.com/site/awmmath/home/announcements/deepconcernaboutthelocationoficm2022")[#text("https://sites.google.com/site/awmmath/home/announcements/deepconcernaboutthelocationoficm2022")]

#text("I have never attended the ICM (though I hope to one day), but I will comment on some items in the blog post and am happy to chat more in person:")

#text("(1) I’ll skip, as I don’t see how I can say much that is helpful here without having previously attended.")

#text("(2) Less format and more reiteration of location choice: it needs to be considered very seriously that some locations simply are not going to be welcoming to many members of our community. That’s a major problem, especially if the ICM is then held at such a location in practice.")

#text("(3) If somebody can’t give at least a reasonable talk, they should not take up the spot of somebody who can. The fact that the schedule is limited only underscores this point. I do understand that there exist brilliant mathematicians who can’t speak their place out of a paper bag (to mix metaphors), but then a large audience wouldn’t benefit from their talks anyway, so those folks can be celebrated in other ways. Giving a good presentation is a crucial component, though different presentations can and should have different audiences in mind.")

#text("(4) Similar to (1), though on a global scale — separately from what the current balance is our what it should be — I am in favor of public talks where the public actually attends (I have been to many conferences where everybody in the public talk is still essentially a mathematician), as that is something that can help promote mathematics in the context of a very skeptical world. We need to help promote those efforts.")

#text("(5) I could go on a very long time about this one, so let’s say that this space is too small for me to type my full answer. (To modernize Fermat: “I have discovered a truly remarkable proof of this theorem which this tweet is too small to contain.”) As an applied mathematician, I have long felt an undertone (a highly inappropriate one) among many theoretical mathematicians — note that the word “pure” is already very insulting to applied mathematicians, given the implications of such words — of considering us to be second-class citizens in the mathematical world. (I like to say jokingly that my membership in SIAM is for the Society for Impure and Adulterated Mathematics. So perhaps this conveys why I strongly dislike the use of the word “pure” for theoretical mathematics. There is nothing impure about what applied mathematicians study. The MSC ontology is also stacked very strongly against applied mathematicians, and I can provide a very long statement/rant about that one as well.) The fact that ICM is very centered on ‘pure’ mathematics underscores this type of sentiment, and making it friendlier to applied, computational, and interdisciplinary mathematics would be very welcome indeed. Perhaps one step to make ICM more attractive, besides perhaps adjusting the balance of theoretical and applied mathematics at the conference, would be for a couple major prizes in applied mathematics to also be announced at ICMs? I am not sure if that is the best way, or whether the costs of doing so are worth it, but that’s at least one possibility.")

#text("(6) Here I can go back to e.g. the location of the 2022 ICM, which is very unwelcoming indeed to many members of the mathematics community.")

#text("Finally, thanks for soliciting these views with the blog post. I really appreciate that!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/744af6de8cc8d5fa42cf0dbd096e88eef82f4b51081b78514bff85bf909eab07-d4d0b110ce3d5330716c189c6d455c2cd768a34ab962b2a8c3755b79505fb788.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of grpaseman")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512248")[#strong[#text("grpaseman")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2019")])]

#text("I recommend that you pore over the abstracts and talks from previous congresses. The applied and interdisciplinary sections may not be as large as you wish, but they are present and seem to grow over time. I have the sense that the pure vs applied schism does not appear at the ICM as much as excitement over the spread across disciplines of ideas. Further, I see the Gauss and Leelavati prizes are a recognition of this spread.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0307c4295da425194dad96d1a631d5f48fbfccc8643425982bd70219703a5ebe-661d1e64caa217e10cbbca677c9db51332f9d74326020417eecb43cb40c852f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JP")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512243")[#strong[#text("JP")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2019")])]

#text("ICM has become a fetish, a line to add to your resume. Anything that could break that would be welcome. What about the live broadcast of all talks on Youtube? So that mathematicians around the world can really enjoy the Olympics instead of just checking who won the Fields Medal.")

#text("In addition, there is a frightening correlation between section subcommittee members and the list of invited speakers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1cf9bca2192232d4297f7b4c4c3154b2431c06ad2f7a16c673fe84f712f2fdaa-3d1a76bfd473a1d5ac82f8787ed68bd884c3a935313f346df281882fcdd5efd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allan van Hulst")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512251")[#strong[#text("Allan van Hulst")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2019")])]

#text("I am under the impression that top-down selective stimulation of certain areas of mathematics, or re-structuring organizational matters in such a way that some areas are better represented will turn out to be a hopeless endeavor. (1) The question: what is (right now important in) mathematics? allows for many dynamic answers that change over time and are hard to accommodate in an event that has a mostly predefined setup, (2) There will always be people in sub-areas who feel underrepresented. Both (1) and (2) apply to the technical content of an area of mathematics, as well as the more orthogonal characterization of applied vs. pure.")

#text("One should wonder whether it is the task of a general congress (like ICM) or a general journal (like AoM) to fix the sort of problems that people sometimes formulate as “logic is underrepresented”, “combinatorics deserves more attention”, etc. The only way to really repair these sort of issues is to allow truly bottom-up steering in topic selection.")

#text("As a suggestion: reserve an entire day at ICM for conference-style presentations distributed over multiple parallel tracks of new ideas (and advertise this widely). Submissions should first pass a selection purely based on correctness, and not on perceived value of the contribution. An online voting system allows anyone who considers himself a mathematician to vote on what gets presented on this day. For added value, add a keynote talk where the results are summarized in a presentation by a well-known mathematician titled: “this is the way we are heading”.")

#text("I now take some liberty in formulating an unrelated critical remark regarding the topic of inclusiveness. Inclusiveness is strongly related to core principles, which is fair and proper. However, the fact that multiple (monetary) prizes are awarded at ICM under stringent age limitations and the fact that IMU wishes to promote inclusiveness are, and always will remain, contradictory.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512336")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2019")])]

#text("The objective should be to include the most qualified speaker list, not the most diverse speaker list. If the best speaker is a man/woman/AI agent, so be it. Trying to equate these two criteria does not work (speaking mathematically). Topics such as diversity/inclusiveness are the refuge for social justice warriors, who are trying to enforce their mediocrity onto the rest of us.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1db578f81108f908ab71d3ea938f246003c66458fc5fed72b02adee03077b295-b505761af10647bdd8f4e9bf0f94de0dd980a95ba8a29390d6da86f6d9c48727.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of F")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512341")[#strong[#text("F")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2019")])]

#text("This comment is irrelevant trolling (sounds like someone just got triggered by the word ‘inclusiveness’ and copy-pasted a canned rant) but I’ll bite anyway. (Just this once.)")

#text("How do you judge “most qualified”? Two randomly chosen mathematicians probably don’t even understand each other’s work, let alone being able to formulate an objective judgement of whose work is “better” in widely disparate areas (or, for that matter, in the same area.)")

#text("You also cannot separate the quality of someone’s past work from their access to resources, which includes things like time they’ve spent talking to leaders in their field. Part of what’s great about the ICM is it gives a chance to mathematicians from developing countries and mathematical backwaters to engage with people from the centers.")

#text("So selecting for diversity (all other things being equal or at least debatable) can be a way of maximizing the _potential_ of attendees.")

#text("And if you don’t believe that the same issues of access can affect women, I suggest you read the anecdotes on this webpage, for example the one linked:")#linebreak()#text(" ")#link("https://sites.google.com/site/numberlandadventures/#THEMENSCH")[#text("https://sites.google.com/site/numberlandadventures/#THEMENSCH")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512619")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2019")])]

#text("What matters is ideas and the quality of work. The best qualified candidates — judged by citations, impact of work — and their work will speak for itself. Promote research candidates who are new researchers eg students/New PhD/Postdocs. Other considerations including gender/race are irrelevant.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f4b17d7048978bae5a61ddc378e14759273d17ec4cdf58fbf8a8b1af485c720-d0a769a64a6cf8aade017065a57512419553dca55ad8ff47dd42c19dec9b5189.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmy")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512436")[#strong[#text("Emmy")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2019")])]

#text("Oh my, just look at this. A frightened, emotional reactionary whining hysterically and endlessly here (and everywhere) about “social justice warriors” and bleating about “mediocrity”.")

#text("The fact is, you’re frightened to death that those who have had to deal with adversity through racism and sexism and still surpass you in life are going to take everything from you. You fear that more than anything. You fear social justice because it means that cheating and privilege won’t carry you along anymore. And that’s so fearful because your own abilities won’t get you anywhere. Pathetic….")

#text("We see right through you. You are the very essence of mediocrity. Take it somewhere else.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed7fe480a3961266e21303169a56485024d3761fdd7df6313fdb8a9c1d61f7a0-75a66dce3db0742badf7bb3b53131cb1c0febb8c669081d6c1961ecdd8c48a16.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of voloch")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512272")[#strong[#text("voloch")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2019")])]

#text("I’ll start with my personal experience of ICMs, which informs my opinions and then answer your specific questions.")

#text("In 1990, I was a young mathematician from the developing world and thus qualified to apply for an IMU grant to attend the ICM in Kyoto. I went and enjoyed it. The trip was great, visiting Japan was a treat, I went to talks I enjoyed and met lots of people. But I must say that most of the mathematical usefulness came from the satellite conference I attended in Tokyo beforehand. The ICM itself is too big to be really useful. If I was instead given the money in the form of a grant to use as I saw fit to help my research I might not have chosen to go to the ICM.")

#text("Not long after, I moved to the developed world (and eventually ceased to be young too). I did not go to an ICM until the last one in Rio de Janeiro (by the way, you’ve misspelled Janeiro twice ")#emph[#text("[Corrected, thanks – T.]")]#text("). I’ve had grant support and access to funds during most of that period which I chose not to spend on the ICM, again because I didn’t feel it was worth it. By the way, for similar reasons, in over 20 years in the US, I only went to a handful of JMMs, all but one in San Antonio, which is a short drive from Austin.")

#text("I went to the ICM in Rio because it’s my home town and I felt I should support the congress there and I had other reasons to be in Rio anyway. I paid my own way and only asked my current University to pay the registration fee. Again, I went to talks I enjoyed and met lots of people. Unfortunately, I had to miss the satellite conference. But again, it is too big to be useful. On a side note, there were a number of friends I had hoped to see whom I didn’t see. Many Brazilian mathematicians stayed away, unhappy with the registration fee (which wasn’t high by international standards but high enough to elicit this reaction there).")

#text("For your specific questions:")

#text("1. Make the ICM shorter and give more support for and increase the number of satellite conferences.")

#text("2. It’s not a good value proposition for them. I can’t imagine how it would be better than going to a specialized conference. If you pay their expenses, they’ll come.")

#text("3. Research talks are only useful for a handful of people. Expository talks, either on the speaker’s own work or a survey talk are more broadly useful. 3000 people sitting through a lecture that only 50 of them can understand seems like a waste.")

#text("4. No. Do away with the section talks, have more plenary talks.")

#text("5. Don’t know.")

#text("6. Yes, there are underrepresented areas. Reserve a few slots for something different and perhaps widen your consultation.")

#text("I also agree with JP’s comment above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512305")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2019")])]

#text("Add an outreach workshop for memeing and shitposting. Reaching 3000 people isn’t bad, but reaching 3000 million people is better! By working together we can make mathematics go viral!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cd6e5aad292560f64aa9b45f206b0b28bb1653f6fa014816cacacbed78552fc-c80b60e7a5c2a123c91bafc7bcbdd6449b4a89fd888c4af3c56d500dd860cd71.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of test")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512317")[#strong[#text("test")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2019")])]

#text("Are aliens allowed to comment on this post?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ebce40356821fd654dafdb60f5b13a46661e053c1436ffc096391d3c5fb50a87-249188400b871c54ac722dff53b022a220fba0b4573f3db83103fb0993919a73.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stefan Kohl")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512321")[#strong[#text("Stefan Kohl")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2019")])]

#text("Just a very basic suggestion regarding Question 1: I think the fact that nowadays information (papers, notes, broadcasts of talks, mail …) can be disseminated via the internet worldwide in basically no time has an immense impact on how a conference nowadays should be organized in order to be as useful as possible to the mathematical community. — The advantage of a conference over all sorts of telecommunication is that it allows people to directly interact with each other. In order to watch talks, nowadays nobody needs to travel thousands of kilometres any more. I do think that the structure of a modern mathematics conference should take this into account!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/201d0194c9990ed4915d6f072193729af7e60d09bb9b1ec0eeafe91b8846c508-c9025a9e6a493f11f46ad8975d6a91a5601dff77b9123a09919cdc1f5f45fde7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chorasimilarity")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512323")[#strong[#text("chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2019")])]

#text("I half-joked some time ago that mathematics needs an infusion of diversity like art needed 150 years ago. Maybe by a way alike the famous Salon des Refuses (1863) ? It would be certainly a media hit.")

#link("https://en.wikipedia.org/wiki/Salon_des_Refus%C3%A9s#Background_of_the_Salon_of_1863")[#text("https://en.wikipedia.org/wiki/Salon_des_Refus%C3%A9s#Background_of_the_Salon_of_1863")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/85a188b385a378b90299ed773ab1af8bd6b68720a58f3c1a01880221a92773ea-0f6bee3bb8f9ca5c929594aa64a739946773ec2f7e24c059441b8fe685297059.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yiftach Barnea")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512331")[#strong[#text("Yiftach Barnea")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2019")])]

#text("I have never been to an ICM and I am unlikely to ever go to one. However, here is a suggestion: Many mathematician have the opportunity to hear famous mathematicians give talks (especially if you attend an ICM). A much less common occasion is the opportunity to talk to a famous mathematician about your own work. If you can think on a way to give this opportunity to a young mathematician, I believe that would be very remarkable experience for them, especially if they do not come from a well known school, e.g., Harvard, Oxford, etc. So for instance make sure that in every talk or poster presentation some well known mathematician will attend the talk or see the poster and than talk to the presenter. Or say arrange that young mathematicians would be able to apply and the selected one would get such an opportunity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512332")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2019")])]

#text("Dear all, I think the ICM is a big and intense celebration of mathematics on both a professional and a personal way. One nice thing about Rio-ICM2018 was that all invited, public, plenary lectures and also the panels were videotaped (in a very good quality) which provided (in addition to the traditional Proceeding) a very valuable resource.")

#text("Perhaps we can give all speakers of all types (except, of course the prize winners) an opportunity to post a 20 minute introductory video that will be posted around May of the year in the ICM site. (This can be extended also to contributed talks/abstracts and to lectures in satellite conferences.) While only a few percent of people in the audience will watch the video this can still be very helpful.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df65a9c97e36e10169216a707d6961aec9bcc13e8d480072bc9e4d091d84b373-7be139d3c4291ac8aeffdc60749a94c1288a383fd51ac39ad59738acc586061e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512557")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2019")])]

#text("Rio was my first ICM. I was invited to give a section talk. I did not follow the advices of the “old peoples” in my domain: step out of the plane, give your talk, and escape the quickest as you can. I stayed for the entire ICM and this was a strong mistake, I should have followed the advices of the older. After my talk I escaped the quickest from the ICM to do tourism. All the peoples I know did the same.")

#text("The ICM in Rio was the worst scientific event ever organized to which I attended. Very far from the centre in a completely lost place (it could have been somewhere in a suburban area in the US it would have been the same, no difference), not even a restaurant in sight, a real catastrophe. The attendance was very low, I could walk in the conference centre 20 minutes without seeing anybody.")

#text("There was a satellite conference in my domain, in a very fancy place, where the organizers had collected the 3 peoples in South America in the domain (let’s be honest, outside of dynamical systems and a little bit of differential geometry there is no mathematics in Brazil, sadly). The satellite conference was low level and uninteresting compared to the usual conferences to which I attend, I left quickly for tourism.")

#text("At some point I complained to some “high level” (member of Fields comity) person around a drink and this person said that the only purpose of the ICM is to promote mathematics via the publicity made around the Fields Medals: the journalists speak about the Fields Medals, the media are here, and that’s all that counts, nobody cares about the section talks (I saw some very good one with 10 peoples in the room, mine was OK with something like 90 peoples because I’m “very well known”).")

#text("Thus, what’s the meaning of this ICM ? Why does the math community spends millions for this event (I spent a lot on my grant to pay for everything and stay in a shitty hotel near an highway) ? I mean if everything is for the Fields Medals then make a press release with the journalists, the cameras and that’s all, no need to force researchers to travel all around the world.")

#text("That being said the main good point of this ICM is the articles of the proceedings. All of them are very good and interesting. I’m very proud of mine, I guess this will be very useful for peoples in my community.")

#text("Next ICM in Russia. There is almost no mathematicians in Russia, all of them left a long time ago for the US or Israel. Do peoples seriously think that an ICM in Russia or Brazil will motivate anybody to go to Russia to do mathematics ? I had a discussion with one of the rare peoples doing mathematics in Brazil: he told me that there is no money, no electricity in his university, with shitty salaries and he would leave for the US soon. Today any kid behind his computer in Russia, smart enough to do maths, can realize quickly that mathematics is not good for him and he should go to an investments bank rather than pursuing a mathematics career. ICM or not, this does not change anything. The main problem is the public investment in research and universities in those countries, good salaries in particular is the key. The ICM will take place in Russia and this won’t change anything to the situation of mathematics in Russia. We’re in 2019, anybody has a quick access to informations, can move easily to a richer country and this story of using the ICM to promote mathematics is a joke to me. If Putin wants to promote mathematics in his country he should use his millions to give good salaries to mathematicians, everybody would know it very quickly, instead of organizing an ICM.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef7779e47a498538847b7db8ad122bb9cda722b4473088a8be55bea843c770c4-d390c41c244bd1325d98861d6bf0206e2b8b0ff29317d85a41dd53ee1861b84a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stefan Kohl")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512566")[#strong[#text("Stefan Kohl")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2019")])]

#text("While there are certainly many reasons for which one may criticise the ICM and in particular the importance attributed to it, your claims that “outside of dynamical systems and a little bit of differential geometry there is no mathematics in Brazil” and that there are “almost no mathematicians in Russia, all of them left a long time ago for the US or Israel” sound pretty")#linebreak()#text(" bold to me, to put it mildly. Given your comparison US / Israel (“good”) vs. Russia (“bad”), and given that you have posted your criticism anonymously, it seems to me that your comment is motivated mostly politically. Independent of this, of course living- and working conditions for mathematicians in many parts of the world could be better than they are now (and this holds for the US as well!).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/041e0d8efb404a6a2cf18b2270a848edf2c64e454a9f79bc7b5042d769355180-62fe160b29fccbce5500ff3d0ac989c0d3a0e9678d38be9c88331b114d02c1d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512568")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2019")])]

#text("I am not the original poster; however I think that his comment “almost no mathematicians in Russia, all of them left a long time ago for the US or Israel” is accurate if one expands the list to add Europe (in particular France, Switzerland, Germany, … ). Yes, I agree he could be more generous to Brazilian mathematics, for instance some areas of combinatorics have some reasonable representation at a reasonable level.")

#text("Returning to Russia. Stefan, I think that you are not aware of the academic situation in Russia : these days displaying a certain amount of nationalistic fervor is part of the job in many places (this could mean for example claiming that “no _real_ mathematics happens in the West”). PhD students who come back are interrogated at length at the border on their “true allegiance”. Another staple is displaying cult-like reverence to some supposed “greats” of the past (interestingly some of the _truly great_ are never celebrated). The level has dropped catastrophically, and worse the climate is now infused with paranoia, e.g “the West doesn’t give us enough credit”. This was quite possibly the case in the times of the Soviet Union, when Soviet mathematics was at least on par, but this is certainly no longer the case. The current level (with few isolated exceptions) is truly abysmal, but the egos are still of the same size.")

#text("I understand that it is fashionable in Europe to be anti-US or US-sceptic and perhaps think that “Russia = bad” is propaganda, but the situation in Russia really is going from bad to worse. Most people with options and common sense simply leave (take a look at the very bright young Russian ICM speakers in Rio, what are their current affiliations?).")

#text("As for the OP wanting to remain anonymous this is completely understandable : after all he is criticizing in rather harsh term the ICM in Rio, and why should he risk getting on the bad side of some of the distinguished people who worked very hard to make it happen?")

#text("I also attended this ICM in its entirety. I can relate to some of the criticism but I think the flaws are intrinsic to any conference of this size and breadth. All in all, I think OP’s original post was an extremely honest one, I disagree with labeling it as politically motivated.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512677")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2019")])]

#text("To the question “What is the purpose of the ICM” My understanding is that the main purpose is to have a large event where the most important scientific achievements and directions in the area of mathematics are recognized, presented, and celebrated.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a86dd4e50ba8f22943a189f854c40d839497a731ff6b4079c4d133b372c09e8f-be41755421a180a22b86e0fb0f8b744ed70f251fd0b1e4339fd3a3abebec0c0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512713")[#strong[#text("Joe")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2019")])]

#text("Most important achievements, yes, but not in all areas of mathematics but in the subfields closely connected to the program committee and section subcommittees.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/85a188b385a378b90299ed773ab1af8bd6b68720a58f3c1a01880221a92773ea-0f6bee3bb8f9ca5c929594aa64a739946773ec2f7e24c059441b8fe685297059.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yiftach Barnea")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512559")[#strong[#text("Yiftach Barnea")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2019")])]

#text("Just one comment: there are some pretty good group theorists in Brazil.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512565")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2019")])]

#text("I personally like the ICMs but it is true that some mathematicians do not like huge and very general conferences. I tentatively plan to attend the ICM in Saint Petersburg in 2022, and perhaps will try to live blog. I do think it is important for participants to allow plenty of time to sightseeing. In fact, I strongly recommend also to my visitors not to neglect their sightseeing and touristic duties while visiting and give them the highest priority.")

#text("One plan ")#link("https://gilkalai.wordpress.com/2018/08/12/icm2018-first-report/")[#text("I have regarding ICM 2022 (see this post)")]#text(" is to have a reception/party open ")#strong[#text("(music/food/dancing)")]#text(" for all participants hosted by combinatorics in Tuesday evening of the second week. This might not be relevant to the structure committee (perhaps more so to a “chaos committee”). I am not sure how precisely to advance this idea at this moment.")

#text("Regarding anonymous’ comment. I personally had an opportunity to get to taste of the excellent, diverse and passionate Brazilian mathematics in the Brazilian colloquium a year earlier (and also at the ICM itself) and I don’t share anonymous’ judgement. (And, of course there is a very strong mathematics in Russia.) I do share anonymous’ sentiment (that i read between the lines) that there are real-life problems, some severe, in the world and various difficulties. However, the IMU general policy of inclusion and outreaching is to my taste.")

#text("While it is very general and large for me the Rio ICM could be seen as an excellent conference of combinatorics (and I am sure this is the way for other areas), with something between 40 to 100 devoted participants, with 12 or so top-of-the line section-talks in combinatorics, and double that amount talks related to combinatorics in other sections. But, of course, there are various competing activities, you can just choose a few talks from different areas, go to plenary or public lectures, go to panel discussions, etc. (and also meet many people, and make your touristic duties.) In short, ICM is like a huge meal that if you put some thinking on what and how to choose, there are various ways to greatly enjoy it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512631")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2019")])]

#text("Ah yes, to taste of the diverse and passionate Brazilian mathematics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512982")[#strong[#text("Comité de Estructura de la IMU – Real Sociedad Matemática Española")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2019")]

#text("[…] Esta semana le ha sustituido en el cargo el medallista Fields Terence Tao. Tao ha abierto un debate en su blog en el que anima a la comunidad a dar su opinión sobre posibles cambios en la estructura de los […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca185876592cc8d040e7a1e8ac52726a6134ec66c1571fcc282d15e05a83d854-493ad49ed929ddb8493f0d923d153c02aa00a7dc8b4382cc248a7a34dc2ae151.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Volker Mehrmann")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-512992")[#strong[#text("Volker Mehrmann")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2019")])]

#text("As chair of the organizing committee of the European Congress of Mathematics 2016 I am well aware of the difficulties of a congress like the ICM, after all ECM is modelled in many respects after ICM.")

#text("First of all I think that the ICM should be the place to go for all mathematicians. I also think that the mutual respects of mathematicians from different fields and the communication between the different fields of mathematics needs to improved drastically. We can learn so much from each other if we make an effort. A small science like mathematics can only get worldwide respect if it stands toegether rather than loosing energy in internal fights about who is the better mathematician or who is more important for society. However, with invitations to such important congresses like ICM and ECM being used as quality stamp in evaluations of projects, grants, hiring processes etc, it is inevitable that conflicts arise.")

#text("I consider myself a wholehearted mathematician and I work hard for the mathematical community. However, in the last 20 years I did not feel that I wanted to go to the ICM for several reasons:")

#text("First, my own research area is not well represented at ICM, second many talks are given without having the possible audience in mind, and third I did not feel the mutual respect for other mathematical fields well established. I had the feeling (and I may be wrong) that this was much better established at the ECM than at ICM. Reading some of the comments in the blog I feel similar frustration and anger.")

#text("I do not have a recipe how to make things really better, but here are some suggestions about what can be done.")

#text("-The different mathematical subfields should be equally represented in the sections, plenaries and invited lectures. This can be done by splitting in many small subfields or by joining subfields. At 7ECM 2016 we agreed to have only 17 bigger sections, and personally I think that this worked well.")

#text("– Invited, plenary and speakers in sessions should be asked to adress a general mathematical audience not only specialists.")

#text("– The huge diversity of mathematics and mathematicians should be reflected in the program, in the comittees and in the prizes.")

#text("Is all this possible? I do not know, but I think we should try.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/58b174c7cb7d460981cbb31f1772f9ed15c7cb9bc8e93d97e70aae8d9e4829e5-5db96651edc28c662788758c9888bfc165337f367224703d0fae0c75469dd5ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Helge Holden")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-513425")[#strong[#text("Helge Holden")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2019")])]

#text("First of all I would like to say that I share many of Volker’s concerns about the ICMs. It is a big challenge to embrace all of contemporary mathematics at an ICM, and I think the main problem is how to include more applied areas of mathematics. This is precisely one of the major tasks for the ICM Structure Committee to consider.")

#text("To divide mathematics into sections is another difficult task. At the 7ECM there were 17 sections, while at the ICM 2014 and ICM 2018 we had 19 sections. It is difficult to say that this constitutes a big difference.")

#text("It is a never ending problem to make lectures accessible to non-specialists. Here is an excerpt from the invitation letter for plenary speakers at the ICM 2018:")#linebreak()#text(" “Plenary lectures at ICMs are addressed to all the attendees of the congress and aim to be surveys of recent major developments in a mathematical area, with possibly some discussion on future research trends. Therefore, they should be made comprehensible and interesting to a broad mathematical audience. More focused lectures on specific topics are the object of the")#linebreak()#text(" parallel sections of the congress.”")

#text("All speakers are seasoned lecturers, but they are not equally amenable to advice. So it is difficult to obtain the ideal survey lecture which is accessible to mathematicians at large. Some are, but many are not.")

#text("To select the about 200 speakers at an ICM, we have a Program Committee comprising 12 members, and sectional panels, which gives a total of around 200 members. In all committees and panels we try to make them well-balanced and diverse (gender, geography, age, scientific disciplines) while at the same time keeping a high scientific level. So it is not that we are not trying.")

#text("Helge Holden")#linebreak()#text(" IMU Secretary General")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-513220")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2019")])]

#text("I watched some of the Rio talks online. They seem no more polished or professional than normal math talks. They also don’t have very many views.")

#text("It would be nice if the speakers were given help making more professional and accessible talks and did them on topics that every professional mathematician could follow. If they were better, it’d be great to watch talks")#linebreak()#text(" by the amazing mathematicians online (like watching the old Feynman Messenger lectures).")

#text("I have a friend who gave a TED talk and they helped her a great deal in polishing her talk and making it accessible to everyone. Of course, math talks probably can’t all be accessible to everyone, but they could be accessible to a large fraction of mathematicians. And the slides could be much better than what I saw from Rio.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d6a3192005d81c821e6b194e5f169a69a68218d9323372af2f9372980bc991f-06f3f788ffbd5e347f66de79c5d93066bc480f53c0e1a609feda33e5d30a7bb6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Smith")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-513593")[#strong[#text("James Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2019")])]

#text("I think the ICM should wholeheartedly enable and promote remote attendance. This would help with inclusiveness and also encourage more social responsibility amongst mathematicians. Less jetting around for very little reason! The technologies around remote collaboration are good and cheap enough these days, it’s definitely the way forward.")

#text("I’m not a fan of poster sessions at conferences, but some arrangement whereby attendees can sit and talk with anyone who’s interested in their work, not stand in front of a poster like some poor, self-conscious salesperson, might result in many fruitful interactions. Simply having a small desk to sit behind with your laptop and pen and paper would be so much better. I don’t like sitting along with a small crowd facing a panel of people at the other end of a large room, either, the interactions always seem artificial. Breaking that up into many individual sessions might be better.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-513849")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2019")])]

#text("I always thought that an emphasis ought to be placed on presenting mathematics in a way that avoids duplications. For instance, in computer science it is customary to avoid so-called “code duplication” in order to make source code more readable. I believe that mathematicians should adapt that concept. Some great pioneers of this approach might have been Grothendieck, Mac Lane and Eilenberg. They saw to it that the assumptions one had to place on a mathematical object were reduced to a minimum, so that very general theorems could be proven, which in turn enriched many different subjects instead of only one. Grothendieck in particular placed great emphasis on finding the true nature of mathematical objects for which certain theorems were true, ie. which behave in a special way, and I believe that this search should be one of the fundamental principles of all of mathematics. (Right now, I’m learning a little bit about dynamical systems, and one of the books I’m working with proves the existence of invariant measures from scratch, even though it follows from the Riesz representation theorem, which has many additional applications. That is not to say that that book is bad, since it includes many illuminating examples, but it’s nonetheless something that could be improved.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9762aa6fc897b413ee727afa29ee0f4e207a7453ec92b389ed64ab33c93da450-02b44c278ba35aea14787b75d90c0c939047be5233b2563e407b76f796a22e15.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of betul tanbay")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-514437")[#strong[#text("betul tanbay")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2019")])]

#text("The first ICM I attended was in Berkeley in 1986, I was part of the graduate student working team. I thought I was in paradise, almost math-drunk!")#linebreak()#text(" At every hallway, amphi, classroom, coffee corner of the campus there was some mathematician whose theorems I was trying to understand. The word “congress” from “congredi” made sense, namely “walking together”.")

#text("Since then I have attended partly or fully four more congresses, and")#linebreak()#text(" I have the feeling we are walking less and less together. With all respect and admiration for the huge work done, I am afraid there is more and more distance between the “chosen” participants and the ones who chose to participate. It is maybe romantic to long for the “spirit” of the old congresses")#linebreak()#text(" in a world where humans walk much less.")

#text("Now there is a “congress industry”, and congresses have formats imposed by this industry, locations usually out of city centres, conditions usually far from a “university” surrounding.")

#text("The questions raised by Tao make me feel that the aim is structuring the inside of the congress in this exterior new format, which is of course very valuable. The structure committee has a huge task, and it is great courage")#linebreak()#text(" to raise an open discussion but I must confess I am looking for a “Restructuring committee” which would redefine the very existence of the ICM’s for the future:")#linebreak()#text(" do we organise ICM for “us”, to see, to meet each other, to walk together,")#linebreak()#text(" or is it to be the first news in the world a few minutes every four years?")#linebreak()#text(" So far we might have been aiming both, but maybe it is not efficient anymore to try both at the same time.")

#text("We could have a world-wide diffused “Fields days” (maybe right after the General Assembly so that there is a minimum live participation from all")#linebreak()#text(" over the world) and restructure the remaining of the 9 days with “field days” conferences where real interaction is aimed.")#linebreak()#text(" Maybe Fields recipients can be the natural participants of the")#linebreak()#text(" field days to walk a few steps together with even younger mathematicians.")

#text("Betül Tanbay, Turkey")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-514591")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2019")])]

#text("One request that I heard several times (and I like) is to find ways to represent emerging fields like Symbolic Computation and experimental mathematics.")

#text("A meta-structural issue is how to do it. The obvious way keeping the structure precisely as is, is to create new sections and then shrink other sections. But maybe there is a more subtle way in additional to sections to find ways to represent groups that are represented across sessions. I dont have an obvious answer on how to do it but it is an interesting question.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-523712")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2019")])]

#text("I think it’s worth noting that the committee has released its report:")

#link("https://www.mathunion.org/fileadmin/IMU/Report/SC/2019/structure_committee_final.pdf")[#text("Click to access structure_committee_final.pdf")]

#text("and that:")

#text("“The IMU Executive Committee (EC) has discussed the report and made the following decisions:")

#text("For the ICM 2022:")#linebreak()#text(" 1. The EC endorses the proposal of creating:")#linebreak()#text(" (i) A new Section 17 (Statistics and Data Analysis) which replaces the old Section 17 (Mathematics in Science and Technology), and which incorporates the Statistics part of the old Section 12 (Probability and Statistics), which now becomes Section 12 (Probability).")#linebreak()#text(" (ii) A new Section 18 (Stochastic and Differential Modeling), which expands on aspects of the old Section 17 (Mathematics in Science and Technology).")#linebreak()#text(" The rationale for these changes is to start the process of enhancing the representation of applied mathematics in the ICM, and to keep up with recent groundbreaking developments in applied mathematics.")#linebreak()#text(" 2. The EC endorses the given Sections with its descriptors and with the given base lecture slots.")#linebreak()#text(" 3. The EC endorses the proposal to leave 20 sectional talks to the discretion of the PC, as described in the SC report.")#linebreak()#text(" 4. The EC endorses the proposal to leave 2–3 plenary for “special plenary lectures” as described in the SC report.")#linebreak()#text(" 5. The EC recommends that the opening ceremony is to be streamed, while the recording of other lectures should be made available later to the mathematical community by the organizers in a timely fashion. Videos are to be stored at the IMU Secretariat.")#linebreak()#text(" 6. The EC asks that local organizers conduct an exit survey for ICM participants in order to guide subsequent SCs in their work.")

#text("For ICMs after 2022:")#linebreak()#text(" 7. The EC asks that the SC proposes a dynamic mechanism on how the size of each Section can reflect the activity in the various subfields of mathematics. This mechanism can be applied for the ICM 2026. “")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf3f9333bb27c9fb137983ab09a8db8725a027dcd044600f2e413952e4d54d0c-9ee43cbbf03da69a499125c671343b88ad746a582b357e7a884cd38238030077.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AA")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-524655")[#strong[#text("AA")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2019")])]

#text("I don’t know about other sections but the description of “Probability” seems weird. I really want to see what the previous description looked like.")

#text("—————————————————————-")#linebreak()#text(" Section 12. Probability (7–10 base lecture slots).")#linebreak()#text(" —————————————————————-")#linebreak()#text(" Description: Stochastic analysis, Stochastic PDEs, Markov processes. Interacting particle systems, Random media. Random matrices and random graphs. Conformally invariant models, random growth models, exactly solvable models. Branching processes. Rough paths, regularity structures. Stochastic networks, Stochastic geometry. Applications in Statistics, Data Science, Computer Science, Physics, or Life Sciences.")#linebreak()#text(" —————————————————————-")

#text("Aren’t “interacting particle systems, “random growth models”, “exactly solvable models”, and especially “stochastic networks” (aka queueing theory), all part of “Markov processes”?")

#text("Is “exactly solvable models” the same as integrable probability?")

#text("Aren’t “rough paths, regularity structures” part of “stochastic PDEs”? Why mention “regularity structures” so specifically?")

#text("Are “branching processes” such a big area of Probability? Why not “martingales”, or “Gaussian processes”, or “infinitely-divisible processes”, or “… processes”?")

#text("Why are “random matrices” and “random graphs” in one sentences? Does this means that only eigenvalue distributions of random graphs are of interest?")

#text("What is “stochastic geometry”?")

#text("No mention of foundations of probability, inequalities, limit theorems?")

#text("The description sounds as if to be part of Probability you have to work in the areas of Werner, Smirnov, Hairer, Tao (random matrices), or Borodin (interacting particle systems, random growth models, exactly solvable models). Plus a few random buzzwords. Who wrote this?")

#text("By the way, “interacting particle systems”, “random matrices” and “stochastic PDEs” are also part of Section 11, Mathematical Physics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/58e62d8a9052c0031ccbafa2c87c251d3691c6c86f3825b7b616ef8def4ad997-7722bfea0c5ef16506fab4938969eccc741f6847c4aaab127123328b72171347.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jamie")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-525316")[#strong[#text("Jamie")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2019")])]

#text("Descriptions of most sections look quite standard and uncontroversial.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08e1295cc07135dd015eae38c0386a1fd9cb765394e7c9a1c9aabd4a67425ec1-cbaa83195d1c9a8fc249c98ce0c98cbde651268adc08c4b80b1cd79f550879db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chael")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-527417")[#strong[#text("Chael")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2019")])]

#text("This description is completely out of sync with Section 60-xx of MSC: ")#link("https://cran.r-project.org/web/classifications/MSC.html")[#text("https://cran.r-project.org/web/classifications/MSC.html")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of j+O+H+n")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-628982")[#strong[#text("j+O+H+n")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2021")])]

#text("Seems like the ICM 2022 plenary speakers selection was influenced by the structure committee: ")#link("https://icm2022.org/plenary-lectures")[#text("https://icm2022.org/plenary-lectures")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Request for comments from the ICM Structure Committee | What's new")]], [#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/#comment-649306")[#strong[#text("Request for comments from the ICM Structure Committee | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2022")])]

#text("[…] of the ICM, and any proposals to improve that state for the subsequent congresses; we had issued a similar call on this blog back in 2019. This time around, of course, the situation is complicated by the extraordinary and exceptional […]")
]
