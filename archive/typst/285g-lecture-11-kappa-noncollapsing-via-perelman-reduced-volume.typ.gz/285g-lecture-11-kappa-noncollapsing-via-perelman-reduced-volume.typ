// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/05/14/285g-lecture-11-%ce%ba-noncollapsing-via-perelman-reduced-volume/
// Converted to Typst by tao2typ: "2026-10-14T15:16:46.369513+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "285G, Lecture 11: κ-noncollapsing via Perelman reduced volume", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("285G, Lecture 11: κ-noncollapsing via Perelman reduced volume")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 May 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/05/14/285g-lecture-11-%ce%ba-noncollapsing-via-perelman-reduced-volume/")[#text("https://terrytao.wordpress.com/2008/05/14/285g-lecture-11-%ce%ba-noncollapsing-via-perelman-reduced-volume/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Having established the monotonicity of the Perelman reduced volume in the ")#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/")[#text("previous lecture")]#text(" (after first heuristically justifying this monotonicity in ")#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/")[#text("Lecture 9")]#text("), we now show how this can be used to establish ")#mi("\\kappa")#text("-noncollapsing of Ricci flows, thus giving a second proof of Theorem 2 from ")#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/")[#text("Lecture 7")]#text(". Of course, we already proved (a stronger version) of this theorem already in ")#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/")[#text("Lecture 8")]#text(", using the Perelman entropy, but this second proof is also important, because the reduced volume is a more localised quantity (due to the weight ")#mi("e^{-l_{(0,x_0)}}")#text(" in its definition and so one can in fact establish ")#emph[#text("local ")]#text("versions of the non-collapsing theorem which turn out to be important when we study ancient ")#mi("\\kappa")#text("-noncollapsing solutions later in Perelman’s proof, because such solutions need not be compact and so cannot be controlled by global quantities (such as the Perelman entropy).")

#text("The route to ")#mi("\\kappa")#text("-noncollapsing via reduced volume proceeds by the following scheme:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#align(center)[#text("Non-collapsing at time t=0 (1)")]

#align(center)[#tao-fit-display[#mitex("\\Downarrow")]]

#align(center)[#text("Large reduced volume at time t=0 (2)")]

#align(center)[#tao-fit-display[#mitex("\\Downarrow")]]

#align(center)[#text("Large reduced volume at later times t (3)")]

#align(center)[#tao-fit-display[#mitex("\\Downarrow")]]

#align(center)[#text("Non-collapsing at later times t (4)")]
]

#text("The implication ")#mi("(2) \\implies (3)")#text(" is the monotonicity of Perelman reduced volume. In this lecture we discuss the other two implications ")#mi("(1) \\implies (2)")#text(", and ")#mi("(3) \\implies (4)")#text(").")

#text("Our arguments here are based on ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("Perelman’s first paper")]#text(", ")#link("http://arxiv.org/abs/math.DG/0605667")[#text("Kleiner-Lott’s notes")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian’s book")]#text(", though the material in the Morgan-Tian book differs in some key respects from the other two texts. A closely related presentation of these topics also appears in the paper of ")#link("http://arxiv.org/abs/math/0612069")[#text("Cao-Zhu")]#text(".")

#metadata(none) <tao-ccfce23b6f217e8ba56f>

#heading(level: 1)[#text("— Definitions —")]

#text("Let us first recall our definitions. Previously we defined Perelman reduced length and reduced volume for ancient flows ")#mi("t \\mapsto (M,g(t))")#text(" for ")#mi("t \\in (-\\infty,0]")#text(", centred at a point ")#mi("(0,x_0)")#text(" on the final time slice ")#mi("t=0")#text(", but one can also define these quantities for flows on the time interval ")#mi("{}[0,T]")#text(" and for points ")#mi("(t_0,x_0) \\in [0,T] \\times M")#text(" as follows. We introduce the backward time variable ")#mi("\\tau := t_0 - t")#text(". Given any path ")#mi("\\gamma: [0,\\tau_1] \\to M")#text(", we define its length")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("L(\\gamma) := \\int_0^{\\tau_1} \\sqrt{\\tau} (R + \\left|\\dot \\gamma(\\tau)\\right|_g^2)\\ d\\tau", block: true)]]

#text("and for any ")#mi("(t_1,x_1)")#text(" with ")#mi("0 \\leq t_1 < t_0")#text(", with ")#mi("\\tau_1 := t_0 - t_1")#text(", we define the reduced length")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("l_{(t_0,x_0)}(t_1,x_1) := \\frac{1}{2\\sqrt{\\tau_1}} \\inf_\\gamma L(\\gamma)")]]

#text("where ")#mi("\\gamma: [0,\\tau_1] \\to M")#text(" ranges over all ")#mi("C^1")#text(" paths from ")#mi("x_0")#text(" to ")#mi("x_1")#text(" (which can also be viewed as trajectories in the spacetime manifold ")#mi("{}[0,T] \\times M")#text(" from ")#mi("(t_0,x_0)")#text(" to ")#mi("(t_1,x_1)")#text(". The reduced volume is then defined as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\tilde V_{(t_0,x_0)}(\\tau_1) := \\frac{1}{\\tau_1^{d/2}} \\int_M e^{-l_{(t_0,x_0)}(t_1,x_1)}\\ d\\mu_{t_1}(x_1).")]]

#text("[Note: some authors normalise the reduced volume by using ")#mi("(4\\pi \\tau_1)^{d/2}")#text(" instead of ")#mi("\\tau_1^{d/2}")#text(", in order to give Euclidean space a reduced volume of 1, but this makes no essential difference to the analysis.]")

#text("The arguments of the ")#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/")[#text("previous lecture")]#text(" show that if ")#mi("t \\mapsto (M,g(t))")#text(" is a Ricci flow, then the reduced volume is a non-increasing function of ")#mi("\\tau_1")#text(" for fixed ")#mi("(t_0,x_0)")#text(". In particular, the reduced volume at later times ")#mi("t_1")#text(" is bounded from below by the reduced volume at time 0 (which is the implication ")#mi("(2) \\implies (3)")#text(").")

#heading(level: 1)[#text("— Heuristic analysis —")]

#text("In the case of the trivial Euclidean flow, the reduced length is given by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("l_{(t_0,x_0)}(t_1,x_1) = \\frac{\\left|x_1-x_0\\right|^2}{4\\tau_1} = \\frac{\\left|x_1-x_0\\right|^2}{4(t_1-t_0)}", block: true)]]

#text("with the minimising geodesic given by the formula")

#align(center)[#mi("\\gamma(\\tau) = x_0 + 2v \\sqrt{\\tau}")#text(" with ")#mi("v := \\frac{x_1-x_0}{2\\sqrt{\\tau_1}}")#text(" (9)")]

#text("Here, we briefly argue why we expect heuristically to have a similar relationship")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("l_{(t_0,x_0)}(t_1,x_1) \\approx \\frac{d_{g(t_1)}( x_0, x_1 )^2}{\\tau_1} + O(1)")]]

#text("for the reduced length on more general Ricci flows, under an assumption of bounded normalised curvature.")

#text("Specifically, suppose that we have a normalised curvature bound ")#tao-math("\\left|\\text{Riem}\\right|_g = O(1/\\tau_1)", block: false)#text(". Then we have ")#mi("\\dot g = - 2\\text{Ric} = O( g / \\tau_1 )")#text(", and so over the time scale ")#mi("\\tau_1")#text(", we see that the metric only changes by a multiplicative constant. If we ignore such constants for now, we see that the distance function ")#mi("d_{g(t)}(x, y)")#text(" does not change much over the time interval of interest.")

#text("Let ")#mi("\\gamma")#text(" be a minimising ")#mi("{\\mathcal L}")#text("-geodesic from ")#mi("(t_0,x_0)")#text(" to ")#mi("(t_1,x_1)")#text(". This path has to traverse a distance roughly ")#mi("d_{g(t_1)}(x_0,x_1)")#text(" in time ")#mi("\\tau_1")#text(", and so its speed ")#tao-math("\\left|\\dot \\gamma\\right|_g", block: false)#text(" should be at least ")#mi("d_{g(t_1)}(x_0,x_1) / \\tau_1")#text(". Also, the scalar curvature R should be ")#mi("O(1/\\tau_1)")#text(" by the bounded normalised curvature assumption. Putting all this into (5) and (6) we heuristically obtain (10).")

#text("From (10), we expect the expression ")#mi("e^{-l_{(t_0,x_0)}(t_1,x_1)}")#text(" to be comparable to 1 when ")#mi("x_1")#text(" is inside the ball ")#mi("B_{g(t_1)}(x_0, O( \\sqrt{t_1} ))")#text(", and to be exponentially small outside of this ball. Using (7), we thus obtain a heuristic approximation for the Perelman reduced volume:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\tilde V_{(t_0,x_0)}(\\tau_1) \\approx \\text{Vol}_{g(t_1)}(x_0, \\sqrt{\\tau_1} ) / \\tau_1^{d/2}.")]]

#text("Thus the Perelman reduced volume ")#mi("\\tilde V_{(t_0,x_0)}(\\tau_1)")#text(" is heuristically equivalent to the Bishop-Gromov reduced volume at ")#mi("(x_1,t_1)")#text(" at scale ")#mi("\\tau_1")#text(". Since the latter measures non-collapsing, we heuristically obtain the implications ")#mi("(1) \\implies (2)")#text(" and ")#mi("(3) \\implies (4)")#text(".")

#heading(level: 1)[#text("— From non-collapsing to lower bounds on reduced volume —")]

#text("Now we discuss implications of the form ")#mi("(1) \\implies (2)")#text(" in more detail. Specifically, we show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1. ")]#text(" Let ")#mi("t \\mapsto (M,g(t))")#text(" be a d-dimensional Ricci flow on a complete manifold M for ")#mi("t \\in [0,T]")#text(" such that we have the normalised initial conditions ")#tao-math("\\left|\\text{Riem}(0,x)\\right|_g \\leq 1", block: false)#text(" and ")#mi("\\text{Vol}_{g(0)}(B_{g(0)}(x,1)) \\geq \\omega")#text(" at time t=0 for some ")#mi("\\omega > 0")#text(" and all x (so in particular, the geometry is non-collapsed at scale 1 at all points at time zero). Then we have ")#mi("\\tilde V_{(t_0,x_0)}(t_0) \\geq c")#text(" for some ")#mi("c = c(d,\\omega,T) > 0")#text(" and all ")#mi("(t_0,x_0) \\in (0,T) \\times M")#text(".")
]

#text("The main task in proving implications of the form ")#mi("(1) \\implies (2)")#text(" is to show the existence of some large ball at time zero on which ")#mi("l = l_{(t_0,x_0)}")#text(" is bounded from above.")

#text("Turning to the specific proposition above, we first observe that we can reduce to the large time case ")#mi("t_0 \\geq 1")#text(". Indeed, if ")#mi("0 < t_0 < 1")#text(", then we can rescale the Ricci flow until ")#mi("t_0 = 1")#text(" (this increases T, but we can simply truncate T to compensate for this). This rescaling reduces the size of the initial Riemann curvature, and the volume of balls of unit radius are still bounded from below thanks to the ")#link("http://en.wikipedia.org/wiki/Bishop%E2%80%93Gromov_inequality")[#text("Bishop-Gromov inequality")]#text(".")

#text("The next observation we need is that the control on the geometry at time zero persists for a short amount of additional time:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" (Local persistence of controlled geometry) Let the hypotheses be as in Proposition 1. Then there exists an absolute constant c > 0 (depending only on d) such that ")#tao-math("\\left|\\text{Riem}(t,x)\\right|_g \\leq 2", block: false)#text(" for all times ")#mi("0 \\leq t \\leq c")#text(" and ")#mi("x \\in M")#text(". Also we have ")#mi("\\text{Vol}_{g(t)}(B_{g(t)}(x,1)) \\ge \\omega^{\\prime}")#text(" for all ")#mi("0 \\leq t \\leq c")#text(" and ")#mi("x \\in M")#text(", and some ")#mi("\\omega^{\\prime} > 0")#text(" depending only on ")#mi("\\omega, d")#text(".")
]

#strong[#text("Proof.")]#text(" We recall the nonlinear heat equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\partial_t \\text{Riem} = \\Delta \\text{Riem} + {\\mathcal O}( g^{-1} \\text{Riem}^2 )")]]

#text("for the Riemann curvature tensor ")#mi("\\text{Riem}")#text(" under Ricci flow (see equation (31) of ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text("). The bound on Riemann curvature can then obtained by an application of Hamilton’s maximum principle (Proposition 1 from ")#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/")[#text("Lecture 3")]#text("); we leave this as an exercise to the reader. [Technically, one needs to first generalise the maximum principle from compact manifolds to complete manifolds of bounded curvature. This can be done using barrier functions, but it is somewhat technically involved: see Chapter 12 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2365237")[#text("Chow et al.")]#text(" for details.] As in the heuristic discussion, the bounds on the Riemann curvature (and hence the Ricci curvature) show that the metric g and the distance function ")#mi("d_{g(t)}(x,y)")#text(" only change by at most a multiplicative constant; this also implies that the volume measure only changes by a multiplicative constant as well. From this we see that the lower bound on the volume of unit balls at time zero implies a lower bound on the volume of balls of radius O(1) at times ")#mi("0 \\leq t \\leq c")#text("; one can then get back to balls of radius 1 by invoking the Bishop-Gromov inequality. ")#mi("\\Box")

#text("The next task is to find a point ")#mi("y \\in M")#text(" such that the reduced length from ")#mi("(t_0,x_0)")#text(" to ")#mi("(0,y)")#text(" is small, since this should force y (and the points close to y) to give a large contribution to the reduced volume. In the Euclidean case, one would just take ")#mi("y = x_0")#text(" (see (8)), but this does not necessarily work for general Ricci flows: note from (5), (6) that the reduced length from ")#mi("(t_0,x_0)")#text(" to ")#mi("(t_1,x_0)")#text(" could in principle be as large as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\frac{1}{2\\sqrt{t_0-t_1}} \\int_0^{t_0-t_1} \\sqrt{\\tau} R(t_0-\\tau,x_0)\\ d\\tau,")]]

#text("which could be quite large if the scalar curvature becomes large and positive (which is certainly within the realm of possibility, especially if one is approaching a singularity).")

#text("Fortunately, we can use the parabolic properties of the reduced length ")#mi("l = l_{(t_0,x_0)}")#text(", combined with the maximum principle, to locate a good point y with the required properties. From the analysis of the ")#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/")[#text("previous lecture")]#text(", and some rescaling and time translation, we obtain the identities and inequalities")

#tao-aligned(keep: true)[


#tao-math("\\nabla l  & = X", block: true, numbering: n => [#text("(14)")])



#tao-math("\\partial_\\tau l  & = \\frac{1}{2} R - \\frac{1}{2} \\left|X\\right|_g^2 - \\frac{1}{2\\tau} l", block: true, numbering: n => [#text("(15)")])



#tao-math("\\Delta l  & \\leq \\frac{d}{2\\tau} + \\frac{1}{2} \\left|X\\right|_g^2 - \\frac{1}{2} R - \\frac{1}{2\\tau} l", block: true, numbering: n => [#text("(16)")])
]

#text("(cf. equations (29), (33), (47) from the ")#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/")[#text("previous lecture")]#text("), where ")#mi("X = \\gamma^{\\prime}(\\tau)")#text(" is the final velocity vector of the minimising ")#mi("{\\mathcal L}")#text("-geodesic from ")#mi("(t_0,x_0)")#text(" to ")#mi("(t_1,x_1)")#text(". [We only derived (14)-(16) rigorously inside the domain of injectivity, but as discussed in the ")#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/")[#text("previous lecture")]#text(", one can establish the above inequalities in the sense of distributions on the whole manifold M.] From (15), (16) we obtain in particular that l is a supersolution of a heat equation:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\partial_t l \\geq \\Delta l + \\frac{l-(d/2)}{\\tau}.")]]

#text("[Note that (17) holds with equality in the Euclidean case (8).] From the maximum principle (Corollary 1 from ")#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/")[#text("Lecture 3")]#text("), we see that if we have the uniform lower bound ")#mi("l \\geq d/2")#text(" at some time ")#mi("0 \\leq t < t_0")#text(", then this bound will persist for all times between t and ")#mi("t_0")#text(". On the other hand, by using the upper bound (12) for ")#mi("l(t_1,x_0)")#text(" we see that the bound ")#mi("l \\geq d/2")#text(" breaks down for times t sufficiently close to ")#mi("t_0")#text(". We therefore conclude that ")#mi("\\inf_{x \\in M} l(t,x) < d/2")#text(" for all ")#mi("0 \\leq t < t_0")#text(". In particular we can find a point y such that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("l(c,y) < d/2,")]]

#text("where c is the small constant in Lemma 1. Given the bounded geometry control in Lemma 1 (and in particular the fact that g(t) is comparable to g(0) for ")#mi("0 \\leq t \\leq c")#text("), it is thus not hard to see (by concatenating the minimising path from ")#mi("(0,x_0)")#text(" to ")#mi("(c,y)")#text(" with a geodesic segment (in the g(0) metric) from ")#mi("(c,y)")#text(" to ")#mi("(0,y^{\\prime})")#text(") that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("l(0, y^{\\prime}) \\leq C \\text{ for } y^{\\prime} \\in B_{g(0)}(y, c^{\\prime})")]]

#text("for some ")#mi("C, c^{\\prime} > 0")#text(" depending only on d, where. The hypotheses on the geometry of g(0), combined with the Bishop-Gromov inequality, give a uniform lower bound for the volume of ")#mi("B_{g(0)}(y,c^{\\prime})")#text(", and Proposition 1 now follows directly from the definition (7) of reduced volume.")

#heading(level: 1)[#text("— From lower bounds on reduced volume to non-collapsing —")]

#text("Now we consider the reverse type of implication ")#mi("(3) \\implies (4)")#text(" from those just discussed. Here, the task is reversed; rather than establishing ")#emph[#text("upper")]#text(" bounds on l on a ball of radius comparable to one, the main challenge is now to establish ")#emph[#text("lower")]#text(" bounds (of the form ")#mi("l \\geq -O(1)")#text(") on l on such a ball, as well as some growth bounds on l away from this ball.")

#text("We begin by formally stating the result of the form ")#mi("(3) \\implies (4)")#text(" that we shall establish.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2.")]#text(" Let ")#mi("t \\mapsto (M,g(t))")#text(" be a d-dimensional Ricci flow on a complete manifold M for ")#mi("t \\in [0,T]")#text(", and let ")#mi("0 \\leq t_0-r_0^2 \\leq t_0 \\leq T")#text(" and ")#mi("x_0 \\in M")#text(" be such that ")#tao-math("\\left|\\text{Riem}(t,x)\\right|_g \\leq r_0^{-2}", block: false)#text(" for ")#mi("x \\in B_{g(t_0)}(x_0,r_0)")#text(" and ")#mi("t \\in [t_0-r_0^2,t_0]")#text(", and such that ")#mi("\\tilde V_{(t_0,x_0)}(\\tau) \\geq \\delta")#text(" for some ")#mi("\\delta > 0")#text(" and all ")#mi("0 < \\tau < r_0^2")#text(". Then one has ")#mi("\\text{Vol}_{g(t_0)}( B_{g(t_0)}(x_0,r_0) ) \\geq c")#text(" for some c depending only on d and ")#mi("\\delta")#text(".")
]

#strong[#text("Exercise 1.")]#text(" Use Proposition 1, Proposition 2, and the monotonicity of Perelman reduced volume to deduce Theorem 2 from ")#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/")[#text("Lecture 7")]#text(". ")#mi("\\diamond")

#text("We now prove Proposition 2. We first observe by time translation (and by removing the portion of the Ricci flow below ")#mi("t_0-r_0^2")#text(" that we may normalise ")#mi("t_0-r_0^2=0")#text(", and then by scaling we may normalise ")#mi("t_0 = 1")#text(". Thus we now have a Ricci flow on [0,1] with ")#tao-math("\\left|\\text{Riem}(t,x)\\right|_g \\leq 1", block: false)#text(" on ")#mi("{}[0,1] \\times B_{g(1)}(x_0,1)")#text(" and")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\tilde V_{(1,x_0)}(\\tau) = \\int_M e^{-l(\\tau,x)}\\ d\\mu_{g(\\tau)}(x) \\geq \\delta")]]

#text("for all ")#mi("0 < \\tau \\leq 1")#text(", where ")#mi("l = l_{(1,x_0)}")#text(" is the reduced length function. Our task is to show that ")#mi("\\text{Vol}_{g(1)}( B_{g(1)}(x_0,1) )")#text(" is bounded away from zero.")

#text("We first observe (as in Lemma 1) that the metrics g(t) for ")#mi("0 \\leq t \\leq 1")#text(" are all comparable to each other up to multiplicative constants on ")#mi("B_{g(1)}(x_0,1)")#text(", and so the balls in these metrics also differ only up to multiplicative constants.")

#text("Next, we would like to localise the reduced volume (20) to the ball ")#mi("B_{g(1)}(x_0,1)")#text(" (since this is the only place where we really control the geometry). To do this it is convenient to work in the parabolic counterpart of normal coordinates around ")#mi("(1,x_0)")#text(" and exploit the pointwise version of the Perelman reduced volume monotonicity. To motivate this, recall from the pointwise inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("{\\mathcal L}_{\\partial r} d\\mu \\leq \\frac{d-1}{r}\\ d\\mu")]]

#text("that we had the Bishop-Gromov inequality")

#align(center)[#mi("\\displaystyle \\partial_r r^{-(d-1)} \\int_{S(x_0,r)}\\ dS \\leq 0")#text(" (21′)")]

#text("where ")#mi("S(x_0,r)")#text(" is the sphere of radius r centred at ")#mi("x_0")#text(" with area element dS. Indeed, we can rewrite the left-hand side of (21′) as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\partial_r r^{-(d-1)} \\int_{S^{d-1}} J_r( \\omega )\\ d\\omega")]]

#text("where ")#mi("S^{d-1}")#text(" is the standard sphere with the standard area element ")#mi("d\\omega")#text(", and ")#mi("J_r")#text(" is the ")#link("http://en.wikipedia.org/wiki/Jacobian")[#text("Jacobian")]#text(" of the exponential map ")#mi("\\omega \\mapsto \\exp_{x_0}(r \\omega)")#text("; in the Euclidean case, ")#mi("J_r(\\omega) = r^{d-1}")#text(". [Actually, once the radius r exceeds the injectivity radius, one has to restrict to the portion of ")#mi("S^{d-1}")#text(" that has not yet encountered the ")#link("http://en.wikipedia.org/wiki/Cut_locus_%28Riemannian_manifold%29")[#text("cut locus")]#text(", but let us ignore this technical issue for now.] The inequality (21) (when combined with the ")#link("http://en.wikipedia.org/wiki/Gauss%27s_lemma_%28Riemannian_geometry%29")[#text("Gauss lemma")]#text(") is equivalent to the pointwise inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\partial_r r^{-(d-1)} J_r(\\omega) \\leq 0")]]

#text("which certainly implies (22), but also implies the stronger fact that the Bishop-Gromov inequality can be localised to arbitrary sectors in the sense that ")#mi("r^{-(d-1)} \\int_{\\Omega} J_r(\\omega)\\ d\\omega")#text(" (which can be viewed as the Bishop-Gromov reduced volume of the sector ")#mi("\\{ \\exp_{x_0}(r\\omega): \\omega \\in \\Omega \\}")#text(") is non-increasing in ")#mi("r")#text(".")

#text("Now we develop parabolic analogues of the above observations. Recall from the ")#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/")[#text("previous lecture")]#text(" that we have an ")#mi("{\\mathcal L}")#text("-exponential map ")#mi("{\\mathcal L}\\exp_{(1,x_0),\\tau_1}: T_{x_0} M \\to M")#text(" for ")#mi("0 \\leq \\tau_1 \\leq 1")#text(" that sends a tangent vector v to ")#mi("\\gamma(\\tau_1)")#text(", where ")#mi("\\gamma: [0,\\tau] \\to M")#text(" is the unique ")#mi("{\\mathcal L}")#text("-geodesic starting at ")#mi("x_0")#text(" with initial condition ")#mi("v = \\lim_{\\tau \\to 0} \\sqrt{\\tau} X(\\tau) = \\lim_{\\tau \\to 0} \\sqrt{\\tau} \\gamma^{\\prime}(\\tau)")#text(". In the Euclidean case, this map is given by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("{\\mathcal L}\\exp_{(1,x_0),\\tau_1}(v)= x_0 + 2 (x_1-x_0) \\sqrt{\\tau_1}")]]

#text("as can be seen from (9). We can then rewrite the reduced volume ")#mi("\\tilde V_{(1,x_0)}(\\tau)")#text(" in terms of “normal coordinates” as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\tilde V_{(1,x_0)}(\\tau) = \\tau^{-d/2} \\int_{{\\Bbb R}^d} e^{-l({\\mathcal L} \\exp_{(1,x_0),\\tau}(v))} J_{\\tau}(v)\\ dv")]]

#text("where ")#mi("J_\\tau")#text(" is the Jacobian of the map ")#mi("v \\mapsto {\\mathcal L}\\exp_{(1,x_0),\\tau_1}(v)")#text(". (Again, one has to restrict ")#mi("{\\Bbb R}^d")#text(" to the portion of the tangent manifold lies inside the injectivity domain, but this domain turns out to be non-increasing in ")#mi("\\tau")#text(" (for much the same reason that the region inside the cut locus of a point in a Riemannian manifold is star-shaped) and so this effect works in our favour as far as monotonicity is concerned.)")

#text("In the ")#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/")[#text("previous lecture")]#text(" we saw that the monotonicity of Perelman reduced volume followed from the pointwise inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#tao-math("\\partial_{\\tau} l - \\Delta l + \\left|\\nabla l\\right|_{g}^2 - R + \\frac{d}{2\\tau} \\geq 0", block: true)]]

#text("which of course also follows from (14)-(16).")

#strong[#text("Exercise 2.")]#text(" Use (14), (26), and the identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\partial_\\tau {\\mathcal L}\\exp_{(1,x_0),\\tau}(v) = X")]]

#text("(which basically follows from the fact that any segment of a minimising ")#mi("{\\mathcal L}")#text("-geodesic is again a ")#mi("{\\mathcal L}")#text("-geodesic) to derive the pointwise inequality")

#align(center)[#mi("\\displaystyle \\partial_\\tau \\tau^{-d/2} e^{-l({\\mathcal L} \\exp_{(1,x_0),\\tau}(v))} J_{\\tau}(v) \\leq 0")#text(". ")#mi("\\diamond")#text(" (38)")]

#text("Exercise 2 reproves the monotonicity of Perelman reduced volume (25), but also proves a stronger local version of this monotonicity in which the region of integration ")#mi("{\\mathbb R}^d")#text(" is replaced by an arbitrary region ")#mi("\\Omega")#text(" (intersected with the injectivity region, as mentioned earlier).")

#text("In the Euclidean case, a computation using (8) and (24) shows that ")#tao-math("l({\\mathcal L} \\exp_{(1,x_0),\\tau}(v)) = \\left|v\\right|^2", block: false)#text(" and ")#mi("J_\\tau(v) = 2^n \\tau^{d/2}")#text(". Also, one can use some basic analysis arguments to show that in the limit ")#mi("\\tau \\to 0")#text(", the expressions in (25) converge pointwise to their Euclidean counterparts. As a consequence we obtain the pointwise domination")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(39)")])
#tao-math("\\tau^{-d/2} e^{-l({\\mathcal L} \\exp_{(1,x_0),\\tau}(v))} J_{\\tau}(v) \\leq 2^{n/2} e^{-\\left|v\\right|^2}", block: true)]]

#text("for any v and any ")#mi("0 < \\tau < 1")#text(". As a consequence, the far part of (25) (corresponding to “fast” geodesics) is negligible: we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(40)")])
#tao-math("\\tau^{-d/2} \\int_{\\left|v\\right| > C} e^{-l({\\mathcal L} \\exp_{(1,x_0),\\tau}(v))} J_{\\tau}(v)\\ dv \\leq \\delta/2", block: true)]]

#text("for some C depending only on d and ")#mi("\\delta")#text(". From this and the hypothesis (19) we thus obtain lower bounds on ")#emph[#text("local")]#text(" Perelman reduced volume, or more precisely that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(41)")])
#tao-math("\\tau^{-d/2} \\int_{\\left|v\\right| \\leq C} e^{-l({\\mathcal L} \\exp_{(1,x_0),\\tau}(v))} J_{\\tau}(v)\\ dv \\geq \\delta/2", block: true)]]

#text("for all ")#mi("0 < \\tau \\leq 1")#text(".")

#text("Now, we have bounded curvature on the cylinder ")#mi("{}[0,1] \\times B_{g(1)}(x_0,1)")#text(". Using the heat equation (12) and standard parabolic regularity estimates, we thus conclude that any first derivatives of the curvature are also bounded on the cylinder ")#mi("{}[1/2,1] \\times B_{(g(1)}(x_0,1/2)")#text(". (In fact, all higher derivatives are controlled as well; see this ")#link("http://www.ams.org/mathscinet-getitem?mr=1001277")[#text("paper of Shi")]#text(" for full details.) In particular we have ")#mi("\\nabla R = O(1)")#text(" in this cylinder. Thus the equation G=0 for an ")#mi("{\\mathcal L}")#text("-geodesic (where G was defined in equation (27) of the previous lecture) becomes")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(42)")])
#tao-math("\\nabla_\\tau X + \\frac{1}{2\\tau} X = O(1) + O( \\left|X\\right| )", block: true)]]

#text("or equivalently that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(43)")])
#tao-math("\\nabla_\\tau (\\sqrt{\\tau} X) = O(\\sqrt{\\tau}) + O( \\sqrt{\\tau} \\left|X\\right| )", block: true)]]

#text("as long as the geodesic stays inside this smaller cylinder. From this and Gronwall’s inequality one easily verifies that for sufficiently small ")#mi("0 < \\tau < 1/2")#text(" (depending on C, d), the exponential map ")#mi("{\\mathcal L}\\exp_{(1,x_0),\\tau}(v)")#text(" does not exit the cylinder ")#mi("{}[1/2,1] \\times B_{g(1)}(x_0,1/2)")#text(" for ")#tao-math("\\left|v \\right|\\leq C", block: false)#text(". On the other hand, at time ")#mi("\\tau")#text(", we see from (5), (6) and the bounds on curvature in this cylinder that the reduced length l of the associated ")#mi("{\\mathcal L}")#text("-geodesic is bounded below by some constant depending on ")#mi("\\tau, C, d")#text(". We thus see (from the change of variables formula) that the left-hand side of (41) is bounded above by ")#mi("O_{\\tau,C,d}( \\text{Vol}_{g(1-\\tau)}( B_{g(1)}(x_0,1/2) ) )")#text(". Choosing ")#mi("\\tau")#text(" to be a small number depending on C, d, we thus conclude from (41) that the volume of ")#mi("B_{g(1)}(x_0,1)")#text(" with respect to ")#mi("g(1-\\tau)")#text(" (and hence g(1), by comparability of metrics) is bounded from below by some constant depending on C and d, and thus ultimately on ")#mi("\\delta")#text(" and d, giving Proposition 2 as desired.")

#heading(level: 1)[#text("— Extensions —")]

#text("The pointwise nature of the monotonicity of Perelman reduced volume allows one to derive local versions of the non-collapsing result, in which one only needs a portion of the geometry to be non-collapsed at the initial time. A typical version of such a local noncollapsing result reads as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" (Perelman’s non-collapsing theorem, second version) Let ")#mi("t \\mapsto (M,g(t))")#text(" be a d-dimensional Ricci flow on the time interval ")#mi("{}[0,r_0^2]")#text(", and suppose that one has the bounded normalised curvature condition ")#tao-math("\\left|\\text{Riem}\\right|_g \\leq r_0^{-2}", block: false)#text(" on a cylinder ")#mi("{}[0,r_0^2] \\times B_{g(0)}(x_0,r_0)")#text(" for some ")#mi("x_0 \\in M")#text(". Suppose also that we have the volume lower bound ")#mi("\\text{Vol}_{g(0)}(B_{g(0)}(x_0,r_0)) \\geq c r_0^d")#text(" for some ")#mi("c>0")#text(". Then for any ")#mi("A > 0")#text(", the Ricci flow is ")#mi("\\kappa")#text("-noncollapsed at ")#mi("(r_0^2,x)")#text(" for any ")#mi("x \\in B_{g(r_0^2)}(x_0,Ar_0)")#text(" and at any scale ")#mi("0 < r < r_0")#text(", for some ")#mi("\\kappa")#text(" depending only on d, c, A.")
]

#text("The novelty here is that the geometry is controlled in a cylinder, rather than on the initial time slice, but one gets to conclude ")#mi("\\kappa")#text("-noncollapsing at points some distance away from the cylinder. In view of Lemma 1, we see that this result is more or less a strengthening of the previous ")#mi("\\kappa")#text("-noncollapsing theorem.")

#text("This theorem (or more precisely, a generalisation of it involving Ricci flow with surgery) is used in the original argument of ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("Perelman")]#text(" (and then in the later treatments by ")#link("http://arxiv.org/abs/math.DG/0605667")[#text("Kleiner-Lott")]#text(" and ")#link("http://arxiv.org/abs/math/0612069")[#text("Cao-Zhu")]#text(") in order to deal with the long-time behaviour of Ricci flow with surgery, which is needed for the geometrisation conjecture. For proving the Poincaré conjecture, though, one has finite time extinction, and it turns out that the above theorem is not needed for the proof of that conjecture (for instance, it does not appear in treatment of ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian")]#text("). Nevertheless I will sketch how the above theorem is proven below, since there are one or two interesting technical tricks that get used in the argument.")

#text("The proof of Theorem 1 is, unsurprisingly, a modification of the previous arguments . The implications ")#mi("(2) \\implies (3)")#text(" and ")#mi("(3) \\implies (4)")#text(" are basically unchanged, but one needs to replace Proposition 1 by the following variant.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3. ")]#text(" Let the hypotheses be as in Theorem 1. Then for any ")#mi("x \\in B_{g(r_0^2)}(x_0,Ar_0)")#text(" one has ")#mi("\\tilde V_{(r_0^2,x)}(r_0^2) \\geq c^{\\prime}")#text(" for some ")#mi("c^{\\prime} > 0")#text(" depending on A, c, d.")
]

#text("We sketch the proof of Proposition 3. It is convenient to rescale so that ")#mi("r_0=1")#text(". In view of the non-collapsed nature of the geometry in ")#mi("B_{g(0)}(x_0,1)")#text(", it suffices to establish a lower bound of the form ")#mi("l_{(1,x)}(0,z) \\geq -C")#text(" for all ")#mi("z \\in B_{g(0)}(x_0,1/2)")#text(" for some ")#mi("C > 0")#text(" depending on A,c,d. Actually, because of the bounded geometry in the cylinder, it suffices to show that ")#mi("l_{(1,x)}(1/2,y) \\geq -C^{\\prime}")#text(" for just one point ")#mi("z \\in B_{g(1/2)}(x_0,1/10)")#text(" for some ")#mi("C^{\\prime} > 0")#text(" depending on A,c,d, since one can join (1/2,y) by a geodesic to (1,z) much as in the proof of Proposition 1.")

#text("The task is now analogous to that of finding a point y that obeyed the relation (18), so we expect the heat equation (17) to again play a role. We do not need the sharp bound of n/2 which occurs in (18); on the other hand, y is now constrained to lie in a ball, which defeats a direct application of the maximum principle. To fix this one has to multiply the reduced length l by a penalising weight to force the minimum to lie in the desired ball at time 1/2, and then rapidly relax this weight as one moves from time 1/2 to time 1 so that it incorporates the point x at time 1. It turns out the maximum principle can then be applied with a suitable choice of weights, as long as one knows that the distance function ")#mi("r(t,y) = d_{g(t)}(x_0,y)")#text(" is a supersolution to a heat equation, and more precisely that ")#mi("\\partial_t r - \\Delta r \\geq -C")#text(" when r is bounded away from the origin. But this can be established by the first and second variation formulae for the distance function, and in particular using the non-negativity of the second variation for minimising geodesics. Details can be found in Section 8 of ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("Perelman’s paper")]#text(", Sections 26-27 of ")#link("http://arxiv.org/abs/math.DG/0605667")[#text("Kleiner-Lott")]#text(", or Section 3.4 of ")#link("http://arxiv.org/abs/math/0612069")[#text("Cao-Zhu")]#text(".")

#strong[#text("Remark 1.")]#text(" One can also interpret the above analysis in terms of heat kernels, and using (26) instead of (17). The former inequality is equivalent to the assertion that the function ")#mi("v := (4\\pi \\tau)^{-d/2} e^{-l}")#text(" is a subsolution of the adjoint heat equation: ")#mi("\\partial_t v + \\Delta v - Rv \\leq 0")#text(". As ")#mi("t \\to 1")#text(", v approaches a Dirac mass at x (indeed, v asymptotically resembles the Euclidean backwards heat kernel from ")#mi("(1,x_0)")#text(") and the task is to obtain upper bounds on v at some point on a ball ")#mi("B_{g(1/2)}(x_0,1/10)")#text(" at time 1/2. This is basically equivalent to establishing lower bounds of Gaussian type for the fundamental solution of the adjoint heat equation at some point in ")#mi("B_{g(1/2)}(x_0,1/10)")#text(". Similar analysis in the case of a static manifold with potential (and a lower bound on Ricci curvature) was carried out somewhat earlier by ")#link("http://www.ams.org/mathscinet-getitem?mr=834612")[#text("Li and Yau")]#text(". ")#mi("\\diamond")

#text("As mentioned previously, in order to apply the non-collapsing result beyond the first surgery time, it is necessary to develop analogues of the above theory for Ricci flows with surgery. This turns out to be remarkably technical, but the main ideas at least are fairly clear. Firstly, one has to delete all ")#mi("{\\mathcal L}")#text("-geodesics which pass through surgery regions when defining the Perelman reduced volume; such curves are called “inadmissible”. Note that if ")#mi("(1,x_0)")#text(" is in a surgery region to begin with, then every curve is inadmissible but in this case the geometry can be controlled directly from the surgery theory. As it turns out, one can similarly deal with the case when ")#mi("(1,x_0)")#text(" has extremely high curvature because one can control the geometry of such regions. So we can easily eliminate these bad cases.")

#text("Because of the pointwise nature of the monotonicity formula for reduced volume, this restriction of admissibility does not affect the “")#mi("(2) \\implies (3)")#text("” stage of the argument. The “")#mi("(3) \\implies (4)")#text("” step is also largely unaffected, since removing inadmissible components of the reduced volume only serves to strengthen the hypothesis (3). But significant new technical difficulties arise in the “")#mi("(1) \\implies (2)")#text("” portion of the argument, when one has to argue that not too much of the reduced volume has been deleted by all the various surgeries that take place between time t=0 and time ")#mi("t=1")#text(". In particular, we still need to find a point y obeying (18) (or something very much like (18)) which is admissible. To do this, the basic idea is to establish that inadmissible curves have large reduced length (and so removing them will not impact the search for a solution to (18)). For technical reasons it is better to restrict attention to ")#emph[#text("barely admissible")]#text(" curves – curves which just touch the border of the surgery region, but do not actually enter it. In this case it is possible to use the geometric control of the surgery regions to give some non-trivial lower bounds on the reduced length of such curves, although there are still significant technical issues to resolve beyond this. I hope to return to this point later in the course, when we have defined surgery properly.")

#heading(level: 1)[#text("— Epilogue: a connection between Perelman entropy and Perelman reduced volume —")]

#text("We have shown two routes towards establishing ")#mi("\\kappa")#text("-non-collapsing of Ricci flows, one using the (parameterised) Perelman entropies")

#tao-aligned(keep: true)[


#tao-math("\\mu(g(t),\\tau)  & := \\inf \\{ \\int_M (\\tau(\\left|\\nabla f\\right|^2 + R) + f - d) (4\\pi\\tau)^{-d/2} e^{-f}\\ d\\mu:", block: true)



#tao-math("\\int_M (4\\pi\\tau)^{-d/2} e^{-f}\\ d\\mu  & = 1 \\}", block: true, numbering: n => [#text("(44)")])
]

#text("and one using the reduced volumes ")#mi("\\tilde V_{(0,x_0)}")#text(" mentioned above. Actually, the two quantities are related to each other (this is hinted at in Section 9 of ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("Perelman’s paper")]#text("); very roughly speaking, the potential function f in the theory of Perelman entropy plays the same role that reduced length l does in the theory of Perelman volume. Indeed, using (44) and shifting f by a constant if necessary, we have the log-Sobolev inequality")

#align(center)[#tao-fit-display[#tao-math("\\int_M (\\tau(\\left|\\nabla f\\right|^2 + R) + f - d) (4\\pi\\tau)^{-d/2} e^{-f}\\ d\\mu", block: true)]]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(45)")])
#mitex("\\geq [\\mu(g(t),\\tau) - \\log \\int_M (4\\pi\\tau)^{-d/2} e^{-f}\\ d\\mu] \\int_M (4\\pi\\tau)^{-d/2} e^{-f}\\ d\\mu.")]]

#text("An integration by parts reveals that we can replace the ")#tao-math("\\left|\\nabla f\\right|^2", block: false)#text(" on the left -hand side by ")#mi("\\Delta f")#text(", and hence one can also replace this quantity by ")#tao-math("2\\Delta f - \\left|\\nabla f\\right|^2", block: false)#text(".")

#text("We now apply this inequality with ")#mi("\\tau := t_0-t")#text(" and ")#mi("f = l_{(t_0,x_0)}")#text(" for some spacetime point ")#mi("(t_0,x_0)")#text(" in the Ricci flow. Using (14), (16) we see that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(46)")])
#tao-math("2 \\Delta f - \\left|\\nabla f\\right|^2 \\leq \\frac{d}{2\\tau} - R - \\frac{1}{\\tau} f", block: true)]]

#text("and thus the left-hand side of (45) is non-positive. Using (7) we thus conclude a simple relationship between entropy and reduced volume:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(47)")])
#mitex("\\mu(g(t_0-\\tau),\\tau) \\leq \\log \\frac{\\tilde V_{(t_0,x_0)}(\\tau)}{(4\\pi)^{d/2}}.")]]

#text("[As usual, we have equality in physical space; this inequality also reinforces the suggestion that one normalise the reduced volume by an additional factor of ")#mi("1/(4\\pi)^{d/2}")#text(".]")

#text("Thus the Perelman entropy can be viewed as a global analogue of the Perelman reduced volume, in which we allow the base point ")#mi("x_0")#text(" to vary (thus it measures the global non-collapsing nature of the manifold, as opposed to the local nature; we already saw this in ")#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/")[#text("Lecture 8")]#text("; compare in particular equation (62) from ")#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/")[#text("Lecture 8")]#text(" with the heuristic (11) using (47).)")

#text("There are other connections between entropy and reduced volume; compare for instance the flow equation for the potential f (equation (46) from ")#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/")[#text("Lecture 8")]#text(") with equation (26) here. The adjoint heat equation ")#mi("\\partial_t u + \\Delta u - Ru = 0")#text(" also makes essentially the same appearance in both theories. See Section 9 of ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("Perelman’s paper")]#text(" for further discussion.")

#strong[#text("Remark 2.")]#text(" As remarked above, the flow equation for f can be viewed as a pointwise versions of the entropy monotonicity formula, which in principle leads to localised monotonicity formulae for the Perelman entropy; some analysis in this direction appears in Section 9 of ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("Perelman’s paper")]#text(". But I do not know if these localised entropy formulae can substitute to give a different proof of Theorem 1. ")#mi("\\diamond")

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4f80cbb5722abb3492de3f863665f43b8d09e525eda1a8ffd4bda968ea98fe2-748546092a4debe1b2b6fe7773ad1c23571f1f3dfd749e5412f24773326b0ea5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sylvain Maillot")]], [#link("https://terrytao.wordpress.com/2008/05/14/285g-lecture-11-%ce%ba-noncollapsing-via-perelman-reduced-volume/#comment-29849")[#strong[#text("Sylvain Maillot")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2008")])]

#text("Theorem 1 (extending ")#mi("\\kappa")#text("-noncollapsedness forward in time and to")#linebreak()#text(" a larger ball) can be viewed as a simpler version of some results in Section 6 of")#linebreak()#text(" Perelman’s second paper, where Ricci flow with surgery is considered. This material")#linebreak()#text(" is concerned with the long time behavior of Ricci flow with surgery. Hence it is")#linebreak()#text(" crucial in the proof of the geometrization conjecture. For the Poincare conjecture,")#linebreak()#text(" however, it is not necessary, which is probably why Morgan-Tian do not discuss it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/05/14/285g-lecture-11-%ce%ba-noncollapsing-via-perelman-reduced-volume/#comment-29880")[#strong[#text("This past two weeks… « It’s Equal, but It’s Different…")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2008")]

#text("[…] Lecture 10: Variation of L-geodesics, and monotonicity of Perelman reduced volume, 285G, Lecture 11: κ-noncollapsing via Perelman reduced volume, 285G, Lecture 12: High curvature regions of Ricci flow and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2008/05/14/285g-lecture-11-%ce%ba-noncollapsing-via-perelman-reduced-volume/#comment-29886")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2008")])]

#text("For the proof of Lemma 1, you cite the maximum principle (Proposition 1 from Lecture 3), but I don’t think the maximum principle applies directly, since the manifold might not be compact. Is there an easy way to get around this difficulty?")

#text("For example, in proving Proposition 1 you use a maximum principle argument for the reduced length, but I think this is non-problematic since the reduced length is big near infinity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/05/14/285g-lecture-11-%ce%ba-noncollapsing-via-perelman-reduced-volume/#comment-29887")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2008")])]

#text("Dear Sylvain: Thanks very much for the clarification, it all makes sense now.")

#text("Dear Dan: It’s true that the maximum principle I established in Lecture 3 is restricted to the compact case. It turns out that one can extend the maximum principle (in both scalar and tensor forms) to complete manifolds of bounded curvature by a barrier method (basically, one subtracts a small multiple of a smooth weight that grows exponentially at infinity) but it is somewhat technical (see e.g. Chapter 12 of “The Ricci Flow… part II” by Chow et al.). To oversimplify a little, maximum principles continue to hold in this case as long as the solution does not grow super-exponentially fast at infinity.")

#text("It might also be possible to establish the curvature bound by a Gronwall (or ODE comparison) type argument: starting with the heat equation ")#mi("\\partial_t \\text{Riem} = \\Delta \\text{Riem} + O( \\text{Riem}^2 )")#text(" one should be able to obtain an integral inequality of the form ")#tao-math("\\left\\| \\text{Riem}(t) \\right\\|_{L^\\infty} \\leq \\left\\| \\text{Riem}(0) \\right\\|_{L^\\infty} + \\int_0^t O( \\left\\| \\text{Riem}(t^{\\prime}) \\right\\|_{L^\\infty}^2 ) \\ dt^{\\prime}", block: false)#text(" from the ")#mi("L^\\infty")#text("-boundedness of the heat propagator on tensors, and ODE comparison would then do the rest. Of course this is in some sense the maximum principle in disguise, since that is the easiest way to establish the above boundedness property, but if one has another way to get a handle on the heat propagator then one might possibly be able to avoid the maximum principle altogether.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 13: Li-Yau-Hamilton Harnack inequalities and κ-solutions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/14/285g-lecture-11-%ce%ba-noncollapsing-via-perelman-reduced-volume/#comment-29893")[#strong[#text("285G, Lecture 13: Li-Yau-Hamilton Harnack inequalities and κ-solutions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2008")])]

#text("[…] as l. Using the first variation formulae for reduced length (see equations (14), (15) from Lecture 11), as well as the nonnegativity of R (and hence of l), we obtain the useful […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 14: Stationary points of Perelman entropy or reduced volume are gradient shrinking solitons « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/14/285g-lecture-11-%ce%ba-noncollapsing-via-perelman-reduced-volume/#comment-30016")[#strong[#text("285G, Lecture 14: Stationary points of Perelman entropy or reduced volume are gradient shrinking solitons « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2008")])]

#text("[…] with equality, show that the function obeys (6) and that (cf. the computations at the end of Lecture 11). From this and (7), deduce another (formal) proof of (36) whenever the reduced volume is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 15: Geometric limits of Ricci flows, and asymptotic gradient shrinking solitons « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/14/285g-lecture-11-%ce%ba-noncollapsing-via-perelman-reduced-volume/#comment-30096")[#strong[#text("285G, Lecture 15: Geometric limits of Ricci flows, and asymptotic gradient shrinking solitons « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2008")])]

#text("[…] pick an arbitrary point and consider the reduced length function . Recall (see equation (18) from Lecture 11) that we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 17: The structure of κ-solutions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/14/285g-lecture-11-%ce%ba-noncollapsing-via-perelman-reduced-volume/#comment-30202")[#strong[#text("285G, Lecture 17: The structure of κ-solutions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2008")])]

#text("[…] Using monotonicity of reduced volume, we thus have this lower bound for all times. The arguments in Lecture 11 then give -noncollapsing for some other universal […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 19: The structure of Ricci flow at the singular time, surgery, and the Poincaré conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/14/285g-lecture-11-%ce%ba-noncollapsing-via-perelman-reduced-volume/#comment-30245")[#strong[#text("285G, Lecture 19: The structure of Ricci flow at the singular time, surgery, and the Poincaré conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2008")])]

#text("[…] argument that located points of small reduced length for Ricci flows (cf. equation (18) from Lecture 11), would continue to work for Ricci flows with surgery, with the points located being inside the […]")
]
