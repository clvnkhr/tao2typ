// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/09/30/two-quick-updates/
// Converted to Typst by tao2typ: "2026-10-14T15:17:27.353220+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Two quick updates", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Two quick updates")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 September 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/09/30/two-quick-updates/")[#text("https://terrytao.wordpress.com/2009/09/30/two-quick-updates/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#enum(start: 1, 
[#link("https://terrytao.wordpress.com/2009/08/09/what-do-mathematicians-need-to-know-about-blogging/")[#text("In a previous post")]#text(", I noted ")#link("http://golem.ph.utexas.edu/category/2009/08/what_do_mathematicians_need_to.html")[#text("John Baez’s thread")]#text(" discussing his incipient article for the Notices of the AMS, entitled “What do mathematicians need to know about blogging?”. John has now completed an initial draft of his article and is ")#link("http://golem.ph.utexas.edu/category/2009/09/what_do_mathematicians_need_to_1.html")[#text("welcoming comments on it here.")]#text(" [")#emph[#text("Update")]#text(", Oct 2: the ")#link("http://math.ucr.edu/home/baez/mathblogs.pdf")[#text("article has now been submitted")]#text(", incorporating much of the feedback.]")],
[#link("https://terrytao.wordpress.com/2009/05/29/google-wave/")[#text("In another previous post")]#text(", I talked about the forthcoming ")#link("http://wave.google.com/")[#text("Google Wave")]#text(" platform being developed currently by Google, and its potential usefulness for online mathematical collaborative projects, such as the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("polymath projects")]#text(". My brother, who is one of the developers for this project, has just informed me that there are now a limited number of invites available to others who would like to develop specific Wave extensions or other projects (see for instance ")#link("http://blogs.gnome.org/nigeltao/2009/09/30/jump-in-the-waters-fine/")[#text("his own blog post")]#text(", aimed at the GNOME community). As I understand it, the Wave platform is not yet ready for general use, so these invites would be intended for technical developers (or preferably, a group of developers) who would be working on specific projects. (For instance, I understand that there is already a preliminary extension for encoding LaTeX in a Wave, but it could be developed further.) If any readers are interested, one can request an invite directly from the ")#link("http://wave.google.com/")[#text("Google Wave page")]#text(", or I can forward requests to my brother. [At some point, I may ask for help in trying to build a Wave platform for the next generation of Polymath projects, but this will probably not occur for several months yet, due to a large number of other things on my plate (including existing Polymath projects).]")]
)

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/980dd7aef9a6cfc300e501c82cc15624aabf015b7fa44c5821de3f8b8db11f18-5121d618d99abc19cdfdb25c1acfa4ce92d0e0f331d1e9083f2995c2a1f356ba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of range")]], [#link("https://terrytao.wordpress.com/2009/09/30/two-quick-updates/#comment-41646")[#strong[#text("range")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2009")])]

#text("Hi Dr. Tao, I’m a graduate math student and I wouldn’t mind an invite for Google Wave.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2238656de7940377d7f2d425854b905551f9f8f70c2984fc0f37dc1c5a5bef31-3b9a87ff4032e9dd9a10b3d23c289f18fe40eff3ce97a331741f56b1445ff494.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AF")]], [#link("https://terrytao.wordpress.com/2009/09/30/two-quick-updates/#comment-41649")[#strong[#text("AF")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2009")])]

#text("Dr. Tao,")

#text("I am a graduate student in EE and I would really appreciate an invite for Wave.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88dc07d90798fd713b160de8c64b2fdc2969d546791c112a696fae99c8f22baa-44e6e1e13dd479df23d3dcfe117ddd800356254430607b8ee03188dfaa5a677b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philipp")]], [#link("https://terrytao.wordpress.com/2009/09/30/two-quick-updates/#comment-41651")[#strong[#text("Philipp")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2009")])]

#text("Dear Dr. Tao,")

#text("I am a German Ph.D. student and I would love to be invited to google wave to test the latex support.")

#text("If that is somehow possible, thanks in advance!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26949c029d209e90dc7ee7908e858204e6c7898942264637081dad8d256ce7f3-75200ce9a7f0d15e329f1db3bf9fdcba96f3d07556d7919644e912c19bba98f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nigel Tao")]], [#link("https://terrytao.wordpress.com/2009/09/30/two-quick-updates/#comment-41652")[#strong[#text("Nigel Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2009")])]

#text("At this stage, Wave invites would probably be best used by a group of people who already know each other, and have a reason to converse (e.g. all the graduate students at XXX), rather than to diverse individuals. It’s less useful if the only other Waver you know is our fearless frontman, Doctor Wave. On the other hand, Doctor Wave is currently entertaining himself immensely by talking to random strangers on Wave…")

#text("Also, being software developers would be nice to have (and would hopefully be more forgiving of the bugs still in the system (*)), but not essential.")

#text("(*) wave.google.com is still in “preview release” stage. It’s not perfect. We’re working on it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c8d284dd2ddbb40626c126309bc8e8f09a743a2912dbd9b7b72bfd1a29c8e63-fb26f3846087993e4a4209154a6ee4d8b3e21164c0e309de7f1e307e01f6612f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Morrison")]], [#link("https://terrytao.wordpress.com/2009/09/30/two-quick-updates/#comment-41661")[#strong[#text("Scott Morrison")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2009")])]

#text("@Nigel Tao,")

#text("if you’re actually interested in giving invites to all the graduates students at XXX, let me propose the Berkeley maths department! I’m currently a postdoc there, and if something like this could be arranged, I’d happily do a “demo seminar” for anyone interested. This would hopefully start a conversation about using LaTeX in waves, collaborative note-taking, and perhaps even the process of integrating Wave for early exploratory research work with convention LaTeX for “production” work.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/340b02c273c5b762ff2704091fce6f317819b3440b136110b95ea352717e322c-46821a9b29edbf3b5aa0be1b839f1a6b362cca6dae8eb473253ecab327ad0209.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Radu Grigore")]], [#link("https://terrytao.wordpress.com/2009/09/30/two-quick-updates/#comment-41655")[#strong[#text("Radu Grigore")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2009")])]

#text("@Nigel Tao: It sounds like it would make sense to invite the participants in a polymath project… ")#emph[#text("perhaps")]#text(" after there’s some LaTeX support.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ec5f78731edc201d99268e7ee5bebd4048b4ac34c2179a7eaef3942d18742858-f9923df6c91dc1e48da7945d10b89b1991a00ed102e3db0c701993c9edb15aac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt Leifer")]], [#link("https://terrytao.wordpress.com/2009/09/30/two-quick-updates/#comment-41657")[#strong[#text("Matt Leifer")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2009")])]

#text("I hope you realize that you have opened a can of worms by offering the possibility of Wave invites. You can look forward to a large amount of comment spam from people scoping for invites. Speaking of which:")

#text("I have been attempting to get invited to Wave for some time, including in the earlier developer sandbox preview, with no success. My main reason for wanting an invite was to work on LaTeX implementation, so I guess this may not be urgent if someone else is working on it, but I could definitely help with testing and improving the implementation. It would be useful if you could put me in touch with the people developing the Wave LaTeX extension so that I can find out more about what has been done. I am not primarily a software developer, but I do write plugins for web applications in my spare time. My main specialty is getting LaTeX functionality to work (see ")#link("http://mattleifer.info/code/")[#text("http://mattleifer.info/code/")]#text(" for a couple of examples of LaTeX plugins). I am also currently hacking on Andrew Stacey’s PHPLaTeX script (")#link("http://www.math.ntnu.no/~stacey/PHPLaTeX/")[#text("http://www.math.ntnu.no/~stacey/PHPLaTeX/")]#text(") so I am learning a lot about the internals of TeX/LaTeX parsing. Everything I have done so far is written in PHP for portability reasons, but I am also familiar with python and javascript, so I should be able to work with the Wave APIs.")

#text("My email is msleifer [at] the mail service offered by the same company as Wave.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c8d284dd2ddbb40626c126309bc8e8f09a743a2912dbd9b7b72bfd1a29c8e63-fb26f3846087993e4a4209154a6ee4d8b3e21164c0e309de7f1e307e01f6612f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Morrison")]], [#link("https://terrytao.wordpress.com/2009/09/30/two-quick-updates/#comment-41660")[#strong[#text("Scott Morrison")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2009")])]

#text("Just to clarify what just changed at Google Wave: everyone who already had an account at the developer preview (")#link("http://wavesandbox.com")[#text("http://wavesandbox.com")]#text(") has just been given an account over at the real thing (")#link("http://wave.google.com")[#text("http://wave.google.com")]#text("), along with 8 invites to give away.")

#text("I’ve already used up my invites: for (mathematical) collaborators, family, and people who’ve been blogging about Wave and LaTeX but don’t already have accounts.")

#text("I’m enthusiastic about improving LaTeX support in Wave. The current solution seems to be the robot “watexy” to replace text enclosed in $$ with an image rendered by a web service. This works, but it leaves a lot to be desired. The images aren’t as high quality as they might be, they have white (not transparent) background and the baseline doesn’t align well.")

#text("Worst of all, since the original LaTeX is *replaced* by the image, it is intrinsically uneditable! Not very nice. We really need a solution which allows “presentation” and “editing” modes, but it’s not immediately obvious how this can be done in the current Wave stack.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43c6e8a8da64cd8d8330e0a17b568edb712ad8e78efffeac790325f83615fb0a-4dfb49c86896fc83cb3dd6340ed6fef67136274d82d04398453780f35237e326.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jonathanfine")]], [#link("https://terrytao.wordpress.com/2009/09/30/two-quick-updates/#comment-41670")[#strong[#text("jonathanfine")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2009")])]

#text("I’m interested in developing LaTeX support for Google Wave (and other platforms), and would very much appreciate an invite.")

#text("I’m the developer of ")#link("http://www.mathtran.org")[#text("http://www.mathtran.org")]#text(", which runs TeX as a daemon to provide translation of mathematical content as a web service.")

#text("I also played a leading role in organising a workshop on technical aspects of mathematical content, and some of my fellow participants are also interested in this:")#linebreak()#text(" ")#link("http://groups.google.com/group/uk-math-content-2009/web/home")[#text("http://groups.google.com/group/uk-math-content-2009/web/home")]

#text("@Scott: MathTran has solved the problem of editing images, at least in principle. The images served by MathTran are PNGs that contain a ‘custom chunk’ that contains metadata, such as the TeX source. Just open one of these images up in an text editor (gasp) and you’ll see what I mean.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5c7ef2734fbecdfc5bd5cdd836027c85301bb1694ede49822f46e5174176e04c-a48033282d56e7adb7528b397ddd6945136e8ab8ab033316870a98d531b47035.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin")]], [#link("https://terrytao.wordpress.com/2009/09/30/two-quick-updates/#comment-42370")[#strong[#text("Kevin")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2009")])]

#text("Hi.")#linebreak()#text(" I developed a latex robot that renders LaTeX :)")#linebreak()#text(" you can use it adding ")#link("mailto:kevinalle@appspot.com")[#text("kevinalle@appspot.com")]#text(" as a participant to a wave and type latex between $$’s")#linebreak()#text(" (like: ")#tao-fit-display[#mitex("\\sum_{i=0}^n")]#text(")")

#text("there is a longer description here:")#linebreak()#text(" ")#link("http://wave-samples-gallery.appspot.com/about_app?app_id=58014")[#text("http://wave-samples-gallery.appspot.com/about_app?app_id=58014")]

#text("also the source code is available here:")#linebreak()#text(" ")#link("http://code.google.com/p/latexy/")[#text("http://code.google.com/p/latexy/")]

#text("enjoy!")#linebreak()#text(" Kev")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/631b57c510b1e97558c98ce79b699fc120a2a323ae4958ed9424d13c6e5c405c-c26befb15dfbc1f1a6cb15cdddd237e171039be65c91ad3375b11e4835c4912b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/09/30/two-quick-updates/#comment-41678")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2009")])]

#text("It seems like there is already quite a bit of interest for implementing polymath friendly structures in wave. I just set up an email account for people who are interested, polymathwavegroup [at] gmail.com. Now, I would like to stress that this is completely informal and I don’t have a wave invitation. I, myself, am quite interested in working on implementing polymath ideas in wave and I thought it would be great if there were a group of like-minded people.")

#text("Even if we are not part of the initial wave invites, this can serve as a contact list for when wave becomes more widely availabe in the future.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/631b57c510b1e97558c98ce79b699fc120a2a323ae4958ed9424d13c6e5c405c-c26befb15dfbc1f1a6cb15cdddd237e171039be65c91ad3375b11e4835c4912b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/09/30/two-quick-updates/#comment-41680")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2009")])]

#text("Someone suggested that a google group might be a better idea so here’s a ")#link("http://groups.google.com/group/polymath-on-google-wave-group")[#text("link")]#text(" to that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/356dfd03faab1abd6619ce0128bad2e1297ad775e63da2e9f278d95501eff942-9fb23f8bd0da7eb04a2394a9a9f6392bf8bdfe3f996d19cd1c2a50888acd7d06.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Hunt")]], [#link("https://terrytao.wordpress.com/2009/09/30/two-quick-updates/#comment-41816")[#strong[#text("Jonathan Hunt")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2009")])]

#text("Hi,")

#text("Just in case people are interested I have made a Wave gadget for equation editing (it’s very basic at the moment, but I hope it will improve). In addition, I’ve got a bot which replaces text between $$ signs with equation gadgets.")

#text("To use it just at ")#link("mailto:eqybot@appspot.com")[#text("eqybot@appspot.com")]#text(" as a participant to a Wave. Or visit ")#link("https://wave.google.com/wave/#restored:wave:googlewave.com!w%252B4muyQgqQR.3")[#text("https://wave.google.com/wave/#restored:wave:googlewave.com!w%252B4muyQgqQR.3")]#text(" to find the gadget installer.")

#text("You can also learn more at ")#link("http://waveyscience.appspot.com")[#text("http://waveyscience.appspot.com")]#linebreak()#text(" I’m keen to work with other’s on making Wave better for science/maths collaboration.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/99318f1082eedf6ce98c1c518fac63315ba18c377a4f5016c6efd8eacf8d3f0a-d527e8b102b33c361e23040fc2b5fecf0dd4ff3ae268c682954a42d918f40f59.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of joshua vogelstein")]], [#link("https://terrytao.wordpress.com/2009/09/30/two-quick-updates/#comment-41822")[#strong[#text("joshua vogelstein")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2009")])]

#text("i’d love an invite. i work collaboratively on several applied math projects, with people in different institutions, running different OS’s, on different continents. we currently kludge together some collaborative online stuff using emails, ftp sites, and git, which is painfully suboptimal. we have some ideas about how to organize things to work better for our purposes, and some development experience. many thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7f86bdf5423f5e786a1f10f13b649ef1723accc95ab9345320804fbbce91f652-1c6630d56591d34d3dd73d3b2b6928919f34b508a3d3273b32588ec90059141e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pdehaye")]], [#link("https://terrytao.wordpress.com/2009/09/30/two-quick-updates/#comment-421943")[#strong[#text("pdehaye")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2014")])]

#text("Five years later, where are we now?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7f86bdf5423f5e786a1f10f13b649ef1723accc95ab9345320804fbbce91f652-1c6630d56591d34d3dd73d3b2b6928919f34b508a3d3273b32588ec90059141e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pdehaye")]], [#link("https://terrytao.wordpress.com/2009/09/30/two-quick-updates/#comment-421945")[#strong[#text("pdehaye")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2014")])]

#text("Would it be worthwhile revisiting this in the context of MOOCs? This could align incentives for us mathematicians, blending our research and our teaching, if we manage to pull off a hint of citizen science.")
]
