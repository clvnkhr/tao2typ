// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/
// Converted to Typst by tao2typ: "2026-10-14T15:17:50.442151+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A first draft of a non-technical article on universality", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A first draft of a non-technical article on universality")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 September 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/")[#text("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The month of April has been designated as ")#link("http://www.mathaware.org/index.html")[#text("Mathematics Awareness Month")]#text(" by the major American mathematics organisations (the ")#link("http://www.ams.org/home/page")[#text("AMS")]#text(", ")#link("http://www.amstat.org/")[#text("ASA")]#text(", ")#link("http://www.maa.org/")[#text("MAA")]#text(", and ")#link("http://www.siam.org/")[#text("SIAM")]#text("). I was approached to write a popular mathematics article for April 2011 (the theme for that month is “Mathematics and Complexity”). While I have written a fair number of expository articles (including several on this blog) aimed at a mathematical audience, I actually have not had much experience writing articles at the popular mathematics level, and so I found this task to be remarkably difficult. At this level of exposition, one not only needs to explain the facts, but also to tell a story; I have experience in the former but not in the latter.")

#text("I decided to write on the topic of ")#link("http://en.wikipedia.org/wiki/Universality_(dynamical_systems)")[#text("universality")]#text(" – the phenomenon that the macroscopic behaviour of a dynamical system can be largely independent of the precise microscopic structure. Below the fold is a first draft of the article; I would definitely welcome feedback and corrections. It does not yet have any pictures, but I plan to rectify that in the final draft. It also does not have a title, but this will be easy to address later. But perhaps the biggest thing lacking right now is a narrative “hook”; I don’t yet have any good ideas as to how to make the story of universality compelling to a lay audience. Any suggestions in this regard would be particularly appreciated.")

#text("I have not yet decided where I would try to publish this article; in fact, I might just publish it here on this blog (and eventually, in one of the blog book compilations).")

#metadata(none) <tao-81d4d08a66411d23e719>

#text("— Untitled —")

#text("One of the great triumphs of classical mathematics and physics was the ability to predict, with great precision, the future behaviour of simple physical systems. For instance, in Isaac Newton’s ")#emph[#link("http://en.wikipedia.org/wiki/Philosophiae_Naturalis_Principia_Mathematica")[#text("Principia")]]#text(", ")#link("http://en.wikipedia.org/wiki/Newton's_law_of_universal_gravitation")[#text("Newton’s law of universal gravitation")]#text(" was applied to completely describe the behaviour of two bodies under the influence of each other’s gravity, and in particular explaining ")#link("http://en.wikipedia.org/wiki/Kepler's_laws_of_planetary_motion")[#text("Johannes Kepler’s laws of planetary motion")]#text(" as a consequence.")

#text("In contrast, the infamous ")#emph[#link("http://en.wikipedia.org/wiki/Three-body_problem")[#text("three-body problem")]]#text(", in which one seeks to generalise Newton’s analysis of two bodies under the influence of gravitation to a third, remains unsolved to this day despite centuries of efforts by such great mathematicians as Isaac Newton and Henri Poincaré; Newton himself complained that this was the one problem that gave him headaches.")

#text("This is not to say that no progress at all has been made on this problem. We now know rigorously that the three body problem exhibits chaotic behaviour, which helps explain why no exact solution has ever been located; and we are also able to use computers to obtain numerical solutions to this problem with great accuracy and over long periods of time. The ")#link("http://en.wikipedia.org/wiki/Celestial_mechanics")[#text("motion of the planets in the solar system")]#text(", for instance, can be extrapolated a hundred million years into the future or the past.")

#text("If however we increase the complexity of the system further, by steadily increasing the number of ")#emph[#link("http://en.wikipedia.org/wiki/Degrees_of_freedom_(physics_and_chemistry)")[#text("degrees of freedom")]]#text(", the ability to predict the behaviour of the system degrades rapidly. For instance, ")#link("http://en.wikipedia.org/wiki/Weather_prediction")[#text("weather prediction")]#text(" requires one to understand the interaction of a dozen atmospheric variables from thousands of locations throughout the planet, leading to an enormously complicated system that we can barely predict (with only moderate accuracy) a week into the future at best, and that only with the assistance of the latest algorithms and extremely powerful computers.")

#text("Given how complicated life is, it may thus seem that the ability of mathematics to model real-world situations is sharply limited. And this is certainly the case in many contexts; for instance, the ability of mathematical models to predict key economic indicators even just a few months into the future is notoriously poor, and in some cases only marginally better than random chance.")

#text("There is however, a remarkable phenomenon that occurs with some (but not all) complex systems: as the number of degrees of freedom increases, a system can become ")#emph[#text("more")]#text(" predictable and orderly, rather than ")#emph[#text("less")]#text(". Even more remarkable is the phenomenon of ")#emph[#text("universality")]#text(": many complex systems have the same macroscopic behaviour, even if they have very different microscopic dynamics.")

#text("A simple example of this occurs when predicting how voters will act in an election. It is enormously difficult to predict how one, ten, or a hundred voters will cast their vote; but when the electorate is in the millions, one can obtain quite precise predictions by polling just a few thousand of the voters, if done with proper methodology. For instance, just before the 2008 US elections, the statistician ")#link("http://en.wikipedia.org/wiki/Nate_Silver")[#text("Nate Silver")]#text(" used a weighted analysis of all existing polls to correctly predict the outcome of all the US senate races, and of the presidential election in 49 out of 50 states.")

#text("Mathematically, the accuracy of such predictions ultimately derives from two fundamental results in probability theory: the ")#emph[#link("http://en.wikipedia.org/wiki/Law_of_large_numbers")[#text("law of large numbers")]]#text(", and the ")#emph[#link("http://en.wikipedia.org/wiki/Central_limit_theorem")[#text("central limit theorem")]]#text(". Very roughly speaking, the law of large numbers asserts that if one takes a large number of randomly chosen quantities (e.g. the voting preferences of randomly chosen voters), then the average of these quantities (known as the ")#emph[#text("empirical average")]#text(") will usually be quite close to a specific number, namely the ")#emph[#link("http://en.wikipedia.org/wiki/Expected_value")[#text("expectation")]]#text(" of these quantities (which, in this case, would be the mean voting preference of the entire electorate). This is not quite an exact law; there is a small error between the empirical average and the expectation which can fluctuate randomly, but the central limit theorem describes the size and distribution of this random error; roughly speaking, this error is distributed according to the ")#link("http://en.wikipedia.org/wiki/Normal_distribution")[#text("normal distribution")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Gaussian_function")[#text("Gaussian distribution")]#text("), more popularly known as the ")#emph[#link("http://en.wikipedia.org/wiki/Bell_curve")[#text("bell curve")]]#text(".")

#text("The central limit theorem is astonishingly ")#emph[#text("universal")]#text("; whenever a large number of independent random quantities are averaged together to form a single combined quantity, the distribution of that quantity usually follows the bell curve distribution (with the caveat that if the quantities are combined together in a multiplicative manner rather than an additive one, then the bell curve only appears when the quantity is plotted logarithmically). For instance, the heights of human adults (or any other given species) follow a bell curve distribution closely (when plotted logarithmically), as do standardised test scores, velocities of particles in a gas, or the casino’s take from a day’s worth of gambling. This is not because there is any fundamental common mechanism linking height, test performance, atomic velocities, and gambling profits together; from a “low-level” perspective, the factors that go into these quantities behave completely differently from each other. But these quantities are all formed by aggregating together many independent factors (for instance, human height arises from a combination of diet, genetics, environment, health, and childhood development), and it is this high-level structure that gives them all the same universal bell curve distribution.")

#text("The universality of the bell curve allows one to model many complex phenomena, from the noise of electromagnetic interference to the insurance costs of medical diseases, which would otherwise defy any rational analysis; it is of fundamental importance in many practical disciplines, such as engineering, statistics, and finance. It is important to note, however, that there are limits to this universality principle: if the individual factors that are aggregated into a combined quantity are ")#emph[#text("not")]#text(" independent of each other, but are instead highly")#emph[#text(" ")]#emph[#link("http://en.wikipedia.org/wiki/Correlation")[#text("correlated")]]#text(" with each other, then the combined quantity can in fact be distributed in a manner radically different from the bell curve. The financial markets discovered this unfortunate fact recently, most notably with the collateralised debt obligations that aggregated together many mortgages into a single instrument. If the mortgages behaved independently, then it would be inconceivable that a large fraction of them would fail simultaneously; but, as we now know, there was a lot more dependence between them than had previously been believed. A mathematical model is only as strong as the assumptions behind it.")

#text("The central limit theorem is one of the most basic examples of the universality phenomenon in nature, in which the compound quantity being measured is simply an aggregate of the individual components. But there are several other universal laws for complex systems, in which one is performing a more complex operation than mere aggregation. One example of this occurs in the theory of ")#emph[#link("http://en.wikipedia.org/wiki/Percolation")[#text("percolation")]]#text(". This theory models such phenomena as the percolation of water through a porous medium of coffee grounds, the conductance of electricity through nanomaterials, or the extraction of oil through cracks in the earth. In this theory, one starts with a network of connections in a two-dimensional, three-dimensional, or higher-dimensional space (such as a cubic lattice, a square lattice, or a triangular lattice), and then activates some randomly selected fraction of this network. These active connections then organise into complicated-looking fractal shapes known as clusters. If the proportion of connections being activated is low, then the clusters tend to be small and numerous; the water does not percolate through the coffee, the nanomaterial is an insulator, and the oil does not seep out of the earth. At the other extreme, when the proportion is high, then the connections tend to mostly coalesce into one huge cluster; the water percolates freely, the nanomaterial conducts, and the oil seeps through. But the most interesting phenomena happens near the ")#emph[#text("critical")]#text(" density of percolation, in which the clusters are almost, but not quite, threatening to join up into one single giant cluster. When observing such a ")#emph[#link("http://en.wikipedia.org/wiki/Phase_transition")[#text("phase transition")]]#text(", we have found that the size, shape, and distribution of such clusters follow a beautifully fractal, but very specific, law. Furthermore, this law is ")#emph[#text("universal")]#text(": one can start with two different networks (e.g. a square lattice and triangular lattice), and the behaviour of the clusters near the critical density will be virtually identical (provided that certain basic statistics of the problem, such as the dimension of the lattice, are kept constant). Such universality laws have tantalising implications for physics; they suggest that we may not actually need to fully understand the laws of physics at the microscopic level in order to be able to obtain predictions at the macroscopic level, much as the laws of thermodynamics can be derived without necessarily knowing all the subtleties of atomic physics. Unfortunately, the rigorous mathematical understanding of universality for such theories as percolation is still incomplete, despite many recent advances (for instance, very recently a Fields Medal, one of the highest honours in mathematics, was awarded to the Russian mathematician Stas Smirnov, in part for his breakthroughs in the theory of percolation for certain specific networks).")

#text("Another major example of universality, which is also only partially understood at present, arises in understanding the spectra of various large systems. Historically, the first instance of this came with the work of Eugene Wigner in the 1950s on the scattering of neutrons off of large nuclei, such as the Uranium-238 nucleus. Much as the laws of quantum mechanics dictate that an atom only absorbs some frequencies of light and not others, leading to a distinctive colour for each atomic element, the electromagnetic and nuclear forces of a nucleus, when combined with the laws of quantum mechanics, predict that a neutron will pass through a nucleus virtually unimpeded for some energies, but will bounce off that nucleus at other energies, known as ")#emph[#text("scattering resonances")]#text(". One can compute these resonances directly from first principles when dealing with very simple nuclei, such as the hydrogen and helium nuclei, but the internal structure of larger nuclei are so complex that it has not been possible to compute these resonances either theoretically or numerically, leaving experimental data as the only option.")

#text("These resonances have an interesting distribution; they are not independent of each other, but instead seem to obey a precise ")#emph[#text("repulsion")]#text(" law that makes it quite unlikely that two adjacent resonances are too close to each other. In the decades since Wigner’s work, exactly the same governing laws have been found for many systems, both physical and mathematical, that have absolutely nothing to do with neutron scattering, from the arrival times of buses at a bus stop to the zeroes of the Riemann zeta function. The latter example is particularly striking, as it comes from one of the purest subfields of mathematics, namely number theory, and in particular the distribution of the prime numbers. The prime numbers are distributed in an irregular fashion through the integers; but if one performs a spectral analysis on this distribution, one can discern certain long-term oscillations in this distribution (sometimes known as the ")#emph[#text("music of the primes")]#text("), the frequencies of which are described by a sequence of complex numbers known as the (non-trivial) ")#emph[#text("zeroes of the ")]#emph[#link("http://en.wikipedia.org/wiki/Riemann_zeta_function")[#text("Riemann zeta function")]]#text(", which were first studied by Bernhard Riemann. In principle, these numbers tell us everything we would wish to know about the primes. One of the most famous and important problems in number theory is the ")#emph[#link("http://en.wikipedia.org/wiki/Riemann_hypothesis")[#text("Riemann hypothesis")]]#text(", which asserts that these numbers all lie on a single line in the complex plane. It has many consequences in number theory, and in particular gives many important consequences about the prime numbers. However, even the powerful Riemann hypothesis does not settle everything in this subject, in part because it does not directly say much about how the zeroes are distributed on this line. But there is extremely strong numerical evidence that these zeroes obey the same precise law that is observed in neutron scattering and in other systems; in particular, the zeroes seem to “repel” each other in a certain very precise fashion. The formal description of this law is known as the ")#emph[#link("http://en.wikipedia.org/wiki/Gaussian_unitary_ensemble")[#text("Gaussian Unitary Ensemble")]]#emph[#text(" (GUE) hypothesis")]#text(". Like the Riemann hypothesis, it is currently unproven, but it has powerful consequences for the distribution of the prime numbers.")

#text("The fact that the music of the primes, and the energy levels of nuclei, obey the same universal law, is a very surprising fact; legend has it that during a tea at the Institute for Advanced Study, the number theorist Hugh Montgomery had been telling the renowned physicist Freeman Dyson of his remarkable findings into the distribution of the zeroes of the zeta function (or more precisely, a statistic of this distribution known as the ")#emph[#text("pair correlation function")]#text("), only to have Dyson write down this function exactly, based on nothing more than his experience with scattering, and the random matrix models used to make predictions about them. But this does not mean that the primes are somehow nuclear-powered, or that atomic physics is somehow driven by the prime numbers; instead, it is evidence that a single distribution (known as the ")#emph[#text("GUE distribution")]#text(") is so ")#emph[#text("universal")]#text(" that it is the natural end product of any number of different processes, whether it comes from nuclear physics or number theory.")

#text("We still do not have a full explanation of why this particular distribution is so universal. There has however been some recent theoretical progress in this direction. For instance, recent work of Laszlo Erdos, Benjamin Schlein, and Horng-Tzer Yau has shown that the GUE distribution has a strong attraction property: if a system does not initially obey the GUE distribution, then after randomly perturbing the various coefficients of that system in a certain natural manner, the distribution converges quite rapidly in a certain sense to GUE. This can already be used to rigorously demonstrate the presence of the GUE distribution in a number of theoretical randomised models known as ")#emph[#link("http://en.wikipedia.org/wiki/Random_matrix_theory")[#text("random matrix models")]]#text(" (though, sadly, not for the zeroes of the zeta function, as this is a deterministic system rather than a random one). In related recent work of Van Vu and myself, we showed that the spectral distribution of a random matrix model does not change much if one replaces one (or even all) of the components of the system with another component that fluctuates in a comparable manner; this implies that large classes of systems end up having almost the same spectral statistics, which is further evidence towards universality, and can be used to give similar results to that obtained by Erdos, Schlein, and Yau. The study of these random matrix models, and their implications regarding the universality phenomenon, is a highly active current area of research.")

#text("There are however important settings in which we are unable to rely on universality, for instance in fluid mechanics. At microscopic (molecular) scales, one can understand a fluid by modeling the collisions of individual molecues. At macroscopic scales, one can use the universal equations of fluid mechanics (such as the ")#link("http://en.wikipedia.org/wiki/Navier-Stokes_equations")[#emph[#text("Navier-Stokes equations")]]#text("), which reduce all the microscopic structure of the component molecues to a few key macroscopic statistics such as viscosity and compressibility. However, at ")#emph[#link("http://en.wikipedia.org/wiki/Mesoscopic")[#text("mesoscopic")]]#text(" scales that are too large for microscopic analysis to be effective, but too small for macroscopic universality to kick in, our ability to model fluids is still very poor. Examples of important mesoscopic fluids include blood flowing through blood vessels; the blood cells that make up this liquid are so large that they cannot be treated merely as an ensemble of microscopic molecues, but as mesoscopic agents with complex behaviour. Understanding exactly which scenarios admit a universality phenomenon to simplify the analysis, and knowing what to do even in the absence of such phenomena, is a continuing challenge to mathematical modeling today.")

#heading(level: 1)[#text("Comments (51)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phil")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46853")[#strong[#text("Phil")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("The first line of the second paragraph says “in which one seeks generalise”. ")#emph[#text("[Corrected, thanks. – T.]")]#text(" I think the article uses too many mathsy words. Even though you don’t have to understand any of them, a glance at any of the main paragraphs looks a bit intimidating.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9dfd506431bdc82b623f4c4c75df1ca02cac8ffe0b080cdb73b83c6058bb838a-b436cbfacd459fdce34b9ba635d8f458b91eb525ecb76f956d24b02556b5db00.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46859")[#strong[#text("Matt")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("I think the same goes for “chaotic behaviour” (3rd paragraph) and “degrees of freedom” (first appearing 4th paragraph). When people get to a word or phrase they don’t understand it tends to distract them from what comes next, and so they end up missing more than just that word or phrase.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46862")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("In the first place ,sorry to post a poor comment .")

#text("I think,it’s so clear and exiciting and inspiring for even an economics student.")

#text("And also i think, for emphasizing nature’s mystery,")#linebreak()#text(" better to emphasize the statistical laws like a Laws of large numbers")#linebreak()#text(" are not just an artificial theory.")#linebreak()#text(" Because in past, I personaly and falsely believed that such ‘laws’ are")#linebreak()#text(" not a natural process itself and it’s cold, ideal stuff.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e01fd2b173a343b5620ded5db260b00ba040cf7f42bf00846f58f672fcdba872-609170a7e1d6d1b1904f7398483b4810c1aae8cd75836408b04073e6a6804e31.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spencer")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46863")[#strong[#text("Spencer")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("I’m looking forward to reading this later.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/826a2728424b30ad8cc83000d2bfd8744edcd1bafba060e1c70b63281a0934f6-5e3de4a3d5bde314bee2c1b42ac7f851cee463773970099eaeb046cc61a7dd19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of harrison")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46864")[#strong[#text("harrison")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#emph[#text("For instance, just before the 2008 US elections, the statistician Nate Silver used a weighted analysis of all existing polls to correctly predict the outcome of all the US senate races, and of the presidential election in 49 out of 50 states.")]

#text("Minor nitpicking detail: Silver also constructed and used a regression model based on ")#emph[#text("demographic")]#text(" data, which allowed him to outperform other weighted averages of polls — which have existed for some time. (Indeed, the remarkable success of this approach in the Democratic primaries is what brought 538 so much notice to start with!) There’s an interesting sort of psychological phenomenon there, too — many people would likely take offense at the notion that their gender, race, education level, income, age, etc. could be used to predict their ")#emph[#text("individual")]#text(" voting behavior; but at a “macro” scale, such predictions have been empirically shown to work very well (as they should, of course, by the law of large numbers.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of obryant")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46867")[#strong[#text("obryant")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("Just brainstorming: one possible hook may be to begin with a relevant social observation. For example, while it’s nearly impossible to predict who will be murdered, we can predict quite accurately how many people will be murdered this year. Or with marriages, if murder has the wrong subliminal tone.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46869")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("This text is very nice and interesting. I have some tiny suggestions. The definition “known as the critical line” is not used later and could be omitted. ")#emph[#text("[Done – T.]")]#text(" Giving titles to the sections may help the reader grasping the structure of the text. Keep on the good work!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23b8d92961a32c5a056a2caffa8ccefc39a60a809078dceb6b443cfce6f6d23c-6f7ce7c451caec8f71fcc1451a2256ee6c6e6002c8a71cf28df91ea951940d38.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elin")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46870")[#strong[#text("Elin")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("I’m not sure I agree that there are too many ‘mathy’ words. As a non-mathematician I have to say that there were quite a few words I didn’t understand, but this did not detract from the main message of the article. For me it all came together with this sentence: ‘When observing such a phase transition, we have found that the size, shape, and distribution of such clusters follow a beautifully fractal, but very specific, law.’ The fact that not only everything somehow falls into place, but that the law is also beautiful, gave me a proper little thrill. If you can make people feel that thrill that mathematics can give you, you will have done your bit for Math Awareness Month!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60e651d303f654cbe29cc5b1af232502ccbdde7ecec550301541654f6c0787ec-2fa46a5dbec7b82637a9096da1bd730ccb4675997c4681be45cfa9757ca7b84a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valter")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46871")[#strong[#text("valter")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("Fascinating – even for a non-mathematician like me.")

#text("I have only two comments/suggestions:")

#text("1) I suspect you omitted this on purpose, but if you did not, then I would recommend mentioning (with cautions) Zipf’s Law; since it is something that readers of pop math have probably seen before, it may increase their comfort level.")

#text("2) of all the technical terms used, one stood out as in need of definition: spectral. Without a brief explanation, many readers will think of Ghostbusters ;-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/331d038ad95a3eb037ac000002c01f600336c123bc87b189c6a75ab25ae04180-783b5f870be83b77fed6db3652900c76ab2737de4981fcbc14020e557be608d9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Olof")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46872")[#strong[#text("Olof")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("Heights of human adults follow a bell curve distribution closely if you treat one sex at a time only, not if you include human adults of both sexes. ")#emph[#text("[Nice observation, and that would actually dovetail nicely with the later point that universality sometimes breaks down. Will try to incorporate this – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d825238531e6e661a7106b2047d006182569b80262a2c6ab462cf1036dc7c662-635a1a1978fa92b0a5ba474d5fe995d2262040e5aafbe1ada3712d19f865cb11.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kkar")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46981")[#strong[#text("kkar")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2010")])]

#text("This sounds a bit strange to me; it implies that distribution of the height of each sex is normal, but the joint distribution is not.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46983")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2010")])]

#text("Yes, that is more or less correct (the point being that gender is a discrete parameter and so is definitely not normally distributed). See for instance")

#link("http://mindprod.com/jgloss/histogram.html")[#text("http://mindprod.com/jgloss/histogram.html")]

#text("or")

#link("http://www.biostat.jhsph.edu/bstcourse/bio751/papers/bimodalHeight.pdf")[#text("Click to access bimodalHeight.pdf")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of GP")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46874")[#strong[#text("GP")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("Dear Terry,")#linebreak()#text(" great text.")

#text("Here is a suggestion. After the discussion of the CLT, you could maybe describe how universal central limit phenomena hold in a dynamic context, as Brownian motion appears as the limiting object of a large number of random fluctuations.")

#text("The history of Brownian motion (with the pollen, Einstein and everything) is always good for a general public (personal experience). Planar Brownian motion is good for pictures, and makes a nice connection with Smirnov and SLE.")

#text("GP")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8442ab05981b5f2944ef3387ce95faae79fbbcab0252627380eb6bfff76e97bd-386a3fdbcc0a12b60077e9dd23e718db90aed0b2988d3cbcebaf044b057408f5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Coulter")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46875")[#strong[#text("Robert Coulter")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("Do you know of this from the Foundation Series by Asimov?:")

#text("“…Hari Seldon spent his life developing a branch of mathematics known as psychohistory, a concept of mathematical sociology (analogous to mathematical physics) devised by Asimov and his editor John W. Campbell. Using the law of mass action, it can predict the future, but only on a large scale; it is error-prone on a small scale…”")

#text("Quote above from the article at ")#link("http://en.wikipedia.org/wiki/Foundation_series")[#text("http://en.wikipedia.org/wiki/Foundation_series")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e01fd2b173a343b5620ded5db260b00ba040cf7f42bf00846f58f672fcdba872-609170a7e1d6d1b1904f7398483b4810c1aae8cd75836408b04073e6a6804e31.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spencer")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46879")[#strong[#text("Spencer")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("I really like the article. The theme is ambitious, which is great but you definitely get across a sense of the phenomenon. These are my cents:")

#text("To my mind, at the moment, I’d already have to be the kind of person who read (at least) popular books on science and maths to get much out of it, but it’s not really an issue per se. I just know that most of my friends would have trouble with “complex plane”, let alone “deterministic system” or “spectra”. A good portion of them would have trouble with “neutrons” and “function”, despite how basic it is mathematically speaking. So, I am inclined to to agree that it might be a tad terminology-heavy for some readers. I agree with the principle someone has already touched upon in the comments of just not bothering with a proper mathsy name for something unless it crops up again and again in an unavoidable way and there’s no substitute.")

#text("I’d consider introducing the article with a different example. I suspect that to many people, the planetary motion stuff is not impressive and it isn’t obvious why it might be useful etc. The stuff about bell-curves arising when lots of different things are graphed (if accompanied by pictures) or the stuff about CDOs might be a better opener. I might be led to think: Can maths *explain* the ubiquity of this shape or how the mortgage crisis occurred or, could it have *predicted* this shape of graph or predicted the crisis? This might hook me in. Now that I want to know, I am more prepared to read the paragraph on “empirical averages” and “distributions”. In short, I think (Gowers’ favourite pedagogical principle) ‘examples first’, could come in handy, but more down-to-earth than the fact that a 3-body system is chaotic. It *might* also benefit from some essay-style tedium like “First I’ll discuss this…then explain this… then say how this links to this….”")

#text("The general stuff on CLT is riveting. If it is possible to break down the technicality of the Zeta function/atomic resonance stuff a bit then it will be very very cool. Personally, I would even consider removing the percolation section entirely if increasing the clarity of the other sections meant expanding them. The fluids stuff at the end is nice because most people can see that modelling blood flow could be important!")

#text("Very much enjoyed it. I’ll now be looking up GUEs…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46881")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("Thank you all for the valuable feedback, which has given me some perspective I did not previously have on this type of writing. In particular, I work so often with technical mathematical terms that I often forget that they are not familiarly known to lay audiences. I have decided to keep the article in an online format, in which case I can at least give hyperlinks (e.g. to Wikipedia pages) for these terms, though this only partially mitigates the problem. ")#emph[#text("[Update: some hyperlinks added. -T.]")]

#text("It seems clear that a few more cycles of the drafting process will be needed. I will implement minor corrections to the article here, but more major changes will have to wait until the second draft (which I might release back here in a week or two). I suppose it would be instructive to keep all the various drafts online; we mathematicians usually conceal all but the final draft of our work from public view, and perhaps it is good to reveal a bit more of the writing process from time to time.")

#text("It is a cliche that a picture is worth a thousand words, but actually I had not realised until now that much of what I am trying to describe would indeed be much more easily conveyed with the assistance of graphics, in particular putting various real-world distributions side by side to emphasise their universal nature. (Part of the issue here is that in order to be suitable for publication, images cannot simply be grabbed off of a random web page, but need to be either public domain or come with explicit permission from the copyright holder. What I may do here is temporarily use some placeholder images from the web in the drafts, until legally publishable substitutes can be obtained.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b4b839e096870bd0a232e5aa9457125af1c2515d8a27c51f3f43896bbce740b-ab922a9613e39f5f7a45c484e5a137613e8928de1fbfde28f3953381436e9307.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tony Vladusich")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46882")[#strong[#text("Tony Vladusich")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("My first reaction upon reading the article was that the paragraph regarding the accurate prediction of voting behavior would be the ideal hook. My next thought was that this example would form a good contrast with your comments on why economic models failed in the recent debt crisis. You could thus begin with these apparently contradictory observations and then go on to explain why universality obtained in one instance and not the other. I think that progressing from the concrete to the abstract may be a useful way to capture and hold the reader. That said, I enjoyed the read as is!")

#text("“The financial markets discovered this unfortunate fact recently, most notably with the collateralised debt obligations that aggregated together many mortgages into a single instrument.”")

#text("Seems to me you could delete the above sentence and not lose anything (in fact, I think some clarity is afforded).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e3b959399992f110f84d4a3d18b2460fdfe975efed8e8a6d258d19b774811769-c134577090e2f00f9d90c8f12f44f28d7942254c684b4375eee459edc041fd35.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of matheuscmss")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46883")[#strong[#text("matheuscmss")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("Hi Terry!")

#text("Although my suggestion may be difficult to implement in a non-technical article (such as this draft), I think you could touch upon the Feigenbaum phenomena (and renormalization of unimodal maps) as another source of universalty: in fact, this was one of the “leit-motiv” of Avila´s talk at ICM 2010 and I guess it was accessible to the general audience (as I could infer from T. Gowers comments in his blog), so that´s why I´m suggesting it. By the way, another example of universality (with applications to billiards) is the Rauzy-Vecch induction and Teichmüller flow (but this time I agree that this may be hard to explain in few words, i.e., it may be not suited to a short general audience article).")

#text("Best, Matheus")

#text("PS: This is a copy of my comment in your buzz version of this post.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f28d5d37b3a0f3fe81d5f01b1c2d6f3f9f707172720c901de22d46e10af9527c-472c85474a41f9b4626e6c74432d521a2a1f66955a0936ef5b4f9be017e35110.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron Sheldon")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46884")[#strong[#text("Aaron Sheldon")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("Like looking down train tracks to the horizon, universal laws blur the measurable properties of a system by taking the limit to infinity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e63ea5e1b8218e00224ea4064e491a057dff17e7c93e5d999780a667b1087078-3d3f907f8b982b39a3aa7591934ce51e829e6701c5d4eb8f1b99d0b8dd4c075c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel Lacruz")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46887")[#strong[#text("Miguel Lacruz")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("Dear Terry,")

#text("An example of universality that comes to my mind is Benford’s law, and you wrote a nice post about this about one year ago.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29884bbba47c6be14a754803ce5ef4f246acbf49de864658588ee8546cbd08c4-926f96a1e80ba6c336337d531a4bb56248108c322a0061d9db8b005b0901ac97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giampiero Campa")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46888")[#strong[#text("Giampiero Campa")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("Personally, I like it very much the way it is, and i don’t think reorganizing the subjects in a different order, or choosing a different intro, would yield a better final result. The article is for the scientifically inclined anyway, so they can probably relate to Newton, gravitation, and hopefully be intrigued by the fact that having just 3 bodies instead of 2 results in an “unsolved problem”.")

#text("Yes pictures will go a long way in helping the reader to visualize some concepts.")

#text("If i have to be really picky, then i’d say that perhaps more examples on how underlying correlation breaks down the gaussian distributions, and on how *something_else* breaks down the GUE distribution (perhaps an example from physics) could help as well, or at least be informative.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0d8a003af138ca1f68e7d3b582c1280566a5901d3b7cd485861da9a2d6fae7b-8c29d677a7209f96ed5d8d4315a5d18db03fa50b3a504f005c3e12f58e11b3dc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erik")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46889")[#strong[#text("Erik")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("Terry,")

#text("I liked the article ‘as is’. For a hook, maybe you might expand the")#linebreak()#text(" section on mesoscale physics in the last paragraph.")

#text("Here is a link to a (somewhat) recent article on the emergence of")#linebreak()#text(" mesoscale organizing principles that may be helpful to you.")

#link("http://www.pnas.org/content/97/1/32.full.pdf+html")[#text("http://www.pnas.org/content/97/1/32.full.pdf+html")]

#text("By the way, thanks for posting the notes on your real analysis")#linebreak()#text(" course.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4734140d75448931d2959640a0e7d5834d1c1414fc5b39f214d9949a357aad80-0ff663b7a9d5b31683c59ecc76604f878a904846e8af7377c396a77f1191657d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Globule")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46890")[#strong[#text("Globule")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("Minor nit. Referring to someone by their last name only (Wigner) is a bit formal for a popular article. ")#emph[#text("[Fair enough; first names added. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aae63a793e21ba239ceef13e0fa1910aed10576bee1e247cad2d5d5dd2c00745-490845dda6d4ad1ace8df3a57513884fc979f98ad195de04f9284b622da59d55.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J Balachandran")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46897")[#strong[#text("J Balachandran")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2010")])]

#text("Prof. Tao")

#text("You article is really lucid and very well written. However I have a question regarding the Universality. I read about the work of Laszlo Erdos etal where they showed that by randomly perturbing the coefficients it is possible to make it follow GUE. My question is, is it possible to make a system that actually obeys gaussian distribution (voting pattern, height of men) to follow GUE by perturbing the coefficients")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aae63a793e21ba239ceef13e0fa1910aed10576bee1e247cad2d5d5dd2c00745-490845dda6d4ad1ace8df3a57513884fc979f98ad195de04f9284b622da59d55.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J Balachandran")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46898")[#strong[#text("J Balachandran")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2010")])]

#text("I meant i read about the work in the post and not outside. I dont have much idea about probability and statistics")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46905")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2010")])]

#text("The type of statistics (spectra, sets of resonances, sets of zeroes) that the GUE universality phenomenon applies to are quite different from that which the central limit theorem applies to (averages of many independent quantities, or the sum of many small factors). There are connections between the two (versions of the central limit theorem are used in the ")#emph[#text("proof")]#text(" of the theorems of Erdos-Schlein-Yau and Vu and myself), but the results apply to different statistics. I’ll try to emphasise this point more in the next draft (the pictures should help in this regard, as would sectioning the paper).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70d4121c1b1a94d832990865939158fdff7ef16b22a2de4c0a9f58b4e829924e-924c4de11387f3dd841345d05b12a9736ceef58a9bae3acd0b253e5fe35d1675.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maya Incaand")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46900")[#strong[#text("Maya Incaand")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2010")])]

#text("As a more or less “mathy” person, I quite like the article.")

#text("However, I’m inclined to agree with Phil, although you might not think it is “mathy” , a “popular” reader might well read it like that.")

#text("eg when you use the word solve, you mean in the sense of “exact analytic solution” as compared to the computer “solution”.")

#text("Bob (popular reader) – ‘you say first that there is no solution but then you say that it is solved with a computer, so Newton wouldn’t have had a headache if he had a computer??’")

#text("OK I’m exaggerating a bit, but you see what I mean.")

#text("“Very roughly speaking, the law of large numbers asserts that if one takes a large number of randomly chosen quantities (e.g. the voting preferences of randomly chosen voters), then the average of these quantities (known as the empirical average) will usually be quite close to a specific number, namely the expectation of these quantities (which, in this case, would be the mean voting preference of the entire electorate). This is not quite an exact law; there is a small error between the empirical average and the expectation which can fluctuate randomly, but the central limit theorem describes the size and distribution of this random error; roughly speaking, this error is distributed according to the normal distribution (or Gaussian distribution), more popularly known as the bell curve.”")

#text("could read instead something like")

#text("“The law of large numbers and the central limit theorem help pollsters to make more or less accurate predictions for the behaviour of a large group of voters, for example”")

#text("and so on.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46904")[#strong[#text("complex systems « Brosamen")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2010")]

#text("[…] 9, 2010 in generale, math Terry Tao, A first draft of a non-technical article on universality on universality and emergence (though he does not explicitely name the latter). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b1e8475d83caf12bceb425617df8c7688af9dcc631a7b338b2874fda00ccdde-f5efe42d5d6dbdaa2ac522359232afd10c8ca7efe9be970864b65e49d4bfbb5a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeremy")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46911")[#strong[#text("Jeremy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2010")])]

#text("You mention chaos in the first paragraphs about Newtonian gravity, but you don’t really define in any way what this means. Since this is aimed at a popular level, you should give some explanation of what the statement the “problem exhibits chaotic behaviour,” means, and say something about *why* this would be related to not being able to find ‘simple’ solutions.")

#text("The way it’s explained now, I think a lot of people will take away from this the idea: “oh someone just has to write down a clever enough answer and it will solve this problem.” Remember, at a popular level, when you say “solving” they’re thinking of something like solving “3x-1=2” for x, by trial and error, since that’s all they know how to do, and they could imagine this question is something like “243245346346x-32424324324=454523” and you have to be *really clever* to guess that answer, but once you do, you get a number and you’re done. Most people don’t have the more sophisticated understanding that the solution is a machine for putting in, e.g., initial data and getting out a trajectory.")

#text("It would be nice to hear something about measurement uncertainties here, too, since this is important to predicting how a chaotic system evolves. In astronomical cases, measurement uncertainties are the most significant limiting factor in predicting things. This is why, e.g., when you hear the media talking about an asteroid coming near us, they assign a probability to it hitting us, which can change significantly as new data are collected.")

#text("Also, you mention voters, it might also be nice to mention advertisers. Advertising is effective because while we can’t predict what individuals do, we can predict what groups do, which is really the same story as voting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e63ea5e1b8218e00224ea4064e491a057dff17e7c93e5d999780a667b1087078-3d3f907f8b982b39a3aa7591934ce51e829e6701c5d4eb8f1b99d0b8dd4c075c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel Lacruz")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46912")[#strong[#text("Miguel Lacruz")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2010")])]

#text("Dear Terry,")

#text("I wonder if universality has to do at all with the fact that the bell function is an eigenfunction for the Fourier transform.")

#text("All my best,")#linebreak()#text(" Miguel")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46934")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2010")])]

#text("Well, the gaussian is only an eigenfunction for the Fourier transform for a very specific choice of variance; usually the Fourier transform of a gaussian would be another gaussian with a different variance (and also with a phase modulation, if the gaussian was not centred at the origin).")

#text("But the fact that the Fourier transform of a gaussian is an exponential of a quadratic is indeed the key to the standard Fourier-analytic proof of the central limit theorem based on characteristic functions. But there are other proofs of the central limit theorem that avoid explicit use of Fourier analysis. For instance, the fact that the gaussians form a stable law (any linear combination of two independent gaussians is another independent gaussian) is strong heuristic support, at least, for the central limit theorem.")

#text("I discuss a few different proofs of the CLT at")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/")[#text("254A, Notes 2: The central limit theorem")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0fc807063d2ae74ade863c339bc88dc57335e179cc2342e264655fc6559af77b-ef4e6ea7e6a33bd542369eeded2342aa40cfecdc1f77f979b0381a460328acbb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ross")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46913")[#strong[#text("Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2010")])]

#text("a single death is a tragedy, but a")#linebreak()#text(" million deaths was a statistic. thats an example of universality.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cea4482cf8fe82d809a9254f47850640aa446480b6230707a86b17841b1311f-40cd73e53de0394731e6772de7a9b922e0a52a7d938e4d062a67819179414feb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Principle")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46916")[#strong[#text("Principle")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2010")])]

#text("The article is a bit folksy, like Hawking explaining the Universe, and could contain more mathematical details. That way interested high school kids might learn about universality on concrete examples.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75e777514f5b1c071a5889cfc83f2e7d595daba29908aef18a101e2efa86334b-c73ddc684cda3c4ec527fbeb1c3374290457435b3822877034c686dfd541c585.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ionica")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46926")[#strong[#text("Ionica")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2010")])]

#text("Wow, you gave yourself a hard nut to crack! Funny how you get comments saying that the text is too technical for laymen and others saying it is not mathematical enough. This always seems to happen with popular articles.")

#text("I think you should decide for who you’re writing this article. If you aim at an non-mathematical but academic reader, I think this draft is at the right level. However, if you want to write for a more general audience, this text is too formal and hard.")

#text("It would be great if you tried to reach out to a broader audience (especially in Math Awareness Month). I believe splitting the article in a series of shorter columns, each starting with a recognizable real-life-example, would be a good format to reach the more or less average American.")

#text("(By the way, it feels really awkward to advise you, I imagine other commenters asking who I think I am…)")

#text("A general tip: I believe that adding personal experiences works really well in popular writing. And I think it would be nice if you showed more of your personality in the text (which you do on your blog quite often). Marcus du Sautoy is really good at this, he can make readers feel his excitement and frustration about mathematics. My newspaper columns were I tell something personal always yield the most reactions, and not just about the personal stuff, about the mathematics too.")

#text("Good luck, I am curious to see the second draft!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46935")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2010")])]

#text("Hi Ionica! It’s a good point about the intended audience. It would be easier for me to have an article just for mathematically literate readers, but I am thinking of moving outside of my own “comfort zone” and try for a broader audience than what I am accustomed to. (Also, there are a number of surveys of various aspects of universality that are reasonably accessible to such audiences, e.g. this ")#link("http://arxiv.org/abs/arXiv:math-ph/0603038")[#text("survey by Deift")]#text(", focusing on GUE type universality.) It is interesting to see that many of the conventions in popular writing are almost the opposite of those for formal research writing (in which personal anecdotes are discouraged, people are referred to by last name only, the use of standardised technical jargon is preferred, and so forth). So a certain amount of “unlearning” may be needed on my part.")

#text("I will probably keep things in a single article though; I’m not sure there is enough “meat” on the universality story to stretch it out much further than it is now.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9b49775ba440bc299a8e443e66f418549260e4fd191e925caccb59659e2563f-1231ddc5cb6cca924e7ec4976153eeb4571fcc05501cec85cff9092688f1afde.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lefty")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46929")[#strong[#text("Lefty")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2010")])]

#text("I agree it needs more of a narrative, rather than just being a collection of examples, which is how it reads to me at the moment. Either lead the reader through the historical development of the ideas (which I’m not sure is appropriate to the subject chosen) or write a more personal narrative, as suggested by Ionica.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0fc807063d2ae74ade863c339bc88dc57335e179cc2342e264655fc6559af77b-ef4e6ea7e6a33bd542369eeded2342aa40cfecdc1f77f979b0381a460328acbb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ross")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46936")[#strong[#text("Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2010")])]

#text("Maybe hire a childrens author to edit it. Like J.K rowling.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9db883c092a43606496cf6e00698f42a88a4b73073b7642c64186ea784895de-17dded4f7640ff0f836a4b69a43dc91754a0826c437dd010a370f72e2c915663.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of roice")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46938")[#strong[#text("roice")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2010")])]

#text("Thanks for the really nice article.")

#text("A minor bit of feedback relates to the three-body problem, in particular about saying it remains unsolved. After seeing that written a number of times over the years, I was surprised to read the following in the popular mathematics book “An Imaginary Tale: The Story of i”.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("“There are, of course, more than just two distinct masses in the universe. The problem of calculating the motion of N gravitationally interacting masses became known as the N-body problem of celestial mechanics, and the myth has spread among most physicists that it remains unsolved for N>=3. This is true only if one demands closed-form, exact equations. In fact, the Finnish mathematical astronomer Karl F. Sundman (1873-1949) solved the three-body problem during the period 1907-19, and in 1991 a Chinese student, Qiudong Wang, solved the N-body problem for any N. These solutions are in the form of infinite convergent series, however, which unfortunately converge far too slowly to be of any practical use.”")
]

#text("When I read that, I remember feeling a little deceived by what I had seen before :) Perhaps it would be overkill for this article, but I thought I’d bring it up since the info could possibly fit into the paragraph describing progress on the problem.")

#text("Wang’s paper is available online at")

#link("http://adsabs.harvard.edu/abs/1991CeMDA")[#text("http://adsabs.harvard.edu/abs/1991CeMDA")]#text("..50…73W")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d16748755f72f2245cf7d76271ef24bf6211a05587775c0018440e64692942fe-cab85b756ce58d92eeb39033c3652949ff38e82fa28fde4dde4b74c0ef6d2d55.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Furber")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46958")[#strong[#text("Robert Furber")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2010")])]

#text("This has annoyed me too ever since I found out about it. However, there is a meaningful distinction between n=2 and n>= 2, which is the 2 body problem is Liouville integrable. There’s also a less meaninful distinction in that the n body problem’s solution cannot be expressed in terms of a finite expression of polynomials and (complex) exponentials. On the other hand, some might even say that the 2 body problem has no “exact” solution, as it requires the use of transcendental functions to express it in cartesian coordinates.")

#text("What this really underlines is the very inexactitude of what an “exact” solution, or an “exact” formula is.")

#text("I think it’s like if people said that quintics were unsolvable “exactly”, whereas I think in this case most people are aware that they are unsolvable _by radicals_ (if they aren’t the special cases of quintics with solvable Galois group).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46943")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2010")])]

#text("Perhaps a lot of people (well … me at least) would enjoy a linked series of essays on emerging 21st century ideals of mathematical abstraction.")

#text("The first essay might cover ")#emph[#text("“universal” → “universality”")]#text(" … of which this draft is a wonderful start. Similarly, a follow-on essay might cover the evolution of ")#emph[#text("“natural” → “naturality”")]#text(" … discussing the proof technologies needed to analyze the problems of the first essay.")

#text("Then a third essay might cover the evolution of ")#emph[#text("“instances” → “instantiation”")]#text(" … discussing how we systematically represent, via increasingly powerful and general techniques, these natural mathematical ideas in concrete simulation codes, feasible physical experiments, and practical technologies … even in automated theorem-proving (per Petkovsek/Wilf/Zeilberger’s ")#emph[#text("A=B")]#text(" for example).")

#text("A fourth, concluding essay might dovetail these three themes, showing how evolving 21st century ideals of naturality and instantiation act to continually renew our appreciation of universal themes not only in mathematics, but throughout the STEM enterprise.")

#text("The overall (hopeful!) message is that despite the ever-increasing torrent of STEM articles, technologies, and enterprises, the STEM enterprise is *NOT* becoming fragmented … thanks largely to the evolving sophistication of our mathematical notions of universality, naturality, and instantiation.")

#text("This pragmatic & evolving lens of universality-naturality-instantiation is how we systems engineers *already* strive to make sense of the mathematical literature … and also of the emerging cadre of “first-name” mathematics weblogs (Bill, Lance, Scott, Dick, Gil, Terry, Tim, Dave, and others).")

#text("That is why, if Martin Gardner were still writing today, then perhaps this would be one of the themes that he would write about … to everyone’s enjoyment and benefit.")

#text("At any rate, one reader’s appreciation and thanks are extended for writing (what amounts to) the first essay in a “natural” (and wonderful) sequence of mathematical narratives … we all hope for many more such essays.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e63ea5e1b8218e00224ea4064e491a057dff17e7c93e5d999780a667b1087078-3d3f907f8b982b39a3aa7591934ce51e829e6701c5d4eb8f1b99d0b8dd4c075c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel Lacruz")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46952")[#strong[#text("Miguel Lacruz")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2010")])]

#text("Dear Terry,")

#text("Hi again, and speaking of the three bodies, it might be worth to mention Lagrange’s restricted problem, the equilibrium points and so on.")

#text("All my best,")#linebreak()#text(" Miguel")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edd83145ca65974719ae5de0aacb47653d9a23fe23076eb2c270dcba01386de5-aec8eab1a1b8ddfa7cec41e6c848b5f817eaf047215f05f54ffc906b30e47a8e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve Witham")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46974")[#strong[#text("Steve Witham")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2010")])]

#text("“The universality of the bell curve… is of fundamental importance in many practical disciplines, such as engineering, statistics, and finance.”")

#text("Putting statistics in there sounded strange to me. To apply the bell curve to any field ")#emph[#text("is")]#text(" statistics.")

#text("You might want to introduce the law of large numbers by saying that the simplest kind of universality happens when the individual participants aren’t interacting but their independent actions are just being added or averaged together.")

#text("I think “degrees of freedom” is something the reader can get the feel of in context.")

#text("When I hear “spectra,” I’m always looking for colors or frequencies, and don’t connect it to collision-results-by-speed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e63ea5e1b8218e00224ea4064e491a057dff17e7c93e5d999780a667b1087078-3d3f907f8b982b39a3aa7591934ce51e829e6701c5d4eb8f1b99d0b8dd4c075c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel Lacruz")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46989")[#strong[#text("Miguel Lacruz")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2010")])]

#text("Dear Terry,")

#text("I wonder if Condorcet’s paradox is yet another example of universality.")

#link("http://en.wikipedia.org/wiki/Condorcet#Condorcet.27s_paradox")[#text("http://en.wikipedia.org/wiki/Condorcet#Condorcet.27s_paradox")]

#text("All my best,")#linebreak()#text(" Miguel")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A second draft of a non-technical article on universality « What’s new")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-46992")[#strong[#text("A second draft of a non-technical article on universality « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2010")])]

#text("[…] spent the last week or so reworking the first draft of my universality article for Mathematics Awareness Month, in view of the useful comments and feedback received on that draft […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e63ea5e1b8218e00224ea4064e491a057dff17e7c93e5d999780a667b1087078-3d3f907f8b982b39a3aa7591934ce51e829e6701c5d4eb8f1b99d0b8dd4c075c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel Lacruz")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-47031")[#strong[#text("Miguel Lacruz")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#text("Dear Terry,")

#emph[#text("Collective intelligence,")]#text(" like a flock of canadian geese flying in V-shape, or a large group of people working on a polymath project to solve it on the internet.")

#text("Best,")#linebreak()#text(" Miguel")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57744d317aabf2623318a0b93bec2c13a4c686b4cea94c1c7eafa52c7a7eaf31-ee1e69b722b749f580dce786d1e425137d5db5835597cc3689cef46fec32a06e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig Tracy")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-47190")[#strong[#text("Craig Tracy")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2010")])]

#text("Dear Terry,")

#text("Your readers might enjoy reading the experimental paper “Universal fluctuations of growing interfaces: Evidence in turbulent liquid crystals” by Kazumasa Takeuchi & Masaki Sano, Physical Review Letters 104, 230601 (2010). A pdf file of the paper is available at Takeuchi’s homepage:")

#link("http://daisy.phys.s.u-tokyo.ac.jp/student/kazumasa/publication.html")[#text("http://daisy.phys.s.u-tokyo.ac.jp/student/kazumasa/publication.html")]

#text("Craig Tracy")#linebreak()#text(" UC Davis")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c514ac24f83e4b5cff3f5a8f7e69c7739d466a090d3ebc0000c588118688049e-fe4a375bd51d7782ba3def1fd9da15f0083a08a89282e2849f5d6a48a1048243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petequinn")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-50744")[#strong[#text("petequinn")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2011")])]

#text("Is anyone aware of a good overview paper or text, accessible to the generalist, applying fractal geometry to physics? I’m trying to explore the fractal nature of geological materials in relation to their physical behaviour.")

#text("Our basic assumptions in soil and rock mechanics are based on physical models derived from Euclidean assumptions of the spatial distribution of material characteristics. This is an acceptable simplification (else we would not be successful building major earthworks structures), but we tend to make very conservative assumptions to overcome inherent uncertainty and variability in material properties. I have a feeling we can do better with physical models based on a more correct fractal geometry, and am looking for some useful starting points. I’ve gathered a fair range of specialist papers for background review, but haven’t yet come across a good overview that simplifies fractal geometry (and the associated statistics) for physics.")

#text("This post mentions fractals, hence I’ve posed the question here. Thanks for the indulgence.")

#text("Pete")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/526d9e73755bfaacaf8b53a721172fdf5795152b9291d1f1e9853af08202a2ff-96d86605c4365b533345f53ee3eafd3e87323cd8758df04d9be271f849947cd2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Pensaert")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-354668")[#strong[#text("William Pensaert")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2014")])]

#text("We now know rigorously that the three body problem exhibits chaotic behaviour, which helps explain why no exact solution has ever been located;")

#text("Is chaos the true reason that the three-body problem has not been solved exactly?")#linebreak()#text(" Yes, I know,, you don’t make that claim, you only say ‘helps to explain’.")#linebreak()#text(" I could probably come up with many parametrized functions whose behaviour is very sensitve to a change in a parameter; in effect this is one way chaos can be captured in a formula. What would be the real reason then, or, are you suggesting, chaos is but one component of several why no closed-form solution has been found? What then are the other components?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-355187")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2014")])]

#text("To actually show rigorously that no exact solutions exist for a certain set of equations (for some suitable definition of “exact”) is in fact rather difficult; even the basic example of showing the Abel-Ruffini theorem that the general quintic polynomial is not solvable exactly by radicals requires the machinery of Galois theory (or something copmarable to it). (And indeed, to determine whether differential equations can be solved exactly in general requires the analogous tool of ")#link("http://en.wikipedia.org/wiki/Differential_Galois_theory")[#text("differential Galois theory")]#text(".)")

#text("However, chaotic behaviour does rule out many simple classes of solution and is evidence against exact solution, as the trajectories of such solutions tend to be significantly “simpler” than chaotic trajectories. For instance, while you could perhaps cook up an explicit family of functions that are sensitive to the choice of parameter, it would be extremely challenging to come up with such an explicit family that produces trajectories that resemble the ")#link("http://en.wikipedia.org/wiki/Lorenz_system")[#text("Lorenz butterfly")]#text(", which is a typical example of a chaotic orbit.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-693205")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2026")])]

#text("Thanks for this intuitive post! I would like to ask one thing: you mentioned that LLN and CLT only take effect if we select a “large” number of randomly chosen quantities. I checked Wikipedia and it says that in the mathematical world, an infinite sample size is required. Thus, in the real world, how many samples do we need to satisfy the prerequisites for using LLN and CLT?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/07/a-first-draft-of-a-non-technical-article-on-universality/#comment-693208")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2026")])]

#text("I am outsourcing ")#link("https://claude.ai/share/facc088b-66f8-46b8-ba80-df95d6bdeb2b")[#text("this question to an AI")]#text(". I will also add that there are various quantitative refinements of both the LLN and CLT, e.g., the ")#link("https://en.wikipedia.org/wiki/Berry%E2%80%93Esseen_theorem")[#text("Berry–Esseen theorem")]#text(", which can give some theoretical answers to these sorts of questions.")
]
]
