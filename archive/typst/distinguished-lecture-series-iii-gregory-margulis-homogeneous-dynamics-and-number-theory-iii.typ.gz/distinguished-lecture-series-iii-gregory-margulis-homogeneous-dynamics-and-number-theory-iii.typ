// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/01/16/distinguished-lecture-series-iii-gregory-margulis-homogeneous-dynamics-and-number-theory-iii/
// Converted to Typst by tao2typ: "2026-10-14T16:35:31.984814+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Distinguished Lecture Series III: Gregory Margulis, “Homogeneous dynamics and number theory III.”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Distinguished Lecture Series III: Gregory Margulis, “Homogeneous dynamics and number theory III.”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 January 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/01/16/distinguished-lecture-series-iii-gregory-margulis-homogeneous-dynamics-and-number-theory-iii/")[#text("https://terrytao.wordpress.com/2009/01/16/distinguished-lecture-series-iii-gregory-margulis-homogeneous-dynamics-and-number-theory-iii/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In his final lecture, Prof. Margulis talked about some of the ideas around the theory of unipotent flows on homogeneous spaces, culminating in the ")#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/")[#text("orbit closure, equidsitribution, and measure classification theorems of Ratner")]#text(" in the subject. Margulis also discussed the application to metric theory of Diophantine approximation which was not covered in the preceding lecture.")

#metadata(none) <tao-e8562f54446d74212450>

#heading(level: 1)[#text("— Some ingredients in the proofs —")]

#text("Margulis began with some ingredients used in the proofs of the above theorems, either in special cases or in full generality.")

#text("The simplest examples of flows on homogeneous spaces are linear flows ")#mi("u(t) \\in SL_n({\\Bbb R})")#text(" acting on a point x in Euclidean space ")#mi("x \\in {\\Bbb R}^n")#text(". Already when n=2, one sees a sharp distinction between unipotent flows, such as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("u(t) := \\begin{pmatrix} 1 & t \\\\ 0 & 1 \\end{pmatrix}")]]

#text("and non-unipotent flows, such as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("d(t) := \\begin{pmatrix} e^t & 0 \\\\ 0 & e^{-t} \\end{pmatrix}.")]]

#text("Indeed, if x is a typical point close to the origin, then both ")#mi("u(t)")#text(" and ")#mi("d(t)")#text(" will “pull” x away from the origin, but ")#mi("u(t)")#text(", being unipotent (hence polynomial) in nature, will do so in a “slow” and “controlled” manner, whereas ")#mi("d(t)")#text(", being non-unipotent (hence exponential) in nature, will do so in “fast” and “uncontrolled” manner. One can formalise this as follows. If we fix two constants ")#mi("R > r > 0")#text(", and assume ")#tao-math("\\left|x\\right| < r", block: false)#text(", and let ")#mi("T_r")#text(" and ")#mi("T_R")#text(" be the first times t for which ")#tao-math("\\left|u(t) x\\right|", block: false)#text(" exceeds r or R respectively, then in unipotent cases such as (1), ")#mi("T_R-T_r")#text(" will be comparable in magnitude to ")#mi("T_R")#text(" regardless of how close x is initially to the origin, whereas in non-unipotent cases, we expect ")#mi("T_R-T_r")#text(" to be much smaller than ")#mi("T_R")#text(" (indeed, for (2), ")#mi("T_R-T_r = O(1)")#text(" while ")#tao-math("T_R \\sim \\log 1/\\left|x\\right|", block: false)#text(" in general). In other words, when tracking the trajectory of x through the “near” region ")#tao-math("\\left|x\\right| \\leq r", block: false)#text(" and the “intermediate” region ")#tao-math("r < \\left|x\\right| \\leq R", block: false)#text(", in the unipotent case a large fraction of the trajectory is in the intermediate region, whereas in the non-unipotent case the trajectory is mostly in the near region. It turns out that the intermediate region is where all the interesting dynamics occurs, which is why the unipotent case is much better behaved than the non-unipotent case.")

#text("The above discussion compared an orbit ")#mi("u(t) x")#text(" of a linear action with the origin, but one can generalise it in several ways. Firstly, given an action of a (Ad-) unipotent one-parameter subgroup ")#mi("\\{ u(t) \\} \\leq G")#text(" on a homogeneous space ")#mi("G/\\Gamma")#text(", there is a similar phenomenon: if x and y are two very close points in ")#mi("G/\\Gamma")#text(" that differ by some group element g (i.e. ")#mi("y = gx")#text("), then ")#mi("u(t) x")#text(" and ")#mi("u(t) y")#text(" differ by ")#mi("u(t) g u(t)^{-1}")#text(", and the Ad-unipotency will guarantee that when again considering the portion of the trajectory for which ")#mi("u(t) x")#text(" and ")#mi("u(t) y")#text(" are within R of each other, a significant portion of that trajectory will in fact be spent in the “intermediate range” in which the separation between ")#mi("u(t) x")#text(" and ")#mi("u(t) y")#text(" is between r and R.")

#text("For various technical reasons, it is not enough in most applications to study how to nearby points x, y are pulled apart from each other by unipotent flows, but rather how two nearby ")#emph[#text("sets")]#text(" Ax, Ay are pulled apart, where A is some nice subset of G, typically living in some closed subgroup U. For this one needs to analyse the action of the unipotent group on some sort of “transverse space” such as ")#mi("G/U")#text(". There are some technical difficulties here because such quotient spaces are not, in general, affine varieties, and so the unipotent action is no longer polynomial. However, thanks to Chevalley’s theorem, they are still ")#emph[#text("quasi")]#text("-affine varieties (if one takes a “G-equivariant” perspective), and this keeps the unipotent action “rational” at least, which turns out to suffice to get the type of intermediate range behaviour discussed above. [I admit I didn’t fully understand this point.] The strategy is always to reduce matters to the case of linear actions by linearising around one of the sets Ax, Ay, so this technique is often referred to as the “linearisation technique”.")

#text("It is often difficult to apply this technique, but in the special case when the unipotent group U is ")#emph[#text("horospherical")]#text(", which means that there exists a group element g such that ")#mi("\\lim_{n \\to +\\infty} g^n u g^{-n} = 1")#text(" for all u in U, there is an easier method available, called the “banana argument”, which relies of the act of conjugation by ")#mi("g^{-1}")#text(" to stretch out U without stretching out the directions transverse to U to find neighbourhoods of U that remain close to U even after conjugating by ")#mi("g^{-n}")#text(" for large n (the conjugated neighbourhoods resemble a banana in shape, hence the name). (In ")#mi("SL_2({\\Bbb R})")#text(", it turns out that all unipotent groups are horospherical, but this is certainly not the case in general, thus ")#mi("SL_2")#text(" can be a somewhat misleading example.) By combining this argument with the mixing properties of g (which would basically be geodesic flow in the ")#mi("SL_2")#text(" case) one can obtain many special cases of the orbit closure theorem and related results, but they are largely restricted to horospherical settings.")

#text("Another important property of unipotent flows is that of ")#emph[#text("quantitative recurrence to compact sets")]#text(". If ")#mi("\\Gamma")#text(" is a lattice of a connected Lie group G, then ")#mi("G/\\Gamma")#text(" need not be compact (though it must have finite volume); it can (and usually does) contain one or more cusps going off to infinity. For instance, the homogeneous space ")#mi("\\Omega_n := SL_n({\\Bbb R})/SL_n({\\Bbb Z})")#text(" of unimodular lattices has a cusp; a lattice ")#mi("\\Delta")#text(" goes to infinity” when the distance ")#mi("\\delta(\\Delta)")#text(" of the shortest non-zero vector in ")#mi("\\Delta")#text(" goes to zero. However, it turns out that unimodular flows never send lattices off to infinity, which (in principle) allows us to argue “as if” ")#mi("G/\\Gamma")#text(" was compact when considering unipotent flows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Qualitative recurence to compact sets.")]#text(" If ")#mi("\\{u(t)\\} \\in SL_n({\\Bbb R})")#text(" is a unipotent one-parameter group, and ")#mi("\\Delta \\in \\Omega_n")#text(" is a lattice, then ")#mi("u(t) \\Delta")#text(" returns to any given compact subset of ")#mi("\\Omega_n")#text(" for arbitrarily large times ")#mi("t")#text(".")
]

#text("(Of course, this type of claim is totally false in the non-unipotent case, such as for the flow (2).)")

#text("In the n=2 case the claim is easy to prove, and relies on two facts. The first fact (valid in all dimensions) is a controlled growth rate for linear unipotent flows in the intermediate range, or more precisely for every ")#mi("r > 1")#text(" there exists an ")#mi("\\varepsilon > 0")#text(" such that if ")#tao-math("\\left|u(t) v\\right| \\leq \\varepsilon", block: false)#text(" for all ")#tao-math("\\left|t\\right| < T", block: false)#text(" and some vector v, then we have ")#tao-math("\\left|u(t) v\\right| \\leq 1", block: false)#text(" for all ")#tao-math("\\left|t\\right| \\leq rT", block: false)#text(". (This is closely related to the growth properties mentioned at the start of the talk). The second fact is specific to two dimensions, and states the obvious fact that a two-dimensional unimodular lattice cannot contain two linearly independent vectors which are both small (e.g. have magnitude less than 1/2), since otherwise the parallelogram they generate would have too small an area for the lattice to be unimodular.")

#text("For higher dimensions, one can use similar arguments, but one needs to deal with primitive sublattices of ")#mi("\\Delta")#text(" rather than individual vectors; see ")#link("http://www.ams.org/mathscinet-getitem?mr=470140")[#text("this paper of Margulis")]#text(".")

#text("In practice, the qualitative recurrence is not enough (it is not uniform in ")#mi("\\Delta")#text(", also one needs to generalise to other homogeneous spaces) and one needs results such as the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Quantitative recurrence to compact sets. ")]#text(" Let G be a connected Lie group, ")#mi("\\Gamma")#text(" a lattice in G, F be a compact set in ")#mi("G/\\Gamma")#text(", and ")#mi("\\varepsilon > 0")#text(". Then the unipotent orbits ")#mi("u(t) x")#text(" with ")#mi("x \\in F")#text(" “mostly stay in a compact set” in the sense that there is a compact subset K of ")#mi("G/\\Gamma")#text(" such that for any ")#mi("x \\in F")#text(" and ")#mi("T > 0")#text(", and any unipotent one-parameter subgroup ")#mi("\\{u(t)\\}")#text(", one has ")#tao-math("\\left| \\{ t \\in [0,T]: u(t) x \\in K \\}\\right| \\geq (1-\\varepsilon) T", block: false)#text(".")
]

#text("This particular result is essentially due to Dani (see e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=1237827")[#text("this paper")]#text("), and is also related to earlier work of Selberg and Pyatetskii-Shapiro.")

#heading(level: 1)[#text("— Applications to metric theory of Diophantine approximation —")]

#text("Recall that a vector ")#mi("x \\in {\\Bbb R}^n")#text(" is said to be ")#emph[#text("very well approximable")]#text(" (or VWA) by rationals if there exists ")#mi("\\nu > n")#text(" and infinitely many non-zero ")#mi("q \\in {\\Bbb Z}^n")#text(" such that ")#tao-math("\\text{dist}(q \\cdot x, {\\Bbb Z}) < \\left|q\\right|^{-\\nu}", block: false)#text(". There is also the weaker property of being ")#emph[#text("very well multiplicatively approximable")]#text(" (VWMA), in which ")#tao-math("\\left|q\\right|^{-\\nu}", block: false)#text(" is replaced by ")#tao-math("\\prod_{i=1}^n (1+\\left|q_i\\right|)^{-1-\\varepsilon}", block: false)#text(" for some ")#mi("\\varepsilon > 0")#text(", where ")#mi("q_1,\\ldots,q_n")#text(" are the components of q. An easy application of the Borel-Cantelli lemma shows that almost every point in ")#mi("{\\Bbb R}^n")#text(" is not VWA and not VWMA. However, this does not reveal what happens when one places additional constraints on x, such as restriction to a lower-dimensional surface. A typical question is whether almost every point on the curve ")#mi("\\{ (x,x^2,\\ldots,x^n): x \\in {\\Bbb R} \\}")#text(" is VMA or VWMA. This was conjectured by Mahler and stablished ")#link("http://www.ams.org/mathscinet-getitem?mr=245527")[#text("by Sprindzuk")]#text(" by an intricate argument (the Borel-Cantelli argument fails if applied naively, the total measure of all the exceptional sets diverges). Using the theory of homogeneous unipotent flows, Kleinbock and Margulis established a much more general statement: given any non-degenerate sufficiently smooth submanifold of ")#mi("{\\Bbb R}^n")#text(", almost every point on that manifold is not VWMA (and hence also not VMA). (“Non-degenerate” basically means that sufficiently many of the derivatives of the graphing functions have full rank; in the analytic category, it is equivalent to the manifold not being contained in a proper subspace.)")

#text("It turns out that this problem is equivalent to a dynamical problem on ")#mi("\\Omega_{n+1} = SL_{n+1}({\\Bbb R}) / SL_{n+1}({\\Bbb Z})")#text(", involving the unipotent shifts ")#mi("U_{f(x)}")#text(" where")

#align(center)[#tao-fit-display[#mitex("U_{y_1,\\ldots,y_n} := \\begin{pmatrix} 1 & y_1 & \\ldots & y_n \\\\ 0 & 1 & \\ldots & 0 \\\\ 0 & 0 & \\ddots & 0 \\\\ 0 & 0 & \\ldots & 1 \\end{pmatrix}")]]

#text("and f is a graphing function for the manifold of interest. Indeed, a point f(x) is VDMA iff ")#mi("g_t U_{f(x)} {\\Bbb Z}^{n+1}")#text(" only goes off to infinity at a sublinear rate at worst, where ")#mi("t = (t_1,\\ldots,t_n)")#text(" and ")#mi("g_t \\in SL_{n+1}({\\Bbb R})")#text(" is the diagonal matrix with coefficients ")#mi("e^{t_1+\\ldots+t_n}, e^{-t_1},\\ldots,e^{-t_n}")#text(". The quantitative recurrence to compact sets is the main tool used to establish that this occurs for almost every x. Note that this type of argument is entirely concerned with how often an orbit stays in the cusp and is thus more of a “covering” argument than an “equidistribution” argument.")

#heading(level: 1)[#text("— The orbit closure, equidistribution, and measure classification theorems —")]

#text("Finally, Margulis discussed the famous orbit closure, equidistribution, and measure classification theorems for unipotent flows, proven in full generality by Ratner after several partial results by other authors. Here are the three theorems:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Orbit closure theorem.")]#text(" Let H be a connected subgroup of a connected Lie group G generated by Ad-unipotent elements,let ")#mi("\\Gamma")#text(" be a lattice, and let ")#mi("x \\in G/\\Gamma")#text(". Then the orbit closure ")#mi("\\overline{Hx}")#text(" takes the form Lx for some closed connected subgroup L containing H. Furthermore Lx supports an L-invariant measure ")#mi("\\mu_x")#text(" (such measures are known as ")#emph[#text("algebraic measures")]#text(").")

#strong[#text("Equidistribution theorem.")]#text(" Suppose further that ")#mi("H = \\{u(t)\\}")#text(" is a one-parameter Ad-unipotent subgroup, then for any continuous compactly supported ")#mi("f: G/\\Gamma \\to {\\Bbb R}")#text(", we have ")#mi("\\frac{1}{T} \\int_0^T f(u(t) x) \\to \\int_{Lx} f\\ d\\mu_x")#text(" as ")#mi("T \\to \\infty")#text(".")

#strong[#text("Measure classification theorem.")]#text(" Let ")#mi("\\Gamma")#text(" be a discrete subgroup of a connected Lie group G (not necessarily a lattice), and let H be a connected subgroup generated by Ad-unipotents. THen any finite H-ergodic H-invariant measure on ")#mi("G/\\Gamma")#text(" is algebraic.")
]

#text("The orbit closure theorem was first conjectured by Raghunathan in the case when U was itself an Ad-unipotent subgroup; the measure classification theorem was conjectured by Dani in the same setting. These two conjectures in the case when G was reductive and U was maximal horospherical was settled by Dani, while the solvable case of Raghunathan’s conjecture was done by Starkov. The first non-horospherical case (")#mi("SL(3)")#text(", with U consisting of rank 2 perturbations of the identity) of the Raghunathan conjecture was done by Dani and Margulis, and the full statement of all these theorems was done by Ratner.")

#text("The orbit closure theorem follows in a reasonably straightforward fashion from the equidistribution theorem. The equidistribution theorem in turn follows by combining the quantitative recurrence to compact sets with the measure classification argument, together with an additional (relatively easy) argument based on the countability of rational subgroups of G. The basic idea is to linearise the dynamics around a minimal invariant set and exploit the controlled growth of unipotent flows in the transverse direction. A key proposition that encapsulates this idea is as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition.")]#text(" Let G, ")#mi("\\Gamma")#text(", U be as above. Let H be a closed connected subgroup of G which is rational (i.e. ")#mi("H \\cap \\Gamma")#text(" is cocompact in H). Let X be the set of all group elements ")#mi("g \\in G")#text(" such that ")#mi("Ug \\subset gH")#text(". Then ")#mi("X/\\Gamma")#text(" is avoidable in ")#mi("G/\\Gamma")#text(" in the following sense: given any compact set C outside of ")#mi("G/\\Gamma")#text(" and ")#mi("\\varepsilon > 0")#text(", there exists a neighbourhood ")#mi("\\Psi")#text(" of ")#mi("G/\\Gamma")#text(" such that orbits originating from C mostly stay outside ")#mi("\\Psi")#text(", or more precisely we have")

#align(center)[#tao-fit-display[#tao-math("\\left| \\{ t \\in [t_1,t_2]: u(t) x \\in \\Psi \\} \\right| \\leq \\varepsilon (t_2 - t_1)", block: true)]]

#text("for any ")#mi("x \\in C")#text(" and ")#mi("t_1 < 0 < t_2")#text(".")
]

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2413ea49e91edc291d51de27a9f278d355a2db166c2ebed0013fac7b2d1068d7-a123ddfd03e312c5c49d8515de57e643ea0c7f4d36a45e8e3f26c5c595a9bf88.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2009/01/16/distinguished-lecture-series-iii-gregory-margulis-homogeneous-dynamics-and-number-theory-iii/#comment-35046")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2009")])]

#emph[#text("such quotient spaces are not, in general, affine varieties, and so the unipotent action is no longer polynomial. … they are still quasi-affine varieties … [I admit I didn’t fully understand this point.] ")]

#text("I certainly don’t understand the relevance, but at least I can explain the basic example. In the action of SL_2(C) on C^2, there are two orbits, the origin and the rest, and this latter orbit is easily identified with SL_2(C)/U. This space is not affine; if you take an algebraic function on C^2 \\ 0 it will automatically extend over C^2 (Hartogs’ theorem). But it’s an open set in an affine variety, so it’s “quasi-affine”.")

#text("Adding a point to C^2 \\ 0 seems harmless enough; unfortunately the corresponding space for any more interesting Lie group than SL_2 is always singular along the added points.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/16/distinguished-lecture-series-iii-gregory-margulis-homogeneous-dynamics-and-number-theory-iii/#comment-35090")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2009")])]

#text("Thanks Allen, that helped clarify things for me!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steven Heilman")]], [#link("https://terrytao.wordpress.com/2009/01/16/distinguished-lecture-series-iii-gregory-margulis-homogeneous-dynamics-and-number-theory-iii/#comment-35104")[#strong[#text("Steven Heilman")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2009")])]

#text("I believe the Equidistribution theorem is stated incorrectly. We want to let T go to infinity, no? ")#emph[#text("[Oops! Thanks for the correction – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/16/distinguished-lecture-series-iii-gregory-margulis-homogeneous-dynamics-and-number-theory-iii/#comment-56142")[#strong[#text("Conférence internationale Géométrie Ergodique (Orsay 2011) I « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2011")]

#text("[…] above, I strongly recommend reading Terence Tao’s posts on this subject, specially these ones […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/16/distinguished-lecture-series-iii-gregory-margulis-homogeneous-dynamics-and-number-theory-iii/#comment-71374")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2011")])]

#text("Dear Terry,")

#text("I just wanted to let you know that you’ve been using two tags: “Gregory Margulis” and “Grigory Margulis”. So posts tagged with one don’t show up as posted tagged wtih the other.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/16/distinguished-lecture-series-iii-gregory-margulis-homogeneous-dynamics-and-number-theory-iii/#comment-136726")[#strong[#text("Hakan Eliasson’s talk on a problem of Michel Herman « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2012")]

#text("[…] the section “Applications to metric theory of Diophantine approximation” this post here and this article of D. Kleinbock and G. Margulis for a nice introductions to this circle of ideas), […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9dad3d519c58213a4d6042908d48e27ecda195a10db2402ba6e92b12db1f3dd8-bf07935d5f30a431637a719192b12d205c9e7ef35907a6d219f579c70cd7ac2b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Taylor M")]], [#link("https://terrytao.wordpress.com/2009/01/16/distinguished-lecture-series-iii-gregory-margulis-homogeneous-dynamics-and-number-theory-iii/#comment-493247")[#strong[#text("Taylor M")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2018")])]

#text("Hello, and thank you for this nice summary of some very interesting material!")

#text("I realize this post is a bit old now, but I just wanted to point out that the statement of qualitative recurrence to compact sets as stated here is not correct. For any unipotent flow on the space of lattices \\Omega_n, the orbit of almost every lattice will be dense in \\Omega_n, which is not itself compact, so the statement above cannot be true. The qualitative statement of recurrence should instead be that for any compact set K and any lattice in \\Omega_n, the orbit of that lattice under u(t) will return to K for arbitrarily large values of t. The quantitative statement makes this more precise by specifying that in fact a large (depending on K) proportion of the time will be spent inside K. Nonetheless, the orbit of any generic point will contain lattices with arbitrarily short vectors.")

#text("Best,")#linebreak()#text(" Taylor M")

#emph[#text("[Corrected, thanks – T.]")]
]
