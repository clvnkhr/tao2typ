// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/03/18/lewis-lectures/
// Converted to Typst by tao2typ: "2026-10-14T06:57:22.723707+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Lewis lectures", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Lewis lectures")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 March 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/03/18/lewis-lectures/")[#text("https://terrytao.wordpress.com/2008/03/18/lewis-lectures/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("This week I am at ")#link("http://www.math.rutgers.edu/")[#text("Rutgers University")]#text(", giving the ")#link("http://www.math.rutgers.edu/events/lewis.html")[#text("Lewis Memorial Lectures")]#text(" for this year, which are also concurrently part of a ")#link("http://dimacs.rutgers.edu/Workshops/RandomMatrices/")[#text("workshop in random matrices")]#text(". I gave four lectures, three of which were on random matrices, and one of which was on the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(".")

#text("The titles, abstracts, and slides of these talks are as follows.")

#enum(start: 1, 
[#link("https://terrytao.wordpress.com/wp-content/uploads/2008/03/regularity1.pdf")[#text("Szemerédi’s lemma revisited")]#text(". In this general-audience talk, I discuss the Szemerédi regularity lemma (which, roughly speaking, shows that an arbitrary large dense graph can always be viewed as the disjoint union of a bounded number of pseudorandom components), and how it has recently been reinterpreted in a more analytical (and infinitary) language using the theory of graph limits or of exchangeable measures. I also discuss arithmetic analogues of this lemma, including one which (implicitly) underlies ")#link("http://front.math.ucdavis.edu/math.NT/0404188")[#text("my result with Ben Green")]#text(" that the primes contain arbitrarily long arithmetic progressions.")],
[#link("https://terrytao.wordpress.com/wp-content/uploads/2008/03/determinant.pdf")[#text("Singularity and determinant of random matrices")]#text(". Here, I present recent progress in understanding the question of how likely a random matrix (e.g. one whose entries are all +1 or -1 with equal probability) is to be invertible, as well as the related question of how large the determinant should be. The case of continuous matrix ensembles (such as the Gaussian ensemble) is well understood, but the discrete case contains some combinatorial difficulties and took longer to understand properly. In particular I present the results of ")#link("http://www.ams.org/mathscinet-getitem?mr=1260107")[#text("Kahn-Komlós-Szemerédi")]#text(" and later authors showing that discrete random matrices are invertible with exponentially high probability, and also give some results for the distribution of the determinant.")],
[#link("https://terrytao.wordpress.com/wp-content/uploads/2008/03/lsv.pdf")[#text("The least singular value of random matrices")]#text(". A more quantitative version of the question “when is a matrix invertible?” is “what is the least singular value of that matrix”? I present here the recent results of ")#link("http://www.ams.org/mathscinet-getitem?mr=2146352")[#text("Litvak-Pajor-Rudelson-Tomczak-Jaegermann")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2196007")[#text("Rudelson")]#text(", ")#link("http://arxiv.org/abs/math.PR/0511215")[#text("myself ")]#link("http://arxiv.org/abs/math.PR/0703307")[#text("and")]#text(" ")#link("http://arxiv.org/abs/0708.2895")[#text("Vu")]#text(", and ")#link("http://arxiv.org/abs/math/0703503")[#text("Rudelson")]#text("–")#link("http://arxiv.org/abs/0802.3956")[#text("Vershynin")]#text(" on addressing this question in the discrete case. A central role is played by the inverse Littlewood-Offord theorems of additive combinatorics, which give reasonably sharp necessary conditions for a discrete random walk to concentrate in a small ball.")],
[#link("https://terrytao.wordpress.com/wp-content/uploads/2008/03/circular.pdf")[#text("The circular law")]#text(". One interesting application of the above theory is to extend the ")#link("http://mathworld.wolfram.com/GirkosCircularLaw.html")[#text("circular law")]#text(" for the spectrum of random matrices from the continuous case to the discrete case. Previous arguments of Girko and")#link("http://www.ams.org/mathscinet-getitem?mr=1428519")[#text(" Bai")]#text(" for the continuous case can be transplanted to the discrete case, but the key new ingredient needed is a least singular value bound for shifted matrices ")#mi("M-\\lambda I")#text(" in order to avoid the spectrum being overwhelmed by ")#link("http://en.wikipedia.org/wiki/Pseudospectrum")[#text("pseudospectrum")]#text(". It turns out that the results of the preceding lecture are almost precisely what are needed to accomplish this.")]
)

#text("[")#emph[#text("Update")]#text(", Mar 31: first lecture slides corrected. Thanks to Yoshiyasu Ishigami for pointing out a slight inaccuracy in the text.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Random matrices: A general approach for the least singular value problem « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/18/lewis-lectures/#comment-29989")[#strong[#text("Random matrices: A general approach for the least singular value problem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2008")])]

#text("[…] with the entropy bounds in turn originating from inverse Littlewood-Offord theorems; see my Lewis lectures for further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of From the Littlewood-Offord problem to the Circular Law: universality of the spectral distribution of random matrices « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/18/lewis-lectures/#comment-33114")[#strong[#text("From the Littlewood-Offord problem to the Circular Law: universality of the spectral distribution of random matrices « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2008")])]

#text("[…] random matrices with zero mean and unit variance (see my previous blog post on this topic, or my Lewis lectures). We conclude by mentioning a few open problems in the […]")
]
