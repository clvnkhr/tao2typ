// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/06/more-posts/
// Converted to Typst by tao2typ: "2026-11-07T13:20:26.067828+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "More posts", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("More posts")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/06/more-posts/")[#text("https://terrytao.wordpress.com/2026/11/06/more-posts/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-07 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#list(
[#text("Pavel Etingof, ")#link("https://math.mit.edu/~etingof/aiuse.pdf")[#text("“Use of AI in Mathematical Research: A Guide for Young Mathematicians”")]],
[#text("Anna Gilbert, “")#link("https://annagilbert.substack.com/p/math-qua-math")[#text("Math qua math")]#text("“")],
[#text("Anna Gilbert, “")#link("https://annagilbert.substack.com/p/mathematical-criticism")[#text("Mathematical criticism")]#text("“")],
[#text("Larry Guth, “")#link("https://math.mit.edu/math-community/files/whatmathmeanstome.pdf")[#text("What math means to me")]#text("“")],
[#text("Atoosa Kasirzadeh, “")#link("https://www.noemamag.com/a-new-dawn-for-mathematical-progress")[#text("A New Dawn For Mathematical Progress")]#text("“")]
)

#text("As in previous posts, readers are invited to post links to additional articles in the comments.")

#heading(level: 1)[#text("Comments (1)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/11/06/more-posts/#comment-699261")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2026")])]

#text("Very nice docu by ")#strong[#text("Pavel Etingof.")]#text(" Highly recommended, not only for young mathematcians.")
]
