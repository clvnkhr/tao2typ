// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/06/more-posts/
// Converted to Typst by tao2typ: "2026-11-10T15:04:17.856151+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "More posts", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("More posts")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/06/more-posts/")[#text("https://terrytao.wordpress.com/2026/11/06/more-posts/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-10 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#list(
[#text("Pavel Etingof, ")#link("https://math.mit.edu/~etingof/aiuse.pdf")[#text("“Use of AI in Mathematical Research: A Guide for Young Mathematicians”")]],
[#text("Anna Gilbert, “")#link("https://annagilbert.substack.com/p/math-qua-math")[#text("Math qua math")]#text("“")],
[#text("Anna Gilbert, “")#link("https://annagilbert.substack.com/p/mathematical-criticism")[#text("Mathematical criticism")]#text("“")],
[#text("Larry Guth, “")#link("https://math.mit.edu/math-community/files/whatmathmeanstome.pdf")[#text("What math means to me")]#text("“")],
[#text("Atoosa Kasirzadeh, “")#link("https://www.noemamag.com/a-new-dawn-for-mathematical-progress")[#text("A New Dawn For Mathematical Progress")]#text("“")]
)

#text("As in previous posts, readers are invited to post links to additional articles in the comments.")

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/11/06/more-posts/#comment-699261")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2026")])]

#text("Very nice docu by ")#strong[#text("Pavel Etingof.")]#text(" Highly recommended, not only for young mathematcians.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70c1326d3f8e867f4ecf6a48f637c6476c5229e78d03a943402ecac101439c91-ab27c5a5bf3734c5e1b87ac0af3e61d2f9c42b03754455a4b1655f1e83af0c80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John M")]], [#link("https://terrytao.wordpress.com/2026/11/06/more-posts/#comment-699265")[#strong[#text("John M")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2026")])]

#text("i found the distinction Atoosa makes between the checklist and the generative encounter of mathematical progress genuinely interesting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8379cf39f358bc2c951842c74f863890ee29070edbfbb384414888141de5c8f-207c32945f499e96ca5d4595d0f1a6ea8ffd2010a492f995ce0bd43e7e9cfaba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pecunia Non Olet")]], [#link("https://terrytao.wordpress.com/2026/11/06/more-posts/#comment-699268")[#strong[#text("Pecunia Non Olet")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2026")])]

#text("Taking up the invitation: a short essay of mine (in Spanish) starting from the globe-of-knowledge image in the Fridman conversation with Kontorovich, Moitra and Brunton. It leaves aside whether AI stays inside the convex hull and asks the demand side: as producing knowledge gets cheaper, new problems come into view, and with them goods and wants we did not know we had. A demand story, not a rebound story.")#linebreak()#link("https://vespasiano2026.substack.com/p/el-globo-no-necesita-salida")[#text("https://vespasiano2026.substack.com/p/el-globo-no-necesita-salida")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/11/06/more-posts/#comment-699269")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2026")])]

#text("One wish to those who bomb me with “thumbs done”. Please write instead why you do not like my comments. Or are you simply fed up with the situation and look for any target to express your uncomfort?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/06/more-posts/#comment-699283")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2026")])]

#text("It is because we do not know how to use (or not able to use) AI. Seeing comments like yours make us more depressed (or jealous).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b2471604c8902ec9746d53afa441873dadc9012b5022d6ff0bc83852a9993e-b8d80f565218ccfbd08a65971f9e4d3de692f80225ef4b30178db5d2e2c01251.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/06/more-posts/#comment-699301")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2026")])]

#text("Since you ask, my guess is that in this particular case you praised the work of Etingof, who is an Anthropic consultant. People are beginning to understand the industry networks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/06/more-posts/#comment-699302")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2026")])]

#text("One can see this explicitly in the comments following Etingof’s post in P\\&P.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/11/06/more-posts/#comment-699314")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2026")])]

#text("I did not know about his relation. But independently, his comments and proposals for “Math with AI” are well founded.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c00c973dc29f58f9b8ca0a438616f1d34f3e7169889497dba49dba7f39051c1b-4bbaad75a04e3ac86fc61e546021db29fe0a47ba4834942379f914b5d0298e41.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pavel Etingof")]], [#link("https://terrytao.wordpress.com/2026/11/06/more-posts/#comment-699272")[#strong[#text("Pavel Etingof")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2026")])]

#text("I recently also wrote this one: ")#link("https://math.mit.edu/~etingof/profnorms.pdf")[#text("https://math.mit.edu/~etingof/profnorms.pdf")]

#text("Pavel")
]
