// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/
// Converted to Typst by tao2typ: "2026-10-14T10:27:34.810889+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Sweeping a matrix rotates its graph", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Sweeping a matrix rotates its graph")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 October 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/")[#text("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I recently learned about a curious operation on square matrices known as ")#link("https://support.sas.com/documentation/cdl/en/statug/63347/HTML/default/viewer.htm#statug_intromod_a0000000356.htm")[#text("sweeping")]#text(", which is used in numerical linear algebra (particularly in applications to statistics), as a useful and more robust variant of the usual ")#link("https://en.wikipedia.org/wiki/Gaussian_elimination")[#text("Gaussian elimination operations")]#text(" seen in undergraduate linear algebra courses. Given an ")#mi("{n \\times n}")#text(" matrix ")#mi("{A := (a_{ij})_{1 \\leq i,j \\leq n}}")#text(" (with, say, complex entries) and an index ")#mi("{1 \\leq k \\leq n}")#text(", with the entry ")#mi("{a_{kk}}")#text(" non-zero, the ")#emph[#text("sweep")]#text(" ")#mi("{\\text{Sweep}_k[A] = (\\hat a_{ij})_{1 \\leq i,j \\leq n}}")#text(" of ")#mi("{A}")#text(" at ")#mi("{k}")#text(" is the matrix given by the formulae")

#tao-aligned(keep: true)[


#tao-math("\\hat a_{ij}  & := a_{ij} - \\frac{a_{ik} a_{kj}}{a_{kk}}", block: true)



#tao-math("\\hat a_{ik}  & := \\frac{a_{ik}}{a_{kk}}", block: true)



#tao-math("\\hat a_{kj}  & := \\frac{a_{kj}}{a_{kk}}", block: true)



#tao-math("\\hat a_{kk}  & := \\frac{-1}{a_{kk}}", block: true)
]

#text("for all ")#mi("{i,j \\in \\{1,\\dots,n\\} \\backslash \\{k\\}}")#text(". Thus for instance if ")#mi("{k=1}")#text(", and ")#mi("{A}")#text(" is written in block form as ")#metadata(none) <tao-c800092b095a1274b485>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("A = \\begin{pmatrix} a_{11} & X \\\\ Y & B \\end{pmatrix}")]]

#text("for some ")#mi("{1 \\times n-1}")#text(" row vector ")#mi("{X}")#text(", ")#mi("{n-1 \\times 1}")#text(" column vector ")#mi("{Y}")#text(", and ")#mi("{n-1 \\times n-1}")#text(" minor ")#mi("{B}")#text(", one has ")#metadata(none) <tao-cf4ac28ea7ba1492a583>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\text{Sweep}_1[A] = \\begin{pmatrix} -1/a_{11} & X / a_{11} \\\\ Y/a_{11} & B - a_{11}^{-1} YX \\end{pmatrix}.")]]

#text("The inverse sweep operation ")#mi("{\\text{Sweep}_k^{-1}[A] = (\\check a_{ij})_{1 \\leq i,j \\leq n}}")#text(" is given by a nearly identical set of formulae:")

#tao-aligned(keep: true)[


#tao-math("\\check a_{ij}  & := a_{ij} - \\frac{a_{ik} a_{kj}}{a_{kk}}", block: true)



#tao-math("\\check a_{ik}  & := -\\frac{a_{ik}}{a_{kk}}", block: true)



#tao-math("\\check a_{kj}  & := -\\frac{a_{kj}}{a_{kk}}", block: true)



#tao-math("\\check a_{kk}  & := \\frac{-1}{a_{kk}}", block: true)
]

#text("for all ")#mi("{i,j \\in \\{1,\\dots,n\\} \\backslash \\{k\\}}")#text(". One can check that these operations invert each other. Actually, each sweep turns out to have order ")#mi("{4}")#text(", so that ")#mi("{\\text{Sweep}_k^{-1} = \\text{Sweep}_k^3}")#text(": an inverse sweep performs the same operation as three forward sweeps. Sweeps also preserve the space of symmetric matrices (allowing one to cut down computational run time in that case by a factor of two), and behave well with respect to principal minors; a sweep of a principal minor is a principal minor of a sweep, after adjusting indices appropriately.")

#text("Remarkably, the sweep operators all commute with each other: ")#mi("{\\text{Sweep}_k \\text{Sweep}_l = \\text{Sweep}_l \\text{Sweep}_k}")#text(". If ")#mi("{1 \\leq k \\leq n}")#text(" and we perform the first ")#mi("{k}")#text(" sweeps (in any order) to a matrix")

#align(center)[#tao-fit-display[#mitex("A = \\begin{pmatrix} A_{11} & A_{12} \\\\ A_{21} & A_{22} \\end{pmatrix}")]]

#text("with ")#mi("{A_{11}}")#text(" a ")#mi("{k \\times k}")#text(" minor, ")#mi("{A_{12}}")#text(" a ")#mi("{k \\times n-k}")#text(" matrix, ")#mi("{A_{12}}")#text(" a ")#mi("{n-k \\times k}")#text(" matrix, and ")#mi("{A_{22}}")#text(" a ")#mi("{n-k \\times n-k}")#text(" matrix, one obtains the new matrix")

#align(center)[#tao-fit-display[#mitex("\\text{Sweep}_1 \\dots \\text{Sweep}_k[A] = \\begin{pmatrix} -A_{11}^{-1} & A_{11}^{-1} A_{12} \\\\ A_{21} A_{11}^{-1} & A_{22} - A_{21} A_{11}^{-1} A_{12} \\end{pmatrix}.")]]

#text("Note the appearance of the ")#link("https://en.wikipedia.org/wiki/Schur_complement")[#text("Schur complement")]#text(" in the bottom right block. Thus, for instance, one can essentially invert a matrix ")#mi("{A}")#text(" by performing all ")#mi("{n}")#text(" sweeps:")

#align(center)[#tao-fit-display[#mitex("\\text{Sweep}_1 \\dots \\text{Sweep}_n[A] = -A^{-1}.")]]

#text("If a matrix has the form")

#align(center)[#tao-fit-display[#mitex("A = \\begin{pmatrix} B & X \\\\ Y & a \\end{pmatrix}")]]

#text("for a ")#mi("{n-1 \\times n-1}")#text(" minor ")#mi("{B}")#text(", ")#mi("{n-1 \\times 1}")#text(" column vector ")#mi("{X}")#text(", ")#mi("{1 \\times n-1}")#text(" row vector ")#mi("{Y}")#text(", and scalar ")#mi("{a}")#text(", then performing the first ")#mi("{n-1}")#text(" sweeps gives")

#align(center)[#tao-fit-display[#mitex("\\text{Sweep}_1 \\dots \\text{Sweep}_{n-1}[A] = \\begin{pmatrix} -B^{-1} & B^{-1} X \\\\ Y B^{-1} & a - Y B^{-1} X \\end{pmatrix}")]]

#text("and all the components of this matrix are usable for various numerical linear algebra applications in statistics (e.g. in least squares regression). Given that sweeps behave well with inverses, it is perhaps not surprising that sweeps also behave well under determinants: the determinant of ")#mi("{A}")#text(" can be factored as the product of the entry ")#mi("{a_{kk}}")#text(" and the determinant of the ")#mi("{n-1 \\times n-1}")#text(" matrix formed from ")#mi("{\\text{Sweep}_k[A]}")#text(" by removing the ")#mi("{k^{th}}")#text(" row and column. As a consequence, one can compute the determinant of ")#mi("{A}")#text(" fairly efficiently (so long as the sweep operations don’t come close to dividing by zero) by sweeping the matrix for ")#mi("{k=1,\\dots,n}")#text(" in turn, and multiplying together the ")#mi("{kk^{th}}")#text(" entry of the matrix just before the ")#mi("{k^{th}}")#text(" sweep for ")#mi("{k=1,\\dots,n}")#text(" to obtain the determinant.")

#text("It turns out that there is a simple geometric explanation for these seemingly magical properties of the sweep operation. Any ")#mi("{n \\times n}")#text(" matrix ")#mi("{A}")#text(" creates a graph ")#mi("{\\text{Graph}[A] := \\{ (X, AX): X \\in {\\bf R}^n \\}}")#text(" (where we think of ")#mi("{{\\bf R}^n}")#text(" as the space of column vectors). This graph is an ")#mi("{n}")#text("-dimensional subspace of ")#mi("{{\\bf R}^n \\times {\\bf R}^n}")#text(". Conversely, most subspaces of ")#mi("{{\\bf R}^n \\times {\\bf R}^n}")#text(" arises as graphs; there are some that fail the vertical line test, but these are a positive codimension set of counterexamples.")

#text("We use ")#mi("{e_1,\\dots,e_n,f_1,\\dots,f_n}")#text(" to denote the standard basis of ")#mi("{{\\bf R}^n \\times {\\bf R}^n}")#text(", with ")#mi("{e_1,\\dots,e_n}")#text(" the standard basis for the first factor of ")#mi("{{\\bf R}^n}")#text(" and ")#mi("{f_1,\\dots,f_n}")#text(" the standard basis for the second factor. The operation of sweeping the ")#mi("{k^{th}}")#text(" entry then corresponds to a ninety degree rotation ")#mi("{\\text{Rot}_k: {\\bf R}^n \\times {\\bf R}^n \\rightarrow {\\bf R}^n \\times {\\bf R}^n}")#text(" in the ")#mi("{e_k,f_k}")#text(" plane, that sends ")#mi("{f_k}")#text(" to ")#mi("{e_k}")#text(" (and ")#mi("{e_k}")#text(" to ")#mi("{-f_k}")#text("), keeping all other basis vectors fixed: thus we have")

#align(center)[#tao-fit-display[#mitex("\\text{Graph}[ \\text{Sweep}_k[A] ] = \\text{Rot}_k \\text{Graph}[A]")]]

#text("for generic ")#mi("{n \\times n}")#text(" ")#mi("{A}")#text(" (more precisely, those ")#mi("{A}")#text(" with non-vanishing entry ")#mi("{a_{kk}}")#text("). For instance, if ")#mi("{k=1}")#text(" and ")#mi("{A}")#text(" is of the form ")#link(<tao-c800092b095a1274b485>)[#text("(1)")]#text(", then ")#mi("{\\text{Graph}[A]}")#text(" is the set of tuples ")#mi("{(r,R,s,S) \\in {\\bf R} \\times {\\bf R}^{n-1} \\times {\\bf R} \\times {\\bf R}^{n-1}}")#text(" obeying the equations")

#tao-aligned(keep: true)[


#tao-math("a_{11} r + X R  & = s", block: true)



#tao-math("Y r + B R  & = S.", block: true)
]

#text("The image of ")#mi("{(r,R,s,S)}")#text(" under ")#mi("{\\text{Rot}_1}")#text(" is ")#mi("{(s, R, -r, S)}")#text(". Since we can write the above system of equations (for ")#mi("{a_{11} \\neq 0}")#text(") as")

#tao-aligned(keep: true)[


#tao-math("\\frac{-1}{a_{11}} s + \\frac{X}{a_{11}} R  & = -r", block: true)



#tao-math("\\frac{Y}{a_{11}} s + (B - a_{11}^{-1} YX) R  & = S", block: true)
]

#text("we see from ")#link(<tao-cf4ac28ea7ba1492a583>)[#text("(2)")]#text(" that ")#mi("{\\text{Rot}_1 \\text{Graph}[A]}")#text(" is the graph of ")#mi("{\\text{Sweep}_1[A]}")#text(". Thus the sweep operation is a multidimensional generalisation of the high school geometry fact that the line ")#mi("{y = mx}")#text(" in the plane becomes ")#mi("{y = \\frac{-1}{m} x}")#text(" after applying a ninety degree rotation.")

#text("It is then an instructive exercise to use this geometric interpretation of the sweep operator to recover all the remarkable properties about these operations listed above. It is also useful to compare the geometric interpretation of sweeping as rotation of the graph to that of Gaussian elimination, which instead ")#emph[#text("shears")]#text(" and ")#emph[#text("reflects")]#text(" the graph by various elementary transformations (this is what is going on geometrically when one performs Gaussian elimination on an ")#link("https://en.wikipedia.org/wiki/Augmented_matrix")[#text("augmented matrix")]#text("). Rotations are less distorting than shears, so one can see geometrically why sweeping can produce fewer numerical artefacts than Gaussian elimination.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (26)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/744af6de8cc8d5fa42cf0dbd096e88eef82f4b51081b78514bff85bf909eab07-d4d0b110ce3d5330716c189c6d455c2cd768a34ab962b2a8c3755b79505fb788.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of grpaseman")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460244")[#strong[#text("grpaseman")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2015")])]

#text("Interesting! This reminds me of an analogous operation for when a_{11} is 0: multiply the first row by -1, add it to all the other rows, and then multiply the changed columns by -1. For arbitrary matrices this looks like a mess, but I was working with 0-1 matrices and wanted to preserve absolute value of the determinant. I might consider looking at those matrices again from a geometric viewpoint. Thanks for the post.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460245")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2015")])]

#text("may want to add an “expository” tag")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460246")[#strong[#text("A")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2015")])]

#text("YX in (2) instead of XY.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a0a3e1d1499a4217a236dac2e94549e508835f3ace3bada42a58b21884e7224-bb712242a180086639a6da81f08b9e7b0c8ee89c29a90196b4c585e25da4712e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460247")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2015")])]

#text("This seems to be Gauss-Jordan elimination written with 1 table rather than 2 where you re-use the columns of the first table to hold the emerging columns of the 2nd table? That is you eliminate both below and above the main diagonal before you proceed to the next column. Because of this you can re-use the columns of A (or U) to hold the columns of A^{-1}. This also explains why the sweeps commute (zeros in the right place of the columns you have already eliminated).")

#text("In LU factorization terms you are interleaving the elementary factors of L^{-1} with that of U^{-1}. Not sure if my verbal description makes sense to anyone….")

#text("In any case this does not seem to be a good idea numerically without incorporating some form of pivoting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/734b1288d2c5417ed8bcdfe33d2d012c851301be84f5360e28443af6684f5a58-de3739e0fd10b72f9d9d5b99f29d9e29ef4fb5531c177edb6d0732492b75f5a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dr. Seppo")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460262")[#strong[#text("Dr. Seppo")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2015")])]

#text("Sweep seems to be the same as gyration, aside from a sign change. Gyrations have been studied or used in linear programming where dependent and independent variables are swapped, Tucker has been mentioned in that context. The sign change is clever though as it preserves symmetry, so the “new name” sweep is perhaps justified — but you can find old references with the search term “gyration”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09502f7bb48c0b01adc1b28b306bd65036f470f427a8415997f47879399208f8-baa729165b19c14ed925f6dba18255a5b5713777c53150f6b854a343822c530e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kante")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460273")[#strong[#text("kante")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2015")])]

#text("The sweep operation is also known as Principal Pivot Transform, (as far as I know) introduced by Tucker [A Combinatorial Equivalence of Matrices. In R. Bellman and M. Hall Jr editors, Combinatorial Analysis, pages 129–140. AMS, Providence, 1960] (see the survey by Tsatsomeros [M.J. Tsatsomeros. Principal Pivot Transforms: Properties and Applications. Linear Algebra and its Applications 307(1-3):151–165, 2000]). It is funny because it is related to minors in (Delta-)matroids (and so Graph Minor), see for instance [S. Oum. Rank-Width and Well-Quasi-Ordering of Skew-Symmetric or")#linebreak()#text(" Symmetric Matrices. Linear Algebra and its Applications 436(7):2008–2036, 2012.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c935d3e0b69c3fe73a864a2de52513750618e1267ad7f7e5046377635d58c4ca-ae25666e2277e547f496e73140b31709b4b8ce234d70b62cbc1c158f9aea36c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomcircle")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460277")[#strong[#text("tomcircle")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2015")])]

#text("Reblogged this on ")#link("https://tomcircle.wordpress.com/2015/10/08/sweeping-a-matrix-rotates-its-graph/")[#text("Math Online Tom Circle")]#text(" and commented:")#linebreak()#text(" Interesting!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MatjazG")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460279")[#strong[#text("MatjazG")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2015")])]

#text("Very interesting! Didn’t encounter it before but it just so happens that your post comes at a good time, since I think it could be useful for my work. :)")

#text("I have a question, though: would an obvious generalization to a “fractional sweep”: ")#mi("\\text{Sweep}_k^\\alpha[A] = A \\cos \\alpha + \\text{Sweep}_k[A] \\sin \\alpha")#text(" be a useful concept? Geometrically it would correspond to a rotation by an angle ")#mi("\\alpha")#text(" in the ")#mi("\\{e_k,f_k\\}")#text(" plane and hence algebraically to a fractional power ")#mi("\\alpha")#text(" of the unitary (under the canonical scalar product on ")#mi("{\\bf R}^n \\times {\\bf R}^n")#text(" from your post) operator ")#mi("\\text{Sweep}_k")#text(".")

#text("[I ask because for example the other fractional transforms many times turn out to be quite useful. For example, the fractional Fourier transform, which is just a rotation by the angle ")#mi("\\alpha")#text(" of the Wigner quasiprobability function (if I remember correctly) is useful in many areas and also turns out to be the evolution operator for a particle in a linear harmonic oscillator potential in quantum mechanics, where ")#mi("\\alpha")#text(" changes linearly with time.]")

#text("Fractional sweeps would still be commutative ")#mi("\\text{Sweep}_k^\\alpha \\text{Sweep}_l^\\beta = \\text{Sweep}_l^\\beta \\text{Sweep}_k^\\alpha")#text(" and should thus, for example, give a simple algorithmic way to calculate the fractional power ")#mi("-\\alpha")#text(" of a ")#mi("n \\times n")#text(" matrix ")#mi("A")#text(" when applied in succession for all ")#mi("n")#text(" with the same ")#mi("\\alpha")#text(":")

#mi("\\text{Sweep}_1^\\alpha \\dots \\text{Sweep}_n^\\alpha[A] = (-1)^\\alpha A^{-\\alpha}")

#text("if my thinking is correct:")

#text("If ")#mi("\\alpha = \\frac{p}{q}")#text(" is rational then ")#mi("(\\text{Sweep}_1^\\alpha \\dots \\text{Sweep}_n^\\alpha)^q[A] = (\\text{Sweep}_1 \\dots \\text{Sweep}_n)^p[A] = (-A^{-1})^p = (-1)^p A^{-p}")#text(", and thus: ")#mi("\\text{Sweep}_1^\\alpha \\dots \\text{Sweep}_n^\\alpha[A] = (-1)^\\frac{p}{q} A^{-\\frac{p}{q}} = (-1)^\\alpha A^{-\\alpha}")#text(". Since this is a continuous operation in ")#mi("\\alpha")#text(" and rational numbers are dense in the reals the same relation should hold for all ")#mi("\\alpha \\in {\\bf R}")#text(". (Perhaps not completely rigorous, I guess, but I think it should hold.)")

#text("And I’m sure there are other examples where fractional sweeps could be useful.")

#text("P.S. I’m a physicist, not a mathematician, but I’ve been reading your blog for the past two years and it inspires me to learn more things from pure mathematics and also continually gives me fresh ideas for problem solving when dealing with my physical models.")

#text("P.P.S. Also, congratulations on solving the Erdos discrepancy problem! :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460292")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2015")])]

#text("It seems ")#mi("\\text{Sweep}_k^\\alpha")#text(" is a bit more complicated than this; rotation acts linearly on a graph, but not on the function defining the graph. One can see this even in one dimension: a line ")#mi("y = mx")#text(" rotated by ")#mi("\\alpha")#text(" becomes a line with slope ")#mi("\\frac{m+\\tan \\alpha}{1-m \\tan \\alpha}")#text(" (tangent addition rule). The corresponding formula in higher dimensions should be computable but looks a bit messy.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bf23ebe11fcbe0a61f64f59239b469fe4ee5076b883e15afea619b4b55ffb4b-054844e28292f70f825dd0fb4a8a6b451c1cdf5bd9a9f72293281da9ef6261fb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avi Levy")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460293")[#strong[#text("Avi Levy")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2015")])]

#text("Does the formula become simpler if we identify the graph ")#mi("(X, AX)\\subset \\mathbb R^n\\times \\mathbb R^n")#text(" with ")#mi("\\mathbb C^n")#text(", pairing up the real coordinates to produce complex coordinates and think in terms of complex multiplication?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MatjazG")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460295")[#strong[#text("MatjazG")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2015")])]

#text("Thank you your the reply! :) Ah, yes, I see the mistake. I was a bit hasty there; should’ve been more careful … I will try (<- emphasis) to compute the correct formula anyway, as an exercise. :p")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MatjazG")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460296")[#strong[#text("MatjazG")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2015")])]

#text("Not that hard after all, but I see I made another mistake above: to have the notation that ")#mi("\\text{Sweep}_k^1[A] = \\text{Sweep}_k[A]")#text(" a fractional sweep meant as the power ")#mi("\\alpha")#text(" of ")#mi("\\text{Sweep}_k")#text(" corresponds to a rotation by ")#mi("\\phi = \\frac{\\pi \\alpha}{2}")#text(" (not ")#mi("\\alpha")#text(") of the graph in the ")#mi("\\{e_k,f_k\\}")#text(" plane.")

#text("A rotation of the matrix graph ")#mi("\\text{Graph}[A]")#text(" by ")#mi("\\phi")#text(" in the ")#mi("\\{e_1,f_1\\}")#text(" plane means that we send ")#mi("{(r,R,s,S)}")#text(" to ")#mi("{(r^{\\prime},R,s^{\\prime},S)}")#text(", where:")

#mi("r^{\\prime} = \\cos \\phi r + s \\sin \\phi")#text(",")#linebreak()#text(" ")#mi("s^{\\prime} = \\sin \\phi r - s \\cos \\phi")

#text("So we want to express the original equations:")

#mi("a_{11} r + X R = s")#linebreak()#text(" ")#mi("Y r + B R = S")

#text("as equations for ")#mi("s^{\\prime},S")#text(" in terms of ")#mi("r^{\\prime},R")#text(".")

#text("We can do this easily by first:")#linebreak()#text(" – using the orthogonality of rotations to express ")#mi("r,s")#text(" in terms of ")#mi("r^{\\prime},s^{\\prime}")#text(" (of course, the equations look the same as for the other way around, just with ")#mi("-\\phi")#text(" instead of ")#mi("\\phi")#text("),")#linebreak()#text(" – substituting that into both original equations,")#linebreak()#text(" – expressing ")#mi("s^{\\prime}")#text(" from ")#mi("r^{\\prime},R")#text(" by from the first original equation, and finally,")#linebreak()#text(" – putting the expression for ")#mi("s^{\\prime}")#text(" into the second original equation.")

#text("We get:")

#mi("a^{\\prime}_{11} r^{\\prime} + X^{\\prime} R = s^{\\prime}")#linebreak()#text(" ")#mi("Y^{\\prime} r^{\\prime} + B^{\\prime} R = S")

#text("where:")

#mi("a^{\\prime}_{11} = \\frac{a_{11} \\cos \\phi - \\sin \\phi}{\\cos \\phi + a_{11} \\sin \\phi} =  \\frac{a_{11} - \\tan \\phi}{1 + a_{11} \\tan \\phi}")#linebreak()#text(" ")#mi("X^{\\prime} = \\frac{X}{\\cos \\phi + a_{11} \\sin \\phi}")#linebreak()#text(" ")#mi("Y^{\\prime} = (\\cos \\phi - \\sin \\phi \\frac{a_{11} \\cos \\phi - \\sin \\phi}{\\cos \\phi + a_{11} \\sin \\phi}) Y = (\\cos \\phi - \\sin \\phi a^{\\prime}_{11}) Y")#linebreak()#text(" ")#mi("B^{\\prime} = B - \\frac{\\sin \\phi}{\\cos \\phi + a_{11} \\sin \\phi} Y X = B - \\sin \\phi Y X^{\\prime}")

#text("which together form the matrix ")#mi("\\text{Sweep}_1^\\alpha[A]")#text(" (where ")#mi("\\alpha = \\frac{2 \\phi}{\\pi}")#text(").")

#text("Explicitly:")

#mi("A = \\begin{pmatrix} a_{11} & X \\\\ Y & B \\end{pmatrix}")#linebreak()#text(" ")#mi("A^{\\prime} = \\text{Sweep}^\\alpha_1[A] = \\begin{pmatrix} a^{\\prime}_{11} & X^{\\prime} \\\\ Y^{\\prime} & B^{\\prime} \\end{pmatrix}")

#text("and analogously for ")#mi("\\text{Sweep}_k^\\alpha")#text(" for other ")#mi("k")#text(" (just switch the order of the basis or apply permutation matrices around this). :)")

#text("Here ")#mi("A, A^{\\prime}")#text(" are ")#mi("n \\times n")#text(" matrices, ")#mi("B, B^{\\prime}")#text(" are ")#mi("n - 1 \\times n - 1")#text(" matrices, ")#mi("X, X^{\\prime}")#text(" are ")#mi("1 \\times n - 1")#text(" row vectors ")#mi("Y, Y^{\\prime}, R, R^{\\prime}")#text(" are $n – 1 \\times 1$ column vectors and ")#mi("a_{11}, a^{\\prime}_{11}, r, r^{\\prime}, s, s^{\\prime}")#text(" are scalars.")

#text("Let’s do a sanity check: verifying the limit ")#mi("\\alpha = \\phi = 0")#text(" we get the expected identity transformation ")#mi("A^{\\prime} = \\text{Sweep}^0_1[A] = A")#text(" and verifying the limit ")#mi("\\alpha = 1")#text(" (")#mi("\\phi = \\frac{\\pi}{2}")#text(") we get the normal sweep ")#mi("A^{\\prime} = \\text{Sweep}^1_1[A] = \\text{Sweep}_1[A]")#text(".")

#text("The condition ")#mi("a_{11} \\neq -\\cot \\phi")#text(" (unless ")#mi("\\alpha \\in 2{\\bf Z}")#text("), also passes the sanity check for ")#mi("\\alpha = 0")#text(" (no restriction on ")#mi("a_{11}")#text(") and ")#mi("\\alpha = 1")#text(" (the condition ")#mi("a_{11} \\neq 0")#text("), of course. :)")

#text("Of course, ")#mi("\\text{Sweep}_1^\\alpha")#text(" only works when ")#mi("a_{11} \\neq -\\cot \\phi")#text(", since otherwise we get zero denominators, necessarily giving an undefined (at least) ")#mi("X^{\\prime}")#text(" (unless ")#mi("\\alpha \\in 2{\\bf Z}")#text(").")

#text("The equations for a fractional sweep ")#mi("\\text{Sweep}_k^\\alpha")#text(" might look a bit messy, but still not that much. They are basically almost as easy to implement on a computer as those for regular sweeps, and for many consecutive sweeps with the same ")#mi("\\alpha")#text(" you basically need only a few more additions and multiplications per sweep to get the end result, since you can pre-compute ")#mi("\\cos \\phi")#text(" and ")#mi("\\sin \\phi")#text(" only once, at the beginning of the computation.")

#text("For example, if you want to compute a fractional power of a matrix ")#mi("A^\\alpha")#text(" as ")#mi("A^\\alpha = \\text{Sweep}_1^{-\\alpha} \\dots \\text{Sweep}_n^{-\\alpha}[-A]")#text(", as mentioned in my previous post, you can use this algorithm as an in-place computation, without the need for e.g. an eigenvalue decomposition. (My first guess to compute ")#mi("A^\\alpha")#text(" would be to compute the eigenvalues, put them to some power and then recompose the matrix; with fractional sweeps this is unnecessary – but perhaps there is an even better way?)")

#text("I hope someone finds this useful. Anyway, it was nice thinking about this. :) I just hope I haven’t made any more mistakes … :p")

#text("P.S.")#linebreak()#text(" While writing this I noticed a mistake in your original blog post: in the last equation that has its own line (expressing ")#mi("S")#text(" after ")#mi("\\text{Sweep}_1[A]")#text(") there is an ")#mi("X Y")#text(" term (which is scalar), which should instead by ")#mi("Y X")#text(" (matrix/tensor).")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MatjazG")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460308")[#strong[#text("MatjazG")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2015")])]

#text("P.S. Never mind about calculating ")#mi("A^\\alpha")#text(" by fractional sweeps. Fractional sweeps (of course) don’t produce that as a result. :(")#linebreak()#text(" P.P.S. I’m also sorry for spamming the comments so much in the last day.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460309")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2015")])]

#text("Which ")#mi("\\alpha")#text(" values have the above commutative property (independent of the matrix graph!) for all their corresponding sweep operators?")#linebreak()#text(" It seems that this (smallest) set of ")#mi("\\alpha")#text(" values can be larger for certain symmetries of the matrix graph.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MatjazG")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460317")[#strong[#text("MatjazG")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2015")])]

#text("Commutativity should hold for all ")#mi("1 \\leq k, l \\leq n")#text(" and all ")#mi("\\alpha, \\beta")#text(" in the sense that ")#mi("\\text{Sweep}_k^\\alpha \\text{Sweep}_l^\\beta = \\text{Sweep}_l^\\beta \\text{Sweep}_k^\\alpha")#text(".")

#text("This is because the only thing that ")#mi("\\text{Sweep}_k^\\alpha")#text(" does is that it rotates the graph of an arbitrary matrix in the ")#mi("\\{e_k,f_k\\}")#text(" plane by an angle ")#mi("\\phi = \\frac{\\pi}{2} \\alpha")#text(", leaving the rest of the matrix graph (i.e. all other planes ")#mi("\\{e_{k^{\\prime}},f_{k^{\\prime}}\\}")#text(" for ")#mi("k \\neq k^{\\prime}")#text(") completely unchanged.")

#text("So we have two cases to check: either ")#mi("k \\neq l")#text(" and we have proven commutativity by the fact that they operate on different planes independently, or ")#mi("k = l")#text(" and then commutativity holds since rotations in a single plane are always commutative (i.e. the group ")#mi("SO(2)")#text(" is commutative).")

#text("P.S.")#linebreak()#text(" If I am posting yet another comment, let me just throw these more elegant (but equivalent) expressions for the fractional sweep ")#mi("\\text{Sweep}_1^\\alpha")#text(" in here, restoring a bit of symmetry and simplicity:")

#mi("a^{\\prime}_{11} = f (a_{11} \\cos \\phi - \\sin \\phi)")#linebreak()#text(" ")#mi("X^{\\prime} = f X")#linebreak()#text(" ")#mi("Y^{\\prime} = f Y")#linebreak()#text(" ")#mi("B^{\\prime} = B - f \\sin \\phi Y X")

#text("where ")#mi("f = \\frac{1}{a_{11} \\sin \\phi + \\cos \\phi}")#text(".")

#text("Let me also add that I’ve checked these formulas, so that when you applying a fractional sweep first with ")#mi("\\alpha")#text(" and then do another one with ")#mi("\\beta")#text(" after it, that the result is indeed the same as doing a single fractional sweep with ")#mi("\\alpha + \\beta")#text(" (I checked the general case with Mathematica and separately by hand for general ")#mi("\\alpha = \\beta")#text(" and also for ")#mi("\\alpha = \\beta = \\frac{1}{2}")#text("). In other words, I did the sanity check that: ")#mi("\\text{Sweep}_1^\\alpha")#text("latex \\hbox{Sweep}_1^\\beta = \\hbox{Sweep}_1^{\\alpha+\\beta}$, which also proves commutativity when ")#mi("k = l")#text(".")

#text("So the above expressions for a fractional sweep should really be correct now! :)")

#text("P.P.S.")#linebreak()#text(" A note about commutativity:")

#text("We could always conceive of more contrived generalized operations which do not commute, like for example a “fractional multi-sweep”: ")#mi("\\text{Sweep}_k^\\alpha[F]")#text(", where ")#mi("F: {\\bf R^n} \\times \\dots \\times {\\bf R^n} \\rightarrow {\\bf R^n}")#text(" is now a multi-linear map with ")#mi("m")#text(" input vectors from ")#mi("{\\bf R^n}")#text(" and one output vector in ")#mi("{\\bf R^n}")#text(", and where ")#mi("\\alpha")#text(" is a vector with ")#mi("\\frac{m(m+1)}{2}")#text(" components. A fractional mult-sweep would act on the graph ")#mi("{\\text{Graph}[F] := \\{ (X_1, \\dots, X_m, F(X_1, \\dots, X_m)): X_1, \\dots X_m \\in {\\bf R}^n \\}} \\subset {\\bf R}^{(m+1)n}")#text(" of the multi-linear map ")#mi("F")#text(", with canonical basis vectors ")#mi("{e_1^1,\\dots,e_n^1, \\dots, e_1^m,\\dots,e_n^m,f_1,\\dots,f_n}")#text(", by rotating it in the ")#mi("\\{e_k^1,\\dots,e_k^m,f_k\\}")#text(" subspace with a rotation from the group ")#mi("SO(m+1)")#text(" described by the vector ")#mi("\\alpha")#text(". (The vector ")#mi("\\alpha")#text(" has the same number components as there are independent generators of ")#mi("SO(m+1)")#text(" so we have precisely the correct number of degrees of freedom to describe rotations in the the ")#mi("m+1")#text(" dimensional subspace spanned by ")#mi("\\{e_k^1,\\dots,e_k^m,f_k\\}")#text(".) The regular fractional sweep is just the special case when ")#mi("m = 1")#text(".")

#text("Now, fractional multi-sweeps also commute when ")#mi("k \\neq l")#text(" (i.e. it still holds that ")#mi("\\text{Sweep}_k^\\alpha \\text{Sweep}_l^\\beta = \\text{Sweep}_l^\\beta \\text{Sweep}_k^\\alpha")#text(" in that case) since subspaces for different ")#mi("k, l")#text(" are independent, but when ")#mi("k = l")#text(" they in general do not commute any more for arbitrary ")#mi("\\alpha, \\beta \\in {\\bf R}^\\frac{m(m+1)}{2}")#text(", since the group ")#mi("SO(m+1)")#text(" is non-abelian for ")#mi("m \\geq 2")#text(". Whether or not “fractional multi-sweeps” would be useful for anything though, I have no idea (I don’t know that even about regular fractional sweeps now :p).")

#text("P.P.P.S.")#linebreak()#text(" Generalizing further in another direction: the fractional Fourier transformation is a special case of a linear canonical transformation (LCT; also known as the Collins diffraction integral when used to describe light beam propagation through linear elements in paraxial optics) which is a general linear transformation in the time-frequency domain of a function (for example, a fractional Fourier transform with the fraction ")#mi("\\alpha")#text(" is a rotation by an angle ")#mi("\\phi = \\frac{\\pi}{2} \\alpha")#text(" in the time-frequency domain).")

#text("Analogously, would it then be interesting to consider what happens to the matrix ")#mi("A")#text(" when we apply a more general linear transformation to its graph ")#mi("\\text{Graph}[A]")#text(" (either restricted to a ")#mi("\\{e_k,f_k\\}")#text(" plane or not)?")

#text("Anyway, you can always generalize almost anything, but it would be good if it could be used for something non-trivial at some point … :p")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MatjazG")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460322")[#strong[#text("MatjazG")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2015")])]

#text("I just can’t seem to leave this topic alone, it just fascinates me too much. :p What I’m worried about, though, is if I am derailing the discussion under this post too much. Would it be better to move/post all of this somewhere else instead, so it doesn’t take up so much space on this blog? If that would be better, I will write these things down somewhere else; I just feel the urge to write down my findings somewhere … :p Also, any input is greatly appreciated.")

#text("—")

#text("So, I have obtained the general formula for what happens to an ")#mi("n \\times n")#text(" matrix ")#mi("A")#text(" when we apply a linear transformation on its graph ")#mi("\\text{Graph}[A]")#text(" in the ")#mi("\\{e_k,f_k\\}")#text(" plane, leaving the rest of the graph unmodified. Specifically, lets take ")#mi("k = 1")#text(" and express the coordinates ")#mi("{(r^{\\prime},R,s^{\\prime},S)}")#text(" after a linear transformation transformation ")#mi("M")#text(" in the ")#mi("\\{e_1,f_1\\}")#text(" plane as:")

#mi("\\begin{pmatrix} r^{\\prime} \\\\ s^{\\prime} \\end{pmatrix} = M \\begin{pmatrix} r \\\\ s \\end{pmatrix}")

#text("where ")#mi("M = \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}")#text(" is a ")#mi("2 \\times 2")#text(" matrix, ")#mi("a, b, c, d, r, r^{\\prime}, s, s^{\\prime}")#text(" are scalars and ")#mi("R, S")#text(" are ")#mi("n-1 \\times 1")#text(" column vectors.")

#text("Then we want the following:")

#mi("A \\begin{pmatrix} r \\\\ R \\end{pmatrix} = \\begin{pmatrix} s \\\\ S \\end{pmatrix}")

#text("where ")#mi("A = \\begin{pmatrix} a_{11} & X \\\\ Y & B \\end{pmatrix}")#text(", to be equivalent to:")

#mi("A^{\\prime} \\begin{pmatrix} r^{\\prime} \\\\ R \\end{pmatrix} = \\begin{pmatrix} s^{\\prime} \\\\ S \\end{pmatrix}")

#text("where ")#mi("A^{\\prime} = \\begin{pmatrix} a^{\\prime}_{11} & X^{\\prime} \\\\ Y^{\\prime} & B^{\\prime} \\end{pmatrix}")#text(" is the matrix corresponding to the transformed graph. Here, ")#mi("a_{11}, a^{\\prime}_{11}, f, f^{\\prime}")#text(" are scalars, ")#mi("X, X^{\\prime}")#text(" are ")#mi("1 \\times n-1")#text(" row vectors, ")#mi("Y, Y^{\\prime}")#text(" are ")#mi("n-1 \\times 1")#text(" column vectors, ")#mi("B, B^{\\prime}")#text(" are ")#mi("n-1 \\times n-1")#text(" matrices and ")#mi("A, A^{\\prime}")#text(" are ")#mi("n \\times n")#text(" matrices. The formulas I are obtained for ")#mi("A^{\\prime}")#text(" are the following:")

#mi("a^{\\prime}_{11} = f (a_{11} d + c)")#linebreak()#text(" ")#mi("X^{\\prime} = \\det(M) f X")#linebreak()#text(" ")#mi("Y^{\\prime} = f Y")#linebreak()#text(" ")#mi("B^{\\prime} = B - f b Y X")

#text("where ")#mi("f = \\frac{1}{a_{11} b + a}")#text(" and ")#mi("\\det(M) = a d - b c")#text(" is the determinant of the matrix ")#mi("M")#text(". This works when: ")#mi("a_{11} \\neq -\\frac{a}{b}")#text(" (the matrix ")#mi("M")#text(" should probably also be non-degenerate = invertible = with ")#mi("\\det(M) \\neq 0")#text(").")

#text("This neatly generalizes the fractional sweep, which is just a special case when: ")#mi("M = \\begin{pmatrix} \\cos \\phi & \\sin \\phi \\\\ -\\sin \\phi & \\cos \\phi \\end{pmatrix}")#text(", the special case of which is the regular (full) sweep with: ")#mi("M = \\begin{pmatrix} 0 & 1 \\\\ -1 & 0 \\end{pmatrix}")#text(", i.e. ")#mi("\\phi = \\frac{\\pi}{2}")#text(" in the fractional sweep.")

#text("For convenience, let’s define the above obtained ")#mi("A^{\\prime} = \\text{Sweep}^M_1[A]")#text(" as the “general linear sweep” of the matrix ")#mi("A")#text(" under the matrix ")#mi("M")#text(" at ")#mi("k = 1")#text(", or for an arbitrary ")#mi("k")#text(" (just relabel the basis vectors) as: ")#mi("\\text{Sweep}^M_k[A]")#text(".")

#text("Some properties of this operation (where we assume that the condition ")#mi("a_{11} \\neq -\\frac{a}{b}")#text(" is satisfied wherever relevant):")

#text("1.) Algebraic definition:")

#mi("\\text{Sweep}^M_1[A] \\begin{pmatrix} r^{\\prime} \\\\ R \\end{pmatrix} = \\begin{pmatrix} s^{\\prime} \\\\ S \\end{pmatrix}")#text(" if and only if ")#mi("A \\begin{pmatrix} r \\\\ R \\end{pmatrix} = \\begin{pmatrix} s \\\\ S \\end{pmatrix}")

#text("where ")#mi("\\begin{pmatrix} r^{\\prime} \\\\ s^{\\prime} \\end{pmatrix} = M \\begin{pmatrix} r \\\\ s \\end{pmatrix}")#text(".")

#text("2.) Geometric definition:")

#mi("\\text{Graph}[\\text{Sweep}^M_k[A]] = M_k \\text{Graph}[A]")

#text("where ")#mi("M_k")#text(" acts as an identity in all subspaces orthogonal to the ")#mi("\\{e_k,f_k\\}")#text(" plane, and on the ")#mi("\\{e_k,f_k\\}")#text(" plane acts as the matrix ")#mi("M")#text(" (explicitly, ")#mi("M_k = \\text{id}_{2(k-1)} \\otimes M \\otimes \\text{id}_{2(n-k)}")#text(").")

#text("3.) Homomorphism with matrix multiplication:")

#mi("(\\text{Sweep}^M_k \\text{Sweep}^N_k) = \\text{Sweep}^{M N}_k")

#text("where ")#mi("M, N")#text(" are arbitrary non-degenerate ")#mi("2 \\times 2")#text(" matrices. (I checked this with Mathematica explicitly.)")

#text("4.) Commutativity:")

#mi("\\text{Sweep}^M_k \\text{Sweep}^N_l = \\text{Sweep}^N_l \\text{Sweep}^M_k")

#text("if and only if: either ")#mi("k \\neq l")#text(" (from the geometric definition) or ")#mi("k = l")#text(" and the ")#mi("2 \\times 2")#text(" matrices ")#mi("M, N")#text(" commute, that is, if: ")#mi("M N = N M")#text(" (from homomorphism with matrix multiplication).")

#text("5.) Inverse:")

#text("From homomorphism with matrix multiplication it follows that the inverse of ")#mi("\\text{Sweep}^M_k")#text(" is obtained by using the inverse of the matrix ")#mi("M")#text(" for the general linear sweep:")

#mi("(\\text{Sweep}^M_k)^{-1} = \\text{Sweep}^{M^{-1}}_k")

#text("where ")#mi("M")#text(" is a non-degenerate (invertible) ")#mi("2 \\times 2")#text(" matrix.")

#text("Ok, what still remains to be done at some point is:")

#text("a) Write down the explicit formula for ")#mi("\\text{Sweep}^M_k")#text(" instead of hiding it under the rug, so to speak, by only explicitly deriving ")#mi("\\text{Sweep}^M_1")#text(".")

#text("b) See what happens when we compose sweeps with the same matrix ")#mi("M")#text(" in sequence from ")#mi("k = 1")#text(" to some ")#mi("k = m \\leq n")#text(". That is, what does the matrix: ")#mi("(\\text{Sweep}^M_1 \\dots \\text{Sweep}^M_m)[A]")#text(" look like? This should also address what the correct generalization of matrix inversion is by performing sweeps for all ")#mi("k")#text(" from ")#mi("1")#text(" to ")#mi("n")#text(" in sequence with the same ")#mi("M")#text(".")

#text("c) What is the connection or generalization of the determinant-calculating algorithm from regular (full) sweeps?")

#text("x) Is this useful for anything?")

#emph[#text("[My commenting policy is at ")#link("https://terrytao.wordpress.com/about/")[#text("https://terrytao.wordpress.com/about/")]#text(" . Thus far I see no violation of these policies. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MatjazG")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460328")[#strong[#text("MatjazG")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2015")])]

#text("An obvious property, implicit in the algebraic and geometric definitions and used implicitly in the inversion property:")

#text("6.) Identity:")

#mi("\\text{Sweep}^I_k[A] = A")

#text("for all ")#mi("k")#text(" and all ")#mi("n \\times n")#text(" matrices ")#mi("A")#text(", where ")#mi("I = \\begin{pmatrix} 1 & 0 \\\\ 0 & 1 \\end{pmatrix}")#text(" is the ")#mi("2 \\times 2")#text(" identity matrix.")

#text("Also:")

#text("7.) Scaling:")

#text("For ")#mi("k = 1")#text(", if we use ")#mi("M = M(t) = t M(1)")#text(" we get for ")#mi("A^{\\prime}(t) = \\text{Sweep}^{t M(1)}_1[A] = \\begin{pmatrix} a^{\\prime}_{11}(t) & X^{\\prime}(t) \\\\ Y^{\\prime}(t) & B^{\\prime}(t) \\end{pmatrix}")#text(":")

#mi("a^{\\prime}_{11}(t) = a^{\\prime}_{11}(1)")#linebreak()#text(" ")#mi("B^{\\prime}(t) = B^{\\prime}(1)")

#text("but:")

#mi("X^{\\prime}(t) = t X^{\\prime}(1)")#linebreak()#text(" ")#mi("Y^{\\prime}(t) = \\frac{1}{t} Y^{\\prime}(1)")

#text("In other words, only ")#mi("X^{\\prime}(t)")#text(" and ")#mi("Y^{\\prime}(t)")#text(" change when we multiply the matrix ")#mi("M(1)")#text(" with ")#mi("t")#text(", and they do this by scaling with ")#mi("t^{\\pm 1}")#text(". This property is also obvious from the algebraic definition.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460285")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2015")])]

#text("There is a “the the” but it does not hurt. With this comment there are two so perhaps this comment should be deleted also.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460286")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2015")])]

#text("Thanks to the commenters who noted the alternative names for sweeping in the literature. Based on those, I was able to find a survey of Tsatsomeros at ")#link("http://www.math.wsu.edu/math/faculty/tsat/files/t2.pdf")[#text("http://www.math.wsu.edu/math/faculty/tsat/files/t2.pdf")]#text(" who attributes the operation independently to a 1960 paper of Tucker (under the name of “Principal Pivot Transform”), a 1960 paper of Efroymson (under the name of “sweeping”), and to a 1966 paper of Duffy, Hazony, and Morrison (under the name of “gyration”), and later called “exchange” in a 1998 paper of Stewart and Stewart. It’s curious that such a widespread notion does not seem to have a consensus name (for instance, none of these terms appear as matrix operations on Wikipedia).")

#text("In statistics, it appears that sweeping is primarily applied to matrices that are either positive definite, or have a large positive definite minor. In those cases it appears that the problem of having the pivot too close to zero is largely eliminated, as the pivots are all nonnegative and one can pick the largest one at each stage. Of course, there is still a difficulty if the matrix is close to singular, but presumably there are ways to deal with this case in applications.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/070548c5f283d5da8bc06d5ee4ecf9174139faa45d02e3c408c967e6ec3771b0-96317c989091e8e46020f553fc3a6f996a51998c5bca5c719f77f5ef4cb0a09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of victor")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460381")[#strong[#text("victor")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2015")])]

#text("Is there a connection between the sweeping operation described here and the balayage (sweeping) operator in potential theory?")

#link("https://en.wikipedia.org/wiki/Balayage")[#text("https://en.wikipedia.org/wiki/Balayage")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7bd79ccc17907103f59d86fb20316d47cd1b97b6e5da97c6784bb34597ecff0-0d4f3e22196665cd23c0b63eb88a1c5d6701288f8a5ee038d7b21ba2ca261e47.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460382")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2015")])]

#text("Is there a standard definition of a graph as used in this post? This differs of a graph as set of vertices and edges.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460411")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2015")])]

#text("See ")#link("https://en.wikipedia.org/wiki/Graph_of_a_function")[#text("https://en.wikipedia.org/wiki/Graph_of_a_function")]#text(" .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460443")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2015")])]

#text("second vector -> second factor")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e100766a4021336f08e0f7f81814c7bec8ff2f373f2f9e0032624e6395c4b474-d1dce3e8d896e2996e258b4077118e9c6170fe99464b1a48a38f12b2ab3bb34e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yi HUANG")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460512")[#strong[#text("Yi HUANG")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2015")])]

#text("Hi, Terry,")

#text("At first glance, this sweeping reminds me of the")#linebreak()#text(" Auscher-Axelsson-McIntosh first order formalism")#linebreak()#text(" for second order elliptic equations.")#linebreak()#text(" The article I mean is")#linebreak()#text(" ")#link("http://link.springer.com/article/10.1007/s11512-009-0108-2")[#text("http://link.springer.com/article/10.1007/s11512-009-0108-2")]#linebreak()#text(" The sweeping operation appears in the formula above the equation (11) on page 264.")

#text("Best regard, Yi")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a747537ede6b40643e4449c04bbac2151d50cbe6dcc735502253562a60fb17b0-f5b6dc067e75d522e46dcbc4a63bd1c3e060fcc91b0c03621cc3bdf35e601d80.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of francisrlb")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460644")[#strong[#text("francisrlb")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2015")])]

#text("The formula for the sweep of a matrix looks similar to the formula for the cluster mutation of a matrix. Do you know of any connection between the two?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8836f12a9d806c63b7e9207cf3df987fe6ed0ed88111ac002f7c940d98ff8e2-36522b453f1662a114304bbb8cb83a71251c9367625adbec1f9fea0efcf727c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ammar Husain")]], [#link("https://terrytao.wordpress.com/2015/10/07/sweeping-a-matrix-rotates-its-graph/#comment-460905")[#strong[#text("Ammar Husain")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2015")])]

#text("@francisrlb, That was the first instinct I had too. But there is no mention of whether this matrix is totally positive so maybe would have to check how this transformation behaves with minors. (I haven’t done this) If so, then you could see the Poisson structure and win at usefulness in integrability gives usefulness in numerical analysis.")
]
