// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/
// Converted to Typst by tao2typ: "2026-10-14T15:19:33.107729+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Heath-Brown’s theorem on prime twins and Siegel zeroes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Heath-Brown’s theorem on prime twins and Siegel zeroes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 August 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/")[#text("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("https://en.wikipedia.org/wiki/Twin_prime")[#text("twin prime conjecture")]#text(" is one of the oldest unsolved problems in analytic number theory. There are several reasons why this conjecture remains out of reach of current techniques, but the most important obstacle is the ")#link("https://en.wikipedia.org/wiki/Parity_problem_(sieve_theory)")[#text("parity problem")]#text(" which prevents purely sieve-theoretic methods (or many other popular methods in analytic number theory, such as the circle method) from detecting pairs of prime twins in a way that can distinguish them from other twins of almost primes. The parity problem is discussed in ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("these")]#text(" ")#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/")[#text("previous")]#text(" ")#link("https://terrytao.wordpress.com/2014/11/21/a-general-parity-problem-obstruction/")[#text("blog posts")]#text("; this obstruction is ultimately powered by the ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Möbius pseudorandomness principle")]#text(" that asserts that the ")#link("https://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("Möbius function")]#text(" ")#mi("{\\mu}")#text(" is asymptotically orthogonal to all “structured” functions (and in particular, to the weight functions constructed from sieve theory methods).")

#text("However, there is an intriguing “alternate universe” in which the Möbius function ")#emph[#text("is")]#text(" strongly correlated with some structured functions, and specifically with some ")#link("https://en.wikipedia.org/wiki/Dirichlet_character")[#text("Dirichlet characters")]#text(", leading to the existence of the infamous “")#link("https://en.wikipedia.org/wiki/Siegel_zero")[#text("Siegel zero")]#text("“. In this scenario, the parity problem obstruction disappears, and it becomes possible, ")#emph[#text("in principle")]#text(", to attack problems such as the twin prime conjecture. In particular, we have the following ")#link("http://www.ams.org/mathscinet-getitem?mr=703977")[#text("result of Heath-Brown")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" At least one of the following two statements are true:")

#list(
[#text("(Twin prime conjecture) There are infinitely many primes ")#mi("{p}")#text(" such that ")#mi("{p+2}")#text(" is also prime.")],
[#text("(No Siegel zeroes) There exists a constant ")#mi("{c>0}")#text(" such that for every real Dirichlet character ")#mi("{\\chi}")#text(" of conductor ")#mi("{q > 1}")#text(", the associated Dirichlet ")#mi("{L}")#text("-function ")#mi("{s \\mapsto L(s,\\chi)}")#text(" has no zeroes in the interval ")#mi("{[1-\\frac{c}{\\log q}, 1]}")#text(".")]
)
]

#text("Informally, this result asserts that if one had an infinite sequence of Siegel zeroes, one could use this to generate infinitely many twin primes. See ")#link("http://www.ams.org/notices/200907/rtx090700817p.pdf")[#text("this survey of Friedlander and Iwaniec")]#text(" for more on this “illusory” or “ghostly” parallel universe in analytic number theory that should not actually exist, but is surprisingly self-consistent and to date proven to be impossible to banish from the realm of possibility.")

#text("The strategy of Heath-Brown’s proof is fairly straightforward to describe. The usual starting point is to try to lower bound ")#metadata(none) <tao-124a9caf6e788abd00ff>#mi("\\displaystyle  \\sum_{x \\leq n \\leq 2x} \\Lambda(n) \\Lambda(n+2) \\ \\ \\ \\ \\ (1)")#text(" ")#text(" for some large value of ")#mi("{x}")#text(", where ")#mi("{\\Lambda}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(". Actually, in this post we will work with the slight variant")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq 2x} \\Lambda_2(n(n+2)) \\nu(n(n+2))")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\Lambda_2(n) = (\\mu * L^2)(n) = \\sum_{d|n} \\mu(d) \\log^2 \\frac{n}{d}")]]

#text("is the second von Mangoldt function, and ")#mi("{*}")#text(" denotes ")#link("https://en.wikipedia.org/wiki/Dirichlet_convolution")[#text("Dirichlet convolution")]#text(", and ")#mi("{\\nu}")#text(" is an (unsquared) Selberg sieve that damps out small prime factors. This sum also detects twin primes, but will lead to slightly simpler computations. For technical reasons we will also smooth out the interval ")#mi("{x \\leq n \\leq 2x}")#text(" and remove very small primes from ")#mi("{n}")#text(", but we will skip over these steps for the purpose of this informal discussion. (In Heath-Brown’s original paper, the Selberg sieve ")#mi("{\\nu}")#text(" is essentially replaced by the more combinatorial restriction ")#mi("{1_{(n(n+2),q^{1/C}\\#)=1}}")#text(" for some large ")#mi("{C}")#text(", where ")#mi("{q^{1/C}\\#}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Primorial")[#text("primorial")]#text(" of ")#mi("{q^{1/C}}")#text(", but I found the computations to be slightly easier if one works with a Selberg sieve, particularly if the sieve is not squared to make it nonnegative.)")

#text("If there is a Siegel zero ")#mi("{L(\\beta,\\chi)=0}")#text(" with ")#mi("{\\beta}")#text(" close to ")#mi("{1}")#text(" and ")#mi("{\\chi}")#text(" a Dirichlet character of conductor ")#mi("{q}")#text(", then multiplicative number theory methods can be used to show that the Möbius function ")#mi("{\\mu}")#text(" “pretends” to be like the character ")#mi("{\\chi}")#text(" in the sense that ")#mi("{\\mu(p) \\approx \\chi(p)}")#text(" for “most” primes ")#mi("{p}")#text(" near ")#mi("{q}")#text(" (e.g. in the range ")#mi("{q^\\varepsilon \\leq p \\leq q^C}")#text(" for some small ")#mi("{\\varepsilon>0}")#text(" and large ")#mi("{C>0}")#text("). Traditionally, one uses complex-analytic methods to demonstrate this, but one can also use elementary multiplicative number theory methods to establish these results (qualitatively at least), as will be shown below the fold.")

#text("The fact that ")#mi("{\\mu}")#text(" pretends to be like ")#mi("{\\chi}")#text(" can be used to construct a tractable approximation (after inserting the sieve weight ")#mi("{\\nu}")#text(") in the range ")#mi("{[x,2x]}")#text(" (where ")#mi("{x = q^C}")#text(" for some large ")#mi("{C}")#text(") for the second von Mangoldt function ")#mi("{\\Lambda_2}")#text(", namely the function")

#align(center)[#tao-fit-display[#mitex("\\tilde \\Lambda_2(n) := (\\chi * L)(n) = \\sum_{d|n} \\chi(d) \\log^2 \\frac{n}{d}.")]]

#text("Roughly speaking, we think of the periodic function ")#mi("{\\chi}")#text(" and the slowly varying function ")#mi("{\\log^2}")#text(" as being of about the same “complexity” as the constant function ")#mi("{1}")#text(", so that ")#mi("{\\tilde \\Lambda_2}")#text(" is roughly of the same “complexity” as the ")#link("https://en.wikipedia.org/wiki/Divisor_function")[#text("divisor function")]

#align(center)[#tao-fit-display[#mitex("\\tau(n) := (1*1)(n) = \\sum_{d|n} 1,")]]

#text("which is considerably simpler to obtain asymptotics for than the von Mangoldt function as the Möbius function is no longer present. (For instance, note from the ")#link("http://planetmath.org/dirichlethyperbolamethod")[#text("Dirichlet hyperbola method")]#text(" that one can estimate ")#mi("{\\sum_{x \\leq n \\leq 2x} \\tau(n)}")#text(" to accuracy ")#mi("{O(\\sqrt{x})}")#text(" with little difficulty, whereas to obtain a comparable level of accuracy for ")#mi("{\\sum_{x \\leq n \\leq 2x} \\Lambda(n)}")#text(" or ")#mi("{\\sum_{x \\leq n \\leq 2x} \\Lambda_2(n)}")#text(" is essentially the Riemann hypothesis.)")

#text("One expects ")#mi("{\\tilde \\Lambda_2(n)}")#text(" to be a good approximant to ")#mi("{\\Lambda_2(n)}")#text(" if ")#mi("{n}")#text(" is of size ")#mi("{O(x)}")#text(" and has no prime factors less than ")#mi("{q^{1/C}}")#text(" for some large constant ")#mi("{C}")#text(". The Selberg sieve ")#mi("{\\nu}")#text(" will be mostly supported on numbers with no prime factor less than ")#mi("{q^{1/C}}")#text(". As such, one can hope to approximate ")#link(<tao-124a9caf6e788abd00ff>)[#text("(1)")]#text(" by the expression ")#metadata(none) <tao-5962e6dd2cc94e077913>#mi("\\displaystyle  \\sum_{x \\leq n \\leq 2x} \\tilde \\Lambda_2(n(n+2)) \\nu(n(n+2)); \\ \\ \\ \\ \\ (2)")#text(" ")#text(" as it turns out, the error between this expression and ")#link(<tao-124a9caf6e788abd00ff>)[#text("(1)")]#text(" is easily controlled by sieve-theoretic techniques. Let us ignore the Selberg sieve for now and focus on the slightly simpler sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq 2x} \\tilde \\Lambda_2(n(n+2)).")]]

#text("As discussed above, this sum should be thought of as a slightly more complicated version of the sum")

#metadata(none) <tao-9372c470eeadd5ecd9c3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_{x \\leq n \\leq 2x} \\tau(n(n+2)).")]]

#text("Accordingly, let us look (somewhat informally) at the task of estimating the model sum ")#link(<tao-9372c470eeadd5ecd9c3>)[#text("(3)")]#text(". One can think of this problem as basically that of counting solutions to the equation ")#mi("{ab+2=cd}")#text(" with ")#mi("{a,b,c,d}")#text(" in various ranges; this is clearly related to understanding the equidistribution of the hyperbola ")#mi("{\\{ (a,b) \\in {\\bf Z}/d{\\bf Z}: ab + 2 = 0 \\text{ mod } d \\}}")#text(" in ")#mi("{({\\bf Z}/d{\\bf Z})^2}")#text(". Taking Fourier transforms, the latter problem is closely related to estimation of the ")#link("https://en.wikipedia.org/wiki/Kloosterman_sum")[#text("Kloosterman sums")]

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\in ({\\bf Z}/r{\\bf Z})^\\times} e( \\frac{a_1 m + a_2 \\overline{m}}{r} )")]]

#text("where ")#mi("{\\overline{m}}")#text(" denotes the inverse of ")#mi("{m}")#text(" in ")#mi("{({\\bf Z}/r{\\bf Z})^\\times}")#text(". One can then use the Weil bound")

#metadata(none) <tao-cc953b849b630ad6c486>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{m \\in ({\\bf Z}/r{\\bf Z})^\\times} e( \\frac{am+b\\overline{m}}{r} ) \\ll r^{1/2 + o(1)} (a,b,r)^{1/2}")]]

#text("where ")#mi("{(a,b,r)}")#text(" is the greatest common divisor of ")#mi("{a,b,r}")#text(" (with the convention that this is equal to ")#mi("{r}")#text(" if ")#mi("{a,b}")#text(" vanish), and the ")#mi("{o(1)}")#text(" decays to zero as ")#mi("{r \\rightarrow \\infty}")#text(". The Weil bound yields good enough control on error terms to estimate ")#link(<tao-9372c470eeadd5ecd9c3>)[#text("(3)")]#text(", and as it turns out the same method also works to estimate ")#link(<tao-5962e6dd2cc94e077913>)[#text("(2)")]#text(" (provided that ")#mi("{x=q^C}")#text(" with ")#mi("{C}")#text(" large enough).")

#text("Actually one does not need the full strength of the Weil bound here; any power savings over the trivial bound of ")#mi("{r}")#text(" will do. In particular, it will suffice to use the weaker, but easier to prove, bounds of Kloosterman:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Kloosterman bound)")]#text(" ")#metadata(none) <tao-aced042cecce971f8296>#text(" One has")

#metadata(none) <tao-facdcf17348e8b88754d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_{m \\in ({\\bf Z}/r{\\bf Z})^\\times} e( \\frac{am+b\\overline{m}}{r} ) \\ll r^{3/4 + o(1)} (a,b,r)^{1/4}")]]

#text("whenever ")#mi("{r \\geq 1}")#text(" and ")#mi("{a,b}")#text(" are coprime to ")#mi("{r}")#text(", where the ")#mi("{o(1)}")#text(" is with respect to the limit ")#mi("{r \\rightarrow \\infty}")#text(" (and is uniform in ")#mi("{a,b}")#text(").")
]

#emph[#text("Proof:")]#text(" Observe from change of variables that the Kloosterman sum ")#mi("{\\sum_{m \\in ({\\bf Z}/r{\\bf Z})^\\times} e( \\frac{am+b\\overline{m}}{r} )}")#text(" is unchanged if one replaces ")#mi("{(a,b)}")#text(" with ")#mi("{(\\lambda a, \\lambda^{-1} b)}")#text(" for ")#mi("{\\lambda \\in ({\\bf Z}/d{\\bf Z})^\\times}")#text(". For fixed ")#mi("{a,b}")#text(", the number of such pairs ")#mi("{(\\lambda a, \\lambda^{-1} b)}")#text(" is at least ")#mi("{r^{1-o(1)} / (a,b,r)}")#text(", thanks to the ")#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/")[#text("divisor bound")]#text(". Thus it will suffice to establish the fourth moment bound")

#align(center)[#tao-fit-display[#tao-math("\\sum_{a,b \\in {\\bf Z}/r{\\bf Z}} \\left|\\sum_{m \\in ({\\bf Z}/r{\\bf Z})^\\times} e\\left( \\frac{am+b\\overline{m}}{r} \\right)\\right|^4 \\ll d^{4+o(1)}.", block: true)]]

#text("The left-hand side can be rearranged as")

#align(center)[#tao-fit-display[#mitex("\\sum_{m_1,m_2,m_3,m_4 \\in ({\\bf Z}/r{\\bf Z})^\\times} \\sum_{a,b \\in {\\bf Z}/d{\\bf Z}}")]]

#align(center)[#tao-fit-display[#mitex("e\\left( \\frac{a(m_1+m_2-m_3-m_4) + b(\\overline{m_1}+\\overline{m_2}-\\overline{m_3}-\\overline{m_4})}{r} \\right)")]]

#text("which by Fourier summation is equal to")

#align(center)[#tao-fit-display[#mitex("d^2 \\# \\{ (m_1,m_2,m_3,m_4) \\in (({\\bf Z}/r{\\bf Z})^\\times)^4:")]]

#align(center)[#tao-fit-display[#mitex("m_1+m_2-m_3-m_4 = \\frac{1}{m_1} + \\frac{1}{m_2} - \\frac{1}{m_3} - \\frac{1}{m_4} = 0 \\text{ mod } r \\}.")]]

#text("Observe from the quadratic formula and the divisor bound that each pair ")#mi("{(x,y)\\in ({\\bf Z}/r{\\bf Z})^2}")#text(" has at most ")#mi("{O(r^{o(1)})}")#text(" solutions ")#mi("{(m_1,m_2)}")#text(" to the system of equations ")#mi("{m_1+m_2=x; \\frac{1}{m_1} + \\frac{1}{m_2} = y}")#text(". Hence the number of quadruples ")#mi("{(m_1,m_2,m_3,m_4)}")#text(" of the desired form is ")#mi("{r^{2+o(1)}}")#text(", and the claim follows. ")#mi("\\Box")

#text("We will also need another easy case of the Weil bound to handle some other portions of ")#link(<tao-5962e6dd2cc94e077913>)[#text("(2)")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Easy Weil bound)")]#text(" ")#metadata(none) <tao-392eaffcf701523b013c>#text(" Let ")#mi("{\\chi}")#text(" be a primitive real Dirichlet character of conductor ")#mi("{q}")#text(", and let ")#mi("{a,b,c,d \\in{\\bf Z}/q{\\bf Z}}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}/q{\\bf Z}} \\chi(an+b) \\chi(cn+d) \\ll q^{o(1)} (ad-bc, q).")]]
]

#emph[#text("Proof:")]#text(" As ")#mi("{q}")#text(" is the conductor of a primitive real Dirichlet character, ")#mi("{q}")#text(" is equal to ")#mi("{2^j}")#text(" times a squarefree odd number for some ")#mi("{j \\leq 3}")#text(". By the Chinese remainder theorem, it thus suffices to establish the claim when ")#mi("{q}")#text(" is an odd prime. We may assume that ")#mi("{ad-bc}")#text(" is not divisible by this prime ")#mi("{q}")#text(", as the claim is trivial otherwise. If ")#mi("{a}")#text(" vanishes then ")#mi("{c}")#text(" does not vanish, and the claim follows from the mean zero nature of ")#mi("{\\chi}")#text("; similarly if ")#mi("{c}")#text(" vanishes. Hence we may assume that ")#mi("{a,c}")#text(" do not vanish, and then we can normalise them to equal ")#mi("{1}")#text(". By completing the square it now suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}/p{\\bf Z}} \\chi( n^2 - b ) \\ll 1")]]

#text("whenever ")#mi("{b \\neq 0 \\text{ mod } p}")#text(". As ")#mi("{\\chi}")#text(" is ")#mi("{+1}")#text(" on the quadratic residues and ")#mi("{-1}")#text(" on the non-residues, it now suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\# \\{ (m,n) \\in ({\\bf Z}/p{\\bf Z})^2: n^2 - b = m^2 \\} = p + O(1).")]]

#text("But by making the change of variables ")#mi("{(x,y) = (n+m,n-m)}")#text(", the left-hand side becomes ")#mi("{\\# \\{ (x,y) \\in ({\\bf Z}/p{\\bf Z})^2: xy=b\\}}")#text(", and the claim follows. ")#mi("\\Box")

#text("While the basic strategy of Heath-Brown’s argument is relatively straightforward, implementing it requires a large amount of computation to control both main terms and error terms. I experimented for a while with rearranging the argument to try to reduce the amount of computation; I did not fully succeed in arriving at a satisfactorily minimal amount of superfluous calculation, but I was able to at least reduce this amount a bit, mostly by replacing a combinatorial sieve with a Selberg-type sieve (which was not needed to be positive, so I dispensed with the squaring aspect of the Selberg sieve to simplify the calculations a little further; also for minor reasons it was convenient to retain a tiny portion of the combinatorial sieve to eliminate extremely small primes). Also some modest reductions in complexity can be obtained by using the second von Mangoldt function ")#mi("{\\Lambda_2(n(n+2))}")#text(" in place of ")#mi("{\\Lambda(n) \\Lambda(n+2)}")#text(". These exercises were primarily for my own benefit, but I am placing them here in case they are of interest to some other readers.")

#metadata(none) <tao-fa1db7493d1fdd13d914>

#heading(level: 1)[#strong[#text(" — 1. Consequences of a Siegel zero — ")]]

#text("It is convenient to phrase Heath-Brown’s theorem in the following equivalent form:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4")]#text(" Suppose one has a sequence ")#mi("{\\chi_{\\bf n}}")#text(" of real Dirichlet characters of conductor ")#mi("{q_{\\bf n}}")#text(" going to infinity, and a sequence of real zeroes ")#mi("{L(\\beta_{\\bf n},\\chi_{\\bf n}) = 0}")#text(" with ")#mi("{\\beta_{\\bf n} = 1 - o( \\frac{1}{\\log q_{\\bf n}})}")#text(" as ")#mi("{{\\bf n} \\rightarrow \\infty}")#text(". Then there are infinitely many prime twins.")
]

#text("Henceforth, we omit the dependence on ")#mi("{{\\bf n}}")#text(" from all of our quantities (unless they are explicitly declared to be “fixed”), and the asymptotic notation ")#mi("{o(1)}")#text(", ")#mi("{O(1)}")#text(", ")#mi("{\\ll}")#text(", etc. will always be understood to be with respect to the ")#mi("{{\\bf n}}")#text(" parameter, e.g. ")#mi("{X \\ll Y}")#text(" means that ")#mi("{X \\leq CY}")#text(" for some fixed ")#mi("{C}")#text(". (In the language of ")#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/")[#text("this previous blog post")]#text(", we are thus implicitly using “cheap nonstandard analysis”, although we will not explicitly use nonstandard analysis notation (other than the asymptotic notation mentioned above) further in this post. With this convention, we now have a single (but not fixed) Dirichlet character ")#mi("{\\chi}")#text(" of some conductor ")#mi("{q}")#text(" with a Siegel zero ")#metadata(none) <tao-a36cdab01f2d09dffa0e>#mi("\\displaystyle  \\beta = 1 - o(\\frac{1}{\\log q}). \\ \\ \\ \\ \\ (6)")#text(" ")#text(" It will also be convenient to use the crude bound ")#metadata(none) <tao-f44e64e75f3948e9f73f>#mi("\\displaystyle  1 - \\beta \\gg q^{-O(1)} \\ \\ \\ \\ \\ (7)")#text(" ")#text(" which can be proven by elementary means (see e.g. Exercise 57 of ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("this post")]#text("), although one can use ")#link("https://en.wikipedia.org/wiki/Siegel_zero")[#text("Siegel’s theorem")]#text(" to obtain the better bound ")#mi("{1 - \\beta \\gg q^{-o(1)}}")#text(". Standard arguments (see also Lemma 59 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("this blog post")]#text(") then give ")#metadata(none) <tao-aea721c039a808c24a14>#mi("\\displaystyle  L(1,\\chi) \\gg q^{-O(1)} \\ \\ \\ \\ \\ (8)")

#text("We now use this Siegel zero to show that ")#mi("{\\mu}")#text(" pretends to be like ")#mi("{\\chi}")#text(" for primes that are comparable (in log-scale) to ")#mi("{q}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5")]#text(" ")#metadata(none) <tao-6e533337bd970a97d7ac>#text(" For any fixed ")#mi("{0 < \\varepsilon < C}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{q^\\varepsilon \\leq p \\leq q^C: \\chi(p) \\neq -1} \\frac{1}{p} = o(1).")]]
]

#text("For more precise estimates on the ")#mi("{o(1)}")#text(" error, see ")#link("http://www.ams.org/mathscinet-getitem?mr=703977")[#text("the paper of Heath-Brown")]#text(" (particularly Lemma 3).")

#emph[#text("Proof:")]#text(" It suffices to show, for sufficiently large fixed ")#mi("{C>0}")#text(", that")

#align(center)[#tao-fit-display[#mitex("\\sum_{q^{C/k} < p \\leq q^{2C/k}: \\chi(p) \\neq -1} \\frac{1}{p} = o(1)")]]

#text("for each fixed natural number ")#mi("{k}")#text(".")

#text("We begin by considering the sum ")#metadata(none) <tao-2d949832040c058be68e>#mi("\\displaystyle  \\sum_{n \\leq x} \\frac{1*\\chi(n)}{n^\\beta} \\ \\ \\ \\ \\ (9)")#text(" ")#text(" for some large ")#mi("{x}")#text(" (which we will eventually take to be a power of ")#mi("{q}")#text("); we will exploit the fact that this sum is very stable for ")#mi("{x}")#text(" comparable to ")#mi("{q}")#text(" in log-scale. By the Dirichlet hyperbola method, we can write this as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq \\sqrt{x}} \\frac{1}{d^\\beta} \\sum_{m \\leq x/d} \\frac{\\chi(m)}{m^\\beta} + \\sum_{m < \\sqrt{x}} \\frac{\\chi(m)}{m^\\beta} \\sum_{\\sqrt{x} < d \\leq x/m} \\frac{1}{d^\\beta}")]]

#text("Since ")#mi("{L(\\beta,\\chi) = 0}")#text(", one can show through summation by parts (see Lemma 71 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("this previous post")]#text(") that")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\leq y} \\frac{\\chi(m)}{m^\\beta} \\ll \\frac{q}{y^\\beta}")]]

#text("for any ")#mi("{y \\geq 1}")#text(", while from the integral test (see Lemma 2 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("this previous post")]#text(") we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\sqrt{x} < d \\leq x/m} \\frac{1}{d^\\beta} = \\frac{(x/m)^{1-\\beta}-\\sqrt{x}^{1-\\beta}}{1-\\beta} + O( \\frac{1}{\\sqrt{x}^\\beta}).")]]

#text("We can thus estimate ")#link(<tao-2d949832040c058be68e>)[#text("(9)")]#text(" as")

#tao-aligned(keep: true)[


#tao-math("\\sum_{d \\leq \\sqrt{x}} O( \\frac{q}{x^\\beta} )  & + \\frac{x^{1-\\beta}}{1-\\beta} \\sum_{m < \\sqrt{x}} \\frac{\\chi(m)}{m} - \\frac{x^{(1-\\beta)/2}}{1-\\beta} \\sum_{m < \\sqrt{x}} \\frac{\\chi(m)}{m^\\beta}", block: true)



#tao-math(" & + \\sum_{m < \\sqrt{x}} O( \\frac{1}{m^\\beta \\sqrt{x}^\\beta} ).", block: true)
]

#text("From summation by parts we again have")

#align(center)[#tao-fit-display[#mitex("\\sum_{m < \\sqrt{x}} \\frac{\\chi(m)}{m} = L(1,\\chi) + O( \\frac{q}{\\sqrt{x}})")]]

#text("and we have the crude bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{m < \\sqrt{x}} \\frac{1}{m^\\beta} \\ll \\frac{x^{1-\\beta}}{1-\\beta}")]]

#text("so by using ")#link(<tao-f44e64e75f3948e9f73f>)[#text("(7)")]#text(" and ")#mi("{x^{1-\\beta} = x^{o(1)}}")#text(" we arrive at")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{1*\\chi(n)}{n^\\beta} = \\frac{x^{1-\\beta}}{1-\\beta} L(1,\\chi) + O( q^{O(1)} x^{-1/2+o(1)} ).")]]

#text("for any ")#mi("{x > 1}")#text(", where the ")#mi("{O(1)}")#text(" exponent does not depend on ")#mi("{C}")#text(". In particular, if ")#mi("{q^C \\leq x \\leq q^{3C}}")#text(" and ")#mi("{C}")#text(" is large enough, then by ")#link(<tao-a36cdab01f2d09dffa0e>)[#text("(6)")]#text(", ")#link(<tao-f44e64e75f3948e9f73f>)[#text("(7)")]#text(", ")#link(<tao-aea721c039a808c24a14>)[#text("(8)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{1*\\chi(n)}{n^\\beta} = \\frac{1+o(1)}{1-\\beta} L(1,\\chi).")]]

#text("Setting ")#mi("{x=q^C}")#text(" and ")#mi("{x=q^{3C}}")#text(" and subtracting, we conclude that")

#metadata(none) <tao-957a49c3e803f5053e43>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\sum_{q^C < n \\leq q^{3C}} \\frac{1*\\chi(n)}{n^\\beta} = o( \\sum_{n \\leq q^{C}} \\frac{1*\\chi(n)}{n^\\beta} ).")]]

#text("On the other hand, observe that ")#mi("{1*\\chi}")#text(" is always non-negative, and that ")#mi("{1*\\chi(p_1 \\dots p_k n) \\geq 1*\\chi(n)}")#text(" whenever ")#mi("{n \\leq q^C}")#text(" and ")#mi("{q^{C/k} < p_1,\\dots,p_k \\leq q^{2C/k}}")#text(", with ")#mi("{p_1,\\dots,p_k}")#text(" primes with ")#mi("{\\chi(p_1),\\dots,\\chi(p_k) \\neq -1}")#text(". Since any number ")#mi("{N}")#text(" with ")#mi("{q^C < N \\leq q^{3C}}")#text(" has at most ")#mi("{O(1)}")#text(" representations of the form ")#mi("{N = p_1 \\dots p_k n}")#text(" with ")#mi("{n \\leq q^C}")#text(" and ")#mi("{q^{C/k} < p \\leq q^{2C/k}}")#text(", and no ")#mi("{N}")#text(" outside of the range ")#mi("{q^C < N \\leq q^{3C}}")#text(" has such a representation, we thus see that")

#align(center)[#tao-fit-display[#mitex("\\sum_{q^C < N \\leq q^{3C}} \\frac{1*\\chi(N)}{N^\\beta} \\gg (\\sum_{n \\leq q^C} \\frac{1*\\chi(n)}{n^\\beta}) (\\sum_{q^{C/k} < p \\leq q^{2C/k}: \\chi(p) \\neq -1} \\frac{1}{p^\\beta})^k.")]]

#text("Comparing this with ")#link(<tao-957a49c3e803f5053e43>)[#text("(10)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{q^{C/k} < p \\leq q^{2C/k}: \\chi(p) \\neq -1} \\frac{1}{p^\\beta} = o(1);")]]

#text("since ")#mi("{1/p \\leq 1/p^\\beta}")#text(", the claim follows. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 2. Main argument — ")]]

#text("We let ")#mi("{w}")#text(" be a large absolute constant (")#mi("{w=100}")#text(" will do) and set ")#mi("{W := \\prod_{p \\leq w} p}")#text(" to be the primorial of ")#mi("{w}")#text(". Set ")#mi("{x := q^C}")#text(" for some large fixed ")#mi("{C}")#text(" (large compared to ")#mi("{w}")#text(" or ")#mi("{W}")#text("). Let ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a smooth non-negative function supported on ")#mi("{[-1/2,1/2]}")#text(" and equal to ")#mi("{1}")#text(" at ")#mi("{0}")#text(". Set")

#align(center)[#tao-fit-display[#mitex("f(n) := \\psi( \\frac{\\log n}{\\log q} )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\psi_x(n) := \\psi( \\log^C x (\\frac{n}{x}-1) ).")]]

#text("Thus ")#mi("{f(n)}")#text(" is a smooth cutoff to the region ")#mi("{n \\leq \\sqrt{q}}")#text(", and ")#mi("{\\psi_x(n)}")#text(" is a smooth cutoff to the region ")#mi("{n = (1+O(\\log^{-C} x)) x}")#text(". It will suffice to establish the lower bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{n:(n(n+2),W)=1} \\Lambda_2(n(n+2)) (\\mu f * 1)(n(n+2)) \\psi_x(n)")]]

#align(center)[#tao-fit-display[#mitex("\\gg (1-o(1)) x \\log^{-C} x,")]]

#text("because the non-twin primes ")#mi("{n}")#text(" contribute at most ")#mi("{O(x^{1/2+o(1)})}")#text(" to the left-hand side. The weight ")#mi("{(\\mu f*1)(n(n+2))}")#text(" is an unsquared Selberg sieve designed to damp out those ")#mi("{n}")#text(" for which ")#mi("{n}")#text(" or ")#mi("{n+2}")#text(" have somewhat small prime factors; we did not square this weight as is customary with the Selberg sieve in order to simplify the calculations slightly (the fact that the weight can be non-negative sometimes will not be a serious concern for us).")

#text("We split ")#mi("{1*\\chi}")#text(" as ")#metadata(none) <tao-cf07849a6245416dfc90>#mi("\\displaystyle  1*\\chi(n) = 1_{n=1} + g(n). \\ \\ \\ \\ \\ (11)")#text(" ")#text(" Thus ")#mi("{g}")#text(" is non-negative, and supported on those products ")#mi("{p_1 \\dots p_k}")#text(" of primes with ")#mi("{k \\geq 1}")#text(" and ")#mi("{\\chi(p_1),\\dots,\\chi(p_k) \\neq -1}")#text(", times a square. Convolving ")#link(<tao-cf07849a6245416dfc90>)[#text("(11)")]#text(" by ")#mi("{\\Lambda_2}")#text(" and using the identity ")#mi("{\\Lambda_2*1=L^2}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\tilde \\Lambda_2 = \\Lambda_2 + \\Lambda_2 * g")]]

#text("where ")#mi("{\\tilde \\Lambda_2 := \\chi * L^2}")#text(". (The quantities ")#mi("{\\Lambda_2, g, \\tilde \\Lambda_2}")#text(" are all non-negative, but we will not take advantage of these facts here.) It thus suffices to establish the two bounds")

#metadata(none) <tao-1293b1e32cdce358b4b4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\sum_{n:(n(n+2),W)=1} \\tilde \\Lambda_2(n (n+2)) (\\mu f * 1)(n(n+2)) \\psi_x(n)")]]

#align(center)[#tao-fit-display[#mitex("\\gg (1-o(1)) x \\log^{-C} x")]]

#text("and")

#metadata(none) <tao-2604e27f633ce39d1b8a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\sum_{n:(n(n+2),W)=1} (\\Lambda_2*g)(n (n+2)) (\\mu f * 1)(n(n+2)) \\psi_x(n)")]]

#align(center)[#tao-fit-display[#mitex("= o(x \\log^{-C} x);")]]

#text("the intuition here is that Lemma ")#link(<tao-6e533337bd970a97d7ac>)[#text("5")]#text(" is showing that ")#mi("{g}")#text(" is “sparse” and so the contribution of ")#mi("{\\Lambda_2 * g}")#text(" should be relatively small.")

#text("We begin with ")#link(<tao-2604e27f633ce39d1b8a>)[#text("(13)")]#text(". Let ")#mi("{\\varepsilon > 0}")#text(" be a small fixed quantity to be chosen later. Observe that if ")#mi("{(\\Lambda_2*g)(n(n+2))}")#text(" is non-zero, then ")#mi("{n(n+2)}")#text(" must have a factor on which ")#mi("{g}")#text(" is non-zero, which implies that ")#mi("{n(n+2)}")#text(" is either divisible by a prime ")#mi("{p}")#text(" with ")#mi("{\\chi(p) \\neq -1}")#text(", or by the square of a prime. If the former case occurs, then either ")#mi("{n}")#text(" or ")#mi("{n+2}")#text(" is divisible by ")#mi("{p}")#text("; since ")#mi("{n,n+2 \\leq 2x}")#text(", this implies that either ")#mi("{n(n+2)}")#text(" is divisible by a prime ")#mi("{p}")#text(" with ")#mi("{x^\\varepsilon \\leq p \\leq 2x^{1-\\varepsilon}}")#text(", or that ")#mi("{n(n+2)}")#text(" is divisible by a prime less than ")#mi("{x^\\varepsilon}")#text(". To summarise, at least one of the following three statements must hold:")

#list(
[#mi("{n(n+2)}")#text(" is divisible by a prime ")#mi("{w < p < x^\\varepsilon}")#text(".")],
[#mi("{n(n+2)}")#text(" is divisible by the square ")#mi("{p^2}")#text(" of a prime ")#mi("{p \\geq x^\\varepsilon}")#text(".")],
[#mi("{n(n+2)}")#text(" is divisible by a prime ")#mi("{x^\\varepsilon \\leq p \\leq 2x^{1-\\varepsilon}}")#text(" with ")#mi("{\\chi(p) \\neq -1}")#text(".")]
)

#text("It thus suffices to establish the estimates ")#metadata(none) <tao-ee99280a00b32c5fce7b>#mi("\\displaystyle  \\sum_{w < p < x^\\varepsilon} \\sum_{n: p|n(n+2),(n(n+2),W)=1} (\\Lambda_2*g)(n (n+2)) |(\\mu f * 1)(n(n+2))| \\ \\ \\ \\ \\ (14)")

#align(center)[#tao-fit-display[#mitex("\\psi_x(n) \\ll_C \\varepsilon x \\log^{-C} x,")]]

#metadata(none) <tao-e4c7d8a619f4241f3c56>#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\sum_{p \\geq x^\\varepsilon} \\sum_{n: p^2|n(n+2)} (\\Lambda_2*g)(n (n+2)) \\left|(\\mu f * 1)(n(n+2))\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\psi_x(n) = o(x \\log^{-C} x),")]]

#text("and")

#metadata(none) <tao-204956d3cf371c96017f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\sum_{x^\\varepsilon \\leq p \\geq 2x^{1-\\varepsilon}: \\chi(p) \\neq -1} \\sum_{n: p|n(n+2)} (\\Lambda_2*g)(n (n+2)) \\left|(\\mu f * 1)(n(n+2))\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\psi_x(n) = o(x \\log^{-C} x),")]]

#text("as the claim then follows by summing and sending ")#mi("{\\varepsilon}")#text(" slowly to zero.")

#text("We begin with ")#link(<tao-e4c7d8a619f4241f3c56>)[#text("(15)")]#text(". Observe that if ")#mi("{p^2}")#text(" divides ")#mi("{n(n+2)}")#text(" then either ")#mi("{p^2}")#text(" divides ")#mi("{n}")#text(" or ")#mi("{p^2}")#text(" divides ")#mi("{(n+2)}")#text(". In particular the number of ")#mi("{n \\leq 2x}")#text(" with ")#mi("{p^2 | n(n+2)}")#text(" is ")#mi("{O( \\frac{x}{p^2} )}")#text(". The summand ")#mi("{(\\Lambda_2*g)(n (n+2)) |(\\mu f * 1)(n(n+2)| \\psi_x(n)}")#text(" is ")#mi("{O(x^{o(1)})}")#text(" by the divisor bound, so the left-hand side of ")#link(<tao-e4c7d8a619f4241f3c56>)[#text("(15)")]#text(" is bounded by")

#align(center)[#tao-fit-display[#mitex("\\ll \\sum_{p \\geq x^\\varepsilon} \\frac{x}{p^2} x^{o(1)} \\ll x^{1-\\varepsilon+o(1)}")]]

#text("and the claim follows.")

#text("Next we turn to ")#link(<tao-ee99280a00b32c5fce7b>)[#text("(14)")]#text(". We can very crudely bound ")#metadata(none) <tao-b349f873812c3e0e0074>#mi("\\displaystyle  \\Lambda_2*g(n(n+2)) \\ll \\tau(n(n+2))^{O(1)} \\log^2 x, \\ \\ \\ \\ \\ (17)")#text(" ")#text(" so it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{w < p < x^\\varepsilon} \\sum_{n: p|n(n+2); (n(n+2),W)=1} \\tau(n (n+2))^{O(1)} |(\\mu f * 1)(n(n+2)| \\psi_x(n)")]]

#align(center)[#tao-fit-display[#mitex("\\ll_C \\varepsilon x \\log^{-C} x.")]]

#text("By Mertens’ theorem, it suffices to show that")

#metadata(none) <tao-4c499dc1f10efacdd446>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\sum_{n: p|n(n+2); (n(n+2),W)=1} \\tau(n (n+2))^{O(1)} |(\\mu f * 1)(n(n+2)| \\psi_x(n)")]]

#align(center)[#tao-fit-display[#mitex("\\ll_C \\frac{\\log p}{p \\log q} x \\log^{-C} x")]]

#text("for all ")#mi("{w < p < x^\\varepsilon}")#text(".")

#text("We use a modification of the argument used to prove Proposition 4.2 of ")#link("http://arxiv.org/abs/1407.4897")[#text("this Polymath8b paper")]#text(". By Fourier inversion, we may write")

#align(center)[#tao-fit-display[#mitex("e^u \\psi(u) = \\int_{\\bf R} \\Psi(t) e^{-itu}\\ dt")]]

#text("for some rapidly decreasing function ")#mi("{\\Psi}")#text(", so that")

#align(center)[#tao-fit-display[#mitex("f(d) = \\int_{\\bf R} \\frac{1}{d^{(1+it)/\\log q}} \\Psi(t)\\ dt,")]]

#text("and hence")

#tao-aligned(keep: true)[


#tao-math("\\mu f * 1(n)  & = \\int_{\\bf R} \\sum_{d|n} \\frac{\\mu(d)}{d^{(1+it)/\\log q}} \\Psi(t)\\ dt", block: true)



#tao-math(" & = \\int_{\\bf R} \\prod_{p^{\\prime}|n} (1 - \\frac{1}{(p^{\\prime})^{(1+it)/\\log q}})\\ \\Psi(t)\\ dt", block: true)
]

#text("and hence by the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("(\\mu f*1)(n(n+2)) \\ll_A \\int_{\\bf R} \\prod_{p^{\\prime}|n(n+2)} O( \\min( 1, (1+\\left|t\\right|) \\frac{\\log p^{\\prime}}{\\log q}) )\\ \\frac{dt}{(1+\\left|t\\right|)^A}", block: true)]]

#text("for any fixed ")#mi("{A>0}")#text(". Since ")#mi("{\\prod_{p^{\\prime}|n(n+2)} O(1) \\ll \\tau(n(n+2))^{O(1)}}")#text(", we can thus (after substituting ")#tao-math("{\\sigma := 1+\\left|t\\right|}", block: false)#text(") bound the left-hand side of ")#link(<tao-4c499dc1f10efacdd446>)[#text("(18)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\ll_A \\int_1^\\infty \\sum_{n: p|n(n+2); (n(n+2),W)=1} \\tau(n(n+2))^{O(1)} \\prod_{p^{\\prime}|n(n+2)} \\min( 1, \\sigma \\frac{\\log p^{\\prime}}{\\log q})\\ \\frac{d\\sigma}{\\sigma^A}")]]

#text("and so it will suffice to show the bound")

#metadata(none) <tao-66c3b491d0eb4fc07a81>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\sum_{n: p|n(n+2); (n(n+2),W)=1} \\tau(n(n+2))^{O(1)} \\prod_{p^{\\prime}|n(n+2)} \\min( 1, \\sigma \\frac{\\log p^{\\prime}}{\\log q}) \\psi_x(n)")]]

#align(center)[#tao-fit-display[#mitex("\\ll_C \\sigma^{O_C(1)} \\frac{\\log p}{p \\log q} x \\log^{-C-2} x")]]

#text("for any ")#mi("{\\sigma \\geq 1}")#text(" and ")#mi("{p \\leq 2x^{1-\\varepsilon}}")#text(".")

#text("We factor ")#mi("{n(n+2) = p_1 \\dots p_r}")#text(" where ")#mi("{w < p_1 \\leq \\dots \\leq p_r}")#text(" are primes, and then write ")#mi("{n(n+2) = dm}")#text(" where ")#mi("{d = p_1 \\dots p_i}")#text(" and ")#mi("{i}")#text(" is the largest index for which ")#mi("{p_1 \\dots p_i < x^{1/10}}")#text(". Clearly ")#mi("{0 \\leq i < r}")#text(" and ")#mi("{d < x^{1/10}}")#text(" with ")#mi("{(d,W)=1}")#text(", and the least prime factor ")#mi("{p(m) = p_{i+1}}")#text(" of ")#mi("{m}")#text(" is such that")

#align(center)[#tao-fit-display[#mitex("p_{i+1} \\geq (p_1 \\dots p_{i+1})^{1/(i+1)} \\geq x^{\\frac{1}{10(i+1)}};")]]

#text("we have ")#mi("{n(n+2) \\ll x^2}")#text(" on the support of ")#mi("{\\psi_x(n)}")#text(", and so")

#align(center)[#tao-fit-display[#mitex("r \\ll 1+i")]]

#text("and thus ")#mi("{\\tau(n(n+2)) \\ll \\exp( O(i) )}")#text(". Clearly we have")

#align(center)[#tao-fit-display[#mitex("\\prod_{p^{\\prime}|n(n+2)} \\min( 1, \\sigma \\frac{\\log p^{\\prime}}{\\log q}) \\leq \\prod_{p^{\\prime}|[p,d]} \\min( 1, \\sigma \\frac{\\log p^{\\prime}}{\\log q}).")]]

#text("We write ")#mi("{i = \\Omega(d)}")#text(", where ")#mi("{\\Omega(d)}")#text(" denotes the number of prime factors of ")#mi("{d}")#text(" counting multiplicity. We can thus bound the left-hand side of ")#link(<tao-66c3b491d0eb4fc07a81>)[#text("(19)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\ll \\sum_{d < x^{1/10}; (d,W)=1} \\exp( O( \\Omega(d) ) ) \\prod_{p^{\\prime}|[p,d]} \\min( 1, \\sigma \\frac{\\log p^{\\prime}}{\\log q})")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{n: [p,d]|n(n+2); p(\\frac{n(n+2)}{d}) \\geq x^{\\frac{1}{10(\\Omega(d)+1)}}} \\psi_x(n).")]]

#text("We may replace the ")#mi("{\\psi_x(n)}")#text(" weight with a restriction of ")#mi("{n}")#text(" to the interval ")#mi("{[x - O(x \\log^{-C} x), x + O(x \\log^{-C} x)]}")#text(". The constraint ")#mi("{p(\\frac{n(n+2)}{d}) \\geq x^{\\frac{1}{10(\\Omega(d)+1)}}}")#text(" removes two residue classes modulo every odd prime less than ")#mi("{x^{\\frac{1}{10(\\Omega(d)+1)}}}")#text(", while the constraint ")#mi("{[p,d]|n(n+2)}")#text(" restricts ")#mi("{n}")#text(" to ")#mi("{O( \\exp( O(\\Omega(d))))}")#text(" residue classes modulo ")#mi("{[p,d]}")#text(". Standard sieve theory then gives")

#align(center)[#tao-fit-display[#mitex("\\sum_{n: [p,d]|n(n+2); p(\\frac{n(n+2)}{d} \\geq x^{\\frac{1}{10(\\Omega(d)+1)}})} \\psi_x(n) \\ll \\exp( O(\\Omega(d))) \\frac{x}{[p,d]} \\log^{-C-2} x")]]

#text("and so we are reduced to showing that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d < x^{1/10}; (d,W)=1} \\frac{\\exp( O( \\Omega(d) ) )}{[p,d]} \\prod_{p^{\\prime}|[p,d]} \\min( 1, \\sigma \\frac{\\log p^{\\prime}}{\\log q}) \\ll \\sigma^{O(1)} \\frac{\\log p}{p \\log q}.")]]

#text("Factoring ")#mi("{d = p_1 \\dots p_i}")#text(", we can bound the left-hand side by")

#align(center)[#tao-fit-display[#mitex("\\ll \\frac{\\min(1, \\sigma \\frac{\\log p}{\\log q})}{p} \\prod_{w < p^{\\prime} < x^{1/10}: p^{\\prime} \\neq p} (1 + \\sum_{j=1}^\\infty \\frac{\\exp(O(j))}{(p^{\\prime})^j} \\min( 1, \\sigma \\frac{\\log p^{\\prime}}{\\log q}) )")]]

#text("which (for ")#mi("{w}")#text(" large enough) is bounded by")

#tao-aligned(keep: true)[


#tao-math(" & \\ll \\sigma \\frac{\\log p}{p \\log q} \\prod_{w < p^{\\prime} < x^{1/10}} (1 + O( \\frac{1}{p^{\\prime}} \\min( 1, \\sigma \\frac{\\log p^{\\prime}}{\\log q}) ) )", block: true)



#tao-math(" & \\ll \\sigma \\frac{\\log p}{p \\log q} \\exp( O( \\sum_{p^{\\prime} < x^{1/10}} \\frac{1}{p^{\\prime}} \\min( 1, \\sigma \\frac{\\log p^{\\prime}}{\\log q}) ) )", block: true)
]

#text("which by Mertens’ theorem is bounded by")

#align(center)[#tao-fit-display[#mitex("\\ll \\sigma \\frac{\\log p}{p \\log q} \\exp( O_C( \\log \\sigma ) )")]]

#text("and the claim follows.")

#text("For future reference we observe that the above arguments also establish the bound ")#metadata(none) <tao-0716ef0e157bed2d308b>#mi("\\displaystyle  \\sum_{n: (n(n+2),W)=1} \\tau(n (n+2))^{O(1)} |(\\mu f * 1)(n(n+2)| \\psi_x(n) \\ \\ \\ \\ \\ (20)")

#align(center)[#tao-fit-display[#mitex("\\ll_C \\frac{1}{\\log q} x \\log^{-C-2} x")]]

#text("and (if one replaces ")#mi("{x^{1/10}}")#text(" with ")#mi("{x^{\\varepsilon/10}}")#text(")")

#metadata(none) <tao-ff7578c6eb684c7130ae>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\sum_{n: p|n(n+2); (n(n+2),W)=1} \\tau(n (n+2))^{O(1)} |(\\mu f * 1)(n(n+2)| \\psi_x(n)")]]

#align(center)[#tao-fit-display[#mitex("\\ll_{C,\\varepsilon} \\frac{\\log p}{p \\log q} x \\log^{-C-2} x")]]

#text("for all ")#mi("{p \\leq 2x^{1-\\varepsilon}}")#text(".")

#text("Finally, we turn to ")#link(<tao-204956d3cf371c96017f>)[#text("(16)")]#text(". Using ")#link(<tao-b349f873812c3e0e0074>)[#text("(17)")]#text(" again, it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{x^\\varepsilon \\leq p \\geq 2x^{1-\\varepsilon}: \\chi(p) \\neq -1} \\sum_{n: p|n(n+2)} \\tau(n(n+2))^{O(1)} |(\\mu f * 1)(n(n+2)| \\psi_x(n)")]]

#align(center)[#tao-fit-display[#mitex("= o(x \\log^{-C-2} x).")]]

#text("The claim then follows from ")#link(<tao-ff7578c6eb684c7130ae>)[#text("(21)")]#text(" and Lemma ")#link(<tao-6e533337bd970a97d7ac>)[#text("5")]#text(".")

#text("It remains to prove ")#link(<tao-1293b1e32cdce358b4b4>)[#text("(12)")]#text(", which we write as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n: (n(n+2),W)=1} \\left(\\sum_{d|n(n+2)} \\chi(d) \\log^2 \\frac{n(n+2)}{d}\\right) (\\mu f * 1)(n(n+2)) \\psi_x(n)")]]

#align(center)[#tao-fit-display[#mitex("\\gg (1-o(1)) x \\log^{-C} x.")]]

#text("On the support of ")#mi("{\\psi_x(n)}")#text(", we can write")

#align(center)[#tao-fit-display[#mitex("\\log^2 \\frac{n(n+2)}{d} = \\log^2 \\frac{x^2}{d} + O( \\log^{-C+O(1)} x).")]]

#text("The contribution of the error term can be bounded by")

#align(center)[#tao-fit-display[#mitex("O( \\log^{-C+O(1)} x \\sum_n \\tau(n(n+2))^{O(1)} |(\\mu f * 1)(n(n+2))| \\psi_x(n) );")]]

#text("applying ")#link(<tao-0716ef0e157bed2d308b>)[#text("(20)")]#text(", this is bounded by ")#mi("{O( x \\log^{-2C+O(1)} x)}")#text(" which is acceptable for ")#mi("{C}")#text(" large enough. Thus it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n: (n(n+2),W)=1} (\\sum_{d|n(n+2)} \\chi(d) \\log^2 \\frac{x^2}{d}) (\\mu f * 1)(n(n+2)) \\psi_x(n)")]]

#align(center)[#tao-fit-display[#mitex("\\gg (1-o(1)) x \\log^{-C} x")]]

#text("which we write as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n:(n(n+2),W)=1} \\left(\\sum_{d|n(n+2)} \\chi(d) G( \\frac{\\log d}{\\log x} )\\right) (\\mu f * 1)(n(n+2)) \\psi_x(n)/")]]

#align(center)[#tao-fit-display[#mitex("\\gg (1-o(1)) x \\log^{-C-2} x")]]

#text("where ")#mi("{G(u) := (2-u)^2}")#text(". We split ")#mi("{G = G_< + G_\\sim + G_>}")#text(" where ")#mi("{G_<}")#text(", ")#mi("{G_\\sim}")#text(", ")#mi("{G_>}")#text(" are smooth truncations of ")#mi("{G}")#text(" to the intervals ")#mi("{(-\\infty,0.99)}")#text(", ")#mi("{(0.98, 1.02)}")#text(", and ")#mi("{(1.01, +\\infty)}")#text(" respectively. It will suffice to establish the bounds")

#metadata(none) <tao-074b164bd0cccd404fc4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\sum_{n:(n(n+2),W)=1} \\left(\\sum_{d|n(n+2)} \\chi(d) G_<( \\frac{\\log d}{\\log x} )\\right) (\\mu f * 1)(n(n+2)) \\psi_x(n)")]]

#align(center)[#tao-fit-display[#mitex("\\gg (1-o(1)) x \\log^{-C-2} x")]]

#metadata(none) <tao-31e657e92210ffaec05b>#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\sum_{n:(n(n+2),W)=1} \\left(\\sum_{d|n(n+2)} \\chi(d) G_\\sim( \\frac{\\log d}{\\log x} )\\right) (\\mu f * 1)(n(n+2)) \\psi_x(n)")]]

#align(center)[#tao-fit-display[#mitex("= o(x \\log^{-C-2} x)")]]

#metadata(none) <tao-8208e9605a9a70b8823a>#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\sum_{n: (n(n+2),W)=1} \\left(\\sum_{d|n(n+2)} \\chi(d) G_>( \\frac{\\log d}{\\log x} )\\right) (\\mu f * 1)(n(n+2)) \\psi_x(n)")]]

#align(center)[#tao-fit-display[#mitex("= o(x \\log^{-C-2} x)")]]

#text("We begin with ")#link(<tao-8208e9605a9a70b8823a>)[#text("(24)")]#text(", which is a relatively easy consequence of the cancellation properties of ")#mi("{\\chi}")#text(". We may rewrite the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\sum_e \\mu(e) f(e) \\sum_m \\sum_{n: (n(n+2),W)=1; [e,m] | n(n+2)} \\chi\\left(\\frac{n(n+2)}{m}\\right)")]]

#align(center)[#tao-fit-display[#mitex("G_>\\left( \\frac{\\log \\frac{n(n+2)}{m}}{\\log x} \\right) \\psi_x(n).")]]

#text("The summand vanishes unless ")#mi("{m \\ll x^{0.99}}")#text(", ")#mi("{e \\leq q}")#text(", and ")#mi("{[e,m]/m}")#text(" is coprime to ")#mi("{q}")#text(", so that ")#mi("{[e,m] \\ll q x^{0.99}}")#text(". For fixed ")#mi("{e,m}")#text(", the constraints ")#mi("{(n(n+2),W)=1}")#text(", ")#mi("{[e,m]|n(n+2)}")#text(" restricts ")#mi("{n}")#text(" to ")#mi("{O_w(x^{o(1)})}")#text(" residue classes of the form ")#mi("{a \\text{ mod } W[e,m]}")#text(", with ")#mi("{[e,m]|a(a+2)}")#text(", in particular ")#mi("{m_1 | a}")#text(" and ")#mi("{m_2 | a+2}")#text(" for some ")#mi("{m_1,m_2}")#text(" with ")#mi("{m = m_1 m_2}")#text(". Let us fix ")#mi("{e,m,a,m_1,m_2}")#text(" and consider the sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{n: n = a \\text{ mod } W[e,m]} \\chi(\\frac{n(n+2)}{m}) G_>( \\frac{\\log n(n+2)/m}{\\log x} ) \\psi_x(n).")]]

#text("Writing ")#mi("{n = k W[e,m] + a}")#text(", this becomes")

#align(center)[#tao-fit-display[#mitex("\\sum_k \\chi( \\frac{W[e,m]}{m_1} k + \\frac{a}{m_1} ) \\chi( \\frac{W[e,m]}{m_2} k + \\frac{a+2}{m_2} )")]]

#align(center)[#tao-fit-display[#mitex("G_>( \\frac{\\log (kW[e,m]+a)(kW[e,m]+a+2)/m}{\\log x} ) \\psi_x(kW[e,m]+a).")]]

#text("From Lemma ")#link(<tao-392eaffcf701523b013c>)[#text("3")]#text(", we have")

#tao-aligned(keep: true)[


#tao-math("\\sum_{k \\in {\\bf Z}/q{\\bf Z}} \\chi( \\frac{W[e,m]}{m_1} k + \\frac{a}{m_1} ) \\chi( \\frac{W[e,m]}{m_2} k + \\frac{a+2}{m_2} )  & \\ll x^{o(1)} (2 \\frac{W[e,m]}{m},q)", block: true)



#tao-math(" & \\ll x^{o(1)}", block: true)
]

#text("since ")#mi("{[e,m]/m}")#text(" is coprime to ")#mi("{q}")#text(". From summation by parts we thus have")

#align(center)[#tao-fit-display[#mitex("\\sum_k \\chi( \\frac{W[e,m]}{m_1} k + \\frac{a}{m_1} ) \\chi( \\frac{W[e,m]}{m_2} k + \\frac{a+2}{m_2} )")]]

#align(center)[#tao-fit-display[#mitex("G_>( \\frac{\\log (kW[e,m]+a)(kW[e,m]+a+2)/m}{\\log x} ) \\psi_x(kW[e,m]+a)")]]

#tao-aligned(keep: true)[


#tao-math(" & \\ll \\sup_{I: \\left|I\\right| \\ll x/[e,m]} \\left|\\sum_{k \\in I} \\chi( \\frac{W[e,m]}{m_1} k + \\frac{a}{m_1} ) \\chi( \\frac{W[e,m]}{m_2} k + \\frac{a+2}{m_2} ) \\right|", block: true)



#tao-math(" & \\ll x^{o(1)} \\frac{x}{q[e,m]} + q", block: true)



#tao-math(" & \\ll q^{-1} x^{o(1)} \\frac{x}{[e,m]}", block: true)
]

#text("(noting that ")#mi("{q \\ll \\frac{x}{q[e,m]}}")#text(" if ")#mi("{C}")#text(" is large enough) and so we can bound the left-hand side of ")#link(<tao-8208e9605a9a70b8823a>)[#text("(24)")]#text(" in magnitude by")

#tao-aligned(keep: true)[


#tao-math("q^{-1} x^{1+o(1)} \\sum_{e \\leq q} \\sum_{m \\ll x^{0.99}} \\frac{1}{[e,m]}  & \\ll q^{-1} x^{1+o(1)} \\sum_{d \\ll q x^{0.99}} \\frac{x^{o(1)}}{d}", block: true)



#tao-math(" & \\ll q^{-1} x^{1+o(1)}", block: true)
]

#text("and ")#link(<tao-8208e9605a9a70b8823a>)[#text("(24)")]#text(" follows.")

#text("Now we prove ")#link(<tao-31e657e92210ffaec05b>)[#text("(23)")]#text(", which is where we need nontrivial bounds on Kloosterman sums. Expanding out ")#mi("{\\mu f * 1}")#text(" and using the triangle inequality, it suffices (for ")#mi("{C}")#text(" large enough) to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n: (n(n+2),W)=1; r|n(n+2)} (\\sum_{d|n(n+2)} \\chi(d) G_\\sim( \\frac{\\log d}{\\log x} )) \\psi_x(n) \\ll q^{O(1)} x^{0.99+o(1)}")]]

#text("for all ")#mi("{r < q^{1/2}}")#text(". By Fourier expansion of the ")#mi("{r|n(n+2)}")#text(" and ")#mi("{(n(n+2),W)=1}")#text(" constraints (retaining only the restriction that ")#mi("{n}")#text(" is odd), it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\text{ odd}} (\\sum_{d|n(n+2)} \\chi(d) G_\\sim( \\frac{\\log d}{\\log x} )) \\psi_x(n) e( kn/Wr )\\ll q^{O(1)} x^{0.99+o(1)}")]]

#text("for every ")#mi("{k \\in {\\bf Z}/Wr{\\bf Z}}")#text(".")

#text("Fix ")#mi("{r,k}")#text(". If ")#mi("{d|n(n+2)}")#text(" for an odd ")#mi("{n}")#text(", then we can uniquely factor ")#mi("{d = d_1 d_2}")#text(" such that ")#mi("{d_1|n}")#text(", ")#mi("{d_2|n+2}")#text(", and ")#mi("{(d_1,d_2)=1}")#text(". It thus suffices to show that ")#metadata(none) <tao-d38080931d294994ce2d>#mi("\\displaystyle  \\sum_{d_1,d_2: (d_1,d_2)=1} \\chi(d_1) \\chi(d_2) G_\\sim( \\frac{\\log d_1 + \\log d_2}{\\log x} )) \\ \\ \\ \\ \\ (25)")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\text{ odd}: d_1|n; d_2|n+2}\\psi_x(n) e( kn/Wr)")]]

#align(center)[#tao-fit-display[#mitex("\\ll q^{O(1)} x^{0.99+o(1)}.")]]

#text("Actually, we may delete the condition ")#mi("{(d_1,d_2)=1}")#text(" since this is implied by the constraints ")#mi("{d_1|n, d_2|n+2}")#text(" and ")#mi("{n}")#text(" odd.")

#text("We first dispose of the case when ")#mi("{d_1}")#text(" is large in the sense that ")#mi("{d_1 \\geq x^{0.51}}")#text(". Making the change of variables ")#mi("{d_3 = n/d_1}")#text(", we may rewrite the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_3,d_2} \\chi(d_2) \\sum_{n \\text{ odd}: d_3|n; d_2|n+2} \\chi( \\frac{n}{d_3} ) G_\\sim( \\frac{\\log n - \\log d_3 + \\log d_2}{\\log x} )")]]

#align(center)[#tao-fit-display[#mitex("\\psi_x(n) e(kn/Wr).")]]

#text("We can assume ")#mi("{d_2}")#text(" is coprime to ")#mi("{q}")#text(" and ")#mi("{d_2,d_3}")#text(" odd with ")#mi("{d_3}")#text(" coprime to ")#mi("{d_2}")#text(" and ")#mi("{d_2,d_3 \\ll x^{0.49}}")#text(", as the contribution of all other cases vanish. The constraints that ")#mi("{n}")#text(" is odd and ")#mi("{d_3|n, d_2|n+2}")#text(" then restricts ")#mi("{n}")#text(" to a single residue class modulo ")#mi("{2 d_2 d_3}")#text(", with ")#mi("{n/d_3}")#text(" restricted to a single residue class modulo ")#mi("{2 d_2}")#text(". We split this into ")#mi("{Wr}")#text(" residue classes modulo ")#mi("{2Wd_2 r}")#text(" to make the ")#mi("{e(kn/Wr)}")#text(" phase constant on each residue class. The modulus ")#mi("{2Wd_2 r}")#text(" is not divisible by ")#mi("{q}")#text(", since ")#mi("{d_2}")#text(" is coprime to ")#mi("{q}")#text(" and ")#mi("{r \\leq \\sqrt{q}}")#text(". As such, ")#mi("{\\chi(\\frac{n}{d_3})}")#text(" has mean zero on every consecutive ")#mi("{q}")#text(" elements in each residue class modulo ")#mi("{2Wd_2 r}")#text(" under consideration, and from summation by parts we then have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\text{odd}: d_3|n; d_2|n+2} \\chi( \\frac{n}{d_3} ) G_\\sim( \\frac{\\log n - \\log d_3 + \\log d_2}{\\log x} ) \\psi_x(n) e(kn/Wr)")]]

#align(center)[#tao-fit-display[#mitex("\\ll q Wr")]]

#text("and hence the contribution of the ")#mi("{d_1 \\geq x^{0.51}}")#text(" case to ")#link(<tao-d38080931d294994ce2d>)[#text("(25)")]#text(" is")

#align(center)[#tao-fit-display[#mitex("\\ll \\sum_{d_3,d_2 \\ll x^{0.49}} q Wr \\ll q^{O(1)} x^{0.98}")]]

#text("which is acceptable.")

#text("It remains to control the contribution of the ")#mi("{d_1 < x^{0.51}}")#text(" case to ")#link(<tao-d38080931d294994ce2d>)[#text("(25)")]#text(". By the triangle inequality, it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_2} \\chi(d_2) G_\\sim( \\frac{\\log d_1 + \\log d_2}{\\log x} )) \\sum_{n \\text{odd}: d_1|n; d_2|n+2}\\psi_x(n) e(kn/Wr)")]]

#align(center)[#tao-fit-display[#mitex("\\ll q^{O(1)} x^{0.99+o(1)} / d_1")]]

#text("for all ")#mi("{d_1 < x^{0.51}}")#text(" coprime to ")#mi("{q}")#text(". We can of course restrict ")#mi("{d_1,d_2}")#text(" to be coprime to each other and to ")#mi("{W}")#text(". Writing ")#mi("{n+2 = d_2 (2m+1)}")#text(", the constraint ")#mi("{d_1|n}")#text(" is equivalent to")

#align(center)[#tao-fit-display[#mitex("m = \\overline{d_2} - \\overline{2} \\text{ mod } d_1")]]

#text("and so we can rewrite the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_2: (d_1,d_2)=1} \\chi(d_2) G_\\sim( \\frac{\\log d_1 + \\log d_2}{\\log x} ))")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{m = \\overline{d_2} - \\overline{2} \\text{ mod } d_1} \\psi_x(d_2 (2m+1)-2) e(k(d_2(2m+1))/Wr) e(-2k/Wr).")]]

#text("By Fourier expansion, we can write ")#mi("{\\chi(d_2)}")#text(" as a linear combination of ")#mi("{e( l d_2 / q)}")#text(" with bounded coefficients and ")#mi("{(l,q)=1}")#text(", so it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_2: (d_1,d_2)=1} e(ld_2/q) G_\\sim( \\frac{\\log d_1 + \\log d_2}{\\log x} ))")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{m = \\overline{d_2} - \\overline{2} \\text{ mod } d_1} \\psi_x(d_2 (2m+1)-2) e( 2kd_2 m / Wr )")]]

#align(center)[#tao-fit-display[#mitex("\\ll q^{O(1)} x^{0.99+o(1)} / d_1.")]]

#text("Next, by Fourier expansion of the constraint ")#mi("{m = \\overline{d_2} - \\overline{2} \\text{ mod } d_1}")#text(", we write the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{d_1} \\sum_{h \\in {\\bf Z}/d_1 {\\bf Z}} \\sum_{d_2: (d_1 d_2)=1} e(ld_2/q) G_\\sim( \\frac{\\log d_1 + \\log d_2}{\\log x} )) e( h(\\overline{d_2} - \\overline{2})/d_1)")]]

#align(center)[#tao-fit-display[#mitex("\\sum_m e(-hm/d_1) \\psi_x(d_2 (2m+1)-2) e( 2kd_2 m / Wr ).")]]

#text("From Poisson summation and the smoothness of ")#mi("{\\psi}")#text(", we see that the inner sum is ")#mi("{O(x^{-100})}")#text(" unless")

#metadata(none) <tao-850f9ef8d53cf476852c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#tao-math("\\left\\| \\frac{h}{d_1} - \\frac{c}{Wr} \\right\\| \\ll \\frac{x^{0.01}d_2}{x}", block: true)]]

#text("for some integer ")#mi("{c}")#text(", where ")#tao-math("{\\left\\|\\theta\\right\\|}", block: false)#text(" denotes the distance from ")#mi("{\\theta}")#text(" to the nearest integer. The contribution of the ")#mi("{h}")#text(" which do not satisfy this relation is easily seen to be acceptable. From the support of ")#mi("{G_\\sim}")#text(" we see in particular that there are only ")#mi("{O( r x^{0.03} )}")#text(" remaining choices for ")#mi("{h}")#text(". Thus it suffices by the triangle inequality to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_2: (d_1 d_2)=1} e(ld_2/q) G_\\sim( \\frac{\\log d_1 + \\log d_2}{\\log x} )) e( h\\overline{d_2}/d_1)")]]

#align(center)[#tao-fit-display[#mitex("\\sum_m e(-hm/d_1) \\psi_x(d_2 (2m+1)-2) e( 2kd_2 m / Wr )")]]

#align(center)[#tao-fit-display[#mitex("\\ll q^{O(1)} x^{0.95}")]]

#text("for each ")#mi("{h \\in {\\bf Z}/d_1{\\bf Z}}")#text(" of the form ")#link(<tao-850f9ef8d53cf476852c>)[#text("(26)")]#text(".")

#text("We rearrange the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\sum_m e(-hm/d_1) \\sum_{d_2: (d_1 d_2)=1} e(kd_2/q) G_\\sim( \\frac{\\log d_1 + \\log d_2}{\\log x} )) e( h\\overline{d_2}/d_1)")]]

#align(center)[#tao-fit-display[#mitex("e( 2kd_2 m / Wr ) \\psi_x(d_2 (2m+1)-2).")]]

#text("Suppose first that ")#mi("{h/d_1}")#text(" is of the form ")#mi("{c/Wr}")#text(" for some integer ")#mi("{c}")#text(". Then the phase ")#mi("{d_2 \\mapsto e(kd_2/q) e( h\\overline{d_2}/d_1) e( 2kd_2 m / Wr )}")#text(" is periodic with period ")#mi("{Wqr}")#text(" and has mean zero here (since ")#mi("{Wr<q}")#text("). From this, we can estimate the inner sum by ")#mi("{O( Wqr )}")#text("; since ")#mi("{m}")#text(" is restricted to be of size ")#mi("{O( x / d_2 ) = O( x^{0.02} d_1 ) = O( x^{0.53} )}")#text(", this contribution is certainly acceptable. Thus we may assume that ")#mi("{h/d_1}")#text(" is not of the form ")#mi("{c/Wr}")#text(". A similar argument works when ")#mi("{d_1 \\leq x^{0.4}}")#text(" (say), so we may assume that ")#mi("{d_1 \\geq x^{0.4}}")#text(", so that ")#mi("{d_2 \\ll x^{0.6}}")#text(".")

#text("By ")#link(<tao-850f9ef8d53cf476852c>)[#text("(26)")]#text(", this forces the denominator of ")#mi("{h/d_1}")#text(" in lowest form to be ")#mi("{\\gg \\frac{x}{x^{0.01} d_2 Wr} \\gg q^{-O(1)} x^{0.39}}")#text(". By Lemma ")#link(<tao-aced042cecce971f8296>)[#text("2")]#text(", we thus have")

#tao-aligned(keep: true)[


#tao-math("\\sum_{d_2 \\in ({\\bf Z}/d_1{\\bf Z})^\\times} e( a d_2/d_1) e( h\\overline{d_2}/d_1)  & \\ll x^{o(1)} d_2 ( q^{-O(1)} x^{0.39} )^{-1/4}", block: true)



#tao-math(" & \\ll q^{O(1)} x^{-0.09} d_2", block: true)
]

#text("for any ")#mi("{a}")#text(", so from Poisson summation we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_2: (d_1 d_2)=1} e(kd_2/q) G_\\sim( \\frac{\\log d_1 + \\log d_2}{\\log x} )) e( h\\overline{d_2}/d_1) e( 2kd_2 m / Wr )")]]

#align(center)[#tao-fit-display[#mitex("\\psi_x(d_2 (2m+1)-2) \\ll q^{O(1)} x^{-0.07} \\frac{x}{d_1};")]]

#text("since ")#mi("{m}")#text(" is constrained to be ")#mi("{O( x^{0.02} d_1 )}")#text(", the claim follows.")

#text("Finally, we prove ")#link(<tao-074b164bd0cccd404fc4>)[#text("(22)")]#text(", which is a routine sieve-theoretic calculation. We rewrite the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d,e} \\chi(d) G_<(\\frac{\\log d}{\\log x}) \\mu(e) f(e) \\sum_n 1_{n: (n(n+2),W)=1; [d,e] | n(n+2)} \\psi_x(n).")]]

#text("The summand vanishes unless ")#mi("{d,e}")#text(" are coprime to ")#mi("{W}")#text(" with ")#mi("{d \\ll x^{0.52}}")#text(" and ")#mi("{e \\leq \\sqrt{q}}")#text(". From Poisson summation one then has")

#tao-aligned(keep: true)[


#tao-math("\\sum_n 1_{m: (n(n+2),W)=1; [d,e] | n(n+2)} \\psi_x(n)  & = \\frac{1}{2} (\\prod_{2 < p \\leq w} (1-\\frac{2}{p})) (\\int_{\\bf R} \\psi) \\frac{x \\log^{-C} x 2^{\\omega([d,e])}}{[d,e]}", block: true)



#tao-math(" & + O( x^{-100} ).", block: true)
]

#text("The error term is certainly negligible, so it suffices to show that")

#align(center)[#tao-fit-display[#mitex("(\\prod_{2 < p \\leq w} (1-\\frac{2}{p})) \\sum_{d,e: (de,W)=1} \\chi(d) G_<(\\frac{\\log d}{\\log x}) \\mu(e) \\psi(\\frac{\\log e}{\\log q}) \\frac{2^{\\omega([d,e])}}{[d,e]}")]]

#align(center)[#tao-fit-display[#mitex("\\gg (1-o(1)) \\log^{-2} x.")]]

#text("We can control the left-hand side by Fourier analysis. Writing")

#align(center)[#tao-fit-display[#mitex("e^u G_<(u) = \\int_{\\bf R} g(t) e^{-itu}\\ dt")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("e^u \\psi(u) = \\int_{\\bf R} \\Psi(t) e^{-itu}\\ dt")]]

#text("for some rapidly decreasing functions ")#mi("{g,\\Psi}")#text(", the left-hand side may be expressed as")

#align(center)[#tao-fit-display[#mitex("(\\prod_{2 < p \\leq w} (1-\\frac{2}{p})) \\int_{\\bf R} \\int_{\\bf R} \\sum_{d,e: (de,W)=1} \\frac{\\chi(d) \\mu(e)2^{\\omega([d,e])}}{[d,e] d^{\\frac{1+it_1}{\\log x}} e^{\\frac{1+it_2}{\\log q}}}\\ g(t_1) \\Psi(t_2)\\ dt_1 dt_2")]]

#text("which factors as")

#metadata(none) <tao-da5a8f087a8fa04585e2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\int_{\\bf R} \\int_{\\bf R} \\prod_p E_p( \\frac{1+it_1}{\\log x}, \\frac{1+it_2}{\\log q} ) \\ g(t_1) \\Psi(t_2)\\ dt_1 dt_2")]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("E_2(s_1,s_2)  & := 1", block: true)



#tao-math("E_p(s_1,s_2)  & := 1 - \\frac{2}{p}", block: true)
]

#text("for ")#mi("{p \\leq w}")#text(", and")

#align(center)[#tao-fit-display[#mitex("E_p(s_1,s_2) := 1 - 2\\frac{1}{p^{1+s_2}} + 2\\sum_{j=1}^\\infty \\frac{\\chi(p)^j}{p^{j(1+s_1)}} (1 - \\frac{1}{p^{s_2}})")]]

#text("for ")#mi("{p>w}")#text(". From Mertens’ theorem we have the crude bound")

#align(center)[#tao-fit-display[#mitex("\\prod_p E_p( \\frac{1+it_1}{\\log x}, \\frac{1+it_2}{\\log q} ) \\ll \\log^{O(1)} x")]]

#text("which by the rapid decrease of ")#mi("{g,\\Psi}")#text(" allows one to restrict to the range ")#tao-math("{\\left|t_1\\right|, \\left|t_2\\right| \\leq \\sqrt{\\log q}}", block: false)#text(" with an error of ")#mi("{o(\\log^{-1} x)}")#text(". In particular, we now have ")#mi("{s_1,s_2 = o(1)}")#text(".")

#text("Recalling that")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) = \\prod_p (1 - \\frac{1}{p^s})^{-1}")]]

#text("for ")#mi("{\\text{Re}(s)>1}")#text(", we can factor")

#align(center)[#tao-fit-display[#mitex("\\prod_p E_p( s_1, s_2 ) = \\frac{\\zeta^2(1 + s_1+s_2)}{\\zeta^2(1+s_1) \\zeta^2(1+s_2)} \\prod_p E^{\\prime}_p(s_1,s_2) E^{\\prime\\prime}_p(s_1,s_2)")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("E^{\\prime\\prime}_p(s_1,s_2) := 1 + 1_{p>3} \\times 2 (\\frac{1+\\chi(p)}{p^{1+s_1}} - \\frac{1+\\chi(p)}{p^{1+s_1+s_2}})")]]

#text("(the restriction ")#mi("{p>3}")#text(" being to prevent ")#mi("{E^{\\prime\\prime}_p(s_1,s_2)}")#text(" vanishing for ")#mi("{p=2,3}")#text(" and ")#mi("{s_1,s_2}")#text(" small) and one has")

#align(center)[#tao-fit-display[#mitex("E^{\\prime}_p(s_1,s_2) = 1 + O( \\frac{1}{p^{2+o(1)}} )")]]

#text("for ")#mi("{s_1,s_2 = o(1)}")#text(", and")

#align(center)[#tao-fit-display[#mitex("E_2(0,0) = 2")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("E_p(0,0) = 1")]]

#text("for odd ")#mi("{p}")#text(". In particular, from the Cauchy integral formula we see that")

#align(center)[#tao-fit-display[#mitex("\\prod_p E^{\\prime}_p(s_1,s_2) = 2 + o(1)")]]

#text("for ")#mi("{s_1,s_2 = o(1)}")#text(". Since we also have ")#mi("{\\zeta(1+s) = \\frac{1+o(1)}{s}}")#text(" in this region, we thus can write ")#link(<tao-da5a8f087a8fa04585e2>)[#text("(27)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|t_1\\right|, \\left|t_2\\right| \\leq \\sqrt{\\log q}} (1+o(1)) \\prod_p E^{\\prime\\prime}_p(s_1,s_2) \\frac{(1+it_2)^2 (1+it_1)^2}{(1+it_2 + \\frac{1+it_1}{C})^2 \\log^2 x}", block: true)]]

#align(center)[#tao-fit-display[#mitex("g(t_1) \\Psi(t_2) dt_1 dt_2 + o(\\log^{-2} x)")]]

#text("and our task is now to show that")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|t_1\\right|, \\left|t_2\\right| \\leq \\sqrt{\\log q}} (1+o(1)) \\prod_p E^{\\prime\\prime}_p(s_1,s_2) \\frac{(1+it_2)^2 (1+it_1)^2}{(1+it_2 + \\frac{1+it_1}{C})^2}", block: true)]]

#align(center)[#tao-fit-display[#mitex("g(t_1) \\Psi(t_2) dt_1 dt_2 \\gg 1 - o(1).")]]

#text("We have")

#align(center)[#tao-fit-display[#mitex("\\log E^{\\prime\\prime}_p(s_1,s_2) = O(1/p)")]]

#text("when ")#mi("{s_1,s_2 = O(\\frac{1}{\\log p})}")#text(" (even when ")#mi("{s_1,s_2}")#text(" have negative real part); since ")#mi("{\\log E^{\\prime\\prime}_p(0,0)=0}")#text(", we conclude from the Cauchy integral formula that")

#align(center)[#tao-fit-display[#tao-math("\\log E^{\\prime\\prime}_p(s_1,s_2) \\ll (\\left|s_1\\right|+\\left|s_2\\right|) \\frac{\\log p}{p}", block: true)]]

#text("when ")#tao-math("{\\log p \\ll \\frac{1}{\\left|s_1\\right|+\\left|s_2\\right|}}", block: false)#text(". For the remaining primes ")#mi("{p}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\log E^{\\prime\\prime}_p(s_1,s_2) \\ll \\frac{1+\\chi(p)}{p^{1+1/\\log x}}")]]

#text("when ")#mi("{s_1 = \\frac{1+it_1}{\\log x}}")#text(" and ")#mi("{s_2 := \\frac{1+it_2}{\\log q}}")#text(". Summing in ")#mi("{p}")#text(" using Lemma ")#link(<tao-6e533337bd970a97d7ac>)[#text("5")]#text(" to handle those ")#mi("{p}")#text(" between ")#mi("{q}")#text(" and ")#mi("{x}")#text(", and Mertens’ theorem and the trivial bound ")#mi("{1+\\chi(p)=O(1)}")#text(" for all other ")#mi("{p}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_p \\log E^{\\prime\\prime}_p(s_1,s_2) \\ll \\log( 2+\\left|s_1\\right|+\\left|s_2\\right| )", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\prod_p E^{\\prime\\prime}_p(s_1,s_2) \\ll (2 + \\left|s_1\\right| + \\left|s_2\\right| )^{O(1)}.", block: true)]]

#text("From this and the rapid decrease of ")#mi("{g,\\Psi}")#text(", we may restrict the range of ")#mi("{t_1,t_2}")#text(" even further to ")#tao-math("{\\left|t_1\\right|, \\left|t_2\\right| \\leq \\omega(q)}", block: false)#text(" for any ")#mi("{\\omega(q)}")#text(" that goes to infinity arbitrarily slowly with ")#mi("{q}")#text(". For sufficiently slow ")#mi("{\\omega}")#text(", the above estimates on ")#mi("{\\log E^{\\prime\\prime}_p(s_1,s_2)}")#text(" and Lemma ")#link(<tao-6e533337bd970a97d7ac>)[#text("5")]#text(" (now used to handle those ")#mi("{p}")#text(" between ")#mi("{q^\\varepsilon}")#text(" and ")#mi("{x^{1/\\varepsilon}}")#text(" for some ")#mi("{\\varepsilon}")#text(" going sufficiently slowly to zero) give")

#align(center)[#tao-fit-display[#mitex("\\sum_p \\log E^{\\prime\\prime}_p(s_1,s_2) = o(1)")]]

#text("and so we are reduced to establishing that")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|t_1\\right|, \\left|t_2\\right| \\leq \\omega(q)} (1+o(1)) \\frac{(1+it_2)^2 (1+it_1)^2}{(1+it_2 + \\frac{1+it_1}{C})^2}\\ g(t_1) \\Psi(t_2) dt_1 dt_2 \\gg 1 - o(1).", block: true)]]

#text("We may once again use the rapid decrease of ")#mi("{g,\\Psi}")#text(" to remove the ")#mi("{o(1)}")#text(" prefactor as well as the restrictions ")#tao-math("{\\left|t_1\\right|, \\left|t_2\\right| \\leq \\omega(q)}", block: false)#text(", and reduce to showing that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\int_{\\bf R} \\frac{(1+it_2)^2 (1+it_1)^2}{(1+it_2 + \\frac{1+it_1}{C})^2}\\ g(t_1) \\Psi(t_2) dt_1 dt_2 \\gg 1 - o(1).")]]

#text("For ")#mi("{C}")#text(" large enough, it will suffice to show that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\int_{\\bf R} (1+it_1)^2\\ g(t_1) \\Psi(t_2) dt_1 dt_2 \\gg 1")]]

#text("with the implied constant independent of ")#mi("{C}")#text(". But the left-hand side evaluates to ")#mi("{G^{\\prime\\prime}_<(0) \\psi(0) = 2 \\psi(0)}")#text(", and the claim follows.")

#heading(level: 1)[#text("Comments (76)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-458488")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2015")])]

#text("Is there any known probabilistic argument for the existence/ nonexistence of Siegel zeros?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-458498")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2015")])]

#text("Probabilistic arguments (in particular, the Mobius pseudorandomness principle, discussed in ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("this previous post")]#text(") suggest that the generalised Riemann Hypothesis (GRH) is true, which can be viewed as the polar opposite of having a Siegel zero (certainly the two statements are incompatible). As such, the Siegel zero problem is really quite tantalising; it is the strongest surviving alternative to the conjectural picture we have about the distribution of the primes, and eliminating it would be viewed as a significant advance towards the GRH (although there would still be a lot further to go to finish that off entirely). (Historically, there were GRH alternatives that were even stronger than the Siegel zero, such as the “tenth discriminant”, but these at least have been eliminated, though not without quite a bit of effort.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04f8d9a424c4460454c4c44060831730b706d9d246787736f8709ed38e886d57-32261be2c0eac38e4e79f0537e764718ca0345af38c0afaf977babcdc52a9f97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergei")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-458865")[#strong[#text("Sergei")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2015")])]

#text("It is an interesting idea to use an unsquared Selberg sieve.")#linebreak()#text(" In fact, on the generalized Elliott-Halberstam conjecture")#linebreak()#text(" an unsquared Selberg sieve weight does correlate with the MÃ¶bius function,")#linebreak()#text(" and this can be used to deduce the twin prime conjecture from")#linebreak()#text(" the generalized Elliott-Halberstam conjecture.")

#text("The idea is to use the unsquared sieve weight")

#mi("\\displaystyle  R(\\lambda) := \\lambda - \\lambda ( 1_{{\\mathcal P}_1\\cup{\\mathcal P}_3\\cup\\dots } (n+h_1) 1_{{\\mathcal P}_2\\cup{\\mathcal P}_4\\cup\\dots } (n+h_2) + 1_{{\\mathcal P}_2\\cup{\\mathcal P}_4\\cup\\dots } (n+h_1) 1_{{\\mathcal P}_1\\cup{\\mathcal P}_3\\cup\\dots }(n+h_2) ),")

#text("where ")#mi("{1_{S}(n)}")#text(" is the indicator function of ")#mi("S")#text(" and ")#mi("{{\\mathcal P}_r}")#text(" is the set of squarefree integers")#linebreak()#text(" which have exactly ")#mi("r")#text(" prime factors.")

#text("Now assume the generalized Elliott-Halberstam conjecture, and let ")#mi("{0 < c < 1}")#text(" be a real number to be chosen later.")#linebreak()#text(" Define the function ")#mi("{(f)_{{+}}}")#text(" to be ")#mi("f")#text(" when ")#mi("f")#text(" is positive, and ")#mi("0")#text(" otherwise.")

#text("Take")

#mi("\\displaystyle  f(x,y) := (c-x)_{{+}}(c-y)_{{+}}.")

#text("Consider the weighted expression")

#mi("\\displaystyle  \\sum_{N\\leq n\\leq 2N,\\ n\\equiv b\\ (W)} R(\\lambda_{f}(n))")

#mi("\\displaystyle  \\times (\\theta(n+h_1)+\\theta(n+h_2)-\\log 3N)")

#text("where")

#mi("\\displaystyle  \\lambda_{f}(n) := \\sum_{d_1 | (n+h_1),\\ d_2 | (n+h_2)}\\mu(d_1)\\mu(d_2) f(\\frac{\\log d_1}{\\log N},\\frac{\\log d_2}{\\log N}).")

#text("Using Theorems 3.5, 3.6 of Polymath8b, it can be shown that")

#mi("\\displaystyle  \\sum_{N\\leq n\\leq 2N,\\ n\\equiv b\\ (W)}\\lambda_{f}(n)")

#mi("\\displaystyle  \\times (\\theta(n+h_1)+\\theta(n+h_2)-\\log 3N)")

#mi("\\displaystyle  = (I+o(1))\\frac{WN}{\\varphi^2(W)\\log N}")

#text("for ")#mi("{I > 0}")#text(" fixed if ")#mi("c")#text(" is close enough to ")#mi("1")#text(".")#linebreak()#text(" (note that integers for which ")#mi("n+h_1")#text(" or ")#mi("n+h_2")#text(" has a small prime factor give negligible contribution).")

#text("According to Chapter 16 of Friedlander-Iwaniec, if there are no pairs ")#mi("n+h_1")#text(" prime, ")#mi("n+h_2")#text(" prime, then")

#mi("\\displaystyle  1_{{\\mathcal P}_1\\cup{\\mathcal P}_3\\cup\\dots }(n+h_1)1_{{\\mathcal P}_2\\cup{\\mathcal P}_4\\cup\\dots }(n+h_2) + 1_{{\\mathcal P}_2\\cup{\\mathcal P}_4\\cup\\dots }(n+h_1)1_{{\\mathcal P}_1\\cup{\\mathcal P}_3\\cup\\dots }(n+h_2)")

#text("has a completely determined distribution function, so we can compute that")

#mi("\\displaystyle  \\sum_{N\\leq n\\leq 2N,\\ n\\equiv b\\ (W)} -\\lambda_{f}(n)")

#mi("\\displaystyle  \\times (1_{{\\mathcal P}_1\\cup{\\mathcal P}_3\\cup\\dots }(n+h_1)1_{{\\mathcal P}_2\\cup{\\mathcal P}_4\\cup\\dots }(n+h_2)+1_{{\\mathcal P}_2\\cup{\\mathcal P}_4\\cup\\dots }(n+h_1)1_{{\\mathcal P}_1\\cup{\\mathcal P}_3\\cup\\dots }(n+h_2))")

#mi("\\displaystyle  \\times (\\theta(n+h_1)+\\theta(n+h_2)-\\log 3N)")

#mi("\\displaystyle  \\geq (-\\varepsilon(c)+o(1))\\frac{WN}{\\varphi^2(W)\\log N},")

#text("where ")#mi("{\\varepsilon(c)\\to 0}")#text(" as ")#mi("{c\\to 1}")#text(".")

#text("Choosing ")#mi("c")#text(" close enough to ")#mi("1")#text(",")#linebreak()#text(" we get ")#mi("{I-\\varepsilon(c) > 0}")#text(" and hence")

#mi("\\displaystyle  1_{{\\mathcal P}_1\\cup{\\mathcal P}_3\\cup\\dots }(n+h_1)1_{{\\mathcal P}_1\\cup{\\mathcal P}_3\\cup\\dots }(n+h_2)+1_{{\\mathcal P}_2\\cup{\\mathcal P}_4\\cup\\dots }(n+h_1)1_{{\\mathcal P}_2\\cup{\\mathcal P}_4\\cup\\dots }(n+h_2)")

#text("has a nonzero distribution function, and again by Chapter 16 of Friedlander-Iwaniec")#linebreak()#text(" it follows that")

#mi("\\displaystyle  1_{{\\mathcal P}_1}(n+h_1)1_{{\\mathcal P}_1}(n+h_2)")

#text("has a nonzero distribution function.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-458870")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2015")])]

#text("I think that if you do the calculations carefully (in particular paying attention to the main terms that are not directly treatable by GEH, coming from convolutions in which one factor is supported very close to the origin or which otherwise fails to obey a Siegel-Walfisz condition), you will find that ")#mi("\\varepsilon(c)")#text(" converges to I, not to 0, as ")#mi("c \\to 1")#text(".")

#text("For the twin prime problem, even with GEH, one has the parity problem scenario in which ")#mi("\\lambda(n) = - \\lambda(n+2)")#text(" for all (or almost all) ")#mi("n")#text(" for which ")#mi("n,n+2")#text(" are almost prime (here ")#mi("\\lambda")#text(" is the Liouville function, not the sieve weight). In this scenario there are essentially no twin primes (since for such primes ")#mi("p")#text(" one has ")#mi("\\lambda(p)=\\lambda(p+2)=-1")#text("), and your weight ")#mi("1_{{\\mathcal P}_1 \\cup \\dots}(n) 1_{{\\mathcal P}_2 \\cup \\dots}(n+2) + 1_{{\\mathcal P}_2 \\cup \\dots}(n) 1_{{\\mathcal P}_1 \\cup \\dots}(n+2)")#text(" is essentially equal to 1. This scenario is consistent with GEH (assuming Mobius pseudorandomness) and with all other known inputs available to sieve theory, including those in Friedlander-Iwaniec. From the work of Bomberi we know that (on EH) this scenario is essentially the only scenario in which we have essentially no twin primes.")

#text("Personally, I advise against spending too much time on trying to attack the twin prime conjecture under hypotheses such as GEH unless you can pinpoint the precise input you are using (or hope to use) which breaks the parity barrier by being incompatible (at least from a heuristic, moral, or conjectural standpoint) with the ")#mi("\\lambda(n)=-\\lambda(n+2)")#text(" scenario. (For instance, in the current blog post it is Lemma 3 which is providing the incompatibility, because the Siegel zero forces ")#mi("\\lambda")#text(" to behave like ")#mi("\\chi")#text(" on almost primes, and Lemma 3 (plus some sieve theory) precludes the ")#mi("\\chi(n) = - \\chi(n+2)")#text(" scenario on such almost primes.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergei")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-458892")[#strong[#text("Sergei")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2015")])]

#text("Yes, the weight ")#mi("1_{{\\mathcal P}_1 \\cup \\dots}(n) 1_{{\\mathcal P}_2 \\cup \\dots}(n+2) + 1_{{\\mathcal P}_2 \\cup \\dots}(n) 1_{{\\mathcal P}_1 \\cup \\dots}(n+2)")#text(" is essentially equal to ")#mi("1")#text(" in this unique scenario, but in this scenario the unsquared weight ")#mi("\\lambda_{f}(n)")#text(" is essentially equal to ")#mi("0")#text(" on the primes ")#mi("p")#text(" for which ")#mi("\\lambda(p)=-\\lambda(p+2)")#text(". It is different from the weight in the squared Selberg sieve, which is NOT essentially equal to ")#mi("0")#text(" in this case?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-458894")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2015")])]

#text("Actually, I don’t think ")#mi("\\lambda_f")#text(" is all that small on those primes ")#mi("p")#text(" for which ")#mi("\\lambda(p) = - \\lambda(p+2)")#text(" (note that ")#mi("p+2")#text(" will likely have some prime factors less than ")#mi("x^{1-c}")#text("; this is a subtlety that also shows up in Bombieri’s analysis… one can insert a further sieve to eliminate extremely small prime factors, but not factors of size near ")#mi("x^{1-c}")#text(" unless one damps the function ")#mi("f")#text(" to a higher order near ")#mi("1-c")#text("). Indeed, Mobius pseudorandomness heuristics predict that ")#mi("\\lambda_f(n)")#text(" will be asymptotically orthogonal to ")#mi("\\lambda(n+2)")#text(" (whether one restricts ")#mi("n")#text(" to be prime or not) and so the value of ")#mi("\\lambda(n+2)")#text(" should have essentially no influence on the behaviour of ")#mi("\\lambda_f(n)")#text(".")

#text("To repeat my previous comment, the parity problem is not an obstacle to be taken lightly. If you haven’t identified a precise input in your argument which is explicitly getting around the parity barrier (basically, one needs to somehow control a sum of an expression that has a nontrivial correlation with ")#mi("\\lambda(n) \\lambda(n+2)")#text(", which none of the standard sieve weights do even when weighted by ")#mi("\\theta(n)")#text(" or ")#mi("\\theta(n+2)")#text("), the chances are overwhelmingly likely that there is going to be an error in your analysis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergei")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-458926")[#strong[#text("Sergei")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2015")])]

#text("I absolutely agree that the parity barrier is a very serious problem. It is not entirely clear where is the moral difference between the 2-dimensional weights")

#mi("\\displaystyle  \\lambda_{f_1}(n) := \\sum_{d_1 | n,\\ d_2 | (n+2)}\\mu(d_1)\\mu(d_2) f_1(\\frac{\\log d_1}{\\log N},\\frac{\\log d_2}{\\log N})")

#text("where")

#mi("\\displaystyle  f_1(x,y) := (c-x)_{{+}}(c-y)_{{+}}")

#text("and")

#mi("\\displaystyle  \\lambda_{f_2}(n)^2 := \\left( \\sum_{d_1 | n,\\ d_2 | (n+2)}\\mu(d_1)\\mu(d_2) f_2(\\frac{\\log d_1}{\\log N},\\frac{\\log d_2}{\\log N})\\right)^2")

#text("where")

#mi("\\displaystyle  f_2(x,y) := (c/2-x)_{{+}}(c/2-y)_{{+}}.")

#text("I don’t quite see how ")#mi("\\lambda_{f_1}(p)")#text(" could be large when ")#mi("p+2")#text(" has one (say) prime factor less than ")#mi("x^{1-c}")#text(". But it is clear that ")#mi("\\lambda_{f_2}(p)^2")#text(" could be large when ")#mi("p+2")#text(" has one prime factor less than ")#mi("x^{1-c/2}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-458936")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2015")])]

#text("Note that ")#mi("\\lambda_{f_1}(n)")#text(" factors as ")#mi("\\alpha(n) \\alpha(n+2)")#text(", where ")#mi("\\alpha(n) := \\sum_{d|n} (c - \\frac{\\log d}{\\log N})_+ \\mu(d)")#text(". Next, since")

#mi("\\sum_{d|n} (c - \\frac{\\log d}{\\log N}) \\mu(d) = \\frac{1}{\\log N} \\Lambda(n)")

#text("we can write")

#mi("\\alpha(n) = \\frac{1}{\\log N} \\Lambda(n) + \\sum_{d|n} (\\frac{\\log d}{\\log N} - c)_+ \\mu(d)")

#text("which on replacing ")#mi("d")#text(" by ")#mi("n/d")#text(" is essentially (assuming ")#mi("n")#text(" squarefree and close to ")#mi("N")#text(" for simplicity)")

#mi("\\alpha(n) \\approx \\frac{1}{\\log N} \\Lambda(n) + \\lambda(n) \\sum_{d|n} ((1-c) - \\frac{\\log d}{\\log N})_+ \\mu(d).")

#text("If ")#mi("1-c = \\varepsilon")#text(", the latter term is roughly speaking like ")#mi("\\varepsilon \\lambda(n)")#text(" restricted to those numbers that are ")#mi("N^\\varepsilon")#text("-rough (have no prime factors much smaller than ")#mi("N^\\varepsilon")#text("). This latter set of numbers is larger than the set of primes by a factor of about ")#mi("1/\\varepsilon")#text(". So, while ")#mi("\\alpha")#text(" is of size about 1 on primes, it is also of size about ")#mi("\\varepsilon")#text(" on a set of size about ")#mi("1/\\varepsilon")#text(" larger than the primes, and the net contribution of this set is of equal strength (in an L^1 sense) to the contribution on primes. (It may be small in an ")#mi("L^\\infty")#text(" sense, but it is the ")#mi("L^1")#text(" size which is the most relevant for these computations.) For instance, it is an instructive exercise to compute ")#mi("\\sum_{n \\leq N} \\alpha(n) \\lambda(n)")#text(" and find out that this is rather small (as is predicted from the Mobius pseudorandomness principle – ")#mi("\\alpha")#text(" has to give an equal weight to numbers with an odd number of prime factors, and numbers with an even number of prime factors), even though the contribution coming from the primes (or even from all of the numbers with all prime factors larger than ")#mi("N^{1-c}")#text(") is quite large.")

#text("Returning to ")#mi("\\lambda_{f_1}(n) = \\alpha(n) \\alpha(n+2)")#text(", we now see that ")#mi("\\lambda_{f_1}(p)")#text(" can be somewhat large (of size about ")#mi("\\varepsilon")#text(") when the smallest prime factor of ")#mi("p+2")#text(" is comparable to ")#mi("N^{\\varepsilon}")#text(", and the contribution of this case to the ")#mi("\\varepsilon(c)")#text(" in your original argument is of about the same size as the contribution of the case when ")#mi("p+2")#text(" is prime, which I believe will ultimately lead to ")#mi("\\varepsilon(c)")#text(" converging to I rather than to 0 as I said in my first comment (this is the only possible limiting value for ")#mi("\\varepsilon(c)")#text(" which is compatible with the Mobius pseudorandomness principle). In any event, it’s probably a good idea for you to work out the computation of ")#mi("\\varepsilon(c)")#text(" in full detail.")

#text("—")

#text("By the way, here is a more explicit way to think about the parity obstruction for twin primes which may help you appreciate why the inputs you are using are not strong enough to give the conclusion you wish to obtain. Sieve theory relies on inputs that can take the form of upper or lower bounds on sums of arithmetic functions, e.g.")

#mi("\\sum_n f(n) = X + O(E)")

#text("or")

#mi("\\sum_n f(n) \\geq X_- - O(E)")

#text("or")

#mi("\\sum_n f(n) \\leq X_+ + O(E)")#text(",")

#text("(for some main terms ")#mi("X, X_+, X_-")#text(" and error magnitude ")#mi("E")#text(", and various arithmetic functions ")#mi("f")#text(", which may for instance be the restriction of some other arithmetic function, e.g. ")#mi("\\Lambda(n)")#text(" or ")#mi("\\Lambda(n+2)")#text(", to a residue class ")#mi("a\\ (q)")#text(") or on averaged bounds such as Elliott-Halberstam type bounds")

#tao-math("\\sum_{q \\leq Q} \\sup_{(a,q)=1} \\left|\\sum_{n=a\\ (q)} f(n) - X_q\\right| \\ll E.", block: false)

#text("Sieve theory also takes as input pointwise inequalities")

#mi("f(n) \\leq g(n)")

#text("between arithmetic functions (e.g. the trivial bounds ")#mi("\\Lambda(n), \\Lambda(n+2) \\geq 0")#text(").")

#text("The whole game of sieve theory is to try to cleverly take linear combinations of these inputs, weighted by suitable sieves, to ultimately deduce something like")

#mi("\\sum_{p \\leq N: p+2 \\text{ prime}} 1 \\geq Y - O(E)\\quad (1)")

#text("or perhaps")

#mi("\\sum_{N \\leq n \\leq 2N} (\\theta(n)+\\theta(n+2)-\\log 3N) \\geq Y - O(E)\\quad (2)")

#text("where the main term ")#mi("Y")#text(" is significantly larger than the error term ")#mi("E")#text(".")

#text("Call an estimate ")#emph[#text("parity-insensitive")]#text(" if it is conjectured that the estimate is essentially unchanged after weighting the natural numbers ")#mi("n")#text(" by the weight ")#mi("(1 - \\lambda(n)\\lambda(n+2))")#text(". For instance, Elliott-Halberstam type bounds on ")#mi("\\sum_{n=a\\ (q)} \\Lambda(n)")#text(" are conjectured (by the Mobius pseudorandomness heuristic) to also hold for the weighted sum ")#mi("\\sum_{n=a\\ (q)} \\Lambda(n) (1 - \\lambda(n) \\lambda(n+2))")#text("; similarly if ")#mi("\\Lambda(n)")#text(" is replaced by ")#mi("\\Lambda(n+2)")#text(". Clearly any pointwise bound is also parity-insensitive since the weight ")#mi("1 -\\lambda(n)\\lambda(n+2)")#text(" is non-negative. In fact ")#emph[#text("all")]#text(" of the standard inputs to sieve theory (including GEH) are conjectured to be parity-insensitive. On the other hand, bounds such as (1) or (2) are parity-sensitive (and the bounds you claim would also be parity sensitive if ")#mi("\\varepsilon(c)")#text(" converged to any value other than I), because the weight ")#mi("1 - \\lambda(n) \\lambda(n+2)")#text(" vanishes on twin primes. It is also clear that taking linear combinations of parity-insensitive inequalities weighted by sieve weights can only ever yield more parity-insensitive inequalities, no matter how cleverly one chooses the sieve weights and the linear combinations. As such, it is not possible to produce twin primes by sieve theoretic arguments, unless one uses an input that is parity sensitive, or if one is operating under a hypothesis (such as a Siegel zero hypothesis) that is incompatible with the Mobius pseudorandomness heuristic. If you are unable to identify the precise parity sensitive input or pseudorandomness-violating hypothesis in your argument, this is a very strong signal that your argument is not correct.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergei")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-458953")[#strong[#text("Sergei")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2015")])]

#text("Thanks for this! Very enlightening.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergei")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-458967")[#strong[#text("Sergei")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2015")])]

#text("Is it right that it is unclear what happens with the asymptotic for ")#mi("\\lambda_{f_1}(n)")#text(" in the intermediate regime ")#mi("c=1-o(1)")#text(" for various ")#mi("o(1)")#text(" going to ")#mi("0")#text(" as ")#mi("N \\to \\infty")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-458972")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2015")])]

#text("Depends on what you are trying to compute. A plain sum such as ")#mi("\\sum_{n \\leq x} \\lambda_{f_1}(n)")#text(" should still be computable because the constant function ")#mi("1")#text(" is extremely well distributed in arithmetic progressions. However a sum such as ")#mi("\\sum_{n \\leq x} \\lambda_{f_1}(n) \\theta(n+2)")#text(" becomes very tricky, it involves understanding the distribution of ")#mi("\\theta(n+2)")#text(" in arithmetic progressions of spacing up to ")#mi("x^{1-c}")#text(" and it is known that the Elliott-Halberstam conjecture breaks down for ")#mi("c=1-o(1)")#text(" sufficiently close to 1, see ")#link("https://www.ams.org/mathscinet-getitem?mr=0986796")[#text("the work of Friedlander and Granville")]#text(". It may still be possible to use a strong version of pseudorandomness hypotheses though (e.g. Montgomery’s conjecture on the error term in the prime number theorem in arithmetic progressions) to predict what happens. Of course in the limit ")#mi("c=1")#text(", ")#mi("\\lambda_{f_1}")#text(" is essentially the von Mangoldt function, which is sensitive to ")#mi("\\lambda(n)")#text(" in contrast to the ")#mi("c < 1 - \\varepsilon")#text(" cases, so there must be some transition behaviour at some point.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dab262b249e6b008de2defe2a9d55f776181f2faf2f8a2ae168348cdfb2adaf-097fe507317aee85ccf32427e06a89aeacc09d75464afe95cd265a14b70a7a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-458499")[#strong[#text("Will")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2015")])]

#text("Yes, the heuristic that the primes are distributed randomly (e.g. the Cramer model) suggests that the error term for the prime number theorem in arithmetic progressions is ")#mi("O(n^{1/2+ \\epsilon})")#text(", which implies no Siegel zeros.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-458507")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2015")])]

#text("Minor suggestion: Friedlander and Iwaniec is available freely and legally online ")#link("http://www.ams.org/notices/200907/rtx090700817p.pdf")[#text("http://www.ams.org/notices/200907/rtx090700817p.pdf")]#text(" , but your link requires MathSciNet access. You might want to switch to the free one.")

#emph[#text("[Link changed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-458512")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2015")])]

#text("By the way, I’d enjoy a blogpost laying out what the alternative “ghostly” world looks like. I’ve picked it up in bits and pieces from your posts on the parity problem and other sources, but it would be interesting to see it all in one place, laid out as a consistent alternative.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-458546")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2015")])]

#text("I find it very stimulating that you write about this “unlikely” “alternate universe”. I can recognize terminology (e.g. “damping” ) used in sieve theory, that is also common in electronic filter terminology (signal processing). Is this semblance of an analogy between filters and sieves worthy of some consideration by students or non-specialists of analytic number theory?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-458653")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2015")])]

#text("It is interesting to observe that the (hypothetical) asymptotic orthogonality of the Mobius function ")#mi("\\mu")#text(" to all “structured” functions does not contradict the fact that ")#mi("\\mu")#text(" has bounded algorithmic complexity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-458658")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2015")])]

#text("It was my first encounter with Heath-Brown’s theorem. I’d like to know if there are heuristics or other things that give hope to analytic number theorists concerning which of (a) Twin Prime Conjecture, or (b) “No Siegel zeros”, “should” be the least difficult to prove?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86517a0250e0d07fac7c67edc4d116ce1bd86e1b770d5e7946e6c679dda5d914-380dfe326e07a18a2285931bc25f78c5ecb42ebbd28c82c174b5f78d9129b37c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TK")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-676856")[#strong[#text("TK")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2023")])]

#text("Rather than focusing only on Siegel zeros, i think it would be interesting to investigate the consequences of the existence of any infinite sequence of non-real zeros whose real parts converge to 1. Such zeros actually seem to exist. Kindly see:")

#link("https://figshare.com/articles/preprint/Untitled_Item/14776146")[#text("https://figshare.com/articles/preprint/Untitled_Item/14776146")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-676864")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2023")])]

#text("same nonsense as before (same issues – forgetting dependencies)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86517a0250e0d07fac7c67edc4d116ce1bd86e1b770d5e7946e6c679dda5d914-380dfe326e07a18a2285931bc25f78c5ecb42ebbd28c82c174b5f78d9129b37c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TK")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-676870")[#strong[#text("TK")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2023")])]

#text("Saying words like “nonsense” doesn’t make your comment any stronger or sensible. What exactly are the dependencies are you talking about ? Be explicitly clear.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3d53a5d0a81bb0e9ff47242d9f05e2d075d71434e50e3f7b9f8cfe5d6851f06-08a13e8650c86b9f26b4dcc182171f5d0ba69696ee363ff99633dd3d1e39a5f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walfisz")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-676873")[#strong[#text("Walfisz")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2023")])]

#text("@Anonymous, you’re probably referring to the implicit constant in (4) being dependent on epsilon, so that it may tend to infinity as epsilon tends to 0. However, that only becomes relevant if the author does let epsilon tend to 0.")

#text("Haven’t carefully checked other details, but the issue, if there is one, is definitely not on the the dependencies.")

#text("In short, you’re the one saying nonsense here.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-676917")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2023")])]

#text("the flaw has been detailed on MJR (when you truncate a convergent Dirichlet series at some fixed $x$ the remainder depends on both $s$ and $x$ and while it is true that for $s$ FIXED, the remainder goes to 0 when x to infinity, it is not true that happens uniformly in s so in particular for fixed x the remainder can be quite large when Im s is much larger – an easy example is t^(1/2)/x which goes to zero for fixed t when x goes to infinity but its integral in t is bigger than 1 as long as t is larger than x – this is essentially what happens in the Dirichlet case when uniform remainders are available precisely for x >> t= Im s only")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86517a0250e0d07fac7c67edc4d116ce1bd86e1b770d5e7946e6c679dda5d914-380dfe326e07a18a2285931bc25f78c5ecb42ebbd28c82c174b5f78d9129b37c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TK")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-676967")[#strong[#text("TK")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2023")])]

#text("Okay thanks, but the crux of the argument here, is not the estimate of the remainder term. Rather, it’s the summation in (1), which, if Theta_{\\chi} <1, creates a generalised Dirichlet eta function in the integrand.")

#text("In the calculations, we can actually work with the exact definition of E(x) = E(x, s, \\overline{\\chi}).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86517a0250e0d07fac7c67edc4d116ce1bd86e1b770d5e7946e6c679dda5d914-380dfe326e07a18a2285931bc25f78c5ecb42ebbd28c82c174b5f78d9129b37c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TK")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-676968")[#strong[#text("TK")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2023")])]

#text("**Definitions.** Let: ")#mi("\\mu")#text(" be the Mobius function, ")#mi("\\chi")#text(" be a primitive Dirichlet character of modulus ")#mi("q")#text(" and ")#mi("\\Theta_{\\chi} \\in [\\frac{1}{2}, 1]")#text(" be the supremum of the real parts of the zeros of ")#mi("L(s, \\chi)")#text(". Define ")#mi("M(x, \\chi)=\\sum_{n \\leq x} \\mu(n)\\chi(n)")#text(" and ")#mi("\\sigma=\\Re(s)")#text(". Let ")#mi("T \\in \\mathbb{R}_{\\geq 1}.")

#text("**Theorem 1.** *One has ")#mi("\\Theta_{\\chi}=1")#text(" for every ")#mi("\\chi")#text(".*")

#text("**PROOF.** Suppose that ")#mi("\\Theta_{\\chi}<1")#text(" for some ")#mi("\\chi")#text(", and let ")#mi("0<\\varepsilon \\Theta_\\chi")#text(", it follows by Perron’s formula (Theorem 5.2 of")#linebreak()#text(" Montgomery-Vaughan (M.V.)) that")#linebreak()#text(" $")

#text("latex \\displaystyle $/p>")

#text("Multiplying both sides of (1) by ")#mi("\\frac{(-1)^{n-1}\\overline{\\chi}(n)}{n}")#text(" and summing from ")#mi("n=1")#text(" to ")#mi("n=x")#text(" gives")

#text("$ latex \\displaystyle $")

#text("Since ")#mi("\\sum_{n=1}^{\\infty} (-1)^{n-1}\\overline{\\chi}(n)n^{-z} =(1-2^{1-z})L(z, \\overline{\\chi})")#text(" for $\\Re(z) >0$, note that at ")#mi("\\sigma=\\Theta_{\\chi}+\\varepsilon < 1")#text(", we have")

#text("$")#linebreak()#text(" latex \\displaystyle $")#linebreak()#text(" where for ")#mi("\\Re(1-z)>0")#text(" we have ")#mi("E(x, z, \\overline{\\chi})=-\\sum_{n>x} (-1)^{n-1}\\overline{\\chi}(n)n^{z-1} \\ll 1")#text(" uniformly for ")#mi("x \\geq 1")#text(". Inserting (3) into the right-hand side of (2) gives")

#text("$")#linebreak()#text(" latex \\displaystyle")#linebreak()#text(" $/p>")

#text("Let ")#mi("a_{\\chi}=0")#text(" if ")#mi("\\chi(-1)=1")#text(", and ")#mi("a_{\\chi}=1")#text(" if ")#mi("\\chi(-1)=-1")#text(". Let ")#mi("\\rho_m")#text(" be a zero of ")#mi("L(s, \\chi)")#text(" of order ")#mi("m")#text(", where ")#mi("0<\\Re(\\rho_m)1")#text(". Similarly, the integrand of the second integral has: simple poles at ")#mi("s=-2k-a_{\\chi}")#text(" with residue ")#mi("h(k):=-\\frac{E(x, -2k-a_{\\chi})}{2k+a_{\\chi}}")#text(", poles of order ")#mi("m")#text(" at ")#mi("s=\\rho_{m}")#text(" with residue ")#mi("R(\\rho_{m}, x)=\\frac{1}{(m-1)!}\\frac{d^{m-1}}{ds^{m-1}}\\Big{\\left(\\frac{(s-\\rho_m)^m E(x, s, \\overline{\\chi})}{sL(s, \\chi)}\\right)}\\Big|_{s=\\rho_m} 1")#text(". Let ")#mi("y \\in \\mathbb{R}_{<0}")#text(" be a non-integer, so that ")#mi("L(y, \\chi) \\neq 0")#text(". For ")#mi("\\sigma <0")#text(" and ")#mi("s \\neq -2k-a_{\\chi}")#text(", note that ")#tao-math("\\Big{\\left|\\frac{L(1-s, \\overline{\\chi})}{L(s, \\overline{\\chi})}\\right|} \\ll \\left|s\\right|^{-1/2}", block: false)#text(" [M.V., pp. 330 and 334] and ")#mi("L(1-s, \\overline{\\chi}) \\sim 1")#text(" hence ")#mi("\\lim_{y \\rightarrow -\\infty} \\int_{y-iT}^{y + iT} \\frac{(1-2^s)L(1-s, \\overline{\\chi})}{sL(s, \\chi)} \\mathrm{d}s = 0 = \\lim_{y \\rightarrow -\\infty} \\int_{y - iT }^{y + iT} \\frac{E(x, s, \\overline{\\chi})}{sL(s, \\chi)} \\mathrm{d}s")#text(". Thus by shifting the line of integration in (4) to ")#mi("(-\\infty - iT, -\\infty + iT)")#text(" and applying the residue theorem, we obtain")

#text("$")#linebreak()#text(" latex \\displaystyle")#linebreak()#text(" f(x)&=\\sum_{k=b_{\\chi}}^{\\infty} (g(k) + h(k)) + \\sum_{|\\Im(\\rho_m)| \\leq T} R(\\rho_{m}, x) + \\frac{E(x, 0, \\overline{\\chi})}{L(0,\\chi)} + O(x^{1+\\varepsilon}/T) \\tag{5} \\\\")#linebreak()#text(" &= -\\sum_{k=b_\\chi}^{\\infty}\\Bigg( \\frac{(1-2^{-2k-a_{\\chi}})L(2k+1+a_{\\chi}, \\overline{\\chi})}{2k+a_{\\chi}} + \\frac{E(x, -2k-a_{\\chi})}{2k+a_{\\chi}} \\Bigg) + \\sum_{|\\Im(\\rho_m)| \\leq T} R(\\rho_{m}, x) + O\\Big(1 + \\frac{x^{1+\\varepsilon}}{T} \\Big). \\tag{6}")#linebreak()#text(" >$")

#text("Since $\\latex R(\\rho_m, x) x}\\frac{(-1)^{n-1}\\overline{\\chi}(n)}{n^{2k+a_{\\chi}+1}} \\ll \\sum_{n > x} n^{-2} \\ll x^{-1}$ for every non-negative integer ")#mi("k")#text(". Hence the summands of the first sum are ")#mi("> \\frac{1}{3k}")#text(" for any fixed large enough ")#mi("x")#text(" and all ")#mi("k \\geq k_0")#text(", thus the sum diverges as claimed. But we now have a contradiction, since ")#tao-math("\\left|f(x)\\right|=\\left|\\sum_{n \\leq x} \\frac{(-1)^{n-1}M(n, \\chi)\\overline{\\chi}(n)}{n}\\right| q", block: false)#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86517a0250e0d07fac7c67edc4d116ce1bd86e1b770d5e7946e6c679dda5d914-380dfe326e07a18a2285931bc25f78c5ecb42ebbd28c82c174b5f78d9129b37c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TK")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-676970")[#strong[#text("TK")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2023")])]

#text("Apparently, therearesomeLaTex typos in the previous comment. So, you may see the actual paper:")

#link("https://figshare.com/articles/preprint/Untitled_Item/14776146")[#text("https://figshare.com/articles/preprint/Untitled_Item/14776146")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66568563e6a6b734ec4b9ada3b1b93a72623a9406957e38edbfe2792b4724d8b-602087049d7cb0b9b4efc0d4b19f879d0a1a4c12dfa6e14f4a6ede06e80da390.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677743")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2023")])]

#text("@TK, it really seems you’ve actually disproved the RH. Have you submitted this anywhere yet?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677747")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2023")])]

#text("Tk talking to TK – the wonders of sock pupetry")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6a6d01b175e1a87f1ea7fdcac7e17e0eb6c8c34b65e7437e3cd431be6e2040c7-aa31bd5ea1134a30b035fb75818d7c068936aad0bfe0bc329c01a2d861e751a2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677749")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2023")])]

#text("TK haters, you should be ashamed of yourselves for hating on someone with such talent and passion as TK.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86517a0250e0d07fac7c67edc4d116ce1bd86e1b770d5e7946e6c679dda5d914-380dfe326e07a18a2285931bc25f78c5ecb42ebbd28c82c174b5f78d9129b37c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TK")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677761")[#strong[#text("TK")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2023")])]

#text("@Anonymous: I submitted the paper to the Annals of Mathematics, but they’re yet to acknowledge receipt of the submission. However, I should mention that all the journals I submitted to before the Annals, returned the paper without any review comments. Some of the editors said that before submitting, I should discuss my work with some “experts”. But when I contact the “experts”, most of them suggest I send the work to some journal since it’s their job to review. I have therefore decided to post the work here, since the main result of the paper could be of relevance to this particular post.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3d53a5d0a81bb0e9ff47242d9f05e2d075d71434e50e3f7b9f8cfe5d6851f06-08a13e8650c86b9f26b4dcc182171f5d0ba69696ee363ff99633dd3d1e39a5f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677765")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2023")])]

#text("Fun discussion between TK & David Farmer about this paper on MathOverflow:")

#link("https://mathoverflow.net/questions/445426/reference-request-for-pi-sum-im-rho-leq-t-n-rho-t-lambdan-o")[#text("https://mathoverflow.net/questions/445426/reference-request-for-pi-sum-im-rho-leq-t-n-rho-t-lambdan-o")]

#text("Not sure it’s the David Farmer from AIM, though, given the ridiculously flawed comments he is posting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677768")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2023")])]

#text("As usual, when someone took the time to show your errors, you reply with insults and nitpicking without actually thinking through what they say so do not be surprised that the number of people willing to engage is growing smaller and smaller;")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86517a0250e0d07fac7c67edc4d116ce1bd86e1b770d5e7946e6c679dda5d914-380dfe326e07a18a2285931bc25f78c5ecb42ebbd28c82c174b5f78d9129b37c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TK")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677775")[#strong[#text("TK")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2023")])]

#text("Which insults?? Didn’t I objectively reply in the MO post with factual mathematical comments which you have obviously chosen to ignore to suit your narrative?")

#text("The claim that David Farmer made in the now deleted MO post, is that for ")#mi("\\gamma \\in [T, 2T], f(T, \\rho)=\\sum_{n \\leq \\log T} (-1)^{n-1} n^{\\rho-1}")#text(" doesn’t converge as ")#block(width: 100%, above: 12pt, below: 14pt)[#set par(justify: false)
#text(size: 7pt, fill: rgb("596477"))[#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677775")[Source formula could not be rendered.] ] #text(font: "DejaVu Sans Mono", size: 7.5pt, "T \\rightarow \\infty")]#text(", but tbis is not rrue at all. Inded, here is an elementary argument why ")#mi("f(T, \\rho)")#text(" converges (to ")#mi("(1-2^{\\rho})\\zeta(1-\\rho)=0")#text(") as ")#mi("T")#text(" tends to infinity.")

#text("Let ")#mi("a_n = a_{n, \\rho} = n^{\\rho-1}")#text(" and ")#mi("b_n = (-1)^{n-1}")#text(". Then $ latex a_n$ decreases monotonically to 0 as ")#mi("n")#text(" tends to infinity, and")

#text("$ latex |\\sum_{n \\leq log T} b_n| \\leq 1$")

#text("for all ")#mi("T > e")#text(". Thus by mimicking the proof of the Dirichlet convergence test:")

#link("https://en.m.wikipedia.org/wiki/Dirichlet%27s_test")[#text("https://en.m.wikipedia.org/wiki/Dirichlet%27s_test")]

#text("one deduces that ")#mi("f(T, \\rho)")#text(" indeed converges (to ")#mi("(1-2^{\\rho})zeta(1-\\rho)=0")#text(") as ")#mi("T")#text(" tends to infinity. In particular, notice that this argument is independent of how large ")#tao-math("\\left|\\rho\\right|", block: false)#text(" is.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3d53a5d0a81bb0e9ff47242d9f05e2d075d71434e50e3f7b9f8cfe5d6851f06-08a13e8650c86b9f26b4dcc182171f5d0ba69696ee363ff99633dd3d1e39a5f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walfisz")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677776")[#strong[#text("Walfisz")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2023")])]

#text("@Anonymous, please don’t impose your fallacious claims on TK. It’s a fact that ")#mi("f(T, \\rho) =\\sum_{n \\leq \\log T} (-1)^{n-1}n^{\\rho-1}")#text(" converges as ")#mi("T \\rightarrow \\infty")#text(", even if ")#tao-math("\\left|\\rho\\right| \\approx T", block: false)#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677780")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2023")])]

#text("when the experts point out to you why you are wrong, it is a good idea to at least consider they may have a point; after all you have been provably shown to be wrong by the same experts you have been disparaging for 100 times or more and the same thing is here, confusion between uniform and nonuniform bounds; nothing to do with analytic number theory, just basic analysis")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86517a0250e0d07fac7c67edc4d116ce1bd86e1b770d5e7946e6c679dda5d914-380dfe326e07a18a2285931bc25f78c5ecb42ebbd28c82c174b5f78d9129b37c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TK")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677781")[#strong[#text("TK")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2023")])]

#text("@David Farmer (commenting as “anonymous”, please vomment with your real name like I’m doing, as you informed me via email that you’re the most recent poster. Firstly, let it be known the public that you claimed via email yesterday that if the function ")#mi("f(T, \\rho)")#text(" (which we can simply write as ")#mi("f(T)")#text(" since ")#mi("\\rho")#text(" is a function of ")#mi("T")#text(" via ")#mi("\\gamma")#text(") converges to 0 as ")#mi("T")#text(" tends to ")#mi("\\infty")#text(", then ")#mi("f(T)")#text(" can be close to ")#mi("1")#text(" for infinitely many ")#mi("T")#text(". You and I both know that you uttered this statement, and I had to endure the trouble of explaining to you why it’s elementarily wrong even by the standards of first year undergrad calculus. It’s quite funny that you’re here now calling yourself an “expert”, despite claims such as this. This is the very reason why it’s difficult for you to understand why ")#mi("f(T, \\rho)")#text(" converges as ")#mi("T")#text(" tends to ")#mi("\\infty")#text(". Next time, please comment with yout real name, David Farmer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a69bc8e4db7d8baebb56738830f8d407446ef76b72dd822950badca4a11b0d17-09b431691fea3315644e89226d0ddc42974f1fe471226c144d3f5490c35ac2a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677782")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2023")])]

#text("For the benefit of some of us who didn’t see the now deleted MathOverflow post, can the constrictive critics please kindly point to us what exactly are you claiming to be the flaw? Surely, ")#mi("f(T, \\rho):=\\sum_{n \\leq \\log T} (-1)^{n-1}n^{\\rho-1}")#text(" does converge independently of the magnitude of $|\\rho|$ as ")#mi("T \\rightarrow \\infty,")#text(" since ")#mi("f(T, \\rho) = (1-2^{\\rho})\\zeta(\\rho)- \\sum_{n > \\log T} (-1)^{n-1}n^{\\rho-1}=-\\sum_{n > \\log T} (-1)^{n-1} n^{\\rho-1}")#text(" for all $T$.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e3aad6dcfcd64498f6dd003763d8684003051a64dd223da05858a923fedbd8b-44b60931b11e54c67f9ab2a6e66763b0a9a8a76946a131495a078954666322ff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alvarez")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677784")[#strong[#text("Alvarez")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2023")])]

#text("@Anonymous, which uniform/non uniform bounds are you talking about? I seem not to see any issue with uniformity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677790")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2023")])]

#text("The paper got debunked for (it’s number 100 or so after all and pretty much every time we heard the same combination of insults and assured statements that now this time is surely, utterly and of course 100% right) and no number of sock puppets make it correct. The MO thread (put as usual under false pretenses) and comments clearly showed it; talking from thin air about arbitrary stuff doesn’t change it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a69bc8e4db7d8baebb56738830f8d407446ef76b72dd822950badca4a11b0d17-09b431691fea3315644e89226d0ddc42974f1fe471226c144d3f5490c35ac2a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677791")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2023")])]

#text("@Anonymous, seems you have no valid mathematic criticism against the paper, except trash-talking against it and referring to previous versions. You have been asked to pinpoint the exact flaw in the current two page version, but you’re still beating around the bush. Not to mention how your tone sounds extremely bitter, lol.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2d3e7e9de363864a44b48f2a30bcbdc27c2844a9ca77dbd1d61aaf4bf153d54-b2f299e8631c13cba23275bd61fec77974efbbd181379eb75ecd028ea0406b04.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alvarez")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677792")[#strong[#text("Alvarez")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2023")])]

#text("@Anonymous, it’s funny that you keep referring to the now non-existent MO post that some of is didn’t come across. We’re asking you again for the second time: what exactly are you claiming to be the flaw? Otherwise stop speaking nonsense against someone who is working hard to actually make a meaningful contribution to mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86517a0250e0d07fac7c67edc4d116ce1bd86e1b770d5e7946e6c679dda5d914-380dfe326e07a18a2285931bc25f78c5ecb42ebbd28c82c174b5f78d9129b37c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TK")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677800")[#strong[#text("TK")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2023")])]

#text("The “issue” that was raised in the MathOverflow post is that, if ")#tao-math("\\left|\\rho\\right| > T", block: false)#text(", then ")#mi("f(T, \\rho)")#text(" may not converge to ")#mi("0")#text(" as ")#mi("T \\rightarrow \\infty")#text(". However, this is not true.")

#text("Indeed, fix ")#mi("\\sigma=\\Re(s)T")#text(". Therefore, taking ")#mi("s=\\rho")#text(" where ")#tao-math("\\left|\\rho\\right|", block: false)#text(" yields ")#mi("\\lim_{T \\rightarrow \\infty} f(T, \\rho)=(1-2^{\\rho})\\zeta(1-\\rho)=0")#text(" even if ")#tao-math("\\left|\\rho\\right|>T", block: false)#text(", as claimed. For the sake of completeness, I have added these details into the paper.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86517a0250e0d07fac7c67edc4d116ce1bd86e1b770d5e7946e6c679dda5d914-380dfe326e07a18a2285931bc25f78c5ecb42ebbd28c82c174b5f78d9129b37c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TK")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677803")[#strong[#text("TK")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2023")])]

#text("There are some LaTex typos in the above comment as I’m not used to MathJax. But you can see the revised version of Figshare in which I added the said details for explaining why ")#mi("\\lim_{T \\rightarrow \\infty} f(T, \\rho)=0")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677802")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2023")])]

#text("Good you put in details as they easily show how absurd your claim is since you take the limit of T to infinity and then claim that |\\rho| >T; again same same (uniform vs pointwise), so nothing new; all debunked for the 100th time – looking forward to next try, though hopefully not too soon as it gets boring seeing same mistakes over and over")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91697548747d41f9b37f3bdce8ac05c24a2bd3bea75190959d655b46272cb508-a3f7b227f2a90d4ef9306a0fc4c831ecdf28b63d89c3cdaa719ac83362b497d0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677804")[#strong[#text("Peter")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2023")])]

#text("@Anonymous, why is it absurd that ")#tao-math("\\left|\\rho\\right|>T", block: false)#text(" ? By the way, your choice of words should be more respectful. Your points do not become any stronger by trash-talking against the other person.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2d3e7e9de363864a44b48f2a30bcbdc27c2844a9ca77dbd1d61aaf4bf153d54-b2f299e8631c13cba23275bd61fec77974efbbd181379eb75ecd028ea0406b04.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alvarez")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677813")[#strong[#text("Alvarez")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2023")])]

#text("@Anonymous, it’s so annoying how you’re so arrogant and disrespectful, yet completely ignorant. And, how did your flawed comment get 10 upvotes almost instantly? Using a VPN to upvote your nonsense?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7fab2354265fe37482f1fe6d0a00e602a3d3b1b1909cd361e1b4aad8ce1cc72-dd9721d5af10a664a7f8f567264559d2fe54b471ce737df46c233dcf060df246.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walfisz")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677806")[#strong[#text("Walfisz")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2023")])]

#text("@Anonymous, don’t be too desperate to debunk a paper without carefully reading and understanding what is written. Equation (10) is clearly uniform in ")#mi("T \\geq T_0")#text(". The author then later takes ")#tao-math("\\left|\\rho\\right|>T", block: false)#text(" because that’s what’s relevant for the rest of the argument.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677827")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2023")])]

#text("Actually, there is a paper by Littlewood and Hardy whose methods can be easily adapted to show the divergence (when $T \\to \\infty$) of the sum $f(\\rho(T), T)$ when $\\rho(T) =\\sigma +it, \\sigma \\le 1/2$ and $t$ around $T$ as D. Farmer mentioned on MO; the careless notation which doesn’t make it clear that the $\\rho$ in your sum depends on $T$ (at least if you want to take $T \\to \\infty$ and $|\\rho| >T$) obscures this")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a69bc8e4db7d8baebb56738830f8d407446ef76b72dd822950badca4a11b0d17-09b431691fea3315644e89226d0ddc42974f1fe471226c144d3f5490c35ac2a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-677835")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2023")])]

#text("@Anonymous, actually, one can easily adapt the methods of the proof of Theorem 2.5 of Titchamarsh’s “The Theory of the Riemann zeta functio n”, to prove that if ")#mi("I\\Im(s)| \\in [T, 2T]")#text(", then ")#mi("F(T, s)")#text(" converges to ")#mi("(1-2^{s})\\zeta(1-s)")#text(" as ")#mi("T \\rightarrow \\infty")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86517a0250e0d07fac7c67edc4d116ce1bd86e1b770d5e7946e6c679dda5d914-380dfe326e07a18a2285931bc25f78c5ecb42ebbd28c82c174b5f78d9129b37c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TK")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-678060")[#strong[#text("TK")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2023")])]

#text("The more proper way to say it, is")#linebreak()#text(" ")#mi("f(T, z_T):=\\sum_{n \\leq \\log T} (-1)^{n-1}n^{-z_T} \\rightarrow (1-2^{1-z_T})\\zeta(z_T)")#text(" as ")#mi("T \\rightarrow \\infty")#text(". I find that the quantitative version of Perron’s formula (Theorem 5.2 of Montgomery-Vaughan), provides a more straightforward approach to prove this.")#linebreak()#text(" Indeed, define ")#mi("g(z_T):=(1-2^{1-z_T})\\zeta(z_T)")#text(" and note that ")#mi("\\sum_{n=1}^{\\infty} (-1)^{n-1}n^{-s}=g(s)")#text(" for $\\Re(s)>0$. Thus by the quantitative version of Perron’s formula, we have")

#mi("f(T, z_T) = \\frac{1}{2\\pi i} \\int_{2-iU}^{2+iU} \\frac{g(w+z_T)(\\log T)^{w}}{w} \\mathrm{d}w + O\\Big{\\left(\\frac{(\\log T)^2}{U}\\right)}.")#linebreak()#text(" Notice that the above integrand has a meromorphic continuation to the entire complex plane, with only a simple pole at ")#mi("w=0")#text(" with residue ")#mi("g(z_T)")#text(". Thus by the Cauchy residue theorem, we have")

#mi("\\frac{1}{2\\pi i} \\int_{2-i\\infty}^{2+i\\infty} \\frac{g(w+z_T)(\\log T)^{w}}{w} \\mathrm{d}w = g(z_T).")#linebreak()#text(" Hence from the above two displayed equations with ")#mi("U=T")#text(", we deduce that ")#mi("f(T, z_T) \\rightarrow g(z_T)")#text(" uniformly as ")#mi("T \\rightarrow \\infty")#text(", as claimed.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86517a0250e0d07fac7c67edc4d116ce1bd86e1b770d5e7946e6c679dda5d914-380dfe326e07a18a2285931bc25f78c5ecb42ebbd28c82c174b5f78d9129b37c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TK")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-678061")[#strong[#text("TK")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2023")])]

#text("For the sake of completeness, i have included the above argument in the paper, as a separate Lemma:")

#link("https://figshare.com/articles/preprint/Untitled_Item/14776146")[#text("https://figshare.com/articles/preprint/Untitled_Item/14776146")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d9e338e0cd3c5854d68f121b5bf4dd9161377bdb81e3cdc27ffbef30ef3227b-78ebb2d5d5bd8641134d35ec8cda100165b35ec3350266a25bb780abe9cd2e13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-458795")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2015")])]

#text("The points on the hyperbola ")#mi("ab + 2 = 0 \\mod d")#text(" look equidistributed to me. How is this connected to Möbius pseudorandomness?")#linebreak()#text(" ")#link("http://i.imgur.com/YVZ9vDz.png")[#image("../assets/91ddc76b1b42b38bf37e36350c8b5489b8010dcd4583bd2aedcf6119fc6bc15f-faa24ec881e6040655c187a681d6dc496eb8aa41e1bd0652a180b3a40b457187.png", width: 90%)]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-458907")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2015")])]

#text("Are there some general rules to design a sieve (which motivate the design of the multidimensional Selberg sieve and its variants)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/40e6e839f349dc86fd7cc9dc699f5dc8fc471c9022709605233a286ef97cdebb-0b2c619f0d00bb3eced67879c1a00f90e0a8c2699689cc7f116dac75626f5283.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boris Sklyar")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-458993")[#strong[#text("Boris Sklyar")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2015")])]

#text("“MATRIX DEFINITION” OF PRIME NUMBERS:")

#text("There are two 2-dimensional arrays:")#linebreak()#text(" ……………………………|5 10 15 20 ..|")#linebreak()#text(" 6i^2-1+(6i-1)(j-1)=…..|23 34 45 56…|")#linebreak()#text(" ……………………………|53 70 87 104…|")#linebreak()#text(" …………………………..|95 118 141 164…|")#linebreak()#text(" …………………………..|149 178 207 236…|")#linebreak()#text(" …………………………..|… … … … |")

#text("…………………………….| 5 12 19 26 ..|")#linebreak()#text(" 6i^2-1+(6i+1)(j-1) =….|23 36 49 62…|")#linebreak()#text(" …………………………….|53 72 91 110…|")#linebreak()#text(" ……………………………..|95 120 145 170…|")#linebreak()#text(" ……………………………..|149 180 211 242…|")#linebreak()#text(" ……………………………|… … … … |")#linebreak()#text(" Positive integers not contained in these arrays are indexes p of all prime numbers in the sequence S1(p)=6p+5, i.e. p=0, 1, 2, 3, 4, , 6, 7, 8, 9, , 11, , 13, 14, , 16, 17, 18, , , 21, 22, , 24, , , 27, 28, 29, …")#linebreak()#text(" and primes are: 5, 11, 17. 23, 29, , 41, 47, 53, 59, , 71, , 83, 89, , 101, 107, 113, , , 131, 137, , 149, , , 167, 173, 179, ….")

#text("There are two 2-dimensional arrays:")#linebreak()#text(" ………………………………. |3 8 13 18 ..|")#linebreak()#text(" 6i^2-1-2i+(6i-1)(j-1)=….. |19 30 41 52…|")#linebreak()#text(" …………………………………|47 64 81 98…|")#linebreak()#text(" …………………………………|87 110 133 156…|")#linebreak()#text(" …………………………………|139 168 197 226…|")#linebreak()#text(" …………………………………|… … … … |")

#text("……………………………….. | 7 14 21 28 ..|")#linebreak()#text(" 6i^2-1+2i+(6i+1)(j-1)=…..|27 40 53 66…|")#linebreak()#text(" ………………………………….|59 78 97 116..|")#linebreak()#text(" ………………………………….|103 128 153 178..|")#linebreak()#text(" ………………………………….|159 190 221 252..|")#linebreak()#text(" ………………………………….|… … … … … |")#linebreak()#text(" Positive integers not contained in these arrays are indexes p of all prime numbers in the sequence S2(p)=6p+7, i.e. p=0, 1, 2, , 4, 5, 6, , , 9, 10, 11, 12, , , 15 , 16, 17, , , 20, , 22, , 24, 25 , 26, , , 29, …")#linebreak()#text(" and primes are: 7, 13, 19. , 31, 37, 43, , , 61, 67, 73, 79, , , 97, 103, 109, , , 127, , 139, , 151, 157, 163, , , 181 ….")#linebreak()#text(" ,")#linebreak()#text(" ")#link("http://ijmcr.in/index.php/current-issue/86-title-matrix-sieve-new-algorithm-for-finding-prime-numbers")[#text("http://ijmcr.in/index.php/current-issue/86-title-matrix-sieve-new-algorithm-for-finding-prime-numbers")]

#link("http://www.planet-source-code.com/vb/scripts/ShowCode.asp?txtCodeId=13752&lngWId=3﻿")[#text("http://www.planet-source-code.com/vb/scripts/ShowCode.asp?txtCodeId=13752&lngWId=3﻿")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-459028")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2015")])]

#text("(twin prime conjecture).")

#text("all twins prime it is the form.")

#mi("5+6[7a + (1,2,3,4,5,6)] = p - 2")#text(" ; ")#mi("a\\geq 0")#text(".")

#text("Always that: ")#mi("7a + (1,2,3,4,5,6) \\neq 5n")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/40e6e839f349dc86fd7cc9dc699f5dc8fc471c9022709605233a286ef97cdebb-0b2c619f0d00bb3eced67879c1a00f90e0a8c2699689cc7f116dac75626f5283.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boris Sklyar")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-459036")[#strong[#text("Boris Sklyar")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2015")])]

#text("Twin primes conjecture.")#linebreak()#text(" N1, N2 – primes, N2-N1=2;")#linebreak()#text(" N1 always belongs to the sequence S1(p)=6p+5; p = 0, 1, 2, …")#linebreak()#text(" N2 always belongs to the sequence S2(q)=6q+7; q = 0, 1, 2, …")#linebreak()#text(" When p=q; N1, N2 — are twin primes.")#linebreak()#text(" Twin primes condition:")#linebreak()#text(" Odd positive integers N1 =6p+5 and N2=6p+7 are twin primes if and only if")#linebreak()#text(" no one of four diophantine equations has solution;")#linebreak()#text(" 6x^2-1 + (6x -1)y=p")#linebreak()#text(" 6x^2-1 + (6x +1)y=p")#linebreak()#text(" 6x^2-1 – 2x+(6x -1)y=p")#linebreak()#text(" 6x^2-1 +2x +(6x+1)y=p")#linebreak()#text(" x =1,2,3,..")#linebreak()#text(" y=0,1,2….")

#text("0 0 Rate This")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6387b14435b0ff581eb677123c72a7100c8c7c467c535fbba3aaa4700bb5a99-36f5f55e66b90e73a74cc93599d6853f14085eb5b4988271ad03a60e77bf457a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-467688")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2016")])]

#text("At the start of the proof if Lemma 5, it says for each fixed natural number n. Should the n be a k?")

#text("Also, in the paragraph that starts with: We begin with (13), there is an inequality with \\chi(p) between two powers of x. I believe it should be p, as that is what is used in later lines.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1406bb3790008e41af14a244a6f56ecca0e59d55fc0723dbd2639dd46f51516f-08014907fd7599249cace03d086a8fb3b7d3caf0c88c17ed96f78484157384ae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of primenumbers")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-484382")[#strong[#text("primenumbers")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2017")])]

#text("We will go on to show that the distribution of ")#link("http://nuclearstrategy.co.uk/prime-number-distribution-series")[#text("prime numbers may be best visualized in two-dimensional space.")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1406bb3790008e41af14a244a6f56ecca0e59d55fc0723dbd2639dd46f51516f-08014907fd7599249cace03d086a8fb3b7d3caf0c88c17ed96f78484157384ae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of primenumbers")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-484384")[#strong[#text("primenumbers")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2017")])]

#text("We advance our analysis with the extension of division to the divisor 3in the simplified")#link("http://nuclearstrategy.co.uk/prime-number-distribution-series")[#text("prime number")]#text(" analysis introduced earlier.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The alternative hypothesis for unitary matrices | What's new")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-515976")[#strong[#text("The alternative hypothesis for unitary matrices | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2019")])]

#text("[…] which differs from (13) for any . (This fact was implicitly observed recently by Baluyot, in the original context of the zeta function.) Thus a verification of the pair correlation conjecture (17) for even a single with would rule out the alternative hypothesis. Unfortunately, such a verification appears to be on comparable difficulty with (an averaged version of) the Hardy-Littlewood conjecture, with power saving error term. (This is consistent with the fact that Siegel zeroes can cause distortions in the Hardy-Littlewood conjecture, as (implicitly) discussed in this previous blog post.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2074f177e0fe0b4b28b74b4517d4152bc960959bf1b804352acda86b2be4fd63-7a2401b4796f9848d0569bb41b0f32e90911a8a456a8d7fa2111368d7d58bc6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ES")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-563240")[#strong[#text("ES")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2020")])]

#text("The function ")#mi("g")#text(" introduced in (11) is remarked to be supported on integers whose prime factors satisfy ")#mi("\\chi(p) \\neq -1")#text(". But if ")#mi("k=2")#text(" and ")#mi("p_1=p_2")#text(" and ")#mi("\\chi(p)=-1")#text(" then ")#mi("g( p_1 p_2 ) =g(p^2)= 1")#text(". Or is the support claim only valid when ")#mi("p_1 p_2 \\ldots p_k")#text(" square-free ?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2074f177e0fe0b4b28b74b4517d4152bc960959bf1b804352acda86b2be4fd63-7a2401b4796f9848d0569bb41b0f32e90911a8a456a8d7fa2111368d7d58bc6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ES")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-564079")[#strong[#text("ES")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2020")])]

#text("Equation (19) needs ")#mi("\\psi_x(n)")#text(".")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2074f177e0fe0b4b28b74b4517d4152bc960959bf1b804352acda86b2be4fd63-7a2401b4796f9848d0569bb41b0f32e90911a8a456a8d7fa2111368d7d58bc6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ES")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-569177")[#strong[#text("ES")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2020")])]

#text("It looks like in the equation after “Standard sieve theory then gives” should contain ")#mi("(\\log x)^{-C-2}")#text(" instead of ")#mi("(\\log x)^{-C-1}")#text(" as the length of the interval is ")#mi("x (\\log x)^{-C}")#text(" and the sieve is of dimension ")#mi("2")#text(". I haven’t checked if this matters for later estimates.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2074f177e0fe0b4b28b74b4517d4152bc960959bf1b804352acda86b2be4fd63-7a2401b4796f9848d0569bb41b0f32e90911a8a456a8d7fa2111368d7d58bc6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ES")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-569761")[#strong[#text("ES")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2020")])]

#text("Could I please ask any minor hint about the application of summation by parts in the last step of the proof of (24)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-570616")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2020")])]

#text("We are trying to sum ")#mi("\\sum_k a(k) b(k)")#text(" where ")#mi("a")#text(" is the ")#mi("q")#text("-periodic function ")#mi("a(k) := \\chi(W[e,m]k/m_1 + a/m_1) \\chi(W[e,m]k/m_2 + (a+2)/m_2)")#text(" and ")#mi("b")#text(" is the slowly varying function ")#mi("b(k) := G_>(n+a)\\log(n+2)/\\log x) \\psi_x(n)")#text(" with ")#mi("n = W[e,m]k+a")#text(". The function ")#mi("b")#text(" is supported on an interval of length ")#mi("O( x/[e,m] )")#text(" (we omit the bounded ")#mi("W")#text(" factor here) and has total variation ")#mi("O(1)")#text(", hence by summation by parts this sum is bounded by ")#tao-math("\\sup_I \\left|\\sum_{k \\in I} a(k)\\right|", block: false)#text(" where ")#mi("I")#text(" ranges over intervals of length ")#mi("O(x/[e,m])")#text(". Splitting ")#mi("I")#text(" into intervals of length ")#mi("q")#text(" plus a remainder and using the bound from Lemma 3, this is ")#mi("O( x^{o(1)} x/q[e,m] + q )")#text(" and the latter term is negligible if ")#mi("C")#text(" is large enough.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2074f177e0fe0b4b28b74b4517d4152bc960959bf1b804352acda86b2be4fd63-7a2401b4796f9848d0569bb41b0f32e90911a8a456a8d7fa2111368d7d58bc6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ES")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-573280")[#strong[#text("ES")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2020")])]

#text("Many thanks!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2074f177e0fe0b4b28b74b4517d4152bc960959bf1b804352acda86b2be4fd63-7a2401b4796f9848d0569bb41b0f32e90911a8a456a8d7fa2111368d7d58bc6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ES")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-573279")[#strong[#text("ES")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2020")])]

#text("A harmless typo: the first display after ")#mi("m= \\overline{d_1}-\\overline{2}\\mod {d_1}")#text(" is missing ")#mi("e(-2k/Wr)")#text(".")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2074f177e0fe0b4b28b74b4517d4152bc960959bf1b804352acda86b2be4fd63-7a2401b4796f9848d0569bb41b0f32e90911a8a456a8d7fa2111368d7d58bc6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ES")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-574578")[#strong[#text("ES")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2020")])]

#text("There is something strange in the second application of Poisson’s summation formula just before the start of the proof of (22). To use the Kloosterman bound I am guessing the text suggestion is to partition in congruence classes ")#mi("t\\mod{d_1}")#text(" and for each such ")#mi("t")#text(" we have a sum of (something which is essentially) ")#mi("\\psi_x(md_2)")#text(" over all integers ")#mi("d_2\\equiv t \\mod{d_1}")#text(" which is estimated with Poisson. Because of the presence of ")#mi("m")#text(" within ")#mi("\\psi_x")#text(" I think there is a problem in getting the error term claimed though. We are counting integers ")#mi("d_2")#text(" of size ")#mi("x/m")#text(" in a progression modulo ")#mi("d_1")#text(" and in the cases where ")#mi("d_1 m >x")#text(" one cannot hope to get good errors by Poisson (or otherwise?). Perhaps I am missing something?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-575168")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2020")])]

#text("One should perform an inverse Fourier expansion of ")#mi("e(h \\overline{d_2}/d_1)")#text(" into characters a linear combination of characters ")#mi("e(a d_2/q)")#text(" and then apply the Poisson summation formula in ")#mi("d_2")#text(" to the resulting sums to express things in terms of Fourier integrals such as ")#mi("\\int_{\\bf R} e(k y/q) \\tilde G(\\frac{\\log d_1 + \\log y}{x}) e( ay/q) e( 2kym/Wr) \\psi(y(2m+1)-2)\\ dy")#text(". The ")#mi("\\psi")#text(" cutoff is fairly harmless, it is the ")#mi("\\tilde G")#text(" cutoff that provides the main contribution of ")#mi("O( x/m )")#text(", but only when ")#mi("y/q + a/q + 2km/Wr")#text(" is close to an integer, which basically only happens for a single choice of ")#mi("a")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2074f177e0fe0b4b28b74b4517d4152bc960959bf1b804352acda86b2be4fd63-7a2401b4796f9848d0569bb41b0f32e90911a8a456a8d7fa2111368d7d58bc6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ES")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-575852")[#strong[#text("ES")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2020")])]

#text("Thank you very much for all the time and explanations so far! One last question: when the proof of (22) starts there is another Poisson summation happening. But the main term coming from the central coefficient doesn’t seem to take into account that ")#mi("[d,e]")#text(" divides ")#mi("n(n+2)")#text(". In my calculations it looks like one should have ")#mi("2^{\\omega[d,e]}/[d,e]")#text(" instead of ")#mi("1/[d,e]")#text(". I may be missing something though. But if that is correct then the main term should behave as ")#mi("x(\\log x )^{-C-2}")#text(" instead of ")#mi("x (\\log x )^{-C-1}")#text(". Again, I am sorry if this is not accurate!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-575973")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2020")])]

#text("There were some summations in ")#mi("n")#text(" missing in these displays that have now been corrected. The prime factorization of ")#mi("[d,e]")#text(" does not affect this summation as it is coprime to ")#mi("W")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2074f177e0fe0b4b28b74b4517d4152bc960959bf1b804352acda86b2be4fd63-7a2401b4796f9848d0569bb41b0f32e90911a8a456a8d7fa2111368d7d58bc6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ES")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-575994")[#strong[#text("ES")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2020")])]

#text("Thank you for the summations! But I was alluding to the fact that the condition ")#mi("[d,e] \\mid n(n+2)")#text(" should give rise to a missing term ")#mi("2^{\\omega([d,e])}")#text(" on the right-hand side of the first equation after “From Poisson summation one then has”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-576149")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2020")])]

#text("Ah, I see the issue now. The main term is indeed one power of ")#mi("\\log x")#text(" smaller than claimed (which in retrospect was clear from probabilistic heuristics such as the Cramer model), and all the error bounds have to be improved by a factor of ")#mi("\\log x")#text(" accordingly. In fact now that I see it I had wasted a factor of ")#mi("\\log x")#text(" anyway in the proof of (19) so the two errors ended up cancelinc each other out. The post has now been updated with the correct powers of $\\log x$ and other appropriate changes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Hardy–Littlewood–Chowla conjecture in the presence of a Siegel zero | What's new")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-634158")[#strong[#text("The Hardy–Littlewood–Chowla conjecture in the presence of a Siegel zero | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2021")])]

#text("[…] primes in the indicated range ; this bound is non-trivial for as large as . (See Section 1 of this blog post for some variants of this argument, which were inspired by work of Heath-Brown.) There is also a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-681782")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2023")])]

#text("Dear prof. Tao,")#linebreak()#text(" If we replaced Lambda_2 simply with von Mangoldt function, the argument obviously wouldn’t work anymore, but I have a trouble detecting what part of the proof should crumble. Apparently, in the section concerning the decomposition into G the precise shape of these functions does not have any particular significance provided that the supports are sufficiently restricted. May you give me some hint?")

#text("Best regards!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-681785")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2023")])]

#text("In the very last line of the argument, it is needed that the second derivative of ")#mi("G_{<}")#text(" is positive.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/#comment-681801")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2023")])]

#text("Oh, I see! Thanks a lot.")
]
]
]
