// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/
// Converted to Typst by tao2typ: "2026-10-14T15:16:56.970206+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Cohomology for dynamical systems", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Cohomology for dynamical systems")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 December 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/")[#text("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A ")#link("http://en.wikipedia.org/wiki/Dynamical_system")[#text("dynamical system")]#text(" is a space X, together with an ")#link("http://en.wikipedia.org/wiki/Group_action")[#text("action")]#text(" ")#mi("(g,x) \\mapsto gx")#text(" of some group ")#mi("G = (G,\\cdot)")#text(". [In practice, one often places topological or measure-theoretic structure on X or G, but this will not be relevant for the current discussion. In most applications, G is an abelian (additive) group such as the integers ")#mi("{\\Bbb Z}")#text(" or the reals ")#mi("{\\Bbb R}")#text(", but I prefer to use multiplicative notation here.] A useful notion in the subject is that of an (abelian) ")#emph[#text("cocycle")]#text("; this is a function ")#mi("\\rho: G \\times X \\to U")#text(" taking values in an abelian group ")#mi("U = (U,+)")#text(" that obeys the ")#emph[#text("cocycle equation")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\rho(gh, x) = \\rho(h,x) + \\rho(g,hx)")]]

#text("for all ")#mi("g,h \\in G")#text(" and ")#mi("x \\in X")#text(". [Again, if one is placing topological or measure-theoretic structure on the system, one would want ")#mi("\\rho")#text(" to be continuous or measurable, but we will ignore these issues.] The significance of cocycles in the subject is that they allow one to construct (abelian) ")#emph[#text("extensions")]#text(" or ")#emph[#text("skew products")]#text(" ")#mi("X \\times_\\rho U")#text(" of the original dynamical system X, defined as the Cartesian product ")#mi("\\{ (x,u): x \\in X, u \\in U \\}")#text(" with the group action ")#mi("g(x,u) := (gx,u + \\rho(g,x))")#text(". (The cocycle equation (1) is needed to ensure that one indeed has a group action, and in particular that ")#mi("(gh)(x,u) = g(h(x,u))")#text(".) This turns out to be a useful means to build complex dynamical systems out of simpler ones. (For instance, one can build ")#link("http://en.wikipedia.org/wiki/Nil_manifold")[#text("nilsystems")]#text(" by starting with a point and taking a finite number of abelian extensions of that point by a certain type of cocycle.)")

#text("A special type of cocycle is a ")#emph[#text("coboundary")]#text("; this is a cocycle ")#mi("\\rho: G \\times X \\to U")#text(" that takes the form ")#mi("\\rho(g,x) := F(gx) - F(x)")#text(" for some function ")#mi("F: X \\to U")#text(". (Note that the cocycle equation (1) is automaticaly satisfied if ")#mi("\\rho")#text(" is of this form.) An extension ")#mi("X \\times_\\rho U")#text(" of a dynamical system by a coboundary ")#mi("\\rho(g,x) := F(gx) - F(x)")#text(" can be conjugated to the trivial extension ")#mi("X \\times_0 U")#text(" by the change of variables ")#mi("(x,u) \\mapsto (x,u-F(x))")#text(".")

#text("While every coboundary is a cocycle, the converse is not always true. (For instance, if X is a point, the only coboundary is the zero function, whereas a cocycle is essentially the same thing as a homomorphism from G to U, so in many cases there will be more cocycles than coboundaries. For a contrasting example, if X and G are finite (for simplicity) and G acts ")#link("http://en.wikipedia.org/wiki/Free_action#Types_of_actions")[#text("freely")]#text(" on X, it is not difficult to see that every cocycle is a coboundary.) One can measure the extent to which this converse fails by introducing the ")#emph[#text("first cohomology group")]#text(" ")#mi("H^1(G,X,U) := Z^1(G,X,U) / B^1(G,X,U)")#text(", where ")#mi("Z^1(G,X,U)")#text(" is the space of cocycles ")#mi("\\rho: G \\times X \\to U")#text(" and ")#mi("B^1(G,X,U)")#text(" is the space of coboundaries (note that both spaces are abelian groups). In my forthcoming paper with Vitaly Bergelson and Tamar Ziegler on the ergodic inverse Gowers conjecture (which should be available shortly), we make substantial use of some basic facts about this cohomology group (in the category of measure-preserving systems) that were established in a ")#link("http://www.ams.org/mathscinet-getitem?mr=2150389")[#text("paper of Host and Kra")]#text(".")

#text("The above terminology of cocycles, coboundaries, and cohomology groups of course comes from the theory of ")#link("http://en.wikipedia.org/wiki/Cohomology")[#text("cohomology")]#text(" in ")#link("http://en.wikipedia.org/wiki/Algebraic_topology")[#text("algebraic topology")]#text(". Comparing the formal definitions of cohomology groups in that theory with the ones given above, there is certainly quite a bit of similarity, but in the dynamical systems literature the precise connection does not seem to be heavily emphasised. The purpose of this post is to record the precise fashion in which dynamical systems cohomology is a special case of ")#link("http://en.wikipedia.org/wiki/Cochain_complex")[#text("cochain complex")]#text(" cohomology from algebraic topology, and more specifically is analogous to ")#link("http://en.wikipedia.org/wiki/Singular_cohomology")[#text("singular cohomology")]#text(" (and can also be viewed as the ")#link("http://en.wikipedia.org/wiki/Group_cohomology")[#text("group cohomology")]#text(" of the space of scalar-valued functions on X, when viewed as a G-module); this is not particularly difficult, but I found it an instructive exercise (especially given that my algebraic topology is extremely rusty), though perhaps this post is more for my own benefit that for anyone else.")

#heading(level: 1)[#metadata(none) <tao-8ad31faadf86169cd43f>#text("— Chains —")]

#text("Throughout this discussion, the dynamical system X, the group G, and the group U will be fixed.")

#text("For any ")#mi("n \\geq 0")#text(", we define an ")#emph[#text("n-chain")]#text(" to be a formal integer linear combination of n+1-tuples ")#mi("(g_1,\\ldots,g_n,x)")#text(", where ")#mi("x \\in X")#text(" and ")#mi("g_1,\\ldots,g_n \\in G")#text(". One may wish to think of each such tuple as an “oriented simplex” connecting the n+1 points ")#mi("x, g_n x, g_{n-1} g_n x, \\ldots, g_1 \\ldots g_n x")#text(". Thus, a 0-chain is a formal combination ")#mi("\\sum_{i=1}^m c_i x_i")#text(" of points, a 1-chain is a formal combination ")#mi("\\sum_{i=1}^m c_i (g_i,x_i)")#text(" of “line segments” from ")#mi("x_i")#text(" to ")#mi("g_i x_i")#text(", and so forth. Let ")#mi("C_n(G,X)")#text(" be the space of n-chains; this is an abelian group. We also adopt the convention that ")#mi("C_n(G,X)")#text(" is trivial for ")#mi("n  0")#text(", we define the ")#emph[#text("boundary map")]#text(" ")#mi("\\partial: C_n(G,X) \\to C_{n-1}(G,X)")#text(" to be the unique homomorphism such that")

#tao-aligned(keep: true)[


#tao-math("\\partial (g_1,\\ldots,g_n,x)  & = (g_1,\\ldots,g_{n-1},g_n x)", block: true)



#tao-math(" & + \\sum_{i=1}^{n-1} (-1)^{n-i} (g_1,\\ldots,g_{i-1},g_i g_{i+1}, g_{i+2},\\ldots,g_n, x)", block: true)



#tao-math(" & + (-1)^n (g_2,\\ldots,g_n,x)", block: true)
]

#text("thus for instance")

#tao-aligned(keep: true)[


#tao-math("\\partial (g,x)  & = gx - x", block: true)



#tao-math("\\partial (g,h,x)  & = (g,hx) - (gh,x) + (h,x)", block: true)



#tao-math("\\partial (g,h,k,x)  & = (g,h,kx) - (g,hk,x) + (gh,k,x) - (h,k,x)", block: true)
]

#text("and so forth. Note that this is analogous to the boundary map in ")#link("http://en.wikipedia.org/wiki/Singular_homology")[#text("singular homology")]#text(", if one views the n+1-tuple ")#mi("(x,g_1,\\ldots,g_n)")#text(" as a simplex as discussed earlier. We also define the boundary maps ")#mi("\\partial: C_n(G,X) \\to C_{n-1}(G,X)")#text(" for ")#mi("n \\leq 0")#text(" to be the trivial map, thus for instance ")#mi("\\partial x = 0")#text(". It is not hard to verify the fundamental relation")

#align(center)[#tao-fit-display[#mitex("\\partial^2 = 0")]]

#text("thus turning the sequence of groups ")#mi("C_n(G,X)")#text(" into a ")#link("http://en.wikipedia.org/wiki/Chain_complex")[#text("chain complex")]#text(".")

#text("An n-chain with vanishing boundary is called an ")#emph[#text("n-cycle")]#text(", while an n-chain which is the boundary of an (n+1)-chain is called an ")#emph[#text("n-boundary")]#text("; the spaces of n-cycles and n-boundaries are denoted ")#mi("Z_n(G,X)")#text(" and ")#mi("B_n(G,X)")#text(" respectively. Thus for instance ")#mi("(gh,x) - (h,x) - (g,hx)")#text(" is both a 1-cycle and a 1-boundary. However, if g is a non-trivial group element that fixes x and G is abelian, one can show that ")#mi("(g,x)")#text(" is a 1-cycle but not a 1-boundary.")

#text("We define the ")#emph[#text("homology groups")]#text(" ")#mi("H_n(G,X) := Z_n(G,X)/B_n(G,X)")#text(" for all n. It is a nice exercise to compute these groups in some simple cases, e.g.")

#list(
[#text("If G acts ")#link("http://en.wikipedia.org/wiki/Transitive_action#Types_of_actions")[#text("transitively")]#text(" on X, then ")#mi("H_0(G,X) \\equiv {\\Bbb Z}")#text(".")],
[#text("If G acts ")#link("http://en.wikipedia.org/wiki/Free_action")[#text("freely")]#text(" on X, then ")#mi("H_n(G,X)")#text(" is trivial for ")#mi("n > 0")#text(".")],
[#text("If X is a point, then ")#mi("H_1(G,X) \\equiv G/[G,G]")#text(" is the ")#link("http://en.wikipedia.org/wiki/Abelianization#Abelianization")[#text("abelianisation")]#text(" of G. [Question: Is there a nice description of the higher homology groups ")#mi("H_n(G,X)")#text(", ")#mi("n > 1")#text(" in this case?]")]
)

#text("However, I don’t know of any application of these homology groups to the theory of dynamical systems.")

#heading(level: 1)[#text("— Cochains —")]

#text("An ")#emph[#text("n-cochain")]#text(" is a homomorphism from the space ")#mi("C_n(G,X)")#text(" of n-chains to U. Since ")#mi("C_n(G,X)")#text(" is a free abelian group generated by the simplices ")#mi("(x,g_1,\\ldots,g_n)")#text(", we can view an n-cochain as a function ")#mi("F: (x,g_1,\\ldots,g_n) \\to F(x,g_1,\\ldots,g_n)")#text(" from ")#mi("G \\times \\ldots \\times G \\times X")#text(" to U. (Again, we are ignoring all measure-theoretic or topological considerations here.) The space of all n-cochains is denoted ")#mi("C^n(G,X,U) := \\text{Hom}(C_n(G,X),U)")#text("; this is an abelian group.")

#text("The boundary map ")#mi("\\partial: C_n(G,X) \\to C_{n-1}(G,X)")#text(" defines by duality a ")#link("http://en.wikipedia.org/wiki/Coboundary")[#text("coboundary")]#text(" map ")#mi("\\delta: C^{n-1}(G,X,U) \\to C^n(G,X,U)")#text(", defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\delta F( c ) := F( \\partial c )")]]

#text("for all ")#mi("F \\in C^{n-1}(G,X,U)")#text(" and ")#mi("c \\in C_n(G,X)")#text("; viewing F as a function on simplices, we thus have")

#tao-aligned(keep: true)[


#tao-math("\\delta F(g_1,\\ldots,g_n,x)  & = F(g_1,\\ldots,g_{n-1},g_n x)", block: true)



#tao-math(" & + \\sum_{i=1}^{n-1} (-1)^{n-i} F( g_1,\\ldots,g_{i-1},g_i g_{i+1},\\ldots,g_n,x)", block: true)



#tao-math(" & + (-1)^n F(g_2,\\ldots,g_n,x).", block: true)
]

#text("Thus for instance")

#align(center)[#tao-fit-display[#mitex("\\delta F(g,x) = F(gx) - F(x)")]]

#text("for 0-cochains ")#mi("F:X \\to U")#text(",")

#align(center)[#tao-fit-display[#mitex("\\delta \\rho(g,h,x) = \\rho(g,hx) - \\rho(gh,x) + \\rho(h,x)")]]

#text("for 1-cochains ")#mi("\\rho: G \\times X \\to U")#text(", and so forth.")

#text("Because ")#mi("\\partial^2 = 0")#text(", we have ")#mi("\\delta^2 = 0")#text(", and so ")#mi("C^n(G,X,U)")#text(" becomes a ")#link("http://en.wikipedia.org/wiki/Cochain_complex")[#text("cochain complex")]#text(". n-cochains whose coboundary vanishes are known as ")#emph[#text("n-cocycles")]#text(", and n-cochains which are the coboundary of an (n-1)-cochain are known as ")#emph[#text("n-coboundaries")]#text(". The spaces of n-cocycles and n-coboundaries are denoted ")#mi("Z^n(G,X,U)")#text(" and ")#mi("B^n(G,X,U)")#text(" respectively, allowing us to define the ")#emph[#mi("n^{th}")#text(" cohomology group")]#text(" ")#mi("H^n(G,X,U) := Z^n(G,X,U)/B^n(G,X,U)")#text(".")

#text("When n=0, and if the action of G is ")#link("http://en.wikipedia.org/wiki/Transitive_action#Types_of_actions")[#text("transitive")]#text(" (in the discrete category), minimal (in the topological category), or ")#link("http://en.wikipedia.org/wiki/Ergodic_(adjective)")[#text("ergodic")]#text(" (in the measure-theoretic category), the only 0-cocycles are the constants, and the only 0-coboundary is the zero function, so ")#mi("H^0(G,X,U) \\equiv U")#text(". When n=1, it is not hard to see that the notion of 1-cocycle and 1-coboundary correspond to the notion of cocycle and coboundary discussed at the beginning of this post.")

#text("This whole theory raises the obvious question as to whether the higher cocycles, coboundaries, and cohomology groups have any relevance in dynamical systems. For instance, a 2-cocycle is (after minor notational changes) a function ")#mi("\\psi: G \\times G \\times X \\to U")#text(" that obeys the 2-cocycle equation")

#align(center)[#tao-fit-display[#mitex("\\psi(g,h,kx) - \\psi(g,hk,x) + \\psi(gh,k,x) - \\psi(h,k,x) = 0")]]

#text("while a 2-coboundary is a function of the form")

#align(center)[#tao-fit-display[#mitex("\\psi(g,h,x) := \\rho(gh,x) - \\rho(h,x) - \\rho(g,hx)")]]

#text("for some ")#mi("\\rho: G \\times X \\to U")#text(". Is there some dynamical systems interpretation of these objects, much as 1-cocycles and 1-coboundaries can be interpreted as describing abelian extensions and essentially trivial abelian extensions respectively? I don’t know the answer to this question. (Perhaps one would have to start introducing the concept of a “2-dynamical system”, whatever that means.) In my forthcoming paper with Vitaly Bergelson and Tamar Ziegler, we do briefly encounter 2-coboundaries (we have to deal with various “quasi-cocycles” – 1-chains ")#mi("\\rho")#text(" whose 2-coboundary ")#mi("\\delta \\rho")#text(" does not vanish completely, as with 1-cocycles, but is still of a relatively simple form, such as a constant or a polynomial) but we do not make systematic use of this concept. (We also rely heavily in our paper on the cubic complexes ")#mi("{}X^{[k]}{}")#text(" of Host and Kra, which have some superficial resemblance to the simplex structures appearing here, but I do not know if there is a substantive connection in this regard.)")

#text("Another oddity is that homology and cohomology, as it is classically defined, requires the space of chains, cochains, etc. to all be abelian groups; but for dynamical systems one can certainly talk about cocycles and coboundaries taking values in a non-abelian group U by modifying the definitions slightly, leading to the concept of a ")#emph[#text("group extension")]#text(" of a dynamical system. (In this context, the first cohomology ")#mi("H^1(G,X,U)")#text(" becomes a quotient space rather than a group; see also my ")#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/")[#text("earlier post")]#text(" interpreting these cocycles in the language of gauge theory.) It seems to me that in this case, the dynamical system concept of a cocycle or coboundary cannot be interpreted in terms of classical cohomology theory (but presumably can be handled by ")#link("http://en.wikipedia.org/wiki/Group_cohomology#Non-abelian_group_cohomology")[#text("non-abelian group cohomology")]#text(").")

#text("[")#emph[#text("Update")]#text(", Dec 22: Some typos and LaTeX anomalies fixed.]")

#emph[#text("Update")]#text(", Jan 8: Over at the ")#link("http://golem.ph.utexas.edu/category/2008/12/bridge_building.html")[#text("n-Category Café")]#text(", ")#link("http://golem.ph.utexas.edu/category/2008/12/bridge_building.html")[#text("Minhyong Kim has provided")]#text(" a nice answer to my question about the relevance of higher order cohomology, such as ")#mi("H^2(G,X,U)")#text(", to the problem of extending dynamical systems. Suppose one has a short exact sequence")

#align(center)[#tao-fit-display[#mitex("0 \\to V \\to \\tilde U \\to U \\to 0")]]

#text("of abelian groups, thus one can view ")#mi("\\tilde U")#text(" as the space of pairs ")#mi("(u,v)")#text(" with ")#mi("u\\in U, v \\in V")#text(" with some group addition law")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("(u,v) + (u^{\\prime},v^{\\prime}) := (u+u^{\\prime}, v+v^{\\prime}+B(u,u^{\\prime}))")]]

#text("for some function ")#mi("B: U \\times U \\to V")#text(", that needs to obey a certain set of axioms to make ")#mi("\\tilde U")#text(" an abelian group, which we will not write down here. We then claim that we have a long exact sequence")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\to H^1(G,X,\\tilde U) \\to H^1(G,X,U) \\to H^2(G,X,V) \\to,")]]

#text("thus ")#mi("H^2(G,X,V)")#text(" is capable of detecting whether a U-extension of a G-system X can be lifted to a ")#mi("\\tilde U")#text("-extension.")

#text("The first map in (3) is obvious: the projection from ")#mi("\\tilde U")#text(" to ")#mi("U")#text(" induces a projection from 1-cocycles ")#mi("\\tilde \\rho: G \\times X \\to \\tilde U")#text(" to 1-cocycles ")#mi("\\rho: G \\times X \\to U")#text(" which maps 1-coboundaries to 1-coboundaries, and thus maps ")#mi("H^1(G,X,\\tilde U)")#text(" to ")#mi("H^1(G,X,U)")#text(". The second map requires a bit more thought. Suppose one is given a 1-cocycle ")#mi("\\rho: G \\times X \\to U")#text(" and asks whether it can be lifted to a 1-cocycle ")#mi("\\tilde \\rho: G \\times X \\to \\tilde U")#text(" by the above projection. Writing ")#mi("\\tilde \\rho = (\\rho,\\sigma)")#text(" for some ")#mi("\\sigma: G \\times X \\to V")#text(" and using (1), (2), we see that the question is equivalent to finding a ")#mi("\\sigma")#text(" that obeys the equation")

#align(center)[#tao-fit-display[#mitex("\\sigma(gh, x) = \\sigma(h,x) + \\sigma(g,hx) + B( \\rho(h,x), \\rho(g,hx) )")]]

#text("or in other words, to show that the map ")#mi("\\Phi(\\rho): (g,h,x) \\mapsto B(\\rho(h,x), \\rho(g,hx) )")#text(" is a V-valued 2-coboundary. The same observation (now setting ")#mi("\\sigma=0")#text(") shows that the map ")#mi("(g,h,x) \\mapsto (0,\\Phi(\\rho))")#text(" is a ")#mi("\\tilde U")#text("-valued 2-coboundary (indeed, it is the coboundary of ")#mi("(\\rho,0)")#text("), hence a ")#mi("\\tilde U")#text("-valued 2-cocycle, and thus ")#mi("\\Phi(\\rho)")#text(" is a V-valued 2-cocycle, and so the map ")#mi("\\rho \\mapsto \\Phi(\\rho)")#text(" is a map from 1-cocycles ")#mi("\\rho: G \\times X \\to U")#text(" to 2-cocycles ")#mi("\\Phi(\\rho): G \\times G \\times X \\to V")#text(". Similarly, given two 1-cocycles ")#mi("\\rho, \\rho^{\\prime}: G \\times X \\to U")#text(", we see that ")#mi("(\\rho+\\rho^{\\prime},0)")#text(" differs from ")#mi("(\\rho,0)+(\\rho^{\\prime},0)")#text(" by some V-valued 1-cochain, so on taking derivatives we see that ")#mi("\\Phi(\\rho+\\rho^{\\prime})")#text(" differs from ")#mi("\\Phi(\\rho)+\\Phi(\\rho^{\\prime})")#text(" by some 2-coboundary, thus ")#mi("\\Phi")#text(" is linear modulo 2-coboundaries. Finally, if ")#mi("\\rho")#text(" is a U-valued 1-coboundary, then ")#mi("(\\rho,0)")#text(" is the sum of a ")#mi("\\tilde U")#text("-valued 1-coboundary and a V-valued 1-cochain, and so on taking derivatives we see that ")#mi("\\Phi")#text(" maps 1-coboundaries to 2-coboundaries. (Presumably the above arguments are a special case of one of the standard diagram chasing lemmas in homological algebra, but I don’t know which one it is. One could also verify these facts from the axioms of B induced from (2) and the abelian group structure on ")#mi("\\tilde U")#text(", but this turns out to be remarkably tedious.) Hence it induces a map from ")#mi("H^1(G,X,U)")#text(" to ")#mi("H^2(G,X,V)")#text(", and then (3) is exact by the preceding discussion.")

#heading(level: 1)[#text("Comments (26)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AA")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-34232")[#strong[#text("AA")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2008")])]

#text("Minor typo: Fourth paragraph, first sentence should probably read “While every coboundary is a cocycle, the converse is not always true.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b1a49c59b96f3c2948f86aa04a4802d0015fc6d9bdea53f7c1dbd76200051f76-d2fc500b58c8a3993dc1fece64a3e4936fbebc4656365659e18219338c0a58b3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hilbertthm90")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-34233")[#strong[#text("hilbertthm90")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2008")])]

#text("Thanks! This is the first post in a long while that’s in a field I could follow. I actually just posted on a similar thing but was giving results about cohomology groups of Galois groups. Actually, the real reason I came down here was to post the typo someone else already caught, then decided to actually comment anyway.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f033e7308b4cf1267f303af87f5bc0a962861d193ad03e688227541c53cbe8ff-05c0a4b086d8c6dbe145d080ad79a1b521e2cb05747030e901311750b51833c7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikael Vejdemo Johansson")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-34235")[#strong[#text("Mikael Vejdemo Johansson")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2008")])]

#text("The boundary formula you have listed above comes from a slightly more general formula by using specific choices for group actions from the left and the right on the modules considered – thus, with a slightly more general formula, we’d have ")#mi("\\partial(g,x) = gx \\pm xg")#text(", and ")#mi("\\partial(g,h,x) = g(h,x)\\pm(gh,x)\\pm(g,hx)\\pm(g,h)x")#text(", et.c.")

#text("Would these formulae make sense in the dynamical systems world at all? Or is there nothing to be gained from extending to bimodules?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87cda33277ed0e36ed08b37f23e619ddd55a49872f3f50b63023f93e6c8be7f3-3f316aed179e1d32e236bab92992d498def6db375b3fb8bbc752ac1236a1a3d8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marlowe, PI")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-34237")[#strong[#text("Marlowe, PI")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2008")])]

#text("Dear Terry:")

#text("I’m starting my thesis on certain cohomology theories, and it’s nice to find applications of the ideas in such diverse fields, specially since right now I’m focusing in the algebraic machinery and sometimes “real life” gets too blurred behind it.")

#text("As far as applications of higher cohomological groups goes, there seems to be a certain regularity in that if a certain cohomology group helps to classify extensions up to conjugation, the next cohomology group helps you find out if a certain candidate for an extension CAN be extended to a full extension. The most common example is when you want to deform a certain geometrical structure: you have a sequence of deformation parameters (each a cochain), and if you have a finite number of cochains you think might be the first part of a series, you can look at an associated cochain in the next cohomology group, pray for it to be zero, and if it is, that means the sequence can be continued one more step (in a possibly non unique way). The last paragraph might perhaps point in that direction?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67ff93f4e7e15999ef94c77de9b661b79bc05b2e0408a9d62a698e2753f94207-2973badff05aece490148e8bea3c8f572310e327a9bf689a7107707af2c8142e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of isomorphismes")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-470380")[#strong[#text("isomorphismes")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2016")])]

#text("Mark ____ (50centfunctions on tumblr) came up with a nice real-life dynamical system where the left and right inverses (thought of as undoing earlier-time moves or later-time moves) are noticeably different: touching up a billboard that’s been faded by the sun (right inverse), versus painting a billboard so that it will fade into the desired image (left inverse).")

#link("http://isomorphism.es/post/109259777716/good-example-of-a-function-from-real-life")[#text("http://isomorphism.es/post/109259777716/good-example-of-a-function-from-real-life")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-34238")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2008")])]

#text("Thanks for the correction! I suppose the analogue of a bimodule in dynamical systems would be a space X with both a left and right action of a group G, which commute with each other; but I don’t know of any interesting example of this other than that when X is basically G itself (or maybe a quotient of G by a normal subgroup), in which case one is really doing group cohomology rather than dynamical systems.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-682007")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2023")])]

#text("There is a beautiful example of a bimodule in complex dynamics that first emerges in the `twisted rabbit’ problem. For concreteness consider a quadratic polynomial f(z) = z^2+c such that the forward orbit P(f) of 0 consists of exactly 3 points and f^3(0)=0. There are exactly 3 such polynomials; call this set S.")#linebreak()#text(" (The elements of S are often called the rabbit, the basilica, and the co-rabbit, based on the shape of their Julia sets.)")

#text("Now the space B of branched coverings of the plane admits an action of G, the mapping class group of the plane rel P(f), on the right and the left. Namely you can form the new map hfg(z) = h(f(g z)). The topological map hfg is combinatorial equivalent to a unique polynomial, which must be one of those in S. Predicting which element of S corresponds to, say h^n f, where h is a Dehn twist, is a delicate problem solved by Bartholdi and Nekrashevych in 2006. It involves a fairly complete description of the G-bimodule B. For a recent development and some illustrations, see:")

#link("https://e.math.cornell.edu/people/belk/talkslides/TwistedRabbitTalkMichigan.pdf")[#text("Click to access TwistedRabbitTalkMichigan.pdf")]

#text("-CTM")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/297ba35fceba57126d9613193c7cd9b835407adfe13d536390a27ced310e32e2-a380eea33e7db527042e9dcd6848d8e1ec0adf2e9b8d886dab8b90081140dfe3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-34293")[#strong[#text("Peter")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2008")])]

#text("It looks like you can also obtain this definition of homology using Hochshild homology (although someone should correct me if I’m not being careful enough). Given a ring ")#mi("A")#text(" and a bimodule ")#mi("M")#text(", define ")#mi("C_n := M \\otimes_\\mathbb{Z} A^{\\otimes n}")#text(", and for each ")#mi("n")#text(" the maps ")#mi("d_i: C_n \\to C_{n-1}")#text(" for ")#mi("0 \\leq i \\leq n")#text(" by")

#mi("d_0(m,a_1,a_2,\\ldots a_n) = (m \\cdot a_1,a_2,\\ldots,a_n)")#text(",")#linebreak()#text(" ")#mi("d_i(m,a_1,\\ldots,a_n) = (m,a_1,a_2,\\ldots,a_{i-1}, a_ia_{i+1}, a_{i+2},\\ldots,a_n)")#text(", and")#linebreak()#text(" ")#mi("d_n(m,a_1,\\ldots,a_n) = (a_n\\cdot m,a_1,a_2,\\ldots,a_{n-1})")#text(",")#linebreak()#text(" with the nth boundary ")#mi("d:C_n \\to C_{n-1}")#text(" define by ")#mi("d = \\sum_{i=0}^{i=n} (-1)^i d_i")#text(". The Hochschild homology is defined as the homology of this complex.")

#text("To recover the homology defined in the post in the case of a group ")#mi("G")#text(" acting on a space ")#mi("X")#text(", I think you can take ")#mi("A")#text(" to be the group ring ")#mi("A := \\mathbb{Z} G")#text(" and ")#mi("M")#text(" to be the free abelian group generated by points in ")#mi("X")#text(". The left module structure is given by the group action and the right module structure is the trivial structure.")

#text("This is really just using slightly different language to describe the same thing, I suppose, but I guess in math writing problems or definitions in slightly different language is useful sometimes. Looking at it this way makes it seem a little bit more likely that it might be useful looking at right actions of ")#mi("G")#text(" other than the trivial one. I don’t know much about dynamical systems, so I’m not sure if it could actually be useful or not.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Surya")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-34353")[#strong[#text("Surya")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2008")])]

#text("I am thinking what all this means for information and coding theory. I had always wanted to build a geometric version of information theory based on a “cohomology” of dynamical systems. This cohomology might be a suitable candidate for that….")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96b3e509256c7598de2811cb73619c50814d0e8789aebf4489b052efb1ff9469-23874bc04f9ca71fdd76fbfd8e1bc4a368b7dd44d38814005dfc571163d8fb88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pierre baudot")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-469491")[#strong[#text("Pierre baudot")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("May be this paper could give an answer to the cohomological meaning for information:")#linebreak()#text(" ")#link("http://www.mdpi.com/1099-4300/17/5/3253")[#text("http://www.mdpi.com/1099-4300/17/5/3253")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96b3e509256c7598de2811cb73619c50814d0e8789aebf4489b052efb1ff9469-23874bc04f9ca71fdd76fbfd8e1bc4a368b7dd44d38814005dfc571163d8fb88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pierre baudot")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-469492")[#strong[#text("Pierre baudot")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("PS: The cohomology of information functions is constructed on Hochshild’s introduced by Peter in the last two posts and allows a unique characterisation of Shannon entropy.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b80ed17b0a9ca583b1105e476b6af80dd8f244fcc9a23ade804810bf73d37f0b-01a28f9cc6b908126320c63a0dcd0e26b95be19c987a15b8c7f6a7991f3abce6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Corfield")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-34775")[#strong[#text("David Corfield")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2009")])]

#text("This post was briefly discussed over at our ")#link("http://golem.ph.utexas.edu/category/2008/12/bridge_building.html")[#text("blog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-34799")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2009")])]

#text("Thanks David! I’ve taken the liberty of putting one of the comments on that blog posting (which answered one of my questions) in an update to the body of the post here. As Marlowe already predicted, the second cohomology group detects obstructions to a partial extension of a dynamical system lifting to a full extension.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An inverse theorem for the uniformity seminorms associated with the action of F^infty_p « What’s new")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-35120")[#strong[#text("An inverse theorem for the uniformity seminorms associated with the action of F^infty_p « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2009")])]

#text("[…] as coboundaries, and two cocycles which differ by a coboundary are said to be cohomologous [see my previous post for further discussion]. Thus, our task is to show the cocycle is cohomologous to a phase […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95ee4192e78cd6063a5b63f5ee7437641bc698ea24b8431523552a2da83328b6-f0d15dc189270364cf23e7a3f056db5525f4f18d86bbc7ba58060fc3b480ef00.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam Epstein")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-39761")[#strong[#text("Adam Epstein")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2009")])]

#text("V. Nekresheych develops the notion of permutational bimodule, with many examples and applications, in his book “Self-Similar Groups”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 5: The inverse conjecture for the Gowers norm I. The finite field case « What’s new")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-45030")[#strong[#text("254B, Notes 5: The inverse conjecture for the Gowers norm I. The finite field case « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2010")])]

#text("[…] expression is known as a -coboundary (see this blog post for more discussion). To eliminate it, we use the finite characteristic to discretise the problem […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-46054")[#strong[#text("The cohomological equation for dynamical systems « Climbing Mount Bourbaki")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2010")]

#text("[…] that I’m working on, so I shall not spend much time on it, though. Readers should look at this post on Terence Tao’s blog for more in this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Central extensions of Lie groups, and cocycle averaging « What’s new")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-53573")[#strong[#text("Central extensions of Lie groups, and cocycle averaging « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2011")])]

#text("[…] functions that obey this equation as cocycles (the reason for this terminology being explained in this previous blog post). The space of all such cocyles is denoted (or , if we wish to emphasise that we are working for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52199fa021c337c1315ca742cb5f11ddbb063546fdfab7b8e3ffdfe5bf11cf1b-7c732e386466770316e978619f8228a1388b783fbcf060fc75f647127b3efab3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Freddie Manners")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-218679")[#strong[#text("Freddie Manners")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2013")])]

#text("Rather a late correction, but in the section “cochains”, on the line just before the text “for 1-cochains $\\rho : G \\times H \\rightarrow U”, I think there should be a $\\rho(h, x)$ in place of a $\\rho(g, x)$.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b42c93b7e191f9d381686399283794aadae0d1960addfc2a84fa12dcb256d1bd-2833158bed29ee1131c5c010bebe775e3690da0cf7a858f3947d324614ec0774.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trent Knebel")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-466017")[#strong[#text("Trent Knebel")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2016")])]

#text("I don’t speak portuguese, but I wish I did because this mini-course on dynamical cohomology looks really interesting: ")#link("https://www.youtube.com/playlist?list=PLo4jXE-LdDTT_z9urUQjYxl0uonw9xcBV")[#text("https://www.youtube.com/playlist?list=PLo4jXE-LdDTT_z9urUQjYxl0uonw9xcBV")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9c89788382566484e0322e84193a5fccca6f71b5e515d8b1f87c2c1381d6474-890f2a4504b54fc4f76dab6f8f5b33d80dbc49a57176c02262032e77cd776e0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mma")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-474702")[#strong[#text("mma")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2016")])]

#text("Dear Terry, I’m not a matematician, and just trying to make aquaintaince with homology and cohomology. Unfortunately, I don’t understand your singular cohomolgy analogy. For example, how do I derive your ")#mi("\\partial (g,h,x) = (g,hx) - (gh,x) + (h,x)")#text(" equation, based on this analogy? As far as I see, ")#mi("(g,h,x)")#text(" corresponds to the ")#mi("(x,hx,ghx)")#text(" simplex, and the boundary of this (as the boundary of a simplicial complex) is ")#mi("(hx,ghx)-(x,ghx)+(x,hx)")#text(". How do your ")#mi("(g,hx) - (gh,x) + (h,x)")#text(" expression follow from this? Woould you explain this, please?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-474718")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2016")])]

#text("To avoid confusion let’s use square brackets rather than parentheses to denote simplices. Then the identifications are")

#mi("(g,h,x) \\equiv [x,hx,ghx]; \\quad (g,x) \\equiv [x, gx]")

#text("so in particular")

#mi("(g,hx) \\equiv [hx, ghx]; \\quad (gh, x) \\equiv [x, ghx]; \\quad (h,x) \\equiv [x, hx]")

#text("and so the group boundary equation ")#mi("\\partial(g,h,x) = (g,hx) - (gh,x) + (h,x)")#text(" corresponds to the simplicial boundary equation ")#mi("[x,hx,ghx] = [hx,ghx] - [x,ghx] + [x,hx]")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9c89788382566484e0322e84193a5fccca6f71b5e515d8b1f87c2c1381d6474-890f2a4504b54fc4f76dab6f8f5b33d80dbc49a57176c02262032e77cd776e0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mma")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-474719")[#strong[#text("mma")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2016")])]

#text("Yes, as you guessed, I tried to convert the members in the wrong direction. Your squere brackets solved my confusion. Thank you very much, Terry!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9c89788382566484e0322e84193a5fccca6f71b5e515d8b1f87c2c1381d6474-890f2a4504b54fc4f76dab6f8f5b33d80dbc49a57176c02262032e77cd776e0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mma")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-474872")[#strong[#text("mma")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2016")])]

#text("I think that this correspondence is very similar to the “bar resolution” in Maclane’s Homology, (p.118, (5,11)), However, the numbering and the useage of square brackets and parentheses are opposite there.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 1% quasimorphisms and group cohomology | What's new")]], [#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-502492")[#strong[#text("1% quasimorphisms and group cohomology | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2018")])]

#text("[…] general, one can phrase this problem in the language of group cohomology (discussed in this previous post). Call a map a -cocycle. A -cocycle is a map obeying the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/#comment-505558")[#strong[#text("Cohomologous functions and the Livsic theorem | Vaughn Climenhaga's Math Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2018")]

#text("[…] Remark 1 For a discussion of how this is connected to the notion of cohomology in algebraic topology, see Terry Tao’s blog post from December 2008. […]")
]
