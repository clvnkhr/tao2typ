// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/12/05/milliman-lecture-ii-additive-combinatorics-and-random-matrices/
// Converted to Typst by tao2typ: "2026-10-14T15:16:33.241307+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Milliman Lecture II: Additive combinatorics and random matrices", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Milliman Lecture II: Additive combinatorics and random matrices")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 December 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/12/05/milliman-lecture-ii-additive-combinatorics-and-random-matrices/")[#text("https://terrytao.wordpress.com/2007/12/05/milliman-lecture-ii-additive-combinatorics-and-random-matrices/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is my ")#link("http://www.math.washington.edu/Seminars/milliman_0708.php")[#text("second Milliman lecture")]#text(", in which I talk about recent applications of ideas from additive combinatorics (and in particular, from the inverse Littlewood-Offord problem) to the theory of discrete ")#link("http://en.wikipedia.org/wiki/Random_matrix")[#text("random matrices")]#text(".")#linebreak()#text(" ")#metadata(none) <tao-9a3a7c731bc1e2512147>#text("In many areas of physics, chemistry, and computer science, one often has to study large matrices A, which for sake of discussion we shall take to be square, thus ")#mi("A = (a_{ij})_{1 \\leq i,j \\leq n}")#text(" is an ")#mi("n \\times n")#text(" matrix for some large integer n, and the ")#mi("a_{ij}")#text(" are real or complex numbers. In some cases A will be very structured (e.g. ")#link("http://en.wikipedia.org/wiki/Self-adjoint")[#text("self-adjoint")]#text(", ")#link("http://en.wikipedia.org/wiki/Upper_triangular")[#text("upper triangular")]#text(", sparse, ")#link("http://en.wikipedia.org/wiki/Circulant_matrix")[#text("circulant")]#text(", low ")#link("http://en.wikipedia.org/wiki/Rank_%28linear_algebra%29")[#text("rank")]#text(", etc.) but in other cases one expects A to be so complicated that there is no usable structure to exploit in the matrix. In such cases, one often makes the non-rigorous (but surprisingly accurate, in practice) assumption that A behaves like a random matrix, whose entries are drawn ")#link("http://en.wikipedia.org/wiki/Independent_and_identically-distributed_random_variables")[#text("independently and identically")]#text(" from a single probability distribution (which could be continuous, discrete, or a combination of both). Each choice of distribution determines a different random matrix ")#link("http://en.wikipedia.org/wiki/Distribution_ensemble")[#text("ensemble")]#text(". Two particularly fundamental examples of continuous ensembles are:")

#enum(start: 1, 
[#text("The ")#emph[#text("real Gaussian random matrix ensemble")]#text(", in which each ")#mi("a_{ij}")#text(" is distributed independently according to the standard ")#link("http://en.wikipedia.org/wiki/Normal_distribution")[#text("normal distribution ")]#mi("N(0,1) \\equiv \\frac{1}{\\sqrt{2\\pi}} e^{-x^2/2}\\ dx")#text(". This ensemble has the remarkable feature of being invariant under the ")#link("http://en.wikipedia.org/wiki/Orthogonal_group")[#text("orthogonal group")]#text(" O(n); if R is a rotation or reflection matrix in O(n), and A is distributed as a real Gaussian random matrix, then RA and AR are also distributed as a real Gaussian random matrix. (This is ultimately because the product of n Gaussian measures ")#mi("\\frac{1}{\\sqrt{2\\pi}} e^{-x^2/2}\\ dx")#text(" on ")#mi("{\\Bbb R}")#text(" is a Gaussian measure ")#tao-math("\\frac{1}{(2\\pi)^{n/2}} e^{-\\left|x\\right|^2/2}\\ dx", block: false)#text(" on ")#mi("{\\Bbb R}^n")#text(", which is manifestly rotation-invariant.)")],
[#text("The ")#emph[#text("complex Gaussian random matrix ensemble")]#text(", in which the ")#mi("a_{ij}")#text(" are distributed according to a complex normal distribution ")#tao-math("\\frac{1}{\\pi} e^{-\\left|z\\right|^2}\\ dz", block: false)#text(". This ensemble has the feature of being invariant under the unitary group U(n).")]
)

#text("Two particularly fundamental examples of discrete ensembles are")

#enum(start: 1, 
[#text("The ")#emph[#text("Bernoulli ensemble")]#text(", in which each ")#mi("a_{ij}")#text(" is distributed independently and uniformly in the set ")#mi("\\{-1,+1\\}")#text(", thus A is a random matrix of signs.")],
[#text("The ")#emph[#text("lazy (or sparse) Bernoulli ensemble")]#text(", in which each ")#mi("a_{ij}")#text(" is independently equal to -1 or +1 with probability p/2, and equal to 0 with probability 1-p, for some fixed ")#mi("0 \\leq p \\leq 1")#text(", thus A is a sparse matrix of signs of expected density p.")]
)

#text("The Bernoulli and sparse Bernoulli ensembles arise naturally in computer science and numerical analysis, as they form a simple model for simulating the effect of numerical roundoff error (or other types of digital error) on a large matrix. Continuous ensembles such as the Gaussian ensembles, in contrast, are natural models for matrices in the analog world, and in particular in physics and chemistry. [For reasons that are still somewhat mysterious, these ensembles, or more precisely their self-adjoint counterparts, also seem to be good models for various important statistics in number theory, such as the statistics of zeroes of the ")#link("http://en.wikipedia.org/wiki/Riemann_zeta_function")[#text("Riemann zeta function")]#text(", but this is not the topic of my discussion here.] There are of course many other possible ensembles of interest that one could consider, but I will stick to the Gaussian and Bernoulli ensembles here for simplicity.")

#text("If A is drawn randomly from one of the above matrix ensembles, then we have a very explicit understanding of how each of the coefficients of the matrix A behaves. But in practice, we want to study more “global” properties of the matrix A which involve rather complicated interactions of all the coefficients together. For instance, we could be interested in the following (closely related) questions:")

#list(
[#emph[#text("Dynamics")]#text(". Given a typical vector ")#mi("x \\in {\\Bbb R}^n")#text(", what happens to the iterates ")#mi("Ax, A^2 x, \\ldots, A^m x")#text(" in the limit ")#mi("m \\to \\infty")#text("?")],
[#emph[#text("Expansion and contraction")]#text(". Given a non-zero vector x, how does the norm ")#tao-math("\\left\\|Ax\\right\\|", block: false)#text(" of Ax compare with the norm ")#tao-math("\\left\\|x\\right\\|", block: false)#text(" of x? What is the largest ratio ")#tao-math("\\left\\|Ax\\right\\|/\\left\\|x\\right\\|", block: false)#text("? The smallest ratio? The average ratio?")],
[#emph[#text("Invertibility")]#text(". Is the equation ")#mi("A x = b")#text(" solvable for every vector b? Do small fluctuations in b always cause small fluctuations in x, or can they cause large fluctuations? (In other words, is the invertibility problem stable?)")]
)

#text("As any student of linear algebra knows, these questions can be answered satisfactorily if one knows the ")#link("http://en.wikipedia.org/wiki/Eigenvalue")[#text("eigenvalues ")]#mi("\\lambda_1,\\ldots,\\lambda_n \\in {\\Bbb C}")#text(" (counting multiplicity) and ")#link("http://en.wikipedia.org/wiki/Singular_value")[#text("singular values")]#text(" ")#mi("\\sigma_1 \\geq \\ldots \\geq \\sigma_n \\geq 0")#text(" of the matrix A. (As the matrix A is not ")#link("http://en.wikipedia.org/wiki/Self-adjoint")[#text("self-adjoint")]#text(", the eigenvalues can be complex-valued even if the coefficients of A are real-valued; however, the singular values are always non-negative reals, because ")#mi("AA^*")#text(" is self- adjoint and ")#link("http://en.wikipedia.org/wiki/Positive-definite_matrix")[#text("positive semi-definite")]#text(".) For instance:")

#list(
[#text("The largest eigenvalue magnitude ")#tao-math("\\sup_{1 \\leq k \\leq n} \\left|\\lambda_k\\right|", block: false)#text(" determines the maximal rate of exponential growth or decay of ")#mi("A^m x")#text(" (ignoring polynomial growth corrections coming from repeated eigenvalues), while the smallest eigenvalue magnitude ")#tao-math("\\inf_{1 \\leq k \\leq n} \\left|\\lambda_k\\right|", block: false)#text(" determines the minimal rate of exponential growth.")],
[#text("The ratio ")#tao-math("\\left\\|Ax\\right\\|/\\left\\|x\\right\\|", block: false)#text(" has a maximal value of ")#mi("\\sigma_1")#text(", a minimal value of ")#mi("\\sigma_n")#text(", and a root mean square value of ")#mi("(\\frac{1}{n} \\sum_{k=1}^n \\sigma_k^2)^{1/2}")#text(" if the orientation of x is selected uniformly at random.")],
[#text("The matrix A is invertible if and only if all eigenvalues are non-zero, or equivalently if ")#mi("\\sigma_n")#text(" is positive.")],
[#text("The stability of the invertibility problem is controlled by the ")#link("http://en.wikipedia.org/wiki/Condition_number")[#text("condition number")]#text(" ")#mi("\\sigma_1/\\sigma_n")#text(".")]
)

#text("So, one of the fundamental problems in the theory of random matrices is to understand how the eigenvalues and singular values of a random matrix A are distributed. (More generally, it is of interest to study the eigenvalues and singular values of A+B, where A is drawn from a standard random matrix ensemble, and B is a fixed deterministic matrix, but for simplicity we will not discuss this case here.) But how does one get a handle on these numbers?")

#text("The direct approach of working with the ")#link("http://en.wikipedia.org/wiki/Characteristic_equation")[#text("characteristic equation")]#text(" ")#mi("\\det(A - \\lambda I) = 0")#text(" (or ")#mi("\\det(AA^* - \\sigma^2 I) = 0")#text(") looks very unpromising; one is asking to find the roots of a large degree polynomial, most of whose coefficients depend in a hopelessly complicated way on the coefficients on A.")

#text("In the special cases of the Gaussian orthogonal and unitary ensembles, there is a massive amount of algebraic structure coming from the action of O(n) and U(n) that allows one to explicitly compute various multidimensional integrals, and this approach actually works! One gets a very explicit and useful explicit formula for the joint eigenvalue distribution (first worked out by Ginibre, I believe) this way. But for more general ensembles, such as the Bernoulli ensemble, such algebraic structure is not present, and so it is unlikely that any useful explicit formula for the joint eigenvalue distribution exists. However, one can still obtain a lot of useful information if, instead of trying to locate each eigenvalue or singular value directly, one instead tries to compute various special averages (e.g. ")#link("http://en.wikipedia.org/wiki/Moment_%28mathematics%29")[#text("moments")]#text(") of these eigenvalues or singular values. For instance, from undergraduate linear algebra we have the fundamental formulae")

#align(center)[#tao-fit-display[#mitex("\\text{tr}(A) = \\sum_{k=1}^n \\lambda_k")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\text{det}(A) = \\prod_{k=1}^n \\lambda_k")]]

#text("connecting the ")#link("http://en.wikipedia.org/wiki/Trace_%28linear_algebra%29")[#text("trace")]#text(" and ")#link("http://en.wikipedia.org/wiki/Determinant")[#text("determinant")]#text(" of a matrix A to its eigenvalues, and more generally")

#tao-aligned(keep: true)[


#tao-math("\\text{tr}(A^m)  & = \\sum_{k=1}^n \\lambda_k^m", block: true, numbering: n => [#text("(1)")])



#tao-math("\\text{det}(A - zI)  & = \\prod_{k=1}^n (\\lambda_k-z)", block: true)
]

#text("and similarly for the singular values, we have")

#align(center)[#tao-fit-display[#mitex("\\text{tr}((AA^*)^m) = \\sum_{k=1}^n \\sigma_k^{2m}")]]

#align(center)[#mi("\\text{det}(AA^* - zI) = \\prod_{k=1}^n (\\sigma_k^2-z)")#text(".")]

#text("So, if one can easily compute traces and determinants of the matrix A (and various other matrices related to A), then one can in principle get quite a bit of control on the eigenvalues and singular values. It is also worth noting that the eigenvalues and singular values are related to each other in several ways; for instance, we have the identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\prod_{k=1}^n \\left|\\lambda_k\\right| = \\prod_{k=1}^n \\sigma_k", block: true)]]

#text("(which comes from comparing the determinants of A and ")#mi("AA^*")#text("), the inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\sigma_n \\leq \\sup_{1 \\leq k \\leq n} \\left|\\lambda_k\\right| \\leq \\sigma_1", block: true)]]

#text("(which comes from looking at the ratio ")#tao-math("\\left\\|Ax\\right\\|/\\left\\|x\\right\\|", block: false)#text(" when x is an eigenvector), and the inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\sum_{1 \\leq k \\leq n} \\left|\\lambda_k\\right|^2 \\leq \\sum_{1 \\leq k \\leq n} \\sigma_k^2", block: true)]]

#text("(which is easiest to see by using ")#link("http://en.wikipedia.org/wiki/QR_factorization")[#text("QR")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Iwasawa_decomposition")[#text("KAN")]#text(") decomposition of the eigenvector matrix to rotate the matrix A to be upper triangular, and then computing the trace of ")#mi("AA^*")#text(").")

#text("Let’s give some simple examples of this approach. If we take A to be the Gaussian or Bernoulli ensemble, then the trace of A has expectation zero, and so we know that the sum ")#mi("\\sum_{k=1}^n \\lambda_k")#text(" has expectation zero also. (Actually, this is easy to see for symmetry reasons: A has the same distribution as -A, and so the distribution of eigenvalues also has a symmetry around the origin.) The trace of ")#mi("AA^*")#text(", by contrast, is the sum of the squares of all the matrix coefficients, and will be close to ")#mi("n^2")#text(" (for the Bernoulli ensemble, it is exactly ")#mi("n^2")#text("); thus we see that ")#mi("\\sum_{k=1}^n \\sigma_k^2 \\sim n^2")#text(", and so by (4) we have ")#tao-math("\\sum_{k=1}^n \\left|\\lambda_k\\right|^2 = O(n^2)", block: false)#text(". So we see that the eigenvalues and singular values should be about ")#mi("O(\\sqrt{n})")#text(" on the average. By working a little harder (e.g. by playing with very high moments of ")#mi("AA^*")#text(") one can show that the largest singular value is also going to be ")#mi("O(\\sqrt{n})")#text(" with high probability, which then implies by (3) that all eigenvalues and singular values will be ")#mi("O(\\sqrt{n})")#text(". Unfortunately, this approach does not seem to yield much information on the ")#emph[#text("least")]#text(" singular value, which plays a major role in the invertibility and stability of A.")

#text("It is now natural to normalise the eigenvalues and singular values of A by ")#mi("\\frac{1}{\\sqrt{n}}")#text(", and consider the distribution of the set of normalised eigenvalues ")#mi("\\{ \\frac{1}{\\sqrt{n}} \\lambda_k: 1 \\leq k \\leq n \\}")#text(". If one plots these normalised eigenvalues numerically in the complex plane for moderately large n (e.g. n=100), one sees a ")#link("http://mathworld.wolfram.com/GirkosCircularLaw.html")[#text("remarkable distribution")]#text("; the eigenvalues appear to be uniformly distributed in the unit circle ")#tao-math("D := \\{ z \\in {\\Bbb C}: \\left|z\\right| \\leq 1 \\}", block: false)#text(". (For small n, there is a little bit of a clustering on the real line, just because polynomials with real coefficients tend to have a couple of real zeroes, but this clustering goes away in the limit as n goes to infinity.) This phenomenon is known as the ")#link("http://mathworld.wolfram.com/GirkosCircularLaw.html")[#text("circular law")]#text("; more precisely, if we let n tend to infinity, then for every sufficiently nice set R in the plane (e.g. one could take R to be a rectangle), one has")

#align(center)[#tao-math("\\lim_{n \\to \\infty} \\frac{1}{n} \\{ 1 \\leq k \\leq n: \\frac{1}{\\sqrt{n}} \\lambda_k \\in R \\} \\to \\frac{1}{\\pi} \\left|R \\cap D\\right|", block: false)#text(".")]

#text("(Technically, this formulation is known as the ")#emph[#text("strong circular law")]#text("; there is also a ")#emph[#text("weak circular law")]#text(", which asserts that one has convergence in probability rather than almost sure convergence. But for this talk I will ignore these distinctions.)")

#text("The circular law was first proven in the case of the Gaussian unitary ensemble by Mehta in 1967, using an explicit formula for the joint distribution of the eigenvalues. But for more general ensembles, in which explicit formulae were not available, progress was more difficult. The method of moments (in which one uses (1) to compute the sums of powers of the eigenvalues) is not very useful because of the cancellations caused by the complex nature of the eigenvalues; indeed, one can show that ")#mi("\\text{tr}((\\frac{1}{\\sqrt{n}} A)^m)")#text(" is roughly zero for every m, which is consistent with the circular law but also does not preclude, for instance, all the eigenvalues clustering at the origin. [For random ")#emph[#text("self-adjoint")]#text(" matrices, the moment method works quite well, leading for instance to ")#link("http://mathworld.wolfram.com/WignersSemicircleLaw.html")[#text("Wigner’s semi-circular law")]#text(".]")

#text("The first breakthrough was by Girko in 1984, who observed that the eigenvalue distribution could be recovered from the quantities")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\frac{1}{n} \\log \\left|\\det(\\frac{1}{\\sqrt{n}} A - zI)\\right| = \\frac{1}{n} \\sum_{k=1}^n \\log \\left|\\frac{1}{\\sqrt{n}} \\lambda_k - z\\right|", block: true)]]

#text("for complex z (this expression is known as the ")#emph[#text("Stieltjes transform")]#text(" of the normalised eigenvalue distribution of A). To compute this quantity, Girko then used the formula (2) to relate the determinant of ")#mi("\\frac{1}{\\sqrt{n}} A - zI")#text(" with the singular values of this matrix. The singular value distribution could then be computed by the moment method (note that singular values, unlike eigenvalues, are real and non-negative, and so we do not have cancellation problems). Putting this all together and doing a large number of algebraic computations, one eventually obtains (formally, at least) a proof of the circular law.")

#text("There was however a technical difficulty with the above analysis, which was that the formula (2) becomes very unstable when the least singular value is close to zero (basically because of a division by zero problem). This is not merely a technical issue but is fundamental to the general problem of controlling eigenvalues of non-self-adjoint matrices ")#mi("\\frac{1}{\\sqrt{n}} A")#text(": these eigenvalues can become very unstable near a region of ")#link("http://en.wikipedia.org/wiki/Pseudospectrum")[#text("pseudospectrum")]#text(", which can be defined as a complex number z such that the least singular value of ")#mi("\\frac{1}{\\sqrt{n}} A-zI")#text(" is small. The classic demonstration of this comes from the perturbed shift matrices")

#align(center)[#mi("A_\\varepsilon := \\begin{pmatrix} 0 & 1 & 0 & \\ldots & 0\\\\ 0 & 0 & 1 & \\ldots & 0 \\\\ \\vdots & & & \\ddots & \\\\ 0 & 0 & 0 & \\ldots & 1 \\\\ \\varepsilon & 0 & 0 & \\ldots & 0 \\end{pmatrix}")#text(".")]

#text("For sake of discussion let us take n to be even. When ")#mi("\\varepsilon = 0")#text(", this matrix is singular, with least singular value ")#mi("\\sigma_1 = 0")#text(" and with all n generalised eigenvalues equal to 0. But when ")#mi("\\varepsilon")#text(" becomes positive, the least singular value creeps up to ")#mi("\\varepsilon")#text(", but the n eigenvalues move rapidly away from the origin, becoming ")#mi("\\varepsilon^{1/n} e^{2\\pi i j/n}")#text(" for ")#mi("j=1,\\ldots,n")#text(". This is ultimately because the zero set of the characteristic polynomial ")#mi("z^n - \\varepsilon")#text(" is very sensitive to the value of ")#mi("\\varepsilon")#text(" when that parameter is close to zero.")

#text("So, in order to make the circular law argument complete, one needs to get good lower bounds on the least singular value of the random matrix A (as well as variants of this matrix, such as ")#mi("\\frac{1}{\\sqrt{n}} A - zI")#text("). In the case of continuous (non-Gaussian) ensembles, this was first done by Bai in 1997. To illustrate the basic idea, let us look at a toy problem, to show that the least singular value of a Gaussian orthogonal matrix A is usually non-zero (i.e. A is invertible with high probability). For this, we use some linear algebra. Let ")#mi("X_1,\\ldots,X_n")#text(" denote the rows of A, which we can view as vectors in ")#mi("{\\Bbb R}^n")#text(". Then the least singular value of A vanishes precisely when ")#mi("X_1,\\ldots,X_n")#text(" lie on a ")#link("http://en.wikipedia.org/wiki/Hyperplane")[#text("hyperplane")]#text(". This implies that one of the vectors here is a linear combination of the other n-1; by symmetry, we conclude that the probability that the least singular value vanishes is bounded by n times the probability that ")#mi("X_n")#text(" (say) is a linear combination of ")#mi("X_1,\\ldots,X_{n-1}")#text(". But ")#mi("X_1,\\ldots,X_n")#text(" span a hyperplane at best; and ")#mi("X_n")#text(" has a continuous distribution and so has only a zero probability of lying in the hyperplane. Thus the least singular value vanishes with probability zero. It turns out that this argument is robust enough to also show that the least singular value not only avoids zero, but in fact keeps a certain distance away from it; for instance, it is not hard to show with this method that the least singular value is at least ")#mi("1/n^2")#text(" (say) with probability ")#mi("1-o(1)")#text(", basically because each row vector is not only not a linear combination of the other rows, but in fact keeps a certain distance away from the space spanned by the other rows, with high probability.")

#text("For discrete random matrices, one runs into a new difficulty: a row vector such as ")#mi("X_n")#text(" is no longer continuously distributed, and so can in fact concentrate on a hyperplane with positive probability. For instance, in the Bernoulli case, a row vector X is just a random corner of the discrete cube ")#mi("\\{-1,+1\\}^n")#text(". There are certain hyperplanes which X can visit quite frequently; for instance, X will have a probability 1/2 of lying in the hyperplane ")#mi("\\{ (x_1,\\ldots,x_n): x_1 = x_2 \\}")#text(". In particular, there is a probability ")#mi("1/2^n")#text(" that all rows ")#mi("X_1,\\ldots,X_n")#text(" lie in this hyperplane, which would cause the Bernoulli matrix A to be non-invertible. (In terms of A itself, what is going on is that there is a ")#mi("1/2^n")#text(" chance that the first column and second column coincide, which will of course destroy invertibility.) In particular, A now has a non-zero chance of being singular. [It is in fact conjectured that the singularity probability is close to this value, or more precisely equal to ")#mi("(1/2+o(1))^n")#text(". The best known upper bound currently for this probability is ")#mi("(1/\\sqrt{2}+o(1))^n")#text(", due to Bourgain, building upon earlier work of Kahn-Komlos-Szemeredi, and Vu and myself.]")

#text("One can hope to sum the singularity probability over all hyperplanes, but there are of course infinitely many hyperplanes in ")#mi("{\\Bbb R}^n")#text(". Fortunately, only a few of these will have a particularly high chance of capturing X. The problem now hinges on getting a sufficiently strong control on the number of hyperplanes which are “rich” in the sense that they have a high probability of capturing X (or equivalently, that they have a large intersection with the discrete cube ")#mi("\\{-1,+1\\}^n")#text(").")

#text("This is where (finally!) the additive combinatorics comes in. Let ")#mi("v = (v_1,\\ldots,v_n) \\in {\\Bbb R}^n")#text(" be a normal vector to a given hyperplane V. (For instance, if ")#mi("V = \\{ (x_1,\\ldots,x_n): x_1 = x_2 \\}")#text(", one could take ")#mi("v = (1,-1,0,\\ldots,0)")#text(".) Then V is rich if and only if the random variable")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\epsilon_1 v_1 + \\ldots + \\epsilon_n v_n")]]

#text("vanishes a large proportion of the time, where ")#mi("\\epsilon_1,\\ldots,\\epsilon_n \\in \\{-1,+1\\}")#text(" are independent signs. (One can view (6) as the result of an n-step ")#link("http://en.wikipedia.org/wiki/Random_walk")[#text("random walk")]#text(", in which the ")#mi("j^{th}")#text(" step of the walk has magnitude ")#tao-math("\\left|v_i\\right|", block: false)#text(".) To put it another way, if ")#mi("(v_1,\\ldots,v_n)")#text(" is associated to a rich hyperplane, then there are many additive relations amongst the coefficients ")#mi("v_1,\\ldots,v_n")#text(". What kinds of sets of numbers have such a strong amount of structure? (This problem is known as the ")#emph[#text("inverse Littlewood-Offord problem")]#text("; the ")#link("http://en.wikipedia.org/wiki/Littlewood-Offord_problem")[#text("forward Littlewood-Offord problem ")]#text("concerns how often (6) vanished for a given set of numbers ")#mi("v_1,\\ldots,v_n")#text(".)")

#text("Well, one way that many of the sums (6) could vanish is if many of the ")#mi("v_i")#text(" are themselves zero; for instance, we have already seen that if ")#mi("(v_1,\\ldots,v_n) = (1,-1,0,\\ldots,0)")#text(", then half of the sums (6) vanish. But this is a rather degenerate case, and it is intuitively obvious that the more non-zero terms one has in the random walk, the less likely it is that the sum is going to vanish. Indeed, there is an observation of Erdős (a quick application of ")#link("http://en.wikipedia.org/wiki/Sperner%27s_theorem")[#text("Sperner’s theorem")]#text(") that if k of the coefficients ")#mi("v_1,\\ldots,v_n")#text(" are non-zero,then (6) can only vanish at most ")#mi("O(1/\\sqrt {k})")#text(" of the time. This bound is sharp; if, for instance, ")#mi("v_1=\\ldots=v_k=1")#text(" and ")#mi("v_{k+1}=\\ldots=v_n=0")#text(", then the theory of random walks tells us that (6) is distributed in a roughly Gaussian and discrete fashion around the origin with ")#link("http://en.wikipedia.org/wiki/Standard_deviation")[#text("standard deviation")]#text(" ")#mi("\\sqrt{k}")#text(", and so (6) should vanish about ")#mi("O(1/\\sqrt{k})")#text(" of the time (and one can check this easily enough using ")#link("http://en.wikipedia.org/wiki/Stirling%27s_approximation")[#text("Stirling’s formula")]#text("). [In fact, this case is essentially the exact optimum, as follows from Erdős’ argument.]")

#text("So, now suppose that all the ")#mi("v_i")#text(" are non-zero. Then Erdős’ result tells us that (6) vanishes at most ")#mi("O(1/\\sqrt{n})")#text(" of the time. But in most cases one can do a lot better; if, for instance, the ")#mi("v_i")#text(" are linearly independent over the rationals, then (6) in fact never vanishes at all. It turns out that by intensively using the tools from additive combinatorics (including Fourier analysis and the ")#link("http://en.wikipedia.org/wiki/Geometry_of_numbers")[#text("geometry of numbers")]#text(") one can obtain a satisfactory classification of the vectors ")#mi("v = (v_1,\\ldots,v_n)")#text(" for which (6) has a high chance of vanishing; the precise description is technical, but basically in order for (6) to equal zero often, most of the coordinates of v must lie inside an ")#link("http://en.wikipedia.org/wiki/Generalized_arithmetic_progression")[#text("generalised arithmetic progression")]#text(" of reasonably small size and dimension. Using such facts, it is possible to get good bounds on the singularity probability and on the least singular value of random discrete matrices such as Bernoulli matrices, leading in particular to the circular law for such discrete matrices (various formulations of this law have been recently obtained by ")#link("http://arxiv.org/abs/math/0702386")[#text("Götze-Tikhomirov")]#text(", ")#link("http://arxiv.org/abs/0705.3773")[#text("Pan-Zhou")]#text(", and ")#link("http://arxiv.org/abs/0708.2895")[#text("Van and myself")]#text("). [To get the best bounds on the singularity probability, one uses a slightly different argument, using Fourier analysis and additive combinatorics to compare the vanishing probability of a random walk with that of a lazy random walk, thus creating a relationship between the singularity of Bernoulli matrices and sparse Bernoulli matrices; see for instance ")#link("http://front.math.ucdavis.edu/math.CO/0501313")[#text("my paper with Van")]#text(" on this topic.]")

#text("This theory for understanding singularity behaviour of discrete random matrices promises to have applications to some other areas of mathematics as well. For instance, the subject of ")#link("http://www.cs.yale.edu/homes/spielman/SmoothedAnalysis/index.html")[#text("smoothed analysis")]#text(", in which the introduction of random noise to various numerical algorithms (such as the ")#link("http://en.wikipedia.org/wiki/Simplex_method")[#text("simplex method")]#text(") increases the stability of the algorithm, can use this theory to extend the theoretical results in that subject from continuous noise models to discrete noise models (such as those created by roundoff error).")

#text("[")#emph[#text("Update")]#text(", Dec 6: Terminology and typos corrected.]")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2007/12/05/milliman-lecture-ii-additive-combinatorics-and-random-matrices/#comment-19204")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2007")])]

#text("This is a very nice talk. A correction about terminology: the terms Gaussian Orthogonal Ensemble and Gaussian Unitary Ensemble do not refer to the ensembles you defined above, but rather to their symmetric and Hermitian counterparts, respectively. In the GOE for instance, ")#mi("a_{ij}")#text(" are independent for ")#mi("i \\leq j")#text("; ")#mi("a_{ii}")#text(" are ")#mi("N(0,2)")#text("; ")#mi("a_{ij}")#text(" are ")#mi("N(0,1)")#text(" for ")#mi("i < j")#text(". Alternatively, if ")#mi("G")#text(" is the ensemble you defined with all independent ")#mi("N(0,1)")#text(" entries, then ")#mi("GOE = (G+G^t)/2")#text(" (up to the choice of normalization). The random matrix ")#mi("G")#text(" you defined is typically called simply a Gaussian random matrix.")

#text("The way I prefer to think of these ensembles is that the distribution of ")#mi("G")#text(" is the standard (up to normalization) Gaussian measure on the space of real ")#mi("n \\times n")#text(" matrices equipped with the Hilbert-Schmidt inner product, whereas the distribution of the GOE is the standard Gaussian measure on the subspace of real symmetric matrices. A similar remark holds for the complex counterpart of ")#mi("G")#text(" and the GUE.")

#text("The GOE/GUE as standardly defined are not invariant under multiplication by orthogonal/unitary matrices, but are invariant under conjugation by orthogonal/unitary matrices. There is a large literature on so-called orthogonal and unitary ensembles of random matrices, which generalize the GOE/GUE. These ensembles consist of real symmetric or Hermitian random matrices with dependent entries, which are invariant under orthogonal or unitary conjugation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/05/milliman-lecture-ii-additive-combinatorics-and-random-matrices/#comment-19214")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2007")])]

#text("Thanks for the corrections and comments!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fcbfaf3df0eb68cc28d41c84b898ca547ea8f6fdd26017af51f433bd90ca0e16-e2b402347d05061f283554192c57d99a3dbc4dcba38916c1118a48c36a39b525.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Smith")]], [#link("https://terrytao.wordpress.com/2007/12/05/milliman-lecture-ii-additive-combinatorics-and-random-matrices/#comment-19218")[#strong[#text("Tom Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2007")])]

#text("A small correction: in your “fundamental formula” for det(A-zI) you’ve got an extra “I” on the RHS, and similarly for det(AA* – zI). (I suppose one could regard this I as being the identity in R, ie 1, and hence parse the statement as correct; but it seems a bit of a stretch).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/12/05/milliman-lecture-ii-additive-combinatorics-and-random-matrices/#comment-19236")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2007")])]

#text("Do you think methods like these could be extended to obtaining upper bounds on the probability that a given sequence of n numbers can be realized as the sequence of singular values of a random matrix? This would in particular be interesting for symmetric random matrices, as they might give bounds on probability that two random graphs are cospectral.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/12/05/milliman-lecture-ii-additive-combinatorics-and-random-matrices/#comment-19255")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2007")]

#text("[…] Milliman Lecture II: Additive combinatorics and random matrices This is my second Milliman lecture, in which I talk about recent applications of ideas from additive combinatorics (and […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 558")]], [#link("https://terrytao.wordpress.com/2007/12/05/milliman-lecture-ii-additive-combinatorics-and-random-matrices/#comment-19289")[#strong[#text("558")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2007")])]

#text("Can anyone say a little bit more about the statement below. I’m not sure how to show it.")

#text("it is not hard to show with this method that the least singular value is at least 1/n^2 (say) with probability 1-o(1), basically because each row vector is not only not a linear combination of the other rows, but in fact keeps a certain distance away from the space spanned by the other rows, with high probability.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/05/milliman-lecture-ii-additive-combinatorics-and-random-matrices/#comment-19295")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2007")])]

#text("Dear Tom: thanks for the correction!")

#text("Dear Anonymous: For continuous ensembles, it is likely that the joint distribution of eigenvalues or singular values is also continuous (though this is not entirely trivial to show), and so any given n-tuple would appear with probability 0. For discrete ensembles, the question is likely to be quite tricky. A related problem, which Van and I have thought about on occasion, is to get some non-trivial bound on how often the determinant of a Bernoulli matrix can equal some fixed non-zero value. (We understand the event where the determinant vanishes pretty well, but I can’t tell you too much about how often, say, det(A) is equal to ")#mi("2^n")#text(".)")

#text("Dear 558: The other n-1 rows ")#mi("X_1,\\ldots,X_{n-1}")#text(" lie in a hyperplane, which have some unit normal vector w. Now, the distance from ")#mi("X_n")#text(" to the hyperplane is ")#tao-math("\\left|X_n \\cdot w\\right|", block: false)#text(". Since the coefficients of ")#mi("X_n")#text(" are Gaussian and independent, one can easily see that ")#mi("X_n \\cdot x")#text(" is also Gaussian (with a variance of n) and the claim follows. Note that if there are some linear dependencies amongst the ")#mi("X_1,\\ldots,X_{n-1}")#text(" then the hyperplane will not be unique, but this is not a problem; the distance from ")#mi("X_n")#text(" to the hyperplane still serves as a lower bound for the distance from ")#mi("X_n")#text(" to the true span of the ")#mi("X_1,\\ldots,X_{n-1}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Leopardi")]], [#link("https://terrytao.wordpress.com/2007/12/05/milliman-lecture-ii-additive-combinatorics-and-random-matrices/#comment-19316")[#strong[#text("Paul Leopardi")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2007")])]

#text("Hi Terry,")#linebreak()#text(" Thanks for your lectures. The Bernoulli ensemble strongly reminds me of the Hadamard conjecture.")#linebreak()#text(" ")#link("http://en.wikipedia.org/wiki/Hadamard_matrix")[#text("http://en.wikipedia.org/wiki/Hadamard_matrix")]#linebreak()#text(" This is because the Hadamard conjecture asks about the maximum determinant of a square (-1,1) matrix of a given size, whereas the Bernoulli ensemble focuses your attention on probability distributions based on the set of all (-1,1) matrices of a given size.")

#text("I participated in Nick Witte’s AMSI Summer School course on random matrices in 2003. Since then I have been thinking on and off about a problem involving the reproducing kernel Gram matrices associated with polynomial interpolation on the sphere.")

#text("In [1] Womersley and Sloan define the Gram matrix G, which is real, symmetric and positive semi-definite, and examine the interpolation properties of sets of points on the sphere which maximize the determinant of G (“extremal fundamental systems”). In [2] Sloan and Womersley examine the quadrature properties of extremal fundamental systems.")

#text("What I’ve been thinking about in a vague way is: given (n+1)^2 points uniformly distributed on the 2-sphere, what is the distribution of G, and in what way can this be treated as an ensemble of random matrices? In particular, what can be said about the resulting distributions of eigenvalues, singular values, and determinants? What knowledge of the distribution is needed to obtain knowledge of the extremal values and vice-versa?")

#text("[1] Robert S. Womersley and Ian H. Sloan, How Good can Polynomial Interpolation on the Sphere be?, Advances in Computational Mathematics 14 (2001) 195-226.")

#text("[2] Ian H. Sloan and Robert S. Womersley, Extremal systems of points and numerical integration on the Sphere, Advances in Computational Mathematics 21 (2004) 102-125.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2007/12/05/milliman-lecture-ii-additive-combinatorics-and-random-matrices/#comment-19321")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2007")])]

#text("Regarding Terry’s response to Anonymous’s question: as Terry discussed, the invariance properties of Gaussian random matrices allow one to do quite a lot. In particular, whereas the distribution of the determinant of the Bernoulli ensemble is difficult to understand, the distribution of the determinant of a Gaussian random matrix can be determined exactly. (And for a fixed ")#mi("n")#text(", not just asymptotically!) It turns out to be a product of independent chi-square random variables with different degrees of freedom.")

#text("It’s not clear to me, however, whether it’s appropriate here to wave the magic wand of “universality” and use this result to make any conjectures about the determinant of the Bernoulli ensemble.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54dd1583026134dc4e104ba0a453a466b557c4c7910304ce680dedcd5027035c-b656500dbdcb3cec3e0b384418f76cc54ffd06373cccba7cb58b7cd18cb7c075.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of van vu")]], [#link("https://terrytao.wordpress.com/2007/12/05/milliman-lecture-ii-additive-combinatorics-and-random-matrices/#comment-19326")[#strong[#text("van vu")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2007")])]

#text("Dear Mark,")

#text("YEs, I think there are such conjectures. We (Terry and I) can prove some sort of universality result for ESDs. On the other hand,")#linebreak()#text(" at a very fine scale, the universality does not hold any more.")

#text("BEst, Van")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/12/05/milliman-lecture-ii-additive-combinatorics-and-random-matrices/#comment-19334")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2007")])]

#text("Dear Terry,")

#text("Thanks for the enlightening lecture. Can these ideas be extended to matrices over finite fields? Also here there is the assumption that entries are iid. Suppose we want to get rid of this assumption and make some dependence among the entries.")#linebreak()#text(" Lets say only certian number of 1’s can appear in any row and certain number of 1’s in any column. Does this really complicate the problem?")

#text("Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68c038d0c68bded1b26ebe6d3164b88a8c4632e5af29470e2f8fe28aa1b370f2-b25bbcbdadbb9e29a1b9625a13d4328954c729792394b246586157246137f8a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of No wai")]], [#link("https://terrytao.wordpress.com/2007/12/05/milliman-lecture-ii-additive-combinatorics-and-random-matrices/#comment-19353")[#strong[#text("No wai")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2007")])]

#text("Dear Prof Tao,")

#text("One of the most bizarre phenomenon in random matrix theory is the Tracy-Widom idea that , for example, the probability density function of the largest eigenvalue distribution in the GUE should be linked to (the tau functions) of certain integrable differential equations. In a sense, the appearance of these Painleve transcendants, with their remarkable analytic properties, is precisely what gives the conjectural links to zeta statistics.")

#text("Integrability provides perhaps the ultimate example of “structure” in nonlinear differential equations. On the other hand, your examples in this lecture are clearly using the “pseudostructure” methods of additive combinatorics.")

#text("This prompts the question: what is the natural “pseudostructured” equivalent of integrable differential equations?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/05/milliman-lecture-ii-additive-combinatorics-and-random-matrices/#comment-19503")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2007")])]

#text("Dear Paul,")

#text("It seems that information about the average case distribution of the determinant does not reveal too much information about the extreme case of the determinant, which is what is needed for Hadamard’s conjecture. For instance, Turan showed that the standard deviation of the determinant of a random Bernoulli matrix is ")#mi("\\sqrt{n!}")#text(", which is significantly less than the value ")#mi("\\sqrt{n^n}")#text(" of the determinant of a Hadamard matrix. So this tells you (by Chebyshev’s inequality) that Hadamard matrices are only a small fraction of the set of all Bernoulli matrices, but doesn’t shed much light as to whether they exist at all.")

#text("Dear anonymous: there are some results for the singularity of random Bernoulli matrices over finite fields, see e.g. this paper of Kahn and Komlos:")

#link("http://www.ams.org/mathscinet-getitem?mr=1833067")[#text("http://www.ams.org/mathscinet-getitem?mr=1833067")]

#text("The methods are slightly different, though.")

#text("Dear No wai: I would say that the defining characteristic of structure is the presence of a group action that is large enough (or “transitive” enough) to completely determine the object being studied. For instance, with completely integrable systems it is the action of the maximal torus that can be viewed as conferring the structure. I guess one could call Hamiltonian systems that have a finite number of conservation laws but are not completely integrable to be “pseudostructured”, but it is not clear the extent to which this perspective is useful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of B.G")]], [#link("https://terrytao.wordpress.com/2007/12/05/milliman-lecture-ii-additive-combinatorics-and-random-matrices/#comment-21159")[#strong[#text("B.G")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2007")])]

#text("An interesting and accessible talk which makes me brainstorm for applications in my own field, that of time series prediction.")

#text("When studying a time-series where the time-evolution is approximated as (A + B) x_n = x_(n+1) where A is assumed to have gaussian elements, it might be useful to sample stretches of it to determine the parameters for the gaussian distribution and the eigenvalues, to get probabilities for future behaviour. (a runaway process for instance). I’m assuming that the process is non-stationary so that this sampling would have to be done on recent data.")

#text("But knowing only x_1,…x_k, does one run into the problem of invertibility stability? If it’s gaussian I should already know that the eigenvalues are O(sqrt(n)) but I would also need a test to determine if A really IS gaussian.")

#text("Can such a test be done without the invertibility stability creating trouble and are there special results or considerations when dealing with a time series?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/12/05/milliman-lecture-ii-additive-combinatorics-and-random-matrices/#comment-512061")[#strong[#text("Konstantin Tikhomrov: The Probability that a Bernoulli Matrix is Singular | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2019")]

#text("[…] are related posts on Tao’s blog What’s New. A post on Tao’s Milliman’s lecture on the additive combinatorics and random matrices; On the permamnent of random Bernoulli […]")
]
