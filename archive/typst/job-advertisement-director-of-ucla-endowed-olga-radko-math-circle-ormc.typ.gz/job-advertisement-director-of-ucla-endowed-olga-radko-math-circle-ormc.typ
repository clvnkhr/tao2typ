// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2021/02/13/job-advertisement-director-of-ucla-endowed-olga-radko-math-circle-ormc/
// Converted to Typst by tao2typ: "2026-10-14T15:20:37.811479+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Job advertisement: Director of UCLA Endowed Olga Radko Math Circle (ORMC)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Job advertisement: Director of UCLA Endowed Olga Radko Math Circle (ORMC)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 February 2021")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2021/02/13/job-advertisement-director-of-ucla-endowed-olga-radko-math-circle-ormc/")[#text("https://terrytao.wordpress.com/2021/02/13/job-advertisement-director-of-ucla-endowed-olga-radko-math-circle-ormc/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[I am posting this advertisement in my capacity as chair of the ")#link("https://circles.math.ucla.edu/circles/leadership.shtml")[#text("Steering Committee")]#text(" for the UCLA Endowed Olga Radko Math Circle – T.]")]

#text("The ")#link("https://ww3.math.ucla.edu/")[#text("Department of Mathematics")]#text(" at the University of California, Los Angeles, is ")#link("https://recruit.apo.ucla.edu/JPF06182")[#text("inviting applications")]#text(" for the position of an Academic Administrator who will serve as the Director of the ")#link("https://circles.math.ucla.edu/circles/")[#text("UCLA Endowed Olga Radko Math Circle (ORMC)")]#text(". The Academic Administrator will have the broad responsibility for administration of the ORMC, an outreach program with weekly activities for mathematically inclined students in grades K-12. Currently, over 300 children take part in the program each weekend. Instruction is delivered by a team of over 50 docents, the majority of whom are UCLA undergraduate and graduate students.")

#text("The Academic Administrator is required to teach three mathematics courses in the undergraduate curriculum per academic year as assigned by the Department. This is also intended to help with the recruitment of UCLA students as docents and instructors for the ORMC.")

#text("As the director of ORMC, the Academic Administrator will have primary responsibility for all aspects of ORMC operations:")

#list(
[#text("Determining the structure of ORMC, including the number and levels of groups")],
[#text("Recruiting, training and supervising instructors, docents, and postdoctoral fellows associated with the ORMC")],
[#text("Developing curricular materials and providing leadership in development of innovative ways of explaining mathematical ideas to school children")],
[#text("Working with the Mathematics Department finance office to ensure timely payment of stipends and wages to ORMC instructors and docents, as appropriate")],
[#text("Maintaining ORMC budget and budgetary projections, ensuring that the funds are used appropriately and efficiently for ORMC activities, and applying for grants as appropriate to fund the operations of ORMC")],
[#text("Working with the Steering Committee and UCLA Development to raise funds for ORMC, both from families whose children participate in ORMC and other sources")],
[#text("Admitting students to ORMC, ensuring appropriate placement, and working to maintain a collegial and inclusive atmosphere conducive to learning for all ORMC attendees")],
[#text("Reporting to and working with the ORMC Steering Committee throughout the year")]
)

#text("A competitive candidate should have leadership potential and experience with developing mathematical teaching materials for the use of gifted school children, as well as experience with teaching undergraduate mathematics courses. Candidates must have a Ph.D. degree (or equivalent) or expect to complete their Ph.D. by June 30, 2021.")

#text("Applications should be received by March 15, 2021. Further details on the position and the application process can be found at the ")#link("https://recruit.apo.ucla.edu/JPF06182")[#text("application page")]#text(".")

#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7fa0682acc3de156d19fad43b7dba72e0fa9aa39165d4043812b834b3d1fb6b8-21c1cdb5f0c18cfad5525d665274c50ce0f669895a651e15aac57a0d01905cad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SIKUN LAN")]], [#link("https://terrytao.wordpress.com/2021/02/13/job-advertisement-director-of-ucla-endowed-olga-radko-math-circle-ormc/#comment-622595")[#strong[#text("SIKUN LAN")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2021")])]

#text("Prof. Tao,")

#text("I have worked with Olga teaching AIME and Caltech/Harvey Mudd Math Competition class for the Math Circle for one quarter. I am interested in the position but since I am teaching at the Thousand Oaks High School, I won’t be available till the summer. If the position is still open by then, please let me know.")

#text("Thanks, Sikun (Kevin) Lan PhD in math, UCLA 310-279-2805")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/13/job-advertisement-director-of-ucla-endowed-olga-radko-math-circle-ormc/#comment-622628")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2021")])]

#text("I think that you may have to be a bit more proactive if you want to get a job like this.")
]
]
