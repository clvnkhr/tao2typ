// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/05/21/multiple-recurrence-and-convergence-results-associated-to-f_pomega-actions/
// Converted to Typst by tao2typ: "2026-10-14T16:37:01.665872+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Multiple recurrence and convergence results associated to F_p^omega-actions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Multiple recurrence and convergence results associated to F_p^omega-actions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 May 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/05/21/multiple-recurrence-and-convergence-results-associated-to-f_pomega-actions/")[#text("https://terrytao.wordpress.com/2013/05/21/multiple-recurrence-and-convergence-results-associated-to-f_pomega-actions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.osu.edu/~bergelson.1/")[#text("Vitaly Bergelson")]#text(", ")#link("http://www.technion.ac.il/~tamarzr/")[#text("Tamar Ziegler")]#text(", and I have just uploaded to the arXiv our joint paper “")#link("http://arxiv.org/abs/1305.4717")[#text("Multiple recurrence and convergence results associated to ")#mi("{{\\bf F}_{p}^{\\omega}}")#text("-actions")]#text("“. This paper is primarily concerned with ")#emph[#text("limit formulae")]#text(" in the theory of multiple recurrence in ergodic theory. Perhaps the most basic formula of this type is the ")#emph[#text("mean ergodic theorem")]#text(", which (among other things) asserts that if ")#mi("{(X,{\\mathcal X}, \\mu,T)}")#text(" is a measure-preserving ")#mi("{{\\bf Z}}")#text("-system (which, in this post, means that ")#mi("{(X,{\\mathcal X}, \\mu)}")#text(" is a probability space and ")#mi("{T: X \\mapsto X}")#text(" is measure-preserving and invertible, thus giving an action ")#mi("{(T^n)_{n \\in {\\bf Z}}}")#text(" of the integers), and ")#mi("{f,g \\in L^2(X,{\\mathcal X}, \\mu)}")#text(" are functions, and ")#mi("{X}")#text(" is ergodic (which means that ")#mi("{L^2(X,{\\mathcal X}, \\mu)}")#text(" contains no ")#mi("{T}")#text("-invariant functions other than the constants (up to almost everywhere equivalence, of course)), then the average ")#metadata(none) <tao-55ea09e5715d0a8d9d94>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{1}{N} \\sum_{n=1}^N \\int_X f(x) g(T^n x)\\ d\\mu")]]

#text("converges as ")#mi("{N \\rightarrow \\infty}")#text(" to the expression")

#align(center)[#tao-fit-display[#mitex("(\\int_X f(x)\\ d\\mu) (\\int_X g(x)\\ d\\mu);")]]

#text("see e.g. this ")#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")[#text("previous blog post")]#text(". Informally, one can interpret this limit formula as an equidistribution result: if ")#mi("{x}")#text(" is drawn at random from ")#mi("{X}")#text(" (using the probability measure ")#mi("{\\mu}")#text("), and ")#mi("{n}")#text(" is drawn at random from ")#mi("{\\{1,\\ldots,N\\}}")#text(" for some large ")#mi("{N}")#text(", then the pair ")#mi("{(x, T^n x)}")#text(" becomes uniformly distributed in the product space ")#mi("{X \\times X}")#text(" (using product measure ")#mi("{\\mu \\times \\mu}")#text(") in the limit as ")#mi("{N \\rightarrow \\infty}")#text(".")

#text("If we allow ")#mi("{(X,\\mu)}")#text(" to be non-ergodic, then we still have a limit formula, but it is a bit more complicated. Let ")#mi("{{\\mathcal X}^T}")#text(" be the ")#mi("{T}")#text("-invariant measurable sets in ")#mi("{{\\mathcal X}}")#text("; the ")#mi("{{\\bf Z}}")#text("-system ")#mi("{(X, {\\mathcal X}^T, \\mu, T)}")#text(" can then be viewed as a ")#emph[#text("factor")]#text(" of the original system ")#mi("{(X, {\\mathcal X}, \\mu, T)}")#text(", which is equivalent (in the sense of measure-preserving systems) to a trivial system ")#mi("{(Z_0, {\\mathcal Z}_0, \\mu_{Z_0}, 1)}")#text(" (known as the ")#emph[#text("invariant factor")]#text(") in which the shift is trivial. There is then a projection map ")#mi("{\\pi_0: X \\rightarrow Z_0}")#text(" to the invariant factor which is a factor map, and the average ")#link(<tao-55ea09e5715d0a8d9d94>)[#text("(1)")]#text(" converges in the limit to the expression ")#metadata(none) <tao-7374df08a7a6cf109af4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\int_{Z_0} (\\pi_0)_* f(z) (\\pi_0)_* g(z)\\ d\\mu_{Z_0}(x),")]]

#text("where ")#mi("{(\\pi_0)_*: L^2(X,{\\mathcal X},\\mu) \\rightarrow L^2(Z_0,{\\mathcal Z}_0,\\mu_{Z_0})}")#text(" is the pushforward map associated to the map ")#mi("{\\pi_0: X \\rightarrow Z_0}")#text("; see e.g. ")#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/")[#text("this previous blog post")]#text(". We can interpret this as an equidistribution result. If ")#mi("{(x,T^n x)}")#text(" is a pair as before, then we no longer expect complete equidistribution in ")#mi("{X \\times X}")#text(" in the non-ergodic, because there are now non-trivial constraints relating ")#mi("{x}")#text(" with ")#mi("{T^n x}")#text("; indeed, for any ")#mi("{T}")#text("-invariant function ")#mi("{f: X \\rightarrow {\\bf C}}")#text(", we have the constraint ")#mi("{f(x) = f(T^n x)}")#text("; putting all these constraints together we see that ")#mi("{\\pi_0(x) = \\pi_0(T^n x)}")#text(" (for almost every ")#mi("{x}")#text(", at least). The limit ")#link(<tao-7374df08a7a6cf109af4>)[#text("(2)")]#text(" can be viewed as an assertion that this constraint ")#mi("{\\pi_0(x) = \\pi_0(T^n x)}")#text(" are in some sense the “only” constraints between ")#mi("{x}")#text(" and ")#mi("{T^n x}")#text(", and that the pair ")#mi("{(x,T^n x)}")#text(" is uniformly distributed relative to these constraints.")

#text("Limit formulae are known for multiple ergodic averages as well, although the statement becomes more complicated. For instance, consider the expression ")#metadata(none) <tao-3c504ac87a8749340062>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\frac{1}{N} \\sum_{n=1}^N \\int_X f(x) g(T^n x) h(T^{2n} x)\\ d\\mu")]]

#text("for three functions ")#mi("{f,g,h \\in L^\\infty(X, {\\mathcal X}, \\mu)}")#text("; this is analogous to the combinatorial task of counting length three progressions in various sets. For simplicity we assume the system ")#mi("{(X,{\\mathcal X},\\mu,T)}")#text(" to be ergodic. Naively one might expect this limit to then converge to")

#align(center)[#tao-fit-display[#mitex("(\\int_X f\\ d\\mu) (\\int_X g\\ d\\mu) (\\int_X h\\ d\\mu)")]]

#text("which would roughly speaking correspond to an assertion that the triplet ")#mi("{(x,T^n x, T^{2n} x)}")#text(" is asymptotically equidistributed in ")#mi("{X \\times X \\times X}")#text(". However, even in the ergodic case there can be additional constraints on this triplet that cannot be seen at the level of the individual pairs ")#mi("{(x,T^n x)}")#text(", ")#mi("{(x, T^{2n} x)}")#text(". The key obstruction here is that of ")#emph[#text("eigenfunctions")]#text(" of the shift ")#mi("{T: X \\rightarrow X}")#text(", that is to say non-trivial functions ")#mi("{f: X \\rightarrow S^1}")#text(" that obey the eigenfunction equation ")#mi("{Tf = \\lambda f}")#text(" almost everywhere for some constant (or ")#mi("{T}")#text("-invariant) ")#mi("{\\lambda}")#text(". Each such eigenfunction generates a constraint ")#metadata(none) <tao-1143da2bc54c495c4be3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("f(x) \\overline{f(T^n x)}^2 f(T^{2n} x) = 1")]]

#text("tying together ")#mi("{x}")#text(", ")#mi("{T^n x}")#text(", and ")#mi("{T^{2n} x}")#text(". However, it turns out that these are in some sense the ")#emph[#text("only")]#text(" constraints on ")#mi("{x,T^n x, T^{2n} x}")#text(" that are relevant for the limit ")#link(<tao-3c504ac87a8749340062>)[#text("(3)")]#text(". More precisely, if one sets ")#mi("{{\\mathcal X}_1}")#text(" to be the sub-algebra of ")#mi("{{\\mathcal X}}")#text(" generated by the eigenfunctions of ")#mi("{T}")#text(", then it turns out that the factor ")#mi("{(X, {\\mathcal X}_1, \\mu, T)}")#text(" is isomorphic to a shift system ")#mi("{(Z_1, {\\mathcal Z}_1, \\mu_{Z_1}, x \\mapsto x+\\alpha)}")#text(" known as the ")#emph[#text("Kronecker factor")]#text(", for some compact abelian group ")#mi("{Z_1 = (Z_1,+)}")#text(" and some (irrational) shift ")#mi("{\\alpha \\in Z_1}")#text("; the factor map ")#mi("{\\pi_1: X \\rightarrow Z_1}")#text(" pushes eigenfunctions forward to (affine) characters on ")#mi("{Z_1}")#text(". It is then known that the limit of ")#link(<tao-3c504ac87a8749340062>)[#text("(3)")]#text(" is")

#align(center)[#tao-fit-display[#mitex("\\int_\\Sigma (\\pi_1)_* f(x_0) (\\pi_1)_* g(x_1) (\\pi_1)_* h(x_2)\\ d\\mu_\\Sigma")]]

#text("where ")#mi("{\\Sigma \\subset Z_1^3}")#text(" is the closed subgroup")

#align(center)[#tao-fit-display[#mitex("\\Sigma = \\{ (x_1,x_2,x_3) \\in Z_1^3: x_1-2x_2+x_3=0 \\}")]]

#text("and ")#mi("{\\mu_\\Sigma}")#text(" is the Haar probability measure on ")#mi("{\\Sigma}")#text("; see ")#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/")[#text("this previous blog post")]#text(". The equation ")#mi("{x_1-2x_2+x_3=0}")#text(" defining ")#mi("{\\Sigma}")#text(" corresponds to the constraint ")#link(<tao-1143da2bc54c495c4be3>)[#text("(4)")]#text(" mentioned earlier. Among other things, this limit formula implies ")#emph[#text("Roth’s theorem")]#text(", which in the context of ergodic theory is the assertion that the limit (or at least the limit inferior) of ")#link(<tao-3c504ac87a8749340062>)[#text("(3)")]#text(" is positive when ")#mi("{f=g=h}")#text(" is non-negative and not identically vanishing.")

#text("If one considers a quadruple average ")#metadata(none) <tao-14b9dfca2c9f705541e4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\frac{1}{N} \\sum_{n=1}^N \\int_X f(x) g(T^n x) h(T^{2n} x) k(T^{3n} x)\\ d\\mu")]]

#text("(analogous to counting length four progressions) then the situation becomes more complicated still, even in the ergodic case. In addition to the (linear) eigenfunctions that already showed up in the computation of the triple average ")#link(<tao-3c504ac87a8749340062>)[#text("(3)")]#text(", a new type of constraint also arises from ")#emph[#text("quadratic eigenfunctions")]#text(" ")#mi("{f: X \\rightarrow S^1}")#text(", which obey an eigenfunction equation ")#mi("{Tf = \\lambda f}")#text(" in which ")#mi("{\\lambda}")#text(" is no longer constant, but is now a linear eigenfunction. For such functions, ")#mi("{f(T^n x)}")#text(" behaves quadratically in ")#mi("{n}")#text(", and one can compute the existence of a constraint ")#metadata(none) <tao-2839b64cd3d3ab4b5df0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("f(x) \\overline{f(T^n x)}^3 f(T^{2n} x)^3 \\overline{f(T^{3n} x)} = 1")]]

#text("between ")#mi("{x}")#text(", ")#mi("{T^n x}")#text(", ")#mi("{T^{2n} x}")#text(", and ")#mi("{T^{3n} x}")#text(" that is not detected at the triple average level. As it turns out, this is not the only type of constraint relevant for ")#link(<tao-14b9dfca2c9f705541e4>)[#text("(5)")]#text("; there is a more general class of constraint involving two-step nilsystems which we will not detail here, but see e.g. ")#link("https://terrytao.wordpress.com/2008/03/09/254a-lecture-16-a-ratner-type-theorem-for-nilmanifolds/")[#text("this previous blog post")]#text(" for more discussion. Nevertheless there is still a similar limit formula to previous examples, involving a special factor ")#mi("{(Z_2, {\\mathcal Z}_2, \\mu_{Z_2}, S)}")#text(" which turns out to be an inverse limit of two-step nilsystems; this limit theorem can be extracted from the structural theory in ")#link("http://www.ams.org/mathscinet-getitem?mr=1894481")[#text("this paper of Host and Kra")]#text(" combined with a limit formula for nilsystems ")#link("http://www.ams.org/mathscinet-getitem?mr=991492")[#text("obtained by Lesigne")]#text(", but will not be reproduced here. The pattern continues to higher averages (and higher step nilsystems); this was first done explicitly ")#link("http://www.ams.org/mathscinet-getitem?mr=2257397")[#text("by Ziegler")]#text(", and can also in principle be extracted from the structural theory ")#link("http://www.ams.org/mathscinet-getitem?mr=2150389")[#text("of Host-Kra")]#text(" combined with nilsystem equidistribution results ")#link("http://www.ams.org/mathscinet-getitem?mr=2122919")[#text("of Leibman")]#text(". These sorts of limit formulae can lead to various recurrence results refining Roth’s theorem in various ways; see ")#link("http://www.ams.org/mathscinet-getitem?mr=2138068")[#text("this paper of Bergelson, Host, and Kra")]#text(" for some examples of this.")

#text("The above discussion was concerned with ")#mi("{{\\bf Z}}")#text("-systems, but one can adapt much of the theory to measure-preserving ")#mi("{G}")#text("-systems for other discrete countable abelian groups ")#mi("{G}")#text(", in which one now has a family ")#mi("{(T_g)_{g \\in G}}")#text(" of shifts indexed by ")#mi("{G}")#text(" rather than a single shift, obeying the compatibility relation ")#mi("{T_{g+h}=T_g T_h}")#text(". The role of the intervals ")#mi("{\\{1,\\ldots,N\\}}")#text(" in this more general setting is replaced by that of ")#link("http://en.wikipedia.org/wiki/F%C3%B8lner_sequence")[#text("Folner sequences")]#text(". For arbitrary countable abelian ")#mi("{G}")#text(", the theory for double averages ")#link(<tao-55ea09e5715d0a8d9d94>)[#text("(1)")]#text(" and triple limits ")#link(<tao-3c504ac87a8749340062>)[#text("(3)")]#text(" is essentially identical to the ")#mi("{{\\bf Z}}")#text("-system case. But when one turns to quadruple and higher limits, the situation becomes more complicated (and, for arbitrary ")#mi("{G}")#text(", still not fully understood). However one model case which is now well understood is the finite field case when ")#mi("{G = {\\bf F}_p^\\omega = \\bigcup_{n=1}^\\infty {\\bf F}_p^n}")#text(" is an infinite-dimensional vector space over a finite field ")#mi("{{\\bf F}_p}")#text(" (with the finite subspaces ")#mi("{{\\bf F}_p^n}")#text(" then being a good choice for the Folner sequence). Here, the analogue of the structural theory of Host and Kra was worked out by Vitaly, Tamar, and myself in ")#link("https://terrytao.wordpress.com/2009/01/19/an-inverse-theorem-for-the-uniformity-seminorms-associated-with-the-action-of-finfty_p/")[#text("these")]#text(" ")#link("https://terrytao.wordpress.com/2011/01/11/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-in-low-characteristic/")[#text("previous papers")]#text(" (treating the high characteristic and low characteristic cases respectively). In the finite field setting, it turns out that nilsystems no longer appear, and one only needs to deal with linear, quadratic, and higher order eigenfunctions (known collectively as ")#emph[#text("phase polynomials")]#text("). It is then natural to look for a limit formula that asserts, roughly speaking, that if ")#mi("{x}")#text(" is drawn at random from a ")#mi("{{\\bf F}_p^\\omega}")#text("-system and ")#mi("{n}")#text(" drawn randomly from a large subspace of ")#mi("{{\\bf F}_p^\\omega}")#text(", then the only constraints between ")#mi("{x, T^n x, \\ldots, T^{(p-1)n} x}")#text(" are those that arise from phase polynomials. The main theorem of this paper is to establish this limit formula (which, again, is a little complicated to state explicitly and will not be done here). In particular, we establish for the first time that the limit actually exists (a result which, for ")#mi("{{\\bf Z}}")#text("-systems, was one of the main results of ")#link("http://www.ams.org/mathscinet-getitem?mr=2150389")[#text("this paper of Host and Kra")]#text(").")

#text("As a consequence, we can recover finite field analogues of most of the results of Bergelson-Host-Kra, though interestingly some of the counterexamples demonstrating sharpness of their results for ")#mi("{{\\bf Z}}")#text("-systems (based on Behrend set constructions) do not seem to be present in the finite field setting (cf. ")#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/")[#text("this previous blog post")]#text(" on the cap set problem). In particular, we are able to largely settle the question of when one has a Khintchine-type theorem that asserts that for any measurable set ")#mi("{A}")#text(" in an ergodic ")#mi("{{\\bf F}_p^\\omega}")#text("-system and any ")#mi("{\\epsilon>0}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\mu( T_{c_1 n} A \\cap \\ldots \\cap T_{c_k n} A ) > \\mu(A)^k - \\epsilon")]]

#text("for a ")#link("http://en.wikipedia.org/wiki/Syndetic_set")[#text("syndetic set")]#text(" of ")#mi("{n}")#text(", where ")#mi("{c_1,\\ldots,c_k \\in {\\bf F}_p}")#text(" are distinct residue classes. It turns out that Khintchine-type theorems always hold for ")#mi("{k=1,2,3}")#text(" (and for ")#mi("{k=1,2}")#text(" ergodicity is not required), and for ")#mi("{k=4}")#text(" it holds whenever ")#mi("{c_1,c_2,c_3,c_4}")#text(" form a parallelogram, but not otherwise (though the counterexample here was such a painful computation that we ended up removing it from the paper, and may end up putting it online somewhere instead), and for larger ")#mi("{k}")#text(" we could show that the Khintchine property failed for generic choices of ")#mi("{c_1,\\ldots,c_k}")#text(", though the problem of determining exactly the tuples for which the Khintchine property failed looked to be rather messy and we did not completely settle it.")

#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/feda2708ab41aeb5a863f024d1bdf0b1d8e756e1e19ef3e175c14fd9820c8eca-3335bed4a94ed4d3a639469274e25dfa6b77c1b83e32303b80b4b71de3b79cf8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mixedmath")]], [#link("https://terrytao.wordpress.com/2013/05/21/multiple-recurrence-and-convergence-results-associated-to-f_pomega-actions/#comment-230709")[#strong[#text("mixedmath")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2013")])]

#text("Dr. Tao – I’m afraid you left out the easily forgettable ‘latex’ prefix in your title latex phrase.")

#text("I also want to say that I really appreciate your incredibly complete collection of mathlinks on your site. I was wondering whether you would consider adding my math blog mixedmath.wordpress.com as well?")

#text("David Lowry")

#emph[#text("[Link added, thanks. Unfortunately, WordPress doesn’t render LaTeX in titles, but I can at least remove the dollar signs. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8c2016a95d7871dcb511ae984e701ed78c8c69bcbea8aed09b3f13b3dbc827a-acbdc4f59b530120b45a1ec4380cb421d042b21bae300a1a2688683d5cfce060.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joel Moreira")]], [#link("https://terrytao.wordpress.com/2013/05/21/multiple-recurrence-and-convergence-results-associated-to-f_pomega-actions/#comment-230944")[#strong[#text("Joel Moreira")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2013")])]

#text("Do you know of any other group (besides ")#mi("Z")#text(" and ")#mi("F_p^\\omega")#text(") for which an analogue of the Host-Kra theory has been developed? I think this would be particularly interesting in the multiplicative integers (actually only a semigroup).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/05/21/multiple-recurrence-and-convergence-results-associated-to-f_pomega-actions/#comment-230949")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2013")])]

#text("Well, it is folklore that the Host-Kra theory extends from ")#mi("{\\bf Z}")#text(" to ")#mi("{\\bf Z}^d")#text(" for any fixed d without much modification (using cubes such as ")#mi("[-N,N]^d")#text(" for the Folner sequence), although this has not actually been written up in the literature as far as I know. (This should not be confused with the question of characteristic factors for one-dimensional averages of ")#mi("d")#text(" commuting shifts (in which one only averages over ")#mi("[-N,N]")#text(" rather than over ")#mi("[-N,N]^d")#text(") which appears to be a massively more complicated problem, with some very difficult partial results due to Austin.)")

#text("For general groups, the program of Szegedy (and Camarena-Szegedy) on nonstandard higher order Fourier analysis should _in principle_ be able to say something of Host-Kra type for arbitrary G-systems, but to my knowledge the details have not yet been worked out (the Szegedy program is focused more on the combinatorial setting with inverse theorems for Gowers norms which is similar but not quite identical to the structural theory for measure preserving systems).")

#text("Perhaps the “ultimate” result would be a Host-Kra theory for ")#mi("{\\mathbf Z}^\\omega")#text(", as this in principle then projects down to give all other countable abelian groups. (The semigroup case can in principle be recovered from the group case by an old lifting trick of Furstenberg.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Concatenation theorems for anti-Gowers-uniform functions and Host-Kra characteristic factors; polynomial patterns in primes | What's new")]], [#link("https://terrytao.wordpress.com/2013/05/21/multiple-recurrence-and-convergence-results-associated-to-f_pomega-actions/#comment-467300")[#strong[#text("Concatenation theorems for anti-Gowers-uniform functions and Host-Kra characteristic factors; polynomial patterns in primes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2016")])]

#text("[…] group by Griesmer, while the case of an infinite vector space over a finite field was treated in this paper of Bergelson, Ziegler, and myself. The situation is more subtle when is not -ergodic, or when is -ergodic but is a proper subgroup […]")
]
