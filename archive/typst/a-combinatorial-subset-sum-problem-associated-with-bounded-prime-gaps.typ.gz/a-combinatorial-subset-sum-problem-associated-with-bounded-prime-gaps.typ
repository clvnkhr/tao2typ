// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/
// Converted to Typst by tao2typ: "2026-10-14T16:37:04.079606+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A combinatorial subset sum problem associated with bounded prime gaps", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A combinatorial subset sum problem associated with bounded prime gaps")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 June 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")[#text("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The purpose of this post is to isolate a combinatorial optimisation problem regarding subset sums; any improvement upon the current known bounds for this problem would lead to numerical improvements for the quantities pursued in the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("Polymath8 project")]#text(". (UPDATE: Unfortunately no purely combinatorial improvement is possible, see comments.) We will also record the number-theoretic details of how this combinatorial problem is used in Zhang’s argument establishing bounded prime gaps.")

#text("First, some (rough) motivational background, omitting all the number-theoretic details and focusing on the combinatorics. (But readers who just want to see the combinatorial problem can skip the motivation and jump ahead to Lemma ")#link(<tao-fc6a3d0fff933962afcc>)[#text("5")]#text(".) As part of the Polymath8 project we are trying to establish a certain estimate called ")#mi("{MPZ[\\varpi,\\delta]}")#text(" for as wide a range of ")#mi("{\\varpi,\\delta > 0}")#text(" as possible. Currently the best result we have is:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Zhang’s theorem, numerically optimised)")]#text(" ")#metadata(none) <tao-20854963535d2fa25505>#text(" ")#mi("{MPZ[\\varpi,\\delta]}")#text(" holds whenever ")#mi("{207\\varpi + 43\\delta< \\frac{1}{4}}")#text(".")
]

#text("Enlarging this region would lead to a better value of certain parameters ")#mi("{k_0}")#text(", ")#mi("{H}")#text(" which in turn control the best bound on asymptotic gaps between consecutive primes. See ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("this previous post")]#text(" for more discussion of this. At present, the best value ")#mi("{k_0=23,283}")#text(" of ")#mi("{k_0}")#text(" is applied by taking ")#mi("{(\\varpi,\\delta)}")#text(" sufficiently close to ")#mi("{(1/899,71/154628)}")#text(", so improving Theorem ")#link(<tao-20854963535d2fa25505>)[#text("1")]#text(" in the neighbourhood of this value is particularly desirable.")

#text("I’ll state exactly what ")#mi("{MPZ[\\varpi,\\delta]}")#text(" is below the fold. For now, suffice to say that it involves a certain number-theoretic function, the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(" ")#mi("{\\Lambda}")#text(". To prove the theorem, the first step is to use a certain identity (the Heath-Brown identity) to decompose ")#mi("{\\Lambda}")#text(" into a lot of pieces, which take the form ")#metadata(none) <tao-3f22f007dace5d04260f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\alpha_{1} \\ast \\ldots \\ast \\alpha_{n}")]]

#text("for some bounded ")#mi("{n}")#text(" (in Zhang’s paper ")#mi("{n}")#text(" never exceeds ")#mi("{20}")#text(") and various weights ")#mi("{\\alpha_{1},\\ldots,\\alpha_n}")#text(" supported at various scales ")#mi("{N_1,\\ldots,N_n \\geq 1}")#text(" that multiply up to approximately ")#mi("{x}")#text(":")

#align(center)[#tao-fit-display[#mitex("N_1 \\ldots N_n \\sim x.")]]

#text("We can write ")#mi("{N_i = x^{t_i}}")#text(", thus ignoring negligible errors, ")#mi("{t_1,\\ldots,t_n}")#text(" are non-negative real numbers that add up to ")#mi("{1}")#text(":")

#align(center)[#tao-fit-display[#mitex("t_1 + \\ldots + t_n = 1.")]]

#text("A key technical feature of the Heath-Brown identity is that the weight ")#mi("{\\alpha_i}")#text(" associated to sufficiently large values of ")#mi("{t_i}")#text(" (e.g. ")#mi("{t_i \\geq 1/10}")#text(") are “smooth” in a certain sense; this will be detailed below the fold.")

#text("The operation ")#mi("{\\ast}")#text(" is Dirichlet convolution, which is commutative and associative. We can thus regroup the convolution ")#link(<tao-3f22f007dace5d04260f>)[#text("(1)")]#text(" in a number of ways. For instance, given any partition ")#mi("{\\{1,\\ldots,n\\} = S \\cup T}")#text(" into disjoint sets ")#mi("{S,T}")#text(", we can rewrite ")#link(<tao-3f22f007dace5d04260f>)[#text("(1)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\alpha_S \\ast \\alpha_T")]]

#text("where ")#mi("{\\alpha_S}")#text(" is the convolution of those ")#mi("{\\alpha_i}")#text(" with ")#mi("{i \\in S}")#text(", and similarly for ")#mi("{\\alpha_T}")#text(".")

#text("Zhang’s argument splits into two major pieces, in which certain classes of ")#link(<tao-3f22f007dace5d04260f>)[#text("(1)")]#text(" are established. Cheating a little bit, the following three results are established:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Type 0 estimate, informal version)")]#text(" ")#metadata(none) <tao-512f26ada3c3d634ac3c>#text(" The term ")#link(<tao-3f22f007dace5d04260f>)[#text("(1)")]#text(" gives an acceptable contribution to ")#mi("{MPZ[\\varpi,\\delta]}")#text(" whenever")

#align(center)[#tao-fit-display[#mitex("t_i > \\frac{1}{2} + 2 \\varpi")]]

#text("for some ")#mi("{i}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Type I/II estimate, informal version)")]#text(" ")#metadata(none) <tao-628b49d96dcde97a430d>#text(" The term ")#link(<tao-3f22f007dace5d04260f>)[#text("(1)")]#text(" gives an acceptable contribution to ")#mi("{MPZ[\\varpi,\\delta]}")#text(" whenever one can find a partition ")#mi("{\\{1,\\ldots,n\\} = S \\cup T}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} - \\sigma < \\sum_{i \\in S} t_i \\leq \\sum_{i \\in T} t_i < \\frac{1}{2} + \\sigma")]]

#text("where ")#mi("{\\sigma}")#text(" is a quantity such that")

#align(center)[#tao-fit-display[#mitex("11 \\varpi + 3\\delta + 2 \\sigma < \\frac{1}{4}.")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Type III estimate, informal version)")]#text(" ")#metadata(none) <tao-c44474038d459e40e471>#text(" The term ")#link(<tao-3f22f007dace5d04260f>)[#text("(1)")]#text(" gives an acceptable contribution to ")#mi("{MPZ[\\varpi,\\delta]}")#text(" whenever one can find ")#mi("{t_i,t_j,t_k}")#text(" with distinct ")#mi("{i,j,k \\in \\{1,\\ldots,n\\}}")#text(" with")

#align(center)[#tao-fit-display[#mitex("t_i \\leq t_j \\leq t_k \\leq \\frac{1}{2}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("4t_k + 4t_j + 5t_i > 4 + 16 \\varpi + \\delta.")]]
]

#text("The above assertions are oversimplifications; there are some additional minor smallness hypotheses on ")#mi("{\\varpi,\\delta}")#text(" that are needed but at the current (small) values of ")#mi("{\\varpi,\\delta}")#text(" under consideration they are not relevant and so will be omitted.")

#text("The deduction of Theorem ")#link(<tao-20854963535d2fa25505>)[#text("1")]#text(" from Theorems ")#link(<tao-512f26ada3c3d634ac3c>)[#text("2")]#text(", ")#link(<tao-628b49d96dcde97a430d>)[#text("3")]#text(", ")#link(<tao-c44474038d459e40e471>)[#text("4")]#text(" is then accomplished from the following, purely combinatorial, lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5 (Subset sum lemma)")]#text(" ")#metadata(none) <tao-fc6a3d0fff933962afcc>#text(" Let ")#mi("{\\varpi,\\delta > 0}")#text(" be such that ")#metadata(none) <tao-b07aa1936d43cb934eca>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("207\\varpi + 43\\delta < \\frac{1}{4}.")]]

#text("Let ")#mi("{t_1,\\ldots,t_n}")#text(" be non-negative reals such that")

#align(center)[#tao-fit-display[#mitex("t_1 + \\ldots + t_n = 1.")]]

#text("Then at least one of the following statements hold:")

#list(
[#text("(Type 0) There is ")#mi("{1 \\leq i \\leq n}")#text(" such that ")#mi("{t_i > \\frac{1}{2} + 2 \\varpi}")#text(".")],
[#text("(Type I/II) There is a partition ")#mi("{\\{1,\\ldots,n\\} = S \\cup T}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} - \\sigma < \\sum_{i \\in S} t_i \\leq \\sum_{i \\in T} t_i < \\frac{1}{2} + \\sigma")]]

#text("where ")#mi("{\\sigma}")#text(" is a quantity such that")

#align(center)[#tao-fit-display[#mitex("11 \\varpi + 3\\delta + 2 \\sigma < \\frac{1}{4}.")]]],
[#text("(Type III) One can find distinct ")#mi("{t_i,t_j,t_k}")#text(" with")

#align(center)[#tao-fit-display[#mitex("t_i \\leq t_j \\leq t_k \\leq \\frac{1}{2}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("4t_k + 4t_j + 5t_i > 4 + 16 \\varpi + \\delta.")]]]
)
]

#text("The purely combinatorial question is whether the hypothesis ")#link(<tao-b07aa1936d43cb934eca>)[#text("(2)")]#text(" can be relaxed here to a weaker condition. This would allow us to improve the ranges for Theorem ")#link(<tao-20854963535d2fa25505>)[#text("1")]#text(" (and hence for the values of ")#mi("{k_0}")#text(" and ")#mi("{H}")#text(" alluded to earlier) without needing further improvement on Theorems ")#link(<tao-512f26ada3c3d634ac3c>)[#text("2")]#text(", ")#link(<tao-628b49d96dcde97a430d>)[#text("3")]#text(", ")#link(<tao-c44474038d459e40e471>)[#text("4")]#text(" (although such improvement is also going to be a focus of Polymath8 investigations in the future).")

#text("Let us review how this lemma is currently proven. The key sublemma is the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6")]#text(" ")#metadata(none) <tao-09f5ffef28309853265c>#text(" Let ")#mi("{1/10 < \\sigma < 1/2}")#text(", and let ")#mi("{t_1,\\ldots,t_n}")#text(" be non-negative numbers summing to ")#mi("{1}")#text(". Then one of the following three statements hold:")

#list(
[#text("(Type 0) There is a ")#mi("{t_i}")#text(" with ")#mi("{t_i \\geq 1/2 + \\sigma}")#text(".")],
[#text("(Type I/II) There is a partition ")#mi("{\\{1,\\ldots,n\\} = S \\cup T}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} - \\sigma < \\sum_{i \\in S} t_i \\leq \\sum_{i \\in T} t_i < \\frac{1}{2} + \\sigma.")]]],
[#text("(Type III) There exist distinct ")#mi("{i,j,k}")#text(" with ")#mi("{2\\sigma \\leq t_i \\leq t_j \\leq t_k \\leq 1/2-\\sigma}")#text(" and ")#mi("{t_i+t_j,t_i+t_k,t_j+t_k \\geq 1/2 + \\sigma}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" Suppose Type I/II never occurs, then every partial sum ")#mi("{\\sum_{i \\in S} t_i}")#text(" is either “small” in the sense that it is less than or equal to ")#mi("{1/2-\\sigma}")#text(", or “large” in the sense that it is greater than or equal to ")#mi("{1/2+\\sigma}")#text(", since otherwise we would be in the Type I/II case either with ")#mi("{S}")#text(" as is and ")#mi("{T}")#text(" the complement of ")#mi("{S}")#text(", or vice versa.")

#text("Call a summand ")#mi("{t_i}")#text(" “powerless” if it cannot be used to turn a small partial sum into a large partial sum, thus there are no ")#mi("{S \\subset \\{1,\\ldots,n\\} \\backslash \\{i\\}}")#text(" such that ")#mi("{\\sum_{j \\in S} t_j}")#text(" is small and ")#mi("{t_i + \\sum_{j \\in S} t_j}")#text(" is large. We then split ")#mi("{\\{1,\\ldots,n\\} = A \\cup B}")#text(" where ")#mi("{A}")#text(" are the powerless elements and ")#mi("{B}")#text(" are the powerful elements.")

#text("By induction we see that if ")#mi("{S \\subset B}")#text(" and ")#mi("{\\sum_{i \\in S} t_i}")#text(" is small, then ")#mi("{\\sum_{i \\in S} t_i + \\sum_{i \\in A} t_i}")#text(" is also small. Thus every sum of powerful summand is either less than ")#mi("{1/2-\\sigma-\\sum_{i \\in A} t_i}")#text(" or larger than ")#mi("{1/2+\\sigma}")#text(". Since a powerful element must be able to convert a small sum to a large sum (in fact it must be able to convert a small sum of powerful summands to a large sum, by stripping out the powerless summands), we conclude that every powerful element has size greater than ")#mi("{2\\sigma + \\sum_{i \\in A} t_i}")#text(". We may assume we are not in Type 0, then every powerful summand is at least ")#mi("{2\\sigma + \\sum_{i \\in A} t_i}")#text(" and at most ")#mi("{1/2 - \\sigma - \\sum_{i \\in A} t_i}")#text(". In particular, there have to be at least three powerful summands, otherwise ")#mi("{\\sum_{i=1}^n t_i}")#text(" cannot be as large as ")#mi("{1}")#text(". As ")#mi("{\\sigma > 1/10}")#text(", we have ")#mi("{4\\sigma > 1/2-\\sigma}")#text(", and we conclude that the sum of any two powerful summands is large (which, incidentally, shows that there are ")#emph[#text("exactly")]#text(" three powerful summands). Taking ")#mi("{t_i,t_j,t_k}")#text(" to be three powerful summands in increasing order we land in Type III. ")#mi("\\Box")

#text("Now we see how Lemma ")#link(<tao-09f5ffef28309853265c>)[#text("6")]#text(" implies Lemma ")#link(<tao-fc6a3d0fff933962afcc>)[#text("5")]#text(". Let ")#mi("{\\varpi,\\delta}")#text(" be as in Lemma ")#link(<tao-fc6a3d0fff933962afcc>)[#text("5")]#text(". We take ")#mi("{\\sigma}")#text(" almost as large as we can for the Type I/II case, thus we set ")#metadata(none) <tao-dff5c0fdc4d4c8ea5f2a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sigma := \\frac{1}{8} - \\frac{11}{2} \\varpi - \\frac{3}{2} \\delta - \\epsilon")]]

#text("for some sufficiently small ")#mi("{\\epsilon>0}")#text(". We observe from ")#link(<tao-b07aa1936d43cb934eca>)[#text("(2)")]#text(" that we certainly have")

#align(center)[#tao-fit-display[#mitex("\\sigma > 2 \\varpi")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\sigma > \\frac{1}{10}")]]

#text("with plenty of room to spare. We then apply Lemma ")#link(<tao-09f5ffef28309853265c>)[#text("6")]#text(". The Type 0 case of that lemma then implies the Type 0 case of Lemma ")#link(<tao-fc6a3d0fff933962afcc>)[#text("5")]#text(", while the Type I/II case of Lemma ")#link(<tao-09f5ffef28309853265c>)[#text("6")]#text(" also implies the Type I/II case of Lemma ")#link(<tao-fc6a3d0fff933962afcc>)[#text("5")]#text(". Finally, suppose that we are in the Type III case of Lemma ")#link(<tao-09f5ffef28309853265c>)[#text("6")]#text(". Since")

#align(center)[#tao-fit-display[#mitex("4t_i + 4t_j + 5 t_k = \\frac{5}{2} (t_i+t_k) + \\frac{5}{2}(t_j+t_k) + \\frac{3}{2} (t_i+t_j)")]]

#text("we thus have")

#align(center)[#tao-fit-display[#mitex("4t_i + 4t_j + 5 t_k \\geq \\frac{13}{2} (\\frac{1}{2}+\\sigma)")]]

#text("and so we will be done if")

#align(center)[#tao-fit-display[#mitex("\\frac{13}{2} (\\frac{1}{2}+\\sigma) > 4 + 16 \\varpi + \\delta.")]]

#text("Inserting ")#link(<tao-dff5c0fdc4d4c8ea5f2a>)[#text("(3)")]#text(" and taking ")#mi("{\\epsilon}")#text(" small enough, it suffices to verify that")

#align(center)[#tao-fit-display[#mitex("\\frac{13}{2} (\\frac{1}{2}+\\frac{1}{8} - \\frac{11}{2} \\varpi - \\frac{3}{2}\\delta) > 4 + 16 \\varpi + \\delta")]]

#text("but after some computation this is equivalent to ")#link(<tao-b07aa1936d43cb934eca>)[#text("(2)")]#text(".")

#text("It seems that there is some slack in this computation; some of the conclusions of the Type III case of Lemma ")#link(<tao-fc6a3d0fff933962afcc>)[#text("5")]#text(", in particular, ended up being “wasted”, and it is possible that one did not fully exploit all the partial sums that could be used to create a Type I/II situation. So there may be a way to make improvements through purely combinatorial arguments. (UPDATE: As it turns out, this is sadly not the case: consderation of the case when ")#mi("{n=4}")#text(", ")#mi("{t_1 = 1/4 - 3\\sigma/2}")#text(", and ")#mi("{t_2=t_3=t_4 = 1/4+\\sigma/2}")#text(" shows that one cannot obtain any further improvement without actually improving the Type I/II and Type III analysis.)")

#text("A technical remark: for the application to Theorem ")#link(<tao-20854963535d2fa25505>)[#text("1")]#text(", it is possible to enforce a bound on the number ")#mi("{n}")#text(" of summands in Lemma ")#link(<tao-fc6a3d0fff933962afcc>)[#text("5")]#text(". More precisely, we may assume that ")#mi("{n}")#text(" is an even number of size at most ")#mi("{n \\leq 2K}")#text(" for any natural number ")#mi("{K}")#text(" we please, at the cost of adding the additioal constraint ")#mi("{t_i > \\frac{1}{K}}")#text(" to the Type III conclusion. Since ")#mi("{t_i}")#text(" is already at least ")#mi("{2\\sigma}")#text(", which is at least ")#mi("{\\frac{1}{5}}")#text(", one can safely take ")#mi("{K=5}")#text(", so ")#mi("{n}")#text(" can be taken to be an even number of size at most ")#mi("{10}")#text(", which in principle makes the problem of optimising Lemma ")#link(<tao-fc6a3d0fff933962afcc>)[#text("5")]#text(" a fixed linear programming problem. (Zhang takes ")#mi("{K=10}")#text(", but this appears to be overkill. On the other hand, ")#mi("{K}")#text(" does not appear to be a parameter that overly influences the final numerical bounds.)")

#text("Below the fold I give the number-theoretic details of the combinatorial aspects of Zhang’s argument that correspond to the combinatorial problem described above.")

#metadata(none) <tao-fa57effddcae42eaf3ee>

#heading(level: 1)[#strong[#text(" — 1. Coefficient sequences — ")]]

#text("We now give some number-theoretic background material that will serve two purposes. The most immediate purpose is to enable one to understand the precise statement of Theorems ")#link(<tao-20854963535d2fa25505>)[#text("1")]#text(", ")#link(<tao-512f26ada3c3d634ac3c>)[#text("2")]#text(", ")#link(<tao-628b49d96dcde97a430d>)[#text("3")]#text(", ")#link(<tao-c44474038d459e40e471>)[#text("4")]#text(", as well as the deduction of the first theorem from the other three. A secondary purpose is to establish some reference material which will be used in subsequent posts on the Type I/II and Type III analysis in Zhang’s arguments.")

#text("As in previous posts, we let ")#mi("{x}")#text(" be an asymptotic parameter tending to infinity and define the usual asymptotic notation ")#mi("{O(), o(), \\ll}")#text(" relative to this parameter. It is also convenient to have a large fixed quantity ")#mi("{A_0>0}")#text(" to be chosen later, in order to achieve a fine localisation of scales.")

#text("It will be convenient to set up some notation regarding certain types of sequences, abstracting some axioms appearing in the work of ")#link("http://www.ams.org/mathscinet-getitem?mr=834613")[#text("Bombieri-Friedlander-Iwaniec")]#text(" and ")#link("http://annals.math.princeton.edu/wp-content/uploads/YitangZhang.pdf")[#text("Zhang")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 7")]#text(" A ")#emph[#text("coefficient sequence")]#text(" is a finitely supported sequence ")#mi("{\\alpha: {\\bf N} \\rightarrow {\\bf R}}")#text(" that obeys the bounds ")#metadata(none) <tao-afd7bf72960f2f867380>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|\\alpha(n)\\right| \\ll \\tau^{O(1)}(n) \\log^{O(1)}(x)", block: true)]]

#text("for all ")#mi("{n}")#text(", where ")#mi("{\\tau}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Divisor_function")[#text("divisor function")]#text(". (In particular, any sequence that is pointwise dominated by a coefficient sequence is again a coefficient sequence.)")

#list(
[#text("(i) If ")#mi("{\\alpha}")#text(" is a coefficient sequence and ")#mi("{a\\ (q) = a \\text{ mod } q}")#text(" is a primitive residue class, the (signed) ")#emph[#text("discrepancy")]#text(" ")#mi("{\\Delta(\\alpha; a\\ (q))}")#text(" of ")#mi("{\\alpha}")#text(" in the sequence is defined to be the quantity")

#metadata(none) <tao-6cd4c9c389b460a1f603>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\Delta(\\alpha; a \\ (q)) := \\sum_{n: n = a\\ (q)} \\alpha(n) - \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1} \\alpha(n).")]]

#text("Note that this expression is linear in ")#mi("{\\alpha}")#text(", so in particular we have the triangle inequality")

#metadata(none) <tao-0a3f13c673af2389ecb9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left|\\Delta(\\alpha+\\beta; a\\ (q))\\right| \\leq \\left|\\Delta(\\alpha; a\\ (q))\\right| + \\left|\\Delta(\\beta; a\\ (q))\\right|.", block: true)]]],
[#text("(ii) A coefficient sequence ")#mi("{\\alpha}")#text(" is said to be ")#emph[#text("at scale ")#mi("{N}")]#text(" for some ")#mi("{N \\geq 1}")#text(" if it is supported on an interval of the form ")#mi("{[(1-O(\\log^{-A_0} x)) N, (1+O(\\log^{-A_0} x)) N]}")#text(".")],
[#text("(iii) A coefficient sequence ")#mi("{\\alpha}")#text(" at scale ")#mi("{N}")#text(" is said to ")#emph[#text("obey the Siegel-Walfisz theorem")]#text(" if one has")

#metadata(none) <tao-a543997d84f12798350c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left| \\Delta(\\alpha 1_{(\\cdot,q)=1}; a\\ (r)) \\right| \\ll \\tau(qr)^{O(1)} N \\log^{-A} x", block: true)]]

#text("for any ")#mi("{q,r \\geq 1}")#text(", any fixed ")#mi("{A}")#text(", and any primitive residue class ")#mi("{a\\ (r)}")#text(".")],
[#text("(iv) A coefficient sequence ")#mi("{\\alpha}")#text(" at scale ")#mi("{N}")#text(" is said to ")#emph[#text("obey the Elliott-Halberstam conjecture up to scale ")#mi("{M}")]#text(" for some ")#mi("{1 \\ll M \\ll N}")#text(" if one has")

#metadata(none) <tao-e93247c8fc04bf168ecc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\sum_{q < M} \\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(\\alpha; a\\ (q))\\right| \\ll N \\log^{-A} x", block: true)]]

#text("for any fixed ")#mi("{A>0}")#text(". Thus for instance the Siegel-Walfisz theorem implies the Elliott-Halberstam conjecture up to scale ")#mi("{\\log^C x}")#text(" for any fixed ")#mi("{C}")#text(".")],
[#text("(v) A coefficient sequence ")#mi("{\\alpha}")#text(" at scale ")#mi("{N}")#text(" is said to be ")#emph[#text("smooth")]#text(" if it takes the form ")#mi("{\\alpha(n) = \\psi(n/N)}")#text(" for some smooth function ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf C}}")#text(" supported on ")#mi("{[1-O(\\log^{-A_0} x), 1+O(\\log^{-A_0} x)]}")#text(" obeying the derivative bounds")

#metadata(none) <tao-ab1e6be2000a7c9c3d39>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\psi^{(j)}(t) = O( \\log^{j A_0} x )")]]

#text("for all fixed ")#mi("{j \\geq 0}")#text(" (note that the implied constant in the ")#mi("{O()}")#text(" notation may depend on ")#mi("{j}")#text(").")]
)
]

#text("To control error terms, we will frequently use the following crude bounds:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8 (Crude estimates)")]#text(" ")#metadata(none) <tao-ab7902bcbd91137e09d6>#text(" Let ")#mi("{\\alpha}")#text(" be a coefficient sequence, let ")#mi("{C>0}")#text(" be fixed, and let ")#mi("{1 \\ll y \\ll x^C}")#text(". Then we have ")#metadata(none) <tao-c3ccedf562d9529001d8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\sum_{d \\leq y} \\frac{\\left|\\alpha(d)\\right|^C}{d} \\ll \\log^{O(1)} x", block: true)]]

#text("and ")#metadata(none) <tao-cc598c80e8bd9f3cbaf0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\sum_{d \\leq y} \\left|\\alpha(d)\\right|^C \\ll y \\log^{O(1)} x;", block: true)]]

#text("more generally one has ")#metadata(none) <tao-e2d892e7c0ff7ab404f1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\sum_{d \\leq y: d = a\\ (q)} \\left|\\alpha(d)\\right|^C \\ll \\frac{y}{q} \\tau^{O(1)}(q) \\log^{O(1)} x + y^{o(1)};", block: true)]]

#text("for any congruence class ")#mi("{a\\ (q)}")#text(" (not necessarily primitive). In particular, if ")#mi("{\\alpha}")#text(" is at scale ")#mi("{N}")#text(" for some ")#mi("{1 \\ll N \\ll x^C}")#text(", one has ")#metadata(none) <tao-a302389dda3380261213>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\sum_{d} \\left|\\alpha(d)\\right|^C \\ll N \\log^{O(1)} x", block: true)]]

#text("and ")#metadata(none) <tao-bde297e6789cd213bef8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\sum_{d: d = a\\ (q)} \\left|\\alpha(d)\\right|^C \\ll \\frac{N}{q} \\tau^{O(1)}(q) \\log^{O(1)} x + N^{o(1)}", block: true)]]

#text("and hence from ")#link(<tao-6cd4c9c389b460a1f603>)[#text("(5)")]#text(" we have the crude discrepancy bound ")#metadata(none) <tao-32a4c20f8b4b39d7ce75>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left|\\Delta(\\alpha; a \\ (q))\\right| \\ll\\frac{N}{q} \\tau^{O(1)}(q) \\log^{O(1)} x + N^{o(1)}.", block: true)]]

#text("(In particular, the Siegel-Walfisz estimate ")#link(<tao-a543997d84f12798350c>)[#text("(7)")]#text(" is trivial unless ")#mi("{r = O(\\log^{O(1+A)} x)}")#text(".) Finally, we have the crude bound ")#metadata(none) <tao-1817dab1a8e238707d84>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\alpha(d) = O( x^{o(1)} )")]]

#text("for all ")#mi("{1 \\leq d \\leq x^C}")#text(".")
]

#emph[#text("Proof:")]#text(" To prove ")#link(<tao-c3ccedf562d9529001d8>)[#text("(10)")]#text(" it suffices from ")#link(<tao-afd7bf72960f2f867380>)[#text("(4)")]#text(" to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq x^C} \\frac{\\tau(n)^{O(1)}}{n} \\ll \\log^{O(1)} x,")]]

#text("but this follows from e.g. Lemma 8 of ")#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/")[#text("this previous post")]#text(". From ")#link(<tao-c3ccedf562d9529001d8>)[#text("(10)")]#text(" we also deduce ")#link(<tao-cc598c80e8bd9f3cbaf0>)[#text("(11)")]#text(". To show ")#link(<tao-e2d892e7c0ff7ab404f1>)[#text("(12)")]#text(", it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq y: d = a\\ (q)} \\tau^{O(1)}(d) \\ll \\frac{y}{q} \\tau^{O(1)}(q) \\log^{O(1)} y + y^{o(1)}")]]

#text("(i.e. a Brun-Titchmarsh type inequality for powers of the divisor function); this estimate follows from ")#link("http://www.ams.org/mathscinet-getitem?mr=552470")[#text("this paper of Shiu")]#text(" or ")#link("http://www.ams.org/mathscinet-getitem?mr=250990")[#text("this paper of Barban-Vehov")]#text(", and can also be proven using the methods in ")#link("https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound")[#text("this previous blog post")]#text(". (The factor of ")#mi("{\\tau^{O(1)}(q)}")#text(" is needed to account for the possibility that ")#mi("{a\\ (q)}")#text(" is not primitive, while the ")#mi("{y^{o(1)}}")#text(" term accounts for the possibility that ")#mi("{q}")#text(" is as large as ")#mi("{y^{1-o(1)}}")#text(".) Finally, ")#link(<tao-1817dab1a8e238707d84>)[#text("(16)")]#text(" follows from the standard divisor bound; see ")#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/")[#text("this previous post")]#text(". ")#mi("\\Box")

#text("As a general rule, we may freely use ")#link(<tao-1817dab1a8e238707d84>)[#text("(16)")]#text(" when we are expecting a net power savings ")#mi("{x^{-\\epsilon}}")#text(" to come from another part of the analysis, and we may freely use the other estimates in Lemma ")#link(<tao-ab7902bcbd91137e09d6>)[#text("8")]#text(" when we have a net super-logarithmic savings ")#mi("{\\log^{-A} x}")#text(" from elsewhere in the analysis. When we have neither a net power savings or a net super-logarithmic savings from other sources then we usually cannot afford to use any of the bounds in Lemma ")#link(<tao-ab7902bcbd91137e09d6>)[#text("8")]#text(".")

#text("The concept of a coefficient sequence is stable under the operation of ")#link("http://en.wikipedia.org/wiki/Dirichlet_convolution")[#text("Dirichlet convolution")]#text(" operation")

#align(center)[#tao-fit-display[#mitex("f \\ast g(n) := \\sum_{d|n} f(d) g(\\frac{n}{d}):")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 9")]#text(" ")#metadata(none) <tao-6244580a346acf5d814a>#text(" Let ")#mi("{\\alpha,\\beta}")#text(" be coefficient sequences. Then:")

#list(
[#text("(i) ")#mi("{\\alpha \\ast \\beta}")#text(" is also a coefficient sequence.")],
[#text("(ii) If ")#mi("{\\alpha,\\beta}")#text(" are coefficient sequences at scales ")#mi("{M,N}")#text(" respectively, then ")#mi("{\\alpha \\ast \\beta}")#text(" is a coefficient sequence at scale ")#mi("{MN}")#text(".")],
[#text("(iii) If ")#mi("{\\alpha,\\beta}")#text(" are coefficient sequences at scales ")#mi("{M,N}")#text(" respectively, with ")#mi("{x^c \\ll N \\ll x^C}")#text(" for some fixed ")#mi("{C,c>0}")#text(", and ")#mi("{\\beta}")#text(" obeys a Siegel-Walfisz theorem, then ")#mi("{\\alpha \\ast \\beta}")#text(" also obeys a Siegel-Walfisz theorem (at scale ")#mi("{NM}")#text(").")],
[#text("(iv) If ")#mi("{\\alpha,\\beta}")#text(" are coefficient sequences at scales ")#mi("{M,N}")#text(" respectively, with ")#mi("{x^c \\ll N \\ll x^C}")#text(" for some fixed ")#mi("{C,c>0}")#text(", and ")#mi("{\\beta}")#text(" obeys the Elliott-Halberstam conjecture up to some scale ")#mi("{L}")#text(", then ")#mi("{\\alpha \\ast \\beta}")#text(" (viewed as a coefficient sequence at scale ")#mi("{NM}")#text(") also obeys the Elliott-Halberstam conjecture up to scale ")#mi("{L}")#text(".")],
[#text("(v) If ")#mi("{L}")#text(" is the logarithm function, then ")#mi("{L \\alpha}")#text(" is a coefficient sequence. Furthermore, if ")#mi("{\\alpha}")#text(" is smooth at some scale ")#mi("{N}")#text(", then ")#mi("{L\\alpha}")#text(" is smooth at that scale also.")]
)
]

#emph[#text("Proof:")]#text(" To verify (i), observe from ")#link(<tao-afd7bf72960f2f867380>)[#text("(4)")]#text(" that for any ")#mi("{n}")#text(" one has")

#tao-aligned(keep: true)[


#tao-math("\\alpha \\ast \\beta(n)  & \\ll \\sum_{d|n} (\\log^{O(1)}) x \\tau(d)^{O(1)} \\tau(\\frac{n}{d})^{O(1)}", block: true)



#tao-math(" & \\ll (\\log^{O(1)} x) \\tau(n) \\tau(n)^{O(1)} \\tau(n)^{O(1)}", block: true)
]

#text("so that ")#mi("{\\alpha \\ast \\beta}")#text(" is again a coefficient sequence. The claim (ii) then follows by considering the support of ")#mi("{\\alpha \\ast \\beta}")#text(".")

#text("Now we verify (iii). We need to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Delta((\\alpha \\ast \\beta)1_{(\\cdot,q)=1}, a\\ (r))\\right| \\ll \\tau(qr)^{O(1)} N \\log^{-A} x", block: true)]]

#text("for any ")#mi("{q}")#text(" and any residue class ")#mi("{a\\ (r)}")#text(". By restricting ")#mi("{\\alpha,\\beta}")#text(" to integers coprime to ")#mi("{qr}")#text(" (and noting that the restricted version of ")#mi("{\\beta}")#text(" still obeys the Siegel-Walfisz property if one divides out by a suitable power of ")#mi("{\\tau(qr)}")#text(") we may assume that ")#mi("{\\alpha,\\beta}")#text(" are supported on integers coprime to ")#mi("{qr}")#text(", at which point we may drop the ")#mi("{1_{(\\cdot,qr)=1}}")#text(" constraint. As noted in Lemma ")#link(<tao-ab7902bcbd91137e09d6>)[#text("8")]#text(" we may also assume that ")#mi("{r = O( \\log^{A+O(1)} x)}")#text(".")

#text("We now have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n = a\\ (r)} \\alpha \\ast \\beta(n) = \\sum_{b,c\\in ({\\bf Z}/r{\\bf Z})^\\times: a=bc} (\\sum_{d = b\\ (r)} \\alpha(d)) (\\sum_{m = c\\ (r)} \\beta(m))")]]

#text("and")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n} \\alpha \\ast \\beta(n)  & = (\\sum_d \\alpha(d)) (\\sum_m \\beta(m))", block: true)



#tao-math(" & = \\sum_{b,c \\in ({\\bf Z}/r{\\bf Z})^\\times: a=bc} (\\sum_{d = b\\ (r)} \\alpha(d)) (\\sum_m \\beta(m))", block: true)
]

#text("and by the triangle inequality so we may upper bound ")#tao-math("{\\left|\\Delta(\\alpha \\ast \\beta, a\\ (r))\\right|}", block: false)#text(" by")

#align(center)[#tao-fit-display[#tao-math("\\sum_{b,c \\in ({\\bf Z}/r{\\bf Z})^\\times: a=bc} \\left|\\sum_{d = b\\ (r)} \\alpha(d)\\right| \\left| \\Delta(\\beta; c\\ (r))\\right|.", block: true)]]

#text("Applying ")#link(<tao-a543997d84f12798350c>)[#text("(7)")]#text(" for ")#mi("{\\beta}")#text(" and ")#link(<tao-bde297e6789cd213bef8>)[#text("(14)")]#text(" for ")#mi("{\\alpha}")#text(", we may bound this by")

#align(center)[#tao-fit-display[#mitex("\\ll \\tau(r)^{O(1)} \\log^{-A^{\\prime} + O(1)} x \\sum_{b,c \\in ({\\bf Z}/r{\\bf Z})^\\times: a=bc} ( \\frac{N}{r} + N^{o(1)} ) M")]]

#text("for any fixed ")#mi("{A^{\\prime}}")#text(", which is acceptable using the bound on ")#mi("{r}")#text(".")

#text("Now we verify (iv), which is similar to (iii). Arguing as before, we have the inequality")

#align(center)[#tao-fit-display[#tao-math("\\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(\\alpha \\ast \\beta; a\\ (q))\\right| \\ll (\\sum_{d} \\left|\\alpha(d)\\right|) \\sup_{c \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(\\beta; c\\ (q))\\right|.", block: true)]]

#text("The claim then follows from ")#link(<tao-a302389dda3380261213>)[#text("(13)")]#text(" and the Elliott-Halberstam hypothesis for ")#mi("{\\beta}")#text(".")

#text("Finally, (v) is an easy consequence of the product rule and is left to the reader. ")#mi("\\Box")

#text("We also have some basic sequences that obey the Siegel-Walfisz property:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 10")]#text(" ")#metadata(none) <tao-0e982fbf2b80be4e1970>#text(" Let ")#mi("{\\alpha}")#text(" be a smooth coefficient sequence at some scale ")#mi("{N}")#text(" with ")#mi("{x^c \\ll N \\ll x^C}")#text(" for some fixed ")#mi("{C, c>0}")#text(". Then")

#list(
[#text("(i) ")#mi("{\\alpha}")#text(" obeys the Siegel-Walfisz theorem.")],
[#text("(ii) In fact, ")#mi("{\\alpha}")#text(" obeys the Elliott-Halberstam conjecture up to scale ")#mi("{x^{-\\epsilon} N}")#text(" for any fixed ")#mi("{\\epsilon>0}")#text(".")],
[#text("(iii) ")#mi("{\\mu\\alpha}")#text(" obeys the Siegel-Walfisz theorem, where ")#mi("{\\mu}")#text(" is the ")#link("http://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("Möbius function")]#text(".")]
)
]

#text("Note that some lower bound on ")#mi("{N}")#text(" is necessary here, since one cannot hope for a sequence to be equidistributed to the extent predicted by the Siegel-Walfisz theorem ")#link(<tao-a543997d84f12798350c>)[#text("(7)")]#text(" if the sequence is only supported on a logarithmic range!")

#emph[#text("Proof:")]#text(" We first prove (i). Our task is to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Delta(\\alpha 1_{(\\cdot,q)=1}, a\\ (r))\\right| \\ll \\tau(qr)^{O(1)} N \\log^{-A} x", block: true)]]

#text("for any ")#mi("{q}")#text(" and any residue class ")#mi("{a\\ (r)}")#text(". By applying the Möbius inversion formula")

#align(center)[#tao-fit-display[#mitex("1_{(n,q)=1} = \\sum_{d|q} \\mu(d) 1_{n = 0\\ (d)}")]]

#text("and the triangle inequality ")#link(<tao-0a3f13c673af2389ecb9>)[#text("(6)")]#text(" we thus see that it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Delta(\\alpha 1_{d|\\cdot}, a\\ (r))\\right| \\ll \\tau(dr)^{O(1)} N \\log^{-A} x", block: true)]]

#text("for any ")#mi("{d}")#text(". We may assume that ")#mi("{r}")#text(" is coprime to ")#mi("{d}")#text(" as the left-hand side vanishes otherwise. Our task is now to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n: n = 0\\ (d); n = a\\ (r)} \\alpha(n) = \\frac{1}{\\phi(r)} \\sum_{n: n = 0\\ (d); (n,r)=1} \\alpha(n) + \\tau(dr)^{O(1)} N \\log^{-A} x.")]]

#text("For this it will suffice to establish the claim ")#metadata(none) <tao-e96e02d8e47f2a7c03be>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\sum_{n} \\alpha(n) 1_{n = a\\ (q)} = \\frac{1}{q} (\\sum_n \\alpha(n)) + O( \\tau(q)^{O(1)} N \\log^{-A} x )")]]

#text("for any residue class ")#mi("{a\\ (q)}")#text(" (not necessarily primitive). Note that we may assume that ")#mi("{q = O( \\log^{A+O(1)}(x) )}")#text(" as the claim follows from ")#link(<tao-bde297e6789cd213bef8>)[#text("(14)")]#text(" otherwise. We use the Fourier expansion")

#align(center)[#tao-fit-display[#mitex("1_{n=a\\ (q)} = \\frac{1}{q} \\sum_{h \\in {\\bf Z}/q{\\bf Z}} e_q(-ah) e_q(hn)")]]

#text("where ")#mi("{e_q(n) := e^{2\\pi i n/q}}")#text(" for ")#mi("{n \\in {\\bf Z}/q{\\bf Z}}")#text(" or (by abuse of notation) for ")#mi("{n \\in {\\bf Z}}")#text(". We can thus write the left-hand side of ")#link(<tao-e96e02d8e47f2a7c03be>)[#text("(17)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{q} \\sum_{h \\in {\\bf Z}/q{\\bf Z}} e_q(-ah) \\sum_n \\alpha(n) e_q(hn).")]]

#text("The ")#mi("{h=0}")#text(" term here is the first term on the right-hand side of ")#link(<tao-e96e02d8e47f2a7c03be>)[#text("(17)")]#text(". Thus it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_n \\alpha(n) e_q(hn)\\right| \\ll N \\log^{-A} x", block: true)]]

#text("for all non-zero ")#mi("{h \\in {\\bf Z}/q{\\bf Z}}")#text(". But if we write ")#mi("{\\alpha(n) = \\psi(n/N)}")#text(", then by the ")#link("http://en.wikipedia.org/wiki/Poisson_summation_formula")[#text("Poisson summation formula")]#text(" the left-hand side is equal to")

#align(center)[#tao-fit-display[#mitex("N \\sum_m \\hat \\psi( N m - N h / q )")]]

#text("where ")#mi("{\\hat \\psi(t) := \\int_{\\bf R} \\psi(s) e^{-2\\pi i st}\\ ds}")#text(" is the Fourier transform of ")#mi("{\\psi}")#text(". From the smoothness bounds ")#link(<tao-ab1e6be2000a7c9c3d39>)[#text("(9)")]#text(" and integration by parts we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\hat \\psi(t)\\right| \\ll \\left|t\\right|^{-j} \\log^{(j-1) A_0} x", block: true)]]

#text("for any fixed ")#mi("{j>0}")#text(", so for ")#mi("{j}")#text(" large enough (actually ")#mi("{j=2}")#text(" is enough) we obtain the claim thanks to the lower bound ")#mi("{N \\gg x^c}")#text(" and the upper bound ")#mi("{q = O( \\log^{A+O(1)} x)}")#text(". We remark that the same argument (now with ")#mi("{j}")#text(" as large as needed) in fact shows the much stronger bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{n} \\alpha(n) 1_{n = a\\ (q)} = \\frac{1}{q} (\\sum_n \\alpha(n)) + O( \\tau(q)^{O(1)} N x^{-A} )")]]

#text("for any fixed ")#mi("{A,\\epsilon>0}")#text(" and any ")#mi("{q < x^{-\\epsilon} N}")#text(", which also gives (ii).")

#text("To prove (iii), we can argue similarly to before and reduce to showing that")

#align(center)[#tao-fit-display[#tao-math("\\left| \\sum_{n} \\mu(n) \\alpha(n) 1_{n = a\\ (q)}\\right| \\ll \\tau(q)^{O(1)} N \\log^{-A} x", block: true)]]

#text("for any ")#mi("{a\\ (q)}")#text(", but this follows from ")#link("http://en.wikipedia.org/wiki/Siegel%E2%80%93Walfisz_theorem")[#text("the Siegel-Walfisz theorem")]#text(" for the Möbius function (which can be deduced from the more usual Siegel-Walfisz theorem for the von Mangoldt function, or else proven by essentially the same method) and summation by parts (if one wishes, one can also reduce to the case of primitive residue classes using the multiplicativity of ")#mi("{\\mu}")#text("). ")#mi("\\Box")

#text("We remark that the Siegel-Walfisz theorem for the Möbius function is ineffective, although in practice one can obtain effective substitutes for this theorem that can make applications (such as the one for bounded prime gaps) effective, see e.g. the last section of ")#link("http://arxiv.org/abs/1305.6289")[#text("this article of Pintz")]#text(" for further discussion. One amusing remark in this regard is that if there do happen to be infinitely many Siegel zeroes, then an ")#link("http://www.ams.org/mathscinet-getitem?mr=703977")[#text("old result of Heath-Brown")]#text(" shows that there are infinitely mnay twin primes already, so the ineffective case of Siegel-Walfisz’s theorem is in some sense the best case scenario for us!")

#text("Lemmas ")#link(<tao-6244580a346acf5d814a>)[#text("9")]#text(" and ")#link(<tao-0e982fbf2b80be4e1970>)[#text("10")]#text(" combine to give plenty of coefficient sequences obeying the Siegel-Walfisz property. This will become useful when the time comes to deduce Theorem ")#link(<tao-20854963535d2fa25505>)[#text("1")]#text(" from (the precise versions of) Theorems ")#link(<tao-512f26ada3c3d634ac3c>)[#text("2")]#text(", ")#link(<tao-628b49d96dcde97a430d>)[#text("3")]#text(", ")#link(<tao-c44474038d459e40e471>)[#text("4")]#text(".")

#heading(level: 1)[#strong[#text(" — 2. Congruence class systems — ")]]

#text("The Elliott-Halberstam conjecture on a sequence at scale ")#mi("{N}")#text(" requires taking a supremum over all primitive residue classes. At present, we do not know how to achieve such a strong claim for non-smooth arithmetic sequences such as ")#mi("{\\Lambda}")#text(" or ")#mi("{\\mu}")#text(" once the modulus goes beyond the level ")#mi("{N^{1/2}}")#text(", even if one restricts to smooth moduli. However, Zhang’s work (as well as some of the precursor work of Bombieri, Fouvry, Friedlander, and Iwaniec) allow one to get a restricted version of the Elliott-Halberstam conjecture if one restricts the congruences one is permitted to work with.")

#text("Much as with the coefficient sequence axioms, it is convenient to abstract the axioms that a given system of congruence classes will be obeying. For any set ")#mi("{I \\subset {\\bf R}}")#text(", let ")#mi("{{\\mathcal S}_I}")#text(" denote the set of squarefree natural numbers whose prime divisors lie in ")#mi("{I}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 11")]#text(" Let ")#mi("{I \\subset {\\bf R}}")#text(". A ")#emph[#text("congruence class system")]#text(" on ")#mi("{I}")#text(" is a collection ")#mi("{{\\mathcal C} = (C(q))_{q \\in {\\mathcal S}_I}}")#text(" of sets ")#mi("{C(q)}")#text(" residue classes for each ")#mi("{q \\in {\\mathcal S}_I}")#text(" obeying the following axioms:")

#list(
[#text("(i) (Primitivity) For each ")#mi("{q \\in {\\mathcal S}_I}")#text(", ")#mi("{C(q)}")#text(" is a subset of ")#mi("{({\\bf Z}/q{\\bf Z})^\\times}")#text(".")],
[#text("(ii) (Chinese remainder theorem) For any coprime ")#mi("{q,r \\in {\\mathcal S}_I}")#text(", we have ")#mi("{C(q) \\times C(r) \\equiv C(qr)}")#text(", using the canonical identification between ")#mi("{({\\bf Z}/q{\\bf Z})^\\times \\times ({\\bf Z}/r{\\bf Z})^\\times}")#text(" and ")#mi("{({\\bf Z}/qr{\\bf Z})^\\times}")#text(".")],
[#text("(iii) (Uniform bound) There is a fixed ")#mi("{k_0}")#text(" such that ")#tao-math("{\\left|C(p)\\right| \\leq k_0}", block: false)#text(" for all primes ")#mi("{p \\in I}")#text(".")]
)

#text("If ")#tao-math("{\\left|C(p)\\right|=1}", block: false)#text(" for all ")#mi("{p \\in I}")#text(", thus ")#mi("{C(q) = (a_q)_{q \\in {\\mathcal S}_I}}")#text(", we say that ")#mi("{(C(q))_{q \\in {\\mathcal S}_I}}")#text(" is a ")#emph[#text("singleton congruence class system")]#text(".")

#text("For any integer ")#mi("{n}")#text(", let ")#mi("{\\tau_{\\mathcal C}(n)}")#text(" denote the multiplicity function")

#align(center)[#tao-fit-display[#tao-math("\\tau_{\\mathcal C}(n) := \\left|\\{ q \\in {\\mathcal S}_I: n\\ (q) \\in C(q) \\}\\right|", block: true)]]

#text("or equivalently")

#align(center)[#tao-fit-display[#tao-math("\\tau_{\\mathcal C}(n) := 2^{\\left|\\{ p \\in I: n\\ (p) \\in C(p) \\}\\right|}", block: true)]]

#text("A congruence class system is said to have ")#emph[#text("controlled multiplicity")]#text(" if for any congruence class ")#mi("{a\\ (r)}")#text(" with ")#mi("{r \\in {\\mathcal S}_I}")#text(", we have ")#metadata(none) <tao-cbf38e496835a79fe9ba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\sum_{C^{-1} x \\leq n \\leq Cx: n = a\\ (r)} \\tau_{\\mathcal C}(n)^2 \\ll \\frac{x}{r} \\tau(r)^{O(1)} \\log^{O(1)} x + x^{o(1)}.")]]

#text("for any fixed ")#mi("{C>1}")#text(".")
]

#text("Note from Axiom (ii) that a congruence class system can be specified through its values ")#mi("{C(p)}")#text(" at primes ")#mi("{p \\in I}")#text(". A simple example of a singleton congruence class system with controlled multiplicity is a fixed congruence class ")#mi("{C(q) = \\{ a\\ (q) \\}}")#text(" for some fixed non-zero ")#mi("{a}")#text(", with ")#mi("{I}")#text(" avoiding all the prime divisors of ")#mi("{a}")#text(". This is a special case of the following more general fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 12")]#text(" ")#metadata(none) <tao-8db59feb4d217f26c79d>#text(" Let ")#mi("{{\\mathcal H}}")#text(" be a fixed admissible ")#mi("{k_0}")#text("-tuple for some fixed ")#mi("{k_0 \\geq 2}")#text(", and let ")#mi("{h_i \\in {\\mathcal H}}")#text(". For any modulus ")#mi("{q}")#text(", set")

#align(center)[#tao-fit-display[#mitex("C_i(q) := \\{ a \\in ({\\bf Z}/q{\\bf Z})^\\times: P(a) =0 \\}")]]

#text("where ")#mi("{P(a) := \\prod_{h \\in {\\mathcal H}} (a+h-h_i)}")#text(". Then for any ")#mi("{I \\subset {\\bf R}}")#text(", ")#mi("{(C_i(q))_{q \\in {\\mathcal S}_I}}")#text(" is a congruence class system on ")#mi("{I}")#text(" with controlled multiplicity.")

#text("Similarly, if ")#mi("{b\\ (W)}")#text(" is such that ")#mi("{b+h-h_i}")#text(" is coprime to ")#mi("{W}")#text(" for all ")#mi("{h \\in {\\mathcal H}}")#text(" and ")#mi("{I \\subset{\\bf R}}")#text(", then the system ")#mi("{(C_{i,b,W}(q))_{q \\in {\\mathcal S}_I}}")#text(" defined by setting ")#mi("{C_{i,b,W}(p) := C_i(p)}")#text(" when ")#mi("{p}")#text(" is coprime to ")#mi("{W}")#text(", and ")#mi("{C_{i,b,W}(p) := \\{ b\\ (p)\\}}")#text(" when ")#mi("{p}")#text(" divides ")#mi("{W}")#text(", with ")#mi("{C_{i,b,W}(q)}")#text(" then defined for arbitrary ")#mi("{q \\in {\\mathcal S}_I}")#text(" by the Chinese remainder theorem, is also a congruence system on ")#mi("{I}")#text(" with controlled multiplicity.")
]

#emph[#text("Proof:")]#text(" We just prove the first claim, as the second is similar. Axioms (i)-(iii) are obvious; it remains only to verify the controlled multiplicity. Let ")#mi("{a\\ (r)}")#text(" be a congruence class with ")#mi("{r \\in {\\mathcal S}_I}")#text(".")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\ll n \\ll x: m = a\\ (r)} 2^{2\\left|\\{ p \\in I: p \\not | n; p | P(n) \\}\\right|}.", block: true)]]

#text("We can split")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ p \\in I: p \\not | n; p | P(n) \\}\\right| \\leq \\sum_{h \\in {\\mathcal H}} \\left|\\{ p \\in I: p | n + h - h_i\\}\\right|", block: true)]]

#text("and hence")

#tao-aligned(keep: true)[


#tao-math("2^{2\\left|\\{ p \\in I: p \\not | n; p | P(n) \\}\\right|}  & \\leq \\sum_{h \\in {\\mathcal H}} 2^{2k_0 \\left|\\{ p \\in I: p | n + h - h_i\\}\\right|}", block: true)



#tao-math(" & = \\sum_{h \\in {\\mathcal H}} \\tau(n+h-h_i)^{2k_0}", block: true)
]

#text("so it suffices to show that ")#metadata(none) <tao-a31fe9656fc8d3a459e6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\sum_{x \\ll n \\ll x: n = a\\ (r)} \\tau(n+h-h_i)^{2k_0} \\ll \\frac{x}{r} \\tau(r)^{O(1)} \\log^{O(1)} x + x^{o(1)}")]]

#text("for each ")#mi("{h \\in {\\mathcal H}}")#text(". Writing ")#mi("{b := a+h-h_i}")#text(", this becomes")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\ll n \\ll x: n = b\\ (r)} \\tau(n)^{2k_0} \\ll \\frac{x}{r} \\tau(r)^{O(1)} \\log^{O(1)} x + x^{o(1)}.")]]

#text("The claim then follows Lemma ")#link(<tao-ab7902bcbd91137e09d6>)[#text("8")]#text(". ")#mi("\\Box")

#text("The more precise statement of Theorem ")#link(<tao-20854963535d2fa25505>)[#text("1")]#text(" is now as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 13 (Zhang’s theorem, numerically optimised)")]#text(" ")#metadata(none) <tao-14bbfb46cb710ab5cf47>#text(" Let ")#mi("{\\varpi, \\delta > 0}")#text(" be fixed parameters such that ")#metadata(none) <tao-a70041ea283d8c34b1f6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("207 \\varpi + 43 \\delta < \\frac{1}{4}.")]]

#text("Let ")#mi("{I \\subset [1,x^\\delta]}")#text(", and let ")#mi("{(C(q))_{q \\in {\\mathcal S}_I}}")#text(" be a congruence class system with controlled multiplicity. Then ")#metadata(none) <tao-6d7e04068fa604f0ea60>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\sum_{q \\in {\\mathcal S}_I: q< x^{1/2+2\\varpi}} \\sum_{a \\in C(q)} \\left|\\Delta(\\Lambda 1_{[x,2x]}; a\\ (q))\\right| \\ll x \\log^{-A} x", block: true)]]

#text("for any fixed ")#mi("{A>0}")#text(", where ")#mi("{\\Lambda}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(".")
]

#text("For the application to prime gaps we only need to apply Theorem ")#link(<tao-14bbfb46cb710ab5cf47>)[#text("13")]#text(" to the congruence class system associated to a fixed ")#mi("{k}")#text("-tuple ")#mi("{{\\mathcal H}}")#text(" through Lemma ")#link(<tao-8db59feb4d217f26c79d>)[#text("12")]#text(", but one could imagine that this theorem could have future application with some other congruence class systems.")

#text("One advantage of the abstract formulation of a congruence class systems is that we get a cheap reduction to the singleton case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 14 (Reduction to singletons)")]#text(" ")#metadata(none) <tao-947f187506f7629c81c8>#text(" In order to prove Theorem ")#link(<tao-14bbfb46cb710ab5cf47>)[#text("13")]#text(", it suffices to do so for good singleton class congruence systems.")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{(C(q))_{q \\in {\\mathcal S}_I}}")#text(" be a good congruence class system. By removing all primes ")#mi("{p}")#text(" with ")#tao-math("{\\left|C(p)\\right|=0}", block: false)#text(" from ")#mi("{I}")#text(" we may assume without loss of generality that ")#tao-math("{1 \\leq \\left|C(p)\\right| \\leq k_0}", block: false)#text(" for all ")#mi("{p \\in I}")#text(" and some fixed ")#mi("{k_0}")#text(".")

#text("We use the probabilistic method. Construct a random singleton congruence class system ")#mi("{(\\tilde C(q))_{q \\in {\\mathcal S}_I}}")#text(" by selecting ")#mi("{a_p}")#text(" uniformly at random from ")#mi("{C(p)}")#text(" independently for all ")#mi("{p \\in I}")#text(", and then set ")#mi("{\\tilde C(p) = \\{ a_p\\}}")#text(" and extend by the Chinese remainder theorem. Writing ")#mi("{\\tilde C(q) = \\{ a_q \\}}")#text(", we observe that the property that ")#mi("{(C(q))_{q \\in {\\mathcal S}_I}}")#text(" enjoys of being a congruence class system of controlled multiplicity is inherited by ")#mi("{(\\tilde C(q))_{q \\in {\\mathcal S}_I}}")#text(". From hypothesis we then have that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\in {\\mathcal S}_I: q< x^{1/2+2\\varpi}} \\left|\\Delta(\\Lambda 1_{[x,2x]}; a_q\\ (q))\\right| \\ll x \\log^{-A} x", block: true)]]

#text("for any fixed ")#mi("{A}")#text("; taking expectations we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\in {\\mathcal S}_I: q< x^{1/2+2\\varpi}} \\frac{1}{\\left|C(q)\\right|} \\sum_{a \\in C(q)} \\left|\\Delta(\\Lambda 1_{[x,2x]}; a\\ (q))\\right| \\ll x \\log^{-A} x.", block: true)]]

#text("On the other hand, from Lemma ")#link(<tao-ab7902bcbd91137e09d6>)[#text("8")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\in {\\mathcal S}_I: q< x^{1/2+2\\varpi}} |C(q)| \\sum_{a \\in C(q)} \\left|\\Delta(\\Lambda 1_{[x,2x]}; a\\ (q))\\right| \\ll x \\log^{O(1)} x,", block: true)]]

#text("and the claim then follows from Cauchy-Schwarz. ")#mi("\\Box")

#text("This reduction is not essential to Zhang’s argument (indeed, it is not used in Zhang’s paper), but it does allow for a slightly simpler notation (since the summation over ")#mi("{a}")#text(" is eliminated).")

#text("We can now also state the precise versions of Theorems ")#link(<tao-512f26ada3c3d634ac3c>)[#text("2")]#text(", ")#link(<tao-628b49d96dcde97a430d>)[#text("3")]#text(", ")#link(<tao-c44474038d459e40e471>)[#text("4")]#text(" that we need:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 15 (Type 0 estimate, precise version)")]#text(" ")#metadata(none) <tao-3b0a4462ca95718fae74>#text(" Let ")#mi("{0 < \\varpi < 1/2}")#text(" be fixed, and let ")#mi("{\\alpha,\\psi}")#text(" be coefficient sequences at scales ")#mi("{M,N}")#text(" respectively with ")#mi("{\\psi}")#text(" smooth,")

#align(center)[#tao-fit-display[#mitex("x \\ll MN \\ll x,")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("N > x^{1/2+2\\varpi+\\epsilon}")]]

#text("for some fixed ")#mi("{\\epsilon>0}")#text(". Then ")#mi("{\\alpha \\ast \\psi}")#text(" obeys the Elliott-Halberstam conjecture up to scale ")#mi("{x^{1/2+2\\varpi}}")#text(". In particular, for any ")#mi("{I \\subset {\\bf R}}")#text(" and any singleton congruence class system ")#mi("{(\\{a_q\\})_{q \\in {\\mathcal S}_I}}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\in {\\mathcal S}_I: q< x^{1/2+2\\varpi}} \\left|\\Delta(\\alpha \\ast \\psi; a_q\\ (q))\\right| \\ll x \\log^{-A} x.", block: true)]]
]

#emph[#text("Proof:")]#text(" This is immediate from Lemma ")#link(<tao-0e982fbf2b80be4e1970>)[#text("10")]#text("(ii) and Lemma ")#link(<tao-6244580a346acf5d814a>)[#text("9")]#text("(iv). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 16 (Type I/II estimate, precise version)")]#text(" ")#metadata(none) <tao-840c81157f3688e42875>#text(" Let ")#mi("{\\varpi, \\delta, \\sigma > 0}")#text(" be fixed quantities such that")

#align(center)[#tao-fit-display[#mitex("11 \\varpi + 3\\delta + 2 \\sigma < \\frac{1}{4}")]]

#text("and ")#metadata(none) <tao-5b1b85d956c07f3e4d5f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("37\\varpi + 5 \\delta < \\frac{1}{4}")]]

#text("and let ")#mi("{\\alpha,\\beta}")#text(" be coefficient sequences at scales ")#mi("{M,N}")#text(" respectively with")

#align(center)[#tao-fit-display[#mitex("x \\ll MN \\ll x")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("x^{\\frac{1}{2}-\\sigma} \\ll N \\ll M \\ll x^{\\frac{1}{2}+\\sigma}")]]

#text("with ")#mi("{\\beta}")#text(" obeying a Siegel-Walfisz theorem. Then for any ")#mi("{I \\subset [1,x^\\delta]}")#text(" and any singleton congruence class system ")#mi("{(\\{a_q\\})_{q \\in {\\mathcal S}_I}}")#text(" with controlled multiplicity we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\in {\\mathcal S}_I: q< x^{1/2+2\\varpi}} \\left|\\Delta(\\alpha \\ast \\beta; a_q\\ (q))\\right| \\ll x \\log^{-A} x.", block: true)]]
]

#text("The condition ")#link(<tao-5b1b85d956c07f3e4d5f>)[#text("(22)")]#text(" is dominated by ")#link(<tao-a70041ea283d8c34b1f6>)[#text("(20)")]#text(" and can thus be ignored, at least at our current numerical ranges of parameters. We remark that this theorem is the only theorem that actually uses the controlled multiplicity hypothesis.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 17 (Type III estimate, precise version)")]#text(" ")#metadata(none) <tao-9ce19620746a8f953f54>#text(" Let ")#mi("{\\varpi, \\delta > 0}")#text(" be fixed quantities. Let ")#mi("{N_1,N_2,N_3, M > 1}")#text(" be scales obeying the relations")

#tao-aligned(keep: true)[


#tao-math("N_3  & \\ll N_2 \\ll N_1 \\ll x^{1/2}", block: true)



#tao-math("N_1^4 N_2^4 N_3^5  & > x^{4+16\\varpi + \\delta+\\epsilon}", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#mitex("x \\ll MN_1 N_2 N_3 \\ll x")]]

#text("for some fixed ")#mi("{\\epsilon>0}")#text(". Let ")#mi("{\\alpha,\\psi_1,\\psi_2,\\psi_3}")#text(" be coefficient sequences at scales ")#mi("{M,N_1,N_2,N_3}")#text(" respectively, with ")#mi("{\\psi_1,\\psi_2,\\psi_3}")#text(" smooth. Then for any ")#mi("{I \\subset [1,x^\\delta]}")#text(", and any singleton congruence class system ")#mi("{(\\{a_q\\})_{q \\in {\\mathcal S}_I}}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\in {\\mathcal S}_I: q< x^{1/2+2\\varpi}} \\left|\\Delta(\\alpha \\ast \\psi_1 \\ast \\psi_2 \\ast \\psi_3; a_q\\ (q))\\right| \\ll x \\log^{-A} x", block: true)]]

#text("for any fixed ")#mi("{A>0}")#text(".")
]

#text("As we saw, Theorem ")#link(<tao-3b0a4462ca95718fae74>)[#text("15")]#text(" is easy to establish. On the other hand, Theorem ")#link(<tao-840c81157f3688e42875>)[#text("16")]#text(" and Theorem ")#link(<tao-9ce19620746a8f953f54>)[#text("17")]#text(" are far deeper and will be the subject of future blog posts. We will not discuss them further here, but now turn to the question of how to deduce Theorem ")#link(<tao-14bbfb46cb710ab5cf47>)[#text("13")]#text(" from Theorems ")#link(<tao-3b0a4462ca95718fae74>)[#text("15")]#text(", ")#link(<tao-840c81157f3688e42875>)[#text("16")]#text(", ")#link(<tao-9ce19620746a8f953f54>)[#text("17")]#text(" using Lemma ")#link(<tao-fc6a3d0fff933962afcc>)[#text("5")]#text(".")

#heading(level: 1)[#strong[#text(" — 3. Decomposing the von Mangoldt function — ")]]

#text("The basic strategy is to decompose the von Mangoldt function ")#mi("{\\Lambda}")#text(" as a combination of Dirichlet convolutions of other functions such as ")#mi("{\\mu}")#text(", the constant function ")#mi("{1}")#text(", and the logarithmic function ")#mi("{L: n \\mapsto \\log n}")#text(". The simplest identity of this form is ")#metadata(none) <tao-29df0906e1730ea20667>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\Lambda = \\mu \\ast L")]]

#text("but this is unsuitable for our purposes because when we localise ")#mi("{\\Lambda}")#text(" to scale ")#mi("{x}")#text(", the ")#mi("{\\mu}")#text(" factor could also be localised at scales as large as ")#mi("{x}")#text(", and our understanding of the equidistribution properties of the Möbius function is basically no better than that of the von Mangoldt function, so we have not gained anything with this decomposition.")

#text("To get around this we need to find decompositions that don’t let rough functions such as the Möbius function get up to scales anywhere close to ")#mi("{x}")#text(". One promising identity in this regard is ")#emph[#text("Linnik’s identity")]#text(", which takes the form")

#align(center)[#tao-fit-display[#mitex("\\Lambda = L - L \\ast 1^* + L \\ast 1^* \\ast 1^* - L \\ast 1^* \\ast 1^* \\ast 1^* + \\ldots")]]

#text("where ")#mi("{1^*(n) := 1_{n \\neq 1}}")#text(" is the restriction of the constant function ")#mi("{1}")#text(" to numbers larger than ")#mi("{1}")#text("; this is just the coefficient version of the formal geometric series identity")

#align(center)[#tao-fit-display[#mitex("-\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)} = -\\zeta^{\\prime}(s) + \\zeta^{\\prime}(s) (\\zeta(s)-1) - \\zeta^{\\prime}(s) (\\zeta(s)-1)^2 + \\ldots.")]]

#text("There are no Möbius functions in sight on the right-hand side, which is promising. However, Linnik’s identity has an unbounded number of terms, which render it unsuitable for our argument (we have various factors of ")#mi("{\\tau^{O(1)}(n)}")#text(" and ")#mi("{\\log^{O(1)} x}")#text(" whose exponent would become unbounded if we had to deal with Dirichlet convolutions of unbounded length, which would swamp any gain of ")#mi("{\\log^{-A} x}")#text(" that we are trying to detect). So we will rely on a truncated variant of Linnik’s identity, known as the ")#link("http://www.ams.org/mathscinet-getitem?mr=0678676")[#text("Heath-Brown identity")]#text(".")

#text("We will need a fixed positive natural number ")#mi("{K}")#text(" (Zhang takes ")#mi("{K=10}")#text("; the precise choice here does not seem to be terribly important). From the identities ")#mi("{\\Lambda = \\mu \\ast L}")#text(" and ")#mi("{\\delta = \\mu \\ast 1}")#text(", where ")#mi("{\\delta(n) = 1_{n=1}}")#text(" is the Dirichlet convolution identity, we see that we can write ")#mi("{\\Lambda}")#text(" as a ")#mi("{2K}")#text("-fold convolution ")#metadata(none) <tao-28650e111f88c58648e5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\Lambda = \\mu^{*K} \\ast 1^{*K-1} \\ast L")]]

#text("where ")#mi("{\\mu^{*K}}")#text(" denotes the convolution of ")#mi("{K}")#text(" copies of ")#mi("{\\mu}")#text(".")

#text("As with ")#link(<tao-29df0906e1730ea20667>)[#text("(23)")]#text(", the identity ")#link(<tao-28650e111f88c58648e5>)[#text("(24)")]#text(" is not directly useful for our strategy because one of the ")#mi("{\\mu}")#text(" factors can still get as large as the scale ")#mi("{x}")#text(" that we are studying ")#mi("{\\Lambda}")#text(" at. However, as Heath-Brown observed, we can manipulate ")#link(<tao-28650e111f88c58648e5>)[#text("(24)")]#text(" into a useful form by truncating the Möbius function ")#mi("{\\mu}")#text(". More precisely, we split the Möbius function ")#mi("{\\mu}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\mu = \\mu_\\leq + \\mu_>")]]

#text("where ")#mi("{\\mu_\\leq}")#text(" is the Möbius function restricted to the interval ")#mi("{[1,(2x)^{1/K}]}")#text(", and ")#mi("{\\mu_>}")#text(" is the Möbius function restricted to the interval ")#mi("{((2x)^{1/K},\\infty)}")#text(". The reason for this splitting is that the ")#mi("{K}")#text("-fold Möbius convolution ")#mi("{\\mu_>^{*K}}")#text(" vanishes on ")#mi("{[1,2x]}")#text(", and in particular we have")

#align(center)[#tao-fit-display[#mitex("0 = \\mu_>^{*K} \\ast 1^{*K-1} \\ast L")]]

#text("on ")#mi("{[x,2x]}")#text(". Expanding out ")#mi("{\\mu_> = \\mu - \\mu_\\leq}")#text(" and using the binomial formula, we conclude that ")#metadata(none) <tao-381866f546ffc92b9dfe>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("0 = \\sum_{j=0}^K (-1)^{j} \\binom{K}{j} \\mu^{*K-j} \\ast \\mu_{\\leq}^{j} \\ast 1^{*K-1} \\ast L")]]

#text("on ")#mi("{[x,2x]}")#text(".")

#text("By ")#link(<tao-28650e111f88c58648e5>)[#text("(24)")]#text(", the ")#mi("{j=0}")#text(" term of ")#link(<tao-381866f546ffc92b9dfe>)[#text("(25)")]#text(" is just ")#mi("{\\Lambda}")#text(". For all the other terms, we can cancel ")#mi("{\\mu^{*K-j}}")#text(" against ")#mi("{1^{*K-j}}")#text(" using the Möbius inversion formula ")#mi("{\\delta = \\mu \\ast 1}")#text(" to conclude the ")#emph[#text("Heath-Brown identity")]

#align(center)[#tao-fit-display[#mitex("\\Lambda =\\sum_{j=1}^K (-1)^{j-1} \\binom{K}{j} \\mu_{\\leq}^j \\ast 1^{*j-1} \\ast L")]]

#text("on ")#mi("{[x,2x]}")#text(". Now we see that each of the Möbius factors ")#mi("{\\mu_{\\leq}}")#text(" cannot reach scales much larger than ")#mi("{x^{1/K}}")#text(", although the factors ")#mi("{\\mu_{\\leq}^j}")#text(" may ")#emph[#text("collectively")]#text(" still get close to ")#mi("{x}")#text(" when ")#mi("{j}")#text(" is close to ")#mi("{K}")#text(". From the triangle inequality and Proposition ")#link(<tao-947f187506f7629c81c8>)[#text("14")]#text(", we thus see that to establish Theorem ")#link(<tao-14bbfb46cb710ab5cf47>)[#text("13")]#text(", it suffices to establish the bounds ")#metadata(none) <tao-a871c47a7f48a12b38a9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#tao-math("\\sum_{q \\in {\\mathcal S}_I: q< x^{1/2+2\\varpi}} \\left|\\Delta((\\mu_{\\leq}^j \\ast 1^{*j-1} \\ast L) 1_{[x,2x]}; a_q\\ (q))\\right| \\ll x \\log^{-A} x", block: true)]]

#text("whenever ")#mi("{\\varpi,\\delta > 0}")#text(" are fixed and obey ")#link(<tao-a70041ea283d8c34b1f6>)[#text("(20)")]#text(", ")#mi("{I \\subset [1,x^\\delta]}")#text(", ")#mi("{1 \\leq j \\leq K}")#text(", ")#mi("{A}")#text(" is fixed, and ")#mi("{(a_q)_{q \\in {\\mathcal S}_I}}")#text(" is a singleton congruence class system with controlled multiplicity.")

#text("This is now looking closer to the type of estimates that can be handled by Theorems ")#link(<tao-3b0a4462ca95718fae74>)[#text("15")]#text(", ")#link(<tao-840c81157f3688e42875>)[#text("16")]#text(", ")#link(<tao-9ce19620746a8f953f54>)[#text("17")]#text(", but there are still some technical issues to resolve, namely the presence of the cutoff ")#mi("{1_{[x,2x]}}")#text(" and also the fact that the functions ")#mi("{\\mu_{\\leq}}")#text(", ")#mi("{1}")#text(", ")#mi("{L}")#text(" are not localised to any given scale, but are instead spread out at across many scales. This however can be dealt with by a routine dyadic decomposition (which, in harmonic analysis, is sometimes referred to as ")#link("http://en.wikipedia.org/wiki/Littlewood%E2%80%93Paley_theory")[#text("Littlewood-Paley decomposition")]#text(", at least when applied in the frequency domain), though here instead of using the usual dyadic range ")#mi("{\\{ 2^m: m \\geq 0 \\}}")#text(" of scales, one uses instead a sub-dyadic range ")#mi("{{\\mathcal D} := \\{ (1 + \\log^{-A_0} x)^m: m \\geq 0\\}}")#text(" to eliminate edge effects. (This trick dates back at least to the ")#link("http://www.ams.org/mathscinet-getitem?mr=741055")[#text("work of Fouvry")]#text("; thanks to Emmanuel Kowalski for this reference.)")

#text("More precisely, let ")#mi("{A_0}")#text(" be a large fixed number to be chosen later, and let ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a smooth function supported on ")#mi("{[-1-\\log^{-A_0} x, 1+\\log^{-A_0} x]}")#text(" that equals ")#mi("{1}")#text(" on ")#mi("{[-1,1]}")#text(" and obeys the derivative estimates")

#align(center)[#tao-fit-display[#tao-math("\\left|\\psi^{(j)}(t)\\right| \\ll \\log^{jA_0} x", block: true)]]

#text("for any fixed ")#mi("{j \\geq 0}")#text(" (note that the implied constant here can depend on ")#mi("{j}")#text("). We then have a smooth partition of unity")

#align(center)[#tao-fit-display[#mitex("1 = \\sum_{N \\in {\\mathcal D}} \\psi_N(n)")]]

#text("indexed by the multiplicative semigroup ")#mi("{{\\mathcal D}}")#text(" for any natural number ")#mi("{n}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\psi_N(n) := \\psi( n/N ) - \\psi( (1+\\log^{-A_0} x) n/N ).")]]

#text("We can thus decompose")

#align(center)[#tao-fit-display[#mitex("\\mu_{\\leq} = \\sum_{M \\in {\\mathcal D}} \\mu_{\\leq} \\psi_M")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("1 = \\sum_{N \\in {\\mathcal D}} \\psi_N")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("L = \\sum_{N \\in {\\mathcal D}} L\\psi_N.")]]

#text("For ")#mi("{1 \\leq j \\leq K}")#text(", the expression")

#align(center)[#tao-fit-display[#mitex("(\\mu_{\\leq}^j \\ast 1^{*j-1} \\ast L) 1_{[x,2x]}")]]

#text("can thus be split as")

#align(center)[#tao-fit-display[#mitex("\\sum_{N_1,\\ldots,N_2j \\in {\\mathcal D}} (\\mu_{\\leq} \\psi_{N_1} \\ast \\ldots \\ast \\mu_{\\leq} \\psi_{N_j} \\ast \\psi_{N_{j+1}} \\ast \\ldots \\ast \\psi_{N_{2j-1}} \\ast L \\psi_{N_{2j}}) 1_{[x,2x]}")]]

#text("which we can rewrite as")

#align(center)[#tao-fit-display[#mitex("\\sum_{N_1,\\ldots,N_{2j} \\in {\\mathcal D}} \\log(N_{2j}) \\mu_{\\leq} \\psi_{N_1} \\ast \\ldots \\ast \\mu_{\\leq} \\psi_{N_j} \\ast \\psi_{N_1} \\ast \\ldots \\ast \\psi_{N_{2j-1}} \\ast \\psi^{\\prime}_{N_{2j}} 1_{[x,2x]}")]]

#text("where ")#mi("{\\psi^{\\prime}_N := \\frac{L}{\\log N} \\psi_N}")#text(" is a variant of ")#mi("{\\psi_N}")#text(".")

#text("Observe that the summand vanishes unless")

#align(center)[#tao-fit-display[#mitex("N_1,\\ldots,N_j \\ll x^{1/K}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(1 - O(\\log^{-A_0} x)) x \\leq N_1 \\ldots N_{2j} \\leq (1 + O(\\log^{-A_0} x)) 2x")]]

#text("and the ")#mi("{1_{[x,2x]}}")#text(" factor can be eliminated except in the boundary cases when")

#align(center)[#tao-fit-display[#mitex("N_1 \\ldots N_{2j} = (1 + O(\\log^{-A_0} x)) x")]]

#text("or")

#align(center)[#tao-fit-display[#mitex("N_1 \\ldots N_{2j} = (1 + O(\\log^{-A_0} x)) 2x.")]]

#text("Let us deal with the contribution of the boundary cases to ")#link(<tao-a871c47a7f48a12b38a9>)[#text("(26)")]#text(". If we let ")#mi("{\\alpha}")#text(" be the sum of all the boundary summands, then we have")

#align(center)[#tao-fit-display[#mitex("\\alpha(n) \\ll \\tau(n)^{O(1)} (\\log^{O(1)} x) (1_{n = x + O(x \\log^{-A_0} x)} + 1_{2n = x + O(x \\log^{-A_0} x)}).")]]

#text("From Lemma ")#link(<tao-ab7902bcbd91137e09d6>)[#text("8")]#text(" we have that")

#align(center)[#tao-fit-display[#tao-math("\\sum_n \\left|\\alpha(n)\\right|^2 \\ll x \\log^{O(1)} x", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n = a\\ (q)} \\left|\\alpha(n)\\right|^2 \\ll \\frac{x}{q} \\tau(q)^{O(1)} \\log^{O(1)} x", block: true)]]

#text("for any fixed ")#mi("{C > 0}")#text(" and any ")#mi("{q \\leq x^{1/2+2\\varpi}}")#text(". On the other hand, ")#mi("{\\alpha}")#text(" is supported on two intervals of length ")#mi("{O( x \\log^{-A_0} x )}")#text(". Thus by Cauchy-Schwarz one has")

#align(center)[#tao-fit-display[#tao-math("\\sum_n \\left|\\alpha(n)\\right| \\ll x \\log^{-A_0/2+O(1)} x", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n = a\\ (q)} \\left|\\alpha(n)\\right| \\ll \\frac{x}{q} \\tau(q)^{O(1)} \\log^{-A_0/2+O(1)} x", block: true)]]

#text("for any fixed ")#mi("{\\epsilon>0}")#text(". We thus have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Delta(\\alpha; a\\ (q))\\right| \\ll \\frac{x}{q} \\tau(q)^{O(1)} \\log^{-A_0/2+O(1)} x", block: true)]]

#text("and hence by Lemma ")#link(<tao-ab7902bcbd91137e09d6>)[#text("8")]#text(" again")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\in {\\mathcal S}_I: q< x^{1/2+2\\varpi}} \\left|\\Delta(\\alpha; a_q\\ (q))\\right| \\ll x \\log^{-A_0/2+O(1)} x", block: true)]]

#text("which is acceptable for ")#link(<tao-a871c47a7f48a12b38a9>)[#text("(26)")]#text(" if we take ")#mi("{A_0}")#text(" large enough. Thus it suffices to deal with the contribution of the interior summands, in which the cutoff ")#mi("{1_{[x,2x]}}")#text(" may be dropped. There are ")#mi("{O(\\log^{2j(A_0+1)} x)}")#text(" such summands, and the ")#mi("{\\log(N_j)}")#text(" factor is bounded by ")#mi("{\\log x}")#text(", so it will suffice to show that ")#metadata(none) <tao-729cd87c6329408e2bbf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#tao-math("\\sum_{q \\in {\\mathcal S}_I: q< x^{1/2+2\\varpi}} \\left|\\Delta(\\alpha_1 \\ast \\ldots \\ast \\alpha_{2j}; a_q\\ (q))\\right| \\ll x \\log^{-A} x", block: true)]]

#text("whenever ")#mi("{N_1,\\ldots,N_{2j} \\in {\\mathcal D}}")#text(" and ")#mi("{\\alpha_1,\\ldots,\\alpha_{2j}}")#text(" are such that each ")#mi("{\\alpha_i}")#text(" takes the form ")#mi("{\\mu_{\\leq} \\psi_{N_i}}")#text(", ")#mi("{\\psi_{N_i}}")#text(", or ")#mi("{\\psi^{\\prime}_{N_i}}")#text(". In particular, from Lemmas ")#link(<tao-6244580a346acf5d814a>)[#text("9")]#text(", ")#link(<tao-0e982fbf2b80be4e1970>)[#text("(10)")]#text(" we observe the following facts for any ")#mi("{1 \\leq i \\leq 2j}")#text(" and ")#mi("{S \\subset \\{1,\\ldots,2j\\}}")#text(":")

#list(
[#text("(i) Each ")#mi("{\\alpha_i}")#text(" is a coefficient sequence at scale ")#mi("{N_i}")#text(". More generally the convolution ")#mi("{\\alpha_S}")#text(" of the ")#mi("{\\alpha_i}")#text(" for ")#mi("{i \\in S}")#text(" is a coefficient sequence at scale ")#mi("{\\prod_{i \\in S} N_i}")#text(".")],
[#text("(ii) If ")#mi("{N_i \\gg x^{1/K+\\epsilon}}")#text(" for some fixed ")#mi("{\\epsilon>0}")#text(", then ")#mi("{\\alpha_i}")#text(" is smooth.")],
[#text("(iii) If ")#mi("{N_i \\gg x^\\epsilon}")#text(" for some fixed ")#mi("{\\epsilon>0}")#text(", then ")#mi("{\\alpha_i}")#text(" obeys a Siegel-Walfisz theorem. More generally, ")#mi("{\\alpha_S}")#text(" obeys a Siegel-Walfisz theorem if ")#mi("{\\prod_{i \\in S} N_i \\gg x^\\epsilon}")#text(" for some fixed ")#mi("{\\epsilon>0}")#text(".")],
[#text("(iv) ")#mi("{x \\ll N_1 \\ldots N_{2j} \\ll x}")#text(".")]
)

#text("Now we can prove ")#link(<tao-729cd87c6329408e2bbf>)[#text("(27)")]#text(". We can write ")#mi("{x^{t_i} \\ll N_i \\ll x^{t_i}}")#text(" for ")#mi("{i=1,\\ldots,2j}")#text(", where the ")#mi("{t_i}")#text(" are non-negative reals that sum to ")#mi("{1}")#text(". We apply Lemma ")#link(<tao-fc6a3d0fff933962afcc>)[#text("5")]#text(" and conclude that the ")#mi("{t_i}")#text(" obey one of the three conclusions (Type 0), (Type I/II), (Type III) of that lemma. Furthermore, in the Type III case, an inspection of Lemma ")#link(<tao-09f5ffef28309853265c>)[#text("6")]#text(" reveals that we have an additional lower bound ")#mi("{t_i,t_j,t_k \\geq 2\\delta}")#text(" available, which in particular implies that ")#mi("{t_i,t_j,t_k \\geq \\frac{1}{K} + \\epsilon}")#text(" for some fixed ")#mi("{\\epsilon>0}")#text(" if ")#mi("{K}")#text(" is large enough (")#mi("{K=10}")#text(" will certainly do).")

#text("In the Type 0 case, we can write ")#mi("{\\alpha_1 \\ast \\ldots \\ast \\alpha_{2j}}")#text(" in a form in which Theorem ")#link(<tao-3b0a4462ca95718fae74>)[#text("15")]#text(" applies. Similarly, in the Type I/II case we can write ")#mi("{\\alpha_1 \\ast \\ldots \\ast \\alpha_{2j}}")#text(" in a form in which Theorem ")#link(<tao-840c81157f3688e42875>)[#text("16")]#text(" applies, and in the Type III case we can write ")#mi("{\\alpha_1 \\ast \\ldots \\ast \\alpha_{2j}}")#text(" in a form in which Theorem ")#link(<tao-9ce19620746a8f953f54>)[#text("17")]#text(" applies. Thus in all cases we can establish ")#link(<tao-729cd87c6329408e2bbf>)[#text("(27)")]#text(", and Theorem ")#link(<tao-14bbfb46cb710ab5cf47>)[#text("13")]#text(" follows.")

#heading(level: 1)[#text("Comments (64)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ff39422bba87564dc362dba86346d189c9f13ca60591c0da8772f2d6a73db39-476ea7aed1980e9919a56099f0ba871fd83e9da2e7284c64684097196a1c55a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Omar Aboura")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-233849")[#strong[#text("Omar Aboura")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("“…we land in Type I/II” should be Type III")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-233851")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("Terry, a couple of quick comments: first, I think the ")#mi("\\frac{1}{10}")#text(" term coming from Heath-Brown is a bit of a red herring and should be ignored; my impression is that Heath-Brown is a kind of cut off version of Linnik’s identity and that one should think conceptually in terms of the latter (see my earlier post on this). The only reason you can’t actually use Linnik is that the terms resulting form it do not obey the requisite ")#mi("\\tau(n)^{O(1)}")#text(" bounds.")

#text("Second, I convinced myself that the hard case is ")#mi("n = 4")#text(" and ")#mi("t_1 = \\frac{1}{16} + 3\\epsilon")#text(", ")#mi("t_2 = t_3 = t_4 = \\frac{5}{16} - \\epsilon")#text(", with ")#mi("\\epsilon")#text(" small. I thought that in this case you can either use Type III directly (in Zhang’s notation, with ")#mi("\\mu = t_1, \\nu_1 = \\nu_2 = \\nu_3 = t_2 = t_3 = t_4")#text(", or you use Type I by grouping the ")#mi("t_1, t_2")#text(" terms and the ")#mi("t_3, t_4")#text(" terms. Is there some other way to proceed?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-233853")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("It the statement of Theorem 4, it should be subscripts that are distinct, not the ")#mi("t")#text(" themselves. More roundly, there is a restriction ")#mi("MN_1\\le x_1")#text(" in (A4), which says something about how large the ")#mi("t")#text(" can be, namely ")#mi("\\sum_{u\\ge 4}t_u+t_1\\le 3/8+11\\omega/2+3\\delta/2")#text(" I think, assuming one orders the ")#mi("t")#text("-values decreasingly. This is stronger than the stated bound of 1/2 in your Theorem 4.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-233855")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("That condition is indeed stated in Zhang’s paper, but I think it is not actually used in the Type III argument, it is just what comes out of the combinatorial analysis (represented here by Lemma 6). In particular, the quantity ")#mi("11\\varpi/2 + 3\\delta/2")#text(" is associated to the Type I analysis rather than the Type III analysis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-233856")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("There is also the issue that, in Zhang’s notation, only ")#mi("\\nu")#text(" can go into a Type III convolution, as it involves just the characteristic function ")#mi("\\chi")#text(" while the ")#mi("\\mu")#text(" involve the Mobius function. I am not sure how this is portrayed in your ")#mi("t")#text("-values, perhaps it falls out somewhere.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-233859")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("Yes, this is the “K” issue mentioned at the bottom of the post. As Ben says, one should morally be using the Linnik decomposition in which there are no Mobius factors present (this corresponds to setting ")#mi("K=\\infty")#text("). But the Linnik decomposition has an unbounded number of terms and is not directly available, so we use the Heath-Brown decomposition at some level K (Zhang takes ")#mi("K=10")#text(") instead. As such, any factor ")#mi("t_i")#text(" that is less than or equal to ")#mi("1/K")#text(" could potentially be coming from a Mobius factor ")#mi("\\mu")#text(" rather than a (piecewise) smooth factor ")#mi("\\chi")#text(". But in practice the ")#mi("t_i")#text(" in the Type III analysis will be larger than ")#mi("1/K")#text(" if we set ")#mi("K")#text(" large enough (basically because of the lower bound ")#mi("t_i > 2\\sigma")#text(" in Lemma 6) so this is not an issue.")

#text("I plan to expand this post shortly with the formal number-theoretic versions of the above statements (rather than just the oversimplified combinatorial cartoon) which will mention these various technicalities.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-233858")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("I’ve thought of negating the Conclusion of the Subset sum lemma. It would start: There exist non-negative reals ")#mi("t_1, \\ldots, t_n")#text(" such that ")#mi("t_1 + \\ldots + t_n = 1")#text(" such that none of the following statements hold , etc. If we are given the ")#mi("t_i")#text(", it seems to me that a straightforward simple computation will show whether or not any of the three statements hold. In particular, for the statement of Type I/II, one only needs to look at ")#mi("sigma")#text(" as large as possible while still satisfying the inequality ")#mi("11\\varpi + 3\\delta + 2\\sigma < \\frac{1}{4}.")#text(" That's why I think that \"ruling-out\" candidate pairs ")#mi("(\\varpi, \\delta)")#text(" from the Conclusion of the Subset sum lemma could be easy, given the right choice of ")#mi("t_1, \\ldots, t_n.")#text(" The second observation is as follows: Let ")#mi("0<c 0")#text(" satisfy the conclusion of the Subset sum lemma, so does ")#mi("c\\varpi , c\\delta")#text(". I was thinking of the case ")#mi("n=10")#text(", and I’m curious if ")#mi("n=8")#text(" might give better bounds. David Bernier")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/867b13eef834d30ec4974f653945580ce5e6a7c0054ed0d97ac0cd8e98dbc50e-9b9c55644ae699ca8e22608d10e4e812333e5aac279bbad1521b065b79a29a6f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavfer")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-233861")[#strong[#text("pavfer")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("Hmm, funny,")#linebreak()#text(" So,")#linebreak()#text(" in each election, in which all voted, there is")#linebreak()#text(" either")#linebreak()#text(" one party with 55% or more,")#linebreak()#text(" or")#linebreak()#text(" all parties groupable into two coalitions, each between 45% and 55%,")#linebreak()#text(" or")#linebreak()#text(" at least three possible 2-party coalitions with 55% or more,")#linebreak()#text(" with both coalition partners “non-marginal” and “not-almost-winning”.")

#text("Nice :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-233874")[#strong[#text("Polymath8: Bounded Gaps Between Primes | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")]

#text("[…] proof and improving the upper bound for the gaps. Here are links for three posts (I, II, III) on Terry Tao’s blog and for a post on the polymath blog. And here is the table for the world […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52066431741be7a2710c57cdebb34d7f30c01912795e2e5499720e082e7ebd13-55330c6aba478c921feeed0383b3410ba0c7e4aec7e1a3128f73d4790d4c463a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qianghua")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-233875")[#strong[#text("qianghua")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("“Mor precisely” should be More precisely.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-233878")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("I do realise that you are trying to simplify the picture, but there is some subtlety in why ")#mi("N_3")#text(" in Zhang is the smallest (not the largest, as might be suggested by selecting ")#mi("t_k")#text(" the biggest in your Theorem 4).")

#text("The point is that Zhang dispenses (via 1-variable Kloos bound) the small ")#mi("d_1")#text(" in 13.10-13.11 via a bound with ")#mi("N_3")#text(" in it. This is then used later in comparison to ")#mi("H=d_1/N_1")#text(" in the middle of page 47 (namely that ")#mi("H^2=o(d_1)")#text("). I don’t know how much of this is mandatory, the arguments could be arranged, and as I pointed out a few days ago, Zhang could also use the Deligne 2-variable bound (treating ")#mi("H")#text(" trivially) on 13.7 to handle smaller ")#mi("d")#text(", see the remark of FI upon their Theorem 4.")

#text("It might be that taking ")#mi("N_3")#text(" the smallest simply means that Zhang can work uniformly, w/o worrying about side issues of the variable ranges.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-233883")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("I mean selecting ")#mi("t_i")#text(", in the last line of your Theorem 4. In the previous line, you do indeed put the inequalities correct.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-233884")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("Let me try to explain my thought, over again. If you look at the bottom line of Theorem 4, you would want to take ")#mi("t_i")#text(" (with the 5 factor) as the largest. But the previous line in Theorem 4 prohibits this. However, does Zhang’s methodology in these parts (S13&14) really require one to take ")#mi("t_i\\le t_j\\le t_k")#text(", and if not, to what extent can it be modified? Though, perhaps the “critical” case near 5/16 could dominate the analysis anyway.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-233905")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("I’ve now expanded the post significantly to give the number-theoretic details of how Zhang deduces his distribution theorem on the von Mangoldt function from the Type I/II and Type III estimates. (This was primarily achieved by cannibalising part of an enormous post I was writing for all of Zhang’s Theorem 2, before I decided to break it up into more manageable pieces.) The material here can basically be viewed as an exposition of Section 6 of Zhang.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-233925")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("Note: the use of intervals of type [x,x(1+L^{-A})^m] is completely standard in this game (it’s already done in Fouvry-Iwaniec or even Fouvry’s “Autour du théorème de Bombieri-Vinogradov”, which is a bit earlier, and I’m sure it was not new then.)")

#emph[#text("[Article updated to reflect this reference, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/adaf83934ef9e83041fdd0b5ad16e455b02b1c2e6eb01568a16f9884d8d5f8fd-4cb33d494f6365ff4f85492980c809be6fde69086d5ddfee0bef924d0a084420.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-233941")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("(Along the lines of what Ben Green suggested.) If we’re not in type 0 or I/II in the proof of Lemma 6, then the three largest, ")#mi("t_i")#text(" are in ")#mi("[2\\sigma, 1/2-\\sigma]")#text("; call them ")#mi("t_1\\ge t_2\\ge t_3")#text(", and let ")#mi("R")#text(" denote the sum of the rest of the ")#mi("t_i")#text(". We could do better than bounding ")#mi("t_i+t_j\\ge (1/2+\\sigma)")#text(" for all three pairs if ")#mi("t_3")#text(" is somewhat smaller than ")#mi("t_1,t_2")#text(". That is, if ")#mi("t_3\\le(1-R-\\alpha)/3")#text(" for some ")#mi("\\alpha\\ge 0")#text(", we can pick ")#mi("\\sigma")#text(" to ensure Type III of lemma 5 as long as ")#mi("60\\varpi+13\\delta\\le\\alpha")#text(". If this is not the case, and if ")#mi("R")#text(" is small enough (smaller than ")#mi("(1-\\beta-\\alpha)/13")#text(" for some positive ")#mi("\\beta")#text(") then we can again conclude Type III of lemma 5 if ")#mi("48\\varpi+3\\delta\\le\\beta")#text(" (using the relation ")#mi("4t_1+4t_2+5t_3=4(1-R)+t_3")#text("). This leaves the case that ")#mi("R")#text(" is too large. But then we could pick ")#mi("\\alpha,\\beta")#text(" small enough that this puts one of the terms in ")#mi("(1/2-\\sigma,1/2+\\sigma)")#text(", i.e. Type I/II, which we already excluded.")

#text("Unfortunately, fiddling with this has not yielded improvement around the special point ")#mi("(\\varpi,\\delta)")#text(" you mention (but does seem to increase the feasible region for ")#mi("(\\varpi,\\delta)")#text(" in the region ")#mi("\\delta>>\\varpi")#text("). Perhaps something along these lines could be made to work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e579fa60f06b2b355ef3edabbae6dec6d9e7a0eed71c6645929e8f327d820eed-ba4a4594e7b47094d4631d6c89616486cc2038fed96e37cd81c7d89edceb3a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-233943")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("I have done the question as a linear programming exercise.")#linebreak()#text(" Let ")#mi("u_i=t_i-t_{i-1}")#text(" and ")#mi("u_{10}=t_{10}")#text(", where ")#mi("t_1\\geq t_2\\geq \\ldots \\geq t_{10}")#text(" The conditions I can glean from Lemma 5 are (treating ")#mi("\\delta")#text(" as fixed)")

#mi("u_1+2u_2+...+10u_{10}=1\\\\ -t_2-t_3+\\sigma\\leq-1/2\\\\ 5t_1+4t_2+4t_3-16\\varpi\\geq 4+\\delta\\\\ 11\\varpi/2+\\sigma\\leq1/8-3/2\\delta\\\\ \\varpi\\geq\\delta\\\\ \\sigma\\geq 1/10\\\\ t_1+\\sigma\\leq 1/2\\\\ t_3\\geq 2\\sigma")

#text("then I minimize ")#mi("\\varpi")#text(" as the ")#mi("u_i")#text(" change.")

#text("With the value of ")#mi("\\delta = 1/1000")#text(" I get ")#mi("\\varpi \\leq 1/234.0426")#text(",")#linebreak()#text(" but if I use ")#mi("4t_1 + 4t_2 + 5t_3")#text(" instead of get ")#mi("\\varpi \\leq 1/48.1444")

#text("I don’t have a connection between ")#mi("\\delta")#text(" and ")#mi("\\varpi")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e579fa60f06b2b355ef3edabbae6dec6d9e7a0eed71c6645929e8f327d820eed-ba4a4594e7b47094d4631d6c89616486cc2038fed96e37cd81c7d89edceb3a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-233946")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("I just got ")#mi("3\\delta+11\\varpi\\leq 1/20")#text(" – that is, just let ")#mi("\\sigma=1/10")#linebreak()#text(" What have I missed?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234012")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("Dear Michael,")

#text("I think the main issue is that the negation of the Type I/II case is actually rather complicated; in principle there are as many as ")#mi("2^{10}")#text(" different constraints coming out of this negation, due to all the possible ways to form the subset S. In practice many of these cases are redundant and can be ignored, but it is not immediately obvious that one can discard all but a handful of them as you seem to be doing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e579fa60f06b2b355ef3edabbae6dec6d9e7a0eed71c6645929e8f327d820eed-ba4a4594e7b47094d4631d6c89616486cc2038fed96e37cd81c7d89edceb3a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234064")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("The order of the coordinates doesn’t matter, so I assume ")#mi("t_1\\geq t_2\\geq ... t_{10}")#text(".")

#text("You showed that, if it isn’t Type 0 or i/ii, there are exactly three powerful coordinates, any one of which is between ")#mi("2\\sigma")#text(" and ")#mi("1/2-\\sigma")#text(". This is covered by ")#mi("t_3\\geq 2\\sigma")#text(" and")#linebreak()#text(" ")#mi("t_1 \\leq 1-\\sigma")#text(". Any two of the powerful coordinates is more than ")#mi("1/2+\\sigma")#text(", and that is covered by")#linebreak()#text(" ")#mi("t_2+t+3\\geq 1/2+\\sigma")#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-233956")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("Condition (2) in Lemma 5 is optimal, at least for ")#mi("11\\varpi+3\\delta\\leq\\frac{1}{4}")#text(" which is implicit in the Type I/II condition. More precisely, when ")#mi("207\\varpi+43\\delta\\geq\\frac{1}{4}")#text(", we have the counterexample ")#mi("t_1=\\frac{1}{4}-\\frac{3\\sigma}{2}")#text(", ")#mi("t_2=t_3=t_4=\\frac{1}{4}+\\frac{\\sigma}{2}")#text(", where ")#mi("\\sigma:=\\frac{1}{8}-\\frac{11\\varpi}{2}-\\frac{3\\delta}{2}")#text(". In other words, if we want a better condition than (2), then we have to improve the existing bounds for ")#mi("n=4")#text(". (This response was inspired by Ben’s comment above.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d63d41c9cf4d921d6ceef87c9b8d0d1f57254f648e0c2e785efad352a850e419-3771e98838d83e6eca535b731538af957220cec5537ec9d1f017f45ad85aca5d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dustin G. Mixon")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-233984")[#strong[#text("Dustin G. Mixon")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("To get strict inequality in ")#mi("11\\varpi+3\\delta+2\\sigma<\\frac{1}{4}")#text(", you actually want ")#mi("\\sigma<\\frac{1}{8}-\\frac{11\\varpi}{2}-\\frac{3\\delta}{2}")#text(", but your counterexample is good. Is the implicit requirement that ")#mi("11\\varpi+3\\delta<\\frac{1}{4}")#text(" a fundamental limit in Zhang's technique, or can this be weakened as well?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234035")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("My ")#mi("\\sigma")#text(" is not the same as ")#mi("\\sigma")#text(" in Lemma 5. My ")#mi("\\sigma")#text(" (perhaps I should have called it ")#mi("\\sigma_0")#text(") is a convenient variable for defining the counterexample, and the example is ok (you can check by hand that it is neither of the three types in Lemma 5). About Zhang’s technique: the condition in Lemma 5 is a certain natural limit, as shown by my example, but hopefully this limit is not a fundamental one.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234015")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("Ah well, so no cheap numerical pickup here :). Still, at least we now know what the enemy is. Plugging in the explicit numerical values (ignoring infinitesimals)")

#mi("\\varpi = 1/899 \\approx 0.00111")

#mi("\\delta = 71/154628 \\approx 0.000460")

#text("which are our current optimal values we have")

#mi("\\sigma = 4569/38657 \\approx 0.118193")

#mi("t_1 = 11243/154628 \\approx 0.072710")

#mi("t_2=t_3=t_4 = 47795/154628 \\approx 0.309097")#text(".")

#text("The Type I/II analysis lets one win when any partial sum lies between ")#mi("1/2-\\sigma = 29519/77314 \\approx 0.381807")#text(" and ")#mi("1/2+\\sigma = 47795/77314 \\approx 0.618193")#text(", which at this endpoint case are also the values of ")#mi("t_1+t_2=t_1+t_3=t_1+t_4")#text(" and ")#mi("t_2+t_3=t_2+t_4=t_1+t_4")#text(" respectively. On the number theory side, this case corresponds to the component of ")#mi("\\Lambda")#text(" that takes the form")

#mi("\\psi_1 \\ast \\psi_2 \\ast \\psi_3 \\ast \\psi_4")

#text("where ")#mi("\\psi_i")#text(" is smooth and at scale ")#mi("x^{t_i}")#text(" for ")#mi("i=1,2,3,4")#text(". I was hoping that maybe the smoothness of the first factor ")#mi("\\psi_1")#text(" (called ")#mi("\\alpha")#text(" in the Type III analysis) could be exploitable, but then I realised that one could make the above counterexample more complicated by splitting the ")#mi("t_1")#text(" term up arbitrarily into many small pieces and so one does not necessarily get to assume ")#mi("\\alpha")#text(" is smooth in the critical case.")

#text("Still, at least we have some explicit numerical values to work with when we try to improve either the Type I/II or Type III analysis: specifically, one needs to get some power gain in Theorem 16 with ")#mi("M \\approx x^{0.381807}")#text(" and ")#mi("N \\approx x^{0.618193}")#text(", or Theorem 17 with ")#mi("M \\approx x^{0.072710}")#text(" and ")#mi("N_1=N_2=N_3 \\approx x^{0.309097}")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-233967")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("In the definition of ")#emph[#text("singleton congruence class system")]#text(", which goes with Definition 11, I think the sentence should begin with: “If ")#tao-math("\\left|C(p)\\right|=1", block: false)#text(" for all primes ")#mi("p \\in I")#text(" , […]” . David Bernier")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d63d41c9cf4d921d6ceef87c9b8d0d1f57254f648e0c2e785efad352a850e419-3771e98838d83e6eca535b731538af957220cec5537ec9d1f017f45ad85aca5d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dustin G. Mixon")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-233968")[#strong[#text("Dustin G. Mixon")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("Sometimes you write (22) when I think you mean (2).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234028")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("In fact, it is possible (for each given n) to replace (2) by finding explicitly the EXACT necessary and sufficient conditions on ")#mi("\\varpi")#text(" and")#linebreak()#text(" ")#mi("\\delta")#text(" such that lemma 5 holds. (It may happen, however, that for very small values of n, the admissible set for ")#mi("(\\varpi , \\delta)")#text(" defined by the necessary and sufficient conditions is empty, but as we already know for sufficiently large n it is nonempty.) A systematic way of doing this is as follows:")

#text("1. To find the COMPLEMENT of the above admissible set, containing exactly the pairs ")#mi("\\varpi , \\delta")#text(" for which the conclusion of lemma 5 does not hold (i.e. there is a non-negative non-decreasing sequence")#linebreak()#text(" ")#mi("t_1,...,t_n")#text(" with sum 1, which does NOT belong to any type.)")

#text("Note that for type (0 ) there are n conditions, negating the lemma condition for each ")#mi("t_i")#text(" , for type (I / II) there are ")#mi("n(n-1)/2")#text(" conditions (negating the lemma conditions for each partition), along with the existence of some ")#mi("/sigma")#text(" satisfying its lemma conditions, and for type (III) there are ")#mi("n(n-1)(n-2)/6")#text(" conditions (one for each triple")#linebreak()#text(" ")#mi("(t_i, t_j, t_k)")#text(" such that $t_i < t_j < t_k < 1/2$ and negating the last inequality in lemma 5 for this triple.)")

#text("2. Use any method of quantifier elimination (see e.g. chapter 14 in \"algorithms in real algebraic geometry\" by S. Basu, R. Pollack and M-F Roy, Springer -Verlag, 2003.) to get the desired necessary and sufficient conditions for the complement of the above admissible set for the pairs ")#mi("(\\varpi , \\delta)")#text(".")

#text("Remark: In general such (symbolic) quantifier elimination are used for general systems of polynomial inequalities, but in our case of systems of linear inequalities I think that the computational complexity should be manageable – the resulting admissible set should be a finite union of certain polygons. As I know, there should be several software implementations of quantifier elimination algorithms.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234037")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("Dear Terry, perhaps it would be useful to emphasize in the post that (2) is optimal for Lemma 6, so that others don’t try to improve it. On the other front, I try to catch up with Zhang’s paper.")

#text("Some other small suggestions:")

#text("1. In the proof of Lemma 5 it would be useful to emphasize (for the sake of the reader) that a powerful summand is not only able to convert a small sum to a large sum, but it can do this for a small sum with powerful summands only (as powerless summands can be omitted).")

#text("2. In the sentence “We then apply Lemma 5” and the next one, the numbers 5 and 6 should be flipped.")

#emph[#text("[Corrections and suggestions implemented, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234046")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("Is it possible that for larger n, (2) is not optimal for lemma 5?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d63d41c9cf4d921d6ceef87c9b8d0d1f57254f648e0c2e785efad352a850e419-3771e98838d83e6eca535b731538af957220cec5537ec9d1f017f45ad85aca5d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dustin G. Mixon")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234063")[#strong[#text("Dustin G. Mixon")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("No – Use the same counterexample, except take the ")#mi("n-4")#text(" other ")#mi("t_i")#text("‘s to be zero.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234076")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("In fact, your suggestion is the same counter example with ")#mi("n = 4")#text(" since the other ")#mi("n - 4")#text(" parameters can be ignored!")#linebreak()#text(" But your example can be modified to have the remaining parameters equal to a sufficiently small number to still get a non-degenerate counter example!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Estimation of the Type I and Type II sums | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234212")[#strong[#text("Estimation of the Type I and Type II sums | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("[…] seminar of Zhang’s paper for the polymath8 project. (There are two other continuations; this previous post, which deals with the combinatorial aspects of the second part of Zhang’s paper, and a post […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234293")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("I have an idea which may be able to largely eliminate the role of ")#mi("\\delta")#text(" in Zhang’s analysis. The main reason that we can’t take ")#mi("\\delta")#text(" to be too large is because of the following inefficiency: when we want to factor a ")#mi("x^\\delta")#text("-smooth number ")#mi("d \\sim D")#text(" into two factors ")#mi("d=qr")#text(" with ")#mi("q,r")#text(" chose to some preselected ")#mi("Q,R")#text(" with ")#mi("QR \\sim D")#text(", we can’t quite hit our targets ")#mi("Q,R")#text(" with perfect accuracy, and must instead settle for loose bounds like")

#mi("x^{-\\delta} R \\leq r \\leq R")#text(". (*)")

#text("This gap of ")#mi("x^\\delta")#text(" between where we would like our parameters to be, and where they eventually end up, leads to most of the dependencies on the ")#mi("\\delta")#text(" parameter in Zhang’s theorem ")#mi("MPZ[\\varpi,\\delta]")#text(". (There are a couple places where ")#mi("\\delta")#text(" needs to be small relative to other quantities, but these conditions on ")#mi("\\delta")#text(" are very mild compared to the main effect of ")#mi("\\delta")#text(" on the conditions for ")#mi("MPZ[\\varpi,\\delta]")#text(".)")

#text("Now, if all we know about ")#mi("d")#text(" is that it is ")#mi("x^\\delta")#text("-smooth, then we can’t do much better than (*), at least when ")#mi("D, Q, R")#text(" are close to integer powers of ")#mi("x^\\delta")#text(", since ")#mi("n")#text(" could simply be the product of primes that are close to ")#mi("x^\\delta")#text(". (One could eke out an incredibly tiny improvement to (*) in the case that ")#mi("D,Q,R")#text(" are not integer powers of ")#mi("\\delta")#text(", but this is not the direction I am pursuing here.)")

#text("On the other hand, if we return to the sieve theory side of things, most of the moduli n for which we actually want an Elliott-Halberstam estimate are not of the form “product of primes that are close to ")#mi("x^\\delta")#text("” – most of them also contain a bunch of prime factors that are significantly less than ")#mi("x^\\delta")#text(". I have to do the sieve calculations carefully, but there is a chance that one could show that “most” of the moduli d in the sieve have enough prime factors that their factors are spread much more densely between 1 and d (as measured in log-scale) than (*) suggests, and that one should in fact be able to find a factor r that is basically within ")#mi("x^{o(1)}")#text(" of ")#mi("R")#text(" rather than within ")#mi("x^\\delta")#text(". If so, this should largely eliminate the influence that ")#mi("\\delta")#text(" has on the Type I and Type II sums (so long as it is reasonably small, say 1/100 or so, as opposed to the current level of 1/2000 or so). (Amusingly, one may need to use some inverse Littlewood-Offord theory to make this intuition precise, which is something that I happen to be quite familiar with.)")

#text("This is all contingent though on checking that “most” moduli in the sieve have this desired property (in the sense that the contribution of the exceptional moduli is small). Will think about this…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234301")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("My impression would be that the ")#mi("d")#text(" which are “bad” in this sense are a positive proportion in the contribution, but it would be like the Dickman function at ")#mi("4/\\omega")#text(" or something, so quite quite small. But this is just a guess.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234304")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("If I parse Ford’s paper correctly: ")#link("http://annals.math.princeton.edu/wp-content/uploads/annals-v168-n2-p01.pdf")[#text("http://annals.math.princeton.edu/wp-content/uploads/annals-v168-n2-p01.pdf")]

#text("His theorem p371 states that the proportion of numbers with a factor in [y,z] looks like ")#mi("u^\\delta(log 2/u)^{-3/2}")#text(" where ")#mi("z=y^{1+u}")#text(" and ")#mi("\\delta=1-{1+\\log\\log 2\\over \\log 2}\\approx 0.086071")#text(". For ")#mi("u=1/1000")#text(" say, this is 2.7%, so most numbers don’t have a factor in such a range.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234308")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("Terry, I think you’re quite likely to be right about this. The calculation does need to be done *inside* the sieve, though, because there are “many” ")#mi("d")#text(" in ")#mi("[X,2X]")#text(" with all prime factors pretty near ")#mi("X^{\\delta}")#text(", where “many” means at least ")#mi("X/(\\log X)^{1/\\delta}")#text(" or so. And the sieve weights may more than cancel that denominator of a power of ")#mi("\\log")#text(". But certainly the prime factors of a typical ")#mi("d")#text(", even a typical smooth one, are going to be quite spread out and hence arrangeable to be more-or-less whatever size one wants. One could even get interdisciplinary about this and cite this play:")

#link("https://www.msri.org/general_events/19160")[#text("https://www.msri.org/general_events/19160")]

#text("or, more seriously")

#link("http://www.dms.umontreal.ca/~andrew/PDF/Anatomy.pdf‎")[#text("http://www.dms.umontreal.ca/~andrew/PDF/Anatomy.pdf‎")]

#text("In fact it seems to me that we don’t really care about being ")#mi("X^{\\delta}")#text("-smooth at all. The key property is that if ")#mi("S = \\{ \\frac{\\log p}{\\log X} : p | d\\}")#text(" then the set of subset sums of ")#mi("S")#text(" is ")#mi("\\delta")#text("-dense: this is what lets you arrange factorisations of any desired size (within ")#mi("\\delta")#text("). We could even redefine ")#mi("\\delta")#text(" to be this parameter, couldn’t we? It’s obviously less than or equal to the old ")#mi("\\delta")#text(". And, now you are talking about ruling out sets whose subset sums are strangely distributed, I see why inverse Littlewood-Offord comes into the game. Nice observation!")

#text("I suppose one really (for the moment) only cares about being able to arrange factorisations nicely in the vicinity of the important threshold at the Type I/III border; this may give some extra saving.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234329")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("“But certainly the prime factors of a typical d, even a typical smooth one, are going to be quite spread out and hence arrangeable to be more-or-less whatever size one wants.”")

#text("For a typical ")#mi("d")#text(" isn’t the ")#mi("r")#text("th prime factor typically like ")#mi("e^{e^r}")#text(", which doesn’t allow one that much wiggle room, if you want to force divisors where you want? You may typically have two divisors within a factor or two of each other, but that doesn’t mean that you can force a divisor to be in (too short) an interval wherever you want. If I read the above quoted theorem of Ford (following Tenenbaum) correctly, the percentage of numbers with a factor in a specific power-range like ")#mi("[y,y^{1.001}]")#text(" is quite small (2.7%). Of course we have the smoothness hypothesis, but I don’t know whether this will be a panacea (it will allow us to reduce ")#mi("\\delta")#text(", but not to an infinitesimal, or irrevelancy). Just my opinion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72ea9506a8fb064ca33e1274316b9c84a40688ea23862e524fb0e6f7c49e439d-de04381cb4b04ef82414d1c9f13abb48fa2449415656dd437c3d5867c9ce47c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234334")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("I take your point. But it should certainly allow one to reduce ")#mi("\\delta")#text(" (or, rather, perhaps we should change the definition of ")#mi("\\delta")#text(").")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234376")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("Thanks for all the feedback! The issue is a bit more subtle than I had expected: even after restricting to ")#mi("x^\\delta")#text("-smooth numbers, the proportion of numbers which fail to be, say, ")#mi("x^{\\delta/2}")#text("-divisor-dense (i.e. their set of divisors manages to miss an interval of the form ")#mi("[x^{-\\delta/2} R, R]")#text(" for some medium-sized ")#mi("R")#text(") does have a very small but positive density. But because the Selberg sieve ")#mi("\\nu(n) = (\\sum_{d|n} \\mu(d) a_d)^2")#text(" has a lot of cancellation in it (as evidenced by the Mobius function factor), “very small density” does not automatically translate to “negligible for the purposes of sieve theory” – a naive attempt to estimate the error by taking absolute values everywhere sets one back a few factors of a logarithm (if one uses the GPY sieve, one in fact loses the horrific amount of ")#mi("\\log^{k_0} x")#text(", but I am hoping with the elementary Selberg sieve one only loses something like ")#mi("\\log x")#text(" or ")#mi("\\log^2 x")#text(", which is too large to be absorbed by a smallness of density but it makes it more plausible that one could exploit the cancellation of the Mobius function to control things).")

#text("Of course, one does not necessarily need to compare a new sieve with an old sieve to show that the new sieve is effective – one might be able to compute all the relevant sieve asymptotics for a GPY sieve restricted to “dense-divisor” numbers directly. One thing that works in our favor here is that the property of having a dense set of divisors is sort of multiplicative: if q and r have dense sets of divisors, then qr does as well. But one may have to select the precise definition of having “dense divisors” carefully; as I said before, there is a lot of cancellation going on in the sieve calculations and one cannot afford to disrupt that.")

#text("It seems that if one is willing to just halve the influence of ")#mi("\\delta")#text(" rather than eliminate it entirely (roughly speaking, this would replace the condition ")#mi("207 \\varpi + 43\\delta < 1/4")#text(" by ")#mi("207 \\varpi + 43 \\delta/2 < 1/4")#text(", at least in principle) then one can get a fair amount of control on the exceptional ")#mi("x^\\delta")#text("-smooth numbers ")#mi("q")#text(" that avoid having any divisor in ")#mi("[x^{-\\delta/2} R, R]")#text(", basically by a modification of the combinatorial arguments that happen to be in the main post here. Indeed, call a factor of ")#mi("q")#text(" \"small\" if it is less than ")#mi("x^{-\\delta/2} R")#text(" and \"large\" if it is larger than ")#mi("R")#text(". Call a prime dividing ")#mi("q")#text(" \"powerless\" if it cannot turn a small factor into a large factor and \"powerful\" otherwise; in particular, powerful primes lie between ")#mi("x^{\\delta/2}")#text(" and ")#mi("x^\\delta")#text(". Now look at the minimal large factor of ")#mi("q")#text(", it has to consist entirely of powerful primes as we can strike out all the powerless primes without making the factor small. Furthermore, if one orders the powerful primes as ")#mi("p_1 < \\ldots < p_k")#text(", then the minimal large factor has to consist of an initial segment ")#mi("p_1 \\ldots p_i")#text(" since otherwise one could swap one powerful prime by a smaller one which reduces the product by at most ")#mi("x^{\\delta/2}")#text(" and thus cannot make the product small. Thus every product of i or more powerful primes is large, and every product of i-1 or less primes is small (otherwise the above arguments would also show that ")#mi("p_1 \\ldots p_{i-1}")#text(" is large, contradicting minimality of ")#mi("p_1,\\ldots,p_i")#text("). Thus (roughly speaking) all the powerful primes lie between ")#mi("R^{1/i}")#text(" and ")#mi("(x^{-\\delta} R)^{1/(i-1)}")#text(", which in practice is quite a narrow band. Also all the powerless primes when multiplied together cannot exceed ")#mi("x^{\\delta/2}")#text(" (since otherwise no prime less than ")#mi("x^\\delta")#text(" could be powerful enough to bridge the gap ")#mi("[x^{-\\delta/2} R, R]")#text(" once the effect of the powerless primes are factored in). This is quite a special configuration (the density of such numbers inside the ")#mi("x^\\delta")#text("-smooth numbers appears to be something like ")#mi("\\exp(-1/\\delta)")#text(" from a back-of-the-envelope calculation). Of course as I said before this doesn't immediately allow one to declare victory due to the cancellation in the sieve but it is a promising sign.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234418")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("I guess my concern was: the ")#mi("\\{{\\log p\\over\\log X}\\}")#text(" for an “average” d are like ")#mi("\\{{e-1\\over e^k}\\}_{k=1}^\\infty")#text(" (this is a very vague statement, the geometric series should be ")#mi("1/e")#text(" to some extent, and I made it add up to 1). So that is more sparse than powers of 2, and you cover little with subset sums. But if you are pre-assuming that numbers have no large prime factors, say more than ")#mi("X^{1/1000}")#text(", then I don’t know, but would guess that the above set is looking more like ")#mi("\\frac{e^{k/1000}-1}{e^{k/1000}}")#text(" typically, which looks much denser in its subset sums.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234437")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("Actually it should be ")#mi("e^{1/1000}-1")#text(" in the numerator, which is about the ")#mi("{1\\over 1000}")#text(" which is an upper bound of ")#mi("\\{{\\log p\\over\\log X}\\}")#text(" with these smooths.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234439")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("For some reason, the link to Anatomy.pdf by Granville, when clicked, yields “gibberish”. But searching/googling for: The Anatomy of Integers and Permutations Andrew Granville should work …")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a91dbbd5705f8085aa4b368877768575736327e83b5112c35d161fc17b40dd-f68febc147b1909b1d766de009db17c4fcd3eef72ebe543fc408a7b0c9d6ad8b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andrescaicedo")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234443")[#strong[#text("andrescaicedo")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("There is a small typo (some extra spaces), just remove %E2%80%8E")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Estimation of the Type III sums | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234519")[#strong[#text("Estimation of the Type III sums | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("[…] seminar of Zhang’s paper for the polymath8 project. (There are two other continuations; this previous post, which deals with the combinatorial aspects of the second part of Zhang’s paper, and this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-235023")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("A quick note: Janos Pintz has kindly sent me some handwritten notes (with permission to share them with this project) in which he has (somewhat independently of our own discussion) worked out a way to implement the idea mentioned in comments above of relaxing the condition that the modulus ")#mi("d")#text(" be ")#mi("x^\\delta")#text("-smooth. Basically, the idea is to restrict instead to the wider class of squarefree moduli ")#mi("d")#text(" which are ")#mi("x^{C\\delta}")#text("-smooth for some large C and also obey the property")

#mi("\\prod_{p|d: p < x^\\delta} p \\geq x^{(C-1)\\delta}")

#text("since the greedy algorithm then shows that such a ")#mi("d")#text(" will contain a factor ")#mi("r")#text(" between ")#mi("x^{-\\delta} R")#text(" and ")#mi("R")#text(" for any ")#mi("1 \\leq R \\leq d")#text(". His notes show that the truncation error in the the elementary Selberg sieve (discussed back in ")#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/")[#text("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/")]#text(" , and is a little different from the analytic Selberg sieve which we are currently using) caused by restricting to such numbers is negligible; I’ll try to write up a blog post on this shortly.")

#text("In practice the effect of this will come close to the ideal of being able to ignore delta completely (e.g. the condition ")#mi("87 \\varpi + 17\\delta < 1/4")#text(" morally becomes ")#mi("87 \\varpi < 1/4")#text(").")

#text("With this and the improvement on Type III sums that Michel has just announced at ")#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-235003")[#text("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-235003")]#text(" , it looks like we will have some more progress on these bounds in a few days…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-235048")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("i don’t see any announcement in the last link…")

#emph[#text("[Link corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A truncated elementary Selberg sieve of Pintz | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-235110")[#strong[#text("A truncated elementary Selberg sieve of Pintz | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("[…] a more general systetm of congruence classes obeying a certain controlled multiplicity axiom; see this post. Secondly, and more importantly for this post, the requirement that the modulus lies in can be […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08be7e2ca4ef5a0df94d8b768e99c69a3684b45448137112061fec7825372377-ee7e474ba2a4dd83473477a0c11a980e946a0317cce3a642270544b2615ae672.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-235581")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2013")])]

#text("In (18), I think that the ")#mi("n")#text(" on the RHS of the formula should be an ")#mi("x")#text(" (as ")#mi("n")#text(" is the summation variable).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The distribution of primes in densely divisible moduli | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-235919")[#strong[#text("The distribution of primes in densely divisible moduli | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("[…] improves upon previous constraints of (see this blog comment) and (see Theorem 13 of this previous post), albeit for instead of . Inserting Theorem 4 into the Pintz sieve from this previous post gives […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-236207")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("Three comments and some typos:")

#text("1. Before (27) you say there are ")#mi("O(\\log^{2jA_0} x)")#text(" summands. I think the number is a bit larger, namely ")#mi("O(\\log^{2j(A_0+1)} x)")#text(". This is because there are about ")#mi("\\log^{A_0} x")#text(" elements of ")#mi("\\mathcal{D}")#text(" in every dyadic range, hence about ")#mi("\\log^{A_0+1} x")#text(" elements in ")#mi("[1,x]")#text(".")

#text("2. In the proof of (iv) in Lemma 9, there is no need to introduce ")#mi("C>0")#text(" and proceed by Cauchy-Schwarz (in fact I had difficulty following the original argument). By (13) and the first display in this part of the proof, we have directly")

#tao-math("\\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(\\alpha \\ast \\beta; a\\ (q))\\right| \\ll (N \\log^{O(1)} x)\\sup_{c \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(\\beta; c\\ (q))\\right|", block: false)#text(",")

#text("so that, using the assumption on ")#mi("\\beta")#text(",")

#tao-math("\\sum_{q<L}\\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(\\alpha \\ast \\beta; a\\ (q))\\right| \\ll NM \\log^{-A+O(1)} x", block: false)#text(".")

#text("3. At the end of the proof of Lemma 12, there is no need to reduce to ")#mi("b\\ (r)")#text(" primitive, since (12) does not assume primitivity.")

#text("4a. In the proof of Lemma 9, third line, ")#mi("\\log^{O(1)}")#text(" should be ")#mi("\\log^{O(1)}x")#text(".")

#text("4b. In Section 3, ")#mi("\\mu_<")#text(" should be ")#mi("\\mu_\\leq")#text(".")

#text("4c. In Section 3, ")#mi("\\varphi: {\\bf R} \\rightarrow {\\bf R}")#text(" should be ")#mi("\\psi: {\\bf R} \\rightarrow {\\bf R}")#text(", and ")#mi("\\varphi^{(j)}(t)")#text(" should be ")#mi("\\psi^{(j)}(t)")#text(".")

#text("4d. ")#mi("\\psi(x/N)")#text(" should be ")#mi("\\psi(n/N)")#text(".")

#text("4e. In (21) and in the proof of Proposition 14, ")#mi("\\Delta(\\Lambda 1_{[x,2x]}; a)")#text(" should be ")#mi("\\Delta(\\Lambda 1_{[x,2x]}; a\\ (q))")#text(".")

#text("4f. In the proof of Theorem 15, Lemma 7 should be Lemma 9, and the link to it should be updated.")

#text("4g. In Theorem 17, \"any be a singleton\" should be \"for any singleton\".")

#emph[#text("[Corrected, thanks! – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bounded gaps between primes (Polymath8) – a progress report | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-236881")[#strong[#text("Bounded gaps between primes (Polymath8) – a progress report | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("[…] convolution. The precise identity is a little complicated (although not difficult to prove); see this post for details. Using this identity, we can indeed reduce (2) to slightly more complicated versions of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bf23ebe11fcbe0a61f64f59239b469fe4ee5076b883e15afea619b4b55ffb4b-054844e28292f70f825dd0fb4a8a6b451c1cdf5bd9a9f72293281da9ef6261fb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avi Levy")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-237088")[#strong[#text("Avi Levy")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2013")])]

#text("In the sentence before (26), there is a citation to an unidentified “Proposition”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The distribution of primes in doubly densely divisible moduli | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-237792")[#strong[#text("The distribution of primes in doubly densely divisible moduli | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2013")])]

#text("[…] 4, 5, 6 will be given below the fold, while the proof of Lemma 7 follows from the arguments in this previous post. We remark that in our current arguments, the double dense divisibility is only fully used in the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An improved Type I estimate | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-239913")[#strong[#text("An improved Type I estimate | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2013")])]

#text("[…] Again, these conditions are implied by (8). The claim then follows from the Heath-Brown identity and dyadic decomposition as in this previous post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ffe89443b5bd903c46f0e36ab16b745fe9977f85cacf9fec586271c4ed2cea0b-ac4fdc455655250683cd6bc175d5a2b4626c30d38b6f18e26772587f5e3831e4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stijn Hanson")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-248273")[#strong[#text("Stijn Hanson")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2013")])]

#text("In Lemma 8 it proves equation (10) using a simple bound and then Proposition 5 from “The elementary Selberg sieve and bounded prime gaps” but that’s a proof of MPZ from EH and doesn’t appear to contain any sums of the required form (requiring either squarefree-ness or some coprimality condition on the summands). Is there some numbering/linking mix-up here or am I just not reading it properly?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-248275")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2013")])]

#text("Hmm, that is a numbering issue; one can use for instance Lemma 8 from the previous post. (These estimates can also be found in standard multiplicative number theory texts, e.g. Corollary 2.15 of Montgomery-Vaughan. A good rule of thumb regarding these sorts of estimates is that the number of divisors ")#mi("\\tau(n)")#text(" of a large number ")#mi("n")#text(" is typically of size ")#mi("\\log^{O(1)} n")#text("; this is closely related to the ")#link("http://en.wikipedia.org/wiki/Erd%C5%91s%E2%80%93Kac_theorem")[#text("Erdos-Kac theorem")]#text(", which is a precise version of the assertion that the number of prime factors of a number ")#mi("n")#text(" is typically of size ")#mi("\\log\\log n")#text(".)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cb3782087cf369e17975fc288dd1999d849b428e2925467bbf9b1fce02d9b08-01ef04b5ef1b58a71fbe0cc8f3b459639a6650f6e3bd441f92d2281551b7dd30.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stijn Hanson")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-270580")[#strong[#text("Stijn Hanson")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2014")])]

#text("Sorry, could you expand a little on how the “crude bounds” give the last displayed equation of Proposition 14?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-270587")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2014")])]

#text("One can bound ")#tao-math("\\left|\\Delta(\\Lambda 1_{[x,2x]}, a\\ (q))\\right|", block: false)#text(" by ")#mi("O( \\tau(q)^{O(1)} \\frac{x}{q} \\log^{O(1)} x )")#text(" and ")#tao-math("\\left|C(q)\\right|", block: false)#text(" by ")#mi("\\tau(q)^{O(1)}")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cb3782087cf369e17975fc288dd1999d849b428e2925467bbf9b1fce02d9b08-01ef04b5ef1b58a71fbe0cc8f3b459639a6650f6e3bd441f92d2281551b7dd30.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stijn Hanson")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-270773")[#strong[#text("Stijn Hanson")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("ok, I roughly see how those bounds help (presumably by using ")#mi("\\tau(q) \\ll o(n^{\\epsilon})")#text(" for all ")#mi("\\epsilon > 0")#text(" but how exactly do you get ")#tao-math("\\left|C(q)\\right| \\ll \\tau(q)^{O(1)}", block: false)#text("? I’m looking at the bounds in the definition and the closest asymptotic bound I can easily see is ")#tao-math("\\left|C(q)\\right| \\leq \\phi(q)", block: false)#text(". Sorry, I’m probably being really thick.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-270809")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("Use hypotheses (ii) and (iii) of Definition 11, rather than hypothesis (i). (iii) gives the case when q is prime, and (ii) then gives the general squarefree case as a consequence.")

#text("More generally, bounds on multiplicative functions should usually be proven by first considering the prime case (or the prime power case, if one is not restricted to squarefree numbers).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Derived multiplicative functions | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-419785")[#strong[#text("Derived multiplicative functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2014")])]

#text("[…] to , where and are arbitrary parameters and denotes the -fold convolution of , and discussed in this previous blog post; this is the top order component […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A conjectural local Fourier-uniformity of the Liouville function | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-462896")[#strong[#text("A conjectural local Fourier-uniformity of the Liouville function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2015")])]

#text("[…] (e.g. Vaughan’s identity or Heath-Brown’s identity), as discussed for instance in this previous post (which is focused more on the von Mangoldt function, but analogous identities exist for the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Correlations of the von Mangoldt and higher divisor functions I. Long shift ranges | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-483423")[#strong[#text("Correlations of the von Mangoldt and higher divisor functions I. Long shift ranges | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2017")])]

#text("[…] step, which is again standard, is the use of the Heath-Brown identity (as discussed for instance in this previous blog post) to split up into a number of components that have a Dirichlet convolution structure. Because the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/15339287d6a02da699407f22f5bfbed12a5f468ddbcee1932144f632e19068c7-c42d04ca0d6fbd31aa8b3824d1b8e15f9b4c8db2e473b4d9b16c99c6fcf59586.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Prashanth")]], [#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-638407")[#strong[#text("Prashanth")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2021")])]

#text("Prof. Tao,")#linebreak()#text(" I know this is a very old post, but I stumbled on to this when I was researching all the ways to interpret np-complete problems using number theoretical concepts. Can we somehow relate NP-complete version of the subset sum problem with bounded gaps between primes and generate an equivalence statement for p vs np ? Did you make any attempts in this regards or are you aware of similar attempts? I’m not asking whether we can settle p vs np this way, but can we relate these two fields even if the relation on the number theory side may not be something provable.")

#text("Thanks,")#linebreak()#text(" Prashanth")
]
