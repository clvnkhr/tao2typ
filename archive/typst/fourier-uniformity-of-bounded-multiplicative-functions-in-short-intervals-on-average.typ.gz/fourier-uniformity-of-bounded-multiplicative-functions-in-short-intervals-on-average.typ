// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/12/05/fourier-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/
// Converted to Typst by tao2typ: "2026-10-14T16:38:28.563026+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Fourier uniformity of bounded multiplicative functions in short intervals on average", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Fourier uniformity of bounded multiplicative functions in short intervals on average")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 December 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/12/05/fourier-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/")[#text("https://terrytao.wordpress.com/2018/12/05/fourier-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://users.utu.fi/ksmato/")[#text("Kaisa Matomäki")]#text(", ")#link("http://www.its.caltech.edu/~maksym/")[#text("Maksym Radziwill")]#text(", and I just uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/1812.01224")[#text("Fourier uniformity of bounded multiplicative functions in short intervals on average")]#text("“. This paper is the outcome of our attempts during the ")#link("https://www.msri.org/programs/297")[#text("MSRI program in analytic number theory")]#text(" last year to attack the local Fourier uniformity conjecture for the ")#link("https://en.wikipedia.org/wiki/Liouville_function")[#text("Liouville function")]#text(" ")#mi("{\\lambda}")#text(". This conjecture generalises a ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3488742")[#text("landmark result of Matomäki and Radziwill")]#text(", who show (among other things) that one has the asymptotic ")#metadata(none) <tao-79032b8a85663acddd60>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\int_X^{2X} |\\sum_{x \\leq n \\leq x+H} \\lambda(n)|\\ dx = o(HX)")]]

#text("whenever ")#mi("{X \\rightarrow \\infty}")#text(" and ")#mi("{H = H(X)}")#text(" goes to infinity as ")#mi("{X \\rightarrow \\infty}")#text(". Informally, this says that the Liouville function has small mean for almost all short intervals ")#mi("{[x,x+H]}")#text(". The remarkable thing about this theorem is that there is no lower bound on how ")#mi("{H}")#text(" goes to infinity with ")#mi("{X}")#text("; one can take for instance ")#mi("{H = \\log\\log\\log X}")#text(". This lack of lower bound was crucial when I applied this result (or more precisely, a generalisation of this result to arbitrary non-pretentious bounded multiplicative functions) a few years ago to ")#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/")[#text("solve the Erdös discrepancy problem, as well as a logarithmically averaged two-point Chowla conjecture")]#text(", for instance it implies that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq X} \\frac{\\lambda(n) \\lambda(n+1)}{n} = o(\\log X).")]]

#text("The local Fourier uniformity conjecture asserts the stronger asymptotic ")#metadata(none) <tao-0b57c252172d6287b509>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\int_X^{2X} \\sup_{\\alpha \\in {\\bf R}} \\left|\\sum_{x \\leq n \\leq x+H} \\lambda(n) e(-\\alpha n)\\right|\\ dx = o(HX)", block: true)]]

#text("under the same hypotheses on ")#mi("{H}")#text(" and ")#mi("{X}")#text(". As ")#link("https://terrytao.wordpress.com/2016/05/16/equivalence-of-the-logarithmically-averaged-chowla-and-sarnak-conjectures/")[#text("I worked out in a previous paper")]#text(", this conjecture would imply a logarithmically averaged three-point Chowla conjecture, implying for instance that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq X} \\frac{\\lambda(n) \\lambda(n+1) \\lambda(n+2)}{n} = o(\\log X).")]]

#text("This particular bound also follows from some ")#link("https://terrytao.wordpress.com/2017/08/09/the-structure-of-logarithmically-averaged-correlations-of-multiplicative-functions-with-applications-to-the-chowla-and-elliott-conjectures/")[#text("slightly different arguments")]#text(" ")#link("https://terrytao.wordpress.com/2017/10/07/odd-order-cases-of-of-the-logarithmically-averaged-chowla-conjecture/")[#text("of Joni Teräväinen and myself")]#text(", but the implication would also work for other non-pretentious bounded multiplicative functions, whereas the arguments of Joni and myself rely more heavily on the specific properties of the Liouville function (in particular that ")#mi("{\\lambda(p)=-1}")#text(" for all primes ")#mi("{p}")#text(").")

#text("There is also a higher order version of the local Fourier uniformity conjecture in which the linear phase ")#mi("{{}e(-\\alpha n)}")#text(" is replaced with a polynomial phase such as ")#mi("{e(-\\alpha_d n^d - \\dots - \\alpha_1 n - \\alpha_0)}")#text(", or more generally a nilsequence ")#mi("{\\overline{F(g(n) \\Gamma)}}")#text("; as shown in ")#link("https://terrytao.wordpress.com/2016/05/16/equivalence-of-the-logarithmically-averaged-chowla-and-sarnak-conjectures/")[#text("my previous paper")]#text(", this conjecture implies (and is in fact equivalent to, after logarithmic averaging) a logarithmically averaged version of the full Chowla conjecture (not just the two-point or three-point versions), as well as a logarithmically averaged version of the Sarnak conjecture.")

#text("The main result of the current paper is to obtain some cases of the local Fourier uniformity conjecture:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" The asymptotic ")#link(<tao-0b57c252172d6287b509>)[#text("(2)")]#text(" is true when ")#mi("{H = X^\\theta}")#text(" for a fixed ")#mi("{\\theta > 0}")#text(".")
]

#text("Previously this was known for ")#mi("{\\theta > 5/8}")#text(" by the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1141240")[#text("work of Zhan")]#text(" (who in fact proved the stronger pointwise assertion ")#tao-math("{\\sup_{\\alpha \\in {\\bf R}} \\left|\\sum_{x \\leq n \\leq x+H} \\lambda(n) e(-\\alpha n)\\right|= o(H)}", block: false)#text(" for ")#mi("{X \\leq x \\leq 2X}")#text(" in this case). In a previous paper with Kaisa and Maksym, we also proved a weak version ")#metadata(none) <tao-58329ca38d8ee507c537>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sup_{\\alpha \\in {\\bf R}} \\int_X^{2X} |\\sum_{x \\leq n \\leq x+H} \\lambda(n) e(-\\alpha n)|\\ dx = o(HX)")]]

#text("of ")#link(<tao-0b57c252172d6287b509>)[#text("(2)")]#text(" for any ")#mi("{H}")#text(" growing arbitrarily slowly with ")#mi("{X}")#text("; this is stronger than ")#link(<tao-79032b8a85663acddd60>)[#text("(1)")]#text(" (and is in fact proven by a variant of the method) but significantly weaker than ")#link(<tao-0b57c252172d6287b509>)[#text("(2)")]#text(", because in the latter the worst-case ")#mi("{\\alpha}")#text(" is permitted to depend on the ")#mi("{x}")#text(" parameter, whereas in ")#link(<tao-58329ca38d8ee507c537>)[#text("(3)")]#text(" ")#mi("{\\alpha}")#text(" must remain independent of ")#mi("{x}")#text(".")

#text("Unfortunately, the restriction ")#mi("{H = X^\\theta}")#text(" is not strong enough to give applications to Chowla-type conjectures (one would need something more like ")#mi("{H = \\log^\\theta X}")#text(" for this). However, it can still be used to control some sums that had not previously been manageable. For instance, a quick application of the circle method lets one use the above theorem to derive the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_{h \\leq H} \\sum_{n \\leq X} \\lambda(n) \\Lambda(n+h) \\Lambda(n+2h) = o( H X )")]]

#text("whenever ")#mi("{H = X^\\theta}")#text(" for a fixed ")#mi("{\\theta > 0}")#text(", where ")#mi("{\\Lambda}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(". Amusingly, the seemingly simpler question of establishing the expected asymptotic for")

#align(center)[#tao-fit-display[#mitex("\\sum_{h \\leq H} \\sum_{n \\leq X} \\Lambda(n+h) \\Lambda(n+2h)")]]

#text("is only known in the range ")#mi("{\\theta \\geq 1/6}")#text(" (from ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1617735")[#text("the work of Zaccagnini")]#text("). Thus we have a rare example of a number theory sum that becomes ")#emph[#text("easier")]#text(" to control when one inserts a Liouville function!")

#text("We now give an informal description of the strategy of proof of the theorem (though for numerous technical reasons, the actual proof deviates in some respects from the description given here). If ")#link(<tao-0b57c252172d6287b509>)[#text("(2)")]#text(" failed, then for many values of ")#mi("{x \\in [X,2X]}")#text(" we would have the lower bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{x \\leq n \\leq x+H} \\lambda(n) e(-\\alpha_x n)\\right| \\gg 1", block: true)]]

#text("for some frequency ")#mi("{\\alpha_x \\in{\\bf R}}")#text(". We informally describe this correlation between ")#mi("{\\lambda(n)}")#text(" and ")#mi("{e(\\alpha_x n)}")#text(" by writing ")#metadata(none) <tao-ea325d761f98c6b73320>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\lambda(n) \\approx e(\\alpha_x n)")]]

#text("for ")#mi("{n \\in [x,x+H]}")#text(" (informally, one should view this as asserting that ")#mi("{\\lambda(n)}")#text(" “behaves like” a constant multiple of ")#mi("{e(\\alpha_x n)}")#text("). For sake of discussion, suppose we have this relationship for ")#emph[#text("all")]#text(" ")#mi("{x \\in [X,2X]}")#text(", not just ")#emph[#text("many")]#text(".")

#text("As mentioned before, the main difficulty here is to understand how ")#mi("{\\alpha_x}")#text(" varies with ")#mi("{x}")#text(". As it turns out, the multiplicativity properties of the Liouville function place a significant constraint on this dependence. Indeed, if we let ")#mi("{p}")#text(" be a fairly small prime (e.g. of size ")#mi("{H^\\varepsilon}")#text(" for some ")#mi("{\\varepsilon>0}")#text("), and use the identity ")#mi("{\\lambda(np) = \\lambda(n) \\lambda(p) = - \\lambda(n)}")#text(" for the Liouville function to conclude (at least heuristically) from ")#link(<tao-ea325d761f98c6b73320>)[#text("(4)")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\lambda(n) \\approx e(\\alpha_x n p)")]]

#text("for ")#mi("{n \\in [x/p, x/p + H/p]}")#text(". (In practice, we will have this sort of claim for ")#emph[#text("many")]#text(" primes ")#mi("{p}")#text(" rather than ")#emph[#text("all")]#text(" primes ")#mi("{p}")#text(", after using tools such as the ")#link("https://en.wikipedia.org/wiki/Tur%C3%A1n%E2%80%93Kubilius_inequality")[#text("Turán-Kubilius inequality")]#text(", but we ignore this distinction for this informal argument.)")

#text("Now let ")#mi("{x, y \\in [X,2X]}")#text(" and ")#mi("{p,q \\sim P}")#text(" be primes comparable to some fixed range ")#mi("{P = H^\\varepsilon}")#text(" such that ")#metadata(none) <tao-43961e0a49e0d6abcba0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("x/p = y/q + O( H/P).")]]

#text("Then we have both")

#align(center)[#tao-fit-display[#mitex("\\lambda(n) \\approx e(\\alpha_x n p)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\lambda(n) \\approx e(\\alpha_y n q)")]]

#text("on essentially the same range of ")#mi("{n}")#text(" (two nearby intervals of length ")#mi("{\\sim H/P}")#text("). This suggests that the frequencies ")#mi("{p \\alpha_x}")#text(" and ")#mi("{q \\alpha_y}")#text(" should be close to each other modulo ")#mi("{1}")#text(", in particular one should expect the relationship ")#metadata(none) <tao-327fb97d65cd3e8a4455>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("p \\alpha_x = q \\alpha_y + O( \\frac{P}{H} ) \\text{ mod } 1.")]]

#text("Comparing this with ")#link(<tao-43961e0a49e0d6abcba0>)[#text("(5)")]#text(" one is led to the expectation that ")#mi("{\\alpha_x}")#text(" should depend inversely on ")#mi("{x}")#text(" in some sense (for instance one can check that ")#metadata(none) <tao-68f442015a792fe81d17>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\alpha_x = T/x")]]

#text("would solve ")#link(<tao-327fb97d65cd3e8a4455>)[#text("(6)")]#text(" if ")#mi("{T = O( X / H^2 )}")#text("; by Taylor expansion, this would correspond to a global approximation of the form ")#mi("{\\lambda(n) \\approx n^{iT}}")#text("). One now has a problem of an additive combinatorial flavour (or of a “local to global” flavour), namely to leverage the relation ")#link(<tao-327fb97d65cd3e8a4455>)[#text("(6)")]#text(" to obtain global control on ")#mi("{\\alpha_x}")#text(" that resembles ")#link(<tao-68f442015a792fe81d17>)[#text("(7)")]#text(".")

#text("A key obstacle in solving ")#link(<tao-327fb97d65cd3e8a4455>)[#text("(6)")]#text(" efficiently is the fact that one only knows that ")#mi("{p \\alpha_x}")#text(" and ")#mi("{q \\alpha_y}")#text(" are close modulo ")#mi("{1}")#text(", rather than close on the real line. One can start resolving this problem by the Chinese remainder theorem, using the fact that we have the freedom to shift (say) ")#mi("{\\alpha_y}")#text(" by an arbitrary integer. After doing so, one can arrange matters so that one in fact has the relationship ")#metadata(none) <tao-3d1bb9ff594e010ecaae>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("p \\alpha_x = q \\alpha_y + O( \\frac{P}{H} ) \\text{ mod } p")]]

#text("whenever ")#mi("{x,y \\in [X,2X]}")#text(" and ")#mi("{p,q \\sim P}")#text(" obey ")#link(<tao-43961e0a49e0d6abcba0>)[#text("(5)")]#text(". (This may force ")#mi("{\\alpha_q}")#text(" to become extremely large, on the order of ")#mi("{\\prod_{p \\sim P} p}")#text(", but this will not concern us.)")

#text("Now suppose that we have ")#mi("{y,y^{\\prime} \\in [X,2X]}")#text(" and primes ")#mi("{q,q^{\\prime} \\sim P}")#text(" such that ")#metadata(none) <tao-5a378059430b0f408176>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("y/q = y^{\\prime}/q^{\\prime} + O(H/P).")]]

#text("For every prime ")#mi("{p \\sim P}")#text(", we can find an ")#mi("{x}")#text(" such that ")#mi("{x/p}")#text(" is within ")#mi("{O(H/P)}")#text(" of both ")#mi("{y/q}")#text(" and ")#mi("{y^{\\prime}/q^{\\prime}}")#text(". Applying ")#link(<tao-3d1bb9ff594e010ecaae>)[#text("(8)")]#text(" twice we obtain")

#align(center)[#tao-fit-display[#mitex("p \\alpha_x = q \\alpha_y + O( \\frac{P}{H} ) \\text{ mod } p")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("p \\alpha_x = q^{\\prime} \\alpha_{y^{\\prime}} + O( \\frac{P}{H} ) \\text{ mod } p")]]

#text("and thus by the triangle inequality we have")

#align(center)[#tao-fit-display[#mitex("q \\alpha_y = q^{\\prime} \\alpha_{y^{\\prime}} + O( \\frac{P}{H} ) \\text{ mod } p")]]

#text("for all ")#mi("{p \\sim P}")#text("; hence by the Chinese remainder theorem")

#align(center)[#tao-fit-display[#mitex("q \\alpha_y = q^{\\prime} \\alpha_{y^{\\prime}} + O( \\frac{P}{H} ) \\text{ mod } \\prod_{p \\sim P} p.")]]

#text("In practice, in the regime ")#mi("{H = X^\\theta}")#text(" that we are considering, the modulus ")#mi("{\\prod_{p \\sim P} p}")#text(" is so huge we can effectively ignore it (in the spirit of the ")#link("https://terrytao.wordpress.com/tag/lefschetz-principle/")[#text("Lefschetz principle")]#text("); so let us pretend that we in fact have ")#metadata(none) <tao-759fe98738b76a174c30>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("q \\alpha_y = q^{\\prime} \\alpha_{y^{\\prime}} + O( \\frac{P}{H} )")]]

#text("whenever ")#mi("{y,y^{\\prime} \\in [X,2X]}")#text(" and ")#mi("{q,q^{\\prime} \\sim P}")#text(" obey ")#link(<tao-5a378059430b0f408176>)[#text("(9)")]#text(".")

#text("Now let ")#mi("{k}")#text(" be an integer to be chosen later, and suppose we have primes ")#mi("{p_1,\\dots,p_k,q_1,\\dots,q_k \\sim P}")#text(" such that the difference")

#align(center)[#tao-fit-display[#tao-math("q = \\left|p_1 \\dots p_k - q_1 \\dots q_k\\right|", block: true)]]

#text("is small but non-zero. If ")#mi("{k}")#text(" is chosen so that")

#align(center)[#tao-fit-display[#mitex("P^k \\approx \\frac{X}{H}")]]

#text("(where one is somewhat loose about what ")#mi("{\\approx}")#text(" means) then one can then find real numbers ")#mi("{x_1,\\dots,x_k \\sim X}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\frac{x_j}{p_j} = \\frac{x_{j+1}}{q_j} + O( \\frac{H}{P} )")]]

#text("for ")#mi("{j=1,\\dots,k}")#text(", with the convention that ")#mi("{x_{k+1} = x_1}")#text(". We then have")

#align(center)[#tao-fit-display[#mitex("p_j \\alpha_{x_j} = q_j \\alpha_{x_{j+1}} + O( \\frac{P}{H} )")]]

#text("which telescopes to")

#align(center)[#tao-fit-display[#mitex("p_1 \\dots p_k \\alpha_{x_1} = q_1 \\dots q_k \\alpha_{x_1} + O( \\frac{P^k}{H} )")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("q \\alpha_{x_1} = O( \\frac{P^k}{H} )")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("\\alpha_{x_1} = O( \\frac{P^k}{H} ) \\approx O( \\frac{X}{H^2} ).")]]

#text("In particular, for each ")#mi("{x \\sim X}")#text(", we expect to be able to write")

#align(center)[#tao-fit-display[#mitex("\\alpha_x = \\frac{T_x}{x} + O( \\frac{1}{H} )")]]

#text("for some ")#mi("{T_x = O( \\frac{X^2}{H^2} )}")#text(". This quantity ")#mi("{T_x}")#text(" can vary with ")#mi("{x}")#text("; but from ")#link(<tao-759fe98738b76a174c30>)[#text("(10)")]#text(" and a short calculation we see that")

#align(center)[#tao-fit-display[#mitex("T_y = T_{y^{\\prime}} + O( \\frac{X}{H} )")]]

#text("whenever ")#mi("{y, y^{\\prime} \\in [X,2X]}")#text(" obey ")#link(<tao-5a378059430b0f408176>)[#text("(9)")]#text(" for some ")#mi("{q,q^{\\prime} \\sim P}")#text(".")

#text("Now imagine a “graph” in which the vertices are elements ")#mi("{y}")#text(" of ")#mi("{[X,2X]}")#text(", and two elements ")#mi("{y,y^{\\prime}}")#text(" are joined by an edge if ")#link(<tao-5a378059430b0f408176>)[#text("(9)")]#text(" holds for some ")#mi("{q,q^{\\prime} \\sim P}")#text(". Because of exponential sum estimates on ")#mi("{\\sum_{q \\sim P} q^{it}}")#text(", this graph turns out to essentially be an “")#link("https://en.wikipedia.org/wiki/Expander_graph")[#text("expander")]#text("” in the sense that any two vertices ")#mi("{y,y^{\\prime} \\in [X,2X]}")#text(" can be connected (in multiple ways) by fairly short paths in this graph (if one allows one to modify one of ")#mi("{y}")#text(" or ")#mi("{y^{\\prime}}")#text(" by ")#mi("{O(H)}")#text("). As a consequence, we can assume that this quantity ")#mi("{T_y}")#text(" is essentially constant in ")#mi("{y}")#text(" (cf. the application of the ergodic theorem in ")#link("https://terrytao.wordpress.com/2018/07/17/a-corollary-of-the-ergodic-theorem/")[#text("this previous blog post")]#text("), thus we now have")

#align(center)[#tao-fit-display[#mitex("\\alpha_x = \\frac{T}{x} + O(\\frac{1}{H} )")]]

#text("for most ")#mi("{x \\in [X,2X]}")#text(" and some ")#mi("{T = O(X^2/H^2)}")#text(". By Taylor expansion, this implies that")

#align(center)[#tao-fit-display[#mitex("\\lambda(n) \\approx n^{iT}")]]

#text("on ")#mi("{[x,x+H]}")#text(" for most ")#mi("{x}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\int_X^{2X} |\\sum_{x \\leq n \\leq x+H} \\lambda(n) n^{-iT}|\\ dx \\gg HX.")]]

#text("But this can be shown to contradict the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3488742")[#text("Matomäki-Radziwill theorem")]#text(" (because the multiplicative function ")#mi("{n \\mapsto \\lambda(n) n^{-iT}}")#text(" is known to be non-pretentious).")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/05/fourier-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-508360")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2018")])]

#text("Is it possible in theorem 1 to make ")#mi("\\theta = o_X(1)")#text(" for some explicit sufficiently slowly decreasing function ")#mi("o_X(1)")#text(" (as ")#mi("X \\to \\infty")#text(") ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/05/fourier-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-508361")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2018")])]

#text("Yes; we believe in fact that our arguments should extend to cover the range ")#mi("H \\geq \\exp( \\log^{1-c} X )")#text(" for some absolute constant ")#mi("c>0")#text(", and on the Riemann hypothesis one can hope to get as far as ")#mi("H \\geq \\log^{\\omega(X)} X")#text(" for any ")#mi("\\omega(X)")#text(" that goes to infinity. However we have not checked these claims in detail (particularly the latter). Next week Maksym and I will be at the ")#link("https://aimath.org/workshops/upcoming/sarnakconjecture/")[#text("AIM workshop on the Sarnak and Chowla conjectures")]#text(", together with several other experts in this area, and we may be able to sort out exactly how far these techniques can be pushed then.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48fce4eb8ee74132a21b83db48941b7755f7004fe88049fdc6070ff8064e71a0-7401a4eab5f795736c314dbe6614509e8052467db7407c1495e85fb1ade67d64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of foobar")]], [#link("https://terrytao.wordpress.com/2018/12/05/fourier-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-508432")[#strong[#text("foobar")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2018")])]

#text("A typo nit: Joni Teräväinen, not Joni Teravainen. (It appears to be correct on the other blog post.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1cf9bca2192232d4297f7b4c4c3154b2431c06ad2f7a16c673fe84f712f2fdaa-3d1a76bfd473a1d5ac82f8787ed68bd884c3a935313f346df281882fcdd5efd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allan van Hulst")]], [#link("https://terrytao.wordpress.com/2018/12/05/fourier-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-508458")[#strong[#text("Allan van Hulst")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2018")])]

#text("Typo: “that ths quantity”. By the way, do you think it would be possible to derive a practical upper bound for the length of these “fairly short paths” in the graph-based perspective applied in the latter part of the proof?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/05/fourier-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-508474")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2018")])]

#text("The typical diameter of this “graph” should be logarithmic in size, though in our actual argument we don’t actually work with such long paths and proceed by using a “mixing lemma” (analogous to the “expander mixing lemma” in the theory of expander graphs) instead to show that any two large sets are highly connected to each other by this graph, which is all we really need anyway.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f0b9a908987dfdfc75dae02356a635e8ff78f8d3d1ca98913514ae4baf88d46-d00c0befd789903b432aea6071945fa92bf8636b4820e83fbd2e6a03dea15f9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2018/12/05/fourier-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-508519")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2018")])]

#text("What goes wrong if you try to apply the same argument to polynomial phases? One might naively hope that everything works if you just raise p to a power at every step, but this seems unlikely.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/05/fourier-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-508528")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2018")])]

#text("We haven’t checked the details of this yet, but I am optimistic that most of the argument should be generalisable to polynomial phases, and thence to nilsequences. This is certainly something we plan to look at next week during the AIM workshop.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e0fd56049a8189a380fda42273fee0bc2b9ce50a7a224700afce1fe96194008-d71b4d207f9bb85a02159d9eb02ffc3ded2bfbce61de425e7d3d85b4f53db867.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uwe Stroinski")]], [#link("https://terrytao.wordpress.com/2018/12/05/fourier-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-511433")[#strong[#text("Uwe Stroinski")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2019")])]

#text("Today I was on a workshop where Tanja Eisner was scheduled to give a short talk about Sarnaks conjecture and (I guess) this last AIM workshop. Unfortunately she could not make it. Can you say a sentence or two about what you think what the situation is and whether there are there any promising approaches?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/05/fourier-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-511434")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2019")])]

#text("At AIM we pretty much convinced ourselves that the argument extends to polynomial phases, and we have a sketch of an argument that it also works for nilsequences. Also it looks hopeful that the condition ")#mi("H \\geq X^\\theta")#text(" can be relaxed a bit, probably to ")#mi("H \\geq \\exp( \\log^{1/2+\\varepsilon} X)")#text(" and further than that if we assume RH. The nilsequence extension also seems to have some implications for sign patterns of the Liouville function and for various polynomial correlations of Liouville. Eventually we’ll try to write up these things properly, but at present everything is just in sketchy note form.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9d6c587f0179a9e9cd79521e2b6e113d0cb1f812e0a24e3149da324234575b5-b393abd8e95f8ff6c0382edd82d629c7d085349005e0c6c3c8751e025646bf26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2018/12/05/fourier-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-508525")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2018")])]

#text("I think some references to display (8) should be to display (6).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3de0971aa98986c59e57f76238c236536bbf74450298b40bccba65aaefdc5ad9-4ea34b276d8ccaca362647255e28225be4a33c216c4e97d34fd82798bf1184c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Excited")]], [#link("https://terrytao.wordpress.com/2018/12/05/fourier-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-508662")[#strong[#text("Excited")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2018")])]

#text("It seems the Riemann Hypothesis has been proven ! ")#link("https://math.stackexchange.com/q/3034495/507152")[#text("https://math.stackexchange.com/q/3034495/507152")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/05/fourier-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-508667")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2018")])]

#text("Another proposed one-page proof of RH was recently given by Atiyah.")#linebreak()#text(" One should not be “too excited” by such proposed proofs.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/05/fourier-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-508672")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2018")])]

#text("The math exchange argument is an old flawed one (that seems to reappear once in a while either there or on mathoverflow) that misuses the complex logarithm and the residue theorem to make an integral vanish in thin air")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Higher uniformity of bounded multiplicative functions in short intervals on average | What's new")]], [#link("https://terrytao.wordpress.com/2018/12/05/fourier-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-578370")[#strong[#text("Higher uniformity of bounded multiplicative functions in short intervals on average | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2020")])]

#text("[…] for a generalization of the Chowla conjecture known as the Elliott conjecture). Recently, Kaisa, Maks and myself were able to establish this conjecture in the range (in fact we have since worked out in the current paper that we can get as small as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20b7d9bfcb64c5bea2c91bc6ea88d2666923318fac1a3d1717e80fe47c3bb055-efc06c2c203f32fd53e2c41c3a6338d369b714cbba80b1a734346a5bfcf93e0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andras Biro")]], [#link("https://terrytao.wordpress.com/2018/12/05/fourier-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-636441")[#strong[#text("Andras Biro")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2021")])]

#text("Let me ask a perhaps elementary question. For the proof of Proposition 2.5 you refer to [6, Lemma 4.7]. But the statement there (in Elliott’s book) is not exactly your Proposition 2.5. Elliott’s lemma (which is the dual of the Turán-Kubilius inequality) would give your proposition for the case x=0 and for H>0. But can Proposition 2.5 be proved in exactly the same way as [6, Lemma 4.7]? At first sight it is not trivial for me.")

#emph[#text("[Unfortunately I don’t have Elliott’s book handy, but a standard large sieve / second moment method argument works; see Exercise 8 of ")#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/")[#text("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/")]#text(" . The main point is that we have very good estimates on the covariances between the events ")#mi("p|n")#text(" and ")#mi("q|n")#text(" for distinct small primes ")#mi("p,q")#text(" for ")#mi("n")#text(" chosen randomly in an interval ")#mi("x \\leq n \\leq x+H")#text(", regardless of the value of ")#mi("x")#text(". -T]")]
]
