// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/11/02/climbing-the-cosmic-distance-ladder-launching-an-instagram/
// Converted to Typst by tao2typ: "2026-11-02T16:21:40.803873+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Climbing the cosmic distance ladder: launching an instagram", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Climbing the cosmic distance ladder: launching an instagram")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 November 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/11/02/climbing-the-cosmic-distance-ladder-launching-an-instagram/")[#text("https://terrytao.wordpress.com/2024/11/02/climbing-the-cosmic-distance-ladder-launching-an-instagram/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-02 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I have been collaborating for many years with a long-time personal friend and polymath, ")#link("https://courtauld.ac.uk/people/tanya-klowden/")[#text("Tanya Klowden")]#text(", on a popular book on astronomy tentatively entitled “")#link("https://terrytao.wordpress.com/books/climbing-the-cosmic-distance-ladder/")[#text("Climbing the cosmic distance ladder")]#text("“, which was initially based on a ")#link("https://www.youtube.com/watch?v=7ne0GArfeMs")[#text("public lecture I have given")]#text(" on this topic for many years, but which we have found to be a far richer story than what I was aware of when I first gave those lectures. We had ")#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/")[#text("previously released a sample chapter on this blog")]#text(" back in 2020. The project had stalled for a few years for a number of reasons (including some pandemic-related issues); however, we are now trying to get it back on track. One of the steps we are taking to do so is to ")#link("https://www.instagram.com/cosmic_distance_ladder/")[#text("launch an Instagram account for the book")]#text(", in which we aim to make some regular posts (tentatively on a weekly basis) on astronomical tidbits that we have encountered in the course of researching our book project. Tanya has started this series by ")#link("https://www.instagram.com/p/DB22-sooQhN/?img_index=1")[#text("sharing her experiences")]#text(" on comet-hunting in Hampstead Heath, following in the footsteps of the legendary comet-hunting 19th century astronomer ")#link("https://en.wikipedia.org/wiki/Caroline_Herschel")[#text("Caroline Herschel")]#text(" (who, together with her brother ")#link("https://en.wikipedia.org/wiki/William_Herschel")[#text("William Herschel")]#text(", will make a significant appearance in the “seventh rung” chapter of our book). I plan to follow up with an instagram post of my own in the next few days.")

#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2024/11/02/climbing-the-cosmic-distance-ladder-launching-an-instagram/comment-page-1/#comment-686580")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2024")])]

#text("I only took a look at the slides and got a little bit surprised by that claim that Copernicus worked with observations from Babylonian astronomers. To my knowledge, Babylonian inscriptions where not discovered or even decyphered at this time (but I may be wrong).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/11/02/climbing-the-cosmic-distance-ladder-launching-an-instagram/comment-page-1/#comment-686584")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2024")])]

#text("Babylonian astronomical data was known to the ancient Greeks, whose knowledge was passed on to the Arabs, and this made its way back to Europe by the time of Copernicus.")
]
]
