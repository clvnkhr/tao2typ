// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/02/05/word-maps-close-to-the-identity/
// Converted to Typst by tao2typ: "2026-10-14T16:38:30.905629+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Word maps close to the identity", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Word maps close to the identity")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 February 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/02/05/word-maps-close-to-the-identity/")[#text("https://terrytao.wordpress.com/2019/02/05/word-maps-close-to-the-identity/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("While talking mathematics with a postdoc here at UCLA (")#link("http://www.math.ucla.edu/~march/")[#text("March Boedihardjo")]#text(") we came across the following matrix problem which we managed to solve, but the proof was cute and the process of discovering it was fun, so I thought I would present the problem here as a puzzle without revealing the solution for now.")

#text("The problem involves word maps on a matrix group, which for sake of discussion we will take to be the special orthogonal group ")#mi("SO(3)")#text(" of real ")#mi("3 \\times 3")#text(" matrices (one of the smallest matrix groups that contains a copy of the free group, which incidentally is the key observation powering the ")#link("https://en.wikipedia.org/wiki/Banach%E2%80%93Tarski_paradox")[#text("Banach-Tarski paradox")]#text("). Given any abstract ")#link("https://en.wikipedia.org/wiki/Word_(group_theory)")[#text("word")]#text(" ")#mi("w")#text(" of two generators ")#mi("x,y")#text(" and their inverses (i.e., an element of the ")#link("https://en.wikipedia.org/wiki/Free_group")[#text("free group")]#text(" ")#mi("{\\bf F}_2")#text("), one can define the word map ")#mi("w: SO(3) \\times SO(3) \\to SO(3)")#text(" simply by substituting a pair of matrices in ")#mi("SO(3)")#text(" into these generators. For instance, if one has the word ")#mi("w = x y x^{-2} y^2 x")#text(", then the corresponding word map ")#mi("w: SO(3) \\times SO(3) \\to SO(3)")#text(" is given by")

#align(center)[#tao-fit-display[#mitex("w(A,B) := ABA^{-2} B^2 A")]]

#text("for ")#mi("A,B \\in SO(3)")#text(". Because ")#mi("SO(3)")#text(" contains a copy of the free group, we see the word map is non-trivial (not equal to the identity) if and only if the word itself is nontrivial.")

#text("Anyway, here is the problem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem.")]#text(" Does there exist a sequence ")#mi("w_1, w_2, \\dots")#text(" of non-trivial word maps ")#mi("w_n: SO(3) \\times SO(3) \\to SO(3)")#text(" that converge uniformly to the identity map?")
]

#text("To put it another way, given any ")#mi("\\varepsilon > 0")#text(", does there exist a non-trivial word ")#mi("w")#text(" such that ")#tao-math("\\left\\|w(A,B) - 1 \\right\\| \\leq \\varepsilon", block: false)#text(" for all ")#mi("A,B \\in SO(3)")#text(", where ")#mi("\\| \\|")#text(" denotes (say) the operator norm, and ")#mi("1")#text(" denotes the identity matrix in ")#mi("SO(3)")#text("?")

#text("As I said, I don’t want to spoil the fun of working out this problem, so I will leave it as a challenge. Readers are welcome to share their thoughts, partial solutions, or full solutions in the comments below.")

#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/05/word-maps-close-to-the-identity/#comment-512183")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2019")])]

#text("Professor Tao, Happy Lunar New Year!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fd94aba8ab493f7648c071b13fe40371fa065e7f49c3710bf3be78f00c61854-9a060697f1cfbe2a0f62d1c69b3f2f3f5ee0c3f6fb1dd6ce063d450b023bae82.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jie")]], [#link("https://terrytao.wordpress.com/2019/02/05/word-maps-close-to-the-identity/#comment-512184")[#strong[#text("Jie")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2019")])]

#text("Prof Tao, happy lunar new year!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/195148c9512b278af3c5a4736616a6c3c02da531fa3d2162ab53b1cf8dd347b8-d8e7519ada97498c3e23e3536ffc499b8027882d1828d8a0a844f34f8fbd368a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andreas Thom")]], [#link("https://terrytao.wordpress.com/2019/02/05/word-maps-close-to-the-identity/#comment-512186")[#strong[#text("Andreas Thom")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2019")])]

#text("I proved this and more general results in “Convergent sequences in discrete groups”, Canad. Math. Bull. 56 (2013), no. 2, 424-433. The preprint is available at ")#link("https://arxiv.org/abs/1003.4093")[#text("https://arxiv.org/abs/1003.4093")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/195148c9512b278af3c5a4736616a6c3c02da531fa3d2162ab53b1cf8dd347b8-d8e7519ada97498c3e23e3536ffc499b8027882d1828d8a0a844f34f8fbd368a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andreas Thom")]], [#link("https://terrytao.wordpress.com/2019/02/05/word-maps-close-to-the-identity/#comment-512187")[#strong[#text("Andreas Thom")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2019")])]

#text("See also ")#link("https://mathoverflow.net/questions/229384/solving-equations-in-so3-an-open-problem-by-jan-mycielski/229762")[#text("https://mathoverflow.net/questions/229384/solving-equations-in-so3-an-open-problem-by-jan-mycielski/229762")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/195148c9512b278af3c5a4736616a6c3c02da531fa3d2162ab53b1cf8dd347b8-d8e7519ada97498c3e23e3536ffc499b8027882d1828d8a0a844f34f8fbd368a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andreas Thom")]], [#link("https://terrytao.wordpress.com/2019/02/05/word-maps-close-to-the-identity/#comment-512188")[#strong[#text("Andreas Thom")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2019")])]

#text("It is an interesting open problem (as far as I can tell) to determine how fast (in terms of the word length) the image of the word map can converge to the identity matrix. This is related to the shortest length of iterated commutators, a problem that was discussed in")

#text("Abdelrhman Elkasapy and Andreas Thom, On the length of the shortest non-trivial element in the derived and the lower central series. J. Group Theory 18 (2015), no. 5, 793–804.")

#text("Theorem 5.2. discusses the best asymptotics that we could find. See ")#link("https://arxiv.org/abs/1311.0138")[#text("https://arxiv.org/abs/1311.0138")]#text(" for the preprint.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/568b39c5f16abcbecb107a3f3c8f0b73c881fdadcfbe0f5511f1066079134a30-b20a9013674d1728be5bb84d20666f183d81afafe034529b5e3612acaa91e9ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of duetosymmetry")]], [#link("https://terrytao.wordpress.com/2019/02/05/word-maps-close-to-the-identity/#comment-512192")[#strong[#text("duetosymmetry")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2019")])]

#text("Suppose we consider w_i(e,B) where e is the identity element in SO(3). Then w_i(e,B) can only be of the form B^k for some integer k.")

#text("Is it then a necessary condition that there is some sequence of k_i’s such that B^{k_i} converges to the identity for all B in SO(3)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dd38eb79dd005d5091b9b3c49f40aa47236e21b5345b6381eb83aeb04189483f-5365fee31be4687d5ae998e23aecae25e9205b8b4871e5cef48d4a499c1db808.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2019/02/05/word-maps-close-to-the-identity/#comment-512206")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2019")])]

#text("@duetosymmetry No, because $k$ might be (and will be) zero.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/05/word-maps-close-to-the-identity/#comment-512322")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2019")])]

#link("https://mathoverflow.net/questions/45483/word-maps-on-compact-lie-groups")[#text("https://mathoverflow.net/questions/45483/word-maps-on-compact-lie-groups")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b06d003253d434d80f887682de8a88a6f9fd8ab40008868d81adff930a62d64d-3366080f1907030ec6dc31d433f74f66df708343857a0eefba583cf68a6f46c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dmitriy Zakharov")]], [#link("https://terrytao.wordpress.com/2019/02/05/word-maps-close-to-the-identity/#comment-512355")[#strong[#text("Dmitriy Zakharov")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2019")])]

#text("For ")#mi("A\\in SO(3)")#text(" denote ")#tao-math("{\\rm rot~}A = \\sup \\frac{\\left|\\left|Ax-x\\right|\\right|}{\\left|\\left|x\\right|\\right|}", block: false)#text(". It is clear that if ")#mi("{\\rm rot~}A")#text(" is small enough then ")#mi("A")#text(" is close to the identity.")

#text("Lemma. For any ")#mi("A, B \\in SO(3)")#text(" we have ")#mi("{\\rm rot~}[A,B] \\leqslant 2{\\rm rot~}A \\cdot {\\rm rot~}B")#text(".")#linebreak()#text(" Proof:")

#tao-math("\\displaystyle \\left|\\left|[A,B]x - x\\right|\\right| = \\left|\\left| ABA^{-1}B^{-1} x - x \\right|\\right|", block: false)

#tao-math("\\displaystyle = \\left|\\left|ABx - BAx\\right|\\right| \\leqslant \\left|\\left|ABx - (Ax + Bx - x)\\right|\\right| + \\left|\\left|BAx - (Ax + Bx -x)\\right|\\right|", block: false)

#tao-math("\\displaystyle \\leqslant 2{\\rm rot~}A {\\rm rot~}B \\left\\|x\\right\\|", block: false)#text(".")

#text("Now notice that one of the operators ")#mi("A,A^2,\\ldots, A^{10}")#text(" has rot at most ")#mi("1/3")#text(" for any ")#mi("A \\in SO(3)")#text(". So, there is ")#mi("i \\in \\{1, \\ldots,10\\}")#text(" so that the ")#mi("n")#text("-fold commutator ")#mi("C_i = [A^i,[A^i, \\ldots [A^i, B]\\ldots]]")#text(" has rot at most ")#mi("2 (2/3)^n")#text(". Therefore, the word ")#mi("[\\ldots [C_1, C_2], C_3] \\ldots C_{10}]")#text(" has rot at most ")#mi("2^{10} (2/3)^n")#text(" and it is obviously non-trivial.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e410010a205ecc908db1250d0b3d681284aeae5febc6e40b1d83e751319704e-8edeacd4c416f2512e3ddf92366e9733804557c37ed1952b33780c0624b2fb23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jean Francois LEON")]], [#link("https://terrytao.wordpress.com/2019/02/05/word-maps-close-to-the-identity/#comment-512363")[#strong[#text("Jean Francois LEON")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2019")])]

#text("I am sorry but I don’t understand you lemma.")#linebreak()#text(" You establish a bound on the norm of the commuting not its rot.")#linebreak()#text(" Do I miss something obvious?")

#emph[#text("[Fixed some typos I spotted in the proof of that lemma. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of stunient")]], [#link("https://terrytao.wordpress.com/2019/02/05/word-maps-close-to-the-identity/#comment-512701")[#strong[#text("stunient")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2019")])]

#text("How does one see that the word is nontrivial?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a97deaa3ef13986dc80176f3b5a6ee0c6b50aac91ea4d586c114a25b4b08bb6f-6c6a6b670c64a488edbfc0a351fa1f415f8fa1a444d247a852145bc16b88533f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jair2018")]], [#link("https://terrytao.wordpress.com/2019/02/05/word-maps-close-to-the-identity/#comment-512562")[#strong[#text("jair2018")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2019")])]

#text("Reblogged this on ")#link("https://nricxcrap.wordpress.com/2019/02/13/word-maps-close-to-the-identity/")[#text("Crap")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/02/05/word-maps-close-to-the-identity/#comment-512570")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2019")])]

#text("Sorry for the rude blog post,I was experimenting with something on my blog,I called it crap to just label it as a pastebin")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c9a9b7b41122955e6a4b1b3ae66442ebddbdf2d6700fc60aa36a99ee9c6db80e-e3fe654ddb4fa951d0a5af3930b96e725b45c979bd2211ff9264141be61b4048.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry")]], [#link("https://terrytao.wordpress.com/2019/02/05/word-maps-close-to-the-identity/#comment-512751")[#strong[#text("Henry")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2019")])]

#text("I believe we can find a sequence of rotations of $S^1$ that converges uniformly to the identity map. Then, using the fact that the group of sphere rotation is isomorphic to $SO(3)$, we can define the elements of our sequence by the maps $(A,B) \\mapsto T_n B^{-1} B$, where $T_n$ is the nth element of the uniformly convergent sequence from the circle case.")
]
