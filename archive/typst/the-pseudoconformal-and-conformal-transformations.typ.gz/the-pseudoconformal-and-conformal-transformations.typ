// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/02/14/the-pseudoconformal-and-conformal-transformations/
// Converted to Typst by tao2typ: "2026-10-14T15:18:33.672437+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The pseudoconformal and conformal transformations", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The pseudoconformal and conformal transformations")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 February 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/02/14/the-pseudoconformal-and-conformal-transformations/")[#text("https://terrytao.wordpress.com/2013/02/14/the-pseudoconformal-and-conformal-transformations/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Consider the free Schrödinger equation in ")#mi("{d}")#text(" spatial dimensions, which I will normalise as ")#metadata(none) <tao-701586026ce95fd464c8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("i u_t + \\frac{1}{2} \\Delta_{{\\bf R}^d} u = 0")]]

#text("where ")#mi("{u: {\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is the unknown field and ")#mi("{\\Delta_{{\\bf R}^{d+1}} = \\sum_{j=1}^d \\frac{\\partial^2}{\\partial x_j^2}}")#text(" is the spatial Laplacian. To avoid irrelevant technical issues I will restrict attention to smooth (classical) solutions to this equation, and will work locally in spacetime avoiding issues of decay at infinity (or at other singularities); I will also avoid issues involving branch cuts of functions such as ")#mi("{t^{d/2}}")#text(" (if one wishes, one can restrict ")#mi("{d}")#text(" to be even in order to safely ignore all branch cut issues). The space of solutions to ")#link(<tao-701586026ce95fd464c8>)[#text("(1)")]#text(" enjoys a number of symmetries. A particularly non-obvious symmetry is the ")#emph[#text("pseudoconformal symmetry")]#text(": if ")#mi("{u}")#text(" solves ")#link(<tao-701586026ce95fd464c8>)[#text("(1)")]#text(", then the pseudoconformal solution ")#mi("{pc(u): {\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf C}}")#text(" defined by ")#metadata(none) <tao-5aa1f565273901eed9bc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("pc(u)(t,x) := \\frac{1}{(it)^{d/2}} \\overline{u(\\frac{1}{t}, \\frac{x}{t})} e^{i\\left|x\\right|^2/2t}", block: true)]]

#text("for ")#mi("{t \\neq 0}")#text(" can be seen after some computation to also solve ")#link(<tao-701586026ce95fd464c8>)[#text("(1)")]#text(". (If ")#mi("{u}")#text(" has suitable decay at spatial infinity and one chooses a suitable branch cut for ")#mi("{(it)^{d/2}}")#text(", one can extend ")#mi("{pc(u)}")#text(" continuously to the ")#mi("{t=0}")#text(" spatial slice, whereupon it becomes essentially the spatial Fourier transform of ")#mi("{u(0,\\cdot)}")#text(", but we will not need this fact for the current discussion.)")

#text("An analogous symmetry exists for the free wave equation in ")#mi("{d+1}")#text(" spatial dimensions, which I will write as ")#metadata(none) <tao-61e25c2cdda1758ce167>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("u_{tt} - \\Delta_{{\\bf R}^{d+1}} u = 0")]]

#text("where ")#mi("{u: {\\bf R} \\times {\\bf R}^{d+1} \\rightarrow {\\bf C}}")#text(" is the unknown field. In analogy to pseudoconformal symmetry, we have ")#emph[#text("conformal symmetry")]#text(": if ")#mi("{u: {\\bf R} \\times {\\bf R}^{d+1} \\rightarrow {\\bf C}}")#text(" solves ")#link(<tao-61e25c2cdda1758ce167>)[#text("(3)")]#text(", then the function ")#mi("{conf(u): {\\bf R} \\times {\\bf R}^{d+1} \\rightarrow {\\bf C}}")#text(", defined in the interior ")#tao-math("{\\{ (t,x): \\left|x\\right| < \\left|t\\right| \\}}", block: false)#text(" of the light cone by the formula ")#metadata(none) <tao-e193e5e73d6beceed61d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("conf(u)(t,x) := (t^2-\\left|x\\right|^2)^{-d/2} u( \\frac{t}{t^2-\\left|x\\right|^2}, \\frac{x}{t^2-\\left|x\\right|^2} ),", block: true)]]

#text("also solves ")#link(<tao-61e25c2cdda1758ce167>)[#text("(3)")]#text(".")

#text("There are also some direct links between the Schrödinger equation in ")#mi("{d}")#text(" dimensions and the wave equation in ")#mi("{d+1}")#text(" dimensions. This can be easily seen on the spacetime Fourier side: solutions to ")#link(<tao-701586026ce95fd464c8>)[#text("(1)")]#text(" have spacetime Fourier transform (formally) supported on a ")#mi("{d}")#text("-dimensional hyperboloid, while solutions to ")#link(<tao-61e25c2cdda1758ce167>)[#text("(3)")]#text(" have spacetime Fourier transform formally supported on a ")#mi("{d+1}")#text("-dimensional cone. To link the two, one then observes that the ")#mi("{d}")#text("-dimensional hyperboloid can be viewed as a conic section (i.e. hyperplane slice) of the ")#mi("{d+1}")#text("-dimensional cone. In physical space, this link is manifested as follows: if ")#mi("{u: {\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf C}}")#text(" solves ")#link(<tao-701586026ce95fd464c8>)[#text("(1)")]#text(", then the function ")#mi("{\\iota_{1}(u): {\\bf R} \\times {\\bf R}^{d+1} \\rightarrow {\\bf C}}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("\\iota_{1}(u)(t,x_1,\\ldots,x_{d+1}) := e^{-i(t+x_{d+1})} u( \\frac{t-x_{d+1}}{2}, x_1,\\ldots,x_d)")]]

#text("solves ")#link(<tao-61e25c2cdda1758ce167>)[#text("(3)")]#text(". More generally, for any non-zero scaling parameter ")#mi("{\\lambda}")#text(", the function ")#mi("{\\iota_{\\lambda}(u): {\\bf R} \\times {\\bf R}^{d+1} \\rightarrow {\\bf C}}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("\\iota_{\\lambda}(u)(t,x_1,\\ldots,x_{d+1}) :=")]]

#metadata(none) <tao-e895942f41b07123875a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\lambda^{d/2} e^{-i\\lambda(t+x_{d+1})} u( \\lambda \\frac{t-x_{d+1}}{2}, \\lambda x_1,\\ldots,\\lambda x_d)")]]

#text("solves ")#link(<tao-61e25c2cdda1758ce167>)[#text("(3)")]#text(".")

#text("As an “extra challenge” posed in an exercise in ")#link("https://terrytao.wordpress.com/books/nonlinear-dispersive-equations-local-and-global-analysis")[#text("one of my books")]#text(" (Exercise 2.28, to be precise), I asked the reader to use the embeddings ")#mi("{\\iota_1}")#text(" (or more generally ")#mi("{\\iota_\\lambda}")#text(") to explicitly connect together the pseudoconformal transformation ")#mi("{pc}")#text(" and the conformal transformation ")#mi("{conf}")#text(". It turns out that this connection is a little bit unusual, with the “obvious” guess (namely, that the embeddings ")#mi("{\\iota_\\lambda}")#text(" intertwine ")#mi("{pc}")#text(" and ")#mi("{conf}")#text(") being incorrect, and as such this particular task was perhaps too difficult even for a challenge question. I’ve been asked a couple times to provide the connection more explicitly, so I will do so below the fold.")

#metadata(none) <tao-520c8927cd386fabade2>

#text("To state the connection, it turns out that one must first use separation of variables and restrict to a subclass of solutions to ")#link(<tao-701586026ce95fd464c8>)[#text("(1)")]#text(", namely those of the form ")#metadata(none) <tao-461e35a9bfb0c7ef6f50>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("u(t,x) = e^{-iEt} \\phi(x)")]]

#text("for some energy level ")#mi("{E \\in {\\bf R}}")#text(" and some function ")#mi("{\\phi: {\\bf R}^d \\rightarrow {\\bf C}}")#text(". (The function ")#mi("{\\phi}")#text(" then obeys the ")#emph[#text("time-independent Schrödinger equation")]#text(" ")#mi("{-\\frac{1}{2} \\Delta_{{\\bf R}^d} u = E u}")#text(", although we will not use this equation here.) The connection between ")#mi("{pc}")#text(" and ")#mi("{conf}")#text(" is then as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" Let ")#mi("{u}")#text(" be a solution to ")#link(<tao-701586026ce95fd464c8>)[#text("(1)")]#text(" of the form ")#link(<tao-461e35a9bfb0c7ef6f50>)[#text("(6)")]#text(" for some energy ")#mi("{E}")#text(". Then we have")

#align(center)[#tao-fit-display[#mitex("conf( \\iota_{\\lambda}( pc(u) ) ) = \\iota_{-2E/\\lambda}( pc( u ) )")]]

#text("for any non-zero ")#mi("{\\lambda}")#text(".")
]

#text("Thus, the conformal transformation is not intertwined with the pseudoconformal transformation via the embeddings ")#mi("{\\iota}")#text(", but instead the conformal transformation relates different embeddings of the pseudoconformal transform of a solution ")#mi("{u}")#text(" to ")#link(<tao-701586026ce95fd464c8>)[#text("(1)")]#text(" to each other, where the precise embeddings involved depend on the energy level ")#mi("{E}")#text(" of the original solution ")#mi("{u}")#text(".")

#text("We can verify this proposition by a straightforward calculation. From ")#link(<tao-461e35a9bfb0c7ef6f50>)[#text("(6)")]#text(" and ")#link(<tao-5aa1f565273901eed9bc>)[#text("(2)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("pc(u)(t,x) = \\frac{1}{(it)^{d/2}} \\overline{\\phi}(\\frac{x}{t}) e^{iE/t} e^{i\\left|x\\right|^2/2t}", block: true)]]

#text("and thus by ")#link(<tao-e895942f41b07123875a>)[#text("(5)")]#text(" ")#metadata(none) <tao-62ba50646ed9da5b7b17>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\iota_{\\lambda}(pc(u))(t,x,x_{d+1}) = \\frac{e^{-i\\lambda a}}{(ib/2)^{d/2}} \\overline{\\phi}(\\frac{2x}{b}) e^{2iE / \\lambda b} e^{i\\lambda \\left|x\\right|^2/b}", block: true)]]

#text("where we abbreviate ")#mi("{x = (x_1,\\ldots,x_d)}")#text(" and also introduce the null coordinates ")#mi("{a := t+x_{d+1}}")#text(", ")#mi("{b := t-x_{d+1}}")#text(". Applying ")#link(<tao-e193e5e73d6beceed61d>)[#text("(4)")]#text(" and noting that ")#tao-math("{t^2-\\left|(x,x_{d+1})\\right|^2 = ab - \\left|x\\right|^2}", block: false)#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("conf(\\iota_{\\lambda}(pc(u)))(t,x,x_{d+1})")]]

#text("is equal to")

#align(center)[#tao-fit-display[#tao-math("(ab-\\left|x\\right|^2)^{-d/2} \\frac{e^{-i\\lambda a/(ab-\\left|x\\right|^2)}}{(ib/2(ab-\\left|x\\right|^2))^{d/2}} \\overline{\\phi}(\\frac{2x}{b}) e^{2iE (ab-\\left|x\\right|^2)/ \\lambda b} e^{i\\lambda \\left|x\\right|^2/b(ab-\\left|x\\right|^2)}.", block: true)]]

#text("We can cancel out the factors of ")#tao-math("{(ab-\\left|x\\right|^2)^{-d/2}}", block: false)#text(" to get")

#align(center)[#tao-fit-display[#tao-math("\\frac{e^{-i\\lambda a/(ab-\\left|x\\right|^2)}}{(ib/2)^{d/2}} \\overline{\\phi}(\\frac{2x}{b}) e^{2i\\lambda E (ab-\\left|x\\right|^2)/ \\lambda b} e^{i\\lambda \\left|x\\right|^2/b(ab-\\left|x\\right|^2)}.", block: true)]]

#text("Next, we can combine")

#align(center)[#tao-fit-display[#tao-math("e^{-i\\lambda a/(ab-\\left|x\\right|^2)} e^{i\\lambda \\left|x\\right|^2/b(ab-\\left|x\\right|^2)} = e^{-i\\lambda /b}", block: true)]]

#text("to simplify the previous expression as")

#align(center)[#tao-fit-display[#tao-math("\\frac{e^{-i\\lambda /b}}{(ib/2)^{d/2}} \\overline{\\phi}(\\frac{2x}{b}) e^{2iE (ab-\\left|x\\right|^2)/ \\lambda b}", block: true)]]

#text("which we can rearrange a little as")

#align(center)[#tao-fit-display[#tao-math("\\frac{e^{2iE a / \\lambda}}{(ib/2)^{d/2}} \\overline{\\phi}(\\frac{2x}{b}) e^{-i\\lambda /b} e^{-2i E \\left|x\\right|^2/\\lambda b}.", block: true)]]

#text("Comparing this with ")#link(<tao-62ba50646ed9da5b7b17>)[#text("(7)")]#text(", we see that this expression is equal to ")#mi("{\\iota_{-2E/\\lambda}(pc(u))(t,x,x_{d+1})}")#text(" as desired.")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c93e4cd9252f7f6798d7bf7966c7273860b2d512bacc68ece3fa79d3255e8983-8fd3781da887b224590f64f041a12d74efcb44913c5991ca1250650f21cc0ffe.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of samuelprime")]], [#link("https://terrytao.wordpress.com/2013/02/14/the-pseudoconformal-and-conformal-transformations/#comment-216757")[#strong[#text("samuelprime")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2013")])]

#text("The pseudoconformal transform has the look of the inversion formula for theta functions! Since the free Schrodinger equation is linear it’s enough to check that it can in fact hold for each exponential term involved in theta functions (with suitable choice of constants). So it is interesting that the inversion formula also holds for all solutions to the free Schrodinger equation. Very nice post.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cc89291654d33c46c2d4e5ce2d82a8d9f70acf7988c6411d910a61cd507a6440-4b9e4148c66c6159f5a3b87540a4046294fb5cd0d5b17acab6e5d4440d931a23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mokhtar KIRANE")]], [#link("https://terrytao.wordpress.com/2013/02/14/the-pseudoconformal-and-conformal-transformations/#comment-216777")[#strong[#text("Mokhtar KIRANE")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2013")])]

#text("Please see")#linebreak()#text(" ")#link("http://www3.imperial.ac.uk/newsandeventspggrp/imperialcollege/newssummary/news_17-6-2009-11-29-18?newsid=69042")[#text("http://www3.imperial.ac.uk/newsandeventspggrp/imperialcollege/newssummary/news_17-6-2009-11-29-18?newsid=69042")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cb3280d4a3ac59b59c4cf2c33043f35c9d5c9f277083c51cc4b2e3163aa25a7-6a9cd9f58b7183b2038ce7a394dc5461cc80a5a1b8a2711b65195916592b725c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo de Almeida")]], [#link("https://terrytao.wordpress.com/2013/02/14/the-pseudoconformal-and-conformal-transformations/#comment-216862")[#strong[#text("Marcelo de Almeida")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2013")])]

#text("Mokhtar KIRANE what is this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/02/14/the-pseudoconformal-and-conformal-transformations/#comment-217588")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2013")])]

#text("I don’t know how my name came to this place")#linebreak()#text(" I have no interest in the subject")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cb3280d4a3ac59b59c4cf2c33043f35c9d5c9f277083c51cc4b2e3163aa25a7-6a9cd9f58b7183b2038ce7a394dc5461cc80a5a1b8a2711b65195916592b725c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo de Almeida")]], [#link("https://terrytao.wordpress.com/2013/02/14/the-pseudoconformal-and-conformal-transformations/#comment-217593")[#strong[#text("Marcelo de Almeida")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2013")])]

#text("ok")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c93e4cd9252f7f6798d7bf7966c7273860b2d512bacc68ece3fa79d3255e8983-8fd3781da887b224590f64f041a12d74efcb44913c5991ca1250650f21cc0ffe.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of samuelprime")]], [#link("https://terrytao.wordpress.com/2013/02/14/the-pseudoconformal-and-conformal-transformations/#comment-216867")[#strong[#text("samuelprime")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2013")])]

#text("Maybe worthwhile noting that both pc and conf are order 2 symmetries. So, pc(pc(u)) = u for any function u (even if it doesn’t satisfy the Schrodinger equation). (You may need to add a condition so the transform of u is again defined in the required domain R x R^d.) The same is the case for the conformal symmetry: conf(conf(u)) = u for each u. In view of what I said about theta functions (and which I didn’t state properly in my previous post) they are now invariant functions of pc — so are of pc-eigenvalue 1 (if you choose the parameter constants appropriately in the theta functions). Therefore functions can be decomposed into a sum of an invariant u and one of pc-eigenvalue -1. Proposition 1 (in Terry’s post) shows that these two order 2 symmetries interact in some subtle way. Do you know what pc(conf(u)) is? And how perhaps it could be related to conf(pc) given by Proposition 1? Might give an interesting commutation relation between the two symmetries of order 2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/567d7000471f40d36a2520e0f447a0da8d15c0fddc83e1ae41fb44c7a79d3a3f-c3472ace59adda16c3488b35e8290c137219686f460fd078a8c9bb5cfe4f2b78.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sun's World")]], [#link("https://terrytao.wordpress.com/2013/02/14/the-pseudoconformal-and-conformal-transformations/#comment-222655")[#strong[#text("Sun's World")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2013")])]

#text("how to make a box around proposition 1?")

#emph[#text("[Custom CSS – see ")#link("https://terrytao.wordpress.com/about/")[#text("https://terrytao.wordpress.com/about/")]#text(" -T. ]")]
]
