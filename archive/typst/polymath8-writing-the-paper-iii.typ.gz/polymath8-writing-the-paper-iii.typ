// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/
// Converted to Typst by tao2typ: "2026-10-14T16:37:14.635139+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath8: Writing the paper, III", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath8: Writing the paper, III")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 September 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/")[#text("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("The main purpose of this post is to roll over the discussion from the ")#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/")[#text("previous Polymath8 thread,")]#text(" which has become rather full with comments. We are still writing the paper, but it appears to have stabilised in a ")#link("https://www.dropbox.com/s/16bei7l944twojr/newgap.pdf")[#text("near-final form")]#text(" (source files available ")#link("https://www.dropbox.com/sh/j2r8yia6lkzk2gv/_5Sn7mNN3T")[#text("here")]#text("); the main remaining tasks are proofreading, checking the mathematics, and polishing the exposition. We also have a tentative consensus to submit the paper to ")#link("http://msp.org/ant/about/cover/cover.html")[#text("Algebra and Number Theory")]#text(" when the proofreading is all complete.")

#text("The paper is quite large now (164 pages!) but it is fortunately rather modular, and thus hopefully somewhat readable (particularly regarding the first half of the paper, which does not need any of the advanced exponential sum estimates). The size should not be a major issue for the journal, so I would not seek to artificially shorten the paper at the expense of readability or content.")

#heading(level: 1)[#text("Comments (143)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-2/#comment-248071")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2013")])]

#text("In lines 12, 15 below (3.5), the “")#mi("\\neq")#text("” should be the standard one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-2/#comment-248079")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2013")])]

#text("I am giving a colloquium talk on Zhang’s proof and the polymath8 project on Thursday. Here is a ")#link("http://math.mit.edu/~drew/PrimeGaps.pdf")[#text("draft of my slides")]#text(".")#linebreak()#text(" I would welcome any comments and (especially) corrections. I have tried to give a brief overview of Zhang/GPY and to summarize the main Polymath8 improvements. I necessarily had to surpress a lot of detail, but I hope I haven’t said anything that is actually false by doing so. The last part of the talk focuses on admissible tuples, not because I think this part is particularly important (it obviously isn’t), but it is the easiest piece to explain to a general audience and the area with which I am most familiar. But I would definitely welcome suggestions if anyone thinks I have left out (or underemphasized) something important.")

#text("I also plan to add some graphs and to demo sieving with the applet, but I am still working on these pieces.")

#text("Once I get the talk finalized I can post the latex source in case anyone wants to adapt it for their own use (or just copy pieces of it).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-2/#comment-248083")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2013")])]

#text("Nice slides! Some comments:")

#text("Page 3 of 27: (log t)^k should be (log t)^2")

#text("Page 9 of 27: (??) should be (1)")

#text("Page 12 of 27: I would remark that the implication MPZ[…]->DHL[k,2] was")#linebreak()#text(" published earlier by Motohashi and Pintz.")

#text("Page 17 of 27: I would perhaps mention the H=5414 result that was definite for a while.")

#text("Page 18 of 27: theta should be 1/2")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-2/#comment-248084")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2013")])]

#text("Looks good! Some minor corrections:")

#text("Slide 4: the equals sign in the Hardy-Littlewood conjecture should be a tilde. Also one needs to specify that c_H is positive :)")

#text("Slide 9: LaTeX reference error.")

#text("Slide 11: The first part of this theorem was also essentially proven independently ")#link("http://arxiv.org/abs/math/0602599")[#text("by Motohashi and Pintz")]#text(" (though they didn’t write it so explicitly).")

#text("Slide 17: Very nice compression of the enormous table!")

#text("Slide 18: The second part of this theorem was found shortly before us ")#link("http://arxiv.org/abs/1306.2133")[#text("by Farkas, Pintz, and Revesz")]#text(" (although we discovered it independently).")

#text("Slide 22: A very minor technical point: Strictly speaking, the Brun-Titchmarsh inequality as stated only implies the lower bound on H(k) assuming the prime tuples conjecture. But the Brun-Titchmarsh inequality applies not only to primes in an interval, but any set formed by sieving out one residue class mod p for each p from an interval, and this does give the lower bound on H(k). [Not sure how you would fit this technicality onto one slide though!]")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-2/#comment-248089")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2013")])]

#text("Thanks for the quick feedback! I have posted an updated version of the slides at the link above.")

#text("I didn’t put the k0=720 H=5414 line into the table yet, but I may add it. I do have one question about this — at this point do we regard the 4680 bound in our abstract as any less solid than 5414? (I notice that 4680 still has a question mark on the wiki).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-2/#comment-248091")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2013")])]

#text("Well, the 4680 bound relies on the argument in Section 10 of the paper, which I have gone through line-by-line, and Phillipe has also made some corrections to that part of the paper, but as far as I know we’re the only ones to have seriously looked at that part of the argument. If Emmanuel or Gergely makes it all the way to that section and signs off on it, I’m happy to remove the question mark from the wiki :).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-2/#comment-248097")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2013")])]

#text("Thanks for the clarification — for the moment I went ahead and put in a line with the 5414 bound as well.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8: Writing the paper, IV | What's new")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-2/#comment-248105")[#strong[#text("Polymath8: Writing the paper, IV | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2013")])]

#text("[…] again it is time to roll over the previous discussion thread, which has become rather full with comments. The paper is nearly finished (see also the working […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-2/#comment-248106")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2013")])]

#text("Time to roll over the thread again! Of course, any direct responses to comments here can still be made on this thread, but it will probably be easier for readers to follow new comments if they are made on the fresh thread.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-2/#comment-248110")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2013")])]

#text("Things are settling down, now that I’ve written my grant proposal that I can’t submit. :-p So I started reading through the paper. Here are just some minor typos/comments/questions I found in the first two sections. Feel free to ignore any/all of the comments if you so choose.")

#text("1. In the statement of Theorem 1.2 the reference to Zhang’s paper [79] is given, even though it is listed directly above the theorem. Probably it isn’t needed.")

#text("2. In the first paragraph after Theorem 1.2, there is a list of papers (currently numbered [23, 24, 25, 32, 7, 8, 9]). I was wondering if there was a reason they are not in numerical order.")

#text("3. Sentence above equation 1.1, currently near the top of page 4. It says that GPY “obtained the partial result…”. Perhaps “preliminary result” would be a better way to put it.")

#text("4. Two paragraphs later it says “weakened from of the Elliot-Halberstam conjecture…” The word “from” should be “form”.")

#text("5. Five paragraphs later (currently near the top of page 5), it mentions the “Motohashi-Pintz-Zhang conjecture”. First, I would refer to Claim 2.8 here so the reader knows what this is. Second, I would replace the word “conjecture” with “estimate” (as is done in Claim 2.8). Have any of these authors made a formal conjecture of this form? [If this change is made, perhaps a search-and-replace for “conjecture” in conjunction with MPZ should be done.]")

#text("6. Three paragraphs later (currently near the bottom of page 5 after the offset equation) there is a space missing at the beginning of the sentence “We obtain significant improvements…”")

#text("7. Later in the same paragraph, change “were also obtained” to “are also obtained” to make tenses match.")

#text("8. In the statement of Lemma 1.5, the variable q is used in two ways. In part (i) as a polynomial size variable, and in part (iii) as a modulus with apparently no size restriction. I would recommend a different variable name be used in the first case. Also, does q need to still have polynomial size in part (iii)? [Lemma 1.6 seems to use that restriction, but I may be missing something here.]")

#text("9. In the caption to Figure 1, there is a space missing after the comma in “Specifically,the”")

#text("10. When defining the notation DHL[k_0,2] in Claim 2.1, why not define the fuller notation DHL[k_0,m], so as to make it clear to the reader why there is a 2 here?")

#text("11. Paragraph before Remark 2.5 (currently near the bottom of page 12). In the sentence “It was a crucial progress…” remove “a”.")

#text("12. Two paragraphs after Theorem 2.6, change “Assuming a claim EH[1/2+2\\varpi] with \\varpi>0” to “Assuming the claim E[1/2+2\\varpi] for some \\varpi>0”")

#text("13. Footnote 4, currently at the bottom of page 13: is there a reference to the Bombieri-Davenport result?")

#text("14. Paragraph after Claim 2.8 (currently top of page 14). Change “the residue class modulo all q…” to “the residue class modulo each q….”")

#text("15. Three paragraphs later, the word “barrier” is misspelled as “bareer”")

#text("16. Two paragraphs later it says “for any fixed $a$ such that $1\\leq |x| \\leq x$”. Isn’t the second condition automatically satisfied for a nonzero fixed $a$?")

#text("17. Page 15, offset equation after the ternary divisor function. What does \\Delta(x;a (q)) mean? The first entry of \\Delta should be an arithmetic function with finite support. Also, it isn’t clear what this bound has to do with the ternary divisor bounds.")

#text("18. Paragraph preceding Theorem 2.12 (currently near the top of page 16). Change J_{k_0 -2} to J_{\\nu} in two places, and change the equality j_{k_0 -2} = j_{k_0 -2, 1} by also substituting in \\nu’s.")

#text("19. Top of page 18 change “consider densely divisible integers with prime factors…” by adding the word “squarefree”(near the beginning).")

#text("20. In the statement of Claim 2.15, since 1\\leq q\\leq Q, why does $I$ need to be a bounded set? (Taking $I$ to be the closed interval [1,Q] is the same as making no restriction on $I$, is it not?)")

#text("21. Statement of Theorem 2.17(ii): change “We can prove…” to “We have…” just as in part (i).")

#text("22. Paragraph above Definition 2.20: “Estimating sufficiently precisely these sums…” should probably be reworded, something like “Estimating the sums in a sufficiently precise way…”")

#text("23. Throughout the paper, commas and periods are placed outside of quotation marks, but they should be inside of them. [And yes, I’m not obeying that rule in this post myself!] I recommend a search and replace.")

#text("24. Definition 2.20, part (iii). Don’t you need N\\geq 1, so that the last sentence can hold true (that \\alpha is smoot at scale N)? Also, replace")#linebreak()#text(" “and takes the form…” with “if it takes the form…”.")

#text("That’s it! Hopefully this is helpful.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-2/#comment-248119")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2013")])]

#text("Thanks a lot, I’ll go through the file and correct these some time today…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-2/#comment-248142")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2013")])]

#text("I corrected these; here are comments on some of these points.")

#text("2. In the first paragraph after Theorem 1.2, there is a list of papers (currently numbered [23, 24, 25, 32, 7, 8, 9]). I was wondering if there was a reason they are not in numerical order.")

#text("These are (intended: 25 should have been be last) in chronological order.")

#text("3. Sentence above equation 1.1, currently near the top of page 4. It says that GPY “obtained the partial result…”. Perhaps “preliminary result” would be a better way to put it.")

#text("I think “partial” is better because it wasn’t clear that this was preliminary to the bounded gap property.")

#text("8. Also, does q need to still have polynomial size in part (iii)? [Lemma 1.6 seems to use that restriction, but I may be missing something here")

#text("As the proof explains, there is no restriction on q because we deal separately with q>y and q\\leq y (and for q>y there is at most one term tau(d)^C in the sum, which is << y^{eps} << x^{eps}.)")

#text("13. Footnote 4, currently at the bottom of page 13: is there a reference to the Bombieri-Davenport result?")

#text("I will add the reference — I had forgotten I had inserted this remark.")

#text("16. Two paragraphs later it says “for any fixed $a$ such that $1\\leq |x| \\leq x$”. Isn’t the second condition automatically satisfied for a nonzero fixed $a$?")

#text("This was meant to mean uniformly for such a, so \"fixed\" shouldn't be there.")

#text("17. Page 15, offset equation after the ternary divisor function. What does \\Delta(x;a (q)) mean? The first entry of \\Delta should be an arithmetic function with finite support. Also, it isn’t clear what this bound has to do with the ternary divisor bounds.")

#text("This should have been \\Delta(\\tau_3; a\\ (q))")

#text("20. In the statement of Claim 2.15, since 1\\leq q\\leq Q, why does $I$ need to be a bounded set? (Taking $I$ to be the closed interval [1,Q] is the same as making no restriction on $I$, is it not?)")

#text("This is basically unchanged from the first version, the restriction seems indeed unnecessary. Maybe Terry can comment on why it was put there?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-2/#comment-248177")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2013")])]

#text("The only reason ")#mi("I")#text(" is required to be a bounded set is that so one can interpret the product ")#mi("P_I")#text(" of all the primes in ")#mi("I")#text(" as a finite integer (as opposed to a profinite integer or adele or something more exotic). This restriction also appears in Definition 2.7 and Definition 2.21.")

#text("One could of course restrict to subsets of [1,Q] without loss of generality (and for our application one can take [w,Q] for instance); actually, now that I think about it, the Chinese remainder theorem shows that the I = [1,Q] case implies all the other cases. So maybe a remark after the claim on these points would be in order.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-2/#comment-248181")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2013")])]

#text("Emmanuel, thanks for answering my questions.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246142")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2013")])]

#text("Thank you Terry for adding that sentence at the end of Remark 7.10 in response to my comment from Sept 14th. I’ll take your word for it! – though I do still wonder whether there is sufficient scope for new ideas there (perhaps even new Type II “levels” that for whatever reason do not work at all for Type I methods) to justify a new item in Section 11. Note however that in the last line it should be “supersede”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246211")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2013")])]

#text("A probabilistic interpretation for ")#mi("\\kappa_3")#text(":")

#text("Starting from the definition")

#text("(1) ")#mi("\\kappa_3 := \\sum_{0 \\le J \\le 1/ \\tilde {\\delta}} \\frac{(k_0 - 1)^J}{J!} I_J")

#text("Where")

#text("(2) ")#mi("I_J := \\int_{\\tilde{\\delta} \\le t_1,\\cdots ,t_J \\le \\theta}\\varphi(\\sum_j t_j)\\prod_j(dt_j/t_j)")

#text("and")

#text("(3) ")#mi("\\varphi (t) := [G_{\\tilde{\\theta}}(t, t) /G(0, 0)] 1_{[0, 1]}(t)")

#text("Now observe that the weight function ")#mi("\\prod_j (1/t_j)")#text(" in each J-dim. integral ")#mi("I_J")#text(" is proportional to a joint probability density function of ")#mi("J")#text(" independent identically distributed random variables ")#mi("X_1, \\cdots , X_J")#text(" having a (common) probability density function")

#text("(4) ")#mi("f_X(t) = w(t) / \\log (\\theta / \\tilde{\\delta})")#text(", where")

#text("(4′) ")#mi("w(t) := t^{-1} 1_{[\\tilde{\\delta}, \\theta]}(t)")

#text("Therefore each integral ")#mi("I_J")#text(" can be interpreted as the following expectation")

#text("(5) ")#mi("I_J = C_J E[\\varphi (S_J)]")#text(" , where")

#mi("C_J := \\log^J (\\theta / \\tilde{\\delta})")#text(" , and")

#mi("S_J := \\sum_{j = 0}^J Xj")

#text("Since the probability density of each ")#mi("S_J")#text(" is supported on")#linebreak()#text(" ")#mi("[J \\tilde{\\delta}, J \\theta]")#text(" and ")#mi("\\text{supp} \\varphi = [0, 1]")#text(", (5) implies")

#text("(6) ")#mi("I_J = 0")#text(" whenever ")#mi("J \\ge 1/ \\tilde{\\delta}")

#text("Let ")#mi("f_J")#text(" be the probability density function of ")#mi("S_J")#text(", clearly by (5)")

#text("(7) ")#mi("I_J = C_J \\int_\\mathbb{R} \\varphi(t) f_J(t) dt")

#text("Note that ")#mi("f_J")#text(" is the J-fold convolution of ")#mi("f_X")#text(" with itself, and therefore may be recursively approximated numerically by")

#text("(8) ")#mi("f_J = f_{J-1} * f_X")#text(" for ")#mi("J \\ge 2")

#text("with the initialization ")#mi("f_1 = f_X")#text(".")

#text("Since ")#mi("\\varphi, f_J \\in L^2(\\mathbb{R})")#text(", (7) implies")

#text("(9) ")#mi("I_J = C_J \\langle \\hat{\\varphi}, \\widehat{f_J} \\rangle")

#text("Where “^” denotes Fourier transform and ")#mi("\\langle, \\rangle")#text(" the inner product in ")#mi("L^2(\\mathbb{R})")#text(".")

#text("Since ")#mi("\\widehat{f_J} = \\widehat{f_X}^J")#text(", we have from (4)")

#mi("\\hat{w}^J = C_J \\widehat{f_J}")

#text("Inserting this into (9), we get")

#text("(9′) ")#mi("I_J = \\langle \\hat{\\varphi}, \\hat{w}^J \\rangle")

#text("Since ")#mi("\\varphi, w")#text(" are compactly supported, their Fourier transforms are in fact entire functions. It is easy to verify from (4′) that the Laplace transform of ")#mi("w")#text(" is given by")

#text("(10) ")#mi("W(s) = E_1[\\tilde{\\delta}s] - E_1[\\theta s]")

#text("Where (10) is first proved for ")#mi("s > 0")#text(" and than extended analytically.")

#text("Therefore the Fourier transform of ")#mi("w")#text(" is given by")

#text("(10′) ")#mi("\\hat{w}(\\omega) = W(i \\omega)")

#text("Since we don’t have an explicit expression for the Fourier transform of")#linebreak()#text(" ")#mi("\\varphi")#text(", we use the known bound")

#mi("G_{\\tilde{\\theta}}(t,t)/G(0,0) \\le G(\\tilde{\\theta}) e^{-2 \\eta t}")

#text("So that by (3)")

#text("(11) ")#mi("\\varphi (t) \\le \\psi (t) := G(\\tilde{\\theta}) e^{-2 \\eta t} 1_{[0, 1]}(t)")

#text("Now, by using ")#mi("\\psi")#text(" instead of ")#mi("\\varphi")#text(" in (9′) we get upper bounds for the integrals ")#mi("I_J")#text(". For that we need only the Fourier transform of ")#mi("\\psi")#text(" which is (similarly) found to be")

#text("(12) ")#mi("\\hat{\\psi}(\\omega) = \\Psi(i \\omega)")#text(" , where")

#text("(12′) ")#mi("\\Psi(s) = G(\\tilde{\\theta}) \\frac{1- e^{-s-2\\eta}} {s+2 \\eta}")

#text("is the Laplace transform of ")#mi("\\psi")#text(".")

#text("Therefore, for each ")#mi("I_J")#text(" in (1) we have the upper bound")

#text("(13) ")#mi("I_J \\le \\langle \\hat{\\psi}, \\hat{w}^J \\rangle")

#text("Thus (13) gives (via explicit integral over ")#mi("\\bf R")#text(") an upper bound for each I_J (and therefore for ")#mi("\\kappa_3")#text(".")

#text("Remark: The integrals representing the inner product (13) may be difficult to approximate numerically because of oscillatory integrands, therefore I suggest an effective way to deal with this problem by evaluating an upper bound for the expectation (5) using a quantitative approximation to the CLT distribution for the probability distribution of ")#mi("S_J")#text(" with very few simple parameters of the probability density function ")#mi("f_X")#text(" (using uniform Berry-Esseen bound for small deviation and nonuniform Berry- Esseen bound for larger deviation and a classical large deviation estimates for large deviations). I hope to finish this tomorrow.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246233")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2013")])]

#text("Just a remark about the initials of Polymath: wouldn’t it be more appropriate to replace D.H.J. by something specific to the current project, e.g. S.G. (small gaps)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a91dbbd5705f8085aa4b368877768575736327e83b5112c35d161fc17b40dd-f68febc147b1909b1d766de009db17c4fcd3eef72ebe543fc408a7b0c9d6ad8b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andrescaicedo")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246277")[#strong[#text("andrescaicedo")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2013")])]

#text("This has come up before, see here: ")#link("http://polymathprojects.org/2010/06/29/draft-version-of-polymath4-paper/#comment-2070")[#text("http://polymathprojects.org/2010/06/29/draft-version-of-polymath4-paper/#comment-2070")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246415")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2013")])]

#text("At the end of Section 3.5, maybe it would be nice to include a plot containing all our ")#link("http://math.mit.edu/~primegaps/tuples/ubounds.txt")[#text("upper bounds")]#text(" for H(k), for k up to 5000? For layout’s sake I was wondering how the plots in Section 4 have been made?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246435")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2013")])]

#text("Just generated a plot (h-plot.pdf in the dropbox) for the upper bounds of H(k). Please check if it is useful. It was generated using gnuplot. Please let me know if you need the script to make changes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246480")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2013")])]

#text("Thanks a lot! Maybe I’d like to include the graph of k*log(k) + k as a benchmark, so if you could post the script, that would be nice.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246524")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2013")])]

#text("I temporally put a tar file (H-opt.tar.gz) into the dropbox directory. Please see a simple README file inside. I am not sure the scripts inside are totally platform-independent. If you encounter any problem, I can help to include the graph of k*log(k) + k, or add other information.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246700")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2013")])]

#text("Perhaps a graph of the relative approximation error")

#mi("frac {H(k)}{k \\log k + k} - 1")

#text("may give a better understanding.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246701")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2013")])]

#text("Correction: It should be ")#mi("\\frac {H(k)}{k \\log k +k} -1")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246722")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2013")])]

#text("Generated a plot of the relative approximation error (h-plot-rel.pdf in the dropbox), seems the current H values are normally 1~2% lower than ")#mi("{k \\log k +k}")#text(".")

#emph[#text("[Plot added to paper – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246744")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2013")])]

#text("The description under figure 3 should be updated accordingly (e.g. the relative approximation error of the best known upper bound H(k) by")#linebreak()#text(" ")#mi("k \\log k +k")#text(".)")

#emph[#text("[Fixed – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ebf6302e0d67b9deb354cb529edbd8f475a6fb55a5003b472f23df7b4d2366db-94f09221f7fbaf3b999af5ef8cfb6585fd6f92f359eb736cee14b6634d7d2e7d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246792")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2013")])]

#text("That’s indeed more meaningful, it looks good!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246482")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2013")])]

#text("Thanks for this! I added it to the paper as Figure 2.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246529")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2013")])]

#text("Inspired by Wouter’s idea, I am wondering if it is useful to add plots to show the parts of Theorem 2.22. I put two tentative plots (types_1d10.pdf, for sigma=1/10, and types_1d6.pdf for sigma=1/6) into the dropbox. One usage is for users to verify the relations visually, and have some hints for further improvements (e.g., if (ii) is improved a little bit, it might forms a piecewise linear constraint with (iii)). Maybe somebody can come up with better ideas.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246494")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2013")])]

#text("Good upper bounds for the integrals in ")#mi("\\kappa_1, \\kappa_2, \\kappa_3")#text(":")

#text("1. Since ")#mi("t^{-1}")#text(" is decreasing , integration by parts gives")

#mi("\\kappa_1 \\le  (2 /(k_0 +1)) (1-\\theta)^{(k_0 + 1)/2} / \\theta")

#mi("\\le  (2/ k_0) (1-\\theta)^{k_0 /2} / \\theta")

#text("2. Similarly we have")

#mi("\\kappa_2 \\le (1-1/k_0)(1-\\theta)^{k_0} / \\theta")

#mi("\\le (1-\\theta)^{k_0} / \\theta")

#text("3. The integral in the current bound for ")#mi("\\kappa_3")#text(" is expressible in terms of the exponential integral function ")#mi("E_1")#text(" by")

#mi("E_1[(A+2\\eta) \\tilde{\\delta}] - E_1[(A+2\\eta)\\theta]")

#mi("\\le E_1[(A+2\\eta) \\tilde{\\delta}]")

#text("where the last upper bound is very good (with error")#linebreak()#text(" ")#mi("\\le e^{-(A+2\\eta)\\theta} / [(A+2\\eta)\\theta]")

#text("Therefore, I suggest to avoid the numerical integrals by replacing them with the simple (and quite tight) upper bound above.")

#emph[#text("[I added a footnote regarding this; I checked using Maple that these looser upper bounds for ")#mi("\\kappa_1,\\kappa_2,\\kappa_3")#text(" are still good enough for the purposes of verifying the condition in (2.10), although it is a little tight. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246548")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2013")])]

#text("Perhaps this footnote would look better as a formal remark immediately before or after Remark 2.17.")

#emph[#text("[Moved, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246501")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2013")])]

#text("I’ve gone through the paper a couple times now to fix errant typos, formatting issues, and the like, but now plan to go through the last parts of the paper (Sections 8-11, basically all the post-Deligne stuff) line-by-line, as this is the least well checked portion of the argument. At 164 pages, it is perhaps too much to ask all the active participants to carefully read every line of the paper, but perhaps individual sections could be proofread by one or two of the participants before we are ready to arXiv and submit the paper. (There are also a few small remaining issues to be addressed, which I have highlighted in red in the paper, but these are very minor.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246521")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2013")])]

#text("I’ve gone line-by-line through Section 8. There are a few minor issues that need attention by an ell-adic cohomology expert, but otherwise it all looks OK. I commented out some sheaf-theoretic material that was not actually used in the paper (namely, the construction of a Tate twist – since everything is already normalised to be weight 0 – and also some comments about H^2 weights being algebraic integers).")

#text("On to Section 9…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246653")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2013")])]

#text("I plan to read through everything, but I can only start in earnest some time next week.")

#text("I have started looking at your remarks in the Deligne section and updating/clarifying the text there.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246705")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2013")])]

#text("Just finished proofreading Section 9 line-by-line. I had a brief panic when I discovered that the ")#mi("F(h_1\\overline{q^{\\prime}}, h_2\\overline{q^{\\prime}}, h_3\\overline{q^{\\prime}}, a\\overline{m};b)")#text(" factor had been pulled out of the ")#mi("m")#text(" and ")#mi("q^{\\prime}")#text(" summations, but it turns out that this expression does not actually depend on ")#mi("m")#text(" or ")#mi("q^{\\prime}")#text(" so it is OK.")

#text("Turning now to Section 11…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246549")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2013")])]

#text("I hope to read most of the paper fairly thoroughly in the next few weeks. On the other hand, it might be more efficient to distribute the sections among those who are willing to do the proofreading, so I just signed up for this. We can also wait a bit between the arXiv submission and the journal submission.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246571")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2013")])]

#text("OK. I think if each participant states which sections they are proofreading, we can ensure reasonable coverage of all sections. I would be happy to have a waiting period between the arXiv and journal submissions, though given that the paper is already publicly available in near-final form, this might not be as necessary as with more traditional papers.")

#text("I just gave you write access to the Dropbox folder if you want to make edits directly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246609")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2013")])]

#text("I plan to carefully proof-read Section 3 line-by-line next week (I will also try to at least do a quick read-through of the rest of the paper).")

#text("Also, I am currently working on improving the lower bound on H(632) using a few new tricks. If I am actually able to improve it (which is not clear yet) I may want to add a short subsection explaining this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ebf6302e0d67b9deb354cb529edbd8f475a6fb55a5003b472f23df7b4d2366db-94f09221f7fbaf3b999af5ef8cfb6585fd6f92f359eb736cee14b6634d7d2e7d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246795")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2013")])]

#text("I also plan to do a semi-quick read-through of the whole paper, and to read certain sections in greater detail: sections 1-4 and the more “algebraic” sections 6 and 8.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246508")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2013")])]

#text("In the first line of page 53 (i.e. the line above the inequality for ")#mi("G(t,t)")#text("), it should be ")#mi("t_1 <1")#text(" (instead of ")#mi("t_1 \\le 1")#text(") – since ")#mi("1-t")#text(" appears in the denominator of the expression in the preceding line (last line of page 52.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/538962ce58a139d167d6f782e5df25197f5762e65433e8ee9e04cc5ea234f412-f68febc147b1909b1d766de009db17c4fcd3eef72ebe543fc408a7b0c9d6ad8b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andres Caicedo")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246531")[#strong[#text("Andres Caicedo")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2013")])]

#text("It may be nice to update the AMS Subject Classification to the 2010 version. (The footnote on page 1 still has 1991.)")

#emph[#text("[Fixed – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8aaaa025f9dd35edcc13f449e2b1a88c2c3f8f184e0b316ba07a35b6a45fcbe-2593d0ea9ddef1c4175bff79faf7a35972faebbd77c734f744c5cbc95e9205ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Morphy")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246582")[#strong[#text("Morphy")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2013")])]

#text("Not having access to Zhang’s paper, I don’t know if your Theorem 1.2 is quoted from it. In any case I wonder whether it’s quite fair to Zhang, since as stated it could be a pure existence result, which is not as good as one that provides a bound. Of course his bound is mentioned immediately afterward, but shouldn’t it be part of his theorem, even though its precise value is unimportant?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246608")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2013")])]

#text("Actually Zhang’s main theorem in his paper would read, in the notation of Polymath’s Theorem 2.2, that DHL[k,2] is true for k=3,500,000 and consequently, in the notation of Polymath’s Theorem 1.2, B[H] is true for H=70,000,000. So you have a point: perhaps Polymath’s Theorem 1.2 should be stated in the exact format of Theorem 1.3: B[H] is true for H=70,000,000.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246624")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2013")])]

#text("Fair enough, I’ve changed the wording in Theorem 1.2 and also Theorem 2.2. My initial motivation was so that I could refer to the qualitative versions of these statements (B[H] for some unspecified H, or DHL[k_0,2] for some unspecified k_0) for the purposes of statements such as Remark 2.24, but it turned out to be an easy matter to reword any references to these qualitative statements.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8aaaa025f9dd35edcc13f449e2b1a88c2c3f8f184e0b316ba07a35b6a45fcbe-2593d0ea9ddef1c4175bff79faf7a35972faebbd77c734f744c5cbc95e9205ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Morphy")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246769")[#strong[#text("Morphy")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2013")])]

#text("Thank you for taking account of my concern. But the new wording (“In particular”) is unnatural, because “70,000,000” is normally regarded as a special case of “finite” rather than the other way around. Would the following formulation do for Theorem 1.2, with a parallel one for Theorem 2.2? “B[H] is true for a finite value of H; in fact, for H = 70,000,000.”")

#emph[#text("[“In particular” replaced with “A fortiori” – T.]")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d841279bde782b1cb2e7ccda53cc7961fc14ed2c90a8bc7731bb0c74350c951-eee14fee51eb44b15d62bce8c494cea0959e98139d76d125f021dd3452b6c425.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Check in with Yitang Zhang « Pink Iguana")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246679")[#strong[#text("Check in with Yitang Zhang « Pink Iguana")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2013")])]

#text("[…] Polymath8: Writing the paper, II, here. III, here. The paper is quite large now (164 pages!) but it is fortunately rather modular, and thus […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246687")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2013")])]

#text("I’ve been approached by the editors of the ")#link("http://www.ems-ph.org/journals/journal.php?jrn=news")[#text("Newsletter of the European Mathematical Society")]#text(" to write an article on the polymath project. After some thought, I felt that it would be more appropriate to have an article from the current polymath8 project (and thus authored by “D.H.J. Polymath”, as with the current paper) reflecting on the experience of this project, perhaps with a little speculation on what may and may not work for polymath projects in the future. The editors agreed to this, so I’m now writing to gauge the interest of the other participants for this. There is no hard deadline; I thought we might be able to write something by the end of this calendar year, which was fine with them, and they were looking at something not exceeding 8000 words or 15 pages (their page on author guidelines, by the way, is ")#link("http://www.ems-ph.org/journals/authorinfo.php?jrn=news")[#text("here")]#text(").")

#text("I’m not sure how exactly we would start writing such an article; from a technical perspective presumably we would use the same Dropbox folder as we are currently using for the research paper, but for the writing itself the topic is much more open-ended, and writing the skeletal structure of the paper may well be the hardest part. What I think I may do is start a separate thread to this one to invite people (both active and casual participants) to share their experiences and observations with this project (similar to what was done in ")#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/")[#text("this previous blog post")]#text(" on the 2009 mini polymath), both positive and negative, and then at some point we can try to synthesise these separate points into a coherent article.")

#text("Note that ")#link("http://www.nature.com/nature/journal/v461/n7266/full/461879a.html")[#text("Michael Nielsen and Tim Gowers already wrote an article in Nature on the polymath project")]#text(" as a whole back in 2009; we can refer to that for background while discussing the specific polymath8 project. (I can also write some brief updates about how polymath has developed since then.)")

#text("Anyway, I’d be happy to hear feedback on whether this would be a good idea to pursue. Of course, it would make sense to wait until the research paper is written up and submitted before really working on this sort of report, although conversely if we wait too long then many of the participants might leave or forget about their experiences here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246703")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2013")])]

#text("In the spirit of the Polymath idea, it seems to me that it would be useful for such an article to include individual sections written by participants (and possibly by non-participants), explaining their point of view on the basic idea, as well as on which project they participated. (So the article might look a bit like one of these Notices sections written in honor of mathematicians, with collaborators / colleagues / friends writing short individual sections.)")

#text("In such a case, it would seem that an initial section explaining the original idea might be also important, even if it would probably repeat some of the earlier articles you mention.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246708")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2013")])]

#text("This is an interesting idea, and solves the problem I saw of having to merge together different opinions into a single coherent article. Hopefully we have enough volunteers to write sections to make it an interestingly diverse story…")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246695")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2013")])]

#text("By the way, in case readers haven’t seen it already, there is a new interview with Yitang Zhang at ")#link("http://nautil.us/issue/5/fame/the-twin-prime-hero")[#text("http://nautil.us/issue/5/fame/the-twin-prime-hero")]#text(" (with a brief mention of the polymath8 project).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246707")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2013")])]

#text("In table 1, in the definition of ")#mi("J_{\\nu}")#text(", I suggest to add that it is of order ")#mi("\\nu")#text(".")#linebreak()#text(" In the definition of ")#mi("j_{\\nu}")#text(", it seems clearer to define it as the first positive zero of ")#mi("J_{\\nu}")#text(".")

#emph[#text("[Edited, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246709")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2013")])]

#text("In the definition of ")#mi("j_{\\nu}")#text(", it should be “zero” (instead of “Bessel zero”).")

#emph[#text("[Fixed. thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246712")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2013")])]

#text("I suggest to add to the content the various locations of the tables and figures.")

#emph[#text("[Good suggestion, but I do not know the LaTeX code for doing this in a manner (doing it “by hand” would be rather pointless, as it would not survive the journal typesetting process.) -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246719")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2013")])]

#text("On possible way is to try:")

#text("\\listoftables")#linebreak()#text(" \\listoffigures")

#text("after")

#text("\\tableofcontents")

#text("and to see if the result is quite desired.")

#emph[#text("[I implemented this; it looks a little clunky, but should be improvable – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246785")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2013")])]

#text("I just went quickly through the files to remove overfull hboxs from the LaTeX compilation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246787")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2013")])]

#text("The ratio mentioned in the second line above subsection 3.6 should be updated to the ratio in fig. 3.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246832")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2013")])]

#text("In the second line of remark 2.18, “into” should be inserted before “theorem 2.11”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246833")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2013")])]

#text("I suggest to remark (perhaps in a footnote) that ")#mi("f")#text(" – given by (4.32) – as an optimal weight function, is uniquely determined up to a multiplication by a positive constant.")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246843")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2013")])]

#text("At the request of Erica Klarreich (a mathematics journalist who writes for Quanta magazine), I put together a small javascript applet that illustrates the process of sieving for an admissible 632-tuple of diameter 4680 (the sieved residue classes match the example in the paper when translated to [0,4680]). I’ve posted it at ")#link("https://math.mit.edu/~primegaps/sieve.html?ktuple=632")[#text("https://math.mit.edu/~primegaps/sieve.html?ktuple=632")]#text(" in case anyone wants to check it out.")

#text("The same applet can be used to interactively create new admissible tuples: just use the URL ")#link("https://math.mit.edu/~primegaps/sieve.html")[#text("https://math.mit.edu/~primegaps/sieve.html")]#text(" (leave out the “?ktuple=632”). The default sieve interval is [0,400], but you can change the diameter to any value you like by adding “?d=nnnn” to the URL (e.g. use ")#link("https://math.mit.edu/~primegaps/sieve.html?d=4680")[#text("https://math.mit.edu/~primegaps/sieve.html?d=4680")]#text(" for diameter 4680). The applet will highlight a suggested residue class to sieve in green (corresponding to a greedy choice that doesn’t hit the end points), but you can sieve any classes you like.")

#text("You can also create sieving demos similar to the k=632 example above by specifying a list of residues to sieve. A longer but equivalent version of the “?ktuple=632” URL is")

#link("https://math.mit.edu/~primegaps/sieve.html?d=4680&r=1,1,4,3,2,8,2,14,13,8,29,31,33,28,6,49,21,47,58,35,57,44,1,55,50,57,9,91,87,45,89,50,16,19,122,114,151,66")[#text("https://math.mit.edu/~primegaps/sieve.html?d=4680&r=1,1,4,3,2,8,2,14,13,8,29,31,33,28,6,49,21,47,58,35,57,44,1,55,50,57,9,91,87,45,89,50,16,19,122,114,151,66")]

#text("The numbers listed after “r=” are residue classes modulo increasing primes 2,3,5,7,…, omitting any classes that do not require sieving — the applet will automatically skip such primes (e.g. it skips 151 in the k=632 example).")

#text("A few caveats: You will want to run this on a PC with a reasonably wide display (say 1360 or greater), and I have only tested it on the current versions of Chrome and Firefox (it should work in most browsers but I make no guarantees). Also, the MIT math web server has recently developed the habit of occasionally throwing 403 errors when you try to load a page (I’m told this is being worked on) — if this happens just hit reload.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246847")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2013")])]

#text("Very nice! I’ve added this link to both the paper and the wiki.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246852")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2013")])]

#text("I have begun reading through the paper from the beginning, and I will soon start to make some changes. Since (as my co-authors know…) I often tend to be “aggressive” in attempting changes of notation, style, etc, I will probably create a separate subfolder so that any suggestions I make regarding such matters can be considered without losing track of the current version. One can then use diff/merge tools to combine those changes which are agreed on…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd4ee11e9561e0992302bd40eebde537c101ae33a0d92d3b7989b023a3a577d3-e0c8a4a37da773f1e33327b33382bbc603cf1f00fe1c2f1d21297f602e424cd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alastair Irving")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246854")[#strong[#text("Alastair Irving")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2013")])]

#text("In claim 2.14 I think it should be ")#mi("Q\\lessapprox x^{1/2+2\\varpi}")#text(" rather than ")#mi("x^\\theta")#text(".")

#text("Earlier in section 2 significanty should be significantly.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246855")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2013")])]

#text("I added a folder “ek” with my changes.")

#text("For notation, I suggest:")

#text("\\asymp instead of \\sim (for X << Y << X; this is more standard in the analytic number theory literature)")

#text("\\llcurly instead of \\lessapprox (this is for esthetic typographical reasons, so it is more subjective)")

#text("\\varphi instead of \\phi for the Euler function (again it seems more standard, and slightly nicer, to me)")

#text("and a bold 1 for the characteristic function 1_E of a set.")

#text("The first three are a matter of a renewcommand, and I did a search and replace for the last.")

#text("I also prefer speaking of the Riemann Hypothesis over finite fields instead of the Weil conjectures; strictly speaking, the Weil 2 results of Deligne were never part of the Weil conjectures, and I do not know if even Grothendieck ever explicitly conjectured the main theorem of Weil 2 (although I wouldn't be very surprised if he did…)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246857")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2013")])]

#text("These all sound like good changes to me, and I will certainly defer to you on the nomenclature and history of the Weil conjectures. (A related question: I am unsure as to whether to refer to Weil 2 as a single theorem of Deligne, or as multiple theorems of Deligne; the paper is deliberately ambiguous on this point, but perhaps this could be clarified.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246858")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2013")])]

#text("I think that, for our purpose, there is one main theorem in Weil 2 (behavior of weights under higher direct images), and that this is “the” main theorem. On the other hand, Deligne does on to prove various other results which use this as an ingredient, many of which I don’t really understand… For analytic number theorists, the other main result is the equidistribution theorem, but we are not using it.")

#text("I will add a precise reference to the theorem number that we actually use in Weil 2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246864")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2013")])]

#text("I’ve re-read and made changes in the introduction (see newgap.pdf in the subfolder).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246868")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2013")])]

#text("Looks good to me. There is a space missing before “Additional gains…” in the second paragraph of page 7 of your newgap.pdf, and also the definition of e_q on page 9 is a bit mangled. I wonder if one wants to make more explicit in the intro that we use Deligne Weil II and not just Deligne Weil I (although perhaps the distinction between the two is not so great as the distinction between Deligne and pre-Deligne).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246897")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2013")])]

#text("I think it is worth making the distinction, and for the moment this is done just by pointing out on page 14 that Birch-Bombieri used Weil I to prove the character estimate, and later that we exploit the fact that Weil II gives a much freer formalism for estimates. I will add another remark to this effect in the Deligne section.")

#text("(I think for practical purposes in analytic number theory, the distance pre / after Deligne and Weil I / Weill II are almost as great: it is true that after Weil I, it was in principle possible to prove many estimates for exponential sums in more than one variable, but in practice, the number of people who were able to do this was extremely small, whereas the Weil II formalism is much more accessible.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246876")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2013")])]

#text("Went through Section 10, focusing primarily on the numerology which seems to check out. I’ll refrain from any further major edits for a while so as not to disrupt a subsequent merge with Emmanuel’s edits.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246934")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2013")])]

#text("Dear Terry, a few weeks ago I gave a “low-tech” lecture for incoming graduate students at CEU on bounded gaps and the PolyMath8 project. Please add my lecture notes (")#link("http://www.renyi.hu/~gharcos/gaps.pdf")[#text("http://www.renyi.hu/~gharcos/gaps.pdf")]#text(") to the project webpage (")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")]#text(") if you find them worthwhile.")

#emph[#text("[Added the notes to the wiki – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246964")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2013")])]

#text("@Gergely Harcos: Nice notes! For maps, one should use \\colon instead of : to get the correct spacing. (Sorry for interrupting the thread.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246974")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2013")])]

#text("Thanks for recommending the use of \\colon. As a matter of fact, I like the spacing as it is now. On the other hand, if you have a detailed document or webpage describing the advantages of \\colon, I might give it a try later.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247025")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2013")])]

#text("ftp://ftp.ams.org/pub/tex/doc/amsmath/short-math-guide.pdf")#text(", top of page 8.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247089")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2013")])]

#text("Thank you!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246960")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2013")])]

#text("I am currently reading subtheorems.tex, mostly re-arranging paragraphs (e.g., I suggest moving the lemma on densely divisible properties to gpy.tex, where they are first used).")

#text("I’ve also edited a bit the logic diagram: I suggest merging “Stepanov” and “Weil for curves”, since logically these are essentially the same statements, even if one thinks of two different proofs, and I spelled out GPY. I think it might be reasonable to remove the Siegel-Walfisz input to Bombieri-Vinogradov, or rather to make it an input to the distribution arguments instead (otherwise, one would need to add the large sieve as input to B-V, etc..)")

#text("(In a lighter tone, I am tempted to add the Cauchy-Schwarz inequality as input to (almost) everything…)")

#text("There was an ambiguous sentence in improvements.tex that I also changed.")

#text("All this can be checked in the subfolder.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246969")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2013")])]

#text("Looks good! Regarding Bombieri-Vinogradov, I guess there is an ambiguity here because there are two versions of Bombieri-Vinogradov to refer to here:")

#text("(1) Bombieri-Vinogradov for the von Mangoldt function ")#mi("\\Lambda")#text(", which uses within its proof the Siegel-Walfisz theorem for ")#mi("\\Lambda")

#text("(2) Bombieri-Vinogradov for convolutions ")#mi("\\alpha*\\beta")#text(" in which one of the two convolutions is non-trivial and obeys a Siegel-Walfisz theorem. (this is the version in BFI)")

#text("We have to rely on (2) and not just (1) in our arguments (particularly in the Type I/II estimates), and in that case the logic is indeed as you suggest, whereas the current version of the logic diagram reflects instead (1). But I do want to make the point that we do need just a little bit of multiplicative number theory in the arguments via Siegel-Walfisz (since it is otherwise striking that no zeta functions or L-functions explicitly appear in the argument, unless you count the Weil conjecture stuff).")

#text("Perhaps we could have a single big box for “Bombieri-Vinogradov + Siegel-Walfisz”? That blurs the issue of whether the former depends on the latter, and we wouldn’t have to add more arrows to an already cluttered diagram.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246975")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2013")])]

#text("Just checking: it is possible and natural to deduce (1) from (2) via the Vaughan identity, right?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-246976")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2013")])]

#text("Yes (or from the Heath-Brown identity).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247019")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2013")])]

#text("Thank you!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247008")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2013")])]

#text("Yes, combining both seems indeed to be the best solution. I will do this on the subfolder version of the diagram (which I also export from SVG to a PDF for inclusion in the final file, since I think it gives a nicer result than exporting to PNG.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247076")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2013")])]

#text("I am still reading through subtheorems.tex, and I also corrected a few typos in the bibliography (and updated the logic diagram.) I hope to advance a bit faster tomorrow and Friday.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247081")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2013")])]

#text("Once you are done with subtheorems.tex, it might be a good idea to merge back to the main paper to avoid any bifurcation of the editing process. I plan to have a look at the final section (improvements.tex) in a few days.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247106")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2013")])]

#text("I keep track of the changes in the main folder and merge them with my files, so the two sets can be merged back easily. After subtheorems, I guess that most changes I might want to make would be more cosmetic (typos, etc), so if everyone is OK with the changes I made to the introduction and descriptive sections, there might be no need to have a subfolder. (Although I find it useful to be able to try bigger changes without altering the base files.)")

#text("For the moment, the only influence of the changes I made in the later parts of the paper is that, in the last edit, I changed the names of some parameters in theorem dhl-mpz-2 ( \\tilde\\theta –> \\omega^2 and \\tilde \\delta –> \\xi), just to have a slightly nicer-looking (typographically) statement. I still have to propagate these to the proof of the theorem in gpy.tex.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247079")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2013")])]

#text("A typo: in the line below the three lines of remark 2.9, it should be “of” (instead of “ot”).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247082")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2013")])]

#text("This typo remains now only in the “ek” folder.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247107")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2013")])]

#text("Thanks, I corrected that also on my file.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247127")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2013")])]

#text("More notational cosmetics:")

#text("I have changed the \\Dcal macro to have two arguments (i and y) so that one can try different formatting of this notation. For the moment, I have defined it to be \\mathcal{D}^i(y), partly to avoid the sub/superscript in things like \\Dcal^i_{x^{\\delta}}.")

#text("In fact, \\Dcal is used almost always with an intersection with a set \\Scal_I, so I defined a macro \\DI{I}{i}{y} which is supposed to represent this intersection. It typesets \\mathcal{D}_I^i(y) at the moment, but since it is a macro, we can change that trivially.")

#text("All uses of the notation have been changed in the files in the ek folder.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247134")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2013")])]

#text("A small typo in the ek-version, the paragraph below equation (2.8): there’s an ")#mi("x^\\delta")#text(" that should be ")#mi("y")#text(" (or conversely).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247138")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2013")])]

#text("Thanks, I am correcting this…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247140")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2013")])]

#text("I have finished reading through subtheorems.tex. I will check again if there is any missing additions or corrections in the main folder compared with the subfolder ek, and merge these in my files if this is the case. Then if the changes are considered OK, the files in the subfolder could be copied to the main folder, although a copy of the current state should probably be kept in case some of the changes of notation created problems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PhM")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247146")[#strong[#text("PhM")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2013")])]

#text("We have had some discussion with Paul today about improving further the type I estimates in the improved treatment: the idea would be to exploiting summation in the ")#mi("l")#text(" variable (which is created when performing the factorization ")#mi("r=dr^{\\prime}")#text(" and performing the shift ")#mi("n\\rightarrow n+dl")#text("). It seem that the length ")#mi("L")#text(" of this variable is relatively long compared to the reference modulus $u$ : it seem that in typical situation ")#mi("u=x^{36/75}")#text(", ")#mi("D=x^{16/75}")#text(", ")#mi("L=x^{14/75}>U^{1/3}")#text(" so that one might IN PRINCIPLE perform a VdC in ")#mi("l")#text(" in addition to completion in ")#mi("n")#text(" and VdC in ")#mi("d")#text(" and squezze some extra juice. The question is whether this could be worth the effort because the algebraic geometry gets an extra level of complexity : as a model one would need to check whether the sheaf formed out of the sums")

#mi("\\displaystyle l\\rightarrow p^{-1/2}\\sum_{d}K_f(d)\\overline{K_f(d+1)}")

#text("for ")#mi("f(x,y)=f_l(x,y)")#text(" the rational fraction in the paper with its explicit dependency in ")#mi("l")#text(" contains a quadratic phase in its weight ")#mi("0")#text(" part…")

#text("Do you have an estimate of the potential gain if all worked through ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247155")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2013")])]

#text("I’m already a bit rusty on these calculations, but let me have a stab at it. (The arithmetic needs to be double-checked though.)")

#text("Let’s start with Proposition 10.2 from the paper. Let’s pretend that (cl,u)=1 and that y=1 to simplify things a bit; I also suppress smooth cutoffs. Right now we are bounding")

#mi("\\sum_{l \\sim L} \\sum_{d \\sim D} \\sum_{n \\sim N} e_u( \\frac{cl}{(n+vd+a) (n+(v+l)d+b)} )")

#text("by")

#mi("L (u^{1/2}+\\frac{N}{u^{1/2}}) (1 + D^{1/2} u^{1/6} + \\frac{D}{u^{1/2}} )")

#text("Now I believe a van der Corput in the l variable should, in principle, replace the L with a ")#mi("L^{1/2} u^{1/6}")#text(" factor, saving an additional factor of ")#mi("L^{1/2} u^{-1/6} \\sim N^{1/2}D^{-1/2} u^{-1/6}")#text(". If so, the main constraint of")

#mi("D^{1/2} u^{2/3} \\lessapprox H^{-4} D N")

#text("from (10.27) (ignoring deltas, epsilons,and ")#mi("q_0")#text(") should relax to")

#mi("D^{1/2} u^{2/3} \\lessapprox H^{-4} D N \\times N^{1/2}D^{-1/2} u^{-1/6}")#text(",")

#text("so")

#mi("H^4 u^{5/6} \\lessapprox N^{3/2}.")

#text("using the bound ")#mi("u \\lessapprox R D^{-1}Q^2 H")#text(" this becomes")

#mi("H^{29/6} R^{5/6} Q^{5/3} \\lessapprox N^{3/2} D^{5/6}")

#text("As ")#mi("D \\approx H^{-4} N")#text(", this becomes")

#mi("H^{49/6} R^{5/6} Q^{5/3} \\lessapprox N^{7/3}")#text(";")

#text("as ")#mi("H \\approx x^{-1} Q^2 R  N")#text(", this becomes")

#mi("Q^{18} R^{9} N^{35/6} \\lessapprox x^{49/6}")

#text("Setting ")#mi("QR \\sim x^{1/2+2\\varpi}")#text(" (the worst case), this becomes")

#mi("x^{5/6 + 36 \\varpi} N^{35/6}\\lessapprox R^9")

#text("Since ")#mi("R \\approx N")#text(", this becomes")

#mi("x^{5/6 + 36 \\varpi} \\lessapprox N^{19/6}")#text(";")

#text("Taking ")#mi("N \\approx x^{1/2-\\sigma}")#text(" this becomes")

#mi("\\frac{5}{6} +36 \\varpi < \\frac{19}{6} (\\frac{1}{2}-\\sigma)")

#text("or")

#mi("\\frac{38}{9} \\sigma + 48 \\varpi < 1")#text(";")

#text("setting ")#mi("\\sigma=1/10")#text(", this becomes")

#mi("\\varpi < \\frac{13}{1080} = 0.012\\ldots")

#text("which is slightly better than our current value of ")#mi("\\frac{7}{600} = 0.011666\\ldots")#text(".")

#text("Interpolating xfxie's table at ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0table.html")[#text("http://www.cs.cmu.edu/~xfxie/project/admissible/k0table.html")]#text(" this suggests that ")#mi("k_0")#text(" should be something like 604 or so, which if one plugs into ")#link("http://math.mit.edu/~primegaps/")[#text("http://math.mit.edu/~primegaps/")]#text(" suggests H =4428. But the likelihood of an arithmetic error somewhere in the above is reasonably high (and there is a slight chance also that some of the lower order terms are now no longer lower order)…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247157")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2013")])]

#text("It seems that section 11 should be updated accordingly!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247159")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2013")])]

#text("Well, certainly the paper will have to be amended somehow if this development pans out – though I am worried as to how difficult the algebraic geometry will be. Currently we are using some shortcuts relying on some Fourier identities involving quadratic phases to avoid some difficult conductor bounds, and I would think it unlikely that these identities would continue to suffice for this more complicated argument.")

#text("Given that the current paper is so close to being finalised, I am reluctant to disrupt it too much unless the new argument turns out to be a relatively “cheap” modification of the current one. One possibility could be a second paper (perhaps attached to the ")#link("http://www.math.ethz.ch/~kowalski/transforms.pdf")[#text("upcoming preprint")]#text(" of Fouvry, Kowalski, Michel on bounding conductors, as this may end up relying crucially on the work in that preprint).")

#text("But it is perhaps too soon to decide what to do,the first thing is to check that the argument really works (in principle at least).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247161")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2013")])]

#text("Indeed, and in addition to the conductor bounds (which I think one could possibly “condense” in any given concrete case, by following the techniques in the preprint, although I feel that even this would require at least five pages or so), excluding quadratic phases could be much more delicate now.")

#text("One can try to test (using mean-square estimates) whether the sheaf involved has a chance of being irreducible — if that were the case, the chances of success would be greater, and I will try to see if I can get any information in this direction. (Also if a “generic” absence of quadratic phase, in terms of extra parameters, is sufficient, this might be more accessible.)")

#text("On another note, I incorporated in the subfolder the recent corrections to typei-advanced.tex")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247166")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2013")])]

#text("On a slightly related topic, I was recently asked whether we regard the 4680 bound (and the 14950 bound without Deligne’s theorems) as “solid”. Are we ready yet to remove the question marks from these bounds on the wiki?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247174")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2013")])]

#text("Two technical comments:")

#text("1. It appears that no additional dense divisibility will be needed to incorporate the additional vdC (actually, it’s more like turning a single one-dimensional vdC into a single two-dimensional vdC (in both d and l variables simultaneously) rather than two separate vdC’s (which would require us to start staring at cubic phases, etc.)). One has to factor u in two different ways, one for the d Weyl differencing and one for the l Weyl differencing, but this does not seem to be a difficulty.")

#text("2. One has to take a little care treating the role of q_0, because (as pointed out by Phillippe in an earlier edit of the paper) the l shift affects the modulus n’_0. So we may have to cut the l summation into q_0 residue classes, which costs us an additional factor of q_0, but I think we have enough powers of q_0 to spare that this should not be a problem.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247206")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2013")])]

#text("I’ve rechecked that the files in the subfolder are up-to-date with respect to all corrections or mathematical changes that have been made since I started them. If there is no objection with the notation changes, etc, these files may be copied over to the main folder.")

#text("I started reading narrow.tex…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247241")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2013")])]

#text("I am very busy with other things for the next 1-2 weeks, but once the paper settles after you (and Philippe etc.) review it and incorporate your changes, I will be happy to go through it carefully as I promised.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247297")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2013")])]

#text("I am reading narrow.tex at the moment. In the section on testing admissibility, I had some trouble fully understanding the improved algorithm at first, so I adapted the explanation to the way I understood (in particular, to the way I understood the allusion to a probabilistic model). This write-up in the ek subfolder may therefore be completely wrong-headed and should be checked and probably improved (at least, it should give an idea of how certain readers might misunderstand the original description…)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247299")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2013")])]

#text("Thanks for the feedback, Emmanuel. I’m about to head out for the day, but I will go through your write-up when I get back tonight and see what I can do to clarify things. I was a little unsure about how much detail to put in when I first wrote it, but clearly a bit more explanation is in order.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247311")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2013")])]

#text("Thanks! By the way, is the implementation of the algorithm in the package admisable_v0.1 on your web page?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247340")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2013")])]

#text("No, the v0.1 package doesn’t implement the fast admissibility test. I’ll post an updated version that includes this. I also want to add some documentation (but it may be a few days before I get a chance to do this).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247338")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2013")])]

#text("I read through through your expanded description of the fast admissibility testing algorithm and it looks good, thank you (in particular, the coupon-collector analogy is correct — I tend to think of balls-in-bins, but it amounts to the same thing). There are a few wording tweaks I may want to make, but I’ll wait until you are done with the file.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247368")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2013")])]

#text("You may change directly the current file in the subfolder, since I am now reading the rest of the file and I can easily merge your changes.")

#text("Do you have a standard reference for the various properties of coupon collector / balls in bins that are used for the heuristic analysis of the algorithm? Those I know don’t really discuss, e.g., how many empty bins remain after a given number of steps, but it would be good to add a reference.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247379")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2013")])]

#text("My usual reference for this sort of thing is “Randomized Algorithms” by Motwani and Rhagavan. I’m traveling at the moment and don’t have the book with me but according to Google books, section 3.6 addresses the coupon collector’s problem and includes a proof of the sharp threshold result (originally due to Erdos and Renyi, see ")#link("http://www.renyi.hu/~p_erdos/1961-09.pdf")[#text("http://www.renyi.hu/~p_erdos/1961-09.pdf")]#text("), and related topics.")#linebreak()#text(" It may not have exactly what we need, but the same methods can be applied to our problem (I’ll take a look at this when I get back to Cambridge — in the worst case we can just put in a short proof of the bound we need).")

#text("I did notice one significant typo in the admissibility testing section (due to me, not you). The interval ")#mi("[0,ce(p)]")#text(" should be ")#mi("0,cp/e(p)]")#text("..")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247387")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2013")])]

#text("I will correct the typo. As for precise references, I don’t feel that it’s necessary to add too much details, once we have a decent reference, because as you explain, the probabilistic model is really used only as a guide, and does not intervene in a proof of correctedness of the admissibility test.")#linebreak()#text(" I will also check the book myself tomorrow.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247312")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2013")])]

#text("Another remark: I changed the paragraph skip value in the header of newgap.tex, just because I found some of the gaps in statements of theorems a bit strange. This also makes the paper shorter (quite a bit in fact, it now compiles to 160 pages), but in any case this will be probably also changed by the final journal formatting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247384")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2013")])]

#text("Display in proof of Lemma 7.4, subscript of outer summation: ")#mi("q")#text(" is not needed since it is for individual ")#mi("q")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247394")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2013")])]

#text("Also corrected in the subfolder.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247592")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2013")])]

#text("I am continuing through narrow.tex, though a bit slower because of various other deadlines at work.")#linebreak()#text(" A few questions for Andrew: (1) At the end of Section 3.2, there is mention of something being “invariably” true: is it an experimental fact or a theorem? Still around this point, the fact that m=o(k/log k) is, if I understand right, something proved by Hensley and Richards (similarly to what is explained in Section 3.3), although they consider the “inverse” function to k –> H(k) (which is the function rho^*(x) in their papers). It seems to me that we should explain this, so that the reader is not led to believing that the possibility of taking such an m is obvious.")

#text("I will try to have a write-up of 3.2, 3.3, 3.4 ready today, but changes can also be made to the Dropbox files without danger of editing conflict.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247626")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2013")])]

#text("The parenthetical comment about “invariably” needing to sieve by primes at least up to the square root of the diameter was simply an (experimental/heuristic) observation meant to draw the analogy to the sieve of Eratosthenes. But I don’t think it would be difficult to use the Montgomery-Vaughan lower bound on H(k) to turn it into a theorem (at least asymptotically). One expects to need to sieve by primes up to k/(log k)^c for some c, and a probabilistic model suggests c should be at least 2 (see Gordon and Rodemich section 2.4). So proving a sqrt(k log k) lower bound ought to be very easy, but probably isn’t worth putting in the paper (but feel free to disagree).")

#text("Regarding the claim m=o(k/log k), I agree that this is a non-obvious result of Hensley-Richards that should be cited (it follows from Lemma 5 of their Acta Arithmetica paper).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247627")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2013")])]

#text("Thanks!")#linebreak()#text(" I don’t think it is worth spending too much effort into proving the square root bound. I’ll try to phrase things in such a way that one can see where it comes from, and will propose some wording of the other results.")

#text("I haven’t looked at Gordon and Rodemich (I saw the reference but was traveling yesterday), but I will also do so now.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247630")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2013")])]

#text("Thanks! And of course I should have written that c is likely at most 2, not at least 2 (Gordon and Rodemich conjecture that one can almost always use c=2)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247642")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2013")])]

#text("I have updated the versions of narrow.tex (esp. sections 3.2, 3.3, 3.4) in the subfolder, though the current write-up does not mention the k/(log k)^c issue. As before, you can add / modify / correct all of this…")

#text("I will continue with the rest of this section now…")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb39ff13b507cd80a3e7f3b84ca96c66048f710a8d6c3dcb155983b8384cf63b-3ef2339410cef3f4a091a33c46a26de4be683f0abf8ef232a456d009ecfb359d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247678")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2013")])]

#text("Terry, I think you should pay more time for key ideas rather than checking through small incorrect of such long technical paper.")#linebreak()#text(" thanks !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247711")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2013")])]

#text("Based on ")#link("http://mathoverflow.net/a/144546/766")[#text("this very recent mathoverflow comment")]#text(", it looks like James Maynard may have a new modification of the GPY sieve that improves H from 16 to 12 assuming Elliott-Halberstam (presumably, he has lowered ")#mi("k_0")#text(" from 6 to 5). No details yet. This may possibly lead to an improvement for our current value of H (on top of the potential gain from additional van der Corput raised previously). I am beginning to think that there may well be a Polymath8b project in which a number of further improvements beyond the current headline of 4680 are pursued…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247750")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2013")])]

#text("I have finished reading through narrow.tex, and will begin gpy.tex…")

#text("I expanded a bit Section 3.8 on theoretical lower bounds for H(k).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247755")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2013")])]

#text("By the way, I noticed a slight notational clash in gpy.tex which may need resolving. Right now we are using ")#mi("\\Delta")#text(" for two different things: firstly, following the notation of Zhang, we are using ")#mi("\\Delta(\\alpha; a\\ (q))")#text(" to denote the (signed) discrepancy of ")#mi("\\alpha")#text(" in the residue class ")#mi("a\\ (q)")#text(". Secondly, following the notation of ")#link("http://arxiv.org/abs/math/0602599")[#text("Motohashi and Pintz")]#text(", we are using ")#mi("\\Delta")#text(" to denote a certain multiplicative function related to the GPY sieve, namely ")#mi("\\Delta(d) := \\prod_{p|d} \\frac{k_0}{p}")#text(". The two collide to some extent in gpy.tex and it may be worth renaming one or the other of them, if some other standard name for these sorts of functions are available. The interpretation of ")#mi("\\Delta(d)")#text(", by the way, is the proportion of residue classes modulo ")#mi("d")#text(" that one would like to sieve out.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247758")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2013")])]

#text("I had not noticed that yet, but I will try to come up with a different notation for the Delta multiplicative function. Maybe \\rho (or \\varrho) ? Currently, this letter is only used in narrow.tex (to refer to a notation from Hensley-Richards) and in deligne.tex (for representations), so that there is no risk of confusion.")

#text("At this point, before I start on gpy.tex, I could also move the files from the ek subfolder to the main folder if there is no objection.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247762")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2013")])]

#text("I just went through the first three sections in the ek folder and made some minor changes, but I think it looks great overall and can be merged back into the main folder.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247765")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2013")])]

#text("Great, I’ll wait until you move the files before I make any edits to narrow.tex (which should all be very minor).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247768")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2013")])]

#text("I will move the files right now. I’ll keep on my laptop a copy of the current state of the main folder, just in case (of course Dropbox also keeps track of them.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247766")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2013")])]

#text("I’m updating my previous calculation on what van der Corput in the l variable would give, by now also adding in the dependence on ")#mi("\\delta")#text(" (and also to get an opportunity to double-check the arithmetic). Again, the starting point is Proposition 10.2 from the paper, which (after summing in l) bounds the sum")

#mi("\\sum_{l,d,n} e_u( \\frac{cl}{(n+vd+a)(n+(v+l)d+b)} )")

#text("by")

#mi("(c,u) L (u^{1/2} + N/u^{1/2}) (1 + D^{1/2} u^{1/6} y^{1/6}+ D/u^{1/2} ).")

#text("A van der Corput in L should, in principle, replace the L factor here with ")#mi("L^{1/2} u^{1/6} y^{1/6}")#text(", thus saving a factor of ")#mi("L^{1/2} u^{-1/6} y^{-1/6} \\sim N^{1/2} D^{-1/2} u^{-1/6} x^{-\\delta/6}")#text(" by (10.21) (we ignore epsilons) and bounding ")#mi("y \\leq x^\\delta")#text(". The main constraint")

#mi("D^{1/2} u^{2/3} x^{\\delta/6} \\ll H^{-4} D N")

#text("(ignoring epsilons and ")#mi("q_0")#text(") then gets relaxed to")

#mi("D^{1/2} u^{2/3} x^{\\delta/6} \\ll H^{-4} D N \\times N^{1/2} D^{-1/2} u^{-1/6} x^{-\\delta/6}")

#text("or")

#mi("H^4 u^{5/6} x^{\\delta/3} \\ll N^{3/2}.")

#text("From (10.18), (10.17), (10.11), (10.11) (ignoring ")#mi("q_0")#text(") we have the bound")

#mi("u \\ll (R/D)ST^2Q \\ll R D^{-1} Q^2 x^\\delta H")

#text("and so the previous bound becomes")

#mi("H^{29/6} R^{5/6} Q^{5/3} x^{7\\delta/6} \\ll N^{3/2} D^{5/6}.")

#text("From (10.16), (10.24) we have")

#mi("D \\gg x^{-\\delta} D_1 \\gg x^{-\\delta} H^{-4} N")

#text("so we arrive at")

#mi("H^{49/6} R^{5/6} Q^{5/3} x^{2\\delta} \\ll N^{7/3}.")

#text("Meanwhile, from (10.1),(10.5) we have")

#mi("H \\ll Q^2 R N / x,")

#text("so we arrive at")

#mi("R^{9} Q^{18} N^{35/6} x^{2\\delta} \\ll x^{49/6}.")

#text("As ")#mi("QR \\ll x^{1/2+2\\varpi}")#text(", this becomes")

#mi("x^{5/6 + 36\\varpi + 2\\delta} N^{35/6} \\ll R^9.")

#text("From (10.3) we have ")#mi("R \\gg x^{-\\delta} N")#text(",giving")

#mi("x^{5/6 + 36\\varpi + 11\\delta} \\ll N^{19/6}.")

#text("From (10.2) we have ")#mi("N \\gg x^{1/2-\\sigma}")#text(", giving")

#mi("\\frac{5}{6} + 36 \\varpi+ 11 \\delta < \\frac{19}{6} (\\frac{1}{2}-\\sigma)")

#text("or")

#mi("48 \\varpi + \\frac{44}{3} \\delta + \\frac{38}{9} \\sigma < 1.")

#text("Setting ")#mi("\\sigma=1/10")#text(", this becomes")

#mi("\\frac{1080}{13} \\varpi + \\frac{330}{13} \\delta < 1.")

#text("From the Type II and III estimates respectively we also have the constraints")

#mi("68\\varpi + 14\\delta < 1")

#text("and")

#mi("\\frac{1}{18}+ \\frac{28}{9} \\varpi + \\frac{2}{9} \\delta < \\frac{1}{10}")

#text("or equivalently")

#mi("70 \\varpi + 5 \\delta < 1")

#text("but these are dominated by the main constraint.")

#text("I believe that even with the additional van der Corput we still only need quadruple dense divisibility, so it looks like we have ")#mi("MPZ^{(4)}[\\varpi,\\delta]")#text(" whenever ")#mi("\\frac{1080}{13} \\varpi + \\frac{330}{13} \\delta < 1")#text(". One should now be able to play the optimisation game for Theorem 2.16 and get ")#mi("DHL[k_0,2]")#text(" out if this with ")#mi("k_0")#text(" close to 604, but I didn't attempt to do this (maybe someone already has some optimisation code handy?).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247790")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2013")])]

#text("For this instance, a possible solution is ")#mi("k_0")#text(" = ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi1080d13_603.mpl")[#text("603")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247839")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2013")])]

#text("I confirm this. ")#mi("k_0=603")#text(" also seems to follow from the clean parameters ")#mi("\\delta=1/10000")#text(", ")#mi("\\delta^{\\prime}=1/120")#text(", ")#mi("A=200")#text(". These yield ")#mi("\\epsilon\\approx 4.79\\times 10^{-5}")#text(", ")#mi("2\\kappa_1\\approx 1.10\\times 10^{-5}")#text(", ")#mi("2\\kappa_2\\approx 2.05\\times 10^{-7}")#text(", ")#mi("2\\kappa_3\\approx 1.14\\times 10^{-13}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247844")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2013")])]

#text("In this case ")#mi("k_0^{*} = 600")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247906")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2013")])]

#text("I started reading gpy.tex. Besides minor typos, I had some trouble with the proof of Lemma 4.2, mostly because the statement after “Elementary sieving” is weaker than one can get, and then I couldn’t quite figure out the “by summation by parts” which follows. It seems one uses here a general property of Riemann-integrable functions (which is morally the case k=1, W=1 of the lemma), for which I think a reference might be useful, and I have tried to write things in this way. I might have just missed something obvious — I tend to view summation by parts as involving at least a differentiable function, which is not the case here –, but this might in any case suggest that some readers would have trouble with the first version.")

#text("(I also added in the statement of Lemma 4.2 that it is uniform over equicontinuous functions, since this is used later.)")

#text("As discussed before, I replaced Delta (and Delta^*) with rho and rho^*.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247916")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2013")])]

#text("Oops, the justification for Lemma 4.2 is indeed messed up a bit. The error term I was shooting for here for the elementary sieve was something of the form")

#tao-math("\\sum_{d \\in I: (d,W)=1} = \\frac{\\phi(W)}{W} \\left|I\\right|", block: false)

#text("whenever I is an interval of length exactly W. From this one can estimate the sum ")#mi("\\sum_{(d,W)=1} g(\\frac{\\log a}{\\log R}+\\frac{\\log d}{\\log R}) \\frac{1}{d}")#text(" above and below after partitioning into intervals of size ")#mi("W")#text(", plus some residual intervals at the boundary, by ")#mi("(1+o(1))")#text(" times a Riemann sum for ")#mi("\\frac{\\phi(W)}{W} \\int_{\\log a/\\log R}^\\infty g(t)\\ dt")#text(", plus an error of size (say) ")#mi("O(\\sqrt{\\log R})")#text(" (coming from the region within ")#mi("O(\\sqrt{\\log R})")#text(" from the ends). [One may wish to first restrict to non-negative ")#mi("g")#text(" to justify the upper and lower bounds, but any Riemann-integrable g is the difference of two non-negative Riemann-integrable g.]")

#text("Alternatively one can first prove the lemma for smooth functions ")#mi("g")#text(" (in which case summation by parts should work), and then obtain the general case by approximating a Riemann integrable function ")#mi("g")#text(" by approximating above and below by smooth functions (with error small in L^1). Actually with our current writeup we only need this result for continuous piecewise smooth ")#mi("g")#text(", in which case the summation by parts can I think be justified directly (but one nice thing about having the Riemann integrable case is that it also allows for indicator functions of intervals).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247966")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2013")])]

#text("I’ll try to write a clean and short argument in one of these ways, while continuing reading the section. I don’t think it’s worth losing too much time on this since especially the pieceweise smooth case is very standard.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247907")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2013")])]

#text("I’m not sure if anyone is currently editing section 6, but I noticed a typo in line 5 of the first para: “$q’$ a multiple of $q’$” should by “$q’$ a multiple of $q$”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247908")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2013")])]

#text("I corrected it in both the main folder and the ek subfolder.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247909")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2013")])]

#text("Thanks, there is another typo in line 6 of 6.2 “For arithmetic applications will need…” should be “For arithmetic applications we will need…”")

#text("One minor comment on formatting. With the more compact paragraph spacing you introduced (which I like), I think it would be easier to read if the there was an indent at the beginning of a paragraph (this shouldn’t expand things much, if at all).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247967")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2013")])]

#text("Indeed, just commenting out the “\\parindent 0mm” in newgap.tex gives the standard paragraph indent, which does not change the length of the paper. I did it in the main folder and the subfolder.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247972")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2013")])]

#text("To avoid having only a single line on the last page (p. 163), a “\\vfill” instead of a “\\newpage” would be useful. (I can’t see the TeX files anymore but I guess a \\newpage is used right before the URL (which should be typeset with \\url{} when loading the url package (_after_ hyperref)).)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-247986")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2013")])]

#text("I’ve checked the upper-bound part of gpy.tex, isolating it as a Proposition 4.3. There was a minor problem in the argument (the formula that was (4.15) needs a different function than Phi(d_0) on the right-hand side), but this cancels out with another missing factor, so that the conclusion is unchanged (as it should).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-248027")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2013")])]

#text("I have finished section 4.1. I found a different arithmetic function h(d)/d in Lemma 4.4 than was written (for reasons similar to the previous comment). This should have no effect for the rest of the argument because h(p) is still k_0-1 up to O(1/p), but the computation should be checked again (I will redo it myself later today).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-248059")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2013")])]

#text("Thanks for finding these issues; I looked through the calculations and agree with your fix.")

#text("Some other minor corrections (I thought it safer to list them here rather than try to edit it myself in case of conflict):")

#text("Top of page 45 (three lines after (4.17)): the definition of a_d from (4.8) might be referenced here.")

#text("Just before (4.18): “upper bound” should be “lower bound”.")

#text("Two lines after (4.18): though I like the poetic imagery of “apparition”, perhaps “appearance” would be better here. (In English, the word “apparition” has connotations of being ghostly.)")

#text("Two lines before (4.19) the denominator q-1 should be p-1 instead.")

#text("Second display of Lemma 4.4: a right parenthesis is missing just before ")#mi("\\ll")#text(".")

#text("First display in proof of Lemma 4.4: some factors of ")#mi("\\frac{\\phi(W)}{W} \\log R")#text(" (from (4.15)) are missing, though of course they are harmless. This propagates into the next few estimates.")

#text("End of proof of Lemma 4.4: the period should be outside the parenthetical remark. Also, the final parenthesis of ")#mi("{\\mathcal S}_{(w,+\\infty)}")#text(" here is misplaced.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-248065")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2013")])]

#text("Thanks! I corrected these. I don’t remember writing “apparition”, but although in some context this might be a suggestive wording, it certainly doesn’t feel right here…")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e27f01d862781f71c74a4eb26505afbeea59fa93082ed37dd2a60412a8929258-7cdf7265c0a15cb226a7b4027acda7abae79ed377a762d550944829cf019c8eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arcen")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-248031")[#strong[#text("Arcen")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2013")])]

#text("A loth of math. Thanks for detailed explanation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-248067")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2013")])]

#text("Emmanuel, in section 3.8 It looks like there was a sign change introduced in the RHS of (3.5) (and the next displayed equation) when you made your changes to narrow.tex (Dropbox version 185). I think it should be ")#mi("F(H(k)+1)")#text(" in both cases (for the interval ")#mi("[x+1,x+y]")#text(" the diameter ")#mi("H(k)")#text(" is $y-1$, so $y=H(k)+1$). There is a similar issue in the parenthetical comment immediately following the displayed equation after (3.5).")

#text("I believe Wouter is currently working on narrow.tex, so I won’t make any changes, I just wanted to check that you agree with me (or if not, to understand what I am missing here).")

#text("Also, I think the sentence following (3.5) should say “lower bounds for H(k)”, not upper bounds.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-248069")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2013")])]

#text("Yes, I somehow thought that pi(x+y)-pi(x) means primes in [x,y]… I’ll correct these on my files, and merge the changes, if needed, when Wouter is done with the main files.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ebf6302e0d67b9deb354cb529edbd8f475a6fb55a5003b472f23df7b4d2366db-94f09221f7fbaf3b999af5ef8cfb6585fd6f92f359eb736cee14b6634d7d2e7d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/comment-page-1/#comment-248068")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2013")])]

#text("Hi Drew, yes, I’ve indeed been working on Section 3 today, but I’ll only be able to continue tomorrow. I’ll also fix the H(k) + 1 issue then.")
]
