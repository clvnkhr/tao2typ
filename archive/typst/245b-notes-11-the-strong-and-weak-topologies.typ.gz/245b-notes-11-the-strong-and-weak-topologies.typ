// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/
// Converted to Typst by tao2typ: "2026-10-14T15:17:04.711165+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245B, Notes 11: The strong and weak topologies", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245B, Notes 11: The strong and weak topologies")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 February 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/")[#text("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A ")#link("http://en.wikipedia.org/wiki/Normed_vector_space")[#text("normed vector space")]#text(" ")#mi("{(X, \\| \\|_X)}")#text(" automatically generates a topology, known as the ")#emph[#text("norm topology")]#text(" or ")#emph[#text("strong topology")]#text(" on ")#mi("{X}")#text(", generated by the open balls ")#tao-math("{B(x,r) := \\{ y \\in X: \\left\\|y-x\\right\\|_X < r \\}}", block: false)#text(". A sequence ")#mi("{x_n}")#text(" in such a space ")#emph[#text("converges strongly")]#text(" (or ")#emph[#text("converges in norm")]#text(") to a limit ")#mi("{x}")#text(" if and only if ")#tao-math("{\\left\\|x_n-x\\right\\|_X \\rightarrow 0}", block: false)#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". This is the topology we have implicitly been using in our previous discussion of normed vector spaces.")

#text("However, in some cases it is useful to work in topologies on vector spaces that are weaker than a norm topology. One reason for this is that many important modes of convergence, such as ")#link("http://en.wikipedia.org/wiki/Pointwise_convergence")[#text("pointwise convergence")]#text(", ")#link("http://en.wikipedia.org/wiki/Convergence_in_measure")[#text("convergence in measure")]#text(", smooth convergence, or convergence on compact subsets, are not captured by a norm topology, and so it is useful to have a more general theory of ")#link("http://en.wikipedia.org/wiki/Topological_vector_space")[#text("topological vector spaces")]#text(" that contains these modes. Another reason (of particular importance in PDE) is that the norm topology on infinite-dimensional spaces is so strong that very few sets are compact or pre-compact in these topologies, making it difficult to apply ")#emph[#text("compactness methods")]#text(" in these topologies. Instead, one often first works in a weaker topology, in which compactness is easier to establish, and then somehow upgrades any weakly convergent sequences obtained via compactness to stronger modes of convergence (or alternatively, one abandons strong convergence and exploits the weak convergence directly). Two basic weak topologies for this purpose are the ")#link("http://en.wikipedia.org/wiki/Weak_topology")[#text("weak topology")]#text(" on a normed vector space ")#mi("{X}")#text(", and the ")#link("http://en.wikipedia.org/wiki/Weak_topology")[#text("weak* topology")]#text(" on a dual vector space ")#mi("{X^*}")#text(". Compactness in the latter topology is usually obtained from the ")#link("http://en.wikipedia.org/wiki/Banach%E2%80%93Alaoglu_theorem")[#text("Banach-Alaoglu theorem")]#text(" (and its sequential counterpart), which will be a quick consequence of the ")#link("http://en.wikipedia.org/wiki/Tychonoff%27s_theorem")[#text("Tychonoff theorem")]#text(" (and its sequential counterpart) from the previous lecture.")

#text("The strong and weak topologies on normed vector spaces also have analogues for the space ")#mi("{B(X \\rightarrow Y)}")#text(" of bounded linear operators from ")#mi("{X}")#text(" to ")#mi("{Y}")#text(", thus supplementing the operator norm topology on that space with two weaker topologies, which (somewhat confusingly) are named the ")#link("http://en.wikipedia.org/wiki/Strong_operator_topology")[#text("strong operator topology")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Weak_operator_topology")[#text("weak operator topology")]#text(".")

#metadata(none) <tao-be645e3aee10ec81a8a4>

#heading(level: 1)[#strong[#text(" — 1. Topological vector spaces — ")]]

#text("We begin with the definition of a ")#emph[#text("topological vector space")]#text(", which is a space with suitably compatible topological and vector space structures on it.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1")]#text(" A ")#emph[#text("topological vector space")]#text(" ")#mi("{V = (V,{\\mathcal F})}")#text(" is a real or complex vector space ")#mi("{V}")#text(", together with a topology ")#mi("{{\\mathcal F}}")#text(" such that the addition operation ")#mi("{+: V \\times V \\rightarrow V}")#text(" and the scalar multiplication operation ")#mi("{\\cdot: {\\bf R} \\times V \\rightarrow V}")#text(" or ")#mi("{\\cdot: {\\bf C} \\times V \\rightarrow V}")#text(" is jointly continuous in both variables (thus, for instance, ")#mi("{+}")#text(" is continuous from ")#mi("{V \\times V}")#text(" with the product topology to ")#mi("{V}")#text(").")
]

#text("It is an easy consequence of the definitions that the translation maps ")#mi("{x \\mapsto x + x_0}")#text(" for ")#mi("{x_0 \\in V}")#text(" and the dilation maps ")#mi("{x \\mapsto \\lambda \\cdot x}")#text(" for non-zero scalars ")#mi("{\\lambda}")#text(" are homeomorphisms on ")#mi("{V}")#text("; thus for instance the translation or dilation of an open set (or a closed set, a compact set, etc.) is open (resp. closed, compact, etc.). We also have the usual limit laws: if ")#mi("{x_n \\rightarrow x}")#text(" and ")#mi("{y_n \\rightarrow y}")#text(" in a topological vector space, then ")#mi("{x_n + y_n \\rightarrow x+y}")#text(", and if ")#mi("{\\lambda_n \\rightarrow \\lambda}")#text(" in the field of scalars, then ")#mi("{\\lambda_n x_n \\rightarrow \\lambda x}")#text(". (Note how we need joint continuity here; if we only had continuity in the individual variables, we could only conclude that ")#mi("{x_n+y_n \\rightarrow x+y}")#text(" (for instance) if one of ")#mi("{x_n}")#text(" or ")#mi("{y_n}")#text(" was constant.)")

#text("We now give some basic examples of topological vector spaces.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Show that every normed vector space is a topological vector space, using the balls ")#mi("{B(x,r)}")#text(" as the base for the topology. Show that the same statement holds if the vector space is quasi-normed rather than normed.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" ")#metadata(none) <tao-73850adc8e9319594baa>#text(" Every semi-normed vector space is a topological vector space, again using the balls ")#mi("{B(x,r)}")#text(" as a base for the topology. This topology is Hausdorff if and only if the semi-norm is a norm.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" Any linear subspace of a topological vector space is again a topological vector space (with the induced topology).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Let ")#mi("{V}")#text(" be a vector space, and let ")#mi("{({\\mathcal F}_\\alpha)_{\\alpha \\in A}}")#text(" be a (possibly infinite) family of topologies on ")#mi("{V}")#text(", each of which turning ")#mi("{V}")#text(" into a topological vector space. Let ")#mi("{{\\mathcal F} := \\bigvee_{\\alpha \\in A} {\\mathcal F}_\\alpha}")#text(" be the topology generated by ")#mi("{\\bigcup_{\\alpha \\in A} {\\mathcal F}_\\alpha}")#text(" (i.e. it is the weakest topology that contains all of the ")#mi("{{\\mathcal F}_\\alpha}")#text(". Show that ")#mi("{(V, {\\mathcal F})}")#text(" is also a topological vector space. Also show that a sequence ")#mi("{x_n \\in V}")#text(" converges to a limit ")#mi("{x}")#text(" in ")#mi("{{\\mathcal F}}")#text(" if and only if ")#mi("{x_n \\rightarrow x}")#text(" in ")#mi("{{\\mathcal F}_\\alpha}")#text(" for all ")#mi("{\\alpha \\in A}")#text(". (The same statement also holds if sequences are replaced by nets.) In particular, by Exercise ")#link(<tao-73850adc8e9319594baa>)[#text("2")]#text(", we can talk about the topological vector space ")#mi("{V}")#text(" generated by a family of semi-norms ")#mi("{(\\| \\|_\\alpha)_{\\alpha \\in A}}")#text(" on ")#mi("{V}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Let ")#mi("{T: V \\rightarrow W}")#text(" be a linear map between vector spaces. Suppose that we give ")#mi("{V}")#text(" the topology induced by a family of semi-norms ")#mi("{(\\| \\|_{V_\\alpha})_{\\alpha \\in A}}")#text(", and ")#mi("{W}")#text(" the topology induced by a family of semi-norms ")#mi("{(\\| \\|_{W_\\beta})_{\\beta \\in B}}")#text(". Show that ")#mi("{T}")#text(" is continuous if and only if, for each ")#mi("{\\beta \\in B}")#text(", there exists a finite subset ")#mi("{A_\\beta}")#text(" of ")#mi("{A}")#text(" and a constant ")#mi("{C_\\beta}")#text(" such that ")#tao-math("{\\left\\| Tf\\right\\|_{W_\\beta} \\leq C_\\beta \\sum_{\\alpha \\in A_\\beta} \\left\\| f\\right\\|_{V_\\alpha}}", block: false)#text(" for all ")#mi("{f \\in V}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2 (Pointwise convergence)")]#text(" Let ")#mi("{X}")#text(" be a set, and let ")#mi("{{\\bf C}^X}")#text(" be the space of complex-valued functions ")#mi("{f: X \\rightarrow {\\bf C}}")#text("; this is a complex vector space. Each point ")#mi("{x \\in X}")#text(" gives rise to a seminorm ")#tao-math("{\\left\\| f\\right\\|_x := \\left|f(x)\\right|}", block: false)#text(". The topology generated by all of these seminorms is the ")#emph[#text("topology of pointwise convergence")]#text(" on ")#mi("{{\\bf C}^X}")#text(" (and is also the product topology on this space); a sequence ")#mi("{f_n \\in {\\bf C}^X}")#text(" converges to ")#mi("{f}")#text(" in this topology if and only if it converges pointwise. Note that if ")#mi("{X}")#text(" has more than one point, then none of the semi-norms individually generate a Hausdorff topology, but when combined together, they do.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3 (Uniform convergence)")]#text(" Let ")#mi("{X}")#text(" be a topological space, and let ")#mi("{C(X)}")#text(" be the space of complex-valued continuous functions ")#mi("{f: X \\rightarrow {\\bf C}}")#text(". If ")#mi("{X}")#text(" is not compact, then one does not expect functions in ")#mi("{C(X)}")#text(" to be bounded in general, and so the sup norm does not necessarily make ")#mi("{C(X)}")#text(" into a normed vector space. Nevertheless, one can still define “balls” ")#mi("{B(f,r)}")#text(" in ")#mi("{C(X)}")#text(" by")

#align(center)[#tao-fit-display[#tao-math("B(f,r) := \\{ g \\in C(X): \\sup_{x \\in X} \\left|f(x)-g(x)\\right| \\leq r \\}", block: true)]]

#text("and verify that these form a base for a topological structure on the vector space, although it is not quite a topological vector space structure because multiplication is no longer continuous. A sequence ")#mi("{f_n \\in C(X)}")#text(" converges in this topology to a limit ")#mi("{f \\in C(X)}")#text(" if and only if ")#mi("{f_n}")#text(" converges uniformly to ")#mi("{f}")#text(", thus ")#tao-math("{\\sup_{x \\in X} \\left|f_n(x) -f(x)\\right|}", block: false)#text(" is finite for sufficiently large ")#mi("{n}")#text(" and converges to zero as ")#mi("{n \\rightarrow \\infty}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4 (Uniform convergence on compact sets)")]#text(" ")#metadata(none) <tao-e8330a34cb9612ed5bb5>#text(" Let ")#mi("{X}")#text(" and ")#mi("{C(X)}")#text(" be as in the previous example. For every compact subset ")#mi("{K}")#text(" of ")#mi("{X}")#text(", we can define a seminorm ")#mi("{\\| \\|_{C(K)}}")#text(" on ")#mi("{C(X)}")#text(" by ")#tao-math("{\\left\\|f\\right\\|_{C(K)} := \\sup_{x \\in K} \\left|f(x)\\right|}", block: false)#text(". The topology generated by all of these seminorms (as ")#mi("{K}")#text(" ranges over all compact subsets of ")#mi("{X}")#text(") is called the ")#emph[#text("topology of uniform convergence on compact sets")]#text("; it is stronger than the topology of poitnwise convergence but weaker than the topology of uniform convergence. Indeed, a sequence ")#mi("{f_n \\in C(X)}")#text(" converges to ")#mi("{f \\in C(X)}")#text(" in this topology if and only if ")#mi("{f_n}")#text(" converges uniformly to ")#mi("{f}")#text(" on each compact set.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Show that an arbitrary product of topological vector spaces (endowed with the product topology) is again a topological vector space. [I am not sure if the same statement is true for the box topology; I believe it is false.]")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Show that a topological vector space is Hausdorff if and only if the origin ")#mi("{\\{0\\}}")#text(" is closed. (")#emph[#text("Hint")]#text(": first use the continuity of addition to prove the lemma that if ")#mi("{V}")#text(" is an open neighbourhood of ")#mi("{0}")#text(", then there exists another open neighbourhood ")#mi("{U}")#text(" of ")#mi("{0}")#text(" such that ")#mi("{U+U \\subset V}")#text(", i.e. ")#mi("{u+u^{\\prime} \\in V}")#text(" for all ")#mi("{u,u^{\\prime} \\in U}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 5 (Smooth convergence)")]#text(" ")#metadata(none) <tao-19b738c219c435150a1b>#text(" Let ")#mi("{C^\\infty([0,1])}")#text(" be the space of smooth functions ")#mi("{f: [0,1] \\rightarrow {\\bf C}}")#text(". One can define the ")#mi("{C^k}")#text(" norm on this space for any non-negative integer ")#mi("{k}")#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{C^k} := \\sum_{j=0}^k \\sup_{x \\in [0,1]} \\left|f^{(j)}(x)\\right|,", block: true)]]

#text("where ")#mi("{f^{(j)}}")#text(" is the ")#mi("{j^{th}}")#text(" derivative of ")#mi("{f}")#text(". The topology generated by all the ")#mi("{C^k}")#text(" norms for ")#mi("{k=0,1,2,\\ldots}")#text(" is the ")#emph[#text("smooth topology")]#text(": a sequence ")#mi("{f_n}")#text(" converges in this topology to a limit ")#mi("{f}")#text(" if ")#mi("{f_n^{(j)}}")#text(" converges uniformly to ")#mi("{f^{(j)}}")#text(" for each ")#mi("{j \\geq 0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7 (Convergence in measure)")]#text(" Let ")#mi("{(X,{\\mathcal X},\\mu)}")#text(" be a measure space, and let ")#mi("{L(X)}")#text(" be the space of measurable functions ")#mi("{f: X \\rightarrow {\\bf C}}")#text(". Show that the sets")

#align(center)[#tao-fit-display[#tao-math("B(f,\\epsilon,r) := \\{ g \\in L(X): \\mu( \\{ x: \\left|f(x)-g(x)\\right| \\geq r \\} < \\epsilon ) \\}", block: true)]]

#text("for ")#mi("{f \\in L(X)}")#text(", ")#mi("{\\epsilon > 0}")#text(", ")#mi("{r > 0}")#text(" form the base for a topology that turns ")#mi("{L(X)}")#text(" into a topological vector space, and that a sequence ")#mi("{f_n \\in L(X)}")#text(" converges to a limit ")#mi("{f}")#text(" in this topology if and only if it converges in measure.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Let ")#mi("{[0,1]}")#text(" be given the usual Lebesgue measure. Show that the vector space ")#mi("{L^\\infty([0,1])}")#text(" cannot be given a topological vector space structure in which a sequence ")#mi("{f_n \\in L^\\infty([0,1])}")#text(" converges to ")#mi("{f}")#text(" in this topology if and only if it converges almost everywhere. (Hint: construct a sequence ")#mi("{f_n}")#text(" in ")#mi("{L^\\infty([0,1])}")#text(" which does not converge pointwise a.e. to zero, but such that every subsequence has a further subsequence that converges a.e. to zero, and use Exercise 7′ from ")#link("https://terrytao.wordpress.com/2009/01/30/254a-notes-8-a-quick-review-of-point-set-topology/")[#text("Notes 8")]#text(".) Thus almost everywhere convergence is not “topologisable” in general.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9 (Algebraic topology)")]#text(" Recall that a subset ")#mi("{U}")#text(" of a real vector space ")#mi("{V}")#text(" is ")#emph[#text("algebraically open")]#text(" if the sets ")#mi("{\\{ t \\in {\\bf R}: x+tv \\in U \\}}")#text(" are open for all ")#mi("{x,v \\in V}")#text(".")

#list(
[#text("(i) Show that any set which is open in a topological vector space, is also algebraically open.")],
[#text("(ii) Give an example of a set in ")#mi("{{\\bf R}^2}")#text(" which is algebraically open, but not open in the usual topology. (Hint: a line intersects the unit circle in at most two points.)")],
[#text("(iii) Show that the collection of algebraically open sets in ")#mi("{V}")#text(" is a topology.")],
[#text("(iv) Show that the collection of algebraically open sets in ")#mi("{{\\bf R}^2}")#text(" does ")#emph[#text("not")]#text(" give ")#mi("{{\\bf R}^2}")#text(" the structure of a topological vector space.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Quotient topology)")]#text(" Let ")#mi("{V}")#text(" be a topological vector space, and let ")#mi("{W}")#text(" be a subspace of ")#mi("{V}")#text(". Let ")#mi("{V/W := \\{ v+W: v \\in V \\}}")#text(" be the space of cosets of ")#mi("{W}")#text("; this is a vector space. Let ")#mi("{\\pi: V \\rightarrow V/W}")#text(" be the coset map ")#mi("{\\pi(v) := v+W}")#text(". Show that the collection of sets ")#mi("{U \\subset V/W}")#text(" such that ")#mi("{\\pi^{-1}(U)}")#text(" is open gives ")#mi("{V/W}")#text(" the structure of a topological vector space. If ")#mi("{V}")#text(" is Hausdorff, show that ")#mi("{V/W}")#text(" is Hausdorff if and only if ")#mi("{W}")#text(" is closed in ")#mi("{V}")#text(".")
]

#text("Some (but not all) of the concepts that are definable for normed vector spaces, are also definable for the more general category of topological vector spaces. For instance, even though there is no metric structure, one can still define the notion of a Cauchy sequence ")#mi("{x_n \\in V}")#text(" in a topological vector space: this is a sequence such that ")#mi("{x_n-x_m \\rightarrow 0}")#text(" as ")#mi("{n,m \\rightarrow \\infty}")#text(" (or more precisely, for any open neighbourhood ")#mi("{U}")#text(" of ")#mi("{0}")#text(", there exists ")#mi("{N >0}")#text(" such that ")#mi("{x_n-x_m \\in U}")#text(" for all ")#mi("{n,m \\geq N}")#text("). It is then possible to talk about a topological vector space being ")#emph[#text("complete")]#text(" (i.e. every Cauchy sequence converges). (From a more abstract perspective, the reason we can define notions such as completeness is because a topological vector space has something better than a topological structure, namely a ")#link("http://en.wikipedia.org/wiki/Uniform_space")[#text("uniform structure")]#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" As we have seen in previous lectures, complete normed vector spaces (i.e. Banach spaces) enjoy some very nice properties. Some of these properties (e.g. the ")#link("http://en.wikipedia.org/wiki/Uniform_boundedness_principle")[#text("uniform boundedness principle")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Open_mapping_theorem_(functional_analysis)")[#text("open mapping theorem")]#text(" extend to a slightly larger class of complete topological vector spaces, namely the ")#link("http://en.wikipedia.org/wiki/Fr%C3%A9chet_space")[#text("Fréchet spaces")]#text(". A ")#emph[#text("Fréchet space")]#text(" is a complete Hausdorff topological vector space whose topology is generated by an at most countable family of semi-norms; examples include the space ")#mi("{C^\\infty([0,1])}")#text(" from Exercise ")#link(<tao-19b738c219c435150a1b>)[#text("5")]#text(" or the uniform convergence on compact sets topology from Exercise ")#link(<tao-e8330a34cb9612ed5bb5>)[#text("4")]#text(" in the case when ")#mi("{X}")#text(" is ")#link("http://en.wikipedia.org/wiki/%CE%A3-finite_measure")[#mi("{\\sigma}")#text("-compact")]#text(". We will however not study Fréchet spaces systematically here.")
]

#text("One can also extend the notion of a ")#link("http://en.wikipedia.org/wiki/Dual_space")[#text("dual space")]#text(" ")#mi("{V^*}")#text(" from normed vector spaces to topological vector spaces in the obvious manner: the dual space ")#mi("{V^*}")#text(" of a topological space is the space of continuous linear functionals from ")#mi("{V}")#text(" to the field of scalars (either ")#mi("{{\\bf R}}")#text(" or ")#mi("{{\\bf C}}")#text(", depending on whether ")#mi("{V}")#text(" is a real or complex vector space). This is clearly a vector space. Unfortunately, in the absence of a norm on ")#mi("{V}")#text(", one cannot define the analogue of the norm topology on ")#mi("{V^*}")#text("; but as we shall see below, there are some weaker topologies that one can still place on this dual space.")

#heading(level: 1)[#strong[#text(" — 2. Compactness in the strong topology — ")]]

#text("We now return to normed vector spaces, and briefly discuss compactness in the strong (or norm) topology on such spaces. In finite dimensions, the ")#link("http://en.wikipedia.org/wiki/Heine-Borel_theorem")[#text("Heine-Borel theorem")]#text(" tells us that a set is compact if and only if it is closed and bounded. In infinite dimensions, this is not enough, for two reasons. Firstly, compact sets need to be complete, so we are only likely to find many compact sets when the ambient normed vector space is also complete (i.e. it is a Banach space). Secondly, compact sets need to be totally bounded, rather than merely bounded, and this is quite a stringent condition. Indeed it forces compact sets to be “almost finite-dimensional” in the following sense:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Let ")#mi("{K}")#text(" be a subset of a Banach space ")#mi("{V}")#text(". Show that the following are equivalent:")

#list(
[#text("(i) ")#mi("{K}")#text(" is compact.")],
[#text("(ii) ")#mi("{K}")#text(" is sequentially compact.")],
[#text("(iii) ")#mi("{K}")#text(" is closed and bounded, and for every ")#mi("{\\epsilon > 0}")#text(", ")#mi("{K}")#text(" lies in the ")#mi("{\\epsilon}")#text("-neighbourhood ")#tao-math("{\\{ x \\in V: \\left\\|x-y\\right\\| < \\epsilon \\text{ for some } y \\in W \\}}", block: false)#text(" of a finite-dimensional subspace ")#mi("{W}")#text(" of ")#mi("{V}")#text(".")]
)

#text("Suppose furthermore that there is a nested sequence ")#mi("{V_1 \\subset V_2 \\subset \\ldots}")#text(" of finite-dimensional subspaces of ")#mi("{V}")#text(" such that ")#mi("{\\bigcup_{n=1}^\\infty V_n}")#text(" is dense. Show that the following statement is equivalent to the first three:")

#list(
[#text("(iv) ")#mi("{K}")#text(" is closed and bounded, and for every ")#mi("{\\epsilon > 0}")#text(" there exists an ")#mi("{n}")#text(" such that ")#mi("{K}")#text(" lies in the ")#mi("{\\epsilon}")#text("-neighbourhood of ")#mi("{V_n}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 6")]#text(" Let ")#mi("{1 \\leq p < \\infty}")#text(". In order for a set ")#mi("{K \\subset \\ell^p({\\bf N})}")#text(" to be compact in the strong topology, it needs to be closed and bounded, and also ")#emph[#text("uniformly ")#mi("{p^{th}}")#text("-power integrable at spatial infinity")]#text(" in the sense that for every ")#mi("{\\epsilon > 0}")#text(" there exists ")#mi("{n > 0}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("(\\sum_{m > n} \\left|f(m)\\right|^p)^{1/p} \\leq \\epsilon", block: true)]]

#text("for all ")#mi("{f \\in K}")#text(". Thus, for instance, the “moving bump” example ")#mi("{\\{ e_1, e_2, e_3, \\ldots \\}}")#text(", where ")#mi("{e_n}")#text(" is the sequence which equals ")#mi("{1}")#text(" on ")#mi("{n}")#text(" and zero elsewhere, is not uniformly ")#mi("{p^{th}}")#text(" power integrable and thus not a compact subset of ")#mi("{\\ell^p({\\bf N})}")#text(", despite being closed and bounded.")

#text("For “continuous” ")#mi("{L^p}")#text(" spaces, such as ")#mi("{L^p({\\bf R})}")#text(", uniform integrability at spatial infinity is not sufficient to force compactness in the strong topology; one also needs some uniform integrability at very fine scales, which can be described using harmonic analysis tools such as the Fourier transform. We will not discuss this topic here.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" ")#metadata(none) <tao-4b9df800fa2069382c23>#text(" Let ")#mi("{V}")#text(" be a normed vector space.")

#list(
[#text("If ")#mi("{W}")#text(" is a finite-dimensional subspace of ")#mi("{V}")#text(", and ")#mi("{x \\in V}")#text(", show that there exists ")#mi("{y \\in W}")#text(" such that ")#tao-math("{\\left\\|x-y\\right\\| \\leq \\left\\|x-y^{\\prime}\\right\\|}", block: false)#text(" for all ")#mi("{y^{\\prime} \\in W}")#text(". Give an example to show that ")#mi("{y}")#text(" is not necessarily unique (in contrast to the situation with Hilbert spaces).")],
[#text("If ")#mi("{W}")#text(" is a finite-dimensional proper subspace of ")#mi("{V}")#text(", show that there exists ")#mi("{x \\in V}")#text(" with ")#tao-math("{\\left\\|x\\right\\|=1}", block: false)#text(" such that ")#tao-math("{\\left\\|x-y\\right\\| \\geq 1}", block: false)#text(" for all ")#mi("{y \\in W}")#text(". (cf. the ")#link("http://en.wikipedia.org/wiki/Riesz%27s_lemma")[#text("Riesz lemma")]#text(".)")],
[#text("Show that the closed unit ball ")#tao-math("{\\{ x \\in V: \\left\\|x\\right\\| \\leq 1 \\}}", block: false)#text(" is compact in the strong topology if and only if ")#mi("{V}")#text(" is finite-dimensional.")]
)
]

#heading(level: 1)[#strong[#text(" — 3. The weak and weak* topologies — ")]]

#text("Let ")#mi("{V}")#text(" be a topological vector space. Then, as discussed above, we have the vector space ")#mi("{V^*}")#text(" of continuous linear functionals on ")#mi("{V}")#text(". We can use this dual space to create two useful topologies, the ")#emph[#text("weak topology")]#text(" on ")#mi("{V}")#text(" and the ")#emph[#text("weak* topology")]#text(" on ")#mi("{V^*}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2 (Weak and weak* topologies)")]#text(" Let ")#mi("{V}")#text(" be a topological vector space, and let ")#mi("{V^*}")#text(" be its dual.")

#list(
[#text("The ")#link("http://en.wikipedia.org/wiki/Weak_topology")[#text("weak topology")]#text(" on ")#mi("{V}")#text(" is the topology generated by the seminorms ")#tao-math("{\\left\\| x\\right\\|_\\lambda := \\left|\\lambda(x)\\right|}", block: false)#text(" for all ")#mi("{\\lambda \\in V^*}")#text(".")],
[#text("The ")#link("http://en.wikipedia.org/wiki/Weak_topology")[#text("weak* topology")]#text(" on ")#mi("{V^*}")#text(" is the topology generated by the seminorms ")#tao-math("{\\left\\| \\lambda\\right\\|_x := \\left|\\lambda(x)\\right|}", block: false)#text(" for all ")#mi("{x \\in V}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" It is possible for two non-isomorphic topological vector spaces to have isomorphic duals, but with non-isomorphic weak* topologies. (For instance, ")#mi("{\\ell^1({\\bf N})}")#text(" has a very large number of preduals, which can generate a number of different weak* topologies on ")#mi("{\\ell^1({\\bf N})}")#text(".) So, technically, one cannot talk about ")#emph[#text("the")]#text(" weak* topology on a dual space ")#mi("{V^*}")#text(", without specifying exactly what the predual space ")#mi("{V}")#text(" is. However, in practice, the predual space is usually clear from context.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Show that the weak topology on ")#mi("{V}")#text(" is a topological vector space structure on ")#mi("{V}")#text(" that is weaker than the strong topology on ")#mi("{V}")#text(". Also, if ")#mi("{V}")#text(" (and hence ")#mi("{V^*}")#text(" and ")#mi("{(V^*)^*}")#text(") are normed vector spaces, show that the weak* topology on ")#mi("{V^*}")#text(" is a topological vector space structure on ")#mi("{V^*}")#text(" that is weaker than the weak topology on ")#mi("{V^*}")#text(" (which is defined using the double dual ")#mi("{(V^*)^*}")#text(". When ")#mi("{V}")#text(" is a reflexive normed vector space, show that the weak and weak* topologies on ")#mi("{V^*}")#text(" are equivalent.")
]

#text("From the definition, we see that a sequence ")#mi("{x_n \\in V}")#text(" converges in the weak topology, or ")#emph[#text("converges weakly")]#text(" for short, to a limit ")#mi("{x \\in V}")#text(" if and only if ")#mi("{\\lambda(x_n) \\rightarrow \\lambda(x)}")#text(" for all ")#mi("{\\lambda \\in V^*}")#text(". This weak convergence is often denoted ")#mi("{x_n \\rightharpoonup x}")#text(", to distinguish it from strong convergence ")#mi("{x_n \\rightarrow x}")#text(". Similarly, a sequence ")#mi("{\\lambda_n \\in V^*}")#text(" converges in the weak* topology to ")#mi("{\\lambda \\in V^*}")#text(" if ")#mi("{\\lambda_n(x) \\rightarrow \\lambda(x)}")#text(" for all ")#mi("{x \\in V}")#text(" (thus ")#mi("{\\lambda_n}")#text(", viewed as a function on ")#mi("{V}")#text(", converges pointwise to ")#mi("{\\lambda}")#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" If ")#mi("{V}")#text(" is a Hilbert space, then from the ")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem")[#text("Riesz representation theorem for Hilbert spaces")]#text(" we see that a sequence ")#mi("{x_n \\in V}")#text(" converges weakly (or in the weak* sense) to a limit ")#mi("{x \\in V}")#text(" if and only if ")#mi("{\\langle x_n, y\\rangle \\rightarrow \\langle x, y \\rangle}")#text(" for all ")#mi("{y \\in V}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Show that if ")#mi("{V}")#text(" is a normed vector space, then the weak topology on ")#mi("{V}")#text(" and the weak* topology on ")#mi("{V^*}")#text(" are both Hausdorff. (")#emph[#text("Hint:")]#text(" You will need the ")#link("http://en.wikipedia.org/wiki/Hahn-Banach_theorem")[#text("Hahn-Banach theorem")]#text(".) In particular, we conclude the important fact that weak and weak* limits, when they exist, are unique.")
]

#text("The following exercise shows that the strong, weak, and weak* topologies can all differ from each other.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" ")#metadata(none) <tao-d37a24b801c6e2e33824>#text(" Let ")#mi("{V := c_0({\\bf N})}")#text(", thus ")#mi("{V^* \\equiv \\ell^1({\\bf N})}")#text(" and ")#mi("{V^{**} \\equiv \\ell^\\infty({\\bf N})}")#text(". Let ")#mi("{e_1, e_2, \\ldots}")#text(" be the standard basis of either ")#mi("{V}")#text(", ")#mi("{V^*}")#text(", or ")#mi("{V^{**}}")#text(".")

#list(
[#text("Show that the sequence ")#mi("{e_1, e_2, \\ldots}")#text(" converges weakly in ")#mi("{V}")#text(" to zero, but does not converge strongly in ")#mi("{V}")#text(".")],
[#text("Show that the sequence ")#mi("{e_1, e_2, \\ldots}")#text(" converges in the weak* sense in ")#mi("{V^*}")#text(" to zero, but does not converge in the weak or strong senses in ")#mi("{V^*}")#text(".")],
[#text("Show that the sequence ")#mi("{\\sum_{m=n}^\\infty e_m}")#text(" for ")#mi("{n=1,2,\\ldots}")#text(" converges in the weak* topology of ")#mi("{V^{**}}")#text(" to zero, but does not converge in the weak or strong senses. (Hint: use a generalised limit functional).")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" Recall from Exercise 11 of ")#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/")[#text("Notes 9")]#text(" that sequences in ")#mi("{V^* \\equiv \\ell^1({\\bf N})}")#text(" which converge in the weak topology, also converge in the strong topology. We caution however that the two topologies are not quite equivalent; for instance, the open unit ball in ")#mi("{\\ell^1({\\bf N})}")#text(" is open in the strong topology, but not in the weak.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Let ")#mi("{V}")#text(" be a normed vector space, and let ")#mi("{E}")#text(" be a subset of ")#mi("{V}")#text(". Show that the following are equivalent:")

#list(
[#mi("{E}")#text(" is strongly bounded (i.e. ")#mi("{E}")#text(" is contained in a ball).")],
[#mi("{E}")#text(" is weakly bounded (i.e. ")#mi("{\\lambda(E)}")#text(" is bounded for all ")#mi("{\\lambda \\in V^*}")#text(").")]
)

#text("(Hint: use the ")#link("http://en.wikipedia.org/wiki/Hahn-Banach_theorem")[#text("Hahn-Banach theorem")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Uniform_boundedness_principle")[#text("uniform boundedness principle")]#text(".) Similarly, if ")#mi("{F}")#text(" is a subset of ")#mi("{V^*}")#text(", and ")#mi("{V}")#text(" is a Banach space, show that ")#mi("{F}")#text(" is strongly bounded if and only if ")#mi("{F}")#text(" is weak* bounded (i.e. ")#mi("{\\{ \\lambda(x): \\lambda \\in F \\}}")#text(" is bounded for each ")#mi("{x \\in V}")#text(").) Conclude in particular that any sequence which is weakly convergent in ")#mi("{V}")#text(" or weak* convergent in ")#mi("{V^*}")#text(" is necessarily bounded.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" Let ")#mi("{V}")#text(" be a Banach space, and let ")#mi("{x_n \\in V}")#text(" converge weakly to a limit ")#mi("{x \\in V}")#text(". Show that the sequence ")#mi("{x_n}")#text(" is bounded, and")

#align(center)[#tao-fit-display[#tao-math("\\left\\|x\\right\\|_V \\leq \\liminf_{n \\rightarrow \\infty} \\left\\|x_n\\right\\|_V.", block: true)]]

#text("Observe from Exercise ")#link(<tao-d37a24b801c6e2e33824>)[#text("15")]#text(" that strict inequality can hold (cf. ")#link("http://en.wikipedia.org/wiki/Fatou%27s_lemma")[#text("Fatou’s lemma")]#text("). Similarly, if ")#mi("{\\lambda_n \\in V^*}")#text(" converges in the weak* topology to a limit ")#mi("{\\lambda \\in V^*}")#text(", show that the sequence ")#mi("{\\lambda_n}")#text(" is bounded and that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|\\lambda\\right\\|_{V^*} \\leq \\liminf_{n \\rightarrow \\infty} \\left\\|\\lambda_n\\right\\|_{V^*}.", block: true)]]

#text("Again, construct an example to show that strict inequality can hold. Thus we see that weak or weak* limits can lose mass in the limit, as opposed to strong limits (note from the triangle inequality that if ")#mi("{x_n}")#text(" converges strongly to ")#mi("{x}")#text(", then ")#tao-math("{\\left\\|x_n\\right\\|_V}", block: false)#text(" converges to ")#tao-math("{\\left\\|x\\right\\|_V}", block: false)#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" Let ")#mi("{H}")#text(" be a Hilbert space, and let ")#mi("{x_n \\in H}")#text(" converge weakly to a limit ")#mi("{x \\in H}")#text(". Show that the following statements are equivalent:")

#list(
[#mi("{x_n}")#text(" converges strongly to ")#mi("{x}")#text(".")],
[#tao-math("{\\left\\|x_n\\right\\|}", block: false)#text(" converges to ")#tao-math("{\\left\\|x\\right\\|}", block: false)#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Let ")#mi("{H}")#text(" be a separable Hilbert space. We say that a sequence ")#mi("{x_n \\in H}")#text(" ")#emph[#text("converges in the Césaro sense")]#text(" to a limit ")#mi("{x \\in H}")#text(" if ")#mi("{\\frac{1}{N} \\sum_{n=1}^N x_n}")#text(" converges strongly to ")#mi("{x}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".")

#list(
[#text("Show that if ")#mi("{x_n}")#text(" converges strongly to ")#mi("{x}")#text(", then it also converges in the Césaro sense to ")#mi("{x}")#text(".")],
[#text("Give examples to show that weak convergence does not imply Césaro convergence, and vice versa. On the other hand, if a sequence ")#mi("{x_n}")#text(" converges both weakly and in the Césaro sense, show that the weak limit is necessarily equal to the Césaro limit.")],
[#text("Show that a sequence ")#mi("{x_n}")#text(" converges weakly to ")#mi("{x}")#text(" if and only if every subsequence has a further subsequence that converges in the Césaro sense to ")#mi("{x}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Let ")#mi("{V}")#text(" be a Banach space. Show that the closed unit ball in ")#mi("{V}")#text(" is also closed in the weak topology, and the closed unit ball in ")#mi("{V^*}")#text(" is closed in the weak* topology.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" Let ")#mi("{V}")#text(" be a Banach space. Show that the weak* topology on ")#mi("{V^*}")#text(" is complete.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Let ")#mi("{V}")#text(" be a normed vector space, let ")#mi("{W}")#text(" be a subspace of ")#mi("{V}")#text(" which is closed in the strong topology of ")#mi("{V}")#text(".")

#list(
[#text("Show that ")#mi("{W}")#text(" is closed in the weak topology of ")#mi("{V}")#text(".")],
[#text("If ")#mi("{w_n \\in W}")#text(" is a sequence and ")#mi("{w \\in W}")#text(", show that ")#mi("{w_n}")#text(" converges to ")#mi("{w}")#text(" in the weak topology of ")#mi("{W}")#text(" if and only if it converges to ")#mi("{w}")#text(" in the weak topology of ")#mi("{V}")#text(". (Because of this fact, we can often refer to “the weak topology” without specifying the ambient space precisely.)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" ")#metadata(none) <tao-3f98114b0f77b7da78bc>#text(" Let ")#mi("{V := c_0({\\bf N})}")#text(" with the uniform (i.e. ")#mi("{\\ell^\\infty}")#text(") norm, and identify the dual space ")#mi("{V^*}")#text(" with ")#mi("{\\ell^1({\\bf N})}")#text(" in the usual manner.")

#list(
[#text("Show that a sequence ")#mi("{x_n \\in c_0({\\bf N})}")#text(" converges weakly to a limit ")#mi("{x \\in c_0({\\bf N})}")#text(" if and only if the ")#mi("{x_n}")#text(" are bounded in ")#mi("{c_0({\\bf N})}")#text(" and converge pointwise to ")#mi("{x}")#text(".")],
[#text("Show that a sequence ")#mi("{\\lambda_n \\in \\ell^1({\\bf N})}")#text(" converges in the weak* topology to a limit ")#mi("{\\lambda \\in \\ell^1({\\bf N})}")#text(" if and only if the ")#mi("{\\lambda_n}")#text(" are bounded in ")#mi("{\\ell^1({\\bf N})}")#text(" and converge pointwise to ")#mi("{\\lambda}")#text(".")],
[#text("Show that the weak topology in ")#mi("{c_0({\\bf N})}")#text(" is not complete.")]
)

#text("(More generally, it may help to think of the weak and weak* topologies as being analogous to pointwise convergence topologies.)")
]

#text("One of the main reasons why we use the weak and weak* topologies in the first place is that they have much better compactness properties than the strong topology, thanks to the ")#link("http://en.wikipedia.org/wiki/Banach%E2%80%93Alaoglu_theorem")[#text("Banach-Alaoglu theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Banach-Alaoglu theorem)")]#text(" Let ")#mi("{V}")#text(" be a normed vector space. Then the closed unit ball of ")#mi("{V^*}")#text(" is compact in the weak* topology.")
]

#text("This result should be contrasted with Exercise ")#link(<tao-4b9df800fa2069382c23>)[#text("12")]#text(".")

#emph[#text("Proof:")]#text(" Let’s say ")#mi("{V}")#text(" is a complex vector space (the case of real vector spaces is of course analogous). Let ")#mi("{B^*}")#text(" be the closed unit ball of ")#mi("{V^*}")#text(", then any linear functional ")#mi("{\\lambda \\in B^*}")#text(" maps the closed unit ball ")#mi("{B}")#text(" of ")#mi("{V}")#text(" into the disk ")#tao-math("{D := \\{ z \\in {\\bf C}: \\left|z\\right| \\leq 1 \\}}", block: false)#text(". Thus one can identify ")#mi("{B^*}")#text(" with a subset of ")#mi("{D^B}")#text(", the space of functions from ")#mi("{B}")#text(" to ")#mi("{D}")#text(". One easily verifies that the weak* topology on ")#mi("{B^*}")#text(" is nothing more than the product topology of ")#mi("{D^B}")#text(" restricted to ")#mi("{B^*}")#text(". Also, one easily shows that ")#mi("{B^*}")#text(" is closed in ")#mi("{D^B}")#text(". But by Tychonoff’s theorem, ")#mi("{D^B}")#text(" is compact, and so ")#mi("{B^*}")#text(" is compact also. ")#mi("\\Box")

#text("One should caution that the Banach-Alaoglu theorem does ")#emph[#text("not")]#text(" imply that the space ")#mi("{V^*}")#text(" is locally compact in the weak* topology, because the norm ball in ")#mi("{V}")#text(" has empty interior in the weak* topology unless ")#mi("{V}")#text(" is finite dimensional. In fact, we have the following result of Riesz:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" Let ")#mi("{V}")#text(" be a locally compact Hausdorff topological vector space. Show that ")#mi("{V}")#text(" is finite dimensional. (")#emph[#text("Hint")]#text(": If ")#mi("{V}")#text(" is locally compact, then there exists an open neighbourhood ")#mi("{U}")#text(" of the origin whose closure is compact. Show that ")#mi("{U \\subset W + \\frac{1}{2} U}")#text(" for some finite-dimensional subspace ")#mi("{W}")#text(", where ")#mi("{W+\\frac{1}{2} U := \\{ w + \\frac{1}{2} u: w \\in W, u \\in U \\}}")#text(". Iterate this to conclude that ")#mi("{U \\subset W + \\varepsilon U}")#text(" for any ")#mi("{\\varepsilon > 0}")#text(". On the other hand, use the compactness of ")#mi("{\\overline{U}}")#text(" to show that for any point ")#mi("{x \\in V \\backslash W}")#text(" there exists ")#mi("{\\varepsilon > 0}")#text(" such that ")#mi("{x - \\varepsilon U}")#text(" is disjoint from ")#mi("{W}")#text(". Conclude that ")#mi("{U \\subset W}")#text(" and thence that ")#mi("{V = W}")#text(".)")
]

#text("The sequential version of the Banach-Alaoglu theorem is also of importance (particularly in PDE):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Sequential Banach-Alaoglu theorem)")]#text(" Let ")#mi("{V}")#text(" be a separable normed vector space. Then the closed unit ball of ")#mi("{V^*}")#text(" is sequentially compact in the weak* topology.")
]

#emph[#text("Proof:")]#text(" The functionals in ")#mi("{B^*}")#text(" are uniformly bounded and uniformly equicontinuous on ")#mi("{B}")#text(", which by hypothesis has a countable dense subset ")#mi("{Q}")#text(". By the sequential Tychonoff theorem, any sequence in ")#mi("{B^*}")#text(" then has a subsequence which converges pointwise on ")#mi("{Q}")#text(", and thus converges pointwise on ")#mi("{B}")#text(" by Exercise 28 of ")#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/")[#text("Notes 10")]#text(", and thus converges in the weak* topology. But as ")#mi("{B^*}")#text(" is closed in this topology, we conclude that ")#mi("{B^*}")#text(" is sequentially compact as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" One can also deduce the sequential Banach-Alaoglu theorem from the general Banach-Alaoglu theorem by observing that the weak* topology on (bounded subsets of) the dual of a separable space is metrisable. The sequential Banach-Alaoglu theorem can break down for non-separable spaces. For instance, the closed unit ball in ")#mi("{(\\ell^\\infty({\\bf N}))^*}")#text(" is not sequentially compact in the weak* topology, basically because the space ")#mi("{\\beta {\\bf N}}")#text(" of ultrafilters is not sequentially compact (see Exercise 12 of ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("these lecture notes")]#text(").")
]

#text("If ")#mi("{V}")#text(" is reflexive, then the weak topology on ")#mi("{V}")#text(" is identical to the weak* topology on ")#mi("{(V^*)^*}")#text(". We thus have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 5")]#text(" If ")#mi("{V}")#text(" is a reflexive normed vector space, then the closed unit ball in ")#mi("{V}")#text(" is weakly compact, and (if ")#mi("{V^*}")#text(" is separable) is also sequentially weakly compact.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" If ")#mi("{V}")#text(" is a normed vector space that is not separable, then one can show that ")#mi("{V^*}")#text(" is not separable either. Indeed, using transfinite induction on first uncountable ordinal, one can construct an uncountable proper well-ordered chain of closed separable subspaces of the inseparable space ")#mi("{V}")#text(", which by the Hahn-Banach theorem induces an uncountable proper well-ordered chain of closed subspaces on ")#mi("{V^*}")#text(", which is not compatible with separability. As a consequence, a reflexive space is separable if and only if its dual is separable. [On the other hand, separable spaces can have non-separable duals; consider ")#mi("{\\ell^1({\\bf N})}")#text(", for instance.]")
]

#text("In particular, any bounded sequence in a reflexive separable normed vector space has a weakly convergent subsequence. This fact leads to the very useful ")#emph[#text("weak compactness")]#text(" method in PDE and calculus of variations, in which a solution to a PDE or variational problem is constructed by first constructing a bounded sequence of “near-solutions” or “near-extremisers” to the PDE or variational problem, and then extracting a weak limit. However, it is important to caution that weak compactness can fail for non-reflexive spaces; indeed, for such spaces the closed unit ball in ")#mi("{V}")#text(" may not even be weakly complete, let alone weakly compact, as already seen in Exercise ")#link(<tao-3f98114b0f77b7da78bc>)[#text("23")]#text(". Thus, one should be cautious when applying the weak compactness method to a non-reflexive space such as ")#mi("{L^1}")#text(" or ")#mi("{L^\\infty}")#text(". (On the other hand, weak* compactness does not need reflexivity, and is thus safer to use in such cases.)")

#text("In later notes we will see that the (sequential) Banach-Alaoglu theorem will combine very nicely with the ")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem")[#text("Riesz representation theorem")]#text(" for measures, leading in particular to ")#link("http://en.wikipedia.org/wiki/Prokhorov%27s_theorem")[#text("Prokhorov’s theorem")]#text(".")

#heading(level: 1)[#strong[#text(" — 4. The strong and weak operator topologies — ")]]

#text("Now we turn our attention from function spaces to spaces of operators. Recall that if ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are normed vector spaces, then ")#mi("{B(X \\rightarrow Y)}")#text(" is the space of bounded linear transformations from ")#mi("{X}")#text(" to ")#mi("{Y}")#text(". This is a normed vector space with the operator norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|T\\right\\|_{op} := \\sup \\{ \\left\\|Tx\\right\\|_Y: \\left\\|x\\right\\|_X \\leq 1 \\}.", block: true)]]

#text("This norm induces the ")#emph[#text("operator norm topology")]#text(" on ")#mi("{B(X \\rightarrow Y)}")#text(". Unfortunately, this topology is so strong that it is difficult for a sequence of operators ")#mi("{T_n \\in B(X \\rightarrow Y)}")#text(" to converge to a limit; for this reason, we introduce two weaker topologies.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 6 (Strong and weak operator topologies)")]#text(" Let ")#mi("{X, Y}")#text(" be normed vector spaces. The ")#link("http://en.wikipedia.org/wiki/Strong_operator_topology")[#text("strong operator topology")]#text(" on ")#mi("{B(X \\rightarrow Y)}")#text(" is the topology induced by the seminorms ")#tao-math("{T \\mapsto \\left\\| T x \\right\\|_Y}", block: false)#text(" for all ")#mi("{x \\in X}")#text(". The ")#link("http://en.wikipedia.org/wiki/Weak_operator_topology")[#text("weak operator topology")]#text(" on ")#mi("{B(X \\rightarrow Y)}")#text(" is the topology induced by the seminorms ")#tao-math("{T \\mapsto \\left|\\lambda(Tx)\\right|}", block: false)#text(" for all ")#mi("{x \\in X}")#text(" and ")#mi("{\\lambda \\in Y^*}")#text(".")
]

#text("Note that a sequence ")#mi("{T_n \\in B(X \\rightarrow Y)}")#text(" converges in the strong operator topology to a limit ")#mi("{T \\in B(X \\rightarrow Y)}")#text(" if and only if ")#mi("{T_n x \\rightarrow Tx}")#text(" strongly in ")#mi("{Y}")#text(" for all ")#mi("{x \\in X}")#text(", and ")#mi("{T_n}")#text(" converges in the weak operator topology. (In contrast, ")#mi("{T_n}")#text(" converges to ")#mi("{T}")#text(" in the operator norm topology if and only if ")#mi("{T_n x}")#text(" converges to ")#mi("{Tx}")#text(" ")#emph[#text("uniformly")]#text(" on bounded sets.) One easily sees that the weak operator topology is weaker than the strong operator topology, which in turn is (somewhat confusingly) weaker than the operator norm topology.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 7")]#text(" When ")#mi("{X}")#text(" is the scalar field, then ")#mi("{B(X \\rightarrow Y)}")#text(" is canonically isomorphic to ")#mi("{Y}")#text(". In this case, the operator norm and strong operator topology coincide with the strong topology on ")#mi("{Y}")#text(", and the weak operator norm topology coincides with the weak topology on ")#mi("{Y}")#text(". Meanwhile, ")#mi("{B(Y \\rightarrow X)}")#text(" coincides with ")#mi("{Y^*}")#text(", and the operator norm topology coincides with the strong topology on ")#mi("{Y^*}")#text(", while the strong and weak operator topologies correspond with the weak* topology on ")#mi("{Y^*}")#text(".")
]

#text("We can rephrase the uniform boundedness principle for convergence (Corollary 1 from ")#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/")[#text("Notes 9")]#text(") as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7 (Uniform boundedness principle)")]#text(" ")#metadata(none) <tao-87a9d19c350ee6273599>#text(" Let ")#mi("{T_n \\in B(X \\rightarrow Y)}")#text(" be a sequence of bounded linear operators from a Banach space ")#mi("{X}")#text(" to a normed vector space ")#mi("{Y}")#text(", let ")#mi("{T \\in B(X \\rightarrow Y)}")#text(" be another bounded linear operator, and let ")#mi("{D}")#text(" be a dense subspace of ")#mi("{X}")#text(". Then the following are equivalent:")

#list(
[#mi("{T_n}")#text(" converges in the strong operator topology of ")#mi("{B(X \\rightarrow Y)}")#text(" to ")#mi("{T}")#text(".")],
[#mi("{T_n}")#text(" is bounded in the operator norm (i.e. ")#tao-math("{\\left\\|T_n\\right\\|_{op}}", block: false)#text(" is bounded), and the restriction of ")#mi("{T_n}")#text(" to ")#mi("{D}")#text(" converges in the strong operator topology of ")#mi("{B(D \\rightarrow Y)}")#text(" to the restriction of ")#mi("{T}")#text(" to ")#mi("{D}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" Show that the conclusion of Proposition ")#link(<tao-87a9d19c350ee6273599>)[#text("7")]#text(" continues to hold if “strong operator topology” is replaced by “weak operator topology” throughout.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" Show that the operator norm topology, strong operator topology, and weak operator topology, are all Hausdorff. As these topologies are nested, we thus conclude that it is not possible for a sequence of operators to converge to one limit in one of these topologies and to converge to a different limit in another.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 8")]#text(" Let ")#mi("{X = L^2({\\bf R})}")#text(", and for each ")#mi("{t \\in {\\bf R}}")#text(", let ")#mi("{T_t: X \\rightarrow X}")#text(" be the translation operator by ")#mi("{t}")#text(": ")#mi("{T_t f(x) := f(x-t)}")#text(". If ")#mi("{f}")#text(" is continuous and compactly supported, then (e.g. from dominated convergence) we see that ")#mi("{T_t f \\rightarrow f}")#text(" in ")#mi("{L^2}")#text(" as ")#mi("{t \\rightarrow 0}")#text(". Since the space of continuous and compactly supported functions is dense in ")#mi("{L^2({\\bf R})}")#text(", this implies (from the above proposition, with some obvious modifications to deal with the continuous parameter ")#mi("{t}")#text(" instead of the discrete parameter ")#mi("{n}")#text(") that ")#mi("{T_t}")#text(" converges in the strong operator topology (and hence weak operator topology) to the identity. On the other hand, ")#mi("{T_t}")#text(" does not converge to the identity in the operator norm topology. Indeed, observe for any ")#mi("{t > 0}")#text(" that ")#tao-math("{\\left\\| (T_t - I) 1_{[0,t]} \\right\\|_{L^2({\\bf R})} = \\sqrt{2} \\left\\| 1_{[0,t]} \\right\\|_{L^2({\\bf R})}}", block: false)#text(", and thus ")#tao-math("{\\left\\| T_t - I \\right\\|_{op} \\geq \\sqrt{2}}", block: false)#text(".")

#text("In a similar vein, ")#mi("{T_t}")#text(" does not converge to anything in the strong operator topology (and hence does not converge in the operator norm topology either) in the limit ")#mi("{t \\rightarrow \\infty}")#text(", since ")#mi("{T_t 1_{[0,1]}}")#text(" (say) does not converge strongly in ")#mi("{L^2}")#text(". However, one easily verifies that ")#mi("{\\langle T_t f, g \\rangle \\rightarrow 0}")#text(" as ")#mi("{t \\rightarrow \\infty}")#text(" for any compactly supported ")#mi("{f, g \\in L^2({\\bf R})}")#text(", and hence for all ")#mi("{f, g \\in L^2({\\bf R})}")#text(" by the usual limiting argument, and hence ")#mi("{T_t}")#text(" converges in the weak operator topology to zero.")
]

#text("The following exercise may help clarify the relationship between the operator norm, strong operator, and weak operator topologies.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" Let ")#mi("{H}")#text(" be a Hilbert space, and let ")#mi("{T_n \\in B(H \\rightarrow H)}")#text(" be a sequence of bounded linear operators.")

#list(
[#text("Show that ")#mi("{T_n \\rightarrow 0}")#text(" in the operator norm topology if and only if ")#mi("{\\langle T_n x_n, y_n \\rangle \\rightarrow 0}")#text(" for any bounded sequences ")#mi("{x_n, y_n \\in H}")#text(".")],
[#text("Show that ")#mi("{T_n \\rightarrow 0}")#text(" in the strong operator topology if and only if ")#mi("{\\langle T_n x_n, y_n \\rangle \\rightarrow 0}")#text(" for any convergent sequence ")#mi("{x_n \\in H}")#text(" and any bounded sequence ")#mi("{y_n \\in H}")#text(".")],
[#text("Show that ")#mi("{T_n \\rightarrow 0}")#text(" in the weak operator topology if and only if ")#mi("{\\langle T_n x_n, y_n \\rangle \\rightarrow 0}")#text(" for any convergent sequences ")#mi("{x_n, y_n \\in H}")#text(".")],
[#text("Show that ")#mi("{T_n \\rightarrow 0}")#text(" in the operator norm (resp. weak operator) topology if and only if ")#mi("{T_n^\\dagger \\rightarrow 0}")#text(" in the operator norm (resp. weak operator) topology. Give an example to show that the corresponding claim for the strong operator topology is false.")]
)
]

#text("There is a counterpart of the Banach-Alaoglu theorem (and its sequential analogue), at least in the case of Hilbert spaces:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" Let ")#mi("{H, H^{\\prime}}")#text(" be Hilbert spaces. Show that the closed unit ball (in the operator norm) in ")#mi("{B(H \\rightarrow H^{\\prime})}")#text(" is compact in the weak operator topology. If ")#mi("{H}")#text(" and ")#mi("{H^{\\prime}}")#text(" are separable, show that ")#mi("{B(H \\rightarrow H^{\\prime})}")#text(" is sequentially compact in the weak operator topology.")
]

#text("The behaviour of convergence in various topologies with respect to composition is somewhat complicated, as the following exercise shows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29")]#text(" Let ")#mi("{H}")#text(" be a Hilbert space, let ")#mi("{S_n, T_n \\in B(H \\rightarrow H)}")#text(" be sequences of operators, and let ")#mi("{S \\in B(H \\rightarrow H)}")#text(" be another operator.")

#list(
[#text("If ")#mi("{T_n \\rightarrow 0}")#text(" in the operator norm (resp. strong operator or weak operator) topology, show that ")#mi("{ST_n \\rightarrow 0}")#text(" and ")#mi("{T_n S \\rightarrow 0}")#text(" in the operator norm (resp. strong operator or weak operator) topology.")],
[#text("If ")#mi("{T_n \\rightarrow 0}")#text(" in the operator norm topology, and ")#mi("{S_n}")#text(" is bounded in the operator norm topology, show that ")#mi("{S_n T_n \\rightarrow 0}")#text(" and ")#mi("{T_n S_n \\rightarrow 0}")#text(" in the operator norm topology.")],
[#text("If ")#mi("{T_n \\rightarrow 0}")#text(" in the strong operator topology, and ")#mi("{S_n}")#text(" is bounded in the operator norm topology, show that ")#mi("{S_n T_n \\rightarrow 0}")#text(" in the strong operator norm topology.")],
[#text("Give an example where ")#mi("{T_n \\rightarrow 0}")#text(" in the strong operator topology, and ")#mi("{S_n \\rightarrow 0}")#text(" in the weak operator topology, but ")#mi("{T_n S_n}")#text(" does not converge to zero even in the weak operator topology.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30")]#text(" Let ")#mi("{H}")#text(" be a Hilbert space. An operator ")#mi("{T \\in B( H \\rightarrow H )}")#text(" is said to be ")#link("http://en.wikipedia.org/wiki/Finite_rank_operator")[#text("finite rank")]#text(" if its image ")#mi("{T(H)}")#text(" is finite dimensional. ")#mi("{T}")#text(" is said to be ")#link("http://en.wikipedia.org/wiki/Compact_operator")[#text("compact")]#text(" if the image of the unit ball is precompact. Let ")#mi("{K( H \\rightarrow H )}")#text(" denote the space of compact operators on ")#mi("{H}")#text(".")

#list(
[#text("Show that ")#mi("{T \\in B(H \\rightarrow H)}")#text(" is compact if and only if it is the limit of finite rank operators in the operator norm topology. Conclude in particular that ")#mi("{K(H \\rightarrow H)}")#text(" is a closed subset of ")#mi("{B(H \\rightarrow H)}")#text(" in the operator norm topology.")],
[#text("Show that an operator ")#mi("{T \\in B(H \\rightarrow H)}")#text(" is compact if and only if ")#mi("{T^\\dagger}")#text(" is compact.")],
[#text("If ")#mi("{H}")#text(" is separable, show that every ")#mi("{T \\in B(H \\rightarrow H)}")#text(" is the limit of finite rank operators in the strong operator topology.")],
[#text("If ")#mi("{T \\in K(H \\rightarrow H)}")#text(", show that ")#mi("{T}")#text(" maps weakly convergent sequences to strongly convergent sequences. (This property is known as ")#emph[#text("complete continuity")]#text(".)")],
[#text("Show that ")#mi("{K(H \\rightarrow H)}")#text(" is a subspace of ")#mi("{B(H \\rightarrow H)}")#text(", which is closed with respect to left and right multiplication by elements of ")#mi("{B(H \\rightarrow H)}")#text(". (In other words, the space of compact operators is an two-ideal in the algebra of bounded operators.)")]
)

#text("The weak operator topology plays a particularly important role on the theory of ")#link("http://en.wikipedia.org/wiki/Von_Neumann_algebra")[#text("von Neumann algebras")]#text(", which we will not discuss here. We will return to the study of compact operators next quarter, when we discuss the ")#link("http://en.wikipedia.org/wiki/Spectral_theorem")[#text("spectral theorem")]#text(".")

#text("[")#emph[#text("Update")]#text(", Feb 23: Corrections, another exercise and remark added (note renumbering).]")
]

#heading(level: 1)[#text("Comments (133)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-478431")[#strong[#text("Variational methods and Weak Topologies: Part 1 | Knowing the odds")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2017")]

#text("[…] NLS in this post, for the readers interested in a deep understading in the subject we suggest this Terence Tao’s post or the third chapter of Brezis’ book. Our main interest here is to present a version of a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of keej")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-479910")[#strong[#text("keej")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2017")])]

#text("Regarding this comment in Remark 5: “…the weak* topology on the dual of a separable space is metrisable.” This is not quite true, right? Wouldn’t this imply that the weak topology on every separable Hilbert space is metrizable? ")#emph[#text("[Yes, this is a special case of Remark 5. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of keej")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-479959")[#strong[#text("keej")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2017")])]

#text("Dear Professor Tao, thanks for your reply, but I am still confused… I should have mentioned this in the original comment, but I think a well-known example is the set ")#mi("S = \\{ \\sqrt{n} e_n \\}")#text(" in a Hilbert space with countably infinite basis ")#mi("\\{e_n\\}")#text(". The weak closure of ")#mi("S")#text(" contains ")#mi("0")#text(", but no sequence in ")#mi("S")#text(" converges to ")#mi("0")#text(". So the weak topology cannot be metrizable. Am I still making a mistake somewhere?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-479983")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2017")])]

#text("Ah, I see the issue now. It is the bounded subsets of a normed vector space with the weak* topology that are metrisable; as you point out, unbounded sets need not be metrisable. (This was fixed in the published version of these notes, but not in this blog post, but I will correct this now.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68355afb7bfcf9b6ded40f21c7ad615fc3ab95b96dce6450b6f2a3583549c39c-012729cd35e18a1568c4776c608a4eed2aea905c9759b8d40bb649d3f2dea8c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike Neely")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-501605")[#strong[#text("Mike Neely")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2018")])]

#text("In Exercise 16, should “completeness” be added? Else we can")#linebreak()#text(" define V as the set of all real-valued infinite sequences with a finite")#linebreak()#text(" number of nonzero entries, define ||x||^2=sum_{i=1}^{\\infty} x_i^2,")#linebreak()#text(" and E = {(1,0,0,…), (0,1,0,0…), (0,0,1,0,…), …} which is strongly")#linebreak()#text(" bounded but not weakly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-501611")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2018")])]

#text("All strongly bounded sets are weakly bounded (note that linear functionals in the dual space ")#mi("V^*")#text(" are, by definition, bounded – we are not referring here to the algebraic dual).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68355afb7bfcf9b6ded40f21c7ad615fc3ab95b96dce6450b6f2a3583549c39c-012729cd35e18a1568c4776c608a4eed2aea905c9759b8d40bb649d3f2dea8c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike Neely")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-501614")[#strong[#text("Mike Neely")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2018")])]

#text("Thanks for your reply! I likely am using “algebraic dual” unwittingly, since I don’t know another definition of V*. If we use algebraic dual, it seems E is not weakly bounded since we can consider the linear functional f:V—>R defined by mapping the basis vectors")#linebreak()#text(" {e_1, e_2, e_3, …} as follows: f(e_k)=k for all k in {1, 2, 3, …}.")#linebreak()#text(" This maps every sequence in V to a real number (since sequences")#linebreak()#text(" in V have at most a finite number of nonzeros). And so")#linebreak()#text(" f(E) = {f(e_1), f(e_2), f(e_3), …} = {1,2, 3, …}")#linebreak()#text(" is not a bounded set. Is this correct reasoning if we use “algebraic dual space”? The wiki page here defines “dual space” without the boundedness condition you give: ")#link("https://en.wikipedia.org/wiki/Dual_space")[#text("https://en.wikipedia.org/wiki/Dual_space")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-501624")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2018")])]

#text("As stated in the second paragraph of the wikipedia page you link, in the category of topological vector spaces, one usually works with the continuous dual space instead of the algebraic dual space, in which the linear functional is required to be continuous (or equivalently, bounded). See also Remark 1 in the previous notes ")#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/")[#text("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/")]#text(" . Certainly many results in functional analysis involving the continuous dual space will break down if the algebraic dual space is used instead, and as such the latter is rarely used in this subject.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7941e6fb2b3b1b58f19cc5276496907816fbcea416d1986f14bf027dc250d5be-e77990607feccbc66cde660b029075d2007600d343893b51957486c579a32fb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kenneth Harris")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-584154")[#strong[#text("Kenneth Harris")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2020")])]

#text("For proposition 7, do we need Y to be complete also? Otherwise doesn’t the following counterexample hold?")

#link("https://math.stackexchange.com/questions/690326/uniform-boundedness-principle-for-norm-convergence")[#text("https://math.stackexchange.com/questions/690326/uniform-boundedness-principle-for-norm-convergence")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7941e6fb2b3b1b58f19cc5276496907816fbcea416d1986f14bf027dc250d5be-e77990607feccbc66cde660b029075d2007600d343893b51957486c579a32fb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kenneth Harris")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-584455")[#strong[#text("Kenneth Harris")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2020")])]

#text("Please ignore the last question! The fact that the existence of T is stated in the hypothesis rules out this as a counterexample, and means we don’t need to require Y complete.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-596663")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2020")])]

#text("In definition 1, if instead of joint continuity, one uses separate continuity, does one still has ")#mi("x_n+y_n\\to x+y")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-596684")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2020")])]

#text("No. For instance if one gives ")#mi("{\\bf R}")#text(" the cofinite topology then the sequences ")#mi("n")#text(" and ")#mi("1-n")#text(" both converge to 0 (as well as to every other real number) but their sum does not. Granted, in this particular case scalar multiplication is also discontinuous, but one can fix this by e.g., working with an infinite-dimensional vector space ")#mi("{\\bf R}^{\\bf N}")#text(" endowed with the topology where the non-empty open sets are the complement of subsets of finite-dimensional subspaces that are closed in the natural topology of those subspaces, and then working with ")#mi("e_n")#text(" and ")#mi("e_1-e_n")#text(" rather than ")#mi("n")#text(" and ")#mi("1-n")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/662901cbed42c84a577b29713e9b60cf2dc9bb05ad1bd1f6c9f6f2e82d0c90d7-7f2d4f33cce21c7d3aea54ae584f69aff1332fae054b242a67eab58cc35d67e3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SK Rayamajhi")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-624307")[#strong[#text("SK Rayamajhi")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2021")])]

#text("Regarding example 8: What about operator $T_{B_t} f(x) = f(B_t(x))$ where $B_t$ is some mapping in domain of function.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-642484")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2022")])]

#text("dear prof. Tao, in exercise 21, what does it mean to say that the weak* topology on ")#mi("V^*")#text(" is complete? similarly, in exercise 23, i don’t understand the statement that the weak topology in ")#mi("c_0(\\mathbf N)")#text(" is not complete. thank you.")

#emph[#text("[See ")#link("https://en.wikipedia.org/wiki/Complete_topological_vector_space")[#text("https://en.wikipedia.org/wiki/Complete_topological_vector_space")]#text(" -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-642549")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2022")])]

#text("thank you for your help! i was confused partially because the paragraph before remark 1 defined completeness in TVS using Cauchy sequences, which seems to usually be called sequential completeness in the literature. the claim in exercise 21 seems to hold for sequential completeness but not for completeness (as defined using Cauchy nets as in the Wikipedia article)")

#text("some useful links for anyone else who gets stuck here:")#linebreak()#text(" ")#link("https://math.stackexchange.com/questions/1863811/is-x-complete-with-weak-topology")[#text("https://math.stackexchange.com/questions/1863811/is-x-complete-with-weak-topology")]#linebreak()#text(" ")#link("https://math.stackexchange.com/questions/3161333/on-weak-sequentially-completeness")[#text("https://math.stackexchange.com/questions/3161333/on-weak-sequentially-completeness")]

#link("https://www-users.cse.umn.edu/~garrett/m/fun/incompleteness.pdf")[#text("Click to access incompleteness.pdf")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-671219")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2022")])]

#text("Has a topology of ")#mi("L_{\\text{loc}}^1(\\mathbf{R}^d)")#text(" been defined somewhere in this set of notes? Maybe another good example after Example 4.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-671357")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2023")])]

#text("In Exercise 3, if for every ")#mi("\\alpha\\in A")#text(", ")#mi("x_n\\to x")#text(" in ")#mi("\\mathcal{F}_\\alpha")#text(", then since ")#mi("\\mathcal{F}_\\alpha")#text(" is _part_ of ")#mi("\\mathcal{F}")#text(", it is trivial to see that ")#mi("x_n\\to x")#text(". Why is the inverse also true? ")#mi("\\mathcal{F}")#text(" is generated by the union instead of the intersections of ")#mi("\\mathcal{F}_\\alpha")#text(". Why it can’t be true that ")#mi("x_n\\to x")#text(" in ")#mi("\\mathcal{F}")#text(" but ")#mi("x_n\\to x")#text(" in ")#mi("\\mathcal{F}_\\alpha")#text(" for only one ")#mi("\\alpha")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-671755")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2023")])]

#text("Your implications are the wrong way around: ")#mi("x_n \\to x")#text(" in ")#mi("{\\mathcal F}")#text(" implies ")#mi("x_n \\to x")#text(" in ")#mi("{\\mathcal F}_\\alpha")#text(", but not conversely. (I recommend writing out these convergence statements explicitly using quantifiers.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-671768")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2023")])]

#text("Ah, I somehow messed up with the implications. The trivial one should be ")#mi("x_n \\to x in {\\mathcal F}")#text(" implies ")#mi("x_n \\to x in {\\mathcal F}_\\alpha")#text(" for every ")#mi("\\alpha")#text(", which follows from the fact that each ")#mi("{\\mathcal F}_\\alpha")#text(" is part of ")#mi("{\\mathcal F}")#text(". The other direction follows from the fact that the collections of all the open sets in all ")#mi("{\\mathcal F}_\\alpha")#text(" form a sub-basis of ")#mi("{\\mathcal F}")#text(".")

#text("1. Suppose ")#mi("x_n \\to x in {\\mathcal F}")#text(" and ")#mi("\\alpha\\in A")#text(". If ")#mi("U")#text(" is any open set in ")#mi("{\\mathcal F}_\\alpha")#text(" that contains ")#mi("x")#text(", then since ")#mi("U")#text(" is also open in ")#mi("{\\mathcal F}")#text(", it must contain ")#mi("x_n")#text(" for all sufficiently large ")#mi("n")#text(". This completes the trivial direction.")

#text("2. Now suppose ")#mi("x_n\\to x")#text(" in ")#mi("{\\mathcal F}_\\alpha")#text(" for every ")#mi("\\alpha\\in A")#text(". Suppose ")#mi("x\\in U")#text(" for an open set ")#mi("U")#text(" in ")#mi("{\\mathcal F}")#text(". Since ")#mi("{\\mathcal F}")#text(" is generated by the collection ")#mi("{\\mathcal F}_\\alpha")#text(" (")#mi("\\alpha\\in A")#text("), ")#mi("U")#text(" can be written as a union of finite intersections of open sets from ")#mi("{\\mathcal F}_\\alpha")#text(" and thus particularly, ")#mi("x\\in \\bigcap_{\\alpha \\in I}O_\\alpha")#text(" where ")#mi("I")#text(" is a finite subset of ")#mi("A")#text(" and ")#mi("O_\\alpha")#text(" is an open set in ")#mi("{\\mathcal F}_\\alpha")#text(". By the assumption, ")#mi("\\bigcap_{\\alpha \\in I}O_\\alpha")#text(" contains ")#mi("x_n")#text(" for all sufficiently large ")#mi("n")#text(". The proof is done.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-671362")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2023")])]

#text("In Exercise 4, suppose for each ")#mi("{\\beta \\in B}")#text(", there exists a finite subset ")#mi("{A_\\beta}")#text(" of ")#mi("{A}")#text(" and a constant ")#mi("{C_\\beta}")#text(" such that ")#tao-math("{\\left\\| Tf\\right\\|_{W_\\beta} \\leq C_\\beta \\sum_{\\alpha \\in A_\\beta} \\left\\| f\\right\\|_{V_\\alpha}}", block: false)#text(" for all ")#mi("{f \\in V}")#text(".")#linebreak()#text(" To show that ")#mi("T")#text(" is continuous, it suffices to show that $latext T^{-1}(B)$ is open in $V$ for every ")#mi("\\|\\|_{W_\\beta}")#text(" ball ")#mi("B")#text(" since the inverse ")#mi("T^{-1}")#text(" commutes with union and intersections and the balls form a subbasis.")

#text("Let ")#mi("B")#text(" be a ")#mi("\\|\\|_{W_\\beta}")#text(" ball. One can write for some r,")#linebreak()#text(" ")#tao-math("\\displaystyle T^{-1}(B)=\\{f\\in V: \\left\\|Tf\\right\\|_{W_\\beta}<r\\}", block: false)#linebreak()#text(" How can one write this as a union of finite intersections of balls in ")#mi("V")#text("? I expect that one can use the finite set ")#mi("A_\\beta")#text(" in the assumption. But I don't see how to construct the desired balls.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-671769")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2023")])]

#text("In Folland’s book, the author uses nets. I am wondering if one can work Exercise 4 out from basic definitions of continuity of maps between topological spaces.")

#text("Can one drop the “linear” assumption?")

#emph[#text("[Exercise 4 fails for nonlinear maps, even from ")#mi("{\\bf R}")#text(" to ")#mi("{\\bf R}")#text(". You should be able to find a counterexample without difficulty – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-671770")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2023")])]

#text("Is it by default assumed that ")#mi("V")#text(" and ")#mi("W")#text(" are topological vector spaces with the mentioned topologies?")

#emph[#text("[This follows from the remark at the end of Exercise 3 -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-671792")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2023")])]

#text("The question regarding Exercise 4 earlier was not summarized well, and I’d like to rephrase it here.")

#text("Exercise 4 is a generalization of “Lemma 1 (Continuity is equivalent to boundedness for linear operators)” in ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("Notes 3")]#text(". One can try to adapt the argument to prove Exercise 4.")

#text("The implication that ")#mi("T")#text(" being continuous implies the inequality for seminorms seems easy using homogeneity as in “Lemma 1”:")

#text("If ")#mi("T")#text(" is continuous, then it is continuous at ")#mi("0_V")#text(" particularly. If ")#mi("U")#text(" is a neighborhood of ")#mi("0_W=T(0_V)")#text(", then ")#mi("T^{-1}(U)")#text(" contains an open neighborhood ")#mi("O")#text(" of ")#mi("0_V")#text(" and ")#mi("O")#text(" is a finite intersection of balls by the seminorms in ")#mi("V")#text(". So there exists ")#mi("\\epsilon>0")#text(" and finitely many seminorms in ")#mi("V")#text(" such that")#linebreak()#text(" ")#tao-math("\\displaystyle \\left\\|Tf\\right\\|_{W_\\beta}<1", block: false)#linebreak()#text(" whenever")#linebreak()#text(" ")#tao-math("\\displaystyle \\left\\|f\\right\\|_{V_{\\alpha_j}}<\\epsilon,\\quad j = 1,\\cdots, k", block: false)#linebreak()#text(" One can then work with homogeneity as in \"Lemma 1\" to get ")#mi("C_\\beta")#text(".")

#text("The other implication seems more tricky. Suppose the seminorm inequalit(ies) are true. Then by linearity, as in \"Lemma 1\", to show that ")#mi("T")#text(" is continuous, it suffices to show that ")#mi("T")#text(" is continuous at ")#mi("0_V")#text(". In order to do that, here is the question: how could one show that")#linebreak()#text(" ")#tao-math("\\displaystyle \\{ f\\in V: \\sum_{\\alpha \\in A_\\beta} \\left\\| f\\right\\|_{V_\\alpha} <\\epsilon \\}", block: false)#linebreak()#text(" is an open set in ")#mi("V")#text("? (When the finite set ")#mi("A_\\beta")#text(" contains only ")#emph[#text("one")]#text(" element, this is rather trivial though.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-671973")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2023")])]

#text("Each seminorm ")#tao-math("f \\mapsto \\left\\|f\\right\\|_{V_\\alpha}", block: false)#text(" is a continuous function, so any finite sum of these seminorms is also continuous.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-671987")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2023")])]

#text("Sorry, I may misunderstand your comment, but I seem to get something circular then: in order to show that any finite sum of these seminorms is also continuous in the first place, I need to show that")#linebreak()#text(" that")#linebreak()#text(" ")#tao-math("\\displaystyle \\{ f\\in V: \\sum_{\\alpha \\in A_\\beta} \\left\\| f\\right\\|_{V_\\alpha} <\\epsilon \\}", block: false)#linebreak()#text(" is an open set in ")#mi("V")#text(", which what is to be proved.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-672005")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2023")])]

#text("The sum of any finite number of real-valued continuous functions is automatically continuous. (This is ultimately because the addition map ")#mi("+: {\\bf R} \\times {\\bf R} \\to {\\bf R}")#text(" defined by ")#mi("(x,y) \\mapsto x+y")#text(" is continuous.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-672021")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2023")])]

#text("If one takes two seminorms, ")#mi("\\|\\|_{V_1}")#text(" and ")#mi("\\|\\|_{V_2}")#text(", then in order to show the continuity of ")#tao-math("f\\mapsto\\left\\|f\\right\\|_{V_1}+\\left\\|f\\right\\|_{V_2}", block: false)#text(" using the continuity of the addition map of real numbers, I think I need to show first that ")#tao-math("f\\mapsto (\\left\\|f\\right\\|_{V_1}, \\left\\|f\\right\\|_{V_2})", block: false)#text(" is continuous. But then I end up needing to show that the sets of the form")#linebreak()#text(" ")#tao-math("\\{f:\\left\\|f\\right\\|_{V_1}^2+\\left\\|g\\right\\|_{V_2}^2<\\epsilon\\}", block: false)#linebreak()#text(" are open in ")#mi("V")#text(", which is quite the same as what is to be proved… What do I miss?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-672030")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2023")])]

#text("Ah, never mind. I was lost. That should follow from properties of the product topology on ")#mi("{\\bf R}\\times{\\bf R}")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-672068")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2023")])]

#text("Dr. Tao: How do you have so much patience answering such simple questions? People shouldn’t abuse this blog.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-671373")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2023")])]

#text("Exercise 13 and Theorem 3 in Section 3 in this set of notes use the norm on ")#mi("V^*")#text(". But the notion of operator norms, of which the norm on ")#mi("V^*")#text(" is a special case, is not defined until Section 4. Do I miss anything? Was it defined or mentioned already before this set of notes?")

#emph[#text("[See ")#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/")[#text("Notes 6")]#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-672087")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2023")])]

#emph[#text("Instead, one often first works in a weaker topology, in which compactness is easier to establish, and then somehow upgrades any weakly convergent sequences obtained via compactness to stronger modes of convergence …")#linebreak()#text(" ")]

#text("In this situation, could one have worked (in principle maybe) at the very beginning directly with the stronger topologies that give the “stronger modes of convergence” by rearranging the arguments without referring to any “weak” topologies?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-672115")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2023")])]

#text("It is usually the case that stronger topologies don’t work, then we go to weak topologies.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-672875")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2023")])]

#text("In Exercise 26, how does one know that the three topologies are nested? The chain of inequalities:")#linebreak()#text(" ")#tao-math("\\displaystyle \\left|\\lambda (T_1-T_2)(x)\\right|\\le \\left\\|\\lambda\\right\\|_{Y^*} \\left\\|T_1-T_2\\right\\|_{op}\\left\\|x\\right\\|_X", block: false)#linebreak()#text(" shows that sub-basic sets in these topologies are nested. For instance,")#linebreak()#text(" ")#tao-math("\\displaystyle B_{op}(T,\\varepsilon/\\left\\|x_0\\right\\|_X) \\subset B_{\\rho(\\cdot,x_0)}(T,\\varepsilon)", block: false)#linebreak()#text(" where ")#tao-math("\\rho(T,x_0)=\\left\\|Tx_0\\right\\|_Y", block: false)#text(". Does this imply that the operator norm topology is finer than the strong operator topology?")

#text("In general, if one has two topologies ")#mi("\\mathcal{T}_1")#text(" and ")#mi("\\mathcal{T}_2")#text(" with subbases ")#mi("B_1")#text(" and ")#mi("B_2")#text(" respectively, and if for every ")#mi("B\\in B_1")#text(" there exists ")#mi("B^{\\prime}\\in B_2")#text(" such that ")#mi("B^{\\prime}\\subset B")#text(", can one conclude that ")#mi("T_2")#text(" is finer than ")#mi("T_1")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-672891")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2023")])]

#text("Yes. What you wrote is correct.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-673019")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2023")])]

#text("In Exercise 10, is it less useful to define the open sets in ")#mi("V/W")#text(" using the forward image of open sets (in ")#mi("V")#text(") under the map ")#mi("\\pi")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-673032")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2023")])]

#text("We want it to be a topology, not sure what will one achieve by using the forward image of open sets.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-673186")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2023")])]

#text("To show the continuity of addition in V/W for Exercise 10, suppose let ")#mi("[v_1], [v_2]\\in V/W")#text(" and ")#mi("U\\subset V/W")#text(" is an open set that contains ")#mi("[v_1]+[v_2]=[v_1+v_2]")#text(". Then ")#mi("v_1+v_2")#text(" is in the open set ")#mi("\\pi^{-1}(U)")#text(". By continuity of addition in ")#mi("V")#text(" one has open sets ")#mi("O_1, O_2")#text(" in ")#mi("V")#text(" such that ")#mi("(v_1,v_2)\\in O_1\\times O_2")#text(" and ")#mi("O_1+O_2\\subset \\pi^{-1}(U)")#text(".")

#text("To show the continuity of the addition of V/W, one needs an open set ")#mi("O")#text(" in ")#mi("V/W\\times V/W")#text(" that contains ")#mi("([v_1], [v_2])")#text(" and the image of ")#mi("O")#text(" under addition is contained in ")#mi("U")#text(". How can one get the desired ")#mi("O")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-673187")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2023")])]

#text("By chasing the maps, one can see that ")#mi("\\pi(O_1)\\times \\pi(O_2)\\in V/W\\times V/W")#text(" and it contains ")#mi("([v_1],[v_2])")#text(". But unfortunately, it is not necessarily open.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-673202")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2023")])]

#text("Okay, it seems (much) easier to work with the inverse image of open sets instead of continuity at a point. It would be interesting to see if it is possible to fix the argument above directly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-673262")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2023")])]

#text("Can you give a hint for the implication that ")#mi("V")#text(" being Hausdorff topological vector space and ")#mi("W")#text(" being a closed subspace of ")#mi("V")#text(" implies ")#mi("V/W")#text(" is Hausdorff in exercise 10? How can one construct two open sets to separate ")#mi("[p]\\neq [q]")#text(" in ")#mi("V/W")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-673654")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2023")])]

#text("I think I’ve figured it out: one can work out Exercise 6 first. One then uses the fact that the projection ")#mi("\\pi: V\\to V/W")#text(" is continuous, and thus a set ")#mi("C")#text(" is closed in ")#mi("V/W")#text(" if and only if ")#mi("\\pi^{-1}(C)")#text(" is closed in ")#mi("V")#text(". Now one can let ")#mi("C=\\{0+W\\}")#text(".")

#text("(It is rather difficult to prove the result directly from the definition of Hausdorff. One has to exploit the properties of topological ")#emph[#text("vector")]#text(" spaces.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-673480")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2023")])]

#text("For Exercise 6, does one eventually also need to use the fact that the open set ")#mi("U")#text(" in the hint could be assumed in addition that ")#mi("U=-U")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-692626")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2026")])]

#text("I am confused about the relationship between weak convergence and weak-* convergence. In my probability theory course, I was taught that vague convergence and convergence in distribution are weak convergence, but in my measure theory course, I was taught that they are weak-* convergence. I would like to ask: What is the essential difference between weak convergence and weak-* convergence?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-2/#comment-692629")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2026")])]

#text("I am ")#link("https://claude.ai/share/c93eb9b5-f1df-41b9-9f5c-c5903564d289")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-36093")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2009")])]

#text("Exercise 15: I thought in l^1 a sequence converges iff it converges weakly? The first statement is true for 1 < p < oo.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/626e53d46c710500df401cd08527c0d77bc41c025132055eb6b1eff8f8e41115-d87af44ed68cc76739d63ca4c13478d58612e8f3dab93013de42dffa7899abb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-36101")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2009")])]

#text("The answer to the Question after Corollary 5 is yes. More generally, the predual of any (norm-)separable Banach space is separable. Indeed, if V is not separable, then by induction we can construct a well-ordered strictly increasing sequence of closed subspaces of order type ")#mi("\\omega_1")#text(". By Hahn-Banach, the orthogonal complements of these spaces are a strictly decreasing sequence of closed subspaces of V*. But this is impossible in a second-countable space, so this implies that V* cannot be norm-separable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-36103")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2009")])]

#text("Thanks for the correction and answer to the question!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f9a3c428419604c4989061251931f139fa27828d938f73143c5742a891c410d-9cd2585161352bde24b07ef727b2750612cf99655b6aba76173b9b0813ac6fa7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-600534")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2020")])]

#text("Dr. Tao, I have question please, how to prove that the weak zero neighborhood {x \\in l_1 : | <= 1 } is unbounded with respect to the norm ||.||_1 ?")#linebreak()#text(" Here, w is in l_{infty} \\ {0}.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7038bddc76c3537b53de0d4fa4319c725cfe92725b84fe56924d31dc8bfa51e-ae4c6416cd2d28231a462d832891fe6327c6f2b1bee584ef500eaef3e6b9b4b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-36116")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2009")])]

#text("How does Banach-Alaoglu not contradict F. Riesz’s Theorem that a TVS is locally compact if and only if it is finite-dimensional?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/626e53d46c710500df401cd08527c0d77bc41c025132055eb6b1eff8f8e41115-d87af44ed68cc76739d63ca4c13478d58612e8f3dab93013de42dffa7899abb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-36117")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2009")])]

#text("Re anon: Banach-Alaoglu says that the ")#emph[#text("norm")]#text(" unit ball in a dual space is weak* compact. This does not say that the space is locally compact in the weak* topology because the unit ball has empty interior in the weak* topology.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9040bac26d9a740f9318df61e97779ca8729000df38e4d9aed7ead17b4525756-d4b843ec87daf04a3f02fc66e356632cef15aa27155f9df47406b0c63a31109f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt Daws")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-36121")[#strong[#text("Matt Daws")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2009")])]

#text("For Remark 2, consider ")#mi("\\ell^1")#text(", which has many, many preduals. Indeed, let ")#mi("K")#text(" be any countable compact space, and consider ")#mi("C(K)")#text(". The dual is ")#mi("M(K)")#text(". As $K$ is countable, and as any measure is countably additive, ")#mi("M(K) = \\ell^1(K)")#text(" in the canonical way. Then if ")#mi("(x_n)")#text(" is a sequence in ")#mi("K")#text(" with ")#mi("x_n\\rightarrow x_0")#text(" say, then ")#mi("\\delta_{x_n} \\rightarrow \\delta_x")#text(" in the weak*-topology in ")#mi("\\ell^1(K)")#text(", where ")#mi("\\delta_y")#text(" is the point mass at ")#mi("y\\in K")#text(". So by choosing non-homeomorphic ")#mi("K_1")#text(" and ")#mi("K_2")#text(", we have found preduals for ")#mi("\\ell^1")#text(" which induce distinct weak*-topologies.")

#text("Indeed, preduals of ")#mi("\\ell^1")#text(" can be very weird indeed. The ")#link("http://gowers.wordpress.com/2009/02/07/a-remarkable-recent-result-in-banach-space-theory/")[#text("Argyros-Haydon space")]#text(" is an example!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-36122")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2009")])]

#text("Thanks for the example and the comments!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of less than epsilon")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-36128")[#strong[#text("less than epsilon")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2009")])]

#text("In example 5, is summation index from 0 to k or 0 to infinity?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of less than epsilon")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-36129")[#strong[#text("less than epsilon")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2009")])]

#text("Between exc 13 and remark 3: ” a seq ")#mi("\\lambda_{n}")#text(" in V converges in the weak star topology……”")

#text("should it be ” a seq ")#mi("\\lambda_{n}")#text(" in V star …….” ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-36131")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2009")])]

#text("Thanks for the corrections!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-36210")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2009")])]

#text("This is in relation to exercise 23, part 2. In class, we showed that pointwise convergence implies by the UBP that the ")#mi("\\lambda_{n}")#text(" are bounded, and immediately concluded that we get weak convergence. Isn’t a step through exercise 17 needed, to show that ")#tao-math("\\displaystyle \\left\\|\\lambda\\right\\|_{V^*}", block: false)#text(" is finite so that ")#mi("\\lambda")#text(" is in ")#mi("{V^* \\equiv \\ell^1({\\mathbb N})}")#text("? Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-36215")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2009")])]

#text("Well, in the exercise ")#mi("\\lambda")#text(" is assumed to be in ")#mi("\\ell^1({\\Bbb N})")#text(" already. But yes, one could use Exercise 17 (which is proven using the UBP in any case); also, from Fatou’s lemma, the pointwise limit of sequences bounded in ")#mi("\\ell^1({\\Bbb N})")#text(" is automatically in ")#mi("\\ell^1({\\Bbb N})")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1013eb9df3fb1866c715a1ceb8fa1e9ab166610a95f470d9ef576d3b9bf05b39-94fe98c03916903d8e96bf2e3d0505a842bd5be8c8a301baff405f8bea459f3f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yasser Taima")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-36222")[#strong[#text("Yasser Taima")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2009")])]

#text("In the proof of Theorem 3 (Banach-Alaoglu theorem), is it necessary to take the unit ball ")#mi("{B}")#text(" closed ? To identify ")#mi("{B^*}")#text(" with a subset of ")#mi("{D^B}")#text(", I believe if I take the map ")#mi("{\\phi: {B^*} \\rightarrow {D^B}}")#text(" defined as ")#mi("{\\phi(f) := f\\downharpoonright_{B}}")#text(", then by linearity of ")#mi("{f}")#text(", ")#mi("{f\\downharpoonright_{B} = 0}")#text(" implies ")#mi("{f = 0 on all of V}")#text(", hence in ")#mi("{B^*}")#text(". This seems to work for the ")#mi("{B}")#text(" closed or open.")

#text("Also, the reference to exercise 27 in Notes 10, in the proof of the sequential Banach-Alaoglu theorem might well be to exercise 28 instead. Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-36223")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2009")])]

#text("Dear Yasser: Thanks for the correction! It is true that one can take B to be either closed or open for the proof. (It is essential, though, that ")#mi("B^*")#text(" be closed.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd510153472d42259abe891371a9140439ab72dc5aa8848d761d2e48f1e899d9-2e0699aeb9766f97b1339747600ff56c22895e546e51a43aa4682fc541c0b300.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of etale")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-36254")[#strong[#text("etale")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2009")])]

#text("In exercise 22 :”Show that {W} is closed in the weak topology of {W}. ”")#linebreak()#text(" Should “closed” be replaced by some other concepts like “complete”? A space is trivially closed in any topology on it by definition.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 12: Continuous functions on locally compact Hausdorff spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-36259")[#strong[#text("245B, Notes 12: Continuous functions on locally compact Hausdorff spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2009")])]

#text("[…] and -compact. As is equivalent to the dual of the Banach space , it acquires a weak* topology (see Notes 11), known as the vague topology. A sequence of Radon measures then converges vaguely to a limit if […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-36260")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2009")])]

#text("Dear Etale: Oops, the exercise is meant to state that W is closed in the weak topology of V. It’s corrected now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fcb276611e2ba8229cca78fbfc7749d1f40c9c67d9dd8aa4b0e79522003781bc-80c3289cdf95fc41037506fb62dc18d34b9d05a3cef232085240873b91fb7e3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sebastian Scholtes")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-36385")[#strong[#text("Sebastian Scholtes")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2009")])]

#text("Dear Prof. Tao,")

#text("I have a question regarding Exercise 8, if the statement was true the following argument would be valid (if I’m not mistaken):")

#text("Let ")#mi("f_n \\to f")#text(" in ")#mi("L^1")#text(", every subsequence ")#mi("f_{n_k}")#text(" also converges in ")#mi("L^1")#text(", such that there is a subsubsequence which converges pointwise almost everywhere. With a subsubsequence convergence principle (sometimes called Urysohn’s principle) for topological spaces one concludes for the whole sequence ")#mi("f_n \\to f")#text(" almost everywhere, which we know is false, i.e. [Counterexamples in Analysis, Gelbaum, Olmsted, Example 40, p.111 (iii)")#mi("\\not\\Rightarrow")#text(" (i)].")

#text("I would be very grateful if you could clarify whatever is wrong with my reasoning or the exercise, since I don’t need another sleepless night (-; .")

#text("Best regards")#linebreak()#text(" Sebastian Scholtes")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-36396")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2009")])]

#text("Dear Sebastian,")

#text("Hmm, you’re right. I was trying to glue together the various notions of uniform convergence outside of small sets as given by Egoroff’s theorem, but I didn’t get the quantifiers right and indeed this does not generate a topology, by your Urysohn principle argument. So I’ve replaced the exercise with its negation. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-37494")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2009")])]

#text("Dear Professor Tao:")

#text("The last bracket of exercise 16, it should be ")#mi("x\\in V")#text(", instead of ")#mi("x\\in F")#text(" ")#emph[#text("[Corrected, thanks – T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-38345")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2009")])]

#text("Dear Prof. Tao,")

#text("I guess in example 2 ‘")#mi("x \\in C")#text("‘should be ‘")#mi("x \\in X")#text("‘.")

#emph[#text("[Corrected, thanks – T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e4ae3d4aea38bd3d5b8f6af61e0d6baca66f3297685367c7eda488369874a4a-eae94d7eb0e50c577aa0af7b26d16f6d0878775b41db332c545f3e47ad0be0a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-45198")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2010")])]

#text("Dear Prof. Tao")#linebreak()#text(" I have a question about the compactness of the closed unit ball of a dual space.I want to know wheather or not it’s compact in the strong operator topology.what’s the reason?")#linebreak()#text(" Best regards")#linebreak()#text(" Jafar soltani farsani")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4aa5909e2cb0c404ab4e883944e3e5b432a0a43ba65d72fad57efdddd97878e-ee4f7f953343585a9fdf0833ab4065178ac268cc3901cdc07e81dcd0185143ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Mckenzie")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-47041")[#strong[#text("Daniel Mckenzie")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2010")])]

#text("Hey prof. Tao")#linebreak()#text(" Not that it makes much difference, but shouldn’t the statement ‘the weak-$latex*$ topology on the dual of a separable space is metrisable’ read ‘the weak-$latex*$ topology on the dual of a separable space is metrisable on norm-bounded subsets of ")#mi("X^{*}")#text("‘?")

#emph[#text("[Corrected, thanks – T.]")]

#text("regards")#linebreak()#text(" Daniel")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 4: Modes of convergence « What’s new")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-47870")[#strong[#text("245A, Notes 4: Modes of convergence « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2010")])]

#text("[…] not attempt to exhaustively enumerate these modes here (but see this Wikipedia page, and see also these 245B notes on strong and weak convergence). We will, however, discuss some of the modes of convergence that arise from measure theory, when […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac65ef2389193a0be920f42ba57a7247b1a3cf5dc5196f85bc701dd95a415c14-7e24e67e2b7f61272af3084d47855e9f1aa87190fd3de5316adf3ad2430fdc65.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jean")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-47947")[#strong[#text("Jean")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2010")])]

#text("Does the weak* convergence in {L^\\infty} implies the convergence almost everywhere (up to a subsequence if necessary)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-47950")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2010")])]

#text("No. For instance, on the torus ")#mi("{\\bf R}/{\\bf Z}")#text(", the exponential functions ")#mi("e^{2\\pi i nx}")#text(" converge in the weak-* sense to zero (the Riemann-Lebesgue lemma), but clearly do not converge almost everywhere to zero, even after taking subsequences. The point is that weak-* convergence allows for an “escape to frequency infinity” that is not convergent under any convergence method based on the absolute value rather than on the phase.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems « What’s new")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-48077")[#strong[#text("245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2010")])]

#text("[…] The claim then follows by another appeal to the definition of lim inf. Remark 12 Informally, Fatou’s lemma tells us that when taking the pointwise limit of unsigned functions , that mass can be destroyed in the limit (as was the case in the three key moving bump examples), but it cannot be created in the limit. Of course the unsigned hypothesis is necessary here (consider for instance multiplying any of the moving bump examples by ). While this lemma was stated only for pointwise limits, the same general principle (that mass can be destroyed, but not created, by the process of taking limits) tends to hold for other “weak” notions of convergence. We will see some instances of this in 245B. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c51828e11fa52470e975bba15d63eb912f2e32918d4f0dbaae0f9735b96325ce-bde31a8a9fb0c7f39531b359a695c363280769c6eb4b72ed43f1627a92fc265a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-48874")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2010")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I’m greatly confused about Example 3, in particular about continuity of multiplication with respect to such topology. If ")#mi("[X=(0,1)]")#text(" and ")#mi("[f(x)=\\frac{1}{x}]")#text(", it seems to me that for arbitrary ")#mi("[\\alpha\\neq 1]")#text(", ")#mi("[\\alpha f \\not\\in B(f, r)")#text(" for any r. Doesn’t it imply than multiplication is not continuous, since ")#mi("[(\\alpha, f)]")#text(" has no neighbourhood which is mapped into ")#mi("[B(f, r)]")#text("? It’s probably just my misunderstanding, but I would really appreciate pointing out my mistake.")#linebreak()#text(" Best regards,")#linebreak()#text(" Marcin Łoś")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-48880")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2010")])]

#text("Ack, you’re right. I’ve rewritten the example accordingly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c51828e11fa52470e975bba15d63eb912f2e32918d4f0dbaae0f9735b96325ce-bde31a8a9fb0c7f39531b359a695c363280769c6eb4b72ed43f1627a92fc265a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-49147")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2010")])]

#text("Dear Prof. Tao,")#linebreak()#text(" Thank you for taking time to reply. I believe there might be a problem with ex. 19, 3rd dot. If we take any unit vector ")#mi("e")#text(", the sequence ")#mi("(-1)^n e")#text(" is Césaro-convergent to 0 (since norm of a partial sum is bounded by 1), but surely there is no subsequence weakly convergent to 0. Sorry if it’s just some stupid misunderstanding. If it’s not, is it still possible to prove the 4th dot?")#linebreak()#text(" Merry Christmas,")#linebreak()#text(" Marcin Łoś")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-49153")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2010")])]

#text("Oops, you’re right, the third item is not correct and should be deleted. The fourth item still seems correct to me though (the main trick in proving the “only if” direction being to normalise x to zero and then to use weak convergence choose a subsequence where the vectors are approximately orthogonal to each other).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-50710")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2011")])]

#text("I’m confused by the concepts here. It seems that the strong closure of each set is included in its weak closure. So one can say “weakly closed sets are strongly closed” or “strongly closed sets are weakly closed”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-50711")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2011")])]

#text("Yes, and you should be able to work out which way the inclusion goes. (Hint:")#linebreak()#text(" a good example to settle one’s intuition here is the unit sphere in, say, ")#mi("\\ell^2({\\bf N})")#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-50712")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2011")])]

#text("Hmm, maybe the standard orthonormal basis ")#mi("B=\\{e_n\\}_{n=1}^{\\infty}")#text(" in ")#mi("\\ell^2({\\bf N})")#text(" is enough? So ")#mi("B\\cup \\{0\\}")#text(" is weakly closed and also strongly closed, but ")#mi("B")#text(" is only strongly closed not weakly closed?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-50714")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2011")])]

#text("Yes :-), I think so.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-52221")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2011")])]

#text("Dear Prof. Tao,")

#text("I think that the dual space ")#mi("l^1({\\bf N})")#text(" of ")#mi("c_0({\\bf N})")#text(" is not complete under the weak")#mi("^*")#text(" topology (since we can approximate the elements in ")#mi("l^2({\\bf N})")#text(" by ")#mi("l^1({\\bf N})")#text(" under this topology), and that we can apply the Banach-Alaoglu Thm to ")#mi("l^1({\\bf N})")#text(" .")

#text("But you mentioned that one should have complete topology if he wants to apply Banach-Alaoglu Thm. For this reason, I am a little bit doubted if I am right.")

#text("Thanks a lot!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-52223")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2011")])]

#text("Completeness is a notion that only makes sense for metric spaces, not for topological spaces. The weak-* topology is not metrisable, and so there is no meaningful way to discuss completeness (unless one uses the notion of completeness for uniform spaces or something, but this does not seem to be your intention here).")

#text("Note also that the weak-* topology on ")#mi("\\ell^1(N)")#text(" is distinct from the weak-* topology on ")#mi("\\ell^2(N)")#text(", because convergence in the former requires convergence when evaluated at all members of ")#mi("c_0(N)")#text(", whereas convergence in the latter only requires convergence when evaluated at all members of the smaller space ")#mi("\\ell^2(N)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-52224")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2011")])]

#text("Dear Prof. Tao,")

#text("Many thanks for your prompt reply! I got some point!")

#text("I am still a little confused on Exercise 21, the weak* topology of the dual ")#mi("V^*")#text(" of Banach space ")#mi("V")#text(" is complete.")

#text("Could you give some explanation for this? It seems the completeness of the functional space plays an important role. Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-459811")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2015")])]

#text("Does the article in wikipedia (")#link("https://en.wikipedia.org/wiki/Complete_topological_space")[#text("https://en.wikipedia.org/wiki/Complete_topological_space")]#text(") suggest that people can still define the notion of completeness in a topological space using Cauchy nets?")

#emph[#text("[If the topological space comes with the structure of a Cauchy space, then yes. -T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 2: Building Lie structure from representations and metrics « What’s new")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-75273")[#strong[#text("254A, Notes 2: Building Lie structure from representations and metrics « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2011")])]

#text("[…] norm on the vector space. However, not every topological vector space is generated by a norm. See these notes for some further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-129055")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2012")])]

#text("Does the “algebraic topology” of Exercise 9 actually arise in some natural context (if so, where?), or is it something cooked up solely to serve as a counterexample?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-129066")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2012")])]

#text("The notion of algebraic openness is natural when considering geometric versions of the Hahn-Banach theorem (see Theorem 4 of ")#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/")[#text("Notes 6")]#text("). But outside of that, I don’t know of any other major application of this topology.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-129079")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2012")])]

#text("Incidentally, it might be worthwhile to mention the Zariski topology, which is also another topology (the simplest and most natural I can think of) on ")#mi("\\mathbb{R}^n")#text(" or ")#mi("\\mathbb{C}^n")#text(" that does not make it into a topological vector space.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-151266")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2012")])]

#text("in Remark 1, on line 3 from bottom, “compacta” should be “compact”.")

#emph[#text("[Corrected, thanks. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/600e46e0a4ecede5639336a7514dececeae795e184d8907aa2220609a048a64a-a6755feb1e6b0c356542444a8fd482b0e51b9964814abacb3969bcd70c0368ab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-151612")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2012")])]

#text("I do not understand the last part of Exercise 13: “Show that the weak* topology on the dual is weaker than the weak topology on the dual (which is defined using the double dual)”.")

#text("But how do we define the double dual (V*)* if the dual V* does not have a topology yet?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-151639")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2012")])]

#text("Sorry, in the last two parts of that question V should also be assumed to be a normed vector space; the question has been updated accordingly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/600e46e0a4ecede5639336a7514dececeae795e184d8907aa2220609a048a64a-a6755feb1e6b0c356542444a8fd482b0e51b9964814abacb3969bcd70c0368ab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-151956")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2012")])]

#text("Ok, thanks for the reply!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-255443")[#strong[#text("Linear elliptic equations with measure data I | Partial Differential Australians")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2013")]

#text("[…] and we say that a sequence in converges to in weak- if for all . Further details can be found in Terry Tao’s notes on the subject. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7614a2c4691cdcfcd7b12d0ff115050a27f7dba3df90c51443dbb8fab68672c9-0c2aa5e669f13dca4e240098892a37c40183381a9f3b978580a99c8cfa52209b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of André Caldas")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-335750")[#strong[#text("André Caldas")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2014")])]

#text("Dear professor,")

#text("In Exercise 12, item 1, if you consider ")#mi("V^{\\prime}")#text(" the space spawned by ")#mi("W")#text(" and ")#mi("x")#text(", then the problem is reduced to the finite-dimensional normed space ")#mi("V^{\\prime}")#text(", right? It seems to me that the conclusion is wrong. In special, because of your comment: “in contrast to the situation with Hilbert spaces”. But ")#mi("V^{\\prime}")#text(" is a Hilbert space, right?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-335918")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2014")])]

#text("Uniqueness can fail for some normed spaces V (including some finite dimensional spaces), but can hold for other spaces (such as Hilbert spaces). Uniqueness is ")#emph[#text("necessarily")]#text(" true if V is a Hilbert space, but is ")#emph[#text("not necessarily")]#text(" true if one only assumes that V is a normed vector spaces.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7614a2c4691cdcfcd7b12d0ff115050a27f7dba3df90c51443dbb8fab68672c9-0c2aa5e669f13dca4e240098892a37c40183381a9f3b978580a99c8cfa52209b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of André Caldas")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-335942")[#strong[#text("André Caldas")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2014")])]

#text("Sorry! I fell for the “all norms are equivalent” cavet! Very silly of me… the example is very easy to construct in dimension two and the supremum norm.")

#text("Thank you very much for your time.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-441261")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2014")])]

#text("Some people define the weak topology on ")#mi("V")#text(" with respect to ")#mi("V^*")#text(" as the weakest topology on ")#mi("V")#text(" so that all the linear functional ")#mi("f\\in V^*")#text(" remain continuous in this new topology. Is this definition equivalent to the one in Definition 2?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-441378")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2014")])]

#text("Yes; I recommend verifying this as an exercise.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-452716")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2015")])]

#text("In the proof of Theorem 3 (Alaoglu):")#linebreak()#text(" ")#emph[#text("one can identify ")#mi("{B^*}")#text(" with a subset of ")#mi("{D^B}")#text(", the space of functions from ")#mi("{B}")#text(" to ")#mi("{D}")]#text(".")

#text("For “identify”, do you mean a “homeomorphism” (topological isomorphism) or just a “bijection” (set isomorphism) ?")

#text("If one defines ")#mi("f: B^*\\to D^B")#text(" by ")#mi("f(\\varphi)=\\varphi\\mid_B")#text(". Then ")#mi("f:B^*\\to f(B^*)")#text(" is bijective.")

#emph[#text("One easily verifies that the weak* topology on ")#mi("{B^*}")#text(" is nothing more than the product topology of ")#mi("{D^B}")#text(" restricted to ")#mi("{B^*}")#text(".")]

#text("Let ")#mi("{\\mathcal T_1}")#text(" be the weak* topology on ")#mi("{B^*}")#text(" and ")#mi("{\\mathcal T_2}")#text(" be the product topology of ")#mi("{D^B}")#text(" restricted to ")#mi("f(B^*)")#text(". One can show that a net ")#mi("\\{\\varphi_\\alpha\\}_{\\alpha\\in A}")#text(" converges to a ")#mi("\\varphi")#text(" in ")#mi("(B^*,{\\mathcal T}_1)")#text(" if and only if ")#mi("\\{f(\\varphi_{\\alpha})\\}_{\\alpha\\in A}")#text(" converges to ")#mi("f(\\varphi)")#text(" in ")#mi("(f(B^*),{\\mathcal T_2})")#text(". Does it suggest that these two topologies are the “same”? (By Exercise 13 in Note 8, this only suggest that ")#mi("f")#text(" is continous.) As I’ve seen from Note 8, “nets” are in the “optional” section. Do you suggest that there is an alternative way to show that ")#mi("{\\mathcal T_1}")#text(" and ")#mi("{\\mathcal T_2}")#text(" are the same?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-452729")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2015")])]

#text("Initially, the identification is only on the level of sets (i.e. as a bijection), but once one verifies that the topologies are compatible (in your notation) then the identification is at the level of topological spaces (i.e. as a homeomorphism).")

#text("Exercise 13 (combined with the fact that one has an “if and only if” rather than just an “only if” in the relation between convergence of nets) shows that f and its inverse are both continuous, i.e. that f is a homeomorphism. One can also demonstrate the homeomorphism property by considering the inverse image or forward image of sub-basic sets.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-452736")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2015")])]

#text("For “sub-basic” sets, do you mean sets in a subbasis of a topological space? (People use different spelling such as “subbase”, “sub-base”, etc. I’m usually confused about which one is grammatically correct.)")

#text("If we use ")#mi("D_x:=\\{z\\in{\\bf C}\\mid z|\\leq x\\}")#text(" and consider ")#mi("\\prod_{x\\in V}D_x")#text(" instead of ")#mi("D^B")#text(", I guess we could avoid working back and forth between ")#mi("V")#text(" and ")#mi("B")#text(" since ")#mi("B^*")#text(" is a subset (the elements of which have the linear property) of ")#mi("\\prod_{x\\in V}D_x")#text(". Still need to check the topology though, it might be slightly faster.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-460448")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2015")])]

#text("Sub-basic sets for ")#mi("(B^*,T_1)")#text(" can be ")#mi("\\{\\varphi\\in V^*:\\varphi(h)\\in U\\cap D\\}_{h\\in V}")#text(" with ")#mi("U")#text(" open in ")#mi("\\bf{C}")#text(". Sub-basic sets for ")#mi("(f(B^*), T_2)")#text(" are ")#mi("\\{g^{-1}(V)\\}")#text(" with ")#mi("V")#text(" open in ")#mi("D")#text(" and ")#mi("g\\in D^B")#text(". Would you elaborate how these two things can be used to show the homeomorphism?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-460449")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2015")])]

#text("Actually, the subbasic sets for ")#mi("{\\mathcal T}_2")#text(" are not of the form ")#mi("g^{-1}(V)")#text(" (which lives in the wrong space, namely B), but rather of the form ")#mi("\\{ \\phi \\in f(B^*): \\phi(h) \\in V \\}")#text(" for ")#mi("h \\in B")#text(" and ")#mi("V")#text(" open in ")#mi("D")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-460451")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2015")])]

#text("Ah, so the subbasic sets for ")#mi("\\mathcal{T}_1")#text(" are not be of the form ")#mi("\\{\\varphi\\in V^*:\\varphi(h)\\in U\\cap D\\}")#text(", but rather of the form ")#mi("\\{\\varphi\\in B^*:\\varphi(h)\\in U\\cap D\\}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-460452")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2015")])]

#text("For ")#mi("\\tau_1")#text(", the subbasic sets are of the form")#linebreak()#text(" ")#mi("\\{\\varphi\\in B^*:\\varphi(h)\\in U\\}")#text(" for ")#mi("h\\in V")#text(" and ")#mi("U")#text(" open in ")#mi("D")#text(". For ")#mi("\\tau_2")#text(", the subbasic sets are of the form ")#mi("\\{ \\phi|_B: \\phi(h) \\in U ,\\phi\\in B^*\\}")#text(" for ")#mi("h\\in B")#text(" and ")#mi("U")#text(" open in ")#mi("D")#text(". Denotes these two subbases as ")#mi("P")#text(" and ")#mi("Q")#text(".")

#text("To show ")#mi("f")#text(" is an open map, it suffices to show ")#mi("f(P)\\subset \\tau_2")#text(". To show ")#mi("f")#text(" is continuous it suffices to show that ")#mi("f^{-1}(Q)\\subset\\tau_1")#text(".")

#text("Let ")#mi("W")#text(" be open in ")#mi("D")#text(" and ")#mi("h\\in V")#text(". How can one show that the image of this subbasic set is in ")#mi("\\tau_2")#text("? (Since ")#mi("h")#text(" is not necessarily in ")#mi("B")#text(", I don’t see how one can make the argument here…)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-460453")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2015")])]

#text("Even if ")#mi("h")#text(" is not in ")#mi("B")#text(", some positive scalar multiple ")#mi("\\epsilon h")#text(" of ")#mi("h")#text(" will lie in ")#mi("B")#text(". One can then proceed using the homogeneity property ")#mi("\\varphi(\\epsilon h) = \\epsilon \\varphi(h)")#text(" of linear functionals.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-460460")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2015")])]

#text("If ")#mi("0<\\epsilon<1")#text(", then the image is")

#tao-math("\\{\\phi\\left|_B: \\epsilon \\phi\\right|_B(h)\\in W, \\phi\\in B^*\\} =\\{\\phi\\left|_B:  \\phi\\right|_B(h)\\in \\frac{1}{\\epsilon} W, \\phi\\in B^*\\}", block: false)

#text("Now I have a problem that ")#mi("\\frac{1}{\\epsilon} W")#text(" is not necessarily open in ")#mi("D")#text(" and ")#mi("\\phi|_B(h)")#text(" is not necessarily in ")#mi("D")#text("…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-460462")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2015")])]

#text("A set that is open in D is the intersection with D of a set which is open in ")#mi("{\\bf C}")#text(". So one should really just work with open sets in ")#mi("{\\bf C}")#text(", which behave well with respect to dilations by ")#mi("\\varepsilon")#text(" or ")#mi("1/\\varepsilon")#text(". (The restriction to D is already implicit in the definition of B and B^* anyway.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-460992")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2015")])]

#text("I eventually come up with a proof, which looks very ugly. I think that might be a reason why people prefer an argument via net convergence.")

#text("Consider in ")#mi("\\tau_2")#text(" the open set ")#tao-math("P:=\\{ \\phi\\left|_B: \\phi\\right|_B(h) \\in U\\cap D ,\\phi\\in B^*\\}", block: false)#text(" for some fixed ")#mi("h\\in B")#text(" and ")#mi("U")#text(" open in ")#mi("\\Bbb C")#text(". Note that")

#mi("f^{-1}(P)=\\{\\varphi\\in B^*:\\varphi|_B(h)\\in U\\cap D\\}\\\\ =\\{\\varphi\\in B^*:\\varphi(h)\\in U\\cap D\\},")

#text("which is the same(!) as")

#mi("\\{ \\phi \\in B^*: \\phi(h) \\in U \\}")

#text("since ")#mi("\\phi\\in B^*")#text(" and ")#mi("h\\in B")#text(". Note that this is a subbasic set in ")#mi("(B^*,\\tau_1)")#text(". It follows that ")#mi("f")#text(" is continuous (exercise).")

#text("Now we show that ")#mi("f")#text(" is an open map, which gives the continuity of ")#mi("f^{-1}")#text(". Consider in ")#mi("\\tau_1")#text(" the open set")

#mi("Q=\\{\\varphi\\in B^*:\\varphi(h)\\in U\\}")

#text("for ")#mi("h\\in V")#text(" and ")#mi("U")#text(" open in ")#mi("\\Bbb C")#text(". Note that ")#mi("h=\\epsilon h^{\\prime}")#text(" for some ")#mi("\\epsilon>0")#text(" and ")#mi("h^{\\prime}\\in B")#text(". Then")

#mi("Q=\\{\\varphi\\in B^*:\\varphi(h^{\\prime})\\in U^{\\prime}\\}")

#text("with ")#mi("U^{\\prime}=\\frac{1}{\\epsilon}U")#text(", which is also open in ")#mi("\\Bbb C")#text(". Since ")#mi("h^{\\prime}\\in B")#text(", for each ")#mi("\\varphi\\in B^*")#text(", we have")

#mi("\\varphi(h^{\\prime})\\in D.")

#text("It follows that")

#mi("Q=\\{\\varphi\\in B^*:\\varphi(h^{\\prime})\\in U^{\\prime}\\cap D\\}")

#text("and thus")#linebreak()#text(" ")#tao-math("f(Q)=\\{\\varphi\\left|_B:\\varphi\\in B^*,\\varphi\\right|_B(h^{\\prime})\\in U^{\\prime}\\cap D\\},", block: false)

#text("which is a subbasic set in ")#mi("\\tau_2")#text(". Since ")#mi("f:B^*\\to f(B^*)")#text(" is a bijection, ")#mi("f(Q)\\in\\tau_2")#text(" implies that ")#mi("f")#text(" is an open map.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-460723")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2015")])]

#text("Is the form of the subbasic sets for ")#mi("(B^*, T_1)")#text(" also wrong? Should it be ")#mi("\\{\\varphi\\in V^*:\\varphi(h)\\in U\\}\\cap B^*= \\{\\varphi\\in B^*:\\varphi(h)\\in U\\}")#text(" (with ")#mi("U")#text(" open in ")#mi("\\bf{C}")#text(" ")#mi("h\\in V")#text(") instead?")

#emph[#text("[Yes – T.]")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-460728")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2015")])]

#text("Maybe I’m still looking at things in a stupid wrong way. It makes sense now for me that for ")#mi("\\tau_1")#text(", the subbasic sets are of the form")#linebreak()#text(" ")#mi("\\{\\varphi\\in B^*:\\varphi(h)\\in U\\}")#text(" for ")#mi("h\\in V")#text(" and ")#mi("U")#text(" open in ")#mi("{\\bf C}")#text(". For ")#mi("\\tau_2")#text(", the subbasic sets are of the form ")#tao-math("\\{ \\phi\\left|_B: \\phi\\right|_B(h) \\in U ,\\phi\\in B^*\\}", block: false)#text(" for ")#mi("h\\in B")#text(" and ")#mi("U")#text(" open in ")#mi("D")#text(".")

#text("Now consider in ")#mi("\\tau_2")#text(" the open set ")#mi("P:=\\{ \\phi|_B: \\phi(h) \\in U ,\\phi\\in B^*\\}")#text(" for some fixed ")#mi("h\\in B")#text(" and ")#mi("U")#text(" open in ")#mi("D")#text(". Why is ")#mi("f^{-1}(P)")#text(" open in ")#mi("(B^*,\\tau_1)")#text(" (which shows that ")#mi("f")#text(" is continuous)? The operator ")#mi("f")#text(" is rather confusing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-460732")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2015")])]

#mi("f^{-1}(P)")#text(" is the set ")#mi("\\{ \\phi \\in B^*: \\phi(h) \\in U \\}")#text(", which is a subbasic set in the ")#mi("\\tau_1")#text(" topology. (Note that a linear functional on V is uniquely determined by its restriction to B.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-460734")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2015")])]

#text("Ah, one should really write ")#mi("P")#text(" as")

#mi("P=\\{ \\phi|_B: \\phi(h) \\in U\\cap D ,\\phi\\in B^*")

#text("for ")#mi("h\\in B")#text(" and ")#mi("U")#text(" open in ")#mi("{\\bf C}")#text(". Then ")#mi("f^{-1}(P)")#text(" is")

#mi("\\{ \\phi \\in B^*: \\phi(h) \\in U\\cap D \\}")

#text("which is the same(!) as")

#mi("\\{ \\phi \\in B^*: \\phi(h) \\in U \\}")

#text("since ")#mi("\\phi\\in B^*")#text(" and ")#mi("h\\in B")#text(".")

#text("(I don’t know what is the comment “Note that a linear functional on V is uniquely determined by its restriction to B.” used for though.)")

#text("Thanks a lot!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b6a1d5e8a4edac0c58aefd7284fef68f989a0c9f3193b46ec7999c3bb5957dc-ef565c90e87948c1365f3d78fa93d09bb76fb3aa1bbd67e8fe0c6ce9e6cff615.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sina")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-453648")[#strong[#text("Sina")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2015")])]

#text("nice and systematic explanation of topological vector spaces and weak norms. Was very useful as all these concepts were kind of blurry in my head. It is much more neater in my head now, thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-459160")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2015")])]

#text("Can boundedness be defined in a topological vector space?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-460346")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2015")])]

#text("Are the strong and weak topologies in this post essentially the final topology (")#link("https://en.wikipedia.org/wiki/Final_topology")[#text("https://en.wikipedia.org/wiki/Final_topology")]#text(") and initial topology (")#link("https://en.wikipedia.org/wiki/Initial_topology")[#text("https://en.wikipedia.org/wiki/Initial_topology")]#text(") defined in Wikipedia?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-460351")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2015")])]

#text("The weak one is quite obvious. I’m sure about the ")#emph[#text("strong")]#text(" topology though.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-460366")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2015")])]

#text("Well, at a tautological level, ")#emph[#text("any")]#text(" topology ")#mi("{\\mathcal F}")#text(" on a space X is an initial topology, namely the initial topoology corresponding to the identity map ")#mi("\\text{id}: X \\mapsto X")#text(" from ")#mi("(X, {\\mathcal F})")#text(" to ")#mi("X")#text(". So the strong topology is an initial topology for trivial reasons. But I don’t think there is any especially interesting way to think of the strong topology as an initial topology.")

#text("There is however the notion of an algebraically open set (see ")#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/")[#text("Notes 6")]#text(") which is openness in the initial topology coming from the collection of affine maps from the real line into a vector space. This topology is far stronger than either the strong or weak topologies.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-460356")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2015")])]

#text("I have checked throughout the 245B notes, but I don’t see the definition of “the topology generated by the seminorms”. One can use ")#emph[#text("a")]#text(" norm (seminorm) generate a topology by considering the metric (semimetric) defined by this norm and then the metric topology. What is going on with a family of seminorms? Would you elaborate?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-460365")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2015")])]

#text("The definition of the topology generated by a family of seminorms is given in Exercise 3 of this post (i.e. it is the weakest topology that contains all the topologies of each single seminorm).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-460642")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2015")])]

#text("I saw some text defines the weak topology on ")#mi("{V}")#text(" as the topology generated by the seminorms ")#tao-math("{\\left\\| x\\right\\|_F :=\\max_{\\lambda\\in F} \\left|\\lambda(x)\\right|}", block: false)#text(" for all finite ")#mi("F\\subset {V^*}")#text(". Is this definition equivalent to Definition 2?")

#emph[#text("[Yes, basically because open sets are closed under the operation of taking finite intersections; it’s a good exercise to work this out in detail. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-463909")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2015")])]

#text("Give ")#mi("{V}")#text(" the topology induced by a family of semi-norms ")#mi("{(\\| \\|_{V_\\alpha})_{\\alpha \\in A}}")#text(". Would you elaborate why the map")

#tao-math("x\\mapsto \\left\\|x-y\\right\\|_\\alpha", block: false)#text(" (for fixed ")#mi("y")#text(" and ")#mi("\\alpha")#text(")")

#text("is continuous from ")#mi("V")#text(" to ")#mi("\\mathbb{R}")#text("?")

#text("Denote the map above as ")#mi("f_y")#text(". Consider an open set ")#mi("O:=(3,4)")#text(" in ")#mi("\\mathbb{R}")#text(" for instance. Why is ")#mi("f^{-1}_y(O)")#text(" open in ")#mi("V")#text("?")

#emph[#text("[Use the triangle inequality to show that every point in ")#mi("f^{-1}_y(O)")#text(" contains a basic open neighbourhood that is contained in ")#mi("f^{-1}_y(O)")#text(". -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-463928")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2015")])]

#text("Let ")#mi("\\|\\|:=\\|\\|_\\alpha")#text(" for some fixed ")#mi("\\alpha")#text(".")#linebreak()#text(" Explicitly, we have")

#tao-math("\\displaystyle f_y^{-1}(O)=\\{x\\in V: 3<\\left\\|x-y\\right\\|<4\\}", block: false)#text(".")

#text("Suppose ")#mi("x")#text(" is a point in ")#mi("f_y^{-1}(O)")#text(", then ")#tao-math("3<\\left\\|x-y\\right\\|_\\alpha<4", block: false)#text(". Want to find ")#mi("r>0")#text(" such that")

#tao-math("\\displaystyle \\left\\|z-x\\right\\|<r", block: false)

#text("implies ")#tao-math("3<\\left\\|z-y\\right\\|_\\alpha<4", block: false)

#text("By the triangle inequality,")

#tao-math("\\displaystyle \\left|\\left\\|z-x\\right\\|-\\left\\|x-y\\right\\|\\right|\\leq \\left\\|z-y\\right\\|\\leq\\left\\|z-x\\right\\|+\\left\\|x-y\\right\\|", block: false)#text(".")

#text("I don’t see how to go on…")

#emph[#text("[Choose ")#mi("r")#text(" small enough that ")#tao-math("3 < \\left\\|x-y\\right\\|-r < \\left\\|x-y\\right\\|+r < 4", block: false)#text(". -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-463913")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2015")])]

#text("Let ")#mi("V")#text(" be a vector space with a norm ")#mi("\\|\\|")#text(". Define ")#mi("f_y:V\\to\\mathbb{R}")#text(" for each ")#mi("y\\in V")#text(" with")

#tao-math("\\displaystyle f_y(x)=\\left\\|x-y\\right\\|", block: false)#text(".")

#text("Let ")#mi("\\tau")#text(" be the initial topology ")#mi("\\tau")#text(" with respect to the family ")#mi("\\{f_y\\}_{y\\in V}")#text(". I’m trying to show that this is the same topology as the one in Exercise 1.")

#text("The continuity of ")#mi("f_y")#text(" shows that the ball (in exercise 1)")

#mi("\\displaystyle B(y,r)=f^{-1}((-\\infty,r))")

#text("where ")#tao-math("B(y,r)=\\{x\\in V: \\left\\|x-y\\right\\|<r\\}", block: false)#text(" is open. To show ")#mi("\\{B(x,r)\\}")#text(" forms a base for ")#mi("\\tau")#text(", let ")#mi("U")#text(" be an open nbhd at ")#mi("y_0\\in V")#text(". How can I find ")#mi("B(y_0,r)")#text(" contained in ")#mi("U")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-463919")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2015")])]

#text("Let ")#mi("V")#text(" be a vector space and ")#mi("f:V\\to\\mathbb{R}_+")#text(" be an arbitrary function. One define a “ball” as")

#mi("\\displaystyle B(x,r)=\\{x\\in V: f(y-x)0\\}")#text(".")

#text("What makes such topology less interesting/useful than the case when ")#mi("f")#text(" is a seminorm?")

#emph[#text("[Use &lt; and &gt; instead of < and > to avoid portions of text being interpreted incorrectly as HTML and thus lost. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6bb654f4b94b2375705f7eb939dce55634d62b8370722223b72758433b55320-5d691b56ef25c4388a23a36e1c3112ddc90f2f8819736f21d90adf326e914fc0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Robinson")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-465182")[#strong[#text("James Robinson")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2016")])]

#text("In Remark 5, should that be “no sequential weak-* compactness when ")#mi("V=\\ell^\\infty")#text(", i.e. you consider the closed unit ball in ")#mi("(\\ell^\\infty)^*")#text("? The closed unit ball in ")#mi("\\ell^\\infty")#text(" is sequentially weak-* compact since ")#mi("\\ell^1")#text(" is separable. (I was very worried for a while about this!)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-465893")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2016")])]

#emph[#text("Instead, one often first works in a weaker topology, in which compactness is easier to establish, and then somehow upgrades any weakly convergent sequences obtained via compactness to stronger modes of convergence (or alternatively, one abandons strong convergence and exploits the weak convergence directly). ")]

#text("Why could one “somehow upgrades any weakly convergent sequences obtained via compactness to stronger modes of convergence”? Is this similar to upgrading the regurality of weak solutions in PDE? Do you have a simple example to illustrate this philosophy?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-465895")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2016")])]

#text("Yes, elliptic regularity is the type of upgrading that I had in mind, in which the sequence (or its limit) is known to obey some additional properties, such as being a solution of an elliptic PDE. For instance, one way to solve the Dirichlet problem on a domain is to take a sequence of approximate minimisers to the Dirichlet energy functional, use weak compactness to extract a weak limit, show that this limit is weakly harmonic, and then use elliptic regularity to show that it is smooth. Using this and the strong convexity of the Dirichlet functional, one can then show that the minimising sequence converged strongly in H^1 rather than just weakly along a subsequence.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-466744")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2016")])]

#text("When ")#mi("V")#text(" is a normed space, one has two topologies for ")#mi("V^*")#text(", the norm topology and the weak-* topology. Which one is used when one defines ")#mi("(V^*)^*")#text("?")

#emph[#text("[By default, the double dual is defined using the norm topology on the dual. One could potentially define an alternate double dual using the weak-* topology, but this space is almost never used. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A quick application of the closed graph theorem | What's new")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-467859")[#strong[#text("A quick application of the closed graph theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2016")])]

#text("[…] In functional analysis, it is common to endow various (infinite-dimensional) vector spaces with a variety of topologies. For instance, a normed vector space can be given the strong topology as well as the weak topology; if the vector space has a predual, it also has a weak-* topology. Similarly, spaces of operators have a number of useful topologies on them, including the operator norm topology, strong operator topology, and the weak operator topology. For function spaces, one can use topologies associated to various modes of convergence, such as uniform convergence, pointwise convergence, locally uniform convergence, or convergence in the sense of distributions. (A small minority of such modes are not topologisable, though, the most common of which is pointwise almost everywhere convergence; see Exercise 8 of this previous post). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc2dd4ebeefc8f65e28a9c9451011d784b1081d92dd66b32a550061eaa39c9a7-355f8ffe79f68f85468dad0c9a96b005398fdabe28bcea7a6de74736a6df92bc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-469900")[#strong[#text("Nick")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2016")])]

#text("With respect to Ex. 5, is it not straightforward that the statement is true even in the box topology? Say ")#mi("V= \\prod V_i")#text(" is your infinite product and you have a box neighborhood ")#mi("\\prod U_i")#text(" of ")#mi("(x_i)=(w_i)+(z_i)")#text(", then for each ")#mi("i")#text(" simply take neighborhoods ")#mi("W_i, Z_i")#text(" of ")#mi("w_i, z_i")#text(" respectively such that ")#mi("W_i+Z_i \\subset U_i")#text(", and then take products. This shows continuity of the addition, and scalar multiplication is clear. Am I doing something wrong here?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc2dd4ebeefc8f65e28a9c9451011d784b1081d92dd66b32a550061eaa39c9a7-355f8ffe79f68f85468dad0c9a96b005398fdabe28bcea7a6de74736a6df92bc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-470058")[#strong[#text("Nick")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2016")])]

#text("In Exercise 26 I think it is not necessary to assume ")#mi("Y")#text(" is a Banach space. The second statement applies the first by a direct limiting argument. Conversely, in order to deduce boundedness of the operator norms from weak operator convergence, it is enough to apply Ex. 16 together with the uniform boundedness principle, neither of which assumes that ")#mi("Y")#text(" is complete.")

#emph[#text("[Fair enough; I’ve edited the exercise accordingly. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c06b5c608061b3433364d7a08c276448981d7dbe3ec5a42a3c2cf5097f6a6116-b2064c0da56b72183b36a8e311c8403011196cba9557b86b4ddceb8d838b15a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian")]], [#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/comment-page-1/#comment-474323")[#strong[#text("Ian")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2016")])]

#text("Professor Tao:")

#text("In exercise 16, is the suggested use of the Hahn-Banach Theorem just to verify that the norm of an element $x \\in V$ is the same as the norm of its corresponding functional $\\iota (x) \\in V^{**}$, or is this Theorem used in another substantial way?")

#emph[#text("[This is basically where HB is used, yes -T.]")]
]
