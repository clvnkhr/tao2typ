// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/10/18/garth-gaudry/
// Converted to Typst by tao2typ: "2026-10-14T09:28:21.070224+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Garth Gaudry", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Garth Gaudry")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 October 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/10/18/garth-gaudry/")[#text("https://terrytao.wordpress.com/2012/10/18/garth-gaudry/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Garth Gaudry, who made many contributions to harmonic analysis and to Australian mathematics, and was also both my undergradaute and masters advisor as well as the head of school during one of my first academic jobs, ")#link("http://www.amsi.org.au/news/87-general-and-outreach-news/958-vale-garth-gaudry")[#text("died yesterday")]#text(" after a long battle with cancer, aged 71.")

#text("Garth worked on the interface between real-variable harmonic analysis and abstract harmonic analysis (which, despite their names, are actually two distinct fields, though certainly related to each other). He was one of the first to realise the central importance of ")#link("http://en.wikipedia.org/wiki/Littlewood%E2%80%93Paley_theory")[#text("Littlewood-Paley theory")]#text(" as a general foundation for both abstract and real-variable harmonic analysis, writing an ")#link("http://www.ams.org/mathscinet-getitem?mr=618663")[#text("influential text with Robert Edwards")]#text(" on the topic. He also made contributions to ")#link("http://en.wikipedia.org/wiki/Clifford_analysis")[#text("Clifford analysis")]#text(", which was also the topic of my ")#link("http://www.math.ucla.edu/~tao/preprints/clifford.dvi")[#text("masters thesis")]#text(".")

#text("But, amongst Australian mathematicians at least, Garth will be remembered for his tireless service to the field, most notably for his pivotal role in founding the ")#link("http://www.amsi.org.au/")[#text("Australian Mathematical Sciences Institute")]#text(" (AMSI) and then serving as AMSI’s first director, and then in directing the ")#link("http://www.amsi.org.au/school-education/about")[#text("International Centre of Excellence for Education in Mathematics")]#text(" (ICE-EM), the educational arm of AMSI which, among other things, developed ")#link("http://www.icemaths.org.au/")[#text("a full suite of maths textbooks and related educational materials")]#text(" covering Years 5-10 (which I ")#link("http://austmaths.wordpress.com/2008/05/14/ice-em-mathematics-textbooks-review/")[#text("reviewed here")]#text(" back in 2008).")

#text("I knew Garth ever since I was an undergraduate at ")#link("http://www.flinders.edu.au/")[#text("Flinders University")]#text(". He was head of school then (a position roughly equivalent to department chair in the US), but still was able to spare an hour a week to meet with me to discuss real analysis, as I worked my way through Rudin’s “Real and complex analysis” and then Stein’s “Singular integrals”, and then eventually completed a masters thesis under his supervision on Clifford-valued singular integrals. When Princeton accepted my application for graduate study, he convinced me to take the opportunity without hesitation. Without Garth, I certainly wouldn’t be where I am at today, and I will always be very grateful for his advisorship. He was a good person, and he will be missed very much by me and by many others.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e6f9636aff4e8efe4f609718e99d3efcc5d132dc590b2294f863aa6072fc4c2-ef6a1eba3a4d425a0ccc25fb352a292dd688da2e3dce9fb615482db41998fc1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of iamdibakardatta")]], [#link("https://terrytao.wordpress.com/2012/10/18/garth-gaudry/#comment-183671")[#strong[#text("iamdibakardatta")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2012")])]

#text("“Ideal teachers are those who use themselves as bridges over which they invite their students to cross, then having facilitated their crossing, joyfully collapse, encouraging them to create bridges of their own.”")#linebreak()#text(" — Nikos Kazantzakis ( Greek writer and philosopher )")

#text("— Dibakar Datta")#linebreak()#text(" PhD candidate in Mechanics")#linebreak()#text(" Brown University")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4eaa57a5f80319613bb7b475963f188c5f4ddea836d634e9e88a62c009515c3a-13b10de1d98a7329933ba3e6d91f8da2e6d7d06bb6fc48447e4e4aa33f429931.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/10/18/garth-gaudry/#comment-183722")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2012")])]

#text("Sad to read this. He was the school head when I was at UNSW. A good gentle man. Arguably, his most important contribution to mathematics is to guide Terry to become what he is now. Many gifted kids produced nothing when they grew up. Without Garth’s proper protection and advisory for Terry back at the Flinders time, it is hard to imagine that Terry can so perfectly materialize his talents in such a short time. He will be missed by the math community and people who know him for a long time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/242cf5b8a5dcef048a83e33ccf0b5785b2059a5321d1d3674e7036a8ccc047bf-b8badbaa80eef3562e3db6a3b0f845eacec33bf051478dc866dbdb054b9ca14c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of RJB")]], [#link("https://terrytao.wordpress.com/2012/10/18/garth-gaudry/#comment-191759")[#strong[#text("RJB")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2012")])]

#text("It would be good to hear more of Terry Tao’s studies with the late Bill Cornish, whose health unfortunately began to deteriorate about that time, forcing early retirement, although he only died in 2009.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01d4d2c46b50bc4bc232f5349f3077e3c35ca56f273bc5641b07a7474dde3b11-7930c6e39b14310d3da6a2874719b8e3ed5088044e6a8e47a3c1f4265a3a70e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan")]], [#link("https://terrytao.wordpress.com/2012/10/18/garth-gaudry/#comment-239995")[#strong[#text("Alan")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2013")])]

#text("In fact, Bill Cornish died in 2008, aged sixty-seven.")
]
]
