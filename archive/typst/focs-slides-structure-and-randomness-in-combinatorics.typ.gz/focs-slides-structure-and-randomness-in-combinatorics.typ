// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/10/23/focs-slides-structure-and-randomness-in-combinatorics/
// Converted to Typst by tao2typ: "2026-10-14T06:52:53.227725+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "FOCS slides: structure and randomness in combinatorics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("FOCS slides: structure and randomness in combinatorics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 October 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/10/23/focs-slides-structure-and-randomness-in-combinatorics/")[#text("https://terrytao.wordpress.com/2007/10/23/focs-slides-structure-and-randomness-in-combinatorics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just come back from the ")#link("http://focs2007.org/")[#text("48th Annual IEEE Symposium on the Foundations of Computer science")]#text(", better known as FOCS; this year it was held at Providence, near Brown University. (This conference is also being officially reported on by the blog posts of ")#link("http://weblog.fortnow.com/")[#text("Nicole Immorlica")]#text(", ")#link("http://in-theory.blogspot.com/")[#text("Luca Trevisan")]#text(", and ")#link("http://www.scottaaronson.com/blog/")[#text("Scott Aaronson")]#text(".) I was there to give a tutorial on some of the tools used these days in additive combinatorics and graph theory to distinguish structure and randomness. In a ")#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/")[#text("previous blog post")]#text(", I had already mentioned that my lecture notes for this were ")#link("http://arxiv.org/abs/0707.4269")[#text("available on the arXiv")]#text("; now the slides for ")#link("http://www.math.ucla.edu/~tao/preprints/Slides/struct_slides.pdf")[#text("my tutorial ")]#text(" are available too (it covers much the same ground as the lecture notes, and also incorporates some material from my ICM slides, but in a slightly different format).")

#text("In the slides, I am tentatively announcing some very recent (and not yet fully written up) work of Ben Green and myself establishing the Gowers inverse conjecture in finite fields in the special case when the function f is a bounded degree polynomial (this is a case which already has some theoretical computer science applications). I hope to expand upon this in a future post. But I will describe here a neat trick I learned at the conference (from the ")#link("http://projectamericano.com/adib/pubs/lowdeggen.pdf")[#text("FOCS submission of Bogdanov and Viola")]#text(") which uses ")#link("http://en.wikipedia.org/wiki/Majority_voting")[#text("majority voting")]#text(" to enhance a large number of small independent correlations into a much stronger single correlation. This application of majority voting is widespread in computer science (and, of course, in real-world democracies), but I had not previously been aware of its utility to the type of structure/randomness problems I am interested in (in particular, it seems to significantly simplify some of the arguments in the proof of my result with Ben mentioned above); thanks to this conference, I now know to add majority voting to my “toolbox”.")

#metadata(none) <tao-30462f33458640c5685c>#text("Here is a simple instance of the majority voting trick in action. Suppose one is given a ")#link("http://en.wikipedia.org/wiki/Boolean_function")[#text("boolean function")]#text(" ")#mi("f: {\\Bbb F}_2^n \\to {\\Bbb F}_2")#text(", where one should think of the number ")#mi("n")#text(" of inputs as being very large. Here of course ")#mi("{\\Bbb F}_2 = \\{0,1\\}")#text(" is the field of two elements. Given any such function, and any shift ")#mi("h \\in {\\Bbb F}_2^n")#text(", one can form its ")#emph[#text("derivative")]#text(" ")#mi("D_h f: {\\Bbb F}_2^n \\to {\\Bbb F}_2")#text(" by the formula ")#mi("D_h f(x) := f(x+h) - f(x)")#text(". (Actually, since ")#mi("{\\Bbb F}_2")#text(" has ")#link("http://en.wikipedia.org/wiki/Characteristic_%28algebra%29")[#text("characteristic")]#text(" 2, one could write f(x+h) + f(x) here instead of f(x+h) – f(x), but I will retain the subtraction in order to emphasise the analogy with the classical concept of differentiation.) Now, it turns out that if a function exhibits “polynomial behaviour”, than the derivatives of a function are simpler than the function itself. For instance:")

#enum(start: 1, 
[#text("If f is a constant function, then ")#mi("D_h f")#text(" is zero for all h.")],
[#text("If f is a ")#link("http://en.wikipedia.org/wiki/Linear_functional")[#text("linear functional")]#text(", then ")#mi("D_h f")#text(" is constant for all h.")],
[#text("If f is a ")#link("http://en.wikipedia.org/wiki/Quadratic_form")[#text("quadratic form")]#text(", then ")#mi("D_h f")#text(" is an ")#link("http://en.wikipedia.org/wiki/Affine_transformation")[#text("(affine-)linear")]#text(" functional for all h.")],
[#text("More generally, if f is a polynomial in n variables over ")#mi("{\\Bbb F}_2")#text(" of degree d, then for every h, ")#mi("D_h f")#text(" is a polynomial of degree d-1. (This is of course totally consistent with one’s experience with differentiation of polynomials in the classical setting.)")]
)

#text("Because of this reduction-of-complexity phenomenon, it becomes desirable to represent a function f(x) “efficiently” in terms of its derivatives ")#mi("D_h f(x)")#text(" if at all possible. What do I mean by “efficient”? Well, one has the rather silly representation formula")

#align(center)[#tao-fit-display[#mitex("f(x) = f(0) - D_{-x} f(x)")]]

#text("which allows us to reconstruct the value of f(x) for any x given the value f(0) at 0, and the value of ")#mi("D_h f(x)")#text(" for some h. But this is a very “inefficient” representation, because it will require us to record the derivatives ")#mi("D_h f")#text(" for ")#emph[#text("all")]#text(" h. In applications, we want some representation of f that requires only knowing ")#mi("D_h f")#text(" for a few values of h.")

#text("In the case when f is a random function, with all the values ")#mi("f(x)")#text(" of f being independent and uniformly distributed between 0 and 1, this is basically not possible, for the intuitively obvious reason that none of the values of ")#mi("D_h f(x)")#text(" are particularly well correlated to each other, or to f(x). But if f is not random, one can hope to do better. As an example of this, let me mention the following result (a simple instance of a lemma of Bogdanov and Viola):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma")]#text(". Let ")#mi("f: {\\Bbb F}_2^n \\to {\\Bbb F}_2")#text(" be a boolean function, and let ")#mi("0 < \\varepsilon < 1")#text(". Then at least one of the following statements is true:")

#enum(start: 1, 
[#text("(Pseudorandomness) f is unbiased up to error ")#mi("O(\\varepsilon)")#text(", in the sense that f(x) takes the value 1 for ")#mi("1/2 + O(\\varepsilon)")#text(" of the possible inputs x (and similarly for the value 0, of course); or")],
[#text("(Structure) f can be well approximated by a few of its derivatives. More precisely, there exists ")#mi("h_1, \\ldots, h_k \\in {\\Bbb F}_2^n")#text(" for some ")#mi("k = O_\\varepsilon(1)")#text(" and some boolean function ")#mi("B: {\\Bbb F}^k_2 \\to {\\Bbb F}_2")#text(" such that ")#mi("f(x) = B( D_{h_1} f(x), \\ldots, D_{h_k} f(x) )")#text(" for at least ")#mi("1-O(\\varepsilon)")#text(" of the inputs x.")]
)
]

#text("This result seems to be rather difficult to prove unless one knows about the majority voting trick, in which case it is rather easy. It works like this. Suppose that f is not pseudorandom; let’s say for sake of argument that it takes the value 1 with probability at least ")#mi("1/2 + \\varepsilon")#text(", and the value 0 with probability at most ")#mi("1/2 - \\varepsilon")#text(". The key point is then that the functions f and f-1 have significantly different distributions (or ")#link("http://en.wikipedia.org/wiki/Histogram")[#text("histograms")]#text("); indeed, f-1 takes 1 with probability at most ")#mi("1/2-\\varepsilon")#text(", and 0 with probability at least ")#mi("1/2 + \\varepsilon")#text(". So there is a gap of at least ")#mi("2\\varepsilon")#text(" between the distributions of f and f-1, with the former favoring 1 and the latter favoring 0.")

#text("How can we leverage such a tiny gap? Well, we begin with the tautological identity")

#align(center)[#mi("D_h f(x)  = f(x+h)-f(x)")#text(".")]

#text("We apply this identity with x fixed, and h selected uniformly at random; thus x+h is also a uniformly distributed random variable. As a consequence, the random variable ")#mi("D_h f(x)")#text(" either has the distribution of f (if f(x)=0) or f-1 (if f(x)=1). If we can tell which of these two distributions ")#mi("D_h f(x)")#text(" enjoys, we have discovered what f(x) is.")

#text("So now, the procedure is obvious to anyone who knows about statistics: take an ")#link("http://en.wikipedia.org/wiki/Empirical_distribution")[#text("empirical distribution")]#text("! In other words, just pick some shifts ")#mi("h_1,\\ldots,h_k")#text(" at random for some large k (which we will take to be odd, in order to avoid ties), and measure the k values ")#mi("D_{h_1} f(x), \\ldots, D_{h_k} f(x) \\in {\\Bbb F}_2")#text(". Then perform a majority vote, i.e. ask whether more of the ")#mi("D_{h_i} f(x)")#text(" are equal to 1, or more are equal to 0. If the majority vote is 1, then it is more likely that ")#mi("D_h f(x)")#text(" had the distribution of f and f(x)=0; conversely, if the majority vote is 0, then it is more likely that ")#mi("D_h f(x)")#text(" had the distribution of f-1 and f(x)=1. Thus we see that the majority vote of these k derivatives gives a prediction for the value of f. At this point it is not difficult to use basic laws of probability (in particular, the ")#link("http://en.wikipedia.org/wiki/Law_of_large_numbers")[#text("law of large numbers")]#text(") to show that this prediction becomes increasingly accurate as k increases, and the lemma can then be proven rather quickly (and one can take k to be something civilised like ")#mi("\\varepsilon^{-2} \\log \\frac{1}{\\varepsilon}")#text(").")

#text("The point here was that each of the functions ")#mi("D_{h_i} f")#text(" had a small correlation (about ")#mi("O(\\varepsilon)")#text(") with f. But, because these functions were all independent of each other (due to the independent random choices of the ")#mi("h_i")#text("), one could use majority vote to amplify these small correlations into a much stronger correlation.")

#text("[On a somewhat ironic note, during my tutorial I specifically commented that majority vote seemed to not be a useful tool for dealing with small correlations, since “if only 1% of the population is voting the right way, majority voting don’t always yield the right outcome”. But what I realise now is that if 1% of the population votes the right way, and the other 99% is behaving in a sufficiently random manner, then the influence of the 1% “voting bloc” can be decisive, allowing majority vote to be a useful tool for amplifying a correlation.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e960784f5d18a6c25356d754d1bf2bfebe6b725541ab2a14a85e0265a3b71285-ed08eb569e0bdb5f957f40b915539bf6eaac714d3fe095acf0c63f8dc42b1cdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2007/10/23/focs-slides-structure-and-randomness-in-combinatorics/#comment-12715")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2007")])]

#text("Thank you for the clear explanation of the lemma. Yes, amusing irony.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54dd1583026134dc4e104ba0a453a466b557c4c7910304ce680dedcd5027035c-b656500dbdcb3cec3e0b384418f76cc54ffd06373cccba7cb58b7cd18cb7c075.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of van vu")]], [#link("https://terrytao.wordpress.com/2007/10/23/focs-slides-structure-and-randomness-in-combinatorics/#comment-12745")[#strong[#text("van vu")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2007")])]

#text("Dear Terry,")

#text("It sounds like a general principle used frequently in probabilistic combinatorics: if two random variables has separated means, then few")#linebreak()#text(" samples will tell them appart. Best, Van.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/23/focs-slides-structure-and-randomness-in-combinatorics/#comment-12765")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2007")])]

#text("An historical question regarding your slides. Can you trace back the idea of decomposing an object into (pseudo) random part and structural part. Is this an older idea. Is the specific version for functions has some specific features that goes beyond, or is it just another formulation?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/23/focs-slides-structure-and-randomness-in-combinatorics/#comment-12766")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2007")])]

#text("That’s a good question. Certainly there are many classical results (e.g. orthonormal projections onto a subspace of a Hilbert space; spectral decomposition into continuous and singular components of a self-adjoint operator; Koopman-von Neumann decomposition of a shift operator into almost periodic and weakly mixing components) which have this flavour, as well as many decompositions used in signal processing (e.g. thresholding).")#linebreak()#text(" The method of real interpolation, used for instance to prove the Marcinkeiwicz interpolation theorem, also is in the same spirit; more generally, there are several “stopping time” algorithms in harmonic analysis which have a little bit of resemblance to the energy-increment algorithms discussed here, though the Szemeredi regularity lemma argument is a much closer fit (and was a direct inspiration for the formulations of these theorems as presented in my notes).")

#text("There are also some structural theorems for sequences associated to martingales (I don’t recall the exact details right now, though). In number theory, we have the decomposition of the circle in to major and minor arcs, which is particularly important in the Hardy-Littlewood circle method. In linear PDE, such as in the study of the Schrodinger equation, there is the decomposition of states into bound states and scattering states, which is also falls somewhat in this framework.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/10/23/focs-slides-structure-and-randomness-in-combinatorics/#comment-12811")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2007")])]

#text("A pretty early form of “structure + randomness”, though in a somewhat distinct flavor, is Riemann’s explicit formula for the prime counting function (proved by von Mangoldt): the structure term is just the logarithmic integral ")#tao-fit-display[#mitex("li(x)=\\int_2^x{dt/\\log t}")]#text(", showing the $ 1/log(t)$ density predicted by Gauss, and the (hopefully) random part is a sum over zeros of the Riemann zeta function. (Though it doesn’t really converge if written this way; other variants such as that for the sum of $\\log p$ for $p<x$ are cleaner).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/10/23/focs-slides-structure-and-randomness-in-combinatorics/#comment-12834")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2007")])]

#text("I find it exciting to learn that there is an interchange of ideas among the spectrum of mathematics [at least potential Fields, Nevalinna and Gauss awardees].")#linebreak()#text(" There is hope yet that mathematics may be unified.")

#text("I am not surprised that your description of Probability Space, although not identical, is very similar to that found in Appendix B: Some Notions of Probability Theory, Tamer Basar and Geert Jan Olsder, Dynamic Noncooperative Game Theory (Classics in Applied Mathematics) to supplement their discussion on stochastic game theory.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Prashant V")]], [#link("https://terrytao.wordpress.com/2007/10/23/focs-slides-structure-and-randomness-in-combinatorics/#comment-12873")[#strong[#text("Prashant V")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2007")])]

#text("Dear Terry,")

#text("You say that one of the main goals of the majority voting trick is to enhance a large number of small independent correlations into a much stronger single correlation. So is this essentially the same thing as “filtering out noise?”")

#text("Do you think that this trick would make it easier in dealing with chaotic systems (by reducing noise)? How does noise reduction using the majority voting trick compare to noise reduction via. averaging/weighted averaging?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/23/focs-slides-structure-and-randomness-in-combinatorics/#comment-12878")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2007")])]

#text("Dear Prashant,")

#text("One can indeed view majority vote as a noise-filtering algorithm, albeit for discrete (boolean) signals rather than continuous (analog) signals. It is also nonlinear, as opposed to averaging which is usually a linear operation. But the purposes of the two methods are still broadly similar.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kay")]], [#link("https://terrytao.wordpress.com/2007/10/23/focs-slides-structure-and-randomness-in-combinatorics/#comment-12879")[#strong[#text("Kay")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2007")])]

#text("“But what I realise now is that if 1% of the population votes the right way, and the other 99% is behaving in a sufficiently random manner, then the influence of the 1% “voting bloc” can be decisive, allowing majority vote to be a useful tool for amplifying a correlation.”")

#text("Dear Terry,")

#text("As I understand it, this is actually a very common argument used by economists and political scientists for why democracy isn’t quite the same as ‘mob rule’ … in the sense that, people who don’t know about the issue would vote randomly and people who know about the issue will vote in a more patterned way. There are systematic biases in how people vote that is introduced by campaign advertising and culture so this does not all stand up in practical situations but it is a mitigating factor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An update on the inverse conjecture for the Gowers norm over finite fields « What’s new")]], [#link("https://terrytao.wordpress.com/2007/10/23/focs-slides-structure-and-randomness-in-combinatorics/#comment-13884")[#strong[#text("An update on the inverse conjecture for the Gowers norm over finite fields « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2007")])]

#text("[…] finite fields, Gowers norm, inverse conjecture, polynomials, Ramsey theory, symmetric polynomials Recently, I had tentatively announced a forthcoming result with Ben Green establishing the “Gowers inverse conjecture” (or […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The distribution of polynomials over finite fields, with applications to the Gowers norms « What’s new")]], [#link("https://terrytao.wordpress.com/2007/10/23/focs-slides-structure-and-randomness-in-combinatorics/#comment-16521")[#strong[#text("The distribution of polynomials over finite fields, with applications to the Gowers norms « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2007")])]

#text("[…] to the arXiv, and submitted to Contributions to Discrete Mathematics. This paper, which we first announced at the recent FOCS meeting, and then gave an update on two weeks ago on this blog, is now in final […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 8: The mean ergodic theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2007/10/23/focs-slides-structure-and-randomness-in-combinatorics/#comment-25172")[#strong[#text("254A, Lecture 8: The mean ergodic theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2008")])]

#text("[…] respectively. For more on decompositions into structured and random components, see my FOCS lecture […]")
]
