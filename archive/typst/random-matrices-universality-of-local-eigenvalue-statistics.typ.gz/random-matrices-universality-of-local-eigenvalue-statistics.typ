// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/
// Converted to Typst by tao2typ: "2026-10-14T16:35:46.535955+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Random matrices: universality of local eigenvalue statistics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Random matrices: universality of local eigenvalue statistics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 June 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/")[#text("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Van Vu and I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" our paper “")#link("http://arxiv.org/abs/0906.0510")[#text("Random matrices: universality of local eigenvalue statistics")]#text("“, submitted to Acta Math.. This paper concerns the eigenvalues ")#mi("\\lambda_1(M_n) \\leq \\ldots \\leq \\lambda_n(M_n)")#text(" of a ")#emph[#text("Wigner matrix")]#text(" ")#mi("M_n = (\\zeta_{ij})_{1 \\leq i,j \\leq n}")#text(", which we define to be a random Hermitian ")#mi("n \\times n")#text(" matrix whose upper-triangular entries ")#mi("\\zeta_{ij}, 1 \\leq i \\leq j \\leq n")#text(" are independent (and whose strictly upper-triangular entries ")#mi("\\zeta_{ij}, 1 \\leq i < j \\leq n")#text(" are also identically distributed). [The lower-triangular entries are of course determined from the upper-triangular ones by the Hermitian property.] We normalise the matrices so that all the entries have mean zero and variance 1. Basic examples of Wigner Hermitian matrices include")

#enum(start: 1, 
[#text("The ")#link("http://en.wikipedia.org/wiki/Gaussian_matrix_ensemble")[#text("Gaussian Unitary Ensemble")]#text(" (GUE), in which the upper-triangular entries ")#mi("\\zeta_{ij}, i<j")#text(" are complex gaussian, and the diagonal entries ")#mi("\\zeta_{ii}")#text(" are real gaussians;")],
[#text("The ")#link("http://en.wikipedia.org/wiki/Gaussian_matrix_ensemble")[#text("Gaussian Orthogonal Ensemble")]#text(" (GOE), in which all entries are real gaussian;")],
[#text("The ")#emph[#text("Bernoulli Ensemble")]#text(", in which all entries take values ")#mi("\\pm 1")#text(" (with equal probability of each).")]
)

#text("We will make a further distinction into ")#emph[#text("Wigner real symmetric matrices")]#text(" (which are Wigner matrices with real coefficients, such as GOE and the Bernoulli ensemble) and Wigner Hermitian matrices (which are Wigner matrices whose upper-triangular coefficients have real and imaginary parts iid, such as GUE).")

#text("The GUE and GOE ensembles have a rich algebraic structure (for instance, the GUE distribution is invariant under conjugation by unitary matrices, while the GOE distribution is similarly invariant under conjugation by orthogonal matrices, hence the terminology), and as a consequence their eigenvalue distribution can be computed explicitly. For instance, the joint distribution of the eigenvalues ")#mi("\\lambda_1(M_n),\\ldots,\\lambda_n(M_n)")#text(" for GUE is given by the explicit formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(0)")])
#tao-math("C_n \\prod_{1 \\leq i<j \\leq n} \\left|\\lambda_i-\\lambda_j\\right|^2 \\exp( - \\frac{1}{2n} (\\lambda_1^2+\\ldots+\\lambda_n^2))\\ d\\lambda_1 \\ldots d\\lambda_n", block: true)]]

#text("for some explicitly computable constant ")#mi("C_n")#text(" on the orthant ")#mi("\\{ \\lambda_1 \\leq \\ldots \\leq \\lambda_n\\}")#text(" (a result first established by Ginibre). (A similar formula exists for GOE, but for simplicity we will just discuss GUE here.) Using this explicit formula one can compute a wide variety of asymptotic eigenvalue statistics. For instance, the (bulk) ")#emph[#text("empirical spectral distribution (ESD) measure")]#text(" ")#mi("\\frac{1}{n} \\sum_{i=1}^n \\delta_{\\lambda_i(M_n)/\\sqrt{n}}")#text(" for GUE (and indeed for all Wigner matrices, see below) is known to converge (in the vague sense) to the ")#link("http://en.wikipedia.org/wiki/Wigner_semicircle_distribution")[#text("Wigner semicircular law")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{1}{2\\pi} (4-x^2)_+^{1/2}\\ dx =: \\rho_{sc}(x)\\ dx")]]

#text("as ")#mi("n \\to \\infty")#text(". Actually, more precise statements are known for GUE; for instance, for ")#mi("1 \\leq i \\leq n")#text(", the ")#mi("i^{th}")#text(" eigenvalue ")#mi("\\lambda_i(M_n)")#text(" is known to equal")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\lambda_i(M_n) = \\sqrt{n} t(\\frac{i}{n}) + O( \\frac{\\log n}{n} )")]]

#text("with probability ")#mi("1-o(1)")#text(", where ")#mi("t(a) \\in [-2,2]")#text(" is the inverse cumulative distribution function of the semicircular law, thus")

#align(center)[#mi("\\displaystyle a = \\int_{-2}^{t(a)} \\rho_{sc}(x)\\ dx")#text(".")]

#text("Furthermore, the distribution of the normalised eigenvalue spacing ")#mi("\\sqrt{n} \\rho_{sc}(\\frac{i}{n}) (\\lambda_{i+1}(M_n) - \\lambda_i(M_n))")#text(" is known; in the bulk region ")#mi("\\varepsilon n \\leq i \\leq 1-\\varepsilon n")#text(" for fixed ")#mi("\\varepsilon > 0")#text(", it converges as ")#mi("n \\to \\infty")#text(" to the ")#emph[#text("Gaudin distribution")]#text(", which can be described explicitly in terms of determinants of the ")#link("http://en.wikipedia.org/wiki/Hermite_polynomials")[#text("Dyson sine kernel")]#text(" ")#mi("K(x,y) := \\frac{\\sin \\pi(x-y)}{\\pi(x-y)}")#text(". Many further local statistics of the eigenvalues of GUE are in fact governed by this sine kernel, a result usually proven using the asymptotics of orthogonal polynomials (and specifically, the ")#link("http://en.wikipedia.org/wiki/Hermite_polynomials")[#text("Hermite polynomials")]#text("). (At the edge of the spectrum, say ")#mi("i = n-O(1)")#text(", the asymptotic distribution is a bit different, being governed instead by the ")#emph[#text("Tracy-Widom law")]#text(".)")

#text("It has been widely believed that these GUE facts enjoy a universality property, in the sense that they should also hold for wide classes of other matrix models. In particular, Wigner matrices should enjoy the same bulk distribution (1), the same asymptotic law (2) for individual eigenvalues, and the same sine kernel statistics as GUE. (The statistics for Wigner symmetric matrices are slightly different, and should obey GOE statistics rather than GUE ones.)")

#text("There has been a fair body of evidence to support this belief. The bulk distribution (1) is in fact valid for all Wigner matrices (a result of Pastur, building on the original work of Wigner of course). The Tracy-Widom statistics on the edge were established for all Wigner Hermitian matrices (assuming that the coefficients had a distribution which was symmetric and decayed exponentially) by Soshnikov (with some further refinements by Soshnikov and Peche). Soshnikov’s arguments were based on an advanced version of the moment method.")

#text("The sine kernel statistics were established by Johansson for Wigner Hermitian matrices which were ")#emph[#text("gaussian divisible, ")]#text("which means that they could be expressed as a non-trivial linear combination of another Wigner Hermitian matrix and an independent GUE. (Basically, this means that distribution of the coefficients is a convolution of some other distribution with a gaussian. There were some additional technical decay conditions in Johansson’s work which were removed in subsequent work of Ben Arous and Peche.) Johansson’s work was based on an explicit formula for the joint distribution for gauss divisible matrices that generalises (0) (but is significantly more complicated).")

#text("Just last week, ")#link("http://arxiv.org/abs/0905.4176")[#text("Erdos, Ramirez, Schlein, and Yau")]#text(" established sine kernel statistics for Wigner Hermitian matrices with exponential decay and a high degree of smoothness (roughly speaking, they require control of up to six derivatives of the Radon-Nikodym derivative of the distribution). Their method is based on an analysis of the dynamics of the eigenvalues under a smooth transition from a general Wigner Hermitian matrix to GUE, essentially a matrix version of the ")#link("http://en.wikipedia.org/wiki/Ornstein-Uhlenbeck_process")[#text("Ornstein-Uhlenbeck process")]#text(", whose eigenvalue dynamics are governed by ")#emph[#text("Dyson Brownian motion")]#text(".")

#text("In my paper with Van, we establish similar results to that of Erdos et al. under slightly different hypotheses, and by a somewhat different method. Informally, our main result is as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1. ")]#text("(Informal version) Suppose ")#mi("M_n")#text(" is a Wigner Hermitian matrix whose coefficients have an exponentially decaying distribution, and whose real and imaginary parts are supported on at least three points (basically, this excludes Bernoulli-type distributions only) and have vanishing third moment (which is for instance the case for symmetric distributions). Then one has the local statistics (2) (but with an error term of ")#mi("O(n^{-1+\\delta})")#text(" for any ")#mi("\\delta>0")#text(" rather than ")#mi("O(\\log n/n)")#text(") and the sine kernel statistics for individual eigenvalue spacings ")#mi("\\sqrt{n} \\rho_{sc}(\\frac{i}{n}) (\\lambda_{i+1}(M_n) - \\lambda_i(M_n))")#text(" (as well as higher order correlations) in the bulk.")

#text("If one removes the vanishing third moment hypothesis, one still has the sine kernel statistics provided one averages over all i.")
]

#text("There are analogous results for Wigner real symmetric matrices (see paper for details). There are also some related results, such as a universal distribution for the least singular value of matrices of the form in Theorem 1, and a crude asymptotic for the determinant (in particular, ")#tao-math("\\log \\left|\\det M_n\\right| = (1+o(1)) \\log \\sqrt{n!}", block: false)#text(" with probability ")#mi("1-o(1)")#text(").")

#text("The arguments are based primarily on the ")#emph[#text("Lindeberg replacement strategy,")]#text(" which Van and I also used to obtain ")#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/")[#text("universality for the circular law for iid matrices")]#text(", and for the ")#link("https://terrytao.wordpress.com/2009/03/06/random-matrices-the-distribution-of-the-smallest-singular-values")[#text("least singular value for iid matrices")]#text(", but also rely on other tools, such as some recent arguments of Erdos, Schlein, and Yau, as well as a very useful concentration inequality of Talagrand which lets us tackle both discrete and continuous matrix ensembles in a unified manner. (I plan to talk about Talagrand’s inequality in my next blog post.)")

#heading(level: 1)[#metadata(none) <tao-8c07d819387edee99a13>#text("— The replacement strategy —")]

#text("Suppose one has a Wigner Hermitian random matrix ")#mi("M_n")#text(". To compute the eigenvalue statistics of ")#mi("M_n")#text(", e.g. the expectation ")#mi("{\\Bbb E} G( \\lambda_i(M_n) )")#text(" of some suitably normalised function ")#mi("G()")#text(" of the ")#mi("i^{th}")#text(" eigenvalue, the Lindeberg strategy is not to perform this computation directly, but to first compare the relevant statistic ")#mi("{\\Bbb E} G( \\lambda_i(M_n) )")#text(" of ")#mi("M_n")#text(" with the corresponding statistic ")#mi("{\\Bbb E} G( \\lambda_i(M^{\\prime}_n) )")#text(" of a much nicer random matrix ensemble ")#mi("M^{\\prime}_n")#text(", such as GUE. Since the statistics of the latter have already been computed, one will be done as soon as one establishes an invariance principle ")#mi("{\\Bbb E} G( \\lambda_i(M_n) ) \\approx {\\Bbb E} G( \\lambda_i(M^{\\prime}_n) )")#text(" for the statistic being studied.")

#text("After trying a number of implementations of this strategy, Van and I eventually settled on that of replacing the entries of ")#mi("M_n")#text(" with the corresponding gaussian entries of ")#mi("M^{\\prime}_n")#text(" one by one (or more precisely, two by two, since we need to keep the matrix Hermitian) and seeing how the eigenvalues evolve. A key tool here is the ")#emph[#text("Hadamard variation formula")]

#align(center)[#tao-fit-display[#mitex("\\dot \\lambda_i = u_i^* \\dot M_n u_i")]]

#text("that describes the rate of change of an eigenvalue ")#mi("\\lambda_i")#text(" in terms of the rate of change ")#mi("\\dot M_n")#text(" of the matrix, and the unit eigenvector ")#mi("u_i")#text(" of the matrix associated to that eigenvalue. (See ")#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/")[#text("this earlier blog post")]#text(" for further discussion of this and related formulae). If one assumes that the eigenvectors ")#mi("u_i")#text(" are delocalised in the sense that their ")#mi("n")#text(" coefficients have magnitude ")#mi("O( n^{-1/2+o(1)} )")#text(" (which is essentially the best possible, given that these magnitudes must square-sum to 1 by Pythagoras’ theorem), this formula suggests that the replacement of one or two entries in a random matrix should only move the eigenvalues by about ")#mi("1/n")#text(". (This type of delocalisation result was recently established ")#link("http://arxiv.org/abs/0811.2591")[#text("by Erdos, Schlein, and Yau")]#text(", for a slightly more restrictive class of matrices, but we were able to extend their method to our class.) Since the mean eigenvalue spacing is about ")#mi("1/\\sqrt{n}")#text(", this is encouraging for the purposes of establishing the invariance principle. However, we have to perform about ")#mi("O(n^2)")#text(" separate replacement operations. A random walk of ")#mi("n^2")#text(" steps of size ")#mi("1/n")#text(" would be expected to move a much larger distance than the mean eigenvalue spacing ")#mi("1/\\sqrt{n}")#text(", so it looks like this strategy is not going to work.")

#text("Fortunately, one can salvage things by performing a Taylor expansion. Suppose for instance that one is swapping one entry ")#mi("\\zeta_{pq}")#text(" (together with its adjoint ")#mi("\\zeta_{qp} = \\overline{\\zeta_{pq}}")#text(") of a random matrix M into another entry")#mi("\\zeta^{\\prime}_{pq}")#text(" to create another matrix ")#mi("M^{\\prime}")#text(". Thus one can write")

#align(center)[#tao-fit-display[#mitex("M=M(\\zeta_{pq}), M^{\\prime} = M(\\zeta^{\\prime}_{pq})")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("M(t) = M(0) + t e_{pq} + \\overline{t} e_{qp},")]]

#mi("M(0)")#text(" is the matrix M with the pq and qp entries zeroed out, and ")#mi("e_{pq}, e_{qp}")#text(" are the basis matrices corresponding to the positions pq, qp. If we write ")#mi("F(t) := G(\\lambda_i(M(t)))")#text(", we are trying to compare ")#mi("{\\Bbb E} F( \\zeta_{pq} )")#text(" with ")#mi("{\\Bbb E} F(\\zeta^{\\prime}_{pq} )")#text(". To do this, we can perform a Taylor expansion with remainder:")

#tao-aligned(keep: true)[


#tao-math("F(\\zeta_{pq})  & = F(0) + F^{\\prime}(0) \\zeta_{pq} + \\frac{1}{r!} F^{\\prime\\prime}(0) \\zeta_{pq}^2 + \\ldots", block: true)



#tao-math(" & + \\frac{1}{r!} F^{(r)}(0) \\zeta_{pq}^r + O( \\left\\| F^{(r+1)}\\right\\|_{L^\\infty} \\left|\\zeta_{pq}\\right|^{r+1} ),", block: true, numbering: n => [#text("(3)")])
]

#text("where r is a parameter that one can choose (it is ultimately going to be something like 4 in practice). Technically, the Taylor expansion is a bit messier than this because ")#mi("\\zeta_{pq}")#text(" is complex rather than real (and ")#mi("F")#text(" is not holomorphic), but let us ignore this technicality for now.")

#text("If the moments of ")#mi("\\zeta_{pq}")#text(" and ")#mi("\\zeta^{\\prime}_{pq}")#text(" agree up to ")#mi("r^{th}")#text(" order, then when one takes expectations, all the terms in (3) except for the error term remain unchanged when swapping ")#mi("\\zeta_{pq}")#text(" into ")#mi("\\zeta^{\\prime}_{pq}")#text(". A more advanced version of the Hadamard variation formula can be used to establish (at least heuristically) that ")#mi("F^{(r+1)}")#text(" is “typically” of size ")#mi("n^{-(r+2)/2+o(1)}")#text(", which suggests that one should be able to swap all ")#mi("n^2")#text(" entries and still get fine-scale distributional results as long as r is at least 4.")

#text("It turns out that (with a certain amount of technical effort, and some tweaks to the above strategy) one can make this plan work, with the upshot that one can replace all the entries in a Wigner matrix without significantly affecting the local statistics, as long as one preserves all moments up to fourth order of the entries. This would give Theorem 1 in the case where the entries agreed with the GUE entries up to fourth order, but as stated they only agree up to third order. To drop the moment matching condition by one order, we use the result of Johansson on gaussian divisible matrices, combined with an elementary observation that any random variable that is supported on three or more points can be matched with a gaussian-divisible random variable up to fourth order. (The Bernoulli random variables, which are supported on only two points, are unfortunately an extremal for the moment matching problem and cannot be matched to fourth order with any other distribution.)")

#metadata(none) <tao-f057d9ad07a460347579>

#link("http://en.wikipedia.org/wiki/Ornstein-Uhlenbeck_process")[#text("http://en.wikipedia.org/wiki/Ornstein-Uhlenbeck_process")]

#heading(level: 1)[#text("Comments (35)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ec2f78ceb57d9bd64b34cc4b78429f1c5eac54c83816135c602986374a75021-e038760ba298b6b7b263cacae9f591e1977f4216ef31f5659d7913e113c583d0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Leopardi")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-39178")[#strong[#text("Paul Leopardi")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2009")])]

#text("I recently gave a presentation on random Gram matrices obtained from polynomial interpolation on the unit sphere.")#linebreak()#text(" See ")#link("http://wwwmaths.anu.edu.au/~leopardi/Stoc-Spec-2009-Random-Gram.pdf")[#linebreak()#text(" “Polynomial interpolation on the sphere, reproducing kernels and random matrices”")]#text(".")#linebreak()#text(" My investigation so far has been entirely empirical. It looks like your paper could give me some ideas to use in a more theoretical investigation. In my case, the diagonal entries of the random real symmetric Gram matrix $G_t$ are ")#mi("g_t(1)")#text(" and the strict upper triangular entries are ")#mi("g_t(X \\cdot Y)")#text(" where X and Y are independently, uniformly distributed on the unit sphere.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/587b18a1d0c6d61d98461c45bd9822b04bfdcb6c6823c62fd175e405dc172244-0d0530453ee2655c233e87f3fe79271d32dea11e100abd2f8f0d892ab5064d4b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of edmaths")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-39211")[#strong[#text("edmaths")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2009")])]

#text("Dear Professor Tao,")

#text("Here are some typos I have noticed on your paper about universality of local eigenvalue statistics. The number pages are those of 0906.0510v2.pdf.")

#text("– Page 1, footnote: the word “is” is repeated twice,")#linebreak()#text(" – Page 8, in 1.5, line 5: “Winger” should be Wigner,")#linebreak()#text(" – Page 12, Remark 23: I think the last sentence could be improved (problem with “remove”).")

#text("I am sorry I cannot help on the mathematical content :-)")#linebreak()#text(" Feel free to delete this comment at any time.")

#text("Best regards,")#linebreak()#text(" edmaths")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of masterchef")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-39266")[#strong[#text("masterchef")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2009")])]

#text("Dear Professor Tao,")

#text("I hope one day you will come back to Australia. You’re an Australian Treasure.")

#text("From Masterchef (in Australia)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yet Another Graduate Student")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-39270")[#strong[#text("Yet Another Graduate Student")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2009")])]

#text("Dear Prof. Tao,")#linebreak()#text(" Are there any other central questions left open in random matrix theory after you and Prof. Vu tackled this universality conjecture? I really thought it would take another five to ten years before some special cases of it would yield to human prowess.")

#text("Sincerely,")#linebreak()#text(" John")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-39276")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2009")])]

#text("John,")

#text("What counts as a “central” question is quite subjective, but here are a couple candidates, one rather specific and one quite general:")

#text("1. What are necessary and sufficient conditions on the entries of a Wigner matrix for Tracy-Widom asymptotics of the largest eigenvalue? (The conjecture is that fourth moments exist, which is known to be necessary and sufficient for the largest eigenvalue to satisfy a strong law of large numbers.)")

#text("2. Can the various universality results for Wigner matrices be extended to random matrices with weakly dependent entries? For the so-called unitary and orthogonal ensembles, which share the invariance properties Terry discussed for the GUE/GOE, the answer is known in many cases to yes, but I know of only a few results which lack those invariance properties and simply replace independence with a weaker hypothesis. In the context of Wishart-type matrices, there is also some recent work on matrices with independent columns.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bulk universality for Wigner hermitian matrices with subexponential decay « What’s new")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-39757")[#strong[#text("Bulk universality for Wigner hermitian matrices with subexponential decay « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2009")])]

#text("[…] the universality conjecture for the eigenvalue spacings in the bulk for Wigner random matrices (see my earlier blog post for more discussion). On the one hand, the paper of Erdős-Ramírez-Schlein-Yau established this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Random matrices: Universality of local eigenvalue statistics up to the edge « What’s new")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-41045")[#strong[#text("Random matrices: Universality of local eigenvalue statistics up to the edge « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2009")])]

#text("[…] eigenvalue statistics up to the edge“, submitted to Comm. Math. Phys.. This is a sequel to our previous paper, in which we studied universality of local eigenvalue statistics (such as normalised eigenvalue […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Random covariance matrices: Universality of local statistics of eigenvalues « What’s new")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-42770")[#strong[#text("Random covariance matrices: Universality of local statistics of eigenvalues « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2009")])]

#text("[…] of eigenvalues“, to be submitted shortly. This paper draws heavily on the technology of our previous paper, in which we established a Four Moment Theorem for the local spacing statistics of eigenvalues of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5cd917d0fc70f5103c4dbdd91fc7712df6e813c3927e919cc89cd1b72183e94-23d46c9baca55c0ef9b2da81b7a9129d7df3d09114001b57450a498d82912202.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wynand")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-42776")[#strong[#text("Wynand")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2009")])]

#text("Dear Prof")

#text("In your paper, on page 6, you say that “the distribution of the eigenvalues ")#mi("\\lambda(A_n)")#text(" is given by the restriction ")#mi("n! \\rho_n^{(n)}(x_1, \\ldots, x_n) dx_1 \\ldots dx_n")#text(" to the region ")#mi("{x_1 \\leq \\ldots \\leq x_n}")#text(".”")

#text("I am a bit confused by what “restriction” means here (is it just restriction of a function?) and by how to interpret the infinitesimals ")#mi("dx_1 \\ldots dx_n")#text(". Could you point me at something that will help me understand?")

#text("Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-42790")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2009")])]

#text("I am using ")#mi("f(x)\\ dx")#text(" to denote the absolutely continuous measure ")#mi("\\mu")#text(" formed by multiplying Lebesgue measure ")#mi("dx")#text(" with the density function ")#mi("f(x)")#text(", thus ")#mi("\\mu(E) := \\int_E f(x)\\ dx")#text(". The restriction ")#mi("\\mu\\downharpoonright_F")#text(" of a measure ")#mi("\\mu")#text(" to any subset ")#mi("F")#text(" is defined by ")#mi("\\mu\\downharpoonright_F(E) := \\mu(E \\cap F)")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3a: Eigenvalues and sums of Hermitian matrices « What’s new")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-43223")[#strong[#text("254A, Notes 3a: Eigenvalues and sums of Hermitian matrices « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2010")])]

#text("[…] in the eigenbasis). See this earlier blog post for more discussion. Remark 4 In the proof of the four moment theorem of Van Vu and myself, which we will discuss in a subsequent lecture, we will also need the variation formulae for the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aee8b264b23eab4a8ccdcdc0203b3d4da285321c2393053ae490290d2402c621-6051c260508c9a5c6bebd88a873dd2be62b8fc479a50f7353168143c373d680e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Florent Benaych-Georges")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-43638")[#strong[#text("Florent Benaych-Georges")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2010")])]

#text("Dear Professor Tao,")

#text("I am interested in equation (2) of your post, which is not far away from equation (2) of the article. However, I did not find any good reference for it. For example, I did not find it in the references you give in your article (two articles by Bai and Yin of 1988).")

#text("In fact, I am only interested in the GUE and GOE cases. Would you please tell me where, in the articles of Bai and Yin (or somewhere else), this is proved ?")

#text("Thank you !")

#text("With best regards,")#linebreak()#text(" Florent")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-43642")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2010")])]

#text("The strongest results so far in this direction are in")

#text("J. Gustavsson, Gaussian fluctuations of eigenvalues in the GUE, Ann. Inst. H. Poincare Probab. Statist. 41 (2005), no. 2, 151–178.")

#text("In our paper we use the four moment theorem (actually, we use the three moment version in this case) to extend this result to more general ensembles.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aee8b264b23eab4a8ccdcdc0203b3d4da285321c2393053ae490290d2402c621-6051c260508c9a5c6bebd88a873dd2be62b8fc479a50f7353168143c373d680e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Florent Benaych-Georges")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-43643")[#strong[#text("Florent Benaych-Georges")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2010")])]

#text("OK, thanks a lot !")

#text("Florent")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Random matrices: Localization of the eigenvalues and the necessity of four moments « What’s new")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-44952")[#strong[#text("Random matrices: Localization of the eigenvalues and the necessity of four moments « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2010")])]

#text("[…] of Erdos, Ramirez, Schlein, Vu, Yau, and myself. One tool for this is the four moment theorem of Van and myself, which roughly speaking shows that the behaviour of the eigenvalues at the scale (and even at the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Wigner-Dyson-Mehta bulk universality conjecture for Wigner matrices « What’s new")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-49997")[#strong[#text("The Wigner-Dyson-Mehta bulk universality conjecture for Wigner matrices « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2011")])]

#text("[…] results of Johansson, href{ErdH{o}s-Ramirez-Schlein-Yau}, ErdHs-Peche-Ramirez-Schlein-Yau}, and Vu and myself, extended these results to increasingly wider ranges of Wigner matrices, but in the context of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mads")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-50288")[#strong[#text("Mads")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2011")])]

#text("Professor Tao,")

#text("A typo: In your joint paper with Van Vu, six lines after (44) on page 33, “whence the claim” should be “hence the claim”. ")#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mads")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-50311")[#strong[#text("Mads")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2011")])]

#text("Dear Professor Tau,")

#text("Since English isn’t my main language, I’m not sure whether the following suggestions are correct or not. If not, I apologise for wasting your time.")

#text("*) P. 7, 3 lines before theorem 8: “(i.e. independent” –> “(i.e., independent”")

#text("*) P. 10, line 5: “(i.e. $A_n$ has” –> “(i.e., $A_n$ has”")

#text("*) P. 40, line 9: “(i.e. to spans” –> “(i.e., to spans”")

#text("*) P. 44, 8 lines into corollary 58: “(i.e. to spans” –> “(i.e., to spans”")

#text("*) P. 65, line 5: “(i.e. all” –> “(i.e., all”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Random matrices: Universality of eigenvectors « What’s new")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-50782")[#strong[#text("Random matrices: Universality of eigenvectors « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2011")])]

#text("[…] submitted to Random Matrices: Theory and Applications. This paper concerns an extension of our four moment theorem for eigenvalues. Roughly speaking, that four moment theorem asserts (under mild decay conditions on […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A central limit theorem for the determinant of a Wigner matrix « What’s new")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-110949")[#strong[#text("A central limit theorem for the determinant of a Wigner matrix « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2011")])]

#text("[…] Erdos, Yau, and Yin (based on a previous four moment theorem for individual eigenvalues introduced by Van Vu and myself). The four moment theorem is proven by the now-standard Lindeberg exchange method, combined with […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The asymptotic distribution of a single eigenvalue gap of a Wigner matrix « What’s new")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-132069")[#strong[#text("The asymptotic distribution of a single eigenvalue gap of a Wigner matrix « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2012")])]

#text("[…] ensembles by the Four Moment Theorem, at least if one assumes a moment matching condition; see this previous paper with Van Vu for details. The moment condition can in fact be removed, as was done in this subsequent paper with […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b16b57b2061018808964e85b00b84d898a2186a561a818f9482831648fbf5a1-e17d544f392b6bfd0cc692da244bea947ad4973eb1a964f22aae0e67f2cfe30b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Review of wigner nj-Symbols | quantumtetrahedron")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-347736")[#strong[#text("Review of wigner nj-Symbols | quantumtetrahedron")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2014")])]

#text("[…] Random matrices: universality of local eigenvalue statistics (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fabc6092a391d9eccbe8534b670d3452bc51cc8417de77dfd4c50f2b91852144-3a5c1558b3882c8d711f921945cedd4e21244ac8b94f0c98ecbc793c6fa95022.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of deep")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-375755")[#strong[#text("deep")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2014")])]

#text("Dear Professor Tao,")

#text("I ma little confused by the terminology between Wigner real symmetric matrices and Gaussian Orthogonal Ensemble (GOE). Genrerally for GOE they assume iid diagonal entries N(0; 1) and the off-diagonal entries are iid (subject to being symmetric) as N(0; 1/2).")

#text("But I am interested in a real symmetric matrix with all entries are i.i.d N(0,1) and I wanted to study the spacings to detect whether there is any interesting eigenvalue (via eigen-Gap) present in the specturm. Is you paper ")#link("http://arxiv.org/abs/0906.0510")[#text("http://arxiv.org/abs/0906.0510")]#text(" answer this question or do you know any result in this direction ?")

#text("My goal is to find a threshold c, such that whenever the maximum eigen-gap exceeds that value I will declare thare is potential `signal’ present.")

#text("Best")#linebreak()#text(" Deep")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-375802")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2014")])]

#text("That’s a good question. The universality results in my paper with Van (and in subsequent work) tell us that if one replaces the N(0,1) distributions in your real symmetric matrix with any other distribution with mean zero and variance 1 (and exponential tails), the gap distribution is essentially unchanged (in our paper, one needs also four matching moments; a subsequent paper of Erdos, Ramirez, Schlein, Vu, Yau, and myself removes this condition, at the cost of averaging over all gaps, not just over a specific gap). However, this does not directly tell us what the gap distribution is, only that it is universal. The “local semicircle law” of Erdos, Schlein, and Yau (Theorem 60 in the current paper) tells us that these gaps cannot be much bigger than the mean spacing. and Theorem 19 in the current paper gives a nontrivial lower bound on the gap on average. It is likely that the gap distribution for your model is the same as that in the GOE case, but I don’t think this has been established in the literature yet.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fabc6092a391d9eccbe8534b670d3452bc51cc8417de77dfd4c50f2b91852144-3a5c1558b3882c8d711f921945cedd4e21244ac8b94f0c98ecbc793c6fa95022.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of deep")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-375829")[#strong[#text("deep")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2014")])]

#text("Thank you so much Terence. So if I understood you correctly, there is no literature currently on the distribution of the spacings for a real symmetric random matrix with all entries N(0,1).")

#text("So at this point the other possibility is via maximum eigenvalue route. Do you know any result, which discusses the spectral (specially the maximum eigenvalue Tracy–Widom type result) properties of such matrix ? I would be grateful for that.")

#text("My goal is to detect the `signal’ either using the spacing results or the maximum eigenvalue type thresholding.")

#text("Thank you again for all your valuable insights and comments.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-376104")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2014")])]

#text("The known results for edge universality are a little better than those for bulk universality, in that fewer matching moment conditions are required. In particular, (a small modification of) the paper of Knowles and Yin at ")#link("http://arxiv.org/abs/1102.0057")[#text("http://arxiv.org/abs/1102.0057")]#text(" should imply that the distribution of the largest eigenvalues is essentially unchanged if one changes the variance of the diagonal entries of GOE from 1/2 to 1, so your model should have the same Tracy-Widom statistics that GOE does.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fabc6092a391d9eccbe8534b670d3452bc51cc8417de77dfd4c50f2b91852144-3a5c1558b3882c8d711f921945cedd4e21244ac8b94f0c98ecbc793c6fa95022.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of deeptemple")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-379742")[#strong[#text("deeptemple")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2014")])]

#text("Just to clarify one last thing about the eigenvalue spacing. The Wigner Surmise type distribution only holds for GOE, which has diagonal elements N(0,2) not N(0,1).")#linebreak()#text(" If I understood you correctly there is no known result of this type valid for Real symmetric matrix with all entries N(0,1)..m I correct Terence ?")

#text("Thanks a lot !")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-379775")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2014")])]

#text("I am not aware of such a result in the literature, but it ought to be true, and looks almost within the reach of known methods, particularly if one is willing to work with the average gap spacing rather than with a specific gap.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01901599885f643a9707e9fedd90c0126fa3ed4c884d78f12b539d71c776ab8a-a7916bc83fa7ae082c391fb2e1d63cf97ac556259415a1a4a04b1e45cf143fd8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K. Ahn")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-479105")[#strong[#text("K. Ahn")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2017")])]

#text("Dear professor Tao.")#linebreak()#text(" I read your paper, and I came up with several technical questions in the proof. I will be grateful for any helps.")

#text("1. At the very last part of section 3.5 (High-level proof of Thm 19), it says “if E_0^c holds, then by (i) we have … ” However, I don’t see why E_0^c implies (i) as the definition of E_0 is “at least one of the exceptional events (i),(iii)-(vi), or E_n hold”. (More precisely, I interpreted that E_0^c would be “none of the events (i),(iii)-(vi) hold”)")

#text("2. I don’t see how you relate the event (i) with the definition of g_{i,l,n} in (37). At first glance, the denominator shown in (37) does not look consistent with the right hand side of the inequality presented in the event (i).")

#text("I would appreciate your helps.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-479137")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2017")])]

#text("1. Sorry, this was a typo: it should be “failure of (i)” instead of (i); the next two inequalities should be reversed (with ")#mi("n_0^{-2\\kappa}")#text(" instead of ")#mi("n_0^{-\\kappa/2}")#text("); and the value of ")#mi("Z_{n_0 - \\lfloor \\log^{C_1} n_0 \\rfloor}")#text(" should be ")#mi("n_0^{-9\\kappa}")#text(" rather than ")#mi("n_0^{-\\kappa}")#text(".")

#text("2. To lower bound ")#mi("g_{i_0, \\lfloor\\log^{C_1} n_0 \\rfloor + 1, n_0 - \\lfloor \\log^{C_1} n_0 \\rfloor}")#text(", we upper bound the denominator in (37) by ")#mi("(\\log^{C_1} n_0)^{\\log^{0.9} n_0}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01901599885f643a9707e9fedd90c0126fa3ed4c884d78f12b539d71c776ab8a-a7916bc83fa7ae082c391fb2e1d63cf97ac556259415a1a4a04b1e45cf143fd8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K. Ahn")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-479152")[#strong[#text("K. Ahn")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2017")])]

#text("I have another question. Any helps would be appriciated.")

#text("In section 5.3, I don’t see why you abruptly introduce ")#mi("i_+,i_-")#text(" right after (94). To my understanding, I think it suffices to show for ")#mi("s_n(z)")#text(". (Lemma 64 ensures that we only need to show that ")#mi("s_n(z)")#text(" is close to ")#mi("s(z)")#text(" uniformly for all ")#mi("z")#text(" )")

#text("Again, thanks for any helps!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01901599885f643a9707e9fedd90c0126fa3ed4c884d78f12b539d71c776ab8a-a7916bc83fa7ae082c391fb2e1d63cf97ac556259415a1a4a04b1e45cf143fd8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K. Ahn")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-479154")[#strong[#text("K. Ahn")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2017")])]

#text("I just understood your intention. I apologize for a silly question. I have another question:")

#text("at the very last part of the proof of proposition 65 (section 5.3), we have an upper bound ")#mi("O(1/\\log^4 n)")#text(". However, I don’t see how this comes even though there is ")#mi("\\frac{i_+-i_-}{an\\log^2 n}")#text(" and we only know ")#mi("i_+-i_-\\ll an")#text(".")

#text("Thanks for your helps!")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-479253")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2017")])]

#text("This is a typo: the upper bound on ")#mi("i_+ - i_-")#text(" should be ")#mi("an / \\log^2 n")#text(" (note that the interval ")#mi("I")#text(" to which Proposition 66 is applied has length about ")#mi("a / \\log^2 n")#text(").")

#text("Incidentally, you may find this post of mine on how to deal with these sorts of typos when reading mathematical papers to be helpful: ")#link("https://plus.google.com/u/0/+TerenceTao27/posts/TGjjJPUdJjk")[#text("https://plus.google.com/u/0/+TerenceTao27/posts/TGjjJPUdJjk")]
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eigenvectors from eigenvalues | What's new")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-519569")[#strong[#text("Eigenvectors from eigenvalues | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2019")])]

#text("[…] In the random matrix theory literature, for instance in this paper of Erdos, Schlein, and Yau, or this later paper of Van Vu and myself, a related identity has been used, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eigenvectors from Eigenvalues: a survey of a basic identity in linear algebra | What's new")]], [#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/#comment-531062")[#strong[#text("Eigenvectors from Eigenvalues: a survey of a basic identity in linear algebra | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2019")])]

#text("[…] of this identity in the literature; a related identity had been used by Erdos-Schlein-Yau and by myself and Van Vu for applications to random matrix theory, but to our knowledge this specific identity appeared to […]")
]
