// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/04/11/value-patterns-of-multiplicative-functions-and-related-sequences/
// Converted to Typst by tao2typ: "2026-10-14T16:38:32.449362+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Value patterns of multiplicative functions and related sequences", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Value patterns of multiplicative functions and related sequences")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 April 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/04/11/value-patterns-of-multiplicative-functions-and-related-sequences/")[#text("https://terrytao.wordpress.com/2019/04/11/value-patterns-of-multiplicative-functions-and-related-sequences/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://www.maths.ox.ac.uk/people/joni.teravainen")[#text("Joni Teräväinen")]#text(" and I have just uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/1904.05096")[#text("Value patterns of multiplicative functions and related sequences")]#text("“, submitted to ")#link("https://www.cambridge.org/core/journals/forum-of-mathematics-sigma")[#text("Forum of Mathematics, Sigma")]#text(". This paper explores how to use recent technology on correlations of multiplicative (or nearly multiplicative functions), such as the “entropy decrement method”, in conjunction with techniques from additive combinatorics, to establish new results on the sign patterns of functions such as the Liouville function ")#mi("{\\lambda}")#text(". For instance, with regards to length 5 sign patterns")

#align(center)[#tao-fit-display[#mitex("(\\lambda(n+1),\\dots,\\lambda(n+5)) \\in \\{-1,+1\\}^5")]]

#text("of the Liouville function, we can now show that at least ")#mi("{24}")#text(" of the ")#mi("{32}")#text(" possible sign patterns in ")#mi("{\\{-1,+1\\}^5}")#text(" occur with positive upper density. (Conjecturally, all of them do so, and this is known for all shorter sign patterns, but unfortunately ")#mi("{24}")#text(" seems to be the limitation of our methods.)")

#text("The Liouville function can be written as ")#mi("{\\lambda(n) = e^{2\\pi i \\Omega(n)/2}}")#text(", where ")#mi("{\\Omega(n)}")#text(" is the number of prime factors of ")#mi("{n}")#text(" (counting multiplicity). One can also consider the variant ")#mi("{\\lambda_3(n) = e^{2\\pi i \\Omega(n)/3}}")#text(", which is a completely multiplicative function taking values in the cube roots of unity ")#mi("{\\{1, \\omega, \\omega^2\\}}")#text(". Here we are able to show that all ")#mi("{27}")#text(" sign patterns in ")#mi("{\\{1,\\omega,\\omega^2\\}}")#text(" occur with positive lower density as sign patterns ")#mi("{(\\lambda_3(n+1), \\lambda_3(n+2), \\lambda_3(n+3))}")#text(" of this function. The analogous result for ")#mi("{\\lambda}")#text(" was already known (see ")#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/")[#text("this paper of Matomäki, Radziwiłł, and myself")]#text("), and in that case it is even known that all sign patterns occur with equal logarithmic density ")#mi("{1/8}")#text(" (from ")#link("https://terrytao.wordpress.com/2017/10/07/odd-order-cases-of-of-the-logarithmically-averaged-chowla-conjecture/")[#text("this paper of myself and Teräväinen")]#text("), but these techniques barely fail to handle the ")#mi("{\\lambda_3}")#text(" case by itself (largely because the “parity” arguments used in the case of the Liouville function no longer control three-point correlations in the ")#mi("{\\lambda_3}")#text(" case) and an additional additive combinatorial tool is needed. After applying existing technology (such as entropy decrement methods), the problem roughly speaking reduces to locating patterns ")#mi("{a \\in A_1, a+r \\in A_2, a+2r \\in A_3}")#text(" for a certain partition ")#mi("{G = A_1 \\cup A_2 \\cup A_3}")#text(" of a compact abelian group ")#mi("{G}")#text(" (think for instance of the unit circle ")#mi("{G={\\bf R}/{\\bf Z}}")#text(", although the general case is a bit more complicated, in particular if ")#mi("{G}")#text(" is disconnected then there is a certain “coprimality” constraint on ")#mi("{r}")#text(", also we can allow the ")#mi("{A_1,A_2,A_3}")#text(" to be replaced by any ")#mi("{A_{c_1}, A_{c_2}, A_{c_3}}")#text(" with ")#mi("{c_1+c_2+c_3}")#text(" divisible by ")#mi("{3}")#text("), with each of the ")#mi("{A_i}")#text(" having measure ")#mi("{1/3}")#text(". An inequality of Kneser just barely fails to guarantee the existence of such patterns, but by using an inverse theorem for Kneser’s inequality in ")#link("https://terrytao.wordpress.com/2017/11/15/an-inverse-theorem-for-kempermans-inequality/")[#text("this previous paper of mine")]#text(" we are able to identify precisely the obstruction for this method to work, and rule it out by an ")#emph[#text("ad hoc")]#text(" method.")

#text("The same techniques turn out to also make progress on some conjectures of Erdös-Pomerance and Hildebrand regarding patterns of the largest prime factor ")#mi("{P^+(n)}")#text(" of a natural number ")#mi("{n}")#text(". For instance, we improve results ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=480303")[#text("of Erdös-Pomerance")]#text(" and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1877768")[#text("of Balog")]#text(" demonstrating that the inequalities")

#align(center)[#tao-fit-display[#mitex("P^+(n+1) < P^+(n+2) < P^+(n+3)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("P^+(n+1) > P^+(n+2) > P^+(n+3)")]]

#text("each hold for infinitely many ")#mi("{n}")#text(", by demonstrating the stronger claims that the inequalities")

#align(center)[#tao-fit-display[#mitex("P^+(n+1) < P^+(n+2) < P^+(n+3) > P^+(n+4)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("P^+(n+1) > P^+(n+2) > P^+(n+3) < P^+(n+4)")]]

#text("each hold for a set of ")#mi("{n}")#text(" of positive lower density. As a variant, we also show that we can find a positive density set of ")#mi("{n}")#text(" for which")

#align(center)[#tao-fit-display[#mitex("P^+(n+1), P^+(n+2), P^+(n+3) > n^\\gamma")]]

#text("for any fixed ")#mi("{\\gamma < e^{-1/3} = 0.7165\\dots}")#text(" (this improves on a ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1014201")[#text("previous result of Hildebrand")]#text(" with ")#mi("{e^{-1/3}}")#text(" replaced by ")#mi("{e^{-1/2} = 0.6065\\dots}")#text(". A number of other results of this type are also obtained in this paper.")

#text("In order to obtain these sorts of results, one needs to extend the entropy decrement technology from the setting of multiplicative functions to that of what we call “weakly stable sets” – sets ")#mi("{A}")#text(" which have some multiplicative structure, in the sense that (roughly speaking) there is a set ")#mi("{B}")#text(" such that for all small primes ")#mi("{p}")#text(", the statements ")#mi("{n \\in A}")#text(" and ")#mi("{pn \\in B}")#text(" are roughly equivalent to each other. For instance, if ")#mi("{A}")#text(" is a level set ")#mi("{A = \\{ n: \\omega(n) = 0 \\text{ mod } 3 \\}}")#text(", one would take ")#mi("{B = \\{ n: \\omega(n) = 1 \\text{ mod } 3 \\}}")#text("; if instead ")#mi("{A}")#text(" is a set of the form ")#mi("{\\{ n: P^+(n) \\geq n^\\gamma\\}}")#text(", then one can take ")#mi("{B=A}")#text(". When one has such a situation, then very roughly speaking, the entropy decrement argument then allows one to estimate a one-parameter correlation such as")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_n 1_A(n+1) 1_A(n+2) 1_A(n+3)")]]

#text("with a two-parameter correlation such as")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_n {\\bf E}_p 1_B(n+p) 1_B(n+2p) 1_B(n+3p)")]]

#text("(where we will be deliberately vague as to how we are averaging over ")#mi("{n}")#text(" and ")#mi("{p}")#text("), and then the use of the “linear equations in primes” technology of Ben Green, Tamar Ziegler, and myself then allows one to replace this average in turn by something like")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_n {\\bf E}_r 1_B(n+r) 1_B(n+2r) 1_B(n+3r)")]]

#text("where ")#mi("{r}")#text(" is constrained to be not divisible by small primes but is otherwise quite arbitrary. This latter average can then be attacked by tools from additive combinatorics, such as translation to a continuous group model (using for instance the Furstenberg correspondence principle) followed by tools such as Kneser’s inequality (or inverse theorems to that inequality).")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2019/04/11/value-patterns-of-multiplicative-functions-and-related-sequences/#comment-514849")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2019")])]

#text("Two typos:")#linebreak()#text(" some conjectures of Erd\\H{o}s-Pomerance")#linebreak()#text(" we improve results of Erd\\Hs-Pomerance}")

#emph[#text("[Corrected, thanks -T.]")]

#text("Also, I notice you advertise the journals to which you submit preprints. At what point did you decide to start doing this? I can guess it is a kind of signal to others to communicate the importance you attach to this article, but it seems like the kind of thing that could backfire if someone more junior (cough) adopted it. Especially, for instance, if the paper is about the right level, but the journal decides against publishing it for ‘reasons of space’ (or any other euphemism).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/11/value-patterns-of-multiplicative-functions-and-related-sequences/#comment-514858")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2019")])]

#text("Is it possible to formulate (in simple terms of only sign patterns) the precise obstruction limiting your methods to 24 (out of 32) sign patterns ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/04/11/value-patterns-of-multiplicative-functions-and-related-sequences/#comment-514864")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2019")])]

#text("This is discussed on page 11. It boils down to what bounds one can obtain on the (logarithmic) average value of ")#mi("\\lambda(n+1) \\lambda(n+2) \\lambda(n+3) \\lambda(n+4)")#text(". This average value should be zero, but the best we can do is show that in magnitude it is less than or equal to 1/2. Any improvement to this bound would allow us to increase the lower bound of 24 (probably to 28, though I didn’t check this carefully).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2019/04/11/value-patterns-of-multiplicative-functions-and-related-sequences/#comment-514939")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2019")])]

#text("On p. 10 of the paper you state that someone proved that s(16)=4, where s(k) is the number of length k sign patterns that occur inﬁnitely often in the Liouville function. Should that instead read s(4)=16? (If I understand the definitions, it seems that s should never decrease).")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/421d7732991d97bf8caadbb8d42646c10330017a6d3724474aaf08fe03028b47-4bf4f8cc1181bff3eff113e9d49c3a16c11d0413e5c811d89dca3885657e4227.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Angularis")]], [#link("https://terrytao.wordpress.com/2019/04/11/value-patterns-of-multiplicative-functions-and-related-sequences/#comment-555926")[#strong[#text("Angularis")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2020")])]

#text("In the proof of Theorem 1.14 in “Case c not 0, exactly one of a, b not 0”, you say that the cases “a not 0” and “b not 0” are symmetric. However, you use Lemma 7.2 to obtain |a| <= 1/2. I do not see how to apply this Lemma to b. Or how else do you get the estimate |b| <= 1/2?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/04/11/value-patterns-of-multiplicative-functions-and-related-sequences/#comment-556088")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2020")])]

#text("Fair enough; we don’t get to claim that ")#tao-math("\\left|b\\right| \\leq 1/2", block: false)#text(" in the case not treated explicitly here. However, the ")#tao-math("\\left|b\\right|>1/2", block: false)#text(" case can still be treated by almost exactly the same argument (the analogs of the constraints ")#mi("\\epsilon_1 \\mathrm{sgn}(a) = \\epsilon_3 \\mathrm{sgn}(c)")#text(" and ")#mi("\\epsilon_1 \\epsilon_2 \\epsilon_4 \\epsilon_5 \\mathrm{sgn}(c) = -1")#text(" may flip signs, but there are still only four exceptional sign patters that obey all the constraints).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/11/value-patterns-of-multiplicative-functions-and-related-sequences/#comment-583697")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2020")])]

#text("Conjecturally ")#mi("\\Omega(n) \\pmod{3}")#text(" should be equidistributed among the three residue classes (or equivalently, ")#mi("\\lambda_3(n)")#text(" should be zero on average). For the modulus ")#mi("2")#text(" this is settled by the prime number theorem. What is known for larger moduli?")

#text("Your and Teräväinen’s corollary 1.13 in ")#link("https://arxiv.org/pdf/1708.02610.pdf")[#text("https://arxiv.org/pdf/1708.02610.pdf")]#text(" in particular tells that one has equidistribution in the sense of logarithmic density. As the corollary proves a more general result in a multivariate setting (and there the main difficulty seems to be controlling the correlations of several multiplicative functions), one could hope that there is a simpler proof for the average of one such function.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/04/11/value-patterns-of-multiplicative-functions-and-related-sequences/#comment-583839")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2020")])]

#text("For any fixed modulus ")#mi("k")#text(" one can get equidistribution for ordinary (non-logarithmic) averages of ")#mi("\\Omega(n) \\text{ mod } k")#text(" using Halasz’s theorem applied to the completely multiplicative functions ")#mi("e(a\\Omega(n)/k)")#text(" for various ")#mi("a")#text(" (see e.g., Theorem 7 in ")#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/")[#text("this previous blog post")]#text(" ).")
]
]
