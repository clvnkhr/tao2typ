// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/09/10/the-structure-of-correlations-of-multiplicative-functions-at-almost-all-scales-with-applications-to-the-chowla-and-elliott-conjectures/
// Converted to Typst by tao2typ: "2026-10-14T10:47:52.754825+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The structure of correlations of multiplicative functions at almost all scales, with applications to the Chowla and Elliott conjectures", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The structure of correlations of multiplicative functions at almost all scales, with applications to the Chowla and Elliott conjectures")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 September 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/09/10/the-structure-of-correlations-of-multiplicative-functions-at-almost-all-scales-with-applications-to-the-chowla-and-elliott-conjectures/")[#text("https://terrytao.wordpress.com/2018/09/10/the-structure-of-correlations-of-multiplicative-functions-at-almost-all-scales-with-applications-to-the-chowla-and-elliott-conjectures/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.utu.fi/en/units/sci/units/math/staff/Pages/jopete.aspx")[#text("Joni Teräväinen")]#text(" and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/1809.02518")[#text("The structure of correlations of multiplicative functions at almost all scales, with applications to the Chowla and Elliott conjectures")]#text("“. This is a sequel to our ")#link("https://terrytao.wordpress.com/2017/08/09/the-structure-of-logarithmically-averaged-correlations-of-multiplicative-functions-with-applications-to-the-chowla-and-elliott-conjectures/")[#text("previous paper")]#text(" that studied logarithmic correlations of the form")

#align(center)[#tao-fit-display[#mitex("f(a) := \\lim^*_{x \\rightarrow \\infty} \\frac{1}{\\log \\omega(x)} \\sum_{x/\\omega(x) \\leq n \\leq x} \\frac{g_1(n+ah_1) \\dots g_k(n+ah_k)}{n},")]]

#text("where ")#mi("{g_1,\\dots,g_k}")#text(" were bounded multiplicative functions, ")#mi("{h_1,\\dots,h_k \\rightarrow \\infty}")#text(" were fixed shifts, ")#mi("{1 \\leq \\omega(x) \\leq x}")#text(" was a quantity going off to infinity, and ")#mi("{\\lim^*}")#text(" was a generalised limit functional. Our main technical result asserted that these correlations were necessarily the uniform limit of periodic functions ")#mi("{f_i}")#text(". Furthermore, if ")#mi("{g_1 \\dots g_k}")#text(" (weakly) pretended to be a Dirichlet character ")#mi("{\\chi}")#text(", then the ")#mi("{f_i}")#text(" could be chosen to be ")#mi("{\\chi}")#text("–")#link("https://en.wikipedia.org/wiki/Isotopy_of_an_algebra")[#text("isotypic")]#text(" in the sense that ")#mi("{f_i(ab) = f_i(a) \\chi(b)}")#text(" whenever ")#mi("{a,b}")#text(" are integers with ")#mi("{b}")#text(" coprime to the periods of ")#mi("{\\chi}")#text(" and ")#mi("{f_i}")#text("; otherwise, if ")#mi("{g_1 \\dots g_k}")#text(" did not weakly pretend to be any Dirichlet character ")#mi("{\\chi}")#text(", then ")#mi("{f}")#text(" vanished completely. This was then used to verify several cases of the logarithmically averaged Elliott and Chowla conjectures.")

#text("The purpose of this paper was to investigate the extent to which the methods could be extended to non-logarithmically averaged settings. For our main technical result, we now considered the unweighted averages")

#align(center)[#tao-fit-display[#mitex("f_d(a) := \\lim^*_{x \\rightarrow \\infty} \\frac{1}{x/d} \\sum_{n \\leq x/d} g_1(n+ah_1) \\dots g_k(n+ah_k),")]]

#text("where ")#mi("{d>1}")#text(" is an additional parameter. Our main result was now as follows. If ")#mi("{g_1 \\dots g_k}")#text(" did not weakly pretend to be a twisted Dirichlet character ")#mi("{n \\mapsto \\chi(n) n^{it}}")#text(", then ")#mi("{f_d(a)}")#text(" converged to zero on (doubly logarithmic) average as ")#mi("{d \\rightarrow \\infty}")#text(". If instead ")#mi("{g_1 \\dots g_k}")#text(" did pretend to be such a twisted Dirichlet character, then ")#mi("{f_d(a) d^{it}}")#text(" converged on (doubly logarithmic) average to a limit ")#mi("{f(a)}")#text(" of ")#mi("{\\chi}")#text("-isotypic functions ")#mi("{f_i}")#text(". Thus, roughly speaking, one has the approximation")

#align(center)[#tao-fit-display[#mitex("\\lim^*_{x \\rightarrow \\infty} \\frac{1}{x/d} \\sum_{n \\leq x/d} g_1(n+ah_1) \\dots g_k(n+ah_k) \\approx f(a) d^{-it}")]]

#text("for most ")#mi("{d}")#text(".")

#text("Informally, this says that at almost all scales ")#mi("{x}")#text(" (where “almost all” means “outside of a set of logarithmic density zero”), the non-logarithmic averages behave much like their logarithmic counterparts except for a possible additional twisting by an Archimedean character ")#mi("{d \\mapsto d^{it}}")#text(" (which interacts with the Archimedean parameter ")#mi("{d}")#text(" in much the same way that the Dirichlet character ")#mi("{\\chi}")#text(" interacts with the non-Archimedean parameter ")#mi("{a}")#text("). One consequence of this is that most of the recent results on the logarithmically averaged Chowla and Elliott conjectures can now be extended to their non-logarithmically averaged counterparts, so long as one excludes a set of exceptional scales ")#mi("{x}")#text(" of logarithmic density zero. For instance, the Chowla conjecture")

#align(center)[#tao-fit-display[#mitex("\\lim_{x \\rightarrow\\infty} \\frac{1}{x} \\sum_{n \\leq x} \\lambda(n+h_1) \\dots \\lambda(n+h_k) = 0")]]

#text("is now established for ")#mi("{k}")#text(" either odd or equal to ")#mi("{2}")#text(", so long as one excludes an exceptional set of scales.")

#text("In the logarithmically averaged setup, the main idea was to combine two very different pieces of information on ")#mi("{f(a)}")#text(". The first, coming from recent results in ergodic theory, was to show that ")#mi("{f(a)}")#text(" was well approximated in some sense by a nilsequence. The second was to use the “entropy decrement argument” to obtain an approximate isotopy property of the form")

#align(center)[#tao-fit-display[#mitex("f(a) g_1 \\dots g_k(p)\\approx f(ap)")]]

#text("for “most” primes ")#mi("{p}")#text(" and integers ")#mi("{a}")#text(". Combining the two facts, one eventually finds that only the almost periodic components of the nilsequence are relevant.")

#text("In the current situation, each ")#mi("{a \\mapsto f_d(a)}")#text(" is approximated by a nilsequence, but the nilsequence can vary with ")#mi("{d}")#text(" (although there is some useful “Lipschitz continuity” of this nilsequence with respect to the ")#mi("{d}")#text(" parameter). Meanwhile, the entropy decrement argument gives an approximation basically of the form")

#align(center)[#tao-fit-display[#mitex("f_{dp}(a) g_1 \\dots g_k(p)\\approx f_d(ap)")]]

#text("for “most” ")#mi("{d,p,a}")#text(". The arguments then proceed largely as in the logarithmically averaged case. A key lemma to handle the dependence on the new parameter ")#mi("{d}")#text(" is the following cohomological statement: if one has a map ")#mi("{\\alpha: (0,+\\infty) \\rightarrow S^1}")#text(" that was a quasimorphism in the sense that ")#mi("{\\alpha(xy) = \\alpha(x) \\alpha(y) + O(\\varepsilon)}")#text(" for all ")#mi("{x,y \\in (0,+\\infty)}")#text(" and some small ")#mi("{\\varepsilon}")#text(", then there exists a real number ")#mi("{t}")#text(" such that ")#mi("{\\alpha(x) = x^{it} + O(\\varepsilon)}")#text(" for all small ")#mi("{\\varepsilon}")#text(". This is achieved by applying a standard “cocycle averaging argument” to the cocycle ")#mi("{(x,y) \\mapsto \\alpha(xy) \\alpha(x)^{-1} \\alpha(y)^{-1}}")#text(".")

#text("It would of course be desirable to not have the set of exceptional scales. We only know of one (implausible) scenario in which we can do this, namely when one has far fewer (in particular, subexponentially many) sign patterns for (say) the Liouville function than predicted by the Chowla conjecture. In this scenario (roughly analogous to the “Siegel zero” scenario in multiplicative number theory), the entropy of the Liouville sign patterns is so small that the entropy decrement argument becomes powerful enough to control all scales rather than almost all scales. On the other hand, this scenario seems to be self-defeating, in that it allows one to establish a large number of cases of the Chowla conjecture, and the full Chowla conjecture is inconsistent with having unusually few sign patterns. Still it hints that future work in this direction may need to split into “low entropy” and “high entropy” cases, in analogy to how many arguments in multiplicative number theory have to split into the “Siegel zero” and “no Siegel zero” cases.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/10/the-structure-of-correlations-of-multiplicative-functions-at-almost-all-scales-with-applications-to-the-chowla-and-elliott-conjectures/#comment-504733")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2018")])]

#text("Are these methods sufficient to improve the current upper bounds on the growth rate of summatory functions (i.e. partial sums) for certain multiplicative functions with “small corelation” in some quantitative sense ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/10/the-structure-of-correlations-of-multiplicative-functions-at-almost-all-scales-with-applications-to-the-chowla-and-elliott-conjectures/#comment-504741")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2018")])]

#text("The methods here give quite small gains over the trivial bound (the gain tends to be something like a small power of ")#mi("\\frac{1}{\\log X}")#text(" at best). So direct estimation of summatory functions (e.g., using Halasz’s theorem) will likely give significantly stronger bounds. The tools used in this sort of work (ergodic theory, entropy decrement, and the Matomaki-Radziwill theorem) are probably best thought of as tools to improve ")#mi("O()")#text(" type trivial bounds to ")#mi("o()")#text(" bounds, but without really strong decay rates.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xu")]], [#link("https://terrytao.wordpress.com/2018/09/10/the-structure-of-correlations-of-multiplicative-functions-at-almost-all-scales-with-applications-to-the-chowla-and-elliott-conjectures/#comment-682627")[#strong[#text("Xu")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2023")])]

#text("Why can’t we apply the entropy decrement method repeatedly:")#linebreak()#text(" First, we construct the sequence of primes ")#mi("q_j")#linebreak()#text(" and sets ")#mi("P(H_j)")#text(" of primes of magnitude ")#mi("H_j")#text(",")#linebreak()#text(" such that for all ")#mi("j\\le J")#text(" we have ")#mi("q_jH_j\\approx H_{+}")#text(",")#linebreak()#text(" ")#mi("H_{j+1}\\asymp H_j\\log H_j\\log\\log\\log H_j")#text(" and for all ")#mi("p\\in P(H_j)")#text(" we have")#linebreak()#text(" ")#mi("\\displaystyle g_1(q_j)g_2(q_j)E_{n\\le XH_{+}/(pq_j)}g_1(an+h_1)g_2(an+h_2)\\approx E_{n\\le XH_{+}/p}g_1(an+q_jh_1)g_2(an+q_jh_2).")

#text("Next, use the entropy decrement method to prove the existence of ")#mi("j_0\\le J")#text(" such that for all ")#mi("p\\in P(H_{j_0})")#text(" we have")#linebreak()#text(" ")#mi("\\displaystyle g_1(p)g_2(p)E_{n\\le XH_{+}/p}g_1(an+q_{j_0}h_1)g_2(an+q_{j_0}h_2) \\approx E_{n\\le XH_{+}}g_1(an+pq_{j_0}h_1)g_2(an+pq_{j_0}h_2).")#linebreak()#text(" Finally, apply the circle method to the latter average summed over ")#mi("p")#text(" to get the non-logarithmically averaged result?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/10/the-structure-of-correlations-of-multiplicative-functions-at-almost-all-scales-with-applications-to-the-chowla-and-elliott-conjectures/#comment-682643")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2023")])]

#text("This type of approach will allow one to control a lot of scales (those scales that are comparable to ")#mi("XH_+/(pq_j)")#text(" for enough “good” primes ")#mi("p, q_j")#text(") but it does not seem strong enough to control *all* scales, due to inability to rule out the possibility that there are some scales ")#mi("H")#text(" that contain very few good primes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xu")]], [#link("https://terrytao.wordpress.com/2018/09/10/the-structure-of-correlations-of-multiplicative-functions-at-almost-all-scales-with-applications-to-the-chowla-and-elliott-conjectures/#comment-682650")[#strong[#text("Xu")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2023")])]

#text("Quotation: \" … we construct the sequence of primes ")#mi("q_i")#linebreak()#text(" and sets ")#mi("P(H_i)")#text(" of primes of magnitude ")#mi("H_i")#text(",")#linebreak()#text(" such that for all ")#mi("i<J")#text(" we have ")#mi("q_iH_i\\approx H_{+}")#text(",")#linebreak()#text(" ")#mi("H_{i+1}\\asymp H_i\\log H_i\\log\\log\\log H_i")#text(" and")#linebreak()#text(" ")#mi("\\displaystyle E_{n\\le Xpq_i} \\sum_{p \\in P(H_i)} \\sum_{j: j,j+pq_ih \\in [1,H_{+}]} \\overline{g_1}(p)\\overline{g_2}(p) 1_{an+j = pq_ib \\ (apq_i)} g_1(an+j) g_2(an+j+pq_ih) \\approx \\frac{1}{q_i} E_{n\\le Xpq_i} \\sum_{p \\in P(H_i)} \\sum_{j: j,j+pq_ih \\in [1,H_{+}]} \\overline{g_1}(p)\\overline{g_2}(p) 1_{an+j = pb \\ (ap)} g_1(an+j) g_2(an+j+pq_ih).")

#text("A value of the latter expression is almost unchanged when one replaces ")#mi("an+j")#text(" with ")#mi("\\sigma(an+j)")#text(" and ")#mi("an+j+pq_ih")#text(" with ")#mi("\\sigma(an+j+pq_ih)")#text(", where ")#mi("\\sigma")#text(" is a permutation on ")#mi("n\\le Xpq_i")#text(", preserving the residue classes ")#mi("\\pmod{a\\prod_{p \\in P(H_i)}p}")#text(".")#linebreak()#text(" Thus there exists a ")#mi("\\sigma")#text(" for which one can approximate the latter expression by")#linebreak()#text(" ")#mi("\\displaystyle E_{n\\le Xpq_i} \\sum_{p \\in P(H_i)} \\sum_{j: j,j+pq_ih \\in [1,H_{+}]} \\overline{g_1}(p)\\overline{g_2}(p) 1_{an+j = 0 \\ (q_i)} 1_{an+j = pb \\ (ap)} g_1(\\sigma(an+j)) g_2(\\sigma(an+j+pq_ih))")

#text("and apply the entropy decrement method to the random tuple ")#mi("X_{H_{+},q_i}")#text(", being the consecutive nonzero elements of the sparse random tuple ")#mi("1_{an+j\\equiv 0\\pmod{q_i}}g_1(\\sigma(an+j))g_2(\\sigma(an+j+pq_ih))")#text(", ")#mi("j=1,\\dots,H_{+}")#text(", (extended to ")#mi("Xpq_{i}<n\\le XH_{+}")#text(" periodically).")#linebreak()#text(" We note that the following bound on the entropy holds:")#linebreak()#text(" ")#mi("\\displaystyle H( X_{H_{+},q_i} ) \\ll \\frac{H_{+}}{q_i}.")#text(" \"")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b8f3b96fa52580657f8104f0a8c84d808339b25a593b22ab7032d84494713f8-0a41c4aade441e65b1fd68d0f25e6731b0cd7ca1616347595204b603dd0b2ca6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ibrahim")]], [#link("https://terrytao.wordpress.com/2018/09/10/the-structure-of-correlations-of-multiplicative-functions-at-almost-all-scales-with-applications-to-the-chowla-and-elliott-conjectures/#comment-504748")[#strong[#text("Ibrahim")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2018")])]

#text("please sir, I m a graduate trying to proposed a theory on integers, would you please help me with my theory my email address is ")#link("mailto:ibmuhd557@gmail.com")[#text("ibmuhd557@gmail.com")]#text(".")#linebreak()#text(" Waiting for your reply thank you sir.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8db163ee2080530d530ad01e00b4f831e42348d8e0c11cecb9c0298815b6a4f0-c5d8d8d6496d0e650b45f0d3097ff78f97b9aeaca6fce1792c38496673e0c2d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of think")]], [#link("https://terrytao.wordpress.com/2018/09/10/the-structure-of-correlations-of-multiplicative-functions-at-almost-all-scales-with-applications-to-the-chowla-and-elliott-conjectures/#comment-506023")[#strong[#text("think")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2018")])]

#text("Google on “cocycle averaging argument” only points here and so unsure if it is standard. Is it used anywhere else? How is “siegel zero” presence analogous to the “low entropy” case? ‘Low entropy’ should roughly mean properties about primes are ‘predictable’ in some sense.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3de0971aa98986c59e57f76238c236536bbf74450298b40bccba65aaefdc5ad9-4ea34b276d8ccaca362647255e28225be4a33c216c4e97d34fd82798bf1184c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YNWA")]], [#link("https://terrytao.wordpress.com/2018/09/10/the-structure-of-correlations-of-multiplicative-functions-at-almost-all-scales-with-applications-to-the-chowla-and-elliott-conjectures/#comment-506713")[#strong[#text("YNWA")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2018")])]

#text("Dear all, you might be interested in this question concerning the Riemann zeta function on MathOverflow: ")#link("https://mathoverflow.net/q/314310/130815")[#text("https://mathoverflow.net/q/314310/130815")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quantitative correlations and some problems on prime factors of consecutive integers | What's new")]], [#link("https://terrytao.wordpress.com/2018/09/10/the-structure-of-correlations-of-multiplicative-functions-at-almost-all-scales-with-applications-to-the-chowla-and-elliott-conjectures/#comment-689192")[#strong[#text("Quantitative correlations and some problems on prime factors of consecutive integers | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2025")])]

#text("[…] are quite strong (of order ); previous correlation estimates of this type (such as those used in this earlier paper with Joni) turn out to be too weak for this argument to […]")
]
