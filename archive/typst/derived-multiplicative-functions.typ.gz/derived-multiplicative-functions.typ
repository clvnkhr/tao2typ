// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/
// Converted to Typst by tao2typ: "2026-10-14T10:20:26.492427+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Derived multiplicative functions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Derived multiplicative functions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 September 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/")[#text("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Analytic number theory is often concerned with the asymptotic behaviour of various ")#link("http://en.wikipedia.org/wiki/Arithmetic_function")[#text("arithmetic functions")]#text(": functions ")#mi("{f: {\\bf N} \\rightarrow {\\bf R}}")#text(" or ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" from the natural numbers ")#mi("{{\\bf N} = \\{1,2,\\dots\\}}")#text(" to the real numbers ")#mi("{{\\bf R}}")#text(" or complex numbers ")#mi("{{\\bf C}}")#text(". In this post, we will focus on the purely algebraic properties of these functions, and for reasons that will become clear later, it will be convenient to generalise the notion of an arithmetic function to functions ")#mi("{f: {\\bf N} \\rightarrow R}")#text(" taking values in some abstract commutative ring ")#mi("{R}")#text(". In this setting, we can add or multiply two arithmetic functions ")#mi("{f,g: {\\bf N} \\rightarrow R}")#text(" to obtain further arithmetic functions ")#mi("{f+g, fg: {\\bf N} \\rightarrow R}")#text(", and we can also form the ")#link("http://en.wikipedia.org/wiki/Dirichlet_convolution")[#text("Dirichlet convolution")]#text(" ")#mi("{f*g: {\\bf N} \\rightarrow R}")#text(" by the usual formula")

#align(center)[#tao-fit-display[#mitex("f*g(n) := \\sum_{d|n} f(d) g(\\frac{n}{d}).")]]

#text("Regardless of what commutative ring ")#mi("{R}")#text(" is in used here, we observe that Dirichlet convolution is commutative, associative, and bilinear over ")#mi("{R}")#text(".")

#text("An important class of arithmetic functions in analytic number theory are the ")#link("http://en.wikipedia.org/wiki/Multiplicative_function")[#text("multiplicative functions")]#text(", that is to say the arithmetic functions ")#mi("{f: {\\bf N} \\rightarrow {\\bf R}}")#text(" such that ")#mi("{f(1)=1}")#text(" and")

#align(center)[#tao-fit-display[#mitex("f(nm) = f(n) f(m)")]]

#text("for all coprime ")#mi("{n,m \\in {\\bf N}}")#text(". A subclass of these functions are the ")#link("http://en.wikipedia.org/wiki/Completely_multiplicative_function")[#text("completely multiplicative functions")]#text(", in which the restriction that ")#mi("{n,m}")#text(" be coprime is dropped. Basic examples of completely multiplicative functions (in the classical setting ")#mi("{R={\\bf C}}")#text(") include")

#list(
[#text("the ")#link("http://en.wikipedia.org/wiki/Kronecker_delta")[#text("Kronecker delta")]#text(" ")#mi("{\\delta}")#text(", defined by setting ")#mi("{\\delta(n)=1}")#text(" for ")#mi("{n=1}")#text(" and ")#mi("{\\delta(n)=0}")#text(" otherwise;")],
[#text("the constant function ")#mi("{1: n \\mapsto 1}")#text(" and the linear function ")#mi("{n \\mapsto n}")#text(" (which by abuse of notation we denote by ")#mi("{n}")#text(");")],
[#text("more generally monomials ")#mi("{n \\mapsto n^s}")#text(" for any fixed complex number ")#mi("{s}")#text(" (in particular, the “Archimedean characters” ")#mi("{n \\mapsto n^{it}}")#text(" for any fixed ")#mi("{t \\in {\\bf R}}")#text("), which by abuse of notation we denote by ")#mi("{n^s}")#text(";")],
[#link("http://en.wikipedia.org/wiki/Dirichlet_character")[#text("Dirichlet characters")]#text(" ")#mi("{\\chi}")#text(";")],
[#text("the ")#link("http://en.wikipedia.org/wiki/Liouville_function")[#text("Liouville function")]#text(" ")#mi("{\\lambda}")#text(";")],
[#text("the indicator function of the ")#mi("{z}")#text("–")#link("http://en.wikipedia.org/wiki/Smooth_number")[#text("smooth numbers")]#text(" (numbers whose prime factors are all at most ")#mi("{z}")#text("), for some given ")#mi("{z}")#text("; and")],
[#text("the indicator function of the ")#mi("{z}")#text("–")#link("http://en.wikipedia.org/wiki/Rough_number")[#text("rough numbers")]#text(" (numbers whose prime factors are all greater than ")#mi("{z}")#text("), for some given ")#mi("{z}")#text(".")]
)

#text("Examples of multiplicative functions that are not completely multiplicative include")

#list(
[#link("http://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("the Möbius function")]#text(" ")#mi("{\\mu}")#text(";")],
[#text("the ")#link("http://en.wikipedia.org/wiki/Divisor_function")[#text("divisor function")]#text(" ")#mi("{\\tau}")#text(" (also referred to as ")#mi("{d}")#text(");")],
[#text("more generally, the higher order divisor functions ")#mi("{\\tau_k(n) = \\sum_{d_1,\\dots,d_k: d_1 \\dots d_k = n} 1}")#text(" for ")#mi("{k \\geq 1}")#text(";")],
[#text("the ")#link("http://en.wikipedia.org/wiki/Euler%27s_totient_function")[#text("Euler totient function")]#text(" ")#mi("{\\phi}")#text(";")],
[#text("the number of roots ")#mi("{n \\mapsto \\# \\{ a \\in {\\bf Z}/n{\\bf Z}: P(a) = 0\\}}")#text(" of a given polynomial ")#mi("{P}")#text(" defined over ")#mi("{{\\bf Z}}")#text(";")],
[#text("more generally, the point counting function ")#mi("{n \\mapsto V[{\\bf Z}/n{\\bf Z}]}")#text(" of a given algebraic variety ")#mi("{V}")#text(" defined over ")#mi("{{\\bf Z}}")#text(" (closely tied to the ")#link("http://en.wikipedia.org/wiki/Hasse%E2%80%93Weil_zeta_function")[#text("Hasse-Weil zeta function of ")#mi("{V}")]#text(");")],
[#text("the function ")#mi("{r: n \\mapsto r(n)}")#text(" that counts the number of representations of ")#mi("{n}")#text(" as the sum of two squares;")],
[#text("more generally, the function that maps a natural number ")#mi("{n}")#text(" to the number of ideals in a given ")#link("http://en.wikipedia.org/wiki/Algebraic_number_field")[#text("number field")]#text(" ")#mi("{K}")#text(" of ")#link("http://en.wikipedia.org/wiki/Absolute_norm")[#text("absolute norm")]#text(" ")#mi("{n}")#text(" (closely tied to the ")#link("http://en.wikipedia.org/wiki/Dedekind_zeta_function")[#text("Dedekind zeta function")]#text(" of ")#mi("{K}")#text(").")]
)

#text("These multiplicative functions interact well with the multiplication and convolution operations: if ")#mi("{f,g: {\\bf N} \\rightarrow R}")#text(" are multiplicative, then so are ")#mi("{fg}")#text(" and ")#mi("{f * g}")#text(", and if ")#mi("{\\psi}")#text(" is completely multiplicative, then we also have ")#metadata(none) <tao-40f1502e481bef13ea4c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\psi (f*g) = (\\psi f) * (\\psi g).")]]



#text(" Finally, the product of completely multiplicative functions is again completely multiplicative. On the other hand, the sum of two multiplicative functions will never be multiplicative (just look at what happens at ")#mi("{n=1}")#text("), and the convolution of two completely multiplicative functions will usually just be multiplicative rather than completley multiplicative.")

#text("The specific multiplicative functions listed above are also related to each other by various important identities, for instance")

#align(center)[#tao-fit-display[#mitex("\\delta * f = f; \\quad \\mu * 1 = \\delta; \\quad 1 * 1 = \\tau; \\quad \\phi * 1 = n")]]

#text("where ")#mi("{f}")#text(" is an arbitrary arithmetic function.")

#text("On the other hand, analytic number theory also is very interested in certain arithmetic functions that are ")#emph[#text("not")]#text(" exactly multiplicative (and certainly not completely multiplicative). One particularly important such function is the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(" ")#mi("{\\Lambda}")#text(". This function is certainly not multiplicative, but is clearly closely related to such functions via such identities as ")#mi("{\\Lambda = \\mu * L}")#text(" and ")#mi("{L = \\Lambda * 1}")#text(", where ")#mi("{L: n\\mapsto \\log n}")#text(" is the natural logarithm function. The purpose of this post is to point out that functions such as the von Mangoldt function lie in a class closely related to multiplicative functions, which I will call the ")#emph[#text("derived multiplicative functions")]#text(". More precisely:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1")]#text(" A ")#emph[#text("derived multiplicative function")]#text(" ")#mi("{f: {\\bf N} \\rightarrow R}")#text(" is an arithmetic function that can be expressed as the formal derivative")

#align(center)[#tao-fit-display[#mitex("f(n) = \\frac{d}{d\\varepsilon} F_\\varepsilon(n) |_{\\varepsilon=0}")]]

#text("at the origin of a family ")#mi("{f_\\varepsilon: {\\bf N}\\rightarrow R}")#text(" of multiplicative functions ")#mi("{F_\\varepsilon: {\\bf N} \\rightarrow R}")#text(" parameterised by a formal parameter ")#mi("{\\varepsilon}")#text(". Equivalently, ")#mi("{f: {\\bf N} \\rightarrow R}")#text(" is a derived multiplicative function if it is the ")#mi("{\\varepsilon}")#text(" coefficient of a multiplicative function in the extension ")#mi("{R[\\varepsilon]/(\\varepsilon^2)}")#text(" of ")#mi("{R}")#text(" by a nilpotent infinitesimal ")#mi("{\\varepsilon}")#text("; in other words, there exists an arithmetic function ")#mi("{F: {\\bf N} \\rightarrow R}")#text(" such that the arithmetic function ")#mi("{F + \\varepsilon f: {\\bf N} \\rightarrow R[\\varepsilon]/(\\varepsilon^2)}")#text(" is multiplicative, or equivalently that ")#mi("{F}")#text(" is multiplicative and one has the Leibniz rule ")#metadata(none) <tao-032195745028aa5d9412>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("f(nm) = f(n) F(m) + F(n) f(m)")]]



#text(" for all coprime ")#mi("{n,m \\in {\\bf N}}")#text(".")

#text("More generally, for any ")#mi("{k\\geq 0}")#text(", a ")#emph[#mi("{k}")#text("-derived multiplicative function")]#text(" ")#mi("{f: {\\bf N} \\rightarrow R}")#text(" is an arithmetic function that can be expressed as the formal derivative")

#align(center)[#tao-fit-display[#mitex("f(n) = \\frac{d^k}{d\\varepsilon_1 \\dots d\\varepsilon_k} F_{\\varepsilon_1,\\dots,\\varepsilon_k}(n) |_{\\varepsilon_1,\\dots,\\varepsilon_k=0}")]]

#text("at the origin of a family ")#mi("{f_{\\varepsilon_1,\\dots,\\varepsilon_k}: {\\bf N} \\rightarrow R}")#text(" of multiplicative functions ")#mi("{F_{\\varepsilon_1,\\dots,\\varepsilon_k}: {\\bf N} \\rightarrow R}")#text(" parameterised by formal parameters ")#mi("{\\varepsilon_1,\\dots,\\varepsilon_k}")#text(". Equivalently, ")#mi("{f}")#text(" is the ")#mi("{\\varepsilon_1 \\dots \\varepsilon_k}")#text(" coefficient of a multiplicative function in the extension ")#mi("{R[\\varepsilon_1,\\dots,\\varepsilon_k]/(\\varepsilon_1^2,\\dots,\\varepsilon_k^2)}")#text(" of ")#mi("{R}")#text(" by ")#mi("{k}")#text(" nilpotent infinitesimals ")#mi("{\\varepsilon_1,\\dots,\\varepsilon_k}")#text(".")

#text("We define the notion of a ")#mi("{k}")#text("-derived completely multiplicative function similarly by replacing “multiplicative” with “completely multiplicative” in the above discussion.")
]

#text("There are Leibniz rules similar to ")#link(<tao-032195745028aa5d9412>)[#text("(2)")]#text(" but they are harder to state; for instance, a doubly derived multiplicative function ")#mi("{f: {\\bf N} \\rightarrow R}")#text(" comes with singly derived multiplicative functions ")#mi("{F_1, F_2: {\\bf N} \\rightarrow R}")#text(" and a multiplicative function ")#mi("{G: {\\bf N} \\rightarrow R}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("f(nm) = f(n) G(m) + F_1(n) F_2(m) + F_2(n) F_1(m) + G(n) f(m)")]]

#text("for all coprime ")#mi("{n,m \\in {\\bf N}}")#text(".")

#text("One can then check that the von Mangoldt function ")#mi("{\\Lambda}")#text(" is a derived multiplicative function, because ")#mi("{\\delta + \\varepsilon \\Lambda}")#text(" is multiplicative in the ring ")#mi("{{\\bf C}[\\varepsilon]/(\\varepsilon^2)}")#text(" with one infinitesimal ")#mi("{\\varepsilon}")#text(". Similarly, the logarithm function ")#mi("{L}")#text(" is derived completely multiplicative because ")#mi("{\\exp( \\varepsilon L ) := 1 + \\varepsilon L}")#text(" is completely multiplicative in ")#mi("{{\\bf C}[\\varepsilon]/(\\varepsilon^2)}")#text(". More generally, any ")#link("http://en.wikipedia.org/wiki/Additive_function")[#text("additive function")]#text(" ")#mi("{\\omega: {\\bf N} \\rightarrow R}")#text(" is derived multiplicative because it is the top order coefficient of ")#mi("{\\exp(\\varepsilon \\omega) := 1 + \\varepsilon \\omega}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" One can also phrase these concepts in terms of the formal Dirichlet series ")#mi("{F(s) = \\sum_n \\frac{f(n)}{n^s}}")#text(" associated to an arithmetic function ")#mi("{f}")#text(". A function ")#mi("{f}")#text(" is multiplicative if ")#mi("{F}")#text(" admits a (formal) Euler product; ")#mi("{f}")#text(" is derived multiplicative if ")#mi("{F}")#text(" is the (formal) first logarithmic derivative of an Euler product with respect to some parameter (not necessarily ")#mi("{s}")#text(", although this is certainly an option); and so forth.")
]

#text("Using the definition of a ")#mi("{k}")#text("-derived multiplicative function as the top order coefficient of a multiplicative function of a ring with ")#mi("{k}")#text(" infinitesimals, it is easy to see that the product or convolution of a ")#mi("{k}")#text("-derived multiplicative function ")#mi("{f: {\\bf N} \\rightarrow R}")#text(" and a ")#mi("{l}")#text("-derived multiplicative function ")#mi("{g: {\\bf N} \\rightarrow R}")#text(" is necessarily a ")#mi("{k+l}")#text("-derived multiplicative function (again taking values in ")#mi("{R}")#text("). Thus, for instance, the higher-order von Mangoldt functions ")#mi("{\\Lambda_k := \\mu * L^k}")#text(" are ")#mi("{k}")#text("-derived multiplicative functions, because ")#mi("{L^k}")#text(" is a ")#mi("{k}")#text("-derived completely multiplicative function. More explicitly, ")#mi("{L^k}")#text(" is the top order coeffiicent of the completely multiplicative function ")#mi("{\\prod_{i=1}^k \\exp(\\varepsilon_i L)}")#text(", and ")#mi("{\\Lambda_k}")#text(" is the top order coefficient of the multiplicative function ")#mi("{\\mu * \\prod_{i=1}^k \\exp(\\varepsilon_i L)}")#text(", with both functions taking values in the ring ")#mi("{C[\\varepsilon_1,\\dots,\\varepsilon_k]/(\\varepsilon_1^2,\\dots,\\varepsilon_k^2)}")#text(" of complex numbers with ")#mi("{k}")#text(" infinitesimals ")#mi("{\\varepsilon_1,\\dots,\\varepsilon_k}")#text(" attached.")

#text("It then turns out that most (if not all) of the basic identities used by analytic number theorists concerning derived multiplicative functions, can in fact be viewed as coefficients of identities involving purely multiplicative functions, with the latter identities being provable primarily from multiplicative identities, such as ")#link(<tao-40f1502e481bef13ea4c>)[#text("(1)")]#text(". This phenomenon is analogous to the one in linear algebra discussed in ")#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/")[#text("this previous blog post")]#text(", in which many of the trace identities used there are derivatives of determinant identities. For instance, the Leibniz rule")

#align(center)[#tao-fit-display[#mitex("L (f * g) = (Lf)*g + f*(Lg)")]]

#text("for any arithmetic functions ")#mi("{f,g}")#text(" can be viewed as the top order term in")

#align(center)[#tao-fit-display[#mitex("\\exp(\\varepsilon L) (f*g) = (\\exp(\\varepsilon L) f) * (\\exp(\\varepsilon L) g)")]]

#text("in the ring with one infinitesimal ")#mi("{\\varepsilon}")#text(", and then we see that the Leibniz rule is a special case (or a derivative) of ")#link(<tao-40f1502e481bef13ea4c>)[#text("(1)")]#text(", since ")#mi("{\\exp(\\varepsilon L)}")#text(" is completely multiplicative. Similarly, the formulae")

#align(center)[#tao-fit-display[#mitex("\\Lambda = \\mu * L; \\quad L = \\Lambda * 1")]]

#text("are top order terms of")

#align(center)[#tao-fit-display[#mitex("(\\delta + \\varepsilon \\Lambda) = \\mu * \\exp(\\varepsilon L); \\quad \\exp(\\varepsilon L) = (\\delta + \\varepsilon \\Lambda) * 1,")]]

#text("and the variant formula ")#mi("{\\Lambda = - (L\\mu) * 1}")#text(" is the top order term of")

#align(center)[#tao-fit-display[#mitex("(\\delta + \\varepsilon \\Lambda) = (\\exp(-\\varepsilon L)\\mu) * 1,")]]

#text("which can then be deduced from the previous identities by noting that the completely multiplicative function ")#mi("{\\exp(-\\varepsilon L)}")#text(" inverts ")#mi("{\\exp(\\varepsilon L)}")#text(" multiplicatively, and also noting that ")#mi("{L}")#text(" annihilates ")#mi("{\\mu*1=\\delta}")#text(". The Selberg symmetry formula ")#metadata(none) <tao-7c84ce75d92e62ebdbe7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\Lambda_2 = \\Lambda*\\Lambda + \\Lambda L,")]]



#text(" which plays a key role in the Erdös-Selberg elementary proof of the prime number theorem (as discussed in ")#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/")[#text("this previous blog post")]#text("), is the top order term of the identity")

#align(center)[#tao-fit-display[#mitex("\\delta + \\varepsilon_1 \\Lambda + \\varepsilon_2 \\Lambda + \\varepsilon_1\\varepsilon_2 \\Lambda_2 = (\\exp(\\varepsilon_2 L) (\\delta + \\varepsilon_1 \\Lambda)) * (\\delta + \\varepsilon_2 \\Lambda)")]]

#text("involving the multiplicative functions ")#mi("{\\delta + \\varepsilon_1 \\Lambda + \\varepsilon_2 \\Lambda + \\varepsilon_1\\varepsilon_2 \\Lambda_2}")#text(", ")#mi("{\\exp(\\varepsilon_2 L)}")#text(", ")#mi("{\\delta+\\varepsilon_1 \\Lambda}")#text(", ")#mi("{\\delta+\\varepsilon_2 \\Lambda}")#text(" with two infinitesimals ")#mi("{\\varepsilon_1,\\varepsilon_2}")#text(", and this identity can be proven while staying purely within the realm of multiplicative functions, by using the identities")

#tao-aligned(keep: true)[


#tao-math("\\delta + \\varepsilon_1 \\Lambda + \\varepsilon_2 \\Lambda + \\varepsilon_1\\varepsilon_2 \\Lambda_2  & = \\mu * (\\exp(\\varepsilon_1 L) \\exp(\\varepsilon_2 L))", block: true)



#tao-math("\\exp(\\varepsilon_1 L)  & = 1 * (\\delta + \\varepsilon_1 \\Lambda)", block: true)



#tao-math("\\delta + \\varepsilon_2 \\Lambda  & = \\mu * \\exp(\\varepsilon_2 L)", block: true)
]

#text("and ")#link(<tao-40f1502e481bef13ea4c>)[#text("(1)")]#text(". Similarly for higher identities such as")

#align(center)[#tao-fit-display[#mitex("\\Lambda_3 = \\Lambda L^2 + 3 \\Lambda L * \\Lambda + \\Lambda * \\Lambda * \\Lambda")]]

#text("which arise from expanding out ")#mi("{\\mu * (\\exp(\\varepsilon_1 L) \\exp(\\varepsilon_2 L) \\exp(\\varepsilon_3 L))}")#text(" using ")#link(<tao-40f1502e481bef13ea4c>)[#text("(1)")]#text(" and the above identities; we leave this as an exercise to the interested reader.")

#text("An analogous phenomenon arises for identities that are not purely multiplicative in nature due to the presence of truncations, such as the ")#link("http://en.wikipedia.org/wiki/Vaughan's_identity")[#text("Vaughan identity")]#text(" ")#metadata(none) <tao-f354fdc5c62f3318972d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\Lambda_{> V} = \\mu_{\\leq U} * L - \\mu_{\\leq U} * \\Lambda_{\\leq V} * 1 + \\mu_{>U} * \\Lambda_{>V} * 1")]]



#text(" for any ")#mi("{U,V \\geq 1}")#text(", where ")#mi("{f_{>V} = f 1_{>V}}")#text(" is the restriction of a multiplicative function ")#mi("{f}")#text(" to the natural numbers greater than ")#mi("{V}")#text(", and similarly for ")#mi("{f_{\\leq V}}")#text(", ")#mi("{f_{>U}}")#text(", ")#mi("{f_{\\leq U}}")#text(". In this particular case, ")#link(<tao-f354fdc5c62f3318972d>)[#text("(4)")]#text(" is the top order coefficient of the identity")

#tao-aligned(keep: true)[


#tao-math("(\\delta + \\varepsilon \\Lambda)_{>V}  & = \\mu_{\\leq U} * \\exp(\\varepsilon L) - \\mu_{\\leq U} * (\\delta + \\varepsilon \\Lambda)_{\\leq V} * 1", block: true)



#tao-math(" & + \\mu_{>U} * (\\delta+\\varepsilon \\Lambda)_{>V} * 1", block: true)
]

#text("which can be easily derived from the identities ")#mi("{\\delta = \\mu_{\\leq U} * 1 + \\mu_{>U} * 1}")#text(" and ")#mi("{\\exp(\\varepsilon L) = (\\delta + \\varepsilon \\Lambda)_{>V} * 1 + (\\delta + \\varepsilon \\Lambda)_{\\leq V} + 1}")#text(". Similarly for the Heath-Brown identity ")#metadata(none) <tao-c18e9749b86ee550c3d8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\Lambda = \\sum_{j=1}^K (-1)^{j-1} \\binom{K}{j} \\mu_{\\leq U}^{*j} * 1^{*j-1} * L")]]



#text(" valid for natural numbers up to ")#mi("{U^K}")#text(", where ")#mi("{U \\geq 1}")#text(" and ")#mi("{K \\geq 1}")#text(" are arbitrary parameters and ")#mi("{f^{*j}}")#text(" denotes the ")#mi("{j}")#text("-fold convolution of ")#mi("{f}")#text(", and discussed in ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")[#text("this previous blog post")]#text("; this is the top order coefficient of")

#align(center)[#tao-fit-display[#mitex("\\delta + \\varepsilon \\Lambda = \\sum_{j=1}^K (-1)^{j-1} \\binom{K}{j} \\mu_{\\leq U}^{*j} * 1^{*j-1} * \\exp( \\varepsilon L )")]]

#text("and arises by first observing that")

#align(center)[#tao-fit-display[#mitex("(\\mu - \\mu_{\\leq U})^{*K} * 1^{*K-1} * \\exp(\\varepsilon L) = \\mu_{>U}^{*K} * 1^{*K-1} * \\exp( \\varepsilon L )")]]

#text("vanishes up to ")#mi("{U^K}")#text(", and then expanding the left-hand side using the binomial formula and the identity ")#mi("{\\mu^{*K} * 1^{*K-1} * \\exp(\\varepsilon L) = \\delta + \\varepsilon \\Lambda}")#text(".")

#text("One consequence of this phenomenon is that identities involving derived multiplicative functions tend to have a dimensional consistency property: all terms in the identity have the same order of derivation in them. For instance, all the terms in the Selberg symmetry formula ")#link(<tao-7c84ce75d92e62ebdbe7>)[#text("(3)")]#text(" are doubly derived functions, all the terms in the Vaughan identity ")#link(<tao-f354fdc5c62f3318972d>)[#text("(4)")]#text(" or the Heath-Brown identity ")#link(<tao-c18e9749b86ee550c3d8>)[#text("(5)")]#text(" are singly derived functions, and so forth. One can then use dimensional analysis to help ensure that one has written down a key identity involving such functions correctly, much as is done in physics.")

#text("In addition to the dimensional analysis arising from the order of derivation, there is another dimensional analysis coming from the value of multiplicative functions at primes ")#mi("{p}")#text(" (which is more or less equivalent to the order of pole of the Dirichlet series at ")#mi("{s=1}")#text("). Let us say that a multiplicative function ")#mi("{f: {\\bf N} \\rightarrow R}")#text(" has a ")#emph[#text("pole of order ")#mi("{j}")]#text(" if one has ")#mi("{f(p)=j}")#text(" on the average for primes ")#mi("{p}")#text(", where we will be a bit vague as to what “on the average” means as it usually does not matter in applications. Thus for instance, ")#mi("{1}")#text(" or ")#mi("{\\exp(\\varepsilon L)}")#text(" has a pole of order ")#mi("{1}")#text(" (a simple pole), ")#mi("{\\delta}")#text(" or ")#mi("{\\delta + \\varepsilon \\Lambda}")#text(" has a pole of order ")#mi("{0}")#text(" (i.e. neither a zero or a pole), Dirichlet characters also have a pole of order ")#mi("{0}")#text(" (although this is slightly nontrivial, requiring Dirichlet’s theorem), ")#mi("{\\mu}")#text(" has a pole of order ")#mi("{-1}")#text(" (a simple zero), ")#mi("{\\tau}")#text(" has a pole of order ")#mi("{2}")#text(", and so forth. Note that the convolution of a multiplicative function with a pole of order ")#mi("{j}")#text(" with a multiplicative function with a pole of order ")#mi("{j^{\\prime}}")#text(" will be a multiplicative function with a pole of order ")#mi("{j+j^{\\prime}}")#text(". If there is no oscillation in the primes ")#mi("{p}")#text(" (e.g. if ")#mi("{f(p)=j}")#text(" for ")#emph[#text("all")]#text(" primes ")#mi("{p}")#text(", rather than on the average), it is also true that the product of a multiplicative function with a pole of order ")#mi("{j}")#text(" with a multiplicative function with a pole of order ")#mi("{j^{\\prime}}")#text(" will be a multiplicative function with a pole of order ")#mi("{jj^{\\prime}}")#text(". The situation is significantly different though in the presence of oscillation; for instance, if ")#mi("{\\chi}")#text(" is a quadratic character then ")#mi("{\\chi^2}")#text(" has a pole of order ")#mi("{1}")#text(" even though ")#mi("{\\chi}")#text(" has a pole of order ")#mi("{0}")#text(".")

#text("A ")#mi("{k}")#text("-derived multiplicative function will then be said to have an ")#emph[#text("underived pole of order ")#mi("{j}")]#text(" if it is the top order coefficient of a multiplicative function with a pole of order ")#mi("{j}")#text("; in terms of Dirichlet series, this roughly means that the Dirichlet series has a pole of order ")#mi("{j+k}")#text(" at ")#mi("{s=1}")#text(". For instance, the singly derived multiplicative function ")#mi("{\\Lambda}")#text(" has an underived pole of order ")#mi("{0}")#text(", because it is the top order coefficient of ")#mi("{\\delta + \\varepsilon \\Lambda}")#text(", which has a pole of order ")#mi("{0}")#text("; similarly ")#mi("{L}")#text(" has an underived pole of order ")#mi("{1}")#text(", being the top order coefficient of ")#mi("{\\exp(\\varepsilon L)}")#text(". More generally, ")#mi("{\\Lambda_k}")#text(" and ")#mi("{L^k}")#text(" have underived poles of order ")#mi("{0}")#text(" and ")#mi("{1}")#text(" respectively for any ")#mi("{k}")#text(".")

#text("By taking top order coefficients, we then see that the convolution of a ")#mi("{k}")#text("-derived multiplicative function with underived pole of order ")#mi("{j}")#text(" and a ")#mi("{k^{\\prime}}")#text("-derived multiplicative function with underived pole of order ")#mi("{j^{\\prime}}")#text(" is a ")#mi("{k+k^{\\prime}}")#text("-derived multiplicative function with underived pole of order ")#mi("{j+j^{\\prime}}")#text(". If there is no oscillation in the primes, the product of these functions will similarly have an underived pole of order ")#mi("{jj^{\\prime}}")#text(", for instance ")#mi("{\\Lambda L}")#text(" has an underived pole of order ")#mi("{0}")#text(". We then have the dimensional consistency property that in any of the standard identities involving derived multiplicative functions, all terms not only have the same derived order, but also the same underived pole order. For instance, in ")#link(<tao-7c84ce75d92e62ebdbe7>)[#text("(3)")]#text(", ")#link(<tao-f354fdc5c62f3318972d>)[#text("(4)")]#text(", ")#link(<tao-c18e9749b86ee550c3d8>)[#text("(5)")]#text(" all terms have underived pole order ")#mi("{0}")#text(" (with any Mobius function terms being counterbalanced by a matching term of ")#mi("{1}")#text(" or ")#mi("{L}")#text("). This gives a second way to use dimensional analysis as a consistency check. For instance, any identity that involves a linear combination of ")#mi("{\\mu_{\\leq U} * L}")#text(" and ")#mi("{\\Lambda_{>V} * 1}")#text(" is suspect because the underived pole orders do not match (being ")#mi("{0}")#text(" and ")#mi("{1}")#text(" respectively), even though the derived orders match (both are ")#mi("{1}")#text(").")

#text("One caveat, though: this latter dimensional consistency breaks down for identities that involve infinitely many terms, such as Linnik’s identity")

#align(center)[#tao-fit-display[#mitex("\\Lambda = \\sum_{i=0}^\\infty (-1)^{i} L * 1_{>1}^{*i}.")]]

#text("In this case, one can still rewrite things in terms of multiplicative functions as")

#align(center)[#tao-fit-display[#mitex("\\delta + \\varepsilon \\Lambda = \\sum_{i=0}^\\infty (-1)^i \\exp(\\varepsilon L) * 1_{>1}^{*i},")]]

#text("so the former dimensional consistency is still maintained.")

#text("I thank Andrew Granville, Kannan Soundararajan, and Emmanuel Kowalski for helpful conversations on these topics.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (20)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/#comment-419803")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2014")])]

#text("It seems that the sum of two multiplicative functions can be multiplicative only if one of them is the constant function ")#mi("0")#text(".")

#emph[#text("[By definition, multiplicative functions are required to take the value ")#mi("1")#text(" at ")#mi("1")#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a775d453bcd6946c502156f1cb35a4bed1e86c38743b7a8571353128d52ec436-2b5bcc287629bf18fb3f6a74d4985caac1fe38ce645b05a2bab667c82d4872a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/#comment-419825")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2014")])]

#text("Dear Prof. Tao, My browser (IE) mentions a parsing error for the formula preceding Remark 1.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8504a323aa918a342edb89d935ce5fd1a06d8ce476acba81c14188526cc43968-716d7e62d20e5a91751d3f78fa30ddf9743ded2e631bbb009398563ffd86b202.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ACB")]], [#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/#comment-419941")[#strong[#text("ACB")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2014")])]

#text("Should the second j in the sentence beginning, “Note that the convolution of a multiplicative function…” be a j’?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/#comment-420161")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2014")])]

#text("If you don’t like the language of nilpotents, maybe just use matrices? Your epsilon can be written as")

#text("0 1")#linebreak()#text(" 0 0")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/#comment-421908")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2014")])]

#text("Wouldn’t Hecke operators ")#mi("T_n")#text(" on modular curves be an example of a multiplicative function ")#mi("n\\mapsto T_n")#text(", considered as a map to endomorphisms of modular forms?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/#comment-422388")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2014")])]

#text("Yes, this is an example. It looks like the corresponding endomorphism-valued Dirichlet series generates scalar Dirichlet series associated to various modular forms as coefficients using a basis of Hecke eigenforms, though this statement is basically tautological and I don’t know if one can do much with it that one can’t already do with the usual formulation of Hecke operators and eigenforms.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/#comment-428717")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2014")])]

#text("Very nice! I was just wondering the other day – is there a name for the “higher identities” such as the one involving ")#mi("\\Lambda_3")#text("? (I know about Diamond-Steinig identities for ")#mi("\\Lambda_{2k}")#text(".) I thought these identities were somehow associated with Bombieri, but that may be an association that existed partly in my head. (I’ve also heard some people crediting them to Faa di Bruno, who wrote down a chain rule for higher derivatives in the nineteenth century, but was not the first to do so.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/#comment-428725")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2014")])]

#text("The identity ")#mi("\\Lambda_k = \\Lambda_{k-1} L + \\Lambda * \\Lambda_k")#text(" explicitly appears in this 1975 paper of Bombieri: ")#link("http://matwbn.icm.edu.pl/ksiazki/aa/aa28/aa2828.pdf")[#text("http://matwbn.icm.edu.pl/ksiazki/aa/aa28/aa2828.pdf")]#text(" . I don’t know if this is the earliest explicit appearance of it, though. For instance, Selberg already (implicitly) used the k=2 version of this formula in his 1949 proof of the prime number theorem in ")#link("http://www.jstor.org/stable/1969455")[#text("http://www.jstor.org/stable/1969455")]#text(" , so I would find it plausible that he was aware of some version of the higher k identity also (but perhaps using different notation than the now-standard ")#mi("\\Lambda_k")#text("). Actually, I think the use of ")#mi("\\Lambda_k")#text(" as a tool to detect k-almost primes even predates Selberg, though I’ll have to track down a precise reference for this…")

#text("[UPDATE: I found the reference, but it turns out to postdate Selberg by a little bit: a close relative of the above identity appears in the 1956 PhD thesis of Golomb, “Problems in the distribution of the prime numbers”, in which it is observed that ")#mi("\\Lambda(a_1) \\dots \\Lambda(a_k) = \\frac{(-1)^k}{k!} (L^k \\mu * 1)(a_1 \\dots a_k)")#text(" whenever ")#mi("a_1,\\dots,a_k > 1")#text(" are coprime; see ")#link("http://www.sciencedirect.com/science/article/pii/0022314X70900193")[#text("http://www.sciencedirect.com/science/article/pii/0022314X70900193")]#text(" .]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/#comment-429683")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2014")])]

#text("This is helpful; thanks. However, for several applications (including at least some of those of Selberg, I believe) an identity involving $L^k\\mu \\ast 1$ has got $L^k$ attached to the wrong factor; it is much nicer to have it attached to $1$ rather than to $\\mu$.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/065138e1b1902805d7f744a8b774918e0ccbb72d8c610f9cb5f0d04cde9795e3-c304526fcf69ae299ab157ae31b1f0cc68fc0ab5c24aaa809399deb8b52fce69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mats Granvik")]], [#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/#comment-429717")[#strong[#text("Mats Granvik")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2014")])]

#text("Möbius function calculated from arbitrary numbers as input:")#linebreak()#text(" ")#link("http://math.stackexchange.com/questions/268159/m%c3%b6bius-function-from-random-number-sequence")[#text("http://math.stackexchange.com/questions/268159/m%c3%b6bius-function-from-random-number-sequence")]

#mi("\\varphi (n) = n\\lim\\limits_ {s \\rightarrow 1}\\zeta (s)\\sum\\limits_ {d | n}\\mu (d) (e^{1/d})^{(s - 1)}")

#mi("a(n) = \\lim\\limits_{s \\rightarrow 1} \\zeta(s)\\sum\\limits_{d|n} \\mu(d)(e^{d})^{(s-1)}")

#mi("\\Lambda(n) =\\sum\\limits_{k=1}^{\\infty} \\frac{a(GCD(n,k))}{k}")

#mi("\\Lambda(n)=\\lim\\limits_{s \\rightarrow 1} \\zeta(s)\\sum\\limits_{d|n} \\frac{\\mu(d)}{d^{(s-1)}}")

#mi("\\text{Fourier Transform of } \\Lambda(n) \\sim \\sum\\limits_{n=1}^{n=k} \\frac{1}{n} \\zeta(1/2+i \\cdot t)\\sum\\limits_{d|n} \\frac{\\mu(d)}{d^{(1/2+i \\cdot t-1)}}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/#comment-443030")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2014")])]

#text("The use of ")#mi("R")#text(" and ")#mi("{\\bf R}")#text(" is inconsistent in Definition 1.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b707207aa753455cd94549e35c5d41f37f2b0362274c507983ed665f108df4df-2e7d28c391b8caf33ed3d70a9ebfebf772fc9990b2cddc10fa6a343c919b0ba8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Top 30 Computer Science and Programming Blogs | Yo Worlds")]], [#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/#comment-449683")[#strong[#text("Top 30 Computer Science and Programming Blogs | Yo Worlds")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2015")])]

#text("[…] 14. Terry Tao’s Blog: Terry Tao is a mathematician whose work is frequently relevant for computer scientists and computational theorists. Most of the posts are highly technical mathematical demonstrations that are not accessible to layman. This makes his blog an intellectually challenging but fruitful endeavor for the serious student of computer science or mathematics. Highlight: Derived Multiplicative Functions […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/#comment-455924")[#strong[#text("Топ-30 лучших блогов о программировании… | IT News")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2015")]

#text("[…] Что почитать на Terry Tao’s Blog: Производные мультипликативные функции […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/#comment-460589")[#strong[#text("BLOGS ON COMPUTER SCIENCE | CS SECTION 6B 2013")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2015")]

#text("[…] 14. Terry Tao’s Blog: Terry Tao is a mathematician whose work is frequently relevant for computer scientists and computational theorists. Most of the posts are highly technical mathematical demonstrations that are not accessible to layman. This makes his blog an intellectually challenging but fruitful endeavor for the serious student of computer science or mathematics. Highlight: Derived Multiplicative Functions […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heuristic computation of correlations of the divisor function | What's new")]], [#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/#comment-472024")[#strong[#text("Heuristic computation of correlations of the divisor function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2016")])]

#text("[…] We remark that is an example of a derived multiplicative function, discussed in this previous blog post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 1: Elementary multiplicative number theory | What's new")]], [#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/#comment-472490")[#strong[#text("254A, Notes 1: Elementary multiplicative number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2016")])]

#text("[…] also considers arithmetic functions taking values in more general rings than or , as in this previous blog post, but we will restrict attention here to the classical situation of real ofr complex arithmetic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/#comment-488286")[#strong[#text("Computer science – Live Free")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2017")]

#text("[…] 14. Terry Tao’s Blog: Terry Tao is a mathematician whose work is frequently relevant for computer scientists and computational theorists. Most of the posts are highly technical mathematical demonstrations that are not accessible to layman. This makes his blog an intellectually challenging but fruitful endeavor for the serious student of computer science or mathematics. Highlight: Derived Multiplicative Functions […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/#comment-489253")[#strong[#text("Топ-30 лучших блогов о программировании и вычислительной технике — Rus.Rocks")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2017")]

#text("[…] Что почитать на Terry Tao’s Blog: Производные мультипликативные функции […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/559be3f98ef03df95d622b84afb23c21814d1d34d821900838159be695f1b694-75242e640f0c62602d9e29e85f66e460d12a4933800f0cab05c17474b91ffe7c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Lynch")]], [#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/#comment-489857")[#strong[#text("Sean Lynch")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2017")])]

#text("Regarding remark 1, do you mean the logarithmic derivative of an Euler product?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f6dd99a5b04d4a9fd59c097ec428f9b4e28351e8a70021eda50659472a40029-be15e6e271a6e95cb6b79428d340fd4216b18ecd5bf01d9c37e1a4902a9ff429.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asahay22")]], [#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/#comment-618998")[#strong[#text("asahay22")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2021")])]

#text("Unless I’ve misunderstood something, it appears to me that 1-derived multiplicative functions are precisely the functions that arise as the coefficients of ")#mi("x^1")#text(" in for a multiplicative function ")#mi("f:\\mathbb{N} \\to \\mathbb{C}[[x]]")#text(". This raises the question that do functions that are the coefficients of ")#mi("x^j")#text(" for ")#mi("f")#text(" as above arise in analytic number theory or sieve theory?")

#text("Also, a minor point, but I think you intended to use ")#mi("\\mathbf{C}")#text(" in the paragraph right after Remark 1.")
]
