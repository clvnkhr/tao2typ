// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/
// Converted to Typst by tao2typ: "2026-10-14T15:17:36.956090+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 3a: Eigenvalues and sums of Hermitian matrices", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 3a: Eigenvalues and sums of Hermitian matrices")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 January 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/")[#text("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{A}")#text(" be a Hermitian ")#mi("{n \\times n}")#text(" matrix. By the ")#link("http://en.wikipedia.org/wiki/Spectral_theorem")[#text("spectral theorem")]#text(" for Hermitian matrices (which, for sake of completeness, we prove below), one can diagonalise ")#mi("{A}")#text(" using a sequence")

#align(center)[#tao-fit-display[#mitex("\\lambda_1(A) \\geq \\ldots \\geq \\lambda_n(A)")]]

#text("of ")#mi("{n}")#text(" real eigenvalues, together with an orthonormal basis of eigenvectors ")#mi("{u_1(A),\\ldots,u_n(A) \\in {\\mathbb C}^n}")#text(". (The eigenvalues are uniquely determined by ")#mi("{A}")#text(", but the eigenvectors have a little ambiguity to them, particularly if there are repeated eigenvalues; for instance, one could multiply each eigenvector by a complex phase ")#mi("{e^{i\\theta}}")#text(". In these notes we are arranging eigenvalues in descending order; of course, one can also arrange eigenvalues in increasing order, which causes some slight notational changes in the results below.) The set ")#mi("{\\{\\lambda_1(A),\\ldots,\\lambda_n(A)\\}}")#text(" is known as the ")#link("http://en.wikipedia.org/wiki/Spectrum_of_a_matrix")[#text("spectrum")]#text(" of ")#mi("{A}")#text(".")

#text("A basic question in linear algebra asks the extent to which the eigenvalues ")#mi("{\\lambda_1(A),\\ldots,\\lambda_n(A)}")#text(" and ")#mi("{\\lambda_1(B),\\ldots,\\lambda_n(B)}")#text(" of two Hermitian matrices ")#mi("{A, B}")#text(" constrains the eigenvalues ")#mi("{\\lambda_1(A+B),\\ldots,\\lambda_n(A+B)}")#text(" of the sum. For instance, the linearity of trace")

#align(center)[#tao-fit-display[#mitex("\\text{tr}(A+B) = \\text{tr}(A)+\\text{tr}(B),")]]

#text("when expressed in terms of eigenvalues, gives the trace constraint ")#metadata(none) <tao-eafe895eb8119e6e5d06>

#tao-aligned(keep: true)[


#tao-math("\\lambda_1(A+B)+\\ldots+\\lambda_n(A+B)  & = \\lambda_1(A)+\\ldots+\\lambda_n(A)", block: true, numbering: n => [#text("(1)")])



#tao-math(" & +\\lambda_1(B)+\\ldots+\\lambda_n(B);", block: true)
]

#text("the identity ")#metadata(none) <tao-2804bad6fe94a55f18b2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\lambda_1(A) = \\sup_{\\left|v\\right|=1} v^* Av", block: true)]]

#text("(together with the counterparts for ")#mi("{B}")#text(" and ")#mi("{A+B}")#text(") gives the inequality ")#metadata(none) <tao-8490dba9c1a1aaca6116>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\lambda_1(A+B) \\leq \\lambda_1(A) + \\lambda_1(B);")]]

#text("and so forth.")

#text("The complete answer to this problem is a fascinating one, requiring a strangely recursive description (once known as ")#emph[#text("Horn’s conjecture")]#text(", which is now solved), and connected to a large number of other fields of mathematics, such as geometric invariant theory, intersection theory, and the combinatorics of a certain gadget known as a “honeycomb”. See for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=1811121")[#text("my survey with Allen Knutson")]#text(" on this topic some years ago.")

#text("In typical applications to random matrices, one of the matrices (say, ")#mi("{B}")#text(") is “small” in some sense, so that ")#mi("{A+B}")#text(" is a perturbation of ")#mi("{A}")#text(". In this case, one does not need the full strength of the above theory, and instead rely on a simple aspect of it pointed out ")#link("http://www.ams.org/mathscinet-getitem?mr=1316359")[#text("by Helmke and Rosenthal")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1463972")[#text("by Totaro")]#text(", which generates several of the ")#emph[#text("eigenvalue inequalities")]#text(" relating ")#mi("{A}")#text(", ")#mi("{B}")#text(", and ")#mi("{C}")#text(", of which ")#link(<tao-eafe895eb8119e6e5d06>)[#text("(1)")]#text(" and ")#link(<tao-8490dba9c1a1aaca6116>)[#text("(3)")]#text(" are examples. (Actually, this method eventually generates ")#emph[#text("all")]#text(" of the eigenvalue inequalities, but this is a non-trivial fact to prove.) These eigenvalue inequalities can mostly be deduced from a number of ")#emph[#text("minimax")]#text(" characterisations of eigenvalues (of which ")#link(<tao-2804bad6fe94a55f18b2>)[#text("(2)")]#text(" is a typical example), together with some basic facts about intersections of subspaces. Examples include the ")#link("http://en.wikipedia.org/wiki/Weyl's_inequality")[#text("Weyl inequalities")]#text(" ")#metadata(none) <tao-e3d8c301b327d61d49b7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\lambda_{i+j-1}(A+B) \\leq \\lambda_i(A) + \\lambda_j(B),")]]

#text("valid whenever ")#mi("{i,j \\geq 1}")#text(" and ")#mi("{i+j-1 \\leq n}")#text(", and the ")#emph[#text("Ky Fan inequality")]

#align(center)[#tao-fit-display[#mitex("\\lambda_1(A+B)+\\ldots+\\lambda_k(A+B) \\leq")]]

#metadata(none) <tao-eba779c55910c32f2b21>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\lambda_1(A)+\\ldots+\\lambda_k(A) + \\lambda_1(B)+\\ldots+\\lambda_k(B).")]]

#text("One consequence of these inequalities is that the spectrum of a Hermitian matrix is ")#emph[#text("stable")]#text(" with respect to small perturbations.")

#text("We will also establish some closely related inequalities concerning the relationships between the eigenvalues of a matrix, and the eigenvalues of its minors.")

#text("Many of the inequalities here have analogues for the singular values of non-Hermitian matrices (which is consistent with the discussion near Exercise 16 of ")#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")[#text("Notes 3")]#text("). However, the situation is markedly different when dealing with ")#emph[#text("eigenvalues")]#text(" of ")#emph[#text("non-Hermitian")]#text(" matrices; here, the spectrum can be far more unstable, if ")#link("http://en.wikipedia.org/wiki/Pseudospectrum")[#text("pseudospectrum")]#text(" is present. Because of this, the theory of the eigenvalues of a random non-Hermitian matrix requires an additional ingredient, namely upper bounds on the prevalence of pseudospectrum, which after recentering the matrix is basically equivalent to establishing lower bounds on least singular values. We will discuss this point in more detail in later notes.")

#text("We will work primarily here with Hermitian matrices, which can be viewed as self-adjoint transformations on complex vector spaces such as ")#mi("{{\\mathbb C}^n}")#text(". One can of course specialise the discussion to real symmetric matrices, in which case one can restrict these complex vector spaces to their real counterparts ")#mi("{{\\mathbb R}^n}")#text(". The specialisation of the complex theory below to the real case is straightforward and is left to the interested reader.")

#metadata(none) <tao-79cf9aaa7de245f5f4f4>

#heading(level: 1)[#strong[#text(" — 1. Proof of spectral theorem — ")]]

#text("To prove the spectral theorem, it is convenient to work more abstractly, in the context of self-adjoint operators on finite-dimensional Hilbert spaces:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Spectral theorem)")]#text(" ")#metadata(none) <tao-d4f02eaafd1a9e9de7d1>#text(" Let ")#mi("{V}")#text(" be a finite-dimensional complex Hilbert space of some dimension ")#mi("{n}")#text(", and let ")#mi("{T: V \\rightarrow V}")#text(" be a self-adjoint operator. Then there exists an orthonormal basis ")#mi("{v_1,\\ldots,v_n \\in V}")#text(" of ")#mi("{V}")#text(" and eigenvalues ")#mi("{\\lambda_1,\\ldots,\\lambda_n \\in {\\mathbb R}}")#text(" such that ")#mi("{T v_i = \\lambda_i v_i}")#text(" for all ")#mi("{1 \\leq i \\leq n}")#text(".")
]

#text("The spectral theorem as stated in the introduction then follows by specialising to the case ")#mi("{V = {\\mathbb C}^n}")#text(" and ordering the eigenvalues.")

#emph[#text("Proof:")]#text(" We induct on the dimension ")#mi("{n}")#text(". The claim is vacuous for ")#mi("{n=0}")#text(", so suppose that ")#mi("{n \\geq 1}")#text(" and that the claim has already been proven for ")#mi("{n=1}")#text(".")

#text("Let ")#mi("{v}")#text(" be a unit vector in ")#mi("{{\\mathbb C}^n}")#text(" (thus ")#mi("{v^* v = 1}")#text(") that maximises the form ")#mi("{\\text{Re} v^* Tv}")#text("; this maximum exists by compactness. By the method of ")#link("http://en.wikipedia.org/wiki/Lagrange_multipliers")[#text("Lagrange multipliers")]#text(", ")#mi("{v}")#text(" is a critical point of ")#mi("{\\text{Re} v^* Tv - \\lambda v^* v}")#text(" for some ")#mi("{\\lambda \\in {\\mathbb R}}")#text(". Differentiating in an arbitrary direction ")#mi("{w \\in {\\mathbb C}^n}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\text{Re} ( v^* Tw + w^* Tv - \\lambda v^* w - \\lambda w^* v ) = 0;")]]

#text("this simplifies using self-adjointness to")

#align(center)[#tao-fit-display[#mitex("\\text{Re} ( w^* (Tv - \\lambda v) ) = 0.")]]

#text("Since ")#mi("{w \\in {\\mathbb C}^n}")#text(" was arbitrary, we conclude that ")#mi("{Tv = \\lambda v}")#text(", thus ")#mi("{v}")#text(" is a unit eigenvector of ")#mi("{T}")#text(". By self-adjointness, this implies that the orthogonal complement ")#mi("{v^\\perp := \\{ w \\in V: v^* w = 0 \\}}")#text(" of ")#mi("{v}")#text(" is preserved by ")#mi("{T}")#text(". Restricting ")#mi("{T}")#text(" to this lower-dimensional subspace and applying the induction hypothesis, we can find an orthonormal basis of eigenvectors of ")#mi("{T}")#text(" on ")#mi("{v^\\perp}")#text(". Adjoining the new unit vector ")#mi("{v}")#text(" to the orthonormal basis, we obtain the claim. ")#mi("\\Box")

#text("Suppose we have a self-adjoint transformation ")#mi("{A: {\\mathbb C}^n \\rightarrow {\\mathbb C}^n}")#text(", which of course can be identified with a Hermitian matrix. Using the orthogonal eigenbasis provided by the spectral theorem, we can perform an orthonormal change of variables to set that eigenbasis to be the standard basis ")#mi("{e_1,\\ldots,e_n}")#text(", so that the matrix of ")#mi("{A}")#text(" becomes diagonal. This is very useful when dealing with just a single matrix ")#mi("{A}")#text(" – for instance, it makes the task of computing functions of ")#mi("{A}")#text(", such as ")#mi("{A^k}")#text(" or ")#mi("{\\exp(tA)}")#text(", much easier. However, when one has ")#emph[#text("several")]#text(" Hermitian matrices in play (e.g. ")#mi("{A, B, C}")#text("), then it is usually not possible to standardise all the eigenbases simultaneously (i.e. to simultaneously diagonalise all the matrices), except when the matrices all commute. Nevertheless one can still normalise ")#emph[#text("one")]#text(" of the eigenbases to be the standard basis, and this is still useful for several applications, as we shall soon see.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Suppose that the eigenvalues ")#mi("{\\lambda_1(A) > \\ldots > \\lambda_n(A)}")#text(" of an ")#mi("{n \\times n}")#text(" Hermitian matrix are distinct. Show that the associated eigenbasis ")#mi("{u_1(A),\\ldots,u_n(A)}")#text(" is unique up to rotating each individual eigenvector ")#mi("{u_j(A)}")#text(" by a complex phase ")#mi("{e^{i\\theta_j}}")#text(". In particular, the ")#emph[#text("spectral projections")]#text(" ")#mi("{P_j(A) := u_j(A) u_j(A)^*}")#text(" are unique. What happens when there is eigenvalue multiplicity?")
]

#heading(level: 1)[#strong[#text(" — 2. Minimax formulae — ")]]

#text("The ")#mi("{i^{th}}")#text(" eigenvalue functional ")#mi("{A \\mapsto \\lambda_i(A)}")#text(" is not a linear functional (except in dimension one). It is not even a convex functional (except when ")#mi("{i=1}")#text(") or a concave functional (except when ")#mi("{i=n}")#text("). However, it is the next best thing, namely it is a ")#emph[#text("minimax")]#text(" expression of linear functionals. (Note that a convex functional is the same thing as a max of linear functionals, while a concave functional is the same thing as a min of linear functionals.) More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Courant-Fischer min-max theorem)")]#text(" ")#metadata(none) <tao-7f72a2bdfa8c5254d95e>#text(" Let ")#mi("{A}")#text(" be an ")#mi("{n \\times n}")#text(" Hermitian matrix. Then we have ")#metadata(none) <tao-c5bc387e963903b24398>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\lambda_i(A) = \\sup_{\\text{dim}(V)=i} \\inf_{v \\in V: \\left|v\\right|=1} v^* A v", block: true)]]

#text("and ")#metadata(none) <tao-6b4870bebe8494563136>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\lambda_i(A) = \\inf_{\\text{dim}(V)=n-i+1} \\sup_{v \\in V: \\left|v\\right|=1} v^* A v", block: true)]]

#text("for all ")#mi("{1 \\leq i \\leq n}")#text(", where ")#mi("{V}")#text(" ranges over all subspaces of ")#mi("{{\\mathbb C}^n}")#text(" with the indicated dimension.")
]

#emph[#text("Proof:")]#text(" It suffices to prove ")#link(<tao-c5bc387e963903b24398>)[#text("(6)")]#text(", as ")#link(<tao-6b4870bebe8494563136>)[#text("(7)")]#text(" follows by replacing ")#mi("{A}")#text(" by ")#mi("{-A}")#text(" (noting that ")#mi("{\\lambda_i(-A) = -\\lambda_{n-i+1}(A)}")#text(").")

#text("We first verify the ")#mi("{i=1}")#text(" case, i.e. ")#link(<tao-2804bad6fe94a55f18b2>)[#text("(2)")]#text(". By the spectral theorem, we can assume that ")#mi("{A}")#text(" has the standard eigenbasis ")#mi("{e_1,\\ldots,e_n}")#text(", in which case we have ")#metadata(none) <tao-ae09fee14b5b0aa9b4e5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("v^* A v = \\sum_{i=1}^n \\lambda_i \\left|v_i\\right|^2", block: true)]]

#text("whenever ")#mi("{v = (v_1,\\ldots,v_n)}")#text(". The claim ")#link(<tao-2804bad6fe94a55f18b2>)[#text("(2)")]#text(" is then easily verified.")

#text("To prove the general case, we may again assume ")#mi("{A}")#text(" has the standard eigenbasis. By considering the space ")#mi("{V}")#text(" spanned by ")#mi("{e_1,\\ldots,e_i}")#text(", we easily see the inequality")

#align(center)[#tao-fit-display[#tao-math("\\lambda_i(A) \\leq \\sup_{\\text{dim}(V)=i} \\inf_{v \\in V: \\left|v\\right|=1} v^* A v", block: true)]]

#text("so we only need to prove the reverse inequality. In other words, for every ")#mi("{i}")#text("-dimensional subspace ")#mi("{V}")#text(" of ")#mi("{{\\mathbb C}^n}")#text(", we have to show that ")#mi("{V}")#text(" contains a unit vector ")#mi("{v}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("v^* A v \\leq \\lambda_i(A).")]]

#text("Let ")#mi("{W}")#text(" be the space spanned by ")#mi("{e_i,\\ldots,e_n}")#text(". This space has codimension ")#mi("{i-1}")#text(", so it must have non-trivial intersection with ")#mi("{V}")#text(". If we let ")#mi("{v}")#text(" be a unit vector in ")#mi("{V \\cap W}")#text(", the claim then follows from ")#link(<tao-ae09fee14b5b0aa9b4e5>)[#text("(8)")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" By homogeneity, one can replace the restriction ")#tao-math("{\\left|v\\right|=1}", block: false)#text(" with ")#mi("{v \\neq 0}")#text(" provided that one replaces the quadratic form ")#mi("{v^* A v}")#text(" with the ")#link("http://en.wikipedia.org/wiki/Rayleigh_quotient")[#text("Rayleigh quotient")]#text(" ")#mi("{v^* A v / v^* v}")#text(".")
]

#text("A closely related formula is as follows. Given an ")#mi("{n \\times n}")#text(" Hermitian matrix ")#mi("{A}")#text(" and an ")#mi("{m}")#text("-dimensional subspace ")#mi("{V}")#text(" of ")#mi("{{\\mathbb C}^n}")#text(", we define the ")#emph[#text("partial trace")]#text(" ")#mi("{\\text{tr}(A\\downharpoonright_V)}")#text(" to be the expression")

#align(center)[#tao-fit-display[#mitex("\\text{tr}(A\\downharpoonright_V) := \\sum_{i=1}^m v_i^* A v_i")]]

#text("where ")#mi("{v_1,\\ldots,v_m}")#text(" is any orthonormal basis of ")#mi("{V}")#text(". It is easy to see that this expression is independent of the choice of orthonormal basis, and so the partial trace is well-defined.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Extremal partial trace)")]#text(" ")#metadata(none) <tao-9834a14ab9bcaa0f6a8d>#text(" Let ")#mi("{A}")#text(" be an ")#mi("{n \\times n}")#text(" Hermitian matrix. Then for any ")#mi("{1 \\leq k \\leq n}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\lambda_1(A)+\\ldots+\\lambda_k(A) = \\sup_{\\text{dim}(V)=k} \\text{tr}(A \\downharpoonright_V)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\lambda_{n-k+1}(A)+\\ldots+\\lambda_n(A) = \\inf_{\\text{dim}(V)=k} \\text{tr}(A \\downharpoonright_V).")]]
]

#text("As a corollary, we see that ")#mi("{A \\mapsto \\lambda_1(A)+\\ldots+\\lambda_k(A)}")#text(" is a convex function, and ")#mi("{A \\mapsto \\lambda_{n-k+1}(A)+\\ldots+\\lambda_n(A)}")#text(" is a concave function.")

#emph[#text("Proof:")]#text(" Again, by symmetry it suffices to prove the first formula. As before, we may assume without loss of generality that ")#mi("{A}")#text(" has the standard eigenbasis. By selecting ")#mi("{V}")#text(" to be the span of ")#mi("{e_1,\\ldots,e_k}")#text(" we have the inequality")

#align(center)[#tao-fit-display[#mitex("\\lambda_1(A)+\\ldots+\\lambda_k(A) \\leq \\sup_{\\text{dim}(V)=k} \\text{tr}(A \\downharpoonright_V)")]]

#text("so it suffices to prove the reverse inequality. For this we induct on dimension. If ")#mi("{V}")#text(" has dimension ")#mi("{k}")#text(", then it has a ")#mi("{k-1}")#text("-dimensional subspace ")#mi("{V^{\\prime}}")#text(" that is contained in the span of ")#mi("{e_2,\\ldots,e_n}")#text(". By the induction hypothesis, we have")

#align(center)[#tao-fit-display[#mitex("\\lambda_2(A)+\\ldots+\\lambda_k(A) \\geq \\text{tr}(A \\downharpoonright_{V^{\\prime}}).")]]

#text("On the other hand, if ")#mi("{v}")#text(" is a unit vector in the orthogonal complement of ")#mi("{V^{\\prime}}")#text(" in ")#mi("{V}")#text(", we see from ")#link(<tao-2804bad6fe94a55f18b2>)[#text("(2)")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\lambda_1(A) \\geq v^* A v.")]]

#text("Adding the two inequalities we obtain the claim. ")#mi("\\Box")

#text("Specialising Proposition ")#link(<tao-9834a14ab9bcaa0f6a8d>)[#text("3")]#text(" to the case when ")#mi("{V}")#text(" is a coordinate subspace (i.e. the span of ")#mi("{k}")#text(" of the basis vectors ")#mi("{e_1,\\ldots,e_n}")#text("), we conclude the ")#emph[#text("Schur-Horn inequalities")]

#align(center)[#tao-fit-display[#mitex("\\lambda_{n-k+1}(A)+\\ldots+\\lambda_n(A) \\leq")]]

#metadata(none) <tao-78214a4e70c8502794a6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("a_{i_1 i_1} + \\ldots + a_{i_k i_k} \\leq \\lambda_1(A)+\\ldots +\\lambda_k(A)")]]

#text("for any ")#mi("{1 \\leq i_1 < \\ldots < i_k \\leq n}")#text(", where ")#mi("{a_{11},a_{22},\\ldots,a_{nn}}")#text(" are the diagonal entries of ")#mi("{A}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Show that the inequalities ")#link(<tao-78214a4e70c8502794a6>)[#text("(9)")]#text(" are equivalent to the assertion that the diagonal entries ")#mi("{\\text{diag}(A) = (a_{11},a_{22},\\ldots,a_{nn})}")#text(" lies in the ")#emph[#text("permutahedron")]#text(" of ")#mi("{\\lambda_1(A),\\ldots,\\lambda_n(A)}")#text(", defined as the convex hull of the ")#mi("{n!}")#text(" permutations of ")#mi("{(\\lambda_1(A),\\ldots,\\lambda_n(A))}")#text(" in ")#mi("{{\\mathbb R}^n}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" It is a ")#link("http://mathworld.wolfram.com/HornsTheorem.html")[#text("theorem of Schur and Horn")]#text(" that these are the complete set of inequalities connecting the diagonal entries ")#mi("{\\text{diag}(A) = (a_{11},a_{22},\\ldots,a_{nn})}")#text(" of a Hermitian matrix to its spectrum. To put it another way, the image of any ")#emph[#text("coadjoint orbit")]#text(" ")#mi("{{\\mathcal O}_A := \\{ UAU^*: U \\in U(n) \\}}")#text(" of a matrix ")#mi("{A}")#text(" with a given spectrum ")#mi("{\\lambda_1,\\ldots,\\lambda_n}")#text(" under the diagonal map ")#mi("{\\text{diag}: A \\mapsto \\text{diag}(A)}")#text(" is the permutahedron of ")#mi("{\\lambda_1,\\ldots,\\lambda_n}")#text(". Note that the vertices of this permutahedron can be attained by considering the diagonal matrices inside this coadjoint orbit, whose entries are then a permutation of the eigenvalues. One can interpret this diagonal map ")#mi("{\\text{diag}}")#text(" as the ")#link("http://en.wikipedia.org/wiki/Moment_map")[#text("moment map")]#text(" associated with the conjugation action of the standard maximal torus of ")#mi("{U(n)}")#text(" (i.e. the diagonal unitary matrices) on the coadjoint orbit. When viewed in this fashion, the Schur-Horn theorem can be viewed as the special case of the more general ")#link("http://www.ams.org/mathscinet-getitem?mr=642416")[#text("Atiyah convexity theorem")]#text(" (also proven independently ")#link("http://www.ams.org/mathscinet-getitem?mr=664117")[#text("by Guillemin and Sternberg")]#text(") in symplectic geometry. Indeed, the topic of eigenvalues of Hermitian matrices turns out to be quite profitably viewed as a question in symplectic geometry (and also in algebraic geometry, particularly when viewed through the machinery of ")#link("http://en.wikipedia.org/wiki/Geometric_invariant_theory")[#text("geometric invariant theory")]#text(").")
]

#text("There is a simultaneous generalisation of Theorem ")#link(<tao-7f72a2bdfa8c5254d95e>)[#text("2")]#text(" and Proposition ")#link(<tao-9834a14ab9bcaa0f6a8d>)[#text("3")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3 (Wielandt minimax formula)")]#text(" ")#metadata(none) <tao-009988370651671c5738>#text(" Let ")#mi("{1 \\leq i_1 < \\ldots < i_k \\leq n}")#text(" be integers. Define a ")#link("http://en.wikipedia.org/wiki/Generalized_flag_variety")[#text("partial flag")]#text(" to be a nested collection ")#mi("{V_1 \\subset \\ldots \\subset V_k}")#text(" of subspaces of ")#mi("{{\\mathbb C}^n}")#text(" such that ")#mi("{\\text{dim}(V_j) = i_j}")#text(" for all ")#mi("{1 \\leq j \\leq k}")#text(". Define the associated ")#link("http://en.wikipedia.org/wiki/Schubert_variety")[#text("Schubert variety")]#text(" ")#mi("{X(V_1,\\ldots,V_k)}")#text(" to be the collection of all ")#mi("{k}")#text("-dimensional subspaces ")#mi("{W}")#text(" such that ")#mi("{\\text{dim}(W \\cap V_j) \\geq j}")#text(". Show that for any ")#mi("{n \\times n}")#text(" matrix ")#mi("{A}")#text(",")

#align(center)[#tao-fit-display[#mitex("\\lambda_{i_1}(A) + \\ldots + \\lambda_{i_k}(A) = \\sup_{V_1,\\ldots,V_k} \\inf_{W \\in X(V_1,\\ldots,V_k)} \\text{tr}(A\\downharpoonright_W).")]]
]

#heading(level: 1)[#strong[#text(" — 3. Eigenvalue inequalities — ")]]

#text("Using the above minimax formulae, we can now quickly prove a variety of eigenvalue inequalities. The basic idea is to exploit the linearity relationship ")#metadata(none) <tao-7f2fe580edb35154041f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("v^* (A+B) v = v^* A v + v^* B v")]]

#text("for any unit vector ")#mi("{v}")#text(", and more generally ")#metadata(none) <tao-7fb0f7eaad20ff6d47fb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\text{tr}((A+B) \\downharpoonright_V ) = \\text{tr}(A \\downharpoonright_V ) +\\text{tr}(B \\downharpoonright_V )")]]

#text("for any subspace ")#mi("{V}")#text(".")

#text("For instance, as mentioned before, the inequality ")#link(<tao-8490dba9c1a1aaca6116>)[#text("(3)")]#text(" follows immediately from ")#link(<tao-2804bad6fe94a55f18b2>)[#text("(2)")]#text(" and ")#link(<tao-7f2fe580edb35154041f>)[#text("(10)")]#text(". Similarly, for the Ky Fan inequality ")#link(<tao-eba779c55910c32f2b21>)[#text("(5)")]#text(", one observes from ")#link(<tao-7fb0f7eaad20ff6d47fb>)[#text("(11)")]#text(" and Proposition ")#link(<tao-9834a14ab9bcaa0f6a8d>)[#text("3")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\text{tr}((A+B) \\downharpoonright_W ) \\leq \\text{tr}(A \\downharpoonright_W ) + \\lambda_1(B) + \\ldots + \\lambda_k(B)")]]

#text("for any ")#mi("{k}")#text("-dimensional subspace ")#mi("{W}")#text(". Substituting this into Proposition ")#link(<tao-9834a14ab9bcaa0f6a8d>)[#text("3")]#text(" gives the claim. If one uses Exercise ")#link(<tao-009988370651671c5738>)[#text("3")]#text(" instead of Proposition ")#link(<tao-9834a14ab9bcaa0f6a8d>)[#text("3")]#text(", one obtains the more general ")#emph[#text("Lidskii inequality")]

#align(center)[#tao-fit-display[#mitex("\\lambda_{i_1}(A+B)+\\ldots+\\lambda_{i_k}(A+B) \\leq")]]

#metadata(none) <tao-4501770eb1d4352d2ccf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\lambda_{i_1}(A)+\\ldots+\\lambda_{i_k}(A) + \\lambda_1(B)+\\ldots+\\lambda_k(B)")]]

#text("for any ")#mi("{1 \\leq i_1 < \\ldots < i_k \\leq n}")#text(".")

#text("In a similar spirit, using the inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|v^* B v\\right| \\leq \\left\\|B\\right\\|_{op} = \\max( \\left|\\lambda_1(B)\\right|, \\left|\\lambda_n(B)\\right| )", block: true)]]

#text("for unit vectors ")#mi("{v}")#text(", combined with ")#link(<tao-7f2fe580edb35154041f>)[#text("(10)")]#text(" and ")#link(<tao-c5bc387e963903b24398>)[#text("(6)")]#text(", we obtain the eigenvalue stability inequality ")#metadata(none) <tao-de943f7bdb6ccfcaf82b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left|\\lambda_i(A+B) - \\lambda_i(A)\\right| \\leq \\left\\|B\\right\\|_{op},", block: true)]]

#text("thus the spectrum of ")#mi("{A+B}")#text(" is close to that of ")#mi("{A}")#text(" if ")#mi("{B}")#text(" is small in operator norm. In particular, we see that the map ")#mi("{A \\mapsto \\lambda_i(A)}")#text(" is Lipschitz continuous on the space of Hermitian matrices, for fixed ")#mi("{1 \\leq i \\leq n}")#text(".")

#text("More generally, suppose one wants to establish the Weyl inequality ")#link(<tao-e3d8c301b327d61d49b7>)[#text("(4)")]#text(". From ")#link(<tao-c5bc387e963903b24398>)[#text("(6)")]#text(" that it suffices to show that every ")#mi("{i+j-1}")#text("-dimensional subspace ")#mi("{V}")#text(" contains a unit vector ")#mi("{v}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("v^*(A+B)v \\leq \\lambda_i(A) + \\lambda_j(B).")]]

#text("But from ")#link(<tao-c5bc387e963903b24398>)[#text("(6)")]#text(", one can find a subspace ")#mi("{U}")#text(" of codimension ")#mi("{i-1}")#text(" such that ")#mi("{v^* A v \\leq \\lambda_i(A)}")#text(" for all unit vectors ")#mi("{v}")#text(" in ")#mi("{U}")#text(", and a subspace ")#mi("{W}")#text(" of codimension ")#mi("{j-1}")#text(" such that ")#mi("{v^* B v \\leq \\lambda_j(B)}")#text(" for all unit vectors ")#mi("{v}")#text(" in ")#mi("{W}")#text(". The intersection ")#mi("{U \\cap W}")#text(" has codimension at most ")#mi("{i+j-2}")#text(" and so has a nontrivial intersection with ")#mi("{V}")#text("; and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" More generally, one can generate an eigenvalue inequality whenever the intersection numbers of three Schubert varieties of compatible dimensions is non-zero; see the paper of ")#link("http://www.ams.org/mathscinet-getitem?mr=1316359")[#text("Helmke and Rosenthal")]#text(". In fact, this generates a complete set of inequalities; this is a ")#link("http://www.ams.org/mathscinet-getitem?mr=1654578")[#text("result of Klyachko")]#text(". One can in fact restrict attention to those varieties whose intersection number is exactly one; this is a ")#link("http://www.ams.org/mathscinet-getitem?mr=2015329")[#text("result of Knutson, Woodward, and myself")]#text(". Finally, in those cases, the fact that the intersection is one can be proven by entirely elementary means (based on the standard inequalities relating the dimension of two subspaces ")#mi("{V, W}")#text(" to their intersection ")#mi("{V \\cap W}")#text(" and sum ")#mi("{V + W}")#text("); this is a ")#link("http://arxiv.org/abs/0805.4817")[#text("result of Bercovici, Collins, Dykema, Li, and Timotin")]#text(". As a consequence, the methods in this section can, in principle, be used to derive all possible eigenvalue inequalities for sums of Hermitian matrices.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Verify the inequalities ")#link(<tao-4501770eb1d4352d2ccf>)[#text("(12)")]#text(" and ")#link(<tao-e3d8c301b327d61d49b7>)[#text("(4)")]#text(" by hand in the case when ")#mi("{A}")#text(" and ")#mi("{B}")#text(" commute (and are thus simultaneously diagonalisable), without the use of minimax formulae.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Establish the dual Lidskii inequality")

#tao-aligned(keep: true)[


#tao-math("\\lambda_{i_1}(A+B)+\\ldots+\\lambda_{i_k}(A+B)  & \\geq \\lambda_{i_1}(A)+\\ldots+\\lambda_{i_k}(A)", block: true)



#tao-math(" & + \\lambda_{n-k+1}(B)+\\ldots+\\lambda_n(B)", block: true)
]

#text("for any ")#mi("{1 \\leq i_1 < \\ldots < i_k \\leq n}")#text(" and the dual Weyl inequality")

#align(center)[#tao-fit-display[#mitex("\\lambda_{i+j-n}(A+B) \\geq \\lambda_i(A) + \\lambda_j(B)")]]

#text("whenever ")#mi("{1 \\leq i,j,i+j-n \\leq n}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Use the Lidskii inequality to establish the more general inequality")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^n c_i \\lambda_i(A+B) \\leq \\sum_{i=1}^n c_i \\lambda_i(A) + \\sum_{i=1}^n c^*_i \\lambda_i(B)")]]

#text("whenever ")#mi("{c_1,\\ldots,c_n \\geq 0}")#text(", and ")#mi("{c_1^* \\geq \\ldots \\geq c^*_n \\geq 0}")#text(" is the decreasing rearrangement of ")#mi("{c_1,\\ldots,c_n}")#text(". (")#emph[#text("Hint:")]#text(" express ")#mi("{c_i}")#text(" as the integral of ")#mi("{{\\bf I}(c_i \\geq \\lambda)}")#text(" as ")#mi("{\\lambda}")#text(" runs from ")#mi("{0}")#text(" to infinity. For each fixed ")#mi("{\\lambda}")#text(", apply ")#link(<tao-4501770eb1d4352d2ccf>)[#text("(12)")]#text(".) Combine this with Hölder’s inequality to conclude the ")#emph[#mi("{p}")#text("-Weilandt-Hoffman inequality")]#text(" ")#metadata(none) <tao-0636d62ae40e70578647>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\left\\| (\\lambda_i(A+B) - \\lambda_i(A))_{i=1}^n \\right\\|_{\\ell^p_n} \\leq \\left\\|B\\right\\|_{S^p}", block: true)]]

#text("for any ")#mi("{1 \\leq p \\leq \\infty}")#text(", where")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (a_i)_{i=1}^n \\right\\|_{\\ell^p_n} := (\\sum_{i=1}^n \\left|a_i\\right|^p)^{1/p}", block: true)]]

#text("is the usual ")#mi("{\\ell^p}")#text(" norm (with the usual convention that ")#tao-math("{\\left\\| (a_i)_{i=1}^n \\right\\|_{\\ell^\\infty_n} := \\sup_{1 \\leq i \\leq p} \\left|a_i\\right|}", block: false)#text("), and ")#metadata(none) <tao-a567e9516d3666fde097>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left\\|B\\right\\|_{S^p} := \\left\\| (\\lambda_i(B))_{i=1}^n \\right\\|_{\\ell^p_n}", block: true)]]

#text("is the ")#link("http://en.wikipedia.org/wiki/Schatten_norm")[#mi("{p}")#text("-Schatten norm")]#text(" of ")#mi("{B}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Show that the ")#mi("{p}")#text("-Schatten norms are indeed a norm on the space of Hermitian matrices for every ")#mi("{1 \\leq p \\leq \\infty}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Show that for any ")#mi("{1 \\leq p \\leq \\infty}")#text(" and any Hermitian matrix ")#mi("{A = (a_{ij})_{1 \\leq i,j \\leq n}}")#text(", one has ")#metadata(none) <tao-ab2bde1ce2ab4a8483d4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\left\\| (a_{ii})_{i=1}^n \\right\\|_{\\ell^p_n} \\leq \\left\\| A \\right\\|_{S^p}.", block: true)]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Establish the Hölder inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|\\text{tr}(AB)\\right| \\leq \\left\\|A\\right\\|_{S^p} \\left\\|B\\right\\|_{S^{p^{\\prime}}}", block: true)]]

#text("whenever ")#mi("{1 \\leq p,p^{\\prime} \\leq \\infty}")#text(" with ")#mi("{1/p + 1/p^{\\prime} = 1}")#text(", and ")#mi("{A, B}")#text(" are ")#mi("{n \\times n}")#text(" Hermitian matrices. (")#emph[#text("Hint:")]#text(" Diagonalise one of the matrices and use the preceding exercise.)")
]

#text("The most important ")#mi("{p}")#text("-Schatten norms are the ")#emph[#mi("{\\infty}")#text("-Schatten norm")]#text(" ")#tao-math("{\\left\\|A\\right\\|_{S^\\infty} = \\left\\|A\\right\\|_{op}}", block: false)#text(", which is just the operator norm, and the ")#mi("{2}")#text("-Schatten norm ")#tao-math("{\\left\\|A\\right\\|_{S^2} = (\\sum_{i=1}^n \\lambda_i(A)^2)^{1/2}}", block: false)#text(", which is also the ")#link("http://en.wikipedia.org/wiki/Frobenius_norm#Frobenius_norm")[#text("Frobenius norm")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Hilbert%E2%80%93Schmidt_operator")[#text("Hilbert-Schmidt norm")]#text(")")

#align(center)[#tao-fit-display[#tao-math("\\left\\|A\\right\\|_{S^2} = \\left\\|A\\right\\|_F := \\text{tr}(AA^*)^{1/2} = (\\sum_{i=1}^n \\sum_{j=1}^n \\left|a_{ij}\\right|^2)^{1/2}", block: true)]]

#text("where ")#mi("{a_{ij}}")#text(" are the coeffiicents of ")#mi("{A}")#text(". (The ")#mi("{1}")#text("-Schatten norm ")#mi("{S^1}")#text(", also known as the ")#emph[#text("nuclear norm")]#text(" or ")#link("http://en.wikipedia.org/wiki/Trace_class")[#text("trace class norm")]#text(", is important in a number of applications, such as matrix completion, but will not be used often in this course.) Thus we see that the ")#mi("{p=2}")#text(" case of the Weilandt-Hoffman inequality can be written as ")#metadata(none) <tao-1ed2b38c11c70aa02ade>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\sum_{i=1}^n \\left|\\lambda_i(A+B) - \\lambda_i(A)\\right|^2 \\leq \\left\\|B\\right\\|_F^2.", block: true)]]

#text("We will give an alternate proof of this inequality, based on eigenvalue deformation, in the next section.")

#heading(level: 1)[#strong[#text(" — 4. Eigenvalue deformation — ")]]

#text("From the Weyl inequality ")#link(<tao-de943f7bdb6ccfcaf82b>)[#text("(13)")]#text(", we know that the eigenvalue maps ")#mi("{A \\mapsto \\lambda_i(A)}")#text(" are Lipschitz continuous on Hermitian matrices (and thus also on real symmetric matrices). It turns out that we can obtain better regularity, provided that we avoid repeated eigenvalues. Fortunately, repeated eigenvalues are rare:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Dimension count)")]#text(" ")#metadata(none) <tao-fe80fbb4a1a17773b6d8>#text(" Suppose that ")#mi("{n \\geq 2}")#text(". Show that the space of Hermitian matrices with at least one repeated eigenvalue has codimension ")#mi("{3}")#text(" in the space of all Hermitian matrices, and the space of real symmetric matrices with at least one repeated eigenvalue has codimension ")#mi("{2}")#text(" in the space of all real symmetric matrices. (When ")#mi("{n=1}")#text(", repeated eigenvalues of course do not occur.)")
]

#text("Let us say that a Hermitian matrix has ")#emph[#text("simple spectrum")]#text(" if it has no repeated eigenvalues. We thus see from the above exercise and ")#link(<tao-de943f7bdb6ccfcaf82b>)[#text("(13)")]#text(" that the set of Hermitian matrices with simple spectrum forms an open dense set in the space of all Hermitian matrices, and similarly for real symmetric matrices; thus simple spectrum is the ")#emph[#text("generic")]#text(" behaviour of such matrices. Indeed, the unexpectedly high codimension of the non-simple matrices (naively, one would expect a codimension ")#mi("{1}")#text(" set for a collision between, say, ")#mi("{\\lambda_i(A)}")#text(" and ")#mi("{\\lambda_{i+1}(A)}")#text(") suggests a ")#emph[#text("repulsion")]#text(" phenomenon: because it is unexpectedly rare for eigenvalues to be equal, there must be some “force” that “repels” eigenvalues of Hermitian (and to a lesser extent, real symmetric) matrices from getting too close to each other. We now develop some machinery to make this more precise.")

#text("We first observe that when ")#mi("{A}")#text(" has simple spectrum, the zeroes of the characteristic polynomial ")#mi("{\\lambda \\mapsto \\det(A - \\lambda I)}")#text(" are simple (i.e. the polynomial has nonzero derivartive at those zeroes). From this and the inverse function theorem, we see that each of the eigenvalue maps ")#mi("{A \\mapsto \\lambda_i(A)}")#text(" are smooth on the region where ")#mi("{A}")#text(" has simple spectrum. Because the eigenvectors ")#mi("{u_i(A)}")#text(" are determined (up to phase) by the equations ")#mi("{(A - \\lambda_i(A) I) u_i(A) = 0}")#text(" and ")#mi("{u_i(A)^* u_i(A) = 1}")#text(", another application of the inverse function theorem tells us that we can (locally) select the maps ")#mi("{A \\mapsto u_i(A)}")#text(" to also be smooth. (There may be topological obstructions to smoothly selecting these vectors globally, but this will not concern us here as we will be performing a local analysis only. In later notes, we will in fact not work with the ")#mi("{u_i(A)}")#text(" at all due to their phase ambiguity, and work instead with the ")#emph[#text("spectral projections")]#text(" ")#mi("{P_i(A) := u_i(A) u_i(A)^*}")#text(", which do not have this ambiguity.)")

#text("Now suppose that ")#mi("{A = A(t)}")#text(" depends smoothly on a time variable ")#mi("{t}")#text(", so that (when ")#mi("{A}")#text(" has simple spectrum) the eigenvalues ")#mi("{\\lambda_i(t) = \\lambda_i(A(t))}")#text(" and eigenvectors ")#mi("{u_i(t) = u_i(A(t))}")#text(" also depend smoothly on ")#mi("{t}")#text(". We can then differentiate the equations ")#metadata(none) <tao-94419b99b12c11133a4d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("A u_i = \\lambda_i u_i")]]

#text("and ")#metadata(none) <tao-21f069fe587d339138ae>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("u_i^* u_i = 1")]]

#text("to obtain various equations of motion for ")#mi("{\\lambda_i}")#text(" and ")#mi("{u_i}")#text(" in terms of the derivatives of ")#mi("{A}")#text(".")

#text("Let’s see how this works. Taking first derivatives of ")#link(<tao-94419b99b12c11133a4d>)[#text("(18)")]#text(", ")#link(<tao-21f069fe587d339138ae>)[#text("(19)")]#text(" using the product rule, we obtain ")#metadata(none) <tao-4f27c06b2838a854089e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\dot A u_i + A \\dot u_i = \\dot \\lambda_i u_i + \\lambda_i \\dot u_i")]]

#text("and ")#metadata(none) <tao-ced1f63d2b48c79176a9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\dot u_i^* u_i + u_i^* \\dot u_i = 0.")]]

#text("The equation ")#link(<tao-ced1f63d2b48c79176a9>)[#text("(21)")]#text(" simplifies to ")#mi("{{\\mathrm Re} \\dot u_i^* u_i = 0}")#text(", thus ")#mi("{\\dot u_i}")#text(" is orthogonal to ")#mi("{u_i}")#text(". Taking (real) inner products of ")#link(<tao-4f27c06b2838a854089e>)[#text("(20)")]#text(" with ")#mi("{u_i}")#text(", we conclude the ")#emph[#text("Hadamard first variation formula")]#text(" ")#metadata(none) <tao-c048264deeca0c17ac1d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\dot \\lambda_i = u_i^* \\dot A u_i.")]]

#text("This can already be used to give alternate proofs of various eigenvalue identities. For instance, If we apply this to ")#mi("{A(t) := A + tB}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} \\lambda_i(A+tB) = u_i(A+tB)^* B u_i(A+tB)")]]

#text("whenever ")#mi("{A+tB}")#text(" has simple spectrum. The right-hand side can be bounded in magnitude by ")#tao-math("{\\left\\|B\\right\\|_{op}}", block: false)#text(", and so we see that the map ")#mi("{t \\mapsto \\lambda_i(A+tB)}")#text(" is Lipschitz with norm ")#tao-math("{\\left\\|B\\right\\|_{op}}", block: false)#text(" whenever ")#mi("{A+tB}")#text(" has simple spectrum, which happens for generic ")#mi("{A, B}")#text(" (and all ")#mi("{t}")#text(") by Exercise ")#link(<tao-fe80fbb4a1a17773b6d8>)[#text("10")]#text(". By the fundamental theorem of calculus, we thus conclude ")#link(<tao-de943f7bdb6ccfcaf82b>)[#text("(13)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Use a similar argument to the one above to establish ")#link(<tao-1ed2b38c11c70aa02ade>)[#text("(17)")]#text(" without using minimax formulae or Lidskii’s inequality.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" Use a similar argument to the one above to deduce Lidskii’s inequality ")#link(<tao-4501770eb1d4352d2ccf>)[#text("(12)")]#text(" from Proposition ")#link(<tao-9834a14ab9bcaa0f6a8d>)[#text("3")]#text(" rather than Exercise ")#link(<tao-009988370651671c5738>)[#text("3")]#text(".")
]

#text("One can also compute the second derivative of eigenvalues:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Suppose that ")#mi("{A = A(t)}")#text(" depends smoothly on ")#mi("{t}")#text(". By differentiating ")#link(<tao-4f27c06b2838a854089e>)[#text("(20)")]#text(", ")#link(<tao-ced1f63d2b48c79176a9>)[#text("(21)")]#text(" twice, establish the ")#emph[#text("Hadamard second variation formula")]#text(" ")#metadata(none) <tao-09f943873e673ec8cbd2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#tao-math("\\frac{d^2}{dt^2} \\lambda_k = u_k^* \\ddot A u_k + 2 \\sum_{j \\neq k} \\frac{ \\left|u_j^* \\dot A u_k\\right|^2 }{\\lambda_k - \\lambda_j}", block: true)]]

#text("whenever ")#mi("{A}")#text(" has simple spectrum and ")#mi("{1 \\leq k \\leq n}")#text(".")

#text("If one interprets the second derivative of the eigenvalues as being proportional to a “force” on those eigenvalues (in analogy with ")#link("http://en.wikipedia.org/wiki/Newton%27s_laws_of_motion")[#text("Newton’s second law")]#text("), ")#link(<tao-09f943873e673ec8cbd2>)[#text("(23)")]#text(" is asserting that each eigenvalue ")#mi("{\\lambda_j}")#text(" “repels” the other eigenvalues ")#mi("{\\lambda_k}")#text(" by exerting a force that is inversely proportional to their separation (and also proportional to the square of the matrix coefficient of ")#mi("{\\dot A}")#text(" in the eigenbasis). See ")#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/")[#text("this earlier blog post")]#text(" for more discussion.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" In the proof of the ")#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/")[#text("four moment theorem of Van Vu and myself")]#text(", which we will discuss in a subsequent lecture, we will also need the variation formulae for the third, fourth, and fifth derivatives of the eigenvalues (the first four derivatives match up with the four moments mentioned in the theorem, and the fifth derivative is needed to control error terms). Fortunately, we do not need the precise formulae for these derivatives (which, as one can imagine, are quite complicated), but only their general form, and in particular an upper bound for these derivatives in terms of more easily computable quantities.")
]

#heading(level: 1)[#strong[#text(" — 5. Minors — ")]]

#text("In the previous sections, we perturbed ")#mi("{n \\times n}")#text(" Hermitian matrices ")#mi("{A = A_n}")#text(" by adding a (small) ")#mi("{n \\times n}")#text(" Hermitian correction matrix ")#mi("{B}")#text(" to them to form a new ")#mi("{n \\times n}")#text(" Hermitian matrix ")#mi("{A+B}")#text(". Another important way to perturb a matrix is to pass to a ")#link("http://en.wikipedia.org/wiki/Minor_(linear_algebra)")[#text("principal minor")]#text(", for instance to the top left ")#mi("{n-1 \\times n-1}")#text(" minor ")#mi("{A_{n-1}}")#text(" of ")#mi("{A_n}")#text(". There is an important relationship between the eigenvalues of the two matrices:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14 (Cauchy interlacing inequalities)")]#text(" For any ")#mi("{n \\times n}")#text(" Hermitian matrix ")#mi("{A_n}")#text(" with top left ")#mi("{n-1 \\times n-1}")#text(" minor ")#mi("{A_{n-1}}")#text(", then ")#metadata(none) <tao-a3d984fddf2b98a29947>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\lambda_{i+1}(A_n) \\leq \\lambda_i(A_{n-1}) \\leq \\lambda_i(A_n)")]]

#text("for all ")#mi("{1 \\leq i \\leq n}")#text(". (")#emph[#text("Hint:")]#text(" use the Courant-Fischer min-max theorem, Theorem ")#link(<tao-7f72a2bdfa8c5254d95e>)[#text("2")]#text(".) Show furthermore that the space of ")#mi("{A_n}")#text(" for which equality holds in one of the inequalities in ")#link(<tao-a3d984fddf2b98a29947>)[#text("(24)")]#text(" has codimension ")#mi("{2}")#text(" (for Hermitian matrices) or ")#mi("{1}")#text(" (for real symmetric matrices).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" If one takes successive minors ")#mi("{A_{n-1}, A_{n-2},\\ldots,A_1}")#text(" of an ")#mi("{n \\times n}")#text(" Hermitian matrix ")#mi("{A_n}")#text(", and computes their spectra, then ")#link(<tao-a3d984fddf2b98a29947>)[#text("(24)")]#text(" shows that this triangular array of numbers forms a pattern known as a ")#emph[#text("Gelfand-Tsetlin pattern")]#text(". These patterns are discussed a little more in ")#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/")[#text("this blog post")]#text(".")
]

#text("One can obtain a more precise formula for the eigenvalues of ")#mi("{A_n}")#text(" in terms of those for ")#mi("{A_{n-1}}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Eigenvalue equation)")]#text(" Let ")#mi("{A_n}")#text(" be an ")#mi("{n \\times n}")#text(" Hermitian matrix with top left ")#mi("{n-1 \\times n-1}")#text(" minor ")#mi("{A_{n-1}}")#text(". Suppose that ")#mi("{\\lambda}")#text(" is an eigenvalue of ")#mi("{A_n}")#text(" distinct from all the eigenvalues of ")#mi("{A_{n-1}}")#text(" (and thus simple, by ")#link(<tao-a3d984fddf2b98a29947>)[#text("(24)")]#text("). Show that ")#metadata(none) <tao-17e1a81f4426deb03e26>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#tao-math("\\sum_{j=1}^{n-1} \\frac{ \\left| u_j(A_{n-1})^* X \\right|^2 }{\\lambda_j(A_{n-1}) - \\lambda} = a_{nn} - \\lambda", block: true)]]

#text("where ")#mi("{a_{nn}}")#text(" is the bottom right entry of ")#mi("{A}")#text(", and ")#mi("{X = (a_{nj})_{j=1}^{n-1} \\in {\\mathbb C}^{n-1}}")#text(" is the right column of ")#mi("{A}")#text(" (minus the bottom entry). (")#emph[#text("Hint:")]#text(" Expand out the eigenvalue equation ")#mi("{A_n u = \\lambda u}")#text(" into the ")#mi("{{\\mathbb C}^{n-1}}")#text(" and ")#mi("{{\\mathbb C}}")#text(" components.) Note the similarities between ")#link(<tao-17e1a81f4426deb03e26>)[#text("(25)")]#text(" and ")#link(<tao-09f943873e673ec8cbd2>)[#text("(23)")]#text(".")
]

#text("Observe that the function ")#tao-math("{\\lambda \\rightarrow \\sum_{j=1}^{n-1} \\frac{ \\left| u_j(A_{n-1})^* X \\right|^2 }{\\lambda_j(A_{n-1}) - \\lambda}}", block: false)#text(" is a rational function of ")#mi("{\\lambda}")#text(" which is increasing away from the eigenvalues of ")#mi("{A_{n-1}}")#text(", where it has a pole (except in the rare case when the inner product ")#mi("{u_{j-1}(A_{n-1})^* X}")#text(" vanishes, in which case it can have a removable singularity). By graphing this function one can see that the interlacing formula ")#link(<tao-a3d984fddf2b98a29947>)[#text("(24)")]#text(" can also be interpreted as a manifestation of the intermediate value theorem.")

#text("The identity ")#link(<tao-17e1a81f4426deb03e26>)[#text("(25)")]#text(" suggests that under typical circumstances, an eigenvalue ")#mi("{\\lambda}")#text(" of ")#mi("{A_n}")#text(" can only get close to an eigenvalue ")#mi("{\\lambda_j(A_{n-1})}")#text(" if the associated inner product ")#mi("{u_j(A_{n-1})^* X}")#text(" is small. This type of observation is useful to achieve ")#emph[#text("eigenvalue repulsion")]#text(" – to show that it is unlikely that the gap between two adjacent eigenvalues is small. We shall see examples of this in later notes.")

#heading(level: 1)[#strong[#text(" — 6. Singular values — ")]]

#text("The theory of eigenvalues of ")#mi("{n \\times n}")#text(" Hermitian matrices has an analogue in the theory of singular values of ")#mi("{p \\times n}")#text(" non-Hermitian matrices. We first begin with the counterpart to the spectral theorem, namely the ")#link("http://en.wikipedia.org/wiki/Singular_value_decomposition")[#text("singular value decomposition")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Singular value decomposition)")]#text(" Let ")#mi("{0 \\leq p \\leq n}")#text(", and let ")#mi("{A}")#text(" be a linear transformation from an ")#mi("{n}")#text("-dimensional complex Hilbert space ")#mi("{U}")#text(" to a ")#mi("{p}")#text("-dimensional complex Hilbert space ")#mi("{V}")#text(". (In particular, ")#mi("{A}")#text(" could be an ")#mi("{p \\times n}")#text(" matrix with complex entries, viewed as a linear transformation from ")#mi("{{\\mathbb C}^n}")#text(" to ")#mi("{{\\mathbb C}^p}")#text(".) Then there exist non-negative real numbers")

#align(center)[#tao-fit-display[#mitex("\\sigma_1(A) \\geq \\ldots \\geq \\sigma_p(A) \\geq 0")]]

#text("(known as the ")#emph[#text("singular values")]#text(" of ")#mi("{A}")#text(") and orthonormal sets ")#mi("{u_1(A),\\ldots,u_p(A) \\in U}")#text(" and ")#mi("{v_1(A),\\ldots,v_p(A) \\in V}")#text(" (known as ")#emph[#text("singular vectors")]#text(" of ")#mi("{A}")#text("), such that")

#align(center)[#tao-fit-display[#mitex("A u_j = \\sigma_j v_j; \\quad A^* v_j = \\sigma_j u_j")]]

#text("for all ")#mi("{1 \\leq j \\leq p}")#text(", where we abbreviate ")#mi("{u_j = u_j(A)}")#text(", etc.")

#text("Furthermore, ")#mi("{Au=0}")#text(" whenever ")#mi("{u}")#text(" is orthogonal to all of the ")#mi("{u_1(A),\\ldots,u_p(A)}")#text(".")
]

#text("We adopt the convention that ")#mi("{\\sigma_i(A)=0}")#text(" for ")#mi("{i>p}")#text(". The above theorem only applies to matrices with at least as many rows as columns, but one can also extend the definition to matrices with more columns than rows by adopting the convention ")#mi("{\\sigma_i(A^*) := \\sigma_i(A)}")#text(" (it is easy to check that this extension is consistent on square matrices). All of the results below extend (with minor modifications) to the case when there are more columns than rows, but we have not displayed those extensions here in order to simplify the notation.")

#emph[#text("Proof:")]#text(" We induct on ")#mi("{p}")#text(". The claim is vacuous for ")#mi("{p=0}")#text(", so suppose that ")#mi("{p \\geq 1}")#text(" and that the claim has already been proven for ")#mi("{p-1}")#text(".")

#text("We follow a similar strategy to the proof of Theorem ")#link(<tao-d4f02eaafd1a9e9de7d1>)[#text("1")]#text(". We may assume that ")#mi("{A}")#text(" is not identically zero, as the claim is obvious otherwise. The function ")#tao-math("{u \\mapsto \\left\\|Au\\right\\|^2}", block: false)#text(" is continuous on the unit sphere of ")#mi("{U}")#text(", so there exists a unit vector ")#mi("{u_1}")#text(" which maximises this quantity. If we set ")#tao-math("{\\sigma_1 := \\left\\|Au_1\\right\\| > 0}", block: false)#text(", one easily verifies that ")#mi("{u_1}")#text(" is a critical point of the map ")#tao-math("{u \\mapsto \\left\\|Au\\right\\|^2 - \\sigma_1^2 \\left\\|u\\right\\|^2}", block: false)#text(", which then implies that ")#mi("{A^* A u_1 = \\sigma_1^2 u_1}")#text(". Thus, if we set ")#mi("{v_1 := A u_1 / \\sigma_1}")#text(", then ")#mi("{A u_1 = \\sigma_1 v_1}")#text(" and ")#mi("{A^* v_1 = \\sigma_1 u_1}")#text(". This implies that ")#mi("{A}")#text(" maps the orthogonal complement ")#mi("{u_1^\\perp}")#text(" of ")#mi("{u_1}")#text(" in ")#mi("{U}")#text(" to the orthogonal complement ")#mi("{v_1^\\perp}")#text(" of ")#mi("{v_1}")#text(" in ")#mi("{V}")#text(". By induction hypothesis, the restriction of ")#mi("{A}")#text(" to ")#mi("{u_1^\\perp}")#text(" (and ")#mi("{v_1^\\perp}")#text(") then admits a singular value decomposition with singular values ")#mi("{\\sigma_2 \\geq \\ldots \\geq \\sigma_p \\geq 0}")#text(" and singular vectors ")#mi("{u_2,\\ldots,u_p \\in u_1^\\perp}")#text(", ")#mi("{v_2,\\ldots,v_p \\in v_1^\\perp}")#text(" with the stated properties. By construction we see that ")#mi("{\\sigma_2,\\ldots,\\sigma_p}")#text(" are less than or equal to ")#mi("{\\sigma_1}")#text(". If we now adjoin ")#mi("{\\sigma_1,u_1,v_1}")#text(" to the other singular values and vectors we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Show that the singular values ")#mi("{\\sigma_1(A) \\geq \\ldots \\geq \\sigma_p(A) \\geq 0}")#text(" of a ")#mi("{p \\times n}")#text(" matrix ")#mi("{A}")#text(" are unique. If we have ")#mi("{\\sigma_1(A) > \\ldots > \\sigma_p(A) > 0}")#text(", show that the singular vectors are unique up to rotation by a complex phase.")
]

#text("By construction (and the above uniqueness claim) we see that ")#mi("{\\sigma_i(UAV) = \\sigma_i(A)}")#text(" whenever ")#mi("{A}")#text(" is a ")#mi("{p \\times n}")#text(" matrix, ")#mi("{U}")#text(" is a unitary ")#mi("{p \\times p}")#text(" matrix, and ")#mi("{V}")#text(" is a unitary ")#mi("{n \\times n}")#text(" matrix. Thus the singular spectrum of a matrix is invariant under left and right unitary transformations.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" ")#metadata(none) <tao-f86873875275a1bc55ac>#text(" If ")#mi("{A}")#text(" is a ")#mi("{p \\times n}")#text(" complex matrix for some ")#mi("{1 \\leq p \\leq n}")#text(", show that the augmented matrix")

#align(center)[#tao-fit-display[#mitex("\\tilde A := \\begin{pmatrix} 0 & A \\\\ A^* & 0 \\end{pmatrix}")]]

#text("is a ")#mi("{p+n \\times p+n}")#text(" Hermitian matrix whose eigenvalues consist of ")#mi("{\\pm \\sigma_1(A),\\ldots,\\pm \\sigma_p(A)}")#text(", together with ")#mi("{n-p}")#text(" copies of the eigenvalue zero. (This generalises Exercise 16 from ")#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")[#text("Notes 3")]#text(".) What is the relationship between the singular vectors of ")#mi("{A}")#text(" and the eigenvectors of ")#mi("{\\tilde A}")#text("?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" If ")#mi("{A}")#text(" is an ")#mi("{n \\times n}")#text(" Hermitian matrix, show that the singular values ")#mi("{\\sigma_1(A),\\ldots,\\sigma_n(A)}")#text(" of ")#mi("{A}")#text(" are simply the absolute values ")#tao-math("{\\left|\\lambda_1(A)\\right|,\\ldots,\\left|\\lambda_n(A)\\right|}", block: false)#text(" of ")#mi("{A}")#text(", arranged in descending order. Show that the same claim also holds when ")#mi("{A}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Normal_matrix")[#text("normal matrix")]#text(". What is the relationship between the singular vectors and eigenvectors of ")#mi("{A}")#text("?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" When ")#mi("{A}")#text(" is not normal, the relationship between eigenvalues and singular values is more subtle. We will discuss this point in later notes.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" If ")#mi("{A}")#text(" is a ")#mi("{p \\times n}")#text(" complex matrix for some ")#mi("{1 \\leq p \\leq n}")#text(", show that ")#mi("{AA^*}")#text(" has eigenvalues ")#mi("{\\sigma_1(A)^2,\\ldots,\\sigma_p(A)^2}")#text(", and ")#mi("{A^* A}")#text(" has eigenvalues ")#mi("{\\sigma_1(A)^2,\\ldots,\\sigma_p(A)^2}")#text(" together with ")#mi("{n-p}")#text(" copies of the eigenvalue zero. Based on this observation, give an alternate proof of the singular value decomposition theorem using the spectral theorem for (positive semi-definite) Hermitian matrices.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Show that the rank of a ")#mi("{p \\times n}")#text(" matrix is equal to the number of non-zero singular values.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" Let ")#mi("{A}")#text(" be a ")#mi("{p \\times n}")#text(" complex matrix for some ")#mi("{1 \\leq p \\leq n}")#text(". Establish the Courant-Fischer min-max formula ")#metadata(none) <tao-38de90475bb334fb3dea>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#tao-math("\\sigma_i(A) = \\sup_{\\text{dim}(V)=i} \\inf_{v \\in V; \\left|v\\right|=1} \\left|Av\\right|", block: true)]]

#text("for all ")#mi("{1 \\leq i \\leq p}")#text(", where the supremum ranges over all subspaces of ")#mi("{{\\mathbb C}^n}")#text(" of dimension ")#mi("{i}")#text(".")
]

#text("One can use the above exercises to deduce many inequalities about singular values from analogous ones about eigenvalues. We give some examples below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Let ")#mi("{A, B}")#text(" be ")#mi("{p \\times n}")#text(" complex matrices for some ")#mi("{1 \\leq p \\leq n}")#text(".")

#list(
[#text("(i) Establish the Weyl inequality ")#mi("{\\sigma_{i+j-1}(A+B) \\leq \\sigma_i(A) + \\sigma_j(B)}")#text(" whenever ")#mi("{1 \\leq i,j,i+j-1 \\leq p}")#text(".")],
[#text("(ii) Establish the Lidskii inequality")

#tao-aligned(keep: true)[


#tao-math("\\sigma_{i_1}(A+B)+\\ldots+\\sigma_{i_k}(A+B)  & \\leq \\sigma_{i_1}(A)+\\ldots+\\sigma_{i_k}(A)", block: true)



#tao-math(" & +\\sigma_1(B)+\\ldots+\\sigma_k(B)", block: true)
]

#text("whenever ")#mi("{1 \\leq i_1 < \\ldots < i_k \\leq p}")#text(".")],
[#text("(iii) Show that for any ")#mi("{1 \\leq k \\leq p}")#text(", the map ")#mi("{A \\mapsto \\sigma_1(A)+\\ldots+\\sigma_k(A)}")#text(" defines a norm on the space ")#mi("{{\\mathbb C}^{p \\times n}}")#text(" of complex ")#mi("{p \\times n}")#text(" matrices (this norm is known as the ")#mi("{k^{th}}")#text(" ")#emph[#text("Ky Fan norm")]#text(").")],
[#text("(iv) Establish the Weyl inequality ")#tao-math("{\\left|\\sigma_i(A+B) - \\sigma_i(A)\\right| \\leq \\left\\| B \\right\\|_{op}}", block: false)#text(" for all ")#mi("{1 \\leq i \\leq p}")#text(".")],
[#text("(v) More generally, establish the ")#mi("{q}")#text("-Weilandt-Hoffman inequality ")#tao-math("{\\left\\| (\\sigma_i(A+B)-\\sigma_i(A))_{1 \\leq i \\leq p} \\right\\|_{\\ell^q_p} \\leq \\left\\|B\\right\\|_{S^q}}", block: false)#text(" for any ")#mi("{1 \\leq q \\leq \\infty}")#text(", where ")#tao-math("{\\left\\|B\\right\\|_{S^q} := \\left\\| (\\sigma_i(B))_{1 \\leq i \\leq p} \\right\\|_{\\ell^q_p}}", block: false)#text(" is the ")#mi("{q}")#text("-Schatten norm of ")#mi("{B}")#text(". (Note that this is consistent with the previous definition of the Schatten norms.)")],
[#text("(vi) Show that the ")#mi("{q}")#text("-Schatten norm is indeed a norm on ")#mi("{{\\mathbb C}^{p \\times n}}")#text(" for any ")#mi("{1 \\leq q \\leq \\infty}")#text(".")],
[#text("(vii) If ")#mi("{A^{\\prime}}")#text(" is formed by removing one row from ")#mi("{A}")#text(", show that ")#mi("{\\sigma_{i+1}(A) \\leq \\sigma_i(A^{\\prime}) \\leq \\sigma_i(A)}")#text(" for all ")#mi("{1 \\leq i < p}")#text(".")],
[#text("(viii) If ")#mi("{p<n}")#text(" and ")#mi("{A^{\\prime}}")#text(" is formed by removing one column from ")#mi("{A}")#text(", show that ")#mi("{\\sigma_{i+1}(A) \\leq \\sigma_i(A^{\\prime}) \\leq \\sigma_i(A)}")#text(" for all ")#mi("{1 \\leq i < p}")#text(" and ")#mi("{\\sigma_p(A^{\\prime}) \\leq \\sigma_p(A)}")#text(". What changes when ")#mi("{p=n}")#text("?")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" Let ")#mi("{A}")#text(" be a ")#mi("{p \\times n}")#text(" complex matrix for some ")#mi("{1 \\leq p \\leq n}")#text(". Observe that the linear transformation ")#mi("{A: {\\mathbb C}^n \\rightarrow {\\mathbb C}^p}")#text(" naturally induces a linear transformation ")#mi("{A^{\\wedge k}: \\bigwedge^k {\\mathbb C}^n \\rightarrow \\bigwedge^k {\\mathbb C}^p}")#text(" from ")#mi("{k}")#text("-forms on ")#mi("{{\\mathbb C}^n}")#text(" to ")#mi("{k}")#text("-forms on ")#mi("{{\\mathbb C}^p}")#text(". We give ")#mi("{\\bigwedge^k {\\mathbb C}^n}")#text(" the structure of a Hilbert space by declaring the basic forms ")#mi("{e_{i_1} \\wedge \\ldots \\wedge e_{i_k}}")#text(" for ")#mi("{1 \\leq i_1 < \\ldots < i_k \\leq n}")#text(" to be orthonormal.")

#text("For any ")#mi("{1 \\leq k \\leq p}")#text(", show that the operator norm of ")#mi("{A^{\\wedge k}}")#text(" is equal to ")#mi("{\\sigma_1(A) \\ldots \\sigma_k(A)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" Let ")#mi("{A}")#text(" be a ")#mi("{p \\times n}")#text(" matrix for some ")#mi("{1 \\leq p \\leq n}")#text(", let ")#mi("{B}")#text(" be a ")#mi("{r \\times p}")#text(" matrix, and let ")#mi("{C}")#text(" be a ")#mi("{n \\times s}")#text(" matrix for some ")#mi("{r, s \\geq 1}")#text(".")

#text("Show that ")#tao-math("{\\sigma_i(BA) \\leq \\left\\|B\\right\\|_{op} \\sigma_i(A)}", block: false)#text(" and ")#tao-math("{\\sigma_i(AC) \\leq \\sigma_i(A) \\left\\|C\\right\\|_{op}}", block: false)#text(" for any ")#mi("{1 \\leq i \\leq p}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" Let ")#mi("{A = (a_{ij})_{1 \\leq i \\leq p; 1 \\leq j \\leq n}}")#text(" be a ")#mi("{p \\times n}")#text(" matrix for some ")#mi("{1 \\leq p \\leq n}")#text(", let ")#mi("{i_1,\\ldots,i_k \\in \\{1,\\ldots,p\\}}")#text(" be distinct, and let ")#mi("{j_1,\\ldots,j_k \\in \\{1,\\ldots,n\\}}")#text(" be distinct. Show that")

#align(center)[#tao-fit-display[#mitex("a_{i_1 j_1} + \\ldots + a_{i_k j_k} \\leq \\sigma_1(A) + \\ldots + \\sigma_k(A).")]]

#text("Using this, show that if ")#mi("{j_1,\\ldots,j_p \\in \\{1,\\ldots,n\\}}")#text(" are distinct, then")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (a_{i j_i})_{i=1}^p \\right\\|_{\\ell^q_p} \\leq \\left\\|A\\right\\|_{S^q}", block: true)]]

#text("for every ")#mi("{1 \\leq q \\leq \\infty}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" Establish the Hölder inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|\\text{tr}(A B^*)\\right| \\leq \\left\\|A\\right\\|_{S^q} \\left\\|B\\right\\|_{S^{q^{\\prime}}}", block: true)]]

#text("whenever ")#mi("{A, B}")#text(" are ")#mi("{p \\times n}")#text(" complex matrices and ")#mi("{1 \\leq q,q^{\\prime} \\leq \\infty}")#text(" are such that ")#mi("{1/q+1/q^{\\prime}=1}")#text(".")
]

#emph[#text("Acknowledgments:")]#text(" Thanks to Allen Knutson for corrections.")

#heading(level: 1)[#text("Comments (73)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-43227")[#strong[#text("Marius")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2010")])]

#text("Hi Terry,")

#text("Linear algebra is indeed fascinating. Maybe the readers of this post may find")#linebreak()#text(" interesting some connections between this subject and quasiconvexity in the")#linebreak()#text(" calculus of variations and nonlinear elasticity:")

#link("http://www.sciencedirect.com/science?_ob=ArticleURL&_udi=B6V0R-4SPSHN6-3&_user=3797462&_rdoc=1&_fmt=&_orig=search&_sort=d&_docanchor=&view=c&_searchStrId=1164865628&_rerunOrigin=google&_acct=C000061416&_version=1&_urlVersion=0&_userid=3797462&md5=d8361adf4dc60e9323fc42216695b1cd")[#text("http://www.sciencedirect.com/science?_ob=ArticleURL&_udi=B6V0R-4SPSHN6-3&_user=3797462&_rdoc=1&_fmt=&_orig=search&_sort=d&_docanchor=&view=c&_searchStrId=1164865628&_rerunOrigin=google&_acct=C000061416&_version=1&_urlVersion=0&_userid=3797462&md5=d8361adf4dc60e9323fc42216695b1cd")]

#text("or")

#link("http://www.imar.ro/~mbuliga/major_stem.pdf")[#text("Click to access major_stem.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-43239")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2010")])]

#text("A potential typo: in eq. 19 (and elsewhere), I thought the norm should be 1, not 0.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/85915019c1b44aeb2a96d6e9939b243794b262872db0c0ee22aa35db6d72da2e-aa43badd7972cfc257f90cba3a2d04e35a2d4b94b95959f30321d59c7baf6341.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kashif")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-43244")[#strong[#text("kashif")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2010")])]

#text("A small typo start of section 4: “From the Weyl inequality (13) we now that…” should be “From the Weyl inequality (13) we know that…”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3b: Brownian motion and Dyson Brownian motion « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-43274")[#strong[#text("254A, Notes 3b: Brownian motion and Dyson Brownian motion « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2010")])]

#text("[…] from the first and second Hadamard variation formulae (see Section 4 of Notes 3a) we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-43293")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2010")])]

#text("Possible typo: Should equation (19) read u_i^* u_i =1 (rather than 0)?")

#emph[#text("[Ack, I thought I corrected that typo already. Corrected again, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 4: The semi-circular law « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-43464")[#strong[#text("254A, Notes 4: The semi-circular law « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2010")])]

#text("[…] first observation is that the Cauchy interlacing law (Exercise 14 from Notes 3a) shows that the ESD of is very stable in . Indeed, we see from the interlacing law […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aab534a8f210b7cf9df4446d8db37ac4c66c9daafd983558d524c978586bd377-240112ddbb705ed9e4227fe8af6e34f039e5a6a1a89b991de7041335fc3c4c1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steven Heilman")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-43653")[#strong[#text("Steven Heilman")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2010")])]

#text("Some pretty pedantic potential corrections:")

#text("1. A basic question in linear algebra …\\lambda_{1}(B),\\ldots,\\lambda_{n}(B)")

#text("2. Eqs. (5),(9),(12): numerical label outside viewing window?")

#text("3. Section 3: Similarly, [for] the Ky Fan…")

#text("4. Section 4: From the Weyl inequality… we [k]now")

#text("5. After Exercise 10: … from the above exercise and [ ] (13)")

#text("6(a). Statement of Theorem 4: A^* v_j=\\sigma_j u_j")

#text("6(b). Proof of Theorem 4: \\sigma_1 :=\\|Au_1 \\|>0 ?")

#text("7. Exercise 23: induces a linear transformation … \\bigwedge^k {\\mathbb C}^p …")

#text("——————-")#linebreak()#text(" [and a few for Notes 3b]")

#text("1. After Remark 6: Applying [Lemma] (5)")

#text("2. … with disjoint increments being jointly indepen[d]ent")

#text("3. Proof of Theorem 6: …G continues [to] have the GUE distribution…")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 6: Gaussian ensembles « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-43719")[#strong[#text("254A, Notes 6: Gaussian ensembles « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2010")])]

#text("[…] is simple. Since almost all Hermitian matrices have simple spectrum (see Exercise 10 of Notes 3a), this gives the full spectral distribution of GUE, except for the issue of the unspecified […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The circular law « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-43884")[#strong[#text("254A, Notes 8: The circular law « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2010")])]

#text("[…] case, where eigenvalue inequalities such as the Weyl inequalities or Hoffman-Wielandt inequalities (Notes 3a) ensure stability of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-44730")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2010")])]

#text("Dear Prof. Tao,")

#text("I had some problems on Ex. 8 and Ex. 13:")

#text("Ex. 8: Could you give some hint on how to prove it? This is most probably very trivial, but I tried it for several hours.")

#text("Ex. 13: I tried to do it according to your hint, but it is hard for me how to make the other eigenvalues ")#mi("\\lambda_j")#text(" involved in the equations of ")#mi("\\ddot{\\lambda}_k")#text(".")

#text("Thank you very much in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-44741")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2010")])]

#text("For Ex 8, apply the method of Ex6 but with (12) replaced by (9).")

#text("For Ex13, a solution can be found at the link provided.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-45051")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2010")])]

#text("Hi,")#linebreak()#text(" I’m a bit confused about your use of the inverse/implicit function theorem to get smoothness of the eigenvectors ")#mi("u_i(A)")#text(" in a neighbourhood of ")#mi("A")#text(". Is there not an issue that the matrix ")#mi("A- \\lambda I")#text(" is singular? Is this where the normalization ")#mi("u_i*u_i =1")#text(" comes in? Thanks for your help.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-45052")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2010")])]

#text("Yes, with the normalisation ")#mi("u_i^* u_i = 1")#text(" (and working in the real symmetric setting for simplicity), the map ")#mi("(\\lambda, u) \\mapsto (A-\\lambda I) u")#text(" is a map from an n-dimensional space ")#mi("{\\bf R} \\times {\\bf S}^{n-1}")#text(" to an n-dimensoinal space ")#mi("{\\bf R}^n")#text(", and one can check by hand that the Jacobian is nondegenerate when the eigenvalues are simple, so the inverse theorem lets one select both ")#mi("\\lambda")#text(" and ")#mi("u")#text(" smoothly in this case. In the complex Hermitian setting it is a bit more complicated, one has to also fix the phase of one of the coordinates of ")#mi("u_i")#text(" (e.g. insisting that the first coordinate is a positive real) to make the dimensions match.")

#text("There is a theorem of Rellich that shows that eigenvectors and eigenvalues can in fact be selected in an analytic fashion even when there are repeated eigenvalues, but only if one abandons the idea of keeping the order of the eigenvalues fixed (i.e. one allows one eigenvalue to overtake another). This is a nontrivial theorem to prove, though.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca27d60b14ab1552432b3b394b0793dda1cc9072469f7026b366ebd3c5ef9d1e-be9580dd03bbc7eb1cc84a7127a3ab233f5f9420dac7ed79753ddacd9d78a5d5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hmobahi")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-426451")[#strong[#text("hmobahi")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2014")])]

#text("Thank you Terrence. This was an extremely helpful comment. Does your comment imply that the function \\sum_{k=1}^n (\\frac{d}{d t} \\lambda_k(t)) f_k(\\lambda_k(t)) is well-defined even when eigenvalues are not simple? Here f_k(x) is any functional that analytically depends on x. I think about this, because the sum kills the dependency of a specific ordering of the eigenvaules.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e14070aaf61842c0399191a9bb95788359f444b55267237580b942af839d574f-5dbdb8aba3911f781f4bd724deb9f69ac307ad1183c7a744942ebc691dd981f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-45233")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2010")])]

#text("Question and a correction.")

#text("In Exercise 5, the second inequality should be A->A+B")#linebreak()#text(" n->A, n->B.")

#text("Question: could a hint be given on how to prove the p-Weilandt-Hoffman inequality using Holder’s inequality? I do not have any clue.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-45248")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2010")])]

#text("Thanks for the correction!")

#text("By Holder’s inequality, the ")#mi("\\ell^p")#text(" norm of a sequence is equal to the largest inner product between that sequence and a sequence of unit ")#mi("\\ell^{p^{\\prime}}")#text(" norm. Now use the fact that the ")#mi("\\ell^{p^{\\prime}}")#text(" norm is invariant with respect to rearrangement.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-126981")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2012")])]

#text("Dear Prof. Tao, to get to get the first inequality in Exercise 6, do you multiply the Lidskii’s inequality by the integral given in the hint, and then how can one get ")#mi("c_{i}^{*}")#text(" or have an rearrangement of ")#mi("c_i")#text(" in front of ")#mi("\\lambda_1(B)")#text("? Thanks for your help!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e14070aaf61842c0399191a9bb95788359f444b55267237580b942af839d574f-5dbdb8aba3911f781f4bd724deb9f69ac307ad1183c7a744942ebc691dd981f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-45257")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2010")])]

#text("Thanks for the reply. But I am still confused about how to get (14) using ONLY the first inequality given in Exercise 6 and the Holder’s inequality.")

#text("TO generate the l_p norm for (\\lamda_{i}(A+B)-\\lamda_{i}(A)) using Holder’s inequality, we need to use a c_i that is negative if (\\lamda_{i}(A+B)-\\lamda_{i}(A)) is negative.")

#text("But this inequality is only about c_i that is nonnegative.")

#text("For example, consider the scalar case when A,B are both scalars, \\lamda_{1}(A+B)-\\lamda_{1}(A) <\\lamda_1(B), does not necessarily mean the absolute value of the former is smaller than the absolute value of the latter.")

#text("Should we use some other conditions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-45261")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2010")])]

#text("Because the trace of A+B is the sum of the trace of A and the trace of B, one can extend the original inequality to the case when the c_i are arbitrary reals.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-126982")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2012")])]

#text("Dear Prof. Tao, to get the first inequality in Exercise 6, do you multiply the Lidskii’s inequality by the integral given in the hint, and then how can one get ")#mi("c_{i}^{*}")#text(" or have an rearrangement of ")#mi("c_i")#text(" in front of ")#mi("\\lambda_i(B)")#text("? Thanks for your help!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Outliers in the spectrum of iid matrices with bounded rank permutations « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-49103")[#strong[#text("Outliers in the spectrum of iid matrices with bounded rank permutations « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2010")])]

#text("[…] were no interlacing inequalities in this case to control bounded rank perturbations (as discussed in this post). However, as it turns out I had arrived at the wrong conclusion, especially in the exterior of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/110c06b430e2eabd2235c78608d675bd3c389f7fe50a85db799102dacb382807-11ccfe2c8d141ef2ca95c2e61dee6027a3fcc6b9bd3d33248b5b8d3a633391ec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of San")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-49698")[#strong[#text("San")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2011")])]

#text("In proposition3, how do you use induction hypothesis, as the hypothesis would be true for the sum of first k eigenvalues.")#linebreak()#text(" Thanks,")#linebreak()#text(" San")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-49712")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2011")])]

#text("When one restricts A to the span of ")#mi("e_2,\\ldots,e_n")#text(" to obtain an n-1-dimensional linear operator, the eigenvalues are now ")#mi("\\lambda_2(A),\\ldots,\\lambda_n(A)")#text(", thanks to the hypothesis that A has the standard eigenbasis (so that it is given by the diagonal matrix with entries ")#mi("\\lambda_1(A),\\ldots,\\lambda_n(A)")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/110c06b430e2eabd2235c78608d675bd3c389f7fe50a85db799102dacb382807-11ccfe2c8d141ef2ca95c2e61dee6027a3fcc6b9bd3d33248b5b8d3a633391ec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of San")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-49717")[#strong[#text("San")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2011")])]

#text("Thanks for the reply. Can I ask where can I find the solution of exercise3.")#linebreak()#text(" Sangeeta")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-518923")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2019")])]

#link("https://math.stackexchange.com/q/2863568/469791")[#text("https://math.stackexchange.com/q/2863568/469791")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sandor")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-49753")[#strong[#text("Sandor")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2011")])]

#text("A direct link to “my survey with Allen Knutson” is ")#link("http://www.ams.org/notices/200102/fea-knutson.pdf")[#text("http://www.ams.org/notices/200102/fea-knutson.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-69386")[#strong[#text("Interlaced eigenvalues « Alasdair's musings")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2011")]

#text("[…] Another proof uses the min-max theorem, of which a full account is given by Terry Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b36399a854b04d57d40986fe573827811e75ae18af69b92b70055447acaba73a-af0c815624b3f9377e8efc057e4d514fb427eeaa9545b408ba11f00998948d3a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kushal")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-128401")[#strong[#text("kushal")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2012")])]

#text("Hi,")#linebreak()#text(" 1.Is there any upper bound for the norm of the inverse of a matrix (i.e. ||inv(A)||), in terms of the norm of the matrix , i.e. ||A|| ?")

#text("NB. There is no restriction on A such as det(A)= ???")#linebreak()#text(" Is there any lower bound for problem-2 that involves only A and not inv(A)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6296244c35449e5beb60594ecdfd1ebc3fb432560d22978bcefdca25b8819f8b-b07b89bd004f2d1d1149a3cac0a3adf5315b72a339ab2df98ab15a7e4c4e0373.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-238293")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2013")])]

#text("Hello Prof. Tao,")

#text("Can these results be applied to matrices of differnt dimensions? For example, I have a m*m matrix (A) of rank n<m, and add another matrix of dimension q*q (B), where q< n. All matrices are Hermitian. Can I find a bound on the absolute eigenvalues of the system? The eigenvalues are lambda_1, – lambda_1, lambda_2, -lambda_2, and so on.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-300687")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2014")])]

#text("Is there a relation for the eigenvalues of the sum of an anti-Hermitian A and a Hermitian matrix B? For example, if I want to know the eigenvalues of A + B, can I simply calculate the eigenvalues of A and B seperately and then get the eigenvalues of A + B from them?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-300718")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2014")])]

#text("If A and B commute, then the eigenvalues of A+B are the sum of eigenvalues of A and some permutation of the eigenvalues of B.")

#text("In general, though, the situation is quite complicated, since A+B will usually not be a normal matrix, and the eigenvalues will be quite badly behaved complex numbers. One can still control the singular values, and hence the eigenvalues to some extent, by the Weyl inequalities, and one also controls the trace of A+B, but other than that things look quite messy, even for the 2×2 matrix case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70afc46b147ddae94a359ef8ca49e5e291fca7800e9e09958219b6e07ac83b3b-8950154077a083003948994086a0a074c530e570da0a67867157bead4e84208e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hamed")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-458453")[#strong[#text("Hamed")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2015")])]

#text("I do not know about the application you have in mind. But in case you need to know the bounds of eigenvalues (for example if you want to analysis the stability of some dynamical system) this structure can help you. You can use Bendixon’s theorem which says that the eigenvalues of A+B are bounded in a box, when the real parts are bounded by eigenvalues of B (Hermitian) and the imaginary parts are bounded by eigenvalues of A (anti-Hermitian).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af92eec58d03a3a6901742a94e863e26d705c386dea4a4cedd29aff9cc464718-4d7c5d9d1cabb3b57e6c467647ed415825145a984b65d392832824a4c5352a2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felix V.")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-380605")[#strong[#text("Felix V.")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2014")])]

#text("Dear Professor Tao,")

#text("in Exercise 10, you ask the reader to proof that")

#text("“the space of Hermitian matrices with at least one repeated eigenvalue has codimension {3} in the space of all Hermitian matrices.”")

#text("It seemed to me that “space” should be interpreted as “(real) vector space” in this context.")

#text("But then the problem is that the set of matrices with at least one repeated eigenvalue is NOT a vector space (not closed under addition), as can be seen by considering e.g. diagonal matrices:")

#text("{")#linebreak()#text(" \\left(\\begin{array}{ccc}")#linebreak()#text(" 1\\\\")#linebreak()#text(" & 1\\\\")#linebreak()#text(" & & 2")#linebreak()#text(" \\end{array}\\right)+\\left(\\begin{array}{ccc}")#linebreak()#text(" 0\\\\")#linebreak()#text(" & 1\\\\")#linebreak()#text(" & & 1")#linebreak()#text(" \\end{array}\\right)=\\left(\\begin{array}{ccc}")#linebreak()#text(" 1\\\\")#linebreak()#text(" & 2\\\\")#linebreak()#text(" & & 3")#linebreak()#text(" \\end{array}\\right)")#linebreak()#text(" }")

#text("Best regards,")

#text("Felix V.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-380747")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2014")])]

#text("Here I am not interpreting “space” in the linear algebra sense; you may substitute “set” or “algebraic set” instead, if you prefer.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-453160")[#strong[#text("Lecture #22: Random Sampling for Fast SVDs | CMU Advanced Algos: S15")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2015")]

#text("[…] pointed out that it follows from the Weyl inequalities. These say that for all integers such that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c48d0057e9c21e2c5de8bd525ac237b506aa9b1d6c1c5d1c74bf15eae788395-e64cbd11c91f029f82d355fb07ffa1b1c17504e7766b383bb74e2d33d8bd9940.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kumar vishwajeet")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-453560")[#strong[#text("kumar vishwajeet")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2015")])]

#text("Dear Dr Tao,")#linebreak()#text(" I am currently working on the distribution of eigenvalues of non central wishart matrices. I found the following interesting thing.")#linebreak()#text(" Let ")#mi("\\mathbf{A} = \\mathbf{M}+\\mu")#text(" be a random complex matrix of size ")#mi("m\\times n; n\\ge m")#text(". ")#mi("\\mu")#text(" has circular Gaussian distribution with mean 0 and variance ")#mi("\\sigma^2")#linebreak()#text(" Consider another case where, ")#mi("\\mathbf{B} = \\mathbf{M}+\\eta")#text(" where ")#mi("\\eta")#text(" has Gaussian distribution with mean 0 and variance ")#mi("\\frac{\\sigma^2}{2}")#text(". Using monte Carlo, I found that the probaility density function of the ")#mi("\\mathbf{AA}^{\\dagger}")#text(" and that of ")#mi("\\mathbf{BB}^T")#text(" only differs by a multiplying constant. Is there any mathematical proof or logical explanation for this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-453567")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2015")])]

#text("The eigenvalues of ")#mi("AA^\\dagger")#text(" and ")#mi("BB^T")#text(" are the squares of the eigenvalues of the Hermitian matrices ")#mi("\\begin{pmatrix} 0 & M \\\\ M^T & 0 \\end{pmatrix} + \\begin{pmatrix} 0 & \\mu \\\\ \\mu^\\dagger & 0 \\end{pmatrix}")#text(" and ")#mi("\\begin{pmatrix} 0 & M \\\\ M^T & 0 \\end{pmatrix} + \\begin{pmatrix} 0 & \\eta \\\\ \\eta^\\dagger & 0 \\end{pmatrix}")#text(" respectively. So my guess is that the matrices ")#mi("\\begin{pmatrix} 0 & \\mu \\\\ \\mu^\\dagger& 0 \\end{pmatrix}")#text(" and ")#mi("\\begin{pmatrix} 0 & \\eta \\\\ \\eta^\\dagger & 0 \\end{pmatrix}")#text(" have essentially the same spectrum (semicircle law, I think) and are behaving as if they were free of ")#mi("\\begin{pmatrix} 0 & M \\\\ M^T & 0 \\end{pmatrix}")#text(". (I’m not sure what you mean by the multiplying constant difference though – the probability density function has to integrate to 1.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c48d0057e9c21e2c5de8bd525ac237b506aa9b1d6c1c5d1c74bf15eae788395-e64cbd11c91f029f82d355fb07ffa1b1c17504e7766b383bb74e2d33d8bd9940.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kumar vishwajeet")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-453561")[#strong[#text("kumar vishwajeet")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2015")])]

#text("Just a modification of my last post: The probability density function of eigenvalues of ")#mi("\\mathbf{AA}^{\\dagger}")#text(" and ")#mi("\\mathbf{BB}^T")#text(" differ by a multiplying constant.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c48d0057e9c21e2c5de8bd525ac237b506aa9b1d6c1c5d1c74bf15eae788395-e64cbd11c91f029f82d355fb07ffa1b1c17504e7766b383bb74e2d33d8bd9940.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kumar vishwajeet")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-453570")[#strong[#text("kumar vishwajeet")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2015")])]

#text("Thank you for the prompt reply.")#linebreak()#text(" By “Multiplying constant difference” I mean that if ")#mi("p_{\\Lambda_a}(\\lambda_1,\\lambda_2,\\cdots,\\lambda_m)")#text(" be the pdf of eigenvalues of ")#mi("\\mathbf{AA}^{\\dagger}")#text(" and ")#mi("p_{\\Lambda_b}(\\lambda_1,\\lambda_2,\\cdots,\\lambda_m)")#text(" be the pdf of eigenvalues of ")#mi("\\mathbf{BB}^T")#text(", then")

#mi("p_{\\Lambda_a}(\\lambda_1,\\lambda_2,\\cdots,\\lambda_m)=Kp_{\\Lambda_b}(\\lambda_1,\\lambda_2,\\cdots,\\lambda_m)")#text(", where ")#mi("K")#text(" is a constant.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c48d0057e9c21e2c5de8bd525ac237b506aa9b1d6c1c5d1c74bf15eae788395-e64cbd11c91f029f82d355fb07ffa1b1c17504e7766b383bb74e2d33d8bd9940.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kumar vishwajeet")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-453574")[#strong[#text("kumar vishwajeet")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2015")])]

#text("I got it. ")#mi("K")#text(" has to be equal to one.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1f616de2cc53ad7ab82924fb5ce1684e1490f4853ec894784f90ee724172e5e-bd1ef283d8b7fc601ca82531a9518de255bc0366364dcc2bff302e4b27362625.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abbas")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-459659")[#strong[#text("Abbas")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2015")])]

#text("What does $|Av|$ denote in Exercise 21?")

#emph[#text("[The magnitude of the vector ")#mi("Av")#text(" formed by multiplying the matrix ")#mi("A")#text(" with the vector ")#mi("v")#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/308ce202a6d7c7f6612f29a022b652d873c97e187aad46935ae00ec007d48650-a23b9b3a411e12d892b3b7d04759d2c59cf63728b58cc90087c2ffb91e05df0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-467401")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2016")])]

#text("Prof. Tao,")

#text("I am a novice going through a few of these exercises and ran into trouble on #6. Here you suggest using Holder’s inequality to prove the p-Wielandt Hoffman inequality. This works very straightforwardly to yield an Lp norm for the right hand side of the inequality (in (14)), but the Lp norm also must be obtained on the left hand side, which is more difficult. Can you comment on how to proceed for the left hand side of (14)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-467406")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2016")])]

#text("Use the converse form ")#tao-math("\\left\\|f\\right\\|_p = \\sup \\{ \\langle f, g \\rangle: \\left\\|g\\right\\|_{p^{\\prime}} = 1 \\}", block: false)#text(" of Holder’s inequality.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/308ce202a6d7c7f6612f29a022b652d873c97e187aad46935ae00ec007d48650-a23b9b3a411e12d892b3b7d04759d2c59cf63728b58cc90087c2ffb91e05df0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-467426")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2016")])]

#text("Very nice, thanks.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-687133")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2025")])]

#text("The original proof is too difficult. A better way. Lidskii’s inequality is really saying that ")#mi("\\lambda(A+B) - \\lambda(A)\\preceq_w \\lambda(B)")#text(" where ")#mi("\\preceq_w")#text(" means weak majorization, and then apply a theorem.")

#mi("x \\prec_{\\mathrm{w}} y \\quad")#text(" if and only if ")#mi("\\sum g\\left(x_i\\right) \\leq \\sum g\\left(y_i\\right)")#text(" for all continuous increasing convex functions ")#mi("g: R\\to R")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29dcf3e8979324121b3eb0d40c58eafdfa5806f0ddbaab8d02a2911a2c17cd44-b66690f0fdd149d5dd697a1e05d6115c5bea04de076c0e67d00ba6f88e7ce254.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-468913")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2016")])]

#text("Dear Dr. Tao,")

#text("I was thinking about a way to show that the partial trace is independent of the choice an orthonormal basis. But I kept failing to find a good proof. Is there any hint you can give me ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-468916")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2016")])]

#text("Given two orthonormal bases for ")#mi("V")#text(", write the elements of one basis as a linear combination of the other basis; the coefficients will then form a unitary matrix since both bases are orthonormal. Insert these expansions of the basis elements to write the partial trace in one basis in terms of the other basis, and use the definition of a unitary matrix to simplify.")

#text("Alternatively, one can note that the partial trace is also equal to the full trace of ")#mi("P_V A P_V")#text(", where ")#mi("P_V")#text(" is the orthogonal projection onto ")#mi("V")#text(", and use the standard fact that the full trace is basis-independent.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-468920")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2016")])]

#text("Thank you, the second one is the one I was looking for.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/728ffdbdbf831c46777b2e42bc03f1bc0f99ed9662dcc59e7d11c9f6a31daf72-655411135ff4a9b6876e18ca44556160f605beca0446e09a6fd681af704a7f26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-469011")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2016")])]

#text("Dear Dr. Tao,")#linebreak()#text(" I would be interested to see the proof of the dual Weyl inequality if you happen to have it handy. I have read the proof in “A Note on Weyl’s Inequality” by Steve Fisk, but I failed to really understand it.")

#text("Thanks,")#linebreak()#text(" David")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-469013")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2016")])]

#text("One can for instance derive the dual Weyl inequality from the original Weyl inequality by repeatedly using the identity ")#mi("\\lambda_i(-A) = -\\lambda_{n+1-i}(A)")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2abaa7f7bc00e0673f6e40fc1ff2f7cae976cf3722d0ee90376de7a0d638daaf-54a549720f81e18025b97e19dcf8adf536c29a4409ce759f849c2a8bae30d9ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vsk1996")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-470023")[#strong[#text("vsk1996")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2016")])]

#text("Tao sir please give some simpler version of (Courant-Fischer Theorem) and relate it with rayleigh quotient")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cdf3c28e1f9ab8923e71b35522cf552204c533e2b241d8c2987760bf490283b5-57939f98c416928123315ff8f27e6b4c9f8e881b2bde904d41bf7ccdbe54b0da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Archy")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-473690")[#strong[#text("Archy")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2016")])]

#text("Prof. Tao, is there a simplification of this theory, if all the Hermitian matrices are rank 1? thank you very much!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of keej")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-474671")[#strong[#text("keej")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2016")])]

#text("These notes are great. I think there is a typo in the definition of spectral projection in Exercise 1. It should be $u_j(A) u_j(A)^*$, not $u_j(A)^* u_j(A)$.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of keej")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-478585")[#strong[#text("keej")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2017")])]

#text("In the proof of the SVD, we use the fact that a critical point of the map ")#tao-math("u \\mapsto \\left\\| A u \\right\\|^2 - \\sigma_1^2 \\left\\| u \\right\\|^2", block: false)#text(" must satisfy the identity ")#mi("A^*A u = \\sigma^2 u")#text(". I have two questions about this.")

#text("First, I can see why this is true by expanding out all the entries and differentiating, but I feel like there should be a faster way. Is there?")

#text("Secondly, what does the derivative even mean in the case that ")#mi("u")#text(" has complex entries? The map in question is real-valued, so how can its gradient be a complex vector?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-478602")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2017")])]

#text("One can first try to understand the situation when ")#mi("A")#text(" is a diagonal matrix, in which case the map basically splits as the sum of ")#mi("n")#text(" non-interacting one-dimensional maps, and the claim is then easy to understand in that setting. The existence of the SVD in fact tells us that the critical point behaviour of a general matrix ")#mi("A")#text(" will be the same as that of a diagonal matrix (with the singular values as entries), so if one believes the SVD to exist then this explains why this identity ought to be true. Of course one cannot use this observation to ")#emph[#text("prove")]#text(" the existence of SVD, as this would be circular, but it can certainly be used to ")#emph[#text("motivate")]#text(" such a proof.")

#text("Any complex vector space can be viewed as a real vector space of twice the dimension, so one can take the gradient in that setting.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b460a2cd048cf23703a325033e724aaefc037bddf13752f0f49cbef9c92e7a99-1139ae556020feb3bdec21750e4debb1db6dc1e50849fa3b592e8672839735c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dita")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-492688")[#strong[#text("Dita")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2018")])]

#text("Dear Prof. Tao, I have one question. If the eigenvalues of matrices A and")#linebreak()#text(" A + B are increasing ordered, but the eigenvalues of B are not ordered, is it possible to use Weyl’s inequality to get a bound for the eigenvalue of A + B? Thank you for your attention.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-497725")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2018")])]

#text("Is the Weyl’s inequality true even in the case when we have separable Hilbert space?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-497733")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2018")])]

#text("For compact self-adjoint operators, basically all the inequalities for finite-dimensional operators extend to the infinite-dimensional setting by a limiting argument, see ")#link("https://arxiv.org/abs/0709.1088")[#text("https://arxiv.org/abs/0709.1088")]#text(" . For non-compact operators, in which the spectrum need not be pure point, the situation is significantly more complicated, and I am not sure what can cleanly be said (beyond the subadditivity of operator norms).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c125a2f0ff40b18e45bb066391903f4d701a0b8f0a42e13ef7018c7eb99a222f-61e5524c4a42136700832d5f9f58aa06d04dcd3be380a207079b46d1502cc28b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-502900")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2018")])]

#text("Do (vii/viii) in Exercise 22 imply that cauchy interlacing theorem holds for eigenvalues of matrices that not necessarily hermitian?")

#emph[#text("[Oops, this was a typo: all references to eigenvalues here have been replaced with singular values. There is no interlacing for eigenvalues for non-Hermitian matrices, as these eigenvalues need not even be real. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-514624")[#strong[#text("Schur-Horn | Random Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2019")]

#text("[…] do: Do the exercises of this post by […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-514635")[#strong[#text("Diagonalization of Hermitian matrices | Random Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2019")]

#text("[…] Following Tao’s post here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-514637")[#strong[#text("Courant-Fischer min-max Theorem | Random Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2019")]

#text("[…] Following Tao’s post here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-514645")[#strong[#text("Extremal partial traces | Random Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2019")]

#text("[…] Following Tao’s post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-514647")[#strong[#text("Wielandt minimax formula | Random Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2019")]

#text("[…] This is exercise 3 in Tao’s post here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-556354")[#strong[#text("Hamiltonian Density of States – Ramis Movassagh")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2020")]

#text("[…] Horn’s conjecture was finally proved by Alexander Klaychko in (1998). Later Knutson and Tao gave a proof based on Honey comb puzzles and Schubert calculus (see this post). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ad54c78ac16bc07f9d4d1d641a6498b09cae8cd9c9e9abdd506ab3be4e3da1e-e432991fd90d78696a9740e307d4190f6bde96cd055d815a5bb297bfea40af22.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vaibhav")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-592371")[#strong[#text("Vaibhav")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2020")])]

#text("Does the positive-definiteness of the matrices A and B alter the eigenvalue inequalities, such as, Weyl inequalities? Is that a condition that needs consideration? Thanks in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-592603")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2020")])]

#text("Any self-adjoint matrix can be made positive definite by adding a large multiple of the identity, which has the effect of translating all the eigenvalues by a constant. One can check that inequalities such as Weyl’s inequalities are invariant under such a translation, hence the imposition of positive definiteness does not lead to any significant improvement to Weyl’s inequalities. On the other hand, being positive definite is equivalent to the eigenvalues being non-negative, so one now has some additional inequalities ")#mi("\\lambda_j \\geq 0")#text(" that one can combine with Weyl’s inequalities if one wishes to obtain some new, but *weaker* inequalities. For instance by adding ")#mi("\\lambda_1 \\geq 0")#text(" to ")#mi("\\nu_1 \\leq \\lambda_1 + \\mu_1")#text(" one gets the new, but worse, inequality ")#mi("\\nu_1 \\leq 2\\lambda_1 + \\mu_1")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-623759")[#strong[#text("The Better Way to Convert an SVD into a Symmetric Eigenvalue Problem – Ethan Epperly")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2021")]

#text("[…] This approach of using the Hermitian dilation to compute the SVD of fixes all the issues identified with the “” approach. We are able to accurately resolve a full 16 orders of magnitude of singular values. The computed singular vectors are accurate and numerically orthogonal provided we use an accurate method for the symmetric eigenvalue problem. The Hermitian dilation preserves important structural characteristics in like sparsity. For purposes of theoretical analysis, the mapping is linear.5The linearity of the Hermitian dilation gives direct extensions of most results about the symmetric eigenvalues to singular values; see Exercise 22. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2a72f38152a4ae17a4f3b80ed616689022213a91c4bb986ffd34e5265c445712-a12c254036a47ca8f9fc5e79cec3e6db6f02daf94bba58df54cb22417fc7e075.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xavier Mootoo")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-638952")[#strong[#text("Xavier Mootoo")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2022")])]

#text("Thank you Dr. Tao, this was really helpful for understanding the Courant-Fischer Theorem!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-645941")[#strong[#text("matrices - Is there relation between eigenvalues of A,B,A+B,AB? Answer - Lord Web")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2022")]

#text("[…] I found there are some works about eigenvalues ​​of $A,B,A+B$ in the case of Hermitian matrices. For example, here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-682857")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2024")])]

#text("Hi professor,")

#text("Regarding the proof of the Hadamard first variation formula I am unable to see why for Hermitian matrices $\\dot{u}_i^*u_i = 0$. If the inner product or eigenvectors were real this would be immediate from differentiating the unit norm condition, but for the complex inner product I only see that the real part must vanish. How can one show that the imaginary part vanishes as well?")

#emph[#text("[Real part inserted into the claim; control of the imaginary part is not needed for the rest of the argument. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f23b67cccbadac977ddbca8ff6dd9c1d51287618d1d456e045e07f0a68e92949-225fb671dfdbb8bfc87ddac5e72e5166f6b2caba7db4cca53027932a20b1bb44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shengtong Zhang")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-687748")[#strong[#text("Shengtong Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2025")])]

#text("Hi Professor:")

#text("Thank you for this very nice blog post!")

#text("During my research, I think I have a proof of the following fact: if ")#emph[#text("A")]#text(" is a positive semi-definite matrix with block decomposition")

#mi("\\displaystyle A = \\begin{bmatrix} B & * \\\\ * & C \\end{bmatrix}")

#text("Then for any ")#mi("k")#text(" we have")

#mi("\\displaystyle \\lambda_1(A) + \\cdots + \\lambda_k(A) \\leq \\lambda_1(A) + \\cdots + \\lambda_k(B) + \\lambda_1(A) + \\cdots + \\lambda_k(C)")

#text("where ")#mi("\\lambda_i")#text(" is interpreted to be ")#mi("0")#text(" if ")#mi("i")#text(" exceeds the dimension of the matrices. May I ask if this fact is well-known, or if you know a reference to this fact?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/#comment-687749")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2025")])]

#text("It is probably in the literature (I would try Bhatia’s book on matrix inequalities), but in any case it follows readily from the Weilandt min-max formula. ")#link("https://en.wikipedia.org/wiki/Min-max_theorem")[#text("https://en.wikipedia.org/wiki/Min-max_theorem")]#text(" , generalizing the proof of the Schur-Horn inequality. (Or one could simply apply the Schur-Horn inequality, after diagonalizing both B and C.)")
]
]
