// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/
// Converted to Typst by tao2typ: "2026-10-14T16:36:33.837161+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On the number of solutions to 4/p = 1/n_1 + 1/n_2 + 1/n_3", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On the number of solutions to 4/p = 1/n_1 + 1/n_2 + 1/n_3")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 July 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/")[#text("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I have just uploaded to the arXiv my paper “")#link("http://arxiv.org/abs/1107.1010")[#text("On the number of solutions to ")#mi("{\\frac{4}{p}=\\frac{1}{n_1}+\\frac{1}{n_2}+\\frac{1}{n_3}}")]#text("“, submitted to the ")#link("http://www.austms.org.au/Journal+of+the+Australian+Mathematical+Society")[#text("Journal of the Australian Mathematical Society")]#text(".")

#text("For any positive integer ")#mi("{n}")#text(", let ")#mi("{f(n)}")#text(" denote the number of solutions to the Diophantine equation")

#align(center)[#tao-fit-display[#mitex("\\frac{4}{n} = \\frac{1}{n_1} + \\frac{1}{n_2} + \\frac{1}{n_3}")]]

#text("where ")#mi("{n_1,n_2,n_3}")#text(" are positive integers (we allow repetitions, and do not require the ")#mi("{n_i}")#text(" to be increasing). The ")#link("http://en.wikipedia.org/wiki/Erd%C5%91s%E2%80%93Straus_conjecture")[#text("Erdös-Straus conjecture")]#text(" asserts that ")#mi("{f(n)>0}")#text(" for all ")#mi("{n \\geq 2}")#text(". By dividing through by any positive integer ")#mi("{m}")#text(" we see that ")#mi("{f(nm) \\geq f(n)}")#text(", so it suffices to verify this conjecture for primes ")#mi("{n=p}")#text(", i.e. to solve the Diophantine equation ")#metadata(none) <tao-dccc5d01dabcd1c0b9fa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{4}{p} = \\frac{1}{n_1} + \\frac{1}{n_2} + \\frac{1}{n_3}")]]

#text("for each prime ")#mi("{p}")#text(". As the case ")#mi("{p=2}")#text(" is easily solved, we may of course restrict attention to odd primes.")

#text("This conjecture remains open, although there is a reasonable amount of evidence towards its truth. For instance, it was shown ")#link("http://www.ams.org/mathscinet-getitem?mr=289409")[#text("by Vaughan")]#text(" that for any large ")#mi("{x}")#text(", the number of exceptions ")#mi("{f(n)=0}")#text(" to the Erdös-Straus conjecture with ")#mi("{n<x}")#text(" is at most ")#mi("{x \\exp( - c \\log^{2/3} x)}")#text(" for some absolute constant ")#mi("{c>0}")#text(". The Erdös-Straus conjecture is also verified in several congruence classes of primes; for instance, from the identity")

#align(center)[#tao-fit-display[#mitex("\\frac{4}{p} = \\frac{1}{\\frac{p+1}{4}} + \\frac{1}{\\frac{p+1}{2}p} + \\frac{1}{\\frac{p+1}{2}p}")]]

#text("we see that the conjecture holds when ")#mi("{p = 3 \\text{ mod } 4}")#text(". Further identities of this type can be used to resolve the conjecture unless ")#mi("{p}")#text(" is a quadratic residue mod ")#mi("{840}")#text(", which leaves only six residue classes in that modulus to check (namely, ")#mi("{1, 121, 169, 289, 361}")#text(", and ")#mi("{529}")#text("). However, there is a significant obstruction to eliminating the quadratic residue classes, as we will discuss later.")

#text("By combining these reductions with extensive numerical calculations, the Erdös-Straus conjecture was verified for all ")#mi("{n \\leq 10^{14}}")#text(" ")#link("http://math.uindy.edu/swett/esc.htm")[#text("by Swett")]#text(".")

#text("One approach to solving Diophantine equations such as ")#link(<tao-dccc5d01dabcd1c0b9fa>)[#text("(1)")]#text(" is to use methods of ")#link("http://en.wikipedia.org/wiki/Analytic_number_theory")[#text("analytic number theory")]#text(", such as the ")#link("http://en.wikipedia.org/wiki/Hardy%E2%80%93Littlewood_circle_method")[#text("circle method")]#text(", to obtain asymptotics (or at least lower bounds) for the number ")#mi("{f(p)}")#text(" of solutions (or some proxy for this number); if one obtains a lower bound which is nontrivial for every ")#mi("{p}")#text(", one has solved the problem. (One can alternatively view such methods as a variant of the ")#link("http://en.wikipedia.org/wiki/Probabilistic_method")[#text("probabilistic method")]#text("; in this interpretation, one chooses the unknowns ")#mi("{n_1,n_2,n_3}")#text(" according to some suitable probability distribution and then tries to show that the probability of solving the equation is positive.) Such techniques can be effective for instance for certain instances of the ")#link("http://en.wikipedia.org/wiki/Waring%27s_problem")[#text("Waring problem")]#text(". However, as a general rule, these methods only work when there are a ")#emph[#text("lot")]#text(" of solutions, and specifically when the number ")#mi("{f(p)}")#text(" of solutions grows at a polynomial rate with the parameter ")#mi("{p}")#text(".")

#text("The first main result of my paper is that the number of solutions ")#mi("{f(p)}")#text(" is essentially logarithmic in nature, thus providing a serious obstruction to solution by analytic methods, as there is almost no margin of error available. More precisely, I show that for almost all primes ")#mi("{p}")#text(" (i.e. in a subset of primes of relative density ")#mi("{1}")#text("), one has ")#mi("{f(p) \\leq p^{o(1)}}")#text(", or more precisely that")

#align(center)[#tao-fit-display[#mitex("f(p) \\leq \\exp( O( \\frac{\\log p}{\\log\\log p} ) ).")]]

#text("Readers familiar with analytic number theory will recognise the right-hand side from the ")#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/")[#text("divisor bound")]#text(", which indeed plays a role in the proof.")

#text("Actually, there are more precise estimates which suggest (though do not quite prove) that the mean value of ")#mi("{f(p)}")#text(" is comparable to ")#mi("{\\log^3 p}")#text(". To state these results properly, I need some more notation. It is not difficult to show that if ")#mi("{p}")#text(" is an odd prime and ")#mi("{n_1,n_2,n_3}")#text(" obey ")#link(<tao-dccc5d01dabcd1c0b9fa>)[#text("(1)")]#text(", then at least one, but not all, of the ")#mi("{n_1,n_2,n_3}")#text(" must be a multiple of ")#mi("{p}")#text(". Thus we can split ")#mi("{f(p) = f_1(p) + f_2(p)}")#text(", where ")#mi("{f_i(p)}")#text(" is the number of solutions to ")#link(<tao-dccc5d01dabcd1c0b9fa>)[#text("(1)")]#text(" where exactly ")#mi("{i}")#text(" of the ")#mi("{n_1,n_2,n_3}")#text(" are divisible by ")#mi("{p}")#text(". The sharpest estimates I can prove are then")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" For all sufficiently large ")#mi("{x}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("x \\log^2 x \\ll \\sum_{p < x} f_1(p) \\ll x \\exp( O( \\frac{\\log x}{\\log \\log x} ) )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("x \\log^2 x \\ll \\sum_{p < x} f_2(p) \\ll x \\log^2 x \\log\\log x.")]]
]

#text("Since the number of primes less than ")#mi("{x}")#text(" is comparable to ")#mi("{x/\\log x}")#text(" by the prime number theorem, this shows that the mean value of ")#mi("{f_2(p)}")#text(" in this range is between ")#mi("{\\log^3 x}")#text(" and ")#mi("{\\log^3 \\log\\log x}")#text(", and the mean value of ")#mi("{f_1(p)}")#text(" is between ")#mi("{\\log^3 x}")#text(" and ")#mi("{\\exp( O( \\frac{\\log x}{\\log \\log x}) )}")#text(", which gives the previous result as a corollary (thanks to a Markov inequality argument). A naive ")#link("http://en.wikipedia.org/wiki/Poisson_process")[#text("Poisson process")]#text(" heuristic then suggests that each prime ")#mi("{p}")#text(" has a “probability” ")#mi("{1 - O( \\exp( - c \\log^3 p ) )}")#text(" of having a solution to ")#link(<tao-dccc5d01dabcd1c0b9fa>)[#text("(1)")]#text(", which by the ")#link("http://en.wikipedia.org/wiki/Borel-Cantelli_lemma")[#text("Borel-Cantelli lemma")]#text(" heuristically suggests that there are only finitely many ")#mi("{p}")#text(" for which ")#link(<tao-dccc5d01dabcd1c0b9fa>)[#text("(1)")]#text(" fails. Of course, this is far from a rigorous proof (though the ")#link("http://www.ams.org/mathscinet-getitem?mr=289409")[#text("result of Vaughan")]#text(" mentioned earlier, which is based on the large sieve, can be viewed as a partial formalisation of the argument).")

#text("The first step in obtaining these results is an elementary description of ")#mi("{f_1(p), f_2(p)}")#text(" in terms of some divisibility constraints. More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" ")#metadata(none) <tao-4a630b8e79a0cd2fbae3>#text(" Let ")#mi("{p}")#text(" be an odd prime. Then ")#mi("{f_1(p)}")#text(" is equal to three times the number of triples ")#mi("{(a,b,c)}")#text(" of positive integers, with ")#mi("{a, b}")#text(" coprime, ")#mi("{c}")#text(" dividing ")#mi("{a+b}")#text(", and ")#mi("{4ab}")#text(" dividing ")#mi("{cp+1}")#text(". Similarly, ")#mi("{f_2(p)}")#text(" is equal to three times the number of triples ")#mi("{(a,b,c)}")#text(" of positive integers, with ")#mi("{a, b}")#text(" coprime, ")#mi("{c}")#text(" dividing ")#mi("{a+b}")#text(", and ")#mi("{4ab}")#text(" dividing ")#mi("{p+c}")#text(".")
]

#text("One direction of this lemma is very easy: if ")#mi("{c}")#text(" divides ")#mi("{a+b}")#text(" and ")#mi("{4ab}")#text(" divides ")#mi("{cp+1}")#text(" then the identity")

#align(center)[#tao-fit-display[#mitex("\\frac{4}{p} = \\frac{1}{\\frac{pc+1}{4}p} + \\frac{1}{\\frac{pc+1}{4a} \\frac{a+b}{c}} + \\frac{1}{\\frac{pc+1}{4b} \\frac{a+b}{c}}")]]

#text("and its cyclic permutations give three contributions to ")#mi("{f_1(p)}")#text(", and similarly if ")#mi("{4ab}")#text(" divides ")#mi("{p+c}")#text(" instead then the identity")

#align(center)[#tao-fit-display[#mitex("\\frac{4}{p} = \\frac{1}{\\frac{p+c}{4}} + \\frac{1}{\\frac{p+c}{4a} \\frac{a+b}{c} p} + \\frac{1}{\\frac{p+c}{4b} \\frac{a+b}{c} p}")]]

#text("and its cyclic permutations give three contributions to ")#mi("{f_2(p)}")#text(". Conversely, some elementary number theory can be used to show that all solutions contributing to either ")#mi("{f_1(p)}")#text(" or ")#mi("{f_2(p)}")#text(" are of these forms. (Similar criteria have been used in prior literature, for instance in the previously mentioned ")#link("http://www.ams.org/mathscinet-getitem?mr=289409")[#text("paper of Vaughan")]#text(".)")

#text("This lemma, incidentally, provides a way to quickly generate a large number of congruences of primes ")#mi("{p}")#text(" for which the Erdös-Straus conjecture can be verified. Indeed, from the above lemma we see that if ")#mi("{a, b}")#text(" are coprime and ")#mi("{c}")#text(" is any odd factor of ")#mi("{a+b}")#text(" (and hence coprime to ")#mi("{4ab}")#text("), then the Erdös-Straus conjecture is true whenever ")#mi("{p=-c \\text{ mod } 4ab}")#text(" or ")#mi("{p = -c^{-1} \\text{ mod } 4ab}")#text(". For instance,")

#list(
[#text("Taking ")#mi("{(a,b,c)=(1,1,1)}")#text(", we see that the conjecture holds whenever ")#mi("{p=3 \\text{ mod } 4}")#text(" (leaving only those primes ")#mi("{p=1 \\text{ mod } 4}")#text(");")],
[#text("Taking ")#mi("{(a,b,c)=(1,2,3)}")#text(" we see that the conjecture holds whenever ")#mi("{p=5 \\text{ mod } 8}")#text(" (leaving only those primes ")#mi("{p=1 \\text{ mod } 8}")#text(");")],
[#text("Taking ")#mi("{(a,b,c)=(3,4,7)}")#text(", we see that the conjecture holds whenever ")#mi("{p=5 \\text{ mod } 12}")#text(" ((leaving only those primes ")#mi("{p=1 \\text{ mod } 24}")#text(");")],
[#text("Taking ")#mi("{(a,b,c)=(1,5,3)}")#text(", we see that the conjecture holds whenever ")#mi("{p=17, 13 \\text{ mod } 20}")#text(" (leaving only those primes ")#mi("{p=1,49 \\text{ mod } 120}")#text(");")],
[#text("Taking ")#mi("{(a,b,c)=(1,14,15)}")#text(", we see that the conjecture holds whenever ")#mi("{p= 41 \\text{ mod } 56}")#text("; taking instead ")#mi("{(a,b,c)=(2,21,23)}")#text(", we see that the conjecture holds whenever ")#mi("{p = 73, 145 \\text{ mod } 168}")#text(". (This leaves only the primes ")#mi("{p}")#text(" that are equal to one of the six quadratic residues ")#mi("{1, 121, 169, 289, 361, 529 \\text{ mod } 840}")#text(", an observation first made ")#link("http://www.ams.org/mathscinet-getitem?mr=249355")[#text("by Mordell")]#text(".)")],
[#text("etc.")]
)

#text("If we let ")#mi("{g_1(n)}")#text(" (resp. ")#mi("{g_2(n)}")#text(") be the number of triples ")#mi("{(a,b,c)}")#text(" with ")#mi("{a,b}")#text(" coprime, ")#mi("{c}")#text(" dividing ")#mi("{a+b}")#text(", and ")#mi("{n}")#text(" congruent to ")#mi("{-c^{-1}}")#text(" (resp. ")#mi("{-c}")#text(") mod ")#mi("{4ab}")#text(", the above lemma tells us that ")#mi("{f_i(p) = 3g_i(p)}")#text(" for all odd primes ")#mi("{p}")#text(", so it suffices to show that ")#mi("{g_1(p), g_2(p)}")#text(" are non-zero for all ")#mi("{p}")#text(". One might hope that there are enough congruence relations provided by the previous observation to obtain a ")#link("http://en.wikipedia.org/wiki/Covering_system")[#text("covering system of congruences")]#text(" which would resolve the conjecture. Unfortunately, as was also observed by Mordell, an application of the ")#link("http://en.wikipedia.org/wiki/Quadratic_reciprocity")[#text("quadratic reciprocity law")]#text(" shows that these congruence relations cannot eliminate quadratic residues, only quadratic non-residues. More precisely, one can show that if ")#mi("{a,b,c,p}")#text(" are as above (restricting to the case ")#mi("p=1 \\text{ mod } 8amp;fg000000")#text(", which contains all the unsolved cases of the conjecture) and ")#mi("{q}")#text(" is the largest odd factor of ")#mi("{4ab}")#text(", then the ")#link("http://en.wikipedia.org/wiki/Jacobi_symbol")[#text("Jacobi symbols")]#text(" ")#mi("{\\left(\\frac{-c}{q}\\right)}")#text(" and ")#mi("{\\left(\\frac{-c^{-1}}{q}\\right)}")#text(" are always equal to ")#mi("{-1}")#text(". One consequence of this is that ")#mi("{g_1(n)=g_2(n)=0}")#text(" whenever ")#mi("{n}")#text(" is an odd perfect square. This makes it quite hard to resolve the conjecture for odd primes ")#mi("{p}")#text(" which resemble a perfect square in that they lie in quadratic residue classes to small moduli (and, from ")#link("http://en.wikipedia.org/wiki/Dirichlet%27s_theorem_on_arithmetic_progressions")[#text("Dirichlet’s theorem on primes in arithmetic progressions")]#text(", one can find many primes of this type). The same argument also shows that for an odd prime ")#mi("{p}")#text(", there are no solutions to")

#align(center)[#tao-fit-display[#mitex("\\frac{4}{p^2} = \\frac{1}{n_1} + \\frac{1}{n_2} + \\frac{1}{n_3}")]]

#text("in which one or two of the ")#mi("{n_1,n_2,n_3}")#text(" are divisible by ")#mi("{p^2}")#text(", with the other denominators being coprime to ")#mi("{p}")#text(". (Of course, one can still get representations of ")#mi("{\\frac{4}{p^2}}")#text(" by starting with a representation of ")#mi("{\\frac{4}{p}}")#text(" and dividing by ")#mi("{p}")#text(", but such representations are is not of the above form.) This shows that any attempt to establish the Erdös-Straus conjecture by manually constructing ")#mi("{n_1,n_2,n_3}")#text(" as a function of ")#mi("{p}")#text(" must involve a technique which breaks down if ")#mi("{p}")#text(" is replaced by ")#mi("{p^2}")#text(" (for instance, this rules out any approach based on using polynomial combinations of ")#mi("{p}")#text(" and dividing into cases based on residue classes of ")#mi("{p}")#text(" in small moduli). Part of the problem here is that we do not have good bounds that prevent a prime ")#mi("{p}")#text(" from “spoofing” a perfect square to all small moduli (say, to all moduli less than a small power of ")#mi("{p}")#text("); this problem is closely related (via quadratic reciprocity) to Vinogradov’s conjecture on the least quadratic nonresidue, discussed in ")#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/")[#text("this previous blog post")]#text(".")

#text("It remains to control the sums ")#mi("{\\sum_{p<x} g_i(p)}")#text(" for ")#mi("{i=1,2}")#text(". The lower bounds ")#mi("{\\sum_{p<x} g_i(p) \\gg x \\log^2 x}")#text(" are relatively routine to establish, arising from counting the contribution of those ")#mi("{a,b,c}")#text(" that are somewhat small (e.g. less than ")#mi("{x^{0.2}}")#text("), and use only standard asymptotics of arithmetic functions and the ")#link("http://en.wikipedia.org/wiki/Bombieri%E2%80%93Vinogradov_theorem")[#text("Bombieri-Vinogradov inequality")]#text(" (to handle the restriction of the summation to primes). To obtain (nearly) matching upper bounds, one needs to prevent ")#mi("{a,b,c}")#text(" from getting too large. In the case of ")#mi("{g_2(p)}")#text(", the fact that ")#mi("{c}")#text(" divides ")#mi("{a+b}")#text(" and ")#mi("{4ab}")#text(" divides ")#mi("{c+p}")#text(" soon leads one to the bounds ")#mi("{ab \\ll x}")#text(", at which point one can count primes in residue classes modulo ")#mi("{4ab}")#text(" with reasonable efficiency via the ")#link("http://en.wikipedia.org/wiki/Brun%E2%80%93Titchmarsh_theorem")[#text("Brun-Titchmarsh inequality")]#text(". This inequality unfortunately introduces a factor of ")#mi("{\\frac{4ab}{\\phi(4ab)}}")#text(", which we were only able to handle by bounding it crudely by ")#mi("{O(\\log \\log x)}")#text(", leading to the double logarithmic loss in the ")#mi("{f_2}")#text(" sum.")

#text("For ")#mi("{g_1(p)}")#text(", these arguments do not give good bounds, because it is possible for ")#mi("{ab}")#text(" to be much larger than ")#mi("{x}")#text(", and one can no longer easily count solutions to ")#mi("{p = -c^{-1} \\text{ mod } 4ab}")#text(". However, an elementary change of variables resolves this problem. It turns out that if one lets ")#mi("{l,m}")#text(" be the positive integers")

#tao-aligned(keep: true)[


#tao-math("l  & := \\frac{pc+1}{4ab}", block: true)



#tao-math("m  & := \\frac{4la^2+1}{c}", block: true)
]

#text("then one can convert the triple ")#mi("{(a,b,c)}")#text(" to a triple ")#mi("{(a,l,m)}")#text(" obeying the constraints")

#align(center)[#tao-fit-display[#mitex("al \\leq p")]]

#align(center)[#tao-fit-display[#mitex("m | 4la^2+1")]]

#align(center)[#tao-fit-display[#mitex("p = -m \\text{ mod } 4al.")]]

#text("Conversely, every such triple ")#mi("{(a,l,m)}")#text(" determines ")#mi("{(a,b,c)}")#text(" by the formulae ")#metadata(none) <tao-61c7ee0a173cd4723ab9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("c = \\frac{4la^2+1}{m}; b = c \\frac{p+m}{4al} - a = \\frac{4la^2 p + m + p}{4alm}.")]]

#text("The point is that this transformation now places ")#mi("{p}")#text(" in a residue class modulo ")#mi("{4al}")#text(" rather than ")#mi("{4ab}")#text(", and with ")#mi("{al = O(x)}")#text(", this allows one to count the number of solutions reasonably efficiently. The main loss now comes from counting the number of divisors ")#mi("{m}")#text(" of ")#mi("{4la^2+1}")#text("; in particular, one becomes interested in estimating sums such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{a \\sim A} \\sum_{l \\sim L} d( 4la^2+1 )")]]

#text("where ")#mi("{A, L}")#text(" are less than ")#mi("{x}")#text(" and ")#mi("{d(n)}")#text(" is the number of divisors of ")#mi("{n}")#text(". In principle, because ")#mi("{d(n)}")#text(" behaves like ")#mi("{\\log n}")#text(" on the average (as can be seen from the Dirichlet hyperbola method), we expect this sum to be of order ")#mi("{AL \\log x}")#text(", but I was unable to show this, instead using the far cruder ")#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/")[#text("divisor bound")]

#align(center)[#tao-fit-display[#mitex("d(n) \\ll \\exp( O(\\frac{\\log n}{\\log\\log n}) )")]]

#text("to obtain an upper bound of ")#mi("{AL \\exp( O(\\frac{\\log x}{\\log\\log x}) )}")#text(". Any improvement upon this bound would lead to a corresponding improvement in the upper bound for ")#mi("{\\sum_{p<x} f_1(p)}")#text(". While improvement is possible in some ranges (particularly when ")#mi("{L}")#text(" is large) using various bounds on Kloosterman-type exponential sums, I was not able to adequately control these sums when ")#mi("{L}")#text(" was fairly small (e.g. polylogarithmic size in ")#mi("{x}")#text("), as one could no longer extract much of an averaging effect from the ")#mi("{l}")#text(" summation in that case. Part of the difficulty is that in that case one must somehow exploit the fact that ")#mi("{4la^2+1}")#text(" is irreducible as a polynomial in ")#mi("{a}")#text(" for any fixed ")#mi("{l}")#text(", otherwise there will be too many divisors.")

#metadata(none) <tao-e0f243e1203b3684b236>

#heading(level: 1)[#strong[#text(" — 1. Solvability criteria — ")]]

#text("In the rest of this post, we record some sufficient conditions for an odd prime ")#mi("{p}")#text(" to have a solution to ")#link(<tao-dccc5d01dabcd1c0b9fa>)[#text("(1)")]#text(". From Lemma ")#link(<tao-4a630b8e79a0cd2fbae3>)[#text("2")]#text(" we have already seen that we have a solution whenever we can find positive integers ")#mi("{(a,b,c)}")#text(" with ")#mi("{a,b}")#text(" coprime, ")#mi("{c|a+b}")#text(", and ")#mi("{4ab}")#text(" dividing either ")#mi("{pc+1}")#text(" or ")#mi("{c+p}")#text(".")

#text("The ")#mi("{(a,l,m)}")#text(" representation discussed earlier gives a slightly different criterion. Indeed, we see that if ")#mi("{(a,l,m)}")#text(" are positive integers such that ")#mi("{m|4la^2+1}")#text(", and ")#mi("{p = -m \\text{ mod } 4al}")#text(", then the quantities ")#mi("{b,c}")#text(" defined by ")#link(<tao-61c7ee0a173cd4723ab9>)[#text("(2)")]#text(" are positive integers which clearly obey ")#mi("{c|a+b}")#text("; furthermore, some algebra reveals that ")#mi("{4abl = pc+1}")#text(" and so ")#mi("{4ab|pc+1}")#text(", and so by Lemma ")#link(<tao-4a630b8e79a0cd2fbae3>)[#text("2")]#text(" we have a solution to ")#link(<tao-dccc5d01dabcd1c0b9fa>)[#text("(1)")]#text("; explicitly, we have")

#align(center)[#tao-fit-display[#mitex("\\frac{4}{p} = \\frac{1}{pabl} + \\frac{1}{kbl} + \\frac{1}{kal}")]]

#text("where ")#mi("{k := \\frac{p+m}{4al}}")#text(". This lets us eliminate some further residue classes (restricting, as we may, to the case ")#mi("{p=1 \\text{ mod } 24}")#text("):")

#list(
[#text("Taking ")#mi("{(a,l,m)=(1,11,3)}")#text(", we can eliminate ")#mi("{p= 41 \\text{ mod } 44}")#text(" (or equivalently, ")#mi("{p = 8 \\text{ mod } 11}")#text(");")],
[#text("Taking ")#mi("{(a,l,m)=(1,11,15)}")#text(", we can eliminate ")#mi("{p= 29 \\text{ mod } 44}")#text(" (or equivalently, ")#mi("{p = 7 \\text{ mod } 11}")#text(");")],
[#text("Taking ")#mi("{(a,l,m)=(2,33,23)}")#text(", we can eliminate ")#mi("{p = 241 \\text{ mod } 264}")#text(" (or equivalently, ")#mi("{p = 10 \\text{ mod } 11}")#text(").")]
)

#text("Unfortunately this only eliminates three of the five quadratic non-residues mod ")#mi("{11}")#text("; I do not know how to eliminate the ")#mi("{2,6 \\text{ mod } 11}")#text(" classes.")

#text("Here is another criterion for eliminating large numbers of primes:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" ")#metadata(none) <tao-560c987e35675251567b>#text(" Let ")#mi("{c,q}")#text(" be coprime positive integers with ")#mi("{c}")#text(" odd. Suppose ")#mi("{p}")#text(" is an odd prime such that")

#align(center)[#tao-fit-display[#mitex("4q | p+c")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("c | p + 4r")]]

#text("for some ")#mi("{r}")#text(" dividing ")#mi("{q^2}")#text(". Then there is a positive integer solution to ")#link(<tao-dccc5d01dabcd1c0b9fa>)[#text("(1)")]#text(".")
]

#emph[#text("Proof:")]#text(" Write ")#mi("{r = a^2 t}")#text(" where ")#mi("{t}")#text(" is square-free, then ")#mi("{a^2 t | q^2}")#text(" and hence ")#mi("{at | q}")#text(". In particular, ")#mi("{4at}")#text(" divides ")#mi("{p+c}")#text(". As ")#mi("{c}")#text(" is coprime to ")#mi("{q}")#text(" and odd, it is also coprime to ")#mi("{4at}")#text(".")

#text("If we then set ")#mi("{b := \\frac{p+c}{4at}}")#text(", then we have ")#mi("{4ab | p+c}")#text("; also, since")

#align(center)[#tao-fit-display[#mitex("a+b = \\frac{p+c+4a^2t}{4at} = \\frac{p+4r+c}{4at}")]]

#text("and ")#mi("{c}")#text(" divides ")#mi("{p+4r}")#text(", we see that ")#mi("{c}")#text(" divides ")#mi("{a+b}")#text(", and so from Lemma ")#link(<tao-4a630b8e79a0cd2fbae3>)[#text("2")]#text(" we have a solution to ")#link(<tao-dccc5d01dabcd1c0b9fa>)[#text("(1)")]#text(", more explicitly, one has")

#align(center)[#tao-fit-display[#mitex("\\frac{4}{p} = \\frac{1}{\\frac{p+c}{4}} + \\frac{1}{\\frac{p+c}{4a} k p} + \\frac{1}{atkp}")]]

#text("where ")#mi("{k}")#text(" is the positive integer")

#align(center)[#tao-fit-display[#mitex("k := \\frac{a+b}{c} = \\frac{p+4r+c}{4atc}.")]]

#mi("\\Box")

#text("Here are some typical applications of this lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 4")]#text(" ")#metadata(none) <tao-66c8aec217cac5fa9829>#text(" Let ")#mi("{p}")#text(" be an odd prime. Then we have a positive integer solution to ")#link(<tao-dccc5d01dabcd1c0b9fa>)[#text("(1)")]#text(" whenever one of the following happens:")

#enum(start: 1, 
[#mi("{\\frac{p+3}{4}}")#text(" is divisible by a factor ")#mi("{q = 2 \\text{ mod } 3}")#text(".")],
[#mi("{p+4}")#text(" is divisible by a factor ")#mi("{c = 3 \\text{ mod } 4}")#text(". (Equivalently, ")#mi("{p+4}")#text(" is not the sum of two squares.)")],
[#text("One of ")#mi("{p+4}")#text(", ")#mi("{p+8}")#text(", or ")#mi("{p+16}")#text(" is divisible by a factor ")#mi("{c = 7 \\text{ mod } 8}")#text(".")],
[#text("One of ")#mi("{p+4}")#text(", ")#mi("{p+12}")#text(", or ")#mi("{p+36}")#text(" is divisible by a factor ")#mi("{c = 11 \\text{ mod } 12}")#text(".")],
[#text("One of ")#mi("{p+4}")#text(", ")#mi("{p+8}")#text(", ")#mi("{p+12}")#text(", ")#mi("{p+16}")#text(", ")#mi("{p+24}")#text(", ")#mi("{p+36}")#text(", ")#mi("{p+48}")#text(", ")#mi("{p+72}")#text(", or ")#mi("{p+144}")#text(" is divisible by a factor ")#mi("{c=23 \\text{ mod } 24}")#text(".")],
[#text("One of ")#mi("{p+4}")#text(", ")#mi("{p+20}")#text(", or ")#mi("{p+100}")#text(" is divisible by a factor ")#mi("{c = -p \\text{ mod } 20}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" By previous considerations we may assume ")#mi("{p=1 \\text{ mod } 24}")#text(". The first claim arises from Lemma ")#link(<tao-560c987e35675251567b>)[#text("3")]#text(" with ")#mi("{c=3}")#text(" and ")#mi("{r=q}")#text(". The second claim comes from taking ")#mi("{q=r=1}")#text(". The third comes from taking ")#mi("{q=2}")#text(" and ")#mi("{r=1,2,4}")#text(", the fourth from ")#mi("{q=3}")#text(" and ")#mi("{r=1,3,9}")#text(", and the fifth from ")#mi("{q=6}")#text(" and ")#mi("{r=1,2,3,6,9,12,18,36}")#text(". The final claim comes from taking ")#mi("{q=5}")#text(" and ")#mi("{r=1,5,25}")#text(". ")#mi("\\Box")

#text("These criteria already recover all the congruence relation conditions in small moduli mentioned previously, and generate infinitely many more (though again, these criteria will consistently miss all perfect squares). For instance, we may eliminate the nine residue classes")

#align(center)[#tao-fit-display[#mitex("p = 7, 10, 11, 15, 17, 19, 20, 21, 22 \\text{ mod } 23")]]

#text("by this corollary, which is most (though not all) of the ")#mi("{11}")#text(" quadratic non-residue classes modulo ")#mi("{23}")#text(" (omitting ")#mi("{5}")#text(" and ")#mi("{14}")#text("), and similarly eliminate nine residue classes mod ")#mi("{47}")#text(", mod ")#mi("{71}")#text(", etc. (actually from ")#mi("{71}")#text(" onwards we eliminate ten classes, due to the first part of the corollary).")

#text("Here is a variant of Lemma ")#link(<tao-560c987e35675251567b>)[#text("3")]#text(", adapted to the ")#mi("{f_1}")#text(" solutions rather than the ")#mi("{f_2}")#text(" solutions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5")]#text(" ")#metadata(none) <tao-d122be3537a17c2bdd7a>#text(" Let ")#mi("{a,k,m}")#text(" be positive integers with ")#mi("{m,k}")#text(" coprime. Suppose ")#mi("{p}")#text(" is an odd prime such that")

#align(center)[#tao-fit-display[#mitex("m | ap+k")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("4ak | p + m.")]]

#text("Then there is a positive integer solution to ")#link(<tao-dccc5d01dabcd1c0b9fa>)[#text("(1)")]#text(".")
]

#emph[#text("Proof:")]#text(" Write ")#mi("{l := \\frac{p+m}{4ak}}")#text(", then ")#mi("{l}")#text(" is a positive integer and ")#mi("{p = -m \\text{ mod } 4al}")#text(". Also, ")#mi("{m}")#text(" divides both ")#mi("{ap+k}")#text(" and ")#mi("{4akl-p = 4akm}")#text(", so on eliminating ")#mi("{k}")#text(" we see that ")#mi("{m}")#text(" divides ")#mi("{p (4la^2+1)}")#text(". If ")#mi("{m}")#text(" was divisible by ")#mi("{p}")#text(", then as ")#mi("{m|ap+k}")#text(", ")#mi("{k}")#text(" would also be divisible by ")#mi("{p}")#text(", contradicting coprimality; thus ")#mi("{m}")#text(" divides ")#mi("{4la^2+1}")#text(", and the claim follows from the ")#mi("{(a,l,m)}")#text(" criterion. More explicitly, one has")

#align(center)[#tao-fit-display[#mitex("\\frac{4}{p} = \\frac{1}{p \\frac{ap+k}{m} \\frac{p+m}{4k}} + \\frac{1}{\\frac{ap+k}{m} \\frac{p+m}{4a}} + \\frac{1}{\\frac{p+m}{4}}.")]]

#mi("\\Box")

#text("Thus, for instance, restricting as before to the case ")#mi("{p=1 \\text{ mod } 24}")#text(", we can obtain a solution whenever one of")

#align(center)[#tao-fit-display[#mitex("p+1, p+2, p+3, p+6, 2p+1, 2p+3, 3p+1, 3p+2, 6p+1")]]

#text("is divisible by some ")#mi("{m = 23 \\text{ mod } 24}")#text(". Combining this with Corollary ")#link(<tao-66c8aec217cac5fa9829>)[#text("4")]#text(", we conclude that in order not to have a solution, we must have")

#tao-aligned(keep: true)[


#tao-math("p  & \\neq -1, -2, -3, -4, -6, -8, -12, -16, -24, -36, -48, -72, -144,", block: true)



#tao-math(" & -\\frac{1}{2}, -\\frac{3}{2}, -\\frac{1}{3}, -\\frac{2}{3}, -\\frac{1}{6} \\text{ mod } q", block: true)
]

#text("for any ")#mi("{q = 23 \\text{ mod } 24}")#text(". This unfortunately does not eliminate any more residue classes modulo ")#mi("{23}")#text(" than we already had (and, of course, quadratic residues remain untouched), but eventually eliminates ")#mi("{18}")#text(" classes for each sufficiently large choice of the modulus ")#mi("{q = 23 \\text{ mod } 24}")#text(".")

#text("Finally, we recall a ")#link("http://www.ams.org/mathscinet-getitem?mr=289409")[#text("criterion of Vaughan")]#text(", which asserts that if there are positive integers ")#mi("{r,s,t}")#text(" such that ")#mi("{4rst-1|rp+s}")#text(", then there is a solution to ")#link(<tao-dccc5d01dabcd1c0b9fa>)[#text("(1)")]#text(", namely")

#align(center)[#tao-fit-display[#mitex("\\frac{4}{p} = \\frac{1}{stq} + \\frac{1}{prtq} + \\frac{1}{prst}")]]

#text("where ")#mi("{q := \\frac{rp+s}{4rst-1}}")#text(". In our notation, and assuming ")#mi("{s,t}")#text(" are coprime, this corresponds to the ")#mi("{f_2}")#text(" representation with")

#align(center)[#tao-fit-display[#mitex("(a,b,c) = ( s, q, 4stq-p )")]]

#text("(note that ")#mi("{4stq-p}")#text(" is also equal to ")#mi("{\\frac{s+q}{r}}")#text("), or in the notation of Lemma ")#link(<tao-560c987e35675251567b>)[#text("3")]#text(",")

#align(center)[#tao-fit-display[#mitex("(\\tilde q,\\tilde r,\\tilde c) = (st, s^2 t, 4stq-p)")]]

#text("(where we place tildes on the quantities in Lemma ")#link(<tao-560c987e35675251567b>)[#text("3")]#text(" to reduce confusion). Thus we see that Vaughan’s criterion is essentially the ")#mi("{f_2}")#text(" case of Lemma ")#link(<tao-4a630b8e79a0cd2fbae3>)[#text("2")]#text(", and is basically equivalent to Lemma ")#link(<tao-560c987e35675251567b>)[#text("3")]#text(" also.")

#text("One can use these criteria to test the Erdos-Straus conjecture for all primes in a certain range, by using these sorts of tests to sieve out all but a small exceptional set of primes, which one can perhaps eliminate using a secondary, larger sieve based on the same criteria. This was done up to ")#mi("{10^{14}}")#text(" ")#link("http://math.uindy.edu/swett/esc.htm")[#text("by Swett")]#text(" in 1999, using Vaughan’s criterion, which only covers the ")#mi("{f_2}")#text(" type solutions; it is likely that with modern computers and by using criteria for both the ")#mi("{f_1}")#text(" and ")#mi("{f_2}")#text(" solutions, one could expand this range significantly.")

#heading(level: 1)[#text("Comments (39)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c44b29f93982b43da7392af1cd9c7f773c4fc1aa75df5e149153d3a464fdbde6-06a8a589e1c6b0829563db00beda7fed8ad2e86cc126d35b00ef55e3099fe92f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of saltypod")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-55213")[#strong[#text("saltypod")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2011")])]

#text("Are there simple counterexamples that show that one needs to allow both $f_1$ and $f_2$ type solutions for a general $p$?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5536e2ed5c1fa87e54776ade5c0361da235581bd08d9265280e5bf61c2141ed-12b84bee07fb83b2ffe132e11959371bef82c8c3b1a80d1c8030af90cbdec6dc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. Eppstein")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-55219")[#strong[#text("D. Eppstein")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2011")])]

#text("@saltypod: if there are counterexamples, they are not tiny. I tried all primes congruent to 1 mod 4 from 5 to 197 and in each case there were solutions of both types.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-55226")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2011")])]

#text("It is likely (but, of course, not proven) that f_1(p) and f_2(p) are both non-zero for all odd primes p, so in principle one could restrict to just one type of solution, though this of course leads to a slightly more difficult conjecture to prove.")

#text("There is an interesting numerical coincidence that the congruences for which there are families of f_1 solutions tend to match the congruences for which there are families of f_2 solutions, which I do not fully understand the origin of (though the fact that both congruences are necessarily constrained to quadratic residues is certainly relevant), but this coincidence will probably dissipate at very large moduli. Certainly there does not appear to be a way to convert families of f_1 solutions to families of f_2 solutions or vice versa. For instance, when p=3 mod 4, there are (up to permutations) five families of f_1 solutions, namely")

#mi("\\frac{1}{\\frac{p^2+p}{4}} + \\frac{1}{\\frac{p+1}{2}} + \\frac{1}{\\frac{p+1}{2}}")

#mi("\\frac{1}{p (p+1) \\frac{p+1}{4}} + \\frac{1}{\\frac{p+1}{4}} + \\frac{1}{\\frac{(p+1)^2}{4}}")

#mi("\\frac{1}{\\frac{p^2+p}{4} \\frac{p^2+p+4}{4}} + \\frac{1}{\\frac{p+1}{4}} + \\frac{1}{\\frac{p+1}{4} \\frac{p^2+p+4}{4}}")

#text("and")

#mi("\\frac{1}{p \\frac{5p+m}{4m}} + \\frac{1}{\\frac{p+m}{4}} + \\frac{1}{\\frac{p+m}{4} \\frac{5p+m}{4m} }")

#text("for m=1,5, but only two families of f_2 solutions, namely")

#mi("\\frac{1}{\\frac{p+1}{4}} + \\frac{1}{\\frac{p^2+p}{2}} + \\frac{1}{\\frac{p^2+p}{2}}")

#text("and")

#mi("\\frac{1}{\\frac{p+1}{4}} + \\frac{1}{p \\frac{p+1}{4}} + \\frac{1}{p \\frac{p+1}{4} \\frac{p+5}{4}}.")

#text("There does not appear to be any obvious way to match up these solutions. (I plan to have a followup post detailing the precise congruences coming from the type 1 and type 2 solutions).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b26c03dcf2a255515cc59e7ab742be97e5566a60d8c3e25c5788bf91b359f86a-b87c6976ce1425ebb41e2e59a7c0c5d3f41b07f2901f1919d6a8a3ec157f2772.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stan Dolan")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-145253")[#strong[#text("Stan Dolan")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2012")])]

#text("Dear Professor Tao, To bring some coherence to the various congruence results for f2 solutions it is interesting to consider the equation in the form Ap+B+C=4ABCD where A,B,C,D are polynomials in p. Considering degrees and results like “A divides B+C” quickly gives only two (essentially different) cases-D linear, A,B,C constant OR A,B linear, C and D constant. Very little work then gives the only possible congruence results [of this type] – and these correspond to Lemma 2 and Lemma 3, respectively. Apologies if this is already very familiar to you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b26c03dcf2a255515cc59e7ab742be97e5566a60d8c3e25c5788bf91b359f86a-b87c6976ce1425ebb41e2e59a7c0c5d3f41b07f2901f1919d6a8a3ec157f2772.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stan Dolan")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-145296")[#strong[#text("Stan Dolan")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2012")])]

#text("Just completed the corresponding analysis for f1. This is much more involved so I hope I have not made any errors. The good news is that this does give congruences which I do not believe are listed in the above paper. For example, let [n ] denote multiple of n and denote factor of n. Then a solution is generated for any prime of the form [4n]-<1+4>. In this particular solution, the double “factor of” helps boost the number of solutions quite effectively.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b26c03dcf2a255515cc59e7ab742be97e5566a60d8c3e25c5788bf91b359f86a-b87c6976ce1425ebb41e2e59a7c0c5d3f41b07f2901f1919d6a8a3ec157f2772.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stan Dolan")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-145298")[#strong[#text("Stan Dolan")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2012")])]

#text("The expression <1+4> did not transmit correctly above and nor did the explanation of as meaning factor of n. Hope this works now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b26c03dcf2a255515cc59e7ab742be97e5566a60d8c3e25c5788bf91b359f86a-b87c6976ce1425ebb41e2e59a7c0c5d3f41b07f2901f1919d6a8a3ec157f2772.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stan Dolan")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-145350")[#strong[#text("Stan Dolan")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2012")])]

#text("It should say")#linebreak()#text(" A multiple of 4n")#linebreak()#text(" Minus")#linebreak()#text(" A factor of (1 + 4 times a factor of n^2)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-55230")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2011")])]

#text("I’ve just learned (from Christian Elsholtz) that the results in my paper overlap to a substantial extent with some unpublished observations of Elsholtz and Heath-Brown, and by combining the two one can obtain some improvements to the results (for instance, one can remove the double logarithmic factor in the ")#mi("\\sum_{p<x} f_2(p)")#text(" upper bound). We are now in the process of revising the paper (which is now going to become a jointly authored paper). This will of course take some time, so the version of the paper currently on the arXiv should be now treated as provisional. I'll post an update here when the revision is ready.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f637a5594cd2f531e84adbcf57ed99ab955739a618113970be3c903999478b9-4f8b661ae2538ae1cb980440c000632cb457a5da2551f5a564af6dde1f6e17d9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manuel Bello-Hern\\'andez")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-55379")[#strong[#text("Manuel Bello-Hern\\'andez")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2011")])]

#text("Dear Prof. Tao,")

#text("We give in {\\it arXiv:1010.2035} the following decomposition")#linebreak()#text(" \\begin{equation}\\label{dec}")#linebreak()#text(" \\frac{4}{abc-b-a}=\\frac1{a\\frac{bc-1}{4}}+\\frac1{a(ac-1)\\frac{bc-1}{m}}+ \\frac1{(ac-1)\\frac{bc-1}{4}(abc-b-a)},")#linebreak()#text(" \\end{equation}")#linebreak()#text(" assuming $bc=1 $ mod $4$. Of course, the interesting case for Erdos-Straus conjecture is $b=3$ and $c=3$ mod $4$. The above decomposition correspond to your notation $f_1$. Using computer we have checked that for each prime $p=4q+1<10^{14}$ there exist nonnegative integer numbers $x,y,z$ such that")#linebreak()#text(" \\[")#linebreak()#text(" p=(x+1)(4y+3)(4z+3)-(x+1)-(4y+3).")#linebreak()#text(" \\]")

#text("For decomposition with two denominator divisible by $p$ (case $f_2$) we have to rewrite $p$ as $(4abc-1)d-4 b^2c$")#linebreak()#text(" \\[")#linebreak()#text(" \\frac4p=\\frac4{(4abc-1)d-4 b^2c}=\\frac1{abcp}+\\frac1{bc(ad-b)}+\\frac1{ac(ad-b)p}")#linebreak()#text(" \\]")#linebreak()#text(" We have checked that all prime $p=4q+1<10^{10}$ can be written as $(4abc-1)d-4 b^2c$ with $d=1$ mod 4.")

#text("Best regards, Manuel Bello-Hern\\'andez.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-55255")[#strong[#text("Stones Cry Out - If they keep silent… » Things Heard: e180v5")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2011")]

#text("[…] Well, to be honest I’m mostly linking this so I don’t lose it and can go back to it. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-55512")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2011")])]

#text("A brief update: Christian Elsholtz and I have managed to obtain the right upper bound ")#mi("\\sum_{p \\leq x} f_i(p) \\ll x \\log^2 x")#text(" for both i=1 and i=2 now (thus eliminating the various losses in the version of the paper currently on the arXiv), by adapting an old argument of Erdos. We’ll put up the updated version of the ms (which now also contains a number of other related results as well) when it is fully written up and ready for resubmission, of course.")

#text("I’ll keep updating the situation as it develops, of course.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5ad3f1dea8472011cc6dda2a0de9415c2ff8e61ad5a85819c5f078e6a3443667-169cf59b63af2cef40004b36efa665e4bcb11cfe05d3bf25e321e2ff4046849e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cadet")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-57389")[#strong[#text("cadet")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2011")])]

#text("I have a few clarifications/corrections in the paper.")

#text("p. 8, first equation in that page: Have you got the roles of $i$ and $j$ flipped in a few places? Specifically, $k \\ll 2^j$ and the number of choices of $(a,b)$ is $2^i$, right?")

#text("p. 9, first equation in the page: Did you mean to say $\\phi(a) \\gg a / log log a$? Of course, the equation is correct as it stands..")

#text("In p. 11, Equation 23: Should the right hand side be $x (log x)^2$ instead of $x^2 log x$?")

#emph[#text("[Thanks! Actually the paper is being revised substantially for other reasons, I hope to have a new version up in the near future. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erdos’ divisor bound « What’s new")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-59954")[#strong[#text("Erdos’ divisor bound « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2011")])]

#text("[…] original paper of Erdös was also corrected in this latter paper.) In a forthcoming revision to my paper on the Erdös-Straus conjecture, Christian Elsholtz and I have also applied this method to obtain bounds such […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Counting the number of solutions to the Erdös-Straus equation on unit fractions « What’s new")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-62342")[#strong[#text("Counting the number of solutions to the Erdös-Straus equation on unit fractions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2011")])]

#text("[…] submitted to the Journal of the Australian Mathematical Society. This supercedes my previous paper on the subject, by obtaining stronger and more general results. (The paper is currently in the process of being […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a42cba640f2f48d3f054903d909fb2ce11e1a826b0a5390f8e42d4684bea591b-5dce9a925b3fb33ba098ac4f22ed772ccac177173e57b03a627300d00316757a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Diophantine sets and the integers | cartesian product")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-82096")[#strong[#text("Diophantine sets and the integers | cartesian product")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2011")])]

#text("[…] On the number of solutions to 4/p = 1/n_1 + 1/n_2 + 1/n_3 (terrytao.wordpress.com) […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b26c03dcf2a255515cc59e7ab742be97e5566a60d8c3e25c5788bf91b359f86a-b87c6976ce1425ebb41e2e59a7c0c5d3f41b07f2901f1919d6a8a3ec157f2772.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stan Dolan")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-146864")[#strong[#text("Stan Dolan")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2012")])]

#text("Numbers of the form 4abc-(a+b)/d, with all variables positive integers, seem interesting in their own right. A reciprocity argument can be used to prove that none are squares (either even or odd). Does anyone know of other classes of number that cannot be so expressed?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/668c6388f4edd67abca8e583e7bdd2e94990e64940d99b20b6ec018a6f71f6fb-7b8ad9d4ca00b89a05a0719b5e9db7e53e82a4e20a181e78dd07dc7e2e4c13cc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ibrahima GUEYE")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-137367")[#strong[#text("Ibrahima GUEYE")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2012")])]

#text("Dear all")#linebreak()#text(" The Professor MIZONY and me do rcent progress about the Erdös-Straus conjecture.")#linebreak()#text(" We will publish it icA")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/668c6388f4edd67abca8e583e7bdd2e94990e64940d99b20b6ec018a6f71f6fb-7b8ad9d4ca00b89a05a0719b5e9db7e53e82a4e20a181e78dd07dc7e2e4c13cc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ibrahimaeygue")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-139008")[#strong[#text("ibrahimaeygue")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("Dear all. Please go to Professor MINOZY’s web page and see the relation between Erdös-Straus conjecture and twin Pythagorians triples")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/668c6388f4edd67abca8e583e7bdd2e94990e64940d99b20b6ec018a6f71f6fb-7b8ad9d4ca00b89a05a0719b5e9db7e53e82a4e20a181e78dd07dc7e2e4c13cc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ibrahimaeygue")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-140861")[#strong[#text("ibrahimaeygue")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2012")])]

#text("Dear all")#linebreak()#text(" Here you are the link")

#link("http://math.univ-lyon1.fr/~mizony/Recent%20progress%20about%20Erdos-Straus%20conjecture.pdf")[#text("Click to access Recent%20progress%20about%20Erdos-Straus%20conjecture.pdf")]

#text("Best regards")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b26c03dcf2a255515cc59e7ab742be97e5566a60d8c3e25c5788bf91b359f86a-b87c6976ce1425ebb41e2e59a7c0c5d3f41b07f2901f1919d6a8a3ec157f2772.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stan Dolan")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-144856")[#strong[#text("Stan Dolan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2012")])]

#text("Dear Professor Tao")#linebreak()#text(" Regarding quadratic residues section –")#linebreak()#text(" a=2, b=7, c=3, p=53. Then q=7 but -3 is a q.r. for 7.")#linebreak()#text(" What have I misunderstood?")#linebreak()#text(" Many thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-144879")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2012")])]

#text("Oops, I forgot to add the restriction ")#mi("p = 1 \\text{ mod } 8")#text(" to that claim, which is needed for the quadratic reciprocity argument to work correctly. (But the ")#mi("p = 1 \\text{ mod } 8")#text(" class covers all the open cases of the conjecture, as already discussed in the post.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b26c03dcf2a255515cc59e7ab742be97e5566a60d8c3e25c5788bf91b359f86a-b87c6976ce1425ebb41e2e59a7c0c5d3f41b07f2901f1919d6a8a3ec157f2772.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stan Dolan")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-144899")[#strong[#text("Stan Dolan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2012")])]

#text("Many thanks for your very helpful reply. I suppose I should have realized. With your hint re p, the proof is straightforward but nevertheless it is a brilliant example of quadratic reciprocity which deserves to be better known. Best wishes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b26c03dcf2a255515cc59e7ab742be97e5566a60d8c3e25c5788bf91b359f86a-b87c6976ce1425ebb41e2e59a7c0c5d3f41b07f2901f1919d6a8a3ec157f2772.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stan Dolan")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-144937")[#strong[#text("Stan Dolan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2012")])]

#text("An odd prime p has an f2 solution if and only if there are positive integers a, b and c such that p=a(4b-1)-b^2/c.")

#text("This observation probably does not contribute anything new to the theory but is quite a neat way of characterising solutions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b26c03dcf2a255515cc59e7ab742be97e5566a60d8c3e25c5788bf91b359f86a-b87c6976ce1425ebb41e2e59a7c0c5d3f41b07f2901f1919d6a8a3ec157f2772.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stan Dolan")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-144941")[#strong[#text("Stan Dolan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2012")])]

#text("Oops – missed out a factor of 4 viz")#linebreak()#text(" p=a(4b-1)-4*b^2/c.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ibrahim Gueye")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-144868")[#strong[#text("Ibrahim Gueye")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2012")])]

#text("Dear all")#linebreak()#text(" Please dread this link ")#link("http://math.univ-lyon1.fr/~mizony/Towards%20the%20proof%20of%20Erdos-Straus%20conjecture.pdf")[#text("http://math.univ-lyon1.fr/~mizony/Towards%20the%20proof%20of%20Erdos-Straus%20conjecture.pdf")]#linebreak()#text(" Best regards")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/668c6388f4edd67abca8e583e7bdd2e94990e64940d99b20b6ec018a6f71f6fb-7b8ad9d4ca00b89a05a0719b5e9db7e53e82a4e20a181e78dd07dc7e2e4c13cc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ibrahimaeyguebrahima GUEYE")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-218882")[#strong[#text("ibrahimaeyguebrahima GUEYE")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2013")])]

#text("Dear Professor TAO")#linebreak()#text(" Recently Professor MIZONY and me published articles about Erdös-Straus conjecture. We show the relation between this conjecture and the Pythagorean triples. Can you read them please?")

#link("http://www.ijmsea.com/admin/docs/1339390041YES%202.pdf")[#text("Click to access 1339390041YES%202.pdf")]

#link("http://www.ijmsea.com/admin/docs/1339408468YES%2014.pdf")[#text("Click to access 1339408468YES%2014.pdf")]

#text("You can too read this paper :")

#link("http://math.univ-lyon1.fr/~mizony/SurErdos_Straus2.pdf")[#text("Click to access SurErdos_Straus2.pdf")]

#text("Best regards")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f48af667e2379833f24c6484a4253f1a6d56fc04ade7862b3f9210ec86b4d1a-d8e75ce9c60eaf93cf589af6be6053f9e33f7b05ece2097a05309a9f6f06e81b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Koussay")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-262929")[#strong[#text("Koussay")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2014")])]

#text("Bonsoir!")#linebreak()#text(" Solution dans la moitié des cas!,")#linebreak()#text(" 1/N + +1/(N/2) + 1/N = 4/N , lorsque N est divisinle par 2 !,(N est paire)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f48af667e2379833f24c6484a4253f1a6d56fc04ade7862b3f9210ec86b4d1a-d8e75ce9c60eaf93cf589af6be6053f9e33f7b05ece2097a05309a9f6f06e81b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Koussay")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-449631")[#strong[#text("Koussay")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2015")])]

#text("Bonjour!")#linebreak()#text(" En fait je travaille sur cette conjecture dépuis 2 ans, la dérniere nouveauté concernant ca, était la résolution pour tous les termes de toutes les suite suivantes:")#linebreak()#text(" ( 3n – 1 ) , ( 7n – 2 ) , ( 11n – 3 ) , …..etc…")#linebreak()#text(" please veuillez-vous voir ca:")

#link("https://fr.answers.yahoo.com/question/index?qid=20150110031531AA7Jsn3")[#text("https://fr.answers.yahoo.com/question/index?qid=20150110031531AA7Jsn3")]

#text("Est ce que c’est importante, ou bien c’est triviale ?")#linebreak()#text(" merci, pour mettre votre avis s.V.P ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f48af667e2379833f24c6484a4253f1a6d56fc04ade7862b3f9210ec86b4d1a-d8e75ce9c60eaf93cf589af6be6053f9e33f7b05ece2097a05309a9f6f06e81b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Koussayj")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-450355")[#strong[#text("Koussayj")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2015")])]

#text("Je remplace le lien suivant:")#linebreak()#text(" ")#link("https://fr.answers.yahoo.com/activity/questions")[#text("https://fr.answers.yahoo.com/activity/questions")]#linebreak()#text(" Au lieu de l’ancien:")#linebreak()#text(" ")#link("https://fr.answers.yahoo.com/question/index?qid=20150110031531AA7Jsn3")[#text("https://fr.answers.yahoo.com/question/index?qid=20150110031531AA7Jsn3")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f48af667e2379833f24c6484a4253f1a6d56fc04ade7862b3f9210ec86b4d1a-d8e75ce9c60eaf93cf589af6be6053f9e33f7b05ece2097a05309a9f6f06e81b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Koussay")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-449632")[#strong[#text("Koussay")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2015")])]

#text("Concernant la conjecture d’Erdos-Strauss: 1/a + 1/b + 1/c = 4/N , alors:")#linebreak()#text(" 1- Si le N est un multiple de 3,(( c-a-d: N est de la forme: N = 3n)), la résolution c’est:")#linebreak()#text(" 1/(4N/3) + 1/(N/3) + 1/(4N) = 4/N")#linebreak()#text(" 2- Si le N est de la forme : N = 3n-1, la résolution c’est:")#linebreak()#text(" 1/n + 1/(3n-1) + 1/[ n(3n-1) ] = 4/(3n-1),")#linebreak()#text(" Il reste donc, la résolution dans le cas où: le N est de la forme suivante:")#linebreak()#text(" N = 3n+1 , mais:")#linebreak()#text(" En plus la résolution lorsque N est paire, c’est:")#linebreak()#text(" 1/N + 1/(N/2) + 1/N = 4/N , donc il reste la résolution lorsque N est de la forme suivante: N = 6n + 1")#linebreak()#text(" Est-ce que c’est interessant, ou bien c’est triviale selon vous ?")#linebreak()#text(" Merci pour vos avis")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3ba3591a36541cbd48a8a51bf72c1d755e7e6acff50cfc1e45e0fff521f6caa-bc116d6e2aa48350ea0096a5d730f935de6a66ab9fa6a647047f49077dc7d8a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jose Manuel Montolio Aranda")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-492969")[#strong[#text("Jose Manuel Montolio Aranda")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2018")])]

#text("Good way.")

#text("I solved all the other cases.")

#text("“Comentarios en Teoría de Números”")

#text("en safecreative.org, openthesis.org")

#text("Saludos!")#linebreak()#text(" José Manuel Montolio Aranda")#linebreak()#text(" SPAIN")

#link("mailto:jmmaranda@hispavista.com")[#text("jmmaranda@hispavista.com")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f48af667e2379833f24c6484a4253f1a6d56fc04ade7862b3f9210ec86b4d1a-d8e75ce9c60eaf93cf589af6be6053f9e33f7b05ece2097a05309a9f6f06e81b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Koussay")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-450357")[#strong[#text("Koussay")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2015")])]

#text("La résolution lorsque KN accepte la division sur 3K – 1, c’est:")#linebreak()#text(" 1/(KN) + 1/[ KN/(3K – 1) ] + 1/N = 4/N")#linebreak()#text(" tel que Le “K” est de notre choit!")#linebreak()#text(" @@@ Translation en English By Google:")#linebreak()#text(" The resolution when KN accept the division of 3K – 1 is:")#linebreak()#text(" 1/(KN) + 1/[ KN/(3K – 1) ] + 1/N = 4/N")#linebreak()#text(" where the “K” is our choice!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec335d65e4931a9d48e22100969833734e4a90d176ff126a9fca3365d49b380-6f8f088e9bad52a2ed508d0adc7fd8b14c3efb8321d7f72600118365ec90375d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-453649")[#strong[#text("Marcelo")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2015")])]

#text("Hey all,")

#text("I’m an undergraduate student and a big fan of T. T. (congratulations on another outstanding post! :) ).")#linebreak()#text(" I think I have recently proved a result similar to lemma 5, which at first sight seems to be one of its particular case, but it’s not. It is:")

#text("Let ")#mi("{a}")#text(" equal 1 or 2 and ")#mi("{k,m}")#text(" be positive integers with ")#mi("{m,k}")#text(" coprime and ")#mi("{k<p}")#text(". Suppose ")#mi("{p}")#text(" is an odd prime such that")

#mi("\\displaystyle  m | ap+k")

#text("and")

#mi("\\displaystyle  4ak | 1 + m.")

#text("Then there is a positive integer solution.")

#text("I was thinking of publishing a note with its proof but I don't know if this is enough. Does anyone think that this is not enough to publish?")#linebreak()#text(" If anyone could tell me whether this result is a trivial consequence of a combination of the ones in this post (or of any other one may find) I would very much appreciate it.")

#text("Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-453651")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2015")])]

#text("Relabeling your divisibility criteria as ")#mi("f | cp+a")#text(" and ")#mi("4ac | 1+f")#text(", or equivalently as ")#mi("bf = pc + a")#text(" and ")#mi("4acd = f+1")#text(", this follows from Proposition 2.6 of the latest version of the paper (")#link("http://arxiv.org/pdf/1107.1010v5.pdf")[#text("http://arxiv.org/pdf/1107.1010v5.pdf")]#text("), or more precisely the remarks just preceding that proposition.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3a162ac9558e5fe96a44962b2bf567ce8d8bfa4ff6b93b07dae0f590b7c8a5ab-3706c62f7a98f12626b3f894b5a0d5fffc014eb150ecab7066b3c308faa3f25d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Serge E. Salez")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-457826")[#strong[#text("Serge E. Salez")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2015")])]

#text("Dear professor Tao")

#text("I should like to have some explanation about a proof you give in your paper arxiv 1107.1010v5 (section 10). It’s well known that an odd prime number ")#mi("p")#text(" verify the conjecture of Erdos-Straus")

#mi("\\frac{4}{p}=\\frac{1}{x} + \\frac{1}{y} + \\frac{1}{z}")

#text("if and only if there exist four positive integers, say ")#mi("a, b, c, d")#text(" such that one of the two equations holds")

#mi("4abcd = pa + pb + c")#text(" (1)")#linebreak()#text(" ")#mi("4abcd = a +b + pc")#text(" (2)")

#text("This necessary and sufficient condition may easily be extended to the case where ")#mi("p")#text(" is the polynomial ")#mi("qt+r")#text(" (with ")#mi("(q,r)=1")#text(") and ")#mi("x=x(t), y=y(t), z=z(t)")#text(" are polynomials of ")#mi("\\mathbb{Z}[t]")#text(" whose leading coefficients are positive integers because ")#mi("\\mathbb{Z}[t]")#text(" is factorial. In your paper, you extend that to a more general case, namely where ")#mi("x=x(t), y=y(t), z=z(t)")#text(" are in ")#mi("Int(\\mathbb{Z})")#text(" that is are")#linebreak()#text(" integer-valued polynomials. It’s obvious that the condition is still sufficient. My question concern the necessity. You say:")

#mi("\\bullet")#text(" “Now we establish the converse claim. Suppose first that we have a primitive residue class ")#mi("q \\mod r")#text(" that can be Type I solved by polynomials, and is maximal with respect to this property, then we have")

#mi("\\frac{4}{p}=\\frac{1}{x} + \\frac{1}{y} + \\frac{1}{z}")

#text("for all sufficiently large primes ")#mi("p")#text(" in this class, where ")#mi("x = x(p), y = y(p), z = z(p)")#text(" are polynomials of ")#mi("p")#text(" that take natural number values for all large ")#mi("p")#text(" in this class. For all sufficiently large ")#mi("p")#text(", we either have ")#mi("y(p)\\leqslant z(p)")#text(" for all ")#mi("p")#text(", or ")#mi("y(p) \\geqslant z(p)")#text(" for all ")#mi("p")#text("; by symmetry we may assume the latter. Applying Proposition 2.2, we see that")

#mi("(x,y,z) = (abdp,acd,bcd)")

#text("for some ")#mi("\\mathbb{N}")#text("-point ")#mi("(a,\\cdots,f) = (a(p),\\cdots,f(p))")#text(" in ")#mi("\\Sigma^{I}_p")#text(" with ")#mi("a(p), b(p), c(p)")#text(" having no common factor. In particular, ")#mi("d = d(p")#text(") is the least common multiple [I assume you meant GCD] of ")#mi("x(p), y(p), z(p)")#text(".”")

#mi("\\bullet")#text(" “Applying the Euclidean algorithm to the polynomials ")#mi("x(p), y(p), z(p)")#text(", we conclude that for sufficiently large ")#mi("p")#text(" in the primitive residue class, ")#mi("d")#text(" is also a polynomial in ")#mi("p")#text(", which divides the polynomials ")#mi("x, y, z")#text(". Dividing out by ")#mi("d")#text(" and repeating these arguments, we conclude that ")#mi("a = a(p), b = b(p)")#text(",")#linebreak()#text(" and ")#mi("c = c(p)")#text(" are also polynomials in ")#mi("p")#text(" for sufficiently large ")#mi("p")#text(" in the primitive residue class. Applying the identities (2.1)-(2.9) we also see that ")#mi("e = e(p)")#text(" and ")#mi("f = f(p)")#text(" are polynomials in ")#mi("p")#text(" for sufficiently large ")#mi("p")#text(".”")

#text("I’ll try to show my problem on an example. I take ")#mi("q=13992")#text(" and ")#mi("r=-503")#text(". Let ")#mi("X(n)=(51n+1)/4, Y(n)=(n+503)/4, Z(n)=(51n+1)(n+503)/102608")#text(". We see that")

#mi("\\frac{4}{n}=\\frac{1}{nX(n)} + \\frac{1}{Y(n)} + \\frac{1}{Z(n)}")

#text("and that ")#mi("X(n), Y(n), Z(n)")#text(" take positive integer values when ")#mi("n=r \\mod q")#text(" is positive.")

#mi("\\bullet")#text(" concerning your first point: for all ")#mi("t")#text(" such that ")#mi("p=13992*11*t - 503")#text(" is prime we have ")#mi("d_p = \\gcd(X(p), Y(p),Z(p)) = 6413")#text(" and for ")#mi("p=2*13992 - 503=27481")#text(" ")#mi("d_p = \\gcd(X(p), Y(p),Z(p)) = 53")#text(". Then ")#mi("p\\longmapsto d_p")#text(" can’t be a polynomial function.")

#mi("\\bullet")#text(" concerning your second point: the polynomials ")#mi("a,b,c,d")#text(" can’t be defined by ")#mi("d = \\gcd(X,Y,Z), a = \\gcd(X/d, Y/d/), b=\\gcd(X/d,Z/d)")#text(" and ")#mi("c=\\gcd(Y/d,Z/d)")#text(" because in ")#mi("\\mathbb{Q}[t]")#text(" the ")#mi("\\gcd()")#text(" is an unit polynomial. Here we would have:")

#mi("d(n)=1")#linebreak()#text(" ")#mi("a(n)=1")#linebreak()#text(" ")#mi("b(n)=n + \\frac{1}{51}")#linebreak()#text(" ")#mi("c(n)=n+503")

#text("and ")#mi("X(n)\\neq a(n)b(n)d(n)")#text(". On more ")#mi("b(n)")#text(" never gives integer values.")

#text("So, the polynomials ")#mi("a,b,c,d")#text(" are defined as above but up to a multiplicative constant in ")#mi("\\mathbb{Q}")#text(". In this example, the solution of ")#mi("(X, Y, Z)=(abd, acd, bcd)")#text(" can be easily found:")

#mi("d(n)=53")#linebreak()#text(" ")#mi("a(n)=11")#linebreak()#text(" ")#mi("b(n)=\\frac{51n+1}{2332}")#linebreak()#text(" ")#mi("c(n)=\\frac{n+503}{2332}")

#text("We see that these polynomials give integer values when ")#mi("n=r \\mod q")#text(". It is not obvious that this can be done for each example and I don’t see how to prove it in the general case.")

#text("Best.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-457833")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2015")])]

#text("You’re right, there are some issues here due to the discrepancy between greatest common divisors in ")#mi("{\\mathbf Q}[t]")#text(" and ")#mi("{\\mathbf Z}[t]")#text(". After accounting for this discrepancy, what seems to be happening is this: the gcd ")#mi("d(p)")#text(" is not quite a polynomial function on ")#mi("p")#text(", but is instead “piecewise polynomial” in the following sense: one can partition the original residue class into finitely many subclasses, such that on each such class, ")#mi("d(p)")#text(" is polynomial (in fact this polynomial is always a scalar multiple of the gcd of ")#mi("x(p),y(p),z(p)")#text(" in ")#mi("{\\mathbf Q}[t]")#text(", but the choice of scalar depends on the subclass). Similarly for the other functions ")#mi("a(p),\\dots,f(p)")#text(". The upshot is that the statement of Theorem 1.9 needs to be changed slightly; a primitive residue class that can be solved by polynomials might not be completely contained in just one of the residue classes in the indicated families, but it can always be covered by a finite number of such classes. (One could probably, with a bit more computation, work out exactly which finite unions of classes in the indicated families can be solved using a single polynomial; probably this is a very rare situation, due to some coincidences amongst the polynomials associated to each residue class.)")

#text("We’ll get this fixed in the arXiv version of the paper soon. Thanks for pointing out the issue.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3ba3591a36541cbd48a8a51bf72c1d755e7e6acff50cfc1e45e0fff521f6caa-bc116d6e2aa48350ea0096a5d730f935de6a66ab9fa6a647047f49077dc7d8a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jose Manuel Montolio Aranda")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-492970")[#strong[#text("Jose Manuel Montolio Aranda")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2018")])]

#text("Well, Mr.Tao.")

#text("I solved the conjecture.")

#text("José Manuel Montolio Aranda")#linebreak()#text(" ESPAÑA")

#text("“Comentarios en Teoría de Números”")#linebreak()#text(" ")#link("http://www.safecreative.org")[#text("http://www.safecreative.org")]#text(", ")#link("http://www.openthesis.org")[#text("http://www.openthesis.org")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3ba3591a36541cbd48a8a51bf72c1d755e7e6acff50cfc1e45e0fff521f6caa-bc116d6e2aa48350ea0096a5d730f935de6a66ab9fa6a647047f49077dc7d8a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jose Manuel Montolio Aranda")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-492972")[#strong[#text("Jose Manuel Montolio Aranda")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2018")])]

#text("|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||")

#text("Teorema")#linebreak()#text(" La ec. Straüss-Erdös: 4/n =1/a + 1/b + 1/c.(n>1).")#linebreak()#text(" Es equivalente a:")#linebreak()#text(" Para todo n, existen un “m”, y un “k”, enteros,")#linebreak()#text(" tal que tres divisores de “n*m”, suman “4*k*m”.")

#text("Demostración")#linebreak()#text(" Sean A,B,C los tres divisores de nm. Con nm=aA=bB=cC")#linebreak()#text(" Para k=1, 4/n =(4m/nm) =(A+B+C)/nm =(1/a)+(1/b)+(1/c)")#linebreak()#text(" Para k>1, A+B+C=4km, a=(nm/A)k,b=(nm/B)k,c=(nm/C)k.")

#text("Straüss-Erdös. Ejemplo de solución")#linebreak()#text(" ——————————————————")#linebreak()#text(" n 2 m 1 nm 2 4m= 1+ 1+ 2 (a 2 b 2 c 1)")#linebreak()#text(" n 3 m 2 nm 6 4m= 1+ 1+ 6 (a 6 b 6 c 1)")#linebreak()#text(" n 4 m 1 nm 4 4m= 1+ 1+ 2 (a 4 b 4 c 2)")#linebreak()#text(" n 5 m 2 nm 10 4m= 1+ 2+ 5 (a 10 b 5 c 2)")#linebreak()#text(" n 7 m 4 nm 28 4m= 1+ 1+ 14 (a 28 b 28 c 2)")

#text("Teorema")#linebreak()#text(" Si m soluciona a cierto nro.primo p,entonces m soluciona a todo N con factor menor p.")#linebreak()#text(" La demostración es obvia.")

#text("Ejemplo. Se omite k=1.")#linebreak()#text(" N 4m A B C ( a b c)")#linebreak()#text(" ———————————————")#linebreak()#text(" p=7 4*4= 16 = 7 +7 +2 4/n =( 4 4 2n)")#linebreak()#text(" 49 4*4= 16 = 7 +7 +2 4/n =( 28 28 2n)")#linebreak()#text(" 77 4*4= 16 = 7 +7 +2 4/n =( 44 44 2n)")#linebreak()#text(" 91 4*4= 16 = 7 +7 +2 4/n =( 52 52 2n)")#linebreak()#text(" 119 4*4= 16 = 7 +7 +2 4/n =( 68 68 2n)")#linebreak()#text(" ———————————————")

#text("Serie aritmética solucionable")#linebreak()#text(" Diremos que una serie aritmética “n=A+Bw” tiene solución, si existe una expresión explícita y constante de n, que da la terna de valores (a,b,c) para todo nro. de la serie.")

#text("Ejemplo")#linebreak()#text(" n= A+Bw ( a , b , c )")#linebreak()#text(" —————————————————–")#linebreak()#text(" 0+2w ( n ,n ,n/2 )")#linebreak()#text(" 2+3w ( (n+1)/3 ,n(n+1)/3 ,n )")#linebreak()#text(" 3+4w ( (n+1)/4 ,n(n+1)/4 ,- )")#linebreak()#text(" 5+8w ( (n+3)/4 ,(n/2)*(n+3)/4 ,n(n+3)/4 )")#linebreak()#text(" ——————————————-")

#text("Estas cuatro series recubren por si sólas a todo valor entero,")#linebreak()#text(" excepto por los nros. “1+24w”.")#linebreak()#text(" Si n es nro. compuesto, tiene una solución dada por su factor primo menor.")#linebreak()#text(" Si n pertenece a una serie ya solucionada, tendrá la sol. correspondiente.")

#text("Teorema")#linebreak()#text(" Todo nro. primo n, inicia una serie con solución. En dicha serie, m es constante y k secuencial. Los valores A,B,C mantienen una expresion constante.")

#text("Ejemplo. Serie Aritmética 5+8w")#linebreak()#text(" n k m A B C a b c")#linebreak()#text(" ——————————————————")#linebreak()#text(" PR 5 4* 1* 2= 8 =[ 1n 2 1] 4/n =( 2 1n 2n)")#linebreak()#text(" PR 13 4* 2* 2= 16 =[ 1n 2 1] 4/n =( 4 2n 4n)")#linebreak()#text(" PR 157 4*20* 2= 160 =[ 1n 2 1] 4/n =( 40 20n 40n)")#linebreak()#text(" ——————————————————-")#linebreak()#text(" Ejemplo de serie que inicia un nro. primo")#linebreak()#text(" PR 3 4* 1* 2= 8 =[ 1n 1n 2]; 4/n =( 2 2 1n);S.Aritmética 3+ 4n")#linebreak()#text(" PR 5 4* 1* 2= 8 =[ 1n 2 1]; 4/n =( 2 1n 2n);S.Aritmética 5+ 8n")#linebreak()#text(" PR 7 4* 2* 2= 16 =[ 1n 1n 2]; 4/n =( 4 4 2n);S.Aritmética 7+ 8n")#linebreak()#text(" PR 11 4* 3* 2= 24 =[ 1n 1n 2]; 4/n =( 6 6 3n);S.Aritmética 11+12n")#linebreak()#text(" PR 13 4* 2* 2= 16 =[ 1n 2 1]; 4/n =( 4 2n 4n);S.Aritmética 13+16n")#linebreak()#text(" PR 17 4* 1* 6= 24 =[ 1n 6 1]; 4/n =( 6 1n 6n);S.Aritmética 17+24n")

#text("from my work Comentarios.")#linebreak()#text(" JM Montolio A.")#linebreak()#text(" ESPAÑA")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac76d21fbd1757c2d1228d6bccc7187177f31a04594e1a67237f3d492394c573-08e7b630d4dac0d5fb91d14cfdb85e33a53d619a7c3b4db4303a4949bdd9db64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jose Manuel Montolio Aranda")]], [#link("https://terrytao.wordpress.com/2011/07/07/on-the-number-of-solutions-to-4p-1n_1-1n_2-1n_3/#comment-492973")[#strong[#text("Jose Manuel Montolio Aranda")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2018")])]

#link("mailto:jmmaranda@hispavista.com")[#text("jmmaranda@hispavista.com")]#linebreak()#text(" Jose Manuel Montolio Aranda")
]
]
]
