// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/10/six-math-essentials-now-available/
// Converted to Typst by tao2typ: "2026-11-13T14:46:20.581734+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "“Six Math Essentials” now available", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("“Six Math Essentials” now available")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/10/six-math-essentials-now-available/")[#text("https://terrytao.wordpress.com/2026/11/10/six-math-essentials-now-available/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-13 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("My popular mathematics book, “")#link("https://teorth.github.io/tao-web/six-math-essentials.html")[#text("Six Math Essentials")]#text("” (")#link("https://www.penguin.co.uk/books/482167/six-maths-essentials-by-tao-terence/9780241829486")[#text("Six Maths Essentials in the UK")]#text("), which was ")#link("https://terrytao.wordpress.com/2026/02/16/six-math-essentials/")[#text("previously announced on this blog in February")]#text(", is ")#link("https://www.quantabooks.org/books/six-math-essentials/")[#text("now available")]#text(" (in print, digital, and audiobook formats).")

#text("Some related links:")

#list(
[#link("https://www.newscientist.com/article/2594471-terence-taos-six-maths-essentials-opens-his-field-to-all-of-us")[#text("Review by Karmela Padavic-Callaghan (New Scientist)")]],
[#link("https://www.publishersweekly.com/9780374621797")[#text("Review (Publishers Weekly)")]],
[#link("https://www.libraryjournal.com/review/six-math-essentials-100013537")[#text("Review (Library Journal")]#text(")")],
[#link("https://www.sciencefriday.com/articles/six-math-essentials-book-excerpt/")[#text("Sample excerpt (via Science Friday)")]#text(", with related ")#link("https://www.sciencefriday.com/segments/terence-tao-ai-math-solutions/")[#text("podcast interview")]],
[#link("https://www.youtube.com/watch?v=p2AAz24AzU4")[#text("Interview about the book with Numberphile")]],
[#link("https://www.youtube.com/watch?v=OOMx2BHHWtE")[#text("Interview with Big Think")]]
)

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ff4c4e63812083582f684e63062212bff0a46ed065de43d12ad814f572114f1a-d48de9143ab4bafe86ce90372f6e8d5f0677fa90039212c2302e8ae3f552da55.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shuhao Cao")]], [#link("https://terrytao.wordpress.com/2026/11/10/six-math-essentials-now-available/#comment-699345")[#strong[#text("Shuhao Cao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("Hi Professor Tao. My son is 8-yr-old and he can solve some AMC 8 problems (like those addition and algebra problems), do you think he could appreciate this book?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Feynman")]], [#link("https://terrytao.wordpress.com/2026/11/10/six-math-essentials-now-available/#comment-699366")[#strong[#text("Feynman")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("good book")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/808a9fabaae8b6d14c481cc9eeac1cbda3b5962aeaf87bdc4fb7b4c31d1ff97c-185af9b41daea84400c19162ebace51688ab50f7739620205eaf0a376fe4a413.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/10/six-math-essentials-now-available/#comment-699397")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("I wish there was a free online version. The book is very short but relatively expensive. I probably still would’ve bought a physical copy had I the chance to read it digitally first and if I enjoyed it.")
]
