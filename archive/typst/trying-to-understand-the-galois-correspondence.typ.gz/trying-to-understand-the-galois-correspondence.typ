// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/08/28/trying-to-understand-the-galois-correspondence/
// Converted to Typst by tao2typ: "2026-10-14T10:47:26.120873+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Trying to understand the Galois correspondence", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Trying to understand the Galois correspondence")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 August 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/08/28/trying-to-understand-the-galois-correspondence/")[#text("https://terrytao.wordpress.com/2018/08/28/trying-to-understand-the-galois-correspondence/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{k}")#text(" be a field, and let ")#mi("{E}")#text(" be a finite ")#link("https://en.wikipedia.org/wiki/Field_extension")[#text("extension")]#text(" of that field; in this post we will denote such a relationship by ")#mi("{k \\hookrightarrow E}")#text(". We say that ")#mi("{E}")#text(" is a ")#link("https://en.wikipedia.org/wiki/Galois_extension")[#text("Galois extension")]#text(" of ")#mi("{k}")#text(" if the cardinality of the automorphism group ")#mi("{\\mathrm{Aut}(E/k)}")#text(" of ")#mi("{E}")#text(" fixing ")#mi("{k}")#text(" is as large as it can be, namely the ")#link("https://en.wikipedia.org/wiki/Degree_of_a_field_extension")[#text("degree")]#text(" ")#mi("{[E:k]}")#text(" of the extension. In that case, we call ")#mi("{\\mathrm{Aut}(E/k)}")#text(" the ")#link("https://en.wikipedia.org/wiki/Galois_group")[#text("Galois group")]#text(" of ")#mi("{E}")#text(" over ")#mi("{k}")#text(" and denote it also by ")#mi("{\\mathrm{Gal}(E/k)}")#text(". The ")#link("https://en.wikipedia.org/wiki/Fundamental_theorem_of_Galois_theory")[#text("fundamental theorem of Galois theory")]#text(" then gives a one-to-one correspondence (also known as the ")#emph[#text("Galois correspondence")]#text(") between the intermediate extensions between ")#mi("{E}")#text(" and ")#mi("{k}")#text(" and the subgroups of ")#mi("{\\mathrm{Gal}(E/k)}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Fundamental theorem of Galois theory)")]#text(" ")#metadata(none) <tao-01b51c659dc0dcdab860>#text(" Let ")#mi("{E}")#text(" be a Galois extension of ")#mi("{k}")#text(".")

#list(
[#text("(i) If ")#mi("{k \\hookrightarrow F \\hookrightarrow E}")#text(" is an intermediate field betwen ")#mi("{k}")#text(" and ")#mi("{E}")#text(", then ")#mi("{E}")#text(" is a Galois extension of ")#mi("{F}")#text(", and ")#mi("{\\mathrm{Gal}(E/F)}")#text(" is a subgroup of ")#mi("{\\mathrm{Gal}(E/k)}")#text(".")],
[#text("(ii) Conversely, if ")#mi("{H}")#text(" is a subgroup of ")#mi("{\\mathrm{Gal}(E/k)}")#text(", then there is a unique intermediate field ")#mi("{k \\hookrightarrow F \\hookrightarrow E}")#text(" such that ")#mi("{\\mathrm{Gal}(E/F)=H}")#text("; namely ")#mi("{F}")#text(" is the set of elements of ")#mi("{E}")#text(" that are fixed by ")#mi("{H}")#text(".")],
[#text("(iii) If ")#mi("{k \\hookrightarrow F_1 \\hookrightarrow E}")#text(" and ")#mi("{k \\hookrightarrow F_2 \\hookrightarrow E}")#text(", then ")#mi("{F_1 \\hookrightarrow F_2}")#text(" if and only if ")#mi("{\\mathrm{Gal}(E/F_2)}")#text(" is a subgroup of ")#mi("{\\mathrm{Gal}(E/F_1)}")#text(".")],
[#text("(iv) If ")#mi("{k \\hookrightarrow F \\hookrightarrow E}")#text(" is an intermediate field between ")#mi("{k}")#text(" and ")#mi("{E}")#text(", then ")#mi("{F}")#text(" is a Galois extension of ")#mi("{k}")#text(" if and only if ")#mi("{\\mathrm{Gal}(E/F)}")#text(" is a normal subgroup of ")#mi("{\\mathrm{Gal}(E/k)}")#text(". In that case, ")#mi("{\\mathrm{Gal}(F/k)}")#text(" is isomorphic to the quotient group ")#mi("{\\mathrm{Gal}(E/k) / \\mathrm{Gal}(E/F)}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" ")#metadata(none) <tao-9298c2011ac4d039a934>#text(" Let ")#mi("{k= {\\bf Q}}")#text(", and let ")#mi("{E = {\\bf Q}(e^{2\\pi i/n})}")#text(" be the degree ")#mi("{\\phi(n)}")#text(" Galois extension formed by adjoining a primitive ")#mi("{n^{th}}")#text(" root of unity (that is to say, ")#mi("{E}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Cyclotomic_field")[#text("cyclotomic field")]#text(" of order ")#mi("{n}")#text("). Then ")#mi("{\\mathrm{Gal}(E/k)}")#text(" is isomorphic to the multiplicative cyclic group ")#mi("{({\\bf Z}/n{\\bf Z})^\\times}")#text(" (the invertible elements of the ring ")#mi("{{\\bf Z}/n{\\bf Z}}")#text("). Amongst the intermediate fields, one has the cyclotomic fields of the form ")#mi("{F = {\\bf Q}(e^{2\\pi i/m})}")#text(" where ")#mi("{m}")#text(" divides ")#mi("{n}")#text("; they are also Galois extensions, with ")#mi("{\\mathrm{Gal}(F/k)}")#text(" isomorphic to ")#mi("{({\\bf Z}/m{\\bf Z})^\\times}")#text(" and ")#mi("{\\mathrm{Gal}(E/F)}")#text(" isomorphic to the elements ")#mi("{a}")#text(" of ")#mi("{({\\bf Z}/n{\\bf Z})^\\times}")#text(" such that ")#mi("{a(n/m) = (n/m)}")#text(" modulo ")#mi("{n}")#text(". (There can also be other intermediate fields, corresponding to other subgroups of ")#mi("{({\\bf Z}/n{\\bf Z})^\\times}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" ")#metadata(none) <tao-92405acbf8cacadf91cd>#text(" Let ")#mi("{k = {\\bf C}(z)}")#text(" be the field of rational functions of one indeterminate ")#mi("{z}")#text(" with complex coefficients, and let ")#mi("{E = {\\bf C}(w)}")#text(" be the field formed by adjoining an ")#mi("{n^{th}}")#text(" root ")#mi("{w = z^{1/n}}")#text(" to ")#mi("{k}")#text(", thus ")#mi("{k = {\\bf C}(w^n)}")#text(". Then ")#mi("{E}")#text(" is a degree ")#mi("{n}")#text(" Galois extension of ")#mi("{k}")#text(" with Galois group isomorphic to ")#mi("{{\\bf Z}/n{\\bf Z}}")#text(" (with an element ")#mi("{a \\in {\\bf Z}/n{\\bf Z}}")#text(" corresponding to the field automorphism of ")#mi("{k}")#text(" that sends ")#mi("{w}")#text(" to ")#mi("{e^{2\\pi i a/n} w}")#text("). The intermediate fields are of the form ")#mi("{F = {\\bf C}(w^{n/m})}")#text(" where ")#mi("{m}")#text(" divides ")#mi("{n}")#text("; they are also Galois extensions, with ")#mi("{\\mathrm{Gal}(F/k)}")#text(" isomorphic to ")#mi("{{\\bf Z}/m{\\bf Z}}")#text(" and ")#mi("{\\mathrm{Gal}(E/F)}")#text(" isomorphic to the multiples of ")#mi("{m}")#text(" in ")#mi("{{\\bf Z}/n{\\bf Z}}")#text(".")
]

#text("There is an analogous Galois correspondence in the covering theory of manifolds. For simplicity we restrict attention to finite covers. If ")#mi("{L}")#text(" is a connected manifold and ")#mi("{\\pi_{L \\leftarrow M}: M \\rightarrow L}")#text(" is a ")#link("https://en.wikipedia.org/wiki/Covering_space")[#text("finite covering map")]#text(" of ")#mi("{L}")#text(" by another connected manifold ")#mi("{M}")#text(", we denote this relationship by ")#mi("{L \\leftarrow M}")#text(". (Later on we will change our function notations slightly and write ")#mi("{\\pi_{L \\leftarrow M}: L \\leftarrow M}")#text(" in place of the more traditional ")#mi("{\\pi_{L \\leftarrow M}: M \\rightarrow L}")#text(", and similarly for the deck transformations ")#mi("{g: M \\leftarrow M}")#text(" below; more on this below the fold.) If ")#mi("{L \\leftarrow M}")#text(", we can define ")#mi("{\\mathrm{Aut}(M/L)}")#text(" to be the group of ")#link("https://en.wikipedia.org/wiki/Covering_space#Deck_transformation")[#text("deck transformations")]#text(": continuous maps ")#mi("{g: M \\rightarrow M}")#text(" which preserve the fibres of ")#mi("{\\pi}")#text(". We say that this covering map is a ")#emph[#text("Galois cover")]#text(" if the cardinality of the group ")#mi("{\\mathrm{Aut}(M/L)}")#text(" is as large as it can be. In that case we call ")#mi("{\\mathrm{Aut}(M/L)}")#text(" the ")#emph[#text("Galois group")]#text(" of ")#mi("{M}")#text(" over ")#mi("{L}")#text(" and denote it by ")#mi("{\\mathrm{Gal}(M/L)}")#text(".")

#text("Suppose ")#mi("{M}")#text(" is a finite cover of ")#mi("{L}")#text(". An ")#emph[#text("intermediate cover")]#text(" ")#mi("{N}")#text(" between ")#mi("{M}")#text(" and ")#mi("{L}")#text(" is a cover of ")#mi("{N}")#text(" by ")#mi("{L}")#text(", such that ")#mi("{L \\leftarrow N \\leftarrow M}")#text(", in such a way that the covering maps are compatible, in the sense that ")#mi("{\\pi_{L \\leftarrow M}}")#text(" is the composition of ")#mi("{\\pi_{L \\leftarrow N}}")#text(" and ")#mi("{\\pi_{N \\leftarrow M}}")#text(". This sort of compatibilty condition will be implicitly assumed whenever we chain together multiple instances of the ")#mi("{\\leftarrow}")#text(" notation. Two intermediate covers ")#mi("{N,N^{\\prime}}")#text(" are ")#emph[#text("equivalent")]#text(" if they cover each other, in a fashion compatible with all the other covering maps, thus ")#mi("{L \\leftarrow N \\leftarrow N^{\\prime} \\leftarrow M}")#text(" and ")#mi("{L \\leftarrow N^{\\prime} \\leftarrow N \\leftarrow M}")#text(". We then have the analogous Galois correspondence:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Fundamental theorem of covering spaces)")]#text(" ")#metadata(none) <tao-7792aa5ae17d8e6b13a7>#text(" Let ")#mi("{L \\leftarrow M}")#text(" be a Galois covering.")

#list(
[#text("(i) If ")#mi("{L \\leftarrow N \\leftarrow M}")#text(" is an intermediate cover betwen ")#mi("{L}")#text(" and ")#mi("{M}")#text(", then ")#mi("{M}")#text(" is a Galois extension of ")#mi("{N}")#text(", and ")#mi("{\\mathrm{Gal}(M/N)}")#text(" is a subgroup of ")#mi("{\\mathrm{Gal}(M/L)}")#text(".")],
[#text("(ii) Conversely, if ")#mi("{H}")#text(" is a subgroup of ")#mi("{\\mathrm{Gal}(M/L)}")#text(", then there is a intermediate cover ")#mi("{L \\leftarrow N \\leftarrow M}")#text(", unique up to equivalence, such that ")#mi("{\\mathrm{Gal}(M/N)=H}")#text(".")],
[#text("(iii) If ")#mi("{L \\leftarrow N_1 \\leftarrow M}")#text(" and ")#mi("{L \\leftarrow N_2 \\leftarrow M}")#text(", then ")#mi("{L \\leftarrow N_1 \\leftarrow N_2 \\leftarrow M}")#text(" if and only if ")#mi("{\\mathrm{Gal}(M/N_2)}")#text(" is a subgroup of ")#mi("{\\mathrm{Gal}(M/N_1)}")#text(".")],
[#text("(iv) If ")#mi("{L \\leftarrow N \\leftarrow M}")#text(", then ")#mi("{N}")#text(" is a Galois cover of ")#mi("{L}")#text(" if and only if ")#mi("{\\mathrm{Gal}(M/N)}")#text(" is a normal subgroup of ")#mi("{\\mathrm{Gal}(M/L)}")#text(". In that case, ")#mi("{\\mathrm{Gal}(N/L)}")#text(" is isomorphic to the quotient group ")#mi("{\\mathrm{Gal}(M/L) / \\mathrm{Gal}(M/N)}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 5")]#text(" ")#metadata(none) <tao-b9c5a21ac38d51c72572>#text(" Let ")#mi("{L= {\\bf C}^\\times := {\\bf C} \\backslash \\{0\\}}")#text(", and let ")#mi("{M = {\\bf C}^\\times}")#text(" be the ")#mi("{n}")#text("-fold cover of ")#mi("{L}")#text(" with covering map ")#mi("{\\pi_{L \\leftarrow M}(w) := w^n}")#text(". Then ")#mi("{M}")#text(" is a Galois cover of ")#mi("{L}")#text(", and ")#mi("{\\mathrm{Gal}(M/L)}")#text(" is isomorphic to the cyclic group ")#mi("{{\\bf Z}/n{\\bf Z}}")#text(". The intermediate covers are (up to equivalence) of the form ")#mi("{N = {\\bf C}^\\times}")#text(" with covering map ")#mi("{\\pi_{L \\leftarrow N}(u) := u^m}")#text(" where ")#mi("{m}")#text(" divides ")#mi("{n}")#text("; they are also Galois covers, with ")#mi("{\\mathrm{Gal}(N/L)}")#text(" isomorphic to ")#mi("{{\\bf Z}/m{\\bf Z}}")#text(" and ")#mi("{\\mathrm{Gal}(M/N)}")#text(" isomorphic to the multiples of ")#mi("{m}")#text(" in ")#mi("{{\\bf Z}/n{\\bf Z}}")#text(".")
]

#text("Given the strong similarity between the two theorems, it is natural to ask if there is some more concrete connection between Galois theory and the theory of finite covers.")

#text("In one direction, if the manifolds ")#mi("{L,M,N}")#text(" have an algebraic structure (or a complex structure), then one can relate covering spaces to field extensions by considering the field of rational functions (or meromorphic functions) on the space. For instance, if ")#mi("{L = {\\bf C}^\\times}")#text(" and ")#mi("{z}")#text(" is the coordinate on ")#mi("{L}")#text(", one can consider the field ")#mi("{{\\bf C}(z)}")#text(" of rational functions on ")#mi("{L}")#text("; the ")#mi("{n}")#text("-fold cover ")#mi("{M = {\\bf C}^\\times}")#text(" with coordinate ")#mi("{w}")#text(" from Example ")#link(<tao-b9c5a21ac38d51c72572>)[#text("5")]#text(" similarly has a field ")#mi("{{\\bf C}(w)}")#text(" of rational functions. The covering ")#mi("{\\pi_{L \\leftarrow M}(w) = w^n}")#text(" relates the two coordinates ")#mi("{z,w}")#text(" by the relation ")#mi("{z = w^n}")#text(", at which point one sees that the rational functions ")#mi("{{\\bf C}(w)}")#text(" on ")#mi("{L}")#text(" are a degree ")#mi("{n}")#text(" extension of that of ")#mi("{{\\bf C}(z)}")#text(" (formed by adjoining the ")#mi("{n^{th}}")#text(" root of unity ")#mi("{w}")#text(" to ")#mi("{z}")#text("). In this way we see that Example ")#link(<tao-b9c5a21ac38d51c72572>)[#text("5")]#text(" is in fact closely related to Example ")#link(<tao-92405acbf8cacadf91cd>)[#text("3")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" What happens if one uses meromorphic functions in place of rational functions in the above example? (To answer this question, I found it convenient to use a discrete Fourier transform associated to the multiplicative action of the ")#mi("{n^{th}}")#text(" roots of unity on ")#mi("{M}")#text(" to decompose the meromorphic functions on ")#mi("{M}")#text(" as a linear combination of functions invariant under this action, times a power ")#mi("{w^j}")#text(" of the coordinate ")#mi("{w}")#text(" for ")#mi("{j=0,\\dots,n-1}")#text(".)")
]

#text("I was curious however about the reverse direction. Starting with some field extensions ")#mi("{k \\hookrightarrow F \\hookrightarrow E}")#text(", is it is possible to create manifold like spaces ")#mi("{M_k \\leftarrow M_F \\leftarrow M_E}")#text(" associated to these fields in such a fashion that (say) ")#mi("{M_E}")#text(" behaves like a “covering space” to ")#mi("{M_k}")#text(" with a group ")#mi("{\\mathrm{Aut}(M_E/M_k)}")#text(" of deck transformations isomorphic to ")#mi("{\\mathrm{Aut}(E/k)}")#text(", so that the Galois correspondences agree? Also, given how the notion of a path (and associated concepts such as loops, monodromy and the fundamental group) play a prominent role in the theory of covering spaces, can spaces such as ")#mi("{M_k}")#text(" or ")#mi("{M_E}")#text(" also come with a notion of a path that is somehow compatible with the Galois correspondence?")

#text("The standard answer from modern algebraic geometry (as articulated for instance in ")#link("https://mathoverflow.net/a/24068/766")[#text("this nice MathOverflow answer by Minhyong Kim")]#text(") is to set ")#mi("{M_E}")#text(" equal to the ")#link("https://en.wikipedia.org/wiki/Spectrum_of_a_ring")[#text("spectrum")]#text(" ")#mi("{\\mathrm{Spec}(E)}")#text(" of the field ")#mi("{E}")#text(". As a set, the spectrum ")#mi("{\\mathrm{Spec}(R)}")#text(" of a commutative ring ")#mi("{R}")#text(" is defined as the set of ")#link("https://en.wikipedia.org/wiki/Prime_ideal")[#text("prime ideals")]#text(" of ")#mi("{R}")#text(". Generally speaking, the map ")#mi("{R \\mapsto \\mathrm{Spec}(R)}")#text(" that maps a commutative ring to its spectrum tends to act like an inverse of the operation that maps a space ")#mi("{X}")#text(" to a ring of functions on that space. For instance, if one considers the commutative ring ")#mi("{{\\bf C}[z, z^{-1}]}")#text(" of regular functions on ")#mi("{M = {\\bf C}^\\times}")#text(", then each point ")#mi("{z_0}")#text(" in ")#mi("{M}")#text(" gives rise to the prime ideal ")#mi("{\\{ f \\in {\\bf C}[z, z^{-1}]: f(z_0)=0\\}}")#text(", and one can check that these are the only such prime ideals (other than the zero ideal ")#mi("{(0)}")#text("), giving an almost one-to-one correspondence between ")#mi("{\\mathrm{Spec}( {\\bf C}[z,z^{-1}] )}")#text(" and ")#mi("{M}")#text(". (The zero ideal corresponds instead to the ")#link("https://en.wikipedia.org/wiki/Generic_point")[#text("generic point")]#text(" of ")#mi("{M}")#text(".)")

#text("Of course, the spectrum of a field such as ")#mi("{E}")#text(" is just a point, as the zero ideal ")#mi("{(0)}")#text(" is the only prime ideal. Naively, it would then seem that there is not enough space inside such a point to support a rich enough structure of paths to recover the Galois theory of this field. In modern algebraic geometry, one addresses this issue by considering not just the set-theoretic elements of ")#mi("{E}")#text(", but more general “base points” ")#mi("{p: \\mathrm{Spec}(b) \\rightarrow \\mathrm{Spec}(E)}")#text(" that map from some other (affine) scheme ")#mi("{\\mathrm{Spec}(b)}")#text(" to ")#mi("{\\mathrm{Spec}(E)}")#text(" (one could also consider non-affine base points of course). One has to rework many of the fundamentals of the subject to accommodate this “")#link("https://en.wikipedia.org/wiki/Grothendieck%27s_relative_point_of_view")[#text("relative point of view")]#text("“, for instance replacing the usual notion of topology with an ")#link("https://en.wikipedia.org/wiki/%C3%89tale_topology")[#text("étale topology")]#text(", but once one does so one obtains a very satisfactory theory.")

#text("As an exercise, I set myself the task of trying to interpret Galois theory as an analogue of covering space theory in a more classical fashion, without explicit reference to more modern concepts such as schemes, spectra, or étale topology. After some experimentation, I found a reasonably satisfactory way to do so as follows. The space ")#mi("{M_E}")#text(" that one associates with ")#mi("{E}")#text(" in this classical perspective is not the single point ")#mi("{\\mathrm{Spec}(E)}")#text(", but instead the much larger space consisting of ring homomorphisms ")#mi("{p: E \\rightarrow b}")#text(" from ")#mi("{E}")#text(" to arbitrary ")#link("https://en.wikipedia.org/wiki/Integral_domain")[#text("integral domains")]#text(" ")#mi("{b}")#text("; informally, ")#mi("{M_E}")#text(" consists of all the “models” or “representations” of ")#mi("{E}")#text(" (in the spirit of ")#link("https://terrytao.wordpress.com/2012/09/05/a-trivial-remark-about-schemes/")[#text("this previous blog post")]#text("). (There is a technical set-theoretic issue here because the class of integral domains ")#mi("{R}")#text(" is a proper class, so that ")#mi("{M_E}")#text(" will also be a proper class; I will completely ignore such technicalities in this post.) We view each such homomorphism ")#mi("{p: E \\rightarrow b}")#text(" as a single point in ")#mi("{M_E}")#text(". The analogous notion of a path from one point ")#mi("{p: E \\rightarrow b}")#text(" to another ")#mi("{p^{\\prime}: E \\rightarrow b^{\\prime}}")#text(" is then a homomorphism ")#mi("{\\gamma: b \\rightarrow b^{\\prime}}")#text(" of integral domains, such that ")#mi("{p^{\\prime}}")#text(" is the composition of ")#mi("{p}")#text(" with ")#mi("{\\gamma}")#text(". Note that every prime ideal ")#mi("{I}")#text(" in the spectrum ")#mi("{\\mathrm{Spec}(R)}")#text(" of a commutative ring ")#mi("{R}")#text(" gives rise to a point ")#mi("{p_I}")#text(" in the space ")#mi("{M_R}")#text(" defined here, namely the quotient map ")#mi("{p_I: R \\rightarrow R/I}")#text(" to the ring ")#mi("{R/I}")#text(", which is an integral domain because ")#mi("{I}")#text(" is prime. So one can think of ")#mi("{\\mathrm{Spec}(R)}")#text(" as being a distinguished subset of ")#mi("{M_R}")#text("; alternatively, one can think of ")#mi("{M_R}")#text(" as a sort of “penumbra” surrounding ")#mi("{\\mathrm{Spec}(R)}")#text(". In particular, when ")#mi("{E}")#text(" is a field, ")#mi("{\\mathrm{Spec}(E) = \\{(0)\\}}")#text(" defines a special point ")#mi("{p_R}")#text(" in ")#mi("{M_R}")#text(", namely the identity homomorphism ")#mi("{p_R: R \\rightarrow R}")#text(".")

#text("Below the fold I would like to record this interpretation of Galois theory, by first revisiting the theory of covering spaces using paths as the basic building block, and then adapting that theory to the theory of field extensions using the spaces indicated above. This is not too far from the usual scheme-theoretic way of phrasing the connection between the two topics (basically I have replaced étale-type points ")#mi("{p: \\mathrm{Spec}(b) \\rightarrow \\mathrm{Spec}(E)}")#text(" with more classical points ")#mi("{p: E \\rightarrow b}")#text("), but I had not seen it explicitly articulated before, so I am recording it here for my own benefit and for any other readers who may be interested.")

#metadata(none) <tao-ee21d775cb9ddab998b1>

#heading(level: 1)[#strong[#text(" — 1. Some notation on functions — ")]]

#text("It will be convenient to adopt notation in which many of the basic hypotheses we use take the form of an associativity-type law. To this end, we will use two non-standard notations for functions (which is implicit in the usual notation for left and right group actions), sometimes referred to as ")#link("https://en.wikipedia.org/wiki/Reverse_Polish_notation")[#text("reverse Polish")]#text(" and ")#link("https://en.wikipedia.org/wiki/Polish_notation")[#text("Polish")]#text(" notation (for left and right actions respectively).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 7")]#text(" (Polish and reverse Polish notation) Let ")#mi("{A,B}")#text(" be sets. A ")#emph[#text("function ")#mi("{f: A \\rightarrow B}")#text(" acting on the right")]#text(" is a function ")#mi("{f: A \\rightarrow B}")#text(" in which the notation for evaluating ")#mi("{f}")#text(" at an element ")#mi("{a \\in A}")#text(" is denoted ")#mi("{af}")#text(" rather than the more standard ")#mi("{f(a)}")#text(". If ")#mi("{f: A \\rightarrow B, g: B \\rightarrow C}")#text(" are two functions acting on the right, we write ")#mi("{fg: A \\rightarrow C}")#text(" for the composition that is more commonly denoted ")#mi("{g \\circ f}")#text("; this way we have the associativity-type property ")#metadata(none) <tao-b063dd3619e542ef6afc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("(af) g = a(fg)")]]

#text(" for ")#mi("{a \\in A}")#text(".")

#text("Similarly, a ")#emph[#text("function ")#mi("{f: B \\leftarrow A}")#text(" acting on the left")]#text(" is a function ")#mi("{f: A \\rightarrow B}")#text(" in which the notation for evaluating ")#mi("{f}")#text(" at an element ")#mi("{a \\in A}")#text(" is denoted ")#mi("{fa}")#text(" rather than the more standard ")#mi("{f(a)}")#text(". If ")#mi("{f: B \\leftarrow A, g: C \\leftarrow B}")#text(" are two functions acting on the left, we write ")#mi("{gf: C \\leftarrow A}")#text(" for the composition that is more commonly denoted ")#mi("{g \\circ f}")#text("; this way we have the associativity type property")

#align(center)[#tao-fit-display[#mitex("g(fa) = (gf) a")]]

#text("for ")#mi("{a \\in A}")#text(". We do not define a composition between a function acting on the right and a function acting on the left.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" Functions acting on the left largely correspond to the traditional notion of a function, despite the reversed arrow in the notation ")#mi("{f: B \\leftarrow A}")#text("; functions acting on the right can be thought of as “antifunctions”, in which the composition law is reversed.")
]

#text("As a general rule, in this post covering maps and deck transformations will be functions acting on the left, while paths will be functions acting on the right.")

#text("When viewing the (left or right) automorphisms of a set ")#mi("{A}")#text(" as a group, we use juxtaposition ")#mi("{(f,g) \\mapsto fg}")#text(" rather than composition ")#mi("{(f,g) \\mapsto f \\circ g}")#text(" as the group law; thus, in the case of automorphisms acting on the right, the group structure we will use is the ")#link("https://en.wikipedia.org/wiki/Opposite_group")[#text("opposite")]#text(" of the usual composition group structure, whereas for automorphisms acting on the left the group structure agrees with the standard composition group structure. In particular, the group of right-automorphisms of a space ")#mi("{A}")#text(" is canonically identified with the opposite group of the group of left-automorphisms of a space ")#mi("{A}")#text(". (Of course, the opposite of a group ")#mi("{G}")#text(" is in turn canonically identified with the group itself through the inversion operation ")#mi("{g \\mapsto g^{-1}}")#text(", but we will refrain from using this further identification in this text as it can cause some additional confusion.)")

#text("As is customary, we will adopt the notational convention of omitting parentheses whenever there is an associativity-type law to prevent any ambiguity. For instance, if ")#mi("{a \\in A}")#text(" and ")#mi("{f: A \\rightarrow B}")#text(", ")#mi("{g: B \\rightarrow C}")#text(" are functions acting on the right, we may write ")#mi("{afg}")#text(" without any ambiguity thanks to ")#link(<tao-b063dd3619e542ef6afc>)[#text("(1)")]#text(".")

#heading(level: 1)[#strong[#text(" — 2. Covers of manifolds — ")]]

#text("We begin by revisiting the theory of covering spaces of manifolds. To align with the way we will be thinking about Galois theory, it will be convenient to assume the existence of a (connected) base manifold ")#mi("{B}")#text(", such that all the other manifolds ")#mi("{L,M,N}")#text(" we will be considering are finite extensions of that base ")#mi("{B}")#text(". Again, for simplicity (and to make the theory more closely resemble Galois theory) we will restrict attention to finite covers, though one could extend most of this discussion to infinite covers without much difficulty.")

#text("One can think of the base manifold ")#mi("{B}")#text(" as a ")#link("https://en.wikipedia.org/wiki/Category_(mathematics)")[#text("category")]#text(", in which the objects are the points ")#mi("{b \\in B}")#text(" of the manifold, and the morphisms are the paths ")#mi("{\\gamma}")#text(" in ")#mi("{B}")#text(" connecting one point ")#mi("{b_1 \\in B}")#text(" to another ")#mi("{b_2 \\in B}")#text(", with the composition ")#mi("{\\gamma_1 \\gamma_2}")#text(" of two paths ")#mi("{\\gamma_1}")#text(" (connecting ")#mi("{b_1}")#text(" to ")#mi("{b_2}")#text(") with ")#mi("{\\gamma_2}")#text(" (connecting ")#mi("{b_2}")#text(" to ")#mi("{b_3}")#text(") being a path connecting ")#mi("{b_1}")#text(" with ")#mi("{b_3}")#text(" formed by concatenating the two paths together. We leave the composition ")#mi("{\\gamma_1 \\gamma_2}")#text(" undefined if the terminal point of ")#mi("{\\gamma_1}")#text(" does not agree with the starting point of ")#mi("{\\gamma_2}")#text(". We will not distinguish a path from a reparameterisation of that path (in fact we will not mention parameterisations at all); in particular, we have the associativity law")

#align(center)[#tao-fit-display[#mitex("(\\gamma_1 \\gamma_2) \\gamma_3 = \\gamma_1 (\\gamma_2 \\gamma_3).")]]

#text("We denote the space of all paths (up to reparameterisations) by ")#mi("{\\Gamma}")#text(". One should think of ")#mi("{\\Gamma}")#text(" as being somewhat like a group, except that the multiplication law is not always defined. (More precisely, ")#mi("{\\Gamma}")#text(" is not just a category, but is in fact a ")#link("https://en.wikipedia.org/wiki/Groupoid")[#text("groupoid")]#text(", although we will not explicitly use this fact here.)")

#text("To signify the fact that a path ")#mi("{\\gamma}")#text(" has starting point ")#mi("{b_1}")#text(" and terminal point ")#mi("{b_2}")#text(", we write")

#align(center)[#tao-fit-display[#mitex("b_1 \\gamma = b_2.")]]

#text("If ")#mi("{b_1}")#text(" is not the starting point of ")#mi("{\\gamma}")#text(", we leave ")#mi("{b_1 \\gamma}")#text(" undefined. Note this way that we obtain the associativity-type law")

#align(center)[#tao-fit-display[#mitex("b (\\gamma_1 \\gamma_2) = (b \\gamma_1) \\gamma_2")]]

#text("whenever one of the two sides is well-defined (which forces the other side to be well-defined also).")

#text("Now let ")#mi("{B \\leftarrow M}")#text(" be a finite cover with covering map ")#mi("{\\pi_{B \\leftarrow M}: B \\leftarrow M}")#text("; here all covering maps are understood to act on the left. Given a point ")#mi("{p \\in M}")#text(" lying above a base point ")#mi("{b \\in B}")#text(" (thus ")#mi("{b = \\pi_{B \\leftarrow M} p}")#text("), and a path ")#mi("{\\gamma \\in \\Gamma}")#text(" with starting point ")#mi("{b}")#text(", we may lift ")#mi("{\\gamma}")#text(" up to a path in ")#mi("{M}")#text(" that starts at ")#mi("{p}")#text(" and ends at some point which we will denote by ")#mi("{p \\gamma}")#text(". This point will lie above ")#mi("{b \\gamma}")#text(" in ")#mi("{B}")#text(", thus we have the associativity-type law")

#align(center)[#tao-fit-display[#mitex("(\\pi_{B \\leftarrow M} p) \\gamma = \\pi_{B \\leftarrow M} (p \\gamma)")]]

#text("whenever one of the two sides (and hence the other) is well-defined. It is easy to see that this defines an (right) action of ")#mi("{\\Gamma}")#text(" in the sense that one has the associativity type law")

#align(center)[#tao-fit-display[#mitex("p (\\gamma_1 \\gamma_2) = (p \\gamma_1) \\gamma_2")]]

#text("whenever ")#mi("{p \\in M}")#text(" and ")#mi("{\\gamma_1,\\gamma_2 \\in \\Gamma}")#text(" are such that one of the two sides (and hence the other) is well-defined.")

#text("Note that if ")#mi("{M}")#text(" is connected and ")#mi("{p_0 \\in M}")#text(", then any other point ")#mi("{p \\in M}")#text(" can be connected to ")#mi("{p_0}")#text(" by a path in ")#mi("{M}")#text(", which is the lift of some path in ")#mi("{B}")#text(". Thus the action of ")#mi("{\\Gamma}")#text(" is transitive in the sense that for every ")#mi("{p_0,p \\in M}")#text(" there exists ")#mi("{\\gamma \\in \\Gamma}")#text(" such that ")#mi("{p_0 \\gamma = p}")#text(".")

#text("If we have finite covers ")#mi("{B \\leftarrow L \\leftarrow M}")#text(" then the actions of ")#mi("{\\Gamma}")#text(" on ")#mi("{L}")#text(" and ")#mi("{M}")#text(" are compatible in the sense that one has the associativity-type law")

#align(center)[#tao-fit-display[#mitex("(\\pi_{L \\leftarrow M} p) \\gamma = \\pi_{L \\leftarrow M} (p \\gamma)")]]

#text("whenever one of the two sides (and hence the other) is well-defined. A ")#link("https://en.wikipedia.org/wiki/Covering_space#Deck_transformation_group,_regular_covers")[#text("deck transformation")]#text(" of ")#mi("{M}")#text(" (viewed as a cover of ")#mi("{L}")#text(") is a continuous map ")#mi("{g: M \\leftarrow M}")#text(" (acting on the left) such that ")#metadata(none) <tao-90a0a1823cc085889807>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\pi_{L \\leftarrow M} g = \\pi_{L \\leftarrow M}.")]]

#text(" The space ")#mi("{\\mathrm{Aut}(M/L)}")#text(" of deck transformations is clearly a group that acts on the left on ")#mi("{M}")#text(". By working locally we see that deck transformations map lifts to lifts, thus one has the associativity-type law ")#metadata(none) <tao-0a228cdf0b44df30a354>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("(gp) \\gamma = g(p\\gamma)")]]

#text(" whenever ")#mi("{g \\in \\mathrm{Aut}(M/L)}")#text(", ")#mi("{p \\in M}")#text(", ")#mi("{\\gamma \\in \\Gamma}")#text(" are such that one of the two sides (and hence the other) is well-defined. Conversely, one can check that any map ")#mi("{g: M \\leftarrow M}")#text(" that obeys the two properties ")#link(<tao-90a0a1823cc085889807>)[#text("(2)")]#text(", ")#link(<tao-0a228cdf0b44df30a354>)[#text("(3)")]#text(" is a deck transformation (even without assuming continuity of ")#mi("{g}")#text("!). Hence one can in fact take ")#link(<tao-90a0a1823cc085889807>)[#text("(2)")]#text(", ")#link(<tao-0a228cdf0b44df30a354>)[#text("(3)")]#text(" to be the ")#emph[#text("definition")]#text(" of a deck transformation; all the topological structure is now concealed within the path groupoid ")#mi("{\\Gamma}")#text(" and its actions on ")#mi("{L}")#text(" and ")#mi("{M}")#text(".")

#text("One consequence of ")#link(<tao-0a228cdf0b44df30a354>)[#text("(3)")]#text(" is that the action ")#mi("{\\mathrm{Aut}(M/L)}")#text(" of this group is free: if ")#mi("{g \\in \\mathrm{Aut}(M/L)}")#text(" is such that ")#mi("{g p_0 = p_0}")#text(" for some point ")#mi("{p_0 \\in M}")#text(", then we also have ")#mi("{g p_0 \\gamma = p_0 \\gamma}")#text(" whenever ")#mi("{p_0 \\gamma}")#text(" makes sense, and hence by transitivity ")#mi("{gp = p}")#text(" for all ")#mi("{p \\in M}")#text(", so ")#mi("{g}")#text(" is the identity.")

#text("In particular, if ")#mi("{M}")#text(" is a degree ")#mi("{n}")#text(" cover of ")#mi("{L}")#text(" (so that all fibres ")#mi("{\\pi_{L \\leftarrow M}^{-1} r}")#text(" for ")#mi("{r \\in L}")#text(" have cardinality ")#mi("{n}")#text("), then the order of the group ")#mi("{\\mathrm{Aut}(M/L)}")#text(" cannot exceed ")#mi("{n}")#text(", since the orbit ")#mi("{\\mathrm{Aut}(M/L) p_0}")#text(" of any given point under this free action lies in a fibre of ")#mi("{M}")#text(" above ")#mi("{L}")#text(" and has the same cardinality as ")#mi("{\\mathrm{Aut}(M/L)}")#text(". If the order equals ")#mi("{n}")#text(", we say that the cover is a ")#emph[#text("Galois cover")]#text(", use ")#mi("{\\mathrm{Gal}(M/L)}")#text(" to denote the group ")#mi("{\\mathrm{Aut}(M/L)}")#text(", and conclude that the action of ")#mi("{\\mathrm{Gal}(M/L)}")#text(" is transitive on fibres. Thus, if ")#mi("{p_1, p_2 \\in M}")#text(" are such that ")#mi("{\\pi_{L \\leftarrow M} p_1 = \\pi_{L \\leftarrow M} p_2}")#text(", then there exists a unique ")#mi("{g \\in \\mathrm{Gal}(M/L)}")#text(" such that ")#mi("{g p_1 = p_2}")#text(".")

#text("We can now prove Theorem ")#link(<tao-7792aa5ae17d8e6b13a7>)[#text("4")]#text(". Let ")#mi("{L \\leftarrow M}")#text(" be a degree ")#mi("{n}")#text(" cover. Let ")#mi("{L \\leftarrow N \\leftarrow M}")#text(" be an intermediate cover between ")#mi("{N}")#text(" and ")#mi("{M}")#text(", and suppose that ")#mi("{M}")#text(" has degree ")#mi("{d}")#text(" over ")#mi("{N}")#text(". A fibre ")#mi("{\\pi_{L \\leftarrow M}^{-1} r}")#text(" of ")#mi("{M}")#text(" over ")#mi("{L}")#text(" has degree ")#mi("{n}")#text(", and splits into ")#mi("{n/d}")#text(" fibres ")#mi("{\\pi_{N \\leftarrow M}^{-1} q}")#text(" of ")#mi("{M}")#text(" over ")#mi("{N}")#text(", each of which has cardinality ")#mi("{d}")#text(" (so in particular ")#mi("{d}")#text(" divides ")#mi("{n}")#text("). Pick one of these fibres, and pick a point ")#mi("{p_0}")#text(" in it. By the above discussion, there are precisely ")#mi("{d}")#text(" elements ")#mi("{g}")#text(" of ")#mi("{\\mathrm{Gal}(M/L)}")#text(" such that ")#mi("{gp_0}")#text(" lies in the same fibre over ")#mi("{N}")#text(" as ")#mi("{p_0}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\pi_{N \\leftarrow M} g p_0 = \\pi_{N \\leftarrow M} p_0.")]]

#text("Applying paths in ")#mi("{\\Gamma}")#text(" on the right and using transitivity (and associativity), we conclude that ")#mi("{\\pi_{N \\leftarrow M} g = \\pi_{N \\leftarrow M}}")#text(", thus ")#mi("{g \\in \\mathrm{Aut}(M/N)}")#text(". As we have located ")#mi("{d}")#text(" elements of this group, this is in fact the entire group of automorphisms, so we conclude that ")#mi("{M}")#text(" is a Galois cover of ")#mi("{N}")#text(" and ")#mi("{\\mathrm{Gal}(M/N)}")#text(" is a subgroup of ")#mi("{\\mathrm{Gal}(M/L)}")#text(". This proves part (i) of the theorem.")

#text("A similar argument shows that if ")#mi("{L \\leftarrow N_1 \\leftarrow N_2 \\leftarrow M}")#text(" then ")#mi("{\\mathrm{Gal}(M/N_2)}")#text(" is a subgroup of ")#mi("{\\mathrm{Gal}(M/N_1)}")#text(". In particular, if ")#mi("{N_1}")#text(" and ")#mi("{N_2}")#text(" are equivalent then ")#mi("{\\mathrm{Gal}(M/N_1) = \\mathrm{Gal}(M/N_2)}")#text(". Conversely, suppose that ")#mi("{L \\leftarrow N_1 \\leftarrow M}")#text(" and ")#mi("{L \\leftarrow N_2 \\leftarrow M}")#text(" are such that ")#mi("{\\mathrm{Gal}(M/N_2)}")#text(" is a subgroup of ")#mi("{\\mathrm{Gal}(M/N_1)}")#text(". If ")#mi("{p_1, p_2 \\in M}")#text(" are such that ")#mi("{\\pi_{N_2 \\leftarrow M} p_1 = \\pi_{N_2 \\leftarrow M} p_2}")#text(", then by the Galois nature of ")#mi("{M}")#text(" over ")#mi("{N_2}")#text(" we can find ")#mi("{g \\in \\mathrm{Gal}(M/N_2)}")#text(" such that ")#mi("{gp_1 = p_2}")#text(". But then ")#mi("{g \\in \\mathrm{Gal}(M/N_1)}")#text(", hence ")#mi("{\\pi_{N_1 \\leftarrow M} p_1 = \\pi_{N_1 \\leftarrow M} p_2}")#text(". Thus we can factor ")#mi("{\\pi_{N_1 \\leftarrow M} = \\pi_{N_1 \\leftarrow N_2} \\pi_{N_2 \\leftarrow M}}")#text(" for some uniquely defined function ")#mi("{\\pi_{N_1 \\leftarrow N_2}: N_1 \\leftarrow N_2}")#text(". It is not hard to verify that ")#mi("{\\pi_{N_1 \\leftarrow N_2}}")#text(" is a finite covering map that is compatible with the existing covering maps, and hence ")#mi("{L \\leftarrow N_1 \\leftarrow N_2 \\leftarrow M}")#text(". This proves (iii). Reversing the roles of ")#mi("{N_1}")#text(" and ")#mi("{N_2}")#text(", we conclude in particular that if ")#mi("{\\mathrm{Gal}(M/N_1) = \\mathrm{Gal}(M/N_2)}")#text(" then ")#mi("{N_1}")#text(" and ")#mi("{N_2}")#text(" are equivalent. This gives the “unique up to equivalence” portion of (ii).")

#text("To finish the proof of (ii), let ")#mi("{H}")#text(" be a subgroup of ")#mi("{\\mathrm{Gal}(M/L)}")#text(", then we can define an equivalence relation ")#mi("{\\sim}")#text(" on ")#mi("{M}")#text(" by declaring ")#mi("{hp \\sim p}")#text(" for every ")#mi("{p \\in M}")#text(" and ")#mi("{h \\in \\mathrm{Gal}(M/L)}")#text(". If we set ")#mi("{N}")#text(" to be the quotient space ")#mi("{M/\\sim}")#text(" with the obvious quotient map ")#mi("{\\pi_{N \\leftarrow M}: N \\leftarrow M}")#text(", then one has ")#mi("{\\pi_{L \\leftarrow M} p_1 = \\pi_{L \\leftarrow M} p_2}")#text(" whenever ")#mi("{\\pi_{L \\leftarrow M} p_1 = \\pi_{L \\leftarrow M} p_2}")#text(" (which is equivalent to ")#mi("{p_1 \\sim p_2}")#text("). Thus we may factor")

#align(center)[#tao-fit-display[#mitex("\\pi_{L \\leftarrow M} = \\pi_{L \\leftarrow N} \\pi_{N \\leftarrow M}")]]

#text("for some unique map ")#mi("{\\pi_{L \\leftarrow N}: L \\leftarrow N}")#text(". One may easily verify that ")#mi("{\\pi_{L \\leftarrow N}, \\pi_{N \\leftarrow M}}")#text(" are both covering maps, so that we have ")#mi("{L \\leftarrow N \\leftarrow M}")#text(". To finish the proof of (Ii) we need to show that ")#mi("{\\mathrm{Gal}(M/N)=H}")#text(". Unpacking the definitions, our goal is to show that ")#mi("{H}")#text(" is the set of all ")#mi("{g \\in \\mathrm{Gal}(G/L)}")#text(" such that ")#mi("{gp \\sim p}")#text(" for all ")#mi("{p \\in M}")#text(". Clearly if ")#mi("{h \\in H}")#text(" then ")#mi("{hp \\sim p}")#text(" for all ")#mi("{p \\in M}")#text(". Conversely, suppose that ")#mi("{g \\in \\mathrm{Gal}(M/L)}")#text(" is such that ")#mi("{gp \\sim p}")#text(" for all ")#mi("{p \\in M}")#text(". In particular, if one fixed a point ")#mi("{p_0 \\in M}")#text(", then ")#mi("{gp_0 = hp_0}")#text(" for some ")#mi("{h \\in H}")#text(". This implies that ")#mi("{gp_0 \\gamma = h p_0 \\gamma}")#text(" for all ")#mi("{\\gamma \\in \\Gamma}")#text("; but the action of ")#mi("{\\Gamma}")#text(" on ")#mi("{M}")#text(" is transitive, and hence ")#mi("{g=h}")#text(", giving the claim.")

#text("Finally, we prove (iv). By parts (i), (ii), we may assume without loss of generality that ")#mi("{N = M/\\sim}")#text(", where ")#mi("{p \\sim p^{\\prime}}")#text(" if ")#mi("{hp = p^{\\prime}}")#text(" for some ")#mi("{h \\in \\mathrm{Gal}(M/N)}")#text(".")

#text("First suppose that ")#mi("{\\mathrm{Gal}(M/N)}")#text(" is a normal subgroup of ")#mi("{\\mathrm{Gal}(M/L)}")#text(". Then ")#mi("{p \\sim p^{\\prime}}")#text(" implies ")#mi("{gp \\sim gp^{\\prime}}")#text(" whenever ")#mi("{p,p^{\\prime} \\in M}")#text(" and ")#mi("{g \\in \\mathrm{Gal}(M/L)}")#text(". Thus the action of ")#mi("{\\mathrm{Gal}(M/L)}")#text(" on ")#mi("{M}")#text(" descends to that of ")#mi("{N}")#text("; since the former is transitive on fibres above ")#mi("{L}")#text(", so is the latter. Hence ")#mi("{N}")#text(" is a Galois extension of ")#mi("{L}")#text(". Conversely, suppose that ")#mi("{N}")#text(" is Galois. Then for any ")#mi("{p \\in M}")#text(" and ")#mi("{g \\in \\mathrm{Gal}(M/L)}")#text(", there must exist ")#mi("{h \\in \\mathrm{Gal}(N/L)}")#text(" such that ")#mi("{h \\pi_{N \\leftarrow M} p = \\pi_{N \\leftarrow M} gp}")#text(". Since the right action of ")#mi("{\\Gamma}")#text(" on ")#mi("{N}")#text(" is transitive, ")#mi("{h}")#text(" does not actually depend on ")#mi("{p}")#text(", and is uniquely specified by ")#mi("{g}")#text(". Replacing ")#mi("{p}")#text(" by ")#mi("{g^{\\prime} p}")#text(" for any ")#mi("{g^{\\prime} \\in \\mathrm{Aut}(M/N)}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("h \\pi_{N \\leftarrow M} g^{\\prime}p = \\pi_{N \\leftarrow M} gg^{\\prime} p,")]]

#text("but ")#mi("{\\pi_{N \\leftarrow M} g^{\\prime}=\\pi_{N \\leftarrow M}}")#text(", hence")

#align(center)[#tao-fit-display[#mitex("\\pi_{N \\leftarrow M} gp = \\pi_{N \\leftarrow M} gg^{\\prime} p,")]]

#text("or equivalently ")#mi("{g p \\sim gg^{\\prime} p}")#text(". This implies that ")#mi("{gg^{\\prime}g^{-1} \\in \\mathrm{Gal}(M/N)}")#text(", thus ")#mi("{\\mathrm{Gal}(M/N)}")#text(" is preserved by conjugation by arbitrary elements ")#mi("{g}")#text(" of ")#mi("{\\mathrm{Gal}(M/L)}")#text(". In other words, ")#mi("{\\mathrm{Gal}(M/N)}")#text(" is a normal subgroup. The map ")#mi("{g \\mapsto h}")#text(" described here can easily be verified to be a homomorphism from ")#mi("{\\mathrm{Gal}(M/L)}")#text(" to ")#mi("{\\mathrm{Gal}(M/N)}")#text(" with kernel ")#mi("{\\mathrm{Gal}(N/L)}")#text(", so the claim (iv) follows from the first isomorphism theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" Let ")#mi("{B \\leftarrow M}")#text(" be a Galois cover, let ")#mi("{b}")#text(" be a point in the base ")#mi("{B}")#text(", and let ")#mi("{p_0}")#text(" be a point in the fibre ")#mi("{\\pi_{B \\leftarrow M}^{-1} b}")#text(". For any loop ")#mi("{\\gamma \\in \\Gamma}")#text(" starting and ending at ")#mi("{b}")#text(" (so that ")#mi("{b \\gamma = b}")#text(", the point ")#mi("{p_0 \\gamma}")#text(" lies in the same fibre ")#mi("{\\pi_{B \\leftarrow M}^{-1} b}")#text(" of ")#mi("{M}")#text(" as ")#mi("{p_0}")#text(", hence by the Galois nature of the cover there is a unique ")#mi("{g \\in \\mathrm{Gal}(M/B)}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("g p_0 = p_0 \\gamma.")]]

#text("It is easy to see that homotopic deformations of ")#mi("{\\gamma}")#text(" (preserving the initial and final point ")#mi("{b}")#text(") do not affect the value of ")#mi("{g}")#text(". Thus, we have constructed a map ")#mi("{[\\gamma] \\mapsto g_{[\\gamma]}}")#text(" from the fundamental group ")#mi("{\\pi_1(B,b)}")#text(" of ")#mi("{B}")#text(" at ")#mi("{b}")#text(" to the Galois group ")#mi("{\\mathrm{Gal}(M/B)}")#text(", such that ")#metadata(none) <tao-ce552f91e9dc79133d2c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("g_{[\\gamma]} p_0 = p_0 \\gamma.")]]

#text(" As ")#mi("{M}")#text(" is connected, we see that this map is surjective. From ")#link(<tao-ce552f91e9dc79133d2c>)[#text("(4)")]#text(" and the fact that that ")#mi("{\\mathrm{Gal}(M/B)}")#text(" acts freely on ")#mi("{M}")#text(") we also see that the map is a homomorphism. (In many texts, the notation is set up so that this correspondence is an ")#link("https://en.wikipedia.org/wiki/Antihomomorphism")[#text("antihomomorphism")]#text(" rather than a homomorphism; we have avoided this by making the paths act on the right and the deck transformations act on the left, thus implicitly introducing an order reversal when identifying the two.) Thus we see that the Galois group ")#mi("{\\mathrm{Gal}(M/B)}")#text(" is isomorphic to a quotient of the fundamental group ")#mi("{\\pi_1(B,b)}")#text(". However, this isomorphism is not canonical, even if one fixes the base point ")#mi("{b}")#text(", because it depends on ")#mi("{p_0}")#text("! If one replaces ")#mi("{p_0}")#text(" by another point ")#mi("{p^{\\prime}_0 = h p_0}")#text(" in the same fibre for some ")#mi("{h \\in \\mathrm{Gal}(M/B)}")#text(", then the associated map ")#mi("{[\\gamma] \\mapsto g^{\\prime}_{[\\gamma]}}")#text(", defined by")

#align(center)[#tao-fit-display[#mitex("g^{\\prime}_{[\\gamma]} p^{\\prime}_0 = p^{\\prime}_0 \\gamma,")]]

#text("has to be conjugate to ")#mi("{g_{[\\gamma]}}")#text(" in order to remain compatible with ")#link(<tao-ce552f91e9dc79133d2c>)[#text("(4)")]#text(":")

#align(center)[#tao-fit-display[#mitex("g^{\\prime}_{[\\gamma]} = h g_{[\\gamma]} h^{-1}.")]]

#text("Thus, if one does not specify the reference point ")#mi("{p_0}")#text(" in the covering space ")#mi("{M}")#text(", the identification of ")#mi("{\\mathrm{Gal}(M/B)}")#text(" with a quotient of ")#mi("{\\pi_1(B,b)}")#text(" is only unique up to conjugation. Thus the relationship between fundamental groups and Galois groups are a little subtle, requiring one to be aware of what base points have been selected, unless one is willing to just work up to conjugacy. (See also the above-mentioned ")#link("https://mathoverflow.net/a/24068/766")[#text("post of Kim")]#text(" for some further discussion of this point.)")
]

#heading(level: 1)[#strong[#text(" — 3. Extensions of fields — ")]]

#text("We can now give an analogous treatment of the Galois correspondence for finite extensions of fields.")

#text("In this setting, we will take the base space ")#mi("{B}")#text(" to be the category of integral domains (with morphisms now interpreted as “paths”). Thus, points ")#mi("{b}")#text(" in this space are integral domains, and the paths in this space are ")#link("https://en.wikipedia.org/wiki/Ring_homomorphism")[#text("ring homomorphisms")]#text(" ")#mi("{\\gamma: b_1 \\rightarrow b_2}")#text(" from one integral domain to another, which we will think of as functions acting on the right, in particular the composition of ")#mi("{\\gamma_1: b_1 \\rightarrow b_2}")#text(" and ")#mi("{\\gamma_2: b_2 \\rightarrow b_3}")#text(" will be denoted ")#mi("{\\gamma_1 \\gamma_2}")#text(" (rather than the more traditional ")#mi("{\\gamma_2 \\circ \\gamma_1}")#text("). As before, we use the notation ")#mi("{b_1 \\gamma = b_2}")#text(" to denote the assertion that ")#mi("{\\gamma}")#text(" is a ring homomorphism from ")#mi("{b_1}")#text(" to ")#mi("{b_2}")#text(", so in particular we have the associativity type law")

#align(center)[#tao-fit-display[#mitex("(b \\gamma_1) \\gamma_2 = b (\\gamma_1 \\gamma_2)")]]

#text("whenever either side is well-defined. As previously mentioned, we will ignore all set-theoretic issues caused by the fact that ")#mi("{B}")#text(" is a proper class rather than a set, and similarly for the covers of ")#mi("{B}")#text(" introduced below. We let ")#mi("{\\Gamma}")#text(" denote the collection of all ring homomorphisms ")#mi("{\\gamma: b_1 \\rightarrow b_2}")#text(" connecting points in ")#mi("{B}")#text(". This is analogous to the space of collections of paths in the base manifold ")#mi("{B}")#text(" in the covering space context. Oen caveat however is that while paths in manifolds always have inverses, the same is not true in ")#mi("{B}")#text(", because not every ring homomorphism between integral domains is invertible. This complicates the situation somewhat compared to the covering space case, but it turns out that the additional level of complication is manageable.")

#text("Given a field ")#mi("{k}")#text(", we define an associated space ")#mi("{M_k}")#text(", whose points ")#mi("{p}")#text(" are ring homomorphisms ")#mi("{p: k \\rightarrow b}")#text(" to some ring ")#mi("{b \\in B}")#text(", where we view these homomorphism as acting on the right. There is an obvious map ")#mi("{\\pi_{B \\leftarrow M_k}: B \\leftarrow M_k}")#text(" (viewed as a function acting on the left) that maps a ring homomorphism ")#mi("{p: k \\rightarrow b}")#text(" to its codomain ")#mi("{b}")#text(". If ")#mi("{p \\in M_k, \\gamma \\in \\Gamma}")#text(", ")#mi("{b_1, b_2 \\in B}")#text(" are such that ")#mi("{\\pi_{B \\leftarrow M_k} p = b_1}")#text(" and ")#mi("{b_1 \\gamma = b_2}")#text(", then the composition ")#mi("{p \\gamma}")#text(" is a ring homomorphism from ")#mi("{k}")#text(" to ")#mi("{b_2}")#text(" and is thus also an element of ")#mi("{M_k}")#text(". Thus ")#mi("{\\Gamma}")#text(" acts on the right on ")#mi("{M_k}")#text(" in the sense that")

#align(center)[#tao-fit-display[#mitex("(p \\gamma_1) \\gamma_2 = p (\\gamma_1 \\gamma_2)")]]

#text("whenever either side is well-defined, and the action is compatible with the base ")#mi("{B}")#text(" in the sense that")

#align(center)[#tao-fit-display[#mitex("\\pi_{B \\leftarrow M_k} (p \\gamma) = (\\pi_{B \\leftarrow M_k} p) \\gamma")]]

#text("whenever either side is well-defined.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 10")]#text(" One can define ")#mi("{M_R}")#text(" for any commutative ring ")#mi("{R}")#text(" in the same fashion. If one takes ")#mi("{R}")#text(" to be the integers ")#mi("{{\\bf Z}}")#text(", then ")#mi("{M_{\\bf Z}}")#text(" is in one-to-one correspondence with ")#mi("{B}")#text(", since for every integral domain ")#mi("{b}")#text(" there is a unique ring homomorphism from ")#mi("{{\\bf Z}}")#text(" to ")#mi("{b}")#text(". Thus we are really thinking of all our spaces ")#mi("{M_k}")#text(" as being covers of ")#mi("{M_{\\bf Z}}")#text(". In the usual scheme-theoretic language, one views the schemes ")#mi("{\\mathrm{Spec}(k)}")#text(" as lying above the base scheme ")#mi("{\\mathrm{Spec}({\\bf Z})}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 11")]#text(" The ")#link("https://en.wikipedia.org/wiki/Characteristic_(algebra)")[#text("characteristic")]#text(" of the field ")#mi("{k}")#text(" naturally restricts the base points ")#mi("{b}")#text(" that ")#mi("{M_k}")#text(" actually lies above. For instance, if ")#mi("{k}")#text(" has characteristic zero, then points ")#mi("{p: k \\rightarrow b}")#text(" of ")#mi("{M_k}")#text(" only lie above those base points ")#mi("{b \\in B}")#text(" for which the unit ")#mi("{1_b}")#text(" of ")#mi("{b}")#text(" has infinite order; similarly, if ")#mi("{k}")#text(" has a positive characteristic ")#mi("{q}")#text(", then points of ")#mi("{M_k}")#text(" only lie above base points ")#mi("{b \\in B}")#text(" for which the unit of ")#mi("{b}")#text(" has order ")#mi("{q}")#text(". This helps explain why fields of different characteristic seem to inhabit “different worlds” – they lie above disjoint (and disconnected) portions of the base space ")#mi("{B}")#text("! However, we will not exploit the field characteristic in this post.")
]

#text("As mentioned in the introduction, each space ")#mi("{M_k}")#text(" has a distinguished point ")#mi("{p_k}")#text(", which is the identity map on ")#mi("{k}")#text(" and is the representative in this formalism of ")#mi("{\\mathrm{Spec}(k)}")#text(". This point makes ")#mi("{M_k}")#text(" is “directionally connected” in the following sense: every other point ")#mi("{p: k \\rightarrow b}")#text(" in ")#mi("{M_k}")#text(" is connected to ")#mi("{p}")#text(" by a path ")#mi("{\\gamma \\in \\Gamma}")#text(" in the sense that ")#mi("{p = p_k \\gamma}")#text(". Indeed, one just takes ")#mi("{\\gamma: k \\rightarrow b}")#text(" to be precisely the same homomorphism as ")#mi("{p}")#text(". (More generally, in every commutative ring ")#mi("{R}")#text(", every point ")#mi("{p: R \\rightarrow b}")#text(" of ")#mi("{M_R}")#text(" will be connected via a path from a point in ")#mi("{\\mathrm{Spec}(R)}")#text(", namely the kernel of ")#mi("{p}")#text(" which is necessarily a prime ideal since ")#mi("{b}")#text(" is an integral domain. I like to think of ")#mi("{M_R}")#text(" as a sort of “penumbra” lurking around the much smaller set ")#mi("{\\mathrm{Spec}(R)}")#text(".) However, the connectedness does not flow the other way: not every point ")#mi("{p: k \\rightarrow b}")#text(" in ")#mi("{M_k}")#text(" is connected back to ")#mi("{p_k}")#text(" by a path, because paths need not be invertible. (For instance, if ")#mi("{p}")#text(" is an embedding of ")#mi("{k}")#text(" into a larger field ")#mi("{E}")#text(", there is no way to map ")#mi("{E}")#text(" back into ")#mi("{k}")#text(" by a ring homomorphism while preserving ")#mi("{k}")#text(", as homomorphisms of fields have to be injective.)")

#text("Suppose we have a finite extension ")#mi("{k \\hookrightarrow E}")#text(" of fields, then the inclusion map ")#mi("{\\pi_{k \\hookrightarrow E}: k \\rightarrow E}")#text(", viewed as a function acting on the right, is a ring homomorphism. As such, it also can be viewed as a map from ")#mi("{M_E}")#text(" to ")#mi("{M_k}")#text(": any point ")#mi("{p: E \\rightarrow b}")#text(" of ")#mi("{M_E}")#text(", when composed with ")#mi("{\\pi_{k \\hookrightarrow E}}")#text(", gives rise to a point ")#mi("{\\pi_{k \\hookrightarrow E} p: k \\rightarrow b}")#text(" of ")#mi("{M_k}")#text(". We relabel this composition map as ")#mi("{\\pi_{M_k \\leftarrow M_E}: M_k \\leftarrow M_E}")#text(" (now viewed as a function acting on the left), thus")

#align(center)[#tao-fit-display[#mitex("\\pi_{M_k \\leftarrow M_E} p = \\pi_{k \\hookrightarrow E} p")]]

#text("for all ")#mi("{p \\in M_K}")#text(". By construction we see that")

#align(center)[#tao-fit-display[#mitex("\\pi_{B \\leftarrow M_k} \\pi_{M_k \\leftarrow M_E} = \\pi_{B \\leftarrow M_E}")]]

#text("and similarly for any nested sequence ")#mi("{k \\hookrightarrow F \\hookrightarrow E}")#text(" of fields one has")

#align(center)[#tao-fit-display[#mitex("\\pi_{M_k \\leftarrow M_F} \\pi_{M_F \\leftarrow M_E} = \\pi_{M_k \\leftarrow M_E}.")]]

#text("Now let us look at the fibres of ")#mi("{M_E}")#text(" above ")#mi("{M_k}")#text(". We need the following basic result, which relates the degree of the field extension ")#mi("{k \\hookrightarrow E}")#text(" to the degree of the cover ")#mi("{M_E \\hookrightarrow M_k}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 12")]#text(" ")#metadata(none) <tao-4c3b3284e206c3db7244>#text(" Let ")#mi("{E}")#text(" be a degree ")#mi("{n}")#text(" extension of a field ")#mi("{k}")#text(". Then every fibre ")#mi("{\\pi_{k \\hookrightarrow E}^{-1}(q)}")#text(" in ")#mi("{M_E}")#text(" of a point ")#mi("{q}")#text(" in ")#mi("{M_k}")#text(" has cardinality at most ")#mi("{n}")#text(".")
]

#emph[#text("Proof:")]#text(" Unpacking all the definitions, we are asking to show that every ring homomorphism ")#mi("{q: k \\rightarrow b}")#text(" into an integral domain ")#mi("{b}")#text(" has at most ")#mi("{n}")#text(" extensions to a ring homomorphism ")#mi("{p: E \\rightarrow b}")#text(".")

#text("We induct on ")#mi("{n}")#text(". If ")#mi("{n=1}")#text(" the claim is trivial, so suppose ")#mi("{n > 1}")#text(" and the claim has already been proven for smaller values of ")#mi("{n}")#text(". Then ")#mi("{E}")#text(" is larger than ")#mi("{k}")#text(", so we may find an element ")#mi("{\\alpha}")#text(" that lies in ")#mi("{E}")#text(" but not ")#mi("{k}")#text(". Let ")#mi("{m}")#text(" be the degree of ")#mi("{\\alpha}")#text(", thus ")#mi("{m>1}")#text(", ")#mi("{k(\\alpha)}")#text(" is a degree ")#mi("{m}")#text(" extension of ")#mi("{k}")#text(" and ")#mi("{E}")#text(" is a degree ")#mi("{n/m}")#text(" extension of ")#mi("{k(\\alpha)}")#text(" (in particular, ")#mi("{m}")#text(" divides ")#mi("{n}")#text("). By induction hypothesis, every ring homomorphism on ")#mi("{k(\\alpha)}")#text(" has at most ")#mi("{n/m}")#text(" extensions to ")#mi("{E}")#text(", so it suffices to show that ")#mi("{q: k \\rightarrow b}")#text(" has at most ")#mi("{m}")#text(" extensions to ")#mi("{k(\\alpha)}")#text(".")

#text("Let ")#mi("{P}")#text(" be the minimal polynomial of ")#mi("{\\alpha}")#text(" with coefficients in ")#mi("{k}")#text(", thus ")#mi("{P}")#text(" is monic with degree ")#mi("{m}")#text(", and ")#mi("{P(\\alpha) = 0}")#text(". Any extension ")#mi("{\\tilde q: k(\\alpha) \\rightarrow b}")#text(" of ")#mi("{q}")#text(" to ")#mi("{k(\\alpha)}")#text(" must obey the law ")#mi("{P_q( \\tilde q(\\alpha) ) = 0}")#text(", where ")#mi("{P_q}")#text(" is the monic polynomial of degree ")#mi("{m}")#text(" with coefficients in ")#mi("{b}")#text(" formed by applying ")#mi("{q}")#text(" to each coefficient of ")#mi("{P}")#text(". As ")#mi("{q}")#text(" is an integral domain, ")#mi("{P_q}")#text(" has at most ")#mi("{m}")#text(" roots. Thus there are at most ")#mi("{m}")#text(" possible values of ")#mi("{\\tilde q(\\alpha)}")#text("; since ")#mi("{\\tilde q}")#text(" is completely determined by ")#mi("{q}")#text(" and ")#mi("{\\tilde q(\\alpha)}")#text(", we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 13")]#text(" Let ")#mi("{k = {\\bf C}(z)}")#text(" and ")#mi("{E = {\\bf C}(w)}")#text(" be the fields from Example ")#link(<tao-92405acbf8cacadf91cd>)[#text("3")]#text(". The inclusion map ")#mi("{q: k \\rightarrow E}")#text(" is a point in ")#mi("{M_k}")#text(". The fibre ")#mi("{\\pi_{k \\hookrightarrow E}^{-1}(q)}")#text(" consists of ")#mi("{n}")#text(" points ")#mi("{p_0,\\dots,p_{n-1}}")#text(", with ")#mi("{p_a: E \\rightarrow E}")#text(" being the field automorphism of ")#mi("{E}")#text(" that sends ")#mi("{w}")#text(" to ")#mi("{e^{2\\pi i a/w}}")#text(" (in particular, ")#mi("{p_0}")#text(" is the distinguished point ")#mi("{p_E}")#text(" of ")#mi("{E}")#text("). In contrast, the distinguished point ")#mi("{p_k: k \\rightarrow k}")#text(" of ")#mi("{M_k}")#text(" has empty fibre ")#mi("{\\pi_{k \\hookrightarrow E}^{-1}(p_k)}")#text(", since there is no ring homomorphism from ")#mi("{E}")#text(" to ")#mi("{k}")#text(" that fixes ")#mi("{k}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 14")]#text(" If two points ")#mi("{q_1, q_2}")#text(" in ")#mi("{M_k}")#text(" are connected by an invertible path ")#mi("{\\gamma}")#text(", thus ")#mi("{q_1 \\gamma = q_2}")#text(" and ")#mi("{q_2 \\gamma^{-1} = q_1}")#text(", then it is easy to see that ")#mi("{\\gamma}")#text(" induces a one-to-one correspondence between the fibre ")#mi("{\\pi_{k \\hookrightarrow E}^{-1}(q_1)}")#text(" and the fibre ")#mi("{\\pi_{k \\hookrightarrow E}^{-1}(q_2)}")#text("; in particular, the two have the same cardinality. However, in contrast to the situation with covering spaces, not all paths are invertible, and so the cardinality of a fibre ")#mi("{\\pi_{k \\hookrightarrow E}^{-1}(q)}")#text(" can vary with the base ")#mi("{q}")#text(", as can already be seen in the preceding example. However the situation is better for Galois extensions, as we shall shortly see, in which all non-empty fibres are isomorphic.")
]

#text("We continue analysing a field extension ")#mi("{k \\hookrightarrow E}")#text(", viewing ")#mi("{M_E}")#text(" as analogous to a covering space for ")#mi("{M_k}")#text(". By analogy with covering spaces, we could define a “deck transformation” of ")#mi("{M_E}")#text(" over ")#mi("{M_k}")#text(" to be a map ")#mi("{g: M_k \\rightarrow M_k}")#text(" (acting on the left) such that ")#metadata(none) <tao-3c55c04d8248d3b78c3a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\pi_{M_k \\leftarrow M_E} g = \\pi_{M_k \\leftarrow M_E}")]]

#text(" and such that ")#metadata(none) <tao-6858a423dc9e04f67929>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("(gp) \\gamma = g (p\\gamma)")]]

#text(" whenever ")#mi("{p \\in M_E}")#text(", ")#mi("{\\gamma \\in \\Gamma}")#text(" are such that one side (and hence the other) of the above equation is well-defined. Let us see what a deck transformation actually is. If we apply ")#mi("{g}")#text(" to the distinguished point ")#mi("{p_E: E \\rightarrow E}")#text(" of ")#mi("{M_E}")#text(", we obtain a ring homomorphism ")#mi("{gp_E: E \\rightarrow E}")#text(". From ")#link(<tao-3c55c04d8248d3b78c3a>)[#text("(5)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\pi_{M_k \\leftarrow M_E} g p_E = \\pi_{M_k \\leftarrow M_E} p_E")]]

#text("which on chasing definitions means that ")#mi("{gp_E}")#text(" is the identity on ")#mi("{k}")#text(". Thus ")#mi("{gp_E: E \\rightarrow E}")#text(" is a ")#mi("{k}")#text("-linear map; it also preserves ")#mi("{1}")#text(", so it has trivial kernel and is thus injective. As ")#mi("{E}")#text(" is finite dimensional over ")#mi("{k}")#text(", it is also surjective; hence ")#mi("{gp_E}")#text(" is in fact a field automorphism of ")#mi("{E}")#text(" that fixes ")#mi("{k}")#text(". The action of ")#mi("{g}")#text(" on any other point ")#mi("{p: E \\rightarrow b}")#text(" of ")#mi("{M_E}")#text(" can then be computed by writing ")#mi("{p = p_E \\gamma}")#text(" where ")#mi("{\\gamma=p}")#text(" is the path connecting ")#mi("{p_E}")#text(" to ")#mi("{\\gamma}")#text(" and using ")#link(<tao-6858a423dc9e04f67929>)[#text("(6)")]#text(" to conclude that ")#mi("{gp = (gp_E) \\gamma}")#text(". Conversely, given any field automorphism ")#mi("{\\phi: E \\rightarrow E}")#text(" that fixes ")#mi("{k}")#text(", one can generate a deck transformation ")#mi("{g}")#text(" by setting ")#mi("{gp = \\phi p}")#text(" for all ring homomorphisms ")#mi("{p: E \\rightarrow b}")#text("; by chasing definitions one verifies that this is a deck transformation. Thus we have a one-to-one correspondence between deck transformations and field automorphisms of ")#mi("{E}")#text(" fixing ")#mi("{k}")#text(". (This correspondence feels reminiscent of the ")#link("https://en.wikipedia.org/wiki/Yoneda_lemma")[#text("Yoneda lemma")]#text(", though I was not able to find a direct link between the two.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" Show that the correspondence between deck transformations and field automorphisms given above is a group isomorphism. (When functions are expressed in more traditional language, this correspondence is an ")#link("https://en.wikipedia.org/wiki/Antiisomorphism")[#text("antiisomorphism")]#text(" rather than an isomorphism. We are able to avoid this reversal of order by making deck transformations act on the left and field automorphisms act on the right.)")
]

#text("One consequence of the above correspondence is that the space ")#mi("{\\mathrm{Aut}(M_E/M_k)}")#text(" of deck transformations of ")#mi("{M_E}")#text(" over ")#mi("{M_k}")#text(" is in one-to-one correspondence with the group ")#mi("{\\mathrm{Aut}(E/k)}")#text(" of field automorphisms of ")#mi("{E}")#text(" fixing ")#mi("{k}")#text(". If ")#mi("{k \\hookrightarrow F \\hookrightarrow E}")#text(" is an intermediate field, then certainly any deck transformation of ")#mi("{M_E}")#text(" over ")#mi("{M_F}")#text(" is also a deck transformation of ")#mi("{M_E}")#text(" over ")#mi("{M_k}")#text(", so ")#mi("{\\mathrm{Aut}(M_E/M_F)}")#text(" is a subgroup of ")#mi("{\\mathrm{Aut}(M_E/M_k)}")#text(".")

#text("From the above discussion, we see that a deck transformation of ")#mi("{M_E}")#text(" over ")#mi("{M_k}")#text(" is completely determined by its action on the distinguished point ")#mi("{p_E}")#text(". In particular, the action of ")#mi("{\\mathrm{Aut}(M_E/M_k)}")#text(" is free on the distinguished point ")#mi("{p_E}")#text(" of ")#mi("{M_E}")#text(" in the sense that the points ")#mi("{g p_E}")#text(" for ")#mi("{g \\in \\mathrm{Aut}(M_E/M_k)}")#text(" are all distinct. As they also lie in the same fibre of ")#mi("{p_E}")#text(" above ")#mi("{M_k}")#text(", we conclude from Proposition ")#link(<tao-4c3b3284e206c3db7244>)[#text("12")]#text(" that the order of ")#mi("{\\mathrm{Aut}(M_E/M_k)}")#text(" cannot exceed the degree of the extension: ")#metadata(none) <tao-16a0a2e664cff4e61bb4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left|\\mathrm{Aut}(M_E/M_k)\\right| \\leq [E:k].", block: true)]]



#text("As stated in the introduction, we call ")#mi("{E}")#text(" a Galois extension of ")#mi("{k}")#text(" if we in fact have equality")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathrm{Aut}(M_E/M_k)\\right| = [E:k],", block: true)]]

#text("and then we rename ")#mi("{\\mathrm{Aut}(M_E/M_k)}")#text(" as ")#mi("{\\mathrm{Gal}(M_E/M_k)}")#text(". This is canonically equivalent to the usual Galois group ")#mi("{\\mathrm{Gal}(E/k)}")#text(" over fields. Thus, if ")#mi("{E}")#text(" is a degree ")#mi("{n}")#text(" Galois extension of ")#mi("{k}")#text(", then implies that the fibre containing ")#mi("{p_E}")#text(" above ")#mi("{M_k}")#text(" must have cardinality exactly ")#mi("{n}")#text(", with ")#mi("{\\mathrm{Gal}(M_E/M_k)}")#text(" acting freely and transitively on this fibre. In fact the same is true for every non-empty fibre:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 16")]#text(" ")#metadata(none) <tao-2a6f8f7aa6e5ca1ce062>#text(" Let ")#mi("{E}")#text(" be a degree ")#mi("{n}")#text(" Galois extension of ")#mi("{k}")#text(", and let ")#mi("{p: E \\rightarrow b}")#text(" be a point in ")#mi("{M_E}")#text(". Then the fibre ")#mi("{\\pi_{M_k \\leftarrow M_E}^{-1}(\\pi_{M_k \\leftarrow M_E} p)}")#text(" containing ")#mi("{p}")#text(" above ")#mi("{M_k}")#text(" has cardinality exactly ")#mi("{n}")#text(", and ")#mi("{\\mathrm{Gal}(M_E/M_k)}")#text(" acts freely and transitively on this fibre. In other words, whenever ")#mi("{p,p^{\\prime} \\in M_E}")#text(" are such that ")#mi("{\\pi_{M_k \\leftarrow M_E} p = \\pi_{M_k \\leftarrow M_E} p^{\\prime}}")#text(", then there is a unique ")#mi("{g \\in \\mathrm{Gal}(M_E/M_k)}")#text(" such that ")#mi("{g p = p^{\\prime}}")#text(".")
]

#emph[#text("Proof:")]#text(" As ")#mi("{E}")#text(" is a field and ")#mi("{b}")#text(" is an integral domain, the ring homomorphism ")#mi("{p: E \\rightarrow b}")#text(" must be injective (it maps invertible elements to invertible elements, and hence maps non-zero elements to non-zero elements). Each Galois group element ")#mi("{g \\in \\mathrm{Gal}(M_E/M_k)}")#text(" corresponds to a different field automorphism of ")#mi("{E}")#text(", hence the ")#mi("{n}")#text(" homomorphisms ")#mi("{gp: E \\rightarrow b}")#text(", ")#mi("{g \\in \\mathrm{Gal}(M_E/M_k)}")#text(" are all distinct. This produces ")#mi("{n}")#text(" distinct elements of the fibre of ")#mi("{p}")#text("; by Proposition ")#link(<tao-4c3b3284e206c3db7244>)[#text("12")]#text(" this is the entire fibre. The claim follows. ")#mi("\\Box")

#text("Thanks to this lemma, we see that ")#mi("{M_E}")#text(" behaves like a degree ")#mi("{n}")#text(" covering map on some subset of ")#mi("{M_k}")#text(" (the space of ring homomorphisms ")#mi("{p: k \\rightarrow b}")#text(" for which ")#mi("{b}")#text(" is “large enough” that there is at least one extension of ")#mi("{p}")#text(" to ")#mi("{E}")#text(").")

#text("We can now prove part (i) of Theorem ")#link(<tao-01b51c659dc0dcdab860>)[#text("1")]#text(", in analogy with the covering space theory argument:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 17")]#text(" ")#metadata(none) <tao-57cda594148cb40cfa28>#text(" If ")#mi("{E}")#text(" is a Galois extension of ")#mi("{k}")#text(", and ")#mi("{k \\hookleftarrow F \\hookleftarrow E}")#text(" is an intermediate field, then ")#mi("{E}")#text(" is a Galois extension of ")#mi("{F}")#text(".")
]

#text("Note that we have already demonstrated that ")#mi("{\\mathrm{Aut}(E/F)}")#text(" is a subgroup of ")#mi("{\\mathrm{Aut}(E/k)}")#text(", so this proposition completes the proof of Theorem ")#link(<tao-01b51c659dc0dcdab860>)[#text("1")]#text("(i).")

#emph[#text("Proof:")]#text(" Let ")#mi("{n}")#text(" denote the degree of ")#mi("{E}")#text(" over ")#mi("{k}")#text(", and ")#mi("{m}")#text(" the degree of ")#mi("{F}")#text(" over ")#mi("{k}")#text(", thus ")#mi("{E}")#text(" is a degree ")#mi("{n/m}")#text(" extension of ")#mi("{F}")#text(". Consider a non-empty fibre of ")#mi("{M_E}")#text(" above ")#mi("{M_k}")#text(". By Lemma ")#link(<tao-2a6f8f7aa6e5ca1ce062>)[#text("16")]#text(", this fibre consists of ")#mi("{n}")#text(" points. It also can be decomposed into fibres of ")#mi("{M_E}")#text(" above ")#mi("{M_F}")#text(", indexed by a fibre of ")#mi("{M_F}")#text(" above ")#mi("{M_k}")#text(". By Lemma ")#link(<tao-2a6f8f7aa6e5ca1ce062>)[#text("16")]#text(", the latter fibre consists of ")#mi("{m}")#text(" points, while by Proposition ")#link(<tao-4c3b3284e206c3db7244>)[#text("12")]#text(", the former fibres all have cardinality at most ")#mi("{n/m}")#text(". Hence all the former fibres must have cardinality exactly ")#mi("{n/m}")#text(". In particular, the fibre of ")#mi("{p_E}")#text(" above ")#mi("{M_F}")#text(" has cardinality ")#mi("{n/m}")#text(". This fibre consists of those ring homomorphisms ")#mi("{p: E \\rightarrow E}")#text(" that fix ")#mi("{F}")#text(". As discussed previously, these ring homomorphisms must be field automorphisms, and thus generate elements of ")#mi("{\\mathrm{Aut}(E/F)}")#text(" (or ")#mi("{\\mathrm{Aut}(M_E/M_F)}")#text(". Thus ")#mi("{\\mathrm{Aut}(M_E/M_F)}")#text(" has cardinality at least ")#mi("{n/m}")#text(", and hence by ")#link(<tao-16a0a2e664cff4e61bb4>)[#text("(7)")]#text(" it has cardinality exactly ")#mi("{n/m}")#text(". Thus ")#mi("{E}")#text(" is a Galois extension of ")#mi("{F}")#text(" as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 18")]#text(" ")#metadata(none) <tao-f642974cfcb13951bb7d>#text(" If ")#mi("{k \\hookrightarrow F \\hookrightarrow E}")#text(", then ")#mi("{F = E^{\\mathrm{Gal}(E/F)}}")#text(".")
]

#emph[#text("Proof:")]#text(" By definition, every element of ")#mi("{F}")#text(" is fixed by ")#mi("{\\mathrm{Gal}(E/F)}")#text(", thus ")#mi("{F \\subset E^{\\mathrm{Gal}(E/F)}}")#text(" and hence")

#align(center)[#tao-fit-display[#mitex("[E:F] \\geq [E:E^{\\mathrm{Gal}(E/F)}].")]]

#text("On the other hand, by Proposition ")#link(<tao-57cda594148cb40cfa28>)[#text("17")]#text(" we have ")#tao-math("{[E:F] = \\left|\\mathrm{Gal}(E/F)\\right|}", block: false)#text(". Finally, from ")#link(<tao-16a0a2e664cff4e61bb4>)[#text("(7)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathrm{Gal}(E/F)\\right| \\leq [E:E^{\\mathrm{Gal}(E/F)}].", block: true)]]

#text("Therefore all inequalities must be equalities, and ")#mi("{F = E^{\\mathrm{Gal}(E/F)}}")#text(" as claimed. ")#mi("\\Box")

#text("Now we prove Theorem ")#link(<tao-01b51c659dc0dcdab860>)[#text("1")]#text("(ii). Let ")#mi("{H}")#text(" be a subgroup of ")#mi("{\\mathrm{Gal}(M_E/M_k)}")#text(", which we can also identify with a subgroup of ")#mi("{\\mathrm{Gal}(E/k)}")#text(". Let ")#mi("{E^H}")#text(" denote the set of elements of ")#mi("{E}")#text(" that are fixed by ")#mi("{H}")#text("; this is clearly an intermediate field between ")#mi("{k}")#text(" and ")#mi("{E}")#text(":")

#align(center)[#tao-fit-display[#mitex("k \\hookrightarrow E^H \\hookrightarrow E.")]]

#text("On the one hand, every element of ")#mi("{H}")#text(" can be identified with an element of ")#mi("{\\mathrm{Gal}(E/E^H) \\equiv \\mathrm{Gal}(M_E/M_{E^H})}")#text(". By Proposition ")#link(<tao-57cda594148cb40cfa28>)[#text("17")]#text(", ")#mi("{\\mathrm{Gal}(M_E/M_{E^H})}")#text(" has order exactly equal to ")#mi("{[E:E^H]}")#text(". Thus")

#align(center)[#tao-fit-display[#tao-math("\\left|H\\right| \\leq \\left|\\mathrm{Gal}(M_E/M_{E^H})\\right| = [E:E^H].", block: true)]]

#text("To prove the reverse inequality, we use an argument of Artin. We first need a simple lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 19 (Producing an invariant vector)")]#text(" ")#metadata(none) <tao-89270a50341bb8e83734>#text(" Let the notation be as above. Let ")#mi("{E^m}")#text(" be the ")#mi("{m}")#text("-fold Cartesian product of ")#mi("{E}")#text(" (viewed as a vector space over ")#mi("{E}")#text("), and let ")#mi("{H}")#text(" act componentwise on ")#mi("{E^m}")#text(":")

#align(center)[#tao-fit-display[#mitex("h ( x_1, \\dots, x_m ) := (hx_1, \\dots, hx_m).")]]

#text("Let ")#mi("{V}")#text(" be an ")#mi("{H}")#text("-invariant subspace of ")#mi("{E^m}")#text(" (i.e., ")#mi("{V \\subset E^m}")#text(" is a vector space over ")#mi("{E}")#text(" such that ")#mi("{hv \\in V}")#text(" whenever ")#mi("{h \\in H}")#text(" and ")#mi("{v \\in V}")#text("). If ")#mi("{V}")#text(" contains a non-zero element of ")#mi("{E^m}")#text(", then it also contains a non-zero element of ")#mi("{(E^H)^m}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{v = (x_1,\\dots,x_n)}")#text(" be a non-zero element of ")#mi("{V}")#text(" with a minimal number of non-zero entries. By relabeling, we may assume that ")#mi("{x_1}")#text(" is non-zero; by dividing by ")#mi("{x_1}")#text(", we may normalise ")#mi("{x_1=1}")#text(". If all the other coefficients lie in ")#mi("{E^H}")#text(" then we are done; by relabeling we may thus assume without loss of generality that ")#mi("{x_2 \\not \\in E^H}")#text(". By definition of ")#mi("{E^H}")#text(", we may thus find ")#mi("{h \\in H}")#text(" such that ")#mi("{hx_2 \\neq x_2}")#text(". The vector ")#mi("{hv - v}")#text(" is then a non-zero element of ")#mi("{V}")#text(" with fewer non-zero entries than ")#mi("{v}")#text(", contradicting the minimality of ")#mi("{v}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 20")]#text(" This argument is reminiscent of the abstract ergodic theorem from ")#link("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/")[#text("this previous blog post")]#text(", except that now we minimise the ")#mi("{\\ell^0}")#text(" norm rather than the ")#mi("{\\ell^2}")#text(" norm, since the latter is unavailable over arbitrary fields ")#mi("{E}")#text(". While this lemma is simple, it seems to be the one aspect of the Galois correspondence for field extensions that does not seem to have an obvious analogue in the covering space setting; on the other hand, I do not know how to prove the fundamental theorem of Galois theory without this lemma or something like it (though presumably the original arguments of Galois proceed differently).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 21")]#text(" We have ")#tao-math("{[E:E^H] \\leq \\left|H\\right|}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" Suppose for contradiction that ")#tao-math("{[E:E^H] = m > \\left|H\\right|}", block: false)#text(", thus we may find elements ")#mi("{z_1,\\dots,z_m}")#text(" of ")#mi("{E}")#text(" that are linearly independent over ")#mi("{E^H}")#text(". We form a vector ")#mi("{z = (z_1,\\dots,z_m) \\in E^m}")#text(" out of these elements, and consider the orbit ")#mi("{\\{ hz: h \\in H \\}}")#text(" of this vector. Let ")#mi("{V = \\{ v \\in E^m: v \\cdot hz = 0 \\text{ for all } h \\in H \\}}")#text(" be the space of vectors orthogonal to this orbit, where we use the usual dot product")

#align(center)[#tao-fit-display[#mitex("(v_1,\\dots,v_m) \\cdot (z_1,\\dots,z_m) := v_1 z_1 + \\dots + v_m z_m")]]

#text("in ")#mi("{E^m}")#text(". This space has codimension at most ")#tao-math("{\\left|H\\right|}", block: false)#text(" in ")#mi("{E^m}")#text(" and thus has a non-zero vector since ")#tao-math("{m>\\left|H\\right|}", block: false)#text(". Clearly ")#mi("{V}")#text(" is ")#mi("{H}")#text("-invariant. By Lemma ")#link(<tao-89270a50341bb8e83734>)[#text("19")]#text(", ")#mi("{V}")#text(" contains a non-zero vector ")#mi("{v=(x_1,\\dots,x_m)}")#text(" whose entries lie in ")#mi("{E^H}")#text(". By construction, ")#mi("{v}")#text(" is orthogonal to ")#mi("{z}")#text(", thus there is a non-trivial linear relation amongst the ")#mi("{z_1,\\dots,z_m}")#text(" with coefficients in ")#mi("{E^H}")#text(", contradicting linear independence. ")#mi("\\Box")

#text("We thus have ")#mi("{H = \\mathrm{Gal}(M_E/M_{E^H}) \\equiv \\mathrm{Gal}(E/E^H)}")#text(", giving the existence part of Theorem ")#link(<tao-01b51c659dc0dcdab860>)[#text("1")]#text("(ii); the uniqueness part is immediate from Corollary ")#link(<tao-f642974cfcb13951bb7d>)[#text("18")]#text(".")

#text("Theorem ")#link(<tao-01b51c659dc0dcdab860>)[#text("1")]#text("(iii) is also immediate from Corollary ")#link(<tao-f642974cfcb13951bb7d>)[#text("18")]#text(", so we turn to Theorem ")#link(<tao-01b51c659dc0dcdab860>)[#text("1")]#text("(iv). Let ")#mi("{k \\hookrightarrow F \\hookrightarrow E}")#text(". First suppose that ")#mi("{\\mathrm{Gal}(E/F)}")#text(" is a normal subgroup of ")#mi("{\\mathrm{Gal}(E/k)}")#text(". If ")#mi("{g^{\\prime} \\in \\mathrm{Gal}(E/F)}")#text(" and ")#mi("{g \\in \\mathrm{Gal}(E/k)}")#text(", then ")#mi("{g g^{\\prime} g^{-1} \\in \\mathrm{Gal}(E/F)}")#text(" fixes ")#mi("{F}")#text(", thus ")#mi("{g^{\\prime}}")#text(" fixes ")#mi("{gF}")#text(". Thus ")#mi("{g F \\subset E^{\\mathrm{Gal}(E/F)}}")#text(", hence by Corollary ")#link(<tao-57cda594148cb40cfa28>)[#text("17")]#text(" we have ")#mi("{g F \\subset F}")#text(". Thus the action of ")#mi("{\\mathrm{Gal}(E/k)}")#text(" descends to that of ")#mi("{\\mathrm{Gal}(F/k)}")#text("; equivalently, every deck transformation of ")#mi("{M_E}")#text(" above ")#mi("{M_k}")#text(" descends to a deck transformation of ")#mi("{M_F}")#text(" above ")#mi("{M_k}")#text(". Since the fibre of ")#mi("{p_E}")#text(" above ")#mi("{M_k}")#text(" has cardinality ")#mi("{[E:k]}")#text(", and splits into fibres of cardinality ")#mi("{[E:F]}")#text(" above ")#mi("{M_F}")#text(" indexed by a fibre of ")#mi("{M_F}")#text(" above ")#mi("{M_k}")#text(" that has cardinality at most ")#mi("{[F:k]}")#text(" by Proposition ")#link(<tao-4c3b3284e206c3db7244>)[#text("12")]#text(", and ")#mi("{[E:k] = [E:F] [F:k]}")#text(", we conclude that the latter fibre must have cardinality exactly ")#mi("{[F:k]}")#text(". As ")#mi("{\\mathrm{Gal}(M_E/M_k)}")#text(" acts transitively on the fibre of ")#mi("{M_k}")#text(", it must also act transitively on this fibre of ")#mi("{M_F}")#text(". Thus there at least ")#mi("{[F:k]}")#text(" distinct deck transformations of ")#mi("{M_F}")#text(" above ")#mi("{M_k}")#text(", and so ")#mi("{F}")#text(" is a Galois extension of ")#mi("{k}")#text(" thanks to ")#link(<tao-16a0a2e664cff4e61bb4>)[#text("(7)")]#text(", and every deck transformation of ")#mi("{M_F}")#text(" above ")#mi("{M_k}")#text(" arises from a deck transformation of ")#mi("{M_E}")#text(" above ")#mi("{M_k}")#text(". Thus we have constructed a surjective map from ")#mi("{\\mathrm{Gal}(M_E/M_k)}")#text(" to ")#mi("{\\mathrm{Gal}(M_F/M_k)}")#text(" which can easily be verified to be a homomorphism. The kernel of this homomorphism consists of all deck transformations of ")#mi("{M_E}")#text(" above ")#mi("{M_k}")#text(" that preserve the fibres of ")#mi("{M_E}")#text(" above ")#mi("{M_F}")#text("; applying the deck transformation to the distinguished point ")#mi("{p_E}")#text(", one sees in particular that the field automorphism of ")#mi("{E}")#text(" associated to this transformation preserves ")#mi("{F}")#text(", and hence this transformation lies in ")#mi("{\\mathrm{Gal}(M_E/M_F)}")#text(". Conversely every deck transformation in ")#mi("{\\mathrm{Gal}(M_E/M_F)}")#text(" descends to the identity transformation on ")#mi("{M_F}")#text(". Thus the kernel of the homomorphism is precisely ")#mi("{\\mathrm{Gal}(M_E/M_F)}")#text(", and the isomorphism of ")#mi("{\\mathrm{Gal}(F/k)}")#text(" with ")#mi("{\\mathrm{Gal}(E/k)/\\mathrm{Gal}(E/F)}")#text(" then follows from the first isomorphism theorem.")

#text("Conversely, suppose that ")#mi("{F}")#text(" is a Galois extension of ")#mi("{k}")#text(". Let ")#mi("{g^{\\prime} \\in \\mathrm{Gal}(M_E/M_F)}")#text(" and ")#mi("{g \\in \\mathrm{Gal}(M_E/M_k)}")#text(". The points ")#mi("{\\pi_{M_F \\leftarrow M_E} p_E}")#text(", ")#mi("{\\pi_{M_F \\leftarrow M_E} g p_E}")#text(" of ")#mi("{F}")#text(" lie above the same point of ")#mi("{M_k}")#text("; from Lemma ")#link(<tao-2a6f8f7aa6e5ca1ce062>)[#text("16")]#text(" there thus exists ")#mi("{h \\in \\mathrm{Gal}(M_F/M_k)}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("h \\pi_{M_F \\leftarrow M_E} p_E = \\pi_{M_F \\leftarrow M_E} g p_E.")]]

#text("On the other hand, as ")#mi("{p_E}")#text(" is the distinguished point of ")#mi("{M_E}")#text(", there exists ")#mi("{\\gamma \\in \\Gamma}")#text(" such that ")#mi("{p_E \\gamma = g^{\\prime} p_E}")#text(". Applying ")#mi("{\\gamma}")#text(" on the right to the above equation, we thus have")

#align(center)[#tao-fit-display[#mitex("h \\pi_{M_F \\leftarrow M_E} g^{\\prime} p_E = \\pi_{M_F \\leftarrow M_E} g g^{\\prime} p_E.")]]

#text("But ")#mi("{p_E, g^{\\prime} p_E}")#text(" lie above the same point of ")#mi("{M_F}")#text(", thus ")#mi("{\\pi_{M_F \\leftarrow M_E} p_E = \\pi_{M_F \\leftarrow M_E} g^{\\prime} p_E}")#text(", and hence")

#align(center)[#tao-fit-display[#mitex("\\pi_{M_F \\leftarrow M_E} g g^{\\prime} p_E = \\pi_{M_F \\leftarrow M_E} g p_E.")]]

#text("By Lemma ")#link(<tao-2a6f8f7aa6e5ca1ce062>)[#text("16")]#text(" again, this implies that ")#mi("{gg^{\\prime} p_E = g^{\\prime\\prime} g p_E}")#text(" for some ")#mi("{g^{\\prime\\prime} \\in \\mathrm{Gal}(M_E/M_F)}")#text(". As ")#mi("{p_E}")#text(" connects to every other point in ")#mi("{M_E}")#text(" by a path in ")#mi("{\\Gamma}")#text(", we conclude that ")#mi("{gg^{\\prime} = g^{\\prime\\prime} g}")#text(", thus ")#mi("{g g^{\\prime} g^{-1} \\in \\mathrm{Gal}(M_E/M_F)}")#text(". In other words, ")#mi("{\\mathrm{Gal}(M_E/M_F)}")#text(" is a normal subgroup of ")#mi("{\\mathrm{Gal}(M_E/M_k)}")#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/30a9f9b1621abd7b04ca420171aed30e91677989bb7de01be4c0c07125fda1aa-e9a2701704eead7eabed2961af49f1c84539a18fc9b0d03fa0dc12f18b164224.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fausto di Biase")]], [#link("https://terrytao.wordpress.com/2018/08/28/trying-to-understand-the-galois-correspondence/#comment-504382")[#strong[#text("Fausto di Biase")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2018")])]

#text("This seems reminiscent of some recent work of Peter Scholze.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cd6e5aad292560f64aa9b45f206b0b28bb1653f6fa014816cacacbed78552fc-c80b60e7a5c2a123c91bafc7bcbdd6449b4a89fd888c4af3c56d500dd860cd71.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of test")]], [#link("https://terrytao.wordpress.com/2018/08/28/trying-to-understand-the-galois-correspondence/#comment-504386")[#strong[#text("test")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2018")])]

#text("No it doesn’t.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Spitz")]], [#link("https://terrytao.wordpress.com/2018/08/28/trying-to-understand-the-galois-correspondence/#comment-504393")[#strong[#text("Ben Spitz")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2018")])]

#text("I think part (iv) of the fundamental theorem of galois theory should say that Gal(F/k) is isomorphic to Gal(E/k)/Gal(E/F)")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80f50872e9e60b8bfeb1c5c5ff0a96a7423a13668e4d9d6acdea8085b7ffb338-0e1ab301b41119ab97d9d6b5a53ed0f8bd60470ff5b6b1a939e6c68fad5142f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/08/28/trying-to-understand-the-galois-correspondence/#comment-504523")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2018")])]

#text("I still see the wrong version.")

#emph[#text("[Hopefully fixed for good now – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/08/28/trying-to-understand-the-galois-correspondence/#comment-504398")[#strong[#text("Trying to understand the Galois correspondence | What's new - Nevin Manimala's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2018")]

#text("[…] by /u/tick_tock_clock [link] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/53a6d73ae49e0a8236f9542d9c52c137d4b1b31ab4014e31129cbb6d1d7875ef-4443c8bc5aab0c73e198ee07bd8398054a2ce654a4a023e248c779b1d7edf1e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frank Murphy")]], [#link("https://terrytao.wordpress.com/2018/08/28/trying-to-understand-the-galois-correspondence/#comment-504399")[#strong[#text("Frank Murphy")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2018")])]

#text("Reblogged this on ")#link("https://fmurphyrng.wordpress.com/2018/08/29/trying-to-understand-the-galois-correspondence/")[#text("fmurphyrng")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df88c82a0c6ca60749bde63169ae2c1a10887470fb305be1ac30901d9d26e643-738f0fc464705f031f93b8ebe4bdcd7c3f18bdbd27a382bbbdd325758468e3f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hmmm")]], [#link("https://terrytao.wordpress.com/2018/08/28/trying-to-understand-the-galois-correspondence/#comment-504400")[#strong[#text("hmmm")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2018")])]

#text("Are there nice geometric reformulations of the classical applications of Galois theory (solvability in radicals of the quintic, ruler-and-compass constructions, and the like), in terms of deck coverings?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/08/28/trying-to-understand-the-galois-correspondence/#comment-504404")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2018")])]

#text("For trisection, I did something like this in ")#link("https://terrytao.wordpress.com/2011/08/10/a-geometric-proof-of-the-impossibility-of-angle-trisection-by-straightedge-and-compass/")[#text("this previous blog post")]#text(". For unsolvability of the quintic by radicals, there is a ")#link("http://www.springer.com/mathematics/algebra/book/978-1-4020-2186-2")[#text("Riemann surface argument of Arnold")]#text(" which one can think of as a covering space argument.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a747537ede6b40643e4449c04bbac2151d50cbe6dcc735502253562a60fb17b0-f5b6dc067e75d522e46dcbc4a63bd1c3e060fcc91b0c03621cc3bdf35e601d80.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of francisrlb")]], [#link("https://terrytao.wordpress.com/2018/08/28/trying-to-understand-the-galois-correspondence/#comment-504406")[#strong[#text("francisrlb")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2018")])]

#text("In the last paragraph, is there an issue in saying that M_{F} is a quotient of M_{E}, since the point 1 : F -> F, would need to come from a map E -> F?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/08/28/trying-to-understand-the-galois-correspondence/#comment-504412")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2018")])]

#text("Oops, you’re right, the argument here is a little trickier than in the covering space case (and also I forgot to write up the converse implication for this step). I’ve rewritten the argument to fix this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f1a372e829463793aeb0a623311ea4ace0743754c878093a82082ffe3cd7d03-abe1f067d8cef1b256503dd90f7848db75a2186d27ca83029456caf89a091fd6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Akshaya")]], [#link("https://terrytao.wordpress.com/2018/08/28/trying-to-understand-the-galois-correspondence/#comment-504422")[#strong[#text("Akshaya")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2018")])]

#text("Dear Terry,")

#text("Could you please try to similarly explain Etale topology, cohomology, point-counting trace formula?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/08/28/trying-to-understand-the-galois-correspondence/#comment-504444")[#strong[#text("Quick Links | Not Even Wrong")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2018")]

#text("[…] Terry Tao has come up with his own take on arithmetic geometry, available here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/08/28/trying-to-understand-the-galois-correspondence/#comment-504495")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2018")])]

#text("Dear Terry,")#linebreak()#text(" I would like to confide with you some words:Last night, I had a strange dream.I found that you solved 6 clay millenium problems that I could arrange the order of them below:")#linebreak()#text(" *1)Yang-Mills existence and mass gaps")#linebreak()#text(" *2)Navier-Stokes existence and smoothness")#linebreak()#text(" *3)Riemann hypothesis")#linebreak()#text(" *4)Birch-Swinerton Dyer conjecture")#linebreak()#text(" *5)Hodge conjecture")#linebreak()#text(" *6)P vs NP")#linebreak()#text(" In all of them, I found that Yang Mills you solved very quickly.You had too many proofs for Navier Stokes.Riemann is the best difficult problem in all of 7 ,because I found that you spend a lot of time doing it.")#linebreak()#text(" Aha,there are many things that science never can prove.Many great inventions which comes from a dream.I do not need anyone believe this.Pro.Tao will see my dream is right")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9d3ccd952f74597e785fcef0050fb9ed26ec0c74f46628a808f9afe9de27a08e-6d1fe87159414adc7ad46ed3ff326f28ce5acbfe42580bb8bfa2b1578b7af4e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick")]], [#link("https://terrytao.wordpress.com/2018/08/28/trying-to-understand-the-galois-correspondence/#comment-504521")[#strong[#text("Nick")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2018")])]

#text("Terry: Great exposition. However, in Example 2 (under Theorem 1), I don’t think any intermediate field of a cyclotomic extension is another cyclotomic extension. For example, if you take the fixed field of a cyclotomic extension under complex conjugation, it will consist of real numbers and so generally is not a cyclotomic extension.")#linebreak()#text(" You probably meant to say “some intermediate fields are of the form”.")

#emph[#text("[Oops, had overlooked that point. Corrected now, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/022465e4f9a8dcb56cc461863bfd5037473ffe48f179e8d20f8c228415444460-dd91d5565616aa1dc9f6872a3e94e67744adb41ab4b41264b2630a87b1487db5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathcination")]], [#link("https://terrytao.wordpress.com/2018/08/28/trying-to-understand-the-galois-correspondence/#comment-504651")[#strong[#text("mathcination")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2018")])]

#text("I assume this is strongly related to the following book:")#linebreak()#text(" Khovanskii: Galois Theory, Coverings, and Riemann Surfaces")#linebreak()#text(" ")#link("https://www.springer.com/de/book/9783642388408")[#text("https://www.springer.com/de/book/9783642388408")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/08/28/trying-to-understand-the-galois-correspondence/#comment-504656")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2018")])]

#text("Yes, I should have mentioned some references on this (I am partial to Szamuely’s “")#link("http://admin.cambridge.org/academic/subjects/mathematics/algebra/galois-groups-and-fundamental-groups-1")[#text("Galois groups and fundamental groups")]#text("“, for instance). For fields of meromorphic functions on Riemann surfaces and their finite covers there is a very close correspondence between the Galois groups of the fields and the (profinite completion of the) fundamental groups of the Riemann surfaces, as is discussed in Szamuely’s book (and presumably also in Khovanskii, which I have not read). For more general schemes than this, the philosophy in most of the literature is to try to move away from the topological, path-based perspective and try to unify these topics in a more abstract setting (e.g. using Grothendieck’s functorial point of view). My aim here was slightly different, namely to try to recast Galois theory using the path-based framework. Probably this framework is nowhere near as general as the more category-theoretic approaches, but I found it to be helpful in allowing one to transfer topological intuition to more algebraic settings (as opposed to vice versa).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8640bb4d5ccbc9b28dc2907567b0047b40c9d4223fa7ad1d69ad98152a4ae7cb-424b6bb6a7b634b2299d942218179d0dc179b2db553a774ce450efe886e876d9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samuel Vidal")]], [#link("https://terrytao.wordpress.com/2018/08/28/trying-to-understand-the-galois-correspondence/#comment-504717")[#strong[#text("Samuel Vidal")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2018")])]

#text("Hi, Sorry if I’m wrong, but I think there is a little typo in example 2. The nth cyclotomic field is an extension of degree ")#mi("\\phi(n)")#text(" over ")#mi("\\mathbb{Q}")#text(".")#linebreak()#text(" For example ")#mi("\\mathbb{Q}(\\mu_4) = \\mathbb{Q}(i)")#text(" is of degree 2. I really like the clarity of your blog. Regards")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2bd3520a9a45f5a59cb99d16fec8a9fa83ec641045934efa4ed5305da1c7f76f-615006709b00526f7f45f54427581dab0e15ffd1011babc668f8c849a8f6cfe8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aidan Backus")]], [#link("https://terrytao.wordpress.com/2018/08/28/trying-to-understand-the-galois-correspondence/#comment-596801")[#strong[#text("Aidan Backus")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2020")])]

#text("I think there’s a typo in Theorem 4, iv; namely that $Gal(N/L) \\cong Gal(M/L)/Gal(M/N)$ rather than $Gal(M/L)/Gal(N/L)$.")

#emph[#text("[Corrected, thanks – T.]")]
]
