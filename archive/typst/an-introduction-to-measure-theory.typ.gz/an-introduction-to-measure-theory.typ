// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/
// Converted to Typst by tao2typ: "2026-10-14T16:36:25.159873+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An introduction to measure theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An introduction to measure theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 January 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/")[#text("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("As I have done in the last three years, I am spending some time at the beginning of this year converting some of my posts on this blog into book format. This time round, the situation is a bit different because the majority of mathematical posts last year came from three courses I have taught: ")#link("https://terrytao.wordpress.com/category/teaching/254a-random-matrices/")[#text("random matrices")]#text(", ")#link("https://terrytao.wordpress.com/category/teaching/254b-higher-order-fourier-analysis/")[#text("higher-order Fourier analysis")]#text(", and ")#link("https://terrytao.wordpress.com/category/teaching/245a-real-analysis/")[#text("measure theory")]#text(". These topics are sufficiently unrelated to each other, and to the other mathematical posts from 2010, that I am thinking of having as many as four distinct books this time around, though my plans are not yet definite in this regard.")

#text("In any event, I have started the process by converting the measure theory notes to book form, a draft copy of which is now available ")#link("https://terrytao.wordpress.com/wp-content/uploads/2012/12/gsm-126-tao5-measure-book.pdf")[#text("here")]#text(". I have also started up a ")#link("https://terrytao.wordpress.com/books/an-introduction-to-measure-theory/")[#text("stub of a book page")]#text(" for this text, though it has little content at present beyond that link. I will be continuing to work on it in parallel with the rest of the conversion process. As always, any comments and corrections are very welcome.")

#heading(level: 1)[#text("Comments (26)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-49795")[#strong[#text("Tweets that mention An introduction to measure theory « What’s new -- Topsy.com")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2011")]

#text("[…] This post was mentioned on Twitter by Fumihiro CHIBA, Bidkar Pojoy, Fabio Souza, fabreetseo, Alp Mestanogullari and others. Alp Mestanogullari said: RT @AnalysisFact: Notes on measure theory from Terry Tao ")#link("http://ow.ly/3JbZZ")[#text("http://ow.ly/3JbZZ")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a94ae298efedf200edc76ac5e0ae3e2f4497a86fb190cc62f8a49008912d865-b1dedd248b24e91d4850aa0c1ec81d4fecbea58810aa732e0aac42f73fc62a63.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim H.")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-49803")[#strong[#text("Tim H.")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2011")])]

#text("Thanks, Dr. Tao. I’d love to have this available in a Kindle format :-D")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a94ae298efedf200edc76ac5e0ae3e2f4497a86fb190cc62f8a49008912d865-b1dedd248b24e91d4850aa0c1ec81d4fecbea58810aa732e0aac42f73fc62a63.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim H.")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-49804")[#strong[#text("Tim H.")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2011")])]

#link("http://tex.stackexchange.com/questions/1632/latex-options-for-kindle")[#text("http://tex.stackexchange.com/questions/1632/latex-options-for-kindle")]#text(" maybe?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d54534b486854684e1dc703fbea7ab93e9ca553f4d189fd5c4fc5617168046f-bbd4b7678e524c3005160021bcad8053fdf3cacd177055e7dd634ebda6a8d2ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blake Stacey")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-49806")[#strong[#text("Blake Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2011")])]

#text("Formatting nit: the page heading for section 2.4, “Infinite product spaces and the Kolmogorov extension theorem”, spills over on top of the page numbers.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa7b04c9cdc3b7e94b8790739496fd1879ef0d27a4646215489dc69ad270619b-b58cac8d02b25d1b1056dfeda905e5322de99f389120e665f438b2646d6840fe.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniele A. Gewurz")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-49826")[#strong[#text("Daniele A. Gewurz")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2011")])]

#text("Are you thinking about putting in book form (or in another permanent form) your “Buzz” posts too? Most of them are very interesting and mind-provoking.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b65250bb5838c66ca74ae006e465d2c97993d53ae65a1872331c95224125dbc-f63b062d12effd708db263692f4c9be00d3d9dc57248c9b85c47ece75e841b1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of science and math")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-49850")[#strong[#text("science and math")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2011")])]

#text("Nice.")#linebreak()#text(" The draft version is very good.")#linebreak()#text(" Keep on working.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/899dfecab481cdea500c028afa71be42ef6e0df495b320d967664ab1a9084fdc-25d005ce4e8ca6d2c03ae45082bb0a3a830c3468e596e0241bc2245d6cff26bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-49913")[#strong[#text("James")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2011")])]

#text("Would uppercase be better (i.e. “An Introduction to Measure Theory”)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-49916")[#strong[#text("Weekend miscellany — The Endeavour")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2011")]

#text("[…] Algebraic formula for partition numbers Measure theory notes from Terry Tao […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pan")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-49932")[#strong[#text("Pan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2011")])]

#text("Thank you very much professor, I’m enjoying this book!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9600342ea6c4a9d9b3c467fc166a1c600cb8a5a49b7acc1a145414977e095f9a-e44c4910e771211e44bed0cc8479a2c89f24a6b6a9c6908e32ecf8da5d7ecfcb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ulrich")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-49951")[#strong[#text("Ulrich")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2011")])]

#text("Dear Terence, thank you very much for this great book (I guess, it will become a book). It is exactly what I am looking for. I hope you will bring out a similar one for complex analysis, too.")

#text("Two remarks: The one is a typo regarding the name Rademacher, which is at some places written as Radamacher (but I guess you already have seen this). The second is the adding of some historical remarks. For this I suggest a closer look from your side to the book of")#linebreak()#text(" D. Bressoud, A radical approach to Lebesgue’s Theory of integration, where the historical road from Fourier up to Lebesgue is discussed.")

#text("Thanks again.")

#text("Regards")#linebreak()#text(" Ulrich")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11128e4290fda88162336c609a63a91f90fa88316eff78b1757c67c996c650fa-fcde97ef5627bdc60423b8843e7c57dc4d57eb2cdfdad7ee7f6c20f9f347501a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthony")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-49973")[#strong[#text("anthony")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2011")])]

#text("I would mention that the defect version of Fatou’s lemma (page 128) is due to Brézis and Lieb (at least the Lp version)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd0bdc9db765779dbdf950ce5f607d52503b67cb8602d966dc885e92afc392ba-c92f1866bf498f1012a7154936c4e1586c0b529e26fcceb65756a53c23111257.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maria Alfonseca")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-49975")[#strong[#text("Maria Alfonseca")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2011")])]

#text("Thank you for making you notes available. I used some exercises from your Real Analysis B notes in my functional analysis class last semester.")

#text("In the measure theory book (page 151 in the book, or page 167 of the pdf file) there is a line that runs way over the margins. ")#emph[#text("[Will be corrected in the next update, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39be2b741f5db6b9353e856dec84ec21b8b8926658595af6eb2ba1fe4034e3db-57f8a23a2d0df915fb6c6f2a6bf5621c610b963fa3459c3f36a8d34fe528f89e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew L.")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-50008")[#strong[#text("Andrew L.")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2011")])]

#text("Professor Tao, let me thank you sincerely from the bottom of my heart for putting your considerable skills into textbook writing. Textbook writing,like teaching mathematics in general, is a difficult and often (in a research university environment,especially) thankless task. Many mathematicians who are as successful at research as you’ve been would think themselves above such drudgery. Fortunately for your students and those of us who prize the teaching of advanced mathematics and the texts that result from those who are willing to put the effort and passion into it, you do NOT consider yourself above it. I plan to work carefully through this book this summer after passing my Master’s degree exams in May. It’ll be my pleasure to email you a long list of comments and suggestions for improvements.")#linebreak()#text(" Keep up the great work!")#linebreak()#text(" Sincerely,")#linebreak()#text(" Andrew L.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-50039")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2011")])]

#text("p. 243: Solovay is is spelled incorrectly.")

#emph[#text("[Will be corrected in the next revision, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2e6ae09609e2af75674e0148c5ccdfd1890b2141c5957bcbe6e66b3708dff06-86e24ab119777fcf481bacc29a0775c178571d32b0c54d3c6f9d054968ed2846.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan L")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-50046")[#strong[#text("Dan L")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2011")])]

#text("First, thank you so much for making these notes available. After skimming the first 30 pages or so, I immediately decided to adopt your textbook for my measure theory course this semester. I’ll try to comment here on anything I notice while going through the book.")

#text("First observation: I’m not sure why, but I find Exercise 1.1.17 to be confusingly written. It might be the use of the word “cover.”")

#emph[#text("[Will be corrected in the next revision, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78e3e0c23c286ce361d0a243f2f0e7ab64120485150f4f6799359909c7f932b5-37531fc48390d9341903dff553fac7299ae467cc870eb0e8e66e503a2d995d2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gianfranco OLDANI")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-50244")[#strong[#text("Gianfranco OLDANI")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2011")])]

#text("Thanks for your “draft” book on measure theory. I have great pleasure to read it even if I’m pretty new to the subject. Is it the right place to do our suggestions?")#linebreak()#text(" Just a very little one, at page 6, :")

#text("…Thus, for example, the elementary measure of (1; 2)U[3; 6]is ")#strong[#text("4")]#text(". –> should be ")#strong[#text("3")]#text(" instead of ")#strong[#text("4")]#text(".")

#text("Regards")#linebreak()#text(" Gianfranco")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-50245")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2011")])]

#text("Yes, this is the right place to suggest corrections. But in this case, the elementary measure is 1+3=4; the interval (1,2) has length 2-1=1, and the interval [3,6] has length 6-3=3.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78e3e0c23c286ce361d0a243f2f0e7ab64120485150f4f6799359909c7f932b5-37531fc48390d9341903dff553fac7299ae467cc870eb0e8e66e503a2d995d2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gianfranco")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-50248")[#strong[#text("Gianfranco")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2011")])]

#text("Oh! Sorry of course it’s a union, why I was thinking that it was a product of intervals. Again sorry to have bothered you for that.")

#text("Regards.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guest")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-50441")[#strong[#text("Guest")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2011")])]

#text("On the proof of Lusin’s Theorem,on page 77 , the sets A and E both seem to refer to the same object of arbitrary small measure.")

#text("Thank you for your excellent and very helpful book.")

#emph[#text("[Corrected for the next revision of the ms, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-51180")[#strong[#text("Measure Theory: What are some good resources for learning about measure theory? - Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2011")]

#text("[…] Tao has made a number of books on Analysis available for free. His exposition is excellent. Try:")#link("https://terrytao.wordpress.com/20")[#text("https://terrytao.wordpress.com/20")]#text("…7:52pmView All 0 CommentsCannot add comment at this time. Add […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2e6ae09609e2af75674e0148c5ccdfd1890b2141c5957bcbe6e66b3708dff06-86e24ab119777fcf481bacc29a0775c178571d32b0c54d3c6f9d054968ed2846.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan L")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-51351")[#strong[#text("Dan L")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2011")])]

#text("Lemma 1.3.9 is missing an item (viii). (I’m mildly curious how that can happen in enumeration environment.)")

#text("In Exercise 1.3.25(ii), I don’t think that finite measure support was intended to be included in the hypotheses.")

#emph[#text("[Corrected for the next revision, thanks. The items were labeled by hand, which was what caused the error. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2e6ae09609e2af75674e0148c5ccdfd1890b2141c5957bcbe6e66b3708dff06-86e24ab119777fcf481bacc29a0775c178571d32b0c54d3c6f9d054968ed2846.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan L")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-51732")[#strong[#text("Dan L")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2011")])]

#text("Perhaps I am being a bit dense (and maybe I missed where this was explained in the text), but I don’t understand why the definition of the simple integral in Section 1.4 is so complicated. The best I can piece together is that it explains why the simple integral is well-defined, but this was already explained earlier in the book. Perhaps the point is to just re-prove this using the machinery of algebras? Or is there some greater purpose?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-51745")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2011")])]

#text("Yes, the main issue is to ensure that the simple integral is well-defined (so that no matter how one partitions the simple function into indicators, one obtains the same integral at the end). I chose a more abstract way to define the simple integral here than in the earlier sections in order to show how the simple integral was in some sense the “inverse limit” of the finite integrals, but perhaps for an introductory text this may be too subtle of a point to be worth communicating at this stage. I might reword this section of the text a bit.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2e6ae09609e2af75674e0148c5ccdfd1890b2141c5957bcbe6e66b3708dff06-86e24ab119777fcf481bacc29a0775c178571d32b0c54d3c6f9d054968ed2846.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan L")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-52034")[#strong[#text("Dan L")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2011")])]

#text("Yeah, it would be nice to have just a quick signpost explaining the purpose of the construction and how it’s just a more abstract way to do what was done for the Lebesgue simple integral.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/953b7bd32cf7eaa020006fc272d5a7cbc33654ae9d83278e8f02d0c21a6b5bc4-fa5c994a46b5ca481a9304fba98f508cded48261da3eed811a14fc11b6e65ebb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chandrasekhar")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-61983")[#strong[#text("chandrasekhar")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2011")])]

#text("Respected Sir,")

#text("When can we expect this book in the market. Is it out for publication.")

#text("Chandrasekhar")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44bd330c0376a2af16413b39507779e8241ce19bb4c045ae1923bc4714baacbe-9629ac2c866c286c56338f973bd39ccdcca4fc9c08d46b8ea10b779a51004382.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2011/01/24/an-introduction-to-measure-theory/#comment-67304")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2011")])]

#text("On Page 33 it reads: “The claim now follows from (ii), (iii), (iv)”. Should it be (vi) instead of (iv)?")#linebreak()#text(" Very nice book by The way!")

#emph[#text("[Added to the errata list – T.]")]
]
