// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:38:55.656969+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "246B, Notes 4: The Riemann zeta function and the prime number theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("246B, Notes 4: The Riemann zeta function and the prime number theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 February 2021")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/")[#text("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Previous set of notes: ")#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/")[#text("Notes 3")]#text(". Next set of notes: ")#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/")[#text("246C Notes 1")]#text(".")

#text("One of the great classical triumphs of complex analysis was in providing the first complete proof (by Hadamard and de la Vallée Poussin in 1896) of arguably the most important theorem in analytic number theory, the ")#link("https://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Prime number theorem)")]#text(" ")#metadata(none) <tao-a160524700113ddd3205>#text(" Let ")#mi("{\\pi(x)}")#text(" denote the number of primes less than a given real number ")#mi("{x}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\lim_{x \\rightarrow \\infty} \\frac{\\pi(x)}{x/\\ln x} = 1")]]

#text("(or in asymptotic notation, ")#mi("{\\pi(x) = (1+o(1)) \\frac{x}{\\ln x}}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(").")
]

#text("(Actually, it turns out to be slightly more natural to replace the approximation ")#mi("{\\frac{x}{\\ln x}}")#text(" in the prime number theorem by the ")#link("https://en.wikipedia.org/wiki/Logarithmic_integral_function")[#text("logarithmic integral")]#text(" ")#mi("{\\int_2^x \\frac{dt}{\\ln t}}")#text(", which happens to be a more precise approximation, but we will not stress this point here.)")

#text("The complex-analytic proof of this theorem hinges on the study of a key meromorphic function related to the prime numbers, the ")#link("https://en.wikipedia.org/wiki/Riemann_zeta_function")[#text("Riemann zeta function")]#text(" ")#mi("{\\zeta}")#text(". Initially, it is only defined on the half-plane ")#mi("{\\{ s \\in {\\bf C}: \\mathrm{Re} s > 1 \\}}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2 (Riemann zeta function, preliminary definition)")]#text(" Let ")#mi("{s \\in {\\bf C}}")#text(" be such that ")#mi("{\\mathrm{Re} s > 1}")#text(". Then we define")

#metadata(none) <tao-cb9d7890ca12537fb514>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\zeta(s) := \\sum_{n=1}^\\infty \\frac{1}{n^s}.")]]
]

#text("Note that the series is locally uniformly convergent in the half-plane ")#mi("{\\{ s \\in {\\bf C}: \\mathrm{Re} s > 1 \\}}")#text(", so in particular ")#mi("{\\zeta}")#text(" is holomorphic on this region. In previous notes we have already evaluated some special values of this function: ")#metadata(none) <tao-860c31c720a34f096b3b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\zeta(2) = \\frac{\\pi^2}{6}; \\quad \\zeta(4) = \\frac{\\pi^4}{90}; \\quad \\zeta(6) = \\frac{\\pi^6}{945}.")]]

#text(" ")#text(" However, it turns out that the zeroes (and pole) of this function are of far greater importance to analytic number theory, particularly with regards to the study of the prime numbers.")

#text("The Riemann zeta function has several remarkable properties, some of which we summarise here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Basic properties of the Riemann zeta function)")]#text(" ")#metadata(none) <tao-fbb7b5bf4ca348eeeebf>

#list(
[#text("(i) (")#link("https://en.wikipedia.org/wiki/Euler_product")[#text("Euler product formula")]#text(") For any ")#mi("{s \\in {\\bf C}}")#text(" with ")#mi("{\\mathrm{Re} s > 1}")#text(", we have")

#metadata(none) <tao-164200a298bafec89fd3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\zeta(s) = \\prod_p (1 - \\frac{1}{p^s})^{-1}")]]

#text("where the product is absolutely convergent (and locally uniform in ")#mi("{s}")#text(") and is over the prime numbers ")#mi("{p = 2, 3, 5, \\dots}")#text(".")],
[#text("(ii) (Trivial zero-free region) ")#mi("{\\zeta(s)}")#text(" has no zeroes in the region ")#mi("{\\{s: \\mathrm{Re}(s) > 1 \\}}")#text(".")],
[#text("(iii) (Meromorphic continuation) ")#mi("{\\zeta}")#text(" has a unique meromorphic continuation to the complex plane (which by abuse of notation we also call ")#mi("{\\zeta}")#text("), with a simple pole at ")#mi("{s=1}")#text(" and no other poles. Furthermore, the ")#link("https://en.wikipedia.org/wiki/Riemann_Xi_function")[#text("Riemann xi function")]

#metadata(none) <tao-c765d2f7b42f2a483927>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\xi(s) := \\frac{1}{2} s(s-1) \\pi^{-s/2} \\Gamma(s/2) \\zeta(s)")]]

#text("is an entire function of order ")#mi("{1}")#text(" (after removing all singularities). The function ")#mi("{(s-1) \\zeta(s)}")#text(" is an entire function of order one after removing the singularity at ")#mi("{s=1}")#text(".")],
[#text("(iv) (")#link("https://en.wikipedia.org/wiki/Functional_equation")[#text("Functional equation")]#text(") After applying the meromorphic continuation from (iii), we have")

#metadata(none) <tao-1cec177917a28d4c4548>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\zeta(s) = 2^s \\pi^{s-1} \\sin(\\frac{\\pi s}{2}) \\Gamma(1-s) \\zeta(1-s)")]]

#text("for all ")#mi("{s \\in {\\bf C}}")#text(" (excluding poles). Equivalently, we have")

#metadata(none) <tao-0eb1d8cb89614a82f796>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\xi(s) = \\xi(1-s)")]]

#text("for all ")#mi("{s \\in {\\bf C}}")#text(". (The equivalence between the ")#link(<tao-1cec177917a28d4c4548>)[#text("(5)")]#text(" and ")#link(<tao-0eb1d8cb89614a82f796>)[#text("(6)")]#text(" is a routine consequence of the Euler reflection formula and the Legendre duplication formula, see Exercises 26 and 31 of ")#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/")[#text("Notes 1")]#text(".)")]
)
]

#emph[#text("Proof:")]#text(" We just prove (i) and (ii) for now, leaving (iii) and (iv) for later sections.")

#text("The claim (i) is an encoding of the fundamental theorem of arithmetic, which asserts that every natural number ")#mi("{n}")#text(" is uniquely representable as a product ")#mi("{n = \\prod_p p^{a_p}}")#text(" over primes, where the ")#mi("{a_p}")#text(" are natural numbers, all but finitely many of which are zero. Writing this representation as ")#mi("{\\frac{1}{n^s} = \\prod_p \\frac{1}{p^{a_p s}}}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in S_{x,m}} \\frac{1}{n^s} = \\prod_{p \\leq x} \\sum_{a=0}^m \\frac{1}{p^{as}}")]]

#text("whenever ")#mi("{x \\geq 1}")#text(", ")#mi("{m \\geq 0}")#text(", and ")#mi("{S_{x,m}}")#text(" consists of all the natural numbers of the form ")#mi("{n = \\prod_{p \\leq x} p^{a_p}}")#text(" for some ")#mi("{a_p \\leq m}")#text(". Sending ")#mi("{m}")#text(" and ")#mi("{x}")#text(" to infinity, we conclude from monotone convergence and the geometric series formula that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{1}{n^s} = \\prod_{p} \\sum_{a=0}^\\infty \\frac{1}{p^{as}} =\\prod_p (1 - \\frac{1}{p^s})^{-1}")]]

#text("whenever ")#mi("{s>1}")#text(" is real, and then from dominated convergence we see that the same formula holds for complex ")#mi("{s}")#text(" with ")#mi("{\\mathrm{Re} s > 1}")#text(" as well. Local uniform convergence then follows from the product form of the Weierstrass ")#mi("{M}")#text("-test (Exercise 19 of ")#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/")[#text("Notes 1")]#text(").")

#text("The claim (ii) is immediate from (i) since the Euler product ")#mi("{\\prod_p (1-\\frac{1}{p^s})^{-1}}")#text(" is absolutely convergent and all terms are non-zero. ")#mi("\\Box")

#text("We remark that by sending ")#mi("{s}")#text(" to ")#mi("{1}")#text(" in Theorem ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("3")]#text("(i) we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{1}{n} = \\prod_p (1-\\frac{1}{p})^{-1}")]]

#text("and from the divergence of the harmonic series we then conclude Euler’s theorem ")#mi("{\\sum_p \\frac{1}{p} = \\infty}")#text(". This can be viewed as a weak version of the prime number theorem, and already illustrates the potential applicability of the Riemann zeta function to control the distribution of the prime numbers.")

#text("The meromorphic continuation (iii) of the zeta function is initially surprising, but can be interpreted either as a manifestation of the extremely regular spacing of the natural numbers ")#mi("{n}")#text(" occurring in the sum ")#link(<tao-cb9d7890ca12537fb514>)[#text("(1)")]#text(", or as a consequence of various integral representations of ")#mi("{\\zeta}")#text(" (or slight modifications thereof). We will focus in this set of notes on a particular representation of ")#mi("{\\zeta}")#text(" as essentially the Mellin transform of the theta function ")#mi("{\\theta}")#text(" that briefly appeared in previous notes, and the functional equation (iv) can then be viewed as a consequence of the modularity of that theta function. This in turn was established using the Poisson summation formula, so one can view the functional equation as ultimately being a manifestation of Poisson summation. (For a direct proof of the functional equation via Poisson summation, see ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("these notes")]#text(".)")

#text("Henceforth we work with the meromorphic continuation of ")#mi("{\\zeta}")#text(". The functional equation (iv), when combined with special values of ")#mi("{\\zeta}")#text(" such as ")#link(<tao-860c31c720a34f096b3b>)[#text("(2)")]#text(", gives some additional values of ")#mi("{\\zeta}")#text(" outside of its initial domain ")#mi("{\\{s: \\mathrm{Re} s > 1\\}}")#text(", most famously")

#align(center)[#tao-fit-display[#mitex("\\zeta(-1) = -\\frac{1}{12}.")]]

#text("If one ")#emph[#text("formally")]#text(" compares this formula with ")#link(<tao-cb9d7890ca12537fb514>)[#text("(1)")]#text(", one arrives at the infamous identity")

#align(center)[#tao-fit-display[#mitex("1 + 2 + 3 + \\dots = -\\frac{1}{12}")]]

#text("although this identity has to be interpreted in a suitable non-classical sense in order for it to be rigorous (see ")#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/")[#text("this previous blog post")]#text(" for further discussion).")

#text("From Theorem ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("3")]#text(" and the non-vanishing nature of ")#mi("{\\Gamma}")#text(", we see that ")#mi("{\\zeta}")#text(" has simple zeroes (known as ")#emph[#text("trivial zeroes")]#text(") at the negative even integers ")#mi("{-2, -4, \\dots}")#text(", and all other zeroes (the ")#emph[#text("non-trivial zeroes")]#text(") inside the ")#emph[#text("critical strip")]#text(" ")#mi("{\\{ s \\in {\\bf C}: 0 \\leq \\mathrm{Re} s \\leq 1 \\}}")#text(". (The non-trivial zeroes are conjectured to all be simple, but this is hopelessly far from being proven at present.) As we shall see shortly, these latter zeroes turn out to be closely related to the distribution of the primes. The functional equation tells us that if ")#mi("{\\rho}")#text(" is a non-trivial zero then so is ")#mi("{1-\\rho}")#text("; also, we have the identity ")#metadata(none) <tao-6e0e870191437f3e1e5c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\zeta(s) = \\overline{\\zeta(\\overline{s})}")]]

#text(" ")#text(" for all ")#mi("{s>1}")#text(" by ")#link(<tao-cb9d7890ca12537fb514>)[#text("(1)")]#text(", hence for all ")#mi("{s}")#text(" (except the pole at ")#mi("{s=1}")#text(") by meromorphic continuation. Thus if ")#mi("{\\rho}")#text(" is a non-trivial zero then so is ")#mi("{\\overline{\\rho}}")#text(". We conclude that the set of non-trivial zeroes is symmetric by reflection by both the real axis and the ")#emph[#text("critical line")]#text(" ")#mi("{\\{ s \\in {\\bf C}: \\mathrm{Re} s = \\frac{1}{2} \\}}")#text(". We have the ")#link("https://en.wikipedia.org/wiki/Riemann_hypothesis")[#text("following infamous conjecture")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 4 (Riemann hypothesis)")]#text(" All the non-trivial zeroes of ")#mi("{\\zeta}")#text(" lie on the critical line ")#mi("{\\{ s \\in {\\bf C}: \\mathrm{Re} s = \\frac{1}{2} \\}}")#text(".")
]

#text("This conjecture would have many implications in analytic number theory, particularly with regard to the distribution of the primes. Of course, it is far from proven at present, but the partial results we have towards this conjecture are still sufficient to establish results such as the prime number theorem.")

#text("Return now to the original region where ")#mi("{\\mathrm{Re} s > 1}")#text(". To take more advantage of the Euler product formula ")#link(<tao-164200a298bafec89fd3>)[#text("(3)")]#text(", we take complex logarithms to conclude that")

#align(center)[#tao-fit-display[#mitex("-\\log \\zeta(s) = \\sum_p \\log(1 - \\frac{1}{p^s})")]]

#text("for suitable branches of the complex logarithm, and then on taking derivatives (using for instance the generalised Cauchy integral formula and Fubini’s theorem to justify the interchange of summation and derivative) we see that")

#align(center)[#tao-fit-display[#mitex("-\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)} = \\sum_p \\frac{\\ln p/p^s}{1 - \\frac{1}{p^s}}.")]]

#text("From the geometric series formula we have")

#align(center)[#tao-fit-display[#mitex("\\frac{\\ln p/p^s}{1 - \\frac{1}{p^s}} = \\sum_{j=1}^\\infty \\frac{\\ln p}{p^{js}}")]]

#text("and so (by another application of Fubini’s theorem) we have the identity")

#metadata(none) <tao-5f8b67a0bb370867697d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("-\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)} = \\sum_{n=1}^\\infty \\frac{\\Lambda(n)}{n^s},")]]

#text("for ")#mi("{\\mathrm{Re} s > 1}")#text(", where the ")#link("https://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(" ")#mi("{\\Lambda(n)}")#text(" is defined to equal ")#mi("{\\Lambda(n) = \\ln p}")#text(" whenever ")#mi("{n = p^j}")#text(" is a power ")#mi("{p^j}")#text(" of a prime ")#mi("{p}")#text(" for some ")#mi("{j=1,2,\\dots}")#text(", and ")#mi("{\\Lambda(n)=0}")#text(" otherwise. The contribution of the higher prime powers ")#mi("{p^2, p^3, \\dots}")#text(" is negligible in practice, and as a first approximation one can think of the von Mangoldt function as the indicator function of the primes, weighted by the logarithm function.")

#text("The series ")#mi("{\\sum_{n=1}^\\infty \\frac{1}{n^s}}")#text(" and ")#mi("{\\sum_{n=1}^\\infty \\frac{\\Lambda(n)}{n^s}}")#text(" that show up in the above formulae are examples of Dirichlet series, which are a convenient device to transform various sequences of arithmetic interest into holomorphic or meromorphic functions. Here are some more examples:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5 (Standard Dirichlet series)")]#text(" ")#metadata(none) <tao-fe6d3468cf5c74d8ec2a>#text(" Let ")#mi("{s}")#text(" be a complex number with ")#mi("{\\mathrm{Re} s > 1}")#text(".")

#list(
[#text("(i) Show that ")#mi("{-\\zeta^{\\prime}(s) = \\sum_{n=1}^\\infty \\frac{\\ln n}{n^s}}")#text(".")],
[#text("(ii) Show that ")#mi("{\\zeta^2(s) = \\sum_{n=1}^\\infty \\frac{\\tau(n)}{n^s}}")#text(", where ")#mi("{\\tau(n) := \\sum_{d|n} 1}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Divisor_function")[#text("divisor function")]#text(" of ")#mi("{n}")#text(" (the number of divisors of ")#mi("{n}")#text(").")],
[#text("(iii) Show that ")#mi("{\\frac{1}{\\zeta(s)} = \\sum_{n=1}^\\infty \\frac{\\mu(n)}{n^s}}")#text(", where ")#mi("{\\mu(n)}")#text(" is the ")#link("https://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("Möbius function")]#text(", defined to equal ")#mi("{(-1)^k}")#text(" when ")#mi("{n}")#text(" is the product of ")#mi("{k}")#text(" distinct primes for some ")#mi("{k \\geq 0}")#text(", and ")#mi("{0}")#text(" otherwise.")],
[#text("(iv) Show that ")#mi("{\\frac{\\zeta(2s)}{\\zeta(s)} = \\sum_{n=1}^\\infty \\frac{\\lambda(n)}{n^s}}")#text(", where ")#mi("{\\lambda(n)}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Liouville_function")[#text("Liouville function")]#text(", defined to equal ")#mi("{(-1)^k}")#text(" when ")#mi("{n}")#text(" is the product of ")#mi("{k}")#text(" (not necessarily distinct) primes for some ")#mi("{k \\geq 0}")#text(".")],
[#text("(v) Show that ")#mi("{\\log \\zeta(s) = \\sum_{n=1}^\\infty \\frac{\\Lambda(n)/\\ln n}{n^s}}")#text(", where ")#mi("{\\log \\zeta}")#text(" is the holomorphic branch of the logarithm that is real for ")#mi("{s>1}")#text(", and with the convention that ")#mi("{\\Lambda(n)/\\ln n}")#text(" vanishes for ")#mi("{n=1}")#text(".")],
[#text("(vi) Use the fundamental theorem of arithmetic to show that the von Mangoldt function is the unique function ")#mi("{\\Lambda: {\\bf N} \\rightarrow {\\bf R}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\ln n = \\sum_{d|n} \\Lambda(d)")]]

#text("for every positive integer ")#mi("{n}")#text(". Use this and (i) to provide an alternate proof of the identity ")#link(<tao-5f8b67a0bb370867697d>)[#text("(8)")]#text(". Thus we see that ")#link(<tao-5f8b67a0bb370867697d>)[#text("(8)")]#text(" is really just another encoding of the fundamental theorem of arithmetic.")]
)
]

#text("Given the appearance of the von Mangoldt function ")#mi("{\\Lambda}")#text(", it is natural to reformulate the prime number theorem in terms of this function:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Prime number theorem, von Mangoldt form)")]#text(" ")#metadata(none) <tao-16ea2d0cb257a64124e8>#text(" One has")

#align(center)[#tao-fit-display[#mitex("\\lim_{x \\rightarrow \\infty} \\frac{1}{x} \\sum_{n \\leq x} \\Lambda(n) = 1")]]

#text("(or in asymptotic notation, ")#mi("{\\sum_{n\\leq x} \\Lambda(n) = x + o(x)}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(").")
]

#text("Let us see how Theorem ")#link(<tao-16ea2d0cb257a64124e8>)[#text("6")]#text(" implies Theorem ")#link(<tao-a160524700113ddd3205>)[#text("1")]#text(". Firstly, for any ")#mi("{x \\geq 2}")#text(", we can write")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) = \\sum_{p \\leq x} \\ln p + \\sum_{j=2}^\\infty \\sum_{p \\leq x^{1/j}} \\ln p.")]]

#text("The sum ")#mi("{\\sum_{p \\leq x^{1/j}} \\ln p}")#text(" is non-zero for only ")#mi("{O(\\ln x)}")#text(" values of ")#mi("{j}")#text(", and is of size ")#mi("{O( x^{1/2} \\ln x )}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) = \\sum_{p \\leq x} \\ln p + O( x^{1/2} \\ln^2 x ).")]]

#text("Since ")#mi("{x^{1/2} \\ln^2 x = o(x)}")#text(", we conclude from Theorem ")#link(<tao-16ea2d0cb257a64124e8>)[#text("6")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x} \\ln p = x + o(x)")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(". Next, observe from the fundamental theorem of calculus that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\ln p} - \\frac{1}{\\ln x} = \\int_p^x \\frac{1}{\\ln^2 y} \\frac{dy}{y}.")]]

#text("Multiplying by ")#mi("{\\log p}")#text(" and summing over all primes ")#mi("{p \\leq x}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\pi(x) - \\frac{\\sum_{p \\leq x} \\ln p}{\\ln x} = \\int_2^x \\sum_{p \\leq y} \\ln p \\frac{1}{\\ln^2 y} \\frac{dy}{y}.")]]

#text("From Theorem ")#link(<tao-16ea2d0cb257a64124e8>)[#text("6")]#text(" we certainly have ")#mi("{\\sum_{p \\leq y} \\ln p = O(y)}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\pi(x) - \\frac{x + o(x)}{\\ln x} = O( \\int_2^x \\frac{dy}{\\ln^2 y} ).")]]

#text("By splitting the integral into the ranges ")#mi("{2 \\leq y \\leq \\sqrt{x}}")#text(" and ")#mi("{\\sqrt{x} < y \\leq x}")#text(" we see that the right-hand side is ")#mi("{o(x/\\ln x)}")#text(", and Theorem ")#link(<tao-a160524700113ddd3205>)[#text("1")]#text(" follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Show that Theorem ")#link(<tao-a160524700113ddd3205>)[#text("1")]#text(" conversely implies Theorem ")#link(<tao-16ea2d0cb257a64124e8>)[#text("6")]#text(".")
]

#text("The alternate form ")#link(<tao-5f8b67a0bb370867697d>)[#text("(8)")]#text(" of the Euler product identity connects the primes (represented here via proxy by the von Mangoldt function) with the logarithmic derivative of the zeta function, and can be used as a starting point for describing further relationships between ")#mi("{\\zeta}")#text(" and the primes. Most famously, we shall see later in these notes that it leads to the remarkably precise ")#link("https://en.wikipedia.org/wiki/Explicit_formulae_for_L-functions")[#text("Riemann-von Mangoldt explicit formula")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8 (Riemann-von Mangoldt explicit formula)")]#text(" ")#metadata(none) <tao-7f2756f276876c723c49>#text(" For any non-integer ")#mi("{x > 1}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\leq x} \\Lambda(n) = x - \\lim_{T \\rightarrow \\infty} \\sum_{\\rho: \\left|\\text{Im}(\\rho)\\right| \\leq T} \\frac{x^\\rho}{\\rho} - \\ln(2\\pi) - \\frac{1}{2} \\ln( 1 - x^{-2} )", block: true)]]

#text("where ")#mi("{\\rho}")#text(" ranges over the non-trivial zeroes of ")#mi("{\\zeta}")#text(" with imaginary part in ")#mi("{[-T,T]}")#text(". Furthermore, the convergence of the limit is locally uniform in ")#mi("{x}")#text(".")
]

#text("Actually, it turns out that this formula is in some sense ")#emph[#text("too")]#text(" precise; in applications it is often more convenient to work with smoothed variants of this formula in which the sum on the left-hand side is smoothed out, but the contribution of zeroes with large imaginary part is damped; see Exercise ")#link(<tao-2df70e08bb8b19b937e2>)[#text("22")]#text(". Nevertheless, this formula clearly illustrates how the non-trivial zeroes ")#mi("{\\rho}")#text(" of the zeta function influence the primes. Indeed, if one formally differentiates the above formula in ")#mi("{x}")#text(", one is led to the (quite nonrigorous) approximation ")#metadata(none) <tao-e00443c76cfe2be97aa8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\Lambda(n) \\approx 1 - \\sum_\\rho n^{\\rho-1}")]]

#text(" ")#text(" or (writing ")#mi("{\\rho = \\sigma+i\\gamma}")#text(")")

#align(center)[#tao-fit-display[#mitex("\\Lambda(n) \\approx 1 - \\sum_{\\sigma+i\\gamma} \\frac{n^{i\\gamma}}{n^{1-\\sigma}}.")]]

#text("Thus we see that each zero ")#mi("{\\rho = \\sigma + i\\gamma}")#text(" induces an oscillation in the von Mangoldt function, with ")#mi("{\\gamma}")#text(" controlling the frequency of the oscillation and ")#mi("{\\sigma}")#text(" the rate to which the oscillation dies out as ")#mi("{n \\rightarrow \\infty}")#text(". This relationship is sometimes known informally as “the music of the primes”.")

#text("Comparing Theorem ")#link(<tao-7f2756f276876c723c49>)[#text("8")]#text(" with Theorem ")#link(<tao-16ea2d0cb257a64124e8>)[#text("6")]#text(", it is natural to suspect that the key step in the proof of the latter is to establish the following slight but important extension of Theorem ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("3")]#text("(ii), which can be viewed as a very small step towards the Riemann hypothesis:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9 (Slight enlargement of zero-free region)")]#text(" ")#metadata(none) <tao-5c7dad260e0b1d0f59ef>#text(" There are no zeroes of ")#mi("{\\zeta}")#text(" on the line ")#mi("{\\{ 1+it: t \\in {\\bf R} \\}}")#text(".")
]

#text("It is not quite immediate to see how Theorem ")#link(<tao-16ea2d0cb257a64124e8>)[#text("6")]#text(" follows from Theorem ")#link(<tao-7f2756f276876c723c49>)[#text("8")]#text(" and Theorem ")#link(<tao-5c7dad260e0b1d0f59ef>)[#text("9")]#text(", but we will demonstrate it below the fold.")

#text("Although Theorem ")#link(<tao-5c7dad260e0b1d0f59ef>)[#text("9")]#text(" only seems like a slight improvement of Theorem ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("3")]#text("(ii), proving it is surprisingly non-trivial. The basic idea is the following: if there was a zero at ")#mi("{1+it}")#text(", then there would also be a different zero at ")#mi("{1-it}")#text(" (note ")#mi("{t}")#text(" cannot vanish due to the pole at ")#mi("{s=1}")#text("), and then the approximation ")#link(<tao-e00443c76cfe2be97aa8>)[#text("(9)")]#text(" becomes")

#align(center)[#tao-fit-display[#mitex("\\Lambda(n) \\approx 1 - n^{it} - n^{-it} + \\dots = 1 - 2 \\cos(t \\ln n) + \\dots.")]]

#text("But the expression ")#mi("{1 - 2 \\cos(t \\ln n)}")#text(" can be negative for large regions of the variable ")#mi("{n}")#text(", whereas ")#mi("{\\Lambda(n)}")#text(" is always non-negative. This conflict eventually leads to a contradiction, but it is not immediately obvious how to make this argument rigorous. We will present here the classical approach to doing so using a trigonometric identity of Mertens.")

#text("In fact, Theorem ")#link(<tao-5c7dad260e0b1d0f59ef>)[#text("9")]#text(" is basically equivalent to the prime number theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" For the purposes of this exercise, assume Theorem ")#link(<tao-16ea2d0cb257a64124e8>)[#text("6")]#text(", but do not assume Theorem ")#link(<tao-5c7dad260e0b1d0f59ef>)[#text("9")]#text(". For any non-zero real ")#mi("{t}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("-\\frac{\\zeta^{\\prime}(\\sigma+it)}{\\zeta(\\sigma+it)} = o( \\frac{1}{\\sigma-1})")]]

#text("as ")#mi("{\\sigma \\rightarrow 1^+}")#text(", where ")#mi("{o( \\frac{1}{\\sigma-1})}")#text(" denotes a quantity that goes to zero as ")#mi("{\\sigma \\rightarrow 1^+}")#text(" after being multiplied by ")#mi("{\\sigma-1}")#text(". Use this to derive Theorem ")#link(<tao-5c7dad260e0b1d0f59ef>)[#text("9")]#text(".")
]

#text("This equivalence can help explain why the prime number theorem is remarkably non-trivial to prove, and why the Riemann zeta function has to be either explicitly or implicitly involved in the proof.")

#text("This post is only intended as the briefest of introduction to complex-analytic methods in analytic number theory; also, we have not chosen the shortest route to the prime number theorem, electing instead to travel in directions that particularly showcase the complex-analytic results introduced in this course. For some further discussion see ")#link("https://terrytao.wordpress.com/category/teaching/254a-analytic-prime-number-theory/")[#text("this previous set of lecture notes")]#text(", particularly ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(" and ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Supplement 3")]#text(" (with much of the material in this post drawn from the latter).")

#metadata(none) <tao-90ca54f9f32d369afd6c>

#heading(level: 1)[#strong[#text(" — 1. Meromorphic continuation and functional equation — ")]]

#text("We now focus on understanding the meromorphic continuation of ")#mi("{\\zeta}")#text(", as well as the functional equation that that continuation satisfies. The arguments here date back to ")#link("https://en.wikipedia.org/wiki/On_the_Number_of_Primes_Less_Than_a_Given_Magnitude")[#text("Riemann’s original paper on the zeta function")]#text(". The general strategy is to relate the zeta function ")#mi("{\\zeta(s)}")#text(" for ")#mi("{\\mathrm{Re}(s) > 1}")#text(" to some sort of integral involving the parameter ")#mi("{s}")#text(", which is manipulated in such a way that the integral makes sense for values of ")#mi("{s}")#text(" outside of the halfplane ")#mi("{\\{ s: \\mathrm{Re}(s) > 1 \\}}")#text(", and can thus be used to define the zeta function meromorphically in such a region. Often the Gamma function ")#mi("{\\Gamma}")#text(" is involved in the relationship between the zeta function and integral. There are many such ways to connect ")#mi("{\\zeta}")#text(" to an integral; we present some of the more classical ones here.")

#text("One way to motivate the meromorphic continuation ")#mi("{\\zeta}")#text(" is to look at the continuous analogue")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{s-1} = \\int_1^\\infty \\frac{1}{t^s}\\ dt, \\quad \\mathrm{Re} s > 1")]]

#text("of ")#link(<tao-cb9d7890ca12537fb514>)[#text("(1)")]#text(". This clearly extends meromorphically to the whole complex plane. So one now just has to understand the analytic continuation properties of the residual")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{s-1} - \\zeta(s) = \\int_1^\\infty \\frac{1}{t^s}\\ dt - \\sum_{n=1}^\\infty \\frac{1}{n^s}, \\quad \\mathrm{Re} s > 1.")]]

#text("For instance, using the Riemann sum type quadrature")

#align(center)[#tao-fit-display[#mitex("\\int_n^{n+1} \\frac{1}{t^s}\\ dt = \\frac{1}{n^s} + \\int_n^{n+1} \\frac{1}{t^s} - \\frac{1}{n^s}\\ dt")]]

#text("one can write this residual as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\int_n^{n+1} \\frac{1}{t^s} - \\frac{1}{n^s}\\ dt;")]]

#text("since ")#mi("{\\frac{1}{t^s} - \\frac{1}{n^s} = O_s( \\frac{1}{n^{\\mathrm{Re} s+1}} )}")#text(", it is a routine application of the Fubini and Morera theorems to establish analytic continuation of the residual to the half-plane ")#mi("{\\mathrm{Re} s > 0}")#text(", thus giving a meromorphic extension")

#metadata(none) <tao-b13e43084387f9835b70>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\zeta(s) = \\frac{1}{s-1} - \\sum_{n=1}^\\infty \\int_n^{n+1} \\frac{1}{t^s} - \\frac{1}{n^s}\\ dt")]]

#text("of ")#mi("{\\zeta}")#text(" to the region ")#mi("{\\{ s: \\mathrm{Re}(s) > 0 \\}}")#text(". Among other things, this shows that (the meromorphic continuation of) ")#mi("{\\zeta}")#text(" has a simple pole at ")#mi("{s=1}")#text(" with residue ")#mi("{1}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" ")#metadata(none) <tao-79d90153f879827bfb47>#text(" Using the trapezoid rule, show that for any ")#mi("{s}")#text(" in the region ")#mi("{\\{ s: \\text{Re}(s) > -1 \\}}")#text(" with ")#mi("{s \\neq 1}")#text(", there exists a unique complex number ")#mi("{\\zeta(s)}")#text(" for which one has the asymptotic")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n=1}^N \\frac{1}{n^s} = \\zeta(s) + \\frac{N^{1-s}}{1-s} + \\frac{1}{2} N^{-s} + O( \\frac{\\left|s\\right| \\left|s+1\\right|}{\\sigma+1} N^{-s-1} )", block: true)]]

#text("for any natural number ")#mi("{N}")#text(", where ")#mi("{s=\\sigma+it}")#text(". Use this to extend the Riemann zeta function meromorphically to the region ")#mi("{\\{ s: \\text{Re}(s) > -1 \\}}")#text(". Conclude in particular that ")#mi("{\\zeta(0)=-\\frac{1}{2}}")#text(" and ")#mi("{\\xi(0)=\\xi(1)= \\frac{1}{2}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" ")#metadata(none) <tao-348a629f5ceed032c3e8>#text(" Obtain the refinement")

#tao-aligned(keep: true)[


#tao-math("\\sum_{y \\leq n \\leq x} f(n)  & = \\int_y^x f(t)\\ dt + \\frac{1}{2} f(x) + \\frac{1}{2} f(y)", block: true)



#tao-math(" & + \\frac{1}{12} (f^{\\prime}(x) - f^{\\prime}(y)) + O( \\int_x^y |f^{\\prime\\prime\\prime}(t)|\\ dt )", block: true)
]

#text("to the trapezoid rule when ")#mi("{y < x}")#text(" are integers and ")#mi("{f: [y,x] \\rightarrow {\\bf C}}")#text(" is continuously three times differentiable. Then show that for any ")#mi("{s}")#text(" in the region ")#mi("{\\{ s: \\text{Re}(s) > -2 \\}}")#text(" with ")#mi("{s \\neq 1}")#text(", there exists a unique complex number ")#mi("{\\zeta(s)}")#text(" for which one has the asymptotic")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n=1}^N \\frac{1}{n^s}  & = \\zeta(s) + \\frac{N^{1-s}}{1-s} + \\frac{1}{2} N^{-s} - \\frac{s}{12} N^{-s-1}", block: true)



#tao-math(" & + O( \\frac{\\left|s\\right| \\left|s+1\\right| \\left|s+2\\right|}{\\sigma+2} N^{-s-2} )", block: true)
]

#text("for any natural number ")#mi("{N}")#text(", where ")#mi("{s=\\sigma+it}")#text(". Use this to extend the Riemann zeta function meromorphically to the region ")#mi("{\\{ s: \\text{Re}(s) > -2 \\}}")#text(". Conclude in particular that ")#mi("{\\zeta(-1)=-\\frac{1}{12}}")#text(".")
]

#text("One can keep going in this fashion using the Euler-Maclaurin formula (see ")#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/")[#text("this previous blog post")]#text(") to extend the range of meromorphic continuation to the rest of the complex plane. However, we will now proceed in a different fashion, using the theta function ")#metadata(none) <tao-7cd2ac73a02f098f0c16>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\theta(ix) = \\sum_{n \\in {\\bf Z}} e^{-\\pi n^2 x}")]]

#text(" ")#text(" that made an appearance in previous notes, and try to transform this function into the zeta function. We will only need this function for imaginary values ")#mi("{ix}")#text(" of the argument in the upper half-plane (so ")#mi("{x>0}")#text("); from Exercise 7 of ")#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/")[#text("Notes 2")]#text(" we have the modularity relation")

#metadata(none) <tao-0511abcb24917aec1ef5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\theta(i/x) = x^{1/2} \\theta(ix).")]]

#text("In particular, since ")#mi("{\\theta(ix)}")#text(" decays exponentially to ")#mi("{1}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(", ")#mi("{\\theta(ix)}")#text(" blows up like ")#mi("{x^{-1/2}}")#text(" as ")#mi("{x \\rightarrow 0}")#text(".")

#text("We will attempt to apply the Mellin transform (Exercise 11 from ")#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/")[#text("Notes 2")]#text(") to this function; formally, we have")

#align(center)[#tao-fit-display[#mitex("{\\mathcal M}[\\theta(i\\cdot)](s) := \\int_0^\\infty x^s \\theta(ix) \\frac{dx}{x}.")]]

#text("There is however a problem: as ")#mi("{x}")#text(" goes to infinity, ")#mi("{\\theta(ix)}")#text(" converges to one, and the integral here is unlikely to be convergent. So we will compute the Mellin transform of ")#mi("{\\theta(ix)-1}")#text(":")

#metadata(none) <tao-d5519d3c29a3b2a29be7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("{\\mathcal M}(\\theta(i\\cdot)-1)(s) := \\int_0^\\infty x^s (\\theta(ix)-1) \\frac{dx}{x}.")]]

#text("The function ")#mi("{\\theta-1}")#text(" decays exponentially as ")#mi("{x \\rightarrow \\infty}")#text(", and blows up like ")#mi("{O(x^{-1/2})}")#text(" as ")#mi("{x \\rightarrow 0}")#text(", so this integral will be absolutely integrable when ")#mi("{\\mathrm{Re} s > 1/2}")#text(". Since")

#align(center)[#tao-fit-display[#mitex("\\theta(ix)-1 = 2 \\sum_{n=1}^\\infty e^{-\\pi n^2 x}")]]

#text("we can write")

#align(center)[#tao-fit-display[#mitex("{\\mathcal M}(\\theta(i\\cdot)-1)(s) = 2 \\int_0^\\infty \\sum_{n=1}^\\infty x^s e^{-\\pi n^2 x} \\frac{dx}{x}.")]]

#text("By the Fubini–Tonelli theorem, the integrand here is absolutely integrable, and hence")

#align(center)[#tao-fit-display[#mitex("{\\mathcal M}(\\theta(i\\cdot)-1)(s) = 2 \\sum_{n=1}^\\infty \\int_0^\\infty x^s e^{-\\pi n^2 x} \\frac{dx}{x}.")]]

#text("From the Bernoulli definition of the Gamma function (Exercise 29(ii) of ")#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/")[#text("Notes 1")]#text(") and a change of variables we have")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty x^s e^{-\\pi n^2 x} \\frac{dx}{x} = \\frac{\\Gamma(s)}{(\\pi n^2)^s}")]]

#text("and hence by ")#link(<tao-cb9d7890ca12537fb514>)[#text("(1)")]#text(" we obtain the identity")

#align(center)[#tao-fit-display[#mitex("{\\mathcal M}(\\theta(i\\cdot)-1)(s) = \\frac{2 \\Gamma(s) \\zeta(2s)}{\\pi^s}")]]

#text("whenever ")#mi("{\\mathrm{Re}(s) > 1/2}")#text(". Replacing ")#mi("{s}")#text(" by ")#mi("{s/2}")#text(", we can rearrange this as a formula for the ")#mi("{\\xi}")#text(" function ")#link(<tao-c765d2f7b42f2a483927>)[#text("(4)")]#text(", namely")

#align(center)[#tao-fit-display[#mitex("\\xi(s) = \\frac{s(s-1)}{4} {\\mathcal M}(\\theta(i\\cdot)-1)(s/2)")]]

#text("whenever ")#mi("{\\mathrm{Re}(s) > 1}")#text(".")

#text("Now we exploit the modular identity ")#link(<tao-0511abcb24917aec1ef5>)[#text("(12)")]#text(" to improve the convergence of this formula. The convergence of ")#mi("{\\theta(ix)-1}")#text(" is much better near ")#mi("{x=\\infty}")#text(" than near ")#mi("{x=0}")#text(", so we use ")#link(<tao-d5519d3c29a3b2a29be7>)[#text("(13)")]#text(" to split")

#align(center)[#tao-fit-display[#mitex("\\xi(s) = \\frac{s(s-1)}{4} ( \\int_0^1 x^{s/2} (\\theta(ix)-1) \\frac{dx}{x} + \\int_1^\\infty x^{s/2} (\\theta(ix)-1) \\frac{dx}{x} )")]]

#text("and then transform the first integral using the change of variables ")#mi("{x \\mapsto 1/x}")#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("\\xi(s) = \\frac{s(s-1)}{4} ( \\int_1^\\infty x^{-s/2} (\\theta(i/x)-1) \\frac{dx}{x} + \\int_1^\\infty x^{s/2} (\\theta(ix)-1) \\frac{dx}{x} ).")]]

#text("Using ")#link(<tao-0511abcb24917aec1ef5>)[#text("(12)")]#text(" we can write this as")

#align(center)[#tao-fit-display[#mitex("\\xi(s) = \\frac{s(s-1)}{4} \\int_1^\\infty (x^{(1-s)/2} + x^{s/2}) (\\theta(ix)-1) + (x^{(1-s)/2}-x^{-\ts/2})\\frac{dx}{x}.")]]

#text("Direct computation shows that")

#align(center)[#tao-fit-display[#mitex("\\int_1^\\infty (x^{(1-s)/2}-x^{-s/2})\\frac{dx}{x} = \\frac{2}{s-1} - \\frac{2}{s} = \\frac{2}{s(s-1)}")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\xi(s) = \\frac{1}{2} + \\frac{s(s-1)}{4} \\int_1^\\infty (x^{(1-s)/2} + x^{s/2}) (\\theta(ix)-1) \\frac{dx}{x}")]]

#text("whenever ")#mi("{\\mathrm{Re}(s) > 1}")#text(". However, the integrand here is holomorphic in ")#mi("{x}")#text(" and exponentially decaying in ")#mi("{x}")#text(", so from the Fubini and Morera theorems we easily see that the right-hand side is an entire function of ")#mi("{s}")#text("; also from inspection we see that it is symmetric with respect to the symmetry ")#mi("{s \\mapsto 1-s}")#text(". Thus we can define ")#mi("{\\xi}")#text(" as an entire function, and hence ")#mi("{\\zeta}")#text(" as a meromorphic function, and one verifies the functional equation ")#link(<tao-0eb1d8cb89614a82f796>)[#text("(6)")]#text(".")

#text("It remains to establish that ")#mi("{\\xi}")#text(" is of order ")#mi("{1}")#text(". From ")#link(<tao-7cd2ac73a02f098f0c16>)[#text("(11)")]#text(" we have ")#mi("{\\theta(ix)-1 = O( e^{-\\pi x} )}")#text(" so from the triangle inequality")

#tao-aligned(keep: true)[


#tao-math("\\xi(s)  & \\lesssim 1 + (1+\\left|s\\right|)^2 \\int_1^\\infty x^{\\frac{1+\\left|s\\right|}{2}} e^{-\\pi x} \\frac{dx}{x}", block: true)



#tao-math(" & = 1 + (1+\\left|s\\right|)^2 \\pi^{-\\frac{1+\\left|s\\right|}{2}} \\Gamma( \\frac{1+\\left|s\\right|}{2} ).", block: true)
]

#text("From the Stirling approximation (Exercise 30(v) from ")#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/")[#text("Notes 1")]#text(") we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\xi(s) \\lesssim \\exp( O( \\left|s\\right| \\log \\left|s\\right| ) )", block: true)]]

#text("for ")#tao-math("{\\left|s\\right| \\geq 2}", block: false)#text(" (say), and hence ")#mi("{\\xi}")#text(" is of order at most ")#mi("{1}")#text(" as required. (One can show that ")#mi("{\\xi}")#text(" has order exactly one by inspecting what happens to ")#mi("{\\xi(s)}")#text(" as ")#mi("{s \\rightarrow +\\infty}")#text(", using that ")#mi("{\\zeta(s) \\rightarrow 1}")#text(" in this regime.) This completes the proof of Theorem ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("3")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Alternate derivation of meromorphic continuation and functional equation)")]

#list(
[#text("(i) Establish the identity")

#align(center)[#tao-fit-display[#mitex("\\Gamma(s) \\zeta(s) = \\int_0^\\infty \\frac{t^s}{e^t-1} \\frac{dt}{t}")]]

#text("whenever ")#mi("{\\mathrm{Re}(s) > 1}")#text(".")],
[#text("(ii) Establish the identity")

#metadata(none) <tao-9597914896177b517761>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\zeta(s) = \\frac{1}{\\Gamma(s) (1 - e^{2\\pi i(s-1)})} \\lim_{R \\rightarrow \\infty} \\int_{C_{R,\\varepsilon}} \\frac{z^s}{e^z-1} \\frac{dz}{z}")]]

#text("whenever ")#mi("{\\mathrm{Re}(s) > 1}")#text(", ")#mi("{s}")#text(" is not an integer, ")#mi("{\\varepsilon>0}")#text(", ")#mi("{z^s := \\exp( s \\mathrm{Log}_{[0,2\\pi)} z)}")#text(" where ")#mi("{\\mathrm{Log}_{[0,2\\pi)}}")#text(" is the branch of the logarithm with imaginary part in ")#mi("{[0,2\\pi)}")#text(", and ")#mi("{C_{R,\\varepsilon}}")#text(" is the contour consisting of the line segment ")#mi("{\\gamma_{R-i\\varepsilon \\rightarrow -i\\varepsilon}}")#text(", the semicircle ")#mi("{\\{ \\varepsilon e^{i(3\\pi/2 - \\theta)}: 0 \\leq \\theta \\leq \\pi \\}}")#text(", and the line segment ")#mi("{\\gamma_{i\\varepsilon \\rightarrow R+i\\varepsilon}}")#text(".")],
[#text("(iii) Use (ii) to meromorphically continue ")#mi("{\\zeta}")#text(" to the entire complex plane ")#mi("{{\\bf C}}")#text(".")],
[#text("(iv) By shifting the contour ")#mi("{C_{R,\\varepsilon}}")#text(" to the contour ")#mi("{\\tilde C_{R,N} := \\gamma_{R - 2\\pi i (N+1/2) \\rightarrow -1 - 2\\pi i(N+1/2) \\rightarrow -1 + 2\\pi i (N+1/2) \\rightarrow R + 2\\pi i (N+1/2)}}")#text(" for a large natural number ")#mi("{N}")#text(" and applying the residue theorem, show that")

#align(center)[#tao-fit-display[#mitex("\\lim_{R \\rightarrow \\infty} \\int_{C_{R,\\varepsilon}} \\frac{z^s}{e^z-1} \\frac{dz}{z} = 2\\pi i \\sum_{n \\in {\\bf Z} \\backslash \\{0\\}} (2\\pi i n)^{s-1}")]]

#text("again using the branch ")#mi("{\\mathrm{Log}_{[0,2\\pi)}}")#text(" of the logarithm to define ")#mi("{(2\\pi i n)^{s-1}}")#text(".")],
[#text("(v) Establish the functional equation ")#link(<tao-1cec177917a28d4c4548>)[#text("(5)")]#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Use the formula ")#mi("{\\zeta(-1)=\\frac{-1}{12}}")#text(" from Exercise ")#link(<tao-348a629f5ceed032c3e8>)[#text("12")]#text(", together with the functional equation, to give yet another proof of the identity ")#mi("{\\zeta(2) = \\frac{\\pi^2}{6}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Relation between zeta function and Bernoulli numbers)")]

#list(
[#text("(i) For any complex number ")#mi("{z}")#text(" with ")#mi("{\\text{Re}(z)>0}")#text(", use the Poisson summation formula (Proposition 3(v) from ")#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/")[#text("Notes 2")]#text(") to establish the identity")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\in {\\bf Z}} e^{-\\left|n\\right|z} = \\sum_{m \\in {\\bf Z}} \\frac{2z}{z^2+(2\\pi m)^2}.", block: true)]]],
[#text("(ii) For ")#mi("{z}")#text(" as above and sufficiently small, show that")

#align(center)[#tao-fit-display[#mitex("2\\sum_k (-1)^{k+1} \\zeta(2k) (z/2\\pi)^k = \\frac{z}{1-e^{-z}} - 1 - \\frac{z}{2}.")]]

#text("Conclude that")

#align(center)[#tao-fit-display[#mitex("\\zeta(2k) = \\frac{(-1)^{k+1} (2\\pi)^k}{2 (2k!)} B_{2k}")]]

#text("for any natural number ")#mi("{k}")#text(", where the ")#link("http://en.wikipedia.org/wiki/Bernoulli_number")[#text("Bernoulli numbers")]#text(" ")#mi("{B_2, B_4, B_6, \\dots}")#text(" are defined through the Taylor expansion")

#align(center)[#tao-fit-display[#mitex("\\frac{z}{1-e^{-z}} = 1 + \\frac{z}{2} + \\sum_k \\frac{B_{2k}}{(2k)!} z^{2k}.")]]

#text("Thus for instance ")#mi("{B_2 = 1/6}")#text(", ")#mi("{B_4 = -1/30}")#text(", and so forth.")],
[#text("(iii) Show that")

#metadata(none) <tao-f47058113ff944b203ff>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\zeta(-n) = -\\frac{B_{n+1}}{n+1}")]]

#text("for any odd natural number ")#mi("{n}")#text(". (This identity can also be deduced from the ")#link("http://en.wikipedia.org/wiki/Euler%E2%80%93Maclaurin_formula")[#text("Euler-Maclaurin formula")]#text(", which generalises the approach in Exercise ")#link(<tao-348a629f5ceed032c3e8>)[#text("12")]#text("; see ")#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation")[#text("this previous post")]#text(".)")],
[#text("(iv) Use ")#link(<tao-9597914896177b517761>)[#text("(14)")]#text(" and the residue theorem (now working inside the contour ")#mi("{\\tilde C_{R,N}}")#text(", rather than outside) to give an alternate proof of ")#link(<tao-f47058113ff944b203ff>)[#text("(15)")]#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16 (Convexity bounds)")]

#list(
[#text("(i) Establish the bounds ")#mi("{\\zeta(\\sigma+it) \\lesssim_\\sigma 1}")#text(" for any ")#mi("{\\sigma > 1}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(" with ")#tao-math("{\\left|t\\right|>1}", block: false)#text(".")],
[#text("(ii) Establish the bounds ")#tao-math("{\\zeta(\\sigma+it) \\lesssim_\\sigma \\left|t\\right|^{1/2-\\sigma}}", block: false)#text(" for any ")#mi("{\\sigma < 0}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(" with ")#tao-math("{\\left|t\\right|>1}", block: false)#text(". (Hint: use the functional equation.)")],
[#text("(iii) Establish the bounds ")#tao-math("{\\zeta(\\sigma+it) \\lesssim_{\\sigma,\\varepsilon} \\left|t\\right|^{\\frac{1-\\sigma}{2}+\\varepsilon}}", block: false)#text(" for any ")#mi("{0 \\leq \\sigma \\leq 1, \\varepsilon > 0}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(" with ")#tao-math("{\\left|t\\right|>1}", block: false)#text(". (Hint: use the Phragmén-Lindelöf principle, Exercise 19 from ")#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/")[#text("Notes 2")]#text(", after dealing somehow with the pole at ")#mi("{s=1}")#text(".)")]
)

#text("It is possible to improve the bounds (iii) in the region ")#mi("{0 < \\sigma < 1}")#text("; such improvements are known as ")#emph[#text("subconvexity estimates")]#text(". For instance, it is currently known that ")#tao-math("{\\zeta(\\frac{1}{2}+it) \\lesssim_\\mu (1+\\left|t\\right|)^\\mu}", block: false)#text(" for any ")#mi("{\\mu > 13/84}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(", a ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3556291")[#text("result of Bourgain")]#text("; the ")#link("https://en.wikipedia.org/wiki/Lindel%C3%B6f_hypothesis")[#text("Lindelöf hypothesis")]#text(" asserts that this bound in fact holds for all ")#mi("{\\mu>0}")#text(", although this remains unproven (it is however a consequence of the Riemann hypothesis).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17 (Riemann-von Mangoldt formula)")]#text(" ")#metadata(none) <tao-9bcc91b4b9f08ed96fc9>#text(" Show that for any ")#mi("{T \\geq 2}")#text(", the number of zeroes of ")#mi("{\\zeta}")#text(" in the rectangle ")#mi("{\\{ \\sigma+it: 0 \\leq \\sigma \\leq 1; 0 \\leq t \\leq T \\}}")#text(" is equal to ")#mi("{\\frac{T}{2\\pi} \\log \\frac{T}{2\\pi} - \\frac{T}{2\\pi} + O( \\log T )}")#text(". (")#emph[#text("Hint:")]#text(" apply the argument principle to ")#mi("{\\xi}")#text(" evaluated at a rectangle ")#mi("{\\gamma_{2-iT^{\\prime} \\rightarrow 2+iT^{\\prime} \\rightarrow -1+iT^{\\prime} \\rightarrow -1-iT^{\\prime} \\rightarrow 2-iT^{\\prime}}}")#text(" for some ")#mi("{T^{\\prime} = T + O(1)}")#text(" that is chosen so that the horizontal edges of the rectangle do not come too close to any of the zeroes (cf. the selection of the radii ")#mi("{R_k}")#text(" in the proof of the Hadamard factorisation theorem in ")#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/")[#text("Notes 1")]#text("), and use the functional equation and Stirling’s formula to control the asymptotics for the horizontal edges.)")

#text("We remark that the error term ")#mi("{O(\\log T)}")#text(", due to von Mangoldt in 1905, has not been significantly improved despite over a century of effort. Even assuming the Riemann hypothesis, the error has only been reduced very slightly to ")#mi("{O(\\log T/\\log\\log T)}")#text(" (a result of Littlewood from 1924).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 18")]#text(" Thanks to the functional equation and Rouche’s theorem, it is possible to numerically verify the Riemann hypothesis in any finite portion ")#tao-math("{\\{ \\sigma+it: 0 \\leq \\sigma \\leq 1; \\left|t\\right| \\leq T \\}}", block: false)#text(" of the critical strip, so long as the zeroes in that strip are all simple. Indeed, if there was a zero ")#mi("{\\sigma+it}")#text(" off of the critical line ")#mi("{\\sigma \\neq 1/2}")#text(", then an application of the argument principle (and Rouche’s theorem) in some small contour around ")#mi("{\\sigma+it}")#text(" but avoiding the critical line would be capable of numerically determining that there was a zero off of the line. Similarly, for each simple zero ")#mi("{\\frac{1}{2}+it}")#text(" on the critical line, applying the argument principle for some small contour around that zero and symmetric around the critical line would numerically verify that there was exactly one zero within that contour, which by the functional equation would then have to lie exactly on that line. (In practice, more efficient methods are used to numerically verify the Riemann hypothesis over large finite portions of the strip, but we will not detail them here.)")
]

#heading(level: 1)[#strong[#text(" — 2. The explicit formula — ")]]

#text("We now prove Riemann-von Mangoldt explicit formula. Since ")#mi("{\\xi}")#text(" is a non-trivial entire function of order ")#mi("{1}")#text(", with zeroes at the non-trivial zeroes of ")#mi("{\\zeta}")#text(" (the trivial zeroes having been cancelled out by the Gamma function), we see from the Hadamard factorisation theorem (in the form of Exercise 35 from ")#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/")[#text("Notes 1")]#text(") that")

#align(center)[#tao-fit-display[#mitex("\\frac{\\xi^{\\prime}(s)}{\\xi(s)} = B + \\sum_\\rho \\frac{1}{s-\\rho} + \\frac{1}{\\rho}")]]

#text("away from the zeroes of ")#mi("{\\xi}")#text(", where ")#mi("{\\rho}")#text(" ranges over the non-trivial zeroes of ")#mi("{\\zeta}")#text(" (note from Exercise ")#link(<tao-79d90153f879827bfb47>)[#text("11")]#text(" that there is no zero at the origin), and ")#mi("{B}")#text(" is some constant. From ")#link(<tao-c765d2f7b42f2a483927>)[#text("(4)")]#text(" we can calculate")

#align(center)[#tao-fit-display[#mitex("\\frac{\\xi^{\\prime}(s)}{\\xi(s)} = \\frac{\\zeta^{\\prime}(s)}{\\zeta(s)} + \\frac{1}{s} + \\frac{1}{s-1} - \\frac{1}{2} \\ln \\pi - \\frac{1}{2} \\frac{\\Gamma^{\\prime}(s/2)}{\\Gamma(s/2)}")]]

#text("while from Exercise 27 of ")#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/")[#text("Notes 1")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} \\frac{\\Gamma^{\\prime}(s/2)}{\\Gamma(s/2)} = -\\frac{1}{2} \\gamma + \\sum_{k=0,-2,-4,\\dots} \\frac{1}{2-k} - \\frac{1}{s-k}")]]

#text("and thus (after some rearranging)")

#metadata(none) <tao-7d601f9d20703a97b8cb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("-\\frac{\\zeta^{\\prime}}{\\zeta}(s) = B^{\\prime} + \\frac{1}{s-1} - \\sum_\\rho (\\frac{1}{s-\\rho} + \\frac{1}{\\rho}) - \\sum_{n=1}^\\infty (\\frac{1}{s+2n} - \\frac{1}{2n})")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("B^{\\prime} = -B - \\frac{1}{2} \\log \\pi - \\frac{1}{2} \\gamma.")]]

#text("One can compute the values of ")#mi("{B,B^{\\prime}}")#text(" explicitly:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" By inspecting both sides of ")#link(<tao-7d601f9d20703a97b8cb>)[#text("(16)")]#text(" as ")#mi("{s \\rightarrow 0}")#text(", show that ")#mi("{B^{\\prime} = - \\log 2\\pi + 1}")#text(", and hence ")#mi("{B = \\log 2 + \\frac{1}{2} \\log \\pi - 1 - \\frac{1}{2} \\gamma}")#text(".")
]

#text("Jensen’s formula tells us that the number of non-trivial zeroes of ")#mi("{\\zeta}")#text(" in a disk ")#mi("{D(0,R)}")#text(" is at most ")#mi("{O_\\varepsilon(R^{1+\\varepsilon})}")#text(" for any ")#mi("{\\varepsilon>0}")#text(" and ")#mi("{R>1}")#text(". One can obtain a local version:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20 (Local bound on zeroes)")]#text(" ")#metadata(none) <tao-4c849af9138c280a3e54>

#list(
[#text("(i) Establish the upper bound ")#tao-math("{\\left|\\zeta(\\sigma+it)\\right| \\lesssim \\left|t\\right|^{O(1)}}", block: false)#text(" whenever ")#mi("{\\frac{1}{4} \\leq \\sigma \\lesssim 1}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(" with ")#tao-math("{\\left|t\\right| \\geq 1}", block: false)#text(". (")#emph[#text("Hint:")]#text(" use ")#link(<tao-b13e43084387f9835b70>)[#text("(10)")]#text(". More precise bounds are available with more effort, but will not be needed here.)")],
[#text("(ii) Establish the bounds ")#tao-math("{\\left|\\zeta(2+it)\\right| \\sim 1}", block: false)#text(" uniformly in ")#mi("{t}")#text(". (")#emph[#text("Hint:")]#text(" use the Euler product.)")],
[#text("(iii) Show that for any ")#mi("{T \\geq 2}")#text(", the number of non-trivial zeroes with imaginary part in ")#mi("{[T,T+1]}")#text(" is ")#mi("{O(\\log T)}")#text(". (")#emph[#text("Hint:")]#text(" use Jensen’s formula and the functional equation.)")],
[#text("(iv) For ")#mi("{T \\geq 2}")#text(", ")#tao-math("{\\left|\\mathrm{Re} s\\right| \\leq 10}", block: false)#text(", and ")#tao-math("{\\left|\\mathrm{Im} s\\right| \\in [T,T+1]}", block: false)#text(", with ")#mi("{s}")#text(" not a zero of ")#mi("{\\zeta}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)} = \\sum_{\\rho: \\left|\\rho-s\\right| \\leq 1} \\frac{1}{s-\\rho} + O(\\log T).", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" use Theorem 9 of ")#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/")[#text("Notes 1")]#text(".)")]
)
]

#text("Meanwhile, from Perron’s formula (Exercise 12 of ")#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/")[#text("Notes 2")]#text(") and ")#link(<tao-5f8b67a0bb370867697d>)[#text("(8)")]#text(" we see that for any non-integer ")#mi("{x>1}")#text(", we have")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\leq x} \\Lambda(n)  & = \\frac{1}{2\\pi i} \\lim_{T \\rightarrow \\infty} \\int_{\\gamma_{2-iT \\rightarrow 2+iT}} (B^{\\prime} + \\frac{1}{s-1} - \\sum_\\rho (\\frac{1}{s-\\rho} + \\frac{1}{\\rho})", block: true)



#tao-math(" & - \\sum_{n=1}^\\infty (\\frac{1}{s+2n} - \\frac{1}{2n})) \\frac{x^s}{s}\\ ds.", block: true)
]

#text("We can compute individual terms here and then conclude the Riemann-von Mangoldt explicit formula:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21 (Riemann-von Mangoldt explicit formula)")]#text(" Let ")#mi("{T \\geq 2}")#text(" and ")#mi("{x > 1}")#text(". Establish the following bounds:")

#list(
[#text("(i) ")#mi("{\\frac{1}{2\\pi i} \\int_{\\gamma_{2-iT \\rightarrow 2+iT}} B^{\\prime} \\frac{x^s}{s}\\ ds = B^{\\prime} + O_x( 1/T )}")#text(".")],
[#text("(ii) ")#mi("{\\frac{1}{2\\pi i} \\int_{\\gamma_{2-iT \\rightarrow 2+iT}} \\frac{1}{s-1} \\frac{x^s}{s}\\ ds = x - 1 + O_x( 1/T )}")#text(".")],
[#text("(iii) For any positive integer ")#mi("{n}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi i} \\int_{\\gamma_{2-iT \\rightarrow 2+iT}} (\\frac{1}{s+2n} - \\frac{1}{2n}) \\frac{x^s}{s}\\ ds")]]

#align(center)[#tao-fit-display[#mitex("= \\frac{x^{-2n}}{2n} + O_x( \\frac{1}{n(n+T)} ).")]]],
[#text("(iv) For any non-trivial zero ")#mi("{\\rho}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi i} \\int_{\\gamma_{2-iT \\rightarrow 2+iT}} (\\frac{1}{s-\\rho} - \\frac{1}{\\rho}) \\frac{x^s}{s}\\ ds")]]

#align(center)[#tao-fit-display[#tao-math("= 1_{\\left|\\mathrm{Im}(\\rho)\\right| \\leq T} \\frac{x^{\\rho}}{\\rho} + O_x( \\frac{1}{(1+\\left|\\left|\\mathrm{Im}(\\rho)\\right| - T\\right|) (\\left|\\mathrm{Im}(\\rho)\\right|+T)} ).", block: true)]]],
[#text("(v) We have ")#mi("{\\lim_{T \\rightarrow \\infty} \\sum_{n=1}^\\infty \\frac{1}{n(n+T)} = 0}")#text(".")],
[#text("(vi) We have ")#tao-math("{\\lim_{T \\rightarrow \\infty} \\sum_\\rho \\frac{1}{(1+\\left|\\left|\\mathrm{Im}(\\rho)\\right| - T\\right|) (\\left|\\mathrm{Im}(\\rho)\\right|+T)} = 0}", block: false)#text(".")]
)

#text("(")#emph[#text("Hint:")]#text(" for (i)-(iii), shift the contour ")#mi("{\\gamma_{2-iT \\rightarrow 2+iT}}")#text(" to ")#mi("{\\gamma_{2-iT \\rightarrow -R-iT \\rightarrow -R+iT \\rightarrow 2+iT}}")#text(" for an ")#mi("{R}")#text(" that gets sent to infinity, and using the residue theorem. The same argument works for (iv) except when ")#mi("{\\rho}")#text(" is really close to ")#mi("{2+iT}")#text(", in which case a detour to the contour may be called for. For (vi), use Exercise ")#link(<tao-4c849af9138c280a3e54>)[#text("20")]#text(" and partition the zeroes depending on what unit interval ")#mi("{\\mathrm{Im}(\\rho)}")#text(" falls into.)")

#list(
[#text("(viii) Using the above estimates, conclude Theorem ")#link(<tao-7f2756f276876c723c49>)[#text("8")]#text(".")]
)
]

#text("The explicit formula in Theorem ")#link(<tao-7f2756f276876c723c49>)[#text("8")]#text(" is completely exact, but turns out to be a little bit inconvenient for applications because it involves all the zeroes ")#mi("{\\rho}")#text(", and the series involving them converges very slowly (indeed the convergence is not even absolute). In practice it is preferable to work with a smoothed version of the formula. Here is one such smoothing:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22 (Smoothed explicit formula)")]#text(" ")#metadata(none) <tao-2df70e08bb8b19b937e2>

#list(
[#text("(i) Let ")#mi("{g: {\\bf R} \\rightarrow {\\bf C}}")#text(" be a smooth function compactly supported on ")#mi("{(0,+\\infty)}")#text(". Show that ")#mi("{\\hat g}")#text(" is entire and obeys the bound")

#align(center)[#tao-fit-display[#tao-math("\\hat g(\\frac{i}{2\\pi} (\\sigma+it)) \\lesssim_g e^{c \\sigma} (1+\\left|t\\right|)^{-2}", block: true)]]

#text("(say) for some ")#mi("{c>0}")#text(", all ")#mi("{\\sigma \\leq 10}")#text(", and all ")#mi("{t \\in {\\bf R}}")#text(".")],
[#text("(ii) With ")#mi("{g}")#text(" as in (i), establish the identity")

#tao-aligned(keep: true)[


#tao-math("\\sum_n \\Lambda(n) g(\\ln n)  & = \\hat g(\\frac{i}{2\\pi}) - \\sum_\\rho \\hat g(\\frac{i}{2\\pi} \\rho)", block: true)



#tao-math(" & - \\sum_n \\hat g(-2n \\frac{i}{2\\pi})", block: true)
]

#text("with the summations being absolutely convergent by applying the Fourier inversion formula to ")#mi("{g}")#text(", shifting the contour to frequencies ")#mi("{\\frac{i}{2\\pi} (\\sigma+it)}")#text(" for some ")#mi("{\\sigma>1}")#text(", applying ")#link(<tao-5f8b67a0bb370867697d>)[#text("(8)")]#text(", and then shifting the contour again (using Exercise ")#link(<tao-4c849af9138c280a3e54>)[#text("20")]#text(" and (i) to justify the contour shifting).")],
[#text("(iii) Show that")

#tao-aligned(keep: true)[


#tao-math("\\sum_n \\Lambda(n) \\eta(n)  & = \\int_{\\bf R} (1 - \\frac{1}{y^3-y}) \\eta(y)\\ dy", block: true)



#tao-math(" & - \\sum_\\rho \\int_{\\bf R} \\eta(y) y^{\\rho-1}\\ dy", block: true)
]

#text("whenever ")#mi("{\\eta: {\\bf R} \\rightarrow {\\bf C}}")#text(" is a smooth function, compactly supported in ")#mi("{(1,+\\infty)}")#text(", with the summation being absolutely convergent.")],
[#text("(iv) Explain why (iii) is ")#emph[#text("formally")]#text(" consistent with Theorem ")#link(<tao-7f2756f276876c723c49>)[#text("8")]#text(" when applied to the non-smooth function ")#mi("{\\eta = 1_{[1,x]}}")#text(".")]
)
]

#heading(level: 1)[#strong[#text(" — 3. Extending the zero free region, and the prime number theorem — ")]]

#text("We now show how Theorem ")#link(<tao-5c7dad260e0b1d0f59ef>)[#text("9")]#text(" implies Theorem ")#link(<tao-16ea2d0cb257a64124e8>)[#text("6")]#text(". Let ")#mi("{2 \\leq T \\leq x}")#text(" be parameters to be chosen later. We will apply Exercise ")#link(<tao-2df70e08bb8b19b937e2>)[#text("22")]#text(" to a function ")#mi("{\\eta = \\eta_{T,x}}")#text(" which equals one on ")#mi("{[2,x]}")#text(", is supported on ")#mi("{[1.5, x + x/T]}")#text(", and obeys the derivative estimates")

#align(center)[#tao-fit-display[#mitex("\\eta^{(j)}(y) \\lesssim_j 1")]]

#text("for all ")#mi("{y \\in [1.5,2]}")#text(" and ")#mi("{j \\geq 0}")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\eta^{(j)}(y) \\lesssim_j (T/x)^j")]]

#text("for all ")#mi("{y \\in [x,x+T]}")#text(" and ")#mi("{j \\geq 0}")#text(". Such a function can be constructed by gluing together various rescaled versions of (antiderivatives of) standard bump functions. For such a function, we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) \\leq \\sum_n \\Lambda(n) \\eta(n).")]]

#text("On the other hand, we have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\eta(y)\\ dy = x + O(x/T)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\frac{1}{y^3-y} \\eta(y)\\ dy = O(1)")]]

#text("and hence")

#metadata(none) <tao-295a89c5af71c61e2351>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\sum_{n \\leq x} \\Lambda(n) \\leq x + O(x/T) + \\sum_\\rho O( \\left|\\int_{\\bf R} \\eta(y) y^{\\rho-1}\\ dy\\right| ).", block: true)]]

#text("We split into the two cases ")#tao-math("{\\left|\\rho\\right| \\leq T_*}", block: false)#text(" and ")#tao-math("{\\left|\\rho\\right| > T_*}", block: false)#text(", where ")#mi("{T_* \\geq T}")#text(" is a parameter to be chosen later. For ")#tao-math("{\\left|\\rho\\right| \\leq T_*}", block: false)#text(", there are only ")#mi("{O_T(1)}")#text(" zeros, and all of them have real part strictly less than ")#mi("{1}")#text(" by Theorem ")#link(<tao-5c7dad260e0b1d0f59ef>)[#text("9")]#text(". Hence there exists ")#mi("{\\varepsilon = \\varepsilon_{T_*} > 0}")#text(" such that ")#mi("{\\mathrm{Re} \\rho \\leq 1-\\varepsilon}")#text(" for all such zeroes. For each such zero, we have from the triangle inequality")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\eta(y) y^{\\rho-1}\\ dy \\lesssim_{T_*} x^{1-\\varepsilon}")]]

#text("and so the total contribution of these zeroes to ")#link(<tao-295a89c5af71c61e2351>)[#text("(17)")]#text(" is ")#mi("{O_{T_*}( x^{1-\\varepsilon})}")#text(". For each zero ")#mi("{\\rho}")#text(" with ")#tao-math("{\\left|\\rho\\right| \\geq T_*}", block: false)#text(", we integrate parts twice to get some decay in ")#mi("{\\rho}")#text(":")

#tao-aligned(keep: true)[


#tao-math("\\int_{\\bf R} \\eta(y) y^{\\rho-1}\\ dy  & = \\frac{-1}{\\rho} \\int_{\\bf R} \\eta^{\\prime}(y) y^\\rho\\ dy", block: true)



#tao-math(" & = \\frac{1}{\\rho(\\rho+1)} \\int_{\\bf R} \\eta^{\\prime\\prime}(y) y^{\\rho+1}\\ dy,", block: true)
]

#text("and from the triangle inequality and the fact that ")#mi("{\\mathrm{Re} \\rho \\leq 1}")#text(" we conclude")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\bf R} \\eta(y) y^{\\rho-1}\\ dy \\lesssim \\frac{1}{\\left|\\rho\\right|^2} \\frac{T^2}{x^2} \\frac{x}{T} x^2 = \\frac{T}{\\left|\\rho\\right|^2} x.", block: true)]]

#text("Since ")#tao-math("{\\sum_\\rho \\frac{1}{\\left|\\rho\\right|^2}}", block: false)#text(" is convergent (this follows from Exercise ")#link(<tao-4c849af9138c280a3e54>)[#text("20")]#text(" we conclude (for ")#mi("{T_*}")#text(" large enough depending on ")#mi("{T}")#text(") that the total contribution here is ")#mi("{O(x/T)}")#text(". Thus, after choosing ")#mi("{T_*}")#text(" suitably, we obtain the bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) \\leq x + O(x/T) + O_T(x^{1-\\varepsilon})")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) \\leq x + O(x/T)")]]

#text("whenever ")#mi("{x}")#text(" is sufficiently large depending on ")#mi("{T}")#text(" (since ")#mi("{\\varepsilon}")#text(" depends only on ")#mi("{T_*}")#text(", which depends only on ")#mi("{T}")#text("). A similar argument (replacing ")#mi("{x,x+x/T}")#text(" by ")#mi("{x-x/T, x}")#text(" in the construction of ")#mi("{\\eta}")#text(") gives the matching lower bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) \\geq x - O(x/T)")]]

#text("whenever ")#mi("{x}")#text(" is sufficiently large depending on ")#mi("{T}")#text(". Sending ")#mi("{T \\rightarrow \\infty}")#text(", we obtain Theorem ")#link(<tao-16ea2d0cb257a64124e8>)[#text("6")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" Assuming the Riemann hypothesis, show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) = x + O_\\varepsilon(x^{1/2+\\varepsilon})")]]

#text("for any ")#mi("{\\varepsilon>0}")#text(" and ")#mi("{x>1}")#text(", and that")

#align(center)[#tao-fit-display[#mitex("\\pi(x) = \\int_2^x \\frac{dt}{\\log t} + O_\\varepsilon(x^{1/2+\\varepsilon})")]]

#text("for any ")#mi("{\\varepsilon>0}")#text(" and ")#mi("{x>1}")#text(". Conversely, show that either of these two estimates are equivalent to the Riemann hypothesis. (")#emph[#text("Hint:")]#text(" find a holomorphic continuation of ")#mi("{-\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)} - \\frac{1}{s-1}}")#text(" to the region ")#mi("{\\mathrm{Re}(s) > 1/2}")#text(" in a manner similar to how ")#mi("{\\zeta(s)-\\frac{1}{s-1}}")#text(" was first holomorphically continued to the region ")#mi("{\\mathrm{Re}(s) > 0}")#text(").")
]

#text("It remains to prove Theorem ")#link(<tao-5c7dad260e0b1d0f59ef>)[#text("9")]#text(". The claim is clear for ")#mi("{t=0}")#text(" thanks to the simple pole of ")#mi("{\\zeta}")#text(" at ")#mi("{s=1}")#text(", so we may assume ")#mi("{t \\neq 0}")#text(". Suppose for contradiction that there was a zero of ")#mi("{\\zeta}")#text(" at ")#mi("{1+it}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\zeta(\\sigma+it) = O_t( \\sigma-1)")]]

#text("for ")#mi("{\\sigma>1}")#text(" sufficiently close to ")#mi("{1}")#text(". Taking logarithms, we see in particular that")

#align(center)[#tao-fit-display[#tao-math("\\ln \\left|\\zeta(\\sigma+it)\\right| \\leq - \\ln \\frac{1}{\\sigma-1} + O_t(1).", block: true)]]

#text("Using Lemma ")#link(<tao-fe6d3468cf5c74d8ec2a>)[#text("5")]#text("(v), we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=2}^\\infty \\frac{\\Lambda(n)/\\ln n}{n^\\sigma} \\cos(t \\ln n) \\leq - \\ln \\frac{1}{\\sigma-1} + O_t(1).")]]

#text("Note that the summands here are oscillatory due to the cosine term. To manage the oscillation, we use the simple pole at ")#mi("{s=1}")#text(" that gives")

#align(center)[#tao-fit-display[#mitex("\\zeta(\\sigma) \\sim \\frac{1}{\\sigma-1}")]]

#text("for ")#mi("{\\sigma>1}")#text(" sufficiently close to one, and on taking logarithms as before we get")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=2}^\\infty \\frac{\\Lambda(n)/\\ln n}{n^\\sigma} = \\ln \\frac{1}{\\sigma-1} + O(1).")]]

#text("These two estimates come close to being contradictory, but not quite (because we could have ")#mi("{\\cos(t\\ln n)}")#text(" close to ")#mi("{-1}")#text(" for most numbers ")#mi("{n}")#text(" that are weighted by ")#mi("{\\frac{\\Lambda(n)/\\ln n}{n^\\sigma}}")#text(". To get the contradiction, we use the analytic continuation of ")#mi("{\\zeta}")#text(" to ")#mi("{1+2it}")#text(" to conclude that")

#align(center)[#tao-fit-display[#mitex("\\zeta(\\sigma+2it) = O_t( 1)")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=2}^\\infty \\frac{\\Lambda(n)/\\ln n}{n^\\sigma} \\cos(2 t \\ln n) \\leq O_t(1).")]]

#text("Now we take advantage of the ")#emph[#text("Mertens inequality")]

#align(center)[#tao-fit-display[#mitex("3 + 4 \\cos(\\theta) + \\cos(2\\theta) = 2 (1 + \\cos(\\theta))^2 \\geq 0")]]

#text("(which is a quantitative variant of the observation that if ")#mi("{\\cos(\\theta)}")#text(" is close to ")#mi("{-1}")#text(" then ")#mi("{\\cos(2\\theta)}")#text(" has to be close to ")#mi("{+1}")#text(") as well as the non-negative nature of ")#mi("{\\Lambda(n)}")#text(" to conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=2}^\\infty \\frac{\\Lambda(n)/\\ln n}{n^\\sigma} (3 + 4\\cos(2 t \\ln n) + \\cos(2\\theta) \\geq 0")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("0 \\leq - \\ln \\frac{1}{\\sigma-1} + O_t(1).")]]

#text("This leads to the desired contradiction by sending ")#mi("{\\sigma \\rightarrow 1^+}")#text(", and proves the prime number theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" Establish the inequality")

#align(center)[#tao-fit-display[#tao-math("\\zeta(\\sigma)^3 \\left|\\zeta(\\sigma+it)\\right|^4 \\left|\\zeta(\\sigma+2it)\\right| \\geq 1", block: true)]]

#text("for any ")#mi("{t \\in {\\bf R}}")#text(" and ")#mi("{\\sigma>1}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 25")]#text(" There are a number of ways to improve Theorem ")#link(<tao-5c7dad260e0b1d0f59ef>)[#text("9")]#text(" that move a little closer in the direction of the Riemann hypothesis. Firstly, there are a number of ")#emph[#text("zero-free regions")]#text(" for the Riemann zeta function known that give lower bounds for ")#tao-math("{\\left|\\zeta(s)\\right|}", block: false)#text(" (and in particular preclude the existence of zeros) a small amount inside the critical strip, and can be used to improve the error term in the prime number theorem; for instance, the ")#emph[#text("classical zero-free region")]#text(" shows that there are no zeroes in the region ")#tao-math("{\\{ \\sigma+it: \\sigma \\geq 1 - \\frac{c}{\\ln(1+\\left|t\\right|)}}", block: false)#text(" for some sufficiently small absolute constant ")#mi("{c}")#text(", and lets one improve the ")#mi("{o(x)}")#text(" error term in Theorem ")#link(<tao-16ea2d0cb257a64124e8>)[#text("6")]#text(" to ")#mi("{O( x \\exp( -c\\sqrt{\\ln x}))}")#text(" (with a corresponding improvement in Theorem ")#link(<tao-a160524700113ddd3205>)[#text("1")]#text(", provided that one replaces ")#mi("{x/\\ln x}")#text(" with the ")#link("https://en.wikipedia.org/wiki/Logarithmic_integral_function")[#text("logarithmic integral")]#text(" ")#mi("{\\int_2^x \\frac{dt}{\\ln t}}")#text("). A further improvement in the zero free region and in the prime number theorem error term was subsequently given by Vinogradov. We also mention a number of important ")#emph[#text("zero density estimates")]#text(" which provide non-trivial upper bounds for the number of zeroes in other, somewhat larger regions of the critical strip; the bounds are not strong enough to completely exclude zeroes as is the case with zero-free regions, but can at least limit the collective influence of such zeroes. For more discussion of these topics, see the various lecture notes to ")#link("https://terrytao.wordpress.com/category/teaching/254a-analytic-prime-number-theory/")[#text("this previous course")]#text(".")
]

#heading(level: 1)[#text("Comments (86)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d188e8a4b98e52e7f60556353102fd436bf2240777b5d809927e7edb7c8ea6e-1e29daa8adbc1faba2abda6add320c98d228e44be8fa4cef2623bea7e9e05d94.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pcaceres00")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622259")[#strong[#text("pcaceres00")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("I would appreciate if someone could comment on the attached paper. Fascinating subject.")

#text("Many thanks in advance")#linebreak()#text(" Pedro Caceres")#linebreak()#text(" (763) 412-8915")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d188e8a4b98e52e7f60556353102fd436bf2240777b5d809927e7edb7c8ea6e-1e29daa8adbc1faba2abda6add320c98d228e44be8fa4cef2623bea7e9e05d94.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pcaceres00")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622261")[#strong[#text("pcaceres00")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("It would help if I add the link!")

#link("https://www.researchgate.net/publication/340296254_An_Engineer's_Approach_to_the_Riemann_Hypothesis_and_why_it_is_true")[#text("https://www.researchgate.net/publication/340296254_An_Engineer's_Approach_to_the_Riemann_Hypothesis_and_why_it_is_true")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622265")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("“In this paper we will provide a proof of the RH.” Possibly one or more such papers are published every day. Here to see quickly if possibly could make sense to have a look on one of them ")#link("https://www.scottaaronson.com/blog/?p=304")[#text("https://www.scottaaronson.com/blog/?p=304")]#text(" .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622266")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("In the second line, “la” is missing from the name de la Vallee Poussin")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622267")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("In (2), 645 should be 945")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622272")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("In theorem 3, it may be added that Euler product (3) is locally uniformly convergent (which may be used later to justify the term-wise logaritmic derivative to obtain (8) – without using Fubini theorem)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622275")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("“…from the divergence of the harmonic series we then conclude Euler’s theorem ")#mi("{\\sum_p \\frac{1}{p} = \\infty}")#text(". This can be viewed as a weak version of the prime number theorem,…”")

#text("I believe I heard somewhere the heuristic that a subset of the natural numbers has divergent reciprocal sum if and only if, roughly speaking, its density declines at rate ")#mi("1/\\log(n)")#text(" or slower. Is this true?")

#emph[#text("[Yes; this follows fairly readily from the ")#link("https://en.wikipedia.org/wiki/Cauchy_condensation_test")[#text("Cauchy condensation test")]#text(". For instance, density decaying faster than ")#mi("1/\\log^{1+\\varepsilon} n")#text(" will ensure convergence, whereas density that stays above ")#mi("1/\\log^{1-\\varepsilon} n")#text(" for all sufficiently large ")#mi("n")#text(" will guarantee divergence. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622277")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("So then the divergence of prime reciprocals already gives us yet another simple proof of “the prime number theorem up to a constant”?")

#emph[#text("[Not quite; the density could be wildly fluctuating to be significantly denser than ")#mi("1/\\log x")#text(" at some scales and significantly sparser at other scales. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622295")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("Not quite: the Cauchy condensation test applies to monotone series, and here you don’t know that the density of primes is monotone. Maybe there are long stretches with no primes (so the density falls low), follows by long sequences with many primes (so the density becomes large).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622278")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("“We remark that by sending ")#mi("{s}")#text(" to ")#mi("{1}")#text(" in Theorem 3(i) we conclude that")

#mi("\\displaystyle  \\sum_{n=1}^\\infty \\frac{1}{n} = \\prod_p (1-\\frac{1}{p})^{-1}")#text("”")

#text("It seems here we are implicitly using some Tauberian theorem or other, to assert that the divergence of ")#mi("\\sum_{n=1}^\\infty \\frac{1}{n^s}")#text(" as ")#mi("s \\rightarrow 1")#text(" implies the divergence of the partial sums of ")#mi("\\sum_{n=1}^\\infty \\frac{1}{n}")#text("? And similarly on the product side?")

#emph[#text("[Monotone convergence suffices here. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35e3f98c541902564da73168cadb043725b83be2f57ffe34cdee6ca3661b5894-d8e54f03162761dc3c9e3c1737e09c47ef243abb2ed13e4a46371adc0a04fd73.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Theorist")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622284")[#strong[#text("Theorist")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("I think, contrary to the prime number theorem, the equivalent relation that p_n is asymptotic to n ln(n), where p_n is the n-th prime itself, is much less known. By the way, this relation in turn is equivalent to the nice result that the p_n-th root of n^n tends to Euler’s number e if n tends to infinity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622293")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("I have been looking for the original proof of the prime number theorem. Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622296")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("The original proof is due to ")#link("https://www.claymath.org/sites/default/files/ezeta.pdf")[#text("Riemann (1859)")]#text(" (conditioned on the Riemann hypothesis). The essential ideas are there except for the proof that there are no zeroes on the line ")#mi("\\Re(s)=1")#text(", and for the more delicate handling this required compared with the case where the zeroes are well off that line.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622300")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("Lior I doubt that. I think the first proof was given by Hadamard and Poussin independently around the same time. Their proofs were heavily based on analysing a result due to Chebyshev on Chebyshev functions, and both used complex analytic methods quite heavily.")

#text("Once this proof was found, people wanted to somehow eliminate the complex analytic ingredients in quest to obtain an “elementary” proof of the result. There are also reports of several debates among mathematicians during that time on whether any such non complex analytic proof can be found or not. It is also believed that Hardy carried the impression that the prime number theorem draws so heavily on analysis of the zeta function, that eliminating the complex analytic ingredients from any proof of the result is almost impossible.")

#text("Much later the first and also the only such “elementary” proof was found independently by Paul Erdos and Atle Selberg, both using an identity due to Selberg.")

#text("Even later a very short proof was found by Newman. It is perhaps the shortest known proof of the prime number theorem and uses only very basic level complex analysis, such as those of analytic continuation and evaluation of contour integrals.")

#text("Towards the end of 2020 I read a nice article on the timeline of the prime number theorem, with some reports on debates among mathematicians on non-complex analytic proofs of the result, as well as the issue of rewarding the Fields Medal to Atle Selberg and not Erdos for the elementary proof, but I cannot find it unfortunately (:( ). If someone find it or if I find it, do comment below.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/84a23ab6c1723a1de9c5dd391b271e52f00db829110dde3dd4815190abdc4457-60d9f48e37d734e29c673c221d89e0ca60b40189735b5ae5edea4937831cb91c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ulrich")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622308")[#strong[#text("Ulrich")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2021")])]

#text("This one:")

#link("http://www.ms.uky.edu/~sohum/ma330/files/manuscripts/erdosselberg.pdf")[#text("Click to access erdosselberg.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622313")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2021")])]

#text("Both Selberg and Erdos contributed to the proof (Selberg initially thought that his important estimate was not sufficient to prove the PNT, but Erdos showed him how to prove the PNT from Selberg’s estimate)")#linebreak()#text(" Unfortunately, Selberg chose to publish a separate proof (based on another derivation of the PNT from his basic estimate) – thereby forcing Erdos to publish separately his original derivation of the PNT from Selberg’s basic estimate.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622320")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2021")])]

#text("Aditya: as I explained above, Riemann indeed proved the Prime Number Theorem, conditionally on the Riemann Hypothesis. Conditional proofs have a long history in mathematics — most famously Serre and Ribet proving Fermat’s Last Theorem conditionally on the Tanyiama–Shimura Conjecture, which was later substantially proved by Wiles.")

#text("Riemann’s memoir contains most of the key ideas of the proof. De la Valée Poussin and Hadamard completed the work by giving the first ")#emph[#text("unconditional")]#text(" proofs, but Riemann’s contribution is still the greater.")

#text("Mathematics is a race where often winners are declared by coming ")#emph[#text("last")]#text(": whoever makes the final contribution gets the glory. Sometimes it’s right (the hardest part is often left for last, after all), but sometimes it’s wrong: until the earlier work there was no room for the later. Before Riemann there was no avenue to prove the PNT at all. After Riemann there was a conditional proof and a clear direction.")

#text("For the same reason I credit FLT to Ribet, and the Modularity Theorem to Wiles. Here Wiles’s contribution is greater (the proof of the FLT is mainly of historical importance, while modularity is an essential part of mathematics), but still the FLT was proved by Ribet, not Wiles.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622337")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2021")])]

#text("Ah, I see your point of view, Lior. If you like to call / view it that way then it’s fair enough.")#linebreak()#text(" By “original” I meant the first complete proof which doesn’t assume anything which is not known till date.")#linebreak()#text(" By the way just some nitpicking : given that the truth of Riemann hypothesis is not known till date, would you still say that Riemann “proved” the prime number theorem?")#linebreak()#text(" (Of course now that we know the PNT is true so ex falso quodlibet plays the game.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622321")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2021")])]

#text("I’ve wondered whether Riemann was the very first person to introduce complex methods into number theory. Do you know if Dirichlet’s proof of arithmetic progressions used it in any essential way?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622332")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2021")])]

#text("Indeed Riemann completely revolutionized the field, which is why I credit him with a proof of the PNT. He both had a rigorous conditional proof (subject to RH) and charted the path for the first unconditional proofs.")

#text("Dirichlet’s proof of his theorem is based on Euler’s proof of the infinitude of primes (discussed above after Theorem 3), and lives entirely on the real axis. He originally only used the pole to show that there were infinitely many primes in each admissible arithmetic progression, and later observed that the proof is actually quantitative: generalizing Mertens’s Theorem")

#mi("\\sum_{p\\leq x} \\frac1p = \\log\\log x + O(1)")

#text("Dirichlet shows (purely by real-variable methods, even if some later proofs use complex methods)")

#mi("\\sum_{\\substack{p\\leq x\\\\p \\equiv a\\,(q)}} \\frac1p = \\frac{1}{\\phi(q)} \\log\\log x + O(1)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622338")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2021")])]

#text("Rex, if you go through Dirichlet’s proof of Dirichlet’s theorem, you will find that his proof did involve complex analytic ingredients in it in analysing the L functions which were crucially used in proving the result.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622348")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2021")])]

#text("Aditya: ")#text("Dirichlet’s proof")#text(" (I link to an English translation) did not use complex analysis at all. ")#emph[#text("Today")]#text(" (with the benefit of hindsight) we can see that his arguments prove that his L-series have analytical continuation to the half-plane ")#mi("\\Re(s)>0")#text(". But if you read the paper carefully you’ll see that the parameter ")#mi("s")#text(" only takes ")#emph[#text("real")]#text(" values. The values ")#mi("L(s)")#text(" are complex (because the Dirichlet characters take complex values), but that does not make the ")#emph[#text("proof")]#text(" involve complex analysis. In fact Dirichlet is careful to argue about real and complex parts separately.")

#text("The paper is interesting also for Dirichlet’s calling attention to the distinction between absolutely convergent and conditionally convergent series, and showing he was aware that conditionally convergent series could be rearranged to sum to different values (what we call today “Riemann’s Rearrangement Theorem”).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622349")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2021")])]

#text("Here’s the link to the proof since it didn’t work in the comment above (a double quotes symbol is off in the HTML)")#linebreak()#text(" ")#link("https://arxiv.org/abs/0808.1408")[#text("https://arxiv.org/abs/0808.1408")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622357")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2021")])]

#text("Ah, thanks Lior. I didn’t know of this. I read the proof from Davenport’s text on MNT, and I developed the impression that the proof discussed in the text is what Dirichlet actually did himself. Thank you for the link.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622310")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2021")])]

#text("Reblogged this on ")#link("https://scoutmathematics.wordpress.com/2021/02/13/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/")[#text("Aditya Guha Roy's weblog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622315")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2021")])]

#text("“By splitting the integral into the ranges ")#mi("{2 \\leq y \\leq \\sqrt{x}}")#text(" and ")#mi("{\\sqrt{x} < y \\leq x}")#text(" we see that the right-hand side is ")#mi("{o(x/\\ln x)}")#text(", and Theorem 1 follows.\"")

#text("I've seen this strategy of decomposing an integral or sum into ranges above and below ")#mi("\\sqrt{x}")#text(" in several places, to bound the pieces separately. But I've never really understood the basic principle behind why it works. Why is ")#mi("\\sqrt{x}")#text(" a good cutoff to use?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622345")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2021")])]

#text("The most difficult term to understand in the integral is the ")#mi("\\ln y")#text(" term, which varies in ")#mi("y")#text(". But within the range ")#mi("y \\in [\\sqrt{x},x]")#text(", ")#mi("\\ln y")#text(" is constant (up to bounded multiplicative error), so this term can be simplified. In general, when trying to estimate an integral, it can often be beneficial to break up into pieces where one or more of the terms in the integral is approximately constant, as one can then often replace that term by the constant and get an easier expression to estimate which is still equivalent to the original expression up to constants. One could have replaced ")#mi("\\sqrt{x}")#text(" here by other small powers of ")#mi("x")#text(", but this is as good a choice as any here as the contribution of the very small ")#mi("y")#text(" ends up being negligible and can be controlled satisfactorily by virtually any estimate.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622318")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2021")])]

#text("“From (6) we certainly have ")#mi("{\\sum_{p \\leq y} \\ln p = O(y)}")#text(", thus")#linebreak()#text(" ")#mi("\\displaystyle  \\pi(x) - \\frac{x + o(x)}{\\ln x} = O( \\int_2^x \\frac{dy}{\\ln^2 y} ).")#text("”")

#text("It seems the reference (6) wants to refer to the (unnumbered) formula five lines up, but it’s not actually directing to this.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622350")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2021")])]

#text("“or (writing ")#mi("{\\rho = \\sigma+i\\gamma}")#text(")")#linebreak()#text(" ")#mi("\\displaystyle  \\Lambda(n) \\approx 1 - \\sum_{\\sigma+i\\gamma} \\frac{n^{i\\gamma}}{n^{\\sigma-1}}.")#text("”")

#text("I think here you want the bottom exponent to be ")#mi("1 - \\sigma")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bf23ebe11fcbe0a61f64f59239b469fe4ee5076b883e15afea619b4b55ffb4b-054844e28292f70f825dd0fb4a8a6b451c1cdf5bd9a9f72293281da9ef6261fb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avi Levy")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622352")[#strong[#text("Avi Levy")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2021")])]

#text("Just as the “")#mi("\\zeta")#text(" as Mellin transform of ")#mi("\\theta")#text("” point of view explains how the Poisson summation formula is the source of the critical line reflection symmetry, it brings up a (vague and ill-posed) question about the nature of the square root fluctuations in the explicit formula.")#linebreak()#text(" On the one hand, the exponent ")#mi("\\tfrac12")#text(" is a fixed point of this symmetry. On the other hand, there are “randomness of the primes” heuristics where the ")#mi("\\tfrac12")#text(" comes from Brownian fluctuations, which traces its source to linearity of variance for sums of independent random variables.")#linebreak()#text(" Are these two explanations of the square root fluctuations somehow connected? Or is it akin to phenomena in statistical physics models where the self-dual point happens to coincide with the critical point, as in ")#link("https://arxiv.org/abs/1006.5073")[#text("https://arxiv.org/abs/1006.5073")]#text(" for example?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622354")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2021")])]

#text("It is related to the idea of “square root cancellation”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622519")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2021")])]

#text("Hmm, interesting question. Certainly probabilistic methods can be used without any appeal to the functional equation to give some statistical control on say the Riemann zeta function in the region ")#mi("\\{ \\mathrm{Re} s > 1/2 \\}")#text(", for instance one can show without much difficulty (basically the ")#mi("L^2")#text(" mean value theorem) that almost all of the zeroes avoid the region ")#mi("\\{ \\mathrm{Re} s > 1/2 + \\varepsilon \\}")#text(" for any fixed ")#mi("\\varepsilon")#text(". Here the “1/2” is the same 1/2 that comes from Brownian motion, or more generally in applications of the second moment method. This is only consistent with a functional equation if the critical line of that functional equation is at or to the left of ")#mi("1/2")#text(". On the other hand I don’t see a probabilistic argument that explains why the critical line has to be exactly at ")#mi("1/2")#text("; this would involve some way to understand zeta to the left of the critical line that does not involve the functional equation. Still, this sort of coincidence between the abscissa coming from second moment considerations and the abscissa coming from the functional equation does seem to be pretty universal amongst all the other L-functions in number theory so presumably there is a more robust explanation of this phenomenon.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622353")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2021")])]

#text("In the Wikipedia article on the zeta function it is remarked that the functional equation (5) was discovered and conjectured by Euler (for integer values of ")#mi("s")#text(") in 1749.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e116ad42bc17cc26e02ec2b41665d50ae24e72830366d2f39aec0318ae7246a-5750d896b0f484796c62ffe048fa3caf4be00534965b5692b7b2e11fa545bcea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of justderiving")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622365")[#strong[#text("justderiving")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2021")])]

#text("What would happen to the field of math if the Riemann hypothesis were proven false or true?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-638392")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2021")])]

#text("If the Riemann hypothesis turns out to be true then it would be more exciting than any other discovery in number theory in the last few decades. It will also answer several other questions in different parts of mathematics, and also outside mathematics.")

#text("Of course, if it can be proved that RH is false, that would also be an amazing discovery, but probably that will not make us that happy, as the hope for many other things will be lost.")

#text("There are several papers (which are authentic and reviewed) on several equivalences of RH on the internet.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622395")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2021")])]

#text("“from Exercise 11 that there is no zero at the origin), and ")#mi("{B}")#text(" is some constant. From (4) we can calculate")#linebreak()#text(" ")#mi("\\displaystyle \\frac{\\xi^{\\prime}(s)}{\\xi(s)} =\\frac{1}{s} + \\frac{1}{s-1} - \\frac{1}{2} \\ln \\pi - \\frac{1}{2} \\frac{\\Gamma^{\\prime}(s/2)}{\\Gamma(s/2)}")#text("”")

#text("This formula is missing ")#mi("\\displaystyle \\frac{\\zeta^{\\prime}(s)}{\\zeta(s)}")#text(" on the right.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622526")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2021")])]

#text("Is it just me, or is it still missing?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622698")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2021")])]

#text("Also, there is now an extraneous ")#mi("\\displaystyle \\frac{\\zeta^{\\prime}(s)}{\\zeta(s)}")#text(" in the formula immediately above this one. Probably from the first attempt to fix it.")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63ddb2932f75fce714a4ee7d91dae89a8bd85d72e3a60b5795d6a2434f5e71af-a788db6748036dabecc6eaea2fb41740c9f05215f2630ece0f1a46929cc5c196.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph Sugar")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622405")[#strong[#text("Joseph Sugar")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2021")])]

#text("Riemann states in his paper that he is interested in the prime numbers’ density distribution, not in finding more precise prime number theorems. His formula for x = 2000.000 is exact, so finding better and better approximations was probably already not very exciting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622411")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2021")])]

#text("In the proof of Theorem 3(i), you have used monotone convergence, but that’s only good for $s$ real and positive, right?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622442")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2021")])]

#text("Yes. The proof above uses monotone convergence for ")#mi("s")#text(" real and positive (actually for ")#mi("s>1")#text("), and then dominated convergence to go from there to the halfplane ")#mi("\\Re(s)>1")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622480")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2021")])]

#text("I believe in Exercise 12, it should be ")#mi("\\frac1{12}(f^{\\prime}(x)-f^{\\prime}(y))")#text(" rather than ")#mi("\\frac 1{12}(f^{\\prime}(y)-f^{\\prime}(x))")#text("? (The current version seems to give ")#mi("\\zeta(-1)=\\frac{1}{12}")#text(").")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622508")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2021")])]

#text("Thought this would be relevant: ")#link("https://mathoverflow.net/questions/58004/how-does-one-motivate-the-analytic-continuation-of-the-riemann-zeta-function/380502#380502")[#text("https://mathoverflow.net/questions/58004/how-does-one-motivate-the-analytic-continuation-of-the-riemann-zeta-function/380502#380502")]#text(" here prof. Tao discusses a nice way to motivate (/ see naturally) the meromorphic continuation of the zeta function.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622517")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2021")])]

#text("I believe the exponent in equation (12) should be +1/2, not -1/2. Thank you for posting these great notes!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622544")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2021")])]

#text("Dear respected Pro.Tao,")#linebreak()#text(" Is there any relationship between you and my night dream?")#linebreak()#text(" In 2019, I dreamed about numbers but not clear. A month later, you claimed that you proved Collatz conjecture. In 2020, I also dreamed about many numbers but not clear. Strangely, a month later, you announced that you proved Sendov conjecture. But this time, with the third night dream one month ago in 2021, I had seen many numbers, many equations x, y,z , many maths signals very long and densly . I saw them very clearly like at noon, different from two previous dreams. I am happy myself and I wonder whether Pro.Tao is going to claim proving one clay millenium problem successfully. I hope my third dream is right certainly. My guess that they are Riemann hypothesis, Navier Stokes existence and smoothness, Birch Swinerton Dyer conjecture.")#linebreak()#text(" Bye Pro Tao.( I always wait good news from you)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Course announcement: 246B, complex analysis | What's new")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622826")[#strong[#text("Course announcement: 246B, complex analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("[…] (if time permits) the Riemann zeta function and the prime number theorem. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 3: Elliptic functions and modular forms | What's new")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622831")[#strong[#text("246B, Notes 3: Elliptic functions and modular forms | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("[…] Previous set of notes: Notes 2. Next set of notes: Notes 4. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246C notes 1: Meromorphic functions on Riemann surfaces, and the Riemann-Roch theorem | What's new")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622834")[#strong[#text("246C notes 1: Meromorphic functions on Riemann surfaces, and the Riemann-Roch theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("[…] set of notes: 246B Notes 4. Next set of notes: Notes 2. The fundamental object of study in real differential geometry are the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5fff2261aa6f75854dfbd0f66118e7e774ac9220d8a2ca337ca1d717924b98f-6de15b6ab571e01c62e3cb4401225a118afc1fec17edc4a813caa30ceaf3a5ac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frank Vega")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-622863")[#strong[#text("Frank Vega")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("Good notions (Thanks…)!!! It’s great to obtain for free just already summarized many things here (into a single page instead of trying to find them from many reference papers). I didn’t see the Lagarias and Robin inequalities here. Maybe, they are in the previous posts related to this one. Proving the RH by proving a simple inequality looks very attractive. However, behind these inequalities, we could find a deep estimates on the distribution of primes. I have moved forward in this tempting direction:")

#link("https://doi.org/10.5281/zenodo.3648511")[#text("https://doi.org/10.5281/zenodo.3648511")]

#text("What do you think?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0cc5c5b58984fd8189ecbd929d29b01a826651e0c09b23f3bd634be13eedaaa9-d6d1d5cfe1043cacae035da57d5d17ba965c8e55b19bbe97d948d36de7810dd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An elementary proof of divergence of the sum of reciprocal of prime numbers | Aditya Guha Roy's weblog")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-623238")[#strong[#text("An elementary proof of divergence of the sum of reciprocal of prime numbers | Aditya Guha Roy's weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2021")])]

#text("[…] of primes diverges by contrasting it with the already-known-to-be-divergent harmonic sum (see this blogpost by professor Terence Tao for more details); in this blogpost I discuss a proof of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-623437")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2021")])]

#text("In case anyone is interested (like I was) ")#link("https://www.claymath.org/publications/riemanns-1859-manuscript")[#text("https://www.claymath.org/publications/riemanns-1859-manuscript")]#linebreak()#text(" here you can find the versions (such as the original paper, its German transcription, English translation etc.) of Riemann’s paper where he analyzed the zeta function, introduced the xi function etc..")

#text("Fact:")#linebreak()#text(" This is the only paper Riemann wrote on number theory, and as we all know today this changed the way we look at several topics in number theory and in a sense contributed the most towards development of the modern day subject of analytic number theory.")

#text("Also see some comments above by Dr. Lior for further discussion on his methods and related things.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/229996b1a95304c5bb35998a799951f24dcb764581cd9e0ea2e2b6504b4f9ca3-fe7e35ef6416669df4c32756824903d52aeb77192f81e0186c383e539975d1ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guillaume")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-623807")[#strong[#text("Guillaume")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2021")])]

#text("Dear Terence,")#linebreak()#text(" You write that “the Riemann zeta function has to be either explicitly or implicitly involved in [any] proof [of the PNT]”. Could you explain if this applies (and how) to Florian Richter’s recent new elementary proof as well? (arXiv:2002.03255)")#linebreak()#text(" (I mean, is there a way to re-understand Richter’s proof, or in a way to see where it comes from or rediscover it, in terms the zeta function?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-623843")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2021")])]

#text("Hi Guillaume, let me say what I think is relevant.")

#text("It is true that there can exist proofs which do not involve analysing the Riemann zeta function “explicitly”, for instance Erdos and Selberg (to some extent independently) gave an elementary proof of the PNT which actually doesn’t call for any explicit analysis of the Riemann zeta function.")#linebreak()#text(" However the Riemann zeta function is always connected to the ingredients of the prime number theorem and hence with the PNT as well, thanks to the fundamental theorem of arithmetic (and as a consequence the Euler’s product formula) which allows us to write the zeta function evaluated at some point ")#mi("s")#text(" in the upper half plane ")#mi("\\{ z \\in \\mathbf{C} : Re(z) > 1 \\}")#text(" involving prime numbers; this connection is the reason why the conclusion of the PNT and the behaviour of the zeta function are so implicitly related.")

#text("Thus to put it in a nutshell, the connection of the prime numbers and the zeta function is really very fundamental to understanding the behaviour of the primes and hence any result such as the prime number theorem is believed to have some implicit or explicit connection with the zeta function.")

#text("For a broader discussion on how Riemann came about this connection you can read his paper which is mentioned in the blogpost above or in one of the above comments by me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-624214")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2021")])]

#text("From Fourier or complex-analytic methods, the prime number theorem is equivalent to the non-vanishing ")#mi("\\zeta(1+it) = 0")#text(" on the right edge of the critical strip. From a pretentious number theory viewpoint, this non-vanishing amounts to the M\\”obius function ")#mi("\\mu(n)")#text(" “pretending” to be like the function ")#mi("n^{it}")#text(", in the sense that ")#mi("p^{it} \\approx -1")#text(" for almost all large primes. So the hard part of any proof of the PNT (elementary or otherwise) comes about in eliminating the ")#mi("p^{it} \\approx -1")#text(" scenario. In this perspective, the classical complex analytic proof proceeds basically by observing that ")#mi("p^{it} \\approx -1")#text(" would imply ")#mi("p^{2it} \\approx +1")#text(" which would eventually lead to a pole forming at ")#mi("1+2it")#text(". The elementary proof of Erdos and Selberg basically exploits the Brun-Titchmarsh inequality to show that the large primes cannot all concentrate in the region ")#mi("\\{ n: n^{it} \\approx -1 \\}")#text(".")

#text("Viewing Richter’s proof (or the similar recent elementary ")#link("https://arxiv.org/abs/2002.04007")[#text("proof by McNamara")]#text(") in this lens, the point is that a weak version of Brun-Titchmarsh (that can be proven by the classical methods of Chebyshev) is again enough to preclude the large primes concentrating in a region such as ")#mi("\\{ n: n^{it} \\approx -1 \\}")#text(", though the nice thing about these proofs is that the frequency parameter ")#mi("t")#text(" does not make an explicit appearance, and is instead only implicit through the application of iterated multiplicative convolution (Richter studies products of ")#mi("k")#text(" primes for some large ")#mi("k")#text(", while McNamara instead compares the distribution of primes with the distribution of semiprimes.) (The Erdos-Selberg proof similarly hides the role of the frequency parameter ")#mi("t")#text(", traditionally through the use of various Tauberian theorems.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0cc5c5b58984fd8189ecbd929d29b01a826651e0c09b23f3bd634be13eedaaa9-d6d1d5cfe1043cacae035da57d5d17ba965c8e55b19bbe97d948d36de7810dd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Riemann zeta function from an elementary level number theoretic viewpoint: a prelude to the Riemann zeta function | Aditya Guha Roy's weblog")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-624410")[#strong[#text("Riemann zeta function from an elementary level number theoretic viewpoint: a prelude to the Riemann zeta function | Aditya Guha Roy's weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2021")])]

#text("[…] an earlier blogpost I re-blogged a very interesting blogpost on the Riemann zeta function, the prime number theorem and their connections with complex analysis […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0cc5c5b58984fd8189ecbd929d29b01a826651e0c09b23f3bd634be13eedaaa9-d6d1d5cfe1043cacae035da57d5d17ba965c8e55b19bbe97d948d36de7810dd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Riemann zeta function: connections with the von Mangoldt function and a look at the prime number theorem | Aditya Guha Roy's weblog")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-625186")[#strong[#text("Riemann zeta function: connections with the von Mangoldt function and a look at the prime number theorem | Aditya Guha Roy's weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2021")])]

#text("[…] a particular emphasis on relating it to the von-Mangoldt function. The contents here are based on this blogpost on the topic by professor Terence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d4b19098171cff5147cb5af5e89d688f6d0a83dcca79e979fee2ab496637883-f148e55e951cafb9908f15e2e40b1a4e7731af5b3fc7907f354685ce020203fa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of project_2501")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-625544")[#strong[#text("project_2501")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2021")])]

#text("I am a beginner in this field. I am intrigued by the statement:")

#text("“”")#linebreak()#text(" We remark that by sending {s} to 1 in Theorem 3(i) we conclude that")

#text("\\displaystyle \\sum_{n=1}^\\infty \\frac{1}{n} = \\prod_p (1-\\frac{1}{p})^{-1}")

#text("and from the divergence of the harmonic series we then conclude Euler’s theorem {\\sum_p \\frac{1}{p} = \\infty}")#linebreak()#text(" “”")

#text("I have only seen more laborious proofs that the sum of prime reciprocals diverges. This suggests the proof is immediate from the Euler product formula.")

#text("Can someone explain to me how?")

#text("The closest I have found is this, but experts told me that the proof is wrong:")#linebreak()#text(" ")#link("https://math.stackexchange.com/questions/4114982/validity-of-taking-log-of-divergent-sums-in-proof-sum-1-p-rightarrow-infty")[#text("https://math.stackexchange.com/questions/4114982/validity-of-taking-log-of-divergent-sums-in-proof-sum-1-p-rightarrow-infty")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-638375")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2021")])]

#text("Technically speaking, the proof in the link is incomplete because although we have the convergence of each of the partial sums ")#mi("\\sum_{p} \\frac{1}{p^k}")#text(" for ")#mi("k \\ge 2")#text(" there are infinitely many of them.")

#text("However, we don’t need to do all this.")

#text("Just expand the terms ")#mi("\\frac{1}{1-(1/p)}")#text(" in terms of geometric sums and then use the distributive property and divergence of the harmonic series to establish the claim.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-638376")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2021")])]

#text("If you want to send ")#mi("s \\to 1")#text(" to get the claim, then you can use the monotone convergence theorem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0cc5c5b58984fd8189ecbd929d29b01a826651e0c09b23f3bd634be13eedaaa9-d6d1d5cfe1043cacae035da57d5d17ba965c8e55b19bbe97d948d36de7810dd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Riemann zeta function: standard Dirichlet series associated with the Riemann zeta function | Aditya Guha Roy's weblog")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-631621")[#strong[#text("Riemann zeta function: standard Dirichlet series associated with the Riemann zeta function | Aditya Guha Roy's weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2021")])]

#text("[…] Dirichlet series associated with the Riemann zeta function and is relevant to Exercise 5 from this blogpost by professor Terence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e17dfdcc41d93e81ed98169a7ccb8f748da8c8a4e7a3628dae46061b159a32c4-d2ba8b5d861dd26a029212bddba333afabfd23017b6585ae919d3ea6a25ca4d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liki mitica")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-638350")[#strong[#text("liki mitica")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2021")])]

#text("Dear Professor Tao,")#linebreak()#text(" I am one of enthusiasts of your blog, a great place to read and learn about the (new) trends in math. I found 2 days ago an interesting preprint (researchsquare.com) that approaches the Riemann Hypothesis from a different prospective:")

#text("DOI: ")#link("https://doi.org/10.21203/rs.3.rs-1159792/v1")[#text("https://doi.org/10.21203/rs.3.rs-1159792/v1")]

#text("From the abstract: ‘As an application we proved the injectivity of the integral operator involved in the equivalent formulations of Riemann Hypothesis’.")

#text("The integral operator has been used by Beurling (1955) and Alcantara-Bode (1993) formulating 2 different equivalences to RH. Alcantara-Bode proved that RH is equivalent with the injectivity of the integral operator in discusion using the Beurling paper.")

#text("Supposing that the proof of injectivity is true, my question is how will be received a such result that is a numerical analysis one for a pure math famous open problem ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-638377")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2021")])]

#text("another fake proof link posted by its author under false pretenses; tons of this on this blog, so one more…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-638424")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2021")])]

#text("“another fake proof”: Could you explain professionally and not anonymous where are the mistakes in that paper, please ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-638431")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2021")])]

#text("It is not incumbent upon anyone to explain the mistakes – googling RH one will find hundreds of such “proofs” and a few disproofs and nobody really bothers with them – what is bad form is linking one such on this blog which already makes it hard to take it seriously, and under false pretenses when it is fairly obvious the author is the one claiming “I found…”")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-638433")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2021")])]

#text("@Anonymous, really understand your argument, but is it just an appeal to authority fallacy? How would we ever know if any of those proofs is true if there is no analysis of the proofs by academia?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-638455")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2021")])]

#text("I think it would be better to:")#linebreak()#text(" 1. do a careful proofreading of your work (it helps sometimes to try explaining your work to one of your friends or colleagues, and to see if that person can find any issue in it, if your paper has a mistake, it is very likely to get pointed out when you try to explain it to others; of course bear in mind that you should try with someone who would understand the paper and would not indulge in any fraudulent activities);")

#text("2. once you are confident that your paper is correct, submit it to some journal, and let the referees review your paper; any official proofreading of your paper would be done in this step, and it is very likely that if they do not find errors in it, then it is indeed an appropriate proof of the concerned problem.")

#text("However, please make sure that you do not submit tons of papers for referees to point out mistakes, without doing the first step of self-proofreading.")#linebreak()#text(" But of course, if you are confident with your mathematics you must send it for publication, even if you think the total volume of work you have done is extremely large (most likely the journals would not mind to publish a lot of articles by the same person, all they care about is that the work is error-free, and meet the standards of their previously published works).")

#text("If you are skeptical of some particular step in your work, then it might be a good option to share it on some research level forum such as mathoverflow, and I am sure that if your post is properly framed (and also properly tagged), then there will be quite a few people who would respond on it and try to help you out.")

#text("Personally, I don’t think prof. Tao (or any mathematician) would go over some non-refereed or unpublished paper just on a request made on his weblog. It is only because he is pretty busy, and he has a lot of other important things to do that attend such requests, but again he is a very kind person and I know that he would definitely try to help people with queries related to his work (or sometimes beyond) if they really need the help and of course if that does not bring up time-constraint difficulties on his way, and to some extend bothering busy people with unnecessary queries is also a bad habit (put in Erdos’s words: such pestering can put at least 2 points in favor of the Supreme Fascist).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-638463")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2021")])]

#text("While all of the above are4 certainly needed (and incidentally the paper linked here has both jarring grammatical errors in paragraph titles and starts by a lot of hand waving so only on those grounds should be rejected until fixed), imho the most important steps for a claimed proof of a notorious conjecture (whether it is RH, Navier Stokes, Collatz etc as we saw all here on this blog) are to first explain your method, what does it bring it new that others using it didn’t, how do you break known errors, how would it apply for other problems, why your method solves this but doesn’t prove a known incorrect result that would follow if you alter a little what you do etc as then people would look at it; if you just throw hand waving and technical stuff nobody is going to bother as the odds are 99.9999% you either made a mistake or that the hand waving is actually the crux of what you need to prove, and that is why generally people do not bother (see how Zhang sold his proof about prime gaps as he did precisely the above steps, explaining where he avoided the known issues with the method he usesd)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-681108")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2023")])]

#text("FYI")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://riemann-hypothesis.ca/")[#text("Introduction")]
]
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d188e8a4b98e52e7f60556353102fd436bf2240777b5d809927e7edb7c8ea6e-1e29daa8adbc1faba2abda6add320c98d228e44be8fa4cef2623bea7e9e05d94.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro J Caceres")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-638435")[#strong[#text("Pedro J Caceres")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2021")])]

#text("@Terence Tao, in one of your articles I read that a deeper analysis should be done of:")

#text("sum(1/x^n) – integral(dx/x^n)")

#text("Having researched this analysis, I could decompose Zeta(z)=X(z) – Y(z). The question is if proving that X(z)=Y(z) only happen when re(z)=1/2 is a good approach to proving RH?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-638454")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2021")])]

#text("Could you please give a link to the reference you are mentioning?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d188e8a4b98e52e7f60556353102fd436bf2240777b5d809927e7edb7c8ea6e-1e29daa8adbc1faba2abda6add320c98d228e44be8fa4cef2623bea7e9e05d94.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro J Caceres")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-638464")[#strong[#text("Pedro J Caceres")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2021")])]

#text("Aditya, these would be the two papers with the explanation:")

#text("1) Decomposition of Zeta(z) = X(z)-Y(z)")

#link("https://www.researchgate.net/publication/339840484_ZetazXz-Yz_A_decomposition_of_the_Riemann_Zeta_Function")[#text("https://www.researchgate.net/publication/339840484_ZetazXz-Yz_A_decomposition_of_the_Riemann_Zeta_Function")]

#text("2) X(z) = Y(z) iff re(z)=1/2")

#link("https://www.researchgate.net/publication/339841648_Proof_of_the_Riemann_Hypothesis_using_the_decomposition_Zetaz_Xz_-_Yz")[#text("https://www.researchgate.net/publication/339841648_Proof_of_the_Riemann_Hypothesis_using_the_decomposition_Zetaz_Xz_-_Yz")]

#text("I welcome your comments.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4f3c8b7e45696527a7629da275705ed801207799205253c0bf8a5c9c9ecf914-b4f90f59d1066bc525f16d31a23908b4a5717c238c6adbdab9948bdb075d861a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of robert carlson")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-643188")[#strong[#text("robert carlson")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2022")])]

#text("around any zero of zeta is a zero free region. the domain of zeta can be divided into distict fundamental domains that have exactly one preimage for every number in C. if these fundamental domains span horizontally across the critical strip there is no room for multiple zeros on any horizontal line.")

#text("also , if you know the prime distribution function P(n) number of primes <= n, you can write the sum of all primes as")#linebreak()#text(" sum [P(n) -P(n-1)] n")#linebreak()#text(" and also rewrite the Euler product using that bracketed expression for any prime.")#linebreak()#text(" zeta then is written as a repackaging of P(n), in that sense zeta is equal to P(n). tautology gives no information so knowing the zeroes of zeta requires knowing P(n)")#linebreak()#text(" Beforehand. maybe Riemann can never be known because of self reference in the same way the busy beaver cannot be solved by a turing machine due to self reference. so RH is non computable perhaps.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee9bf66104c58d0fff497f81c56a9edf54153ead4d5ab887abad88d7b6fd1f2f-890b51d9c9a32c4666207c18708b3db7647139aa2f3f361c7044e76a4f103522.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-643572")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2022")])]

#text("Hola a todos. Los ceros de la función Zeta controlan la distribución de los números primos. Ni tan siquiera soy capaz de entender esto, pero me gustaría hacer la siguiente pregunta. Alguien se ha planteado que esto sea un argumento circular? Es decir,los ceros de la función controlan la distribución de los números primos porque la distribución de los números primos controlan los ceros de la función z. Gracias y perdón si la pregunta es absurda.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d833e80ba54dafc812c0a51fb957f640848fee37ea7076493c3d08cc62871d6-c290943c95b857b6ff3524414752f253859c4342a2842f4eaeb29399bbae2630.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tracepnt")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-668028")[#strong[#text("tracepnt")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2022")])]

#text("Is it possible to get the PNT (in an elementary way) from ")#mi("\\sum\\limits_{k\\leq N^2}M_k(N)\\sim CN^4")#text(" where ")#mi("M_k(N)=\\sum\\limits_{d\\vert k} d^2M^2(N/d)")#text(" where ")#mi("M")#text(" is Mertens function?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-668033")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2022")])]

#text("The sum ")#mi("\\sum_{k \\leq N^2} M_k(N)")#text(" is basically ")#mi("\\sum_{d \\leq N} d^2 M^2(N/d) N^2/d = N^4 \\sum_{d \\leq N} m(N/d)^2/d")#text(", where ")#mi("m(x) = M(x)/x")#text(" is the normalized Mertens function. So bounding this by ")#mi("O(N^4)")#text(" would give (after some averaging) some non-trivial bounds on ")#mi("m(x)")#text(" on the average (basically because ")#mi("\\sum_d 1/d")#text(" diverges), which should lead to the prime number theorem. That said, it’s not clear to me that this sum is going to be particularly amenable to elementary methods, and there are good heuristic reasons to suggest that a purely elementary proof of the prime number theorem cannot be obtained just from some finite number of classical manipulations of elementary functions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-681870")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2023")])]

#text("Can anyone tell me where these estimates for the integrals in the implication of 9 to 6 are coming from? Maybe I don’t have a good enough grasp of this $\\eta$-function, but I do not really understand it.")

#emph[#text("[Can you be more specific? What is “the implication of 9 to 6”? -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-681880")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2023")])]

#text("Oh, I meant the implication of the zero free region of the zeta-function to the von Mangoldt form of the prime number theorem. You used exercise 22 (Smoothed explicit formula) to show this. There you had three integrals which needed to be estimated. I have troubles understanding these estimates. Thank you for replying.")

#emph[#text("[Can you be even more specific about the precise step that you were not able to follow (writing out the relevant expressions in LaTeX instead of referring to them indirectly)? -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-682869")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2024")])]

#text("I think that the Riemann-von Mangoldt explicit formula is not locally uniformly convergent near prime powers. Otherwise ")#mi("\\psi_0(x)")#text(" should be continuous for all ")#mi("x>1")#text(", being local uniform limit of continuous functions, which is clearly false.")

#emph[#text("[")#mi("x")#text(" is restricted to be non-integer, which is where the local uniformity is being claimed – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-685027")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2024")])]

#text("as with all the innumerable previous attempts, this one is also flawed in an elementary way (assuming uniformity – eg eq 16 which misquotes Gonek paper – where none such is known/exists)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-685060")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2024")])]

#text("Just a note here to record that multiple recent comments that were in violation of the")#link("https://terrytao.wordpress.com/about/")[#text(" ")]#link("https://terrytao.wordpress.com/about")[#text("blog comment policy")]#text(" have been deleted.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24a6e77567973bd548a06ba46cbbc75c7d37eb3612738fc16de4f083c6b081b6-68d6eaf1abd5bf564f2d449a44e084ca517ef40d64e2a31a86d42bb61b675ad5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ducduc2710")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-685076")[#strong[#text("ducduc2710")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2024")])]

#text("Can the Robin inequality approach each value of n like this?")#linebreak()#text(" ")#link("https://www.facebook.com/photo/?fbid=455468467075416&set=a.169999308955668")[#text("https://www.facebook.com/photo/?fbid=455468467075416&set=a.169999308955668")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-685218")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2024")])]

#text("I would add that it seems that when considering the ratio sigma(10080)/sigma(m) for values ​​m<10080 it is less than 3.9. Is it possible to consider n-h’ and n+h with each value n=5041, 5042, …? The starting point is still from Robin’s inequality. I haven’t asked Tamar Ziegler about this, the non-existence of n-h’ might not have an impact?")

#link("https://www.facebook.com/photo/?fbid=474811321807797&set=a.169999308955668")[#text("https://www.facebook.com/photo/?fbid=474811321807797&set=a.169999308955668")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-688286")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2025")])]

#text("Surely Poisson summation must be hiding somewhere in Exercise 13? Where and how?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-689568")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2026")])]

#text("Is there a heuristic for how one might ")#emph[#text("arrive at")]#text(" the reduction from Theorem 1 (PNT) to Theorem 6 (the von Mangoldt form)?")

#text("It is natural to introduce")#linebreak()#mi("\\psi(x) := \\sum_{n \\le x} \\Lambda(n) = \\sum_{p^m \\le x} \\log p")#text(",")#linebreak()#text("since the logarithm turns multiplicative structure into additive structure. But it still feels mysterious (to me) why one should ")#emph[#text("expect")]#text(" the specific asymptotic")#linebreak()#mi("\\psi(x) \\sim x")#linebreak()#text("to be the “right” statement that is equivalent to the Prime Number Theorem.")

#text("Is there a guiding heuristic (for example: that prime powers are negligible, or via partial summation, or by interpreting ")#mi("\\psi")#text(" as a weighted prime-counting function) that makes this reduction feel inevitable rather than ad hoc?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-689576")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2026")])]

#text("Just to clarify: I did not mean the parenthetical “for example” as suggesting an answer, but rather as indicating the kind of heuristic perspective I am hoping for. My real question is whether there is a unifying conceptual viewpoint that makes the reduction from ")#mi("\\pi(x)")#text(" to ")#mi("\\psi(x)")#text(" feel inevitable, as opposed to a collection of separate technical tricks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/#comment-689577")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2026")])]

#text("I discuss this at ")#link("https://mathoverflow.net/questions/259698/ideas-in-the-elementary-proof-of-the-prime-number-theorem-selberg-erd%c5%91s/259719#259719")[#text("https://mathoverflow.net/questions/259698/ideas-in-the-elementary-proof-of-the-prime-number-theorem-selberg-erd%c5%91s/259719#259719")]#text(" , as well as at the start of this post.")

#text("Another way of thinking about it is as follows. The von Mangoldt function encodes the fundamental theorem of arithmetic via the identity ")#mi("\\Lambda * 1 = \\log")#text(". By comparison, we have ")#mi("1 * 1 = \\tau")#text(", and the divisor function ")#mi("\\tau")#text(" is known to behave like ")#mi("\\log")#text(" on the average, so if one could invert the convolution by ")#mi("1")#text(" efficiently, then one could conclude that ")#mi("\\Lambda \\approx 1")#text(", which is the prime number theorem. However, on taking Dirichlet series we see that the main obstruction to inverting the convolution to ")#mi("1")#text(" is to understand the zeroes of the Riemann zeta function…")
]
]
