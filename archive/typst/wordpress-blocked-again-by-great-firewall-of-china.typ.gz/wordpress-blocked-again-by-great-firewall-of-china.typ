// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/
// Converted to Typst by tao2typ: "2026-10-14T15:17:12.647354+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "WordPress blocked again by great firewall of China?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("WordPress blocked again by great firewall of China?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 April 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/")[#text("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I have received some anecdotal evidence that wordpress blogs such as this one have recently been blocked again by the “")#link("http://en.wikipedia.org/wiki/Great_firewall_of_china")[#text("great firewall of China")]#text("“. I was wondering if the readers here could confirm or disconfirm this, and also if they knew of some effective ways to circumvent this firewall, as I have been getting a number of requests on how to do so.")

#text("[Of course, by definition, if a reader is directly affected by this blockage, then they would not be able to comment here or to read about any workarounds; but perhaps they would be able to confirm the situation indirectly, and I could still pass on any relevant tips obtained here by other channels.]")

#text("[Update, June 3: A partial list of blocked sites can be ")#link("http://www.herdict.org/web/explore/country/CN")[#text("found here")]#text(", and a firewall tester can be ")#link("http://www.websitepulse.com/help/testtools.china-test.html")[#text("found here")]#text(".]")

#heading(level: 1)[#text("Comments (44)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96d1ed63346651bab529aa01a183a9900bbf45b6c1ce3bf49f719273ab87b8e2-04cd73af24208ca01e75d1421daddec0ad55b14379cedd7aeb8586e1fb9ebe80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of not quite chinese")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38390")[#strong[#text("not quite chinese")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("Hi Terry,")

#text("I am behind the great firewall of China. Indeed, wordpress is blocked, and if my memory serves me right, it has been blocked for a while now, and in fact, has been blocked throughout most of the last two years. I remember it was unblocked for some short period at some point, but don’t remember when. What’s even worse, youtube is blocked for the last month or so. Worse, because it’s much harder to bypass the blocking of youtube, since it’s a heavy-bandwidth service.")

#text("Anyway, here are some ways to bypass the firewall. In fact, it’s very easy:")

#text("0. If I just want to read blogs (but without the comments) — google reader has access to everything, and I have access to google reader. So I get all of your blog posts in my reader, without doing anything special.")

#text("1. Use any number of freely-available proxy sites. Examples: ")#link("http://www.pawxy.net/")[#text("http://www.pawxy.net/")]#text(" , ")#link("http://vtunnel.com/")[#text("http://vtunnel.com/")]#text(" , many others (look online for “accessing youtube behind a firewall”). Advantage: quick and easy. Disadvantage: connection is slow, no access to media (e.g. youtube), some of these are gradually blocked.")

#text("2. Use a utility that automates the process in #1. GLadder is a firefox extension that does this, although it’s clunky sometimes. GAppProxy is another useful utility, although it stopped working lately. Tor and such are said to be useful, although I never used Tor. Never managed to set it up properly. (Didn’t try too hard). Advantage: a little easier than #1.")

#text("3. Use a VPN or a tunnel to some offshore account. For example, if you have, say, an MIT unix account but you’re in china, you can perform ssh tunneling, and then define a “SOCKS host” in your browser, and just surf as normally. All of your packets are routed to the offshore account, where they are treated as packets that originate there. It’s perfect, and is the best option. It’s also very quick, assuming the offshore account is quick. VPN is a similar option, which (if I’m not wrong) is windows-based.")

#text("4. You can actually _buy_ a VPN account from some companies. (I don’t have a link handy, but can check if needed). You pay a few bucks each month, and you can access it and surf freely. The only danger is that this might be blocked — all that the chinese government has to do is block your connection to the VPN server, and you’re screwed.")

#text("I think that’s about it. Only options #3,#4 are viable or accessing youtube, and that’s why youtube being blocked really sucks. By the way, the rumor has it that youtube is blocked for stupid political reasons — because the major Chinese competitior of youtube lobbied for youtube to be blocked, and not he’s getting all of the bussiness. For the Chinese government it’s better if people move to Chinese services, because then all the government has to do in order to censor something is just pick up a phone to the company.")

#text("Just a note: the goal of the firewall is not really to hermetically block these websites from the Chinese internet users. The people in charge are not idiots. I can list multiple reasons for blocking:")

#text("1. trying to make such information as inaccessible as possible. “such information” means anything that the authorities are not happy about (e.g. Tienanmen, Tibet, Amnesty International, etc)")

#text("2. making sure that the citizens know that they’re being watched and that they’re not free, so they shou;dn’t get any funny ideas in their head. As a foreigner in China, I have nothing to fear. But the locals could be more worried. (Although, most students in my institute use firewall-bypassing tools, but they’re very tech-savvy and not very conformist).")

#text("3. Chinese-language websites are much more censored than English-language sites. Furthermore, it might be easier for someone Chinese to just go to the unblocked website, and thus get only government-approved information. The government here is not shy about giving various instructions to Chinese websites (hosted in China) about what to write and not write. For example, for the anniversary of the Tienanmen massacre they warned the sites against mentioning anything, and instructed them to not even mention the formal government version — i.e. to just ignore the whole thing.")

#text("I recommend the site danwei.com for any China-related info in English.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb44e2738f7c3f1c593ab72676656f5ac8b514847e02263d3aac0111d89e7bc1-1678ced985578c8de61fcc0acfb1f566d73425eea6f6b4182282ebef7414067a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luca")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38392")[#strong[#text("luca")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("Method (3) in the previous comment (using ssh to route traffic through a non-Chinese computer) worked well for me when I was in China. Detailed instructions on how to do it are in the first comment to this post:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://lucatrevisan.wordpress.com/2008/09/23/the-china-theory-week/")[#text("The China Theory Week")]
]

#text("Unfortunately the usefulness of this method is mostly restricted to visiting foreigners.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb44e2738f7c3f1c593ab72676656f5ac8b514847e02263d3aac0111d89e7bc1-1678ced985578c8de61fcc0acfb1f566d73425eea6f6b4182282ebef7414067a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luca")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38393")[#strong[#text("luca")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("By the way, during September-October, 2008, google reader was blocked, although judging from the first comment it’s unblocked now.")

#text("(Generally, access to google-owned sites, including blogspot blogs and youtube, comes and goes, probably mostly for the reasons that the first poster talks about.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df3e1dd988b5bf64788b5280fd41c58e117e8d99233af185557a6af6366569e3-60c58ef414781b9907bbc0167f9cd9a6c4f44b0e9aca97696035c4754a3bf5bb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of an")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38397")[#strong[#text("an")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("Yes, in china we must use proxy to vist wordpress now. By the way, i also can not receive some post (i.e. 245C notes2, notes3)in google reader.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38401")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("Dear Professor Tao:")

#text("I am in China and spend some time in wordpress everyday during the past year. At the Olympic-Games time, there were about two months when we can visit wordpress in China. I guess that is doing so can convince foreigners that China is a free country. Last month is another time gap when wordpress is free. Apart from these two time gaps, most time wordpress is bloged.")

#text("I hope more Chinese students can learn things from your blog. But the fact is that lots of them don’t even know about your blog at all. I myself maintain a Blog in WordPress and use the method of combining firefox and Tor. I find this method a great one, though it would take some time to get used to. Generally using a proxy can’t make people leave massages such as comments, let alone writing posts.")

#text("I wrote a post about this several days ago, and some great comments provides good possible ways. I quote two linkds here, each of which is written in Chinese, providing a method.")

#text("1,")

#link("http://orzdream.cn/2009/04/google-gwt-and-mirror/")[#text("http://orzdream.cn/2009/04/google-gwt-and-mirror/")]

#text("2,")

#link("http://code.google.com/p/gappproxy/")[#text("http://code.google.com/p/gappproxy/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dceb0f42d2ca3d83c360f31dc615bd5f2ee01f515aea82569b0012f6fcde9b01-63f5842448c0693ab7f081d9593e321d8c1afd582b04c57d6f722d98d7b2393f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38405")[#strong[#text("Robert")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("WordPress was blocked when I was in Beijing for about a month during the winter holidays. I’m unsure of the current situation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/15ad6c35441606e7c900116979dee3176b716057310f6f61fd0d94e34be3bf16-a9db3ff81ec2ed58dc36882a6c3abb2cd5f24ef073f27ced1f3d6109da8d9715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zhuzhuor")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38406")[#strong[#text("zhuzhuor")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("I am also behind the GFW and I am using Google Reader to subscribe the rss of your blog.")

#text("The above 1/2/3/4 points are all about how to access a blocked blog or website from the mainland.")#linebreak()#text(" But for the blog owner (such as you) there is nothing they can do.")#linebreak()#text(" As I know, wordpress.com is always blocked by the GFW. The only way for a blog site to bypass the blockade is changing the website service, e.g. from wordpress to blogspot. However, this would cost a lot of other unnecessary and boring affairs.")

#text("Or you just do not need to mind such things. The people intending to read your posts would have many approaches to access here (just as us). As long as Tao continue to write excellent articles here, I think there would be more and more readers from China.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38409")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("I can no longer get to this blog or most other WordPress mathematics blogs from my government computer in the USA, although I can visit any number of trashy entertainment news sites if I so desired, so we have stupid internet censorship here as well. I can, however, get to Not Even Wrong. Compare these two URLs:")

#link("https://terrytao.wordpress.com")[#text("https://terrytao.wordpress.com")]

#link("http://www.math.columbia.edu/~woit/wordpress/")[#text("http://www.math.columbia.edu/~woit/wordpress/")]#text(" (Not Even Wrong)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38413")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("Terry,")#linebreak()#text(" It should not be so hard to set up a mirror of your blog on the UCLA web, although I am not sure whether it is also easy to allow comments on the mirror and mirror them of the wordpress.com…")

#text("That’s perhaps the most practical thing to do, anyway.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/951516ab72f8eb7e1f0e5e8704dfba7b644383ab92421ee28d997a0921673a9c-4b054f158dec8d55eb32281674b0ca879dfb2ab9a4d79ab87ace095e613c8875.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dima")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38414")[#strong[#text("Dima")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("> That’s perhaps the most practical thing to do, anyway.")#linebreak()#text(" I forgot to log in when I wrote this comment…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/758f78bdc69374a138e14ceeda93836fe67ee98b33063997a5d1536e927a6a7b-f32ad8715309a76f5b93bdfcc1fd214f5cf8e03a4e7bdbab14e6aeaa778ef957.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samir")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38415")[#strong[#text("Samir")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("Hi Professor Tao,")

#text("I’ve found that Tor (")#link("http://www.torproject.org/")[#text("http://www.torproject.org/")]#text(") is arguably the best way to access restricted websites behind most types of firewalls. The Tor project was initially developed in order to prevent totalitarian or authoritarian regimes from limiting their citizens access to the internet. More information can be found in the “Why You Need Tor” section of the link above.")

#text("When one travels to countries such countries, it is also possible to use a bootable flash drive to circumvent these firewalls. After creating a bootable flash drive, one can use PortableApps.com software to load web browsers and other utilities to the drive. Finally Tor can be added to this drive, essentially creating a fairly robust portable “computer” that can avoid firewalls. Considering the low price of flash drives and the open-source nature of the software I’ve discussed, and the portability and ease of concealing such a device, I’d assume that this method of circumventing firewalls may be very useful for both travelers and citizens alike.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75e777514f5b1c071a5889cfc83f2e7d595daba29908aef18a101e2efa86334b-c73ddc684cda3c4ec527fbeb1c3374290457435b3822877034c686dfd541c585.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ionica")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38417")[#strong[#text("Ionica")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("I think the best solution for bloggers is to install wordpress on their own server and run the blog from there. For you this would mean transferring your entire blog, I have no idea how hard that is.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96d1ed63346651bab529aa01a183a9900bbf45b6c1ce3bf49f719273ab87b8e2-04cd73af24208ca01e75d1421daddec0ad55b14379cedd7aeb8586e1fb9ebe80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of not quite chinese")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38421")[#strong[#text("not quite chinese")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2009")])]

#text("luca: in the last two years, as far as I know, Google reader was never blocked. And I would notice.")

#text("liuxiaochuan: from my experience, you can leave comments when using a proxy. Any one of the proxies that I mentioned is good for this. I’m not sure how hard it is to write a blog using an open proxy (it looks reasonable, actually)")

#text("zhuzhuor: Tunneling or VPN is a perfect way to write a wordpress blog from behind the firewall. open proxies areproblematic, indeed.")

#text("Dima: that’s a great idea. The same problem occurs with Gil Kalai’s and Luca Trevisan’s blogs, both in wordpress. Maybe you can ask them to mirror their as well, while you’re at it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38422")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2009")])]

#text("Dear Prof. Tao,")

#text("I stayed in Beijing last year for one weeks, I couldn’t log in. Later I travelled in Suzhou, a city 80 kilometers west to Shanghai, I also couldn’t log in. But I knew some postgraduates at Peking University were discussing your lecture note on Ergodic theory.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d10259e569f7948fb426f219171f06e13dc570f262d4c1ae121b4b024a8b1608-030659b4e829203ccdf0062ebabb0491445396a52c856fea3b1d5e19b723499e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ObsessiveMathsFreak")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38425")[#strong[#text("ObsessiveMathsFreak")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2009")])]

#text("Tor is slow an difficult to set up, but it does work when it comes to bypassing internet filters. You have to be aware though that Tor is not secure by itself as data is ultimately unencrypted when it passes in and out of the “exit nodes”(These are usually in the US or some other unfiltered(?) location). This is only a problem if you wanted encrypted connections, which most people don’t.")

#text("If you use Firefox, Tor usage has been “simplified” somewhat by the ")#link("https://addons.mozilla.org/en-US/firefox/addon/2275")[#text("Tor Button")]#text(" extension. The last time I checked, this did require Tor to already have been installed on your computer, and just made it easier to use.")

#text("Unfortunately, these type of firewalls and net filters are in no way uncommon, with the “Great Firewall” simply being the the most draconian and capricious. Similar censorship in fact exists in the UK and Australia, with ISPs “voluntarily” implementing block lists provided by private companies.")

#text("These filters are becoming more common as time goes by and suffer from the very same faults as the “Great Firewall” with many “unintended” sites being blocked. This is especially a problem for sites using “shared hosting”; meaning moving your blog to another site may not remove this problem. (Your site could be on the same server as a Chiang Kai-shek fan club, for example.) This may be unlikely, but given how capricious all these filters can be, there’s really no way to tell in advance if you’re going to be blocked. It can be very frustrating.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb41629b900a04bf9debac4d5eac088c522fb410dada341099521f7f9faeb264-a753dd309490ffe7a3fccee4f133ec9c1bea4ce7d7e270786ca05bf0f89638af.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daoguo Zhou")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38426")[#strong[#text("Daoguo Zhou")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2009")])]

#text("Dear Prof. Tao:")#linebreak()#text(" I am PhD student in China. I visit your bolg everyday via Tor. The simplest way to bypass “Great Firewall” is installing Firefox+Tor toghter. Although Browsing through Tor is very slow, but Tor may be the easiest way to view WordPress.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of quite chinese")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38441")[#strong[#text("quite chinese")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2009")])]

#text("not quite chinese : “VPN is a similar option, which (if I’m not wrong) is windows-based”")

#text("Not Quite Chinese, that is new to me that VPN is anything to do with operating systems.")

#text("The best way to resolve the current censorship is option 5 an immediate revolution overhauling government current (all ?) foreign and domestic policies.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c8d284dd2ddbb40626c126309bc8e8f09a743a2912dbd9b7b72bfd1a29c8e63-fb26f3846087993e4a4209154a6ee4d8b3e21164c0e309de7f1e307e01f6612f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Morrison")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38447")[#strong[#text("Scott Morrison")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2009")])]

#text("Actually there is something Terry could do to make his blog more accessible; providing “proxied” access through another URL (e.g. at UCLA), without moving the blog away from wordpress hosting.")

#text("The commonly used apache webserver (which ")#link("http://www.math.ucla.edu")[#text("http://www.math.ucla.edu")]#text(" is using) provides for proxying, using the “modproxy” module. Essentially, you could set this up so that any requests to, say, ")#link("http://www.math.ucla.edu/~tao/blog/XYZ")[#text("http://www.math.ucla.edu/~tao/blog/XYZ")]#text(" cause the UCLA webserver to go look up and serve the current version of ")#link("https://terrytao.wordpress.com/XYZ")[#text("https://terrytao.wordpress.com/XYZ")]#text(", rewriting all links in the HTML as appropriate. Comments should work fine.")

#text("I’m not an expert on modproxy, but I have used it, and in principle this is just a few extra lines in a configuration file. Depending on the setup of UCLA’s webserver, Terry might be able to do it himself (in the .htaccess file), or more likely might need cooperation from the sysadmin.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df3e1dd988b5bf64788b5280fd41c58e117e8d99233af185557a6af6366569e3-60c58ef414781b9907bbc0167f9cd9a6c4f44b0e9aca97696035c4754a3bf5bb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of an")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38464")[#strong[#text("an")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2009")])]

#text("Today WordPress is accessible in China mainland without proxy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38478")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2009")])]

#text("Can anyone confirm an’s report? It would be good to know whether the block has been fully lifted.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38483")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2009")])]

#text("I just contacted a friend in China, she said the worldpress was still blogged.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df3e1dd988b5bf64788b5280fd41c58e117e8d99233af185557a6af6366569e3-60c58ef414781b9907bbc0167f9cd9a6c4f44b0e9aca97696035c4754a3bf5bb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of an")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38484")[#strong[#text("an")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2009")])]

#text("I try again. It is still accessible for me without proxy (at Zhejiang province south of Shanghai). By the way, can anyone tell me why my google reader can not receive some posts for this blog (just recent notes 2.3.4 for course 245C )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38485")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2009")])]

#text("Google Reader frequently misses posts from this blog, as far as I can tell for everybody everywhere, not just in China. I have no idea why.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daoguo Zhou")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38486")[#strong[#text("Daoguo Zhou")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2009")])]

#text("WordPress is accessible from China today. Maybe whether WordPress being blocked or not in China depends on the mood of bureaucrats.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb59a81fe2acab58f31180b173a666685ddb6d23c1752e3e7748217dc79cc540-cb0d538891307f79aacf42051ce1716f07335d1db4fa081bebb827572251056a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Good Day")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38488")[#strong[#text("Good Day")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2009")])]

#text("初识wordpress是因为想访问您的blog，但一直没有成功过。几分钟前偶然发现wordpress is accessible，就马上通过您的主页的链接来到这里。非常兴奋呀！")#linebreak()#text(" ps:我的英文不太好，请哪个朋友把我的话翻译成中文吧。以后不再用中文发言了。")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38495")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2009")])]

#text("There is an article on this general topic today in the New York Times:")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08edac3c1ba7fd9837efea66136c65256434d86e121db5dd69fcbd1022f0e945-9fabbe62d37250bce5030405ae4cf685005021e23cb30a46efdcf903e88a6418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of joseph")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38506")[#strong[#text("joseph")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2009")])]

#text("It’s really a shame of China. China should learn u.s, not Korea.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96d1ed63346651bab529aa01a183a9900bbf45b6c1ce3bf49f719273ab87b8e2-04cd73af24208ca01e75d1421daddec0ad55b14379cedd7aeb8586e1fb9ebe80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of not quite chinese")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38523")[#strong[#text("not quite chinese")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2009")])]

#text("I can confirm that today wordpress is unblocked in Beijing, at least in the connection I’m using. It was blocked yesterday, I think. So “volatile” would be the good description. But in the long term it seems more often blocked than not.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38596")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2009")])]

#text("It is ironic that I have to do this in a post concerning firewalls, but I have deleted a number of comments here which were not exactly conforming to ")#link("https://terrytao.wordpress.com/about/")[#text("my requests that discussion be “constructive, polite, and at least tangentially relevant to the topic at hand”.")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38735")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2009")])]

#text("zhuzhuor is right")#linebreak()#text(" The people intending to read your posts would have many approaches to access here (just as us). As long as Tao continue to write excellent articles here, I think there would be more and more readers from China")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/410b9c9ca6499cc5209036257f3918ac4258d3c6701d9f991efa9e24528b2df8-432d3897d03068d8e0e31ec014f2ec7c73c14643504a78c2eabf86dfc22ae74b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jisang Yoo")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38979")[#strong[#text("Jisang Yoo")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2009")])]

#text("I know of two programs that could help bypass the great firewall: 1. Hotspot Shield, which uses VPN, 2. Ultrasurf, which automatically finds proxy servers, and is free. (Both of them are MS Windows only)")#linebreak()#text(" Might help people outside US to view Hulu videos, or Canadian people to watch Daily Show, or people outside UK to watch BBC on the web.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7058e30a8ed31766e947de8b247b6c56d27bdb05b43249562755238310f0923b-eb41d975a2fccde935859d253d69e05e89ac4f5184e16d02993a942bf7282365.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-38998")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2009")])]

#text("I have unfiltered access to any site from China using ")#link("http://www.Freedur.com")[#text("http://www.Freedur.com")]#text(". This little proxy rocks. They offer free trial. Try it, you’ll like it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-39151")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2009")])]

#text("It appears that twitter, Flickr, hotmail, and a number of other sites have been blocked today by China, presumably because of the upcoming June 4 anniversary:")

#link("http://www.danwei.org/net_nanny_follies/twitter_domain_blocked_in_chin.php")[#text("http://www.danwei.org/net_nanny_follies/twitter_domain_blocked_in_chin.php")]

#text("Youtube and blogspot have been blocked for some time. I don’t know about wordpress, though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96d1ed63346651bab529aa01a183a9900bbf45b6c1ce3bf49f719273ab87b8e2-04cd73af24208ca01e75d1421daddec0ad55b14379cedd7aeb8586e1fb9ebe80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of not quite chinese")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-39160")[#strong[#text("not quite chinese")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2009")])]

#text("Indeed, flickr and twitter are blocked from yesterday, probably because of the coming 20th anniversary of the Tienanmen massacre. One would hope that they would be unblocked soon. Twitter is in heavy use by Chinese people (no proper Chinese substitute, I hear) and this is said to be raising eyebrows among people who are not aware of internet in China being filtered. (Yes, some people do not know — they only surf Chinese sites, which are most often unblocked, since they are censored directly by government).")

#text("Hotmail is not blocked as far as I know. (I can access it). It would be very odd to block hotmail — so far China is not blocking free email services. That would be a lot worse than anything going on so far, rendering people unable to use their email address (unless using proxies).")

#text("WordPress is still blocked.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d58677b4023c07b9b61cf0df9fef1bc113847e309100e069a0553cbecbd3aa2-30758f8d1f45cd3689e45046e6532a6d5e9799c1bc00d595c3d66f9be73b61c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YongHui Wang")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-39226")[#strong[#text("YongHui Wang")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2009")])]

#text("In Conclusion: The best and easiest way to access WordPress through GFW, is using Google reader. As previous comments mentioned, the comments will no be seen automatically in Google reader.")

#text("But that can also be solved by the blog-author copying “the Comments feed for this article” in the post (lies in bottom of full-text, top of comments) into the full-text of the post.")

#text("Then Chinese students and other audience will also be able to see the comments by clicking and subscribe it in their Google reader.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db8c474b56f4de7224fddaf23fababa672ffca6425418180712be7f5f21aba46-3806f5742fc0f4f973f4b49c5255e04094ecc181ffa371db7a1e5ec1ca6358c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of niskotink0")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-39280")[#strong[#text("niskotink0")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2009")])]

#strong[#text("Jeff")]#text(".. Thank you ! Very help.. useful service !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-42738")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2009")])]

#text("dear Professor Tao:")#linebreak()#text(" I can visit wordpress directly right now. I don’t know why and how long it will continue in this way.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e1e7f679eb76d15e81727176574dcb858ff822c2b8ef082917cde86bc2402f9-2b88a913dd9728f9a22f3f152362e67d0a5f21d13136cf94c794881a572f47de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Unblock Youtube")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-46439")[#strong[#text("Unblock Youtube")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2010")])]

#text("Everybody knows these restricions have no effect since all sites are still accessable via free online web proxy services.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82b989822d4764eea44fa78df37a14d4cceb1b9bab7c4f90bc8193d679f48cf0-251b437d46dbbc82f62d5cc436f82534357ba965bbf8f0fe9d71fbcfefe33f02.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hughesey")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-48048")[#strong[#text("Hughesey")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2010")])]

#text("Theres a cool tool for checking whether sites are blocked in China or not here: ")#link("http://viewdns.info/chinesefirewall/")[#text("http://viewdns.info/chinesefirewall/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/886449cbcd94a4bd27100e2930e5bd0ffb543be7f7d4f2239b9dbab7c0926c56-d85f5436daedffd6fee1f2d4b1b4ea52671b53d3c020f27c18b60a99dcc4f019.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tengyu")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-53364")[#strong[#text("Tengyu")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2011")])]

#text("Hi Prof. Tao,")#linebreak()#text(" I came here to find a easy method for posting comment behind the GFW like using google reader but failed (I remembered there is such a way). I can confirm that wordpress is not blocked by GFW for recent three months at least. However, the login page of wordpress is blocked, which means that reader can read but writer can’t log in and post in mainlan. (I am using proxy right now)")

#text("Tengyu")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/065b2799359a1922d32ba3cf49f4c66095f28aa6382813865e571939f05dda7e-81f3173230a5c9f1672a94398d26b731393edf76ce5afa485f92f3a8658d2bb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of really")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-100636")[#strong[#text("really")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2011")])]

#link("http://www.cool-vpn.net")[#text("http://www.cool-vpn.net")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e6b198f863573e12b3997579442d674fa439008588a5e16df0b935256a843d7-99c7b96a3f9024d9820a4eb6d8fc12cabe4ca07c5a5eb6fab3950e110bd331ea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Angie")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-124219")[#strong[#text("Angie")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2012")])]

#text("I use ")#link("http://www.highspeedvpn.com/")[#text("http://www.highspeedvpn.com/")]#text(" to get on WordPress blogs when in China. It`s pretty fast and not so expensive ..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anoymous")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-175903")[#strong[#text("Anoymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2012")])]

#text("Now gmail and google docs accessible,youtube and wordpress still can not.A good way to circumvent firewall:Westchamber (西厢，中国古代一戏剧.话说张生就是翻墙去见莺莺的) ")#link("https://github.com/liruqi/west-chamber-season-3/tree/master/west-chamber-proxy")[#text("https://github.com/liruqi/west-chamber-season-3/tree/master/west-chamber-proxy")]#text(" +Proxyswichy(a plugin of google chorome). I also recomment freegate +Proxyswichy,though freegate involve political news which will “harm your pure mind”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dfa17358db2dbfb774868be5d66e6224c31560dd1e6af4dc6c4586d90d977e0d-28f6b2ebbb22dbfa10d80171e7e49a9096dc1c7626474727ddad001167bbd846.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emma")]], [#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/#comment-187894")[#strong[#text("Emma")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2012")])]

#text("Yup, wordpress and blogger are both blocked, but you can always use a VPN service like ")#link("http://www.sunvpn.com")[#text("http://www.sunvpn.com")]#text(" to get around that.")
]
