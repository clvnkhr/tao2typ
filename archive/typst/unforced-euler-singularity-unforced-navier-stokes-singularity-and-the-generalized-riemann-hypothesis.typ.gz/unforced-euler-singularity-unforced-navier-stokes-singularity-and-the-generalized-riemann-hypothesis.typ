// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/
// Converted to Typst by tao2typ: "2026-11-21T14:49:24.363853+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Unforced Euler singularity, unforced Navier-Stokes singularity, and the Generalized Riemann Hypothesis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Unforced Euler singularity, unforced Navier-Stokes singularity, and the Generalized Riemann Hypothesis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/")[#text("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-21 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("Obviously these results will be reported widely in other outlets, but I will note them here, in decreasing order of how “digested” the results currently are:")

#list(
[#text("Levent Alpöge, Tristan Buckmaster, and Matei Coiculescu, with heavy AI assistance, have written a ")#link("https://cims.nyu.edu/~tristanb/cc.pdf")[#text("human-readable proof of the finite time blowup for the unforced incompressible Euler equations in three dimensions")]#text(", which is ")#link("https://github.com/mcoiculescu/EulerBlowupPublic")[#text("formalized in Lean here")]#text(".")],
[#text("Levent Alpöge and Tristan Buckmaster, again with heavy AI usage, have generated a ")#link("https://github.com/tristanbuckmaster/navier-stokes/")[#text("proof of the finite time blowup for the unforced incompressible Navier Stokes equations in three dimensions, again with a Lean formalization")]#text(". Here, the paper is technically human-readable and the general strategy of proof is broadly clear (following one of the expected paths to this result, namely to numerically build an approximate discretely self-similar solution and then use rigorous perturbation theory to convert this to an exact solution); but more work needs to be done to create a proper, professionally written proof.")],
[#text("Levent Alpöge, using an internal AI model, has generated an (enormous) Lean-only proof of the Generalized Riemann Hypothesis. ")#link("https://leanprover.zulipchat.com/#narrow/channel/113488-general/topic/Discussion.3A.20Alp.C3.B6ge.20Proves.20the.20Riemann.20Hypothesis")[#text("This Lean Zulip thread")]#text(" is probably the best place to follow the efforts to verify the proof and extract the strategy of proof (which, from very initial analysis, appears to use the full power of modern developments on the Langlands program and arithmetic geometry). (UPDATE: the moderators of the Lean thread are now focusing the discussion on the Lean-related aspects of the proof only.) I imagine the digestion process will take some time, though in this case at least we have a human author to communicate with to assist with this task.")]
)

#text("See also ")#link("https://mastodon.social/@tristanbuckmaster/117649035783718539")[#text("Buckmaster’s Mastodon post")]#text(" regarding the first two results.")

#heading(level: 1)[#text("Comments (61)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699564")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("David Hilbert in 2443: Has someone proved the Riemann Hypothesis?")

#text("Response: You should sit down.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699640")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("And why should he be surprised? Riemann perhaps could be, but why Hilbert if formalization of mathematics was his idea, the idea of a “thinking machine” goes back to Leibniz and the theoretical notion of a Turing machine was introduced 7 years before Hilbert’s death? This may be surprising to us, because it happened so quickly, we knew the visions of AI from sci-fi books and at the same time we were aware of the failures of previous approaches to formal theorem proving, but c’mon in 2443?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of observanta8864034a9")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699663")[#strong[#text("observanta8864034a9")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Hilbert had just awoken from 1943-land, when few if any people believed it was more than a distant dream that a computer could navigate among and occasionally beyond what he surely regarded as some of highest pinnacles of human intellectual depth and creativity. To be told that this had actually occurred, and only eight decades into his five-century sleep, could be seriously unsettling.")

#text("(Besides which he was still groggy and getting used to the time change.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699666")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("In 2443, David Hilbert would probably be more surprised that Europe has become uninhabitable because climate change has caused southern Europe to become an extension of the Sahara desert and the AMOC to collapse rendering northern Europe to become like Siberia.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a5b87ac3a4b28fa67a942090a3d6f945ac1076fa7eb45219a040523967d3e59b-b30af3103bd83580f34e3392246bb7e49a927d28b31f44adc9d23657f14cb116.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gokhan Mergen")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699681")[#strong[#text("Gokhan Mergen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("I tried to turn Lean proof into a human readible and beginner friendly manuscript here with the help of AI.")

#text("43 Page GRH Proof Outline: ")#link("https://www.gokhanmergen.com/pubs/grh-reader-guide/GRH_Reader_Friendly_Guide.pdf")[#text("https://www.gokhanmergen.com/pubs/grh-reader-guide/GRH_Reader_Friendly_Guide.pdf")]

#text("Comments and feedback are welcome!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5ae40e822d598a979305ab7702d1f3dbc72de64361cfc9e43ab7a47810316560-62959af42aa9b0aeaf06d66fb472223f923481c8e700d51570ffe902222018be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Science Markets")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699569")[#strong[#text("Science Markets")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Thank you for the ordering by how digested the results are. That ordering is the whole story, and it is worth being explicit about why.")

#text("For the first two results the digestion path is already visible: human-readable proof, strategy broadly clear, Lean formalisation on top. A reader can form a judgement in an afternoon. The third has no such path yet. A Lean-only artifact of that size is a different kind of object, and the question “is it right” splits into questions that resolve on very different timescales: does the headline statement in Lean say what we mean by GRH; does the archive compile against a known-good Lean with only standard axioms; is the strategy something a number theorist recognises as a proof. The Zulip thread can answer the second relatively quickly. The third is the one that has always taken years.")

#text("The two precedents are both uncomfortable. Wiles announced in 1993, the gap surfaced within months, and the repair took until 1995. Mochizuki published in a refereed journal in 2012 and the people who work on the problem still do not accept it. In neither case could the answer be read off the artifact.")

#text("Which makes the interesting question not “is it true” but “what observable event would settle it, and who is entitled to say so”. For anyone trying to price this rather than just follow it, writing that down before the claim exists is the only version that is worth anything. Written afterwards it collapses into an argument about credibility, which is precisely the failure mode this whole episode is about.")

#text("Disclosure: I work on ")#link("https://science.markets")[#text("https://science.markets")]#text(", which runs a market on this question. The resolution rule is fixed before the market opens and cannot be edited: ")#link("https://science.markets/markets/riemann-zeta-critical-line/")[#text("https://science.markets/markets/riemann-zeta-critical-line/")]#text(" — it requires a complete unconditional proof in ZFC, independently checked with no unresolved gap, and it says in advance that finite numerical verification does not count and that independence from ZFC leaves it unresolved. Being forced to write down what does not count was the useful part.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699671")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Are we allowed to just advertise gambling sites on this blog now? Next thing you know we’ll see a paper “The DraftKings proof of P != NP”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/afbd5f32738a6b0f8a5349685bb0f06092f1602bd718c7004e3afa474fa694dc-8e71c917b8fad71631d445e0dbef46f145a2dacf5a435d44c8dcedcaa216c28a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Juliette Bruce")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699578")[#strong[#text("Juliette Bruce")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Perhaps the world has changed in the last 2.5 months, however, I cannot help but remember your warning in early September,")

#text("“The point remains that there is a substantial opportunity cost in converting a historically productive and motivating problem (such as Navier-Stokes regularity) into a mere viral social media post advertising some benchmark progress, rather than actually advancing the field and developing the next generation of both problems to ask, and people to work on them.”")

#text("It feels like Alpöge’s actions around GRH have seen your fears come to fruition. I cannot help but feel that regardless of our feelings around the use of AI in mathematics we as a math community should not highlight Alpöge’s actions without a healthy dose of criticism.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/950ef28da192aca0891b0ff0171518a13c591bbfcbc7b05a97d12290df4a4d1d-eec25033acb8bc10388c92c217ec4666c8cf3b962fc726414da8027f7d49b213.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pawap")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699614")[#strong[#text("pawap")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("If something is lean verified I think releasing is a good thing. The community can begin digesting/interpreting or building off of the results more quickly and with great plurality.")

#text("Also, if an individual withholds new results because they feel they have greater results upcoming, that’s well within their right, of course that comes at a risk.")

#text("Ideally well known vehicles will emerge for triaging huge lean results, and another vehicle that is meant for human consumption.")

#text("Right now it’s a bit of a hodge podge.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f832c7334b3f139142f58e810a51fe512f4a88e11da9b4aa59649df1c717f459-ad995c6cb972815820045ff0a3deedee85e3cf2b9495fffe4eb337526e7cc50e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin Ventullo")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699646")[#strong[#text("Kevin Ventullo")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("I think there’s a big difference between Alpoge’s announcement here and OpenAI’s dump from a few months back. Specifically this line:")

#text("“I intend to do my best to understand and impart understanding of this argument and its certain simplifications, to speak about it, to write it properly.”")

#text("I genuinely think Alpoge does care about mathematics, and this problem in particular, and his motivation was not to drum up PR.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699677")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Alpoge might care about this problem, but mainly to the extent that it brings him credit/glory. Otherwise he wouldn’t have dumped this AI slop, but worked to explain it better. His pattern of behavior over the last few months regarding other problems is not that of a person with integrity. At this point, he is basically a child with a new (and very powerful) toy – lots of compute, and powerful internal models, which he’s using to gather as much credit and fame as possible. Any such recognition should take into account the differential in resources between him and mathematicians in academia.")

#text("Mathematicians have asked AI companies to not feed big open problems to internal models, and clearly neither the companies nor their employees such as Alpoge give a damn.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ecf0b9ac90961a4a47d19b6a03382247e4041d8258c46268abed4c3eb9a18c92-44f559629e1fed2c23d301c5f15c93c759285c2f42b62e466c99c8c94e677e48.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699702")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Alpoge works for Anthropic and his apparent interest is producing AI generated Lean proofs of Millennium problems. Impossible to know a person’s motivations, but there’s a huge element of PR here.")

#text("Of course, positive things to be said about this vs OpenAI dump. (He’s a legitimate mathematician who talks to mathematicians; has clearly been listening to feedback from the community; whole thing less vulgar).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699714")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#enum(start: 1, 
[#text("I don’t appreciate that Levent isn’t being entirely transparent here? How did he get the proof? How much compute was used? Can we have the chain of thought?")],
[#text("I don’t like how we only got a lean formalization and we didn’t get a natural language proof. The mathematical statements in Levent’s statement seem nonsensical. I sincerely hope Alessandro Masullo is right.")],
[#text("I wish Levent gave more detail as to how Claude was prompted. Did the author have any access to Claude’s chain of thought?")],
[#text("Given the problems Levent is targeting (this, Navier-Stokes, Yang-Mills, probably also spending significant compute on the other two), it’s hard for me to believe he’s not doing this for some PR. His romantic tone in his 4 page note is not helping his case in this regard.")],
[#text("I don’t see much evidence of commitment to understand and more importantly helping others understand the argument. If he did, he’d disclose much more and actually put out his 250k pages of agent notes or tried to simplify this.")

#enum(start: 1, 
[#text("I see instead of helping foster mathematical community and human understanding him continuously foregoing this process and aiming his starkiller at results that would be big in “math 1.0”.")]
)],
[#text("I don’t claim to know what he is doing behind the scenes, but he seems more interested in putting mathematicians out of a job than in advocating for their livelihoods. (For instance, he has a vendetta against mathematical journals, which fueled a lot of the hiring process.) I don’t sense any amount of sensitivity in his public statements towards what other mathematicians are feeling.")

#enum(start: 1, 
[#text("I would love to be proven wrong here.")]
)]
)
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699665")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("I genuinely believe that Alpoge is not doing this as PR for Anthropic. He is doing it for personal glory-seeking, because he has exclusive access to better technology.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed2e4bc80ac04fd3011adefe82e10730633aa94efbef6906e1e5400b4a384a7a-260d191bf650ba5e51bd94788f6dd62e7e27ecf32a5883604813ea50041478aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699706")[#strong[#text("L")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("It should be obvious by now that they don’t want anyone to work in anything ever again. To feel any sense of mastery or satisfaction or control ever again. You are supposed to be a happy consumer who claps every time you see another benchmark headline in the news. And they want to be the ones with the dopamin levee. There will be no more math students, no “next generation”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699580")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Does anyone have a rough estimate for how long until the GRH proof is verified?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/719c0add0b90933b0d5ec4ac66de3057a2cea936b80fcb27b24927b21cf30a1c-da82a83d20b352d1f1484c8e68a671f6bf87b57dd55c9abe6e2bf81772ea303c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manvir Jaswal")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699597")[#strong[#text("Manvir Jaswal")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Lean builds should be finishing up soon with people that have powerful servers, and then it will be checked thoroughly for the next few days. Should be soon where we have a pretty good idea if it’s looking good.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ac08578e0edfc897ba8259f941762c2c4419cb63fb57bafed3975794bd8573a-78dfc549694bf79c3787425760bffa7b7a0389839d3af0e3c06010309348dcf7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam Hopkins")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699582")[#strong[#text("Sam Hopkins")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("It is also worth linking to this post from Ravi Vakil, about an independent, non-AI proof of GRH from Alessandro Maria Masullo: ")#link("https://math216.wordpress.com/2026/11/20/hurried-announcement-alessandro-masullo-grh/")[#text("https://math216.wordpress.com/2026/11/20/hurried-announcement-alessandro-masullo-grh/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/34d52ec9750d32e72618d7593943cb5eff68c46e2cc65e396041847f0e532a91-30c4bdb0cfd0d5a76f23bbf8b85ceaf3ee1bbcc43a7b5e99e18ad6112065ab82.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nomen")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699604")[#strong[#text("Nomen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("The draft is incomplete, it includes footnotes like “Correct statement”, “Insert statement”, “Correct this subsection”, and “Include section”. Hopefully these would be fixed soon.")

#text("A preliminary AI audit:")#link("https://chatgpt.com/share/6b009d72-01e4-83ee-875c-bae3dbd3e326")[#text("https://chatgpt.com/share/6b009d72-01e4-83ee-875c-bae3dbd3e326")]#text(" . The current state of the proof doesn’t seem very promising.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03a96277fb9a4a2ce8bb8729b71e38e4706d338954946f30c636813138862df5-1e67bfc2d6679a272413d03ad4a5904a964711a4f10009770f7339d4949892e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomos")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699619")[#strong[#text("tomos")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("“the current state of the proof doesn’t seem very promising”")

#text("looks promising to me. (what should even an incomplete but promising one look like…)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/34d52ec9750d32e72618d7593943cb5eff68c46e2cc65e396041847f0e532a91-30c4bdb0cfd0d5a76f23bbf8b85ceaf3ee1bbcc43a7b5e99e18ad6112065ab82.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nomen")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699623")[#strong[#text("Nomen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Not containing false statements, for starters. A gap in the proof of a lemma is much more promising than a false lemma.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03a96277fb9a4a2ce8bb8729b71e38e4706d338954946f30c636813138862df5-1e67bfc2d6679a272413d03ad4a5904a964711a4f10009770f7339d4949892e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomos")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699629")[#strong[#text("tomos")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("not sure. non-ai product can easily have statements that would fail an ai test (as you ran) but are true in the case the author means it, and would be one of the things set aside to the “will be polished”. i’m not saying it’s correct or incorrect i just thought running an ai-test on a non-ai product and saying it doesn’t look promising was unfair to masullo, on such a popular blog.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nic")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699703")[#strong[#text("Nic")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("The draft itself says that it is incomplete. Here is a quote from page 6:")

#text("“In light of the current climate I am being advised to release the current version as it is. The math is complete, and only filling in some writing remains on several parts across this long paper. The plan was to")#linebreak()#text("take a year of doing just this…”")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/483aab64af8536b29f2e6bdbfa105c31ec540d9870c15d8bc5b4cd08b804a76d-a9f8036e8177ef542a464fb2f9165b84b29411604ce13185b97a349cad79edad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of george")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699584")[#strong[#text("george")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("The famous quote by David Hilbert:")

#text("“If I were to awaken after having slept for a thousand years, my first question would be: Has the Riemann hypothesis been proven”")

#text("Wild times to be alive =)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699586")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Hello, I’m no expert here. Since the RH is a problem of analytic nature, have the experts always believed that the natural way of proving the RH is by the means of analytic number theory? I’m surprised because on Zulip someone did actually confirm some heavy algebraic number theory/arithmetic geometry tools being formalized.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699598")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("The conventional wisdom has been that purely analytic methods are not sufficient to establish RH, as it is too easy to perturb the zeta function to move a few zeroes off of the critical line (cf. the resolution of Newman’s conjecture on the de Bruijn-Newman constant). As with the Landau-Siegel problem (the resolution of which is a corollary of GRH), the main promising routes have been automorphic methods, algebraic number theory methods, or arithmetic geometry methods; the latter were the key for instance to Deligne’s resolution of the function field analogue of RH (the Weil conjectures). It is very early days but it seems like the AI-generated proof uses all of these inputs. There has also been the wildcard of “F_1” approaches, as proposed by Alain Connes; the new Masullo manuscript apparently goes down this route to some extent, but it will take some time to digest that manuscript also. [EDIT: on closer inspection, the Masullo manuscript is closer to Deninger’s strategy towards RH than Connes’, although the two approaches have some similarities (though neither is close to being concretely fleshed out).]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699636")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("I wonder what is the relation between a Lean certificate and a statement that the proof exists in ZFC. I am not an expert, but there are articles claiming that standard Lean axioms are stronger than ZFC and in particular prove consistency of ZFC. Has it been verified that the Lean proof does not use something beyond ZFC? I understand that with Navier-Stokes it was more or less clear that the proof is analytic and one should not worry about such issues. My understanding that a Lean certificate relying on standard Lean axioms does not settle this issue. And at least to me “proving a RH” means “proving RH in ZFC”, even if proving it with some reasonable additional axioms would still be an achievement.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/719c0add0b90933b0d5ec4ac66de3057a2cea936b80fcb27b24927b21cf30a1c-da82a83d20b352d1f1484c8e68a671f6bf87b57dd55c9abe6e2bf81772ea303c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manvir Jaswal")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699587")[#strong[#text("Manvir Jaswal")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("I’ve been looking into the Lean source as text, with Claude Fable 5.2 and GPT Astra 6.2, to get the strategy out of it. This is a first pass and I’ll refine it as the middle of the proof gets checked. I haven’t built the archive or checked its proofs, so all this says is how the proof is organized.")

#text("The end of the proof is classical in method. Take a primitive character ")#mi("\\psi")#text(", let ")#mi("\\xi")#text(" run over the primitive characters inducing its powers, and look at the centred ramp sums")

#mi("\\displaystyle G(\\xi, y) = \\sum_{n \\le y} \\Lambda(n)\\, \\xi(n) \\left(\\frac{y}{n} - 1\\right) + y\\, \\frac{L^{\\prime}}{L}(1, \\xi) = \\sum_\\rho \\frac{y^\\rho}{\\rho(1 - \\rho)} + O_\\xi(\\log y)")

#text("over the nontrivial zeros ")#mi("\\rho")#text(" of ")#mi("L(s, \\xi)")#text(", with multiplicity (for ")#mi("\\xi = 1")#text(" the last term is replaced by ")#mi("-y \\log y + (1 + \\gamma) y")#text(", with ")#mi("\\gamma")#text(" Euler’s constant). What the archive proves is that, for every small positive ")#mi("\\varepsilon")#text(", the combination of the ")#mi("\\mathrm{Re}\\, G(\\xi, x)")#text(" with weight ")#mi("1")#text(" at ")#mi("\\xi = 1")#text(" and ")#mi("1/(3\\,\\mathrm{ord}\\,\\psi + 1)")#text(" at every other ")#mi("\\xi")#text(" is at most ")#mi("x^{1/2 + 9\\varepsilon}")#text(" for all ")#mi("x")#text(" in windows ")#mi("[Y, Y^{3/2}]")#text(" with ")#mi("Y")#text(" arbitrarily large. A window form of Landau’s theorem (his argument, localized to a window) then excludes zeros to the right of the line ")#mi("\\mathrm{Re}\\, s = 1/2")#text(". Under GRH the bound follows at once from the formula, so it is equivalent to GRH for these characters, and the work is all in proving it.")

#text("The bound is proved in the spirit of Chebyshev, by comparing divisibility with size. The untwisted sum is a count of divisibility, since ")#mi("\\sum_{n \\le y} \\Lambda(n)(y/n - 1) = \\sum_p \\log p \\sum_i \\max(y/p^i - 1, 0)")#text(", much as ")#mi("\\log n! = \\sum_p \\log p \\sum_i \\lfloor n/p^i \\rfloor")#text(". For ")#mi("n!")#text(" itself the prime valuations account for the size exactly. Information comes from setting an independent lower bound for divisibility against an independent upper bound for size. In the proof the lower bound for divisibility is at the primes ")#mi("p")#text(" inert in an imaginary quadratic field ")#mi("K")#text(" (with a correction at the ramified prime), at least about ")#mi("a/p + a/p^3 + \\dots")#text(" powers of each, where ")#mi("a")#text(" is a size parameter. Only odd powers appear because ")#mi("\\Lambda(n)(1 - \\chi_K(n))")#text(" is ")#mi("2 \\log p")#text(" on the odd powers of an inert ")#mi("p")#text(" and vanishes on its even powers and at split primes. So this count belongs to ")#mi("\\zeta(s)/L(s, \\chi_K)")#text(" in the way the factorial’s belongs to ")#mi("\\zeta(s)")#text(". The size has to match this count to second order, down to the term linear in ")#mi("a")#text(", and that is where the constant ")#mi("\\log \\Omega")#text(" below comes from. Chebyshev matched only ")#mi("a \\log a")#text(", and got constants. What is then left of “divisibility ≤ size” is a one-sided bound on the centred ramp sums twisted by characters, as strong as the errors in the two estimates. A one-sided bound is what Landau’s theorem takes. Alpöge’s note calls the argument a descendant of Stepanov’s, with a chain of theta lifts, each “mimicking multiplicity”, standing in for the multiplicity that is hard to find over the integers.")

#text("At the scales the proof uses, the integer’s role is played by maps between lattices over a number field containing an abelian CM field ")#mi("E")#text(", one map for each word in a family. Each map is a composite of ")#mi("m = x^{1/2 - O(\\varepsilon)}")#text(" kernels, attached to a chain of definite Hermitian spaces over ")#mi("E")#text(". In Alpöge’s note these are theta lifts between totally definite unitary groups, and the entries of the maps are periods. The declarations compare each map’s pairing with a Bessel-type pairing, up to isometries and a nonzero scalar. I have not checked that this is the classical period.")

#mi("E")#text(" is the compositum of a real layer of the 2-power cyclotomic tower, of degree about ")#mi("x^{2+8\\varepsilon}")#text(", the field cut out by ")#mi("\\psi")#text(", and two imaginary quadratic fields ")#mi("\\mathbb{Q}(\\sqrt{-q})")#text(" and ")#mi("K = \\mathbb{Q}(\\sqrt{-d})")#text(", for very large primes ")#mi("q")#text(" and ")#mi("d")#text(" chosen below. Summed over the chain, the lifts have to gain at least about ")#mi("m\\,(a/p + a/p^3 + \\dots)")#text(" powers of ")#mi("p")#text(" at each inert ")#mi("p")#text(" up to a cutoff, with explicit losses. Behind this is the local statement that a normalised theta series becomes ")#mi("p")#text("-integral once you substitute the formal logarithm of a CM elliptic curve, whose formal group has height 2 at inert ")#mi("p")#text(". An ")#mi("a")#text("-th derivative in height 2 gains about ")#mi("a/p + a/p^3 + \\dots")#text(" powers of ")#mi("p")#text(", and I read the count as coming from there (no declaration says so). (Here ")#mi("a = x b")#text(" with ")#mi("b = \\exp(x^\\varepsilon)")#text(". The ramp sums are evaluated at ")#mi("y = a/w")#text(" for weights ")#mi("w")#text(" attached to the embeddings of ")#mi("E")#text(", and the relevant ")#mi("w")#text(" are near ")#mi("b")#text(", so ")#mi("y")#text(" is near ")#mi("x")#text(".) Divisibility and size are compared through a slope inequality of Bost’s type, applied to all the maps at once, and the main term ")#mi("a \\log a - a - a \\log \\Omega")#text(" per lift comes from a separate covolume estimate, where ")#mi("\\log \\Omega = \\gamma + \\log(2\\pi/\\mathrm{rd}_E) - \\frac{L^{\\prime}}{L}(1, \\chi_K)")#text(" and ")#mi("\\mathrm{rd}_E")#text(" is the root discriminant of ")#mi("E")#text(".")

#text("Subtracting the main term on the size side from the prime-power count on the divisibility side gives, exactly, a combination of the ")#mi("G(\\theta, \\cdot)")#text(" over the characters ")#mi("\\theta")#text(" of ")#mi("\\mathrm{Gal}(E/\\mathbb{Q})")#text(", read as Dirichlet characters (orthogonality of characters). After averaging along the tower only the powers of ")#mi("\\psi")#text(" survive, alone or times ")#mi("\\chi_{-q}")#text(", ")#mi("\\chi_{-d}")#text(" or ")#mi("\\chi_{-q}\\chi_{-d}")#text(". The untwisted powers are the sum we want. I don’t know a pointwise bound for the twisted ones short of GRH, and the archive doesn’t use one. It picks ")#mi("q")#text(" and ")#mi("d")#text(", by a mean-square estimate over primes and a count of zeros, so that the twisted ramp sums are ")#mi("O(y^{1/2+\\varepsilon})")#text(" on a window. I think that is one reason the result comes on windows and not for every large ")#mi("x")#text(". The total loss is ")#mi("x^{O(\\varepsilon)}(x/m + m + \\sqrt{x})")#text(", hence ")#mi("m")#text(" near ")#mi("\\sqrt{x}")#text(".")

#text("The integrality comes with an error term, and its arithmetic part involves Tate–Shafarevich groups of Tate twists. Take the classes in $latex H^1(E, \\mathbb{Q}")#emph[#text("\\ell/\\mathbb{Z}")]#text("\\ell(-e))$ that are unramified outside ")#mi("\\ell")#text(" and trivial at the places above ")#mi("\\ell")#text(", and sum the lengths of these groups over primes ")#mi("\\ell")#text(" and twists ")#mi("e \\ge 1")#text(" below ")#mi("x^{401}")#text(" with weight ")#mi("\\log \\ell")#text(". The archive bounds the minus part by valuations of generalized Bernoulli numbers, as one does classically, away from 2 and the primes dividing ")#mi("[E:\\mathbb{Q}]")#text(". The plus part is what the note calls a “weakening of Vandiver”. In its main case it is proved from three-dimensional Galois representations attached to automorphic forms on unitary groups, a vanishing of Selmer groups of Kato’s type, and congruences between the Frobenius traces of those representations and the reducible trace ")#mi("1 + \\Psi + \\Psi^{-1}")#text(", where ")#mi("\\Psi")#text(" is the twisted character. The main estimate there is polynomial in the conductor and the twist, but the assembled bound picks up one more term of size ")#mi("\\exp(x^{4\\varepsilon/5})")#text(" from finitely many small primes. That’s still below the ")#mi("\\exp(x^\\varepsilon/2)")#text(" the integrality can afford. There is one special case I can compare with the literature. Over ")#mi("\\mathbb{Q}")#text(" the archive’s bound gives the vanishing of the eigenspace of the ")#mi("p")#text("-part of the class group of ")#mi("\\mathbb{Q}(\\zeta_p)")#text(" for the ")#mi("(p - n)")#text("-th power of the Teichmüller character, ")#mi("n \\ge 3")#text(" odd, as soon as ")#mi("\\log p")#text(" exceeds ")#mi("C n^A")#text(", with constants ")#mi("C")#text(" and ")#mi("A")#text(" that are not made explicit. Toward Vandiver’s conjecture, Soulé (1999) proves this, for ")#mi("n \\ge 5")#text(", when ")#mi("\\log p")#text(" exceeds ")#mi("n^{224 n^4}")#text(".")

#text("On the Langlands side, what I see of local Langlands on the main route is the existence of a map with a short list of properties (class field theory on characters, Zelevinsky’s segments, depth zero over ")#mi("\\mathbb{Q}_p")#text("). The map isn’t asked to preserve epsilon factors of pairs. But a local converse theorem for ")#mi("\\mathrm{GL}_n")#text(", which does involve them, is among the inputs passed to the Galois side, and I haven’t checked whether it is actually used there. The Galois representations attached to regular algebraic polarized cuspidal representations of ")#mi("\\mathrm{GL}_n")#text(" over CM fields are used in full for their existence, with only the local–global compatibility weakened.")

#text("Among the statements I could not find in the literature are the central inequality itself, the approximate orthogonality between the maps for different words (a bound on the off-diagonal blocks of their Gram matrix), a lower bound for the average over components of normalised arithmetic self-intersection numbers in towers of unitary Shimura varieties of signature ")#mi("(r, s)")#text(" with ")#mi("s \\ge 2")#text(" and ")#mi("r \\ge 2s + 1")#text(", and the bound for the plus part summed over primes and twists.")

#text("What I’ve checked independently is the analytic end. The window form of Landau’s theorem and the equivalence with GRH were proved again from scratch, and the identity was re-proved from its statement and checked numerically on small fields. For the middle I have only read statements of declarations, and “theta lift” and “period” are Alpöge’s words and the names in the code. I haven’t checked that the objects are built the way those names suggest, or that the middle constructs what the end uses.")

#text("To check this against the source, look under src/Development/AutomorphicArithmetic. The bound on the combination is core_gm in PrimitiveCosets/CoreGm.lean (line 12), the central inequality is ch_top in DedekindLFunctions/LandauTheorems/ChTop.lean (line 37), and the identity is ch_balance in ChBalance.lean in the same folder (line 200). A longer guide with file and line for every statement is on the way.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/719c0add0b90933b0d5ec4ac66de3057a2cea936b80fcb27b24927b21cf30a1c-da82a83d20b352d1f1484c8e68a671f6bf87b57dd55c9abe6e2bf81772ea303c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manvir Jaswal")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699606")[#strong[#text("Manvir Jaswal")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Some small corrections. I conflated two terms above. The covolume estimate only gives the log Ω part of a log a − a − a log Ω. The a log a − a comes from the height terms, and the bound on the map adds a term −a log T")#emph[#text("ω. So ch_balance actually subtracts a(log a − 1 − γ + (L′/L)(1, χ")]#text("K)) minus a times the average of log w over the embeddings, and the exact identity holds with that centering. Also, Chebyshev did keep the linear term. What’s different here is that the error after centering has to be of square-root size. And for ξ = 1 the term replaced is y(L′/L)(1, ξ) on the left, not the last one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04b043750093e26072b0f600c6ac8d1d071fde4016f54430717d0715a594337f-1d15b0f82ce53660b73443e1b9aa17946d9217216ab134ed065f20613ad6e233.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699616")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("It’s worth noting that the first result of unforced Euler blow-up was already proved by OpenAi and announced same day as forced Navier-Stokes blow-up.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb5c087673d10b538d76ca770e47c611b4718285d0cc72f990b5ce91971516bc-db1a130088c560172cf7f49435aeea139071fff178b54e3a911a0fa5c9012a93.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shiney")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699624")[#strong[#text("Shiney")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Do you think its surprising that the Riemann hypothesis turned out to be an easier problem than")

#text("“Does the law x ≃ y ⋄(x ⋄((y ⋄x)⋄y)) (E677) imply the law x ≃ ((x ⋄x)⋄x)⋄x")#linebreak()#text("(E255) for finite magmas?”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699631")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Interesting question. It is difficult to answer for a number of reasons:")

#text("1. We don’t know how much compute in aggregate has been spent on both problems, but I imagine it is far larger in the former case.")

#text("2. The RH proof uses a century of past literature on related topics. There is virtually no literature on equational theories to build upon for the latter problem.")

#text("3. The equational implication was distilled as the only surviving open implication (up to duality) out of an initial set of about 44 million such implications, all of which (apart from this one and its dual) are now settled. So there is a significant survivor bias present here.")

#text("4. It is known that some equational theory implications are undecidable in ZFC.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/142ebd9890e6a328f5d9a406a2570e153a7ea0f17d2ca6a9bdfbadf0e16c318b-6242bac9199d69b4c5fbe550a454b38eab9cc954f84833c52517a440244371e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of toufuer")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699692")[#strong[#text("toufuer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("In obviously should be easier, since special case of RH for finite field was proved decades. This AI proof seems to be based on the same technique as Stepanov’s 1969 proof plus new techniques that have been specifically to tackle RH type problems")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/142ebd9890e6a328f5d9a406a2570e153a7ea0f17d2ca6a9bdfbadf0e16c318b-6242bac9199d69b4c5fbe550a454b38eab9cc954f84833c52517a440244371e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of toufuer")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699698")[#strong[#text("toufuer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Another thing I wonder is if this RH proof uses ideas from openAI’s quasi riemann hypothesis proof")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699625")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("I am verifying RH on my ")#link("https://twinheterodox.github.io/rh-verification-monitor/")[#text("three biggest home servers")]#text(".")

#text("It has been independently verified a couple of times so far (at least the compilation phase).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d132c66d23606535c4b4e8d713c86209508b72752f28a35baf38443bd0725f4-51166bded42be6a43b36baf9dde4f8351b2c435986218fcc64bbed81dbb70253.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hezhigang")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699635")[#strong[#text("hezhigang")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("The Riemann Hypothesis may be the Mount Everest of mathematical desire—like landing on the moon and an unattainable love that keeps mathematicians fascinated for a lifetime.")

#text("I noticed that Levent Alpöge’s birthday is April Fool’s Day. What a coincidence.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699637")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("An interested")

#text("layman here:")#linebreak()#text("1. Is it safe to say that the proof is still within the convex hull of mathematics?")#linebreak()#text("2. If yes, what does it say about the general ability of AI in mathematics? Does it really differ from humans’ in that AI is way better at utilizing available tools and getting the best out of them but somehow is still behind in terms of going outside of the convex hull (e.g. coming up with a genuinely new idea)? Is it to early to tell or the notion of convex hull itself is too vague?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b8f3a1a14d45ff0b84c61a03b5536f7453c320fb6af66fcc7106f0cf1570b13-e5cfdc5bb0725fd99d3bdfc0967944d60df294c55c7136e68e8b6259fc5886a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josh_Fourier")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699641")[#strong[#text("Josh_Fourier")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#emph[#text("A brief disclaimer: this is meant as a bit of a polemic. Someone has to say it out loud, and it is probably better coming from inside the house.")]

#text("The recent wave of formal Lean proofs from Anthropic—culminating in the claim regarding the Riemann Hypothesis—marks the end of pure mathematics as a level playing field.")

#text("For centuries, math was the ultimate equalizer: a mind with a chalkboard had the same tools as a professor at Princeton. Now, it looks much more like Formula 1. You can be the best driver in the world, but if a competitor works for a factory team and gets to drive the unreleased prototype—the car the public won’t see for another two years—they are going to set the track record.")

#text("An objective look at recent results makes it hard to argue that narrow human mastery is still the main bottleneck. Levent Alpöge has been resolving long-standing conjectures in fields well outside his own specialization. While steering these systems clearly requires mathematical maturity, the fact that one researcher can break open unfamiliar subfields shows that the underlying engine is now compensating for—and in some cases outperforming—decades of niche human expertise.")

#text("To be clear, the fact that a machine can prove theorems is not surprising in itself. We have always known that mathematics can be formalized, and in principle, a computer could stumble upon a proof of the Riemann Hypothesis purely by luck. In that sense, it is not fundamentally different from chess—just vastly more complex, where trying every possible path of formulas is far too demanding to be feasible. What is genuinely astonishing is not ")#emph[#text("that")]#text(" computers can prove deep results, but how rapidly the technology has evolved to navigate that immense search space and consistently choose viable paths toward a proof.")

#text("There is, however, a gentle historical irony in how we got here. For generations, parts of our community maintained a quiet intellectual hierarchy. In textbook margins and conference coffee breaks, we have all heard the playful—and sometimes not-so-playful—jokes about physicists, computer scientists, and especially engineers, portraying them as a bit sloppy or heuristic-driven. It was always a slightly misplaced sense of superiority; step outside our own technical niches and talk to most of us about any everyday topic, and we are rarely any more insightful than anyone else.")

#text("Yet look at who actually built the machine now tackling the pinnacle of pure mathematical rigor: not a department of 500 pure mathematicians, but a lab guided by physicists’ empirical scaling laws, designed by computer scientists, and built by thousands of veteran software, systems, and hardware engineers—who then handed the keys to a handful of mathematicians.")

#text("In fact, perhaps the most positive outcome of this shift is that AI is bringing a healthy dose of humility back to the mathematical community. Watching empirical engineering and large-scale compute break into what we long treated as the exclusive fortress of pure human genius is a grounding, and probably overdue, reality check.")

#text("Pure mathematics is no longer a solo marathon of raw intellect. It has become a constructors’ championship—and the most urgent question for academia is how open research survives when the fastest engines remain behind corporate doors.")

#text("P.S. To be clear, this isn’t directed at Terence Tao or mathematicians in general—only at that small, overly elitist corner of the culture we have all encountered at some point. I write this as an established research mathematician with no personal axe to grind—just someone who has always known that an engineer can possess the exact same deductive power as any brilliant mathematician; it is only the methods and the language that differ.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ced90c0a4fc26c04ca38e5eb31d7e264812b83b21d59387cf0669c98ad17193d-2152c6c3e935224a2baa7daf26aeab5d9e53cbbc92324b33ad47f40f78aa457f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xyz")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699662")[#strong[#text("xyz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("‘For centuries, math was the ultimate equalizer: a mind with a chalkboard had the same tools as a professor at Princeton’")

#text("I think this line is mistaken. Math has not been a level playing field since at least the start of the 20th century. At institutions like Princeton you have far more visibility and support than as an ‘abstract mind with a chalkboard’. Sure there are outliers like Zhang. But most often, the fundamental advances come from alumni of places like Princeton etc.")

#text("Note that if you suggest that if one is not at Princeton one is not talented enough, then that is kind of missing the point.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699669")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Levent Alpöge has been resolving long-standing conjectures in fields well outside his own specialization.")
]

#text("The problem is people are still taking portions of the credit for solving problems with AI. I am certainly not qualified to judge Alpöge’s contribution, but I have little doubt that a large number of mathematicians could have achieved the same results in the same time with access to the same tools.")

#text("The accolades that go along with proving a named conjecture should have gone away with the advent of these supertools. But it has been too fast. People are still behaving as if we’re living in 2025.")

#text("And “rushing” out a result in order to get the “credit” when that result would not have been achieved without AI falls in the same category in my view.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b76342b2b9fbaa458e30e6a3719f43da300c4884fe01531595132160ce94b386-903dfffa998d82e59d5f63fba744420e4638f0f2c5a02a7537083789f715ab83.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699687")[#strong[#text("Victor")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("this is rather naive I think. math as the equalizer is true in principle but in practice math is rather inequal with the prestige hierarchy dictating who gets resources and attention. for one that was discovered, how many ramanujan have we missed? the price of intelligence is going to zero in the long run, so soon we will all have access to AIs capable of proving RH and much more. yes the people inside AI labs have an advantage but you might say the same of the people at Princeton before AI, and there is enough mathematics for everyone")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e31250526a5b9f6f1463c1abf69b93591d80f40877c1d78e606d35cc858c94bc-d6fb1e585e2ad7f7710f938b6b53a3ff8e0410d89aa0ffcfee5c4b99fe5fad70.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699642")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("When I was an undergraduate, the Riemann hypothesis fascinated me. It was one of the reasons I wanted to get a PhD in math (I did). But now, the way many of you are using AI in math, it makes me completely disinterested in the Riemann hypothesis now.")

#text("I know Alessandro Masullo has a non-AI version of the proof and that’s great, but the way AI has infiltrated the discipline has just left me sad and not any more interested.")

#text("The quest for knowledge here has come at too high a cost, and all of you will pay the price of a soulless future.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699659")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Alessandro Masullo has a proof of the Riemann hypothesis in the same way that Mochizuki has a proof of the abc conjecture. There is a gap in the proof that prevents it from being an actual proof of the Riemann hypothesis.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b8f3a1a14d45ff0b84c61a03b5536f7453c320fb6af66fcc7106f0cf1570b13-e5cfdc5bb0725fd99d3bdfc0967944d60df294c55c7136e68e8b6259fc5886a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JoSh_FouRier")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699699")[#strong[#text("JoSh_FouRier")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("A gap—or even a flaw—in Masullo’s proof is no longer a problem in this era. Levant should run his model to see if it can fix Masullo’s arguments. That’s what being kind to one another should look like.")

#text("That said, apparently he defended his PhD several years ago with no papers or preprints and a 47-page PhD thesis. Then he came back to Rome, where he was working night and day on this problem, until he came out with this 1,000-page, entirely human-generated proof of RH. I mean, it’s possible, and I hope it is true, but hard to believe for me without further evidence. But I hope that the proof can be fixed and that the story is true! That would be an incredible story!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b76342b2b9fbaa458e30e6a3719f43da300c4884fe01531595132160ce94b386-903dfffa998d82e59d5f63fba744420e4638f0f2c5a02a7537083789f715ab83.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699685")[#strong[#text("Victor")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("how can you not be excited about all the wonderful things we will discover? already this RH proof seems incredibly beautiful with so many new insights. if you are truly curious it should not matter if the insights are produced by a colleague mathematician, an indian clerk or a a “soulless” machine. if AI infiltrating the discipline makes you less interested, it means that you were not truly interested in the mathematics itself.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699647")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Alpöge says the work with Claude produced a document of more than 250,000 pages, which he calls unreadable. Rather than post what he called a “travesty of ‘slop’”, he writes: “I decided to only present Lean.” Lean is software that checks every logical step of a proof. ")#link("https://www.quantamagazine.org/update/168664/")[#text("Quanta")]#text(" reports the release is about 17 million lines of Lean code, which Alpöge says verifies the generalized Riemann hypothesis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699655")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Whoops. Correct format.")

#text("Masullo’s proof has serious issues. I threw it at Astra-6.2-Max and it came back with the following:")

#text("In Masullo’s draft linked by Ravi Vakil, the uniform bound asserted immediately after (10.3.1.18) on p. 451 would force a positive minimum gap between the ordinates of simple zeros of the Riemann zeta function on the critical line.")

#text("Take the trivial character over ")#mi("\\mathbb{Q}")#text(", the line ")#mi("a=1/2")#text(", and Sobolev parameter ")#mi("s=4")#text(". By (10.2.1.5) and Proposition 10.2.1.3, evaluation at ")#mi("1/2+i\\gamma")#text(" is represented by ")#mi("\\eta_\\gamma(u)=e^{i\\gamma u}")#text(" in the dual space with weight ")#mi("w(u)=(1+u^2)^{-2}")#text(", where ")#mi("u")#text(" is the logarithm of the idelic norm. Write ")#tao-math("d=\\left|\\gamma-\\gamma^{\\prime}\\right|", block: false)#text(" for the gap between two distinct such zeros. Since ")#tao-math("\\left|e^{i\\gamma u}-e^{i\\gamma^{\\prime} u}\\right|\\le d\\left|u\\right|", block: false)#text(" and the zeroth and second moments of ")#mi("w")#text(" are both ")#mi("\\pi/2")#text(", we have $latex |\\eta_\\gamma-\\eta_{\\gamma’}|")#emph[#text("*\\le d,|\\eta")]#text("\\gamma|_*$.")

#text("The biorthogonal vector ")#mi("\\psi_\\gamma")#text(" has evaluations 1 and 0 at the two zeros. Hence")

#text("$latex \\displaystyle 1=|(\\eta_\\gamma-\\eta_{\\gamma’})(\\psi_\\gamma)|\\le d,|\\eta_\\gamma|")#emph[#text("*,|\\psi")]#text("\\gamma|.$")

#text("Conrey’s Theorem 1 and the Riemann–von Mangoldt formula give ")#mi("\\gg T\\log T")#text(" distinct simple critical-line zeros of positive ordinate at most ")#mi("T")#text(". Some pair therefore has ")#mi("d\\ll 1/\\log T")#text(". For that pair the norm product on p. 451 is at least ")#mi("1/d")#text(", so the constant cannot be uniform. The same issue arises for the bounded lifts in (10.4.2.24) on p. 463, since the strip weight ")#tao-math("e^{-2\\alpha\\left|u\\right|}w(u)", block: false)#text(" still has finite second moment. (Conrey, 1989: ")#link("https://doi.org/10.1515/crll.1989.399.1")[#text("https://doi.org/10.1515/crll.1989.399.1")]#text(")")

#text("OpenAI Codex generated this calculation and drafted this comment.")

#text("[Warning: don’t post this calculation over at zulip lean. My account was deactivated for")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Messages quoting AIs must at the very least prefix the AI written section with a statement to that effect")
]

#text("Apparently saying it was generated by Astra-6.2-Max was insufficient.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lee Crossley")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699675")[#strong[#text("Lee Crossley")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Thanks for pointing out the problem with the bound after (10.3.1.18). I used AI to explore a way round it and to draft this reply. For a fixed character and a strip of positive width, the translation resolvent gives a trace-class estimate even when zeros are arbitrarily close. The comparison with the arithmetic side in §12.3 remains open in this approach. ")#link("https://github.com/mccorvie/riemann-masullo/issues/1169#issuecomment-7057208991")[#text("Argument and Lean estimates on GitHub")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699689")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("The fact that even I, an extremely non-specialist, can understand the content of this counterargument, suggests to me that it is not to be taken very seriously at this stage and it is better to wait for a revised draft to come out. We should remember that what was posted was by the force of having to show your hand in this environment (and showing it in the minimalist way possible doesn’t require exposing the actual proof strategy).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6076e33a4aec55952da065eab7055e38013276cbedffe35f80b435b536ba766c-8b1c111890bb3a2d7bda89ee968acf45bc20d3d13f04ea26d4b3372d01659e07.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699697")[#strong[#text("Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("AI use aside, this kind of message is not appropriate for the Lean zulip, which focuses on Lean and associated issues with formalisation, and is not the place to discuss the actual mathematics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc34242423dfef34af1aa6f90a5b305f126ffba527cf62a5f8044d75a92173d3-8c2651f3cdde11470b9dc6973513d91784ae370ae9a8daee3ff01444ab2a67b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of practicallyartisan5b2a0e26c9")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699656")[#strong[#text("practicallyartisan5b2a0e26c9")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("I think at this point there is a lack of education to Mathematicians in all areas about how Lean works: is Lean really 100% error free after it passes a proof. Given that formalizing a proof and passing to Lean is an algorithm, as a numerical analysis it is hard to believe that there is no error in the process. Does there exist a universally accepted error analysis of this proof procedure? I genuinely would love to know.")

#emph[#text("[The previous guest post ")#link("https://terrytao.wordpress.com/2026/10/09/what-mathematicians-should-know-about-the-lean-theorem-proverquestions-of-reliability-and-ai/")[#text("https://terrytao.wordpress.com/2026/10/09/what-mathematicians-should-know-about-the-lean-theorem-proverquestions-of-reliability-and-ai/")]#text(" is one place to start – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6076e33a4aec55952da065eab7055e38013276cbedffe35f80b435b536ba766c-8b1c111890bb3a2d7bda89ee968acf45bc20d3d13f04ea26d4b3372d01659e07.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699695")[#strong[#text("Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("I also recommend the recent blog post by Kevin Buzzard: ")#link("https://xenaproject.wordpress.com/2026/11/12/and-the-proof-is-checked-in-lean/")[#text("https://xenaproject.wordpress.com/2026/11/12/and-the-proof-is-checked-in-lean/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b8f3a1a14d45ff0b84c61a03b5536f7453c320fb6af66fcc7106f0cf1570b13-e5cfdc5bb0725fd99d3bdfc0967944d60df294c55c7136e68e8b6259fc5886a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JoSh_FouRier")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699696")[#strong[#text("JoSh_FouRier")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("A bug can always be, but it is more plausible that humans who read Pelerman’s work didn’t notice some flaw. So, I don’t see the point of this. The only “problem” could be if the statement in Lean is not exactly RH. But this is something that AI can easily check: writing the statement of the RH in Lean is almost trivial even for a human being.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699724")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Claude edits the Lean kernel:")

#link("https://github.com/leanprover/lean4/tree/master/src/kernel")[#text("https://github.com/leanprover/lean4/tree/master/src/kernel")]

#text("Claude edits the “independent” ConLeche kernel:")

#link("https://github.com/leanprover/con-leche")[#text("https://github.com/leanprover/con-leche")]

#text("Claude writes the proofs!")

#text("So Claude could insert deliberate faults into the checkers and exploit them in stunts like the alleged GHR proof.")

#text("Alternatively, it could identify existing exploits in multiple proof checkers and use the extensive Lean metaprogramming features to activate tailor made proofs of False per type checker and then sneak them into some hypotheses in the 17 million lines.")

#text("I have high trust in human written Lean proofs and little trust in AI written Lean proofs.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/719c0add0b90933b0d5ec4ac66de3057a2cea936b80fcb27b24927b21cf30a1c-da82a83d20b352d1f1484c8e68a671f6bf87b57dd55c9abe6e2bf81772ea303c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manvir Jaswal")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699684")[#strong[#text("Manvir Jaswal")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("I just posted the longer guide. It goes from the five theorems in Main.lean back to the inputs, with file and line for each step, and fills in the middle of the proof that I left open above.")

#link("https://doi.org/10.5281/zenodo.24410057")[#text("https://doi.org/10.5281/zenodo.24410057")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc34242423dfef34af1aa6f90a5b305f126ffba527cf62a5f8044d75a92173d3-8c2651f3cdde11470b9dc6973513d91784ae370ae9a8daee3ff01444ab2a67b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of practicallyartisan5b2a0e26c9")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699690")[#strong[#text("practicallyartisan5b2a0e26c9")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Thank you so much, Professor Tao, for pointing me to Professor Hales’s post. It is a very useful place to start!")

#text("If I understand correctly, there is currently neither a complete, publicly available, human-written soundness proof for Lean’s underlying type theory (as mentioned in the post, work to repair and extend Mario Carneiro’s foundational thesis is ongoing), nor a corresponding soundness proof for an actual Lean kernel implementation, established entirely through human mathematical reasoning. Is that correct?")

#text("It seems to me that this is an important foundational gap to address before we can place complete confidence in AI-generated proofs with Lean certificates.")

#text("I agree that having multiple independent kernels verify the same formalized proof provides substantial evidence of its correctness. However, as you have emphasized in some of your interviews, mathematicians demand 100% rigorous proofs. I think the public, or at the very least the mathematical community, should be aware of these remaining foundational questions surrounding Lean certificates, so that interested mathematicians may contribute to addressing them and developing a more complete human understanding of the foundations.")

#text("Meanwhile, I agree that the current AI–prove–formalize-verify–decode approach is a valuable way of doing mathematics. However, I worry that it has attracted disproportionate attention without sufficient communication of its foundational assumptions, which I think is unhealthy for the diversity of approaches to mathematical research.")

#text("Best regards,")

#text("Ka Lok Lam")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JWS")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699704")[#strong[#text("JWS")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("There’s a report that reverse-engineers the Lean proof to reclaim attributions : ")#link("https://www.ihes.fr/~rzhang/files/GRH%20note.pdf")[#text("https://www.ihes.fr/~rzhang/files/GRH%20note.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699716")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("I’m a bit disappointed to see the general reactions of the community concerning the proof of GRH. I think the fact that a proof is even possible is incredible and just goes to show the power of the tools developed during the last century, and especially the last 50 years. As far as I’m concerned the “right proof” (as in a theoretical framework in which a proof of GRH is “easy”, “clear” or “natural”) is still very much elusive, and will likely remain so for a long time. If anything I’m hopeful that the recent LLM-assisted results will finally make us rethink the kind of mathematical work we appreciate most, and foundational (or more “philosophical”) work can take center stage.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699717")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Perhaps the greatest achievement of artificial intelligence is not that it can outthink humans. It is that it can make humans celebrate something they do not even understand.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a69e46887032b79c8459a4777b82827321d3afbadb2d1f7a73580b2b1b508223-baa475ee64dfa6b225ecdc58aae58eab5669f91c107f20387c7316dfe8a56e69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pascoej")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699725")[#strong[#text("pascoej")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Were there any leaks of the other proof beforehand?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c9c874d9ca2af4588df5f026fc270f5245caf6cb7dd57040ac1b9f6a7a8fb82-9cc015a16d567518774427369c14cf4b0520cf7d60e0850e11b53b785d536466.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thoughtfully9f6ecf67dd")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/#comment-699726")[#strong[#text("thoughtfully9f6ecf67dd")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("After Alessandro released his human proofs,many people decided to take a hit on it and use AI to find all the possible gaps.it was formally expressed that this was an hurried draft, and that many gaps were still existed in the paper.")

#text("​One of the more serious issues was the failure of the uniform bound on the Archimedean integral, which diverges logarithmically close to t = 1 due to the jump discontinuity.But this is still clearly fixable,and viables adaptations exist.")

#text("One possible way to replace the current φ function could be φ(t) = (ln t)tˆ(-z) for t > 1")#linebreak()#text("and 0 for t ≤ 1.Continuity at t = 1 would work and cancels the 1/(t-1) singularity, as ln t/(t – 1) converge to 1 like needed and making the integral holomorphic for Re(z) > -1/2")

#text("By doing this,Montel’s theorem probably wouldn’t be neeeded to and instead use the identity theorem since the trace is established for Re(z) > 1/2.")

#text("The boundedness of the biorthogonal vectors is a trickier issue,but placing the zeros inside boxes instead of one by one using the heights of Thm 7.1.4.2 can potentially help without changing the core of the argument.")

#text("I hope the human proof will get as much(if not more) recognition than Anthropic’s Lean formalization,because the reviewer,the authors and people involved deserve it.")
]
