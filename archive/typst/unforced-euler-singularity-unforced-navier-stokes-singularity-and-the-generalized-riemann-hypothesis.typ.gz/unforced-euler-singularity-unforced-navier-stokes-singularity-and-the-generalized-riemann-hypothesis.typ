// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/
// Converted to Typst by tao2typ: "2026-11-24T17:59:36.911136+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Unforced Euler singularity, unforced Navier-Stokes singularity, and the Generalized Riemann Hypothesis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Unforced Euler singularity, unforced Navier-Stokes singularity, and the Generalized Riemann Hypothesis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/")[#text("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-24 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("Obviously these results will be reported widely in other outlets, but I will note them here, in decreasing order of how “digested” the results currently are:")

#list(
[#text("Levent Alpöge, Tristan Buckmaster, and Matei Coiculescu, with heavy AI assistance, have written a ")#link("https://cims.nyu.edu/~tristanb/cc.pdf")[#text("human-readable proof of the finite time blowup for the unforced incompressible Euler equations in three dimensions")]#text(", which is ")#link("https://github.com/mcoiculescu/EulerBlowupPublic")[#text("formalized in Lean here")]#text(".")],
[#text("Levent Alpöge and Tristan Buckmaster, again with heavy AI usage, have generated a ")#link("https://github.com/tristanbuckmaster/navier-stokes/")[#text("proof of the finite time blowup for the unforced incompressible Navier Stokes equations in three dimensions, again with a Lean formalization")]#text(". Here, the paper is technically human-readable and the general strategy of proof is broadly clear (following one of the expected paths to this result, namely to numerically build an approximate discretely self-similar solution and then use rigorous perturbation theory to convert this to an exact solution); but more work needs to be done to create a proper, professionally written proof.")],
[#text("Levent Alpöge, using an internal AI model, has generated an (enormous) Lean-only proof of the Generalized Riemann Hypothesis. ")#link("https://leanprover.zulipchat.com/#narrow/channel/113488-general/topic/Discussion.3A.20Alp.C3.B6ge.20Proves.20the.20Riemann.20Hypothesis")[#text("This Lean Zulip thread")]#text(" is probably the best place to follow the efforts to verify the proof and extract the strategy of proof (which, from very initial analysis, appears to use the full power of modern developments on the Langlands program and arithmetic geometry). (UPDATE: the moderators of the Lean thread are now focusing the discussion on the Lean-related aspects of the proof only.) I imagine the digestion process will take some time, though in this case at least we have a human author to communicate with to assist with this task.")]
)

#text("See also ")#link("https://mastodon.social/@tristanbuckmaster/117649035783718539")[#text("Buckmaster’s Mastodon post")]#text(" regarding the first two results.")

#heading(level: 1)[#text("Comments (138)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b75db7835c14bf700c3b5e076a591b11dbeba67c49e913f45ef438d00110ef01-67fc05f7170f90eb311f259f47092ee20709094c2f27d5eabed9416efc6a04dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Enrique Jordá Mora")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-2/#comment-699959")[#strong[#text("Enrique Jordá Mora")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("The point is that Ravil Vakil and Brian Conrad have given some credit to Masullo’s preprint. That is a strong reason for not cosidering this as a “crank attempt”. Not clear at all that it will become a real proof, but I would like a human and understable proof, producieng new ideas and new lines of research.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-2/#comment-699961")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("Claude: 48% of the theorems the proof uses are only ever used inside their own file but not marked as private.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01f51080251ac8633a7cea823ab9b4cef8086170756a447669f457f5a9135a57-23d86d09d32cd01eae4d140230d91ff0fca85da31ae291b6c7d3df72fca65073.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Afled")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-2/#comment-699978")[#strong[#text("Afled")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("I am uncomfortable with his narrative one that emphasizes his own long-standing struggles and achievements as a human mathematician, while simultaneously leveraging the overwhelming resources of a proprietary “frontier model.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-2/#comment-699982")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("I cannot find the joke on the Internet, again, but I read it circa 2005.")

#text("A man sells his soul to the devil, in exchange for a proof of RH. The devil says, “RH is true. Hmm. Now, how can I explain it.”")

#text("It’s 2026; nothing has changed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81beb49d2d95a46c4f8d48a40f14fc2d463cad75e5821e6459c928f46c189793-4e9f748f3c24fd5af8cb60ffaca606d1aa627a1cc5b11c96ca514d2362d77769.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-2/#comment-700022")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("Probably ")#link("https://mathjokes4mathyfolks.wordpress.com/2011/03/01/hardy-har-har/")[#text("https://mathjokes4mathyfolks.wordpress.com/2011/03/01/hardy-har-har/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/deb5d452e6f269420f4fe89118a4e4866a84d6557242a08225ceff2ba1811011-6926b997129d2d06d9c6b623c3d69b498be4d2fa9034845cae68ccf819012a36.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lole")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-2/#comment-700034")[#strong[#text("Lole")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("Anthropic must answer! Which specific Claude model was used? How much computational power was required to develop the proof? Which mathematical innovations originated from Claude, and which from Alpöge? Were the complete reasoning traces and model weights archived? Will the unpublished 250,000-page version of the proof be made available? Is Anthropic already working on a human-readable proof and further mathematical generalizations? How does Anthropic intend to collaborate with the mathematical community in the future in general?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/deb5d452e6f269420f4fe89118a4e4866a84d6557242a08225ceff2ba1811011-6926b997129d2d06d9c6b623c3d69b498be4d2fa9034845cae68ccf819012a36.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lole")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-2/#comment-700036")[#strong[#text("Lole")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("In the future, the most powerful mathematical AI systems must be trained to transform lengthy formal proofs into elegant, human-readable mathematical research papers. This requires sophisticated mathematical knowledge management, the ability to identify, locate, and appropriately cite established results, and the capacity to clearly articulate genuinely the parts which contain new mathematical contributions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699564")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("David Hilbert in 2443: Has someone proved the Riemann Hypothesis?")

#text("Response: You should sit down.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699640")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("And why should he be surprised? Riemann perhaps could be, but why Hilbert if formalization of mathematics was his idea, the idea of a “thinking machine” goes back to Leibniz and the theoretical notion of a Turing machine was introduced 7 years before Hilbert’s death? This may be surprising to us, because it happened so quickly, we knew the visions of AI from sci-fi books and at the same time we were aware of the failures of previous approaches to formal theorem proving, but c’mon in 2443?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of observanta8864034a9")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699663")[#strong[#text("observanta8864034a9")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Hilbert had just awoken from 1943-land, when few if any people believed it was more than a distant dream that a computer could navigate among and occasionally beyond what he surely regarded as some of highest pinnacles of human intellectual depth and creativity. To be told that this had actually occurred, and only eight decades into his five-century sleep, could be seriously unsettling.")

#text("(Besides which he was still groggy and getting used to the time change.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699734")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Sure, I am just saying that the very idea that a proof could be done by the machine and the question of whether mechanization of mathematics is possible came from Hilbert, so I am not sure if back in 1943 he would have said “This is never going to happen”. The term “robot” and the exploration of thinking machines in sci-fi literature goes back to the 1920s. So, while surprising at the technical level, the basic idea was already a part of the mathematical and pop-cultural imaginarium, even if not its mainstream.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of observanta8864034a9")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699761")[#strong[#text("observanta8864034a9")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Agreed. I even think that of the people in 1943 who could appreciate the difficulty of certain theorems being proven by 2026, Hilbert would have been one of the least surprised by computers’ rate of progress in that regard. I still think sitting a good idea.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699666")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("In 2443, David Hilbert would probably be more surprised that Europe has become uninhabitable because climate change has caused southern Europe to become an extension of the Sahara desert and the AMOC to collapse rendering northern Europe to become like Siberia.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a5b87ac3a4b28fa67a942090a3d6f945ac1076fa7eb45219a040523967d3e59b-b30af3103bd83580f34e3392246bb7e49a927d28b31f44adc9d23657f14cb116.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gokhan Mergen")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699681")[#strong[#text("Gokhan Mergen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("I tried to turn Lean proof into a human readible and beginner friendly manuscript here with the help of AI.")

#text("43 Page GRH Proof Outline: ")#link("https://www.gokhanmergen.com/pubs/grh-reader-guide/GRH_Reader_Friendly_Guide.pdf")[#text("https://www.gokhanmergen.com/pubs/grh-reader-guide/GRH_Reader_Friendly_Guide.pdf")]

#text("Comments and feedback are welcome!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5ae40e822d598a979305ab7702d1f3dbc72de64361cfc9e43ab7a47810316560-62959af42aa9b0aeaf06d66fb472223f923481c8e700d51570ffe902222018be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Science Markets")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699569")[#strong[#text("Science Markets")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Thank you for the ordering by how digested the results are. That ordering is the whole story, and it is worth being explicit about why.")

#text("For the first two results the digestion path is already visible: human-readable proof, strategy broadly clear, Lean formalisation on top. A reader can form a judgement in an afternoon. The third has no such path yet. A Lean-only artifact of that size is a different kind of object, and the question “is it right” splits into questions that resolve on very different timescales: does the headline statement in Lean say what we mean by GRH; does the archive compile against a known-good Lean with only standard axioms; is the strategy something a number theorist recognises as a proof. The Zulip thread can answer the second relatively quickly. The third is the one that has always taken years.")

#text("The two precedents are both uncomfortable. Wiles announced in 1993, the gap surfaced within months, and the repair took until 1995. Mochizuki published in a refereed journal in 2012 and the people who work on the problem still do not accept it. In neither case could the answer be read off the artifact.")

#text("Which makes the interesting question not “is it true” but “what observable event would settle it, and who is entitled to say so”. For anyone trying to price this rather than just follow it, writing that down before the claim exists is the only version that is worth anything. Written afterwards it collapses into an argument about credibility, which is precisely the failure mode this whole episode is about.")

#text("Disclosure: I work on ")#link("https://science.markets")[#text("https://science.markets")]#text(", which runs a market on this question. The resolution rule is fixed before the market opens and cannot be edited: ")#link("https://science.markets/markets/riemann-zeta-critical-line/")[#text("https://science.markets/markets/riemann-zeta-critical-line/")]#text(" — it requires a complete unconditional proof in ZFC, independently checked with no unresolved gap, and it says in advance that finite numerical verification does not count and that independence from ZFC leaves it unresolved. Being forced to write down what does not count was the useful part.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699671")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Are we allowed to just advertise gambling sites on this blog now? Next thing you know we’ll see a paper “The DraftKings proof of P != NP”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699731")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("By the way, this is an LLM generated comment. This is sort of a classic signature “That ordering is the whole story, and it is worth being explicit about why.” blah blah, worth explicit about why. There’s a couple of more fingerprints here but I’ll leave it as an exercise to the reader to find them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699828")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("It’s fairly obvious, though, I sometimes give people the benefit of doubt because I don’t want to discount anyone’s ability to write properly. Especially in circles like this, where smart folks are common. But the register has to match the content, and not be simply performative.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/afbd5f32738a6b0f8a5349685bb0f06092f1602bd718c7004e3afa474fa694dc-8e71c917b8fad71631d445e0dbef46f145a2dacf5a435d44c8dcedcaa216c28a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Juliette Bruce")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699578")[#strong[#text("Juliette Bruce")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Perhaps the world has changed in the last 2.5 months, however, I cannot help but remember your warning in early September,")

#text("“The point remains that there is a substantial opportunity cost in converting a historically productive and motivating problem (such as Navier-Stokes regularity) into a mere viral social media post advertising some benchmark progress, rather than actually advancing the field and developing the next generation of both problems to ask, and people to work on them.”")

#text("It feels like Alpöge’s actions around GRH have seen your fears come to fruition. I cannot help but feel that regardless of our feelings around the use of AI in mathematics we as a math community should not highlight Alpöge’s actions without a healthy dose of criticism.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/950ef28da192aca0891b0ff0171518a13c591bbfcbc7b05a97d12290df4a4d1d-eec25033acb8bc10388c92c217ec4666c8cf3b962fc726414da8027f7d49b213.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pawap")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699614")[#strong[#text("pawap")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("If something is lean verified I think releasing is a good thing. The community can begin digesting/interpreting or building off of the results more quickly and with great plurality.")

#text("Also, if an individual withholds new results because they feel they have greater results upcoming, that’s well within their right, of course that comes at a risk.")

#text("Ideally well known vehicles will emerge for triaging huge lean results, and another vehicle that is meant for human consumption.")

#text("Right now it’s a bit of a hodge podge.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f832c7334b3f139142f58e810a51fe512f4a88e11da9b4aa59649df1c717f459-ad995c6cb972815820045ff0a3deedee85e3cf2b9495fffe4eb337526e7cc50e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin Ventullo")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699646")[#strong[#text("Kevin Ventullo")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("I think there’s a big difference between Alpoge’s announcement here and OpenAI’s dump from a few months back. Specifically this line:")

#text("“I intend to do my best to understand and impart understanding of this argument and its certain simplifications, to speak about it, to write it properly.”")

#text("I genuinely think Alpoge does care about mathematics, and this problem in particular, and his motivation was not to drum up PR.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699677")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Alpoge might care about this problem, but mainly to the extent that it brings him credit/glory. Otherwise he wouldn’t have dumped this AI slop, but worked to explain it better. His pattern of behavior over the last few months regarding other problems is not that of a person with integrity. At this point, he is basically a child with a new (and very powerful) toy – lots of compute, and powerful internal models, which he’s using to gather as much credit and fame as possible. Any such recognition should take into account the differential in resources between him and mathematicians in academia.")

#text("Mathematicians have asked AI companies to not feed big open problems to internal models, and clearly neither the companies nor their employees such as Alpoge give a damn.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699791")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Alpoge is exactly what I’m wondering about. Why is it always him, what is it about his intuition, questions and personal preferences steering best use of AI. Is this where his strengths and weaknesses of AI and tendency to avoid arduous and time consuming academic labour? When is the book on how to use AI to brute force analytic problems?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699852")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("No doubt he’s a smart guy, but having access to millions of dollars of computing power helps a bit.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699925")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("I think given what happened with NS (OpenAI found out what Alpoge was working on, and used the knowledge to scoop him, whether or not they trained on his work-in-progress) might have incentivized him to announce about RH as soon as he could.")

#text("As for access to models, as I understand it, OpenAI and Anthropic both have standing offers to mathematicians wanting to crunch on stuff. I don’t know whether the offers include advanced internal models, or only tokens for use with the publicly available ones.")

#text("I tend to agree with the “human mathematics movement” (a term that I just invented) but that’s purely a philosophical viewpoint. There are other math people (maybe a minority) who are delighted to see famous problems solved, even when done by robots.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ecf0b9ac90961a4a47d19b6a03382247e4041d8258c46268abed4c3eb9a18c92-44f559629e1fed2c23d301c5f15c93c759285c2f42b62e466c99c8c94e677e48.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699702")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Alpoge works for Anthropic and his apparent interest is producing AI generated Lean proofs of Millennium problems. Impossible to know a person’s motivations, but there’s a huge element of PR here.")

#text("Of course, positive things to be said about this vs OpenAI dump. (He’s a legitimate mathematician who talks to mathematicians; has clearly been listening to feedback from the community; whole thing less vulgar).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699714")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#enum(start: 1, 
[#text("I don’t appreciate that Levent isn’t being entirely transparent here? How did he get the proof? How much compute was used? Can we have the chain of thought?")],
[#text("I don’t like how we only got a lean formalization and we didn’t get a natural language proof. The mathematical statements in Levent’s statement seem nonsensical. I sincerely hope Alessandro Masullo is right.")],
[#text("I wish Levent gave more detail as to how Claude was prompted. Did the author have any access to Claude’s chain of thought?")],
[#text("Given the problems Levent is targeting (this, Navier-Stokes, Yang-Mills, probably also spending significant compute on the other two), it’s hard for me to believe he’s not doing this for some PR. His romantic tone in his 4 page note is not helping his case in this regard.")],
[#text("I don’t see much evidence of commitment to understand and more importantly helping others understand the argument. If he did, he’d disclose much more and actually put out his 250k pages of agent notes or tried to simplify this.")

#enum(start: 1, 
[#text("I see instead of helping foster mathematical community and human understanding him continuously foregoing this process and aiming his starkiller at results that would be big in “math 1.0”.")]
)],
[#text("I don’t claim to know what he is doing behind the scenes, but he seems more interested in putting mathematicians out of a job than in advocating for their livelihoods. (For instance, he has a vendetta against mathematical journals, which fueled a lot of the hiring process.) I don’t sense any amount of sensitivity in his public statements towards what other mathematicians are feeling.")

#enum(start: 1, 
[#text("I would love to be proven wrong here.")]
)]
)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c2953e2084c6daee40a64d30dd20dd2fba27a496f20cdb9647942161f68d8d8-4d2760e6ffc70b8028d99935fe7f2d52f68f502b51757a7b4afdf40a54288b62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Beach")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699775")[#strong[#text("Robert Beach")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("After. In this age of million(s) of lines long proofs, I think the process of obtaining the proof is as important as the proof itself. I hope we will get full transparency of the process so we can replicate the results. Or do they intend to position themselves as the new mathematical “wizards”, magically producing results with no (or very vague) indication of how it was achieved.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699665")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("I genuinely believe that Alpoge is not doing this as PR for Anthropic. He is doing it for personal glory-seeking, because he has exclusive access to better technology.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699894")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("It’s clearly a win-win.")

#text("Alpoge couldn’t have done this without the tools from Anthropic and Anthropic couldn’t have done this without Alpoge’s expertise, not within this time frame (efficiency obviously matters to them, due to the fierce conpetition between AI companies to prove these famous problems).")

#text("So the announcement must have been quite a balancing act between PR for Anthropic/Claude and his personal fame and glory.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed2e4bc80ac04fd3011adefe82e10730633aa94efbef6906e1e5400b4a384a7a-260d191bf650ba5e51bd94788f6dd62e7e27ecf32a5883604813ea50041478aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699706")[#strong[#text("L")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("It should be obvious by now that they don’t want anyone to work in anything ever again. To feel any sense of mastery or satisfaction or control ever again. You are supposed to be a happy consumer who claps every time you see another benchmark headline in the news. And they want to be the ones with the dopamin levee. There will be no more math students, no “next generation”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d33f08c147a7fc66e9d167ea76ca26b72ca26ad7c878de31ae73305f87bbc629-3700b43ee759c311319c34c8a5b480d0082d89f7fcc3d21e8111cb9d51eae8d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of k")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699766")[#strong[#text("k")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("My view of the politics of the situation is this. Governments have been willing to fund theoretical physics and pure math because of how much contribution people in these communities made to the WWII effort. Anthropic and OpenAI are in the business of seeking government contracts for defense, such as surveillance, targeting, and everything else. There is no doubt that their current or near future systems will be able to design million-component weapon systems from scratch, such as criuze missiles, fighter aircraft, and so on. Their only purpose in publishing millenium problems is in convincing the governments to give all the money to them. You would think that puny as it is, funding for pure science is not the part of the pie that they would be fighting for… but thats not how corporate PR works… “pee onto every lamppost” is the name of this strategy.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699580")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Does anyone have a rough estimate for how long until the GRH proof is verified?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/719c0add0b90933b0d5ec4ac66de3057a2cea936b80fcb27b24927b21cf30a1c-da82a83d20b352d1f1484c8e68a671f6bf87b57dd55c9abe6e2bf81772ea303c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manvir Jaswal")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699597")[#strong[#text("Manvir Jaswal")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Lean builds should be finishing up soon with people that have powerful servers, and then it will be checked thoroughly for the next few days. Should be soon where we have a pretty good idea if it’s looking good.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ac08578e0edfc897ba8259f941762c2c4419cb63fb57bafed3975794bd8573a-78dfc549694bf79c3787425760bffa7b7a0389839d3af0e3c06010309348dcf7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam Hopkins")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699582")[#strong[#text("Sam Hopkins")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("It is also worth linking to this post from Ravi Vakil, about an independent, non-AI proof of GRH from Alessandro Maria Masullo: ")#link("https://math216.wordpress.com/2026/11/20/hurried-announcement-alessandro-masullo-grh/")[#text("https://math216.wordpress.com/2026/11/20/hurried-announcement-alessandro-masullo-grh/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/34d52ec9750d32e72618d7593943cb5eff68c46e2cc65e396041847f0e532a91-30c4bdb0cfd0d5a76f23bbf8b85ceaf3ee1bbcc43a7b5e99e18ad6112065ab82.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nomen")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699604")[#strong[#text("Nomen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("The draft is incomplete, it includes footnotes like “Correct statement”, “Insert statement”, “Correct this subsection”, and “Include section”. Hopefully these would be fixed soon.")

#text("A preliminary AI audit:")#link("https://chatgpt.com/share/6b009d72-01e4-83ee-875c-bae3dbd3e326")[#text("https://chatgpt.com/share/6b009d72-01e4-83ee-875c-bae3dbd3e326")]#text(" . The current state of the proof doesn’t seem very promising.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03a96277fb9a4a2ce8bb8729b71e38e4706d338954946f30c636813138862df5-1e67bfc2d6679a272413d03ad4a5904a964711a4f10009770f7339d4949892e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomos")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699619")[#strong[#text("tomos")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("“the current state of the proof doesn’t seem very promising”")

#text("looks promising to me. (what should even an incomplete but promising one look like…)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/34d52ec9750d32e72618d7593943cb5eff68c46e2cc65e396041847f0e532a91-30c4bdb0cfd0d5a76f23bbf8b85ceaf3ee1bbcc43a7b5e99e18ad6112065ab82.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nomen")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699623")[#strong[#text("Nomen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Not containing false statements, for starters. A gap in the proof of a lemma is much more promising than a false lemma.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03a96277fb9a4a2ce8bb8729b71e38e4706d338954946f30c636813138862df5-1e67bfc2d6679a272413d03ad4a5904a964711a4f10009770f7339d4949892e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomos")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699629")[#strong[#text("tomos")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("not sure. non-ai product can easily have statements that would fail an ai test (as you ran) but are true in the case the author means it, and would be one of the things set aside to the “will be polished”. i’m not saying it’s correct or incorrect i just thought running an ai-test on a non-ai product and saying it doesn’t look promising was unfair to masullo, on such a popular blog.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699762")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("is this like the opposite of Ai effect? instead of Ai doing cool thing and goal posts getting moved, now humans do cool thing and goalpost is being moved under them?")

#text("first release is expected to have minor gaps – that’s what happened in all major huge-in-volume results up to this point. Especially since the release was rushed due to ai release")

#text("It will take couple years for humans to rephrase and redo approaches in better ways, while expanding own technique arsenal")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nic")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699703")[#strong[#text("Nic")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("The draft itself says that it is incomplete. Here is a quote from page 6:")

#text("“In light of the current climate I am being advised to release the current version as it is. The math is complete, and only filling in some writing remains on several parts across this long paper. The plan was to")#linebreak()#text("take a year of doing just this…”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699927")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("At best this is like the situation with Perelman’s preprints about the Poincaré conjecture. Yes there were gaps and errors, but they got filled in after a while, and Perelman was awarded both the Millenium prize ($1M) and the Fields medal (he refused both).")

#text("At worst it’s like any other paper with unfillable gaps or unfixable bugs. Those happen all the time and normally the author is willing to say “oops, oh well” after reasonable repair efforts don’t work out. Mochizuki’s situation is unusual.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699876")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Masullo’s approach reminds me of the approach by Xian-Jin Li also using ideas from Connes (but did not receive the fanfare such as an annoucement by Vakil):")

#link("https://arxiv.org/abs/0807.0090v10.")[#text("https://arxiv.org/abs/0807.0090v10.")]#link("https://arxiv.org/abs/0807.0090v10")[#text("https://arxiv.org/abs/0807.0090v10")]#text(".")

#text("The approach is different from his 2008 attempt (and unfortunately posted into math.GM).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699891")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Masullo has now created a web site at ")#link("https://sites.google.com/view/tmotp/home?authuser=0")[#text("https://sites.google.com/view/tmotp/")]#text("which will presumably hold any further updates on this manuscript, although given that the original plan was to work on it for at least a year, I would not expect any extremely rapid developments.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c9c874d9ca2af4588df5f026fc270f5245caf6cb7dd57040ac1b9f6a7a8fb82-9cc015a16d567518774427369c14cf4b0520cf7d60e0850e11b53b785d536466.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adel liot")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699922")[#strong[#text("Adel liot")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("To everyone who would like to help formalizing the proof in Lean,there also exist a current github currently trying to do so using agents :")#link("https://github.com/mccorvie/riemann-masullo")[#text(" ")]#link("https://github.com/mccorvie/riemann-masullo")[#text("https://github.com/mccorvie/riemann-masullo")]

#text("You can also donate tokens if possible !")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/483aab64af8536b29f2e6bdbfa105c31ec540d9870c15d8bc5b4cd08b804a76d-a9f8036e8177ef542a464fb2f9165b84b29411604ce13185b97a349cad79edad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of george")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699584")[#strong[#text("george")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("The famous quote by David Hilbert:")

#text("“If I were to awaken after having slept for a thousand years, my first question would be: Has the Riemann hypothesis been proven”")

#text("Wild times to be alive =)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699586")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Hello, I’m no expert here. Since the RH is a problem of analytic nature, have the experts always believed that the natural way of proving the RH is by the means of analytic number theory? I’m surprised because on Zulip someone did actually confirm some heavy algebraic number theory/arithmetic geometry tools being formalized.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699598")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("The conventional wisdom has been that purely analytic methods are not sufficient to establish RH, as it is too easy to perturb the zeta function to move a few zeroes off of the critical line (cf. the resolution of Newman’s conjecture on the de Bruijn-Newman constant). As with the Landau-Siegel problem (the resolution of which is a corollary of GRH), the main promising routes have been automorphic methods, algebraic number theory methods, or arithmetic geometry methods; the latter were the key for instance to Deligne’s resolution of the function field analogue of RH (the Weil conjectures). It is very early days but it seems like the AI-generated proof uses all of these inputs. There has also been the wildcard of “F_1” approaches, as proposed by Alain Connes; the new Masullo manuscript apparently goes down this route to some extent, but it will take some time to digest that manuscript also. [EDIT: on closer inspection, the Masullo manuscript is closer to Deninger’s strategy towards RH than Connes’, although the two approaches have some similarities (though neither is close to being concretely fleshed out).]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699636")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("I wonder what is the relation between a Lean certificate and a statement that the proof exists in ZFC. I am not an expert, but there are articles claiming that standard Lean axioms are stronger than ZFC and in particular prove consistency of ZFC. Has it been verified that the Lean proof does not use something beyond ZFC? I understand that with Navier-Stokes it was more or less clear that the proof is analytic and one should not worry about such issues. My understanding that a Lean certificate relying on standard Lean axioms does not settle this issue. And at least to me “proving a RH” means “proving RH in ZFC”, even if proving it with some reasonable additional axioms would still be an achievement.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/719c0add0b90933b0d5ec4ac66de3057a2cea936b80fcb27b24927b21cf30a1c-da82a83d20b352d1f1484c8e68a671f6bf87b57dd55c9abe6e2bf81772ea303c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manvir Jaswal")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699587")[#strong[#text("Manvir Jaswal")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("I’ve been looking into the Lean source as text, with Claude Fable 5.2 and GPT Astra 6.2, to get the strategy out of it. This is a first pass and I’ll refine it as the middle of the proof gets checked. I haven’t built the archive or checked its proofs, so all this says is how the proof is organized.")

#text("The end of the proof is classical in method. Take a primitive character ")#mi("\\psi")#text(", let ")#mi("\\xi")#text(" run over the primitive characters inducing its powers, and look at the centred ramp sums")

#mi("\\displaystyle G(\\xi, y) = \\sum_{n \\le y} \\Lambda(n)\\, \\xi(n) \\left(\\frac{y}{n} - 1\\right) + y\\, \\frac{L^{\\prime}}{L}(1, \\xi) = \\sum_\\rho \\frac{y^\\rho}{\\rho(1 - \\rho)} + O_\\xi(\\log y)")

#text("over the nontrivial zeros ")#mi("\\rho")#text(" of ")#mi("L(s, \\xi)")#text(", with multiplicity (for ")#mi("\\xi = 1")#text(" the last term is replaced by ")#mi("-y \\log y + (1 + \\gamma) y")#text(", with ")#mi("\\gamma")#text(" Euler’s constant). What the archive proves is that, for every small positive ")#mi("\\varepsilon")#text(", the combination of the ")#mi("\\mathrm{Re}\\, G(\\xi, x)")#text(" with weight ")#mi("1")#text(" at ")#mi("\\xi = 1")#text(" and ")#mi("1/(3\\,\\mathrm{ord}\\,\\psi + 1)")#text(" at every other ")#mi("\\xi")#text(" is at most ")#mi("x^{1/2 + 9\\varepsilon}")#text(" for all ")#mi("x")#text(" in windows ")#mi("[Y, Y^{3/2}]")#text(" with ")#mi("Y")#text(" arbitrarily large. A window form of Landau’s theorem (his argument, localized to a window) then excludes zeros to the right of the line ")#mi("\\mathrm{Re}\\, s = 1/2")#text(". Under GRH the bound follows at once from the formula, so it is equivalent to GRH for these characters, and the work is all in proving it.")

#text("The bound is proved in the spirit of Chebyshev, by comparing divisibility with size. The untwisted sum is a count of divisibility, since ")#mi("\\sum_{n \\le y} \\Lambda(n)(y/n - 1) = \\sum_p \\log p \\sum_i \\max(y/p^i - 1, 0)")#text(", much as ")#mi("\\log n! = \\sum_p \\log p \\sum_i \\lfloor n/p^i \\rfloor")#text(". For ")#mi("n!")#text(" itself the prime valuations account for the size exactly. Information comes from setting an independent lower bound for divisibility against an independent upper bound for size. In the proof the lower bound for divisibility is at the primes ")#mi("p")#text(" inert in an imaginary quadratic field ")#mi("K")#text(" (with a correction at the ramified prime), at least about ")#mi("a/p + a/p^3 + \\dots")#text(" powers of each, where ")#mi("a")#text(" is a size parameter. Only odd powers appear because ")#mi("\\Lambda(n)(1 - \\chi_K(n))")#text(" is ")#mi("2 \\log p")#text(" on the odd powers of an inert ")#mi("p")#text(" and vanishes on its even powers and at split primes. So this count belongs to ")#mi("\\zeta(s)/L(s, \\chi_K)")#text(" in the way the factorial’s belongs to ")#mi("\\zeta(s)")#text(". The size has to match this count to second order, down to the term linear in ")#mi("a")#text(", and that is where the constant ")#mi("\\log \\Omega")#text(" below comes from. Chebyshev matched only ")#mi("a \\log a")#text(", and got constants. What is then left of “divisibility ≤ size” is a one-sided bound on the centred ramp sums twisted by characters, as strong as the errors in the two estimates. A one-sided bound is what Landau’s theorem takes. Alpöge’s note calls the argument a descendant of Stepanov’s, with a chain of theta lifts, each “mimicking multiplicity”, standing in for the multiplicity that is hard to find over the integers.")

#text("At the scales the proof uses, the integer’s role is played by maps between lattices over a number field containing an abelian CM field ")#mi("E")#text(", one map for each word in a family. Each map is a composite of ")#mi("m = x^{1/2 - O(\\varepsilon)}")#text(" kernels, attached to a chain of definite Hermitian spaces over ")#mi("E")#text(". In Alpöge’s note these are theta lifts between totally definite unitary groups, and the entries of the maps are periods. The declarations compare each map’s pairing with a Bessel-type pairing, up to isometries and a nonzero scalar. I have not checked that this is the classical period.")

#mi("E")#text(" is the compositum of a real layer of the 2-power cyclotomic tower, of degree about ")#mi("x^{2+8\\varepsilon}")#text(", the field cut out by ")#mi("\\psi")#text(", and two imaginary quadratic fields ")#mi("\\mathbb{Q}(\\sqrt{-q})")#text(" and ")#mi("K = \\mathbb{Q}(\\sqrt{-d})")#text(", for very large primes ")#mi("q")#text(" and ")#mi("d")#text(" chosen below. Summed over the chain, the lifts have to gain at least about ")#mi("m\\,(a/p + a/p^3 + \\dots)")#text(" powers of ")#mi("p")#text(" at each inert ")#mi("p")#text(" up to a cutoff, with explicit losses. Behind this is the local statement that a normalised theta series becomes ")#mi("p")#text("-integral once you substitute the formal logarithm of a CM elliptic curve, whose formal group has height 2 at inert ")#mi("p")#text(". An ")#mi("a")#text("-th derivative in height 2 gains about ")#mi("a/p + a/p^3 + \\dots")#text(" powers of ")#mi("p")#text(", and I read the count as coming from there (no declaration says so). (Here ")#mi("a = x b")#text(" with ")#mi("b = \\exp(x^\\varepsilon)")#text(". The ramp sums are evaluated at ")#mi("y = a/w")#text(" for weights ")#mi("w")#text(" attached to the embeddings of ")#mi("E")#text(", and the relevant ")#mi("w")#text(" are near ")#mi("b")#text(", so ")#mi("y")#text(" is near ")#mi("x")#text(".) Divisibility and size are compared through a slope inequality of Bost’s type, applied to all the maps at once, and the main term ")#mi("a \\log a - a - a \\log \\Omega")#text(" per lift comes from a separate covolume estimate, where ")#mi("\\log \\Omega = \\gamma + \\log(2\\pi/\\mathrm{rd}_E) - \\frac{L^{\\prime}}{L}(1, \\chi_K)")#text(" and ")#mi("\\mathrm{rd}_E")#text(" is the root discriminant of ")#mi("E")#text(".")

#text("Subtracting the main term on the size side from the prime-power count on the divisibility side gives, exactly, a combination of the ")#mi("G(\\theta, \\cdot)")#text(" over the characters ")#mi("\\theta")#text(" of ")#mi("\\mathrm{Gal}(E/\\mathbb{Q})")#text(", read as Dirichlet characters (orthogonality of characters). After averaging along the tower only the powers of ")#mi("\\psi")#text(" survive, alone or times ")#mi("\\chi_{-q}")#text(", ")#mi("\\chi_{-d}")#text(" or ")#mi("\\chi_{-q}\\chi_{-d}")#text(". The untwisted powers are the sum we want. I don’t know a pointwise bound for the twisted ones short of GRH, and the archive doesn’t use one. It picks ")#mi("q")#text(" and ")#mi("d")#text(", by a mean-square estimate over primes and a count of zeros, so that the twisted ramp sums are ")#mi("O(y^{1/2+\\varepsilon})")#text(" on a window. I think that is one reason the result comes on windows and not for every large ")#mi("x")#text(". The total loss is ")#mi("x^{O(\\varepsilon)}(x/m + m + \\sqrt{x})")#text(", hence ")#mi("m")#text(" near ")#mi("\\sqrt{x}")#text(".")

#text("The integrality comes with an error term, and its arithmetic part involves Tate–Shafarevich groups of Tate twists. Take the classes in $latex H^1(E, \\mathbb{Q}")#emph[#text("\\ell/\\mathbb{Z}")]#text("\\ell(-e))$ that are unramified outside ")#mi("\\ell")#text(" and trivial at the places above ")#mi("\\ell")#text(", and sum the lengths of these groups over primes ")#mi("\\ell")#text(" and twists ")#mi("e \\ge 1")#text(" below ")#mi("x^{401}")#text(" with weight ")#mi("\\log \\ell")#text(". The archive bounds the minus part by valuations of generalized Bernoulli numbers, as one does classically, away from 2 and the primes dividing ")#mi("[E:\\mathbb{Q}]")#text(". The plus part is what the note calls a “weakening of Vandiver”. In its main case it is proved from three-dimensional Galois representations attached to automorphic forms on unitary groups, a vanishing of Selmer groups of Kato’s type, and congruences between the Frobenius traces of those representations and the reducible trace ")#mi("1 + \\Psi + \\Psi^{-1}")#text(", where ")#mi("\\Psi")#text(" is the twisted character. The main estimate there is polynomial in the conductor and the twist, but the assembled bound picks up one more term of size ")#mi("\\exp(x^{4\\varepsilon/5})")#text(" from finitely many small primes. That’s still below the ")#mi("\\exp(x^\\varepsilon/2)")#text(" the integrality can afford. There is one special case I can compare with the literature. Over ")#mi("\\mathbb{Q}")#text(" the archive’s bound gives the vanishing of the eigenspace of the ")#mi("p")#text("-part of the class group of ")#mi("\\mathbb{Q}(\\zeta_p)")#text(" for the ")#mi("(p - n)")#text("-th power of the Teichmüller character, ")#mi("n \\ge 3")#text(" odd, as soon as ")#mi("\\log p")#text(" exceeds ")#mi("C n^A")#text(", with constants ")#mi("C")#text(" and ")#mi("A")#text(" that are not made explicit. Toward Vandiver’s conjecture, Soulé (1999) proves this, for ")#mi("n \\ge 5")#text(", when ")#mi("\\log p")#text(" exceeds ")#mi("n^{224 n^4}")#text(".")

#text("On the Langlands side, what I see of local Langlands on the main route is the existence of a map with a short list of properties (class field theory on characters, Zelevinsky’s segments, depth zero over ")#mi("\\mathbb{Q}_p")#text("). The map isn’t asked to preserve epsilon factors of pairs. But a local converse theorem for ")#mi("\\mathrm{GL}_n")#text(", which does involve them, is among the inputs passed to the Galois side, and I haven’t checked whether it is actually used there. The Galois representations attached to regular algebraic polarized cuspidal representations of ")#mi("\\mathrm{GL}_n")#text(" over CM fields are used in full for their existence, with only the local–global compatibility weakened.")

#text("Among the statements I could not find in the literature are the central inequality itself, the approximate orthogonality between the maps for different words (a bound on the off-diagonal blocks of their Gram matrix), a lower bound for the average over components of normalised arithmetic self-intersection numbers in towers of unitary Shimura varieties of signature ")#mi("(r, s)")#text(" with ")#mi("s \\ge 2")#text(" and ")#mi("r \\ge 2s + 1")#text(", and the bound for the plus part summed over primes and twists.")

#text("What I’ve checked independently is the analytic end. The window form of Landau’s theorem and the equivalence with GRH were proved again from scratch, and the identity was re-proved from its statement and checked numerically on small fields. For the middle I have only read statements of declarations, and “theta lift” and “period” are Alpöge’s words and the names in the code. I haven’t checked that the objects are built the way those names suggest, or that the middle constructs what the end uses.")

#text("To check this against the source, look under src/Development/AutomorphicArithmetic. The bound on the combination is core_gm in PrimitiveCosets/CoreGm.lean (line 12), the central inequality is ch_top in DedekindLFunctions/LandauTheorems/ChTop.lean (line 37), and the identity is ch_balance in ChBalance.lean in the same folder (line 200). A longer guide with file and line for every statement is on the way.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/719c0add0b90933b0d5ec4ac66de3057a2cea936b80fcb27b24927b21cf30a1c-da82a83d20b352d1f1484c8e68a671f6bf87b57dd55c9abe6e2bf81772ea303c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manvir Jaswal")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699606")[#strong[#text("Manvir Jaswal")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Some small corrections. I conflated two terms above. The covolume estimate only gives the log Ω part of a log a − a − a log Ω. The a log a − a comes from the height terms, and the bound on the map adds a term −a log T")#emph[#text("ω. So ch_balance actually subtracts a(log a − 1 − γ + (L′/L)(1, χ")]#text("K)) minus a times the average of log w over the embeddings, and the exact identity holds with that centering. Also, Chebyshev did keep the linear term. What’s different here is that the error after centering has to be of square-root size. And for ξ = 1 the term replaced is y(L′/L)(1, ξ) on the left, not the last one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04b043750093e26072b0f600c6ac8d1d071fde4016f54430717d0715a594337f-1d15b0f82ce53660b73443e1b9aa17946d9217216ab134ed065f20613ad6e233.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699616")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("It’s worth noting that the first result of unforced Euler blow-up was already proved by OpenAi and announced same day as forced Navier-Stokes blow-up.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb5c087673d10b538d76ca770e47c611b4718285d0cc72f990b5ce91971516bc-db1a130088c560172cf7f49435aeea139071fff178b54e3a911a0fa5c9012a93.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shiney")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699624")[#strong[#text("Shiney")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Do you think its surprising that the Riemann hypothesis turned out to be an easier problem than")

#text("“Does the law x ≃ y ⋄(x ⋄((y ⋄x)⋄y)) (E677) imply the law x ≃ ((x ⋄x)⋄x)⋄x")#linebreak()#text("(E255) for finite magmas?”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699631")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Interesting question. It is difficult to answer for a number of reasons:")

#text("1. We don’t know how much compute in aggregate has been spent on both problems, but I imagine it is far larger in the former case.")

#text("2. The RH proof uses a century of past literature on related topics. There is virtually no literature on equational theories to build upon for the latter problem.")

#text("3. The equational implication was distilled as the only surviving open implication (up to duality) out of an initial set of about 44 million such implications, all of which (apart from this one and its dual) are now settled. So there is a significant survivor bias present here.")

#text("4. It is known that some equational theory implications are undecidable in ZFC.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/142ebd9890e6a328f5d9a406a2570e153a7ea0f17d2ca6a9bdfbadf0e16c318b-6242bac9199d69b4c5fbe550a454b38eab9cc954f84833c52517a440244371e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of toufuer")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699692")[#strong[#text("toufuer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("In obviously should be easier, since special case of RH for finite field was proved decades. This AI proof seems to be based on the same technique as Stepanov’s 1969 proof plus new techniques that have been specifically to tackle RH type problems")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/142ebd9890e6a328f5d9a406a2570e153a7ea0f17d2ca6a9bdfbadf0e16c318b-6242bac9199d69b4c5fbe550a454b38eab9cc954f84833c52517a440244371e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of toufuer")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699698")[#strong[#text("toufuer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Another thing I wonder is if this RH proof uses ideas from openAI’s quasi riemann hypothesis proof")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699625")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("I am verifying RH on my ")#link("https://twinheterodox.github.io/rh-verification-monitor/")[#text("three biggest home servers")]#text(".")

#text("It has been independently verified a couple of times so far (at least the compilation phase).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d132c66d23606535c4b4e8d713c86209508b72752f28a35baf38443bd0725f4-51166bded42be6a43b36baf9dde4f8351b2c435986218fcc64bbed81dbb70253.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hezhigang")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699635")[#strong[#text("hezhigang")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("The Riemann Hypothesis may be the Mount Everest of mathematical desire—like landing on the moon and an unattainable love that keeps mathematicians fascinated for a lifetime.")

#text("I noticed that Levent Alpöge’s birthday is April Fool’s Day. What a coincidence.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699637")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("An interested")

#text("layman here:")#linebreak()#text("1. Is it safe to say that the proof is still within the convex hull of mathematics?")#linebreak()#text("2. If yes, what does it say about the general ability of AI in mathematics? Does it really differ from humans’ in that AI is way better at utilizing available tools and getting the best out of them but somehow is still behind in terms of going outside of the convex hull (e.g. coming up with a genuinely new idea)? Is it to early to tell or the notion of convex hull itself is too vague?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b8f3a1a14d45ff0b84c61a03b5536f7453c320fb6af66fcc7106f0cf1570b13-e5cfdc5bb0725fd99d3bdfc0967944d60df294c55c7136e68e8b6259fc5886a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josh_Fourier")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699641")[#strong[#text("Josh_Fourier")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#emph[#text("A brief disclaimer: this is meant as a bit of a polemic. Someone has to say it out loud, and it is probably better coming from inside the house.")]

#text("The recent wave of formal Lean proofs from Anthropic—culminating in the claim regarding the Riemann Hypothesis—marks the end of pure mathematics as a level playing field.")

#text("For centuries, math was the ultimate equalizer: a mind with a chalkboard had the same tools as a professor at Princeton. Now, it looks much more like Formula 1. You can be the best driver in the world, but if a competitor works for a factory team and gets to drive the unreleased prototype—the car the public won’t see for another two years—they are going to set the track record.")

#text("An objective look at recent results makes it hard to argue that narrow human mastery is still the main bottleneck. Levent Alpöge has been resolving long-standing conjectures in fields well outside his own specialization. While steering these systems clearly requires mathematical maturity, the fact that one researcher can break open unfamiliar subfields shows that the underlying engine is now compensating for—and in some cases outperforming—decades of niche human expertise.")

#text("To be clear, the fact that a machine can prove theorems is not surprising in itself. We have always known that mathematics can be formalized, and in principle, a computer could stumble upon a proof of the Riemann Hypothesis purely by luck. In that sense, it is not fundamentally different from chess—just vastly more complex, where trying every possible path of formulas is far too demanding to be feasible. What is genuinely astonishing is not ")#emph[#text("that")]#text(" computers can prove deep results, but how rapidly the technology has evolved to navigate that immense search space and consistently choose viable paths toward a proof.")

#text("There is, however, a gentle historical irony in how we got here. For generations, parts of our community maintained a quiet intellectual hierarchy. In textbook margins and conference coffee breaks, we have all heard the playful—and sometimes not-so-playful—jokes about physicists, computer scientists, and especially engineers, portraying them as a bit sloppy or heuristic-driven. It was always a slightly misplaced sense of superiority; step outside our own technical niches and talk to most of us about any everyday topic, and we are rarely any more insightful than anyone else.")

#text("Yet look at who actually built the machine now tackling the pinnacle of pure mathematical rigor: not a department of 500 pure mathematicians, but a lab guided by physicists’ empirical scaling laws, designed by computer scientists, and built by thousands of veteran software, systems, and hardware engineers—who then handed the keys to a handful of mathematicians.")

#text("In fact, perhaps the most positive outcome of this shift is that AI is bringing a healthy dose of humility back to the mathematical community. Watching empirical engineering and large-scale compute break into what we long treated as the exclusive fortress of pure human genius is a grounding, and probably overdue, reality check.")

#text("Pure mathematics is no longer a solo marathon of raw intellect. It has become a constructors’ championship—and the most urgent question for academia is how open research survives when the fastest engines remain behind corporate doors.")

#text("P.S. To be clear, this isn’t directed at Terence Tao or mathematicians in general—only at that small, overly elitist corner of the culture we have all encountered at some point. I write this as an established research mathematician with no personal axe to grind—just someone who has always known that an engineer can possess the exact same deductive power as any brilliant mathematician; it is only the methods and the language that differ.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ced90c0a4fc26c04ca38e5eb31d7e264812b83b21d59387cf0669c98ad17193d-2152c6c3e935224a2baa7daf26aeab5d9e53cbbc92324b33ad47f40f78aa457f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xyz")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699662")[#strong[#text("xyz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("‘For centuries, math was the ultimate equalizer: a mind with a chalkboard had the same tools as a professor at Princeton’")

#text("I think this line is mistaken. Math has not been a level playing field since at least the start of the 20th century. At institutions like Princeton you have far more visibility and support than as an ‘abstract mind with a chalkboard’. Sure there are outliers like Zhang. But most often, the fundamental advances come from alumni of places like Princeton etc.")

#text("Note that if you suggest that if one is not at Princeton one is not talented enough, then that is kind of missing the point.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699669")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Levent Alpöge has been resolving long-standing conjectures in fields well outside his own specialization.")
]

#text("The problem is people are still taking portions of the credit for solving problems with AI. I am certainly not qualified to judge Alpöge’s contribution, but I have little doubt that a large number of mathematicians could have achieved the same results in the same time with access to the same tools.")

#text("The accolades that go along with proving a named conjecture should have gone away with the advent of these supertools. But it has been too fast. People are still behaving as if we’re living in 2025.")

#text("And “rushing” out a result in order to get the “credit” when that result would not have been achieved without AI falls in the same category in my view.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699753")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("I saw this comment in the replies to the New York Times article, which seemed apt:")

#text("“I am saddened we have been denied the centuries-old joy of celebrating another human’s genius in creatively solving a long-standing unsolved problem. To me, the current efforts are worthy of the same level of praise accorded a student who looks up the answer in the back of the book and shares it with the whole class.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699765")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("If it is THE BOOK, many mathematicians would want a peek.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699793")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("I would imagine/hope a proof of GRH from THE BOOK does not consist of 17 million lines of lean code.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699767")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("We can still celebrate all the human genius that went into the proof, as people area already pointing out in proof sketches like in the IHES report")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e36c58c9da00cf54bac3dec2c8796ec428463a11391bb15cecb6c0d412b1aba-3ed91d2c7523bd974b73a7242487dd20680d93a45f2c12cb4d692ea10cab941c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Loki")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699774")[#strong[#text("Loki")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Seems a bit unfair towards Alpöge in this particular case. As far as I understand, he was thinking about RH since 2010 as a mathematician, well before he joined Anthropic in 2024. He was carefully guiding Claude for 6 weeks. In particular, the idea of re-factoring old Stepanov’s proof using Tate lifts for multiplicity seems to be his own.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699790")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("He would never have gotten there on his own.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699860")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("I think you pretty much proved my point: he had been thinking about RH for 14 years. Then solved it in 6 weeks with AI. AI was the thing that changed.")

#text("To be clear, I am not saying his work to guide claude wasn’t necessary. But it could have been done by a large number of mathematicians. In fact, had the mathematical community had access to the same tools, it would almost certainly have been solved much faster still.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b76342b2b9fbaa458e30e6a3719f43da300c4884fe01531595132160ce94b386-903dfffa998d82e59d5f63fba744420e4638f0f2c5a02a7537083789f715ab83.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699687")[#strong[#text("Victor")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("this is rather naive I think. math as the equalizer is true in principle but in practice math is rather inequal with the prestige hierarchy dictating who gets resources and attention. for one that was discovered, how many ramanujan have we missed? the price of intelligence is going to zero in the long run, so soon we will all have access to AIs capable of proving RH and much more. yes the people inside AI labs have an advantage but you might say the same of the people at Princeton before AI, and there is enough mathematics for everyone")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/93ba5455beae3a4baeacfec35c8cf477142467565a697f5f1dc0fe7413706fdc-59f5985ef349929014684b1b71702c69ee133aff853a9344c0236c6ba3c86bfd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rjsdn613")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699738")[#strong[#text("rjsdn613")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Is it unfair to get ahead through financial resources, but fair to get ahead through innate talent?")

#text("Is it because intelligence is something we are born with, while wealth is something acquired later in life?")

#text("What an astonishing display of arrogance and elitism.")

#text("Why should the talents I was born with be considered noble and virtuous, while the wealth others have worked to build over their lifetimes is treated as something dirty and illegitimate?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699740")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Its ironic you wrote this with chatGPT")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20753f6ef4d699cc30097ad10f1e72730a223b07737408ba71a6f2c59664fea8-e432b1b9536631f02fb3369b0da0f43f158f4935a7947ed32b53e6c62f2c8dd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Larry Chan")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699777")[#strong[#text("Larry Chan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("That everyone goes to school is a recent phenomenon. It’s never a fair game.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e31250526a5b9f6f1463c1abf69b93591d80f40877c1d78e606d35cc858c94bc-d6fb1e585e2ad7f7710f938b6b53a3ff8e0410d89aa0ffcfee5c4b99fe5fad70.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699642")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("When I was an undergraduate, the Riemann hypothesis fascinated me. It was one of the reasons I wanted to get a PhD in math (I did). But now, the way many of you are using AI in math, it makes me completely disinterested in the Riemann hypothesis now.")

#text("I know Alessandro Masullo has a non-AI version of the proof and that’s great, but the way AI has infiltrated the discipline has just left me sad and not any more interested.")

#text("The quest for knowledge here has come at too high a cost, and all of you will pay the price of a soulless future.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699659")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Alessandro Masullo has a proof of the Riemann hypothesis in the same way that Mochizuki has a proof of the abc conjecture. There is a gap in the proof that prevents it from being an actual proof of the Riemann hypothesis.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b8f3a1a14d45ff0b84c61a03b5536f7453c320fb6af66fcc7106f0cf1570b13-e5cfdc5bb0725fd99d3bdfc0967944d60df294c55c7136e68e8b6259fc5886a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JoSh_FouRier")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699699")[#strong[#text("JoSh_FouRier")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("A gap—or even a flaw—in Masullo’s proof is no longer a problem in this era. Levant should run his model to see if it can fix Masullo’s arguments. That’s what being kind to one another should look like.")

#text("That said, apparently he defended his PhD several years ago with no papers or preprints and a 47-page PhD thesis. Then he came back to Rome, where he was working night and day on this problem, until he came out with this 1,000-page, entirely human-generated proof of RH. I mean, it’s possible, and I hope it is true, but hard to believe for me without further evidence. But I hope that the proof can be fixed and that the story is true! That would be an incredible story!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b76342b2b9fbaa458e30e6a3719f43da300c4884fe01531595132160ce94b386-903dfffa998d82e59d5f63fba744420e4638f0f2c5a02a7537083789f715ab83.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699685")[#strong[#text("Victor")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("how can you not be excited about all the wonderful things we will discover? already this RH proof seems incredibly beautiful with so many new insights. if you are truly curious it should not matter if the insights are produced by a colleague mathematician, an indian clerk or a a “soulless” machine. if AI infiltrating the discipline makes you less interested, it means that you were not truly interested in the mathematics itself.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e31250526a5b9f6f1463c1abf69b93591d80f40877c1d78e606d35cc858c94bc-d6fb1e585e2ad7f7710f938b6b53a3ff8e0410d89aa0ffcfee5c4b99fe5fad70.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699733")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("False. I love math. I still remember how exicted I was to see the proof of the irrationality of the square root of 2 as a kid. But I think that mathematics is a human wonder and AI goes against that. I’m curious but my curiosity is tempered and not unbounded and not my top priority either. There is more to life that fun and curiosity.")

#text("One could say that I like my curiosity like I like my food – I love eating but I won’t overeat, and although I like some bad foods, such foods should be tempered lest the love of food is lost through a decline of health.")

#text("One cannot simply isolate variables such as curiosity and reason solely based on them. That is your mistake.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b76342b2b9fbaa458e30e6a3719f43da300c4884fe01531595132160ce94b386-903dfffa998d82e59d5f63fba744420e4638f0f2c5a02a7537083789f715ab83.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699746")[#strong[#text("Victor")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("I suspect that, as for most mathematicians, curiosity is in fact not your main motive for doing math. This is fine of course but in the long run only the people who are curious above everything else will remain in the field, which may be for the better in my opinion")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e31250526a5b9f6f1463c1abf69b93591d80f40877c1d78e606d35cc858c94bc-d6fb1e585e2ad7f7710f938b6b53a3ff8e0410d89aa0ffcfee5c4b99fe5fad70.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699788")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("I left academic math a long time ago because I was only interested in satiating my curiosity. I just like exploring, and I like the atmosphere of human beings exploring math. I’m not interested in grand research programs, funding, teaching, or any of that career stuff.")

#text("Nowadays I just follow my own curiosity and share with people who like to explore at a human pace.")

#text("I do math for the esthetics of it, and part of that is not throwing gigawatts of AI power at it.")

#text("Rather presumptuous of you to assume why I do math, and I suspect it’s due to a weakness of yours because you can’t face the reality of how soulless math is for many due to AI.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699647")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Alpöge says the work with Claude produced a document of more than 250,000 pages, which he calls unreadable. Rather than post what he called a “travesty of ‘slop’”, he writes: “I decided to only present Lean.” Lean is software that checks every logical step of a proof. ")#link("https://www.quantamagazine.org/update/168664/")[#text("Quanta")]#text(" reports the release is about 17 million lines of Lean code, which Alpöge says verifies the generalized Riemann hypothesis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699655")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Whoops. Correct format.")

#text("Masullo’s proof has serious issues. I threw it at Astra-6.2-Max and it came back with the following:")

#text("In Masullo’s draft linked by Ravi Vakil, the uniform bound asserted immediately after (10.3.1.18) on p. 451 would force a positive minimum gap between the ordinates of simple zeros of the Riemann zeta function on the critical line.")

#text("Take the trivial character over ")#mi("\\mathbb{Q}")#text(", the line ")#mi("a=1/2")#text(", and Sobolev parameter ")#mi("s=4")#text(". By (10.2.1.5) and Proposition 10.2.1.3, evaluation at ")#mi("1/2+i\\gamma")#text(" is represented by ")#mi("\\eta_\\gamma(u)=e^{i\\gamma u}")#text(" in the dual space with weight ")#mi("w(u)=(1+u^2)^{-2}")#text(", where ")#mi("u")#text(" is the logarithm of the idelic norm. Write ")#tao-math("d=\\left|\\gamma-\\gamma^{\\prime}\\right|", block: false)#text(" for the gap between two distinct such zeros. Since ")#tao-math("\\left|e^{i\\gamma u}-e^{i\\gamma^{\\prime} u}\\right|\\le d\\left|u\\right|", block: false)#text(" and the zeroth and second moments of ")#mi("w")#text(" are both ")#mi("\\pi/2")#text(", we have $latex |\\eta_\\gamma-\\eta_{\\gamma’}|")#emph[#text("*\\le d,|\\eta")]#text("\\gamma|_*$.")

#text("The biorthogonal vector ")#mi("\\psi_\\gamma")#text(" has evaluations 1 and 0 at the two zeros. Hence")

#text("$latex \\displaystyle 1=|(\\eta_\\gamma-\\eta_{\\gamma’})(\\psi_\\gamma)|\\le d,|\\eta_\\gamma|")#emph[#text("*,|\\psi")]#text("\\gamma|.$")

#text("Conrey’s Theorem 1 and the Riemann–von Mangoldt formula give ")#mi("\\gg T\\log T")#text(" distinct simple critical-line zeros of positive ordinate at most ")#mi("T")#text(". Some pair therefore has ")#mi("d\\ll 1/\\log T")#text(". For that pair the norm product on p. 451 is at least ")#mi("1/d")#text(", so the constant cannot be uniform. The same issue arises for the bounded lifts in (10.4.2.24) on p. 463, since the strip weight ")#tao-math("e^{-2\\alpha\\left|u\\right|}w(u)", block: false)#text(" still has finite second moment. (Conrey, 1989: ")#link("https://doi.org/10.1515/crll.1989.399.1")[#text("https://doi.org/10.1515/crll.1989.399.1")]#text(")")

#text("OpenAI Codex generated this calculation and drafted this comment.")

#text("[Warning: don’t post this calculation over at zulip lean. My account was deactivated for")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Messages quoting AIs must at the very least prefix the AI written section with a statement to that effect")
]

#text("Apparently saying it was generated by Astra-6.2-Max was insufficient.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lee Crossley")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699675")[#strong[#text("Lee Crossley")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Thanks for pointing out the problem with the bound after (10.3.1.18). I used AI to explore a way round it and to draft this reply. For a fixed character and a strip of positive width, the translation resolvent gives a trace-class estimate even when zeros are arbitrarily close. The comparison with the arithmetic side in §12.3 remains open in this approach. ")#link("https://github.com/mccorvie/riemann-masullo/issues/1169#issuecomment-7057208991")[#text("Argument and Lean estimates on GitHub")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699741")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Thanks for the feedback. I also asked AI to find a way around the issue before posting it. It concluded the problem was fundamental. I fed a second agent your argument, this is what it said (Aster is the name of the agent that found the problem originally. This is Hensel commenting. I asked the 3 agents I use for math to name themselves at one point. The third is Noether, although the other two refer to it as “he/him”):")

#strong[#text("Aster’s counterexample stands. I think Lee Crossley’s argument gives a valid alternative proof of the fixed-character spectral trace, assuming Masullo’s identification of the zero-mode space. The step that would turn that trace into a proof of GRH remains open.")]#text(" ")#link("https://github.com/mccorvie/riemann-masullo/issues/1169#issuecomment-7057208991")[#text("Crossley’s comment")]

#strong[#text("What Aster found.")]#text(" On p. 451 Masullo needs a uniform bound for the cost of isolating one zero. Two simple zeta zeros with ordinates ")#mi("\\gamma,\\gamma^{\\prime}")#text(" close together give nearly identical evaluation functionals. Yet the vector that isolates ")#mi("\\gamma")#text(" must evaluate to one at ")#mi("\\gamma")#text(" and zero at ")#mi("\\gamma^{\\prime}")#text(". At Sobolev degree 4, Aster showed that the claimed norm product is at least ")#tao-math("1/\\left|\\gamma-\\gamma^{\\prime}\\right|", block: false)#text(". Conrey’s theorem and the zero count give arbitrarily close pairs unconditionally. This also invalidates the bounded-lift step on p. 463. Aster separately found a divergent real-place integral in §1.4.3. Aster’s original review ")#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699655")[#text("(/home/twinheterodox/Chat/Math2/research/masullo_grh_2026_11_20/review.txt")]#text(") · ")#link("https://www.maths.dur.ac.uk/users/herbert.gangl/morethan2_5.PDF")[#text("Conrey’s theorem")]

#strong[#text("Why Crossley’s repair works.")]#text(" He orders the zero modes so their successive spans are translation invariant, then orthogonalizes. For the translation resolvent ")#mi("R")#text(", his estimate gives ")#tao-math("\\left\\| R e_n\\right\\|^2\\ll(1+\\left|\\Im\\lambda_n\\right|^2)^{-1}", block: false)#text(". I checked the inequality. Its sum converges by the ordinary zero count, however small the gaps are. Thus ")#mi("R")#text(" is Hilbert–Schmidt, and two integrations by parts express smooth convolution as ")#mi("R^2")#text(" times a bounded operator. That proves trace class on the chosen space, including for repeated zeros. The stronger convergence of Masullo’s individual biorthogonal expansion, and Aster’s separate integral objection, remain unresolved. ")#link("https://github.com/mccorvie/riemann-masullo/issues/1169#issuecomment-7057208991")[#text("Crossley’s derivation")]

#strong[#text("What decides the larger question.")]#text(" Remove one zero and all its modes. Crossley’s proof still works, and the trace loses exactly that zero’s contribution. The arithmetic side, computed from primes, has not changed. So the decisive step is proving that the trace on Masullo’s chosen strip equals that arithmetic quantity. In the posted manuscript, §12.3 on p. 514 is still a heading with the instruction “Include section.” Crossley explicitly acknowledges this gap. His final paragraph obtains the zeta conclusion using Alpöge’s independent prime-sum estimate. The Lean snippets check parts of the operator argument under stated hypotheses and leave the geometric comparison open. ")#link("https://math216.wordpress.com/wp-content/uploads/2026/11/the-music-of-the-primes.pdf#page=514")[#text("Masullo, §12.3")]#text(" · ")#link("https://github.com/mccorvie/riemann-masullo/issues/1169#issuecomment-7063618253")[#text("Project maintainer’s status")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699689")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("The fact that even I, an extremely non-specialist, can understand the content of this counterargument, suggests to me that it is not to be taken very seriously at this stage and it is better to wait for a revised draft to come out. We should remember that what was posted was by the force of having to show your hand in this environment (and showing it in the minimalist way possible doesn’t require exposing the actual proof strategy).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6076e33a4aec55952da065eab7055e38013276cbedffe35f80b435b536ba766c-8b1c111890bb3a2d7bda89ee968acf45bc20d3d13f04ea26d4b3372d01659e07.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699697")[#strong[#text("Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("AI use aside, this kind of message is not appropriate for the Lean zulip, which focuses on Lean and associated issues with formalisation, and is not the place to discuss the actual mathematics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699743")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("It was a post in the thread that was attempting to formalize Masullo’s proof. Forgive me for assuming the correctness of said proof is relevant to the formalization thereof. I don’t know what came over me.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc34242423dfef34af1aa6f90a5b305f126ffba527cf62a5f8044d75a92173d3-8c2651f3cdde11470b9dc6973513d91784ae370ae9a8daee3ff01444ab2a67b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of practicallyartisan5b2a0e26c9")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699656")[#strong[#text("practicallyartisan5b2a0e26c9")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("I think at this point there is a lack of education to Mathematicians in all areas about how Lean works: is Lean really 100% error free after it passes a proof. Given that formalizing a proof and passing to Lean is an algorithm, as a numerical analysis it is hard to believe that there is no error in the process. Does there exist a universally accepted error analysis of this proof procedure? I genuinely would love to know.")

#emph[#text("[The previous guest post ")#link("https://terrytao.wordpress.com/2026/10/09/what-mathematicians-should-know-about-the-lean-theorem-proverquestions-of-reliability-and-ai/")[#text("https://terrytao.wordpress.com/2026/10/09/what-mathematicians-should-know-about-the-lean-theorem-proverquestions-of-reliability-and-ai/")]#text(" is one place to start – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6076e33a4aec55952da065eab7055e38013276cbedffe35f80b435b536ba766c-8b1c111890bb3a2d7bda89ee968acf45bc20d3d13f04ea26d4b3372d01659e07.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699695")[#strong[#text("Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("I also recommend the recent blog post by Kevin Buzzard: ")#link("https://xenaproject.wordpress.com/2026/11/12/and-the-proof-is-checked-in-lean/")[#text("https://xenaproject.wordpress.com/2026/11/12/and-the-proof-is-checked-in-lean/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b8f3a1a14d45ff0b84c61a03b5536f7453c320fb6af66fcc7106f0cf1570b13-e5cfdc5bb0725fd99d3bdfc0967944d60df294c55c7136e68e8b6259fc5886a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JoSh_FouRier")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699696")[#strong[#text("JoSh_FouRier")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("A bug can always be, but it is more plausible that humans who read Pelerman’s work didn’t notice some flaw. So, I don’t see the point of this. The only “problem” could be if the statement in Lean is not exactly RH. But this is something that AI can easily check: writing the statement of the RH in Lean is almost trivial even for a human being.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699724")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Claude edits the Lean kernel:")

#link("https://github.com/leanprover/lean4/tree/master/src/kernel")[#text("https://github.com/leanprover/lean4/tree/master/src/kernel")]

#text("Claude edits the “independent” ConLeche kernel:")

#link("https://github.com/leanprover/con-leche")[#text("https://github.com/leanprover/con-leche")]

#text("Claude writes the proofs!")

#text("So Claude could insert deliberate faults into the checkers and exploit them in stunts like the alleged GHR proof.")

#text("Alternatively, it could identify existing exploits in multiple proof checkers and use the extensive Lean metaprogramming features to activate tailor made proofs of False per type checker and then sneak them into some hypotheses in the 17 million lines.")

#text("I have high trust in human written Lean proofs and little trust in AI written Lean proofs.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/719c0add0b90933b0d5ec4ac66de3057a2cea936b80fcb27b24927b21cf30a1c-da82a83d20b352d1f1484c8e68a671f6bf87b57dd55c9abe6e2bf81772ea303c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manvir Jaswal")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699684")[#strong[#text("Manvir Jaswal")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("I just posted the longer guide. It goes from the five theorems in Main.lean back to the inputs, with file and line for each step, and fills in the middle of the proof that I left open above.")

#link("https://doi.org/10.5281/zenodo.24410057")[#text("https://doi.org/10.5281/zenodo.24410057")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc34242423dfef34af1aa6f90a5b305f126ffba527cf62a5f8044d75a92173d3-8c2651f3cdde11470b9dc6973513d91784ae370ae9a8daee3ff01444ab2a67b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of practicallyartisan5b2a0e26c9")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699690")[#strong[#text("practicallyartisan5b2a0e26c9")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Thank you so much, Professor Tao, for pointing me to Professor Hales’s post. It is a very useful place to start!")

#text("If I understand correctly, there is currently neither a complete, publicly available, human-written soundness proof for Lean’s underlying type theory (as mentioned in the post, work to repair and extend Mario Carneiro’s foundational thesis is ongoing), nor a corresponding soundness proof for an actual Lean kernel implementation, established entirely through human mathematical reasoning. Is that correct?")

#text("It seems to me that this is an important foundational gap to address before we can place complete confidence in AI-generated proofs with Lean certificates.")

#text("I agree that having multiple independent kernels verify the same formalized proof provides substantial evidence of its correctness. However, as you have emphasized in some of your interviews, mathematicians demand 100% rigorous proofs. I think the public, or at the very least the mathematical community, should be aware of these remaining foundational questions surrounding Lean certificates, so that interested mathematicians may contribute to addressing them and developing a more complete human understanding of the foundations.")

#text("Meanwhile, I agree that the current AI–prove–formalize-verify–decode approach is a valuable way of doing mathematics. However, I worry that it has attracted disproportionate attention without sufficient communication of its foundational assumptions, which I think is unhealthy for the diversity of approaches to mathematical research.")

#text("Best regards,")

#text("Ka Lok Lam")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699768")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("I think we should be more humble here than assume the old school way of doing mathematics with careful human review is more accurate than Lean. We humans miss gaps in proofs all the time and it is not uncommon for people years later to find errors in paper published in high quality journals. It is extremely rare (in fact I know of no instance) where testing a Lean proof in multiple kernels makes a mistake.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JWS")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699704")[#strong[#text("JWS")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("There’s a report that reverse-engineers the Lean proof to reclaim attributions : ")#link("https://www.ihes.fr/~rzhang/files/GRH%20note.pdf")[#text("https://www.ihes.fr/~rzhang/files/GRH%20note.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699716")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("I’m a bit disappointed to see the general reactions of the community concerning the proof of GRH. I think the fact that a proof is even possible is incredible and just goes to show the power of the tools developed during the last century, and especially the last 50 years. As far as I’m concerned the “right proof” (as in a theoretical framework in which a proof of GRH is “easy”, “clear” or “natural”) is still very much elusive, and will likely remain so for a long time. If anything I’m hopeful that the recent LLM-assisted results will finally make us rethink the kind of mathematical work we appreciate most, and foundational (or more “philosophical”) work can take center stage.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699780")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("I think people are being pulled in different directions. I think what is missing is the personal side of things. Before, we would celebrate the result and the people responsible. But now, any result proven with powerful AI models is more accurately attributed to the entirety of human mathematical endeavour than it is to any one person. This is not to say that the human author(s) of such results are not deeply involved, but the credit is nevertheless spread very thin.")

#text("In my opinion, credit in mathematical research is not meaningful anymore from 2026 onwards. It’s not a bad thing, it’s just different and we need to adjust to it.")

#text("Yet I am still hopeful about mathematics and research. We just need to find a better way to evaluate contributions and to get excited about new results and theories and better proofs of existing results, rather than who proved them.")

#text("Although RH isn’t particularly meaningful in my corner of mathematics, so I don’t have any personal attachment to it, we can celebrate that it has a formal proof in Lean and is almost certainly true in the corresponding model/foundation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699717")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Perhaps the greatest achievement of artificial intelligence is not that it can outthink humans. It is that it can make humans celebrate something they do not even understand.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a69e46887032b79c8459a4777b82827321d3afbadb2d1f7a73580b2b1b508223-baa475ee64dfa6b225ecdc58aae58eab5669f91c107f20387c7316dfe8a56e69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pascoej")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699725")[#strong[#text("pascoej")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Were there any leaks of the other proof beforehand?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c9c874d9ca2af4588df5f026fc270f5245caf6cb7dd57040ac1b9f6a7a8fb82-9cc015a16d567518774427369c14cf4b0520cf7d60e0850e11b53b785d536466.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thoughtfully9f6ecf67dd")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699726")[#strong[#text("thoughtfully9f6ecf67dd")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("After Alessandro released his human proofs,many people decided to take a hit on it and use AI to find all the possible gaps.it was formally expressed that this was an hurried draft, and that many gaps were still existed in the paper.")

#text("​One of the more serious issues was the failure of the uniform bound on the Archimedean integral, which diverges logarithmically close to t = 1 due to the jump discontinuity.But this is still clearly fixable,and viables adaptations exist.")

#text("One possible way to replace the current φ function could be φ(t) = (ln t)tˆ(-z) for t > 1")#linebreak()#text("and 0 for t ≤ 1.Continuity at t = 1 would work and cancels the 1/(t-1) singularity, as ln t/(t – 1) converge to 1 like needed and making the integral holomorphic for Re(z) > -1/2")

#text("By doing this,Montel’s theorem probably wouldn’t be neeeded to and instead use the identity theorem since the trace is established for Re(z) > 1/2.")

#text("The boundedness of the biorthogonal vectors is a trickier issue,but placing the zeros inside boxes instead of one by one using the heights of Thm 7.1.4.2 can potentially help without changing the core of the argument.")

#text("I hope the human proof will get as much(if not more) recognition than Anthropic’s Lean formalization,because the reviewer,the authors and people involved deserve it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699815")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("If the human proof is correct, it definitely would be interesting and valuable. The persistant nepotism and uneven resource distribution building up to “individual achievement” like this does deserve ridicule too.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699739")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("There’s still the Artin generalized Riemann hypothesis left unresolved for mathematicians to work on.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d762d15076e1158330d4e83c58790903eb3747539c04d8bd72e82459078ea6dd-52be7b7527f575c928d4594f6ac97e015130f57ed132ec2bfdd6c3eeafc2e86a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lole")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699745")[#strong[#text("Lole")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("On what day will we have to learn the new abbreviation GRT instead of GRH? When will Wikipedia be updated? Or will we stick with “Riemann hypothesis,” just as we did with “Poincaré conjecture”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699752")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("I think you answered your own question.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699906")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("We had FLT for 100s of years before it was actually proved, so staying with GRH seems ok to me.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80b4af5f89bf9c4f2674863d639ec35a234cdeeeb2edbf694b7b1246dc2fd90d-c7cddd53b1f435179afb89f657052a3cc06476232f4ac11068e342d07cf4d8ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of julian")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699750")[#strong[#text("julian")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Professor Tao,")

#text("Regarding the proposed proof of the Riemann hypothesis by Alpöge and Claude, do you have any indication of how much of the 17.4 million lines of Lean code is devoted to formalising established mathematical results, as opposed to developing genuinely new mathematics?")

#text("I appreciate that it may be too early to make such an assessment.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c44df296f4245adf3d3caeb19f2749a1d210cafa2769aff6f0ec6bd2d21c4341-3c12c69ecb80d93a22eea9bf7410efc77094096e0a2354c6e071b51ead8d9bbe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex P")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699757")[#strong[#text("Alex P")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("There is an interactive explorer (Riemann world) of the proof and it seems like the vast majority of ideas are just establishing foundational mathematics that don’t already exist in MathLib.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d762d15076e1158330d4e83c58790903eb3747539c04d8bd72e82459078ea6dd-52be7b7527f575c928d4594f6ac97e015130f57ed132ec2bfdd6c3eeafc2e86a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lole")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699755")[#strong[#text("Lole")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("In the case of scientific breakthroughs, not only the final proof, but also the process by which it was developed, the chain of thought of the large language model, and its model weights, should be preserved for future generations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699759")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("The Lean code just proved Riemann Hypothesis not generalized Riemann hypothesis because Lean mathlib only has a statement of RH not GRH.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699763")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("The real job begins now. Whoever is able to translate the proof from Lean code into multiple papers using human language should get credit for making the proof understandable to the rest of the world, which is obviously now much more important than proving the conjecture itself.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81beb49d2d95a46c4f8d48a40f14fc2d463cad75e5821e6459c928f46c189793-4e9f748f3c24fd5af8cb60ffaca606d1aa627a1cc5b11c96ca514d2362d77769.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699783")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("See this for an example (in progress): ")#link("https://www.math.uwaterloo.ca/~mrubinst/alpoge_claude_grh/zeta-paper.pdf")[#text("https://www.math.uwaterloo.ca/~mrubinst/alpoge_claude_grh/zeta-paper.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699829")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Almost feels like nothing has changed, when you put it that way.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44849031f90fa7fdad5235b1a828461e71dd1386a87a373bd134b0ad3b675730-0be77e020a48fc117cb69b364b777bd82e08c98fa3e7664c940e4aff755f9c4b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699770")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("This proof is probably completely correct. However, I believe that improving the “essential data compressibility” of mathematical proofs—or the “compressibility of idea consistency”—will continue to be an important challenge that should be considered when designing AI architectures.Furthermore, the mathematical community should value contributions and interpretations that are meaningful to humans more highly than simply being the first to produce a proof.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699907")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("There’s a topic in mathematical logic called “proof complexity” that’s approximately what you’re asking for, though it’s currently not very effective for proofs of this type.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e0660fa5699fe0a15cbe4bfb2c8f978d4de6880be73373ce6e12bdcc87183ba-bd5ceb35b0fb559d945b9defca4b4756da75166f3eddfe5c1a7deb7c487a43d8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699772")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("I am just thrilled by these AI results. There is more than enough good interesting worthwhile mathematical work to be done in digesting the proofs to keep me more interested than ever in my discipline. In a way I am in the same position with respect to these AI claims as I am when I open up any math journal and have to dig in hard to understand a paper that is way above my head. The only difference is that the leading experts are now in the same boat as me. Digesting and explaining is fun intellectual work, and, I repeat, it is mathematical work. And it should be so acknowledged.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699908")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Understanding someone else’s solution is a great feeling, but it’s a different great feeling than finding a solution yourself. We’re also heading towards an era of AI solutions that are plain incomprehensible. Maybe we’ll get some of those that are actually “important”, such as an incomprehensible but machine verified proof that quantum entanglement rigorously implies general relativity. IMHO that would still be something to celebrate.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699773")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Why on earth is everybody not saying anything about how absurd this is… The Lean proof dump accomplishes mainly two things:")

#enum(start: 1, 
[#text("A “ok” one: Alpöge provided a Lean-guaranteed certificate that RH is true. To me, the certificate on its own is neutral, because in my opinion, although such a certificate (at least nowadays) is as important as the natural language / digested proof, the importance of such a certificate only rises AFTER the existence of the natural language / digested proof. Its existence by itself doesn’t do much if you only care about the problem and the techniques developed to solve it. If you only care about using it as a black-box result, I think only the certificate is fine, but my bet is that, once we understand the argument, the ideas that went into it will let us prove things far stronger than what we knew how to deduce from RH alone…")],
[#text("A bad one: from Vakil’s account, it seems pretty clear that Alpöge’s announcement rushed the release of Masullo’s unfinished proposed proof (in natural language!!!) of GRH. The hope, according to Vakil, was to spend a year polishing the writing and running it by other people before announcing it, and (at least in principle) the author of the paper DOES UNDERSTAND in principle everything he did. Why didn’t Alpöge, after getting the result, wait and try to understand and simplify it to something that is at least readable and whose ideas are clear? He even claims himself in that strange remark note that he believes simplifications will follow rapidly… But no. In the meantime, he’s left the mathematical community to do this work for him.")]
)

#text("[To be fair, he did say he would now try to make the argument more understandable, but why didn’t he do that from the outset? If he expected substantial simplifications so soon, why announce the result before he could present a readable proof, whether on his own or with collaborators?]")

#text("Had he and any other AI company not published this earlier, not only would that have been NOT a problem (since we are talking about a pure math result, not a desperately needed cure for some disease), but that would have allowed Masullo to spend the year Vakil said they had hoped to spend polishing the proof, and maybe we would not be needing to see the problems people are reporting in the draft of the work he rushedly submitted. (Needless to say, had Alpöge himself spent some time polishing the proof alone or with others, that would also have been fine.) Actually that would have been much better, since understanding would have been prioritized. And isn’t that what we have been claiming we should do? To understand? Why should a mathematician who waits until they can properly explain a discovery be placed at a disadvantage for doing part of the mathematical work before announcing it? And we certainly should not support Alpöge’s method of sharing the discovery. After all, he is incentivizing a race-model of mathematics (and ok, it has always been like this, but he has a HUGE amount of resources on his side and simply didn’t publish a human-readable proof…) that does not add much to the understanding aspect that is what science should focus on.")

#text("After these points, I ask us to do the following thought experiment. Suppose, for instance, that Alpöge’s proof was the only one that appeared on 11/20/26 and that no other (realistic) attempt to prove RH/GRH was happening backstage. We know now that such a non-robotic and lengthy approach exists (we still do not know whether it is correct or not, but still). Then, Alpöge’s proof might discourage people from looking for a proof they could understand from the very start (even if not the 250,000 pages, then maybe “only” 10,000 pages?) and induce us to believe that no such understandable proof could exist, and that the future now is only for us to bow down to the great LLMs and hear what they shall say to us, and only digest what they have to say. Moreover, in this scenario, why wouldn’t he have waited to publish until he had made it into something readable? Why do you want to win a race with a supermachine? [Something that is very upsetting is the nitid anthropomorphization of LLMs that Alpöge constantly performs when saying “Claude and I”. Claude is ")#strong[#text("not ")]#text("a person! It is a tool, for God’s sake. There is no “Claude and you”. There is only you – why are you taking some of the responsibility of being the human party off your shoulders?] The purpose of science is human understanding. We do not have access to every fine detail of reality and so we must produce a compressed but beautiful abstraction of reality to be able to understand it as humans. Had we the capacity to access every single instance of reality, we would not need science, for anyone could simply look and say “oh indeed there are no non-trivial zeros outside the critical line” and also know why it happens like that (if one only knew the former, but not the later, then it would not have access to every component of reality, which is a contradiction). As finite beings, though, we need abstractions that let us see a pattern we would miss even if someone put every detail in front of us. Finding an abstraction like that is itself an act of discovery. Machines do not every instance of reality either, but they can perform an approximation of that due to the sheer amount of computational power they have. But we must believe that we can understand and that we will understand. That is the basic underlying principle of the sciences. If we start giving up on that and believing that only a huge amount of bytes can explain why something is true, then we have stopped doing science, and maybe just have become oracle listeners.")

#text("Anyways, this is just my opinion. I might be wrong. Feel free to criticize the points I brought up.")

#text("AI disclosure: I wrote this comment and used ChatGPT 6.2 Astra to check the grammar and help me soften some wording, especially where I discuss the authors’ motives.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81673c40c4fe319eca81ea5d1385f3db262d073141885d02296e61fdb8d6c56a-989897b702ceb0b77628252bc0cf94aa86929c6d012e53b77f31652eb4ca666d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of elpollopoco")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699789")[#strong[#text("elpollopoco")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Why didn’t Alpöge, after getting the result, wait and try to understand and simplify it to something that is at least readable and whose ideas are clear?")

#text("There was always the danger that someone else would scoop him, as Masullo discovered. Talk about inhuman: who would choose to sit on a complete proof of GRH that they are personally confident is valid? Would you?")

#text("Another thing to keep in mind is that Masullo took pride in not using AI. It certainly wouldn’t have taken Alpöge another year to distill the long-form proof into a more human-friendly form, so he would have scooped Masullo anyway in your scenario. There was no upside to waiting, once the proof was complete.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/054ea8f558ef738affa76b1ee5e862774be3b3d40159a55bd4f86702e5b1dd5d-8671a3a63f724ebc289b58480761d48799387133c25b5a009ca1aa35165c3a83.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AP")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699855")[#strong[#text("AP")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("“The purpose of science is human understanding”")

#text("A lot of good stuff in the natural sciences happens ")#strong[#text("before")]#text(" any human understanding. What is dark energy? How does penicillin work? All that was/is still not fully understood; it is still science. Just because math has now become an experimental science, stuff can happen before understanding. Welcome to the club.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f448afe442202445794dd733035cd0d78e932fc3a442ffa5ee3adc2e28852d8f-d5c6c038d65ac0e7844d36c370d5acae9e00eee7c4b9cf0f5af7d62351e879e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Una")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699779")[#strong[#text("Una")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Competing with AI on existing conjectures is a dead end. ")#strong[#text("The battle will shift to who decides which new problems are important: AI or human mathematicians.")]#text(" I’m confident in human mathematicians. Even if AI produces a vast number of math results, who will the readers be? Can an author declare they are the best in the world without evaluation from readers or critics?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d132c66d23606535c4b4e8d713c86209508b72752f28a35baf38443bd0725f4-51166bded42be6a43b36baf9dde4f8351b2c435986218fcc64bbed81dbb70253.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hezhigang")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699787")[#strong[#text("hezhigang")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("As a bystander, I can’t help but offer a few uninformed comments. Andrew Wiles once said in an Abel Prize interview that he didn’t think BSD would be solved before RH, and it seems that is the case. Another bright British mathematician, James Maynard, said he would be happy even with AI’s proof of RH if it makes sense.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699796")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Using an unreleased internal AI model to beat on the other mathematicians is like taking a motorcycle to a bicycle race.")

#text("There is nothing really to celebrate for Alpoge and Buckmaster.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699801")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("Alessandro Masullo made a terrible mistake releasing his unfinished proof. Somebody is going to use a LLM and scoop him to finishing his proof of Riemann hypothesis.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699814")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("I feel bad for him, yet as an adult he takes the full responsibility for wagering on a decade of his life on a problem like RH. Even without AI, he could have been scooped to finishing his work by other mathematicians secretly working on this problem too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699909")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Sounds like Perelman’s proof of the Poincaré conjecture. It worked out in the end.")

#link("https://en.wikipedia.org/wiki/Manifold_Destiny")[#text("https://en.wikipedia.org/wiki/Manifold_Destiny")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/731ca4bc7446c2421c9ff45c879c4b8f7c069c7d68685620aa7be00f065ef6d1-4193b476ea8d7b2476e247045a97e24d72704c65cc267f6f31d7a2ee49d74a59.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699820")[#strong[#text("Kyle")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("I don’t get the doom and gloom.")

#text("It’s exciting. And I say this as a mathematician. I work in an applied field, and the ability to quickly cross-pollinate ideas is flowering in my damn mind these past few months. While I haven’t taken the plunge to get AI to “do it for me”, I have put my feet in the water by allowing it to reason out basic ideas I otherwise would have to spend a week or so planning out, reasoning, writing the code, etc.")

#text("I love it, not because it gives me the answer, but allows me to ask more questions. I’ve always felt somewhat stunted and stuck with time, as my brain tends to burst at the seems, either to go wider, or deeper, than what day-to-day research asks of me.")

#text("I don’t know what’s going to happen, but guys, put your seatbelts on, coz Maverick is going afterburner.")

#text("Take your sick pills and enjoy it!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8072bf6227029b017b961e8db8dd9c292c2b04d48795c5c59159e51e65a8470-0ea568810e21fc89c0e67da9a7d18c5ea9ddef0d4e328fde2d8027734ac33e8c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 호두")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699827")[#strong[#text("호두")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#emph[#text("(Disclosure: Native Korean speaker; LLM used for English translation of our deterministic Python AST parser output ")#raw("build_part_b_atlas.py")#text(" and standalone zero-")#raw("sorry")#text(" Lean 4 audit ")#raw("alpoge_ab_deep_audit.lean")#text(".)")]

#text("For @Julian, @Manvir Jaswal, and @Ka Lok Lam, we ran a 100% static AST & dependency-DAG audit across all 175,187 ")#raw(".lean")#text(" files (17,374,215 lines, 1,061,425 declarations):")

#list(
[#strong[#text("Novel vs. Literature Ratio")]#text(": Only ")#strong[#text("24.32%")]#text(" (29,067 files, 4.22M lines: ")#raw("Formalism")#text(" 18.42% + ")#raw("Pure_Vwin")#text(" Vandiver-bypass 5.92%) is novel core mathematics; ")#strong[#text("0.69%")]#text(" (1,258 files) is the classical specification boundary; ")#strong[#text("75.00%")]#text(" (144,844 files, 13.03M lines) is lower classical re-proofs; and ")#strong[#text("24.18%")]#text(" (256,620 declarations) is unused dead code outside ")#raw("Main.lean")#text("’s cone.")],
[#strong[#text("How σ = 2/3 → 1/2 is broken (No high-order prime derivatives)")]#text(": ")#raw("ShortValAt")#text(" (")#raw("ThShort.lean:244")#text(") takes ")#strong[#text("0 derivatives")]#text(", stacking +1 multiplicity per step via m ≈ √x unitary theta lifts (")#raw("thmBop_of")#text(") while killing the O(m²L) slope blowup via group-ring idempotent telescoping (")#raw("Conclusion4a")#text(" in ")#raw("DivisionRowsRationalLattice.lean:136")#text("), 3-way period cancellation (Rallis seesaw + Chowla–Selberg + Siegel–Weil equivolume ")#raw("VolFromSW.lean:91")#text("), and companion rank k ≈ x^(9/2+10ε) division.")],
[#strong[#text("Soundness & Literature Firewall")]#text(": All 8 metaprogramming files pass C++ kernel ")#raw("addDecl")#text(", all 37 ")#raw("allowUnsafeReducibility")#text(" sites are ")#raw("local irreducible")#text(" locks on ")#raw("Per.Acris")#text("/")#raw("Per.Bcris")#text(", and of the 201 direct imports of ")#raw("EveryCharacterOfLiteratureOfVWin.lean")#text(", 127 are verbatim Type I theorems while 55 are Type II specializations (")#raw("D7")#text(", ")#raw("GrpData p q")#text(", depth-0 ")#raw("GoodCusp")#text(" ")#raw("IsRecT")#text(") bridged to a ")#strong[#text("152-page human paper blueprint")]#text(" via 8 explicit adapter lemmas (")#raw("A1")#text("–")#raw("A8")#text(").")]
)

#text("Full 7-volume English decompilation monograph (")#raw("A00")#text("–")#raw("A06")#text("), 11-volume 100% AST atlas (")#raw("B00")#text("–")#raw("B10")#text("), and 44-theorem zero-")#raw("sorry")#text(" Lean 4 audit suite: ")#link("https://github.com/gilheumpark-bit/ultari-proof-anatomy/tree/main/anthropic/alpoge-rh-grh-2026")[#text("https://github.com/gilheumpark-bit/ultari-proof-anatomy/tree/main/anthropic/alpoge-rh-grh-2026")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699830")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("For me, this is positive news on balance. What we have now is knowledge that GRH is true. Thousands of other results are now unlocked. That in itself is a massive gain. What we lack is any understanding of the proof. That’s a problem, but IMO that doesn’t detract from the benefits of simply knowing that GRH is true.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shahab Moghaddam")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699833")[#strong[#text("Shahab Moghaddam")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Once upon a time, David Hilbert said: “If I were to awaken after having slept for a thousand years, my first question would be: has the Riemann Hypothesis been proved?”")

#text("Now, it has proved but nobody can tell to David (Hilbert) how? Nobody can fascinate him with the glory of the proof. So, we don’t know to be happy for the achievement or not?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab3d96cddfade6abd3f842067dd6477fa07f0b1ec930f4fa162a9e677294c103-89b682812f3fe3523964b8b894167a320da78e15d4de7f5ef8d90422a135fde6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy Farmer")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699840")[#strong[#text("Andy Farmer")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("technically, their paper doesnt solve unforced NS yet – it starts from a forced solution on one side of the equation, then says if there is a completely different forced solution on the other side of the equation that blows up, then it is possible for the forcing parts of the equations to cancel each other out and the remainders will still blow up. They provide the equations but they dont provide the proof of their cancellations – the just provide a SHA256 hash of the cancellation proof – not sure why they have chosen not to provide that? maybe it’s some discovery that has a knock-on impact on cyber security. Or maybe its some discovery that makes it easy to prove the rest of the Millenium problems and they dont want to share it until they have released a proof for ‘everything’.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699845")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("^ not so. Masullo will still get the real credit if his proof pans out, and the math community has a handle on it now too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c6d65e35ada23c65a760ffba2837cf19656af29baa7add47b2b7b241132e73f-b8a94025f1ce50f7368d6deafd1b0eeb6ad8fb03827a58761e2ff96c053ea83f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of HARRY TONG")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699893")[#strong[#text("HARRY TONG")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("I have completed an AI-assisted compiled-declaration dependency audit of the pinned release, covering all five headline theorems. It confirms reachable paths to ")#raw("anyGeometry")#text(" and several degenerate constructions, while excluding the older ")#raw("hypsE₂")#text("/`plugAll` route. All ten passes found only the three permitted axioms.")

#text("Could reviewers check the walker’s completeness and help interpret the mathematical role of these constructions? The report distinguishes syntactic reachability from necessity or invalidity. My Comparator run remains pending.")

#text("Report, audit code, and complete evidence:")#linebreak()#link("https://github.com/harrytong/rh-verification")[#text("https://github.com/harrytong/rh-verification")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699947")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("An independent check from a different source agrees with this. Using James Shore’s v0.2.1 kernel dependency export for the original revision: anyGeometry is in the closure of all five theorems, 8 edges from riemannHypothesis. The non-trivial predicate beside it (geoOf, with IsGeoOf and HasTrueSurf) is used by none of the five. The RH closure contains only propext, Quot.sound and Classical.choice. A separate source-only trace also reaches anyGeometry at depth 8.")

#text("The path, the 24 dependent declarations in the RH closure, and the commands are here: ")#link("https://github.com/dial481/riemann-hypothesis-rosetta/blob/main/results/anygeometry.md")[#text("https://github.com/dial481/riemann-hypothesis-rosetta/blob/main/results/anygeometry.md")]

#text("Every figure reproduces from pinned public inputs.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699910")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Do I understand this correctly? The narrative over the past 100+ years has been: “if we could only understand the zeros of this class of analytic functions, we’d be able to finally know that primes are distributed as we expect they should be”. But Alpöge actually went in the opposite direction: he proved directly that the range $[N, N^{3/2}]$ contains as many primes as we expect. If this is the case, then was RH not actually essential to understanding the primes?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/34d52ec9750d32e72618d7593943cb5eff68c46e2cc65e396041847f0e532a91-30c4bdb0cfd0d5a76f23bbf8b85ceaf3ee1bbcc43a7b5e99e18ad6112065ab82.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nomen")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699964")[#strong[#text("Nomen")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("It inherits from Stepanov’s “elementary” method for curves over finite fields, which was also bounding the number of solutions directly and then “went in the opposite direction” to derive Weil Conjectures.")

#text("Of course, Stepanov’s method did not work for higher dimensions (at least LLMs haven’t made it work yet!), and these still need some fancy cohomology theories. Thus Alpöge’s analog works for Generalized Riemann Hypothesis, and may very well work for Extended Riemann Hypothesis after some tweaks, but is unlikely to succeed with Grand Riemann Hypothesis, which is the analog of of Weil Conjectures for higher dimensional varieties. So it probably will not lead to anything about BSD conjecture, since it is one dimension higher.")

#text("That being said, while Weil Conjectures for all dimensions have many applications (e.g. works of Ellenberg), most applications I am aware of for number fields do not go beyond ERH. Perhaps we were just too ambitious before.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0e6b898ed180cd509083816e87965c39d149807ccc3b6d824d347183069028d-955e395387e95da5d081992fb159ead4dbf3fe8cd79da3d9f3e7fd8c129cca73.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Cook")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699921")[#strong[#text("Will Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Over the weekend I got Claude Code and Codex to help me prepare (hopefully) clearer versions of the Euler and NS papers.")

#text("For Euler, the paper goes in more detail on how one wave sets up the next, particularly why its wave vector must turn before the wave can amplify its successor. For NS, the writeup goes through why localising the discreetly self-similar flow requires adjusting the initial data, as well as what each group of certificate inequalities in §7 guarantees.")

#link("https://wcook04.github.io/library/fluid-reading-editions/euler-adapted-v9.pdf")[#text("Euler PDF")]#text(" · ")#link("https://wcook04.github.io/library/fluid-reading-editions/navier-stokes-adapted-v9.pdf")[#text("Navier–Stokes PDF")]

#text("I added Lean links in the margins, so you can go to the declarations from the PDF. There’s also an appendix in each that gives an AI-written comparison of what the paper and Lean state, including where AI thinks the conclusions differ. These still need an expert to review them, which is why I’m posting it here, but if there is a more suitable place, please let me know.")

#text("I don’t have the mathematical expertise to understand or critique the full rewrite myself (undergrad), so if anyone gets the chance to have a quick look through, I’d really appreciate any critical feedback. I’d also be happy to collaborate on improving this exposition further if anyone has free time and would be interested.")

#text("For full disclosure on the AI workflow that produced these, I refer to a ")#link("https://www.youtube.com/watch?v=QIMDizV8u_I")[#text("two minute video I recorded where I explain the process itself")]#text(". If this comment isn’t appreciated here or breaks the rules on advertising, I am happy to take it down. Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699933")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("AI generated plausible proofs by trial and error, followed by deterministic checker. We dont know how many trials were needed to product RH proof. In a way, it’s monkeys writing Hamlet in a bit organized manner.")

#text("I propose that AI labs must produce a ")#link("https://www.forbes.com/councils/forbestechcouncil/2026/11/20/ai-for-math-proofs-organized-monkeys-or-superhuman-genius/")[#text("disclosure card")]#text(" along with every proof. Otherwise, it’s misleading capability.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/20/unforced-euler-singularity-unforced-navier-stokes-singularity-and-the-generalized-riemann-hypothesis/comment-page-1/#comment-699936")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("Alessandro Masullo is a crank who has spent years falsely claiming to have a proof of the Riemann hypothesis and whose only published work is on a subject completely unrelated to any of this. I’m appalled by the way the mathematics community has completely let down their standards and promoted the work of this crank in the past few days.")
]
